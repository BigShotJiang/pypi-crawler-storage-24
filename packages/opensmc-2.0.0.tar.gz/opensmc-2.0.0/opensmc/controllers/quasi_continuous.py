"""Quasi-Continuous 2-Sliding Mode Controller.

A 2-sliding mode controller that is continuous everywhere except at the
2-sliding manifold σ = σ̇ = 0 itself. In practice, this means the control
is always continuous (since exact σ = σ̇ = 0 is never reached with noise
and discrete sampling), which significantly reduces chattering.

Reference
---------
Levant, A. (2005). Quasi-continuous high-order sliding-mode controllers.
    IEEE Trans. Automatic Control, 50(11), 1812-1816.
Shtessel, Y. et al. (2014). Sliding Mode Control and Observation,
    Sec 4.2.4, Eq 4.30, and Sec 6.6.2 (arbitrary-order generalization).

Formula (2nd-order, relative degree 2)
--------------------------------------
    u = -α · (σ̇ + β|σ|^{1/2} · sign(σ)) / (|σ̇| + β|σ|^{1/2})

The numerator is the prescribed convergence surface: σ̇ + β|σ|^{1/2}·sign(σ).
The denominator normalizes it to [-1, 1], making u continuous.

Sufficient condition: α·Km - C > β²/2 (from Theorem 4.3).

Properties
----------
- Continuous everywhere except σ = σ̇ = 0
- Finite-time convergence to 2-sliding mode
- |u| ≤ α (bounded by design)
- Significantly less chattering than twisting or prescribed convergence
- Sliding accuracy O(τ²) with sampling interval τ
- Preferred by the textbook authors over nested controllers (p.228)
"""

import numpy as np
from opensmc.core import Controller


class QuasiContinuous2SMC(Controller):
    """Quasi-continuous 2-sliding mode controller (Levant 2005, Shtessel Eq 4.30).

    u = -α · (σ̇ + β|σ|^{1/2} · sign(σ)) / (|σ̇| + β|σ|^{1/2})

    Parameters
    ----------
    alpha : float
        Control magnitude. Must satisfy α·Km - C > β²/2 where
        Km is the minimum input gain and C is the disturbance bound.
    beta : float
        Convergence parameter. Larger β gives faster convergence
        but requires larger α. Typical: β = 1.0 to 5.0.
    c : float
        Surface slope for computing σ = c·e + edot (when no surface
        is provided).
    surface : SlidingSurface or None
        Optional pluggable surface for σ computation.
    epsilon : float
        Small positive constant to avoid division by zero when
        both σ and σ̇ are very close to zero. Default 1e-10.
    """

    def __init__(self, alpha=10.0, beta=2.0, c=1.0,
                 surface=None, epsilon=1e-10, g_sign=-1.0):
        super().__init__(surface=surface)
        if alpha <= 0:
            raise ValueError(f"alpha must be positive, got {alpha}")
        if beta <= 0:
            raise ValueError(f"beta must be positive, got {beta}")
        self.alpha = alpha
        self.beta = beta
        self.c = c
        self.epsilon = epsilon
        # g_sign: sign of the input gain in σ̈ = h + g·u.
        # Default -1 for σ=e on DoubleIntegrator where σ̈ = -u.
        self.g_sign = np.sign(g_sign) if g_sign != 0 else -1.0

    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute quasi-continuous 2-SM control.

        Parameters
        ----------
        t : float
            Current time.
        x : ndarray
            State vector. For 2nd-order: [x1, x2].
        xref : ndarray
            Reference. For 2nd-order: [xref1, xref2].
        plant : Plant or None
            Not used (model-free controller).

        Returns
        -------
        u : float
            Control signal, bounded by |u| ≤ α.
        info : dict
            Contains 's' (σ), 'sdot' (σ̇), 'e', 'edot'.
        """
        # Tracking errors
        e = xref[0] - x[0]
        edot = (xref[1] - x[1]) if len(xref) > 1 else -x[1]

        # Sliding variable σ
        if self.surface is not None:
            sigma = self.surface.compute(e, edot, t=t, **kwargs)
        else:
            sigma = self.c * e + edot

        # σ̇ estimate (for linear surface σ = c·e + edot)
        sigma_dot = self.c * edot

        # Quasi-continuous control law (Eq 4.30)
        #   numerator = σ̇ + β|σ|^{1/2}·sign(σ)
        #   denominator = |σ̇| + β|σ|^{1/2}
        abs_sigma_half = self.beta * np.abs(sigma) ** 0.5
        numerator = sigma_dot + abs_sigma_half * np.sign(sigma)
        denominator = np.abs(sigma_dot) + abs_sigma_half + self.epsilon

        # The textbook assumes g > 0. For g < 0, flip sign.
        v = -self.alpha * numerator / denominator
        u = v / self.g_sign

        info = {
            's': sigma,
            'sdot': sigma_dot,
            'e': e,
            'edot': edot,
        }
        return u, info
