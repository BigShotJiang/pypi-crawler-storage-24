"""OpenSMC RL — Reinforcement learning integration.

Provides:
- RLDiscoveredSurface: wraps a trained SB3 policy as a sliding surface
- Training utilities for RL + SMC hybrid controllers
"""

from .rl_surface import RLDiscoveredSurface

__all__ = ['RLDiscoveredSurface']
