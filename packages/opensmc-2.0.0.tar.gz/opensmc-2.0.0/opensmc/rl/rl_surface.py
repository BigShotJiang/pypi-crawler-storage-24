"""RL-Discovered Sliding Surface — wraps a trained RL model as a surface.

This bridges reinforcement learning and classical SMC: an RL agent learns
an optimal sliding surface function s(e, edot) that can be used with any
reaching law and plant in OpenSMC.

Usage
-----
# Train a model
from stable_baselines3 import PPO
model = PPO("MlpPolicy", env).learn(50_000)
model.save("my_surface")

# Use as a sliding surface in OpenSMC
from opensmc.rl import RLDiscoveredSurface
surface = RLDiscoveredSurface("my_surface")
ctrl = ClassicalSMC(surface=surface, reaching=SuperTwisting(k1=15, k2=10))
result = Simulator().run(ctrl, plant)
"""

import numpy as np
from opensmc.core import SlidingSurface


class RLDiscoveredSurface(SlidingSurface):
    """Sliding surface learned by a reinforcement learning agent.

    Wraps a trained Stable-Baselines3 model (or any callable) as a
    SlidingSurface compatible with all OpenSMC controllers.

    Parameters
    ----------
    model : str or callable
        If str: path to a saved SB3 model (.zip). Loaded with PPO.load().
        If callable: function(obs) -> action that computes the surface value.
    obs_fn : callable or None
        Optional function to map (e, edot, t) -> observation vector.
        Default: np.array([e, edot]).
    scale : float
        Scale factor applied to the RL output. Default 1.0.
    """

    def __init__(self, model, obs_fn=None, scale=1.0):
        self.scale = scale
        self._obs_fn = obs_fn

        if isinstance(model, str):
            self._model = self._load_sb3(model)
            self._predict = self._sb3_predict
        elif callable(model):
            self._model = model
            self._predict = model
        else:
            raise TypeError(
                f"model must be a file path (str) or callable, got {type(model)}")

    @staticmethod
    def _load_sb3(path):
        """Load a Stable-Baselines3 model from file."""
        try:
            from stable_baselines3 import PPO
            return PPO.load(path)
        except ImportError:
            raise ImportError(
                "stable-baselines3 is required to load SB3 models. "
                "Install with: pip install opensmc[rl]")

    def _sb3_predict(self, obs):
        """Predict using SB3 model (deterministic)."""
        action, _ = self._model.predict(obs, deterministic=True)
        return action

    def _make_obs(self, e, edot, t):
        """Build observation vector from error state."""
        if self._obs_fn is not None:
            return self._obs_fn(e, edot, t)

        e_scalar = float(e) if np.ndim(e) == 0 else e
        edot_scalar = float(edot) if np.ndim(edot) == 0 else edot

        if np.ndim(e_scalar) == 0:
            return np.array([e_scalar, edot_scalar], dtype=np.float32)
        else:
            return np.concatenate([
                np.atleast_1d(e_scalar),
                np.atleast_1d(edot_scalar)
            ]).astype(np.float32)

    def compute(self, e, edot, t=0.0, **kwargs):
        """Compute sliding variable using the RL policy.

        Parameters
        ----------
        e : float or ndarray — tracking error
        edot : float or ndarray — error derivative
        t : float — time

        Returns
        -------
        s : float or ndarray — RL-generated sliding variable
        """
        obs = self._make_obs(e, edot, t)
        raw = self._predict(obs)
        s = float(np.ravel(raw)[0]) * self.scale
        return s

    def reset(self):
        """Reset (no-op for most RL models)."""
        pass

    def __repr__(self):
        return f"RLDiscoveredSurface(scale={self.scale})"
