"""Terminal sliding surface family: Terminal, Nonsingular Terminal, Fast Terminal.

References:
    - Zak, M. (1988). "Terminal attractors for addressable memory in neural
      networks." Physics Letters A, 133(1-2), 18-22.
    - Yu, X. & Zhihong, M. (2002). "Fast terminal sliding-mode control design
      for nonlinear dynamical systems." IEEE TCAS-I, 49(2), 261-264.
    - Liu, J. & Wang, X. (2012). Advanced SMC for Mechanical Systems,
      Springer, Ch 7.3.
"""

import numpy as np

from opensmc.core import SlidingSurface


def _frac_power(x, p, q):
    r"""Compute |x|^{p/q} * sign(x), safe for x = 0."""
    return np.abs(x) ** (p / q) * np.sign(x)


class TerminalSurface(SlidingSurface):
    r"""Terminal sliding surface (Zak, 1988).

    .. math::
        s = \dot{e} + \beta\,|e|^{p/q}\,\mathrm{sign}(e)

    Provides finite-time convergence on the sliding manifold with
    convergence time:

    .. math::
        T_f = \frac{q}{\beta\,(q - p)}\,|e(0)|^{(q-p)/q}

    .. warning::
        This surface has a singularity at e = 0 in the equivalent control
        (the coefficient beta * (p/q) * |e|^{p/q - 1} diverges). Use
        :class:`NonsingularTerminalSurface` to avoid this issue.

    Parameters
    ----------
    beta : float
        Gain (positive).
    p : int
        Numerator of the fractional exponent (odd positive integer, p < q).
    q : int
        Denominator of the fractional exponent (odd positive integer).
    """

    def __init__(self, beta=10.0, p=5, q=7):
        if beta <= 0:
            raise ValueError(f"beta must be positive, got {beta}")
        if p >= q:
            raise ValueError(f"Require p < q, got p={p}, q={q}")
        if p % 2 == 0 or q % 2 == 0:
            raise ValueError(f"p and q must be odd, got p={p}, q={q}")
        self.beta = beta
        self.p = p
        self.q = q

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = edot + beta * |e|^{p/q} * sign(e)."""
        return edot + self.beta * _frac_power(e, self.p, self.q)


class NonsingularTerminalSurface(SlidingSurface):
    r"""Nonsingular terminal sliding surface (Yu & Zhihong, 2002).

    .. math::
        s = e + \frac{1}{\beta}\,|\dot{e}|^{q/p}\,\mathrm{sign}(\dot{e})

    Avoids the singularity of the standard terminal surface by placing
    the fractional power on edot instead of e. Note q/p > 1 so the
    exponent is greater than one.

    Parameters
    ----------
    beta : float
        Gain (positive).
    p : int
        Numerator (odd positive integer, p < q).
    q : int
        Denominator (odd positive integer).
    """

    def __init__(self, beta=10.0, p=5, q=7):
        if beta <= 0:
            raise ValueError(f"beta must be positive, got {beta}")
        if p >= q:
            raise ValueError(f"Require p < q, got p={p}, q={q}")
        if p % 2 == 0 or q % 2 == 0:
            raise ValueError(f"p and q must be odd, got p={p}, q={q}")
        self.beta = beta
        self.p = p
        self.q = q

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = e + (1/beta) * |edot|^{q/p} * sign(edot)."""
        return e + (1.0 / self.beta) * _frac_power(edot, self.q, self.p)


class FastTerminalSurface(SlidingSurface):
    r"""Fast terminal sliding surface (Liu & Wang, 2012).

    .. math::
        s = \dot{e} + \alpha\,e + \beta\,|e|^{q/p}\,\mathrm{sign}(e)

    Combines a linear term (alpha * e) for global convergence with a
    terminal term (beta * |e|^{q/p} * sign(e)) for finite-time
    convergence near the origin. This ensures global finite-time
    stability.

    .. note::
        The exponent here is q/p > 1 (not p/q < 1 as in the standard
        terminal surface), following Liu & Wang (2012) Ch 7.3.

    Parameters
    ----------
    alpha : float
        Linear gain (positive).
    beta : float
        Terminal gain (positive).
    p : int
        Numerator (odd positive integer, p < q).
    q : int
        Denominator (odd positive integer).
    """

    def __init__(self, alpha=2.0, beta=1.0, p=5, q=9):
        if alpha <= 0:
            raise ValueError(f"alpha must be positive, got {alpha}")
        if beta <= 0:
            raise ValueError(f"beta must be positive, got {beta}")
        if p >= q:
            raise ValueError(f"Require p < q, got p={p}, q={q}")
        if p % 2 == 0 or q % 2 == 0:
            raise ValueError(f"p and q must be odd, got p={p}, q={q}")
        self.alpha = alpha
        self.beta = beta
        self.p = p
        self.q = q

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = edot + alpha * e + beta * |e|^{q/p} * sign(e)."""
        return edot + self.alpha * e + self.beta * _frac_power(e, self.q, self.p)
