"""Predefined-time sliding surface: convergence guaranteed before Tc.

Reference:
    Sanchez-Torres, J.D. et al. (2018). "Predefined-time stability of
    dynamical systems with sliding modes." Mathematical Problems in
    Engineering, 2018, Article ID 3710532.
"""

import numpy as np

from opensmc.core import SlidingSurface


class PredefinedTimeSurface(SlidingSurface):
    r"""Predefined-time sliding surface.

    For t < Tc:

    .. math::
        c(t) = \frac{\pi}{2\,T_c}
               \cdot \frac{1}{\cos\!\left(\frac{\pi}{2}\,\frac{t}{T_c}\right)}

    .. math::
        s(t) = \dot{e} + c(t)\,e

    For t >= Tc:

    .. math::
        s(t) = \dot{e} + c_\infty\,e \quad \text{(standard linear surface)}

    **Key property:** The time-varying gain c(t) grows to infinity as
    t -> Tc, forcing e(t) -> 0 before the user-specified deadline Tc,
    regardless of initial conditions. After Tc, the surface reverts to
    a standard linear surface for regulation.

    The gain derivative (needed for the controller) is:

    .. math::
        \dot{c}(t) = \frac{\pi^2}{4\,T_c^2}
                     \cdot \frac{\sin\!\left(\frac{\pi}{2}\,\frac{t}{T_c}\right)}
                          {\cos^2\!\left(\frac{\pi}{2}\,\frac{t}{T_c}\right)}

    Parameters
    ----------
    Tc : float
        Predefined convergence time (positive). Error will reach zero
        before this time.
    c_inf : float
        Post-convergence surface slope (positive). Used for t >= Tc.
    """

    def __init__(self, Tc=2.0, c_inf=10.0):
        if Tc <= 0:
            raise ValueError(f"Tc must be positive, got {Tc}")
        if c_inf <= 0:
            raise ValueError(f"c_inf must be positive, got {c_inf}")
        self.Tc = Tc
        self.c_inf = c_inf

    def gain(self, t):
        """Compute the time-varying gain c(t).

        Returns c(t) for t < Tc, or c_inf for t >= Tc.
        Clamps t/Tc to 0.999 to avoid division by zero at t = Tc.
        """
        if t >= self.Tc:
            return self.c_inf
        ratio = min(t / self.Tc, 0.999)
        return (np.pi / (2.0 * self.Tc)) / np.cos(np.pi / 2.0 * ratio)

    def gain_dot(self, t):
        """Compute the time derivative of c(t).

        Returns dc/dt for t < Tc, or 0.0 for t >= Tc.
        """
        if t >= self.Tc:
            return 0.0
        ratio = min(t / self.Tc, 0.999)
        s = np.sin(np.pi / 2.0 * ratio)
        c = np.cos(np.pi / 2.0 * ratio)
        return (np.pi ** 2 / (4.0 * self.Tc ** 2)) * s / (c ** 2)

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = edot + c(t) * e.

        Parameters
        ----------
        e : float
            Tracking error.
        edot : float
            Error derivative.
        t : float
            Current time (required for the time-varying gain).

        Returns
        -------
        s : float
            Sliding variable.
        """
        ct = self.gain(t)
        return edot + ct * e
