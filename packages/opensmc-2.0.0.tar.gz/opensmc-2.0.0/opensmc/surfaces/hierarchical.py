"""Hierarchical sliding surface for underactuated systems.

Reference:
    Qian, D. & Yi, J. (2015). Hierarchical Sliding Mode Control for
    Under-actuated Cranes, Springer, Ch 4.
"""

from opensmc.core import SlidingSurface


class HierarchicalSurface(SlidingSurface):
    r"""Hierarchical sliding surface for multi-DOF underactuated systems.

    .. math::
        s_1 &= \dot{e}_a + c_1\,e_a \qquad \text{(actuated subsystem)} \\
        s_2 &= \dot{e}_u + c_2\,e_u \qquad \text{(unactuated subsystem)} \\
        S   &= s_1 + \lambda\,s_2   \qquad \text{(hierarchical combination)}

    A single control input stabilizes both subsystems through the
    dynamic coupling. The weight lambda controls the relative priority:

    - lambda = 0: only the actuated DOF is controlled.
    - lambda >> 1: the controller prioritizes the unactuated DOF.

    Parameters
    ----------
    c1 : float
        Actuated subsystem surface slope (positive).
    c2 : float
        Unactuated subsystem surface slope (positive).
    lam : float
        Coupling weight (non-negative).
    """

    def __init__(self, c1=10.0, c2=10.0, lam=1.0):
        if c1 <= 0:
            raise ValueError(f"c1 must be positive, got {c1}")
        if c2 <= 0:
            raise ValueError(f"c2 must be positive, got {c2}")
        if lam < 0:
            raise ValueError(f"lam must be non-negative, got {lam}")
        self.c1 = c1
        self.c2 = c2
        self.lam = lam

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute the hierarchical sliding variable S = s1 + lambda * s2.

        For underactuated systems, the errors must be provided as
        keyword arguments:

        Parameters
        ----------
        e : float
            Actuated subsystem error (e_a). Ignored if e_a is in kwargs.
        edot : float
            Actuated subsystem error derivative. Ignored if edot_a is in kwargs.
        e_a : float, optional
            Actuated subsystem error (alternative to positional ``e``).
        edot_a : float, optional
            Actuated error derivative (alternative to positional ``edot``).
        e_u : float
            Unactuated subsystem error (required in kwargs).
        edot_u : float
            Unactuated error derivative (required in kwargs).

        Returns
        -------
        S : float
            Hierarchical sliding variable.
        """
        e_a = kwargs.get('e_a', e)
        edot_a = kwargs.get('edot_a', edot)
        e_u = kwargs.get('e_u', 0.0)
        edot_u = kwargs.get('edot_u', 0.0)

        s1 = edot_a + self.c1 * e_a
        s2 = edot_u + self.c2 * e_u
        return s1 + self.lam * s2
