"""PID sliding surface: s = alpha * edot + beta * e + gamma * integral(e dt).

References:
    - Qian, D. & Yi, J. (2015). Hierarchical Sliding Mode Control for
      Under-actuated Cranes, Springer, Appendix E.
    - Chiang, H. et al. (2011). "Second-order sliding mode control for
      a magnetic levitation system."
"""

import numpy as np

from opensmc.core import SlidingSurface


class PIDSurface(SlidingSurface):
    r"""PID-type sliding surface.

    .. math::
        s = \alpha\,\dot{e} + \beta\,e + \gamma \int_0^t e(\tau)\,d\tau

    Three-term surface combining derivative, proportional, and integral
    action:

    - **alpha** (derivative): provides damping.
    - **beta** (proportional): controls convergence rate.
    - **gamma** (integral): eliminates steady-state error under constant
      disturbance.

    When gamma = 0, this reduces to the classical linear surface
    s = alpha * edot + beta * e.

    Designed for second-order SMC where the controller computes udot
    (control derivative), making the actual control u continuous (no
    chattering).

    Parameters
    ----------
    alpha : float
        Derivative coefficient (positive).
    beta : float
        Proportional coefficient (positive).
    gamma : float
        Integral coefficient (non-negative). Set to 0 to recover
        the classical linear surface.
    dt : float
        Integration time step for the integral term.
    """

    def __init__(self, alpha=1.0, beta=10.0, gamma=1.0, dt=1e-4):
        if alpha <= 0:
            raise ValueError(f"alpha must be positive, got {alpha}")
        if beta <= 0:
            raise ValueError(f"beta must be positive, got {beta}")
        if gamma < 0:
            raise ValueError(f"gamma must be non-negative, got {gamma}")
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.dt = dt
        self._eint = 0.0

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = alpha * edot + beta * e + gamma * eint.

        The error integral is accumulated internally via Euler integration
        at each call.
        """
        self._eint += e * self.dt
        return self.alpha * edot + self.beta * e + self.gamma * self._eint

    def reset(self):
        """Reset the accumulated error integral to zero."""
        self._eint = 0.0
