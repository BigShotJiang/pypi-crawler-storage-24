"""Integral terminal sliding surface (ITSMC).

References:
    - Liu, J. & Wang, X. (2012). Advanced Sliding Mode Control for
      Mechanical Systems, Springer.
    - Al Ghanimi et al. (2026). "RBF-ELM-ITSMC Hybrid Controller for
      Quadrotor UAV Trajectory Tracking." (Manuscript)
"""

import numpy as np

from opensmc.core import SlidingSurface


class IntegralTerminalSurface(SlidingSurface):
    r"""Integral terminal sliding surface.

    .. math::
        s = \dot{e} + c_1\,e + c_2 \int_0^t |e(\tau)|^{p/q}
            \,\mathrm{sign}(e(\tau))\,d\tau

    Combines three mechanisms:
    - Linear term (c1 * e): fast convergence far from origin.
    - Terminal integral term: finite-time convergence via fractional
      power p/q < 1.
    - Integral action: eliminates steady-state error under constant
      disturbance.

    Parameters
    ----------
    c1 : float
        Linear gain (positive).
    c2 : float
        Integral terminal gain (positive).
    p : int
        Numerator of fractional exponent (odd positive integer, p < q).
    q : int
        Denominator of fractional exponent (odd positive integer).
    dt : float
        Integration time step for accumulating the integral term.
    """

    def __init__(self, c1=10.0, c2=5.0, p=5, q=7, dt=1e-4):
        if c1 <= 0:
            raise ValueError(f"c1 must be positive, got {c1}")
        if c2 <= 0:
            raise ValueError(f"c2 must be positive, got {c2}")
        if p >= q:
            raise ValueError(f"Require p < q, got p={p}, q={q}")
        if p % 2 == 0 or q % 2 == 0:
            raise ValueError(f"p and q must be odd, got p={p}, q={q}")
        self.c1 = c1
        self.c2 = c2
        self.p = p
        self.q = q
        self.dt = dt
        self._integral = 0.0

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = edot + c1*e + c2*integral(|e|^{p/q}*sign(e) dt).

        The integral is accumulated internally using Euler integration
        at each call.
        """
        frac_term = np.abs(e) ** (self.p / self.q) * np.sign(e)
        self._integral += frac_term * self.dt
        return edot + self.c1 * e + self.c2 * self._integral

    def reset(self):
        """Reset the accumulated integral state to zero."""
        self._integral = 0.0
