"""Global sliding surface: eliminates reaching phase via exponential correction.

References:
    - Bartoszewicz, A. (1998). "Discrete-time quasi-sliding-mode control
      strategies." IEEE Trans. Industrial Electronics, 45(4), 633-637.
    - Zhihong, M. & Yu, X.H. (1999). "Global sliding mode control."
      Int. J. Control, 72(12), 1096-1109.
"""

import numpy as np

from opensmc.core import SlidingSurface


class GlobalSurface(SlidingSurface):
    r"""Global sliding surface with exponential correction.

    .. math::
        s(t) = \dot{e} + c\,e
               - \bigl(\dot{e}(0) + c\,e(0)\bigr)\,\exp(-\alpha\,t)

    **Key property:** s(0) = 0 by construction, regardless of initial
    conditions. The exponential correction decays with rate alpha, and
    as t -> infinity the surface converges to the standard linear
    surface s = edot + c * e.

    The transition time from global to linear behavior is approximately:

    .. math::
        t_\epsilon = -\frac{\ln(\epsilon / |s_0|)}{\alpha}

    Parameters
    ----------
    c : float
        Base surface slope (positive).
    alpha : float
        Exponential decay rate for the correction term (positive).
        Larger alpha means faster transition to the standard surface.
    """

    def __init__(self, c=10.0, alpha=5.0):
        if c <= 0:
            raise ValueError(f"c must be positive, got {c}")
        if alpha <= 0:
            raise ValueError(f"alpha must be positive, got {alpha}")
        self.c = c
        self.alpha = alpha
        self._e0 = None
        self._edot0 = None
        self._s0 = None
        self._initialized = False

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute the global sliding variable.

        On first call, stores e(0) and edot(0) to compute the
        correction term s_0 = edot(0) + c * e(0).

        Parameters
        ----------
        e : float
            Tracking error.
        edot : float
            Error derivative.
        t : float
            Current time (required for the exponential decay).

        Returns
        -------
        s : float
            Sliding variable (exactly zero at t = 0).
        """
        if not self._initialized:
            self._e0 = e
            self._edot0 = edot
            self._s0 = edot + self.c * e
            self._initialized = True

        s_nominal = edot + self.c * e
        correction = self._s0 * np.exp(-self.alpha * t)
        return s_nominal - correction

    def reset(self):
        """Reset the stored initial conditions."""
        self._e0 = None
        self._edot0 = None
        self._s0 = None
        self._initialized = False
