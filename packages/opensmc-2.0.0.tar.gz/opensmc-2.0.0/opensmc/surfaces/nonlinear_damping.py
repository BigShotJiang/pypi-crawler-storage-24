"""Nonlinear damping sliding surface: s = edot + (c + Psi(y)) * e.

Reference:
    Bandyopadhyay, B., Deepak, F., & Kim, K.S. (2009). Sliding Mode
    Control Using Novel Sliding Surfaces. LNCIS 392, Springer, Ch 2,
    Eqs. 2.7-2.8.
"""

import numpy as np

from opensmc.core import SlidingSurface


class NonlinearDampingSurface(SlidingSurface):
    r"""Nonlinear damping sliding surface.

    .. math::
        s = \dot{e} + \bigl(c + \Psi(y)\bigr)\,e

    The nonlinear function Psi(y) adapts the effective slope c_eff = c + Psi(y)
    based on the output y, reducing overshoot compared to a fixed linear surface.

    Two Psi types are supported:

    **Gaussian** (Eq. 2.8):

    .. math::
        \Psi(y) = -\beta\,\exp(-\tilde{k}\,y^2)

    - At y = 0 (far from setpoint): Psi = -beta, c_eff = c - beta (gentle start).
    - At y = y_ref: Psi ~ 0, c_eff ~ c (full slope, fast final convergence).

    **Exponential** (Eq. 2.7, adapted for tracking):

    .. math::
        \Psi(y) = \frac{-\beta}{1 - e^{-1}}
                  \left(\exp\!\bigl(-(1 - r^2)\bigr) - e^{-1}\right),
        \quad r = y / y_{\mathrm{ref}}

    - At y = 0: Psi ~ 0, c_eff = c (fast approach).
    - At y = y_ref: Psi = -beta, c_eff = c - beta (gentle arrival).

    Parameters
    ----------
    c : float
        Base surface slope (positive, must satisfy c > beta for c_eff > 0).
    beta : float
        Damping amplitude (positive, beta < c).
    psi_type : str
        Either ``'gaussian'`` or ``'exponential'``.
    k_tilde : float
        Width parameter for Gaussian Psi (positive).
    y_ref : float
        Reference setpoint for exponential Psi.
    """

    def __init__(self, c=10.0, beta=7.9, psi_type='gaussian',
                 k_tilde=1.0, y_ref=1.0):
        if c <= 0:
            raise ValueError(f"c must be positive, got {c}")
        if beta <= 0:
            raise ValueError(f"beta must be positive, got {beta}")
        if beta >= c:
            raise ValueError(f"Require beta < c for positive c_eff, got beta={beta}, c={c}")
        if psi_type not in ('gaussian', 'exponential'):
            raise ValueError(f"psi_type must be 'gaussian' or 'exponential', got '{psi_type}'")
        self.c = c
        self.beta = beta
        self.psi_type = psi_type
        self.k_tilde = k_tilde
        self.y_ref = y_ref

    def _psi(self, y):
        """Compute the nonlinear damping function Psi(y)."""
        if self.psi_type == 'gaussian':
            return -self.beta * np.exp(-self.k_tilde * y ** 2)
        else:  # exponential
            if abs(self.y_ref) < 1e-10:
                return 0.0
            r = np.clip(y / self.y_ref, 0.0, 1.0)
            exponent = -(1.0 - r ** 2)
            return (-self.beta / (1.0 - np.exp(-1.0))
                    * (np.exp(exponent) - np.exp(-1.0)))

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute s = edot + (c + Psi(y)) * e.

        Parameters
        ----------
        e : float
            Tracking error.
        edot : float
            Error derivative.
        y : float, optional
            Current output value for computing Psi. If not provided,
            defaults to 0.0 (which gives Psi at the initial condition).

        Returns
        -------
        s : float
            Sliding variable.
        """
        y = kwargs.get('y', 0.0)
        c_eff = self.c + self._psi(y)
        return edot + c_eff * e
