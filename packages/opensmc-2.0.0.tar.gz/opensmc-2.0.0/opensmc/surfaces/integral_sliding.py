"""Integral sliding surface (eliminates reaching phase).

References:
    - Utkin, V.I. & Shi, J. (1996). "Integral sliding mode in systems
      operating under uncertainty conditions." Proc. 35th IEEE CDC,
      pp. 4591-4596.
    - Qian, D. & Yi, J. (2015). Hierarchical Sliding Mode Control for
      Under-actuated Cranes, Springer, Appendix C.
"""

import numpy as np

from opensmc.core import SlidingSurface


class IntegralSlidingSurface(SlidingSurface):
    r"""Integral sliding surface (Utkin, 1996).

    Utkin formulation:

    .. math::
        s(t) = G\bigl[x(t) - x(0)\bigr]
               - \int_0^t G\bigl(A\,x(\tau) + B\,u_{\mathrm{nom}}(\tau)
               \bigr)\,d\tau

    Simplified scalar formulation (used here):

    .. math::
        s = c\,(e - e_0) - z, \quad \dot{z} = c\,\dot{e}_{\mathrm{nom}}

    where e_0 is the initial error and z accumulates the nominal
    dynamics.

    **Key property:** s(0) = 0 by construction -- no reaching phase.

    For the common case of a second-order plant with nominal feedback
    u_nom = -K*x, the integral compensator evolves as:

    .. math::
        s = C \cdot (x_{\mathrm{err}} - E), \quad
        \dot{E} = (A - BK)\,x_{\mathrm{err}}, \quad E(0) = 0

    Parameters
    ----------
    c : float
        Surface slope (positive).
    dt : float
        Integration time step for accumulating the integral.
    """

    def __init__(self, c=10.0, dt=1e-4):
        if c <= 0:
            raise ValueError(f"Surface slope c must be positive, got {c}")
        self.c = c
        self.dt = dt
        self._e0 = None
        self._edot0 = None
        self._integral = 0.0
        self._initialized = False

    def compute(self, e, edot, t=0.0, **kwargs):
        r"""Compute the integral sliding variable.

        On first call, stores e(0) and edot(0) so that s(0) = 0.
        Subsequent calls accumulate the nominal dynamics integral.

        .. math::
            s(t) = (\dot{e} + c\,e) - (\dot{e}_0 + c\,e_0)\,
                   \exp(-\alpha\,t)

        This implementation uses the Utkin approach: s(0) = 0 exactly.

        Parameters
        ----------
        e : float
            Tracking error.
        edot : float
            Error derivative.
        t : float
            Current time.

        Returns
        -------
        s : float
            Sliding variable (zero at t = 0).
        """
        if not self._initialized:
            self._e0 = e
            self._edot0 = edot
            self._s0 = edot + self.c * e  # nominal surface value at t=0
            self._integral = 0.0
            self._initialized = True

        s_nominal = edot + self.c * e
        s_initial = self._edot0 + self.c * self._e0

        # Utkin formulation: subtract the initial condition contribution
        # s = (edot + c*e) - (edot0 + c*e0) + integral_correction
        # Simplified: s = G*(x - x0) - integral
        # which equals (edot + c*e) - (edot0 + c*e0) at t=0 => 0
        return s_nominal - s_initial + self._integral

    def reset(self):
        """Reset the integral state and initialization flag."""
        self._e0 = None
        self._edot0 = None
        self._integral = 0.0
        self._initialized = False
