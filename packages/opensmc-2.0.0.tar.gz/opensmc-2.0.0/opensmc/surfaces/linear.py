"""Linear sliding surface: s = edot + c * e.

Reference: Liu, J. (2017). Sliding Mode Control Using MATLAB.
           Academic Press, Chapter 1, Eq. 1.2.
"""

from opensmc.core import SlidingSurface


class LinearSurface(SlidingSurface):
    r"""Classical linear sliding surface.

    .. math::
        s = \dot{e} + c \, e

    Parameters
    ----------
    c : float
        Surface slope (must be positive). Controls the convergence
        rate on the sliding manifold: e(t) = e(t_r) * exp(-c*(t - t_r)).
    """

    def __init__(self, c=10.0):
        if c <= 0:
            raise ValueError(f"Surface slope c must be positive, got {c}")
        self.c = c

    def compute(self, e, edot, t=0.0, **kwargs):
        """Compute s = edot + c * e."""
        return edot + self.c * e
