"""OpenSMC Surfaces — 11 sliding surface implementations."""

from .linear import LinearSurface
from .terminal import TerminalSurface, NonsingularTerminalSurface, FastTerminalSurface
from .integral_terminal import IntegralTerminalSurface
from .integral_sliding import IntegralSlidingSurface
from .pid import PIDSurface
from .hierarchical import HierarchicalSurface
from .nonlinear_damping import NonlinearDampingSurface
from .global_surface import GlobalSurface
from .predefined_time import PredefinedTimeSurface

__all__ = [
    'LinearSurface', 'TerminalSurface', 'NonsingularTerminalSurface',
    'FastTerminalSurface', 'IntegralTerminalSurface', 'IntegralSlidingSurface',
    'PIDSurface', 'HierarchicalSurface', 'NonlinearDampingSurface',
    'GlobalSurface', 'PredefinedTimeSurface',
]
