"""OpenSMC Metrics — 12 standardized performance metrics for SMC benchmarking."""

import numpy as np


def rmse(result, axis=None):
    """Root mean square error."""
    e = result['e']
    if axis is not None:
        e = e[:, axis]
    return float(np.sqrt(np.mean(e ** 2)))


def mae(result, axis=None):
    """Mean absolute error."""
    e = result['e']
    if axis is not None:
        e = e[:, axis]
    return float(np.mean(np.abs(e)))


def ise(result, axis=None):
    """Integral of squared error."""
    e = result['e']
    t = result['t']
    dt = t[1] - t[0] if len(t) > 1 else 1.0
    if axis is not None:
        e = e[:, axis]
    return float(np.sum(e ** 2) * dt)


def iae(result, axis=None):
    """Integral of absolute error."""
    e = result['e']
    t = result['t']
    dt = t[1] - t[0] if len(t) > 1 else 1.0
    if axis is not None:
        e = e[:, axis]
    return float(np.sum(np.abs(e)) * dt)


def settling_time(result, axis=0, tol_frac=0.02):
    """Settling time (2% criterion by default).

    Time after which |e| stays within tol_frac * |e(0)| permanently.
    """
    e = result['e'][:, axis] if result['e'].ndim > 1 else result['e']
    t = result['t']
    tol = tol_frac * np.max(np.abs(e[:min(10, len(e))]))
    if tol < 1e-15:
        tol = 1e-6
    ts = t[-1]
    for j in range(len(t) - 1, -1, -1):
        if np.abs(e[j]) > tol:
            ts = t[min(j + 1, len(t) - 1)]
            break
    else:
        ts = t[0]
    return float(ts)


def overshoot(result, axis=0):
    """Percent overshoot relative to reference."""
    x = result['x'][:, axis]
    xref = result['xref'][:, axis]
    ref_final = xref[-1]
    x0 = x[0]
    if abs(ref_final - x0) < 1e-15:
        return 0.0
    peak = np.max(x) if ref_final > x0 else np.min(x)
    os = (peak - ref_final) / (ref_final - x0) * 100
    return float(max(0.0, os))


def control_effort(result, axis=None):
    """Total control effort: integral of |u|^2."""
    u = result['u']
    t = result['t']
    dt = t[1] - t[0] if len(t) > 1 else 1.0
    if axis is not None:
        u = u[:, axis]
    return float(np.sum(u ** 2) * dt)


def chattering_index(result, axis=0):
    """Chattering index: total variation of control signal TV(u)."""
    u = result['u'][:, axis] if result['u'].ndim > 1 else result['u'].ravel()
    return float(np.sum(np.abs(np.diff(u))))


def reaching_time(result, axis=0, tol=0.01):
    """Time for |s| to first enter the band |s| < tol."""
    s = result['s'][:, axis] if result['s'].ndim > 1 else result['s'].ravel()
    t = result['t']
    for i in range(len(s)):
        if np.abs(s[i]) < tol:
            return float(t[i])
    return float(t[-1])


def ss_error(result, axis=0, tail_frac=0.1):
    """Steady-state error: mean |e| over last tail_frac of simulation."""
    e = result['e'][:, axis] if result['e'].ndim > 1 else result['e'].ravel()
    idx = int(len(e) * (1 - tail_frac))
    return float(np.mean(np.abs(e[idx:])))


def max_swing(result, axis=2):
    """Maximum swing angle (for crane/pendulum systems). Default: state index 2."""
    x = result['x'][:, axis]
    return float(np.max(np.abs(x)))


def residual_swing(result, axis=2, tail_frac=0.2):
    """Residual swing in steady state."""
    x = result['x'][:, axis]
    idx = int(len(x) * (1 - tail_frac))
    return float(np.max(np.abs(x[idx:])))


def compute_all(result, axis=0):
    """Compute all 12 metrics and return as dict."""
    return {
        'rmse': rmse(result, axis),
        'mae': mae(result, axis),
        'ise': ise(result, axis),
        'iae': iae(result, axis),
        'settling_time': settling_time(result, axis),
        'overshoot': overshoot(result, axis),
        'control_effort': control_effort(result, axis if result['u'].shape[1] > 1 else 0),
        'chattering_index': chattering_index(result, axis if result['u'].shape[1] > 1 else 0),
        'reaching_time': reaching_time(result, axis if result['s'].shape[1] > 1 else 0),
        'ss_error': ss_error(result, axis),
        'max_swing': max_swing(result, min(axis, result['x'].shape[1] - 1)),
        'residual_swing': residual_swing(result, min(axis, result['x'].shape[1] - 1)),
    }
