"""OpenSMC Utilities — Reference signals and disturbance profiles."""

import numpy as np


# ── Reference signals ──────────────────────────────────────────────

def step_ref(amplitude=1.0, n_states=2, t_start=0.0):
    """Step reference: xref = [amplitude, 0, 0, ...]."""
    def ref_fn(t):
        xref = np.zeros(n_states)
        if t >= t_start:
            xref[0] = amplitude
        return xref
    return ref_fn


def ramp_ref(slope=1.0, n_states=2):
    """Ramp reference: xref = [slope*t, slope, 0, ...]."""
    def ref_fn(t):
        xref = np.zeros(n_states)
        xref[0] = slope * t
        if n_states > 1:
            xref[1] = slope
        return xref
    return ref_fn


def sinusoidal_ref(amplitude=1.0, omega=1.0, n_states=2):
    """Sinusoidal reference with derivatives."""
    def ref_fn(t):
        xref = np.zeros(n_states)
        xref[0] = amplitude * np.sin(omega * t)
        if n_states > 1:
            xref[1] = amplitude * omega * np.cos(omega * t)
        return xref
    return ref_fn


def circular_3d(radius=2.0, omega=0.5, z_base=1.0, z_amp=0.3, z_omega=0.2):
    """3D circular trajectory for quadrotor: x=R*cos(wt), y=R*sin(wt), z=z0+A*sin(wz*t)."""
    def ref_fn(t):
        xref = np.zeros(12)
        xref[0] = radius * np.cos(omega * t)
        xref[1] = radius * np.sin(omega * t)
        xref[2] = z_base + z_amp * np.sin(z_omega * t)
        xref[6] = -radius * omega * np.sin(omega * t)
        xref[7] = radius * omega * np.cos(omega * t)
        xref[8] = z_amp * z_omega * np.cos(z_omega * t)
        return xref
    return ref_fn


def multi_step(amplitudes, durations, n_states=2):
    """Multi-step reference: sequence of step values."""
    times = np.cumsum([0] + list(durations))
    def ref_fn(t):
        xref = np.zeros(n_states)
        for i in range(len(amplitudes)):
            if t >= times[i]:
                xref[0] = amplitudes[i]
        return xref
    return ref_fn


# ── Disturbance profiles ──────────────────────────────────────────

def no_disturbance(n_states=2):
    """Zero disturbance."""
    return lambda t: np.zeros(n_states)


def step_disturbance(amplitude=1.0, t_start=0.0, n_states=2, axis=1):
    """Step disturbance on a specific axis."""
    def dist_fn(t):
        d = np.zeros(n_states)
        if t >= t_start:
            d[axis] = amplitude
        return d
    return dist_fn


def sinusoidal_disturbance(amplitude=1.0, omega=1.0, n_states=2, axis=1):
    """Sinusoidal disturbance."""
    def dist_fn(t):
        d = np.zeros(n_states)
        d[axis] = amplitude * np.sin(omega * t)
        return d
    return dist_fn


def composite_disturbance(components, n_states=2):
    """Sum of multiple disturbance components.

    Parameters
    ----------
    components : list of (amplitude, omega, axis) tuples
    """
    def dist_fn(t):
        d = np.zeros(n_states)
        for amp, omega, axis in components:
            d[axis] += amp * np.sin(omega * t)
        return d
    return dist_fn


def random_band(amplitude=1.0, n_states=2, axis=1, seed=42):
    """Band-limited random disturbance (reproducible)."""
    rng = np.random.RandomState(seed)
    # Pre-generate random sequence (up to 1M steps)
    _rand = rng.randn(1_000_000) * amplitude
    _idx = [0]
    def dist_fn(t):
        d = np.zeros(n_states)
        d[axis] = _rand[_idx[0] % len(_rand)]
        _idx[0] += 1
        return d
    return dist_fn
