"""OpenSMC Core — Abstract base classes for all components.

Every surface, reaching law, plant, controller, estimator, and architecture
inherits from these base classes to ensure composability.
"""

from abc import ABC, abstractmethod
import numpy as np


class SlidingSurface(ABC):
    """Abstract sliding surface: s = f(e, edot, state, t)."""

    @abstractmethod
    def compute(self, e, edot, t=0.0, **kwargs):
        """Compute sliding variable s.

        Parameters
        ----------
        e : float or ndarray — tracking error (xref - x)
        edot : float or ndarray — error derivative
        t : float — time
        **kwargs : additional state (integral, etc.)

        Returns
        -------
        s : float or ndarray — sliding variable
        """

    def reset(self):
        """Reset internal state (integral terms, etc.)."""
        pass


class ReachingLaw(ABC):
    """Abstract reaching law: u_r = g(s, t)."""

    @abstractmethod
    def compute(self, s, t=0.0, **kwargs):
        """Compute reaching control signal.

        Parameters
        ----------
        s : float or ndarray — sliding variable
        t : float — time

        Returns
        -------
        u_r : float or ndarray — reaching control
        """

    def reset(self):
        """Reset internal state (integral for super-twisting, etc.)."""
        pass


class Plant(ABC):
    """Abstract dynamical system: xdot = f(t, x, u, d)."""

    def __init__(self, n_states, n_inputs, n_outputs, name="Plant"):
        self.n_states = n_states
        self.n_inputs = n_inputs
        self.n_outputs = n_outputs
        self.name = name

    @abstractmethod
    def dynamics(self, t, x, u, d=None):
        """Compute state derivatives.

        Parameters
        ----------
        t : float — time
        x : ndarray (n_states,) — state vector
        u : float or ndarray — control input
        d : ndarray or None — disturbance

        Returns
        -------
        xdot : ndarray (n_states,) — state derivatives
        """

    def output(self, x):
        """Compute output y from state x. Default: first n_outputs states."""
        return x[:self.n_outputs]

    def get_default_x0(self):
        """Return default initial state."""
        return np.zeros(self.n_states)


class Controller(ABC):
    """Abstract SMC controller: u = compute(t, x, xref, plant)."""

    def __init__(self, surface=None, reaching=None):
        self.surface = surface
        self.reaching = reaching

    @abstractmethod
    def compute(self, t, x, xref, plant=None, **kwargs):
        """Compute control signal.

        Parameters
        ----------
        t : float — time
        x : ndarray — current state
        xref : ndarray — reference state
        plant : Plant or None — plant model (for model-based control)

        Returns
        -------
        u : float or ndarray — control signal
        info : dict — diagnostics (s, u_eq, u_rob, etc.)
        """

    def reset(self):
        """Reset internal state."""
        if self.surface:
            self.surface.reset()
        if self.reaching:
            self.reaching.reset()


class Estimator(ABC):
    """Abstract disturbance/state estimator."""

    @abstractmethod
    def estimate(self, t, x, u, y=None, **kwargs):
        """Compute estimate.

        Parameters
        ----------
        t : float — time
        x : ndarray — state
        u : float or ndarray — control input
        y : ndarray or None — measured output

        Returns
        -------
        dhat : float or ndarray — disturbance or state estimate
        """

    def reset(self):
        """Reset internal state."""
        pass


class Architecture(ABC):
    """Abstract control architecture (Direct, Cascaded, etc.)."""

    @abstractmethod
    def compute(self, t, x, xref, plant, **kwargs):
        """Compute control through the architecture.

        Returns
        -------
        u : ndarray — control input to plant
        info : dict — diagnostics
        """

    def reset(self):
        """Reset all internal controllers/estimators."""
        pass


class NoEstimator(Estimator):
    """Null estimator — returns zero. Used when no estimation is needed."""

    def estimate(self, t, x, u, y=None, **kwargs):
        return 0.0
