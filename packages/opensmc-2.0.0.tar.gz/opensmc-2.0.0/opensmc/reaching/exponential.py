"""Exponential reaching law.

Reference
---------
Gao, W. & Hung, J.C. (1993). IEEE Trans. Industrial Electronics, 40(1), 45-55.
Liu, J. (2017). Sliding Mode Control Using MATLAB, Eq. 1.8.

Formula
-------
    u_r = -k * sign(s) - q * s

The linear term -q*s provides exponential convergence when |s| is large,
while -k*sign(s) ensures finite-time reaching through the origin.
Combined dynamics: sdot = -k*sign(s) - q*s.
"""

import numpy as np
from opensmc.core import ReachingLaw


class ExponentialRate(ReachingLaw):
    """Exponential reaching law: u_r = -k * sign(s) - q * s.

    Parameters
    ----------
    k : float
        Switching gain (must exceed disturbance bound).
    q : float
        Exponential/linear gain (controls convergence rate far from surface).
    """

    def __init__(self, *, k=1.0, q=10.0):
        self.k = k
        self.q = q

    def compute(self, s, t=0.0, **kwargs):
        """Compute reaching control signal.

        Parameters
        ----------
        s : float
            Sliding variable.
        t : float, optional
            Time (unused).

        Returns
        -------
        u_r : float
            Reaching control: -k * sign(s) - q * s.
        """
        return -self.k * float(np.sign(s)) - self.q * s
