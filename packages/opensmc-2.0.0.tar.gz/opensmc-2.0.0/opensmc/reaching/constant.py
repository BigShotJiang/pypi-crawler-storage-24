"""Constant-rate reaching law.

Reference
---------
Gao, W. & Hung, J.C. (1993). IEEE Trans. Industrial Electronics, 40(1), 45-55.
Liu, J. (2017). Sliding Mode Control Using MATLAB, Eq. 1.7.

Formula
-------
    u_r = -k * sign(s)

This is the simplest reaching law. The sliding variable decreases at a
constant rate, yielding linear convergence: s(t) = s(0) - k*t until s = 0.
"""

import numpy as np
from opensmc.core import ReachingLaw


class ConstantRate(ReachingLaw):
    """Constant-rate reaching law: u_r = -k * sign(s).

    Parameters
    ----------
    k : float
        Switching gain (must exceed disturbance bound for robustness).
    """

    def __init__(self, *, k=1.0):
        self.k = k

    def compute(self, s, t=0.0, **kwargs):
        """Compute reaching control signal.

        Parameters
        ----------
        s : float
            Sliding variable.
        t : float, optional
            Time (unused).

        Returns
        -------
        u_r : float
            Reaching control: -k * sign(s).
        """
        return -self.k * float(np.sign(s))
