"""Saturation-based reaching law (boundary layer).

Reference
---------
Slotine, J.-J.E. (1984). "Sliding controller design for non-linear systems."
    Int. J. Control, 40(2), 421-434.
Shtessel, Y. et al. (2014). Sliding Mode Control and Observation, Ch 1.

Formula
-------
    u_r = -k * sat(s / phi)

    sat(y) = y       if |y| <= 1
             sign(y) otherwise

The saturation function replaces sign(s) with a linear region of width phi
around the sliding surface, eliminating chattering at the cost of a bounded
steady-state error within the boundary layer |s| < phi.
"""

import numpy as np
from opensmc.core import ReachingLaw


class Saturation(ReachingLaw):
    """Saturation reaching law: u_r = -k * sat(s / phi).

    Parameters
    ----------
    k : float
        Gain.
    phi : float
        Boundary layer thickness. Larger phi reduces chattering but
        increases steady-state error.
    """

    def __init__(self, *, k=15.0, phi=0.1):
        self.k = k
        self.phi = phi

    def compute(self, s, t=0.0, **kwargs):
        """Compute reaching control signal.

        Parameters
        ----------
        s : float
            Sliding variable.
        t : float, optional
            Time (unused).

        Returns
        -------
        u_r : float
            Reaching control: -k * sat(s / phi).
        """
        y = s / self.phi
        sat_y = float(np.clip(y, -1.0, 1.0))
        return -self.k * sat_y
