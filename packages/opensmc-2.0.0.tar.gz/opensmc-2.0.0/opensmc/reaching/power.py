"""Power-rate reaching law.

Reference
---------
Gao, W. & Hung, J.C. (1993). IEEE Trans. Industrial Electronics, 40(1), 45-55.
Liu, J. (2017). Sliding Mode Control Using MATLAB, Eq. 1.9.

Formula
-------
    u_r = -k * |s|^alpha * sign(s)

For 0 < alpha < 1, this law achieves finite-time convergence to the
sliding surface. The convergence rate adapts: fast when |s| is large,
slow (but finite-time) when |s| is small.
"""

import numpy as np
from opensmc.core import ReachingLaw


class PowerRate(ReachingLaw):
    """Power-rate reaching law: u_r = -k * |s|^alpha * sign(s).

    Parameters
    ----------
    k : float
        Gain.
    alpha : float
        Power exponent, typically 0 < alpha < 1 for finite-time convergence.
    """

    def __init__(self, *, k=10.0, alpha=0.5):
        self.k = k
        self.alpha = alpha

    def compute(self, s, t=0.0, **kwargs):
        """Compute reaching control signal.

        Parameters
        ----------
        s : float
            Sliding variable.
        t : float, optional
            Time (unused).

        Returns
        -------
        u_r : float
            Reaching control: -k * |s|^alpha * sign(s).
        """
        return -self.k * float(np.abs(s)) ** self.alpha * float(np.sign(s))
