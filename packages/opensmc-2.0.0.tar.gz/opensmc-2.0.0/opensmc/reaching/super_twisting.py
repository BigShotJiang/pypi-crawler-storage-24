"""Super-twisting reaching law.

Reference
---------
Levant, A. (1993). Int. J. Control, 58(6), 1247-1263.
Shtessel, Y. et al. (2014). Sliding Mode Control and Observation, Ch 1.

Formula
-------
    u_r = -k1 * |s|^(1/2) * sign(s) + z
    zdot = -k2 * sign(s)

The integral state z accumulates to cancel matched disturbances,
producing a continuous control signal (no chattering) while
maintaining finite-time convergence to the sliding surface.
"""

import numpy as np
from opensmc.core import ReachingLaw


class SuperTwisting(ReachingLaw):
    """Super-twisting reaching law (Levant, 1993).

    u_r = -k1 * |s|^(1/2) * sign(s) + z,  zdot = -k2 * sign(s)

    Parameters
    ----------
    k1 : float
        Proportional gain on |s|^(1/2) term.
    k2 : float
        Integral gain (drives zdot).
    dt : float
        Time step for Euler integration of the internal state z.
    """

    def __init__(self, *, k1=15.0, k2=10.0, dt=1e-4):
        self.k1 = k1
        self.k2 = k2
        self.dt = dt
        self.z = 0.0

    def compute(self, s, t=0.0, **kwargs):
        """Compute reaching control signal and update internal state.

        Parameters
        ----------
        s : float
            Sliding variable.
        t : float, optional
            Time (unused).

        Returns
        -------
        u_r : float
            Reaching control: -k1 * |s|^(1/2) * sign(s) + z.
        """
        sign_s = float(np.sign(s))
        u_r = -self.k1 * float(np.abs(s)) ** 0.5 * sign_s + self.z
        self.z -= self.k2 * sign_s * self.dt
        return u_r

    def reset(self):
        """Reset the integral state z to zero."""
        self.z = 0.0
