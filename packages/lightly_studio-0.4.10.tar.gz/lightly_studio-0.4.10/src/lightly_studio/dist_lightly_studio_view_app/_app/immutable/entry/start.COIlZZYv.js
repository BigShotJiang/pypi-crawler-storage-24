import{l as o,b as r}from"../chunks/ZxKj1VBP.js";export{o as load_css,r as start};
