"""Selection package."""
