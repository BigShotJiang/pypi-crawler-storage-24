# Fastly CDN/VCL setup journey for `download.dnscrypt.info`

## Goal

Configure a Fastly VCL service that caches content for `https://download.dnscrypt.info` while fetching from the origin `https://dnscrypt.info` and sending `Host: download.dnscrypt.info` to the origin. Use a Fastly test domain first so the setup can be validated without touching production DNS.

## Final result

- Service name: `dnscrypt-download-cache-test-20260316-120114`
- Service ID: `vYS2k2bw2VZNRVcV7ois2P`
- Test domain configured on the service: `dnscrypt-download-cache-20260316-120114.global.ssl.fastly.net`
- Test URL that worked: `https://dnscrypt-download-cache-20260316-120114.freetls.fastly.net/`
- Backend address: `dnscrypt.info:443`
- Host header sent to origin: `download.dnscrypt.info`
- TLS certificate verification hostname: `dnscrypt.info`
- TLS SNI hostname: `dnscrypt.info`
- Result: Fastly served the site successfully and honored the origin cache headers. First successful request was a `MISS`; subsequent requests became `HIT` with increasing `Age`.

## Why no custom VCL snippet was needed

The origin already returns cache headers:

- `Cache-Control: max-age=3600`
- `Expires: ...`

Fastly VCL services respect those headers by default, so adding a VCL snippet would have been unnecessary and risked overriding the origin policy.

## Journey log

### 1. Activated the Fastly skills and checked local guidance

Read these references:

- `fastly-cli` skill: `services.md`, `auth.md`
- `fastly` skill: `service-management.md`, `vcl-services.md`

Key takeaways from the docs:

- Use a VCL service, not Compute, for a plain caching reverse proxy.
- Configure everything on version `1` for a brand-new service, then activate once.
- Use `fastly service domain create`, not `fastly domain create`.
- For HTTPS origins where `--override-host` differs from `--address`, set:
  - `--address` to the real origin hostname
  - `--override-host` to the desired `Host` header
  - `--ssl-cert-hostname` and `--ssl-sni-hostname` to the hostname covered by the origin certificate

### 2. Verified Fastly CLI access and account state

Command run:

```sh
fastly version
fastly whoami
fastly service list --json | head -c 2000
```

Findings:

- Fastly CLI was installed and usable.
- Authentication already worked.
- The active Fastly identity was `Frank Denis <fastly@pureftpd.org>`.

### 3. Ran pre-flight origin checks

Command run:

```sh
curl -sI -H 'Host: download.dnscrypt.info' https://dnscrypt.info/
curl -sI https://download.dnscrypt.info/
echo | openssl s_client -connect dnscrypt.info:443 -servername dnscrypt.info 2>/dev/null | \
  openssl x509 -noout -text | grep -A1 'Subject Alternative Name'
```

Findings:

- `https://dnscrypt.info/` responds correctly when sent `Host: download.dnscrypt.info`.
- The response includes `Cache-Control: max-age=3600` and `Expires`, so origin-driven caching is already in place.
- The certificate SANs include `dnscrypt.info` but not `download.dnscrypt.info`.
- That means the correct backend settings are:
  - `--address dnscrypt.info`
  - `--override-host download.dnscrypt.info`
  - `--ssl-cert-hostname dnscrypt.info`
  - `--ssl-sni-hostname dnscrypt.info`

### 4. Checked the exact CLI flags before changing anything

Command run:

```sh
fastly service create --help
fastly service backend create --help
fastly service domain create --help
fastly service version activate --help
```

Reason:

- Confirmed the precise command paths and flags on the installed CLI version before mutating Fastly configuration.

### 5. Created the new Fastly VCL test service

Chosen names:

- Service name: `dnscrypt-download-cache-test-20260316-120114`
- Test hostname label: `dnscrypt-download-cache-20260316-120114`
- Test domain: `dnscrypt-download-cache-20260316-120114.global.ssl.fastly.net`

Commands run:

```sh
fastly service create --name 'dnscrypt-download-cache-test-20260316-120114' --type vcl --non-interactive

fastly service domain create \
  --service-id vYS2k2bw2VZNRVcV7ois2P \
  --version 1 \
  --name dnscrypt-download-cache-20260316-120114.global.ssl.fastly.net \
  --non-interactive

fastly service backend create \
  --service-id vYS2k2bw2VZNRVcV7ois2P \
  --version 1 \
  --name origin \
  --address dnscrypt.info \
  --port 443 \
  --use-ssl \
  --override-host download.dnscrypt.info \
  --ssl-cert-hostname dnscrypt.info \
  --ssl-sni-hostname dnscrypt.info \
  --non-interactive

fastly service version activate \
  --service-id vYS2k2bw2VZNRVcV7ois2P \
  --version 1 \
  --non-interactive
```

Observed output:

```text
SUCCESS: Created service vYS2k2bw2VZNRVcV7ois2P
SUCCESS: Created domain dnscrypt-download-cache-20260316-120114.global.ssl.fastly.net (service vYS2k2bw2VZNRVcV7ois2P version 1)
SUCCESS: Created backend origin (service vYS2k2bw2VZNRVcV7ois2P version 1)
SUCCESS: Activated service vYS2k2bw2VZNRVcV7ois2P version 1
```

### 6. Attempted version validation through the REST API and hit an auth caveat

Attempted command:

```sh
curl -s "https://api.fastly.com/service/$SERVICE_ID/version/1/validate" \
  -H "Fastly-Key: $(fastly auth show --reveal --quiet | awk '/^Token:/ {print $2}')"
```

Observed issue:

```text
ERROR: current token is not stored (provided via --token or FASTLY_API_TOKEN); use `fastly auth add` or `fastly auth show <name>`.
{"msg":"Provided credentials are missing or invalid"}
```

What this means:

- The skill guidance suggesting `fastly auth show --reveal --quiet` as a safe token source is not universally valid.
- It fails when the CLI is authenticated via `FASTLY_API_TOKEN` or another non-stored-token path.
- In this session, Fastly CLI commands worked, but `fastly auth show --reveal --quiet` could not return a token because the current credential was not a stored auth profile.

Safer practical lesson:

- Prefer CLI-native commands whenever possible.
- If an API call is absolutely needed later, source the token from the environment without printing it into logs or conversation context, or ensure a named stored token exists first.

### 7. Verified the service configuration after activation

Commands run:

```sh
fastly service describe --service-id vYS2k2bw2VZNRVcV7ois2P
fastly service version list --service-id vYS2k2bw2VZNRVcV7ois2P
fastly service domain list --service-id vYS2k2bw2VZNRVcV7ois2P --version 1
fastly service backend list --service-id vYS2k2bw2VZNRVcV7ois2P --version 1
fastly service backend describe --service-id vYS2k2bw2VZNRVcV7ois2P --version 1 --name origin --json
fastly service domain describe --service-id vYS2k2bw2VZNRVcV7ois2P --version 1 --name dnscrypt-download-cache-20260316-120114.global.ssl.fastly.net --json
```

Important verified details:

- Service type is `vcl`.
- Active version is `1`.
- Backend `origin` points to `dnscrypt.info:443`.
- Backend has:
  - `OverrideHost: download.dnscrypt.info`
  - `SSLCertHostname: dnscrypt.info`
  - `SSLSNIHostname: dnscrypt.info`
  - `UseSSL: true`
- Service domain exists on version `1` as expected.

### 8. Tested the Fastly test-domain path and waited through propagation

Test URL:

```text
https://dnscrypt-download-cache-20260316-120114.freetls.fastly.net/
```

Loop used:

```sh
for i in 1 2 3 4 5 6; do
  echo "TRY=$i"
  curl -sS -D - -o /tmp/dnscrypt-fastly-body.txt \
    'https://dnscrypt-download-cache-20260316-120114.freetls.fastly.net/' | sed -n '1,40p'
  echo '---'
  sleep 10
done
```

Observed progression:

1. First three attempts returned `HTTP/2 500` from `server: Varnish`.
2. About 30 seconds later, the service started returning `HTTP/2 200`.
3. First successful 200 response showed:
   - `x-cache: MISS`
   - `age: 0`
   - origin `cache-control: max-age=3600`
4. Subsequent requests showed:
   - `x-cache: HIT`
   - `age: 10`, then `age: 21`

Representative successful headers:

```text
HTTP/2 200
server: nginx/1.29.5
cache-control: max-age=3600
expires: Mon, 16 Mar 2026 12:02:07 GMT
age: 10
via: 1.1 varnish
x-cache: HIT
x-cache-hits: 1
```

Interpretation:

- The temporary 500s were consistent with new-service propagation.
- Once propagation finished, Fastly fetched from the configured origin successfully.
- Fastly respected the origin cache lifetime instead of requiring a manual TTL override.

## Working command recipe for repeating this quickly

Replace the generated names if you do this again:

```sh
SERVICE_NAME="dnscrypt-download-cache-test-$(date +%Y%m%d-%H%M%S)"
TEST_LABEL="dnscrypt-download-cache-$(date +%Y%m%d-%H%M%S)"
TEST_DOMAIN="${TEST_LABEL}.global.ssl.fastly.net"

SERVICE_OUTPUT=$(fastly service create --name "$SERVICE_NAME" --type vcl --non-interactive)
SERVICE_ID=$(printf '%s\n' "$SERVICE_OUTPUT" | sed -n 's/^SUCCESS: Created service \([^[:space:]]*\)$/\1/p')

fastly service domain create \
  --service-id "$SERVICE_ID" \
  --version 1 \
  --name "$TEST_DOMAIN" \
  --non-interactive

fastly service backend create \
  --service-id "$SERVICE_ID" \
  --version 1 \
  --name origin \
  --address dnscrypt.info \
  --port 443 \
  --use-ssl \
  --override-host download.dnscrypt.info \
  --ssl-cert-hostname dnscrypt.info \
  --ssl-sni-hostname dnscrypt.info \
  --non-interactive

fastly service version activate \
  --service-id "$SERVICE_ID" \
  --version 1 \
  --non-interactive

curl -sS -D - -o /tmp/body.txt "https://${TEST_LABEL}.freetls.fastly.net/"
```

## Findings and learnings

- Fastly test domains under `*.global.ssl.fastly.net` work for VCL services and are also reachable through the corresponding `*.freetls.fastly.net` hostname.
- For this origin, no custom VCL was required because the origin already provides cache headers.
- The TLS certificate on the origin covers `dnscrypt.info`, not `download.dnscrypt.info`, so `ssl-cert-hostname` and `ssl-sni-hostname` must stay on `dnscrypt.info`.
- `override-host` is the correct way to send `Host: download.dnscrypt.info` while still connecting to `dnscrypt.info`.
- New test-domain activations can return temporary `500` responses before the service becomes reachable.
- The installed Fastly CLI help text was worth checking before acting, because exact command trees matter.
- CLI auth success does not guarantee that `fastly auth show --reveal --quiet` can reveal a token. That command depends on the token being stored in Fastly CLI config, which was not true here.

## Errors made during this run

### Error 1: bad documentation fetch URLs

I tried `fetch_url` against guessed Fastly docs URLs and got `HTTP 404` twice.

Lesson:

- Do not guess Fastly docs paths.
- Prefer the local skill reference files first.
- If fetching live docs later, use confirmed `docs.fastly.com` URLs rather than guessed routes.

### Error 2: assuming token reveal would always work

I attempted to validate the version with `fastly auth show --reveal --quiet` and that failed because the current token was not stored.

Lesson:

- Treat that token-retrieval method as conditional, not universal.
- Prefer CLI commands where available.

## What to do next if promoting beyond the test domain

1. Add the real domain to the service with `fastly service domain create` on a cloned draft version if version `1` is already active and locked.
2. Point the real DNS record at Fastly as required by the Fastly domain check.
3. Re-test on the production hostname.
4. Optionally purge once after cutover if needed.

## Cleanup note

This run created a real Fastly service in the account:

- Service ID: `vYS2k2bw2VZNRVcV7ois2P`

I did not delete it because deletion is destructive and was not requested.
