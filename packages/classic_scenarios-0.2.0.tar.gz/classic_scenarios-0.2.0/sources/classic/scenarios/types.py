from typing import TypeVar, ParamSpec, Callable


Params = ParamSpec('Params')
Result = TypeVar('Result')
UseCase = TypeVar('UseCase')

UseCaseMethod = Callable[[UseCase], Result]
KwargsWrapper = Callable[[Params], Result]
