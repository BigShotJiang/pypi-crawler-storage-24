# abcdLux
A functional backend differentiable propagator library for Fourier and Fresnel optics 

Very much in development.

**Core Functions**

 - Coordinates
 - ABCD Matrices
 - MFT utilities
 - Fraunhofer Propagators
 - ASM Propagators
 - LCT Propagators