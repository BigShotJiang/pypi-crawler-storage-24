"""Hoox MCP Server — exposes the Hoox video generation API as MCP tools."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from hoox_mcp.client import HooxClient, HooxClientError

logger = logging.getLogger("hoox-mcp")
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

mcp = FastMCP(
    "hoox",
    instructions="MCP server for Hoox — AI video generation platform. "
    "Use these tools to generate videos, manage avatars and voices, "
    "create scripts, and export final MP4s via the Hoox API.",
)

_client: HooxClient | None = None


def _get_client() -> HooxClient:
    global _client
    if _client is None:
        _client = HooxClient()
    return _client


def _json(data: Any) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False)


def _error_response(e: Exception) -> str:
    if isinstance(e, HooxClientError):
        return _json({"error": True, "status_code": e.status_code, "detail": e.detail})
    return _json({"error": True, "detail": str(e)})


_AVATAR_SUMMARY_KEYS = {"id", "avatar_name", "look_name", "name", "gender", "place", "format", "tags", "model_available"}
_VOICE_SUMMARY_KEYS = {"id", "name", "language", "accent", "gender", "tags"}

DEFAULT_LIST_LIMIT = 50


def _summarize(items: list[dict], keys: set[str]) -> list[dict]:
    """Keep only essential fields from list items to reduce response size."""
    return [{k: v for k, v in item.items() if k in keys} for item in items]


def _filter_by_name(items: list[dict], name: str | None) -> list[dict]:
    """Case-insensitive name search across name-related fields."""
    if not name:
        return items
    q = name.lower()
    return [
        item for item in items
        if q in (item.get("name") or "").lower()
        or q in (item.get("avatar_name") or "").lower()
        or q in (item.get("look_name") or "").lower()
    ]


# ======================================================================
# Voices
# ======================================================================


@mcp.tool()
async def list_voices(
    language: str | None = None,
    gender: str | None = None,
    tags: str | None = None,
    name: str | None = None,
    only_public: bool | None = None,
    limit: int = DEFAULT_LIST_LIMIT,
) -> str:
    """List available voices for video generation.

    Filter by language (e.g. "en", "fr"), gender ("male"/"female"),
    comma-separated tags, or search by name. Returns up to `limit`
    voices (default 50) with id, name, language, accent, gender, tags.
    Use get_voice(id) for full details including preview URL.
    """
    try:
        result = await _get_client().list_voices(
            language=language, gender=gender, tags=tags, only_public=only_public
        )
        result = _filter_by_name(result, name)
        items = _summarize(result[:limit], _VOICE_SUMMARY_KEYS)
        return _json({"total": len(result), "showing": len(items), "voices": items})
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def get_voice(voice_id: str) -> str:
    """Get details for a specific voice by its ID.

    Returns the full voice object including name, language, accent,
    gender, tags, and preview audio URL.
    """
    try:
        return _json(await _get_client().get_voice(voice_id))
    except Exception as e:
        return _error_response(e)


# ======================================================================
# Avatars
# ======================================================================


@mcp.tool()
async def list_avatars(
    gender: str | None = None,
    tags: str | None = None,
    name: str | None = None,
    only_public: bool | None = None,
    limit: int = DEFAULT_LIST_LIMIT,
) -> str:
    """List available avatar looks for video generation.

    Filter by gender ("male"/"female"), comma-separated tags, or
    search by name (e.g. "Jayden"). Returns up to `limit` avatars
    (default 50) with id, avatar_name, look_name, gender, place,
    format, tags, and available models.
    Use get_avatar(id) for full details including thumbnail/preview.
    """
    try:
        result = await _get_client().list_avatars(
            gender=gender, tags=tags, only_public=only_public
        )
        result = _filter_by_name(result, name)
        items = _summarize(result[:limit], _AVATAR_SUMMARY_KEYS)
        return _json({"total": len(result), "showing": len(items), "avatars": items})
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def get_avatar(avatar_id: str) -> str:
    """Get full details for a specific avatar including all its looks.

    Returns avatar name, gender, age, tags, thumbnail, and a list
    of looks with their status, format, and available models.
    """
    try:
        return _json(await _get_client().get_avatar(avatar_id))
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def get_avatar_look(avatar_id: str, look_id: str) -> str:
    """Get details for a specific avatar look.

    Returns look name, gender, place, format, tags, thumbnail,
    preview URL, available models, and status.
    """
    try:
        return _json(await _get_client().get_avatar_look(avatar_id, look_id))
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def get_avatar_status(avatar_id: str, look_id: str) -> str:
    """Check the creation status of an avatar look.

    Use this after create_avatar or edit_avatar to poll until
    the look is ready. Status: pending → processing → completed/failed.
    """
    try:
        return _json(await _get_client().get_avatar_status(avatar_id, look_id))
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def create_avatar(
    prompt: str | None = None,
    style: str | None = None,
    format: str | None = None,
    name: str | None = None,
    place: str | None = None,
    image_urls: list[str] | None = None,
    element_images: list[str] | None = None,
    resolution: str | None = None,
    webhook_url: str | None = None,
) -> str:
    """Create a new avatar from a text prompt or reference images.

    Provide a prompt to generate an AI avatar (2K: 2 credits, 4K: 4 credits),
    or supply image_urls to use existing images (free).

    Styles: "iphone", "selfie", "podcast", "car", "conference".
    Formats: "vertical", "horizontal".
    Resolutions: "2K", "4K" (default: "2K").

    Returns avatar_id and look_id. The avatar is generated
    asynchronously — use get_avatar_status to poll until ready.
    """
    try:
        body: dict[str, Any] = {}
        if prompt is not None:
            body["prompt"] = prompt
        if style is not None:
            body["style"] = style
        if format is not None:
            body["format"] = format
        if name is not None:
            body["name"] = name
        if place is not None:
            body["place"] = place
        if image_urls is not None:
            body["imageUrls"] = image_urls
        if element_images is not None:
            body["elementImages"] = element_images
        if resolution is not None:
            body["resolution"] = resolution
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        return _json(await _get_client().create_avatar(**body))
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def edit_avatar(
    avatar_id: str,
    look_id: str,
    prompt: str,
    format: str | None = None,
    style: str | None = None,
    image_urls: list[str] | None = None,
    upscale: bool | None = None,
    resolution: str | None = None,
    webhook_url: str | None = None,
) -> str:
    """Edit an existing avatar look to create a new variation.

    Requires avatar_id, look_id (source look), and a prompt describing
    the desired changes.

    Costs:
    - 2K resolution: 2 credits
    - 4K resolution: 4 credits
    - Upscale: +1.5 credits

    Returns a new look_id. Generation is asynchronous — use
    get_avatar_status to poll until the new look is ready.
    """
    try:
        body: dict[str, Any] = {
            "avatar_id": avatar_id,
            "look_id": look_id,
            "prompt": prompt,
        }
        if format is not None:
            body["format"] = format
        if style is not None:
            body["style"] = style
        if image_urls is not None:
            body["imageUrls"] = image_urls
        if upscale is not None:
            body["upscale"] = upscale
        if resolution is not None:
            body["resolution"] = resolution
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        return _json(await _get_client().edit_avatar(**body))
    except Exception as e:
        return _error_response(e)


# ======================================================================
# Script
# ======================================================================


@mcp.tool()
async def generate_script(
    prompt: str,
    duration: int | None = None,
    urls: list[str] | None = None,
    web_search: bool | None = None,
) -> str:
    """Generate a video script from a text prompt.

    The AI writes a narration script optimized for video.
    Optionally provide a target duration (10-600 seconds, default 60),
    URLs to extract content from (max 10), or enable web search
    for up-to-date information.

    Returns the generated script text, cost in credits, and any
    extracted images from the provided URLs.
    """
    try:
        body: dict[str, Any] = {"prompt": prompt}
        if duration is not None:
            body["duration"] = duration
        if urls is not None:
            body["urls"] = urls
        if web_search is not None:
            body["webSearch"] = web_search
        return _json(await _get_client().generate_script(**body))
    except Exception as e:
        return _error_response(e)


# ======================================================================
# Generation
# ======================================================================


@mcp.tool()
async def start_generation(
    prompt: str | None = None,
    duration: int | None = None,
    script: str | None = None,
    voice_id: str | None = None,
    voice_url: str | None = None,
    avatar_id: str | None = None,
    avatar_url: str | None = None,
    format: str | None = None,
    width: int | None = None,
    height: int | None = None,
    media_urls: list[str] | None = None,
    web_urls: list[str] | None = None,
    web_search: dict | None = None,
    animate_image: bool | None = None,
    animate_mode: str | None = None,
    emotion_enhancement: bool | None = None,
    use_veo3: bool | None = None,
    webhook_url: str | None = None,
    use_space_media: bool | None = None,
    save_media_to_space: bool | None = None,
    enable: dict | None = None,
) -> str:
    """Start an AI video generation job.

    Two modes:
    1. Prompt mode: provide `prompt` + `duration` — Hoox generates
       the script and video automatically.
    2. Script mode: provide `script` + `voice_id` — you control
       the narration text and voice.

    Optional: avatar_id (look ID), format ("vertical"/"square"/"ads"/"custom"),
    media_urls (images/videos to include), web_urls (pages to extract),
    web_search ({"script": true, "images": true}), animate_image,
    enable ({"subtitles": true, "broll": true, "music": true, "transitions": true}).

    Returns a job_id and estimated credits. Use get_generation_status
    to poll progress (recommended intervals: 5s → 10s → 30s).
    """
    try:
        body: dict[str, Any] = {}
        if prompt is not None:
            body["prompt"] = prompt
        if duration is not None:
            body["duration"] = duration
        if script is not None:
            body["script"] = script
        if voice_id is not None:
            body["voice_id"] = voice_id
        if voice_url is not None:
            body["voice_url"] = voice_url
        if avatar_id is not None:
            body["avatar_id"] = avatar_id
        if avatar_url is not None:
            body["avatar_url"] = avatar_url
        if format is not None:
            body["format"] = format
        if width is not None:
            body["width"] = width
        if height is not None:
            body["height"] = height
        if media_urls is not None:
            body["media_urls"] = media_urls
        if web_urls is not None:
            body["web_urls"] = web_urls
        if web_search is not None:
            body["web_search"] = web_search
        if animate_image is not None:
            body["animate_image"] = animate_image
        if animate_mode is not None:
            body["animate_mode"] = animate_mode
        if emotion_enhancement is not None:
            body["emotion_enhancement"] = emotion_enhancement
        if use_veo3 is not None:
            body["use_veo3"] = use_veo3
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if use_space_media is not None:
            body["use_space_media"] = use_space_media
        if save_media_to_space is not None:
            body["save_media_to_space"] = save_media_to_space
        if enable is not None:
            body["enable"] = enable
        return _json(await _get_client().start_generation(**body))
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def get_generation_status(job_id: str) -> str:
    """Check the status of a video generation job.

    Returns status (pending/processing/completed/failed),
    progress percentage, current step, and when completed,
    the video_id, thumbnail, duration, and cost.

    Recommended polling intervals: 5s → 10s → 30s.
    """
    try:
        return _json(await _get_client().get_generation_status(job_id))
    except Exception as e:
        return _error_response(e)


# ======================================================================
# Export
# ======================================================================


@mcp.tool()
async def start_export(
    video_id: str,
    format: str | None = None,
    width: int | None = None,
    height: int | None = None,
    avatar_model: str | None = None,
    webhook_url: str | None = None,
) -> str:
    """Start exporting a generated video to MP4.

    Requires the video_id from a completed generation.
    Optionally change the format ("vertical"/"square"/"ads"/"custom")
    or avatar model ("standard"/"premium"/"ultra"/"veo-3"/"veo-3-fast").

    Base export cost is 0 credits for API-generated videos.
    Extra costs may apply for premium avatar models or high resolution.

    Returns a job_id. Use get_export_status to poll progress
    (recommended intervals: 3s → 5s → 10s).
    """
    try:
        body: dict[str, Any] = {"video_id": video_id}
        if format is not None:
            body["format"] = format
        if width is not None:
            body["width"] = width
        if height is not None:
            body["height"] = height
        if avatar_model is not None:
            body["avatar_model"] = avatar_model
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        return _json(await _get_client().start_export(**body))
    except Exception as e:
        return _error_response(e)


@mcp.tool()
async def get_export_status(job_id: str) -> str:
    """Check the status of a video export job.

    Returns status (pending/processing/completed/failed),
    progress percentage, current step, and when completed,
    the download URL (valid for 7 days), thumbnail, and cost.

    Recommended polling intervals: 3s → 5s → 10s.
    """
    try:
        return _json(await _get_client().get_export_status(job_id))
    except Exception as e:
        return _error_response(e)


# ======================================================================
# Video
# ======================================================================


@mcp.tool()
async def duplicate_video(
    video_id: str,
    voice_id: str | None = None,
    avatar_look_id: str | None = None,
) -> str:
    """Duplicate a completed video, optionally changing voice or avatar.

    Provide the source video_id (must be in "done" status).
    Optionally swap in a different voice_id or avatar_look_id.

    Returns the new video_id and which changes were applied.
    """
    try:
        body: dict[str, Any] = {"video_id": video_id}
        if voice_id is not None:
            body["voice_id"] = voice_id
        if avatar_look_id is not None:
            body["avatar_look_id"] = avatar_look_id
        return _json(await _get_client().duplicate_video(**body))
    except Exception as e:
        return _error_response(e)



def main() -> None:
    """Entry point for the hoox-mcp CLI."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
