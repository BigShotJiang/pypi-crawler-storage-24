---
name: ocr
description: 图片/PDF 转 Markdown 的 OCR 技能。通过 PaddleOCR 版面解析 API 将图片或 PDF 文件识别并转换为结构化的 Markdown 文本。当用户提到"OCR"、"识别图片"、"图片转文字"、"PDF转markdown"、"提取文字"、"文字识别"、"识别这个文件"、"把这个PDF/图片转成文本"，或者给出图片/PDF路径要求提取内容时，都应触发此技能。即使用户只是说"帮我看看这个图片里写了什么"或"把这个扫描件转成可编辑的"，也应触发。
---

# OCR: 图片/PDF 转 Markdown

将图片（PNG、JPG、BMP、TIFF、WebP）或 PDF 文件通过 PaddleOCR 版面解析 API 转换为结构化 Markdown。

## API 信息

- 地址: `http://192.168.25.212:8080/layout-parsing`
- 方法: POST，JSON body
- 无需认证

## 使用方式

技能目录下有现成的脚本 `scripts/ocr.py`，直接用 Python 调用即可，无需额外依赖（仅用标准库）。

**重要**: 脚本路径使用 `${SKILL_DIR}` 变量，即本技能的根目录。加载技能时会提示 "Base directory for this skill: ..."，用该路径替换 `${SKILL_DIR}`。

### 基本用法

```bash
# 本地文件（图片或 PDF）
python3 ${SKILL_DIR}/scripts/ocr.py /path/to/file.png

# URL
python3 ${SKILL_DIR}/scripts/ocr.py https://example.com/document.pdf

# 指定输出路径
python3 ${SKILL_DIR}/scripts/ocr.py /path/to/file.pdf -o /path/to/output.md
```

脚本成功执行后，会输出生成的 Markdown 文件的绝对路径。

### 可选参数

| 参数 | 说明 |
|------|------|
| `-o`, `--output` | 指定输出文件路径，默认为输入文件同名 `.md` |
| `--no-layout` | 禁用版面检测（纯文本场景更快） |
| `--no-restructure` | 禁用多页 PDF 重组（保持原始页面分隔） |

## 工作流程

1. **确认输入**: 拿到用户给的文件路径或 URL
2. **执行脚本**: 用 Bash 工具运行 `python3 ${SKILL_DIR}/scripts/ocr.py <input>`
3. **输出结果**: 脚本会打印生成的 `.md` 文件路径，告知用户
4. **按需后处理**: 如果用户需要，可以读取生成的 Markdown 内容做进一步处理（总结、翻译等）

## 注意事项

- 大文件（特别是多页 PDF）处理时间可能较长，脚本设置了 300 秒超时
- 如果 API 服务不可用，脚本会报错 — 提示用户检查 `192.168.25.212:8080` 是否可达
- 对于多页 PDF，默认启用页面重组和标题层级调整，输出更连贯的 Markdown
- 输入文件类型由扩展名自动判断，支持: `.png` `.jpg` `.jpeg` `.bmp` `.tiff` `.tif` `.webp` `.pdf`
