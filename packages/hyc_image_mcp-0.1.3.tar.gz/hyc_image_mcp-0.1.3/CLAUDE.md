1. 使用uv run 脚本名.py 来运行脚本。
2. 这是一个mcp server 的项目， 不要自己造轮子。优先使用 fastmcp 这个lib来实现mcp server的底层逻辑
3. 涉及到 mcp 相关的功能开发，一定要先查询 context7 mcp server 这里是最新的技术文档