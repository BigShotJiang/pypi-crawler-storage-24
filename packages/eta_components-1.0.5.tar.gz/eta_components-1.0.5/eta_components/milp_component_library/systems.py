from __future__ import annotations

import logging
import time
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

import xarray as xr

from eta_components.milp_component_library.backends.protocol import BackendProtocol, ResultsBundle, SolveInfo
from eta_components.milp_component_library.exceptions import InfeasibleProblemError, UnboundedProblemError
from eta_components.milp_component_library.indexing import DIMS_ORDER, make_index

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from eta_components.milp_component_library.environments import _BaseEnvironment
    from eta_components.milp_component_library.networks import _BaseNetwork
    from eta_components.milp_component_library.objectives import _BaseObjective
    from eta_components.milp_component_library.units.base_unit import BaseUnit


class _BaseSystem:
    """Linopy-native system orchestrator.

    eta-components is Linopy-only. All variables/constraints/objectives are built through the backend protocol.

    **Batch mode (vectorized scenarios):** When `n_scenarios` is set, the system index includes a
    `scenario` coordinate. For *batch* use (e.g. antifragile PCE with independent scenario copies),
    **no non-anticipativity constraints** are added; scenario is used only to index independent
    copies. Design variables (investment/capex) are scenario-free; operational variables and
    constraints use the full index including scenario. See cross-repo.md (eta-incerto) Contract.
    """

    def __init__(
        self,
        n_years: int,
        n_periods: int,
        n_time_steps: int,
        step_length: float = 1,
        year_length: int = 1,
        *,
        n_scenarios: int | None = None,
        backend: str | BackendProtocol = "linopy",
        backend_options: dict[str, Any] | None = None,
    ):
        self._n_years = int(n_years)
        self._n_periods = int(n_periods)
        self._n_time_steps = int(n_time_steps)
        self._step_length = float(step_length)
        self._year_length = int(year_length)
        self._n_scenarios = int(n_scenarios) if n_scenarios is not None else None

        # Indexing contract
        self.dims_order: tuple[str, ...] = DIMS_ORDER
        end_year = self._n_years * self._year_length
        years = list(range(1, end_year + 1, self._year_length))
        periods = list(range(1, self._n_periods + 1))
        time = list(range(1, self._n_time_steps + 1))
        coords: dict[str, Any] = {"year": years, "period": periods, "time": time}
        if self._n_scenarios is not None:
            coords["scenario"] = list(range(1, self._n_scenarios + 1))
        self.index: xr.Dataset = make_index(coords)

        self._units: list[BaseUnit] = []
        self._networks: list[_BaseNetwork] = []
        self._environments: list[_BaseEnvironment] = []

        self._objective: _BaseObjective | None = None
        self._is_objective_set: bool = False

        self._backend_spec: str | BackendProtocol = backend
        self._backend_options: dict[str, Any] = dict(backend_options or {})
        self._backend_name: str = backend if isinstance(backend, str) else type(backend).__name__
        self._backend: BackendProtocol = self._initialize_backend(self._backend_spec)
        self.last_solve_info: SolveInfo | None = None
        self.last_results: ResultsBundle | None = None

        # Objective term registry for backend-built objectives.
        # Structure: kind -> term_name -> {"expr": <ExprHandle>, "weight": float}
        self._objective_terms: dict[str, dict[str, dict[str, object]]] = {"opex": {}, "capex": {}, "emissions": {}}
        self._rebuild_required: bool = False
        self._constraints_built: bool = False
        self._cached_operational_time_dims_coords: tuple[tuple[str, ...], dict[str, Any]] | None = None
        self._cached_design_time_dims_coords: tuple[tuple[str, ...], dict[str, Any]] | None = None

    # -----------------------------
    # Batch mode / design vs operational coords
    # -----------------------------
    @property
    def batch_mode(self) -> bool:
        """True when system has multiple scenarios used as independent batch (no non-anticipativity)."""
        return self._n_scenarios is not None

    def get_investment_years(self) -> list:
        """Years in which investment is allowed. Standard: first year only."""
        return list(self.index.coords["year"].values)[:1]

    def get_design_coords(self) -> dict[str, Any]:
        """Coords for design (investment) variables: index coords excluding scenario; year = first year only."""
        coords = {k: list(v.values) for k, v in self.index.coords.items() if k != "scenario"}
        coords["year"] = self.get_investment_years()
        return coords

    def get_operational_coords(self) -> dict[str, Any]:
        """Coords for operational variables: full index coords (including scenario when batch_mode)."""
        return {k: list(v.values) for k, v in self.index.coords.items()}

    def get_operational_time_dims_coords(self) -> tuple[tuple[str, ...], dict[str, Any]]:
        """(dims, coords) for operational time-indexed vars (year, period, time; + scenario if batch_mode)."""
        if self._cached_operational_time_dims_coords is not None:
            return self._cached_operational_time_dims_coords
        idx = self.index
        dims: tuple[str, ...] = ("year", "period", "time")
        coords = {d: list(idx.coords[d].values) for d in dims}
        if self.batch_mode and "scenario" in idx.coords:
            dims = ("scenario", *dims)
            coords = {"scenario": list(idx.coords["scenario"].values), **coords}
        self._cached_operational_time_dims_coords = (dims, coords)
        return self._cached_operational_time_dims_coords

    def get_design_time_dims_coords(self) -> tuple[tuple[str, ...], dict[str, Any]]:
        """(dims, coords) for design time-indexed vars: same as operational but without scenario."""
        if self._cached_design_time_dims_coords is not None:
            return self._cached_design_time_dims_coords
        dims, coords = self.get_operational_time_dims_coords()
        if "scenario" in coords:
            dims = tuple(d for d in dims if d != "scenario")
            coords = {d: coords[d] for d in dims}
        self._cached_design_time_dims_coords = (dims, coords)
        return self._cached_design_time_dims_coords

    def _initialize_backend(self, backend: str | BackendProtocol) -> BackendProtocol:
        if isinstance(backend, BackendProtocol):
            return backend

        if str(backend).lower() != "linopy":
            raise ValueError(
                "eta-components is Linopy-only. Pass backend='linopy' or provide a BackendProtocol instance."
            )

        from eta_components.milp_component_library.backends.linopy_backend import LinopyBackend

        opts = getattr(self, "_backend_options", None) or {}
        return LinopyBackend(
            explicit_coordinate_names=opts.get("explicit_coordinate_names", True),
        )

    def _reset_backend_for_rebuild(self) -> None:
        """Reset backend state for rebuild-on-solve semantics."""
        if isinstance(self._backend_spec, str):
            # Re-create a new backend instance (simplest way to clear vars/constraints/objective).
            self._backend = self._initialize_backend(self._backend_spec)
            return

        # If caller provided a backend instance, try a best-effort reset hook.
        backend = self._backend_spec
        if hasattr(backend, "reset") and callable(backend.reset):
            backend.reset()
        self._backend = backend

    def _rebuild_model(self) -> None:
        """Rebuild variables/constraints/objective from current components.

        This enables repeated `solve()` calls (and `update_data(...); solve()`) without
        accumulating duplicate constraints in the backend model.
        """

        # Reset objective term registry.
        self.clear_objective_terms()

        # Reset network registrations (units will re-register powers; losses will re-register).
        for net in self._networks:
            if hasattr(net, "reset_registrations"):
                net.reset_registrations()

        # Reset backend and rebuild units (recreate decision variables/expressions).
        self._reset_backend_for_rebuild()
        self._constraints_built = False
        if self._objective is not None and hasattr(self._objective, "_is_constructed"):
            self._objective._is_constructed = False
        for unit in list(self._units):
            # Clear handles from any previous backend instance.
            if hasattr(unit, "vars"):
                unit.vars.clear()
            if hasattr(unit, "exprs"):
                unit.exprs.clear()
            unit.build()

    # -----------------------------
    # Backend extension points
    # -----------------------------
    @property
    def backend_model(self) -> Any:
        return getattr(self._backend, "model", None)

    def add_variable(
        self,
        name: str,
        *,
        dims: tuple[str, ...],
        coords: dict[str, Any],
        lower: Any = None,
        upper: Any = None,
        binary: bool = False,
        integer: bool = False,
    ):
        return self._backend.add_variable(
            name,
            dims=dims,
            coords=coords,
            lower=lower,
            upper=upper,
            binary=binary,
            integer=integer,
        )

    def get_var(self, name: str):
        return self._backend.get_var(name)

    def add_variables_batch(self, specs: Iterable[dict[str, Any]]) -> list[Any]:
        return self._backend.add_variables_batch(specs)

    def add_constraints(self, name: str, expr: Any) -> None:
        self._backend.add_constraints(name, expr)

    def add_constraints_batch(self, items: Iterable[tuple[str, Any]]) -> None:
        self._backend.add_constraints_batch(items)

    def set_backend_objective(self, expr: Any, *, sense: str = "min") -> None:
        self._backend.set_objective(expr, sense=sense)

    def as_lp(self, path: str | Path, *, explicit_coordinate_names: bool | None = None) -> None:
        self._backend.as_lp(path, explicit_coordinate_names=explicit_coordinate_names)

    def export_results(self, *, solve_info: SolveInfo) -> ResultsBundle:
        return self._backend.export_results(solve_info=solve_info)

    # -----------------------------
    # Objective term registry
    # -----------------------------
    def add_objective_term(self, name: str, expr: object, *, kind: str = "opex", weight: float = 1.0) -> None:
        if kind not in self._objective_terms:
            raise ValueError(f"Unknown objective term kind '{kind}'. Expected one of {list(self._objective_terms)}.")
        self._objective_terms[kind][name] = {"expr": expr, "weight": float(weight)}

    def clear_objective_terms(self, kind: str | None = None) -> None:
        if kind is None:
            for k in self._objective_terms:
                self._objective_terms[k].clear()
            return
        if kind not in self._objective_terms:
            raise ValueError(f"Unknown objective term kind '{kind}'. Expected one of {list(self._objective_terms)}.")
        self._objective_terms[kind].clear()

    # -----------------------------
    # Scenario / non-anticipativity
    # -----------------------------
    def add_non_anticipativity(  # noqa: PLR0912
        self,
        var_key: Any,
        stage_selector: Any,
        *,
        scenarios: Any = None,
        name: str | None = None,
        anchor: str = "scenario0",
    ) -> None:
        """Add non-anticipativity constraints for a scenario-indexed variable.

        See cross-repo.md (eta-incerto) Contract section for the required semantics.
        """

        if "scenario" not in self.index.coords:
            raise ValueError("Cannot add non-anticipativity constraints: system has no 'scenario' dim.")

        var = var_key
        if isinstance(var_key, tuple) and len(var_key) == 2:
            component, local = var_key
            dims = tuple(d for d in self.dims_order if d in ("scenario", "year", "period", "time"))
            var_name = f"{component}__{local}__{'_'.join(dims)}"
            var = self.get_var(var_name)

        if not hasattr(var, "dims") or "scenario" not in getattr(var, "dims", ()):
            raise TypeError("var_key must refer to a scenario-indexed variable (dims include 'scenario').")

        # Build mask on time dims only.
        if callable(stage_selector):
            mask = stage_selector(self.index)
        elif isinstance(stage_selector, dict):
            mask = self._stage_mask_from_spec(stage_selector)
        else:
            raise TypeError("stage_selector must be a callable or a dict spec.")

        if not isinstance(mask, xr.DataArray):
            raise TypeError("stage_selector must produce an xarray.DataArray mask.")
        if "scenario" in mask.dims:
            raise ValueError("stage mask must not include 'scenario' dim.")

        # Normalize scenario selection.
        all_scen = list(self.index.coords["scenario"].values)
        scen_list = list(all_scen if scenarios is None else scenarios)
        if not scen_list:
            return

        if anchor == "scenario0":
            anchor_s = scen_list[0]
        elif anchor in scen_list:
            anchor_s = anchor
        else:
            raise ValueError("anchor must be 'scenario0' or a scenario coordinate included in scenarios.")

        others = [s for s in scen_list if s != anchor_s]
        if not others:
            return

        # Vectorized: enforce var(s,...) == var(anchor,...), masked on stage.
        diff = var.sel(scenario=others) - var.sel(scenario=anchor_s)
        diff = diff.where(mask, other=0)

        con_name = name or f"non_anticipativity__{getattr(var, 'name', 'var')}"
        self.add_constraints(con_name, diff == 0)

    def _stage_mask_from_spec(self, spec: dict[str, Any]) -> xr.DataArray:
        years = list(self.index.coords["year"].values)
        periods = list(self.index.coords["period"].values)
        times = list(self.index.coords["time"].values)

        mask = xr.DataArray(
            True,
            coords={"year": years, "period": periods, "time": times},
            dims=("year", "period", "time"),
            name="stage_mask",
        )

        year_max = spec.get("year_max", spec.get("year"))
        period_max = spec.get("period_max", spec.get("period"))
        time_max = spec.get("time_max", spec.get("time"))

        if year_max is not None:
            y = xr.DataArray(years, coords={"year": years}, dims=("year",))
            mask = mask & (y <= int(year_max))
        if period_max is not None:
            p = xr.DataArray(periods, coords={"period": periods}, dims=("period",))
            mask = mask & (p <= int(period_max))
        if time_max is not None:
            t = xr.DataArray(times, coords={"time": times}, dims=("time",))
            mask = mask & (t <= int(time_max))

        return mask

    # -----------------------------
    # Registration
    # -----------------------------
    def register_unit(self, unit: BaseUnit) -> None:
        self._units.append(unit)
        # If the model was already built once, adding units requires a rebuild.
        if self._constraints_built:
            self._rebuild_required = True

    def unregister_unit(self, unit: BaseUnit) -> None:
        if unit in self._units:
            self._units.remove(unit)
            self._rebuild_required = True

    def register_network(self, network: _BaseNetwork) -> None:
        self._networks.append(network)
        if self._constraints_built:
            self._rebuild_required = True

    def unregister_network(self, network: _BaseNetwork) -> None:
        if network in self._networks:
            self._networks.remove(network)
            self._rebuild_required = True

    def register_environment(self, environment: _BaseEnvironment) -> None:
        self._environments.append(environment)

    def unregister_environment(self, environment: _BaseEnvironment) -> None:
        if environment in self._environments:
            self._environments.remove(environment)
            self._rebuild_required = True

    def get_network(self, name: str) -> _BaseNetwork:
        """Return the network with the given name."""
        for net in self._networks:
            if net.name == name:
                return net
        raise KeyError(f"No network named '{name}'.")

    def get_unit(self, name: str) -> BaseUnit:
        """Return the unit with the given name."""
        for unit in self._units:
            if unit.name == name:
                return unit
        raise KeyError(f"No unit named '{name}'.")

    def get_environment(self, name: str) -> _BaseEnvironment:
        """Return the environment with the given name."""
        for env in self._environments:
            if env.name == name:
                return env
        raise KeyError(f"No environment named '{name}'.")

    # -----------------------------
    # Objective orchestration
    # -----------------------------
    def set_objective(self, objective: _BaseObjective) -> None:
        self._objective = objective
        self._is_objective_set = True

    @property
    def objective(self) -> _BaseObjective:
        if self._objective is None:
            raise RuntimeError("Accessing unset objective.")
        return self._objective

    # -----------------------------
    # Solve
    # -----------------------------
    def solve(
        self,
        *,
        solver: str = "highs",
        options: dict[str, Any] | None = None,
        tee: bool = False,
        export_results: bool = True,
        model_export: str | Path | None = None,
        explicit_coordinate_names: bool = True,
    ) -> ResultsBundle | SolveInfo:
        build_rebuild_s = 0.0
        build_networks_s = 0.0
        build_objective_s = 0.0
        solve_s = 0.0

        # Rebuild only when requested (e.g. after update_data()).
        if self._rebuild_required:
            t0 = time.perf_counter()
            self._rebuild_model()
            self._rebuild_required = False
            build_rebuild_s = time.perf_counter() - t0

        # Build constraints for networks only once per backend build.
        if not self._constraints_built:
            t0 = time.perf_counter()
            for network in self._networks:
                if hasattr(network, "build_constraints"):
                    network.build_constraints()
            self._constraints_built = True
            build_networks_s = time.perf_counter() - t0

        # Allow objectives to build a backend objective from registered terms.
        # Skip if already constructed (e.g. by DeterministicFramework.build_model()) to avoid
        # duplicate variable/constraint errors such as __obj_per_scenario already assigned.
        if (
            self._is_objective_set
            and self._objective is not None
            and hasattr(self._objective, "construct_objective")
            and not getattr(self._objective, "_is_constructed", False)
        ):
            t0 = time.perf_counter()
            self._objective.construct_objective()
            build_objective_s = time.perf_counter() - t0

        if model_export:
            path = Path("model.lp") if model_export is True else Path(model_export)
            self.as_lp(path, explicit_coordinate_names=explicit_coordinate_names)

        t0 = time.perf_counter()
        solve_info = self._backend.solve(solver=str(solver), options=dict(options or {}), tee=bool(tee))
        solve_s = time.perf_counter() - t0

        logger.info(
            "build_rebuild_s=%.3f build_networks_s=%.3f build_objective_s=%.3f solve_s=%.3f",
            build_rebuild_s,
            build_networks_s,
            build_objective_s,
            solve_s,
        )
        self.last_solve_info = solve_info

        term = (solve_info.termination_condition or "").lower()
        if "infeasible" in term:
            raise InfeasibleProblemError("Model reported infeasible.")
        if "unbounded" in term:
            raise UnboundedProblemError("Model reported unbounded.")

        if not export_results:
            return solve_info
        bundle = self.export_results(solve_info=solve_info)
        self.last_results = bundle
        return bundle

    # -----------------------------
    # Compat surface (cross-repo contract)
    # -----------------------------
    @property
    def years_set(self) -> list:
        return list(self.index.coords["year"].values)

    @property
    def periods_set(self) -> list:
        return list(self.index.coords["period"].values)

    @property
    def time_set(self) -> list:
        return list(self.index.coords["time"].values)

    @property
    def sets(self) -> tuple[list, ...]:
        """Return (years_set, periods_set, time_set) for compatibility."""
        return (self.years_set, self.periods_set, self.time_set)

    def join_models(self) -> None:
        """No-op compatibility hook. Linopy builds one model per system; no join step."""

    # -----------------------------
    # Metadata
    # -----------------------------
    @property
    def created_at(self) -> datetime:
        return datetime.now(tz=timezone.utc)

    @property
    def units(self) -> list[BaseUnit]:
        return self._units

    @property
    def networks(self) -> list[_BaseNetwork]:
        return self._networks

    @property
    def environments(self) -> list[_BaseEnvironment]:
        return self._environments


class BasicSystem(_BaseSystem):
    """System for basic optimization (Linopy-only)."""

    @property
    def step_length(self) -> float:
        return float(self._step_length)
