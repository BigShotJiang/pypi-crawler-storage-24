"""Objectives for MILP systems. All use SI units: W, Wh, EUR.

NetPresentValue objective value: output **EUR**.
Unit dispatch (power variables from equipment): output **W**.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, ClassVar

import xarray as xr

from eta_components.milp_component_library.base_object import BaseObject

if TYPE_CHECKING:
    from eta_components.milp_component_library.systems import _BaseSystem


class _BaseObjective(BaseObject, ABC):
    """Abstract base class for system objectives (Linopy-only)."""

    _param_names: ClassVar[list[str]] = []
    _optional_params: ClassVar[dict[str, Any]] = {"sense": "minimize"}

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self._is_constructed: bool = False
        self._active: bool = True

    @abstractmethod
    def construct_objective(self) -> None:
        """Construct the backend objective via `system.set_backend_objective(...)`."""

    def _sense_backend(self) -> str:
        sense = str(self.data.get("sense", "minimize")).lower()
        return "min" if sense in {"min", "minimize"} else "max"

    def deactivate(self) -> None:
        """Deactivate this objective: set backend objective to 0 so it does not contribute."""
        self._active = False
        self.system.set_backend_objective(0, sense=self._sense_backend())

    def activate(self) -> None:
        """Reactivate this objective; next construct_objective() will build the real expression."""
        self._active = True
        self._is_constructed = False

    def update_data(self, updates: dict[str, Any]) -> None:  # type: ignore[override]
        # Objective parameter updates should not force a full backend rebuild; they only require
        # reconstructing the objective expression on the existing model.
        super().update_data(updates)
        if hasattr(self.system, "_rebuild_required"):
            self.system._rebuild_required = False
        self._is_constructed = False


class _SingleObjective(_BaseObjective, ABC):
    pass


class DummyObjective(_SingleObjective):
    """Placeholder objective used when callers haven't set a real objective yet."""

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self.expr: object | None = None

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        expr = 0 if self.expr is None else self.expr
        self.system.set_backend_objective(expr, sense=self._sense_backend())
        self._is_constructed = True


class _WeightedObjective(_SingleObjective, ABC):
    _optional_params: ClassVar[dict[str, Any]] = {
        **_BaseObjective._optional_params,
        "weights": 1,
    }

    def _weights_da(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        periods = list(self.system.index.coords["period"].values)
        weights = self.data.get("weights", 1)

        if isinstance(weights, dict):
            w = {(y, p): float(weights.get((y, p), 0.0)) for y in years for p in periods}
        else:
            w = {(y, p): float(weights) for y in years for p in periods}

        return xr.DataArray(
            [[w[(y, p)] for p in periods] for y in years],
            coords={"year": years, "period": periods},
            dims=("year", "period"),
            name="weights",
        )

    @property
    def weights(self) -> xr.DataArray:
        return self._weights_da()


def _sum_objective_terms(term_dict: dict[str, dict[str, object]]) -> object:
    expr = None
    for meta in term_dict.values():
        term_expr = meta["expr"]
        term_weight = float(meta.get("weight", 1.0))
        term_expr = term_expr * term_weight
        expr = term_expr if expr is None else (expr + term_expr)
    return expr if expr is not None else 0


def _sum_all_dims(expr: object) -> object:
    if hasattr(expr, "sum"):
        try:
            return expr.sum()
        except TypeError:
            return expr.sum(dim=getattr(expr, "dims", None))
    return expr


def sum_all_dims(expr: object) -> object:
    """Sum expression over all dimensions. For use by scenario aggregators (e.g. eta-incerto)."""
    return _sum_all_dims(expr)


def _align_weights_to_expr(
    w: xr.DataArray,
    expr: object,
    dims_order: tuple[str, ...] = ("scenario", "year", "period", "time"),
) -> xr.DataArray:
    """Align weight DataArray to the expression's coordinates so expr * w does not change dimension sizes.

    Uses expression coeffs (for Linopy) or the expression itself for dims/coords. For each shared dim
    in dims_order (scenario, year, period, time), reindex or expand_dims so that w matches the
    expression; reindex uses fill_value=0.0. _term is intentionally skipped so that weights broadcast
    over objective terms and do not introduce conflicting _term sizes when summing multiple terms.
    """
    expr_da = getattr(expr, "coeffs", expr)
    if not hasattr(expr_da, "dims"):
        return w
    dims_to_align = [d for d in dims_order if d in expr_da.dims]
    for d in dims_to_align:
        coords = getattr(expr_da, "coords", None)
        if coords is not None and d in coords:
            target_vals = list(expr_da.coords[d].values)
        else:
            n = getattr(expr_da, "sizes", {}).get(d, 0)
            target_vals = list(range(n))
        w = w.expand_dims({d: target_vals}) if d not in w.dims else w.reindex({d: target_vals}, fill_value=0.0)
    order = [d for d in dims_order if d in w.dims]
    return w.transpose(*order)


class StaticCost(_WeightedObjective):
    """Aggregate cost objective based on the system objective-term registry.

    Expected terms:
    - kind="opex": time-structured (typically year/period/time) expressions
    - kind="capex": scalar-like expressions
    - kind="emissions": time-structured emission expressions (optional)
    """

    _optional_params: ClassVar[dict[str, Any]] = {
        **_WeightedObjective._optional_params,
        "emission_cost": 0,
    }

    def _expression(self) -> object:
        terms = getattr(self.system, "_objective_terms", {})
        opex_expr = _sum_objective_terms(terms.get("opex", {}))
        capex_expr = _sum_objective_terms(terms.get("capex", {}))
        emissions_expr = _sum_objective_terms(terms.get("emissions", {}))

        w = self._weights_da()
        step_length = float(getattr(self.system, "step_length", 1.0))

        def _weight(expr: object) -> object:
            if hasattr(expr, "dims") and ("year" in expr.dims and "period" in expr.dims):
                return expr * w
            return expr

        emission_cost = self.data.get("emission_cost", 0)
        if emissions_expr != 0 and emission_cost:
            years = list(self.system.index.coords["year"].values)
            if isinstance(emission_cost, dict):
                cost = xr.DataArray(
                    [float(emission_cost.get(y, 0.0)) for y in years],
                    coords={"year": years},
                    dims=("year",),
                    name="emission_cost",
                )
            else:
                cost = float(emission_cost)
            emissions_expr = emissions_expr * cost

        # Opex/emissions are typically per-time-step flows; scale by system step_length.
        def _scale_time(expr: object) -> object:
            if hasattr(expr, "dims") and ("time" in expr.dims):
                return expr * step_length
            return expr

        return (
            _sum_all_dims(_scale_time(_weight(opex_expr)))
            + _sum_all_dims(_scale_time(_weight(emissions_expr)))
            + _sum_all_dims(capex_expr)
        )

    def _operational_and_capex_parts(self) -> tuple[object, object]:
        """Return (operational_expr, capex_expr) for batch-mode per-scenario objective."""
        terms = getattr(self.system, "_objective_terms", {})
        opex_expr = _sum_objective_terms(terms.get("opex", {}))
        capex_expr = _sum_objective_terms(terms.get("capex", {}))
        emissions_expr = _sum_objective_terms(terms.get("emissions", {}))

        w = self._weights_da()
        step_length = float(getattr(self.system, "step_length", 1.0))

        def _weight(expr: object) -> object:
            if hasattr(expr, "dims") and ("year" in expr.dims and "period" in expr.dims):
                w_use = w
                if getattr(self.system, "batch_mode", False):
                    dims_order = getattr(self.system, "dims_order", ("scenario", "year", "period", "time"))
                    w_use = _align_weights_to_expr(w, expr, dims_order)
                return expr * w_use
            return expr

        emission_cost = self.data.get("emission_cost", 0)
        if emissions_expr != 0 and emission_cost:
            years = list(self.system.index.coords["year"].values)
            if isinstance(emission_cost, dict):
                cost = xr.DataArray(
                    [float(emission_cost.get(y, 0.0)) for y in years],
                    coords={"year": years},
                    dims=("year",),
                    name="emission_cost",
                )
            else:
                cost = float(emission_cost)
            emissions_expr = emissions_expr * cost

        def _scale_time(expr: object) -> object:
            if hasattr(expr, "dims") and ("time" in expr.dims):
                return expr * step_length
            return expr

        if getattr(self.system, "batch_mode", False):
            # Weight the combined expression once so _term dimension is consistent when summing.
            operational_unscaled = opex_expr + emissions_expr
            w_use = _align_weights_to_expr(
                w, operational_unscaled, getattr(self.system, "dims_order", ("scenario", "year", "period", "time"))
            )
            operational = _scale_time(operational_unscaled * w_use)
        else:
            operational = _scale_time(_weight(opex_expr)) + _scale_time(_weight(emissions_expr))
        return operational, capex_expr

    def get_operational_and_capex_parts(self) -> tuple[object, object]:
        """Return (operational_expr, capex_expr) for use by scenario aggregators (e.g. in eta-incerto).

        In batch mode, operational is time-weighted opex+emissions per scenario; capex_expr is the
        capex sum. Callers must ensure the system is already built (index, objective terms) when
        calling.
        """
        return self._operational_and_capex_parts()

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        if getattr(self.system, "batch_mode", False) and "scenario" in self.system.index.coords:
            # Batch mode: do not set objective here; an external aggregator (e.g. eta-incerto) will.
            self._is_constructed = True
            return
        total = self._expression()
        sense = str(self.data.get("sense", "minimize")).lower()
        sense_backend = "min" if sense in {"min", "minimize"} else "max"
        self.system.set_backend_objective(total, sense=sense_backend)
        self._is_constructed = True


class Emissions(_WeightedObjective):
    """Emissions-only objective using registry kind="emissions"."""

    def get_operational_and_capex_parts(self) -> tuple[object, object]:
        """Return (emissions_expr, 0) for use by scenario aggregators. Capex is 0 for emissions."""
        terms = getattr(self.system, "_objective_terms", {})
        emissions_expr = _sum_objective_terms(terms.get("emissions", {}))
        w = self._weights_da()
        if hasattr(emissions_expr, "dims") and ("year" in emissions_expr.dims and "period" in emissions_expr.dims):
            dims_order = getattr(self.system, "dims_order", ("scenario", "year", "period", "time"))
            w_aligned = _align_weights_to_expr(w, emissions_expr, dims_order)
            emissions_expr = emissions_expr * w_aligned
        return emissions_expr, 0

    def _expression(self) -> object:
        terms = getattr(self.system, "_objective_terms", {})
        emissions_expr = _sum_objective_terms(terms.get("emissions", {}))
        w = self._weights_da()
        if hasattr(emissions_expr, "dims") and ("year" in emissions_expr.dims and "period" in emissions_expr.dims):
            emissions_expr = emissions_expr * w
        return _sum_all_dims(emissions_expr)

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        if getattr(self.system, "batch_mode", False) and "scenario" in self.system.index.coords:
            # Batch mode: do not set objective here; an external aggregator (e.g. eta-incerto) will.
            self._is_constructed = True
            return
        total = self._expression()
        sense = str(self.data.get("sense", "minimize")).lower()
        sense_backend = "min" if sense in {"min", "minimize"} else "max"
        self.system.set_backend_objective(total, sense=sense_backend)
        self._is_constructed = True


class NetPresentValue(StaticCost):
    """Discounted cost objective (NPV-style) on opex/emissions terms.

    Parameters:
    - interest: mapping year -> interest rate

    Units: objective value output is **EUR**.
    """

    _optional_params: ClassVar[dict[str, Any]] = {
        **StaticCost._optional_params,
        "interest": {},
    }

    def _operational_and_capex_parts(self) -> tuple[object, object]:
        """Operational and capex with discount applied (for batch-mode per-scenario objective)."""
        operational, capex_expr = super()._operational_and_capex_parts()
        disc = self._discount_da()

        def _discount(expr: object) -> object:
            if hasattr(expr, "dims") and ("year" in expr.dims):
                disc_use = disc
                if getattr(self.system, "batch_mode", False):
                    dims_order = getattr(self.system, "dims_order", ("scenario", "year", "period", "time"))
                    disc_use = _align_weights_to_expr(disc, expr, dims_order)
                return expr * disc_use
            return expr

        return _discount(operational), capex_expr

    def _discount_da(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        interest = self.data.get("interest", {}) or {}
        year_length = int(getattr(self.system, "_year_length", 1))
        y0 = min(years) if years else 1

        if isinstance(interest, (int, float)):
            r = [float(interest) for _ in years]
        else:
            r = [float(interest.get(int(y), 0.0)) for y in years]
        exp = [int(y) - int(y0) + year_length for y in years]
        disc = [1.0 / ((1.0 + rr) ** ee) for rr, ee in zip(r, exp, strict=False)]
        return xr.DataArray(disc, coords={"year": years}, dims=("year",), name="discount")

    def _expression(self) -> object:
        # Base StaticCost expression pieces, but apply discount to time-structured parts.
        terms = getattr(self.system, "_objective_terms", {})
        opex_expr = _sum_objective_terms(terms.get("opex", {}))
        capex_expr = _sum_objective_terms(terms.get("capex", {}))
        emissions_expr = _sum_objective_terms(terms.get("emissions", {}))

        w = self._weights_da()
        step_length = float(getattr(self.system, "step_length", 1.0))
        disc = self._discount_da()

        def _weight(expr: object) -> object:
            if hasattr(expr, "dims") and ("year" in expr.dims and "period" in expr.dims):
                return expr * w
            return expr

        def _scale_time(expr: object) -> object:
            if hasattr(expr, "dims") and ("time" in expr.dims):
                return expr * step_length
            return expr

        def _discount(expr: object) -> object:
            if hasattr(expr, "dims") and ("year" in expr.dims):
                return expr * disc
            return expr

        return (
            _sum_all_dims(_discount(_scale_time(_weight(opex_expr))))
            + _sum_all_dims(_discount(_scale_time(_weight(emissions_expr))))
            + _sum_all_dims(capex_expr)
        )


class TotalAnnualizedCost(NetPresentValue):
    """Total Annualized Costs (TAC): NPV / APVF.
    APVF = ((1+i)^Th - 1) / (i(1+i)^Th), Th = horizon.n_years, i = interest.
    Output: **EUR/year**.
    """

    _optional_params: ClassVar[dict[str, Any]] = {
        **NetPresentValue._optional_params,
        "n_years": None,
    }

    def _apvf(self) -> float:
        i = self.data.get("interest", 0.0)
        if isinstance(i, dict):
            vals = list(i.values()) if i else [0.0]
            i = float(vals[0]) if vals else 0.0
        else:
            i = float(i)
        th = self.data.get("n_years")
        if th is None:
            th = int(getattr(self.system, "_n_years", 1))
            years = list(self.system.index.coords.get("year", []))
            if years:
                th = len(years)
        th = int(th)
        if i <= 0:
            return float(th)
        return ((1.0 + i) ** th - 1.0) / (i * (1.0 + i) ** th)

    def _expression(self) -> object:
        npv_total = super()._expression()
        apvf = self._apvf()
        return npv_total / apvf

    def _operational_and_capex_parts(self) -> tuple[object, object]:
        operational, capex_expr = super()._operational_and_capex_parts()
        apvf = self._apvf()
        return operational / apvf, capex_expr / apvf


class MultiObjective(_SingleObjective):
    """Combine two objective expressions with weights."""

    _optional_params: ClassVar[dict[str, Any]] = {
        **_BaseObjective._optional_params,
        "first_weight": 1.0,
        "second_weight": 1.0,
    }

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self.first_objective = data["first_objective"]
        self.second_objective = data["second_objective"]

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        w1 = float(self.data.get("first_weight", 1.0))
        w2 = float(self.data.get("second_weight", 1.0))

        expr1 = self.first_objective._expression()
        expr2 = self.second_objective._expression()
        total = w1 * expr1 + w2 * expr2

        sense = str(self.data.get("sense", "minimize")).lower()
        sense_backend = "min" if sense in {"min", "minimize"} else "max"
        self.system.set_backend_objective(total, sense=sense_backend)
        self._is_constructed = True
