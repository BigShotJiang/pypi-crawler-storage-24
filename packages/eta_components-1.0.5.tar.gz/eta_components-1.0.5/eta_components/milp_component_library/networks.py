from __future__ import annotations

import itertools
import logging
from abc import ABC
from enum import Enum
from typing import TYPE_CHECKING, Any, ClassVar

import tabulate
import xarray as xr

from eta_components.milp_component_library.base_object import BaseObject

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from eta_components.milp_component_library.systems import _BaseSystem
    from eta_components.milp_component_library.units.base_unit import BaseUnit


class PowerSign(Enum):
    UNDEFINED = 1
    POSITIVE = 2
    NEGATIVE = 3


class _BaseNetwork(BaseObject, ABC):
    """Linopy-native network with a vectorized power balance constraint."""

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        system.register_network(self)

        # Registered power expressions (Linopy/xarray expressions; scalar allowed).
        self._positive_powers: list[tuple[BaseUnit, Any]] = []
        self._negative_powers: list[tuple[BaseUnit, Any]] = []
        self._undefined_powers: list[tuple[BaseUnit, Any]] = []

        # Optional loss components (kept as generic hooks for now).
        self._losses: list[Any] = []

    def register_unit(self, unit: BaseUnit, power: Any, kind: PowerSign) -> None:
        """Register a unit's power expression for this network.

        Convention: the provided `power` should already carry the intended sign.
        The `kind` is used for grouping/display only.
        """

        if kind == PowerSign.UNDEFINED:
            self._undefined_powers.append((unit, power))
        elif kind == PowerSign.POSITIVE:
            self._positive_powers.append((unit, power))
        elif kind == PowerSign.NEGATIVE:
            self._negative_powers.append((unit, power))
        else:
            raise ValueError(f"Unknown power kind {kind!r}.")

    def unregister_unit(self, unit: BaseUnit) -> None:
        removed = False
        for bucket in (self._undefined_powers, self._positive_powers, self._negative_powers):
            for unit_, power in list(bucket):
                if unit_ == unit:
                    bucket.remove((unit_, power))
                    removed = True
        if not removed:
            raise ValueError(f"Unit {unit.name} is not registered in network {self.name}.")

    def register_loss(self, loss: Any) -> None:
        self._losses.append(loss)

    def unregister_loss(self, loss: Any) -> None:
        try:
            self._losses.remove(loss)
        except ValueError as err:
            msg = f"Transmission loss {getattr(loss, 'name', loss)} is not registered in {self.name}."
            raise ValueError(msg) from err

    def build_constraints(self) -> None:
        """Build all network constraints (called automatically by the system on solve)."""
        self._init_losses()
        self._enforce_power_balance()

    def reset_registrations(self) -> None:
        """Clear registered unit powers/losses (used for rebuild-on-solve)."""
        self._positive_powers.clear()
        self._negative_powers.clear()
        self._undefined_powers.clear()
        self._losses.clear()

    def _init_losses(self) -> None:
        for loss in self._losses:
            if hasattr(loss, "build_constraints"):
                loss.build_constraints()
            elif hasattr(loss, "construct_model"):
                # Legacy naming used in older code.
                loss.construct_model()

    def _enforce_power_balance(self) -> None:
        if not len(self.units()):
            return

        powers = [p for _, p in self.unit_power_pairs()]
        for p in powers:
            if p is None:
                continue
            mod = type(p).__module__
            if isinstance(p, xr.DataArray):
                continue
            if "linopy" in mod:
                continue
            raise TypeError(
                f"Network {self.name} received unsupported power type {type(p).__name__}. "
                "Register Linopy or xarray expressions only."
            )

        # Sum DataArrays first (xarray), then convert once to LinearExpression.
        # Sum Linopy expressions directly. Reduces LinearExpression.from_constant calls.
        from linopy import LinearExpression

        const_terms: list[xr.DataArray] = []
        linopy_terms: list[Any] = []
        for p in powers:
            if isinstance(p, xr.DataArray):
                const_terms.append(p)
            else:
                linopy_terms.append(p)

        expr: Any = None
        if const_terms:
            const_sum = const_terms[0]
            for c in const_terms[1:]:
                const_sum = const_sum + c
            expr = LinearExpression.from_constant(self.system.backend_model, const_sum)
        for lp in linopy_terms:
            expr = lp if expr is None else (expr + lp)

        if expr is None:
            return

        # Ensure we create a vectorized constraint where possible.
        # If `expr` is scalar, this becomes a scalar equality constraint.
        self.system.add_constraints(f"{self.name}__power_balance", expr == 0)

    # -----------------------------
    # Introspection helpers
    # -----------------------------
    @property
    def _producers(self):
        return self._positive_powers

    @property
    def _consumers(self):
        return self._negative_powers

    @property
    def _prosumers(self):
        return self._undefined_powers

    def units(self) -> tuple[BaseUnit, ...]:
        return tuple(
            unit_power_pair[0]
            for unit_power_pair in itertools.chain(self._undefined_powers, self._positive_powers, self._negative_powers)
        )

    def powers(self, unit: BaseUnit) -> tuple[Any, ...]:
        if unit not in self.units():
            raise ValueError(f"Unit {unit.name} is not registered in network {self.name}.")
        powers: list[Any] = []
        for bucket in (self._undefined_powers, self._positive_powers, self._negative_powers):
            for unit_, power in bucket:
                if unit_ == unit:
                    powers.append(power)
        return tuple(powers)

    def unit_power_pairs(self) -> list[tuple[BaseUnit, Any]]:
        """Return (unit, power) pairs for all registered units."""
        return list(itertools.chain(self._undefined_powers, self._positive_powers, self._negative_powers))

    def display(self) -> None:
        def _rows(bucket: list[tuple[BaseUnit, Any]]) -> list[list[str]]:
            rows: list[list[str]] = []
            for unit, power in bucket:
                label = getattr(power, "name", None) or getattr(power, "local_name", None) or type(power).__name__
                rows.append([unit.name, str(label)])
            return rows

        logger.info("Producers")
        logger.info("\n%s", tabulate.tabulate(_rows(self._producers), headers=["Name", "Power"]))
        logger.info("\nConsumers")
        logger.info("\n%s", tabulate.tabulate(_rows(self._consumers), headers=["Name", "Power"]))
        if self._prosumers:
            logger.info("\nProsumers")
            logger.info("\n%s", tabulate.tabulate(_rows(self._prosumers), headers=["Name", "Power"]))


class _Thermal(_BaseNetwork, ABC):
    pass


class _ThermalFluid(_Thermal, ABC):
    """Thermal fluid network parameters exposed as xarray DataArrays."""

    _param_names: ClassVar[list[str]] = ["T_hot", "T_cold"]
    _optional_params: ClassVar[dict[str, float]] = {"rho": 997.0, "cp": 4.19}

    @property
    def T_hot(self) -> xr.DataArray:  # noqa: N802
        return self.param(self.data.get("T_hot", 0.0), name="T_hot")

    @property
    def T_cold(self) -> xr.DataArray:  # noqa: N802
        return self.param(self.data.get("T_cold", 0.0), name="T_cold")

    @property
    def rho(self) -> float:
        return float(self.data.get("rho", 997.0))

    @property
    def cp(self) -> float:
        return float(self.data.get("cp", 4.19))


class HeatingFluid(_ThermalFluid):
    """Heating network: flow = hot supply, return = cold."""

    @property
    def t_flow(self) -> xr.DataArray:
        """Flow (supply) temperature. Alias for T_hot."""
        return self.T_hot

    @property
    def t_return(self) -> xr.DataArray:
        """Return temperature. Alias for T_cold."""
        return self.T_cold


class CoolingFluid(_ThermalFluid):
    """Cooling network: flow = cold supply, return = hot."""

    @property
    def t_flow(self) -> xr.DataArray:
        """Flow (supply) temperature. Alias for T_cold."""
        return self.T_cold

    @property
    def t_return(self) -> xr.DataArray:
        """Return temperature. Alias for T_hot."""
        return self.T_hot


class Fuel(_BaseNetwork, ABC):
    pass


class Gas(Fuel):
    pass


class Hydrogen(Fuel):
    pass


class Electrical(_BaseNetwork):
    pass


class AlternatingCurrent(Electrical):
    pass


class DirectCurrent(Electrical):
    pass


class Water(_BaseNetwork):
    pass
