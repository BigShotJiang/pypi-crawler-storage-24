from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

import xarray as xr

VarHandle = Any
ExprHandle = Any


@dataclass(frozen=True, slots=True)
class SolveInfo:
    """Backend-agnostic solver metadata.

    Notes on fields:
    - `status`: backend-agnostic coarse status, e.g. "ok" / "infeasible" / "unbounded" / "error".
    - `termination_condition`: best-effort backend/native termination condition string.
    - `objective_value`: best-effort objective value, if available.
    - `effective_options`: normalized + solver-native options actually applied/passed to the solver.
    """

    status: str
    solver: str
    runtime_s: float
    termination_condition: str | None = None
    objective_value: float | None = None
    effective_options: dict[str, Any] = field(default_factory=dict)


# When the system was built in batch mode (n_scenarios > 1), the backend may add an auxiliary
# variable with this name (dims: scenario) so that per-scenario objective values are readable
# from ResultsBundle.vars after solve.
OBJ_PER_SCENARIO_VAR = "__obj_per_scenario"


@dataclass(frozen=True, slots=True)
class ResultsBundle:
    """Stable results schema returned by `export_results()`.

    When the system was built in vectorized batch mode (n_scenarios > 1), vars may contain
    OBJ_PER_SCENARIO_VAR with dim (scenario,) giving the per-scenario objective values.
    """

    solve_info: SolveInfo
    vars: xr.Dataset
    derived: xr.Dataset


@runtime_checkable
class BackendProtocol(Protocol):
    """Minimal backend interface. See cross-repo.md (eta-incerto) Contract section."""

    def add_variable(
        self,
        name: str,
        dims: tuple[str, ...],
        coords: dict[str, Any],
        *,
        lower: Any = None,
        upper: Any = None,
        binary: bool = False,
        integer: bool = False,
    ) -> VarHandle: ...

    def get_var(self, name: str) -> VarHandle: ...

    def add_variables_batch(self, specs: Iterable[dict[str, Any]]) -> list[VarHandle]: ...

    def add_constraints(self, name: str, expr: Any) -> None: ...

    def add_constraints_batch(self, items: Iterable[tuple[str, Any]]) -> None: ...

    def set_objective(self, expr: Any, *, sense: str = "min") -> None: ...

    def solve(self, *, solver: str, options: dict[str, Any] | None = None, tee: bool = False) -> SolveInfo: ...

    def as_lp(self, path: str | Path, *, explicit_coordinate_names: bool | None = None) -> None: ...

    def get_constraint(self, name: str) -> dict[str, Any]: ...

    def export_results(self, *, solve_info: SolveInfo) -> ResultsBundle: ...


def sanitize_identifier(value: str) -> str:
    """Sanitize a string to a conservative solver/LP-safe identifier.

    Rules (see cross-repo.md Contract section):
    - Replace any character not in [A-Za-z0-9_] with '_'
    - Collapse multiple '_' into one
    - Ensure it does not start with a digit (prefix '_' if needed)
    """

    out = []
    last_underscore = False
    for ch in value:
        is_ok = ("a" <= ch <= "z") or ("A" <= ch <= "Z") or ("0" <= ch <= "9") or (ch == "_")
        ch_out = ch if is_ok else "_"
        if ch_out == "_":
            if last_underscore:
                continue
            last_underscore = True
        else:
            last_underscore = False
        out.append(ch_out)

    s = "".join(out).strip("_") or "_"
    if s[0].isdigit():
        s = f"_{s}"
    return s


def canonical_var_name(component: str, local: str, dims: tuple[str, ...]) -> str:
    """Canonical variable naming scheme: '{component}__{local}__{dims}'."""

    component_s = sanitize_identifier(component)
    local_s = sanitize_identifier(local)
    dims_s = "_".join(dims) if dims else "scalar"
    return f"{component_s}__{local_s}__{dims_s}"
