from __future__ import annotations

import logging
import time
import warnings
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import xarray as xr
from linopy import Model
from linopy.solver_capabilities import SolverFeature, solver_supports

from eta_components.milp_component_library.backends.protocol import ResultsBundle, SolveInfo

logger = logging.getLogger(__name__)


class LinopyBackend:
    """Linopy backend (Phase 0: minimal, protocol-conform)."""

    def __init__(self, *, explicit_coordinate_names: bool = True):
        self.model: Model = Model()
        self._vars: dict[str, Any] = {}
        self._constraints: dict[str, Any] = {}
        self._objective: Any | None = None
        self._explicit_coordinate_names: bool = explicit_coordinate_names

    def add_variable(
        self,
        name: str,
        dims: tuple[str, ...],
        coords: dict[str, Any],
        *,
        lower: Any = None,
        upper: Any = None,
        binary: bool = False,
        integer: bool = False,
    ):
        coord_list = [pd.Index(list(coords[dim]), name=dim) for dim in dims]
        if lower is None:
            lower = float("-inf")
        if upper is None:
            upper = float("inf")

        var = self.model.add_variables(
            lower=lower,
            upper=upper,
            coords=coord_list if coord_list else None,
            name=name,
            binary=binary,
            integer=integer,
        )
        self._vars[name] = var
        return var

    def get_var(self, name: str):
        return self._vars[name]

    def add_variables_batch(self, specs: Iterable[dict[str, Any]]) -> list[Any]:
        """Add multiple variables in a loop. specs: dicts with name, dims, coords, lower, upper, binary, integer."""
        result: list[Any] = []
        for s in specs:
            name = s["name"]
            dims = s["dims"]
            coords = s["coords"]
            lower = s.get("lower")
            upper = s.get("upper")
            binary = s.get("binary", False)
            integer = s.get("integer", False)
            var = self.add_variable(
                name,
                dims=dims,
                coords=coords,
                lower=lower,
                upper=upper,
                binary=binary,
                integer=integer,
            )
            result.append(var)
        return result

    def add_constraints(self, name: str, expr: Any) -> None:
        labels = self.model.add_constraints(expr, name=name)
        self._constraints[name] = labels

    def add_constraints_batch(self, items: Iterable[tuple[str, Any]]) -> None:
        """Add multiple constraints in a tight loop. items = (name, expr) with expr like lhs <= rhs."""
        for name, expr in items:
            labels = self.model.add_constraints(expr, name=name)
            self._constraints[name] = labels

    def set_objective(self, expr: Any, *, sense: str = "min") -> None:
        sense_norm = sense.lower()
        if sense_norm in {"min", "minimize"}:
            lin_sense = "min"
        elif sense_norm in {"max", "maximize"}:
            lin_sense = "max"
        else:
            raise ValueError(f"Unknown sense '{sense}'. Expected 'min' or 'max'.")
        if isinstance(expr, (int, float, xr.DataArray)):
            from linopy import LinearExpression

            expr = LinearExpression.from_constant(self.model, expr)
        # Linopy/HiGHS path does not support a nonzero constant in objective; absorb it via a fixed variable.
        if hasattr(expr, "const"):
            try:
                const = float(expr.const)
            except Exception:
                const = 0.0
            import math

            if const not in (0.0, -0.0) and not math.isnan(const):
                expr = expr.reset_const()
                one_name = "__eta_obj_const_one"
                if one_name in self.model.variables:
                    one = self.model.variables[one_name]
                else:
                    one = self.model.add_variables(lower=1, upper=1, name=one_name)
                expr = expr + const * one
        self._objective = self.model.add_objective(expr, overwrite=True, sense=lin_sense)

    @staticmethod
    def _prepare_solver_options(solver: str, options: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
        normalized: dict[str, Any] = {}
        for key, cast in (("time_limit_s", float), ("mip_gap", float), ("threads", int)):
            if key in options:
                normalized[key] = cast(options.pop(key))

        solver_native = options.pop("solver_options", {}) or {}
        if not isinstance(solver_native, dict):
            raise TypeError("options['solver_options'] must be a dict if provided.")

        if options:
            warnings.warn(
                "Passing solver-native options at the top level of `options` is deprecated. "
                "Put them under options['solver_options'] to make intent explicit.",
                DeprecationWarning,
                stacklevel=2,
            )
            solver_native = {**solver_native, **options}

        mapped: dict[str, Any] = {}
        solver_lc = str(solver).lower()
        # CPLEX uses nested params: mip.tolerances.mipgap, timelimit, threads (linopy iterates key.split("."))
        _cplex_param_paths: dict[str, str] = {
            "mipgap": "mip.tolerances.mipgap",
            "timelimit": "timelimit",
            "threads": "threads",
        }
        if normalized and solver_lc == "cplex":
            mapped = {
                **({"timelimit": normalized["time_limit_s"]} if "time_limit_s" in normalized else {}),
                **({"mipgap": normalized["mip_gap"]} if "mip_gap" in normalized else {}),
                **({"threads": normalized["threads"]} if "threads" in normalized else {}),
            }
        elif normalized and solver_lc == "highs":
            # HiGHS expects `time_limit` (seconds).
            mapped = {
                **({"time_limit": normalized["time_limit_s"]} if "time_limit_s" in normalized else {}),
            }
        elif normalized:
            mapped = dict(normalized)

        effective: dict[str, Any] = {**mapped, **solver_native}
        if solver_lc == "cplex":
            # Linopy CPLEX solver expects dotted param paths (e.g. mip.tolerances.mipgap)
            translated: dict[str, Any] = {}
            for k, v in effective.items():
                translated[_cplex_param_paths.get(k, k)] = v
            effective = translated
        return normalized, effective

    def solve(self, *, solver: str, options: dict[str, Any] | None = None, tee: bool = False) -> SolveInfo:
        opts = dict(options or {})  # do not mutate caller dict
        explicit = opts.pop("explicit_coordinate_names", self._explicit_coordinate_names)
        use_solver_api = opts.pop("use_solver_api", False)
        normalized, effective_solver_options = self._prepare_solver_options(solver, opts)

        solver_lc = str(solver).lower()
        io_api = None
        if use_solver_api:
            if solver_supports(solver_lc, SolverFeature.DIRECT_API):
                io_api = "direct"
            else:
                logger.info(
                    "use_solver_api=True but solver %s does not support direct API; using file-based solve.",
                    solver,
                )

        t0 = time.perf_counter()
        solve_kw: dict[str, Any] = {
            "solver_name": solver,
            "explicit_coordinate_names": explicit,
            **effective_solver_options,
        }
        if io_api is not None:
            solve_kw["io_api"] = io_api
        status, term = self.model.solve(**solve_kw)
        runtime_s = time.perf_counter() - t0

        obj_val = None
        try:
            obj_val = float(self.model.objective.value)
        except Exception:
            obj_val = None

        return SolveInfo(
            status=str(status),
            termination_condition=str(term) if term is not None else None,
            solver=str(solver),
            runtime_s=float(runtime_s),
            objective_value=obj_val,
            effective_options={"normalized": normalized, "solver_native": effective_solver_options},
        )

    def as_lp(self, path: str | Path, *, explicit_coordinate_names: bool | None = None) -> None:
        expl = self._explicit_coordinate_names if explicit_coordinate_names is None else explicit_coordinate_names
        self.model.to_file(str(Path(path)), io_api="lp", explicit_coordinate_names=expl)

    def get_constraint(self, name: str) -> dict[str, Any]:
        con = self._constraints.get(name)
        if con is None:
            return {}
        return {"backend": "linopy", "name": name}

    def export_results(self, *, solve_info: SolveInfo) -> ResultsBundle:
        data_vars: dict[str, xr.DataArray] = {}
        for name, var in self._vars.items():
            try:
                da = var.solution
            except Exception:
                # Model not optimized (e.g. solver failed): use NaN-filled array with variable shape
                labels = getattr(var, "labels", None)
                if labels is not None and hasattr(labels, "shape") and labels.ndim > 0:
                    da = xr.DataArray(
                        np.full(labels.shape, np.nan),
                        dims=labels.dims,
                        coords=dict(labels.coords),
                    )
                else:
                    dims = getattr(var, "dims", ())
                    coords = getattr(var, "coords", None)
                    if coords is not None and dims:
                        da = xr.DataArray(np.nan, dims=dims, coords=coords)
                    else:
                        da = xr.DataArray(np.nan, dims=dims if dims else ())
            # Ensure float dtype stability.
            data_vars[name] = da.astype(float)

        vars_ds = xr.Dataset(data_vars=data_vars)
        derived_ds = xr.Dataset()
        return ResultsBundle(solve_info=solve_info, vars=vars_ds, derived=derived_ds)
