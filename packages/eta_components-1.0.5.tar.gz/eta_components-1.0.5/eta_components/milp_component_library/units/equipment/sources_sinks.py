from __future__ import annotations

import operator
import warnings
from abc import ABC
from typing import TYPE_CHECKING, Any, ClassVar

import xarray as xr
from pydantic.fields import ModelPrivateAttr, PydanticUndefined

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.base_unit import BaseStandaloneUnit

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, Electrical, HeatingFluid, _BaseNetwork
    from eta_components.milp_component_library.systems import _BaseSystem


class _BaseSourceSink(BaseStandaloneUnit, ABC):
    """Linopy-native fixed sources/sinks (parameterized power profiles)."""

    _sign_of_capacity = None

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, network: _BaseNetwork):
        self._net = network
        super().__init__(name, data, system)

    def _validate_capacity(self, capacity: Any) -> None:
        sign = getattr(type(self), "_sign_of_capacity", None)
        if isinstance(sign, ModelPrivateAttr):
            sign = sign.get_default()
        if sign in (None, PydanticUndefined):
            return

        if isinstance(capacity, (int, float)):
            values = [float(capacity)]
        elif isinstance(capacity, dict):
            values = [float(v) for v in capacity.values()]
        elif isinstance(capacity, xr.DataArray):
            values = [float(v) for v in capacity.values.reshape(-1)]
        else:
            return

        if not all(sign(val, 0) for val in values):
            warnings.warn(
                f"Not all values for {self.name} satisfy {getattr(sign, '__name__', str(sign))}(value, 0). "
                "Positive means feeding into the network, negative means pulling from the network.",
                stacklevel=2,
            )

    # Objective contribution defaults
    @property
    def time_step_cost(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__time_step_cost")

    @property
    def annual_cost(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        return xr.DataArray(0.0, coords={"year": years}, dims=("year",), name=f"{self.name}__annual_cost")

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__emissions")


class _BaseSource(_BaseSourceSink, ABC):
    @property
    def _p_out(self) -> xr.DataArray:
        raise NotImplementedError


class _SimpleSource(_BaseSource, ABC):
    _sign_of_capacity = operator.ge
    _param_names: ClassVar[list[str]] = ["P_out"]

    def build(self) -> None:
        self._validate_capacity(self.data.get("P_out"))
        p_out = self.param(self.data.get("P_out", 0.0), name=f"{self.name}__P_out")
        self.exprs["p_out"] = p_out
        self._net.register_unit(self, p_out, PowerSign.POSITIVE)

    def unregister(self) -> None:
        self._net.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def _p_out(self) -> xr.DataArray:
        return self.exprs["p_out"]


class SimpleElectricitySource(_SimpleSource):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, electrical_network: Electrical):
        super().__init__(name, data, system, network=electrical_network)

    @property
    def p_el_out(self) -> xr.DataArray:
        return self._p_out


class SimpleThermalSource(_SimpleSource):
    pass


class SimpleHeatingSource(SimpleThermalSource):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, heating_network: HeatingFluid):
        super().__init__(name, data, system, network=heating_network)

    @property
    def p_heat_out(self) -> xr.DataArray:
        return self._p_out


class SimpleCoolingSource(SimpleThermalSource):
    _sign_of_capacity = operator.le

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, cooling_network: CoolingFluid):
        super().__init__(name, data, system, network=cooling_network)

    def build(self) -> None:
        self._validate_capacity(self.data.get("P_out"))
        p_out = self.param(self.data.get("P_out", 0.0), name=f"{self.name}__P_out")
        self.exprs["p_out"] = p_out
        # Cooling "production" convention is often negative (pull heat out of network).
        self._net.register_unit(self, p_out, PowerSign.NEGATIVE)

    @property
    def p_cool_out(self) -> xr.DataArray:
        return self._p_out


class _BaseSink(_BaseSourceSink, ABC):
    _sign_of_capacity = operator.le

    @property
    def _p_in(self) -> xr.DataArray:
        raise NotImplementedError


class _SimpleSink(_BaseSink, ABC):
    _param_names: ClassVar[list[str]] = ["P_in"]

    def build(self) -> None:
        self._validate_capacity(self.data.get("P_in"))
        p_in = self.param(self.data.get("P_in", 0.0), name=f"{self.name}__P_in")
        self.exprs["p_in"] = p_in
        self._net.register_unit(self, p_in, PowerSign.NEGATIVE)

    def unregister(self) -> None:
        self._net.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def _p_in(self) -> xr.DataArray:
        return self.exprs["p_in"]


class SimpleElectricitySink(_SimpleSink):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, electrical_network: Electrical):
        super().__init__(name, data, system, network=electrical_network)

    @property
    def p_el_in(self) -> xr.DataArray:
        return self._p_in


class SimpleHeatingSink(_SimpleSink):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, heating_network: HeatingFluid):
        super().__init__(name, data, system, network=heating_network)

    @property
    def p_heat_in(self) -> xr.DataArray:
        return self._p_in


class SimpleCoolingSink(_SimpleSink):
    # Cooling convention in this library/tests:
    # - cooling *producers* are typically negative (remove heat; see `SimpleCoolingSource`)
    # - cooling *demands/sinks* are typically positive to balance the cooling network
    _sign_of_capacity = operator.ge

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, cooling_network: CoolingFluid):
        super().__init__(name, data, system, network=cooling_network)

    @property
    def p_cool_in(self) -> xr.DataArray:
        return self._p_in


class _VariableSource(_BaseSource, ABC):
    """Linopy-native variable source (decision variable power profile)."""

    _sign_of_capacity = operator.ge
    _optional_params: ClassVar[dict[str, Any]] = {"P_out_lb": 0.0, "P_out_ub": None}

    def build(self) -> None:
        idx = self.system.index
        dims = ("year", "period", "time")
        coords = {d: idx.coords[d].values for d in dims}

        lb_raw = self.data.get("P_out_lb", None)
        if lb_raw is None:
            lb_raw = self.data.get("P_out_min", 0.0)
        lb = float(lb_raw)

        ub = self.data.get("P_out_ub", None)
        if ub is None:
            ub = self.data.get("P_out_max", None)

        p_out = self.system.add_variable(
            f"{self.name}__P_out",
            dims=dims,
            coords=coords,
            lower=lb,
            upper=ub,
        )
        self.vars["p_out"] = p_out
        self.exprs["p_out"] = p_out
        self._net.register_unit(self, p_out, PowerSign.POSITIVE)

    def unregister(self) -> None:
        self._net.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def _p_out(self):
        return self.exprs["p_out"]


class _VariableSink(_BaseSink, ABC):
    """Linopy-native variable sink (decision variable power profile)."""

    _sign_of_capacity = operator.le
    _optional_params: ClassVar[dict[str, Any]] = {"P_in_lb": None, "P_in_ub": 0.0}

    def build(self) -> None:
        idx = self.system.index
        dims = ("year", "period", "time")
        coords = {d: idx.coords[d].values for d in dims}

        lb = self.data.get("P_in_lb", None)
        ub = self.data.get("P_in_ub", 0.0)

        p_in = self.system.add_variable(
            f"{self.name}__P_in",
            dims=dims,
            coords=coords,
            lower=lb,
            upper=ub,
        )
        self.vars["p_in"] = p_in
        self.exprs["p_in"] = p_in
        self._net.register_unit(self, p_in, PowerSign.NEGATIVE)

    def unregister(self) -> None:
        self._net.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def _p_in(self):
        return self.exprs["p_in"]


class VariableHeatingSource(_VariableSource):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        heating_network: HeatingFluid | None = None,
        network: _BaseNetwork | None = None,
    ):
        net = heating_network if heating_network is not None else network
        if net is None:
            raise TypeError("Missing required argument: heating_network (or alias network).")
        super().__init__(name, data, system, network=net)

    @property
    def p_heat_out(self):
        return self._p_out

    @property
    def p(self):
        """Legacy alias used in some tests/examples."""
        return self._p_out


class VariableHeatingSink(_VariableSink):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, heating_network: HeatingFluid):
        super().__init__(name, data, system, network=heating_network)

    @property
    def p_heat_in(self):
        return self._p_in


class VariableElectricalSink(_VariableSink):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, electrical_network: Electrical):
        super().__init__(name, data, system, network=electrical_network)

    @property
    def p_el_in(self):
        return self._p_in


class VariableCoolingSink(_BaseSink):
    """Cooling buffer sink: positive power into cooling network.

    This is used in legacy tests as a slack/buffer to close the cooling balance when no
    explicit cooling demand is present.
    """

    _sign_of_capacity = operator.ge
    _optional_params: ClassVar[dict[str, Any]] = {"P_in_lb": 0.0, "P_in_ub": None}

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, cooling_network: CoolingFluid):
        super().__init__(name, data, system, network=cooling_network)

    def build(self) -> None:
        idx = self.system.index
        dims = ("year", "period", "time")
        coords = {d: idx.coords[d].values for d in dims}

        lb = float(self.data.get("P_in_lb", 0.0))
        ub = self.data.get("P_in_ub", None)

        p_in = self.system.add_variable(
            f"{self.name}__P_in",
            dims=dims,
            coords=coords,
            lower=lb,
            upper=ub,
        )
        self.vars["p_in"] = p_in
        self.exprs["p_in"] = p_in
        # Cooling sink is positive by convention in many tests (balances negative cooling producers).
        self._net.register_unit(self, p_in, PowerSign.NEGATIVE)

    def unregister(self) -> None:
        self._net.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def _p_in(self):
        return self.exprs["p_in"]

    @property
    def p_cool_in(self):
        return self._p_in
