from __future__ import annotations

from abc import ABC
from typing import Any, ClassVar

import xarray as xr

from eta_components.milp_component_library.exceptions import InvalidPwlfValuesError
from eta_components.milp_component_library.units.equipment.base_equipment import BaseConverter


class BaseOperational(BaseConverter, ABC):
    """Linopy-only operational equipment base.

    This base provides:
    - on/off binary (`is_operating`) and part-load ratio (`plr`)
    - input fraction (`pfr`) coupled to `plr` via a piecewise-linear relation
      using a SOS2-like formulation (emulated via segment binaries for HiGHS).

    Concrete subclasses must implement `_build_operational()` to create their
    unit-specific power variables and constraints (boilers, CHP, chillers, etc.).
    """

    _optional_params: ClassVar[dict[str, Any]] = {**BaseConverter._optional_params}

    def build(self) -> None:
        is_operating, plr, pfr = self._add_operating_core()
        self.vars["is_operating"] = is_operating
        self.model.is_operating = is_operating

        self.model.plr = plr
        self.model.pfr = pfr

        # Unit-specific build.
        self._build_operational()

    # -----------------------------
    # Core operating/PWL helpers
    # -----------------------------
    def _time_dims_coords(self) -> tuple[tuple[str, ...], dict[str, Any]]:
        """Operational time dims/coords (include scenario when system is in batch_mode)."""
        return self.system.get_operational_time_dims_coords()

    @staticmethod
    def _validate_pfr_plr_bpts(bpts: Any) -> tuple[tuple[float, float], ...]:
        if bpts is None:
            return ((0.0, 0.0), (1.0, 1.0))
        try:
            pts = tuple((float(pfr), float(plr)) for pfr, plr in bpts)
        except Exception as err:
            raise InvalidPwlfValuesError("pfr_plr_bpts must be an iterable of (pfr, plr) pairs.") from err

        if len(pts) < 2:
            raise InvalidPwlfValuesError("pfr_plr_bpts must contain at least two breakpoints.")

        for pfr, plr in pts:
            if not (0.0 <= pfr <= 1.0) or not (0.0 <= plr <= 1.0):
                raise InvalidPwlfValuesError("pfr_plr_bpts values must be within [0, 1].")

        plrs = [plr for _, plr in pts]
        pfrs = [pfr for pfr, _ in pts]
        if any(plrs[i] >= plrs[i + 1] for i in range(len(plrs) - 1)):
            raise InvalidPwlfValuesError("pfr_plr_bpts must be strictly increasing in plr.")
        if any(pfrs[i] > pfrs[i + 1] for i in range(len(pfrs) - 1)):
            raise InvalidPwlfValuesError("pfr_plr_bpts must be nondecreasing in pfr.")
        # Require the curve to reach full load.
        pfr_last, plr_last = pts[-1]
        if abs(pfr_last - 1.0) > 1e-12 or abs(plr_last - 1.0) > 1e-12:
            raise InvalidPwlfValuesError("pfr_plr_bpts must end at (1, 1).")

        return pts

    def _add_operating_core(self):
        dims, coords = self._time_dims_coords()

        is_operating = self.system.add_variable(
            f"{self.name}__is_operating",
            dims=dims,
            coords=coords,
            binary=True,
        )
        # Part-load ratio in [0, 1].
        plr = self.system.add_variable(
            f"{self.name}__plr",
            dims=dims,
            coords=coords,
            lower=0,
            upper=1,
        )
        pfr = self.system.add_variable(
            f"{self.name}__pfr",
            dims=dims,
            coords=coords,
            lower=0,
            upper=1,
        )

        plr_min = float(self.data.get("plr_min", 0.0))
        bpts = self._validate_pfr_plr_bpts(self.data.get("pfr_plr_bpts"))
        if plr_min == 0.0 and bpts and bpts[0][1] > 0.0:
            plr_min = float(bpts[0][1])

        self.system.add_constraints_batch(
            [
                (f"{self.name}__plr_ub", plr <= is_operating),
                (f"{self.name}__plr_lb", plr >= plr_min * is_operating),
                (f"{self.name}__pfr_ub", pfr <= is_operating),
            ]
        )
        self._couple_pfr_plr(pfr=pfr, plr=plr, is_operating=is_operating, bpts=bpts)
        return is_operating, plr, pfr

    def _couple_pfr_plr(
        self,
        *,
        pfr: Any,
        plr: Any,
        is_operating: Any,
        bpts: tuple[tuple[float, float], ...],
    ) -> None:
        # If relation is identity, avoid PWL machinery.
        if all(abs(pfr_i - plr_i) < 1e-12 for pfr_i, plr_i in bpts):
            self.system.add_constraints_batch([(f"{self.name}__pfr_eq_plr", pfr == plr)])
            return

        method = str(self.data.get("pwl_method", "binary")).lower()

        # Optionally use native SOS2 if available.
        if method == "sos2":
            try:
                backend_model = self.system.backend_model
                if backend_model is None or not hasattr(backend_model, "add_sos_constraints"):
                    raise AttributeError

                n = len(bpts)
                dims, coords = self._time_dims_coords()
                bp_dim = "bp"
                coords_lambda = {**coords, bp_dim: list(range(n))}

                lam = self.system.add_variable(
                    f"{self.name}__pwl_lambda",
                    dims=(*dims, bp_dim),
                    coords=coords_lambda,
                    lower=0,
                )
                plr_pts = xr.DataArray([plr_i for _, plr_i in bpts], coords={bp_dim: list(range(n))}, dims=(bp_dim,))
                pfr_pts = xr.DataArray([pfr_i for pfr_i, _ in bpts], coords={bp_dim: list(range(n))}, dims=(bp_dim,))

                self.system.add_constraints_batch(
                    [
                        (f"{self.name}__pwl_lambda_sum", lam.sum(dim=bp_dim) == is_operating),
                        (f"{self.name}__pwl_plr", plr == (lam * plr_pts).sum(dim=bp_dim)),
                        (f"{self.name}__pwl_pfr", pfr == (lam * pfr_pts).sum(dim=bp_dim)),
                    ]
                )
                backend_model.add_sos_constraints(lam, sos_type=2, sos_dim=bp_dim)
                return
            except Exception:
                # Fall back to binary segment formulation below.
                pass

        # Binary-segment emulation of SOS2 (HiGHS-compatible).
        n = len(bpts)
        segs = list(range(n - 1))
        dims, coords = self._time_dims_coords()

        bp_dim = "bp"
        seg_dim = "seg"
        coords_lambda = {**coords, bp_dim: list(range(n))}
        coords_seg = {**coords, seg_dim: segs}

        lam = self.system.add_variable(
            f"{self.name}__pwl_lambda",
            dims=(*dims, bp_dim),
            coords=coords_lambda,
            lower=0,
        )
        z = self.system.add_variable(
            f"{self.name}__pwl_seg",
            dims=(*dims, seg_dim),
            coords=coords_seg,
            binary=True,
        )

        plr_pts = xr.DataArray([plr_i for _, plr_i in bpts], coords={bp_dim: list(range(n))}, dims=(bp_dim,))
        pfr_pts = xr.DataArray([pfr_i for pfr_i, _ in bpts], coords={bp_dim: list(range(n))}, dims=(bp_dim,))

        pwl_constraints: list[tuple[str, Any]] = [
            (f"{self.name}__pwl_seg_sum", z.sum(dim=seg_dim) == is_operating),
            (f"{self.name}__pwl_lambda_sum", lam.sum(dim=bp_dim) == is_operating),
            (f"{self.name}__pwl_adj_0", lam.sel({bp_dim: 0}) <= z.sel({seg_dim: 0})),
            (f"{self.name}__pwl_adj_last", lam.sel({bp_dim: n - 1}) <= z.sel({seg_dim: n - 2})),
            (f"{self.name}__pwl_plr", plr == (lam * plr_pts).sum(dim=bp_dim)),
            (f"{self.name}__pwl_pfr", pfr == (lam * pfr_pts).sum(dim=bp_dim)),
        ]
        for i in range(1, n - 1):
            pwl_constraints.append(
                (f"{self.name}__pwl_adj_{i}", lam.sel({bp_dim: i}) <= z.sel({seg_dim: i - 1}) + z.sel({seg_dim: i}))
            )
        self.system.add_constraints_batch(pwl_constraints)

    # -----------------------------
    # Abstract hook for subclasses
    # -----------------------------
    def _build_operational(self) -> None:
        raise NotImplementedError(f"{type(self).__name__} has no Linopy build implementation yet.")

    def unregister(self) -> None:
        # Best-effort: detach from networks if subclasses registered.
        for maybe_net in ("_net", "_electrical_net", "_thermal_net", "_hot_network", "_cold_network"):
            net = getattr(self, maybe_net, None)
            if net is not None and hasattr(net, "unregister_unit"):
                try:
                    net.unregister_unit(self)
                except Exception:
                    pass
        self.system.unregister_unit(self)

    @property
    def time_step_cost(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__time_step_cost")

    @property
    def annual_cost(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        return xr.DataArray(0.0, coords={"year": years}, dims=("year",), name=f"{self.name}__annual_cost")

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__emissions")
