from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, Electrical, Gas, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class Chp(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        fuel_network: Gas | None = None,
        gas_network: Gas | None = None,
        electrical_network: Electrical,
        exhaust_heat_network: HeatingFluid | None = None,
        heating_network: HeatingFluid | None = None,
        waste_heat_network: HeatingFluid | None = None,
        cooling_network: CoolingFluid | None = None,
    ):
        self._fuel_network = fuel_network if fuel_network is not None else gas_network
        if self._fuel_network is None:
            raise TypeError("Missing required argument: fuel_network (or alias gas_network).")
        self._electrical_net = electrical_network
        self._exhaust_net = exhaust_heat_network if exhaust_heat_network is not None else heating_network
        if self._exhaust_net is None:
            raise TypeError("Missing required argument: exhaust_heat_network (or alias heating_network).")
        self._waste_net = waste_heat_network if waste_heat_network is not None else self._exhaust_net
        self._cooling_net = cooling_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(coords["year"])

        p_el_out = self.system.add_variable(f"{self.name}__p_el_out", dims=dims, coords=coords, lower=0)
        p_heat_out = self.system.add_variable(f"{self.name}__p_heat_out", dims=dims, coords=coords, lower=0)
        p_waste_heat_out = self.system.add_variable(f"{self.name}__p_waste_heat_out", dims=dims, coords=coords, lower=0)
        p_gas_in = self.system.add_variable(f"{self.name}__p_gas_in", dims=dims, coords=coords, upper=0)

        self.vars["p_el_out"] = p_el_out
        self.vars["p_heat_out"] = p_heat_out
        self.vars["p_waste_heat_out"] = p_waste_heat_out
        self.vars["p_gas_in"] = p_gas_in

        self._electrical_net.register_unit(self, p_el_out, PowerSign.POSITIVE)
        self._exhaust_net.register_unit(self, p_heat_out, PowerSign.POSITIVE)
        if self._waste_net is not None:
            self._waste_net.register_unit(self, p_waste_heat_out, PowerSign.POSITIVE)
        self._fuel_network.register_unit(self, p_gas_in, PowerSign.NEGATIVE)

        # Fuel input based on nominal useful output + efficiency.
        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta_total = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta_total")
        eta_th_exh = float(self.data.get("eta_th_exhaust", 0.0))
        eta_th_motor = float(self.data.get("eta_th_motor", 0.0))
        motor_use = float(self.data.get("motor_heat_usability", 0.0))

        plr = self.model.plr
        pfr = self.model.pfr

        fuel_in = (p_nom * pfr) / eta_total
        self.system.add_constraints(f"{self.name}__fuel_in", p_gas_in == -fuel_in)

        motor_heat_total = eta_th_motor * fuel_in
        exhaust_heat = eta_th_exh * fuel_in
        self.system.add_constraints(f"{self.name}__exhaust_heat", p_heat_out == exhaust_heat)
        self.system.add_constraints(f"{self.name}__waste_heat", p_waste_heat_out == motor_use * motor_heat_total)

        # Electrical output is the remaining useful output after heat streams.
        self.system.add_constraints(
            f"{self.name}__el_out",
            p_el_out == p_nom * plr - exhaust_heat - motor_heat_total,
        )

        # Optional cooling consumption for unusable motor heat.
        if self._cooling_net is not None and eta_th_motor:
            p_cool_in = self.system.add_variable(f"{self.name}__p_cool_in", dims=dims, coords=coords, lower=0)
            self.vars["p_cool_in"] = p_cool_in
            self._cooling_net.register_unit(self, p_cool_in, PowerSign.POSITIVE)
            self.system.add_constraints(f"{self.name}__cool_in", p_cool_in == (1 - motor_use) * motor_heat_total)

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_el_out(self):
        return self.vars["p_el_out"]

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def p_waste_heat_out(self):
        return self.vars["p_waste_heat_out"]

    @property
    def p_fuel_in(self):
        """Legacy alias."""
        return self.vars["p_gas_in"]
