from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.base_unit import BaseStandaloneUnit
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import _ThermalFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class ParallelFlowHeatExchanger(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        hot_network: _ThermalFluid,
        cold_network: _ThermalFluid,
    ):
        self._hot_network = hot_network
        self._cold_network = cold_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        # Minimal: behave like a heat transfer with nominal cap based on LMTD for parallel flow.
        dims, coords = self._time_dims_coords()

        p_out = self.system.add_variable(f"{self.name}__p_out", dims=dims, coords=coords, lower=0)
        p_in = self.system.add_variable(f"{self.name}__p_in", dims=dims, coords=coords, upper=0)
        self.vars["p_out"] = p_out
        self.vars["p_in"] = p_in

        self._cold_network.register_unit(self, p_out, PowerSign.POSITIVE)
        self._hot_network.register_unit(self, p_in, PowerSign.NEGATIVE)
        self.system.add_constraints(f"{self.name}__balance", p_in == -p_out)

        area = float(self.data.get("area", 0.0))
        u = float(self.data.get("heat_transfer_coefficient", 0.0))
        # Parallel flow: deltaT1 = Th_in - Tc_in, deltaT2 = Th_out - Tc_out.
        dt1 = self._hot_network.T_hot - self._cold_network.T_cold
        dt2 = self._hot_network.T_cold - self._cold_network.T_hot
        lmtd = xr.where(abs(dt1 - dt2) < 1e-12, dt1, (dt1 - dt2) / xr.apply_ufunc(np.log, dt1 / dt2))
        p_nom = area * u * lmtd
        self.system.add_constraints(f"{self.name}__cap", p_out == p_nom * self.model.plr)

    @property
    def p_out(self):
        return self.vars["p_out"]

    @property
    def p_in(self):
        return self.vars["p_in"]


class CounterFlowHeatExchanger(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        hot_network: _ThermalFluid,
        cold_network: _ThermalFluid,
    ):
        self._hot_network = hot_network
        self._cold_network = cold_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_out = self.system.add_variable(f"{self.name}__p_out", dims=dims, coords=coords, lower=0)
        p_in = self.system.add_variable(f"{self.name}__p_in", dims=dims, coords=coords, upper=0)
        self.vars["p_out"] = p_out
        self.vars["p_in"] = p_in

        self._cold_network.register_unit(self, p_out, PowerSign.POSITIVE)
        self._hot_network.register_unit(self, p_in, PowerSign.NEGATIVE)
        self.system.add_constraints(f"{self.name}__balance", p_in == -p_out)

        area = float(self.data.get("area", 0.0))
        u = float(self.data.get("heat_transfer_coefficient", 0.0))
        # Counter flow: deltaT1 = Th_in - Tc_out, deltaT2 = Th_out - Tc_in.
        dt1 = self._hot_network.T_hot - self._cold_network.T_hot
        dt2 = self._hot_network.T_cold - self._cold_network.T_cold
        lmtd = xr.where(abs(dt1 - dt2) < 1e-12, dt1, (dt1 - dt2) / xr.apply_ufunc(np.log, dt1 / dt2))
        p_nom = area * u * lmtd

        self.system.add_constraints(f"{self.name}__cap", p_out == p_nom * self.model.plr)

    @property
    def p_out(self):
        return self.vars["p_out"]

    @property
    def p_in(self):
        return self.vars["p_in"]


class HeatTransfer(BaseStandaloneUnit):
    """Pure heat transfer between two thermal networks (no sizing)."""

    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        from_network: _ThermalFluid,
        to_network: _ThermalFluid,
    ):
        self._from = from_network
        self._to = to_network
        super().__init__(name, data, system)

    def build(self) -> None:
        dims, coords = self.system.get_operational_time_dims_coords()

        p_out = self.system.add_variable(f"{self.name}__p_out", dims=dims, coords=coords, lower=0)
        p_in = self.system.add_variable(f"{self.name}__p_in", dims=dims, coords=coords, upper=0)

        self.vars["p_out"] = p_out
        self.vars["p_in"] = p_in

        self._to.register_unit(self, p_out, PowerSign.POSITIVE)
        self._from.register_unit(self, p_in, PowerSign.NEGATIVE)
        self.system.add_constraints(f"{self.name}__balance", p_in == -p_out)

    def unregister(self) -> None:
        self._from.unregister_unit(self)
        self._to.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def p_out(self):
        return self.vars["p_out"]

    @property
    def p_in(self):
        return self.vars["p_in"]

    @property
    def time_step_cost(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__time_step_cost")

    @property
    def annual_cost(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        return xr.DataArray(0.0, coords={"year": years}, dims=("year",), name=f"{self.name}__annual_cost")

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__emissions")
