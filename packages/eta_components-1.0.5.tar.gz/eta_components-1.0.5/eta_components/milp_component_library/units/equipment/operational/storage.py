from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, DirectCurrent, Gas, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class Battery(BaseOperational):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, electrical_network: DirectCurrent):
        self._electrical_net = electrical_network
        super().__init__(name, data, system)


class HeatStorage(BaseOperational):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, heating_network: HeatingFluid):
        self._thermal_network = heating_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(coords["year"])
        times = list(coords["time"])
        periods = list(coords["period"])

        e_nom = float(self.data.get("E_nom", 0.0))
        cap = float(e_nom)
        eta = float(self.data.get("eta", 1.0))
        loss = float(self.data.get("loss", 0.0))
        c_in_max = float(self.data.get("c_in_max", 0.0))
        c_out_max = float(self.data.get("c_out_max", 0.0))

        e = self.system.add_variable(f"{self.name}__e", dims=dims, coords=coords, lower=0, upper=cap)
        p_in = self.system.add_variable(
            f"{self.name}__p_heat_in",
            dims=dims,
            coords=coords,
            lower=-cap * c_in_max,
            upper=0,
        )
        p_out = self.system.add_variable(
            f"{self.name}__p_heat_out",
            dims=dims,
            coords=coords,
            lower=0,
            upper=cap * c_out_max,
        )

        self.vars["e"] = e
        self.vars["p_heat_in"] = p_in
        self.vars["p_heat_out"] = p_out
        # Legacy alias used in tests.
        self.vars["_p_in"] = p_in
        self.vars["_p_out"] = p_out

        self._thermal_network.register_unit(self, p_in, PowerSign.NEGATIVE)
        self._thermal_network.register_unit(self, p_out, PowerSign.POSITIVE)

        # Initial energy is zero.
        self.system.add_constraints(f"{self.name}__e_init", e.sel(time=times[0]) == 0)

        # Dynamics (within time dim, per (year, period)).
        e_next = e.shift(time=-1)
        mask = xr.DataArray(
            [t != times[-1] for t in times],
            coords={"time": times},
            dims=("time",),
        )
        dyn = e_next - ((1 - loss) * e + eta * (-p_in) - (1 / eta) * p_out)
        dyn = dyn.where(mask, other=0)
        self.system.add_constraints(f"{self.name}__dyn", dyn == 0)

        # Terminal transition for last time step (prevents unconstrained last-step discharge/charge).
        if "scenario" in coords:
            e_end_dims = ("scenario", "year", "period")
            e_end_coords = {"scenario": list(coords["scenario"]), "year": years, "period": periods}
        else:
            e_end_dims = ("year", "period")
            e_end_coords = {"year": years, "period": periods}
        e_end = self.system.add_variable(
            f"{self.name}__e_end",
            dims=e_end_dims,
            coords=e_end_coords,
            lower=0,
            upper=cap,
        )
        self.vars["e_end"] = e_end
        t_last = times[-1]
        self.system.add_constraints(
            f"{self.name}__dyn_terminal",
            e_end
            == (1 - loss) * e.sel(time=t_last) + eta * (-p_in.sel(time=t_last)) - (1 / eta) * p_out.sel(time=t_last),
        )

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def e(self):
        return self.vars["e"]

    @property
    def p_heat_in(self):
        return self.vars["p_heat_in"]

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def _p_in(self):
        return self.vars["_p_in"]

    @property
    def _p_out(self):
        return self.vars["_p_out"]


class ColdStorage(BaseOperational):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, cooling_network: CoolingFluid):
        self._thermal_network = cooling_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(coords["year"])
        times = list(coords["time"])
        periods = list(coords["period"])

        e_nom = float(self.data.get("E_nom", 0.0))
        cap = abs(float(e_nom))
        eta = float(self.data.get("eta", 1.0))
        loss = float(self.data.get("loss", 0.0))
        c_in_max = float(self.data.get("c_in_max", 0.0))
        c_out_max = float(self.data.get("c_out_max", 0.0))

        # Cold storage energy is negative (between E_nom and 0).
        e = self.system.add_variable(f"{self.name}__e", dims=dims, coords=coords, lower=e_nom, upper=0)
        p_in = self.system.add_variable(
            f"{self.name}__p_cool_in",
            dims=dims,
            coords=coords,
            lower=0,
            upper=cap * c_in_max,
        )
        p_out = self.system.add_variable(
            f"{self.name}__p_cool_out",
            dims=dims,
            coords=coords,
            lower=-cap * c_out_max,
            upper=0,
        )

        self.vars["e"] = e
        self.vars["p_cool_in"] = p_in
        self.vars["p_cool_out"] = p_out

        self._thermal_network.register_unit(self, p_in, PowerSign.POSITIVE)
        self._thermal_network.register_unit(self, p_out, PowerSign.NEGATIVE)

        self.system.add_constraints(f"{self.name}__e_init", e.sel(time=times[0]) == 0)

        e_next = e.shift(time=-1)
        mask = xr.DataArray(
            [t != times[-1] for t in times],
            coords={"time": times},
            dims=("time",),
        )
        dyn = e_next - ((1 - loss) * e - eta * p_in + (1 / eta) * (-p_out))
        dyn = dyn.where(mask, other=0)
        self.system.add_constraints(f"{self.name}__dyn", dyn == 0)

        if "scenario" in coords:
            e_end_dims = ("scenario", "year", "period")
            e_end_coords = {"scenario": list(coords["scenario"]), "year": years, "period": periods}
        else:
            e_end_dims = ("year", "period")
            e_end_coords = {"year": years, "period": periods}
        e_end = self.system.add_variable(
            f"{self.name}__e_end",
            dims=e_end_dims,
            coords=e_end_coords,
            lower=e_nom,
            upper=0,
        )
        self.vars["e_end"] = e_end
        t_last = times[-1]
        self.system.add_constraints(
            f"{self.name}__dyn_terminal",
            e_end
            == (1 - loss) * e.sel(time=t_last) - eta * p_in.sel(time=t_last) + (1 / eta) * (-p_out.sel(time=t_last)),
        )

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def e(self):
        return self.vars["e"]

    @property
    def p_cool_in(self):
        return self.vars["p_cool_in"]

    @property
    def p_cool_out(self):
        return self.vars["p_cool_out"]


class HydrogenStorage(BaseOperational):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, hydrogen_network: Gas):
        self._fuel_network = hydrogen_network
        super().__init__(name, data, system)
