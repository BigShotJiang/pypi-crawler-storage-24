from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import Electrical, Gas, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class GasBoiler(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        gas_network: Gas,
        heating_network: HeatingFluid,
    ):
        self._fuel_network = gas_network
        self._thermal_network = heating_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_heat_out = self.system.add_variable(
            f"{self.name}__p_heat_out",
            dims=dims,
            coords=coords,
            lower=0,
        )
        self.vars["p_heat_out"] = p_heat_out
        self._thermal_network.register_unit(self, p_heat_out, kind=PowerSign.POSITIVE)

        # Fuel input is negative by convention.
        p_gas_in = self.system.add_variable(
            f"{self.name}__p_gas_in",
            dims=dims,
            coords=coords,
            upper=0,
        )
        self.vars["p_gas_in"] = p_gas_in
        self._fuel_network.register_unit(self, p_gas_in, kind=PowerSign.NEGATIVE)

        plr = self.model.plr
        pfr = self.model.pfr
        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")

        self.system.add_constraints(f"{self.name}__heat_out", p_heat_out == p_nom * plr)
        self.system.add_constraints(f"{self.name}__gas_in", p_gas_in == -(p_nom * pfr) / eta)

        maintenance = float(self.data.get("maintenance_cost", 0.0))
        years = list(coords["year"])
        self.exprs["annual_cost"] = xr.DataArray(
            [maintenance for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def p_gas_in(self):
        return self.vars["p_gas_in"]

    @property
    def annual_cost(self):
        return self.exprs.get("annual_cost", super().annual_cost)


class ElectrodeBoiler(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        heating_network: HeatingFluid,
    ):
        self._electrical_net = electrical_network
        self._thermal_network = heating_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_heat_out = self.system.add_variable(
            f"{self.name}__p_heat_out",
            dims=dims,
            coords=coords,
            lower=0,
        )
        self.vars["p_heat_out"] = p_heat_out
        self._thermal_network.register_unit(self, p_heat_out, kind=PowerSign.POSITIVE)

        p_el_in = self.system.add_variable(
            f"{self.name}__p_el_in",
            dims=dims,
            coords=coords,
            upper=0,
        )
        self.vars["p_el_in"] = p_el_in
        self._electrical_net.register_unit(self, p_el_in, kind=PowerSign.NEGATIVE)

        plr = self.model.plr
        pfr = self.model.pfr
        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")

        self.system.add_constraints(f"{self.name}__heat_out", p_heat_out == p_nom * plr)
        self.system.add_constraints(f"{self.name}__el_in", p_el_in == -(p_nom * pfr) / eta)

        maintenance = float(self.data.get("maintenance_cost", 0.0))
        years = list(coords["year"])
        self.exprs["annual_cost"] = xr.DataArray(
            [maintenance for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def annual_cost(self):
        return self.exprs.get("annual_cost", super().annual_cost)
