from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.environments import DryAir, HumidAir
    from eta_components.milp_component_library.networks import CoolingFluid, Electrical, Water
    from eta_components.milp_component_library.systems import _BaseSystem


class DryCooler(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        cooling_network: CoolingFluid,
        electrical_network: Electrical,
        ambient_environment: DryAir,
    ):
        self._cold_network = cooling_network
        self._electrical_net = electrical_network
        self._ambient = ambient_environment
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")

        p_cool_out = self.system.add_variable(f"{self.name}__p_cool_out", dims=dims, coords=coords, upper=0)
        p_el_in = self.system.add_variable(f"{self.name}__p_el_in", dims=dims, coords=coords, upper=0)
        self.vars["p_cool_out"] = p_cool_out
        self.vars["p_el_in"] = p_el_in

        self._cold_network.register_unit(self, p_cool_out, PowerSign.NEGATIVE)
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)

        plr = self.model.plr
        pfr = self.model.pfr
        self.system.add_constraints(f"{self.name}__cool_out", p_cool_out == -(p_nom * plr))
        self.system.add_constraints(f"{self.name}__el_in", p_el_in == -(p_nom * pfr) / eta)

        # Ambient feasibility: require T_db <= cooling network cold temperature.
        ok = (self._ambient.temp_db <= self._cold_network.T_cold).astype(float)
        self.system.add_constraints(f"{self.name}__ambient_ok", self.model.is_operating <= ok)

    @property
    def p_cool_out(self):
        return self.vars["p_cool_out"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]


class HybridCooler(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        cooling_network: CoolingFluid,
        electrical_network: Electrical,
        water_network: Water,
        ambient_environment: HumidAir,
    ):
        self._cold_network = cooling_network
        self._electrical_net = electrical_network
        self._water_net = water_network
        self._ambient = ambient_environment
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()
        idx = self.system.index

        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")
        spec_w = float(self.data.get("specific_water_consumption", 0.0))
        approach_min = float(self.data.get("approach_min", 0.0))

        p_cool_out = self.system.add_variable(f"{self.name}__p_cool_out", dims=dims, coords=coords, upper=0)
        p_el_in = self.system.add_variable(f"{self.name}__p_el_in", dims=dims, coords=coords, upper=0)
        water = self.system.add_variable(f"{self.name}__water_consumption", dims=dims, coords=coords, upper=0)

        self.vars["p_cool_out"] = p_cool_out
        self.vars["p_el_in"] = p_el_in
        self.vars["water_consumption"] = water

        self._cold_network.register_unit(self, p_cool_out, PowerSign.NEGATIVE)
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)
        self._water_net.register_unit(self, water, PowerSign.NEGATIVE)

        plr = self.model.plr
        pfr = self.model.pfr
        self.system.add_constraints(f"{self.name}__cool_out", p_cool_out == -(p_nom * plr))
        self.system.add_constraints(f"{self.name}__el_in", p_el_in == -(p_nom * pfr) / eta)
        self.system.add_constraints(f"{self.name}__water", water == -(spec_w * (-p_cool_out)))

        # Ambient feasibility based on wet-bulb + approach.
        ok = ((self._ambient.temp_wb + approach_min) <= self._cold_network.T_cold).astype(float)
        self.system.add_constraints(f"{self.name}__ambient_ok", self.model.is_operating <= ok)

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in idx.coords["year"].values],
            coords={"year": list(idx.coords["year"].values)},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_cool_out(self):
        return self.vars["p_cool_out"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]

    @property
    def water_consumption(self):
        return self.vars["water_consumption"]
