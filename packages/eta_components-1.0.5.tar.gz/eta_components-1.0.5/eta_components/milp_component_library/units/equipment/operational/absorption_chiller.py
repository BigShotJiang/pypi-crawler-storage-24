from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class AbsorptionChiller(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        heating_network: HeatingFluid,
        cooling_network: CoolingFluid,
    ):
        self._hot_network = heating_network
        self._cold_network = cooling_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_cool_out = self.system.add_variable(f"{self.name}__p_cool_out", dims=dims, coords=coords, upper=0)
        p_heat_in = self.system.add_variable(f"{self.name}__p_heat_in", dims=dims, coords=coords, upper=0)

        self.vars["p_cool_out"] = p_cool_out
        self.vars["p_heat_in"] = p_heat_in

        self._cold_network.register_unit(self, p_cool_out, PowerSign.NEGATIVE)
        self._hot_network.register_unit(self, p_heat_in, PowerSign.NEGATIVE)

        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")
        plr = self.model.plr
        pfr = self.model.pfr

        self.system.add_constraints(f"{self.name}__cool_out", p_cool_out == -(p_nom * plr))
        self.system.add_constraints(f"{self.name}__heat_in", p_heat_in == -(p_nom * pfr) / eta)

        years = list(coords["year"])
        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_cool_out(self):
        return self.vars["p_cool_out"]

    @property
    def p_heat_in(self):
        return self.vars["p_heat_in"]
