from __future__ import annotations

from typing import TYPE_CHECKING

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.environments import DryAir, SolarIrradiance
    from eta_components.milp_component_library.networks import Electrical, Gas, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class Photovoltaic(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        ambient_environment: DryAir,
        solar_irradiance: SolarIrradiance,
    ):
        self._electrical_net = electrical_network
        self._ambient = ambient_environment
        self._solar = solar_irradiance
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_nom = float(self.data.get("P_out_nom", 0.0))
        t_coef = float(self.data.get("T_coefficient", 0.0))
        t_st = float(self.data.get("T_module_st", 273.15 + 25))
        g_st = float(self.data.get("solar_irradiance_st", 1.0))

        g = self._solar.solar_irradiance
        t = self._ambient.temp_db

        profile = p_nom * (g / g_st) * (1 + t_coef * (t - t_st))

        p_el_out = self.system.add_variable(f"{self.name}__p_el_out", dims=dims, coords=coords, lower=0)
        self.vars["p_el_out"] = p_el_out
        self._electrical_net.register_unit(self, p_el_out, PowerSign.POSITIVE)
        self.system.add_constraints(f"{self.name}__profile", p_el_out == profile)

    @property
    def p_el_out(self):
        return self.vars["p_el_out"]


class Electrolyzer(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        hydrogen_network: Gas,
        waste_heat_network: HeatingFluid | None = None,
    ):
        self._electrical_net = electrical_network
        self._hydrogen_net = hydrogen_network
        self._waste_heat_net = waste_heat_network
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = float(self.data.get("eta", 1.0))
        eta_wh = float(self.data.get("eta_waste_heat", 0.0))

        p_h2_out = self.system.add_variable(f"{self.name}__p_hydrogen_out", dims=dims, coords=coords, lower=0)
        p_el_in = self.system.add_variable(f"{self.name}__p_el_in", dims=dims, coords=coords, upper=0)
        self.vars["p_hydrogen_out"] = p_h2_out
        self.vars["p_el_in"] = p_el_in

        self._hydrogen_net.register_unit(self, p_h2_out, PowerSign.POSITIVE)
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)

        plr = self.model.plr
        pfr = self.model.pfr
        self.system.add_constraints(f"{self.name}__h2_out", p_h2_out == p_nom * plr)
        self.system.add_constraints(f"{self.name}__el_in", p_el_in == -(p_nom * pfr) / eta)

        if self._waste_heat_net is not None and eta_wh:
            p_wh = self.system.add_variable(f"{self.name}__p_waste_heat_out", dims=dims, coords=coords, lower=0)
            self.vars["p_waste_heat_out"] = p_wh
            self._waste_heat_net.register_unit(self, p_wh, PowerSign.POSITIVE)
            # Waste heat from electrical losses.
            self.system.add_constraints(
                f"{self.name}__waste_heat",
                p_wh == eta_wh * ((-p_el_in) - p_h2_out),
            )

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]

    @property
    def p_hydrogen_out(self):
        return self.vars["p_hydrogen_out"]

    @property
    def p_waste_heat_out(self):
        return self.vars.get("p_waste_heat_out", 0)
