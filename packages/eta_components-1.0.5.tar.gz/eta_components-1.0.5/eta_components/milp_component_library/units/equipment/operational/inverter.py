from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import AlternatingCurrent, DirectCurrent
    from eta_components.milp_component_library.systems import _BaseSystem


class Inverter(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        alternating_current_network: AlternatingCurrent | None = None,
        direct_current_network: DirectCurrent | None = None,
        ac_network: AlternatingCurrent | None = None,
        dc_network: DirectCurrent | None = None,
    ):
        self._ac_network = alternating_current_network if alternating_current_network is not None else ac_network
        self._dc_network = direct_current_network if direct_current_network is not None else dc_network
        if self._ac_network is None or self._dc_network is None:
            raise TypeError("Missing required arguments: alternating_current_network and direct_current_network.")
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(coords["year"])

        p_out_nom = float(self.data.get("P_out_nom", 0.0))
        eta = float(self.data.get("eta", 1.0))

        p_dc_in = self.system.add_variable(
            f"{self.name}__p_dc_in", dims=dims, coords=coords, lower=-p_out_nom / eta, upper=0
        )
        p_dc_out = self.system.add_variable(
            f"{self.name}__p_dc_out", dims=dims, coords=coords, lower=0, upper=p_out_nom
        )
        p_ac_in = self.system.add_variable(
            f"{self.name}__p_ac_in", dims=dims, coords=coords, lower=-p_out_nom / eta, upper=0
        )
        p_ac_out = self.system.add_variable(
            f"{self.name}__p_ac_out", dims=dims, coords=coords, lower=0, upper=p_out_nom
        )

        self.vars["p_dc_in"] = p_dc_in
        self.vars["p_dc_out"] = p_dc_out
        self.vars["p_ac_in"] = p_ac_in
        self.vars["p_ac_out"] = p_ac_out

        self._dc_network.register_unit(self, p_dc_in, PowerSign.NEGATIVE)
        self._dc_network.register_unit(self, p_dc_out, PowerSign.POSITIVE)
        self._ac_network.register_unit(self, p_ac_in, PowerSign.NEGATIVE)
        self._ac_network.register_unit(self, p_ac_out, PowerSign.POSITIVE)

        # Conversion relations (one-way efficiencies).
        self.system.add_constraints(f"{self.name}__dc_to_ac", p_ac_out == -eta * p_dc_in)
        self.system.add_constraints(f"{self.name}__ac_to_dc", p_dc_out == -eta * p_ac_in)

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_dc_in(self):
        return self.vars["p_dc_in"]

    @property
    def p_dc_out(self):
        return self.vars["p_dc_out"]

    @property
    def p_ac_in(self):
        return self.vars["p_ac_in"]

    @property
    def p_ac_out(self):
        return self.vars["p_ac_out"]
