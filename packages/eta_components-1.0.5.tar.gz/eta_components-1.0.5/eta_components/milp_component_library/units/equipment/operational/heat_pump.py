from __future__ import annotations

from typing import TYPE_CHECKING, Any

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.operational.base_operational import BaseOperational

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, Electrical, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class WaterWaterHeatPump(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        heating_network: HeatingFluid,
        cooling_network: CoolingFluid | None = None,
        cold_network: CoolingFluid | None = None,
    ):
        self._electrical_net = electrical_network
        self._hot_network = heating_network
        self._cold_network = cooling_network if cooling_network is not None else cold_network
        if self._cold_network is None:
            raise TypeError("Missing required argument: cooling_network (or alias cold_network).")
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_heat_out = self.system.add_variable(f"{self.name}__p_heat_out", dims=dims, coords=coords, lower=0)
        p_el_in = self.system.add_variable(f"{self.name}__p_el_in", dims=dims, coords=coords, upper=0)
        p_cool_out = self.system.add_variable(f"{self.name}__p_cool_out", dims=dims, coords=coords, upper=0)

        self.vars["p_heat_out"] = p_heat_out
        self.vars["p_el_in"] = p_el_in
        self.vars["p_cool_out"] = p_cool_out

        self._hot_network.register_unit(self, p_heat_out, PowerSign.POSITIVE)
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)
        self._cold_network.register_unit(self, p_cool_out, PowerSign.NEGATIVE)

        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")

        plr = self.model.plr
        self.system.add_constraints(f"{self.name}__heat_out", p_heat_out == p_nom * plr)
        self.system.add_constraints(f"{self.name}__el_in", p_el_in == -(p_heat_out / eta))
        self.system.add_constraints(f"{self.name}__cool_out", p_cool_out == -(p_heat_out + p_el_in))

        years = list(coords["year"])
        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]

    @property
    def p_cool_out(self):
        return self.vars["p_cool_out"]


class AirWaterHeatPump(BaseOperational):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        heating_network: HeatingFluid,
        ambient_environment: Any | None = None,
    ):
        self._electrical_net = electrical_network
        self._hot_network = heating_network
        self._ambient = ambient_environment
        super().__init__(name, data, system)

    def _build_operational(self) -> None:
        dims, coords = self._time_dims_coords()

        p_heat_out = self.system.add_variable(f"{self.name}__p_heat_out", dims=dims, coords=coords, lower=0)
        p_el_in = self.system.add_variable(f"{self.name}__p_el_in", dims=dims, coords=coords, upper=0)
        self.vars["p_heat_out"] = p_heat_out
        self.vars["p_el_in"] = p_el_in

        self._hot_network.register_unit(self, p_heat_out, PowerSign.POSITIVE)
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)

        p_nom = float(self.data.get("P_out_nom", 0.0))
        eta = self.param(self.data.get("eta", 1.0), name=f"{self.name}__eta")

        plr = self.model.plr
        self.system.add_constraints(f"{self.name}__heat_out", p_heat_out == p_nom * plr)
        self.system.add_constraints(f"{self.name}__el_in", p_el_in == -(p_heat_out / eta))

        years = list(coords["year"])
        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]
