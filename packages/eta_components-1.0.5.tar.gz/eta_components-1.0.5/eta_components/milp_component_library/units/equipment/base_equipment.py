from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING, Any, ClassVar

from eta_components.milp_component_library.systems import _BaseSystem
from eta_components.milp_component_library.units.base_unit import BaseStandaloneUnit

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import _BaseNetwork


class BaseEquipment(BaseStandaloneUnit, ABC):
    """Base class for all equipment units (Linopy-only)."""


class BaseConverter(BaseEquipment, ABC):
    """Base class for converter-style equipment.

    Subclasses should expose backend handles (linopy/xarray expressions) via attributes or properties.
    """

    # Common optional params kept for compatibility with existing data dicts.
    _optional_params: ClassVar[dict[str, Any]] = {"plr_min": 0.0, "eta": 1.0}

    @property
    def is_operating(self) -> Any:
        return self.vars.get("is_operating")


class BaseStorage(BaseEquipment, ABC):
    """Base class for storage-style equipment."""

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, network: _BaseNetwork):
        self._net = network
        super().__init__(name, data, system)

    @property
    def p_in(self) -> Any:
        return self.vars.get("p_in")

    @property
    def p_out(self) -> Any:
        return self.vars.get("p_out")

    def unregister(self) -> None:
        # Network APIs will be Linopy-native after network rewrite.
        if hasattr(self._net, "unregister_unit"):
            self._net.unregister_unit(self)
        self.system.unregister_unit(self)


class BaseElectricalStorage(BaseStorage, ABC):
    pass


class BaseBattery(BaseElectricalStorage, ABC):
    pass


class BaseThermalStorage(BaseStorage, ABC):
    pass


class BaseFuelStorage(BaseStorage, ABC):
    pass


class BaseHeatStorage(BaseThermalStorage, ABC):
    pass


class BaseColdStorage(BaseThermalStorage, ABC):
    pass


class BaseHydrogenStorage(BaseFuelStorage, ABC):
    pass


class BaseHeatExchanger(BaseConverter, ABC):
    pass
