from __future__ import annotations

from abc import ABC
from typing import Any, ClassVar

import xarray as xr

from eta_components.milp_component_library.units.equipment.base_equipment import BaseConverter


class BaseDimensioning(BaseConverter, ABC):
    """Linopy-only dimensioning equipment base (stub)."""

    _has_investment_decision = True
    _optional_params: ClassVar[dict[str, Any]] = {**BaseConverter._optional_params}

    def _time_dims_coords(self) -> tuple[tuple[str, ...], dict[str, Any]]:
        """Operational time dims/coords (include scenario when system is in batch_mode)."""
        return self.system.get_operational_time_dims_coords()

    def _select_support_value(
        self,
        *,
        name: str,
        support: tuple[float, ...],
        i_b: float,
        k: float,
        cost_ref_scale: float = 1.0,
    ) -> tuple[Any, Any, Any]:
        """Piecewise-linear selection (with interpolation) over support points.

        Returns (is_bought, nominal_value, onetime_cost) with dims ('year',).

        When support is in W (power) or Wh (energy) and I_B is per kW or per kWh,
        pass cost_ref_scale=1000.0 so cost uses (v / 1000)^K.
        """

        design_coords = self.system.get_design_coords()
        years = list(design_coords["year"])
        year_dim = "year"
        s_dim = "support"
        seg_dim = "seg"
        s_idx = list(range(len(support)))
        seg_idx = list(range(len(support) - 1))

        is_bought = self.system.add_variable(
            f"{name}__is_bought",
            dims=(year_dim,),
            coords={year_dim: years},
            binary=True,
        )
        lam = self.system.add_variable(
            f"{name}__inv_lambda",
            dims=(year_dim, s_dim),
            coords={year_dim: years, s_dim: s_idx},
            lower=0,
        )
        z = self.system.add_variable(
            f"{name}__inv_seg",
            dims=(year_dim, seg_dim),
            coords={year_dim: years, seg_dim: seg_idx},
            binary=True,
        )

        inv_constraints: list[tuple[str, Any]] = [
            (f"{name}__inv_seg_sum", z.sum(dim=seg_dim) == is_bought),
            (f"{name}__inv_lam_sum", lam.sum(dim=s_dim) == is_bought),
            (f"{name}__inv_adj_0", lam.sel({s_dim: 0}) <= z.sel({seg_dim: 0})),
            (
                f"{name}__inv_adj_last",
                lam.sel({s_dim: len(support) - 1}) <= z.sel({seg_dim: len(support) - 2}),
            ),
        ]
        for i in range(1, len(support) - 1):
            inv_constraints.append(
                (f"{name}__inv_adj_{i}", lam.sel({s_dim: i}) <= z.sel({seg_dim: i - 1}) + z.sel({seg_dim: i}))
            )
        self.system.add_constraints_batch(inv_constraints)

        sup_da = xr.DataArray(list(support), coords={s_dim: s_idx}, dims=(s_dim,))
        if cost_ref_scale == 1.0:
            cost_da = xr.DataArray([i_b * (v**k) for v in support], coords={s_dim: s_idx}, dims=(s_dim,))
        else:
            cost_da = xr.DataArray(
                [i_b * ((v / cost_ref_scale) ** k) for v in support],
                coords={s_dim: s_idx},
                dims=(s_dim,),
            )

        nominal = (lam * sup_da).sum(dim=s_dim)
        cost = (lam * cost_da).sum(dim=s_dim)
        return is_bought, nominal, cost

    def build(self) -> None:
        raise NotImplementedError(f"{type(self).__name__} (dimensioning) has not been migrated to Linopy yet.")

    def unregister(self) -> None:
        for maybe_net in ("_net", "_electrical_net", "_thermal_net", "_hot_network", "_cold_network"):
            net = getattr(self, maybe_net, None)
            if net is not None and hasattr(net, "unregister_unit"):
                try:
                    net.unregister_unit(self)
                except Exception:
                    pass
        self.system.unregister_unit(self)

    @property
    def time_step_cost(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__time_step_cost")

    @property
    def annual_cost(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        return xr.DataArray(0.0, coords={"year": years}, dims=("year",), name=f"{self.name}__annual_cost")

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__emissions")
