from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.dimensioning.base_dimensioning import BaseDimensioning

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, Electrical, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class WaterWaterHeatPump(BaseDimensioning):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        heating_network: HeatingFluid,
        cooling_network: CoolingFluid | None = None,
        cold_network: CoolingFluid | None = None,
    ):
        self._electrical_net = electrical_network
        self._hot_network = heating_network
        self._cold_network = cooling_network if cooling_network is not None else cold_network
        if self._cold_network is None:
            raise TypeError("Missing required argument: cooling_network (or alias cold_network).")
        super().__init__(name, data, system)

    def build(self) -> None:
        self._declare_variables()
        self._declare_constraints()

    def _declare_variables(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(self.system.get_design_coords()["year"])
        support = tuple(float(v) for v in self.data.get("P_out_nom_support", (0.0,)))
        p_nom_max = float(max(support) if support else 0.0)

        p_heat_out = self.system.add_variable(f"{self.name}__p_heat_out", dims=dims, coords=coords, lower=0)
        p_el_in = self.system.add_variable(f"{self.name}__p_el_in", dims=dims, coords=coords, upper=0)
        p_cool_out = self.system.add_variable(f"{self.name}__p_cool_out", dims=dims, coords=coords, upper=0)

        self.vars["p_heat_out"] = p_heat_out
        self.vars["p_el_in"] = p_el_in
        self.vars["p_cool_out"] = p_cool_out

        self._hot_network.register_unit(self, p_heat_out, PowerSign.POSITIVE)
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)
        self._cold_network.register_unit(self, p_cool_out, PowerSign.NEGATIVE)

        is_bought, p_nom_expr, inv_cost_expr = self._select_support_value(
            name=self.name,
            support=support,
            i_b=float(self.data.get("I_B", 0.0)),
            k=float(self.data.get("K", 1.0)),
            cost_ref_scale=1000.0,
        )
        self.vars["is_bought"] = is_bought
        self._p_nom_expr = p_nom_expr
        self._inv_cost_expr = inv_cost_expr
        p_nom = self.system.add_variable(
            f"{self.name}__p_heat_out_nom",
            dims=("year",),
            coords={"year": years},
            lower=0,
            upper=p_nom_max,
        )
        self.vars["p_heat_out_nom"] = p_nom

        onetime_cost = self.system.add_variable(
            f"{self.name}__onetime_cost",
            dims=("year",),
            coords={"year": years},
            lower=0,
        )
        self.vars["onetime_cost"] = onetime_cost
        self.exprs["onetime_cost"] = onetime_cost
        self.system.add_objective_term(f"{self.name}__capex", onetime_cost, kind="capex", weight=1.0)

        is_operating = self.system.add_variable(f"{self.name}__is_operating", dims=dims, coords=coords, binary=True)
        self.vars["is_operating"] = is_operating
        self.model.is_operating = is_operating

        p_nom_on = self.system.add_variable(
            f"{self.name}__p_heat_out_nom_on",
            dims=dims,
            coords=coords,
            lower=0,
            upper=p_nom_max,
        )
        self.vars["p_heat_out_nom_on"] = p_nom_on

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    def _declare_constraints(self) -> None:
        dims, coords = self._time_dims_coords()
        plr_min = float(self.data.get("plr_min", 0.0))
        eta = self.param(self.data.get("eta", 1.0), dims=dims, coords=coords, name=f"{self.name}__eta")
        support = tuple(float(v) for v in self.data.get("P_out_nom_support", (0.0,)))
        p_nom_max = float(max(support) if support else 0.0)
        design_years = list(self.system.get_design_coords()["year"])
        first_year = design_years[0]

        p_heat_out = self.vars["p_heat_out"]
        p_el_in = self.vars["p_el_in"]
        p_cool_out = self.vars["p_cool_out"]
        is_bought = self.vars["is_bought"]
        p_nom = self.vars["p_heat_out_nom"]
        onetime_cost = self.vars["onetime_cost"]
        is_operating = self.vars["is_operating"]
        p_nom_on = self.vars["p_heat_out_nom_on"]
        p_nom_design = p_nom.sel(year=first_year)
        # Allow operation in all years if bought in first (investment) year; is_bought has year=design_years only.
        is_bought_first_year = is_bought.sel(year=first_year)

        self.system.add_constraints_batch(
            [
                (f"{self.name}__p_nom_def", p_nom == self._p_nom_expr),
                (f"{self.name}__onetime_cost_def", onetime_cost == self._inv_cost_expr),
                (f"{self.name}__operating_requires_invest", is_operating <= is_bought_first_year),
                (f"{self.name}__p_nom_on_ub1", p_nom_on <= p_nom_design),
                (f"{self.name}__p_nom_on_ub2", p_nom_on <= p_nom_max * is_operating),
                (f"{self.name}__p_nom_on_lb", p_nom_on >= p_nom_design - p_nom_max * (1 - is_operating)),
                (f"{self.name}__heat_out_ub", p_heat_out <= p_nom_on),
                (f"{self.name}__heat_out_lb", p_heat_out >= plr_min * p_nom_on),
                (f"{self.name}__el_in", p_el_in == -(p_heat_out / eta)),
                (f"{self.name}__cool_out", p_cool_out == -(p_heat_out + p_el_in)),
            ]
        )

    @property
    def p_heat_out(self):
        return self.vars["p_heat_out"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]

    @property
    def p_cool_out(self):
        return self.vars["p_cool_out"]

    @property
    def p_heat_out_nom(self):
        return self.vars["p_heat_out_nom"]

    @property
    def is_bought(self):
        return self.vars["is_bought"]

    @property
    def onetime_cost(self):
        return self.exprs.get("onetime_cost", 0.0)


class AirWaterHeatPump(BaseDimensioning):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        electrical_network: Electrical,
        heating_network: HeatingFluid,
    ):
        self._electrical_net = electrical_network
        self._hot_network = heating_network
        super().__init__(name, data, system)

    def build(self) -> None:
        raise NotImplementedError("AirWaterHeatPump dimensioning not migrated yet.")
