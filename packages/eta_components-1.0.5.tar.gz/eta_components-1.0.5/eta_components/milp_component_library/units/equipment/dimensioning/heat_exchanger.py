from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.dimensioning.base_dimensioning import BaseDimensioning

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import _ThermalFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class ParallelFlowHeatExchanger(BaseDimensioning):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        hot_network: _ThermalFluid,
        cold_network: _ThermalFluid,
    ):
        self._hot_network = hot_network
        self._cold_network = cold_network
        super().__init__(name, data, system)

    def build(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(self.system.get_design_coords()["year"])

        p_out = self.system.add_variable(f"{self.name}__p_out", dims=dims, coords=coords, lower=0)
        p_in = self.system.add_variable(f"{self.name}__p_in", dims=dims, coords=coords, upper=0)
        self.vars["p_out"] = p_out
        self.vars["p_in"] = p_in

        self._cold_network.register_unit(self, p_out, PowerSign.POSITIVE)
        self._hot_network.register_unit(self, p_in, PowerSign.NEGATIVE)
        self.system.add_constraints(f"{self.name}__balance", p_in == -p_out)

        support = tuple(float(v) for v in self.data.get("area_support", (0.0,)))
        i_b = float(self.data.get("I_B", 0.0))
        k = float(self.data.get("K", 1.0))
        is_bought, area_expr, inv_cost_expr = self._select_support_value(
            name=self.name,
            support=support,
            i_b=i_b,
            k=k,
        )
        self.vars["is_bought"] = is_bought
        area = self.system.add_variable(
            f"{self.name}__area",
            dims=("year",),
            coords={"year": years},
            lower=0,
            upper=float(max(support) if support else 0.0),
        )
        self.system.add_constraints(f"{self.name}__area_def", area == area_expr)
        self.vars["area"] = area
        onetime_cost = self.system.add_variable(
            f"{self.name}__onetime_cost",
            dims=("year",),
            coords={"year": years},
            lower=0,
        )
        self.system.add_constraints(f"{self.name}__onetime_cost_def", onetime_cost == inv_cost_expr)
        self.vars["onetime_cost"] = onetime_cost
        self.exprs["onetime_cost"] = onetime_cost
        self.system.add_objective_term(f"{self.name}__capex", onetime_cost, kind="capex", weight=1.0)

        u = float(self.data.get("heat_transfer_coefficient", 0.0))
        dt1 = self._hot_network.T_hot - self._cold_network.T_cold
        dt2 = self._hot_network.T_cold - self._cold_network.T_hot
        lmtd = xr.where(abs(dt1 - dt2) < 1e-12, dt1, (dt1 - dt2) / xr.apply_ufunc(np.log, dt1 / dt2))
        area_design = area.sel(year=years[0])
        p_nom = area_design * u * lmtd
        # Capacity-only (linear): p_out <= U * area * LMTD (single design year broadcasts).
        self.system.add_constraints(f"{self.name}__cap", p_out <= p_nom)

    @property
    def p_out(self):
        return self.vars["p_out"]

    @property
    def p_in(self):
        return self.vars["p_in"]

    @property
    def area(self):
        return self.vars["area"]

    @property
    def onetime_cost(self):
        return self.exprs.get("onetime_cost", 0.0)


class CounterFlowHeatExchanger(BaseDimensioning):
    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        hot_network: _ThermalFluid,
        cold_network: _ThermalFluid,
    ):
        self._hot_network = hot_network
        self._cold_network = cold_network
        super().__init__(name, data, system)

    def build(self) -> None:
        dims, coords = self._time_dims_coords()
        years = list(self.system.get_design_coords()["year"])

        p_out = self.system.add_variable(f"{self.name}__p_out", dims=dims, coords=coords, lower=0)
        p_in = self.system.add_variable(f"{self.name}__p_in", dims=dims, coords=coords, upper=0)
        self.vars["p_out"] = p_out
        self.vars["p_in"] = p_in

        self._cold_network.register_unit(self, p_out, PowerSign.POSITIVE)
        self._hot_network.register_unit(self, p_in, PowerSign.NEGATIVE)
        self.system.add_constraints(f"{self.name}__balance", p_in == -p_out)

        support = tuple(float(v) for v in self.data.get("area_support", (0.0,)))
        i_b = float(self.data.get("I_B", 0.0))
        k = float(self.data.get("K", 1.0))
        is_bought, area_expr, inv_cost_expr = self._select_support_value(
            name=self.name,
            support=support,
            i_b=i_b,
            k=k,
        )
        self.vars["is_bought"] = is_bought
        area = self.system.add_variable(
            f"{self.name}__area",
            dims=("year",),
            coords={"year": years},
            lower=0,
            upper=float(max(support) if support else 0.0),
        )
        self.system.add_constraints(f"{self.name}__area_def", area == area_expr)
        self.vars["area"] = area
        onetime_cost = self.system.add_variable(
            f"{self.name}__onetime_cost",
            dims=("year",),
            coords={"year": years},
            lower=0,
        )
        self.system.add_constraints(f"{self.name}__onetime_cost_def", onetime_cost == inv_cost_expr)
        self.vars["onetime_cost"] = onetime_cost
        self.exprs["onetime_cost"] = onetime_cost
        self.system.add_objective_term(f"{self.name}__capex", onetime_cost, kind="capex", weight=1.0)

        u = float(self.data.get("heat_transfer_coefficient", 0.0))
        dt1 = self._hot_network.T_hot - self._cold_network.T_hot
        dt2 = self._hot_network.T_cold - self._cold_network.T_cold
        lmtd = xr.where(abs(dt1 - dt2) < 1e-12, dt1, (dt1 - dt2) / xr.apply_ufunc(np.log, dt1 / dt2))
        area_design = area.sel(year=years[0])
        p_nom = area_design * u * lmtd
        self.system.add_constraints(f"{self.name}__cap", p_out <= p_nom)

    @property
    def p_out(self):
        return self.vars["p_out"]

    @property
    def p_in(self):
        return self.vars["p_in"]

    @property
    def area(self):
        return self.vars["area"]

    @property
    def onetime_cost(self):
        return self.exprs.get("onetime_cost", 0.0)
