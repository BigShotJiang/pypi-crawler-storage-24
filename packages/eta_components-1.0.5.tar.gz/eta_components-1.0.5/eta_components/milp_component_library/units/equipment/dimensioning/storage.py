from __future__ import annotations

from typing import TYPE_CHECKING

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.equipment.dimensioning.base_dimensioning import BaseDimensioning

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import CoolingFluid, HeatingFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class HeatStorage(BaseDimensioning):
    def __init__(self, name: str, data: dict, system: _BaseSystem, *, heating_network: HeatingFluid):
        self._thermal_network = heating_network
        super().__init__(name, data, system)

    def build(self) -> None:
        dims, coords = self._time_dims_coords()
        design_coords = self.system.get_design_coords()
        years = design_coords["year"]
        periods = coords["period"]
        times = coords["time"]

        support = tuple(float(v) for v in self.data.get("E_nom_support", (0.0,)))
        max_cap = float(max(support) if support else 0.0)
        i_b = float(self.data.get("I_B", 0.0))
        k = float(self.data.get("K", 1.0))
        c_in_max = float(self.data.get("c_in_max", 0.0))
        c_out_max = float(self.data.get("c_out_max", 0.0))
        eta = float(self.data.get("eta", 1.0))
        loss = float(self.data.get("loss", 0.0))

        is_bought, e_nom_expr, inv_cost_expr = self._select_support_value(
            name=self.name,
            support=support,
            i_b=i_b,
            k=k,
            cost_ref_scale=1000.0,
        )
        self.vars["is_bought"] = is_bought
        e_nom = self.system.add_variable(
            f"{self.name}__e_nom",
            dims=("year",),
            coords={"year": years},
            lower=0,
            upper=max_cap,
        )
        self.vars["e_nom"] = e_nom

        onetime_cost = self.system.add_variable(
            f"{self.name}__onetime_cost",
            dims=("year",),
            coords={"year": years},
            lower=0,
        )
        self.vars["onetime_cost"] = onetime_cost
        self.exprs["onetime_cost"] = onetime_cost
        self.system.add_objective_term(f"{self.name}__capex", onetime_cost, kind="capex", weight=1.0)

        e = self.system.add_variable(f"{self.name}__e", dims=dims, coords=coords, lower=0, upper=max_cap)
        p_in = self.system.add_variable(
            f"{self.name}__p_heat_in",
            dims=dims,
            coords=coords,
            lower=-max_cap * c_in_max,
            upper=0,
        )
        p_out = self.system.add_variable(
            f"{self.name}__p_heat_out",
            dims=dims,
            coords=coords,
            lower=0,
            upper=max_cap * c_out_max,
        )

        self.vars["e"] = e
        self.vars["p_heat_in"] = p_in
        self.vars["p_heat_out"] = p_out
        self.vars["_p_in"] = p_in
        self.vars["_p_out"] = p_out

        self._thermal_network.register_unit(self, p_in, PowerSign.NEGATIVE)
        self._thermal_network.register_unit(self, p_out, PowerSign.POSITIVE)

        e_next = e.shift(time=-1)
        mask = xr.DataArray(
            [t != times[-1] for t in times],
            coords={"time": times},
            dims=("time",),
        )
        dyn = e_next - ((1 - loss) * e + eta * (-p_in) - (1 / eta) * p_out)
        dyn = dyn.where(mask, other=0)

        if "scenario" in coords:
            e_end_dims = ("scenario", "year", "period")
            e_end_coords = {"scenario": list(coords["scenario"]), "year": years, "period": list(periods)}
        else:
            e_end_dims = ("year", "period")
            e_end_coords = {"year": years, "period": periods}
        e_end = self.system.add_variable(
            f"{self.name}__e_end",
            dims=e_end_dims,
            coords=e_end_coords,
            lower=0,
            upper=max_cap,
        )
        self.vars["e_end"] = e_end
        t_last = times[-1]
        first_year = years[0]
        e_nom_design = e_nom.sel(year=first_year)

        self.system.add_constraints_batch(
            [
                (f"{self.name}__e_nom_def", e_nom == e_nom_expr),
                (f"{self.name}__onetime_cost_def", onetime_cost == inv_cost_expr),
                (f"{self.name}__e_cap", e <= e_nom_design),
                (f"{self.name}__p_in_cap", p_in >= -(c_in_max * e_nom_design)),
                (f"{self.name}__p_out_cap", p_out <= c_out_max * e_nom_design),
                (f"{self.name}__e_init", e.sel(time=times[0]) == 0),
                (f"{self.name}__dyn", dyn == 0),
                (f"{self.name}__e_end_cap", e_end <= e_nom_design),
                (
                    f"{self.name}__dyn_terminal",
                    e_end
                    == (1 - loss) * e.sel(time=t_last)
                    + eta * (-p_in.sel(time=t_last))
                    - (1 / eta) * p_out.sel(time=t_last),
                ),
            ]
        )

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def e(self):
        return self.vars["e"]

    @property
    def e_nom(self):
        return self.vars["e_nom"]

    @property
    def onetime_cost(self):
        return self.exprs.get("onetime_cost", 0.0)


class ColdStorage(BaseDimensioning):
    """Cold storage with negative energy convention: e in [-e_nom, 0]."""

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, cooling_network: CoolingFluid):
        self._thermal_network = cooling_network
        super().__init__(name, data, system)

    def build(self) -> None:
        dims, coords = self._time_dims_coords()
        design_coords = self.system.get_design_coords()
        years = design_coords["year"]
        periods = coords["period"]
        times = coords["time"]

        support = tuple(float(v) for v in self.data.get("E_nom_support", (0.0,)))
        max_cap = float(max(support) if support else 0.0)
        i_b = float(self.data.get("I_B", 0.0))
        k = float(self.data.get("K", 1.0))
        c_in_max = float(self.data.get("c_in_max", 0.0))
        c_out_max = float(self.data.get("c_out_max", 0.0))
        eta = float(self.data.get("eta", 1.0))
        loss = float(self.data.get("loss", 0.0))

        is_bought, e_nom_expr, inv_cost_expr = self._select_support_value(
            name=self.name,
            support=support,
            i_b=i_b,
            k=k,
            cost_ref_scale=1000.0,
        )
        self.vars["is_bought"] = is_bought
        e_nom = self.system.add_variable(
            f"{self.name}__e_nom",
            dims=("year",),
            coords={"year": years},
            lower=0,
            upper=max_cap,
        )
        self.vars["e_nom"] = e_nom

        onetime_cost = self.system.add_variable(
            f"{self.name}__onetime_cost",
            dims=("year",),
            coords={"year": years},
            lower=0,
        )
        self.vars["onetime_cost"] = onetime_cost
        self.exprs["onetime_cost"] = onetime_cost
        self.system.add_objective_term(f"{self.name}__capex", onetime_cost, kind="capex", weight=1.0)

        e = self.system.add_variable(
            f"{self.name}__e",
            dims=dims,
            coords=coords,
            lower=-max_cap,
            upper=0,
        )
        p_in = self.system.add_variable(
            f"{self.name}__p_cool_in",
            dims=dims,
            coords=coords,
            lower=0,
            upper=max_cap * c_in_max,
        )
        p_out = self.system.add_variable(
            f"{self.name}__p_cool_out",
            dims=dims,
            coords=coords,
            lower=-max_cap * c_out_max,
            upper=0,
        )

        self.vars["e"] = e
        self.vars["p_cool_in"] = p_in
        self.vars["p_cool_out"] = p_out
        self.vars["_p_in"] = p_in
        self.vars["_p_out"] = p_out

        self._thermal_network.register_unit(self, p_in, PowerSign.POSITIVE)
        self._thermal_network.register_unit(self, p_out, PowerSign.NEGATIVE)

        e_next = e.shift(time=-1)
        mask = xr.DataArray(
            [t != times[-1] for t in times],
            coords={"time": times},
            dims=("time",),
        )
        dyn = e_next - ((1 - loss) * e - eta * p_in + (1 / eta) * (-p_out))
        dyn = dyn.where(mask, other=0)

        if "scenario" in coords:
            e_end_dims = ("scenario", "year", "period")
            e_end_coords = {"scenario": list(coords["scenario"]), "year": years, "period": list(periods)}
        else:
            e_end_dims = ("year", "period")
            e_end_coords = {"year": years, "period": periods}
        e_end = self.system.add_variable(
            f"{self.name}__e_end",
            dims=e_end_dims,
            coords=e_end_coords,
            lower=-max_cap,
            upper=0,
        )
        self.vars["e_end"] = e_end
        t_last = times[-1]
        first_year = years[0]
        e_nom_design = e_nom.sel(year=first_year)

        self.system.add_constraints_batch(
            [
                (f"{self.name}__e_nom_def", e_nom == e_nom_expr),
                (f"{self.name}__onetime_cost_def", onetime_cost == inv_cost_expr),
                (f"{self.name}__e_cap", e >= -e_nom_design),
                (f"{self.name}__p_in_cap", p_in <= c_in_max * e_nom_design),
                (f"{self.name}__p_out_cap", p_out >= -(c_out_max * e_nom_design)),
                (f"{self.name}__e_init", e.sel(time=times[0]) == 0),
                (f"{self.name}__dyn", dyn == 0),
                (f"{self.name}__e_end_cap", e_end >= -e_nom_design),
                (
                    f"{self.name}__dyn_terminal",
                    e_end
                    == (1 - loss) * e.sel(time=t_last)
                    - eta * p_in.sel(time=t_last)
                    + (1 / eta) * (-p_out.sel(time=t_last)),
                ),
            ]
        )

        self.exprs["annual_cost"] = xr.DataArray(
            [float(self.data.get("maintenance_cost", 0.0)) for _ in years],
            coords={"year": years},
            dims=("year",),
            name=f"{self.name}__annual_cost",
        )

    @property
    def e(self):
        return self.vars["e"]

    @property
    def e_nom(self):
        return self.vars["e_nom"]

    @property
    def onetime_cost(self):
        return self.exprs.get("onetime_cost", 0.0)
