from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING, Any, ClassVar

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.base_unit import BaseAuxiliaryUnit

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import Electrical, _ThermalFluid
    from eta_components.milp_component_library.systems import _BaseSystem


class _BasePump(BaseAuxiliaryUnit, ABC):
    """Linopy-only pump stub.

    The historical Pyomo implementation included complex PWL/pressure-drop logic.
    It must be rederived against the Linopy backend APIs.
    """

    def __init__(
        self,
        name: str,
        data: dict,
        system: _BaseSystem,
        *,
        thermal_network: _ThermalFluid,
        electrical_network: Electrical,
    ):
        self._thermal_net = thermal_network
        self._electrical_net = electrical_network
        self._unit_powers: list[Any] = []
        super().__init__(name, data, system)

    def build(self) -> None:
        dims = ("year", "period", "time")
        idx = self.system.index
        coords = {d: idx.coords[d].values for d in dims}

        # Decision variables
        volume_flow = self.system.add_variable(
            f"{self.name}__volume_flow",
            dims=dims,
            coords=coords,
            lower=0,
            upper=self._volume_flow_max_bound(),
        )
        p_el_in = self.system.add_variable(
            f"{self.name}__p_el_in",
            dims=dims,
            coords=coords,
            upper=0,
        )
        self.vars["volume_flow"] = volume_flow
        self.vars["p_el_in"] = p_el_in

        # Register electrical consumption.
        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)

        # Link flow to coupled thermal powers.
        if self._unit_powers:
            total = None
            for p in self._unit_powers:
                total = p if total is None else (total + p)
            delta_t = self._thermal_net.T_hot - self._thermal_net.T_cold
            cp = self._thermal_net.cp
            rho = self._thermal_net.rho
            self.system.add_constraints(
                f"{self.name}__flow_def",
                volume_flow == total / (delta_t * cp * rho),
            )

        eta = float(self.data.get("eta", 1.0))
        dp = float(self.data.get("delta_pressure", 0.0))
        # Legacy convention: P_el = -eta * P_hyd = -eta * (vol_flow * dp)
        self.system.add_constraints(f"{self.name}__p_el", p_el_in == -(eta * dp) * volume_flow)

    def unregister(self) -> None:
        # Best-effort unregister.
        if hasattr(self._thermal_net, "unregister_unit"):
            self._thermal_net.unregister_unit(self)
        if hasattr(self._electrical_net, "unregister_unit"):
            self._electrical_net.unregister_unit(self)
        self.system.unregister_unit(self)

    @property
    def time_step_cost(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__time_step_cost")

    @property
    def annual_cost(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        return xr.DataArray(0.0, coords={"year": years}, dims=("year",), name=f"{self.name}__annual_cost")

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__emissions")

    @property
    def power_el(self) -> Any:
        raise NotImplementedError

    def add_unit(self, unit: object, power: Any) -> None:
        """Legacy API: associate a unit thermal power with this pump."""
        self._unit_powers.append(power)
        # Ensure the coupling is applied (pump may have been built before add_unit was called).
        if hasattr(self.system, "_rebuild_required"):
            self.system._rebuild_required = True

    def _volume_flow_max_bound(self) -> Any:
        raise NotImplementedError


class PumpOperational(_BasePump):
    _param_names: ClassVar[list[str]] = ["eta", "volume_flow_max", "delta_pressure"]

    def _volume_flow_max_bound(self) -> Any:
        return float(self.data.get("volume_flow_max", 0.0))

    @property
    def volume_flow(self):
        return self.vars["volume_flow"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]


class PumpInvestment(_BasePump):
    _param_names: ClassVar[list[str]] = ["eta", "volume_flow_nom_support", "I_B", "K", "delta_pressure"]

    def _volume_flow_max_bound(self) -> Any:
        # Upper bound is the max support point.
        support = tuple(float(v) for v in self.data.get("volume_flow_nom_support", (0.0,)))
        return max(support) if support else 0.0

    def build(self) -> None:
        # Build base pump vars (volume_flow and p_el_in) with temporary inf upper bound, then add investment bound.
        dims = ("year", "period", "time")
        idx = self.system.index
        coords = {d: idx.coords[d].values for d in dims}

        support = tuple(float(v) for v in self.data.get("volume_flow_nom_support", (0.0,)))
        if not support:
            raise ValueError("volume_flow_nom_support must contain at least one support point.")

        # Select a nominal max volume flow from support points.
        sel_dim = "support"
        s_idx = list(range(len(support)))
        select = self.system.add_variable(
            f"{self.name}__support_sel",
            dims=(sel_dim,),
            coords={sel_dim: s_idx},
            binary=True,
        )
        self.system.add_constraints(f"{self.name}__support_one", select.sum(dim=sel_dim) == 1)

        vf_max = (select * xr.DataArray(list(support), coords={sel_dim: s_idx}, dims=(sel_dim,))).sum(dim=sel_dim)
        self.exprs["volume_flow_max"] = vf_max

        volume_flow = self.system.add_variable(
            f"{self.name}__volume_flow",
            dims=dims,
            coords=coords,
            lower=0,
        )
        p_el_in = self.system.add_variable(
            f"{self.name}__p_el_in",
            dims=dims,
            coords=coords,
            upper=0,
        )
        self.vars["volume_flow"] = volume_flow
        self.vars["p_el_in"] = p_el_in

        self._electrical_net.register_unit(self, p_el_in, PowerSign.NEGATIVE)

        # Enforce volume_flow <= selected max.
        self.system.add_constraints(f"{self.name}__vf_max", volume_flow <= vf_max)

        if self._unit_powers:
            total = None
            for p in self._unit_powers:
                total = p if total is None else (total + p)
            delta_t = self._thermal_net.T_hot - self._thermal_net.T_cold
            cp = self._thermal_net.cp
            rho = self._thermal_net.rho
            self.system.add_constraints(
                f"{self.name}__flow_def",
                volume_flow == total / (delta_t * cp * rho),
            )

        eta = float(self.data.get("eta", 1.0))
        dp = float(self.data.get("delta_pressure", 0.0))
        self.system.add_constraints(f"{self.name}__p_el", p_el_in == -(eta * dp) * volume_flow)

        # Linearized investment cost on support points.
        i_b = float(self.data.get("I_B", 0.0))
        k = float(self.data.get("K", 1.0))
        costs = [i_b * (v**k) for v in support]
        onetime = (select * xr.DataArray(costs, coords={sel_dim: s_idx}, dims=(sel_dim,))).sum(dim=sel_dim)
        self.exprs["onetime_cost"] = onetime
        # Register as capex.
        self.system.add_objective_term(f"{self.name}__capex", onetime, kind="capex", weight=1.0)

    @property
    def volume_flow(self):
        return self.vars["volume_flow"]

    @property
    def p_el_in(self):
        return self.vars["p_el_in"]

    @property
    def volume_flow_max(self):
        return self.exprs["volume_flow_max"]

    @property
    def onetime_cost(self):
        return self.exprs["onetime_cost"]
