from __future__ import annotations

import abc
from abc import abstractmethod
from typing import Any

from pydantic.fields import ModelPrivateAttr, PydanticUndefined

from eta_components.milp_component_library.base_object import BaseObject
from eta_components.milp_component_library.systems import _BaseSystem


class BaseUnit(BaseObject, abc.ABC):
    """Base class for all units (Linopy-only).

    Units build variables/constraints through `system.add_variable` / `system.add_constraints` and register:
    - network power expressions (via networks)
    - objective contributions (via `system.add_objective_term`)
    """

    _has_investment_decision: bool = False

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self.build()
        system.register_unit(self)

    def has_investment_decision(self) -> bool:
        flag = getattr(type(self), "_has_investment_decision", False)
        # Pydantic v2 may replace leading-underscore class attrs with ModelPrivateAttr
        if isinstance(flag, ModelPrivateAttr):
            flag = flag.get_default()
        if flag is PydanticUndefined:
            return False
        return bool(flag)

    @abstractmethod
    def build(self) -> None:
        """Create variables/constraints and register terms/powers."""

    @abstractmethod
    def unregister(self) -> None:
        """Remove any registrations from system/networks."""

    # Compatibility properties (objective modules may still reference these)
    @property
    @abstractmethod
    def time_step_cost(self) -> Any:
        raise NotImplementedError

    @property
    @abstractmethod
    def annual_cost(self) -> Any:
        raise NotImplementedError

    @property
    @abstractmethod
    def onetime_cost(self) -> Any:
        raise NotImplementedError

    @property
    @abstractmethod
    def emissions(self) -> Any:
        raise NotImplementedError


class BaseAuxiliaryUnit(BaseUnit, abc.ABC):
    """Auxiliaries depend on other units."""


class BaseStandaloneUnit(BaseUnit, abc.ABC):
    """Standalone units do not depend on other units."""
