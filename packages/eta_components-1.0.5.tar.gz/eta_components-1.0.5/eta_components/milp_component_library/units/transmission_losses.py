from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.base_unit import BaseAuxiliaryUnit

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import _BaseNetwork
    from eta_components.milp_component_library.systems import _BaseSystem


class TransmissionLoss(BaseAuxiliaryUnit):
    """Linopy-only transmission loss (minimal).

    This implementation models a generic fractional loss on an externally provided `total_power` expression.
    Complex per-unit association from the historical Pyomo version is not yet migrated.
    """

    _has_investment_decision = False
    _param_names: ClassVar[list[str]] = ["loss"]

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, network: _BaseNetwork):
        self._net = network
        self._loss_units: list[tuple[object, Any]] = []
        super().__init__(name, data, system)
        self._net.register_loss(self)

    def build(self) -> None:
        # Loss constraints are built via `build_constraints()` when the network is solved.
        return

    def add_unit(self, unit: object, power: Any) -> None:
        """Legacy API: associate a unit power with this loss component."""
        self._loss_units.append((unit, power))

    def build_constraints(self) -> None:
        """Build/register loss power contributions.

        This is called from the network on `system.solve()`.
        """
        if self._loss_units:
            total = None
            for _, p in self._loss_units:
                total = p if total is None else (total + p)
            if total is not None:
                self.register_loss_power(total)

    def unregister(self) -> None:
        if hasattr(self._net, "unregister_loss"):
            self._net.unregister_loss(self)
        try:
            self._net.unregister_unit(self)
        except Exception:
            pass
        self.system.unregister_unit(self)

    def register_loss_power(self, total_power: Any) -> None:
        """Register a loss power expression derived from `total_power`.

        `loss` may be scalar or time-structured. The resulting loss power is added as an UNDEFINED contribution.
        """

        loss = self.param(self.data.get("loss", 0.0), name=f"{self.name}__loss")
        loss_power = -total_power * loss
        self.exprs["loss_power"] = loss_power
        self._net.register_unit(self, loss_power, PowerSign.UNDEFINED)

    @property
    def time_step_cost(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__time_step_cost")

    @property
    def annual_cost(self) -> xr.DataArray:
        years = list(self.system.index.coords["year"].values)
        return xr.DataArray(0.0, coords={"year": years}, dims=("year",), name=f"{self.name}__annual_cost")

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> xr.DataArray:
        return self.param(0.0, name=f"{self.name}__emissions")
