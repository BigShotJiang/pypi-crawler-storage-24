from __future__ import annotations

from abc import ABC
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, ClassVar

import xarray as xr

from eta_components.milp_component_library.networks import PowerSign
from eta_components.milp_component_library.units.base_unit import BaseStandaloneUnit

if TYPE_CHECKING:
    from eta_components.milp_component_library.networks import _BaseNetwork
    from eta_components.milp_component_library.systems import _BaseSystem


class _BaseTrader(BaseStandaloneUnit, ABC):
    """Linopy-native trader exchanging energy with system boundary.

    Units (SI throughout):
    - amount (decision variable): output **W** (power per timestep)
    - unit_price (config): required input **EUR/Wh**
    - emissions_per_unit (config): required input **kgCO2/Wh** or tCO2/Wh
    """

    def __init__(self, name: str, data: dict, system: _BaseSystem, *, network: _BaseNetwork):
        self._net = network
        # Compatibility: legacy tests accessed `unit.model.<attr>` (Pyomo Block). Use a simple namespace.
        self.model = SimpleNamespace()
        super().__init__(name, data, system)

    @property
    def amount(self) -> Any:
        """Decision variable: power in W per timestep (dims: year, period, time)."""
        return self.vars["amount"]


class _SimpleTrader(_BaseTrader, ABC):
    _param_names: ClassVar[list[str]] = ["unit_price"]
    _optional_params: ClassVar[dict[str, float]] = {"emissions_per_unit": 0.0, "capacity_price": 0.0}

    def _unit_price(self) -> xr.DataArray:
        return self.param(self.data.get("unit_price", 0.0), name=f"{self.name}__unit_price")

    def _emissions_per_unit(self) -> xr.DataArray:
        return self.param(self.data.get("emissions_per_unit", 0.0), name=f"{self.name}__emissions_per_unit")

    def _register_terms(self, amount: Any) -> None:
        price = self._unit_price()
        epu = self._emissions_per_unit()
        # Opex term: amount * unit_price
        self.system.add_objective_term(f"{self.name}__opex", amount * price, kind="opex", weight=1.0)
        # Emissions term: amount * emissions_per_unit
        self.system.add_objective_term(f"{self.name}__emissions", amount * epu, kind="emissions", weight=1.0)

    @property
    def time_step_cost(self) -> Any:
        return self.exprs.get("time_step_cost", 0)

    @property
    def annual_cost(self) -> Any:
        return self.exprs.get("annual_cost", 0)

    @property
    def onetime_cost(self) -> float:
        return 0.0

    @property
    def emissions(self) -> Any:
        return self.exprs.get("emissions", 0)

    def unregister(self) -> None:
        self._net.unregister_unit(self)
        self.system.unregister_unit(self)

    def _add_capacity_pricing(
        self,
        *,
        amount: Any,
        name: str,
        mode: str,
    ) -> None:
        """Add capacity-price annual term based on max/min over time.

        Parameters
        - amount: decision variable with dims (year, period, time)
        - mode: 'max' or 'min' (over period/time) per year
        """

        cap_price = float(self.data.get("capacity_price", 0.0))
        if not cap_price:
            return

        big_m = float(self.data.get("capacity_price_M", 1e6))
        dims, coords = self.system.get_operational_time_dims_coords()

        design_coords = self.system.get_design_coords()
        cap = self.system.add_variable(
            f"{name}__amount_max",
            dims=("year",),
            coords={"year": design_coords["year"]},
            lower=None,
            upper=None,
        )
        b = self.system.add_variable(
            f"{name}__amount_max_sel",
            dims=dims,
            coords={d: coords[d] for d in dims},
            binary=True,
        )

        if mode == "max":
            cap_constraints = [
                (f"{name}__amount_max_sel_sum", b.sum(dim=("period", "time")) == 1),
                (f"{name}__amount_max_lb", cap >= amount),
                (f"{name}__amount_max_ub", cap <= amount + big_m * (1 - b)),
            ]
        elif mode == "min":
            cap_constraints = [
                (f"{name}__amount_max_sel_sum", b.sum(dim=("period", "time")) == 1),
                (f"{name}__amount_min_ub", cap <= amount),
                (f"{name}__amount_min_lb", cap >= amount - big_m * (1 - b)),
            ]
        else:
            raise ValueError("mode must be 'max' or 'min'.")
        self.system.add_constraints_batch(cap_constraints)

        annual_cost = cap_price * cap
        self.exprs["annual_cost"] = annual_cost
        self.model.amount_max = cap

        # Register as capex-like term (unweighted by period weights).
        self.system.add_objective_term(f"{name}__capacity_price", annual_cost, kind="capex", weight=1.0)


class SimpleBuyer(_SimpleTrader):
    """Market buyer: consumes energy from the network (negative `amount`)."""

    def build(self) -> None:
        dims, coords = self.system.get_operational_time_dims_coords()
        amount = self.system.add_variable(
            f"{self.name}__amount",
            dims=dims,
            coords={d: coords[d] for d in dims},
            upper=0,
        )
        self.vars["amount"] = amount

        power = amount
        self.exprs["power"] = power
        self._net.register_unit(self, power, PowerSign.NEGATIVE)

        self.exprs["time_step_cost"] = amount * self._unit_price()
        self.exprs["emissions"] = amount * self._emissions_per_unit()
        self._register_terms(amount)
        # No capacity pricing for the plain buyer (legacy tests use dedicated subclasses).


class SimpleSeller(_SimpleTrader):
    """Market seller: supplies energy into the network (positive `amount`)."""

    def build(self) -> None:
        dims, coords = self.system.get_operational_time_dims_coords()
        amount = self.system.add_variable(
            f"{self.name}__amount",
            dims=dims,
            coords={d: coords[d] for d in dims},
            lower=0,
        )
        self.vars["amount"] = amount

        power = amount
        self.exprs["power"] = power
        self._net.register_unit(self, power, PowerSign.POSITIVE)

        self.exprs["time_step_cost"] = amount * self._unit_price()
        self.exprs["emissions"] = amount * self._emissions_per_unit()
        self._register_terms(amount)
        self._add_capacity_pricing(amount=amount, name=self.name, mode="max")


class CapacityCostBuyer(SimpleBuyer):
    """Buyer with capacity price based on max delivery magnitude (legacy sign convention)."""

    def build(self) -> None:
        super().build()
        amount = self.vars["amount"]
        # Legacy tests expect min(amount) (most negative) to drive the capacity payment.
        self._add_capacity_pricing(amount=amount, name=self.name, mode="min")


class SecuredDeliveryBuyer(SimpleBuyer):
    """Buyer with capacity price based on secured delivery (max amount, i.e. least negative)."""

    def build(self) -> None:
        super().build()
        amount = self.vars["amount"]
        self._add_capacity_pricing(amount=amount, name=self.name, mode="max")
