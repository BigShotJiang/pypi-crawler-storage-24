import itertools

import matplotlib.pyplot as plt

from eta_components.milp_component_library.networks import _BaseNetwork
from eta_components.milp_component_library.systems import _BaseSystem


class Visualizer:
    def __init__(self, system: _BaseSystem):
        self._system = system

    def visualize_all(self):
        years = list(self._system.index.coords["year"].values)
        periods = list(self._system.index.coords["period"].values)
        for year, period in itertools.product(years, periods):
            self.visualize_period(year, period)

    def visualize_period(self, year: int, period: int):
        for network in self._system.networks:
            fig, ax = plt.subplots(dpi=300)
            fig.suptitle(network.name)
            ax.set_title(f"Year {year}, Period {period}")
            for unit, power in network.unit_power_pairs():
                try:
                    da = power.sel(year=year, period=period)
                    values = list(da.values)
                except Exception:
                    # Scalar or non-xarray expression; plot as flat line.
                    values = [float(power)] * len(self._system.index.coords["time"].values)

                time = list(self._system.index.coords["time"].values)
                label = getattr(power, "name", None) or type(power).__name__
                ax.plot(time, values, label=f"{unit.name}: {label}")

            ax.legend()
            ax.autoscale(enable=True, axis="x", tight=True)
            fig.tight_layout()

    def visualize_network(self, network: _BaseNetwork):
        years = list(self._system.index.coords["year"].values)
        periods = list(self._system.index.coords["period"].values)
        for year, period in itertools.product(years, periods):
            fig, ax = plt.subplots(dpi=300)
            fig.suptitle(network.name)
            ax.set_title(f"Year {year}, Period {period}")
            for unit, power in network.unit_power_pairs():
                try:
                    da = power.sel(year=year, period=period)
                    values = list(da.values)
                except Exception:
                    values = [float(power)] * len(self._system.index.coords["time"].values)

                time = list(self._system.index.coords["time"].values)
                label = getattr(power, "name", None) or type(power).__name__
                ax.plot(time, values, label=f"{unit.name}: {label}")

            ax.legend()
            ax.autoscale(enable=True, axis="x", tight=True)
            fig.tight_layout()
