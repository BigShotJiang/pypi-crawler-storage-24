from __future__ import annotations

import warnings
from collections.abc import Mapping
from types import SimpleNamespace
from typing import Any, ClassVar

import numpy as np
import xarray as xr

from eta_components.milp_component_library.indexing import ensure_dim_order
from eta_components.milp_component_library.systems import _BaseSystem


class BaseObject:
    """Lightweight base class for Linopy-native components.

    Components must not touch backend internals; they only interact via the System APIs and indexing helpers.
    """

    _param_names: ClassVar[list[str]] = []
    _optional_params: ClassVar[dict[str, Any]] = {}
    _forbidden_updates: ClassVar[list[str]] = []

    def __init__(self, name: str, data: dict[str, Any] | None, system: _BaseSystem):
        self._validate_name(name)
        self._name = str(name)
        self._system = system

        # Merge optional defaults from full inheritance chain (base -> subclass)
        defaults: dict[str, Any] = {}
        for cls in reversed(type(self).mro()):
            defaults.update(getattr(cls, "_optional_params", {}))
        self._data: dict[str, Any] = {**defaults, **(data or {})}

        # Optional storage for backend handles (vars/exprs/constraints) per component.
        self.vars: dict[str, Any] = {}
        self.exprs: dict[str, Any] = {}
        # Param cache: key -> DataArray. Invalidated on update_data().
        self._param_cache: dict[tuple[Any, ...], xr.DataArray] = {}
        # Compatibility shim: legacy code/tests used `.model` (Pyomo Block). Provide a namespace.
        self.model: Any = SimpleNamespace()

    @staticmethod
    def _validate_name(name: str) -> None:
        if not str(name).isidentifier():
            warnings.warn(
                f"The name '{name}' is not a valid identifier. For better access to optimization "
                "results, choose a valid Python identifier as a name.",
                stacklevel=2,
            )

    @property
    def name(self) -> str:
        return self._name

    @property
    def system(self) -> _BaseSystem:
        return self._system

    @property
    def data(self) -> dict[str, Any]:
        return self._data

    def update_data(self, updates: Mapping[str, Any]) -> None:
        """Update this component's data dict in-place.

        This is a compatibility helper used by legacy tests/examples which re-solve after
        changing parameters (e.g. `unit.update_data({"eta": 0.8}); system.solve()`).

        Notes:
        - Components must remain Linopy-only; no backend rebuild happens here. The system is
          responsible for rebuild-on-solve semantics.
        - Callers may update only non-forbidden keys.
        """

        for key in updates:
            if key in getattr(type(self), "_forbidden_updates", []):
                raise ValueError(f"Parameter '{key}' cannot be updated for {type(self).__name__}.")
        self._data.update(dict(updates))
        self._param_cache.clear()
        # Request a rebuild before the next solve so updated params are applied.
        if hasattr(self.system, "_rebuild_required"):
            self.system._rebuild_required = True

    # -----------------------------
    # Parameter ingestion helpers
    # -----------------------------
    def param(
        self,
        value: Any,
        *,
        dims: tuple[str, ...] = ("year", "period", "time"),
        coords: Mapping[str, Any] | None = None,
        default: float = 0,
        name: str | None = None,
    ) -> xr.DataArray:
        """Create an xarray parameter aligned to the system index.

        Supported value shapes:
        - scalar (int/float)
        - dict mapping index tuples -> values
        - xarray.DataArray
        """
        cache_key: tuple[Any, ...] = (
            name,
            tuple(dims),
            default,
            value if isinstance(value, (int, float)) else id(value),
            None
            if coords is None
            else tuple(
                sorted(
                    (k, tuple(v) if hasattr(v, "__iter__") and not isinstance(v, str) else v) for k, v in coords.items()
                )
            ),
        )
        if cache_key in self._param_cache:
            return self._param_cache[cache_key]

        if isinstance(value, xr.DataArray):
            da = value
        elif isinstance(value, (int, float)):
            coords_resolved = coords or {d: self.system.index.coords[d].values for d in dims}
            da = xr.DataArray(float(value), dims=tuple(dims), coords={k: list(v) for k, v in coords_resolved.items()})
        elif isinstance(value, Mapping):
            coords_resolved = coords or {d: self.system.index.coords[d].values for d in dims}
            da = xr.DataArray(float(default), dims=tuple(dims), coords={k: list(v) for k, v in coords_resolved.items()})
            for k, v in value.items():
                k_tuple = (k,) if not isinstance(k, tuple) else k
                indexer = dict(zip(dims, k_tuple, strict=False))
                if not all(indexer[d] in da.coords[d].values for d in dims):
                    continue
                sel = da.loc[indexer]
                # Assign array of correct shape to avoid xarray set_dims errors when RHS is scalar
                val = float(v)
                da.loc[indexer] = np.broadcast_to(val, sel.shape) if sel.size > 1 else val
        else:
            raise TypeError(f"Unsupported parameter value type: {type(value)}")

        da = ensure_dim_order(da, dims_order=self.system.dims_order)
        # Numeric stability: parameters should be float for solver compatibility.
        try:
            da = da.astype(float)
        except Exception:
            pass
        if name is not None:
            da.name = name
        self._param_cache[cache_key] = da
        return da
