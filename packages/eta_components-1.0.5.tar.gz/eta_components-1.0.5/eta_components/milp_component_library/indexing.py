from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

import xarray as xr

DIMS_ORDER: tuple[str, ...] = ("scenario", "year", "period", "time")
TIME_DIMS: tuple[str, ...] = ("year", "period", "time")
STACKED_TIME_DIM: str = "time_index"

# Extra dims must be prepended in this stable precedence order (see cross-repo.md).
EXTRA_DIMS_PRECEDENCE: tuple[str, ...] = ("node", "carrier", "tech", "unit")


def make_index(coords: Mapping[str, Any]) -> xr.Dataset:
    """Create a canonical `system.index` coordinate container."""

    return xr.Dataset(coords={k: coords[k] for k in coords})


def _ordered_dims(dims: Iterable[str], *, dims_order: tuple[str, ...] = DIMS_ORDER) -> tuple[str, ...]:
    dims_set = set(dims)
    extra = tuple(d for d in EXTRA_DIMS_PRECEDENCE if d in dims_set)
    core = tuple(d for d in dims_order if d in dims_set)
    # Any remaining dims (not declared in precedence lists) are prepended *after* known extras, stable by name.
    remaining = tuple(sorted(dims_set - set(extra) - set(core)))
    return (*extra, *remaining, *core)


def ensure_dim_order(da: xr.DataArray, *, dims_order: tuple[str, ...] = DIMS_ORDER) -> xr.DataArray:
    """Reorder dims to the canonical order (extra dims first, then scenario/year/period/time)."""

    return da.transpose(*_ordered_dims(da.dims, dims_order=dims_order))


def stack_time(da: xr.DataArray) -> xr.DataArray:
    """Stack (year, period, time) into a single `time_index` dim in a stable order."""

    missing = [d for d in TIME_DIMS if d not in da.dims]
    if missing:
        raise ValueError(f"Cannot stack_time: missing dims {missing}. Present dims: {da.dims}")

    stacked = da.stack({STACKED_TIME_DIM: TIME_DIMS})
    # Put time_index at the end of the time-structure block and keep canonical ordering.
    return ensure_dim_order(stacked)


def unstack_time(da: xr.DataArray) -> xr.DataArray:
    """Unstack `time_index` back into (year, period, time)."""

    if STACKED_TIME_DIM not in da.dims:
        raise ValueError(f"Cannot unstack_time: missing dim '{STACKED_TIME_DIM}'. Present dims: {da.dims}")
    out = da.unstack(STACKED_TIME_DIM)
    return ensure_dim_order(out)
