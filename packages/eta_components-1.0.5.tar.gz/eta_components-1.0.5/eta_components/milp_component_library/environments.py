from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING, ClassVar

import xarray as xr

from eta_components.milp_component_library.base_object import BaseObject
from eta_components.milp_component_library.utils import DeprecatedClassMeta

if TYPE_CHECKING:
    from eta_components.milp_component_library.systems import _BaseSystem


class _BaseEnvironment(BaseObject, ABC):
    """Linopy-native environment container (parameters only)."""

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        system.register_environment(self)


class _Air(_BaseEnvironment, ABC):
    pass


class DryAir(_Air):
    """Dry-bulb air temperature environment."""

    _param_names: ClassVar[list[str]] = ["T_db"]

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self.exprs["temp_db"] = self.param(self.data.get("T_db", 0.0), name=f"{self.name}__T_db")

    @property
    def temp_db(self) -> xr.DataArray:
        return self.exprs["temp_db"]


class Ambient(metaclass=DeprecatedClassMeta):
    _DeprecatedClassMeta__alias = DryAir


class HumidAir(DryAir):
    """Dry-bulb and wet-bulb air temperatures."""

    _param_names: ClassVar[list[str]] = [*DryAir._param_names, "T_wb"]

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self.exprs["temp_wb"] = self.param(self.data.get("T_wb", 0.0), name=f"{self.name}__T_wb")

    @property
    def temp_wb(self) -> xr.DataArray:
        return self.exprs["temp_wb"]


class SolarIrradiance(_BaseEnvironment):
    """Solar irradiance environment."""

    _param_names: ClassVar[list[str]] = ["solar_irradiance"]

    def __init__(self, name: str, data: dict, system: _BaseSystem):
        super().__init__(name, data, system)
        self.exprs["solar_irradiance"] = self.param(
            self.data.get("solar_irradiance", 0.0),
            name=f"{self.name}__solar_irradiance",
        )

    @property
    def solar_irradiance(self) -> xr.DataArray:
        return self.exprs["solar_irradiance"]
