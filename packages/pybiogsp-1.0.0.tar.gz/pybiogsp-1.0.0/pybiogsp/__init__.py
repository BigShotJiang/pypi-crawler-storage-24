"""
PyBioGSP: Biological Graph Signal Processing for Spatial Data Analysis

A Python implementation of Graph Signal Processing (GSP) methods including 
Spectral Graph Wavelet Transform (SGWT) for analyzing spatial patterns in 
biological data. Uses PyTorch for accelerated matrix decomposition.

Based on Hammond, Vandergheynst, and Gribonval (2011) 
"Wavelets on Graphs via Spectral Graph Theory"
"""

from .sgwt import SGWT, init_sgwt
from .core import (
    sgwt_get_kernels,
    compute_sgwt_filters,
    sgwt_forward,
    sgwt_inverse,
    sgwt_auto_scales,
    compare_kernel_families,
)
from .utils import (
    cal_laplacian,
    fast_decomposition_lap,
    gft,
    igft,
    cosine_similarity,
    find_knee_point,
    check_kband,
)
from .simulation import (
    simulate_multiscale,
    simulate_stripe_patterns,
    simulate_multiscale_overlap,
    simulate_moving_circles,
    simulate_checkerboard,
)
from .visualization import (
    plot_sgwt_decomposition,
    plot_fourier_modes,
    visualize_sgwt_kernels,
    visualize_similarity_xy,
    visualize_multiscale,
    visualize_stripe_patterns,
    visualize_moving_circles,
    visualize_checkerboard,
)

__version__ = "1.0.0"
__author__ = "Yuzhou Chang"
__email__ = "yuzhou.chang@osumc.edu"

__all__ = [
    # Main class
    "SGWT",
    "init_sgwt",
    # Core functions
    "sgwt_get_kernels",
    "compute_sgwt_filters",
    "sgwt_forward",
    "sgwt_inverse",
    "sgwt_auto_scales",
    "compare_kernel_families",
    # Utility functions
    "cal_laplacian",
    "fast_decomposition_lap",
    "gft",
    "igft",
    "cosine_similarity",
    "find_knee_point",
    "check_kband",
    # Simulation functions
    "simulate_multiscale",
    "simulate_stripe_patterns",
    "simulate_multiscale_overlap",
    "simulate_moving_circles",
    "simulate_checkerboard",
    # Visualization functions
    "plot_sgwt_decomposition",
    "plot_fourier_modes",
    "visualize_sgwt_kernels",
    "visualize_similarity_xy",
    "visualize_multiscale",
    "visualize_stripe_patterns",
    "visualize_moving_circles",
    "visualize_checkerboard",
]
