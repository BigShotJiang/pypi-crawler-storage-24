# Ad06 Agent

**Agente de automacao desktop com inteligencia artificial.**

Controle seu computador por voz ou texto usando IA (Grok xAI) com automacao precisa via UI Automation API.

---

## Instalacao

```bash
pip install ad06-agent
```

**Requisitos:** Windows 10/11, Python 3.10+

---

## Uso rapido

```bash
# Configurar o agente (primeira vez)
ad06-agent config

# Iniciar o agente
ad06-agent start

# Ver status
ad06-agent status

# Parar o agente
ad06-agent stop
```

---

## O que o agente faz

- Abre aplicativos por nome
- Clica em botoes e elementos da interface
- Digita texto em qualquer campo
- Navega em menus
- Captura a tela e entende o que esta visivel
- Executa comandos por voz ou texto via chat

## Tecnologias

- **UI Automation API** — automacao nativa do Windows
- **Grok xAI** — inteligencia artificial para planejamento
- **WebSocket** — comunicacao em tempo real com o backend
- **PyAutoGUI** — fallback para qualquer situacao

---

## Suporte

Windows 10 / Windows 11 — Python 3.10+
