"""
setup.py — Torna o agente instalável via:  pip install seu-agente-desktop
"""
from setuptools import setup, find_packages
from pathlib import Path

long_description = Path("README.md").read_text(encoding="utf-8") if Path("README.md").exists() else ""

setup(
    name="seu-agente-desktop",
    version="1.0.0",
    description="Agente de automação desktop — UI Automation API + Grok xAI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Seu Nome",
    python_requires=">=3.10",

    packages=find_packages(),

    install_requires=[
        "typer>=0.12.0",
        "loguru>=0.7.0",
        "websockets>=12.0",
        "requests>=2.31.0",
        "psutil>=5.9.0",
        "pywin32>=306;sys_platform=='win32'",
        "uiautomation>=2.0.18;sys_platform=='win32'",
        "pywinauto>=0.6.8;sys_platform=='win32'",
        "pyautogui>=0.9.54;sys_platform=='win32'",
        "keyboard>=0.13.5;sys_platform=='win32'",
        "mss>=9.0.1;sys_platform=='win32'",
        "Pillow>=10.0.0",
    ],

    # Cria o comando "seu-agente" no terminal após instalar
    entry_points={
        "console_scripts": [
            "seu-agente=seu_agente.main:cli",
        ],
    },

    classifiers=[
        "Programming Language :: Python :: 3.10",
        "Operating System :: Microsoft :: Windows",
    ],
)
