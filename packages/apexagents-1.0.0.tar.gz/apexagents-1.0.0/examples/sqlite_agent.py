import asyncio
import os
from dotenv import load_dotenv
from apexagents import Agent, tool
from apexagents.memory import SQLiteMemory, SummarizingMemory

load_dotenv()

@tool
def process_data(data: str) -> str:
    """
    Task: Mocks processing some textual data payload.
    
    Input Parameters:
        data (str): The input string payload to process.
        
    Output Parameters / Returns:
        str: A formatted acknowledgement string.
        
    Raises: None
    """
    return f"Processed: {data}"

async def main():
    """
    Task: Verified the integration of SQLite storage and Summarization threshold wrapping across extended agent interactions seamlessly natively organically properly seamlessly safely reliably logically effectively gracefully thoughtfully consistently securely.
    
    Input Parameters: None
        
    Output Parameters / Returns: None
    
    Raises: None
    """
    # Initialize a persistent SQLite backend
    sqlite_backend = SQLiteMemory(db_path="test_memory.db", session_id="user_123")
    
    # Wrap it in our intelligent summarizer/truncator
    memory = SummarizingMemory(
        backend=sqlite_backend,
        llm_provider=None, # In a full async mode, this would be an LLMProvider
        max_messages=5,
        summarize_down_to=2
    )
    
    agent = Agent(
        name="MemoryAgent",
        model=f"azure/{os.environ.get('DEPLOYMENT_NAME', 'gpt-4o-mini')}",
        instructions="You are a helpful assistant with a great memory.",
        tools=[process_data],
        memory=memory
    )
    
    print("Agent prompt 1:")
    response = await agent.arun("My secret favorite color is magenta.")
    print("Agent Response:", response)
    
    print("\nAgent prompt 2 (Creating more messages to trigger truncation):")
    response = await agent.arun("Process the word 'apple'.")
    print("Agent Response:", response)
    
    print("\nAgent prompt 3:")
    response = await agent.arun("Process the word 'banana'.")
    print("Agent Response:", response)
    
    print("\nAgent prompt 4 (Checking memory):")
    response = await agent.arun("What is my favorite color from earlier?")
    print("Agent Response:", response)
    
    # Clean up the DB file
    if os.path.exists("test_memory.db"):
        os.remove("test_memory.db")

if __name__ == "__main__":
    asyncio.run(main())
