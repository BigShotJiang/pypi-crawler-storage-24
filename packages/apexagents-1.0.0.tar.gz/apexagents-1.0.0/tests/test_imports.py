import pytest
from apexagents import Agent, tool, Tool
from apexagents.memory import InMemoryMemory
from apexagents.llm import LLMProvider

def test_imports():
    """Verify that all main components can be imported correctly."""
    assert Agent is not None
    assert tool is not None
    assert Tool is not None
    assert InMemoryMemory is not None
    assert LLMProvider is not None

def test_agent_initialization():
    """Verify that an Agent can be initialized with basic parameters."""
    agent = Agent(
        name="TestAgent",
        model="gpt-4o-mini",
        instructions="You are a test agent."
    )
    assert agent.name == "TestAgent"
    assert agent.llm.model_name == "gpt-4o-mini"
