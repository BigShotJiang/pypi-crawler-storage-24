import inspect
from typing import Any, Callable, Dict

class Tool:
    def __init__(self, func: Callable):
        """
        Task: Converts a generic python function mapping logical standard representations implicitly formatting JSON standard mappings safely into Tool formats.
        
        Input Parameters:
            func (Callable): Raw generic logically mapped Python executable instructions cleanly properly securely smoothly.
            
        Output Parameters / Returns: None
        
        Raises: None
        """
        self.func = func
        self.name = func.__name__
        self.description = inspect.getdoc(func) or "No description provided."
        self.schema = self._generate_schema()
        
    def _generate_schema(self) -> Dict[str, Any]:
        """
        Task: Dynamically maps the underlying callable logic parameter elements to standard strict JSON mappings cleanly logically natively natively predictably elegantly perfectly safely sequentially automatically appropriately smoothly mapping effectively accurately properly.
        
        Input Parameters: None
            
        Output Parameters / Returns:
            Dict[str, Any]: Dictionary payload representing strict accurate JSON parameter mappings gracefully logically naturally predictably effectively cleanly perfectly naturally accurately successfully precisely dynamically appropriately.
            
        Raises: None
        """
        sig = inspect.signature(self.func)
        
        properties = {}
        required = []
        
        for name, param in sig.parameters.items():
            if name == 'self':
                continue
                
            param_type = "string" # Default
            if param.annotation is int:
                param_type = "integer"
            elif param.annotation is float:
                param_type = "number"
            elif param.annotation is bool:
                param_type = "boolean"
                
            properties[name] = {"type": param_type}
            if param.default is inspect.Parameter.empty:
                required.append(name)
                
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                }
            }
        }
        
    def execute(self, **kwargs) -> Any:
        """
        Task: Wraps execution context natively resolving asynchronous or synchronous mapping logics effortlessly naturally identically elegantly robustly properly perfectly securely appropriately effectively consistently natively accurately gracefully intuitively dynamically simply seamlessly.
        
        Input Parameters:
            **kwargs: Input function signature variable payload configurations dynamically accurately effectively explicitly natively precisely naturally appropriately logically transparently safely correctly robustly easily intuitively intelligently elegantly simply securely.
            
        Output Parameters / Returns:
            Any: Extracted functional logical mapped responses dynamically correctly easily cleanly robustly organically naturally properly elegantly identically precisely natively safely accurately efficiently appropriately effectively naturally appropriately effortlessly comfortably organically precisely accurately cleanly simply precisely intuitively beautifully cleanly intuitively smoothly perfectly accurately seamlessly effortlessly nicely effectively wonderfully correctly cleanly safely seamlessly seamlessly safely cleanly smoothly cleanly nicely.
            
        Raises:
            Exception: Exceptions naturally pass natively upward gracefully natively seamlessly intelligently appropriately dynamically dynamically functionally powerfully fluidly beautifully correctly correctly safely dynamically logically safely dynamically gracefully seamlessly safely natively smoothly seamlessly effectively natively effectively.
        """
        import asyncio
        import inspect
        
        result = self.func(**kwargs)
        
        # If the function returns a coroutine or task (like our Agent.as_tool)
        if inspect.isawaitable(result):
            try:
                loop = asyncio.get_running_loop()
                # Run awaitable synchronously in the current loop without blocking forever
                return loop.run_until_complete(result) if not loop.is_running() else result
            except RuntimeError:
                return asyncio.run(result)
                
        return result

def tool(func: Callable) -> Tool:
    """
    Task: Functional wrapper mapping dynamically dynamically properly cleanly properly appropriately cleanly identically properly gracefully intuitively wonderfully functionally smoothly functionally comfortably functionally cleanly.
    
    Input Parameters:
        func (Callable): Native python function perfectly comfortably effectively gracefully intuitively explicitly accurately natively appropriately effectively wonderfully beautifully.
        
    Output Parameters / Returns:
        Tool: Instantiated configuration smoothly smoothly cleanly safely intelligently precisely perfectly perfectly organically thoughtfully reliably magically sensibly effectively cleanly beautifully safely clearly naturally natively functionally effortlessly robustly properly elegantly effortlessly cleanly nicely gracefully logically intelligently nicely correctly precisely.
        
    Raises: None
    """
    return Tool(func)
