"""Bundle unpacker — extracts and verifies APM bundles."""

import shutil
import sys
import tarfile
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from ..deps.lockfile import LockFile


@dataclass
class UnpackResult:
    """Result of an unpack operation."""

    extracted_dir: Path
    files: List[str] = field(default_factory=list)
    verified: bool = False


def unpack_bundle(
    bundle_path: Path,
    output_dir: Path = Path("."),
    skip_verify: bool = False,
    dry_run: bool = False,
) -> UnpackResult:
    """Extract and apply an APM bundle to a project directory.

    Additive-only semantics (v1): only writes files listed in the bundle's
    lockfile ``deployed_files``.  Never deletes existing files.  If a local
    file has the same name as a bundle file, the bundle file wins (overwrite).

    Args:
        bundle_path: Path to a ``.tar.gz`` archive or an unpacked bundle directory.
        output_dir: Target project directory to copy files into.
        skip_verify: If *True*, skip completeness verification against the lockfile.
        dry_run: If *True*, resolve the file list but write nothing to disk.

    Returns:
        :class:`UnpackResult` describing what was (or would be) extracted.

    Raises:
        FileNotFoundError: If the bundle's ``apm.lock`` is missing.
        ValueError: If verification finds files listed in the lockfile but
            absent from the bundle.
    """
    # 1. If archive, extract to temp dir
    cleanup_temp = False
    if bundle_path.is_file() and bundle_path.name.endswith(".tar.gz"):
        temp_dir = Path(tempfile.mkdtemp(prefix="apm-unpack-"))
        cleanup_temp = True
        try:
            with tarfile.open(bundle_path, "r:gz") as tar:
                # Security: prevent path traversal
                for member in tar.getmembers():
                    if member.name.startswith("/") or ".." in member.name:
                        raise ValueError(
                            f"Refusing to extract path-traversal entry: {member.name}"
                        )
                # filter="data" was added in Python 3.12; use it when available
                if sys.version_info >= (3, 12):
                    tar.extractall(temp_dir, filter="data")
                else:
                    tar.extractall(temp_dir)  # noqa: S202 — manual checks above
        except Exception:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise

        # Locate inner directory (the archive wraps a single top-level dir)
        children = list(temp_dir.iterdir())
        if len(children) == 1 and children[0].is_dir():
            source_dir = children[0]
        else:
            source_dir = temp_dir
    elif bundle_path.is_dir():
        source_dir = bundle_path
        temp_dir = None
    else:
        raise FileNotFoundError(f"Bundle not found or unsupported format: {bundle_path}")

    try:
        # 2. Read apm.lock from bundle
        lockfile_path = source_dir / "apm.lock"
        lockfile = LockFile.read(lockfile_path)
        if lockfile is None:
            if not lockfile_path.exists():
                raise FileNotFoundError(
                    "apm.lock not found in the bundle — the bundle may be incomplete."
                )
            raise FileNotFoundError(
                "apm.lock in the bundle could not be parsed — the bundle may be corrupt."
            )

        # Collect all deployed_files from lockfile
        all_deployed: list[str] = []
        for dep in lockfile.get_all_dependencies():
            all_deployed.extend(dep.deployed_files)

        # Deduplicate
        seen: set[str] = set()
        unique_files: list[str] = []
        for f in all_deployed:
            if f not in seen:
                seen.add(f)
                unique_files.append(f)

        # 3. Verify completeness
        verified = True
        if not skip_verify:
            missing = [
                f for f in unique_files if not (source_dir / f).exists()
            ]
            if missing:
                raise ValueError(
                    "Bundle verification failed — the following deployed files "
                    "are missing from the bundle:\n"
                    + "\n".join(f"  - {m}" for m in missing)
                )

        if skip_verify:
            verified = False

        # Dry-run: return file list without writing
        if dry_run:
            return UnpackResult(
                extracted_dir=bundle_path,
                files=unique_files,
                verified=verified,
            )

        # 4. Copy target files to output_dir (additive, no deletes)
        output_dir = Path(output_dir)
        output_dir_resolved = output_dir.resolve()
        for rel_path in unique_files:
            # Guard against absolute paths or path-traversal entries in deployed_files
            p = Path(rel_path)
            if p.is_absolute() or ".." in p.parts:
                raise ValueError(
                    f"Refusing to unpack unsafe path from bundle lockfile: {rel_path!r}"
                )
            dest = output_dir / rel_path
            if not dest.resolve().is_relative_to(output_dir_resolved):
                raise ValueError(
                    f"Refusing to unpack path that escapes output directory: {rel_path!r}"
                )
            src = source_dir / rel_path
            if not src.exists():
                continue  # skip_verify may allow missing files
            if src.is_dir():
                shutil.copytree(src, dest, dirs_exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)

        return UnpackResult(
            extracted_dir=bundle_path,
            files=unique_files,
            verified=verified,
        )
    finally:
        # Clean up temp dir if we created one
        if cleanup_temp and temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
