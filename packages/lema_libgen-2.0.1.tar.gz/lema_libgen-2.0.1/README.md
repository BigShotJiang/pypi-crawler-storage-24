<p align="center">
  <h1 align="center">📚 lema-libgen</h1>
  <p align="center">
    <em>A fully async Library Genesis scraper and downloader with proxy support, mirror management, and extensive book metadata extraction</em>
  </p>
  <p align="center">
    <a href="https://pypi.org/project/lema-libgen/"><img alt="PyPI" src="https://img.shields.io/pypi/v/lema-libgen?color=blue"></a>
    <a href="https://pypi.org/project/lema-libgen/"><img alt="Python" src="https://img.shields.io/pypi/pyversions/lema-libgen"></a>
    <img alt="License" src="https://img.shields.io/badge/license-MIT-green">
  </p>
</p>

---

## ✨ Features

- ⚡ **Fully async** - all methods are async using aiohttp
- 🔍 **Full-text search** with pagination support
- 📥 **Downloads** with automatic mirror fallback and progress display
- 🌐 **Proxy support** - HTTP, HTTPS, and SOCKS5 proxies
- 🔀 **Proxy pool** - random proxy selection from a pool for each request
- 🪞 **Mirror management** - discover, check availability, and prioritize mirrors
- 📊 **Rich metadata extraction** - title, authors, series, publisher, year, language, pages, size, extension, and cover images
- 🖼️ **Cover image support** - optionally fetch book covers during search
- 🔄 **Custom downloaders** - extensible downloader system for different mirror types
- ⚡ **Concurrent operations** - parallel mirror checking and multi-page search

---

## 📦 Installation

```bash
pip install lema-libgen
```

---

## 🚀 Quick Start

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()

    # Search for books
    books = await lg.search("python programming", results=25)

    for book in books[:5]:
        print(f"📖 {book.title}")
        print(f"   Authors: {', '.join(book.authors)}")
        print(f"   Size: {book.size} | Format: {book.extension}")
        print()

    # Download the first book
    if books:
        filepath = await lg.download(books[0], output_dir="./downloads")
        print(f"✅ Downloaded to: {filepath}")

asyncio.run(main())
```

---

## 🌐 Proxy Support

The library supports HTTP, HTTPS, and SOCKS5 proxies. You can set a single proxy, a pool of proxies, or override per-request.

### How Proxy Selection Works

The library uses a **priority chain** to determine which proxy to use for each request:

```
1. Explicit proxy parameter  →  proxy="http://specific:8080"
2. Empty string              →  proxy=""  (disables proxy)
3. Default proxy             →  LibGen(proxy="http://default:8080")
4. Random from pool          →  LibGen(proxy_pool=[...])
5. None                      →  No proxy
```

```python
# Priority example
lg = LibGen(
    proxy="http://default:8080",
    proxy_pool=["http://pool1:8080", "http://pool2:8080"]
)

# 1. Explicit - uses specific proxy
await lg.search("python", proxy="http://specific:8080")

# 2. Empty string - disables proxy for this request
await lg.search("python", proxy="")

# 3. None - falls back to default proxy, then pool
await lg.search("python")
```

### Single Proxy

```python
import asyncio
from libgen import LibGen

async def main():
    # Set default proxy for all requests
    lg = LibGen(proxy="http://127.0.0.1:8080")
    
    books = await lg.search("python")
    print(f"Found {len(books)} books")

asyncio.run(main())
```

### Proxy Pool (Rotation)

```python
import asyncio
from libgen import LibGen

async def main():
    # Pool of proxies - random one is used for each request
    lg = LibGen(proxy_pool=[
        "http://proxy1:8080",
        "http://user:pass@proxy2:8080",
        "socks5://proxy3:1080",
    ])
    
    # Each search uses a random proxy from the pool
    books = await lg.search("python")
    mirrors = await lg.get_mirrors()

asyncio.run(main())
```

### Per-Request Override

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen(proxy_pool=["http://proxy1:8080", "http://proxy2:8080"])
    
    # Use specific proxy for this request
    books = await lg.search("python", proxy="http://specific:8080")
    
    # Disable proxy for this request
    books = await lg.search("python", proxy="")
    
    # Use random proxy from pool
    books = await lg.search("python")

asyncio.run(main())
```

### Supported Proxy Formats

| Type | Format | Example |
|------|--------|---------|
| HTTP | `http://host:port` | `http://127.0.0.1:8080` |
| HTTP with auth | `http://user:pass@host:port` | `http://admin:secret@proxy.com:8080` |
| HTTPS | `https://host:port` | `https://proxy.example.com:443` |
| SOCKS5 | `socks5://host:port` | `socks5://127.0.0.1:1080` |
| SOCKS4 | `socks4://host:port` | `socks4://127.0.0.1:1080` |
| SOCKS5 with auth | `socks5://user:pass@host:port` | `socks5://user:pass@tor:1080` |

### ProxyManager Class

For advanced proxy management:

```python
from libgen import ProxyManager, ProxyConfig

# Create manager
pm = ProxyManager()

# Add proxies
pm.add_proxy("http://proxy1:8080")
pm.add_proxies(["socks5://proxy2:1080", "http://proxy3:8080"])

# Get random proxy (None if empty)
proxy = pm.get_random()

# Get all proxies
all_proxies = pm.get_all()

# Check count
count = pm.count()
is_empty = pm.is_empty()

# Check if URL is SOCKS
is_socks = ProxyManager.is_socks_url("socks5://host:1080")  # True

# ProxyConfig for individual proxy info
config = ProxyConfig(url="socks5://user:pass@proxy:1080")
print(config.proxy_type)  # "socks"
print(config.is_socks)    # True
```

### SOCKS5 Proxy Requirements

SOCKS proxies require the `aiohttp-socks` package (included in dependencies):

```python
# Internally, the library creates a ProxyConnector for SOCKS
from aiohttp_socks import ProxyConnector

connector = ProxyConnector.from_url("socks5://proxy:1080")
session = aiohttp.ClientSession(connector=connector)
```

### Proxy with Authentication

```python
import asyncio
from libgen import LibGen

async def main():
    # HTTP proxy with username/password
    lg = LibGen(proxy="http://user:password@proxy.example.com:8080")
    
    # SOCKS5 with authentication
    lg = LibGen(proxy="socks5://user:password@127.0.0.1:1080")
    
    # Using a pool with mixed auth
    lg = LibGen(proxy_pool=[
        "http://public:8080",
        "http://user1:pass1@private1.com:8080",
        "socks5://user2:pass2@private2.com:1080",
    ])

asyncio.run(main())
```

### Tor / Onion Routing

```python
import asyncio
from libgen import LibGen

async def main():
    # Connect through Tor (requires Tor running on localhost:9050)
    lg = LibGen(proxy="socks5://127.0.0.1:9050")
    
    books = await lg.search("python")
    print(f"Found {len(books)} books via Tor")

asyncio.run(main())
```

---

## 📖 API Reference

### Class: `LibGen`

Main async client for interacting with Library Genesis.

#### Constructor

```python
LibGen(
    main_url: str = "https://librarygenesis.net/",
    proxy: Optional[str] = None,
    proxy_pool: Optional[List[str]] = None,
    timeout: int = 15,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `main_url` | `str` | `"https://librarygenesis.net/"` | Main LibGen URL |
| `proxy` | `Optional[str]` | `None` | Default proxy for all requests |
| `proxy_pool` | `Optional[List[str]]` | `None` | List of proxies (random selection) |
| `timeout` | `int` | `15` | Request timeout in seconds |

---

### Search Methods

#### `search()`

Search for books on a single page.

```python
async def search(
    query: str,
    mirror: str = "https://libgen.li",
    results: int = 25,
    covers: bool = False,
    page: int = 1,
    proxy: Optional[str] = None,
) -> List[Book]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `query` | `str` | required | Search query |
| `mirror` | `str` | `"https://libgen.li"` | Mirror URL to search on |
| `results` | `int` | `25` | Results per page (25, 50, or 100) |
| `covers` | `bool` | `False` | Include book cover URLs |
| `page` | `int` | `1` | Page number |
| `proxy` | `Optional[str]` | `None` | Override proxy for this request |

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    
    # Basic search
    books = await lg.search("machine learning")
    
    # Search with covers
    books = await lg.search("data science", covers=True)
    
    # Search on specific mirror with proxy
    books = await lg.search("algorithms", mirror="https://libgen.is", proxy="http://proxy:8080")

asyncio.run(main())
```

---

#### `search_pages()`

Search across multiple pages concurrently.

```python
async def search_pages(
    query: str,
    mirror: str = "https://libgen.li",
    results: int = 25,
    covers: bool = False,
    start_page: int = 1,
    end_page: int = 1,
    proxy: Optional[str] = None,
) -> List[Book]
```

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    
    # Get results from pages 1-5 concurrently
    books = await lg.search_pages("python", start_page=1, end_page=5)
    print(f"Found {len(books)} books across 5 pages")

asyncio.run(main())
```

---

### Download Methods

#### `download()`

Download a book with automatic mirror fallback.

```python
async def download(
    book: Book,
    output_dir: str = ".",
    preferred_mirrors: Optional[List[str]] = None,
    proxy: Optional[str] = None,
) -> Optional[str]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `book` | `Book` | required | Book object to download |
| `output_dir` | `str` | `"."` | Directory to save the file |
| `preferred_mirrors` | `List[str]` | `None` | Mirror domains to prioritize |
| `proxy` | `Optional[str]` | `None` | Override proxy for this request |

**Returns:** Path to downloaded file or `None` on failure.

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    books = await lg.search("clean code")
    
    if books:
        # Download with preferred mirrors
        filepath = await lg.download(
            books[0],
            output_dir="./books",
            preferred_mirrors=["libgen.li", "libgen.is"]
        )
        
        if filepath:
            print(f"Downloaded to: {filepath}")

asyncio.run(main())
```

---

#### `get_download_url()`

Get the direct download URL from a mirror page.

```python
async def get_download_url(
    mirror_url: str,
    proxy: Optional[str] = None,
) -> Optional[str]
```

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    books = await lg.search("refactoring")
    
    if books and books[0].mirrors:
        direct_url = await lg.get_download_url(books[0].mirrors[0])
        print(f"Direct link: {direct_url}")

asyncio.run(main())
```

---

#### `get_download_urls()`

Get all direct download URLs for all mirrors of a book.

```python
async def get_download_urls(
    book: Book,
    proxy: Optional[str] = None,
) -> Dict[str, Optional[str]]
```

**Returns:** Dictionary mapping mirror URLs to direct download URLs.

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    books = await lg.search("functional programming")
    
    if books:
        urls = await lg.get_download_urls(books[0])
        for mirror, direct_url in urls.items():
            print(f"{mirror} -> {direct_url}")

asyncio.run(main())
```

---

### Mirror Methods

#### `get_mirrors()`

Discover available LibGen mirrors from the main page.

```python
async def get_mirrors(proxy: Optional[str] = None) -> List[str]
```

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    mirrors = await lg.get_mirrors()
    
    print(f"Found {len(mirrors)} mirrors:")
    for m in mirrors:
        print(f"  - {m}")

asyncio.run(main())
```

---

#### `check_mirrors()`

Check availability of mirrors with concurrent requests.

```python
async def check_mirrors(
    mirrors: Optional[List[str]] = None,
    proxy: Optional[str] = None,
) -> Dict[str, Dict[str, bool | str]]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mirrors` | `List[str]` | `None` | Mirrors to check (auto-discovers if `None`) |
| `proxy` | `Optional[str]` | `None` | Proxy to use for checks |

**Returns:** Dictionary with mirror status:
```python
{
    "https://libgen.li": {"working": True, "status": "HTTP 200"},
    "https://libgen.is": {"working": False, "status": "Timeout"},
}
```

**Example:**

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    status = await lg.check_mirrors()
    
    working = [m for m, info in status.items() if info["working"]]
    failed = [m for m, info in status.items() if not info["working"]]
    
    print(f"✅ Working: {len(working)}")
    print(f"❌ Failed: {len(failed)}")

asyncio.run(main())
```

---

### Data Class: `Book`

```python
@dataclass
class Book:
    id: str                      # Book identifier
    title: str                   # Book title
    authors: List[str]           # List of authors
    mirrors: List[str]           # Download mirror URLs
    timeadd: Optional[str]       # Date added (YYYY-MM-DD)
    series: Optional[str]        # Series name
    publisher: Optional[str]     # Publisher name
    year: Optional[str]          # Publication year
    language: Optional[str]      # Language code
    pages: Optional[str]         # Number of pages
    size: Optional[str]          # File size
    extension: Optional[str]     # File extension (pdf, epub, etc.)
    cover: Optional[str]         # Cover image URL
```

**Example:**

```python
book = books[0]

print(f"Title: {book.title}")
print(f"Authors: {', '.join(book.authors)}")
print(f"Series: {book.series or 'N/A'}")
print(f"Publisher: {book.publisher}")
print(f"Year: {book.year}")
print(f"Language: {book.language}")
print(f"Pages: {book.pages}")
print(f"Size: {book.size}")
print(f"Format: {book.extension}")
print(f"Cover: {book.cover}")
print(f"Mirrors: {len(book.mirrors)} available")
```

---

### Class: `ProxyManager`

Manage a pool of proxies with random selection.

```python
from libgen import ProxyManager

pm = ProxyManager(proxy_pool=["http://p1:8080", "socks5://p2:1080"])

# Get random proxy
proxy = pm.get_random()

# Add more proxies
pm.add_proxy("http://p3:8080")
pm.add_proxies(["http://p4:8080", "http://p5:8080"])

# Check if SOCKS
is_socks = ProxyManager.is_socks_url("socks5://host:1080")  # True

# Get all proxies
all_proxies = pm.get_all()

# Count
count = pm.count()
```

---

## 🔧 Advanced Usage

### Async Bulk Download

```python
import asyncio
from libgen import LibGen

async def download_multiple(books, output_dir, proxy=None):
    lg = LibGen(proxy=proxy)
    tasks = [lg.download(book, output_dir) for book in books]
    return await asyncio.gather(*tasks)

async def main():
    lg = LibGen()
    books = await lg.search_pages("python", start_page=1, end_page=3)
    books = books[:5]
    
    results = await download_multiple(books, "./library")
    successful = [r for r in results if r]
    print(f"Downloaded {len(successful)}/{len(books)} books")

asyncio.run(main())
```

### Custom Mirror Priority

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    books = await lg.search("design patterns")
    
    if books:
        # Prioritize specific mirrors for faster downloads
        filepath = await lg.download(
            books[0],
            output_dir="./books",
            preferred_mirrors=["libgen.li", "libgen.is", "library.lol"]
        )

asyncio.run(main())
```

### Filter by Format

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    books = await lg.search("javascript")
    
    # Get only PDF books
    pdf_books = [b for b in books if b.extension == "pdf"]
    
    # Get only EPUB books
    epub_books = [b for b in books if b.extension == "epub"]
    
    # Get ebooks (epub, mobi, azw3, fb2)
    ebook_exts = {"epub", "mobi", "azw3", "fb2"}
    ebooks = [b for b in books if b.extension in ebook_exts]

asyncio.run(main())
```

### Working with Covers

```python
import asyncio
from libgen import LibGen

async def main():
    lg = LibGen()
    
    # Enable covers in search
    books = await lg.search("art history", covers=True)
    
    for book in books:
        if book.cover:
            print(f"📖 {book.title}")
            print(f"   Cover: {book.cover}")

asyncio.run(main())
```

### Rotating Proxies

```python
import asyncio
from libgen import LibGen

async def main():
    # Large proxy pool - each request uses a random proxy
    proxy_pool = [
        "http://proxy1:8080",
        "http://proxy2:8080",
        "socks5://proxy3:1080",
        "http://user:pass@proxy4:8080",
    ]
    
    lg = LibGen(proxy_pool=proxy_pool)
    
    # Each call uses a different random proxy
    books1 = await lg.search("python")
    books2 = await lg.search("java")
    mirrors = await lg.get_mirrors()

asyncio.run(main())
```

---

## 🛠️ Extending with Custom Downloaders

Create custom downloaders for new mirror types:

```python
import aiohttp
from typing import Optional
from libgen.downloaders import MirrorDownloader

class CustomDownloader(MirrorDownloader):
    def can_handle(self, url: str) -> bool:
        return "custom-mirror.com" in url
    
    async def get_download_url(
        self,
        session: aiohttp.ClientSession,
        url: str,
        timeout: int = 15,
        proxy: Optional[str] = None,
    ) -> Optional[str]:
        # Implement custom async logic
        async with session.get(url, proxy=proxy) as response:
            # Parse and return direct download URL
            return direct_download_url

# Register the downloader
lg = LibGen()
lg.downloaders.append(CustomDownloader())
```

---

## 📋 Utility Functions

Available in `libgen.utils`:

| Function | Description |
|----------|-------------|
| `sanitize_filename(name)` | Remove invalid characters from filenames |
| `parse_authors(text)` | Parse author string into list |
| `extract_domain(url)` | Extract domain from URL |
| `is_book_extension(filename)` | Check if file is a book format |
| `get_extension_category(ext)` | Get category (ebook/document/comics) |
| `dedupe_mirrors_by_domain(mirrors)` | Remove duplicate mirrors by domain |

---

## 📝 Supported File Formats

| Category | Extensions |
|----------|------------|
| **Ebooks** | epub, mobi, azw3, fb2, lit, oeb, prc, pdb, tcr |
| **Documents** | pdf, djvu, txt, rtf, doc, docx, chm, html, htm |
| **Comics** | cbr, cbz, cb7, cbt |

---

## ⚠️ Disclaimer

This library is for educational purposes only. Always respect copyright laws and the terms of service of the websites you access.

---

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

<p align="center">
  Made with ❤️ by <a href="https://github.com/lemantorus">lemantorus</a>
</p>
