import asyncio
import os
import tempfile
from unittest.mock import patch

import aiohttp
import pytest
from aioresponses import aioresponses

from libgen import LibGen
from libgen.downloaders.libgen import LibGenDownloader
from libgen.downloaders.randombook import RandomBookDownloader
from libgen.models import Book


class TestLibGenInit:
    def test_init_defaults(self) -> None:
        client = LibGen()
        assert client.main_url == "https://librarygenesis.net/"
        assert client.timeout == 15
        assert client.default_proxy is None
        assert len(client.downloaders) == 3

    def test_init_custom(self) -> None:
        client = LibGen(
            main_url="https://custom.url/",
            proxy="http://proxy:8080",
            timeout=30,
        )
        assert client.main_url == "https://custom.url/"
        assert client.timeout == 30
        assert client.default_proxy == "http://proxy:8080"

    def test_init_proxy_pool(self) -> None:
        client = LibGen(proxy_pool=["http://proxy1:8080", "http://proxy2:8080"])
        assert client.proxy_manager.count() == 2


class TestGetProxy:
    def test_get_proxy_explicit(self) -> None:
        client = LibGen(proxy_pool=["http://pool:8080"])
        result = client._get_proxy("http://explicit:8080")
        assert result == "http://explicit:8080"

    def test_get_proxy_empty_string(self) -> None:
        client = LibGen(proxy_pool=["http://pool:8080"])
        result = client._get_proxy("")
        assert result is None

    def test_get_proxy_default(self) -> None:
        client = LibGen(proxy="http://default:8080")
        result = client._get_proxy(None)
        assert result == "http://default:8080"

    def test_get_proxy_from_pool(self) -> None:
        client = LibGen(proxy_pool=["http://pool:8080"])
        result = client._get_proxy(None)
        assert result == "http://pool:8080"

    def test_get_proxy_none(self) -> None:
        client = LibGen()
        result = client._get_proxy(None)
        assert result is None

    def test_get_proxy_priority(self) -> None:
        client = LibGen(proxy="http://default:8080", proxy_pool=["http://pool:8080"])
        result = client._get_proxy("http://explicit:8080")
        assert result == "http://explicit:8080"


class TestCreateSession:
    @pytest.mark.asyncio
    async def test_create_session_regular(self) -> None:
        client = LibGen()
        session = client._create_session()
        assert isinstance(session, aiohttp.ClientSession)
        await session.close()

    @pytest.mark.asyncio
    async def test_create_session_socks(self) -> None:
        client = LibGen()
        session = client._create_session("socks5://proxy:1080")
        assert isinstance(session, aiohttp.ClientSession)
        await session.close()

    @pytest.mark.asyncio
    async def test_create_session_no_proxy(self) -> None:
        client = LibGen()
        session = client._create_session(None)
        assert isinstance(session, aiohttp.ClientSession)
        await session.close()


class TestGetDownloader:
    def test_get_downloader_libgen(self) -> None:
        client = LibGen()
        downloader = client._get_downloader("https://libgen.li/ads/12345")
        assert isinstance(downloader, LibGenDownloader)

    def test_get_downloader_randombook(self) -> None:
        client = LibGen()
        downloader = client._get_downloader("https://randombook.org/12345")
        assert isinstance(downloader, RandomBookDownloader)

    def test_get_downloader_libgen_pw(self) -> None:
        client = LibGen()
        downloader = client._get_downloader("https://libgen.pw/12345")
        assert isinstance(downloader, LibGenDownloader)

    def test_get_downloader_unknown(self) -> None:
        client = LibGen()
        downloader = client._get_downloader("https://unknown.com/12345")
        assert downloader is None


class TestParseResults:
    def test_parse_results_basic(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Book Title</b></td>
                <td>John Doe</td>
                <td>Publisher</td>
                <td>2023</td>
                <td>English</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert len(books) == 1
        assert books[0].title == "Book Title"
        assert books[0].authors == ["John Doe"]

    def test_parse_results_with_covers(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><img src="/cover.jpg" /></td>
                <td><b>Covered Book</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li", covers=True)
        assert len(books) == 1
        assert books[0].cover == "https://libgen.li/cover.jpg"

    def test_parse_results_cover_absolute_url(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><img src="https://cdn.example.com/cover.jpg" /></td>
                <td><b>Book</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li", covers=True)
        assert books[0].cover == "https://cdn.example.com/cover.jpg"

    def test_parse_results_empty(self) -> None:
        client = LibGen()
        html = "<html><body></body></html>"
        books = client._parse_results(html, "https://libgen.li")
        assert books == []

    def test_parse_results_no_tables(self) -> None:
        client = LibGen()
        html = "<html><body><p>No tables</p></body></html>"
        books = client._parse_results(html, "https://libgen.li")
        assert books == []

    def test_parse_results_single_table(self) -> None:
        client = LibGen()
        html = "<table><tr><td>Only one table</td></tr></table>"
        books = client._parse_results(html, "https://libgen.li")
        assert books == []

    def test_parse_row_minimal_cells(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Title</b></td>
                <td>Author</td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books == []

    def test_parse_row_full(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td>
                    <b>Main Title</b>
                    <a href="/edition.php?id=12345" title="Add/Edit: 2024-01-15 ID: 99999">Subtitle</a>
                    <i>Series Name</i>
                </td>
                <td>John Doe, Jane Smith</td>
                <td>Test Publisher</td>
                <td>2023</td>
                <td>English</td>
                <td>350</td>
                <td><a href="/file.php?id=12345">5 MB</a></td>
                <td>pdf</td>
                <td>
                    <a href="https://libgen.li/ads/1">Mirror 1</a>
                    <a href="/ads/2">Mirror 2</a>
                </td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert len(books) == 1
        book = books[0]
        assert "Main Title" in book.title
        assert book.series == "Series Name"
        assert book.authors == ["John Doe", "Jane Smith"]
        assert book.publisher == "Test Publisher"
        assert book.year == "2023"
        assert book.language == "English"
        assert book.pages == "350"
        assert book.size == "5 MB"
        assert book.extension == "pdf"
        assert len(book.mirrors) == 2
        assert book.timeadd == "2024-01-15"

    def test_parse_row_series_extraction(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td>
                    <b>Title</b>
                    <i>Book Series #5</i>
                </td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].series == "Book Series #5"

    def test_parse_row_file_id_from_size_link(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Title</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td><a href="/file.php?id=98765">5 MB</a></td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].id == "98765"

    def test_parse_row_mirrors_absolute(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Title</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/12345">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].mirrors[0] == "https://libgen.li/ads/12345"

    def test_parse_row_mirrors_relative(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Title</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="/ads/12345">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].mirrors[0] == "https://libgen.li/ads/12345"

    def test_parse_row_no_authors(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Title</b></td>
                <td></td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].authors == []

    def test_parse_row_exception_handled(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr><td>Bad row with exception</td></tr>
            <tr>
                <td><b>Good Title</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert len(books) == 1
        assert books[0].title == "Good Title"

    def test_parse_results_exception_in_parse_row(self) -> None:
        client = LibGen()
        call_count = [0]

        original_parse_row = client._parse_row

        def mock_parse_row(row, base_url, covers=False):
            call_count[0] += 1
            if call_count[0] == 1:
                raise ValueError("Mock exception")
            return original_parse_row(row, base_url, covers)

        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Title 1</b></td>
                <td>Author</td>
                <td></td><td></td><td></td><td></td><td></td><td></td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
            <tr>
                <td><b>Title 2</b></td>
                <td>Author</td>
                <td></td><td></td><td></td><td></td><td></td><td></td>
                <td><a href="https://libgen.li/ads/2">Mirror</a></td>
            </tr>
        </table>
        """
        with patch.object(client, "_parse_row", side_effect=mock_parse_row):
            books = client._parse_results(html, "https://libgen.li")
        assert len(books) == 1
        assert books[0].title == "Title 2"

    def test_parse_row_title_subtitle_only(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><a href="/edition.php?id=1">Subtitle Only</a></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].title == "Subtitle Only"

    def test_parse_row_title_empty(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].title == ""

    def test_parse_row_series_inside_link(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td>
                    <b>Title</b>
                    <a href="/edition.php?id=1"><i>9781234567890</i></a>
                </td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        books = client._parse_results(html, "https://libgen.li")
        assert books[0].series is None


class TestGetMirrors:
    @pytest.mark.asyncio
    async def test_get_mirrors_success(self) -> None:
        client = LibGen()
        html = """
        <html>
        <a href="https://libgen.li">Link</a>
        <a href="https://libgen.rs">Link</a>
        </html>
        """
        with aioresponses() as m:
            m.get("https://librarygenesis.net/", status=200, body=html)
            result = await client.get_mirrors()
        assert len(result) == 2
        assert "https://libgen.li" in result
        assert "https://libgen.rs" in result

    @pytest.mark.asyncio
    async def test_get_mirrors_http_error(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://librarygenesis.net/", status=500)
            result = await client.get_mirrors()
        assert result == []

    @pytest.mark.asyncio
    async def test_get_mirrors_exception(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://librarygenesis.net/", exception=Exception("Network error"))
            result = await client.get_mirrors()
        assert result == []

    @pytest.mark.asyncio
    async def test_get_mirrors_with_proxy(self) -> None:
        client = LibGen()
        html = '<a href="https://libgen.li">Link</a>'
        with aioresponses() as m:
            m.get("https://librarygenesis.net/", status=200, body=html)
            result = await client.get_mirrors(proxy="http://proxy:8080")
        assert len(result) == 1


class TestCheckSingleMirror:
    @pytest.mark.asyncio
    async def test_check_single_mirror_success(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li", status=200)
            mirror, is_working, status = await client._check_single_mirror(
                "https://libgen.li"
            )
        assert mirror == "https://libgen.li"
        assert is_working is True
        assert status == "HTTP 200"

    @pytest.mark.asyncio
    async def test_check_single_mirror_failure(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li", status=404)
            mirror, is_working, status = await client._check_single_mirror(
                "https://libgen.li"
            )
        assert is_working is False
        assert status == "HTTP 404"

    @pytest.mark.asyncio
    async def test_check_single_mirror_timeout(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li", exception=asyncio.TimeoutError())
            mirror, is_working, status = await client._check_single_mirror(
                "https://libgen.li"
            )
        assert is_working is False
        assert status == "Timeout"

    @pytest.mark.asyncio
    async def test_check_single_mirror_client_error(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li", exception=aiohttp.ClientError())
            mirror, is_working, status = await client._check_single_mirror(
                "https://libgen.li"
            )
        assert is_working is False
        assert "Error" in status

    @pytest.mark.asyncio
    async def test_check_single_mirror_generic_exception(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li", exception=Exception("Generic error"))
            mirror, is_working, status = await client._check_single_mirror(
                "https://libgen.li"
            )
        assert is_working is False
        assert status == "Generic error"


class TestCheckMirrors:
    @pytest.mark.asyncio
    async def test_check_mirrors_concurrent(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li", status=200)
            m.get("https://libgen.rs", status=200)
            result = await client.check_mirrors(
                mirrors=["https://libgen.li", "https://libgen.rs"]
            )
        assert len(result) == 2
        assert result["https://libgen.li"]["working"] is True
        assert result["https://libgen.rs"]["working"] is True

    @pytest.mark.asyncio
    async def test_check_mirrors_none_uses_get_mirrors(self) -> None:
        client = LibGen()
        html = '<a href="https://libgen.li">Link</a>'
        with aioresponses() as m:
            m.get("https://librarygenesis.net/", status=200, body=html)
            m.get("https://libgen.li", status=200)
            result = await client.check_mirrors(mirrors=None)
        assert "https://libgen.li" in result

    @pytest.mark.asyncio
    async def test_check_mirrors_empty(self) -> None:
        client = LibGen()
        result = await client.check_mirrors(mirrors=[])
        assert result == {}


class TestSearch:
    @pytest.mark.asyncio
    async def test_search_success(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Python Book</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=python&res=25&page=1",
                status=200,
                body=html,
            )
            result = await client.search("python")
        assert len(result) == 1
        assert result[0].title == "Python Book"

    @pytest.mark.asyncio
    async def test_search_http_error(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get("https://libgen.li/index.php?req=python&res=25&page=1", status=500)
            result = await client.search("python")
        assert result == []

    @pytest.mark.asyncio
    async def test_search_exception(self) -> None:
        client = LibGen()
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=python&res=25&page=1",
                exception=Exception("Network error"),
            )
            result = await client.search("python")
        assert result == []

    @pytest.mark.asyncio
    async def test_search_with_covers(self) -> None:
        client = LibGen()
        html = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><img src="/cover.jpg" /></td>
                <td><b>Book</b></td>
                <td>Author</td>
                <td>Pub</td>
                <td>2023</td>
                <td>EN</td>
                <td>100</td>
                <td>5 MB</td>
                <td>pdf</td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=python&res=25&page=1&covers=on",
                status=200,
                body=html,
            )
            result = await client.search("python", covers=True)
        assert result[0].cover is not None

    @pytest.mark.asyncio
    async def test_search_custom_params(self) -> None:
        client = LibGen()
        html = "<table><tr><td>Header</td></tr></table><table></table>"
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=test&res=50&page=2",
                status=200,
                body=html,
            )
            await client.search("test", results=50, page=2)
        assert True

    @pytest.mark.asyncio
    async def test_search_with_proxy(self) -> None:
        client = LibGen()
        html = "<table><tr><td>Header</td></tr></table><table></table>"
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=python&res=25&page=1",
                status=200,
                body=html,
            )
            await client.search("python", proxy="http://proxy:8080")
        assert True


class TestSearchPages:
    @pytest.mark.asyncio
    async def test_search_pages_multiple(self) -> None:
        client = LibGen()
        html1 = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Book 1</b></td>
                <td>Author</td>
                <td></td><td></td><td></td><td></td><td></td><td></td>
                <td><a href="https://libgen.li/ads/1">Mirror</a></td>
            </tr>
        </table>
        """
        html2 = """
        <table><tr><td>Header</td></tr></table>
        <table>
            <tr>
                <td><b>Book 2</b></td>
                <td>Author</td>
                <td></td><td></td><td></td><td></td><td></td><td></td>
                <td><a href="https://libgen.li/ads/2">Mirror</a></td>
            </tr>
        </table>
        """
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=python&res=25&page=1",
                status=200,
                body=html1,
            )
            m.get(
                "https://libgen.li/index.php?req=python&res=25&page=2",
                status=200,
                body=html2,
            )
            result = await client.search_pages("python", start_page=1, end_page=2)
        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_search_pages_single(self) -> None:
        client = LibGen()
        html = "<table><tr><td>Header</td></tr></table><table></table>"
        with aioresponses() as m:
            m.get(
                "https://libgen.li/index.php?req=test&res=25&page=1",
                status=200,
                body=html,
            )
            result = await client.search_pages("test", start_page=1, end_page=1)
        assert result == []


class TestGetDownloadUrl:
    @pytest.mark.asyncio
    async def test_get_download_url_with_downloader(self) -> None:
        client = LibGen()
        html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", status=200, body=html)
            result = await client.get_download_url("https://libgen.li/ads/12345")
        assert result == "https://files.libgen.li/get.php?md5=abc"

    @pytest.mark.asyncio
    async def test_get_download_url_no_downloader(self) -> None:
        client = LibGen()
        result = await client.get_download_url("https://unknown.com/12345")
        assert result is None


class TestGetDownloadUrls:
    @pytest.mark.asyncio
    async def test_get_download_urls_all_mirrors(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension=None,
            mirrors=[
                "https://libgen.li/ads/1",
                "https://libgen.rs/ads/1",
            ],
            cover=None,
        )
        html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with aioresponses() as m:
            m.get("https://libgen.li/ads/1", status=200, body=html)
            m.get("https://libgen.rs/ads/1", status=200, body=html)
            result = await client.get_download_urls(book)
        assert len(result) == 2
        assert result["https://libgen.li/ads/1"] is not None
        assert result["https://libgen.rs/ads/1"] is not None


class TestDownload:
    @pytest.mark.asyncio
    async def test_download_success(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        file_content = b"PDF content here"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    status=200,
                    body=file_content,
                    headers={"Content-Length": str(len(file_content))},
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is not None
            assert os.path.exists(result)
            with open(result, "rb") as f:
                assert f.read() == file_content

    @pytest.mark.asyncio
    async def test_download_http_error(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get("https://files.libgen.li/get.php?md5=abc", status=403)
                result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_timeout(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    exception=asyncio.TimeoutError(),
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_client_error(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    exception=aiohttp.ClientError(),
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_generic_exception(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    exception=Exception("Generic error"),
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_no_download_url(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = "<html><body>No download link</body></html>"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_preferred_mirrors(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=[
                "https://libgen.rs/ads/1",
                "https://libgen.li/ads/1",
            ],
            cover=None,
        )
        detail_html_li = (
            '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        )
        file_content = b"PDF content"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html_li)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    status=200,
                    body=file_content,
                    headers={"Content-Length": str(len(file_content))},
                )
                result = await client.download(
                    book, output_dir=tmpdir, preferred_mirrors=["libgen.li"]
                )
            assert result is not None

    @pytest.mark.asyncio
    async def test_download_fallback_to_next_mirror(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=[
                "https://libgen.li/ads/1",
                "https://libgen.rs/ads/1",
            ],
            cover=None,
        )
        detail_html_1 = "<html><body>No link</body></html>"
        detail_html_2 = '<a href="https://files.libgen.rs/get.php?md5=abc">Download</a>'
        file_content = b"PDF content"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html_1)
                m.get("https://libgen.rs/ads/1", status=200, body=detail_html_2)
                m.get(
                    "https://files.libgen.rs/get.php?md5=abc",
                    status=200,
                    body=file_content,
                    headers={"Content-Length": str(len(file_content))},
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is not None

    @pytest.mark.asyncio
    async def test_download_sanitizes_filename(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title='Test<>:"/\\|?*Book',
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        file_content = b"PDF content"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    status=200,
                    body=file_content,
                    headers={"Content-Length": str(len(file_content))},
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is not None
            assert "<" not in os.path.basename(result)
            assert ">" not in os.path.basename(result)

    @pytest.mark.asyncio
    async def test_download_default_extension(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension=None,
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        file_content = b"PDF content"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    status=200,
                    body=file_content,
                    headers={"Content-Length": str(len(file_content))},
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is not None
            assert result.endswith(".pdf")

    @pytest.mark.asyncio
    async def test_download_all_mirrors_fail(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1", "https://libgen.rs/ads/1"],
            cover=None,
        )
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=404)
                m.get("https://libgen.rs/ads/1", status=404)
                result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_file_raises_unexpected_exception(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                with patch.object(
                    client, "_download_file", side_effect=RuntimeError("Mock error")
                ):
                    result = await client.download(book, output_dir=tmpdir)
            assert result is None

    @pytest.mark.asyncio
    async def test_download_no_content_length(self) -> None:
        client = LibGen()
        book = Book(
            id="1",
            timeadd=None,
            title="Test Book",
            series=None,
            authors=[],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension="pdf",
            mirrors=["https://libgen.li/ads/1"],
            cover=None,
        )
        detail_html = '<a href="https://files.libgen.li/get.php?md5=abc">Download</a>'
        file_content = b"PDF content"
        with tempfile.TemporaryDirectory() as tmpdir:
            with aioresponses() as m:
                m.get("https://libgen.li/ads/1", status=200, body=detail_html)
                m.get(
                    "https://files.libgen.li/get.php?md5=abc",
                    status=200,
                    body=file_content,
                )
                result = await client.download(book, output_dir=tmpdir)
            assert result is not None
