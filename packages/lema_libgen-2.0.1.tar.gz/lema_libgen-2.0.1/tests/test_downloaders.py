import pytest
from aioresponses import aioresponses

from libgen.downloaders.libgen import LibGenDownloader
from libgen.downloaders.libgen_pw import LibGenPwDownloader
from libgen.downloaders.randombook import RandomBookDownloader


class TestLibGenDownloader:
    @pytest.fixture
    def downloader(self) -> LibGenDownloader:
        return LibGenDownloader()

    def test_can_handle_libgen_li(self, downloader: LibGenDownloader) -> None:
        assert downloader.can_handle("https://libgen.li/ads/12345") is True

    def test_can_handle_libgen_rs(self, downloader: LibGenDownloader) -> None:
        assert downloader.can_handle("https://libgen.rs/ads/12345") is True

    def test_can_handle_libgen_is(self, downloader: LibGenDownloader) -> None:
        assert downloader.can_handle("https://libgen.is/ads/12345") is True

    def test_can_handle_subdomain(self, downloader: LibGenDownloader) -> None:
        assert downloader.can_handle("https://sub.libgen.li/ads/12345") is True

    def test_can_handle_randombook(self, downloader: LibGenDownloader) -> None:
        assert downloader.can_handle("https://randombook.org/12345") is False

    def test_can_handle_other(self, downloader: LibGenDownloader) -> None:
        assert downloader.can_handle("https://example.com") is False

    @pytest.mark.asyncio
    async def test_get_download_url_absolute(
        self, downloader: LibGenDownloader
    ) -> None:
        html = '<html><body><a href="https://files.libgen.li/get.php?md5=abc">Download</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.li/ads/12345"
                )
            assert result == "https://files.libgen.li/get.php?md5=abc"

    @pytest.mark.asyncio
    async def test_get_download_url_relative(
        self, downloader: LibGenDownloader
    ) -> None:
        html = '<html><body><a href="get.php?md5=abc">Download</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.li/ads/12345"
                )
            assert result == "https://libgen.li/get.php?md5=abc"

    @pytest.mark.asyncio
    async def test_get_download_url_not_found(
        self, downloader: LibGenDownloader
    ) -> None:
        html = '<html><body><a href="/other">Other</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.li/ads/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_http_error(
        self, downloader: LibGenDownloader
    ) -> None:
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", status=404)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.li/ads/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_exception(
        self, downloader: LibGenDownloader
    ) -> None:
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", exception=Exception("Network error"))
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.li/ads/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_with_proxy(
        self, downloader: LibGenDownloader
    ) -> None:
        html = '<html><body><a href="https://files.libgen.li/get.php?md5=abc">Download</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.li/ads/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.li/ads/12345", proxy="http://proxy:8080"
                )
            assert result == "https://files.libgen.li/get.php?md5=abc"


class TestRandomBookDownloader:
    @pytest.fixture
    def downloader(self) -> RandomBookDownloader:
        return RandomBookDownloader()

    def test_can_handle_randombook(self, downloader: RandomBookDownloader) -> None:
        assert downloader.can_handle("https://randombook.org/12345") is True

    def test_can_handle_randombook_subdomain(
        self, downloader: RandomBookDownloader
    ) -> None:
        assert downloader.can_handle("https://sub.randombook.org/12345") is True

    def test_can_handle_other(self, downloader: RandomBookDownloader) -> None:
        assert downloader.can_handle("https://libgen.li/ads/12345") is False

    @pytest.mark.asyncio
    async def test_get_download_url_by_text(
        self, downloader: RandomBookDownloader
    ) -> None:
        html = '<html><body><a href="https://files.randombook.org/book.pdf">Download</a></body></html>'
        with aioresponses() as m:
            m.get("https://randombook.org/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result == "https://files.randombook.org/book.pdf"

    @pytest.mark.asyncio
    async def test_get_download_url_by_get_text(
        self, downloader: RandomBookDownloader
    ) -> None:
        html = '<html><body><a href="https://files.randombook.org/book.pdf">Get Book</a></body></html>'
        with aioresponses() as m:
            m.get("https://randombook.org/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result == "https://files.randombook.org/book.pdf"

    @pytest.mark.asyncio
    async def test_get_download_url_by_extension(
        self, downloader: RandomBookDownloader
    ) -> None:
        html = '<html><body><a href="https://files.randombook.org/book.pdf">Link</a></body></html>'
        with aioresponses() as m:
            m.get("https://randombook.org/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result == "https://files.randombook.org/book.pdf"

    @pytest.mark.asyncio
    async def test_get_download_url_by_epub_extension(
        self, downloader: RandomBookDownloader
    ) -> None:
        html = '<html><body><a href="https://files.randombook.org/book.epub">Link</a></body></html>'
        with aioresponses() as m:
            m.get("https://randombook.org/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result == "https://files.randombook.org/book.epub"

    @pytest.mark.asyncio
    async def test_get_download_url_not_found(
        self, downloader: RandomBookDownloader
    ) -> None:
        html = '<html><body><a href="/other">Other</a></body></html>'
        with aioresponses() as m:
            m.get("https://randombook.org/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_http_error(
        self, downloader: RandomBookDownloader
    ) -> None:
        with aioresponses() as m:
            m.get("https://randombook.org/12345", status=500)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_exception(
        self, downloader: RandomBookDownloader
    ) -> None:
        with aioresponses() as m:
            m.get("https://randombook.org/12345", exception=Exception("Network error"))
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://randombook.org/12345"
                )
            assert result is None


class TestLibGenPwDownloader:
    @pytest.fixture
    def downloader(self) -> LibGenPwDownloader:
        return LibGenPwDownloader()

    def test_can_handle_libgen_pw(self, downloader: LibGenPwDownloader) -> None:
        assert downloader.can_handle("https://libgen.pw/12345") is True

    def test_can_handle_other(self, downloader: LibGenPwDownloader) -> None:
        assert downloader.can_handle("https://libgen.li/ads/12345") is False

    @pytest.mark.asyncio
    async def test_get_download_url_absolute(
        self, downloader: LibGenPwDownloader
    ) -> None:
        html = '<html><body><a href="https://files.libgen.pw/download/12345">Get</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.pw/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.pw/12345"
                )
            assert result == "https://files.libgen.pw/download/12345"

    @pytest.mark.asyncio
    async def test_get_download_url_relative(
        self, downloader: LibGenPwDownloader
    ) -> None:
        html = '<html><body><a href="/download/item/12345">Get</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.pw/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.pw/12345"
                )
            assert result == "https://libgen.pw/download/item/12345"

    @pytest.mark.asyncio
    async def test_get_download_url_by_extension(
        self, downloader: LibGenPwDownloader
    ) -> None:
        html = '<html><body><a href="/files/book.pdf">Get</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.pw/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.pw/12345"
                )
            assert result == "https://libgen.pw/files/book.pdf"

    @pytest.mark.asyncio
    async def test_get_download_url_not_found(
        self, downloader: LibGenPwDownloader
    ) -> None:
        html = '<html><body><a href="/other">Other</a></body></html>'
        with aioresponses() as m:
            m.get("https://libgen.pw/12345", status=200, body=html)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.pw/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_http_error(
        self, downloader: LibGenPwDownloader
    ) -> None:
        with aioresponses() as m:
            m.get("https://libgen.pw/12345", status=403)
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.pw/12345"
                )
            assert result is None

    @pytest.mark.asyncio
    async def test_get_download_url_exception(
        self, downloader: LibGenPwDownloader
    ) -> None:
        with aioresponses() as m:
            m.get("https://libgen.pw/12345", exception=Exception("Network error"))
            import aiohttp

            async with aiohttp.ClientSession() as session:
                result = await downloader.get_download_url(
                    session, "https://libgen.pw/12345"
                )
            assert result is None
