from libgen.proxy import ProxyConfig, ProxyManager


class TestProxyConfig:
    def test_proxy_config_http_type(self) -> None:
        config = ProxyConfig(url="http://proxy.example.com:8080")
        assert config.proxy_type == "http"
        assert config.is_socks is False

    def test_proxy_config_http_with_auth(self) -> None:
        config = ProxyConfig(url="http://user:pass@proxy.example.com:8080")
        assert config.proxy_type == "http"
        assert config.is_socks is False

    def test_proxy_config_socks5_type(self) -> None:
        config = ProxyConfig(url="socks5://proxy.example.com:1080")
        assert config.proxy_type == "socks"
        assert config.is_socks is True

    def test_proxy_config_socks4_type(self) -> None:
        config = ProxyConfig(url="socks4://proxy.example.com:1080")
        assert config.proxy_type == "socks"
        assert config.is_socks is True

    def test_proxy_config_socks5_with_auth(self) -> None:
        config = ProxyConfig(url="socks5://user:pass@proxy.example.com:1080")
        assert config.proxy_type == "socks"
        assert config.is_socks is True


class TestProxyManager:
    def test_proxy_manager_empty_init(self) -> None:
        manager = ProxyManager()
        assert manager.is_empty() is True
        assert manager.count() == 0
        assert manager.get_random() is None
        assert manager.get_all() == []

    def test_proxy_manager_init_with_none(self) -> None:
        manager = ProxyManager(proxies=None)
        assert manager.is_empty() is True

    def test_proxy_manager_init_with_empty_list(self) -> None:
        manager = ProxyManager(proxies=[])
        assert manager.is_empty() is True

    def test_proxy_manager_with_proxies(self) -> None:
        manager = ProxyManager(proxies=["http://proxy1:8080", "http://proxy2:8080"])
        assert manager.count() == 2
        assert manager.is_empty() is False

    def test_proxy_manager_add_proxy(self) -> None:
        manager = ProxyManager()
        manager.add_proxy("http://proxy1:8080")
        assert manager.count() == 1
        assert "http://proxy1:8080" in manager.get_all()

    def test_proxy_manager_add_proxy_empty_string(self) -> None:
        manager = ProxyManager()
        manager.add_proxy("")
        manager.add_proxy("   ")
        assert manager.is_empty() is True

    def test_proxy_manager_add_proxy_whitespace(self) -> None:
        manager = ProxyManager()
        manager.add_proxy("  http://proxy1:8080  ")
        assert manager.count() == 1
        assert manager.get_all()[0] == "http://proxy1:8080"

    def test_proxy_manager_add_proxies(self) -> None:
        manager = ProxyManager()
        manager.add_proxies(["http://proxy1:8080", "http://proxy2:8080"])
        assert manager.count() == 2

    def test_proxy_manager_get_random_empty(self) -> None:
        manager = ProxyManager()
        assert manager.get_random() is None

    def test_proxy_manager_get_random_from_pool(self) -> None:
        proxies = ["http://proxy1:8080", "http://proxy2:8080", "http://proxy3:8080"]
        manager = ProxyManager(proxies=proxies)
        for _ in range(10):
            result = manager.get_random()
            assert result in proxies

    def test_proxy_manager_get_all(self) -> None:
        proxies = ["http://proxy1:8080", "socks5://proxy2:1080"]
        manager = ProxyManager(proxies=proxies)
        all_proxies = manager.get_all()
        assert len(all_proxies) == 2
        assert "http://proxy1:8080" in all_proxies
        assert "socks5://proxy2:1080" in all_proxies

    def test_proxy_manager_count(self) -> None:
        manager = ProxyManager(proxies=["http://proxy1:8080", "http://proxy2:8080"])
        assert manager.count() == 2
        manager.add_proxy("http://proxy3:8080")
        assert manager.count() == 3

    def test_proxy_manager_is_empty(self) -> None:
        manager = ProxyManager()
        assert manager.is_empty() is True
        manager.add_proxy("http://proxy1:8080")
        assert manager.is_empty() is False

    def test_is_socks_url_http(self) -> None:
        assert ProxyManager.is_socks_url("http://proxy.com:8080") is False
        assert ProxyManager.is_socks_url("https://proxy.com:8080") is False

    def test_is_socks_url_socks5(self) -> None:
        assert ProxyManager.is_socks_url("socks5://proxy.com:1080") is True

    def test_is_socks_url_socks4(self) -> None:
        assert ProxyManager.is_socks_url("socks4://proxy.com:1080") is True

    def test_proxy_manager_repr(self) -> None:
        manager = ProxyManager(proxies=["http://proxy1:8080", "http://proxy2:8080"])
        result = repr(manager)
        assert "ProxyManager" in result
        assert "2" in result
