from libgen.models import Book


class TestBook:
    def test_book_creation_all_fields(self, sample_book: Book) -> None:
        assert sample_book.id == "12345"
        assert sample_book.timeadd == "2024-01-15"
        assert sample_book.title == "Test Book Title"
        assert sample_book.series == "Test Series"
        assert sample_book.authors == ["John Doe", "Jane Smith"]
        assert sample_book.publisher == "Test Publisher"
        assert sample_book.year == "2023"
        assert sample_book.language == "English"
        assert sample_book.pages == "350"
        assert sample_book.size == "5 MB"
        assert sample_book.extension == "pdf"
        assert len(sample_book.mirrors) == 2
        assert sample_book.cover == "https://example.com/cover.jpg"

    def test_book_creation_minimal(self, sample_book_minimal: Book) -> None:
        assert sample_book_minimal.id == "999"
        assert sample_book_minimal.timeadd is None
        assert sample_book_minimal.title == "Minimal Book"
        assert sample_book_minimal.series is None
        assert sample_book_minimal.authors == ["Author One"]
        assert sample_book_minimal.publisher is None
        assert sample_book_minimal.year is None
        assert sample_book_minimal.language is None
        assert sample_book_minimal.pages is None
        assert sample_book_minimal.size is None
        assert sample_book_minimal.extension is None
        assert len(sample_book_minimal.mirrors) == 1
        assert sample_book_minimal.cover is None

    def test_book_repr_few_authors(self) -> None:
        book = Book(
            id="1",
            timeadd=None,
            title="Test",
            series=None,
            authors=["A", "B"],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension=None,
            mirrors=[],
            cover=None,
        )
        result = repr(book)
        assert "id='1'" in result
        assert "title='Test'" in result
        assert "authors=[A, B]" in result

    def test_book_repr_many_authors(self) -> None:
        book = Book(
            id="2",
            timeadd=None,
            title="Multi-Author",
            series=None,
            authors=["A", "B", "C", "D", "E"],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension=None,
            mirrors=[],
            cover=None,
        )
        result = repr(book)
        assert "authors=[A, B, C...]" in result

    def test_book_repr_exactly_three_authors(self) -> None:
        book = Book(
            id="3",
            timeadd=None,
            title="Three Authors",
            series=None,
            authors=["A", "B", "C"],
            publisher=None,
            year=None,
            language=None,
            pages=None,
            size=None,
            extension=None,
            mirrors=[],
            cover=None,
        )
        result = repr(book)
        assert "authors=[A, B, C]" in result
        assert "..." not in result
