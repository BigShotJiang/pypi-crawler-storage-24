from libgen.utils import (
    BOOK_EXTENSIONS_ALL,
    BOOK_EXTENSIONS_BY_FORMAT,
    BOOK_EXTENSIONS_COMMON,
    BOOK_EXTENSIONS_COMICS,
    BOOK_EXTENSIONS_DOCS,
    BOOK_EXTENSIONS_RARE,
    BOOK_EXTENSIONS_TUPLE,
    DEFAULT_MIRROR,
    dedupe_mirrors_by_domain,
    extract_domain,
    extract_mirrors_from_html,
    get_extension_category,
    is_book_extension,
    normalize_url,
    parse_authors,
    parse_size_and_file_id,
    resolve_url,
    sanitize_filename,
)


class TestBookExtensions:
    def test_book_extensions_common_contains_pdf(self) -> None:
        assert "pdf" in BOOK_EXTENSIONS_COMMON
        assert "epub" in BOOK_EXTENSIONS_COMMON
        assert "mobi" in BOOK_EXTENSIONS_COMMON

    def test_book_extensions_comics_contains_cbr(self) -> None:
        assert "cbr" in BOOK_EXTENSIONS_COMICS
        assert "cbz" in BOOK_EXTENSIONS_COMICS

    def test_book_extensions_docs_contains_docx(self) -> None:
        assert "doc" in BOOK_EXTENSIONS_DOCS
        assert "docx" in BOOK_EXTENSIONS_DOCS

    def test_book_extensions_rare_contains_chm(self) -> None:
        assert "chm" in BOOK_EXTENSIONS_RARE
        assert "lit" in BOOK_EXTENSIONS_RARE

    def test_book_extensions_all_combined(self) -> None:
        assert "pdf" in BOOK_EXTENSIONS_ALL
        assert "cbr" in BOOK_EXTENSIONS_ALL
        assert "docx" in BOOK_EXTENSIONS_ALL
        assert "lit" in BOOK_EXTENSIONS_ALL

    def test_book_extensions_tuple_is_sorted(self) -> None:
        assert BOOK_EXTENSIONS_TUPLE == tuple(sorted(BOOK_EXTENSIONS_ALL))

    def test_book_extensions_by_format_ebook(self) -> None:
        assert "epub" in BOOK_EXTENSIONS_BY_FORMAT["ebook"]
        assert "mobi" in BOOK_EXTENSIONS_BY_FORMAT["ebook"]

    def test_book_extensions_by_format_document(self) -> None:
        assert "pdf" in BOOK_EXTENSIONS_BY_FORMAT["document"]
        assert "docx" in BOOK_EXTENSIONS_BY_FORMAT["document"]

    def test_book_extensions_by_format_comics(self) -> None:
        assert "cbr" in BOOK_EXTENSIONS_BY_FORMAT["comics"]
        assert "cbz" in BOOK_EXTENSIONS_BY_FORMAT["comics"]


class TestIsBookExtension:
    def test_is_book_extension_pdf(self) -> None:
        assert is_book_extension("file.pdf") is True
        assert is_book_extension("document.PDF") is True

    def test_is_book_extension_epub(self) -> None:
        assert is_book_extension("book.epub") is True

    def test_is_book_extension_cbr(self) -> None:
        assert is_book_extension("comic.cbr") is True

    def test_is_book_extension_unknown(self) -> None:
        assert is_book_extension("file.exe") is False
        assert is_book_extension("image.png") is False

    def test_is_book_extension_with_url(self) -> None:
        assert is_book_extension("https://example.com/book.pdf") is True


class TestGetExtensionCategory:
    def test_get_extension_category_ebook(self) -> None:
        assert get_extension_category("epub") == "ebook"
        assert get_extension_category("mobi") == "ebook"
        assert get_extension_category(".azw3") == "ebook"

    def test_get_extension_category_document(self) -> None:
        assert get_extension_category("pdf") == "document"
        assert get_extension_category("docx") == "document"
        assert get_extension_category("txt") == "document"

    def test_get_extension_category_comics(self) -> None:
        assert get_extension_category("cbr") == "comics"
        assert get_extension_category("cbz") == "comics"

    def test_get_extension_category_unknown(self) -> None:
        assert get_extension_category("exe") is None
        assert get_extension_category("zip") is None


class TestSanitizeFilename:
    def test_sanitize_filename_removes_invalid(self) -> None:
        assert sanitize_filename('file<>:"/\\|?*name') == "filename"

    def test_sanitize_filename_truncates(self) -> None:
        long_name = "a" * 150
        result = sanitize_filename(long_name, max_length=50)
        assert len(result) == 50

    def test_sanitize_filename_default_length(self) -> None:
        long_name = "a" * 150
        result = sanitize_filename(long_name)
        assert len(result) == 100

    def test_sanitize_filename_preserves_valid(self) -> None:
        assert sanitize_filename("valid_filename-123") == "valid_filename-123"

    def test_sanitize_filename_empty(self) -> None:
        assert sanitize_filename("") == ""


class TestExtractDomain:
    def test_extract_domain_valid(self) -> None:
        assert extract_domain("https://libgen.li") == "libgen.li"
        assert extract_domain("https://libgen.li/path") == "libgen.li"
        assert extract_domain("http://example.com:8080") == "example.com"

    def test_extract_domain_subdomain(self) -> None:
        assert extract_domain("https://sub.example.com") == "sub.example.com"

    def test_extract_domain_lowercase(self) -> None:
        assert extract_domain("https://LIBGEN.LI") == "libgen.li"

    def test_extract_domain_invalid(self) -> None:
        assert extract_domain("not a url") is None
        assert extract_domain("") is None


class TestNormalizeUrl:
    def test_normalize_url_trailing_slash(self) -> None:
        assert normalize_url("https://example.com/") == "https://example.com"
        assert normalize_url("https://example.com/path/") == "https://example.com/path"

    def test_normalize_url_trailing_comma(self) -> None:
        assert normalize_url("https://example.com,") == "https://example.com"
        assert normalize_url("https://example.com/path,") == "https://example.com/path"

    def test_normalize_url_multiple_trailing(self) -> None:
        assert normalize_url("https://example.com/,") == "https://example.com"
        assert normalize_url("https://example.com/,,/") == "https://example.com"

    def test_normalize_url_no_trailing(self) -> None:
        assert normalize_url("https://example.com") == "https://example.com"


class TestResolveUrl:
    def test_resolve_url_absolute(self) -> None:
        result = resolve_url("https://example.com", "https://other.com/file")
        assert result == "https://other.com/file"

    def test_resolve_url_relative(self) -> None:
        result = resolve_url("https://example.com/page/", "../file")
        assert result == "https://example.com/file"

    def test_resolve_url_root_relative(self) -> None:
        result = resolve_url("https://example.com/page/sub", "/file")
        assert result == "https://example.com/file"

    def test_resolve_url_same_dir(self) -> None:
        result = resolve_url("https://example.com/page/", "file.pdf")
        assert result == "https://example.com/page/file.pdf"


class TestExtractMirrorsFromHtml:
    def test_extract_mirrors_from_html(self) -> None:
        html = """
        <a href="https://libgen.li">Link 1</a>
        <a href="https://libgen.rs">Link 2</a>
        <a href="https://libgen.is/path">Link 3</a>
        """
        result = extract_mirrors_from_html(html)
        assert len(result) == 3
        assert "https://libgen.li" in result
        assert "https://libgen.rs" in result
        assert "https://libgen.is/path" in result

    def test_extract_mirrors_from_html_empty(self) -> None:
        assert extract_mirrors_from_html("") == []
        assert extract_mirrors_from_html("<html></html>") == []

    def test_extract_mirrors_from_html_no_matches(self) -> None:
        html = '<a href="https://example.com">Not LibGen</a>'
        assert extract_mirrors_from_html(html) == []

    def test_extract_mirrors_from_html_duplicates(self) -> None:
        html = """
        <a href="https://libgen.li">Link 1</a>
        <a href="https://libgen.li">Link 2</a>
        """
        result = extract_mirrors_from_html(html)
        assert len(result) == 1

    def test_extract_mirrors_from_html_case_insensitive(self) -> None:
        html = '<a href="https://LIBGEN.LI">Link</a>'
        result = extract_mirrors_from_html(html)
        assert len(result) == 1


class TestDedupeMirrorsByDomain:
    def test_dedupe_mirrors_by_domain(self) -> None:
        mirrors = [
            "https://libgen.li",
            "https://libgen.li/path",
            "https://libgen.rs",
        ]
        result = dedupe_mirrors_by_domain(mirrors)
        assert len(result) == 2
        assert result[0] == "https://libgen.li"
        assert result[1] == "https://libgen.rs"

    def test_dedupe_mirrors_by_domain_preserves_order(self) -> None:
        mirrors = [
            "https://libgen.rs",
            "https://libgen.li",
            "https://libgen.is",
        ]
        result = dedupe_mirrors_by_domain(mirrors)
        assert result[0] == "https://libgen.rs"
        assert result[1] == "https://libgen.li"
        assert result[2] == "https://libgen.is"

    def test_dedupe_mirrors_by_domain_empty(self) -> None:
        assert dedupe_mirrors_by_domain([]) == []

    def test_dedupe_mirrors_by_domain_no_duplicates(self) -> None:
        mirrors = ["https://libgen.li", "https://libgen.rs"]
        result = dedupe_mirrors_by_domain(mirrors)
        assert len(result) == 2


class TestParseAuthors:
    def test_parse_authors_comma(self) -> None:
        result = parse_authors("John Doe, Jane Smith")
        assert result == ["John Doe", "Jane Smith"]

    def test_parse_authors_semicolon(self) -> None:
        result = parse_authors("John Doe; Jane Smith")
        assert result == ["John Doe", "Jane Smith"]

    def test_parse_authors_mixed(self) -> None:
        result = parse_authors("John Doe, Jane Smith; Bob Wilson")
        assert result == ["John Doe", "Jane Smith", "Bob Wilson"]

    def test_parse_authors_empty(self) -> None:
        assert parse_authors("") == []

    def test_parse_authors_whitespace(self) -> None:
        result = parse_authors("  John Doe  ,  Jane Smith  ")
        assert result == ["John Doe", "Jane Smith"]

    def test_parse_authors_single(self) -> None:
        result = parse_authors("John Doe")
        assert result == ["John Doe"]


class TestParseSizeAndFileId:
    def test_parse_size_and_file_id_with_link(self) -> None:
        html = '<a href="/file.php?id=12345">5 MB</a>'
        size, file_id = parse_size_and_file_id(html)
        assert size == "5 MB"
        assert file_id == "12345"

    def test_parse_size_and_file_id_without_link(self) -> None:
        html = "<span>5 MB</span>"
        size, file_id = parse_size_and_file_id(html)
        assert size == "5 MB"
        assert file_id == ""

    def test_parse_size_and_file_id_empty(self) -> None:
        size, file_id = parse_size_and_file_id("")
        assert size == ""
        assert file_id == ""

    def test_parse_size_and_file_id_no_file_id(self) -> None:
        html = "<span>10 MB</span>"
        size, file_id = parse_size_and_file_id(html)
        assert size == "10 MB"
        assert file_id == ""


class TestDefaultMirror:
    def test_default_mirror_value(self) -> None:
        assert DEFAULT_MIRROR == "https://libgen.li"
