# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["ContactCreateParams"]


class ContactCreateParams(TypedDict, total=False):
    fields: Required[
        Union[
            Dict[
                str,
                Union[
                    str,
                    float,
                    bool,
                    SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    None,
                ],
            ]
        ]
    ]
    """Field values for the new contact.

    System fields use a `$` prefix (e.g. `$email`, `$name`); custom attributes use
    their bare slug. Note: `$name` is an object `{ firstName, lastName }`, not a
    plain string. Call the
    <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> to
    discover available fields and their types. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Union[Dict[str, Union[str, SequenceNotStr[str]]]]
    """Relationships to set on the new contact.

    System relationships use a `$` prefix (e.g. `$account`); custom relationships
    use their bare slug. Each value is a single entity ID or an array of IDs. Call
    the <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> to
    list available relationship keys.
    """
