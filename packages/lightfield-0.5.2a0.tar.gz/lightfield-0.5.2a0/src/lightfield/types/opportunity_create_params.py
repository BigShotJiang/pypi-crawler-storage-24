# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["OpportunityCreateParams"]


class OpportunityCreateParams(TypedDict, total=False):
    fields: Required[
        Union[
            Dict[
                str,
                Union[
                    str,
                    float,
                    bool,
                    SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    None,
                ],
            ]
        ]
    ]
    """Field values for the new opportunity.

    System fields use a `$` prefix (e.g. `$name`, `$stage`); custom attributes use
    their bare slug. Required: `$name` (string) and `$stage` (option ID or label).
    Fields of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or
    label from the field's `typeConfiguration.options` — call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to
    discover available fields and options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Required[Union[Dict[str, Union[str, SequenceNotStr[str]]]]]
    """Relationships to set on the new opportunity.

    System relationships use a `$` prefix (e.g. `$account`, `$owner`); custom
    relationships use their bare slug. `$account` is required. Each value is a
    single entity ID or an array of IDs. Call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to
    list available relationship keys.
    """
