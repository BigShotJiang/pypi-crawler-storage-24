# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    OpportunityListResponse,
    OpportunityCreateResponse,
    OpportunityUpdateResponse,
    OpportunityRetrieveResponse,
    OpportunityDefinitionsResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestOpportunity:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Lightfield) -> None:
        opportunity = client.opportunity.create(
            fields={"foo": "string"},
            relationships={"foo": "string"},
        )
        assert_matches_type(OpportunityCreateResponse, opportunity, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Lightfield) -> None:
        response = client.opportunity.with_raw_response.create(
            fields={"foo": "string"},
            relationships={"foo": "string"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = response.parse()
        assert_matches_type(OpportunityCreateResponse, opportunity, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Lightfield) -> None:
        with client.opportunity.with_streaming_response.create(
            fields={"foo": "string"},
            relationships={"foo": "string"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = response.parse()
            assert_matches_type(OpportunityCreateResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        opportunity = client.opportunity.retrieve(
            "id",
        )
        assert_matches_type(OpportunityRetrieveResponse, opportunity, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.opportunity.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = response.parse()
        assert_matches_type(OpportunityRetrieveResponse, opportunity, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.opportunity.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = response.parse()
            assert_matches_type(OpportunityRetrieveResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.opportunity.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Lightfield) -> None:
        opportunity = client.opportunity.update(
            id="id",
        )
        assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Lightfield) -> None:
        opportunity = client.opportunity.update(
            id="id",
            fields={"foo": "string"},
            relationships={
                "foo": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                }
            },
        )
        assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Lightfield) -> None:
        response = client.opportunity.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = response.parse()
        assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Lightfield) -> None:
        with client.opportunity.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = response.parse()
            assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.opportunity.with_raw_response.update(
                id="",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        opportunity = client.opportunity.list()
        assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        opportunity = client.opportunity.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.opportunity.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = response.parse()
        assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.opportunity.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = response.parse()
            assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_definitions(self, client: Lightfield) -> None:
        opportunity = client.opportunity.definitions()
        assert_matches_type(OpportunityDefinitionsResponse, opportunity, path=["response"])

    @parametrize
    def test_raw_response_definitions(self, client: Lightfield) -> None:
        response = client.opportunity.with_raw_response.definitions()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = response.parse()
        assert_matches_type(OpportunityDefinitionsResponse, opportunity, path=["response"])

    @parametrize
    def test_streaming_response_definitions(self, client: Lightfield) -> None:
        with client.opportunity.with_streaming_response.definitions() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = response.parse()
            assert_matches_type(OpportunityDefinitionsResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncOpportunity:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.create(
            fields={"foo": "string"},
            relationships={"foo": "string"},
        )
        assert_matches_type(OpportunityCreateResponse, opportunity, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightfield) -> None:
        response = await async_client.opportunity.with_raw_response.create(
            fields={"foo": "string"},
            relationships={"foo": "string"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = await response.parse()
        assert_matches_type(OpportunityCreateResponse, opportunity, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightfield) -> None:
        async with async_client.opportunity.with_streaming_response.create(
            fields={"foo": "string"},
            relationships={"foo": "string"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = await response.parse()
            assert_matches_type(OpportunityCreateResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.retrieve(
            "id",
        )
        assert_matches_type(OpportunityRetrieveResponse, opportunity, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.opportunity.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = await response.parse()
        assert_matches_type(OpportunityRetrieveResponse, opportunity, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.opportunity.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = await response.parse()
            assert_matches_type(OpportunityRetrieveResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.opportunity.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.update(
            id="id",
        )
        assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.update(
            id="id",
            fields={"foo": "string"},
            relationships={
                "foo": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                }
            },
        )
        assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLightfield) -> None:
        response = await async_client.opportunity.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = await response.parse()
        assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLightfield) -> None:
        async with async_client.opportunity.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = await response.parse()
            assert_matches_type(OpportunityUpdateResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.opportunity.with_raw_response.update(
                id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.list()
        assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.opportunity.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = await response.parse()
        assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.opportunity.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = await response.parse()
            assert_matches_type(OpportunityListResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_definitions(self, async_client: AsyncLightfield) -> None:
        opportunity = await async_client.opportunity.definitions()
        assert_matches_type(OpportunityDefinitionsResponse, opportunity, path=["response"])

    @parametrize
    async def test_raw_response_definitions(self, async_client: AsyncLightfield) -> None:
        response = await async_client.opportunity.with_raw_response.definitions()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        opportunity = await response.parse()
        assert_matches_type(OpportunityDefinitionsResponse, opportunity, path=["response"])

    @parametrize
    async def test_streaming_response_definitions(self, async_client: AsyncLightfield) -> None:
        async with async_client.opportunity.with_streaming_response.definitions() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            opportunity = await response.parse()
            assert_matches_type(OpportunityDefinitionsResponse, opportunity, path=["response"])

        assert cast(Any, response.is_closed) is True
