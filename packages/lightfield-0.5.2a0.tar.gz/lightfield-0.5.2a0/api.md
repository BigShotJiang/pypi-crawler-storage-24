# Account

Types:

```python
from lightfield.types import (
    AccountCreateResponse,
    AccountDefinitionsResponse,
    AccountListResponse,
    AccountRetrieveResponse,
    AccountUpdateResponse,
)
```

Methods:

- <code title="post /v1/accounts">client.account.<a href="./src/lightfield/resources/account.py">create</a>(\*\*<a href="src/lightfield/types/account_create_params.py">params</a>) -> <a href="./src/lightfield/types/account_create_response.py">AccountCreateResponse</a></code>
- <code title="get /v1/accounts/{id}">client.account.<a href="./src/lightfield/resources/account.py">retrieve</a>(id) -> <a href="./src/lightfield/types/account_retrieve_response.py">AccountRetrieveResponse</a></code>
- <code title="post /v1/accounts/{id}">client.account.<a href="./src/lightfield/resources/account.py">update</a>(id, \*\*<a href="src/lightfield/types/account_update_params.py">params</a>) -> <a href="./src/lightfield/types/account_update_response.py">AccountUpdateResponse</a></code>
- <code title="get /v1/accounts">client.account.<a href="./src/lightfield/resources/account.py">list</a>(\*\*<a href="src/lightfield/types/account_list_params.py">params</a>) -> <a href="./src/lightfield/types/account_list_response.py">AccountListResponse</a></code>
- <code title="get /v1/accounts/definitions">client.account.<a href="./src/lightfield/resources/account.py">definitions</a>() -> <a href="./src/lightfield/types/account_definitions_response.py">AccountDefinitionsResponse</a></code>

# Contact

Types:

```python
from lightfield.types import (
    ContactCreateResponse,
    ContactDefinitionsResponse,
    ContactListResponse,
    ContactRetrieveResponse,
    ContactUpdateResponse,
)
```

Methods:

- <code title="post /v1/contacts">client.contact.<a href="./src/lightfield/resources/contact.py">create</a>(\*\*<a href="src/lightfield/types/contact_create_params.py">params</a>) -> <a href="./src/lightfield/types/contact_create_response.py">ContactCreateResponse</a></code>
- <code title="get /v1/contacts/{id}">client.contact.<a href="./src/lightfield/resources/contact.py">retrieve</a>(id) -> <a href="./src/lightfield/types/contact_retrieve_response.py">ContactRetrieveResponse</a></code>
- <code title="post /v1/contacts/{id}">client.contact.<a href="./src/lightfield/resources/contact.py">update</a>(id, \*\*<a href="src/lightfield/types/contact_update_params.py">params</a>) -> <a href="./src/lightfield/types/contact_update_response.py">ContactUpdateResponse</a></code>
- <code title="get /v1/contacts">client.contact.<a href="./src/lightfield/resources/contact.py">list</a>(\*\*<a href="src/lightfield/types/contact_list_params.py">params</a>) -> <a href="./src/lightfield/types/contact_list_response.py">ContactListResponse</a></code>
- <code title="get /v1/contacts/definitions">client.contact.<a href="./src/lightfield/resources/contact.py">definitions</a>() -> <a href="./src/lightfield/types/contact_definitions_response.py">ContactDefinitionsResponse</a></code>

# Opportunity

Types:

```python
from lightfield.types import (
    OpportunityCreateResponse,
    OpportunityDefinitionsResponse,
    OpportunityListResponse,
    OpportunityRetrieveResponse,
    OpportunityUpdateResponse,
)
```

Methods:

- <code title="post /v1/opportunities">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">create</a>(\*\*<a href="src/lightfield/types/opportunity_create_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_create_response.py">OpportunityCreateResponse</a></code>
- <code title="get /v1/opportunities/{id}">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">retrieve</a>(id) -> <a href="./src/lightfield/types/opportunity_retrieve_response.py">OpportunityRetrieveResponse</a></code>
- <code title="post /v1/opportunities/{id}">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">update</a>(id, \*\*<a href="src/lightfield/types/opportunity_update_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_update_response.py">OpportunityUpdateResponse</a></code>
- <code title="get /v1/opportunities">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">list</a>(\*\*<a href="src/lightfield/types/opportunity_list_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_list_response.py">OpportunityListResponse</a></code>
- <code title="get /v1/opportunities/definitions">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">definitions</a>() -> <a href="./src/lightfield/types/opportunity_definitions_response.py">OpportunityDefinitionsResponse</a></code>

# Member

Types:

```python
from lightfield.types import MemberListResponse, MemberRetrieveResponse
```

Methods:

- <code title="get /v1/members/{id}">client.member.<a href="./src/lightfield/resources/member.py">retrieve</a>(id) -> <a href="./src/lightfield/types/member_retrieve_response.py">MemberRetrieveResponse</a></code>
- <code title="get /v1/members">client.member.<a href="./src/lightfield/resources/member.py">list</a>(\*\*<a href="src/lightfield/types/member_list_params.py">params</a>) -> <a href="./src/lightfield/types/member_list_response.py">MemberListResponse</a></code>

# WorkflowRun

Types:

```python
from lightfield.types import WorkflowRunStatusResponse
```

Methods:

- <code title="get /v1/workflowRun/{runId}/status">client.workflow_run.<a href="./src/lightfield/resources/workflow_run.py">status</a>(run_id) -> <a href="./src/lightfield/types/workflow_run_status_response.py">WorkflowRunStatusResponse</a></code>
