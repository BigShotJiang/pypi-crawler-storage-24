from __future__ import annotations

import sys
import unittest
from pathlib import Path

THIS_FILE = Path(__file__).resolve()
PROJECT_ROOT = THIS_FILE.parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "prophet-cli" / "src"))

from prophet_cli.cli import build_ir
from prophet_cli.cli import build_generated_outputs
from prophet_cli.cli import parse_ontology
from prophet_cli.cli import validate_ontology
from prophet_cli.core.materialize import materialize_missing_ids


class DSLFeaturesTests(unittest.TestCase):
    def test_event_blocks_and_state_field_metadata_roundtrip_into_ir(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  id "ont_commerce_local"
  version "0.1.0"

  enum OrderStatus {
    id "enum_order_status"

    value Created {
      id "enumv_order_status_created"
    }

    value Approved {
      id "enumv_order_status_approved"
    }
  }

  object Order {
    id "obj_order"

    field orderId {
      id "fld_order_order_id"
      type string
      key primary
    }

    field status {
      id "fld_order_status"
      type OrderStatus
      state
      initial Created
    }
  }

  event OrderApproved {
    id "evt_order_approved"

    field order {
      id "fld_evt_order_approved_order"
      type ref(Order)
    }
  }

  action approveOrder {
    id "act_approve_order"

    input {
      id "ain_approve_order"

      field order {
        id "fld_ain_approve_order_order"
        type ref(Order)
      }
    }

    output event OrderApproved
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])

        ir = build_ir(ontology, {})
        obj = next(item for item in ir["objects"] if item["id"] == "obj_order")
        self.assertNotIn("states", obj)
        self.assertNotIn("transitions", obj)

        status_field = next(field for field in obj["fields"] if field["id"] == "fld_order_status")
        self.assertTrue(status_field["is_state_field"])
        self.assertEqual(status_field["initial_enum_value_id"], "enumv_order_status_created")

        event = next(item for item in ir["events"] if item["id"] == "evt_order_approved")
        self.assertNotIn("kind", event)

        action = next(item for item in ir["actions"] if item["id"] == "act_approve_order")
        self.assertEqual(action["output_event_id"], "evt_order_approved")

    def test_descriptions_and_composite_display_keys_roundtrip_into_ir(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  id "ont_commerce_local"
  name "Commerce Local"
  version "0.1.0"
  description "Commerce ontology for local order processing."

  object TenantOrder {
    id "obj_tenant_order"
    name "Tenant Order"
    description "Tenant-scoped order aggregate."
    key primary (tenantId, orderId)
    key display (externalCode)

    field tenantId {
      id "fld_tenant_order_tenant_id"
      name "Tenant ID"
      type string
      required
      description "Tenant identifier."
    }

    field orderId {
      id "fld_tenant_order_order_id"
      type string
      required
      documentation "Order identifier."
    }

    field externalCode {
      id "fld_tenant_order_external_code"
      name "External Code"
      type string
      optional
      description "Human-friendly lookup code."
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])

        ir = build_ir(ontology, {})
        self.assertEqual(ir["ontology"]["description"], "Commerce ontology for local order processing.")
        self.assertEqual(ir["ontology"]["display_name"], "Commerce Local")
        obj = next(item for item in ir["objects"] if item["id"] == "obj_tenant_order")
        self.assertEqual(obj["description"], "Tenant-scoped order aggregate.")
        self.assertEqual(obj["display_name"], "Tenant Order")
        self.assertEqual(
            obj["keys"]["primary"]["field_ids"],
            ["fld_tenant_order_tenant_id", "fld_tenant_order_order_id"],
        )
        self.assertEqual(
            obj["keys"]["display"]["field_ids"],
            ["fld_tenant_order_external_code"],
        )
        field_by_id = {field["id"]: field for field in obj["fields"]}
        self.assertEqual(field_by_id["fld_tenant_order_tenant_id"]["description"], "Tenant identifier.")
        self.assertEqual(field_by_id["fld_tenant_order_order_id"]["description"], "Order identifier.")
        self.assertEqual(field_by_id["fld_tenant_order_external_code"]["description"], "Human-friendly lookup code.")
        self.assertEqual(field_by_id["fld_tenant_order_tenant_id"]["display_name"], "Tenant ID")
        self.assertEqual(field_by_id["fld_tenant_order_external_code"]["display_name"], "External Code")

        contract = next(item for item in ir["query_contracts"] if item["object_id"] == "obj_tenant_order")
        self.assertEqual(contract["paths"]["get_by_id"], "/tenant_orders/{tenantId}/{orderId}")

    def test_name_metadata_rejects_empty_and_duplicate_values(self) -> None:
        empty_name = """
ontology CommerceLocal {
  version "0.1.0"
  name "   "
}
"""
        with self.assertRaisesRegex(Exception, "must not be empty"):
            parse_ontology(empty_name)

        duplicate_name = """
ontology CommerceLocal {
  version "0.1.0"
  object Order {
    name "Order"
    name "Order Duplicate"
    field orderId {
      type string
      key primary
    }
  }
}
"""
        with self.assertRaisesRegex(Exception, "duplicate name metadata"):
            parse_ontology(duplicate_name)

    def test_display_name_flows_to_turtle_and_openapi_hints(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  id "ont_commerce_local"
  name "Commerce Local"
  version "0.1.0"

  object Order {
    id "obj_order"
    name "Sales Order"

    field orderId {
      id "fld_order_order_id"
      name "Order ID"
      type string
      key primary
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])
        cfg = {
            "project": {"ontology_file": "ontology/local/main.prophet"},
            "generation": {
                "out_dir": "gen",
                "stack": {"id": "java_spring_jpa"},
                "targets": ["openapi", "turtle", "manifest"],
            },
        }
        ir = build_ir(ontology, cfg)
        outputs = build_generated_outputs(ir, cfg)

        turtle = outputs["gen/turtle/ontology.ttl"]
        self.assertIn('prophet:name "Commerce Local"', turtle)
        self.assertIn('prophet:name "Sales Order"', turtle)
        self.assertIn('prophet:name "Order ID"', turtle)
        self.assertIn('prophet:fieldKey "orderId"', turtle)

        openapi = outputs["gen/openapi/openapi.yaml"]
        self.assertIn("title: Sales Order", openapi)
        self.assertIn("x-prophet-display-name: Sales Order", openapi)
        self.assertIn("title: Order ID", openapi)
        self.assertIn("x-prophet-display-name: Order ID", openapi)

    def test_object_refs_require_single_field_primary_key_targets(self) -> None:
        ontology_text = """
ontology RefConstraint {
  id "ont_ref_constraint"
  version "0.1.0"

  object Parent {
    id "obj_parent"
    key primary (tenantId, parentId)

    field tenantId {
      id "fld_parent_tenant_id"
      type string
      required
    }

    field parentId {
      id "fld_parent_parent_id"
      type string
      required
    }
  }

  object Child {
    id "obj_child"
    field childId {
      id "fld_child_child_id"
      type string
      required
      key primary
    }
    field parent {
      id "fld_child_parent"
      type ref(Parent)
      required
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertTrue(any("single-field primary keys" in item for item in errors))

    def test_fields_default_to_required_when_modifier_is_omitted(self) -> None:
        ontology_text = """
ontology RequiredDefaults {
  version "0.1.0"

  object Customer {
    field customerId {
      type string
      key primary
    }

    field nickname {
      type string
      optional
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])

        customer = next(item for item in ontology.objects if item.name == "Customer")
        field_required = {field.name: field.required for field in customer.fields}
        self.assertTrue(field_required["customerId"])
        self.assertFalse(field_required["nickname"])

    def test_missing_ids_are_auto_generated_and_unique(self) -> None:
        ontology_text = """
ontology MinimalCommerce {
  version "0.1.0"

  object Order {
    field orderId {
      type string
      key primary
    }

    field notes {
      type string
      optional
    }
  }

  action createOrder {
    input {
      field notes {
        type string
        optional
      }
    }

    output {
      field order {
        type ref(Order)
      }
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])

        ir = build_ir(ontology, {})
        ids = [ir["ontology"]["id"]]
        ids.extend(item["id"] for item in ir.get("objects", []))
        for obj in ir.get("objects", []):
            ids.extend(field["id"] for field in obj.get("fields", []))
            ids.extend(state["id"] for state in obj.get("states", []))
            ids.extend(transition["id"] for transition in obj.get("transitions", []))
        ids.extend(item["id"] for item in ir.get("action_inputs", []))
        for shape in ir.get("action_inputs", []):
            ids.extend(field["id"] for field in shape.get("fields", []))
        ids.extend(item["id"] for item in ir.get("events", []))
        for event in ir.get("events", []):
            ids.extend(field["id"] for field in event.get("fields", []))
        ids.extend(item["id"] for item in ir.get("actions", []))

        self.assertTrue(all(ids))
        self.assertEqual(len(ids), len(set(ids)))

        input_names = {shape["name"] for shape in ir.get("action_inputs", [])}
        output_names = {event["name"] for event in ir.get("events", [])}
        self.assertIn("CreateOrder Command", input_names)
        self.assertIn("CreateOrder Result", output_names)

    def test_action_custom_name_drives_derived_input_and_result_names(self) -> None:
        ontology_text = """
ontology MinimalCommerce {
  version "0.1.0"

  object Order {
    field orderId {
      type string
      key primary
    }
  }

  action createOrder {
    input {
      field notes {
        type string
        optional
      }
    }

    output {
      field order {
        type ref(Order)
      }
    }

    name "Create Order"
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])

        ir = build_ir(ontology, {})
        input_names = {shape["name"] for shape in ir.get("action_inputs", [])}
        output_names = {event["name"] for event in ir.get("events", [])}
        self.assertIn("Create Order Command", input_names)
        self.assertIn("Create Order Result", output_names)

    def test_action_kind_lines_are_rejected(self) -> None:
        ontology_text = """
ontology MinimalCommerce {
  version "0.1.0"

  object Order {
    field orderId {
      type string
      key primary
    }
  }

  action createOrder {
    kind process

    input {
      field order {
        type ref(Order)
      }
    }

    output {
      field order {
        type ref(Order)
      }
    }
  }
}
"""
        with self.assertRaisesRegex(Exception, "no longer supports 'kind'"):
            parse_ontology(ontology_text)

    def test_enums_roundtrip_into_ir_and_openapi(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  version "0.1.0"

  enum OrderStatus {
    value Pending {
      name "Pending"
    }

    value Approved {
      name "Approved"
    }
  }

  object Order {
    field orderId {
      type string
      key primary
    }

    field status {
      type OrderStatus
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertEqual(errors, [])

        ir = build_ir(ontology, {})
        self.assertEqual(len(ir["enums"]), 1)
        self.assertEqual(ir["enums"][0]["name"], "OrderStatus")
        self.assertEqual([value["name"] for value in ir["enums"][0]["values"]], ["Pending", "Approved"])

        order = next(item for item in ir["objects"] if item["name"] == "Order")
        status_field = next(field for field in order["fields"] if field["name"] == "status")
        self.assertEqual(status_field["type"], {"kind": "enum", "target_enum_id": ir["enums"][0]["id"]})

        cfg = {
            "project": {"ontology_file": "ontology/local/main.prophet"},
            "generation": {
                "out_dir": "gen",
                "stack": {"id": "java_spring_jpa"},
                "targets": ["openapi", "spring_boot", "manifest"],
                "spring_boot": {"base_package": "com.example.prophet", "boot_version": "3.3"},
            },
        }
        outputs = build_generated_outputs(ir, cfg)
        openapi = outputs["gen/openapi/openapi.yaml"]
        self.assertIn("enum:", openapi)
        self.assertIn("- Pending", openapi)
        self.assertIn("- Approved", openapi)
        self.assertIn(
            "public enum OrderStatus",
            outputs["gen/spring-boot/src/main/java/com/example/prophet/commerce_local/generated/domain/OrderStatus.java"],
        )
        self.assertIn(
            "@Enumerated(EnumType.STRING)",
            outputs["gen/spring-boot/src/main/java/com/example/prophet/commerce_local/generated/persistence/OrderEntity.java"],
        )

    def test_enum_member_ids_are_auto_generated(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  version "0.1.0"

  enum OrderStatus {
    value Pending
  }
}
"""
        ontology = parse_ontology(ontology_text)
        self.assertEqual(validate_ontology(ontology), [])
        self.assertTrue(ontology.enums[0].id)
        self.assertTrue(ontology.enums[0].values[0].id)
        materialized_source, changed = materialize_missing_ids(ontology_text, ontology)
        self.assertTrue(changed)
        self.assertIn("value Pending {", materialized_source)
        self.assertIn('id "', materialized_source)

    def test_enum_names_collide_with_type_namespace(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  version "0.1.0"

  enum Status {
    value Pending {
    }
  }

  struct Status {
    field value {
      type string
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        errors = validate_ontology(ontology)
        self.assertTrue(any("type namespace name 'Status'" in item for item in errors))

    def test_state_field_must_reference_enum_and_declare_initial_value(self) -> None:
        non_enum_ontology = """
ontology CommerceLocal {
  version "0.1.0"

  object Order {
    field orderId {
      type string
      key primary
    }

    field status {
      type string
      state
      initial Pending
    }
  }
}
"""
        ontology = parse_ontology(non_enum_ontology)
        errors = validate_ontology(ontology)
        self.assertTrue(any("state field Order.status must use an enum type" in item for item in errors))

        missing_initial_ontology = """
ontology CommerceLocal {
  version "0.1.0"

  enum OrderStatus {
    value Pending
  }

  object Order {
    field orderId {
      type string
      key primary
    }

    field status {
      type OrderStatus
      state
    }
  }
}
"""
        ontology = parse_ontology(missing_initial_ontology)
        errors = validate_ontology(ontology)
        self.assertTrue(any("state field Order.status must declare an initial enum value" in item for item in errors))

    def test_field_name_state_is_allowed_as_a_normal_field_name(self) -> None:
        object_ontology = """
ontology CommerceLocal {
  version "0.1.0"

  object Order {
    field orderId {
      type string
      key primary
    }

    field state {
      type string
    }
  }
}
"""
        ontology = parse_ontology(object_ontology)
        self.assertEqual(validate_ontology(ontology), [])

        valid_object_ontology = """
ontology CommerceLocal {
  version "0.1.0"

  enum OrderStatus {
    value Pending
  }

  object Order {
    field orderId {
      type string
      key primary
    }

    field state {
      type OrderStatus
      state
      initial Pending
    }
  }
}
"""
        ontology = parse_ontology(valid_object_ontology)
        self.assertEqual(validate_ontology(ontology), [])

        struct_ontology = """
ontology CommerceLocal {
  version "0.1.0"

  struct ApprovalContext {
    field state {
      type string
    }
  }

  object Order {
    field orderId {
      type string
      key primary
    }
  }
}
"""
        ontology = parse_ontology(struct_ontology)
        self.assertEqual(validate_ontology(ontology), [])

    def test_autogenerated_event_ids_keep_signal_prefixes(self) -> None:
        ontology_text = """
ontology CommerceLocal {
  version "0.1.0"

  object Order {
    field orderId {
      type string
      key primary
    }
  }

  event PaymentCaptured {
    field order {
      type ref(Order)
    }
  }

  action createOrder {
    input {
      field order {
        type ref(Order)
      }
    }

    output {
      field order {
        type ref(Order)
      }
    }
  }
}
"""
        ontology = parse_ontology(ontology_text)
        materialized, changed = materialize_missing_ids(ontology_text, ontology)

        self.assertTrue(changed)

        self.assertIn('id "sig_payment_captured"', materialized)
        self.assertIn('id "fld_sig_payment_captured_order"', materialized)
        self.assertIn('id "sig_action_create_order"', materialized)
        self.assertIn('id "fld_sig_action_create_order_order"', materialized)

if __name__ == "__main__":
    unittest.main()
