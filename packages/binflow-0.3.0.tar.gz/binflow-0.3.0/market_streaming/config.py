"""Configuración centralizada del sistema de streaming de mercado."""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass, field


class Market(str, enum.Enum):
    """Mercados soportados de Binance."""

    SPOT = "spot"
    FUTURES_USD = "futures_usd"   # USD-M Futures
    FUTURES_COIN = "futures_coin"  # COIN-M Futures


MARKET_URLS: dict[Market, str] = {
    Market.SPOT: "wss://stream.binance.com:9443/ws",
    Market.FUTURES_USD: "wss://fstream.binance.com/ws",
    Market.FUTURES_COIN: "wss://dstream.binance.com/ws",
}

MARKET_REST_URLS: dict[Market, str] = {
    Market.SPOT: "https://api.binance.com",
    Market.FUTURES_USD: "https://fapi.binance.com",
    Market.FUTURES_COIN: "https://dapi.binance.com",
}

MARKET_DEPTH_PATHS: dict[Market, str] = {
    Market.SPOT: "/api/v3/depth",
    Market.FUTURES_USD: "/fapi/v1/depth",
    Market.FUTURES_COIN: "/dapi/v1/depth",
}


@dataclass(slots=True)
class StreamConfig:
    """Configuración completa del motor de WebSockets.

    Centraliza todos los parámetros operativos para evitar constantes
    dispersas por el código. Cada campo tiene un valor por defecto razonable
    para Binance.

    Para cambiar de mercado basta con pasar ``market``::

        StreamConfig(market=Market.FUTURES_USD)

    También se puede forzar una URL personalizada con ``base_url``,
    que tiene prioridad sobre ``market``.
    """

    # --- Mercado ---
    market: Market = Market.SPOT
    base_url: str = ""
    ping_interval_s: float = 20.0
    ping_timeout_s: float = 10.0

    # --- Cache ---
    max_recent_trades: int = 1000
    default_order_book_depth: int = 20

    # --- Reconexión ---
    reconnect_base_delay_s: float = 1.0
    reconnect_max_delay_s: float = 60.0
    reconnect_jitter_factor: float = 0.2
    max_reconnect_attempts: int = 0  # 0 = sin límite

    # --- Health ---
    stale_threshold_s: float = 30.0
    health_check_interval_s: float = 5.0

    # --- Logging ---
    log_level: int = field(default=logging.INFO)
    log_dir: str = "logs"
    log_max_bytes: int = 10 * 1024 * 1024  # 10 MB por archivo
    log_backup_count: int = 5               # maximo 5 archivos rotados

    def __post_init__(self) -> None:
        if not self.base_url:
            self.base_url = MARKET_URLS[self.market]

    def rest_depth_url(self, symbol: str, limit: int = 1000) -> str:
        """URL para GET depth snapshot de un simbolo."""
        base = MARKET_REST_URLS[self.market]
        path = MARKET_DEPTH_PATHS[self.market]
        return f"{base}{path}?symbol={symbol}&limit={limit}"
