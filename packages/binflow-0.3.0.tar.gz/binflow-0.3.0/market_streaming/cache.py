"""Cache en memoria thread-safe para datos de mercado.

El cache es el repositorio central de estado de mercado. Escrito desde el
thread asyncio (workers) y leído desde el thread principal (API pública).
Se protege con threading.Lock - las operaciones son O(1) por lo que el
contention es despreciable.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field

from .config import StreamConfig
from .models import (
    AggTrade,
    BookTicker,
    Kline,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    Ticker,
    Trade,
)


@dataclass
class _SymbolTradeData:
    """Datos de trades para un símbolo."""

    last: Trade | None = None
    recent: deque[Trade] = field(default_factory=deque)


@dataclass
class _SymbolAggTradeData:
    """Datos de trades agregados para un símbolo."""

    last: AggTrade | None = None
    recent: deque[AggTrade] = field(default_factory=deque)


class MarketDataCache:
    """Cache en memoria para trades y order books.

    Thread-safe mediante un Lock global. Las lecturas y escrituras son
    operaciones rápidas (O(1) amortizado) por lo que el Lock no es un
    cuello de botella en la práctica.
    """

    def __init__(self, config: StreamConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._trades: dict[str, _SymbolTradeData] = {}
        self._order_books: dict[str, OrderBookSnapshot] = {}
        self._agg_trades: dict[str, _SymbolAggTradeData] = {}
        self._klines: dict[str, dict[str, Kline]] = {}  # {symbol: {interval: kline}}
        self._tickers: dict[str, Ticker] = {}
        self._mini_tickers: dict[str, MiniTicker] = {}
        self._book_tickers: dict[str, BookTicker] = {}

    # ------------------------------------------------------------------
    # Escritura (llamado desde workers asyncio)
    # ------------------------------------------------------------------

    def update_trade(self, trade: Trade) -> None:
        """Registra un nuevo trade en el cache."""
        symbol = trade.symbol.upper()
        with self._lock:
            data = self._trades.get(symbol)
            if data is None:
                data = _SymbolTradeData(
                    recent=deque(maxlen=self._config.max_recent_trades)
                )
                self._trades[symbol] = data
            data.last = trade
            data.recent.append(trade)

    def update_order_book(self, snapshot: OrderBookSnapshot) -> None:
        """Reemplaza el snapshot del order book para un simbolo.

        Si ya existe un book con un lastUpdateId mayor o igual, solo se
        reemplaza si el snapshot nuevo viene marcado como is_synced y el
        existente no lo esta (el REST snapshot tiene prioridad sobre un
        book construido solo con diffs).
        Si ambos estan synced, no se retrocede.
        """
        symbol = snapshot.symbol.upper()
        with self._lock:
            existing = self._order_books.get(symbol)
            if existing is not None:
                if snapshot.last_update_id <= existing.last_update_id:
                    # Solo reemplazar si el snapshot trae sync y el existente no
                    if not (snapshot.is_synced and not existing.is_synced):
                        return
            self._order_books[symbol] = snapshot

    def apply_depth_update(
        self,
        symbol: str,
        bids: list[OrderBookLevel],
        asks: list[OrderBookLevel],
        last_update_id: int,
        *,
        max_depth: int | None = None,
        event_time_ms: int = 0,
        transaction_time_ms: int = 0,
        is_synced: bool = False,
    ) -> None:
        """Aplica una actualización incremental al order book.

        Si no existe snapshot previo, crea uno nuevo. Si el update_id no es
        posterior al actual, lo ignora (protección contra duplicados).
        Preserva las cadenas originales de precisión en cada nivel.

        Parameters
        ----------
        max_depth : int, opcional
            Profundidad maxima a retener. Si no se indica, usa el default
            del config. Los workers pasan su propio depth para que el cache
            respete la profundidad solicitada por cada stream.
        """
        symbol = symbol.upper()
        depth = max_depth or self._config.default_order_book_depth
        with self._lock:
            book = self._order_books.get(symbol)
            if book is None:
                book = OrderBookSnapshot(symbol=symbol)
                self._order_books[symbol] = book

            if last_update_id <= book.last_update_id:
                return

            # Mapas con (quantity, price_str, qty_str) para preservar strings
            bid_map: dict[float, OrderBookLevel] = {
                level.price: level for level in book.bids
            }
            for level in bids:
                if level.quantity == 0.0:
                    bid_map.pop(level.price, None)
                else:
                    bid_map[level.price] = level

            ask_map: dict[float, OrderBookLevel] = {
                level.price: level for level in book.asks
            }
            for level in asks:
                if level.quantity == 0.0:
                    ask_map.pop(level.price, None)
                else:
                    ask_map[level.price] = level

            book.bids = [
                v for _, v in sorted(bid_map.items(), reverse=True)[:depth]
            ]
            book.asks = [
                v for _, v in sorted(ask_map.items())[:depth]
            ]
            book.last_update_id = last_update_id
            book.timestamp = time.time()
            book.event_time_ms = event_time_ms
            book.transaction_time_ms = transaction_time_ms
            book.is_synced = book.is_synced or is_synced

    def update_agg_trade(self, agg_trade: AggTrade) -> None:
        """Registra un nuevo trade agregado en el cache."""
        symbol = agg_trade.symbol.upper()
        with self._lock:
            data = self._agg_trades.get(symbol)
            if data is None:
                data = _SymbolAggTradeData(
                    recent=deque(maxlen=self._config.max_recent_trades)
                )
                self._agg_trades[symbol] = data
            data.last = agg_trade
            data.recent.append(agg_trade)

    def update_kline(self, kline: Kline) -> None:
        """Registra o actualiza una kline en el cache."""
        symbol = kline.symbol.upper()
        with self._lock:
            intervals = self._klines.get(symbol)
            if intervals is None:
                intervals = {}
                self._klines[symbol] = intervals
            intervals[kline.interval] = kline

    def update_ticker(self, ticker: Ticker) -> None:
        """Registra o actualiza un ticker 24h en el cache."""
        symbol = ticker.symbol.upper()
        with self._lock:
            self._tickers[symbol] = ticker

    def update_mini_ticker(self, mini_ticker: MiniTicker) -> None:
        """Registra o actualiza un mini ticker 24h en el cache."""
        symbol = mini_ticker.symbol.upper()
        with self._lock:
            self._mini_tickers[symbol] = mini_ticker

    def update_book_ticker(self, book_ticker: BookTicker) -> None:
        """Registra o actualiza un book ticker en el cache."""
        symbol = book_ticker.symbol.upper()
        with self._lock:
            self._book_tickers[symbol] = book_ticker

    # ------------------------------------------------------------------
    # Lectura (llamado desde el thread principal)
    # ------------------------------------------------------------------

    def get_last_trade(self, symbol: str) -> Trade | None:
        """Devuelve el último trade para un símbolo, o None."""
        symbol = symbol.upper()
        with self._lock:
            data = self._trades.get(symbol)
            return data.last if data else None

    def get_recent_trades(self, symbol: str, limit: int = 100) -> list[Trade]:
        """Devuelve los últimos N trades para un símbolo."""
        symbol = symbol.upper()
        with self._lock:
            data = self._trades.get(symbol)
            if data is None:
                return []
            trades = list(data.recent)
            return trades[-limit:]

    def get_order_book(self, symbol: str) -> OrderBookSnapshot | None:
        """Devuelve el snapshot actual del order book, o None."""
        symbol = symbol.upper()
        with self._lock:
            book = self._order_books.get(symbol)
            if book is None:
                return None
            # Devolver copia para evitar mutación externa
            return OrderBookSnapshot(
                symbol=book.symbol,
                bids=list(book.bids),
                asks=list(book.asks),
                last_update_id=book.last_update_id,
                timestamp=book.timestamp,
                event_time_ms=book.event_time_ms,
                transaction_time_ms=book.transaction_time_ms,
                is_synced=book.is_synced,
            )

    def get_last_agg_trade(self, symbol: str) -> AggTrade | None:
        """Devuelve el ultimo trade agregado para un simbolo, o None."""
        symbol = symbol.upper()
        with self._lock:
            data = self._agg_trades.get(symbol)
            return data.last if data else None

    def get_recent_agg_trades(self, symbol: str, limit: int = 100) -> list[AggTrade]:
        """Devuelve los ultimos N trades agregados para un simbolo."""
        symbol = symbol.upper()
        with self._lock:
            data = self._agg_trades.get(symbol)
            if data is None:
                return []
            trades = list(data.recent)
            return trades[-limit:]

    def get_kline(self, symbol: str, interval: str = "1m") -> Kline | None:
        """Devuelve la ultima kline para un simbolo e intervalo, o None."""
        symbol = symbol.upper()
        with self._lock:
            intervals = self._klines.get(symbol)
            if intervals is None:
                return None
            return intervals.get(interval)

    def get_ticker(self, symbol: str) -> Ticker | None:
        """Devuelve el ticker 24h para un simbolo, o None."""
        symbol = symbol.upper()
        with self._lock:
            return self._tickers.get(symbol)

    def get_mini_ticker(self, symbol: str) -> MiniTicker | None:
        """Devuelve el mini ticker 24h para un simbolo, o None."""
        symbol = symbol.upper()
        with self._lock:
            return self._mini_tickers.get(symbol)

    def get_book_ticker(self, symbol: str) -> BookTicker | None:
        """Devuelve el book ticker para un simbolo, o None."""
        symbol = symbol.upper()
        with self._lock:
            return self._book_tickers.get(symbol)

    def get_symbols(self) -> list[str]:
        """Devuelve la lista de símbolos conocidos."""
        with self._lock:
            return list(
                set(
                    list(self._trades.keys())
                    + list(self._order_books.keys())
                    + list(self._agg_trades.keys())
                    + list(self._klines.keys())
                    + list(self._tickers.keys())
                    + list(self._mini_tickers.keys())
                    + list(self._book_tickers.keys())
                )
            )

    def clear(self) -> None:
        """Limpia todo el cache."""
        with self._lock:
            self._trades.clear()
            self._order_books.clear()
            self._agg_trades.clear()
            self._klines.clear()
            self._tickers.clear()
            self._mini_tickers.clear()
            self._book_tickers.clear()
