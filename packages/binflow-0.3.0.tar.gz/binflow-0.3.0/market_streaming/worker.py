"""Workers asyncio para conexiones WebSocket a Binance.

Cada worker gestiona uno o mas streams logicos (trade o depth).
Se encarga de: conectar, suscribir, recibir, parsear, alimentar el cache,
detectar errores y reconectar con backoff exponencial.

Jerarquia:
- _BaseStreamWorker: logica comun (lifecycle, reconnect, backoff)
- WebSocketStreamWorker: un simbolo por conexion
- CombinedStreamWorker: hasta 200 simbolos por conexion
"""

from __future__ import annotations

import abc
import asyncio
import json
import logging
import random
import time
from typing import TYPE_CHECKING

import websockets
from panzer import BinancePublicClient
from websockets.asyncio.client import ClientConnection

from .config import Market
from .exceptions import FatalStreamError
from .models import (
    AggTrade,
    BookTicker,
    Kline,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    Ticker,
    Trade,
)

if TYPE_CHECKING:
    from .cache import MarketDataCache
    from .config import StreamConfig

logger = logging.getLogger(__name__)

# Profundidades validas para el Partial Book Depth Stream de Binance.
# Cualquier otro valor usa el Diff Depth Stream (actualizaciones incrementales).
_PARTIAL_DEPTH_LEVELS = {5, 10, 20}

# ------------------------------------------------------------------
# Funciones de modulo (compartidas entre workers)
# ------------------------------------------------------------------

def _depth_stream_name(symbol: str, depth: int) -> str:
    """Devuelve el nombre de stream de depth correcto segun la profundidad."""
    if depth in _PARTIAL_DEPTH_LEVELS:
        return f"{symbol}@depth{depth}"
    return f"{symbol}@depth"


def _parse_book_levels(raw_levels: list) -> list[OrderBookLevel]:
    """Parsea niveles del order book preservando cadenas originales."""
    return [
        OrderBookLevel(
            price=float(p),
            quantity=float(q),
            price_str=p,
            quantity_str=q,
        )
        for p, q in raw_levels
    ]


def _build_trade(data: dict, symbol: str) -> Trade:
    """Construye un Trade a partir del JSON de Binance."""
    price_str = data["p"]
    qty_str = data["q"]
    price = float(price_str)
    quantity = float(qty_str)
    quote_quantity = price * quantity

    return Trade(
        symbol=symbol,
        trade_id=data["t"],
        price=price,
        quantity=quantity,
        quote_quantity=quote_quantity,
        buyer_maker=data["m"],
        timestamp_ms=data["T"],
        price_str=price_str,
        quantity_str=qty_str,
        quote_quantity_str=f"{quote_quantity:.8f}",
        is_best_match=data.get("M", True),
        event_time_ms=data.get("E", 0),
    )


def _build_agg_trade(data: dict, symbol: str) -> AggTrade:
    """Construye un AggTrade a partir del JSON de Binance."""
    price_str = data["p"]
    qty_str = data["q"]
    price = float(price_str)
    quantity = float(qty_str)
    return AggTrade(
        symbol=symbol,
        agg_trade_id=data["a"],
        price=price,
        quantity=quantity,
        first_trade_id=data["f"],
        last_trade_id=data["l"],
        timestamp_ms=data["T"],
        buyer_maker=data["m"],
        price_str=price_str,
        quantity_str=qty_str,
        event_time_ms=data.get("E", 0),
    )


def _build_kline(data: dict, symbol: str) -> Kline:
    """Construye una Kline a partir del JSON de Binance."""
    k = data["k"]
    return Kline(
        symbol=symbol,
        interval=k["i"],
        open_time_ms=k["t"],
        close_time_ms=k["T"],
        open=float(k["o"]),
        close=float(k["c"]),
        high=float(k["h"]),
        low=float(k["l"]),
        volume=float(k["v"]),
        quote_volume=float(k["q"]),
        trades=k["n"],
        taker_buy_volume=float(k["V"]),
        taker_buy_quote_volume=float(k["Q"]),
        is_closed=k["x"],
        open_str=k["o"],
        close_str=k["c"],
        high_str=k["h"],
        low_str=k["l"],
        volume_str=k["v"],
        quote_volume_str=k["q"],
        taker_buy_volume_str=k["V"],
        taker_buy_quote_volume_str=k["Q"],
        event_time_ms=data.get("E", 0),
    )


def _build_ticker(data: dict, symbol: str) -> Ticker:
    """Construye un Ticker a partir del JSON de Binance."""
    return Ticker(
        symbol=symbol,
        price_change=float(data["p"]),
        price_change_pct=float(data["P"]),
        weighted_avg_price=float(data["w"]),
        prev_close_price=float(data["x"]),
        last_price=float(data["c"]),
        last_quantity=float(data["Q"]),
        best_bid_price=float(data["b"]),
        best_bid_quantity=float(data["B"]),
        best_ask_price=float(data["a"]),
        best_ask_quantity=float(data["A"]),
        open_price=float(data["o"]),
        high_price=float(data["h"]),
        low_price=float(data["l"]),
        volume=float(data["v"]),
        quote_volume=float(data["q"]),
        open_time_ms=data["O"],
        close_time_ms=data["C"],
        first_trade_id=data["F"],
        last_trade_id=data["L"],
        trade_count=data["n"],
        event_time_ms=data.get("E", 0),
        price_change_str=data["p"],
        price_change_pct_str=data["P"],
        weighted_avg_price_str=data["w"],
        prev_close_price_str=data["x"],
        last_price_str=data["c"],
        last_quantity_str=data["Q"],
        best_bid_price_str=data["b"],
        best_bid_quantity_str=data["B"],
        best_ask_price_str=data["a"],
        best_ask_quantity_str=data["A"],
        open_price_str=data["o"],
        high_price_str=data["h"],
        low_price_str=data["l"],
        volume_str=data["v"],
        quote_volume_str=data["q"],
    )


def _build_mini_ticker(data: dict, symbol: str) -> MiniTicker:
    """Construye un MiniTicker a partir del JSON de Binance."""
    return MiniTicker(
        symbol=symbol,
        close_price=float(data["c"]),
        open_price=float(data["o"]),
        high_price=float(data["h"]),
        low_price=float(data["l"]),
        volume=float(data["v"]),
        quote_volume=float(data["q"]),
        event_time_ms=data.get("E", 0),
        close_price_str=data["c"],
        open_price_str=data["o"],
        high_price_str=data["h"],
        low_price_str=data["l"],
        volume_str=data["v"],
        quote_volume_str=data["q"],
    )


def _build_book_ticker(data: dict, symbol: str) -> BookTicker:
    """Construye un BookTicker a partir del JSON de Binance."""
    return BookTicker(
        symbol=symbol,
        update_id=data["u"],
        best_bid_price=float(data["b"]),
        best_bid_quantity=float(data["B"]),
        best_ask_price=float(data["a"]),
        best_ask_quantity=float(data["A"]),
        best_bid_price_str=data["b"],
        best_bid_quantity_str=data["B"],
        best_ask_price_str=data["a"],
        best_ask_quantity_str=data["A"],
    )


def _filter_sync_diffs(
    buffer: list[dict],
    snapshot_update_id: int,
    market: Market,
) -> list[dict]:
    """Filtra y ordena diffs validos para aplicar despues del snapshot REST."""
    is_spot = (market == Market.SPOT)
    valid = []

    for diff in buffer:
        u = diff.get("u", 0)  # last update ID in event
        if is_spot:
            if u <= snapshot_update_id:
                continue
        else:
            if u < snapshot_update_id:
                continue
        valid.append(diff)

    valid.sort(key=lambda d: d.get("U", 0))

    # Validar continuidad del primer evento
    if valid:
        first = valid[0]
        U = first.get("U", 0)
        u = first.get("u", 0)
        if is_spot:
            expected = snapshot_update_id + 1
            if not (U <= expected <= u):
                logger.warning(
                    "Primer diff no coincide con snapshot "
                    "(U=%d, u=%d, expected=%d)",
                    U, u, expected,
                )
        else:
            if not (U <= snapshot_update_id <= u):
                logger.warning(
                    "Primer diff no coincide con snapshot "
                    "(U=%d, u=%d, snapshot=%d)",
                    U, u, snapshot_update_id,
                )

    return valid


# ------------------------------------------------------------------
# Base abstracta
# ------------------------------------------------------------------

class _BaseStreamWorker(abc.ABC):
    """Logica comun para workers de streaming WebSocket."""

    def __init__(
        self,
        stream_id: str,
        stream_type: StreamType,
        config: StreamConfig,
        cache: MarketDataCache,
        depth: int = 20,
        rest_client: BinancePublicClient | None = None,
        interval: str = "1m",
    ) -> None:
        self._stream_id = stream_id
        self._stream_type = stream_type
        self._config = config
        self._cache = cache
        self._depth = depth
        self._rest_client = rest_client
        self._interval = interval
        self._ws: ClientConnection | None = None
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._stop_event = asyncio.Event()
        # self.status lo define cada subclase en su __init__

    @property
    def stream_id(self) -> str:
        return self._stream_id

    # ------------------------------------------------------------------
    # Ciclo de vida
    # ------------------------------------------------------------------

    def start(self, loop: asyncio.AbstractEventLoop) -> None:
        """Lanza la tarea del worker en el event loop dado."""
        self._task = loop.create_task(
            self._run(), name=f"worker-{self._stream_id}"
        )

    async def stop(self) -> None:
        """Detiene el worker de forma limpia."""
        self._stop_event.set()
        ws = self._ws
        if ws is not None:
            self._ws = None
            try:
                await ws.close()
            except Exception:
                pass
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        self.status.state = StreamState.STOPPED
        logger.info("Stream %s detenido", self._stream_id)

    # ------------------------------------------------------------------
    # Bucle principal con reconexion
    # ------------------------------------------------------------------

    async def _run(self) -> None:
        """Bucle principal: conectar -> recibir -> reconectar."""
        attempt = 0
        while not self._stop_event.is_set():
            try:
                await self._connect_and_consume()
                if self._stop_event.is_set():
                    break
            except FatalStreamError as exc:
                logger.error(
                    "Error fatal en stream %s: %s", self._stream_id, exc
                )
                self.status.state = StreamState.FAILED
                self.status.error_count += 1
                break
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self.status.error_count += 1
                logger.warning(
                    "Error en stream %s (intento %d): %s",
                    self._stream_id, attempt, exc,
                )

            if self._stop_event.is_set():
                break

            attempt += 1
            max_attempts = self._config.max_reconnect_attempts
            if max_attempts > 0 and attempt > max_attempts:
                logger.error(
                    "Stream %s: maximo de reconexiones alcanzado (%d)",
                    self._stream_id, max_attempts,
                )
                self.status.state = StreamState.FAILED
                break

            delay = self._calculate_backoff(attempt)
            self.status.state = StreamState.RECONNECTING
            self.status.reconnect_count += 1
            logger.info(
                "Stream %s: reconectando en %.1fs (intento %d)",
                self._stream_id, delay, attempt,
            )

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(), timeout=delay
                )
                break  # stop_event se activo durante el wait
            except asyncio.TimeoutError:
                pass  # Timeout esperado, proceder a reconectar

        if self.status.state != StreamState.FAILED:
            self.status.state = StreamState.STOPPED

    def _calculate_backoff(self, attempt: int) -> float:
        """Calcula el delay de reconexion con backoff exponencial y jitter."""
        base = self._config.reconnect_base_delay_s
        max_delay = self._config.reconnect_max_delay_s
        delay = min(base * (2 ** (attempt - 1)), max_delay)
        jitter = delay * self._config.reconnect_jitter_factor
        return delay + random.uniform(-jitter, jitter)

    @abc.abstractmethod
    async def _connect_and_consume(self) -> None:
        """Abre conexion y consume mensajes. Implementada por subclases."""

    @abc.abstractmethod
    def _build_url(self) -> str:
        """Construye la URL del stream. Implementada por subclases."""


# ------------------------------------------------------------------
# Worker de stream individual (un simbolo por conexion)
# ------------------------------------------------------------------

class WebSocketStreamWorker(_BaseStreamWorker):
    """Worker que mantiene una conexion WebSocket a un stream de Binance.

    Disenado para ejecutarse como tarea asyncio de larga duracion. Gestiona
    su propio ciclo de reconexion y actualiza el cache de forma autonoma.
    """

    def __init__(
        self,
        stream_id: str,
        stream_type: StreamType,
        symbol: str,
        config: StreamConfig,
        cache: MarketDataCache,
        depth: int = 20,
        rest_client: BinancePublicClient | None = None,
        interval: str = "1m",
    ) -> None:
        self._symbol = symbol.lower()
        self._symbol_upper = symbol.upper()
        super().__init__(stream_id, stream_type, config, cache, depth, rest_client, interval=interval)

        self.status = StreamStatus(
            stream_id=stream_id,
            stream_type=stream_type,
            symbol=self._symbol_upper,
        )

        # Estado de sincronizacion para diff depth
        self._needs_sync = (
            stream_type == StreamType.DEPTH
            and depth not in _PARTIAL_DEPTH_LEVELS
        )
        self._synced = False

    def _build_url(self) -> str:
        """Construye la URL del stream segun el tipo."""
        if self._stream_type == StreamType.TRADE:
            stream_name = f"{self._symbol}@trade"
        elif self._stream_type == StreamType.DEPTH:
            stream_name = _depth_stream_name(self._symbol, self._depth)
        elif self._stream_type == StreamType.AGG_TRADE:
            stream_name = f"{self._symbol}@aggTrade"
        elif self._stream_type == StreamType.KLINE:
            stream_name = f"{self._symbol}@kline_{self._interval}"
        elif self._stream_type == StreamType.TICKER:
            stream_name = f"{self._symbol}@ticker"
        elif self._stream_type == StreamType.MINI_TICKER:
            stream_name = f"{self._symbol}@miniTicker"
        elif self._stream_type == StreamType.BOOK_TICKER:
            stream_name = f"{self._symbol}@bookTicker"
        else:
            raise FatalStreamError(
                f"Tipo de stream desconocido: {self._stream_type}"
            )
        return f"{self._config.base_url}/{stream_name}"

    async def _connect_and_consume(self) -> None:
        """Abre conexion, sincroniza si es necesario, y consume mensajes."""
        url = self._build_url()
        logger.info("Stream %s: conectando a %s", self._stream_id, url)

        if self._needs_sync:
            self._synced = False

        try:
            async with websockets.connect(
                url,
                ping_interval=self._config.ping_interval_s,
                ping_timeout=self._config.ping_timeout_s,
                close_timeout=5,
            ) as ws:
                self._ws = ws
                self.status.state = StreamState.RUNNING
                self.status.connected_at = time.time()
                logger.info("Stream %s: conexion establecida", self._stream_id)

                if self._needs_sync:
                    await self._sync_order_book(ws)

                async for raw_message in ws:
                    if self._stop_event.is_set():
                        break
                    self._process_message(raw_message)
        finally:
            self._ws = None

    # ------------------------------------------------------------------
    # Sincronizacion REST snapshot + diff depth
    # ------------------------------------------------------------------

    async def _sync_order_book(self, ws: ClientConnection) -> None:
        """Sincroniza el order book: REST snapshot via panzer + diffs buffeados."""
        if self._rest_client is None:
            logger.warning(
                "Stream %s: sin REST client, continuando sin sync",
                self._stream_id,
            )
            return

        logger.info("Stream %s: sincronizando order book", self._stream_id)

        # Lanzar REST en executor (panzer es sincrono) y buffear WS
        loop = asyncio.get_running_loop()
        rest_future = loop.run_in_executor(
            None, self._rest_client.depth,
            self._symbol_upper, self._depth,
        )

        buffer: list[dict] = []
        while not rest_future.done():
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=0.2)
                data = json.loads(raw)
                if data.get("e") == "depthUpdate":
                    buffer.append(data)
                self.status.message_count += 1
                self.status.last_message_at = time.time()
            except asyncio.TimeoutError:
                pass

        try:
            snapshot_data = rest_future.result()
        except Exception as exc:
            logger.warning(
                "Stream %s: snapshot REST fallo: %s, continuando sin sync",
                self._stream_id, exc,
            )
            return

        snapshot_update_id = snapshot_data["lastUpdateId"]
        logger.info(
            "Stream %s: snapshot REST obtenido (lastUpdateId=%d, buffer=%d diffs)",
            self._stream_id, snapshot_update_id, len(buffer),
        )

        # Aplicar snapshot (truncar al depth configurado)
        max_depth = self._depth
        bids = _parse_book_levels(snapshot_data.get("bids", [])[:max_depth])
        asks = _parse_book_levels(snapshot_data.get("asks", [])[:max_depth])
        snapshot = OrderBookSnapshot(
            symbol=self._symbol_upper,
            bids=bids,
            asks=asks,
            last_update_id=snapshot_update_id,
            timestamp=time.time(),
            is_synced=True,
        )
        self._cache.update_order_book(snapshot)

        # Aplicar diffs filtrados
        valid_diffs = _filter_sync_diffs(
            buffer, snapshot_update_id, self._config.market
        )
        for diff in valid_diffs:
            diff_bids = _parse_book_levels(diff.get("b", []))
            diff_asks = _parse_book_levels(diff.get("a", []))
            self._cache.apply_depth_update(
                self._symbol_upper, diff_bids, diff_asks, diff.get("u", 0),
                max_depth=self._depth,
                event_time_ms=diff.get("E", 0),
                transaction_time_ms=diff.get("T", 0),
                is_synced=True,
            )

        self._synced = True
        logger.info(
            "Stream %s: sync completado (%d/%d diffs aplicados)",
            self._stream_id, len(valid_diffs), len(buffer),
        )

    # ------------------------------------------------------------------
    # Procesamiento de mensajes
    # ------------------------------------------------------------------

    def _process_message(self, raw: str | bytes) -> None:
        """Parsea y despacha un mensaje del WebSocket."""
        now = time.time()
        self.status.last_message_at = now
        self.status.message_count += 1

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Stream %s: mensaje JSON invalido", self._stream_id)
            self.status.error_count += 1
            return

        event_type = data.get("e")

        if event_type == "trade":
            self._handle_trade(data)
        elif event_type == "depthUpdate":
            self._handle_depth_update(data)
        elif event_type == "aggTrade":
            self._handle_agg_trade(data)
        elif event_type == "kline":
            self._handle_kline(data)
        elif event_type == "24hrTicker":
            self._handle_ticker(data)
        elif event_type == "24hrMiniTicker":
            self._handle_mini_ticker(data)
        elif "lastUpdateId" in data:
            self._handle_depth_snapshot(data)
        elif self._stream_type == StreamType.BOOK_TICKER:
            self._handle_book_ticker(data)

    def _handle_trade(self, data: dict) -> None:
        """Procesa un evento de trade."""
        trade = _build_trade(data, self._symbol_upper)
        self._cache.update_trade(trade)

    def _handle_depth_update(self, data: dict) -> None:
        """Procesa una actualizacion incremental del order book."""
        bids = _parse_book_levels(data.get("b", []))
        asks = _parse_book_levels(data.get("a", []))
        self._cache.apply_depth_update(
            self._symbol_upper, bids, asks, data.get("u", 0),
            max_depth=self._depth,
            event_time_ms=data.get("E", 0),
            transaction_time_ms=data.get("T", 0),
            is_synced=self._synced,
        )

    def _handle_depth_snapshot(self, data: dict) -> None:
        """Procesa un snapshot completo del order book (partial depth stream)."""
        max_depth = self._depth
        bids = _parse_book_levels(data.get("bids", [])[:max_depth])
        asks = _parse_book_levels(data.get("asks", [])[:max_depth])
        snapshot = OrderBookSnapshot(
            symbol=self._symbol_upper,
            bids=bids,
            asks=asks,
            last_update_id=data.get("lastUpdateId", 0),
            timestamp=time.time(),
            event_time_ms=data.get("E", 0),
            transaction_time_ms=data.get("T", 0),
        )
        self._cache.update_order_book(snapshot)

    def _handle_agg_trade(self, data: dict) -> None:
        """Procesa un evento de agg trade."""
        agg_trade = _build_agg_trade(data, self._symbol_upper)
        self._cache.update_agg_trade(agg_trade)

    def _handle_kline(self, data: dict) -> None:
        """Procesa un evento de kline."""
        kline = _build_kline(data, self._symbol_upper)
        self._cache.update_kline(kline)

    def _handle_ticker(self, data: dict) -> None:
        """Procesa un evento de ticker 24h."""
        ticker = _build_ticker(data, self._symbol_upper)
        self._cache.update_ticker(ticker)

    def _handle_mini_ticker(self, data: dict) -> None:
        """Procesa un evento de mini ticker 24h."""
        mini_ticker = _build_mini_ticker(data, self._symbol_upper)
        self._cache.update_mini_ticker(mini_ticker)

    def _handle_book_ticker(self, data: dict) -> None:
        """Procesa un evento de book ticker."""
        book_ticker = _build_book_ticker(data, self._symbol_upper)
        self._cache.update_book_ticker(book_ticker)


# ------------------------------------------------------------------
# Worker de streams combinados (multiples simbolos por conexion)
# ------------------------------------------------------------------

class CombinedStreamWorker(_BaseStreamWorker):
    """Worker que multiplexa varios streams en una sola conexion WebSocket.

    Usa el endpoint de combined streams de Binance para gestionar hasta
    MAX_STREAMS simbolos en una sola conexion TCP, eliminando el cuello
    de botella de conexiones individuales.

    El formato de mensajes combinados envuelve cada evento::

        {"stream": "btcusdt@trade", "data": {...evento original...}}
    """

    MAX_STREAMS = 200

    def __init__(
        self,
        worker_id: str,
        stream_type: StreamType,
        symbols: list[str],
        config: StreamConfig,
        cache: MarketDataCache,
        depth: int = 20,
        rest_client: BinancePublicClient | None = None,
        interval: str = "1m",
    ) -> None:
        self._symbols = [s.lower() for s in symbols]
        self._symbols_upper = [s.upper() for s in symbols]
        super().__init__(worker_id, stream_type, config, cache, depth, rest_client, interval=interval)

        self.status = StreamStatus(
            stream_id=worker_id,
            stream_type=stream_type,
            symbol=f"COMBINED({len(symbols)})",
        )

        self._request_id = 0

        # Estado de sincronizacion para diff depth por simbolo
        self._needs_sync = (
            stream_type == StreamType.DEPTH
            and depth not in _PARTIAL_DEPTH_LEVELS
        )
        self._synced_symbols: set[str] = set()

    def _build_url(self) -> str:
        """Construye la URL de combined streams."""
        if self._stream_type == StreamType.TRADE:
            stream_names = [f"{s}@trade" for s in self._symbols]
        elif self._stream_type == StreamType.DEPTH:
            stream_names = [
                _depth_stream_name(s, self._depth) for s in self._symbols
            ]
        elif self._stream_type == StreamType.AGG_TRADE:
            stream_names = [f"{s}@aggTrade" for s in self._symbols]
        elif self._stream_type == StreamType.KLINE:
            stream_names = [f"{s}@kline_{self._interval}" for s in self._symbols]
        elif self._stream_type == StreamType.TICKER:
            stream_names = [f"{s}@ticker" for s in self._symbols]
        elif self._stream_type == StreamType.MINI_TICKER:
            stream_names = [f"{s}@miniTicker" for s in self._symbols]
        elif self._stream_type == StreamType.BOOK_TICKER:
            stream_names = [f"{s}@bookTicker" for s in self._symbols]
        else:
            raise FatalStreamError(
                f"Tipo de stream desconocido: {self._stream_type}"
            )

        streams_path = "/".join(stream_names)
        base = self._config.base_url
        if base.endswith("/ws"):
            base = base[:-3]
        return f"{base}/stream?streams={streams_path}"

    async def _connect_and_consume(self) -> None:
        """Abre conexion combinada y consume mensajes.

        Para diff depth (depth > 20), lanza la sincronizacion REST en
        background mientras el loop de mensajes procesa normalmente.
        Los books se acumulan incrementalmente desde el primer segundo;
        cuando cada snapshot REST llega, reemplaza el book incremental
        con el estado correcto y marca el simbolo como synced.
        """
        url = self._build_url()
        logger.info(
            "Combined stream %s: conectando (%d streams)",
            self._stream_id, len(self._symbols),
        )

        if self._needs_sync:
            self._synced_symbols.clear()

        try:
            async with websockets.connect(
                url,
                ping_interval=self._config.ping_interval_s,
                ping_timeout=self._config.ping_timeout_s,
                close_timeout=5,
            ) as ws:
                self._ws = ws
                self.status.state = StreamState.RUNNING
                self.status.connected_at = time.time()
                logger.info(
                    "Combined stream %s: conexion establecida",
                    self._stream_id,
                )

                # Sync en background (no bloquea el loop de mensajes)
                sync_task = None
                if self._needs_sync:
                    sync_task = asyncio.create_task(
                        self._sync_order_books_background()
                    )

                try:
                    async for raw_message in ws:
                        if self._stop_event.is_set():
                            break
                        self._process_message(raw_message)
                finally:
                    if sync_task is not None and not sync_task.done():
                        sync_task.cancel()
                        try:
                            await sync_task
                        except asyncio.CancelledError:
                            pass
        finally:
            self._ws = None

    # ------------------------------------------------------------------
    # Sincronizacion REST snapshot en background (multi-simbolo)
    # ------------------------------------------------------------------

    async def _sync_order_books_background(self) -> None:
        """Obtiene REST snapshots en background via panzer y los aplica al cache.

        Usa bulk_depth() de panzer que gestiona rate limiting, batching y
        paralelismo automaticamente. El loop de mensajes sigue procesando
        diffs normalmente; cuando cada snapshot llega, el book se reemplaza
        con el estado correcto y se marca como synced.
        """
        if self._rest_client is None:
            logger.warning(
                "Combined stream %s: sin REST client, continuando sin sync",
                self._stream_id,
            )
            return

        logger.info(
            "Combined stream %s: sync background iniciado "
            "(%d simbolos, depth=%d)",
            self._stream_id, len(self._symbols), self._depth,
        )

        loop = asyncio.get_running_loop()

        try:
            # bulk_depth es sincrono (panzer gestiona rate limits internamente)
            results = await loop.run_in_executor(
                None,
                self._rest_client.bulk_depth,
                self._symbols_upper,
                self._depth,
            )
        except Exception as exc:
            logger.warning(
                "Combined stream %s: bulk_depth fallo: %s",
                self._stream_id, exc,
            )
            return

        synced = 0
        max_depth = self._depth
        for symbol, data in results.items():
            if self._stop_event.is_set():
                break
            try:
                snapshot_update_id = data["lastUpdateId"]
                bids = _parse_book_levels(data.get("bids", [])[:max_depth])
                asks = _parse_book_levels(data.get("asks", [])[:max_depth])
                snapshot = OrderBookSnapshot(
                    symbol=symbol,
                    bids=bids,
                    asks=asks,
                    last_update_id=snapshot_update_id,
                    timestamp=time.time(),
                    is_synced=True,
                )
                self._cache.update_order_book(snapshot)
                self._synced_symbols.add(symbol)
                synced += 1
            except Exception as exc:
                logger.warning(
                    "Combined stream %s: snapshot fallo para %s: %s",
                    self._stream_id, symbol, exc,
                )

        logger.info(
            "Combined stream %s: sync completado (%d/%d simbolos)",
            self._stream_id, synced, len(self._symbols),
        )

    # ------------------------------------------------------------------
    # Procesamiento de mensajes
    # ------------------------------------------------------------------

    def _process_message(self, raw: str | bytes) -> None:
        """Parsea y despacha un mensaje del combined stream."""
        now = time.time()
        self.status.last_message_at = now
        self.status.message_count += 1

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning(
                "Combined stream %s: mensaje JSON invalido",
                self._stream_id,
            )
            self.status.error_count += 1
            return

        # Combined streams envuelven en {stream, data}
        if "stream" in data and "data" in data:
            stream_name = data["stream"]
            inner = data["data"]
            event_type = inner.get("e")

            if event_type == "trade":
                self._handle_trade(inner)
            elif event_type == "depthUpdate":
                self._handle_depth_update(inner)
            elif event_type == "aggTrade":
                self._handle_agg_trade(inner)
            elif event_type == "kline":
                self._handle_kline(inner)
            elif event_type == "24hrTicker":
                self._handle_ticker(inner)
            elif event_type == "24hrMiniTicker":
                self._handle_mini_ticker(inner)
            elif "lastUpdateId" in inner:
                # Partial book depth no incluye "s", extraer del stream name
                symbol = stream_name.split("@")[0].upper()
                self._handle_depth_snapshot(inner, symbol)
            elif self._stream_type == StreamType.BOOK_TICKER:
                self._handle_book_ticker(inner)

    def _handle_trade(self, data: dict) -> None:
        """Procesa un evento de trade del combined stream."""
        trade = _build_trade(data, data["s"])
        self._cache.update_trade(trade)

    def _handle_depth_update(self, data: dict) -> None:
        """Procesa una actualizacion incremental del order book."""
        symbol_upper = data["s"]
        bids = _parse_book_levels(data.get("b", []))
        asks = _parse_book_levels(data.get("a", []))
        is_synced = symbol_upper in self._synced_symbols
        self._cache.apply_depth_update(
            symbol_upper, bids, asks, data.get("u", 0),
            max_depth=self._depth,
            event_time_ms=data.get("E", 0),
            transaction_time_ms=data.get("T", 0),
            is_synced=is_synced,
        )

    def _handle_depth_snapshot(
        self, data: dict, symbol: str | None = None,
    ) -> None:
        """Procesa un snapshot completo del order book."""
        symbol_upper = symbol or data.get("s", "UNKNOWN")
        max_depth = self._depth
        bids = _parse_book_levels(data.get("bids", [])[:max_depth])
        asks = _parse_book_levels(data.get("asks", [])[:max_depth])
        snapshot = OrderBookSnapshot(
            symbol=symbol_upper,
            bids=bids,
            asks=asks,
            last_update_id=data.get("lastUpdateId", 0),
            timestamp=time.time(),
            event_time_ms=data.get("E", 0),
            transaction_time_ms=data.get("T", 0),
        )
        self._cache.update_order_book(snapshot)

    def _handle_agg_trade(self, data: dict) -> None:
        """Procesa un evento de agg trade del combined stream."""
        agg_trade = _build_agg_trade(data, data["s"])
        self._cache.update_agg_trade(agg_trade)

    def _handle_kline(self, data: dict) -> None:
        """Procesa un evento de kline del combined stream."""
        kline = _build_kline(data, data["s"])
        self._cache.update_kline(kline)

    def _handle_ticker(self, data: dict) -> None:
        """Procesa un evento de ticker 24h del combined stream."""
        ticker = _build_ticker(data, data["s"])
        self._cache.update_ticker(ticker)

    def _handle_mini_ticker(self, data: dict) -> None:
        """Procesa un evento de mini ticker 24h del combined stream."""
        mini_ticker = _build_mini_ticker(data, data["s"])
        self._cache.update_mini_ticker(mini_ticker)

    def _handle_book_ticker(self, data: dict) -> None:
        """Procesa un evento de book ticker del combined stream."""
        book_ticker = _build_book_ticker(data, data.get("s", "UNKNOWN"))
        self._cache.update_book_ticker(book_ticker)

    # ------------------------------------------------------------------
    # Gestion dinamica de simbolos
    # ------------------------------------------------------------------

    def _stream_name_for_symbol(self, symbol: str) -> str:
        """Devuelve el nombre de stream para un simbolo segun el tipo."""
        s = symbol.lower()
        if self._stream_type == StreamType.TRADE:
            return f"{s}@trade"
        elif self._stream_type == StreamType.DEPTH:
            return _depth_stream_name(s, self._depth)
        elif self._stream_type == StreamType.AGG_TRADE:
            return f"{s}@aggTrade"
        elif self._stream_type == StreamType.KLINE:
            return f"{s}@kline_{self._interval}"
        elif self._stream_type == StreamType.TICKER:
            return f"{s}@ticker"
        elif self._stream_type == StreamType.MINI_TICKER:
            return f"{s}@miniTicker"
        elif self._stream_type == StreamType.BOOK_TICKER:
            return f"{s}@bookTicker"
        return f"{s}@{self._stream_type.value}"

    async def subscribe(self, symbol: str) -> None:
        """Suscribe un simbolo adicional en la conexion existente."""
        ws = self._ws
        if ws is None:
            raise RuntimeError("Worker no conectado")
        symbol_lower = symbol.lower()
        symbol_upper = symbol.upper()
        if symbol_lower in self._symbols:
            return
        stream_name = self._stream_name_for_symbol(symbol)
        self._request_id += 1
        msg = json.dumps({
            "method": "SUBSCRIBE",
            "params": [stream_name],
            "id": self._request_id,
        })
        await ws.send(msg)
        self._symbols.append(symbol_lower)
        self._symbols_upper.append(symbol_upper)
        self.status.symbol = f"COMBINED({len(self._symbols)})"
        logger.info(
            "Combined stream %s: suscrito a %s (total: %d)",
            self._stream_id, symbol_upper, len(self._symbols),
        )

    async def unsubscribe(self, symbol: str) -> None:
        """Desuscribe un simbolo de la conexion existente."""
        ws = self._ws
        if ws is None:
            raise RuntimeError("Worker no conectado")
        symbol_lower = symbol.lower()
        symbol_upper = symbol.upper()
        if symbol_lower not in self._symbols:
            return
        stream_name = self._stream_name_for_symbol(symbol)
        self._request_id += 1
        msg = json.dumps({
            "method": "UNSUBSCRIBE",
            "params": [stream_name],
            "id": self._request_id,
        })
        await ws.send(msg)
        self._symbols.remove(symbol_lower)
        self._symbols_upper.remove(symbol_upper)
        self._synced_symbols.discard(symbol_upper)
        self.status.symbol = f"COMBINED({len(self._symbols)})"
        logger.info(
            "Combined stream %s: desuscrito de %s (total: %d)",
            self._stream_id, symbol_upper, len(self._symbols),
        )
