"""Motor de WebSockets persistente para datos de mercado de Binance.

Proporciona streaming en tiempo real de trades y order book con reconexión
automática, cache en memoria thread-safe y observabilidad integrada.

Uso básico::

    from market_streaming import MarketStreamManager, StreamConfig

    manager = MarketStreamManager(StreamConfig())
    manager.start()
    manager.add_trade_stream("BTCUSDT")
    trade = manager.get_last_trade("BTCUSDT")
    manager.stop()
"""

from .cache import MarketDataCache
from .config import MARKET_DEPTH_PATHS, MARKET_REST_URLS, MARKET_URLS, Market, StreamConfig
from .exceptions import (
    FatalStreamError,
    ManagerNotRunningError,
    MarketStreamError,
    StreamAlreadyExistsError,
    StreamNotFoundError,
)
from .health import HealthMonitor
from .logging_config import setup_logging, teardown_logging
from .manager import MarketStreamManager
from .models import (
    AggTrade,
    BookTicker,
    Kline,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    SystemHealth,
    Ticker,
    Trade,
)
from .worker import CombinedStreamWorker, WebSocketStreamWorker

__all__ = [
    "MarketStreamManager",
    "MarketDataCache",
    "StreamConfig",
    "Market",
    "MARKET_URLS",
    "MARKET_REST_URLS",
    "MARKET_DEPTH_PATHS",
    "HealthMonitor",
    "WebSocketStreamWorker",
    "CombinedStreamWorker",
    "Trade",
    "AggTrade",
    "Kline",
    "Ticker",
    "MiniTicker",
    "BookTicker",
    "OrderBookLevel",
    "OrderBookSnapshot",
    "StreamState",
    "StreamStatus",
    "StreamType",
    "SystemHealth",
    "MarketStreamError",
    "StreamAlreadyExistsError",
    "StreamNotFoundError",
    "ManagerNotRunningError",
    "FatalStreamError",
    "setup_logging",
    "teardown_logging",
]
