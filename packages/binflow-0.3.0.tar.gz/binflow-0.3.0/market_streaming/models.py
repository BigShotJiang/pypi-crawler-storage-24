"""Modelos de dominio para datos de mercado y estado de streams.

Se usan dataclasses en lugar de pydantic porque estos modelos son poblados
por código interno (parsing de JSON de Binance), no por input de usuario.
dataclasses con __slots__ son más ligeros y no añaden dependencias externas.
"""

from __future__ import annotations

import enum
import time
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Datos de mercado
# ---------------------------------------------------------------------------

@dataclass(slots=True, frozen=True)
class Trade:
    """Un trade individual de Binance.

    Normalizado para ser compatible con la REST API de Binance
    (GET /api/v3/trades y GET /fapi/v1/trades). Contiene tanto los valores
    numéricos (float) como las cadenas originales de precisión (str) para
    mantener la fidelidad con la fuente.

    Mapping REST -> modelo::

        id           -> trade_id
        price        -> price / price_str
        qty          -> quantity / quantity_str
        quoteQty     -> quote_quantity / quote_quantity_str
        time         -> timestamp_ms
        isBuyerMaker -> buyer_maker
        isBestMatch  -> is_best_match  (solo Spot)
    """

    symbol: str
    trade_id: int
    price: float
    quantity: float
    quote_quantity: float
    buyer_maker: bool
    timestamp_ms: int
    price_str: str = ""
    quantity_str: str = ""
    quote_quantity_str: str = ""
    is_best_match: bool = True
    event_time_ms: int = 0

    def to_rest_format(self) -> dict:
        """Devuelve un dict con los mismos campos que GET /api/v3/trades."""
        return {
            "id": self.trade_id,
            "price": self.price_str or f"{self.price:.8f}",
            "qty": self.quantity_str or f"{self.quantity:.8f}",
            "quoteQty": self.quote_quantity_str or f"{self.quote_quantity:.8f}",
            "time": self.timestamp_ms,
            "isBuyerMaker": self.buyer_maker,
            "isBestMatch": self.is_best_match,
        }


@dataclass(slots=True, frozen=True)
class OrderBookLevel:
    """Un nivel de precio en el order book.

    Mantiene tanto los valores numéricos como las cadenas originales
    para preservar la precisión decimal de Binance.
    """

    price: float
    quantity: float
    price_str: str = ""
    quantity_str: str = ""

    def to_rest_format(self) -> list[str]:
        """Devuelve [price, qty] como cadenas, igual que la REST API."""
        return [
            self.price_str or f"{self.price:.8f}",
            self.quantity_str or f"{self.quantity:.8f}",
        ]


@dataclass(slots=True)
class OrderBookSnapshot:
    """Snapshot actual del order book para un símbolo.

    Normalizado para ser compatible con la REST API de Binance
    (GET /api/v3/depth y GET /fapi/v1/depth).
    """

    symbol: str
    bids: list[OrderBookLevel] = field(default_factory=list)
    asks: list[OrderBookLevel] = field(default_factory=list)
    last_update_id: int = 0
    timestamp: float = field(default_factory=time.time)
    event_time_ms: int = 0
    transaction_time_ms: int = 0
    is_synced: bool = False

    def to_rest_format(self) -> dict:
        """Devuelve un dict con los mismos campos que GET /api/v3/depth."""
        return {
            "lastUpdateId": self.last_update_id,
            "bids": [level.to_rest_format() for level in self.bids],
            "asks": [level.to_rest_format() for level in self.asks],
        }


@dataclass(slots=True, frozen=True)
class AggTrade:
    """Un trade agregado de Binance (stream @aggTrade).

    Agrupa uno o mas trades individuales ejecutados al mismo precio
    y en la misma orden. Reduce el volumen de mensajes respecto a @trade.
    """

    symbol: str
    agg_trade_id: int
    price: float
    quantity: float
    first_trade_id: int
    last_trade_id: int
    timestamp_ms: int
    buyer_maker: bool
    price_str: str = ""
    quantity_str: str = ""
    event_time_ms: int = 0

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /api/v3/aggTrades."""
        return {
            "a": self.agg_trade_id,
            "p": self.price_str or f"{self.price:.8f}",
            "q": self.quantity_str or f"{self.quantity:.8f}",
            "f": self.first_trade_id,
            "l": self.last_trade_id,
            "T": self.timestamp_ms,
            "m": self.buyer_maker,
            "M": True,
        }


@dataclass(slots=True, frozen=True)
class Kline:
    """Una vela (candlestick) de Binance (stream @kline_{interval}).

    Se actualiza en tiempo real mientras la vela esta abierta.
    Cuando is_closed=True, la vela es definitiva.
    """

    symbol: str
    interval: str
    open_time_ms: int
    close_time_ms: int
    open: float
    close: float
    high: float
    low: float
    volume: float
    quote_volume: float
    trades: int
    taker_buy_volume: float
    taker_buy_quote_volume: float
    is_closed: bool
    open_str: str = ""
    close_str: str = ""
    high_str: str = ""
    low_str: str = ""
    volume_str: str = ""
    quote_volume_str: str = ""
    taker_buy_volume_str: str = ""
    taker_buy_quote_volume_str: str = ""
    event_time_ms: int = 0

    def to_rest_format(self) -> list:
        """Devuelve un array compatible con GET /api/v3/klines."""
        return [
            self.open_time_ms,
            self.open_str or f"{self.open:.8f}",
            self.high_str or f"{self.high:.8f}",
            self.low_str or f"{self.low:.8f}",
            self.close_str or f"{self.close:.8f}",
            self.volume_str or f"{self.volume:.8f}",
            self.close_time_ms,
            self.quote_volume_str or f"{self.quote_volume:.8f}",
            self.trades,
            self.taker_buy_volume_str or f"{self.taker_buy_volume:.8f}",
            self.taker_buy_quote_volume_str or f"{self.taker_buy_quote_volume:.8f}",
            "0",
        ]


@dataclass(slots=True, frozen=True)
class Ticker:
    """Estadisticas 24h de Binance (stream @ticker).

    Incluye OHLC, volumen, mejor bid/ask y cambio de precio.
    """

    symbol: str
    price_change: float
    price_change_pct: float
    weighted_avg_price: float
    prev_close_price: float
    last_price: float
    last_quantity: float
    best_bid_price: float
    best_bid_quantity: float
    best_ask_price: float
    best_ask_quantity: float
    open_price: float
    high_price: float
    low_price: float
    volume: float
    quote_volume: float
    open_time_ms: int
    close_time_ms: int
    first_trade_id: int
    last_trade_id: int
    trade_count: int
    event_time_ms: int = 0
    price_change_str: str = ""
    price_change_pct_str: str = ""
    weighted_avg_price_str: str = ""
    prev_close_price_str: str = ""
    last_price_str: str = ""
    last_quantity_str: str = ""
    best_bid_price_str: str = ""
    best_bid_quantity_str: str = ""
    best_ask_price_str: str = ""
    best_ask_quantity_str: str = ""
    open_price_str: str = ""
    high_price_str: str = ""
    low_price_str: str = ""
    volume_str: str = ""
    quote_volume_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /api/v3/ticker/24hr."""
        return {
            "symbol": self.symbol,
            "priceChange": self.price_change_str or f"{self.price_change:.8f}",
            "priceChangePercent": self.price_change_pct_str or f"{self.price_change_pct:.3f}",
            "weightedAvgPrice": self.weighted_avg_price_str or f"{self.weighted_avg_price:.8f}",
            "prevClosePrice": self.prev_close_price_str or f"{self.prev_close_price:.8f}",
            "lastPrice": self.last_price_str or f"{self.last_price:.8f}",
            "lastQty": self.last_quantity_str or f"{self.last_quantity:.8f}",
            "bidPrice": self.best_bid_price_str or f"{self.best_bid_price:.8f}",
            "bidQty": self.best_bid_quantity_str or f"{self.best_bid_quantity:.8f}",
            "askPrice": self.best_ask_price_str or f"{self.best_ask_price:.8f}",
            "askQty": self.best_ask_quantity_str or f"{self.best_ask_quantity:.8f}",
            "openPrice": self.open_price_str or f"{self.open_price:.8f}",
            "highPrice": self.high_price_str or f"{self.high_price:.8f}",
            "lowPrice": self.low_price_str or f"{self.low_price:.8f}",
            "volume": self.volume_str or f"{self.volume:.8f}",
            "quoteVolume": self.quote_volume_str or f"{self.quote_volume:.8f}",
            "openTime": self.open_time_ms,
            "closeTime": self.close_time_ms,
            "firstId": self.first_trade_id,
            "lastId": self.last_trade_id,
            "count": self.trade_count,
        }


@dataclass(slots=True, frozen=True)
class MiniTicker:
    """Estadisticas 24h reducidas de Binance (stream @miniTicker).

    Version ligera de Ticker con solo OHLC y volumen.
    """

    symbol: str
    close_price: float
    open_price: float
    high_price: float
    low_price: float
    volume: float
    quote_volume: float
    event_time_ms: int = 0
    close_price_str: str = ""
    open_price_str: str = ""
    high_price_str: str = ""
    low_price_str: str = ""
    volume_str: str = ""
    quote_volume_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict con campos basicos del ticker."""
        return {
            "symbol": self.symbol,
            "closePrice": self.close_price_str or f"{self.close_price:.8f}",
            "openPrice": self.open_price_str or f"{self.open_price:.8f}",
            "highPrice": self.high_price_str or f"{self.high_price:.8f}",
            "lowPrice": self.low_price_str or f"{self.low_price:.8f}",
            "volume": self.volume_str or f"{self.volume:.8f}",
            "quoteVolume": self.quote_volume_str or f"{self.quote_volume:.8f}",
        }


@dataclass(slots=True, frozen=True)
class BookTicker:
    """Mejor bid/ask en tiempo real de Binance (stream @bookTicker).

    El stream mas rapido para obtener spread. No tiene campo "e" en el payload.
    """

    symbol: str
    update_id: int
    best_bid_price: float
    best_bid_quantity: float
    best_ask_price: float
    best_ask_quantity: float
    best_bid_price_str: str = ""
    best_bid_quantity_str: str = ""
    best_ask_price_str: str = ""
    best_ask_quantity_str: str = ""

    def to_rest_format(self) -> dict:
        """Devuelve un dict compatible con GET /api/v3/ticker/bookTicker."""
        return {
            "symbol": self.symbol,
            "bidPrice": self.best_bid_price_str or f"{self.best_bid_price:.8f}",
            "bidQty": self.best_bid_quantity_str or f"{self.best_bid_quantity:.8f}",
            "askPrice": self.best_ask_price_str or f"{self.best_ask_price:.8f}",
            "askQty": self.best_ask_quantity_str or f"{self.best_ask_quantity:.8f}",
        }


# ---------------------------------------------------------------------------
# Estado de streams
# ---------------------------------------------------------------------------

class StreamState(str, enum.Enum):
    """Estados posibles de un stream."""

    STARTING = "starting"
    RUNNING = "running"
    RECONNECTING = "reconnecting"
    STALE = "stale"
    STOPPED = "stopped"
    FAILED = "failed"


class StreamType(str, enum.Enum):
    """Tipos de stream soportados."""

    TRADE = "trade"
    DEPTH = "depth"
    AGG_TRADE = "aggTrade"
    KLINE = "kline"
    TICKER = "ticker"
    MINI_TICKER = "miniTicker"
    BOOK_TICKER = "bookTicker"


@dataclass(slots=True)
class StreamStatus:
    """Estado operativo de un stream individual."""

    stream_id: str
    stream_type: StreamType
    symbol: str
    state: StreamState = StreamState.STARTING
    connected_at: float | None = None
    last_message_at: float | None = None
    reconnect_count: int = 0
    message_count: int = 0
    error_count: int = 0


@dataclass(slots=True)
class SystemHealth:
    """Salud global del sistema de streaming."""

    is_healthy: bool
    total_streams: int
    running_streams: int
    stale_streams: int
    reconnecting_streams: int
    stopped_streams: int
    uptime_s: float
    total_messages: int
    stream_details: dict[str, StreamStatus] = field(default_factory=dict)
