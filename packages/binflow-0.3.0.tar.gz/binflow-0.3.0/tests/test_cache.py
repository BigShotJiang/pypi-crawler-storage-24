"""Tests unitarios para MarketDataCache."""

import time

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import StreamConfig
from market_streaming.models import (
    AggTrade,
    BookTicker,
    Kline,
    MiniTicker,
    OrderBookLevel,
    OrderBookSnapshot,
    Ticker,
    Trade,
)


@pytest.fixture
def config() -> StreamConfig:
    return StreamConfig(max_recent_trades=5, default_order_book_depth=3)


@pytest.fixture
def cache(config: StreamConfig) -> MarketDataCache:
    return MarketDataCache(config)


def _make_trade(symbol: str = "BTCUSDT", price: float = 50000.0, tid: int = 1) -> Trade:
    qty = 0.1
    return Trade(
        symbol=symbol,
        trade_id=tid,
        price=price,
        quantity=qty,
        quote_quantity=price * qty,
        buyer_maker=False,
        timestamp_ms=int(time.time() * 1000),
    )


# ---------- Trades ----------


class TestTradeCache:
    def test_last_trade_empty(self, cache: MarketDataCache) -> None:
        assert cache.get_last_trade("BTCUSDT") is None

    def test_update_and_get_last_trade(self, cache: MarketDataCache) -> None:
        trade = _make_trade(price=50000.0)
        cache.update_trade(trade)
        last = cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 50000.0

    def test_last_trade_updates(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade(price=50000.0, tid=1))
        cache.update_trade(_make_trade(price=51000.0, tid=2))
        assert cache.get_last_trade("BTCUSDT").price == 51000.0  # type: ignore[union-attr]

    def test_recent_trades_limit(self, cache: MarketDataCache) -> None:
        for i in range(10):
            cache.update_trade(_make_trade(price=float(i), tid=i))
        # maxlen=5, pedir 3
        trades = cache.get_recent_trades("BTCUSDT", limit=3)
        assert len(trades) == 3
        assert trades[0].price == 7.0  # últimos 5 son [5,6,7,8,9], últimos 3 son [7,8,9]

    def test_recent_trades_respects_deque_maxlen(self, cache: MarketDataCache) -> None:
        for i in range(10):
            cache.update_trade(_make_trade(price=float(i), tid=i))
        all_trades = cache.get_recent_trades("BTCUSDT", limit=100)
        assert len(all_trades) == 5  # maxlen del deque

    def test_symbol_case_insensitive(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade(symbol="btcusdt"))
        assert cache.get_last_trade("BTCUSDT") is not None
        assert cache.get_last_trade("btcusdt") is not None

    def test_empty_recent_trades(self, cache: MarketDataCache) -> None:
        assert cache.get_recent_trades("ETHUSDT") == []

    def test_trade_ids_continuous(self, cache: MarketDataCache) -> None:
        for tid in range(100, 120):
            cache.update_trade(_make_trade(tid=tid))
        trades = cache.get_recent_trades("BTCUSDT", limit=100)
        ids = [t.trade_id for t in trades]
        gaps = [
            (ids[i], ids[i + 1])
            for i in range(len(ids) - 1)
            if ids[i + 1] - ids[i] != 1
        ]
        assert gaps == [], f"Huecos en IDs: {gaps}"

    def test_trade_ids_continuous_after_overflow(self, cache: MarketDataCache) -> None:
        # maxlen=5, insertamos 10 IDs consecutivos: solo quedan los ultimos 5
        for tid in range(100, 110):
            cache.update_trade(_make_trade(tid=tid))
        trades = cache.get_recent_trades("BTCUSDT", limit=100)
        ids = [t.trade_id for t in trades]
        assert ids == [105, 106, 107, 108, 109]
        gaps = [
            (ids[i], ids[i + 1])
            for i in range(len(ids) - 1)
            if ids[i + 1] - ids[i] != 1
        ]
        assert gaps == []


# ---------- Order Book ----------


class TestOrderBookCache:
    def test_empty_order_book(self, cache: MarketDataCache) -> None:
        assert cache.get_order_book("BTCUSDT") is None

    def test_update_order_book(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(50000.0, 1.0)],
            asks=[OrderBookLevel(50001.0, 0.5)],
            last_update_id=100,
        )
        cache.update_order_book(snapshot)
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 1
        assert book.bids[0].price == 50000.0

    def test_order_book_returns_copy(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(50000.0, 1.0)],
            asks=[],
            last_update_id=1,
        )
        cache.update_order_book(snapshot)
        book1 = cache.get_order_book("BTCUSDT")
        book2 = cache.get_order_book("BTCUSDT")
        assert book1 is not book2

    def test_apply_depth_update(self, cache: MarketDataCache) -> None:
        # Snapshot inicial
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0), OrderBookLevel(99.0, 2.0)],
            asks=[OrderBookLevel(101.0, 1.0)],
            last_update_id=10,
        )
        cache.update_order_book(snapshot)

        # Actualización incremental
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 3.0)],  # Actualizar cantidad
            asks=[OrderBookLevel(102.0, 0.5)],   # Nuevo nivel
            last_update_id=11,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        bid_prices = {b.price for b in book.bids}
        assert 100.0 in bid_prices
        # La cantidad del bid a 100.0 se actualizó
        bid_100 = next(b for b in book.bids if b.price == 100.0)
        assert bid_100.quantity == 3.0

    def test_apply_depth_removes_zero_quantity(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0), OrderBookLevel(99.0, 2.0)],
            asks=[],
            last_update_id=10,
        )
        cache.update_order_book(snapshot)

        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 0.0)],  # Eliminar nivel
            asks=[],
            last_update_id=11,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        bid_prices = {b.price for b in book.bids}
        assert 100.0 not in bid_prices

    def test_apply_depth_ignores_old_update_id(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=10,
        )
        cache.update_order_book(snapshot)

        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 999.0)],
            asks=[],
            last_update_id=5,  # Antiguo
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.bids[0].quantity == 1.0  # Sin cambios

    def test_apply_depth_respects_config_max_depth(self, cache: MarketDataCache) -> None:
        # config tiene depth=3, sin max_depth explicito usa config
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[
                OrderBookLevel(100.0, 1.0),
                OrderBookLevel(99.0, 1.0),
                OrderBookLevel(98.0, 1.0),
                OrderBookLevel(97.0, 1.0),  # Excede max_depth
            ],
            asks=[],
            last_update_id=1,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 3
        assert book.bids[0].price == 100.0  # Ordenados descendente

    def test_apply_depth_respects_explicit_max_depth(self, cache: MarketDataCache) -> None:
        # config tiene depth=3, pero max_depth explicito=6 lo sobreescribe
        cache.apply_depth_update(
            "ETHUSDT",
            bids=[
                OrderBookLevel(200.0, 1.0),
                OrderBookLevel(199.0, 1.0),
                OrderBookLevel(198.0, 1.0),
                OrderBookLevel(197.0, 1.0),
                OrderBookLevel(196.0, 1.0),
                OrderBookLevel(195.0, 1.0),
                OrderBookLevel(194.0, 1.0),  # Excede max_depth=6
            ],
            asks=[],
            last_update_id=1,
            max_depth=6,
        )
        book = cache.get_order_book("ETHUSDT")
        assert book is not None
        assert len(book.bids) == 6
        assert book.bids[0].price == 200.0


# ---------- Sync ----------


class TestOrderBookSync:
    def test_unsynced_by_default(self, cache: MarketDataCache) -> None:
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=1,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.is_synced is False

    def test_synced_via_snapshot(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=10,
            is_synced=True,
        )
        cache.update_order_book(snapshot)
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.is_synced is True

    def test_synced_preserved_after_update(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=10,
            is_synced=True,
        )
        cache.update_order_book(snapshot)

        # Update sin is_synced explicito no pierde el estado
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 2.0)],
            asks=[],
            last_update_id=11,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book.is_synced is True

    def test_synced_via_depth_update(self, cache: MarketDataCache) -> None:
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=1,
            is_synced=True,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book.is_synced is True

    def test_synced_in_copy(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[],
            asks=[],
            last_update_id=1,
            is_synced=True,
        )
        cache.update_order_book(snapshot)
        copy = cache.get_order_book("BTCUSDT")
        assert copy.is_synced is True


# ---------- Anti-retroceso ----------


class TestOrderBookAntiRegression:
    """Verifica que update_order_book no retrocede el estado del book."""

    def test_reject_older_snapshot(self, cache: MarketDataCache) -> None:
        """Un snapshot con ID menor no debe reemplazar uno mayor."""
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=200,
        ))
        # Intentar reemplazar con snapshot mas viejo
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(999.0, 9.0)],
            asks=[],
            last_update_id=100,
        ))
        book = cache.get_order_book("BTCUSDT")
        assert book.last_update_id == 200
        assert book.bids[0].price == 100.0  # No cambio

    def test_synced_snapshot_replaces_unsynced(self, cache: MarketDataCache) -> None:
        """Un snapshot synced reemplaza uno unsynced aunque tenga ID menor."""
        # Book construido solo con diffs (unsynced), tiene ID alto
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=500,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book.is_synced is False

        # REST snapshot con ID menor pero is_synced=True -> debe reemplazar
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(200.0, 2.0)],
            asks=[],
            last_update_id=300,
            is_synced=True,
        ))
        book = cache.get_order_book("BTCUSDT")
        assert book.last_update_id == 300
        assert book.bids[0].price == 200.0
        assert book.is_synced is True

    def test_synced_does_not_replace_synced_with_older(self, cache: MarketDataCache) -> None:
        """Un snapshot synced no reemplaza otro synced con ID mayor."""
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=500,
            is_synced=True,
        ))
        # Otro snapshot synced pero mas viejo -> rechazado
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(999.0, 9.0)],
            asks=[],
            last_update_id=300,
            is_synced=True,
        ))
        book = cache.get_order_book("BTCUSDT")
        assert book.last_update_id == 500
        assert book.bids[0].price == 100.0

    def test_newer_snapshot_always_accepted(self, cache: MarketDataCache) -> None:
        """Un snapshot con ID mayor siempre se acepta."""
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=100,
            is_synced=True,
        ))
        cache.update_order_book(OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(200.0, 2.0)],
            asks=[],
            last_update_id=200,
        ))
        book = cache.get_order_book("BTCUSDT")
        assert book.last_update_id == 200
        assert book.bids[0].price == 200.0


# ---------- Misc ----------


class TestCacheMisc:
    def test_get_symbols(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade(symbol="BTCUSDT"))
        cache.update_order_book(
            OrderBookSnapshot(symbol="ETHUSDT", last_update_id=1)
        )
        symbols = cache.get_symbols()
        assert "BTCUSDT" in symbols
        assert "ETHUSDT" in symbols

    def test_clear(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade())
        cache.clear()
        assert cache.get_last_trade("BTCUSDT") is None
        assert cache.get_symbols() == []


# ---------- AggTrade ----------


def _make_agg_trade(
    symbol: str = "BTCUSDT",
    price: float = 50000.0,
    aid: int = 1,
) -> AggTrade:
    return AggTrade(
        symbol=symbol,
        agg_trade_id=aid,
        price=price,
        quantity=0.1,
        first_trade_id=aid * 10,
        last_trade_id=aid * 10 + 5,
        timestamp_ms=int(time.time() * 1000),
        buyer_maker=False,
    )


class TestAggTradeCache:
    def test_empty_agg_trade(self, cache: MarketDataCache) -> None:
        assert cache.get_last_agg_trade("BTCUSDT") is None

    def test_update_and_get_agg_trade(self, cache: MarketDataCache) -> None:
        agg = _make_agg_trade(price=50000.0)
        cache.update_agg_trade(agg)
        last = cache.get_last_agg_trade("BTCUSDT")
        assert last is not None
        assert last.price == 50000.0
        assert last.agg_trade_id == 1

    def test_recent_agg_trades_limit(self, cache: MarketDataCache) -> None:
        for i in range(10):
            cache.update_agg_trade(_make_agg_trade(price=float(i), aid=i))
        # maxlen=5 (config), pedir 3
        trades = cache.get_recent_agg_trades("BTCUSDT", limit=3)
        assert len(trades) == 3
        assert trades[0].price == 7.0  # ultimos 5 son [5,6,7,8,9], ultimos 3 son [7,8,9]


# ---------- Kline ----------


def _make_kline(
    symbol: str = "BTCUSDT",
    interval: str = "1m",
    close: float = 50100.0,
) -> Kline:
    return Kline(
        symbol=symbol,
        interval=interval,
        open_time_ms=1672515780000,
        close_time_ms=1672515839999,
        open=50000.0,
        close=close,
        high=50200.0,
        low=49900.0,
        volume=100.0,
        quote_volume=5000000.0,
        trades=150,
        taker_buy_volume=60.0,
        taker_buy_quote_volume=3000000.0,
        is_closed=False,
    )


class TestKlineCache:
    def test_empty_kline(self, cache: MarketDataCache) -> None:
        assert cache.get_kline("BTCUSDT") is None

    def test_update_and_get_kline(self, cache: MarketDataCache) -> None:
        kline = _make_kline(close=50100.0)
        cache.update_kline(kline)
        result = cache.get_kline("BTCUSDT", "1m")
        assert result is not None
        assert result.close == 50100.0
        assert result.interval == "1m"

    def test_kline_different_intervals(self, cache: MarketDataCache) -> None:
        kline_1m = _make_kline(interval="1m", close=50100.0)
        kline_5m = _make_kline(interval="5m", close=50200.0)
        cache.update_kline(kline_1m)
        cache.update_kline(kline_5m)
        result_1m = cache.get_kline("BTCUSDT", "1m")
        result_5m = cache.get_kline("BTCUSDT", "5m")
        assert result_1m is not None
        assert result_5m is not None
        assert result_1m.close == 50100.0
        assert result_5m.close == 50200.0


# ---------- Ticker ----------


def _make_ticker(
    symbol: str = "BTCUSDT",
    last_price: float = 50000.0,
) -> Ticker:
    return Ticker(
        symbol=symbol,
        price_change=500.0,
        price_change_pct=1.0,
        weighted_avg_price=50000.0,
        prev_close_price=49500.0,
        last_price=last_price,
        last_quantity=0.1,
        best_bid_price=49999.0,
        best_bid_quantity=1.0,
        best_ask_price=50001.0,
        best_ask_quantity=0.5,
        open_price=49500.0,
        high_price=50500.0,
        low_price=49000.0,
        volume=1000.0,
        quote_volume=50000000.0,
        open_time_ms=0,
        close_time_ms=86400000,
        first_trade_id=1,
        last_trade_id=18150,
        trade_count=18151,
    )


class TestTickerCache:
    def test_empty_ticker(self, cache: MarketDataCache) -> None:
        assert cache.get_ticker("BTCUSDT") is None

    def test_update_and_get_ticker(self, cache: MarketDataCache) -> None:
        ticker = _make_ticker(last_price=50000.0)
        cache.update_ticker(ticker)
        result = cache.get_ticker("BTCUSDT")
        assert result is not None
        assert result.last_price == 50000.0

    def test_ticker_overwrites(self, cache: MarketDataCache) -> None:
        cache.update_ticker(_make_ticker(last_price=50000.0))
        cache.update_ticker(_make_ticker(last_price=51000.0))
        result = cache.get_ticker("BTCUSDT")
        assert result is not None
        assert result.last_price == 51000.0


# ---------- MiniTicker ----------


def _make_mini_ticker(
    symbol: str = "BTCUSDT",
    close_price: float = 50000.0,
) -> MiniTicker:
    return MiniTicker(
        symbol=symbol,
        close_price=close_price,
        open_price=49500.0,
        high_price=50500.0,
        low_price=49000.0,
        volume=1000.0,
        quote_volume=50000000.0,
    )


class TestMiniTickerCache:
    def test_empty_mini_ticker(self, cache: MarketDataCache) -> None:
        assert cache.get_mini_ticker("BTCUSDT") is None

    def test_update_and_get_mini_ticker(self, cache: MarketDataCache) -> None:
        mt = _make_mini_ticker(close_price=50000.0)
        cache.update_mini_ticker(mt)
        result = cache.get_mini_ticker("BTCUSDT")
        assert result is not None
        assert result.close_price == 50000.0


# ---------- BookTicker ----------


def _make_book_ticker(
    symbol: str = "BTCUSDT",
    bid: float = 49999.0,
    ask: float = 50001.0,
) -> BookTicker:
    return BookTicker(
        symbol=symbol,
        update_id=400900217,
        best_bid_price=bid,
        best_bid_quantity=1.0,
        best_ask_price=ask,
        best_ask_quantity=0.5,
    )


class TestBookTickerCache:
    def test_empty_book_ticker(self, cache: MarketDataCache) -> None:
        assert cache.get_book_ticker("BTCUSDT") is None

    def test_update_and_get_book_ticker(self, cache: MarketDataCache) -> None:
        bt = _make_book_ticker(bid=49999.0, ask=50001.0)
        cache.update_book_ticker(bt)
        result = cache.get_book_ticker("BTCUSDT")
        assert result is not None
        assert result.best_bid_price == 49999.0
        assert result.best_ask_price == 50001.0


# ---------- Symbols & Clear (new types) ----------


class TestCacheNewSymbols:
    def test_get_symbols_includes_new_types(self, cache: MarketDataCache) -> None:
        cache.update_agg_trade(_make_agg_trade(symbol="AAVEUSDT"))
        cache.update_kline(_make_kline(symbol="SOLUSDT"))
        cache.update_ticker(_make_ticker(symbol="ADAUSDT"))
        cache.update_mini_ticker(_make_mini_ticker(symbol="DOTUSDT"))
        cache.update_book_ticker(_make_book_ticker(symbol="LINKUSDT"))
        symbols = cache.get_symbols()
        assert "AAVEUSDT" in symbols
        assert "SOLUSDT" in symbols
        assert "ADAUSDT" in symbols
        assert "DOTUSDT" in symbols
        assert "LINKUSDT" in symbols

    def test_clear_removes_new_types(self, cache: MarketDataCache) -> None:
        cache.update_agg_trade(_make_agg_trade(symbol="BTCUSDT"))
        cache.update_kline(_make_kline(symbol="BTCUSDT"))
        cache.update_ticker(_make_ticker(symbol="BTCUSDT"))
        cache.update_mini_ticker(_make_mini_ticker(symbol="BTCUSDT"))
        cache.update_book_ticker(_make_book_ticker(symbol="BTCUSDT"))
        cache.clear()
        assert cache.get_last_agg_trade("BTCUSDT") is None
        assert cache.get_kline("BTCUSDT") is None
        assert cache.get_ticker("BTCUSDT") is None
        assert cache.get_mini_ticker("BTCUSDT") is None
        assert cache.get_book_ticker("BTCUSDT") is None
        assert cache.get_symbols() == []
