"""Tests unitarios para workers de streaming."""

import asyncio
import json

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import Market, StreamConfig
from market_streaming.exceptions import FatalStreamError
from market_streaming.models import StreamState, StreamType
from market_streaming.worker import (
    CombinedStreamWorker,
    WebSocketStreamWorker,
    _build_agg_trade,
    _build_book_ticker,
    _build_kline,
    _build_mini_ticker,
    _build_ticker,
    _build_trade,
    _filter_sync_diffs,
    _parse_book_levels,
)


@pytest.fixture
def config() -> StreamConfig:
    return StreamConfig(max_recent_trades=100, default_order_book_depth=5)


@pytest.fixture
def cache(config: StreamConfig) -> MarketDataCache:
    return MarketDataCache(config)


@pytest.fixture
def trade_worker(config: StreamConfig, cache: MarketDataCache) -> WebSocketStreamWorker:
    return WebSocketStreamWorker(
        stream_id="trade_BTCUSDT",
        stream_type=StreamType.TRADE,
        symbol="BTCUSDT",
        config=config,
        cache=cache,
    )


@pytest.fixture
def depth_worker(config: StreamConfig, cache: MarketDataCache) -> WebSocketStreamWorker:
    return WebSocketStreamWorker(
        stream_id="depth_BTCUSDT",
        stream_type=StreamType.DEPTH,
        symbol="BTCUSDT",
        config=config,
        cache=cache,
        depth=5,
    )


class TestWorkerInit:
    def test_initial_state(self, trade_worker: WebSocketStreamWorker) -> None:
        assert trade_worker.status.state == StreamState.STARTING
        assert trade_worker.status.message_count == 0
        assert trade_worker.stream_id == "trade_BTCUSDT"

    def test_url_trade(self, trade_worker: WebSocketStreamWorker) -> None:
        url = trade_worker._build_url()
        assert "btcusdt@trade" in url

    def test_url_depth(self, depth_worker: WebSocketStreamWorker) -> None:
        url = depth_worker._build_url()
        assert "btcusdt@depth5" in url

    def test_url_spot_default(self, trade_worker: WebSocketStreamWorker) -> None:
        url = trade_worker._build_url()
        assert "stream.binance.com" in url

    def test_url_futures_usd(self, cache: MarketDataCache) -> None:
        cfg = StreamConfig(market=Market.FUTURES_USD, max_recent_trades=100)
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "fstream.binance.com" in url

    def test_url_futures_coin(self, cache: MarketDataCache) -> None:
        cfg = StreamConfig(market=Market.FUTURES_COIN, max_recent_trades=100)
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSD_PERP",
            stream_type=StreamType.TRADE,
            symbol="BTCUSD_PERP",
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "dstream.binance.com" in url

    def test_url_custom_base_url(self, cache: MarketDataCache) -> None:
        cfg = StreamConfig(base_url="wss://custom.example.com/ws", max_recent_trades=100)
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "custom.example.com" in url


class TestWorkerMessageProcessing:
    def test_process_trade_message(
        self, trade_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "e": "trade",
            "E": 1234567890,
            "s": "BTCUSDT",
            "t": 100,
            "p": "50000.00",
            "q": "0.50000000",
            "T": 1234567890,
            "m": False,
            "M": True,
        })
        trade_worker._process_message(msg)

        assert trade_worker.status.message_count == 1
        assert trade_worker.status.last_message_at is not None

        last = cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 50000.0
        assert last.quantity == 0.5
        assert last.quote_quantity == 25000.0
        assert last.price_str == "50000.00"
        assert last.quantity_str == "0.50000000"
        assert last.is_best_match is True
        assert last.event_time_ms == 1234567890

    def test_trade_to_rest_format(
        self, trade_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "e": "trade",
            "E": 1234567890,
            "s": "BTCUSDT",
            "t": 42,
            "p": "68332.01000000",
            "q": "0.00016000",
            "T": 1499865549590,
            "m": False,
            "M": True,
        })
        trade_worker._process_message(msg)
        last = cache.get_last_trade("BTCUSDT")
        rest = last.to_rest_format()
        assert rest["id"] == 42
        assert rest["price"] == "68332.01000000"
        assert rest["qty"] == "0.00016000"
        assert "quoteQty" in rest
        assert rest["time"] == 1499865549590
        assert rest["isBuyerMaker"] is False
        assert rest["isBestMatch"] is True

    def test_process_depth_update(
        self, depth_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "e": "depthUpdate",
            "E": 1234567890,
            "T": 1234567891,
            "s": "BTCUSDT",
            "U": 1,
            "u": 5,
            "b": [["50000.00000000", "1.00000000"], ["49999.00000000", "2.00000000"]],
            "a": [["50001.00000000", "0.50000000"]],
        })
        depth_worker._process_message(msg)

        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 2
        assert len(book.asks) == 1
        assert book.bids[0].price_str == "50000.00000000"
        assert book.bids[0].quantity_str == "1.00000000"
        assert book.event_time_ms == 1234567890
        assert book.transaction_time_ms == 1234567891

    def test_process_depth_snapshot(
        self, depth_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "lastUpdateId": 100,
            "bids": [["50000.00000000", "1.00000000"]],
            "asks": [["50001.00000000", "0.50000000"]],
        })
        depth_worker._process_message(msg)

        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.last_update_id == 100
        assert book.bids[0].price_str == "50000.00000000"

    def test_depth_to_rest_format(
        self, depth_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "lastUpdateId": 200,
            "bids": [["50000.00000000", "1.00000000"]],
            "asks": [["50001.00000000", "0.50000000"]],
        })
        depth_worker._process_message(msg)
        book = cache.get_order_book("BTCUSDT")
        rest = book.to_rest_format()
        assert rest["lastUpdateId"] == 200
        assert rest["bids"] == [["50000.00000000", "1.00000000"]]
        assert rest["asks"] == [["50001.00000000", "0.50000000"]]

    def test_invalid_json(self, trade_worker: WebSocketStreamWorker) -> None:
        trade_worker._process_message("not json at all")
        assert trade_worker.status.error_count == 1
        assert trade_worker.status.message_count == 1


class TestWorkerBackoff:
    def test_backoff_increases(self, trade_worker: WebSocketStreamWorker) -> None:
        d1 = trade_worker._calculate_backoff(1)
        d2 = trade_worker._calculate_backoff(3)
        assert d1 > 0
        assert d2 > 0

    def test_backoff_capped(self, trade_worker: WebSocketStreamWorker) -> None:
        delay = trade_worker._calculate_backoff(100)
        max_with_jitter = (
            trade_worker._config.reconnect_max_delay_s * 1.3
        )
        assert delay <= max_with_jitter


class TestModuleFunctions:
    """Tests para funciones de modulo extraidas del refactor."""

    def test_parse_book_levels(self) -> None:
        raw = [["50000.00", "1.00"], ["49999.00", "2.00"]]
        levels = _parse_book_levels(raw)
        assert len(levels) == 2
        assert levels[0].price == 50000.0
        assert levels[0].price_str == "50000.00"
        assert levels[1].quantity == 2.0

    def test_parse_book_levels_empty(self) -> None:
        assert _parse_book_levels([]) == []

    def test_build_trade(self) -> None:
        data = {
            "t": 100, "p": "50000.00", "q": "0.50000000",
            "T": 1234567890, "m": False, "M": True, "E": 9999,
        }
        trade = _build_trade(data, "BTCUSDT")
        assert trade.symbol == "BTCUSDT"
        assert trade.trade_id == 100
        assert trade.price == 50000.0
        assert trade.quantity == 0.5
        assert trade.quote_quantity == 25000.0
        assert trade.price_str == "50000.00"
        assert trade.buyer_maker is False
        assert trade.is_best_match is True
        assert trade.event_time_ms == 9999

class TestFilterSyncDiffs:
    """Tests para _filter_sync_diffs (validacion de continuidad)."""

    def test_spot_drops_stale_diffs(self) -> None:
        buffer = [
            {"U": 1, "u": 5},   # stale (u <= 10)
            {"U": 6, "u": 10},  # stale (u <= 10)
            {"U": 11, "u": 15}, # valid (u > 10)
        ]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.SPOT)
        assert len(result) == 1
        assert result[0]["U"] == 11

    def test_futures_drops_stale_diffs(self) -> None:
        buffer = [
            {"U": 1, "u": 5},   # stale (u < 10)
            {"U": 6, "u": 9},   # stale (u < 10)
            {"U": 8, "u": 10},  # valid (u >= 10)
            {"U": 11, "u": 15}, # valid (u >= 10)
        ]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.FUTURES_USD)
        assert len(result) == 2
        assert result[0]["U"] == 8

    def test_empty_buffer(self) -> None:
        result = _filter_sync_diffs([], snapshot_update_id=10, market=Market.SPOT)
        assert result == []

    def test_all_stale(self) -> None:
        buffer = [{"U": 1, "u": 3}, {"U": 4, "u": 8}]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.SPOT)
        assert result == []

    def test_sorted_by_first_update_id(self) -> None:
        buffer = [
            {"U": 20, "u": 25},
            {"U": 11, "u": 15},
            {"U": 16, "u": 19},
        ]
        result = _filter_sync_diffs(buffer, snapshot_update_id=10, market=Market.SPOT)
        assert [d["U"] for d in result] == [11, 16, 20]


class TestCombinedStreamWorker:
    """Tests para CombinedStreamWorker."""

    def test_initial_state(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_trades_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=config,
            cache=cache,
        )
        assert worker.status.state == StreamState.STARTING
        assert worker.status.symbol == "COMBINED(2)"
        assert worker.stream_id == "combined_trades_0"

    def test_combined_url_trades(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_trades_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=config,
            cache=cache,
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@trade" in url
        assert "ethusdt@trade" in url

    def test_combined_url_depth(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=config,
            cache=cache,
            depth=5,
        )
        url = worker._build_url()
        assert "btcusdt@depth5" in url

    def test_combined_process_trade(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_trades_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=config,
            cache=cache,
        )
        msg = json.dumps({
            "stream": "btcusdt@trade",
            "data": {
                "e": "trade", "E": 1234567890, "s": "BTCUSDT",
                "t": 42, "p": "60000.00", "q": "1.00000000",
                "T": 1234567890, "m": True, "M": True,
            },
        })
        worker._process_message(msg)
        assert worker.status.message_count == 1
        last = cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 60000.0
        assert last.trade_id == 42

    def test_combined_process_depth_update(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT"],
            config=config,
            cache=cache,
            depth=5,
        )
        msg = json.dumps({
            "stream": "btcusdt@depth5",
            "data": {
                "e": "depthUpdate", "E": 1234567890, "T": 1234567891,
                "s": "BTCUSDT", "U": 1, "u": 5,
                "b": [["50000.00", "1.00"]],
                "a": [["50001.00", "0.50"]],
            },
        })
        worker._process_message(msg)
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 1

    def test_combined_invalid_json(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_trades_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=config,
            cache=cache,
        )
        worker._process_message("not json")
        assert worker.status.error_count == 1


class TestWorkerSyncState:
    """Tests para el estado de sincronizacion de workers."""

    def test_single_worker_needs_sync_for_deep_depth(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="depth_BTCUSDT",
            stream_type=StreamType.DEPTH,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
            depth=200,
        )
        assert worker._needs_sync is True
        assert worker._synced is False

    def test_single_worker_no_sync_for_partial_depth(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        for depth in [5, 10, 20]:
            worker = WebSocketStreamWorker(
                stream_id=f"depth_BTCUSDT",
                stream_type=StreamType.DEPTH,
                symbol="BTCUSDT",
                config=config,
                cache=cache,
                depth=depth,
            )
            assert worker._needs_sync is False

    def test_trade_worker_no_sync(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        assert worker._needs_sync is False

    def test_combined_worker_needs_sync_for_deep_depth(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_depth_0",
            stream_type=StreamType.DEPTH,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=config,
            cache=cache,
            depth=200,
        )
        assert worker._needs_sync is True
        assert worker._synced_symbols == set()

    def test_combined_worker_no_sync_for_trades(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_trades_0",
            stream_type=StreamType.TRADE,
            symbols=["BTCUSDT"],
            config=config,
            cache=cache,
        )
        assert worker._needs_sync is False


class TestRunPreservesFailed:
    """Verifica que _run() no sobreescribe StreamState.FAILED con STOPPED."""

    def test_fatal_error_preserves_failed(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        # Monkey-patch _connect_and_consume para lanzar FatalStreamError
        async def _raise_fatal() -> None:
            raise FatalStreamError("test fatal")

        worker._connect_and_consume = _raise_fatal  # type: ignore[assignment]
        asyncio.run(worker._run())
        assert worker.status.state == StreamState.FAILED

    def test_max_reconnect_preserves_failed(
        self, cache: MarketDataCache,
    ) -> None:
        cfg = StreamConfig(
            max_recent_trades=100,
            max_reconnect_attempts=1,
            reconnect_base_delay_s=0.01,
            reconnect_max_delay_s=0.01,
        )
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=cfg,
            cache=cache,
        )
        # Falla siempre con error generico para agotar reintentos
        async def _raise_generic() -> None:
            raise ConnectionError("test reconnect")

        worker._connect_and_consume = _raise_generic  # type: ignore[assignment]
        asyncio.run(worker._run())
        assert worker.status.state == StreamState.FAILED

    def test_normal_stop_sets_stopped(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        # _connect_and_consume que respeta stop_event
        async def _stop_immediately() -> None:
            worker._stop_event.set()

        worker._connect_and_consume = _stop_immediately  # type: ignore[assignment]
        asyncio.run(worker._run())
        assert worker.status.state == StreamState.STOPPED


class TestNewBuilderFunctions:
    """Tests para funciones builder de los nuevos tipos de stream."""

    def test_build_agg_trade(self) -> None:
        data = {
            "e": "aggTrade", "E": 1672515782136, "s": "BTCUSDT",
            "a": 12345, "p": "50000.00", "q": "0.001",
            "f": 100, "l": 105, "T": 1672515782136,
            "m": False, "M": True,
        }
        agg = _build_agg_trade(data, "BTCUSDT")
        assert agg.symbol == "BTCUSDT"
        assert agg.agg_trade_id == 12345
        assert agg.price == 50000.0
        assert agg.quantity == 0.001
        assert agg.first_trade_id == 100
        assert agg.last_trade_id == 105
        assert agg.timestamp_ms == 1672515782136
        assert agg.buyer_maker is False
        assert agg.price_str == "50000.00"
        assert agg.quantity_str == "0.001"
        assert agg.event_time_ms == 1672515782136

    def test_build_kline(self) -> None:
        data = {
            "e": "kline", "E": 1672515782136, "s": "BTCUSDT",
            "k": {
                "t": 1672515780000, "T": 1672515839999, "s": "BTCUSDT",
                "i": "1m", "f": 100, "L": 200,
                "o": "50000.00", "c": "50100.00", "h": "50200.00",
                "l": "49900.00", "v": "100.00", "n": 150,
                "x": False, "q": "5000000.00", "V": "60.00",
                "Q": "3000000.00", "B": "0",
            },
        }
        kline = _build_kline(data, "BTCUSDT")
        assert kline.symbol == "BTCUSDT"
        assert kline.interval == "1m"
        assert kline.open == 50000.0
        assert kline.close == 50100.0
        assert kline.high == 50200.0
        assert kline.low == 49900.0
        assert kline.volume == 100.0
        assert kline.trades == 150
        assert kline.is_closed is False
        assert kline.open_str == "50000.00"
        assert kline.event_time_ms == 1672515782136

    def test_build_ticker(self) -> None:
        data = {
            "e": "24hrTicker", "E": 1672515782136, "s": "BTCUSDT",
            "p": "500.00", "P": "1.00", "w": "50000.00",
            "x": "49500.00", "c": "50000.00", "Q": "0.1",
            "b": "49999.00", "B": "1.0", "a": "50001.00", "A": "0.5",
            "o": "49500.00", "h": "50500.00", "l": "49000.00",
            "v": "1000.00", "q": "50000000.00",
            "O": 0, "C": 86400000, "F": 1, "L": 18150, "n": 18151,
        }
        ticker = _build_ticker(data, "BTCUSDT")
        assert ticker.symbol == "BTCUSDT"
        assert ticker.price_change == 500.0
        assert ticker.last_price == 50000.0
        assert ticker.best_bid_price == 49999.0
        assert ticker.best_ask_price == 50001.0
        assert ticker.trade_count == 18151
        assert ticker.event_time_ms == 1672515782136

    def test_build_mini_ticker(self) -> None:
        data = {
            "e": "24hrMiniTicker", "E": 1672515782136, "s": "BTCUSDT",
            "c": "50000.00", "o": "49500.00", "h": "50500.00",
            "l": "49000.00", "v": "1000.00", "q": "50000000.00",
        }
        mt = _build_mini_ticker(data, "BTCUSDT")
        assert mt.symbol == "BTCUSDT"
        assert mt.close_price == 50000.0
        assert mt.open_price == 49500.0
        assert mt.high_price == 50500.0
        assert mt.low_price == 49000.0
        assert mt.volume == 1000.0
        assert mt.quote_volume == 50000000.0
        assert mt.event_time_ms == 1672515782136

    def test_build_book_ticker(self) -> None:
        data = {
            "u": 400900217, "s": "BTCUSDT",
            "b": "49999.00", "B": "1.0",
            "a": "50001.00", "A": "0.5",
        }
        bt = _build_book_ticker(data, "BTCUSDT")
        assert bt.symbol == "BTCUSDT"
        assert bt.update_id == 400900217
        assert bt.best_bid_price == 49999.0
        assert bt.best_bid_quantity == 1.0
        assert bt.best_ask_price == 50001.0
        assert bt.best_ask_quantity == 0.5
        assert bt.best_bid_price_str == "49999.00"
        assert bt.best_ask_price_str == "50001.00"


class TestNewStreamURLs:
    """Tests para URLs de los nuevos tipos de stream."""

    def test_url_agg_trade(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = WebSocketStreamWorker(
            stream_id="agg_trade_BTCUSDT",
            stream_type=StreamType.AGG_TRADE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@aggTrade" in url

    def test_url_kline(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = WebSocketStreamWorker(
            stream_id="kline_BTCUSDT",
            stream_type=StreamType.KLINE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
            interval="5m",
        )
        url = worker._build_url()
        assert "btcusdt@kline_5m" in url

    def test_url_ticker(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = WebSocketStreamWorker(
            stream_id="ticker_BTCUSDT",
            stream_type=StreamType.TICKER,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@ticker" in url

    def test_url_mini_ticker(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = WebSocketStreamWorker(
            stream_id="mini_ticker_BTCUSDT",
            stream_type=StreamType.MINI_TICKER,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@miniTicker" in url

    def test_url_book_ticker(self, config: StreamConfig, cache: MarketDataCache) -> None:
        worker = WebSocketStreamWorker(
            stream_id="book_ticker_BTCUSDT",
            stream_type=StreamType.BOOK_TICKER,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        url = worker._build_url()
        assert "btcusdt@bookTicker" in url

    def test_combined_url_agg_trades(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_agg_trades_0",
            stream_type=StreamType.AGG_TRADE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=config,
            cache=cache,
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@aggTrade" in url
        assert "ethusdt@aggTrade" in url

    def test_combined_url_klines(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = CombinedStreamWorker(
            worker_id="combined_klines_0",
            stream_type=StreamType.KLINE,
            symbols=["BTCUSDT", "ETHUSDT"],
            config=config,
            cache=cache,
            interval="15m",
        )
        url = worker._build_url()
        assert "stream?streams=" in url
        assert "btcusdt@kline_15m" in url
        assert "ethusdt@kline_15m" in url


class TestNewMessageProcessing:
    """Tests para procesamiento de mensajes de los nuevos tipos de stream."""

    def test_process_agg_trade_message(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="agg_trade_BTCUSDT",
            stream_type=StreamType.AGG_TRADE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        msg = json.dumps({
            "e": "aggTrade", "E": 1672515782136, "s": "BTCUSDT",
            "a": 12345, "p": "50000.00", "q": "0.001",
            "f": 100, "l": 105, "T": 1672515782136,
            "m": False, "M": True,
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        last = cache.get_last_agg_trade("BTCUSDT")
        assert last is not None
        assert last.agg_trade_id == 12345
        assert last.price == 50000.0
        assert last.quantity == 0.001

    def test_process_kline_message(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="kline_BTCUSDT",
            stream_type=StreamType.KLINE,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        msg = json.dumps({
            "e": "kline", "E": 1672515782136, "s": "BTCUSDT",
            "k": {
                "t": 1672515780000, "T": 1672515839999, "s": "BTCUSDT",
                "i": "1m", "f": 100, "L": 200,
                "o": "50000.00", "c": "50100.00", "h": "50200.00",
                "l": "49900.00", "v": "100.00", "n": 150,
                "x": False, "q": "5000000.00", "V": "60.00",
                "Q": "3000000.00", "B": "0",
            },
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        kline = cache.get_kline("BTCUSDT", "1m")
        assert kline is not None
        assert kline.open == 50000.0
        assert kline.close == 50100.0
        assert kline.interval == "1m"

    def test_process_ticker_message(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="ticker_BTCUSDT",
            stream_type=StreamType.TICKER,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        msg = json.dumps({
            "e": "24hrTicker", "E": 1672515782136, "s": "BTCUSDT",
            "p": "500.00", "P": "1.00", "w": "50000.00",
            "x": "49500.00", "c": "50000.00", "Q": "0.1",
            "b": "49999.00", "B": "1.0", "a": "50001.00", "A": "0.5",
            "o": "49500.00", "h": "50500.00", "l": "49000.00",
            "v": "1000.00", "q": "50000000.00",
            "O": 0, "C": 86400000, "F": 1, "L": 18150, "n": 18151,
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        ticker = cache.get_ticker("BTCUSDT")
        assert ticker is not None
        assert ticker.last_price == 50000.0
        assert ticker.trade_count == 18151

    def test_process_mini_ticker_message(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="mini_ticker_BTCUSDT",
            stream_type=StreamType.MINI_TICKER,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        msg = json.dumps({
            "e": "24hrMiniTicker", "E": 1672515782136, "s": "BTCUSDT",
            "c": "50000.00", "o": "49500.00", "h": "50500.00",
            "l": "49000.00", "v": "1000.00", "q": "50000000.00",
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        mt = cache.get_mini_ticker("BTCUSDT")
        assert mt is not None
        assert mt.close_price == 50000.0
        assert mt.open_price == 49500.0

    def test_process_book_ticker_message(
        self, config: StreamConfig, cache: MarketDataCache,
    ) -> None:
        worker = WebSocketStreamWorker(
            stream_id="book_ticker_BTCUSDT",
            stream_type=StreamType.BOOK_TICKER,
            symbol="BTCUSDT",
            config=config,
            cache=cache,
        )
        # bookTicker has no "e" field
        msg = json.dumps({
            "u": 400900217, "s": "BTCUSDT",
            "b": "49999.00", "B": "1.0",
            "a": "50001.00", "A": "0.5",
        })
        worker._process_message(msg)

        assert worker.status.message_count == 1
        bt = cache.get_book_ticker("BTCUSDT")
        assert bt is not None
        assert bt.best_bid_price == 49999.0
        assert bt.best_ask_price == 50001.0
        assert bt.update_id == 400900217
