# coding: utf-8
import json
from copy import deepcopy
from enum import Enum
from pathlib import Path
from typing import List

from PySide6.QtCore import QObject, Signal, qVersion
from PySide6.QtGui import QColor

from .exception_handler import exceptionHandler


_darkdetect = None


def _resolve_system_theme():
    global _darkdetect

    if _darkdetect is None:
        try:
            import darkdetect as _darkdetect_module
        except Exception:
            _darkdetect = False
        else:
            _darkdetect = _darkdetect_module

    if not _darkdetect:
        return Theme.LIGHT

    detected_theme = _darkdetect.theme()
    return Theme(detected_theme) if detected_theme else Theme.LIGHT

class Theme(Enum):
    """ 主题枚举 """

    LIGHT = "Light"
    DARK = "Dark"
    AUTO = "Auto"


class ConfigValidator:
    """ 配置校验器 """

    def validate(self, value):
        """校验值是否合法."""
        return True

    def correct(self, value):
        """修正非法值."""
        return value


class RangeValidator(ConfigValidator):
    """ 范围校验器 """

    def __init__(self, min, max):
        self.min = min
        self.max = max
        self.range = (min, max)

    def validate(self, value):
        return self.min <= value <= self.max

    def correct(self, value):
        return min(max(self.min, value), self.max)


class OptionsValidator(ConfigValidator):
    """ 选项校验器 """

    def __init__(self, options):
        if not options:
            raise ValueError("The `options` can't be empty.")

        if isinstance(options, Enum):
            options = options._member_map_.values()

        self.options = list(options)

    def validate(self, value):
        return value in self.options

    def correct(self, value):
        return value if self.validate(value) else self.options[0]


class BoolValidator(OptionsValidator):
    """ 布尔值校验器 """

    def __init__(self):
        super().__init__([True, False])


class FolderValidator(ConfigValidator):
    """ 文件夹校验器 """

    def validate(self, value):
        return Path(value).exists()

    def correct(self, value):
        path = Path(value)
        path.mkdir(exist_ok=True, parents=True)
        return str(path.absolute()).replace("\\", "/")


class FolderListValidator(ConfigValidator):
    """ 文件夹列表校验器 """

    def validate(self, value):
        return all(Path(i).exists() for i in value)

    def correct(self, value: List[str]):
        folders = []
        for folder in value:
            path = Path(folder)
            if path.exists():
                folders.append(str(path.absolute()).replace("\\", "/"))

        return folders


class ColorValidator(ConfigValidator):
    """ RGB 颜色校验器 """

    def __init__(self, default):
        self.default = QColor(default)

    def validate(self, color):
        try:
            return QColor(color).isValid()
        except:
            return False

    def correct(self, value):
        return QColor(value) if self.validate(value) else self.default


class ConfigSerializer:
    """ 配置序列化器 """

    def serialize(self, value):
        """序列化配置值."""
        return value

    def deserialize(self, value):
        """从配置文件中的值反序列化配置."""
        return value


class EnumSerializer(ConfigSerializer):
    """ 枚举类序列化器 """

    def __init__(self, enumClass):
        self.enumClass = enumClass

    def serialize(self, value):
        return value.value

    def deserialize(self, value):
        return self.enumClass(value)


class ColorSerializer(ConfigSerializer):
    """ QColor 序列化器 """

    def serialize(self, value: QColor):
        return value.name(QColor.HexArgb)

    def deserialize(self, value):
        if isinstance(value, list):
            return QColor(*value)

        return QColor(value)


class ConfigItem(QObject):
    """ 配置项 """

    valueChanged = Signal(object)

    def __init__(self, group, name, default, validator=None, serializer=None, restart=False):
        """
        参数
        ----------
        group: str
            配置分组名称.

        name: str
            配置项名称,可以为空.

        default:
            默认值.

        serializer: ConfigSerializer
            配置序列化器.

        restart: bool
            更新值后是否需要重启应用.
        """
        super().__init__()
        self.group = group
        self.name = name
        self.validator = validator or ConfigValidator()
        self.serializer = serializer or ConfigSerializer()
        self.__value = default
        self.value = default
        self.restart = restart
        self.defaultValue = self.validator.correct(default)

    @property
    def value(self):
        """获取配置项的值."""
        return self.__value

    @value.setter
    def value(self, v):
        v = self.validator.correct(v)
        ov = self.__value
        self.__value = v
        if ov != v:
            self.valueChanged.emit(v)

    @property
    def key(self):
        """获取以 `.` 分隔的配置键."""
        return self.group+"."+self.name if self.name else self.group

    def __str__(self):
        return f'{self.__class__.__name__}[value={self.value}]'

    def serialize(self):
        return self.serializer.serialize(self.value)

    def deserializeFrom(self, value):
        self.value = self.serializer.deserialize(value)


class RangeConfigItem(ConfigItem):
    """带范围约束的配置项."""

    @property
    def range(self):
        """获取配置项允许的取值范围."""
        return self.validator.range

    def __str__(self):
        return f'{self.__class__.__name__}[range={self.range}, value={self.value}]'


class OptionsConfigItem(ConfigItem):
    """带选项列表的配置项."""

    @property
    def options(self):
        return self.validator.options

    def __str__(self):
        return f'{self.__class__.__name__}[options={self.options}, value={self.value}]'


class ColorConfigItem(ConfigItem):
    """ 颜色配置项 """

    def __init__(self, group, name, default, restart=False):
        super().__init__(group, name, QColor(default), ColorValidator(default),
                         ColorSerializer(), restart)

    def __str__(self):
        return f'{self.__class__.__name__}[value={self.value.name()}]'


class QConfig(QObject):
    """应用级配置对象."""

    appRestartSig = Signal()
    themeChanged = Signal(Theme)
    themeChangedFinished = Signal()
    themeColorChanged = Signal(QColor)

    themeMode = OptionsConfigItem(
        "QFluentWidgets", "ThemeMode", Theme.LIGHT, OptionsValidator(Theme), EnumSerializer(Theme))
    themeColor = ColorConfigItem("QFluentWidgets", "ThemeColor", '#009faa')
    fontFamilies = ConfigItem("QFluentWidgets", "FontFamilies", ['Segoe UI', 'Microsoft YaHei', 'PingFang SC'])

    def __init__(self):
        super().__init__()
        self.file = Path("config/config.json")
        self._theme = Theme.LIGHT
        self._cfg = self

    def get(self, item):
        """获取配置项的值."""
        return item.value

    def set(self, item, value, save=True, copy=True):
        """设置配置项的值.

        参数
        ----------
        item: ConfigItem
            配置项.

        value:
            要写入的新值.

        save: bool
            是否立即保存到配置文件.

        copy: bool
            是否对新值执行深拷贝.
        """
        if item.value == value:
            return

        # 复杂对象默认做深拷贝,避免外部引用继续修改配置值.
        try:
            item.value = deepcopy(value) if copy else value
        except:
            item.value = value

        if save:
            self.save()

        if item.restart:
            self._cfg.appRestartSig.emit()

        if item is self._cfg.themeMode:
            self.theme = value
            self._cfg.themeChanged.emit(value)

        if item is self._cfg.themeColor:
            self._cfg.themeColorChanged.emit(value)

    def toDict(self, serialize=True):
        """将配置项转换为 `dict`."""
        items = {}
        for name in dir(self._cfg.__class__):
            item = getattr(self._cfg.__class__, name)
            if not isinstance(item, ConfigItem):
                continue

            value = item.serialize() if serialize else item.value
            if not items.get(item.group):
                if not item.name:
                    items[item.group] = value
                else:
                    items[item.group] = {}

            if item.name:
                items[item.group][item.name] = value

        return items

    def save(self):
        """保存配置."""
        self._cfg.file.parent.mkdir(parents=True, exist_ok=True)
        with open(self._cfg.file, "w", encoding="utf-8") as f:
            json.dump(self._cfg.toDict(), f, ensure_ascii=False, indent=4)

    @exceptionHandler()
    def load(self, file=None, config=None):
        """加载配置.

        参数
        ----------
        file: str 或 Path
            JSON 配置文件路径.

        config: 配置
            要初始化的配置对象.
        """
        if isinstance(config, QConfig):
            self._cfg = config
            self._cfg.themeChanged.connect(self.themeChanged)

        if isinstance(file, (str, Path)):
            self._cfg.file = Path(file)

        try:
            with open(self._cfg.file, encoding="utf-8") as f:
                cfg = json.load(f)
        except:
            cfg = {}

        # 将配置键映射到对应的配置项,便于后续回填.
        items = {}
        for name in dir(self._cfg.__class__):
            item = getattr(self._cfg.__class__, name)
            if isinstance(item, ConfigItem):
                items[item.key] = item

        # 根据配置文件中的值更新配置项.
        for k, v in cfg.items():
            if not isinstance(v, dict) and items.get(k) is not None:
                items[k].deserializeFrom(v)
            elif isinstance(v, dict):
                for key, value in v.items():
                    key = k + "." + key
                    if items.get(key) is not None:
                        items[key].deserializeFrom(value)

        self.theme = self.get(self._cfg.themeMode)

    @property
    def theme(self):
        """获取当前主题模式."""
        return self._cfg._theme

    @theme.setter
    def theme(self, t):
        """切换主题,但不修改配置文件."""
        if t == Theme.AUTO:
            t = _resolve_system_theme()

        self._cfg._theme = t


QT_VERSION = tuple([int(v) for v in qVersion().split('.')])
qconfig = QConfig()


def isDarkTheme():
    """返回当前主题是否为暗色模式."""
    return qconfig.theme == Theme.DARK

def theme():
    """获取当前主题."""
    return qconfig.theme

def isDarkThemeMode(theme=Theme.AUTO):
    """判断给定主题模式是否为暗色模式."""
    return theme == Theme.DARK if theme != Theme.AUTO else isDarkTheme()
