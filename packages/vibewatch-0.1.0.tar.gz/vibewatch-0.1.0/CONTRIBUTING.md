# Contributing

## Commit conventions

Follow Conventional Commits: feat:, fix:, refactor:, test:, docs:, chore:

## Branch naming

feature/<issue-id>-<short-description>
fix/<issue-id>-<short-description>

## Before submitting

Run: ruff check src/ tests/ && mypy src/vibewatch/ && pytest

All three must pass with zero errors.

## Adding adapters

See docs/development.md - Adding a new adapter.
