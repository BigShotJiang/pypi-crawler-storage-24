# VibeWatch

> Stop your AI coding session from going stale. VibeWatch monitors your Claude Code, Copilot, Cursor, or Aider context in real time and tells you exactly when to start a fresh session — before the model starts forgetting.

[![PyPI version](https://img.shields.io/pypi/v/vibewatch.svg)](https://pypi.org/project/vibewatch/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

> **Runs entirely on your machine.**
> VibeWatch reads transcript files your AI tool already writes locally.
> No data is sent to any server. No telemetry. No retraining. Your code and conversations never leave your disk.

---

## The problem

Long AI coding sessions accumulate context rot — old tool results, superseded plans, stale file reads, and abandoned attempts that still consume tokens but add no value. When rot is high, the model starts missing context, repeating itself, or contradicting earlier decisions. You can't see it happening until it already has.

VibeWatch makes context rot visible before it breaks your session.

---

## Install

```bash
pip install vibewatch
```

Requires Python 3.11+. Works on macOS, Linux, and Windows.

---

## Quick start

```bash
# 1. Go to your project directory
cd /your/project

# 2. One-time setup — detects your AI tool and writes .vibewatch.toml
vibewatch init

# 3. Launch the live dashboard
vibewatch watch
```

That's it. VibeWatch auto-detects Claude Code, Copilot, Cursor, or Aider and starts monitoring immediately.

---

## What it looks like

```
┌─────────────────────────────┐ ┌─────────────────────────────┐
│ TOKEN BUDGET                │ │ CONTEXT BREAKDOWN           │
│                             │ │                             │
│ ~87,400/200k                │ │ ████░░ Keep    28%          │
│ [████████░░]                │ │ ███░░░ Monitor 19%          │
│ ~43.7% used                 │ │ █████░ Evict   34%          │
│ (est. ±20%)                 │ │ ████░░ Stale   19%          │
└─────────────────────────────┘ └─────────────────────────────┘
┌─────────────────────────────┐ ┌─────────────────────────────────────┐
│ ROT RISK                    │ │ EVICTION CANDIDATES                 │
│                             │ │                                     │
│ [████████░] 71%             │ │ tool_result  read_file  4,200 tok   │
│                             │ │ tool_result  bash       2,800 tok   │
│ STATUS: ACT NOW             │ │ assistant    text        890 tok    │
│ ~46,200 evictable           │ │ tool_result  read_file  1,100 tok   │
└─────────────────────────────┘ └─────────────────────────────────────┘

Session: m4-hitl-agent (auto)   [G] Handoff  [H] Save context  [S] Switch  [Q] Quit
```

### Rot score

| Score | Status | What it means |
|-------|--------|---------------|
| 0.0 – 0.40 | **green** | Context is healthy — keep going |
| 0.40 – 0.70 | **yellow** | Degradation starting — keep an eye on it |
| 0.70+       | **red**    | Act now — generate a handoff and start fresh |

---

## Supported AI tools

| Tool | How VibeWatch finds it | Notes |
|------|------------------------|-------|
| **Claude Code** | `~/.claude/projects/<encoded>/` JSONL files | Auto-selects best session by cost proxy |
| **Aider** | `.aider.chat.history.md` in project dir | Auto-detected |
| **VS Code Copilot** | VS Code `workspaceStorage` chat sessions | Windows/macOS |
| **Cursor** | Cursor `workspaceStorage` chat sessions | Windows/macOS |

Detection is automatic — VibeWatch finds the right files without configuration. Force a specific tool with `--tool` if needed.

---

## Session modes (Claude Code)

When you run Claude Code with parallel agents, multiple session files are created. VibeWatch handles this with `--session-mode`:

```bash
# auto (default) — picks the session with the most work done
vibewatch watch

# pick — shows an interactive list to choose from
vibewatch watch --session-mode pick

# all — monitors every session simultaneously in a swarm view
vibewatch watch --session-mode all

# explicit — point directly at a specific JSONL file
vibewatch watch --session /path/to/session.jsonl
```

---

## Dashboard key bindings

| Key | Action |
|-----|--------|
| `G` | Generate handoff prompt and copy to clipboard |
| `H` | Save context snapshot to `~/.vibewatch/context/` |
| `S` | Switch to a different session (pick mode) |
| `Q` | Quit |

**Handoff prompt (G):** Generates a compact prompt you paste into a new session. It tells the next agent exactly what was accomplished, what files were modified, and what to do next — so nothing is lost when you start fresh.

**Context snapshot (H):** Writes a Markdown + JSON summary to `~/.vibewatch/context/<session-id>.md`. Useful for handing off between agents or resuming work later.

---

## One-shot audit

Run a single rot check without the dashboard — useful in CI or pre-commit hooks:

```bash
# Print JSON report to stdout
vibewatch audit

# Write report to a file
vibewatch audit --output rot-report.json
```

### Exit codes

| Code | Meaning |
|------|---------|
| `0` | Green — rot score below 0.40 |
| `1` | Yellow or Red — rot score 0.40 or higher |
| `2` | Fatal error (no session found, etc.) |

### Example JSON output

```json
{
  "session_id": "7b8ca12f-...",
  "project": "my-project",
  "tool": "claude-code",
  "total_tokens": 87400,
  "rot_score": 0.71,
  "status": "red",
  "breakdown": {
    "keep":      { "tokens": 24500, "pct": 28.1 },
    "monitor":   { "tokens": 16600, "pct": 19.0 },
    "evictable": { "tokens": 29700, "pct": 34.0 },
    "stale":     { "tokens": 16600, "pct": 19.0 }
  },
  "eviction_candidates": [...]
}
```

---

## Issue tracker integration (optional)

VibeWatch can display the active GitHub or GitLab issue in the dashboard, matched by branch name.

**GitHub:**
```bash
export GITHUB_TOKEN=ghp_...
vibewatch init  # select "github" when prompted
```

**GitLab:**
```bash
export GITLAB_PERSONAL_ACCESS_TOKEN=glpat-...
vibewatch init  # select "gitlab" when prompted
```

Branch pattern matching (configured in `.vibewatch.toml`):
```toml
[tracker]
type = "github"
base_url = "https://api.github.com"
project = "owner/repo"
branch_pattern = "feature/{id}-*"
```

---

## Configuration

VibeWatch reads config in priority order:

```
1. CLI flags (--tool, --issue, --poll-interval, etc.)
2. .vibewatch.toml in the current directory  (from vibewatch init)
3. ~/.vibewatch/config.toml  (machine-wide defaults)
4. Built-in defaults
```

### All config keys

| Key | Default | Description |
|-----|---------|-------------|
| `tool` | `auto` | `auto` \| `claude-code` \| `aider` \| `copilot` \| `cursor` |
| `poll_interval_seconds` | `2.0` | How often to re-read the session file |
| `monitor_threshold` | `0.40` | Rot score threshold for yellow status |
| `red_threshold` | `0.70` | Rot score threshold for red status |
| `tracker` | `null` | `github` \| `gitlab` \| `null` |
| `issue_number` | `null` | Override issue number (skips branch detection) |
| `context_dir` | `~/.vibewatch/context/` | Where context snapshots are written |

### Environment variables

| Variable | Purpose |
|----------|---------|
| `GITHUB_TOKEN` | GitHub issue tracker auth |
| `GITLAB_PERSONAL_ACCESS_TOKEN` | GitLab issue tracker auth |
| `VIBEWATCH_TOOL` | Override tool (same as `--tool`) |
| `VIBEWATCH_POLL_INTERVAL_SECONDS` | Override poll interval |

---

## How rot scoring works

Every block in your AI session is classified into one of four decay classes:

| Class | Weight | Meaning |
|-------|--------|---------|
| **keep** | — | Essential: system prompts, active task context, recent tool results |
| **monitor** | 0.20 | Potentially useful but not critical |
| **evictable** | 0.30 | Safe to discard: old tool results, superseded file reads |
| **stale** | 0.50 | Not referenced in the last 10 turns |

```
rot_score = (stale/total × 0.50) + (evictable/total × 0.30) + (monitor/total × 0.20)
```

Token counts are estimated with tiktoken (±15–25% vs the actual model tokenizer). Displayed counts are prefixed with `~` to reflect this.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). PRs welcome — especially new adapter implementations for additional AI tools.

## License

MIT — see [LICENSE](LICENSE).
