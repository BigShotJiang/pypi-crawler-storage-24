from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

from vibewatch.cli import main


def test_help_renders() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "watch" in result.output
    assert "audit" in result.output


def test_audit_with_valid_jsonl(tmp_path: Path) -> None:
    # Write a minimal JSONL session file
    lines = [
        {"type": "user", "uuid": "u1", "sessionId": "s1", "cwd": str(tmp_path),
         "gitBranch": "main", "message": {"role": "user", "content": "hello"}},
    ]
    jsonl = tmp_path / "session.jsonl"
    jsonl.write_text("\n".join(json.dumps(line) for line in lines))

    # Point to this as the claude-code project dir using the resolved path encoding
    resolved = str(tmp_path.resolve())
    encoded = resolved.replace(":", "-").replace("\\", "-").replace("/", "-")
    claude_dir = Path.home() / ".claude" / "projects" / encoded
    claude_dir.mkdir(parents=True, exist_ok=True)
    (claude_dir / "session.jsonl").write_text(jsonl.read_text())

    runner = CliRunner()
    # Use env var to set project_dir so the adapter finds the session we created
    result = runner.invoke(
        main,
        ["audit", "--tool", "claude-code"],
        env={"VIBEWATCH_PROJECT_DIR": str(tmp_path)},
        catch_exceptions=False,
    )
    # Should exit 0 (green) or 1 (yellow/red), not 2 (error)
    assert result.exit_code in (0, 1), result.output
    # Strip any stderr-mixed lines (e.g. "[vibewatch] Auto-selected: ...") before parsing JSON
    json_text = "\n".join(
        line for line in result.output.splitlines()
        if not line.startswith("[vibewatch]") and not line.startswith("Context written")
    )
    report = json.loads(json_text)
    assert "rot_score" in report
    assert "status" in report
