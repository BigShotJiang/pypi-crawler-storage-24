from __future__ import annotations

from vibewatch.core.models import IssueRef, RotRiskResult
from vibewatch.generators.handoff import HandoffGenerator


def make_result(status: str = "red", rot_score: float = 0.71) -> RotRiskResult:
    return RotRiskResult(
        total_tokens=47230,
        keep_tokens=12000,
        monitor_tokens=8000,
        evictable_tokens=15000,
        stale_tokens=12230,
        rot_score=rot_score,
        status=status,
        eviction_candidates=[],
        active_issue=None,
    )


def test_handoff_contains_project_name() -> None:
    gen = HandoffGenerator(project_name="AgentCanvas")
    prompt = gen.generate(make_result(), active_issue=None, modified_files=[])
    assert "AgentCanvas" in prompt


def test_handoff_contains_rot_score() -> None:
    gen = HandoffGenerator(project_name="AgentCanvas")
    prompt = gen.generate(
        make_result(rot_score=0.71, status="red"), active_issue=None, modified_files=[]
    )
    assert "71%" in prompt or "0.71" in prompt


def test_handoff_contains_issue_info() -> None:
    issue = IssueRef(
        id=23, title="HITL queue page", status="In Progress",
        milestone="M4", url="https://example.com/23", tracker="gitlab"
    )
    gen = HandoffGenerator(project_name="AgentCanvas")
    prompt = gen.generate(make_result(), active_issue=issue, modified_files=[])
    assert "#23" in prompt
    assert "HITL queue page" in prompt


def test_handoff_contains_modified_files() -> None:
    gen = HandoffGenerator(project_name="AgentCanvas")
    prompt = gen.generate(
        make_result(),
        active_issue=None,
        modified_files=["src/pages/HITLQueuePage.tsx", "src/store/hitlStore.ts"],
    )
    assert "HITLQueuePage.tsx" in prompt
    assert "hitlStore.ts" in prompt


def test_handoff_has_header_and_footer() -> None:
    gen = HandoffGenerator(project_name="TestProj")
    prompt = gen.generate(make_result(), active_issue=None, modified_files=[])
    assert "=== VibeWatch Handoff Prompt ===" in prompt
    assert "=== End Handoff Prompt ===" in prompt
