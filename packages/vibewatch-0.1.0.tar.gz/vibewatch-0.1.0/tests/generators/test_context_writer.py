from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from vibewatch.core.models import IssueRef, RotRiskResult, SessionMeta
from vibewatch.generators.context_writer import ContextWriter

_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)
_NOW = datetime(2026, 3, 19, 10, 0, 0, tzinfo=UTC)


def _make_session_meta(session_id: str = "test-session-id") -> SessionMeta:
    return SessionMeta(
        path=Path("/fake/path.jsonl"),
        session_id=session_id,
        is_subagent=True,
        agent_name="m4-hitl-agent",
        slug="shared-slug",
        output_tokens=21221,
        cache_creation_tokens=4000,
        cache_read_tokens=60000,
        cost_proxy=23021.0,
        wall_clock_seconds=5160.0,
        total_turn_duration_ms=5100000,
        first_timestamp=_NOW,
        last_timestamp=_NOW,
        cwd="/projects/AgentCanvas",
        git_branch="feature/M4-backend",
    )


def _make_rot_result(status: str = "red", rot_score: float = 0.71) -> RotRiskResult:
    return RotRiskResult(
        total_tokens=95000,
        keep_tokens=22000,
        monitor_tokens=14000,
        evictable_tokens=31000,
        stale_tokens=28000,
        rot_score=rot_score,
        status=status,
        eviction_candidates=[],
        active_issue=None,
    )


# ---------------------------------------------------------------------------
# File writing tests
# ---------------------------------------------------------------------------


def test_write_creates_json_and_md_files() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        context_dir = Path(tmpdir)
        writer = ContextWriter(context_dir=context_dir, project_name="AgentCanvas")
        json_path, md_path = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        assert json_path.exists()
        assert md_path.exists()


def test_write_files_named_by_session_id() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        context_dir = Path(tmpdir)
        writer = ContextWriter(context_dir=context_dir, project_name="AgentCanvas")
        json_path, md_path = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(session_id="abc-123"),
            modified_files=[],
        )
        assert json_path.name == "abc-123.json"
        assert md_path.name == "abc-123.md"


def test_write_creates_context_dir_if_missing() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        context_dir = Path(tmpdir) / "new" / "nested" / "dir"
        writer = ContextWriter(context_dir=context_dir, project_name="AgentCanvas")
        writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        assert context_dir.exists()


# ---------------------------------------------------------------------------
# JSON structure tests
# ---------------------------------------------------------------------------


def test_json_contains_session_id() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(session_id="sess-xyz"),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["session_id"] == "sess-xyz"


def test_json_contains_rot_score() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(rot_score=0.71),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert abs(data["rot_score"] - 0.71) < 0.001


def test_json_contains_status() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(status="red"),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["status"] == "red"


def test_json_contains_token_fields() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["total_tokens"] == 95000
        assert data["keep_tokens"] == 22000
        assert data["evictable_tokens"] == 31000
        assert data["stale_tokens"] == 28000


def test_json_contains_agent_name() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["agent_name"] == "m4-hitl-agent"


def test_json_contains_project_name() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["project"] == "AgentCanvas"


def test_json_contains_git_branch() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["git_branch"] == "feature/M4-backend"


def test_json_active_issue_when_present() -> None:
    issue = IssueRef(
        id=22, title="BC-06 HITLManager", status="in-progress",
        milestone="M4", url="https://example.com/22", tracker="gitlab",
    )
    rot = RotRiskResult(
        total_tokens=50000,
        keep_tokens=10000,
        monitor_tokens=5000,
        evictable_tokens=20000,
        stale_tokens=15000,
        rot_score=0.70,
        status="yellow",
        eviction_candidates=[],
        active_issue=issue,
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=rot,
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["active_issue"] is not None
        assert data["active_issue"]["id"] == 22
        assert data["active_issue"]["title"] == "BC-06 HITLManager"


def test_json_active_issue_null_when_absent() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        data = json.loads(json_path.read_text())
        assert data["active_issue"] is None


def test_json_modified_files_included() -> None:
    files = ["backend/app/core/hitl_manager.py", "backend/app/core/ws_manager.py"]
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        json_path, _ = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=files,
        )
        data = json.loads(json_path.read_text())
        assert data["modified_files"] == files


# ---------------------------------------------------------------------------
# Markdown structure tests
# ---------------------------------------------------------------------------


def test_md_contains_agent_name_in_header() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        content = md_path.read_text()
        assert "m4-hitl-agent" in content


def test_md_contains_rot_pct() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=_make_rot_result(rot_score=0.71),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        content = md_path.read_text()
        assert "71%" in content


def test_md_contains_status() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=_make_rot_result(status="red"),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        content = md_path.read_text()
        assert "RED" in content


def test_md_contains_git_branch() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        content = md_path.read_text()
        assert "feature/M4-backend" in content


def test_md_contains_modified_files() -> None:
    files = ["backend/app/core/hitl_manager.py"]
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=files,
        )
        content = md_path.read_text()
        assert "hitl_manager.py" in content


def test_md_contains_token_summary() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=_make_rot_result(),
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        content = md_path.read_text()
        assert "Keep" in content
        assert "Evictable" in content
        assert "Stale" in content


def test_md_contains_active_issue_section() -> None:
    issue = IssueRef(
        id=22, title="HITLManager", status="in-progress",
        milestone="M4", url="https://example.com/22", tracker="gitlab",
    )
    rot = RotRiskResult(
        total_tokens=50000,
        keep_tokens=10000,
        monitor_tokens=5000,
        evictable_tokens=20000,
        stale_tokens=15000,
        rot_score=0.70,
        status="yellow",
        eviction_candidates=[],
        active_issue=issue,
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        writer = ContextWriter(context_dir=Path(tmpdir), project_name="AgentCanvas")
        _, md_path = writer.write(
            rot_result=rot,
            session_meta=_make_session_meta(),
            modified_files=[],
        )
        content = md_path.read_text()
        assert "#22" in content
        assert "HITLManager" in content
