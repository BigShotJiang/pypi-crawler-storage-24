from vibewatch.config import VibeWatchConfig


def test_defaults() -> None:
    cfg = VibeWatchConfig()
    assert cfg.tool == "auto"
    assert cfg.poll_interval_seconds == 2.0
    assert cfg.monitor_threshold == 0.40
    assert cfg.red_threshold == 0.70


def test_env_override(monkeypatch: object) -> None:
    monkeypatch.setenv("VIBEWATCH_TOOL", "aider")  # type: ignore[attr-defined]
    cfg = VibeWatchConfig()
    assert cfg.tool == "aider"
