from __future__ import annotations

import json
import tempfile
from pathlib import Path

from vibewatch.adapters.claude_code import ClaudeCodeAdapter

MINIMAL_JSONL = [
    {
        "type": "user",
        "uuid": "uuid-001",
        "parentUuid": None,
        "sessionId": "sess-abc",
        "timestamp": "2026-03-23T10:00:00.000Z",
        "isMeta": False,
        "cwd": "/projects/foo",
        "gitBranch": "feature/23-test",
        "message": {"role": "user", "content": "Implement the feature"},
    },
    {
        "type": "assistant",
        "uuid": "uuid-002",
        "parentUuid": "uuid-001",
        "sessionId": "sess-abc",
        "timestamp": "2026-03-23T10:00:05.000Z",
        "message": {
            "role": "assistant",
            "model": "claude-sonnet-4-6",
            "usage": {"input_tokens": 150, "cache_read_input_tokens": 0},
            "content": [
                {"type": "thinking", "thinking": "I should write some code", "signature": "sig"},
                {
                    "type": "tool_use",
                    "id": "toolu-read-1",
                    "name": "Read",
                    "input": {"file_path": "/projects/foo/src/main.py"},
                },
            ],
        },
    },
    {
        "type": "user",
        "uuid": "uuid-003",
        "parentUuid": "uuid-002",
        "sessionId": "sess-abc",
        "timestamp": "2026-03-23T10:00:06.000Z",
        "message": {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "toolu-read-1",
                    "content": "def main(): pass",
                    "is_error": False,
                }
            ],
        },
    },
    # Non-message lines to be ignored
    {"type": "progress", "data": {"type": "hook_progress"}},
    {"type": "file-history-snapshot", "messageId": "x"},
]


def _write_jsonl(path: Path, lines: list[dict]) -> None:
    with open(path, "w") as f:
        for line in lines:
            f.write(json.dumps(line) + "\n")


def test_adapter_parses_correct_block_count() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "session.jsonl"
        _write_jsonl(jsonl_path, MINIMAL_JSONL)
        adapter = ClaudeCodeAdapter(jsonl_path)
        session = adapter.read()
        # user text + thinking + tool_use(Read) + tool_result = 4 blocks
        assert len(session.blocks) == 4


def test_adapter_ignores_progress_lines() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "session.jsonl"
        _write_jsonl(jsonl_path, MINIMAL_JSONL)
        adapter = ClaudeCodeAdapter(jsonl_path)
        session = adapter.read()
        types = {b.block_type for b in session.blocks}
        assert "progress" not in types


def test_adapter_extracts_session_id() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "session.jsonl"
        _write_jsonl(jsonl_path, MINIMAL_JSONL)
        adapter = ClaudeCodeAdapter(jsonl_path)
        session = adapter.read()
        assert session.session_id == "sess-abc"


def test_adapter_extracts_git_branch() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "session.jsonl"
        _write_jsonl(jsonl_path, MINIMAL_JSONL)
        adapter = ClaudeCodeAdapter(jsonl_path)
        session = adapter.read()
        assert session.git_branch == "feature/23-test"


def test_thinking_block_type() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "session.jsonl"
        _write_jsonl(jsonl_path, MINIMAL_JSONL)
        adapter = ClaudeCodeAdapter(jsonl_path)
        session = adapter.read()
        thinking_blocks = [b for b in session.blocks if b.block_type == "thinking"]
        assert len(thinking_blocks) == 1


def test_tool_result_links_tool_use_id() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = Path(tmpdir) / "session.jsonl"
        _write_jsonl(jsonl_path, MINIMAL_JSONL)
        adapter = ClaudeCodeAdapter(jsonl_path)
        session = adapter.read()
        tool_result = next(b for b in session.blocks if b.block_type == "tool_result")
        assert tool_result.tool_use_id == "toolu-read-1"
