from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from vibewatch.adapters.copilot import CopilotAdapter

FIXTURES = Path(__file__).parent.parent / "fixtures"


# ---------------------------------------------------------------------------
# JSON v3 format tests
# ---------------------------------------------------------------------------


def test_copilot_v3_parses_user_blocks() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    user_blocks = [b for b in session.blocks if b.role == "user"]
    assert len(user_blocks) == 2


def test_copilot_v3_parses_assistant_blocks() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    assistant_blocks = [b for b in session.blocks if b.role == "assistant"]
    assert len(assistant_blocks) == 2


def test_copilot_v3_user_content_preview() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    user_blocks = [b for b in session.blocks if b.role == "user"]
    assert "FastAPI" in user_blocks[0].content_preview


def test_copilot_v3_assistant_content_preview() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    assistant_blocks = [b for b in session.blocks if b.role == "assistant"]
    preview = assistant_blocks[0].content_preview
    assert "FastAPI" in preview or "endpoint" in preview


def test_copilot_v3_block_type_is_text() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    assert all(b.block_type == "text" for b in session.blocks)


def test_copilot_v3_no_tool_blocks() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    assert not any(b.block_type in ("tool_use", "tool_result") for b in session.blocks)


def test_copilot_v3_token_estimates_positive() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    assert all(b.token_estimate > 0 for b in session.blocks)


def test_copilot_v3_total_turns() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    # 2 user + 2 assistant = 4 blocks
    assert session.total_turns == 4


def test_copilot_v3_session_id_is_stem() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_v3.json")
    session = adapter.read()
    assert session.session_id == "copilot_v3"


# ---------------------------------------------------------------------------
# JSONL kind-based format tests
# ---------------------------------------------------------------------------


def test_copilot_kindlog_parses_user_blocks() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_kindlog.jsonl")
    session = adapter.read()
    user_blocks = [b for b in session.blocks if b.role == "user"]
    assert len(user_blocks) == 2


def test_copilot_kindlog_parses_assistant_blocks() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_kindlog.jsonl")
    session = adapter.read()
    assistant_blocks = [b for b in session.blocks if b.role == "assistant"]
    assert len(assistant_blocks) == 2


def test_copilot_kindlog_session_id_from_kind0() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_kindlog.jsonl")
    session = adapter.read()
    assert session.session_id == "copilot-kind-session-xyz"


def test_copilot_kindlog_no_tool_blocks() -> None:
    adapter = CopilotAdapter(FIXTURES / "copilot_kindlog.jsonl")
    session = adapter.read()
    assert not any(b.block_type in ("tool_use", "tool_result") for b in session.blocks)


def test_copilot_kindlog_kind12_skipped() -> None:
    """kind=12 tool invocation lines should be silently skipped."""
    with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
        path = Path(f.name)
        f.write(json.dumps({"kind": 0, "sessionId": "test-sess", "creationDate": 0}) + "\n")
        f.write(json.dumps({"kind": 12, "requestId": "r1", "toolName": "read_file"}) + "\n")
        f.write(json.dumps({
            "kind": 2, "requestId": "req-only",
            "timestamp": 1000,
            "prompt": "hello",
            "response": "world",
        }) + "\n")
    try:
        adapter = CopilotAdapter(path)
        session = adapter.read()
        assert len(session.blocks) == 2  # user + assistant, no tool block
    finally:
        path.unlink(missing_ok=True)


def test_copilot_kindlog_records_sorted_by_timestamp() -> None:
    """Records should be ordered by timestamp even if written out of order."""
    with tempfile.NamedTemporaryFile(suffix=".jsonl", mode="w", delete=False) as f:
        path = Path(f.name)
        # Write later record first
        f.write(json.dumps({
            "kind": 2, "requestId": "req-late",
            "timestamp": 2000,
            "prompt": "second question",
            "response": "second answer",
        }) + "\n")
        f.write(json.dumps({
            "kind": 2, "requestId": "req-early",
            "timestamp": 1000,
            "prompt": "first question",
            "response": "first answer",
        }) + "\n")
    try:
        adapter = CopilotAdapter(path)
        session = adapter.read()
        user_blocks = [b for b in session.blocks if b.role == "user"]
        assert "first question" in user_blocks[0].content_preview
    finally:
        path.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# find_copilot_sessions tests (workspace.json matching)
# ---------------------------------------------------------------------------


def test_find_copilot_sessions_returns_empty_when_appdata_missing(
    monkeypatch: object,
) -> None:
    import vibewatch.core.detector as det
    monkeypatch.setenv("APPDATA", "/nonexistent/path/that/does/not/exist")  # type: ignore[attr-defined]
    result = det.find_copilot_sessions(Path("/some/project"), "copilot")
    assert result == []


def test_find_copilot_sessions_matches_project_dir(
    tmp_path: Path, monkeypatch: object
) -> None:
    """Simulate the workspaceStorage layout and verify matching."""
    import vibewatch.core.detector as det

    # Build fake workspaceStorage
    app_data = tmp_path / "AppData" / "Roaming"
    ws_root = app_data / "Code" / "User" / "workspaceStorage" / "abc123"
    ws_root.mkdir(parents=True)

    project_dir = tmp_path / "my-project"
    project_dir.mkdir()

    # workspace.json with file:/// URI
    folder_uri = "file:///" + str(project_dir.resolve()).replace(os.sep, "/")
    (ws_root / "workspace.json").write_text(
        json.dumps({"folder": folder_uri}), encoding="utf-8"
    )

    # chatSessions with one .json file
    chat_dir = ws_root / "chatSessions"
    chat_dir.mkdir()
    (chat_dir / "session1.json").write_text("{}", encoding="utf-8")

    monkeypatch.setenv("APPDATA", str(app_data))  # type: ignore[attr-defined]

    results = det.find_copilot_sessions(project_dir, "copilot")
    assert len(results) == 1
    assert results[0].name == "session1.json"


def test_find_copilot_sessions_no_match_for_different_dir(
    tmp_path: Path, monkeypatch: object
) -> None:
    import vibewatch.core.detector as det

    app_data = tmp_path / "AppData" / "Roaming"
    ws_root = app_data / "Code" / "User" / "workspaceStorage" / "abc123"
    ws_root.mkdir(parents=True)

    project_a = tmp_path / "project-a"
    project_b = tmp_path / "project-b"
    project_a.mkdir()
    project_b.mkdir()

    folder_uri = "file:///" + str(project_a.resolve()).replace(os.sep, "/")
    (ws_root / "workspace.json").write_text(
        json.dumps({"folder": folder_uri}), encoding="utf-8"
    )
    chat_dir = ws_root / "chatSessions"
    chat_dir.mkdir()
    (chat_dir / "session1.json").write_text("{}", encoding="utf-8")

    monkeypatch.setenv("APPDATA", str(app_data))  # type: ignore[attr-defined]

    # Searching for project_b should find nothing
    results = det.find_copilot_sessions(project_b, "copilot")
    assert results == []
