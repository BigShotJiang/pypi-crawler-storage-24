from __future__ import annotations

import tempfile
from pathlib import Path

from vibewatch.adapters.aider import AiderAdapter

SAMPLE_HISTORY = """\
# aider chat started at 2026-03-23 10:00:00

> /add src/main.py

#### Implement the feature

```python
def main():
    print("hello")
```

Some assistant explanation text here.

---
"""


def test_parses_command_block() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / ".aider.chat.history.md"
        p.write_text(SAMPLE_HISTORY)
        adapter = AiderAdapter(p)
        session = adapter.read()
        commands = [b for b in session.blocks if b.block_type == "command"]
        assert len(commands) == 1
        assert "/add" in commands[0].content_preview


def test_parses_user_text_block() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / ".aider.chat.history.md"
        p.write_text(SAMPLE_HISTORY)
        adapter = AiderAdapter(p)
        session = adapter.read()
        user_blocks = [b for b in session.blocks if b.role == "user"]
        assert any("Implement the feature" in b.content_preview for b in user_blocks)


def test_parses_code_block() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / ".aider.chat.history.md"
        p.write_text(SAMPLE_HISTORY)
        adapter = AiderAdapter(p)
        session = adapter.read()
        code_blocks = [b for b in session.blocks if b.block_type == "code"]
        assert len(code_blocks) == 1


def test_all_blocks_have_positive_tokens() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / ".aider.chat.history.md"
        p.write_text(SAMPLE_HISTORY)
        adapter = AiderAdapter(p)
        session = adapter.read()
        assert all(b.token_estimate > 0 for b in session.blocks)
