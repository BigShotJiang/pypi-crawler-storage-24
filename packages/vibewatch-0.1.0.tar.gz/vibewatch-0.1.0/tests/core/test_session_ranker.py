from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from vibewatch.core.session_ranker import classify_session, rank_sessions

FIXTURES = Path(__file__).parent.parent / "fixtures"


# ---------------------------------------------------------------------------
# classify_session tests
# ---------------------------------------------------------------------------


def test_classify_orchestrator_is_subagent_false() -> None:
    meta = classify_session(FIXTURES / "orchestrator_session.jsonl")
    assert meta.is_subagent is False


def test_classify_subagent_is_subagent_true() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.is_subagent is True


def test_classify_subagent_agent_name() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.agent_name == "m4-hitl-redis-websocket-auth"


def test_classify_unclassified_is_subagent_none() -> None:
    meta = classify_session(FIXTURES / "unclassified_session.jsonl")
    assert meta.is_subagent is None


def test_classify_orchestrator_output_tokens() -> None:
    meta = classify_session(FIXTURES / "orchestrator_session.jsonl")
    assert meta.output_tokens == 2488


def test_classify_subagent_output_tokens() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.output_tokens == 21221


def test_classify_subagent_cache_creation_tokens() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.cache_creation_tokens == 4000


def test_classify_subagent_cache_read_tokens() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.cache_read_tokens == 60000


def test_classify_cost_proxy_formula() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    expected = 21221 + 4000 * 0.25 + 60000 * 0.03
    assert abs(meta.cost_proxy - expected) < 0.01


def test_classify_slug_extracted() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.slug == "refactored-wandering-lecun"


def test_classify_git_branch() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.git_branch == "feature/M4-backend"


def test_classify_cwd() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.cwd == "/projects/AgentCanvas"


def test_classify_turn_duration_ms() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.total_turn_duration_ms == 5100000


def test_classify_wall_clock_positive() -> None:
    meta = classify_session(FIXTURES / "subagent_session.jsonl")
    assert meta.wall_clock_seconds > 0


def test_classify_orchestrator_wall_clock() -> None:
    meta = classify_session(FIXTURES / "orchestrator_session.jsonl")
    # 10:00:00 to 10:05:00 is 300 seconds (turn_duration line is 3s after)
    assert meta.wall_clock_seconds >= 300


def test_classify_empty_file_returns_zero_meta() -> None:
    with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
        empty_path = Path(f.name)
    try:
        empty_path.write_text("")
        meta = classify_session(empty_path)
        assert meta.is_subagent is None
        assert meta.output_tokens == 0
        assert meta.cost_proxy == 0.0
    finally:
        empty_path.unlink(missing_ok=True)


def test_classify_nonexistent_file_returns_zero_meta() -> None:
    meta = classify_session(Path("/nonexistent/path/session.jsonl"))
    assert meta.is_subagent is None
    assert meta.output_tokens == 0


def test_classify_session_id_extracted() -> None:
    meta = classify_session(FIXTURES / "orchestrator_session.jsonl")
    assert meta.session_id == "orch-sess-aaa"


# ---------------------------------------------------------------------------
# rank_sessions tests
# ---------------------------------------------------------------------------


def _write_jsonl(path: Path, lines: list[dict]) -> None:  # type: ignore[type-arg]
    with open(path, "w") as f:
        for line in lines:
            f.write(json.dumps(line) + "\n")


def test_rank_sessions_returns_empty_for_empty_dir(tmp_path: Path) -> None:
    # rank_sessions looks in ~/.claude/projects/<encoded>, which doesn't exist for tmp_path
    result = rank_sessions(tmp_path)
    assert result == []


def _make_fake_rank_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> tuple[Path, Path]:
    """Set up a fake home + project dir for rank_sessions tests.

    Returns (project_dir, claude_dir).
    Sets Path.home() → tmp_path and uses a short fixed name to avoid
    Windows MAX_PATH issues with the encoded directory name.
    """
    import time

    # Patch home first so the encoded path is relative to tmp_path
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))  # type: ignore[arg-type]
    monkeypatch.setattr(time, "time", lambda: 9999999999.0)

    # Use a short fixed project path (relative to the fake home)
    # so the encoded name stays short
    project_dir = Path("C:/P/proj")

    from vibewatch.core.detector import encode_path_for_claude
    encoded = encode_path_for_claude(project_dir)
    claude_dir = tmp_path / ".claude" / "projects" / encoded
    claude_dir.mkdir(parents=True)
    return project_dir, claude_dir


def test_rank_sessions_subagent_ranks_by_cost_proxy(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Verify that within a slug group, subagents rank by cost_proxy descending."""
    project_dir, claude_dir = _make_fake_rank_env(tmp_path, monkeypatch)

    cheap = claude_dir / "cheap.jsonl"
    expensive = claude_dir / "expensive.jsonl"

    _write_jsonl(cheap, [
        {"type": "custom-title", "customTitle": "cheap-agent", "sessionId": "cheap-1",
         "timestamp": "2026-03-19T10:00:00.000Z", "slug": "same-slug"},
        {"type": "user", "uuid": "u1", "sessionId": "cheap-1",
         "timestamp": "2026-03-19T10:00:01.000Z", "planContent": "plan",
         "message": {"role": "user", "content": "do it"}},
        {"type": "assistant", "uuid": "a1", "sessionId": "cheap-1",
         "timestamp": "2026-03-19T10:00:05.000Z", "slug": "same-slug",
         "message": {"role": "assistant",
                     "usage": {"output_tokens": 100, "cache_creation_input_tokens": 0,
                                "cache_read_input_tokens": 0},
                     "content": [{"type": "text", "text": "done"}]}},
    ])
    _write_jsonl(expensive, [
        {"type": "custom-title", "customTitle": "expensive-agent", "sessionId": "exp-1",
         "timestamp": "2026-03-19T10:00:00.000Z", "slug": "same-slug"},
        {"type": "user", "uuid": "u2", "sessionId": "exp-1",
         "timestamp": "2026-03-19T10:00:01.000Z", "planContent": "plan",
         "message": {"role": "user", "content": "do it"}},
        {"type": "assistant", "uuid": "a2", "sessionId": "exp-1",
         "timestamp": "2026-03-19T10:00:05.000Z", "slug": "same-slug",
         "message": {"role": "assistant",
                     "usage": {"output_tokens": 5000, "cache_creation_input_tokens": 0,
                                "cache_read_input_tokens": 0},
                     "content": [{"type": "text", "text": "done"}]}},
    ])

    result = rank_sessions(project_dir)
    assert len(result) == 2
    assert result[0].output_tokens == 5000  # expensive first
    assert result[1].output_tokens == 100


def test_rank_sessions_orchestrator_before_subagent(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Orchestrator (is_subagent=False) should rank before subagents within same slug group."""
    project_dir, claude_dir = _make_fake_rank_env(tmp_path, monkeypatch)

    orch = claude_dir / "orch.jsonl"
    sub = claude_dir / "sub.jsonl"

    _write_jsonl(orch, [
        {"type": "user", "uuid": "u1", "sessionId": "orch-1",
         "timestamp": "2026-03-19T10:00:00.000Z", "slug": "shared-slug",
         "message": {"role": "user", "content": "orchestrate"}},
        {"type": "assistant", "uuid": "a1", "sessionId": "orch-1",
         "timestamp": "2026-03-19T10:00:10.000Z", "slug": "shared-slug",
         "message": {"role": "assistant",
                     "usage": {"output_tokens": 200, "cache_creation_input_tokens": 0,
                                "cache_read_input_tokens": 0},
                     "content": [{"type": "text", "text": "dispatching"}]}},
    ])
    _write_jsonl(sub, [
        {"type": "custom-title", "customTitle": "impl-agent", "sessionId": "sub-1",
         "timestamp": "2026-03-19T10:00:00.000Z", "slug": "shared-slug"},
        {"type": "user", "uuid": "u2", "sessionId": "sub-1",
         "timestamp": "2026-03-19T10:00:01.000Z", "planContent": "plan",
         "message": {"role": "user", "content": "implement"}},
        {"type": "assistant", "uuid": "a2", "sessionId": "sub-1",
         "timestamp": "2026-03-19T10:00:15.000Z", "slug": "shared-slug",
         "message": {"role": "assistant",
                     "usage": {"output_tokens": 10000, "cache_creation_input_tokens": 0,
                                "cache_read_input_tokens": 0},
                     "content": [{"type": "text", "text": "implemented"}]}},
    ])

    result = rank_sessions(project_dir)
    assert len(result) == 2
    assert result[0].is_subagent is False
    assert result[1].is_subagent is True
