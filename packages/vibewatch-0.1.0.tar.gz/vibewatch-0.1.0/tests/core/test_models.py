from dataclasses import fields

from vibewatch.core.models import ContextBlock, RotRiskResult


def test_context_block_fields() -> None:
    required = {
        "id", "turn_index", "role", "block_type", "tool_name",
        "tool_use_id", "tool_input", "is_error", "token_estimate",
        "content_preview", "recency_score", "decay_class",
    }
    actual = {f.name for f in fields(ContextBlock)}
    assert required == actual


def test_rot_risk_result_token_sum() -> None:
    result = RotRiskResult(
        total_tokens=100,
        keep_tokens=40,
        monitor_tokens=20,
        evictable_tokens=25,
        stale_tokens=15,
        rot_score=0.0,
        status="green",
        eviction_candidates=[],
        active_issue=None,
    )
    token_sum = (
        result.keep_tokens + result.monitor_tokens
        + result.evictable_tokens + result.stale_tokens
    )
    assert token_sum == result.total_tokens
