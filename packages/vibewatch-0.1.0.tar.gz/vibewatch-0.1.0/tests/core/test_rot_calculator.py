from __future__ import annotations

from vibewatch.core.models import ContextBlock, IssueRef
from vibewatch.core.rot_calculator import RotCalculator


def make_block(
    turn_index: int,
    block_type: str = "text",
    role: str = "assistant",
    tool_name: str | None = None,
    tool_use_id: str | None = None,
    tool_input: dict | None = None,
    is_error: bool = False,
    tokens: int = 100,
    content_preview: str = "",
) -> ContextBlock:
    return ContextBlock(
        id=f"block-{turn_index}",
        turn_index=turn_index,
        role=role,
        block_type=block_type,
        tool_name=tool_name,
        tool_use_id=tool_use_id,
        tool_input=tool_input,
        is_error=is_error,
        token_estimate=tokens,
        content_preview=content_preview,
        recency_score=0.0,
        decay_class="",
    )


def test_last_5_blocks_are_always_keep() -> None:
    blocks = [make_block(i) for i in range(10)]
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=None)
    keep_indices = {b.turn_index for b in result.eviction_candidates}
    # last 5 (5-9) should NOT appear as eviction candidates
    assert not keep_indices.intersection({5, 6, 7, 8, 9})


def test_user_messages_always_keep() -> None:
    blocks = [make_block(i, role="user", block_type="text") for i in range(20)]
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=None)
    assert result.eviction_candidates == []


def test_thinking_blocks_are_evictable() -> None:
    blocks = [make_block(i) for i in range(20)]
    thinking = make_block(5, block_type="thinking", tokens=500)
    blocks[5] = thinking
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=None)
    evictable_ids = {b.id for b in result.eviction_candidates}
    assert "block-5" in evictable_ids


def test_token_sum_invariant() -> None:
    blocks = [make_block(i, tokens=50) for i in range(30)]
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=None)
    total = (
        result.keep_tokens + result.monitor_tokens
        + result.evictable_tokens + result.stale_tokens
    )
    assert total == result.total_tokens


def test_rot_score_all_keep_is_zero() -> None:
    # 20 user messages — all should be keep, rot_score must be 0.0
    # (uses the user-message keep rule, not just the last-5 rule)
    blocks = [make_block(i, role="user", block_type="text") for i in range(20)]
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=None)
    assert result.rot_score == 0.0
    assert result.status == "green"
    assert result.monitor_tokens == 0
    assert result.evictable_tokens == 0
    assert result.stale_tokens == 0


def test_rot_score_stale_tool_results_produce_high_score() -> None:
    # 40 old tool_result blocks (all far from last 5, none referenced recently) +
    # 5 recent keep blocks. With max_turn=44, stale threshold=34.
    # Blocks 0-33 = 34 stale (3400t), 34-39 = 6 monitor (600t), 40-44 = 5 keep (500t).
    # rot_score = (3400/4500)*0.50 + (600/4500)*0.20 ~= 0.404 (yellow).
    stale_blocks = [
        make_block(i, block_type="tool_result", tool_use_id=f"tid-{i}", tokens=100)
        for i in range(40)
    ]
    recent_blocks = [
        make_block(40 + i, role="user", block_type="text", tokens=100) for i in range(5)
    ]
    calc = RotCalculator()
    result = calc.score(stale_blocks + recent_blocks, active_issue=None)
    assert result.stale_tokens > 0, "Old tool_results should be classified stale"
    assert result.rot_score >= 0.30, f"Expected rot_score >= 0.30, got {result.rot_score}"
    assert result.status in ("yellow", "red")


def test_old_command_blocks_always_keep() -> None:
    # Aider command blocks should always be keep regardless of age
    blocks = [make_block(i, role="user", block_type="command", tokens=50) for i in range(30)]
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=None)
    assert result.keep_tokens == 30 * 50
    assert result.monitor_tokens == 0
    assert result.evictable_tokens == 0
    assert result.stale_tokens == 0


def test_active_issue_keyword_keeps_block() -> None:
    issue = IssueRef(
        id=23, title="HITL queue page", status="In Progress",
        milestone="M4", url="https://example.com/23", tracker="gitlab"
    )
    block = make_block(0, block_type="text", content_preview="Working on HITL queue implementation")
    blocks = [block] + [make_block(i + 1) for i in range(15)]
    calc = RotCalculator()
    result = calc.score(blocks, active_issue=issue)
    # block-0 should be keep due to "HITL" keyword match
    evictable_ids = {b.id for b in result.eviction_candidates}
    assert "block-0" not in evictable_ids
