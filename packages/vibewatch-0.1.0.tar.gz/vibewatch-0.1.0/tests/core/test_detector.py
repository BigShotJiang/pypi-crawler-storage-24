from __future__ import annotations

import tempfile
from pathlib import Path

from vibewatch.core.detector import detect_tool


def test_encode_path_replaces_separators() -> None:
    # Test the encoding algorithm using the raw string replacement rules
    # (avoid Path.resolve() which is platform-dependent)
    from vibewatch.core.detector import _encode_path_str
    result = _encode_path_str("C:/Users/Foo/Projects/Bar")
    assert result == "C--Users-Foo-Projects-Bar"

    result_backslash = _encode_path_str("C:\\Users\\Foo\\Projects\\Bar")
    assert result_backslash == "C--Users-Foo-Projects-Bar"


def test_detect_aider_when_history_file_exists() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        (p / ".aider.chat.history.md").write_text("# aider chat")
        result = detect_tool(p)
        assert result == "aider"


def test_detect_unknown_for_empty_dir() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        result = detect_tool(Path(tmpdir))
        assert result == "unknown"
