from vibewatch.tui.dashboard import _bar


def test_bar_empty() -> None:
    result = _bar(0.0, width=8)
    assert result == "[░░░░░░░░]"


def test_bar_full() -> None:
    result = _bar(100.0, width=8)
    assert result == "[████████]"


def test_bar_half() -> None:
    result = _bar(50.0, width=8)
    assert result == "[████░░░░]"
