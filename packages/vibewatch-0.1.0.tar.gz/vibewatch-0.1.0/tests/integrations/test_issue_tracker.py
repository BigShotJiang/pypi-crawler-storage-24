from __future__ import annotations

from vibewatch.integrations.issue_tracker import extract_issue_number


def test_extract_issue_number_feature_branch() -> None:
    assert extract_issue_number("feature/23-hitl-queue-page") == 23


def test_extract_issue_number_fix_branch() -> None:
    assert extract_issue_number("fix/7-login-bug") == 7


def test_extract_issue_number_no_match() -> None:
    assert extract_issue_number("main") is None


def test_extract_issue_number_chore_branch() -> None:
    assert extract_issue_number("chore/15-update-deps") == 15
