from vibewatch.adapters.copilot import CopilotAdapter

__all__ = ["CopilotAdapter"]
