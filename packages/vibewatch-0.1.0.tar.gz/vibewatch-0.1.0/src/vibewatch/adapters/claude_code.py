from __future__ import annotations

import json
from typing import Any

import tiktoken

from vibewatch.adapters.base import SessionAdapter
from vibewatch.core.models import ContextBlock, SessionState

_TOKENIZER = tiktoken.get_encoding("cl100k_base")
_SKIP_TYPES = frozenset({"progress", "file-history-snapshot"})


def _estimate_tokens(text: str) -> int:
    return len(_TOKENIZER.encode(text))


def _preview(text: str) -> str:
    return text[:120]


class ClaudeCodeAdapter(SessionAdapter):
    """Reads Claude Code JSONL transcript files."""

    def read(self) -> SessionState:
        lines = self._source_path.read_text(encoding="utf-8").splitlines()

        session_id = ""
        project_path = ""
        git_branch = ""
        blocks: list[ContextBlock] = []
        turn_index = 0

        for raw_line in lines:
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            try:
                obj: dict[str, Any] = json.loads(raw_line)
            except json.JSONDecodeError:
                continue

            msg_type: str = obj.get("type", "")
            if msg_type in _SKIP_TYPES:
                continue

            # Extract session metadata from any line that carries it
            if not session_id and obj.get("sessionId"):
                session_id = obj["sessionId"]
            if not project_path and obj.get("cwd"):
                project_path = obj["cwd"]
            if not git_branch and obj.get("gitBranch"):
                git_branch = obj["gitBranch"]

            message = obj.get("message", {})
            content = message.get("content", "")

            if msg_type == "user":
                if isinstance(content, str):
                    # Plain user text message
                    tokens = _estimate_tokens(content)
                    blocks.append(ContextBlock(
                        id=obj.get("uuid", f"auto-{turn_index}"),
                        turn_index=turn_index,
                        role="user",
                        block_type="text",
                        tool_name=None,
                        tool_use_id=None,
                        tool_input=None,
                        is_error=False,
                        token_estimate=tokens,
                        content_preview=_preview(content),
                        recency_score=0.0,
                        decay_class="",
                    ))
                    turn_index += 1
                elif isinstance(content, list):
                    # Tool results
                    for item in content:
                        if not isinstance(item, dict):
                            continue
                        if item.get("type") != "tool_result":
                            continue
                        item_content = item.get("content", "")
                        if isinstance(item_content, list):
                            text = " ".join(
                                c.get("text", "") for c in item_content
                                if isinstance(c, dict)
                            )
                        else:
                            text = str(item_content)
                        tokens = _estimate_tokens(text)
                        blocks.append(ContextBlock(
                            id=obj.get("uuid", f"auto-{turn_index}"),
                            turn_index=turn_index,
                            role="user",
                            block_type="tool_result",
                            tool_name=None,
                            tool_use_id=item.get("tool_use_id"),
                            tool_input=None,
                            is_error=bool(item.get("is_error", False)),
                            token_estimate=tokens,
                            content_preview=_preview(text),
                            recency_score=0.0,
                            decay_class="",
                        ))
                        turn_index += 1

            elif msg_type == "assistant":
                if not isinstance(content, list):
                    continue
                for item in content:
                    if not isinstance(item, dict):
                        continue
                    item_type = item.get("type", "")

                    if item_type == "thinking":
                        text = item.get("thinking", "")
                        tokens = _estimate_tokens(text)
                        blocks.append(ContextBlock(
                            id=obj.get("uuid", f"auto-{turn_index}"),
                            turn_index=turn_index,
                            role="assistant",
                            block_type="thinking",
                            tool_name=None,
                            tool_use_id=None,
                            tool_input=None,
                            is_error=False,
                            token_estimate=tokens,
                            content_preview=_preview(text),
                            recency_score=0.0,
                            decay_class="",
                        ))
                        turn_index += 1

                    elif item_type == "tool_use":
                        tool_input = item.get("input", {})
                        text = json.dumps(tool_input)
                        tokens = _estimate_tokens(text)
                        blocks.append(ContextBlock(
                            id=obj.get("uuid", f"auto-{turn_index}"),
                            turn_index=turn_index,
                            role="assistant",
                            block_type="tool_use",
                            tool_name=item.get("name"),
                            tool_use_id=item.get("id"),
                            tool_input=tool_input,
                            is_error=False,
                            token_estimate=tokens,
                            content_preview=_preview(text),
                            recency_score=0.0,
                            decay_class="",
                        ))
                        turn_index += 1

                    elif item_type == "text":
                        text = item.get("text", "")
                        tokens = _estimate_tokens(text)
                        blocks.append(ContextBlock(
                            id=obj.get("uuid", f"auto-{turn_index}"),
                            turn_index=turn_index,
                            role="assistant",
                            block_type="text",
                            tool_name=None,
                            tool_use_id=None,
                            tool_input=None,
                            is_error=False,
                            token_estimate=tokens,
                            content_preview=_preview(text),
                            recency_score=0.0,
                            decay_class="",
                        ))
                        turn_index += 1

        return SessionState(
            session_id=session_id,
            project_path=project_path,
            git_branch=git_branch,
            total_turns=turn_index,
            blocks=blocks,
        )
