from __future__ import annotations

import re

import tiktoken

from vibewatch.adapters.base import SessionAdapter
from vibewatch.core.models import ContextBlock, SessionState

_TOKENIZER = tiktoken.get_encoding("cl100k_base")
_CODE_FENCE = re.compile(r"^```")


def _estimate_tokens(text: str) -> int:
    return max(1, len(_TOKENIZER.encode(text)))


def _preview(text: str) -> str:
    return text.strip()[:120]


class AiderAdapter(SessionAdapter):
    """Reads Aider .aider.chat.history.md files."""

    def read(self) -> SessionState:
        text = self._source_path.read_text(encoding="utf-8")
        blocks: list[ContextBlock] = []
        turn_index = 0
        lines = text.splitlines()

        in_code_block = False
        code_lines: list[str] = []
        i = 0

        while i < len(lines):
            line = lines[i]

            if _CODE_FENCE.match(line):
                if in_code_block:
                    # End of code block
                    code_text = "\n".join(code_lines)
                    blocks.append(ContextBlock(
                        id=f"aider-{turn_index}",
                        turn_index=turn_index,
                        role="assistant",
                        block_type="code",
                        tool_name=None,
                        tool_use_id=None,
                        tool_input=None,
                        is_error=False,
                        token_estimate=_estimate_tokens(code_text),
                        content_preview=_preview(code_text),
                        recency_score=0.0,
                        decay_class="",
                    ))
                    turn_index += 1
                    in_code_block = False
                    code_lines = []
                else:
                    in_code_block = True
                i += 1
                continue

            if in_code_block:
                code_lines.append(line)
                i += 1
                continue

            # Aider command: lines starting with "> "
            if line.startswith("> "):
                cmd = line[2:].strip()
                if cmd:
                    blocks.append(ContextBlock(
                        id=f"aider-{turn_index}",
                        turn_index=turn_index,
                        role="user",
                        block_type="command",
                        tool_name=None,
                        tool_use_id=None,
                        tool_input=None,
                        is_error=False,
                        token_estimate=_estimate_tokens(cmd),
                        content_preview=_preview(cmd),
                        recency_score=0.0,
                        decay_class="",
                    ))
                    turn_index += 1
                i += 1
                continue

            # User message: lines starting with "#### "
            if line.startswith("#### "):
                msg = line[5:].strip()
                blocks.append(ContextBlock(
                    id=f"aider-{turn_index}",
                    turn_index=turn_index,
                    role="user",
                    block_type="text",
                    tool_name=None,
                    tool_use_id=None,
                    tool_input=None,
                    is_error=False,
                    token_estimate=_estimate_tokens(msg),
                    content_preview=_preview(msg),
                    recency_score=0.0,
                    decay_class="",
                ))
                turn_index += 1
                i += 1
                continue

            # Skip session header and horizontal rules
            if line.startswith("# aider chat") or line.strip() in ("---", ""):
                i += 1
                continue

            # Plain assistant text paragraph
            if line.strip():
                blocks.append(ContextBlock(
                    id=f"aider-{turn_index}",
                    turn_index=turn_index,
                    role="assistant",
                    block_type="text",
                    tool_name=None,
                    tool_use_id=None,
                    tool_input=None,
                    is_error=False,
                    token_estimate=_estimate_tokens(line),
                    content_preview=_preview(line),
                    recency_score=0.0,
                    decay_class="",
                ))
                turn_index += 1

            i += 1

        session_id = self._source_path.stem
        return SessionState(
            session_id=session_id,
            project_path=str(self._source_path.parent),
            git_branch="",
            total_turns=turn_index,
            blocks=blocks,
        )
