from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import tiktoken

from vibewatch.adapters.base import SessionAdapter
from vibewatch.core.models import ContextBlock, SessionState

_TOKENIZER = tiktoken.get_encoding("cl100k_base")


def _estimate_tokens(text: str) -> int:
    return len(_TOKENIZER.encode(text))


def _preview(text: str) -> str:
    return text[:120]


def _is_json_v3(path: Path) -> bool:
    """Return True if file is a JSON v3 chat file (has top-level "requests" list)."""
    if path.suffix.lower() != ".json":
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return isinstance(data, dict) and "requests" in data
    except (OSError, json.JSONDecodeError):
        return False


def _parse_json_v3(path: Path) -> SessionState:
    """Parse VS Code Copilot JSON v3 format.

    Schema: {"version": 3, "requests": [{
        "message": {"text": "..."},
        "response": [{"value": "..."}, ...],
        "result": {"timings": {"totalElapsed": 1234}}
    }, ...]}
    """
    data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    requests: list[dict[str, Any]] = data.get("requests", [])

    blocks: list[ContextBlock] = []
    turn_index = 0
    session_id = path.stem

    for req in requests:
        # User turn
        user_text: str = req.get("message", {}).get("text", "") or ""
        if user_text:
            tokens = _estimate_tokens(user_text)
            blocks.append(ContextBlock(
                id=f"{session_id}-u{turn_index}",
                turn_index=turn_index,
                role="user",
                block_type="text",
                tool_name=None,
                tool_use_id=None,
                tool_input=None,
                is_error=False,
                token_estimate=tokens,
                content_preview=_preview(user_text),
                recency_score=0.0,
                decay_class="",
            ))
            turn_index += 1

        # Assistant turn — flatten response items
        response_parts: list[str] = []
        for item in req.get("response", []):
            if not isinstance(item, dict):
                continue
            value: str = item.get("value", "") or ""
            if value:
                response_parts.append(value)

        assistant_text = " ".join(response_parts).strip()
        if assistant_text:
            tokens = _estimate_tokens(assistant_text)
            blocks.append(ContextBlock(
                id=f"{session_id}-a{turn_index}",
                turn_index=turn_index,
                role="assistant",
                block_type="text",
                tool_name=None,
                tool_use_id=None,
                tool_input=None,
                is_error=False,
                token_estimate=tokens,
                content_preview=_preview(assistant_text),
                recency_score=0.0,
                decay_class="",
            ))
            turn_index += 1

    return SessionState(
        session_id=session_id,
        project_path="",
        git_branch="",
        total_turns=turn_index,
        blocks=blocks,
    )


def _parse_kindlog(path: Path) -> SessionState:
    """Parse VS Code Copilot JSONL kind-based format.

    Line kinds:
        kind=0  session metadata (creationDate)
        kind=2  request/response data (timestamp ms epoch)
        kind=12 tool invocations (skipped — incompatible format)
    """
    raw_lines = [ln.strip() for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    session_id = path.stem

    # Accumulate records by requestId
    records: dict[str, dict[str, Any]] = {}

    for raw in raw_lines:
        try:
            obj: dict[str, Any] = json.loads(raw)
        except json.JSONDecodeError:
            continue

        kind: int = int(obj.get("kind", -1))

        if kind == 12:
            # Tool invocations — skip, format incompatible with Claude Code blocks
            continue

        if kind == 0:
            # Session metadata
            session_id = obj.get("sessionId", session_id) or session_id
            continue

        if kind == 2:
            req_id: str = str(obj.get("requestId", ""))
            if req_id not in records:
                records[req_id] = {}
            records[req_id].update(obj)

    blocks: list[ContextBlock] = []
    turn_index = 0

    # Sort records by timestamp (ms epoch)
    sorted_records = sorted(
        records.values(),
        key=lambda r: int(r.get("timestamp", 0)),
    )

    for rec in sorted_records:
        user_text: str = rec.get("prompt", "") or rec.get("userMessage", "") or ""
        if user_text:
            tokens = _estimate_tokens(user_text)
            blocks.append(ContextBlock(
                id=f"{session_id}-u{turn_index}",
                turn_index=turn_index,
                role="user",
                block_type="text",
                tool_name=None,
                tool_use_id=None,
                tool_input=None,
                is_error=False,
                token_estimate=tokens,
                content_preview=_preview(user_text),
                recency_score=0.0,
                decay_class="",
            ))
            turn_index += 1

        assistant_text: str = rec.get("response", "") or rec.get("assistantMessage", "") or ""
        if assistant_text:
            tokens = _estimate_tokens(assistant_text)
            blocks.append(ContextBlock(
                id=f"{session_id}-a{turn_index}",
                turn_index=turn_index,
                role="assistant",
                block_type="text",
                tool_name=None,
                tool_use_id=None,
                tool_input=None,
                is_error=False,
                token_estimate=tokens,
                content_preview=_preview(assistant_text),
                recency_score=0.0,
                decay_class="",
            ))
            turn_index += 1

    return SessionState(
        session_id=session_id,
        project_path="",
        git_branch="",
        total_turns=turn_index,
        blocks=blocks,
    )


class CopilotAdapter(SessionAdapter):
    """Reads VS Code Copilot (or Cursor) chat session files.

    Supports two formats:
    - JSON v3 (.json): {"version": 3, "requests": [...]}
    - JSONL kind-based (.jsonl): one JSON object per line, kind field
    """

    def read(self) -> SessionState:
        if _is_json_v3(self._source_path):
            return _parse_json_v3(self._source_path)
        return _parse_kindlog(self._source_path)
