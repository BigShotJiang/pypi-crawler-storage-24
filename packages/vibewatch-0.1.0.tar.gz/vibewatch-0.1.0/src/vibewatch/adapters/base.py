from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from vibewatch.core.models import SessionState


class SessionAdapter(ABC):
    """Common interface for all AI tool transcript adapters."""

    def __init__(self, source_path: Path) -> None:
        self._source_path = source_path

    @abstractmethod
    def read(self) -> SessionState:
        """Read transcript and return parsed SessionState."""
        ...

    @property
    def source_path(self) -> Path:
        return self._source_path
