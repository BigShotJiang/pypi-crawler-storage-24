from __future__ import annotations

import threading
import time
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Footer, Header, Static

from vibewatch.adapters.base import SessionAdapter
from vibewatch.config import VibeWatchConfig
from vibewatch.core.models import IssueRef, RotRiskResult
from vibewatch.core.rot_calculator import RotCalculator
from vibewatch.generators.handoff import HandoffGenerator


def _bar(filled_pct: float, width: int = 8) -> str:
    filled = int(filled_pct / 100 * width)
    return "[" + "\u2588" * filled + "\u2591" * (width - filled) + "]"


class TokenBudgetPanel(Static):
    DEFAULT_CSS = "TokenBudgetPanel { border: solid green; height: 8; width: 1fr; }"

    def update_data(self, result: RotRiskResult, model_limit: int = 200_000) -> None:
        pct = result.total_tokens / model_limit * 100
        bar = _bar(pct, width=10)
        self.update(
            f"TOKEN BUDGET\n\n"
            f"~{result.total_tokens:,}/{model_limit // 1000}k\n"
            f"{bar}\n"
            f"~{pct:.1f}% used\n"
            f"(est. \u00b120%)"
        )


class BreakdownPanel(Static):
    DEFAULT_CSS = "BreakdownPanel { border: solid blue; height: 8; width: 1fr; }"

    def update_data(self, result: RotRiskResult) -> None:
        total = max(result.total_tokens, 1)
        keep_pct = result.keep_tokens / total * 100
        monitor_pct = result.monitor_tokens / total * 100
        evict_pct = result.evictable_tokens / total * 100
        stale_pct = result.stale_tokens / total * 100
        self.update(
            f"CONTEXT BREAKDOWN\n\n"
            f"{_bar(keep_pct, 6)} Keep    {keep_pct:.0f}%\n"
            f"{_bar(monitor_pct, 6)} Monitor {monitor_pct:.0f}%\n"
            f"{_bar(evict_pct, 6)} Evict   {evict_pct:.0f}%\n"
            f"{_bar(stale_pct, 6)} Stale   {stale_pct:.0f}%"
        )


class RotRiskPanel(Static):
    DEFAULT_CSS = "RotRiskPanel { border: solid red; height: 8; width: 1fr; }"

    def update_data(self, result: RotRiskResult) -> None:
        rot_pct = int(result.rot_score * 100)
        color_map = {"green": "FRESH", "yellow": "MONITOR", "red": "ACT NOW"}
        label = color_map.get(result.status, result.status.upper())
        evictable = result.evictable_tokens + result.stale_tokens
        self.update(
            f"ROT RISK\n\n"
            f"{_bar(rot_pct, 8)} {rot_pct}%\n\n"
            f"STATUS: {label}\n"
            f"~{evictable:,} evictable"
        )


class IssuePanel(Static):
    DEFAULT_CSS = "IssuePanel { border: solid yellow; height: 8; width: 1fr; }"

    def update_data(self, issue: IssueRef | None) -> None:
        if issue is None:
            self.update(
                "ACTIVE ISSUE\n\n"
                "No issue detected\n"
                "(set --issue or use\n"
                " feature/<id>- branch)"
            )
        else:
            milestone = f" | {issue.milestone}" if issue.milestone else ""
            self.update(
                f"ACTIVE ISSUE\n\n"
                f"#{issue.id} {issue.title[:30]}\n"
                f"status: {issue.status}\n"
                f"{issue.tracker.title()}{milestone}"
            )


class EvictionPanel(Static):
    DEFAULT_CSS = "EvictionPanel { border: solid white; height: 8; width: 2fr; }"

    def update_data(self, result: RotRiskResult) -> None:
        lines = ["EVICTION CANDIDATES\n"]
        for b in result.eviction_candidates[:6]:
            tool = b.tool_name or b.block_type
            lines.append(
                f"{b.turn_index:03d} | {b.block_type:12s} | {tool:8s} ~{b.token_estimate:,}t"
            )
        if not result.eviction_candidates:
            lines.append("(none — context looks fresh)")
        self.update("\n".join(lines))


class VibeDashboard(App):  # type: ignore[type-arg]
    """Live 4-panel VibeWatch TUI dashboard."""

    BINDINGS = [
        Binding("g", "generate_handoff", "Generate handoff"),
        Binding("h", "write_context", "Write context"),
        Binding("s", "switch_session", "Switch session"),
        Binding("q", "quit", "Quit"),
    ]

    def __init__(
        self,
        adapter: SessionAdapter,
        config: VibeWatchConfig,
        effective_tool: str,
        issue_override: int | None,
        poll_interval: float,
        session_mode: str = "auto",
    ) -> None:
        super().__init__()
        self._adapter = adapter
        self._config = config
        self._effective_tool = effective_tool
        self._issue_override = issue_override
        self._poll_interval = poll_interval
        self._session_mode = session_mode
        self._calc = RotCalculator()
        self._last_result: RotRiskResult | None = None
        self._active_issue: IssueRef | None = None
        self._project_name = Path(config.project_dir).name
        self._prev_status: str = ""

    def compose(self) -> ComposeResult:
        yield Header()
        yield TokenBudgetPanel(id="budget")
        yield BreakdownPanel(id="breakdown")
        yield RotRiskPanel(id="rot")
        yield IssuePanel(id="issue")
        yield EvictionPanel(id="eviction")
        yield Footer()

    def on_mount(self) -> None:
        # Show session name in title
        session_label = Path(self._adapter.source_path).stem
        self.title = (
            f"VibeWatch | {self._project_name} | {self._effective_tool} "
            f"| {session_label} ({self._session_mode})"
        )
        self._refresh_data()
        t = threading.Thread(target=self._poll_loop, daemon=True)
        t.start()

    def _poll_loop(self) -> None:
        while True:
            time.sleep(self._poll_interval)
            self.call_from_thread(self._refresh_data)

    def _refresh_data(self) -> None:
        try:
            session = self._adapter.read()
        except Exception:
            return

        active_issue = self._active_issue
        if self._config.tracker and (self._config.tracker_token or self._config.github_token):
            from vibewatch.integrations.issue_tracker import IssueTracker
            tracker = IssueTracker(
                tracker=self._config.tracker,
                base_url=self._config.tracker_url,
                token=self._config.tracker_token or self._config.github_token,
            )
            active_issue = tracker.get_active_issue(
                session.git_branch,
                issue_number=self._issue_override,
            )
            self._active_issue = active_issue

        result = self._calc.score(session.blocks, active_issue=active_issue)
        prev = self._prev_status
        self._last_result = result
        self._prev_status = result.status

        # Auto-write context on red transition
        if prev not in ("", "red") and result.status == "red":
            self._write_context_file()

        self.query_one("#budget", TokenBudgetPanel).update_data(result)
        self.query_one("#breakdown", BreakdownPanel).update_data(result)
        self.query_one("#rot", RotRiskPanel).update_data(result)
        self.query_one("#issue", IssuePanel).update_data(active_issue)
        self.query_one("#eviction", EvictionPanel).update_data(result)

    def _write_context_file(self) -> tuple[Path, Path] | None:
        """Write context snapshot and return (json_path, md_path) or None on failure."""
        if self._last_result is None:
            return None
        try:
            from vibewatch.core.session_ranker import classify_session
            from vibewatch.generators.context_writer import ContextWriter

            session_meta = classify_session(self._adapter.source_path)
            writer = ContextWriter(
                context_dir=self._config.context_dir,
                project_name=self._project_name,
            )
            return writer.write(
                rot_result=self._last_result,
                session_meta=session_meta,
                modified_files=[],
            )
        except Exception:
            return None

    def action_generate_handoff(self) -> None:
        if self._last_result is None:
            return
        gen = HandoffGenerator(project_name=self._project_name)
        modified: list[str] = []
        prompt = gen.generate(
            self._last_result,
            active_issue=self._active_issue,
            modified_files=modified,
        )
        try:
            import pyperclip
            pyperclip.copy(prompt)
            self.notify("Handoff prompt copied to clipboard!")
        except Exception:
            self.notify("pyperclip unavailable — printing to console")
            print(prompt)

    def action_write_context(self) -> None:
        """Write context file and copy pointer prompt to clipboard."""
        paths = self._write_context_file()
        if paths is None:
            self.notify("No data to write context file")
            return
        _json_path, md_path = paths
        if self._last_result is not None:
            gen = HandoffGenerator(project_name=self._project_name)
            pointer = gen.generate(
                self._last_result,
                active_issue=self._active_issue,
                modified_files=[],
                context_path=md_path,
            )
            try:
                import pyperclip
                pyperclip.copy(pointer)
                self.notify(f"Context written to {md_path} — pointer prompt copied!")
            except Exception:
                self.notify(f"Context written to {md_path}")

    def action_switch_session(self) -> None:
        """Re-run session picker (only in pick mode; no-op otherwise)."""
        if self._session_mode != "pick":
            self.notify("Session switching only available in --session-mode pick")
            return
        try:
            from vibewatch.cli import _run_session_picker
            from vibewatch.core.session_ranker import rank_sessions

            sessions = rank_sessions(self._config.project_dir)
            if len(sessions) > 1:
                from vibewatch.adapters.claude_code import ClaudeCodeAdapter
                from vibewatch.core.models import SessionMeta
                chosen: SessionMeta = _run_session_picker(sessions)
                self._adapter = ClaudeCodeAdapter(chosen.path)
                self._prev_status = ""
                self._refresh_data()
                self.notify(f"Switched to {chosen.agent_name or 'orchestrator'}")
        except Exception:
            self.notify("Could not switch session")


# ---------------------------------------------------------------------------
# Swarm mode
# ---------------------------------------------------------------------------


class SessionPanel(Static):
    """One row in the swarm view — name, rot bar, tokens, status."""

    DEFAULT_CSS = "SessionPanel { border: solid grey; height: 7; width: 1fr; }"

    def __init__(self, adapter: SessionAdapter, config: VibeWatchConfig) -> None:
        super().__init__()
        self._adapter = adapter
        self._config = config
        self._calc = RotCalculator()
        self._prev_status: str = ""
        self._last_result: RotRiskResult | None = None
        self._project_name = Path(config.project_dir).name

    def refresh_data(self) -> None:
        """Poll adapter and update display. Called from parent swarm on each poll cycle."""
        try:
            session = self._adapter.read()
        except Exception:
            return

        result = self._calc.score(session.blocks, active_issue=None)
        prev = self._prev_status
        self._last_result = result
        self._prev_status = result.status

        # Auto-write on red transition
        if prev not in ("", "red") and result.status == "red":
            self._write_context_file()

        session_label = Path(self._adapter.source_path).stem[:30]
        rot_pct = int(result.rot_score * 100)
        evictable = result.evictable_tokens + result.stale_tokens
        self.update(
            f"{session_label}\n"
            f"{_bar(rot_pct, 8)} {rot_pct}%  {result.status.upper()}\n"
            f"tokens: {result.total_tokens:,}  evictable: {evictable:,}"
        )

    def _write_context_file(self) -> None:
        if self._last_result is None:
            return
        try:
            from vibewatch.core.session_ranker import classify_session
            from vibewatch.generators.context_writer import ContextWriter

            session_meta = classify_session(self._adapter.source_path)
            writer = ContextWriter(
                context_dir=self._config.context_dir,
                project_name=self._project_name,
            )
            writer.write(
                rot_result=self._last_result,
                session_meta=session_meta,
                modified_files=[],
            )
        except Exception:
            pass


class AggregatePanel(Static):
    """Shows totals across all sessions in the swarm."""

    DEFAULT_CSS = "AggregatePanel { border: solid white; height: 4; width: 1fr; }"

    def update_data(self, panels: list[SessionPanel]) -> None:
        total_tokens = 0
        red_count = 0
        for panel in panels:
            if panel._last_result is not None:
                total_tokens += panel._last_result.total_tokens
                if panel._last_result.status == "red":
                    red_count += 1
        self.update(
            f"SWARM TOTALS\n"
            f"Sessions: {len(panels)}  Red: {red_count}\n"
            f"Total tokens: {total_tokens:,}"
        )


class VibeDashboardSwarm(App):  # type: ignore[type-arg]
    """Multi-session swarm view. Used when --session-mode all."""

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("h", "handoff_all", "Handoff All"),
        Binding("s", "switch_pick", "Pick"),
    ]

    def __init__(
        self,
        adapters: list[SessionAdapter],
        config: VibeWatchConfig,
        effective_tool: str,
        issue_override: int | None,
        poll_interval: float,
    ) -> None:
        super().__init__()
        self._adapters = adapters
        self._config = config
        self._effective_tool = effective_tool
        self._issue_override = issue_override
        self._poll_interval = poll_interval
        self._panels: list[SessionPanel] = []
        self._project_name = Path(config.project_dir).name

    def compose(self) -> ComposeResult:
        yield Header()
        for adapter in self._adapters:
            panel = SessionPanel(adapter=adapter, config=self._config)
            self._panels.append(panel)
            yield panel
        yield AggregatePanel(id="aggregate")
        yield Footer()

    def on_mount(self) -> None:
        self.title = f"VibeWatch Swarm | {self._project_name} | {len(self._adapters)} sessions"
        self._refresh_all()
        t = threading.Thread(target=self._poll_loop, daemon=True)
        t.start()

    def _poll_loop(self) -> None:
        while True:
            time.sleep(self._poll_interval)
            self.call_from_thread(self._refresh_all)

    def _refresh_all(self) -> None:
        for panel in self._panels:
            panel.refresh_data()
        agg = self.query_one("#aggregate", AggregatePanel)
        agg.update_data(self._panels)

    def action_handoff_all(self) -> None:
        """Write context files for all sessions with red status."""
        written = 0
        for panel in self._panels:
            if panel._last_result is not None and panel._last_result.status == "red":
                panel._write_context_file()
                written += 1
        self.notify(f"Context files written for {written} red session(s)")

    def action_switch_pick(self) -> None:
        self.notify("Switch to single-session mode with --session-mode pick")
