from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class ContextBlock:
    id: str
    turn_index: int
    role: str                   # "user" | "assistant"
    block_type: str             # "text"|"tool_use"|"tool_result"|"thinking"|"command"|"code"
    tool_name: str | None
    tool_use_id: str | None
    tool_input: dict | None     # type: ignore[type-arg]
    is_error: bool
    token_estimate: int
    content_preview: str        # first 120 chars
    recency_score: float        # 0.0 (oldest) → 1.0 (newest)
    decay_class: str            # "keep" | "monitor" | "evictable" | "stale"


@dataclass
class SessionState:
    session_id: str
    project_path: str
    git_branch: str
    total_turns: int
    blocks: list[ContextBlock] = field(default_factory=list)
    last_updated: datetime = field(default_factory=datetime.utcnow)


@dataclass
class IssueRef:
    id: int
    title: str
    status: str
    milestone: str | None
    url: str
    tracker: str                # "github" | "gitlab"


@dataclass
class SessionMeta:
    path: Path
    session_id: str
    is_subagent: bool | None       # None = unclassified
    agent_name: str                # "" if orchestrator or unclassified
    slug: str                      # "" if no slug field found
    output_tokens: int
    cache_creation_tokens: int     # message.usage.cache_creation_input_tokens
    cache_read_tokens: int         # message.usage.cache_read_input_tokens
    cost_proxy: float              # output + create*0.25 + read*0.03
    wall_clock_seconds: float      # max(timestamp) - min(timestamp) in seconds
    total_turn_duration_ms: int    # sum of system:turn_duration durationMs values
    first_timestamp: datetime
    last_timestamp: datetime
    cwd: str
    git_branch: str


@dataclass
class RotRiskResult:
    total_tokens: int
    keep_tokens: int
    monitor_tokens: int
    evictable_tokens: int
    stale_tokens: int
    rot_score: float
    status: str                 # "green" | "yellow" | "red"
    eviction_candidates: list[ContextBlock]
    active_issue: IssueRef | None
