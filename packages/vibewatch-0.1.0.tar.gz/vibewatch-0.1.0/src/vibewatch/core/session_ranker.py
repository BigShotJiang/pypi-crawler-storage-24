from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from vibewatch.core.models import SessionMeta

_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)


def _parse_ts(ts_str: str) -> datetime:
    """Parse ISO 8601 timestamp string to timezone-aware datetime."""
    try:
        # Python 3.11+ supports Z suffix directly
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return _EPOCH


def _compute_cost_proxy(output: int, cache_create: int, cache_read: int) -> float:
    return output + cache_create * 0.25 + cache_read * 0.03


def classify_session(jsonl_path: Path) -> SessionMeta:
    """Parse a Claude Code JSONL file and return its SessionMeta.

    Reads a limited number of lines for the header scan, then streams all
    lines for token/timestamp accounting. Empty or unreadable files return
    a zero-filled SessionMeta with is_subagent=None.
    """
    _ZERO_TS = _EPOCH

    def _empty() -> SessionMeta:
        return SessionMeta(
            path=jsonl_path,
            session_id="",
            is_subagent=None,
            agent_name="",
            slug="",
            output_tokens=0,
            cache_creation_tokens=0,
            cache_read_tokens=0,
            cost_proxy=0.0,
            wall_clock_seconds=0.0,
            total_turn_duration_ms=0,
            first_timestamp=_ZERO_TS,
            last_timestamp=_ZERO_TS,
            cwd="",
            git_branch="",
        )

    try:
        raw_text = jsonl_path.read_text(encoding="utf-8")
    except OSError:
        return _empty()

    raw_lines = [ln.strip() for ln in raw_text.splitlines() if ln.strip()]
    if not raw_lines:
        return _empty()

    # Parse all lines into dicts, skip malformed
    parsed: list[dict] = []  # type: ignore[type-arg]
    for raw in raw_lines:
        try:
            obj: dict = json.loads(raw)  # type: ignore[type-arg]
            parsed.append(obj)
        except json.JSONDecodeError:
            continue

    if not parsed:
        return _empty()

    # --- Header scan (first 10 lines) ---
    header = parsed[:10]
    first_line = header[0]
    first_type: str = first_line.get("type", "")

    is_subagent_candidate = first_type == "custom-title"
    agent_name = ""
    if is_subagent_candidate:
        agent_name = first_line.get("customTitle", "")

    # If candidate subagent, scan first 20 lines for first user line with planContent
    is_subagent: bool | None
    if is_subagent_candidate:
        is_subagent = None  # default to unclassified
        for obj in parsed[:20]:
            if obj.get("type") == "user" and "planContent" in obj:
                is_subagent = True
                break
    else:
        is_subagent = False  # orchestrator

    # --- Full scan for tokens, timestamps, metadata ---
    output_tokens = 0
    cache_creation_tokens = 0
    cache_read_tokens = 0
    timestamps: list[datetime] = []
    total_turn_duration_ms = 0
    session_id = ""
    cwd = ""
    git_branch = ""
    slug = ""

    for obj in parsed:
        obj_type: str = obj.get("type", "")

        # Metadata fields
        if not session_id and obj.get("sessionId"):
            session_id = str(obj["sessionId"])
        if not cwd and obj.get("cwd"):
            cwd = str(obj["cwd"])
        if not git_branch and obj.get("gitBranch"):
            git_branch = str(obj["gitBranch"])
        if not slug and obj.get("slug"):
            slug = str(obj["slug"])

        # Timestamp
        ts_str: str = obj.get("timestamp", "")
        if ts_str:
            timestamps.append(_parse_ts(ts_str))

        if obj_type == "assistant":
            message = obj.get("message", {})
            usage = message.get("usage", {})
            output_tokens += int(usage.get("output_tokens", 0))
            cache_creation_tokens += int(usage.get("cache_creation_input_tokens", 0))
            cache_read_tokens += int(usage.get("cache_read_input_tokens", 0))

        elif obj_type == "system":
            subtype: str = obj.get("subtype", "")
            if subtype == "turn_duration":
                total_turn_duration_ms += int(obj.get("durationMs", 0))

    first_timestamp = min(timestamps, default=_ZERO_TS)
    last_timestamp = max(timestamps, default=_ZERO_TS)

    wall_clock_seconds = (last_timestamp - first_timestamp).total_seconds()
    if wall_clock_seconds < 0:
        wall_clock_seconds = 0.0

    cost_proxy = _compute_cost_proxy(output_tokens, cache_creation_tokens, cache_read_tokens)

    return SessionMeta(
        path=jsonl_path,
        session_id=session_id,
        is_subagent=is_subagent,
        agent_name=agent_name,
        slug=slug,
        output_tokens=output_tokens,
        cache_creation_tokens=cache_creation_tokens,
        cache_read_tokens=cache_read_tokens,
        cost_proxy=cost_proxy,
        wall_clock_seconds=wall_clock_seconds,
        total_turn_duration_ms=total_turn_duration_ms,
        first_timestamp=first_timestamp,
        last_timestamp=last_timestamp,
        cwd=cwd,
        git_branch=git_branch,
    )


def rank_sessions(
    project_dir: Path,
    max_age_hours: float = 2.0,
) -> list[SessionMeta]:
    """Scan all Claude Code JSONL files for project_dir and return ranked list.

    Ranking:
    1. Filter to files modified within max_age_hours (fall back to all if none found)
    2. Classify each file via classify_session()
    3. Group by slug (empty slug = own group)
    4. Within each group: orchestrators first, then by cost_proxy desc
    5. Return flat list: most-recent group first (by last_timestamp)
    """
    from vibewatch.core.detector import encode_path_for_claude

    encoded = encode_path_for_claude(project_dir)
    claude_dir = Path.home() / ".claude" / "projects" / encoded

    all_jsonl = list(claude_dir.glob("*.jsonl")) if claude_dir.exists() else []
    if not all_jsonl:
        return []

    # Filter by age
    import time
    cutoff = time.time() - max_age_hours * 3600
    recent = [p for p in all_jsonl if p.stat().st_mtime >= cutoff]
    candidates = recent if recent else all_jsonl

    metas = [classify_session(p) for p in candidates]

    # Group by slug
    grouped: dict[str, list[SessionMeta]] = {}
    for meta in metas:
        key = meta.slug if meta.slug else f"__no_slug_{meta.session_id}_{meta.path.name}"
        grouped.setdefault(key, []).append(meta)

    # Sort within each group: orchestrators (is_subagent=False) first, then by cost_proxy desc
    for group in grouped.values():
        group.sort(
            key=lambda m: (
                0 if m.is_subagent is False else 1,  # orchestrators first
                -m.cost_proxy,
            )
        )

    # Sort groups by last_timestamp of highest-cost member (desc)
    sorted_groups = sorted(
        grouped.values(),
        key=lambda grp: max(m.last_timestamp for m in grp),
        reverse=True,
    )

    result: list[SessionMeta] = []
    for group in sorted_groups:
        result.extend(group)
    return result
