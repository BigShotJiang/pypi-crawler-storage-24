from __future__ import annotations

import json
import os
import urllib.parse
from pathlib import Path


def _encode_path_str(path_str: str) -> str:
    """Encode a raw path string to Claude Code's project directory naming convention.

    Rule: replace ":" with "-", replace backslash and forward slash with "-"
    Example: C:/Users/Foo/Projects/Bar -> C--Users-Foo-Projects-Bar
    """
    return path_str.replace(":", "-").replace("\\", "-").replace("/", "-")


def encode_path_for_claude(project_dir: Path) -> str:
    """Encode a project Path to Claude Code's projects directory naming convention."""
    return _encode_path_str(str(project_dir.resolve()))


def detect_tool(project_dir: Path) -> str:
    """Detect which AI coding tool is active for this project directory.

    Checks project-local artifacts first to avoid false positives.
    Returns: "claude-code" | "aider" | "unknown"
    """
    encoded = encode_path_for_claude(project_dir)
    claude_project_dir = Path.home() / ".claude" / "projects" / encoded
    if claude_project_dir.exists() and any(claude_project_dir.glob("*.jsonl")):
        return "claude-code"

    if (project_dir / ".aider.chat.history.md").exists():
        return "aider"

    if find_copilot_sessions(project_dir, "copilot"):
        return "copilot"

    if find_copilot_sessions(project_dir, "cursor"):
        return "cursor"

    return "unknown"


def find_copilot_sessions(project_dir: Path, agent: str = "copilot") -> list[Path]:
    """Locate VS Code Copilot or Cursor chat session files for a project directory.

    Scans %APPDATA%/Code (or Cursor)/User/workspaceStorage for hash dirs
    whose workspace.json folder URI resolves to project_dir.
    Returns all .json and .jsonl files found under chatSessions/.
    """
    appdata = Path(os.environ.get("APPDATA", ""))
    if not appdata.exists():
        return []

    app_name = "Code" if agent == "copilot" else "Cursor"
    ws_root = appdata / app_name / "User" / "workspaceStorage"
    if not ws_root.exists():
        return []

    target = str(project_dir.resolve()).lower()
    results: list[Path] = []

    for hash_dir in ws_root.iterdir():
        if not hash_dir.is_dir():
            continue
        ws_json = hash_dir / "workspace.json"
        if not ws_json.exists():
            continue
        try:
            data = json.loads(ws_json.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        folder_uri: str = data.get("folder", "")
        # Normalize: URI decode, strip "file:///", normalize separators
        normalized = urllib.parse.unquote(folder_uri)
        normalized = normalized.removeprefix("file:///").replace("/", os.sep)
        if Path(normalized).resolve().__str__().lower() == target:
            chat_dir = hash_dir / "chatSessions"
            if chat_dir.exists():
                results.extend(chat_dir.glob("*.json"))
                results.extend(chat_dir.glob("*.jsonl"))

    return results
