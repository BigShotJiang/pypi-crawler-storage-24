from __future__ import annotations

from vibewatch.core.models import ContextBlock, IssueRef, RotRiskResult


class RotCalculator:
    """Assigns decay classes and computes rot score. Deterministic heuristics only."""

    def score(
        self,
        blocks: list[ContextBlock],
        active_issue: IssueRef | None,
    ) -> RotRiskResult:
        if not blocks:
            return RotRiskResult(
                total_tokens=0, keep_tokens=0, monitor_tokens=0,
                evictable_tokens=0, stale_tokens=0, rot_score=0.0,
                status="green", eviction_candidates=[], active_issue=active_issue,
            )

        max_turn = max(b.turn_index for b in blocks)

        # Pre-pass: build resolved_tool_use_ids
        resolved_tool_use_ids: set[str] = self._build_resolved_ids(blocks)

        # Pre-pass: build referenced_uuids_in_last_5
        # Collect tool_use_ids referenced by tool_result blocks within the last 5
        last_5 = sorted(blocks, key=lambda b: b.turn_index)[-5:]
        referenced_uuids_in_last_5: set[str] = set()
        for b in last_5:
            if b.block_type == "tool_result" and b.tool_use_id:
                referenced_uuids_in_last_5.add(b.tool_use_id)

        # Classify each block
        classified: list[ContextBlock] = []
        for block in blocks:
            decay_class = self._classify(
                block=block,
                max_turn=max_turn,
                active_issue=active_issue,
                resolved_tool_use_ids=resolved_tool_use_ids,
                referenced_uuids_in_last_5=referenced_uuids_in_last_5,
                all_blocks=blocks,
            )
            # Assign recency_score
            recency = block.turn_index / max_turn if max_turn > 0 else 1.0
            classified.append(ContextBlock(
                id=block.id,
                turn_index=block.turn_index,
                role=block.role,
                block_type=block.block_type,
                tool_name=block.tool_name,
                tool_use_id=block.tool_use_id,
                tool_input=block.tool_input,
                is_error=block.is_error,
                token_estimate=block.token_estimate,
                content_preview=block.content_preview,
                recency_score=recency,
                decay_class=decay_class,
            ))

        keep_tokens = sum(b.token_estimate for b in classified if b.decay_class == "keep")
        monitor_tokens = sum(b.token_estimate for b in classified if b.decay_class == "monitor")
        evictable_tokens = sum(b.token_estimate for b in classified if b.decay_class == "evictable")
        stale_tokens = sum(b.token_estimate for b in classified if b.decay_class == "stale")
        total_tokens = sum(b.token_estimate for b in classified)

        if keep_tokens + monitor_tokens + evictable_tokens + stale_tokens != total_tokens:
            raise ValueError(
                f"Token sum mismatch: {keep_tokens}+{monitor_tokens}+"
                f"{evictable_tokens}+{stale_tokens} != {total_tokens}"
            )

        rot_score = 0.0
        if total_tokens > 0:
            rot_score = (
                (stale_tokens / total_tokens) * 0.50
                + (evictable_tokens / total_tokens) * 0.30
                + (monitor_tokens / total_tokens) * 0.20
            )

        if rot_score >= 0.70:
            status = "red"
        elif rot_score >= 0.40:
            status = "yellow"
        else:
            status = "green"

        eviction_candidates = [
            b for b in classified if b.decay_class in ("evictable", "stale")
        ]

        return RotRiskResult(
            total_tokens=total_tokens,
            keep_tokens=keep_tokens,
            monitor_tokens=monitor_tokens,
            evictable_tokens=evictable_tokens,
            stale_tokens=stale_tokens,
            rot_score=rot_score,
            status=status,
            eviction_candidates=eviction_candidates,
            active_issue=active_issue,
        )

    def _build_resolved_ids(self, blocks: list[ContextBlock]) -> set[str]:
        """Find Read tool_use_ids where the same file was later Edit/Write'd."""
        resolved: set[str] = set()
        sorted_blocks = sorted(blocks, key=lambda b: b.turn_index)

        for i, block in enumerate(sorted_blocks):
            if block.block_type != "tool_use" or block.tool_name != "Read":
                continue
            file_path = (block.tool_input or {}).get("file_path")
            if not file_path or not block.tool_use_id:
                continue

            # Find the tool_result for this Read
            result_idx: int | None = None
            for j in range(i + 1, len(sorted_blocks)):
                b2 = sorted_blocks[j]
                if b2.block_type == "tool_result" and b2.tool_use_id == block.tool_use_id:
                    if not b2.is_error:
                        result_idx = j
                    break

            if result_idx is None:
                continue

            # Check next 10 blocks after the result for Edit/Write on same file
            for k in range(result_idx + 1, min(result_idx + 11, len(sorted_blocks))):
                b3 = sorted_blocks[k]
                if (
                    b3.block_type == "tool_use"
                    and b3.tool_name in ("Edit", "Write")
                    and (b3.tool_input or {}).get("file_path") == file_path
                ):
                    resolved.add(block.tool_use_id)
                    break

        return resolved

    def _classify(
        self,
        block: ContextBlock,
        max_turn: int,
        active_issue: IssueRef | None,
        resolved_tool_use_ids: set[str],
        referenced_uuids_in_last_5: set[str],
        all_blocks: list[ContextBlock],
    ) -> str:
        # Priority: keep > evictable > stale > monitor

        # --- KEEP rules ---
        if block.turn_index >= (max_turn - 4):
            return "keep"
        if block.role == "user" and block.block_type in ("text", "command"):
            return "keep"
        if block.block_type == "tool_use" and block.tool_name in ("Edit", "Write"):
            return "keep"
        if block.block_type == "code":
            # Aider code blocks — always keep
            return "keep"
        if active_issue is not None:
            keywords = [kw.lower() for kw in active_issue.title.split()]
            preview_lower = block.content_preview.lower()
            if any(kw in preview_lower for kw in keywords):
                return "keep"

        # --- EVICTABLE rules ---
        if block.block_type == "thinking":
            return "evictable"
        if (
            block.block_type == "tool_result"
            and block.is_error
            and block.tool_use_id in resolved_tool_use_ids
        ):
            return "evictable"
        if block.block_type == "tool_use" and block.tool_name == "Read":
            # Check if a later Edit/Write references same file_path
            file_path = (block.tool_input or {}).get("file_path")
            if file_path:
                for other in all_blocks:
                    if (
                        other.turn_index > block.turn_index
                        and other.block_type == "tool_use"
                        and other.tool_name in ("Edit", "Write")
                        and (other.tool_input or {}).get("file_path") == file_path
                    ):
                        return "evictable"

        # --- STALE rules ---
        if (
            block.block_type == "tool_result"
            and block.turn_index < (max_turn - 10)
            and block.tool_use_id not in referenced_uuids_in_last_5
        ):
            return "stale"

        # --- MONITOR rules ---
        if block.turn_index < (max_turn // 2):
            return "monitor"

        # Default: blocks in the second half not matching any other rule
        return "monitor"
