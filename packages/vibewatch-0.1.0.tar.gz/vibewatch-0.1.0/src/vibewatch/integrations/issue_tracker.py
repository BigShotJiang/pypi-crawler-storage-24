from __future__ import annotations

import logging
import re
from pathlib import Path

import httpx

from vibewatch.core.models import IssueRef

logger = logging.getLogger(__name__)
_BRANCH_RE = re.compile(r"(?:feature|fix|chore|docs)/(\d+)-")
_LOG_PATH = Path.home() / ".vibewatch" / "errors.log"


def extract_issue_number(branch_name: str) -> int | None:
    """Extract issue number from branch name like feature/23-hitl-queue-page."""
    match = _BRANCH_RE.search(branch_name)
    if match:
        return int(match.group(1))
    return None


class IssueTracker:
    """Fetches active issue from GitHub or GitLab. Never raises — returns None on any failure."""

    def __init__(
        self,
        tracker: str,
        base_url: str,
        token: str | None,
        project: str | None = None,
    ) -> None:
        self._tracker = tracker
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._project = project

    def get_active_issue(
        self,
        branch_name: str,
        issue_number: int | None = None,
    ) -> IssueRef | None:
        """Fetch active issue. Returns None on any failure."""
        number = issue_number or extract_issue_number(branch_name)
        if number is None:
            return None

        try:
            if self._tracker == "gitlab":
                return self._fetch_gitlab(number)
            if self._tracker == "github":
                return self._fetch_github(number)
        except Exception as exc:  # noqa: BLE001
            self._log_error(str(exc))

        return None

    def _fetch_gitlab(self, issue_number: int) -> IssueRef | None:
        if not self._project or not self._token:
            return None
        project_encoded = self._project.replace("/", "%2F")
        url = f"{self._base_url}/projects/{project_encoded}/issues/{issue_number}"
        headers = {"PRIVATE-TOKEN": self._token}
        resp = httpx.get(url, headers=headers, timeout=5.0)
        resp.raise_for_status()
        data = resp.json()
        milestone = (data.get("milestone") or {}).get("title")
        return IssueRef(
            id=data["iid"],
            title=data["title"],
            status=data.get("state", "unknown"),
            milestone=milestone,
            url=data.get("web_url", ""),
            tracker="gitlab",
        )

    def _fetch_github(self, issue_number: int) -> IssueRef | None:
        if not self._project or not self._token:
            return None
        url = f"https://api.github.com/repos/{self._project}/issues/{issue_number}"
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/vnd.github+json",
        }
        resp = httpx.get(url, headers=headers, timeout=5.0)
        resp.raise_for_status()
        data = resp.json()
        milestone = (data.get("milestone") or {}).get("title")
        return IssueRef(
            id=data["number"],
            title=data["title"],
            status=data.get("state", "unknown"),
            milestone=milestone,
            url=data.get("html_url", ""),
            tracker="github",
        )

    def _log_error(self, message: str) -> None:
        _LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(_LOG_PATH, "a") as f:
            f.write(f"[issue_tracker] {message}\n")
