from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from vibewatch.adapters.base import SessionAdapter
from vibewatch.config import VibeWatchConfig
from vibewatch.core.detector import detect_tool
from vibewatch.core.models import SessionMeta
from vibewatch.core.rot_calculator import RotCalculator


def _resolve_adapter(
    tool: str,
    project_dir: Path,
    session_mode: str = "auto",
    session_path: str | None = None,
) -> SessionAdapter | list[SessionAdapter]:
    """Return adapter(s) for the detected tool.

    Returns list[SessionAdapter] only when session_mode == 'all'.
    Returns SessionAdapter in all other cases.
    """
    from vibewatch.adapters.aider import AiderAdapter
    from vibewatch.adapters.claude_code import ClaudeCodeAdapter
    from vibewatch.adapters.copilot import CopilotAdapter
    from vibewatch.core.detector import encode_path_for_claude, find_copilot_sessions

    # Priority 1: explicit --session path
    if session_path is not None:
        return ClaudeCodeAdapter(Path(session_path))

    if tool == "claude-code":
        from vibewatch.core.session_ranker import rank_sessions

        encoded = encode_path_for_claude(project_dir)
        claude_dir = Path.home() / ".claude" / "projects" / encoded
        jsonl_files = list(claude_dir.glob("*.jsonl")) if claude_dir.exists() else []
        if not jsonl_files:
            raise FileNotFoundError(f"No JSONL sessions found in {claude_dir}")

        # Priority 2: pick mode (interactive picker)
        if session_mode == "pick":
            sessions = rank_sessions(project_dir)
            if len(sessions) <= 1:
                chosen_path = sessions[0].path if sessions else max(
                    jsonl_files, key=lambda p: p.stat().st_mtime
                )
                return ClaudeCodeAdapter(chosen_path)
            chosen = _run_session_picker(sessions)
            return ClaudeCodeAdapter(chosen.path)

        # Priority 3: all mode → swarm
        if session_mode == "all":
            sessions = rank_sessions(project_dir)
            if not sessions:
                # Fall back to all jsonl files sorted by mtime
                return [ClaudeCodeAdapter(p) for p in sorted(
                    jsonl_files, key=lambda p: p.stat().st_mtime, reverse=True
                )]
            return [ClaudeCodeAdapter(m.path) for m in sessions]

        # Priority 4: auto mode (default)
        sessions = rank_sessions(project_dir)
        if sessions:
            chosen = sessions[0]
            click.echo(
                f"[vibewatch] Auto-selected: {chosen.agent_name or 'orchestrator'} "
                f"({chosen.output_tokens:,} output tokens)",
                err=True,
            )
            return ClaudeCodeAdapter(chosen.path)

        # Priority 7: Phase 1 fallback — latest mtime
        return ClaudeCodeAdapter(max(jsonl_files, key=lambda p: p.stat().st_mtime))

    if tool == "aider":
        history = project_dir / ".aider.chat.history.md"
        if not history.exists():
            raise FileNotFoundError(f"No Aider history at {history}")
        return AiderAdapter(history)

    if tool in ("copilot", "cursor"):
        paths = find_copilot_sessions(project_dir, tool)
        if not paths:
            raise FileNotFoundError(
                f"No {tool.title()} session files found for {project_dir}"
            )
        if session_mode == "all":
            return [CopilotAdapter(p) for p in paths]
        # auto/pick: use the most recently modified file
        chosen_path = max(paths, key=lambda p: p.stat().st_mtime)
        return CopilotAdapter(chosen_path)

    raise ValueError(f"Unsupported tool: {tool}")


def _run_session_picker(sessions: list) -> SessionMeta:  # type: ignore[type-arg]
    """Display an inline Textual picker for session selection.

    Falls back to returning sessions[0] if Textual is unavailable.
    """
    try:
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from textual.widgets import Footer, Label, ListItem, ListView

        class _PickerApp(App):  # type: ignore[type-arg]
            BINDINGS = [Binding("enter", "select", "Select"), Binding("q", "quit", "Quit")]

            def __init__(self, session_list: list[SessionMeta]) -> None:
                super().__init__()
                self._sessions = session_list
                self.chosen: SessionMeta = session_list[0]

            def compose(self) -> ComposeResult:
                items: list[ListItem] = []
                for meta in self._sessions:
                    kind = "subagent" if meta.is_subagent else "orchestr"
                    wall = meta.wall_clock_seconds / 60
                    label = (
                        f"[{kind}] {meta.agent_name or '(unnamed)':40s}  "
                        f"{wall:.1f}min  {meta.output_tokens:,} tokens  {meta.git_branch}"
                    )
                    items.append(ListItem(Label(label)))
                yield Label("Select session to monitor (Enter to select, q to quit):")
                yield ListView(*items, id="picker")
                yield Footer()

            def action_select(self) -> None:
                lv = self.query_one("#picker", ListView)
                idx = lv.index or 0
                self.chosen = self._sessions[idx]
                self.exit()

        picker = _PickerApp(sessions)
        picker.run()
        return picker.chosen
    except Exception:
        result: SessionMeta = sessions[0]
        return result


@click.group()
def main() -> None:
    """VibeWatch — context rot detection for vibe coders."""


@main.command()
@click.option("--tool", default=None, help="Force tool: claude-code | aider | copilot | cursor")
@click.option("--issue", default=None, type=int, help="Override issue number")
@click.option("--poll-interval", default=None, type=float, help="Poll interval in seconds")
@click.option(
    "--session-mode",
    default="auto",
    type=click.Choice(["auto", "pick", "all"]),
    help="Session selection: auto (default) | pick (interactive) | all (swarm)",
)
@click.option("--session", default=None, type=str, help="Explicit JSONL file path")
def watch(
    tool: str | None,
    issue: int | None,
    poll_interval: float | None,
    session_mode: str,
    session: str | None,
) -> None:
    """Launch live TUI dashboard."""
    cfg = VibeWatchConfig()
    configured = cfg.tool if cfg.tool != "auto" else None
    effective_tool = tool or configured or detect_tool(cfg.project_dir)

    if effective_tool == "unknown":
        click.echo("Could not detect AI coding tool. Use --tool flag.", err=True)
        sys.exit(2)

    adapter_or_list = _resolve_adapter(
        effective_tool,
        cfg.project_dir,
        session_mode=session_mode,
        session_path=session,
    )

    from vibewatch.tui.dashboard import VibeDashboard, VibeDashboardSwarm

    if isinstance(adapter_or_list, list):
        app: VibeDashboardSwarm | VibeDashboard = VibeDashboardSwarm(
            adapters=adapter_or_list,
            config=cfg,
            effective_tool=effective_tool,
            issue_override=issue or cfg.issue_number,
            poll_interval=poll_interval or cfg.poll_interval_seconds,
        )
    else:
        app = VibeDashboard(
            adapter=adapter_or_list,
            config=cfg,
            effective_tool=effective_tool,
            issue_override=issue or cfg.issue_number,
            poll_interval=poll_interval or cfg.poll_interval_seconds,
            session_mode=session_mode,
        )
    app.run()


@main.command()
@click.option("--tool", default=None)
@click.option("--issue", default=None, type=int)
@click.option("--output", default=None, type=click.Path(), help="Write JSON to file")
def audit(tool: str | None, issue: int | None, output: str | None) -> None:
    """One-shot rot audit. Exits 0=green, 1=yellow/red, 2=error."""
    cfg = VibeWatchConfig()
    configured = cfg.tool if cfg.tool != "auto" else None
    effective_tool = tool or configured or detect_tool(cfg.project_dir)

    if effective_tool == "unknown":
        click.echo("Could not detect AI coding tool. Use --tool flag.", err=True)
        sys.exit(2)

    try:
        adapter = _resolve_adapter(effective_tool, cfg.project_dir)
        # audit always uses single adapter; if list returned (shouldn't happen in auto) take first
        if isinstance(adapter, list):
            adapter = adapter[0]
        session = adapter.read()
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(2)

    active_issue = None
    if cfg.tracker and (cfg.tracker_token or cfg.github_token):
        from vibewatch.integrations.issue_tracker import IssueTracker
        tracker = IssueTracker(
            tracker=cfg.tracker,
            base_url=cfg.tracker_url,
            token=cfg.tracker_token or cfg.github_token,
            project=None,
        )
        active_issue = tracker.get_active_issue(
            session.git_branch, issue_number=issue or cfg.issue_number
        )

    calc = RotCalculator()
    result = calc.score(session.blocks, active_issue=active_issue)

    # Write context file
    from vibewatch.core.session_ranker import classify_session
    from vibewatch.generators.context_writer import ContextWriter

    project_name = Path(session.project_path).name if session.project_path else "unknown"
    try:
        session_meta = classify_session(adapter.source_path)
        writer = ContextWriter(context_dir=cfg.context_dir, project_name=project_name)
        _json_path, md_path = writer.write(
            rot_result=result,
            session_meta=session_meta,
            modified_files=[],
        )
        click.echo(f"Context written to {md_path}", err=True)
    except Exception:
        pass  # context writing is best-effort

    report = {
        "session_id": session.session_id,
        "project": project_name,
        "tool": effective_tool,
        "total_tokens": result.total_tokens,
        "rot_score": round(result.rot_score, 4),
        "status": result.status,
        "breakdown": {
            "keep": {
                "tokens": result.keep_tokens,
                "pct": round(result.keep_tokens / max(result.total_tokens, 1) * 100, 1),
            },
            "monitor": {
                "tokens": result.monitor_tokens,
                "pct": round(result.monitor_tokens / max(result.total_tokens, 1) * 100, 1),
            },
            "evictable": {
                "tokens": result.evictable_tokens,
                "pct": round(result.evictable_tokens / max(result.total_tokens, 1) * 100, 1),
            },
            "stale": {
                "tokens": result.stale_tokens,
                "pct": round(result.stale_tokens / max(result.total_tokens, 1) * 100, 1),
            },
        },
        "eviction_candidates": [
            {
                "turn": b.turn_index,
                "type": b.block_type,
                "tool": b.tool_name,
                "tokens": b.token_estimate,
                "preview": b.content_preview,
            }
            for b in result.eviction_candidates[:10]
        ],
    }
    json_output = json.dumps(report, indent=2)

    if output:
        Path(output).write_text(json_output)
        click.echo(f"Report written to {output}")
    else:
        click.echo(json_output)

    sys.exit(0 if result.status == "green" else 1)


@main.command()
def init() -> None:
    """Interactive project setup. Writes .vibewatch.toml to current directory."""
    project_dir = Path.cwd()
    detected = detect_tool(project_dir)

    click.echo(f"Detecting AI coding tool... found: {detected}")
    tool = click.prompt("Tool", default=detected)

    tracker = click.prompt("Issue tracker? (github/gitlab/none)", default="none")
    tracker_config: dict[str, str] = {}

    if tracker in ("github", "gitlab"):
        if tracker == "gitlab":
            base_url = click.prompt("GitLab base URL", default="https://gitlab.com/api/v4")
            click.echo("Token: set GITLAB_PERSONAL_ACCESS_TOKEN env var (not written to file)")
            project = click.prompt("Project (namespace/project or ID)")
            tracker_config = {"type": tracker, "base_url": base_url, "project": project}
        else:
            click.echo("Token: set GITHUB_TOKEN env var (not written to file)")
            project = click.prompt("Repository (owner/repo)")
            tracker_config = {
                "type": tracker, "base_url": "https://api.github.com", "project": project
            }

    branch_pattern = click.prompt("Branch pattern for issue detection", default="feature/{id}-*")
    poll_interval = click.prompt("Poll interval seconds", default="2", type=float)

    lines = ["[vibewatch]", f'tool = "{tool}"', f"poll_interval_seconds = {poll_interval}", ""]
    if tracker_config:
        lines.append("[tracker]")
        lines.append(f'type = "{tracker_config["type"]}"')
        lines.append(f'base_url = "{tracker_config["base_url"]}"')
        lines.append(f'project = "{tracker_config["project"]}"')
        lines.append(f'branch_pattern = "{branch_pattern}"')
        lines.append("")

    toml_path = project_dir / ".vibewatch.toml"
    toml_path.write_text("\n".join(lines))
    click.echo(f"\nConfig written to {toml_path}")
    click.echo("Run `vibewatch watch` to start.")
