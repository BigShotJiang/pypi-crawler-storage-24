from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class VibeWatchConfig(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="VIBEWATCH_")

    # Tool detection
    tool: str = "auto"          # "auto" | "claude-code" | "aider" | "copilot" | "cursor"
    project_dir: Path = Field(default_factory=Path.cwd)

    # Polling
    poll_interval_seconds: float = 2.0

    # Thresholds
    monitor_threshold: float = 0.40
    red_threshold: float = 0.70

    # Issue tracker
    tracker: str | None = None  # "github" | "gitlab" | None
    tracker_url: str = "https://gitlab.com/api/v4"
    # Read from env var directly (no VIBEWATCH_ prefix for these secrets)
    tracker_token: str | None = Field(
        default=None,
        validation_alias="GITLAB_PERSONAL_ACCESS_TOKEN",
    )
    github_token: str | None = Field(
        default=None,
        validation_alias="GITHUB_TOKEN",
    )
    issue_number: int | None = None

    # Context offload directory (Phase 2)
    context_dir: Path = Field(
        default_factory=lambda: Path.home() / ".vibewatch" / "context"
    )
