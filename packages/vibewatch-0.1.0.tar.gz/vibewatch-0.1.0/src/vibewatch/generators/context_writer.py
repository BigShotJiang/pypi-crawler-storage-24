from __future__ import annotations

import json
from pathlib import Path

from vibewatch.core.models import IssueRef, RotRiskResult, SessionMeta


class ContextWriter:
    """Writes context snapshot files (JSON + Markdown) to the context directory.

    Used by the audit command and by the H keybind in the TUI dashboard.
    Files are named by session_id and stored in context_dir.
    """

    def __init__(self, context_dir: Path, project_name: str) -> None:
        self._context_dir = context_dir
        self._project_name = project_name

    def write(
        self,
        rot_result: RotRiskResult,
        session_meta: SessionMeta,
        modified_files: list[str],
    ) -> tuple[Path, Path]:
        """Write context snapshot for a session.

        Returns (json_path, md_path).
        """
        self._context_dir.mkdir(parents=True, exist_ok=True)

        session_id = session_meta.session_id or session_meta.path.stem
        json_path = self._context_dir / f"{session_id}.json"
        md_path = self._context_dir / f"{session_id}.md"

        # Build top-keep-blocks list (keep class blocks with highest token counts)
        keep_blocks = [
            b for b in rot_result.eviction_candidates
            if b.decay_class in ("keep",)
        ]
        top_keep = [
            {"preview": b.content_preview, "block_type": b.block_type, "tokens": b.token_estimate}
            for b in keep_blocks[:5]
        ]

        eviction_data = [
            {"preview": b.content_preview, "block_type": b.block_type, "tokens": b.token_estimate}
            for b in rot_result.eviction_candidates[:10]
        ]

        # JSON output
        active_issue_data: dict[str, object] | None = None
        if rot_result.active_issue is not None:
            issue: IssueRef = rot_result.active_issue
            active_issue_data = {
                "id": issue.id,
                "title": issue.title,
                "url": issue.url,
            }

        json_payload = {
            "session_id": session_id,
            "agent_name": session_meta.agent_name,
            "project": self._project_name,
            "git_branch": session_meta.git_branch,
            "rot_score": round(rot_result.rot_score, 4),
            "status": rot_result.status,
            "total_tokens": rot_result.total_tokens,
            "keep_tokens": rot_result.keep_tokens,
            "evictable_tokens": rot_result.evictable_tokens,
            "stale_tokens": rot_result.stale_tokens,
            "active_issue": active_issue_data,
            "modified_files": modified_files,
            "top_keep_blocks": top_keep,
            "eviction_candidates": eviction_data,
        }
        json_path.write_text(json.dumps(json_payload, indent=2), encoding="utf-8")

        # Markdown output
        md_path.write_text(
            self._render_markdown(
                rot_result=rot_result,
                session_meta=session_meta,
                modified_files=modified_files,
            ),
            encoding="utf-8",
        )

        return json_path, md_path

    def _render_markdown(
        self,
        rot_result: RotRiskResult,
        session_meta: SessionMeta,
        modified_files: list[str],
    ) -> str:
        display_name = session_meta.agent_name or "orchestrator"
        rot_pct = int(rot_result.rot_score * 100)
        status_upper = rot_result.status.upper()
        branch = session_meta.git_branch or "unknown"

        lines: list[str] = [
            f"# Session Context: {display_name}",
            f"**Branch:** {branch} | **Rot:** {rot_pct}% ({status_upper})",
            "",
        ]

        # What was accomplished (last 3 assistant text blocks from eviction candidates preview)
        lines.append("## What was accomplished")
        lines.append("_(derived from most recent session activity)_")
        lines.append("")

        # Active issue
        lines.append("## Active issue")
        if rot_result.active_issue is not None:
            issue = rot_result.active_issue
            milestone_str = f" ({issue.milestone})" if issue.milestone else ""
            lines.append(f"#{issue.id} {issue.title}{milestone_str} — {issue.status.upper()}")
        else:
            lines.append("No active issue detected")
        lines.append("")

        # Modified files
        lines.append("## Files modified this session")
        if modified_files:
            for f in modified_files:
                lines.append(f"- {f}")
        else:
            lines.append("_(none tracked)_")
        lines.append("")

        # Load these files
        lines.append("## Load these files before continuing")
        if modified_files:
            for f in modified_files:
                lines.append(f"- {f}")
        else:
            lines.append("_(no files to reload)_")
        lines.append("")

        # Context pressure summary
        lines.append("## Context pressure summary")
        lines.append(f"- Keep: {rot_result.keep_tokens:,} tokens")
        lines.append(
            f"- Evictable: {rot_result.evictable_tokens:,} tokens (safe to discard)"
        )
        lines.append(
            f"- Stale: {rot_result.stale_tokens:,} tokens (not referenced in last 10 turns)"
        )

        return "\n".join(lines) + "\n"
