from __future__ import annotations

from pathlib import Path

from vibewatch.core.models import IssueRef, RotRiskResult


class HandoffGenerator:
    """Generates a paste-ready handoff prompt for starting a fresh session."""

    def __init__(self, project_name: str) -> None:
        self._project_name = project_name

    def generate(
        self,
        rot_result: RotRiskResult,
        active_issue: IssueRef | None,
        modified_files: list[str],
        context_path: Path | None = None,
    ) -> str:
        if context_path is not None:
            return self._generate_pointer(rot_result, active_issue, context_path)

        lines: list[str] = []
        lines.append("=== VibeWatch Handoff Prompt ===")
        lines.append(f"Project: {self._project_name}")

        rot_pct = int(rot_result.rot_score * 100)
        evictable = rot_result.evictable_tokens + rot_result.stale_tokens
        lines.append(
            f"Session rot score: {rot_pct}% ({rot_result.status} — ~{evictable:,} evictable tokens)"
        )
        lines.append("")

        if active_issue is not None:
            lines.append(
                f"Active Issue: #{active_issue.id} {active_issue.title} ({active_issue.status})"
            )
            if active_issue.milestone:
                lines.append(f"Milestone: {active_issue.milestone}")
            lines.append(f"URL: {active_issue.url}")
            lines.append("")

        lines.append("CONTEXT SUMMARY:")
        lines.append(f"You are continuing work on {self._project_name}.")
        if active_issue is not None:
            lines.append(
                f"Current task: {active_issue.title} "
                f"({active_issue.tracker.title()} #{active_issue.id}"
                + (f", {active_issue.milestone}" if active_issue.milestone else "")
                + ")."
            )
        lines.append("")

        if modified_files:
            lines.append("Files modified this session:")
            for f in modified_files:
                lines.append(f"- {f}")
            lines.append("")
            lines.append("Load these files before continuing:")
            for f in modified_files:
                lines.append(f"- {f}")
            lines.append("")

        lines.append("=== End Handoff Prompt ===")
        return "\n".join(lines)

    def _generate_pointer(
        self,
        rot_result: RotRiskResult,
        active_issue: IssueRef | None,
        context_path: Path,
    ) -> str:
        """Short pointer prompt that references an offloaded context file."""
        rot_pct = int(rot_result.rot_score * 100)
        lines: list[str] = [
            "=== VibeWatch Handoff ===",
            f"Project: {self._project_name} | Rot: {rot_pct}% ({rot_result.status.upper()})",
            "",
            "Context file written to:",
            f"  {context_path}",
            "",
            "READ THAT FILE FIRST before doing anything else.",
            "",
        ]
        if active_issue is not None:
            lines.append(
                f"Active issue: #{active_issue.id} {active_issue.title} (in-progress)"
            )
            lines.append("Next: Continue from where the session left off per the context file.")
        lines.append("=== End Handoff ===")
        return "\n".join(lines)
