# Development Guide

## Prerequisites

- Python 3.11+
- uv (recommended) or pip

## Setup

```bash
git clone https://github.com/avmkmk/vibewatch.git
cd vibewatch
uv venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
uv pip install -e ".[dev]"
```

## Commands

```bash
# Run tests
pytest

# Run tests with coverage
pytest --cov=src/vibewatch

# Lint
ruff check src/ tests/

# Type check
mypy src/vibewatch/

# All checks (run before committing)
ruff check src/ tests/ && mypy src/vibewatch/ && pytest
```

## Project structure

```
src/vibewatch/
  adapters/         - One per AI tool (ClaudeCodeAdapter, AiderAdapter, CopilotAdapter)
  core/
    detector.py     - Auto-detect AI tool + find session files
    models.py       - SessionMeta, ContextBlock, RotRiskResult, IssueRef
    rot_calculator.py - Decay classification + rot score formula
    session_ranker.py - Classify + rank multi-session JSONL files
  generators/
    context_writer.py - Write JSON + Markdown context snapshots
    handoff.py      - Generate handoff prompt (inline or pointer)
  integrations/     - GitHub + GitLab issue tracker
  tui/              - Textual dashboard (VibeDashboard, VibeDashboardSwarm)
  cli.py            - Click entrypoint (watch, audit, init)
  config.py         - Pydantic settings
tests/              - Mirrors src/ structure, plus tests/fixtures/
docs/               - Architecture, JSONL schema reference
```

## Adding a new adapter

1. Create `src/vibewatch/adapters/<tool_name>.py`
2. Subclass `SessionAdapter` from `base.py`
3. Implement `read() -> SessionState`
4. Add detection logic in `core/detector.py`
5. Add a case in `cli.py::_resolve_adapter()`
6. Write tests in `tests/adapters/test_<tool_name>.py`
