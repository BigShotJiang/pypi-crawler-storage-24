# Architecture

## Data flow

```
AI tool writes transcript (JSONL / .md)
        |
watchdog (poll_interval) detects change
        |
SessionAdapter.read() -> SessionState (list[ContextBlock])
        |
RotCalculator.score(blocks) -> RotRiskResult
        |
IssueTracker.get_active_issue() -> IssueRef | None
        |
Dashboard.update() -> live TUI refresh
        | (press G)
HandoffGenerator.generate() -> clipboard + stdout
```

## Decay class priority

Priority order: keep > evictable > stale > monitor.
The first matching rule wins. Each block gets exactly one class.
Sum invariant: keep + evictable + stale + monitor == total_tokens (enforced).

## Rot score formula

```
rot_score = (stale/total * 0.50) + (evictable/total * 0.30) + (monitor/total * 0.20)
```

Thresholds: green < 0.40, yellow < 0.70, red >= 0.70.

## Token counting

tiktoken cl100k_base is used for token estimates (~15-25% error vs Claude tokenizer).
All displayed counts are prefixed with ~ to communicate this.
When available, model-reported usage.input_tokens from the most recent assistant line
is used as the actual total budget (not estimated).
