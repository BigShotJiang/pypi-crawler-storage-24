# Claude Code JSONL Schema

Each line in `~/.claude/projects/<project-hash>/<session-uuid>.jsonl` is a JSON object.

## User turn (plain text)

```json
{
  "type": "user",
  "uuid": "9b014a59-...",
  "parentUuid": "206bdaab-...",
  "sessionId": "105b8f44-...",
  "timestamp": "2026-03-05T07:12:35.922Z",
  "isMeta": false,
  "cwd": "/path/to/project",
  "gitBranch": "feature/23-hitl-queue-page",
  "message": {
    "role": "user",
    "content": "Implement the HITL queue page"
  }
}
```

## User turn carrying tool results

Tool result lines have `type: "user"` with content array:

```json
{
  "type": "user",
  "uuid": "f5727ad1-...",
  "toolUseResult": "File does not exist...",
  "message": {
    "role": "user",
    "content": [
      {
        "type": "tool_result",
        "tool_use_id": "toolu_bdrk_01Tn...",
        "content": "File does not exist...",
        "is_error": true
      }
    ]
  }
}
```

## Assistant turn with tool use

```json
{
  "type": "assistant",
  "uuid": "327fad66-...",
  "message": {
    "role": "assistant",
    "model": "claude-sonnet-4-6",
    "usage": { "input_tokens": 3, "cache_read_input_tokens": 57457 },
    "content": [
      { "type": "thinking", "thinking": "...", "signature": "..." },
      {
        "type": "tool_use",
        "id": "toolu_bdrk_01Tn...",
        "name": "Read",
        "input": { "file_path": "/path/to/file" }
      }
    ]
  }
}
```

## Progress/hook events (ignore these)

```json
{ "type": "progress", "data": { "type": "hook_progress" } }
{ "type": "file-history-snapshot", "messageId": "x" }
```

## Key parsing rules

- Lines are appended incrementally as the session progresses
- `type` field distinguishes message lines (`"user"`, `"assistant"`) from metadata
- Tool results appear as `type: "user"` lines where `message.content` is an array with `type: "tool_result"` items
- Thinking blocks appear as `type: "thinking"` items inside `message.content` on assistant lines
- Token counts are in `message.usage` on assistant lines (`input_tokens`, `cache_read_input_tokens`, `cache_creation_input_tokens`)
- `gitBranch` and `cwd` appear on user lines that initiate tool requests
