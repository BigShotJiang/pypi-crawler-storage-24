"""Tests for constants completeness — validation sets, rel types, confidence."""

from __future__ import annotations

from arandu.constants import (
    ALLOWED_ATTRIBUTE_KEYS,
    ATTRIBUTE_ALIASES,
    CANONICAL_REL_TYPES,
    KEY_MAPPER_ALLOWED_NAMESPACES,
    KEY_MAPPER_MAX_KEY_LENGTH,
    VALID_EMOTIONS,
    VALID_ENERGIES,
    VALID_OBSERVATION_TYPES,
    normalize_rel_type,
    resolve_confidence,
)

# ---------------------------------------------------------------------------
# Attribute catalog (now empty by default — deployers extend via config)
# ---------------------------------------------------------------------------


def test_allowed_keys_empty_by_default():
    """ALLOWED_ATTRIBUTE_KEYS should be empty set by default (open catalog)."""
    assert set() == ALLOWED_ATTRIBUTE_KEYS


def test_aliases_empty_by_default():
    """ATTRIBUTE_ALIASES should be empty dict by default."""
    assert ATTRIBUTE_ALIASES == {}


# ---------------------------------------------------------------------------
# Namespaces
# ---------------------------------------------------------------------------


def test_namespaces_have_core():
    """KEY_MAPPER_ALLOWED_NAMESPACES should include core generic namespaces."""
    for ns in ["user", "person", "pet", "place", "organization"]:
        assert ns in KEY_MAPPER_ALLOWED_NAMESPACES


def test_namespaces_no_domain_specific():
    """KEY_MAPPER_ALLOWED_NAMESPACES should not contain domain-specific namespaces."""
    for ns in ["finance", "style", "fitness"]:
        assert ns not in KEY_MAPPER_ALLOWED_NAMESPACES


def test_max_key_length():
    """KEY_MAPPER_MAX_KEY_LENGTH should be 64."""
    assert KEY_MAPPER_MAX_KEY_LENGTH == 64


# ---------------------------------------------------------------------------
# Validation sets
# ---------------------------------------------------------------------------


def test_emotions_complete():
    """VALID_EMOTIONS should have ≥10 entries."""
    assert len(VALID_EMOTIONS) >= 10
    assert "neutral" in VALID_EMOTIONS


def test_energies_complete():
    """VALID_ENERGIES should have high/medium/low."""
    assert frozenset({"high", "medium", "low"}) == VALID_ENERGIES


def test_observation_types_complete():
    """VALID_OBSERVATION_TYPES should have core types."""
    assert "pattern" in VALID_OBSERVATION_TYPES
    assert "behavioral_preference" in VALID_OBSERVATION_TYPES


# ---------------------------------------------------------------------------
# Relationship types
# ---------------------------------------------------------------------------


def test_canonical_rel_types():
    """CANONICAL_REL_TYPES should have core relationships."""
    assert "family_of" in CANONICAL_REL_TYPES
    assert "works_at" in CANONICAL_REL_TYPES


def test_normalize_rel_type_alias():
    """normalize_rel_type should resolve aliases."""
    assert normalize_rel_type("boss") == "reports_to"
    assert normalize_rel_type("spouse") == "partner_of"


# ---------------------------------------------------------------------------
# Confidence
# ---------------------------------------------------------------------------


def test_resolve_confidence_level():
    """resolve_confidence with level should return mapped value."""
    assert resolve_confidence("explicit_statement") == 0.95


def test_resolve_confidence_float():
    """resolve_confidence with float should return clamped value."""
    assert resolve_confidence(confidence_float=0.77) == 0.77
