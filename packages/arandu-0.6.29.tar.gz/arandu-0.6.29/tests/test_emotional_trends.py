"""Tests for emotional trends — keyword extraction, result dataclass, helpers."""

from __future__ import annotations

from arandu.read.emotional_trends import (
    EmotionalTrendsResult,
    _extract_keywords,
    _parse_trend_meta,
)

# ---------------------------------------------------------------------------
# Keyword extraction
# ---------------------------------------------------------------------------


def test_extract_keywords_basic():
    """Should extract frequent words excluding PT-BR stopwords."""
    text = "trabalho estressante no trabalho com muito estresse"
    keywords = _extract_keywords(text, top_n=3)
    assert "trabalho" in keywords
    assert "estressante" in keywords or "estresse" in keywords


def test_extract_keywords_empty():
    """Empty text → empty list."""
    assert _extract_keywords("") == []
    assert _extract_keywords("  ") == []


def test_extract_keywords_stopwords_filtered():
    """Stopwords should be excluded."""
    text = "que de para com não uma um os as"
    keywords = _extract_keywords(text, top_n=5)
    assert len(keywords) == 0


def test_extract_keywords_short_words_filtered():
    """Words shorter than 3 chars should be excluded."""
    text = "eu vi os as de um"
    keywords = _extract_keywords(text, top_n=5)
    assert len(keywords) == 0


def test_extract_keywords_accents():
    """Should handle PT-BR accents."""
    text = "emoção emoção emoção felicidade"
    keywords = _extract_keywords(text, top_n=2)
    assert "emoção" in keywords


# ---------------------------------------------------------------------------
# EmotionalTrendsResult defaults
# ---------------------------------------------------------------------------


def test_emotional_trends_result_defaults():
    """EmotionalTrendsResult should have sane defaults."""
    result = EmotionalTrendsResult()
    assert result.emotion_counts == {}
    assert result.trend_direction == "stable"
    assert result.dominant_emotion is None
    assert result.trigger_keywords == []
    assert result.avg_intensity == 0.0
    assert result.events_analyzed == 0
    assert result.observation_created is False
    assert result.observation_id is None


# ---------------------------------------------------------------------------
# _parse_trend_meta
# ---------------------------------------------------------------------------


def test_parse_trend_meta_full():
    """Should extract emotion and direction from observation."""
    from types import SimpleNamespace

    obs = SimpleNamespace(
        title="Emotional trend: ansiedade",
        text='Emotional trend (30 days): dominant emotion "ansiedade" (5x). Direction: increasing.',
    )
    dominant, direction = _parse_trend_meta(obs)
    assert dominant == "ansiedade"
    assert direction == "increasing"


def test_parse_trend_meta_no_direction():
    """Missing direction → empty string."""
    from types import SimpleNamespace

    obs = SimpleNamespace(
        title="Emotional trend: alegria",
        text="Sem informação de direção",
    )
    dominant, direction = _parse_trend_meta(obs)
    assert dominant == "alegria"
    assert direction == ""


def test_parse_trend_meta_empty():
    """Empty observation → empty strings."""
    from types import SimpleNamespace

    obs = SimpleNamespace(title="", text="")
    dominant, direction = _parse_trend_meta(obs)
    assert dominant == ""
    assert direction == ""
