# Referência da API

Gerada automaticamente a partir dos docstrings do código-fonte. Para guias conceituais sobre como esses componentes funcionam juntos, veja a seção [Conceitos](../concepts/write-pipeline.md).

---

## Client

### MemoryClient

::: arandu.MemoryClient
    options:
      show_source: false
      heading_level: 4
      members_order: source

### WriteResult

::: arandu.WriteResult
    options:
      show_source: false
      heading_level: 4

### RetrieveResult

::: arandu.RetrieveResult
    options:
      show_source: false
      heading_level: 4

### ScoredFact

::: arandu.ScoredFact
    options:
      show_source: false
      heading_level: 4

### PipelineTrace

::: arandu.PipelineTrace
    options:
      show_source: false
      heading_level: 4

---

## Configuração

### MemoryConfig

::: arandu.MemoryConfig
    options:
      show_source: false
      heading_level: 4

---

## Protocolos

### LLMProvider

::: arandu.LLMProvider
    options:
      show_source: false
      heading_level: 4

### EmbeddingProvider

::: arandu.EmbeddingProvider
    options:
      show_source: false
      heading_level: 4

---

## Providers

### OpenAIProvider

::: arandu.providers.openai.OpenAIProvider
    options:
      show_source: false
      heading_level: 4

---

## Exceções

### MemoryError

::: arandu.MemoryError
    options:
      show_source: false
      heading_level: 4

### ExtractionError

::: arandu.ExtractionError
    options:
      show_source: false
      heading_level: 4

### ResolutionError

::: arandu.ResolutionError
    options:
      show_source: false
      heading_level: 4

### ReconciliationError

::: arandu.ReconciliationError
    options:
      show_source: false
      heading_level: 4

### RetrievalError

::: arandu.RetrievalError
    options:
      show_source: false
      heading_level: 4

### UpsertError

::: arandu.UpsertError
    options:
      show_source: false
      heading_level: 4

---

## Funções de Background

### Clustering

#### cluster_user_facts

::: arandu.cluster_user_facts
    options:
      show_source: false
      heading_level: 5

#### detect_communities

::: arandu.detect_communities
    options:
      show_source: false
      heading_level: 5

### Consolidation

#### run_consolidation

::: arandu.run_consolidation
    options:
      show_source: false
      heading_level: 5

#### run_profile_consolidation

::: arandu.run_profile_consolidation
    options:
      show_source: false
      heading_level: 5

### Memify

#### run_memify

::: arandu.run_memify
    options:
      show_source: false
      heading_level: 5

#### compute_vitality

::: arandu.compute_vitality
    options:
      show_source: false
      heading_level: 5

### Sleep-Time Compute

#### compute_entity_importance

::: arandu.compute_entity_importance
    options:
      show_source: false
      heading_level: 5

#### refresh_entity_summaries

::: arandu.refresh_entity_summaries
    options:
      show_source: false
      heading_level: 5

#### detect_entity_communities

::: arandu.detect_entity_communities
    options:
      show_source: false
      heading_level: 5

---

## Dataclasses de Resultado

### ClusteringResult

::: arandu.ClusteringResult
    options:
      show_source: false
      heading_level: 4

### CommunityDetectionResult

::: arandu.CommunityDetectionResult
    options:
      show_source: false
      heading_level: 4

### ConsolidationResult

::: arandu.ConsolidationResult
    options:
      show_source: false
      heading_level: 4

### MemifyResult

::: arandu.MemifyResult
    options:
      show_source: false
      heading_level: 4

### EntityImportanceResult

::: arandu.EntityImportanceResult
    options:
      show_source: false
      heading_level: 4

### SummaryRefreshResult

::: arandu.SummaryRefreshResult
    options:
      show_source: false
      heading_level: 4

---

## Veja Tambem: API Avancada

Para documentacao de funcoes internas do pipeline, exports de sub-modulos e tipos de dados adicionais nao cobertos aqui, veja a secao **Avancado**:

- [API do Write Pipeline](../advanced/write-api.md) -- estrategia de extracao, canonicalizacao, helpers de entidades, deteccao de correcoes, operacoes pendentes e `run_write_pipeline()`.
- [API do Read Pipeline](../advanced/read-api.md) -- retrieval agent, expansao de query, retrieval de grafo, spreading activation, compressao de contexto, tendencias emocionais, importancia dinamica, memoria procedimental e `run_read_pipeline()`.
- [Utilitarios de Banco de Dados](../advanced/database.md) -- `create_engine()`, `create_session_factory()`, `init_db()` e visao geral do schema.
- [Referencia de Tipos de Dados](../advanced/data-types.md) -- todos os enums, dataclasses e tipos de resultado dos modulos de escrita, leitura e background.
