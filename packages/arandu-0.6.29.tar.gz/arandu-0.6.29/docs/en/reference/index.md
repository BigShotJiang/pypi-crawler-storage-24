# API Reference

Auto-generated from source code docstrings. For conceptual guides on how these components work together, see the [Concepts](../concepts/write-pipeline.md) section.

---

## Client

### MemoryClient

::: arandu.MemoryClient
    options:
      show_source: false
      heading_level: 4
      members_order: source

### WriteResult

::: arandu.WriteResult
    options:
      show_source: false
      heading_level: 4

### RetrieveResult

::: arandu.RetrieveResult
    options:
      show_source: false
      heading_level: 4

### ScoredFact

::: arandu.ScoredFact
    options:
      show_source: false
      heading_level: 4

### PipelineTrace

::: arandu.PipelineTrace
    options:
      show_source: false
      heading_level: 4

---

## Configuration

### MemoryConfig

::: arandu.MemoryConfig
    options:
      show_source: false
      heading_level: 4

---

## Protocols

### LLMProvider

::: arandu.LLMProvider
    options:
      show_source: false
      heading_level: 4

### EmbeddingProvider

::: arandu.EmbeddingProvider
    options:
      show_source: false
      heading_level: 4

---

## Providers

### OpenAIProvider

::: arandu.providers.openai.OpenAIProvider
    options:
      show_source: false
      heading_level: 4

---

## Exceptions

### MemoryError

::: arandu.MemoryError
    options:
      show_source: false
      heading_level: 4

### ExtractionError

::: arandu.ExtractionError
    options:
      show_source: false
      heading_level: 4

### ResolutionError

::: arandu.ResolutionError
    options:
      show_source: false
      heading_level: 4

### ReconciliationError

::: arandu.ReconciliationError
    options:
      show_source: false
      heading_level: 4

### RetrievalError

::: arandu.RetrievalError
    options:
      show_source: false
      heading_level: 4

### UpsertError

::: arandu.UpsertError
    options:
      show_source: false
      heading_level: 4

---

## Background Functions

### Clustering

#### cluster_user_facts

::: arandu.cluster_user_facts
    options:
      show_source: false
      heading_level: 5

#### detect_communities

::: arandu.detect_communities
    options:
      show_source: false
      heading_level: 5

### Consolidation

#### run_consolidation

::: arandu.run_consolidation
    options:
      show_source: false
      heading_level: 5

#### run_profile_consolidation

::: arandu.run_profile_consolidation
    options:
      show_source: false
      heading_level: 5

### Memify

#### run_memify

::: arandu.run_memify
    options:
      show_source: false
      heading_level: 5

#### compute_vitality

::: arandu.compute_vitality
    options:
      show_source: false
      heading_level: 5

### Sleep-Time Compute

#### compute_entity_importance

::: arandu.compute_entity_importance
    options:
      show_source: false
      heading_level: 5

#### refresh_entity_summaries

::: arandu.refresh_entity_summaries
    options:
      show_source: false
      heading_level: 5

#### detect_entity_communities

::: arandu.detect_entity_communities
    options:
      show_source: false
      heading_level: 5

---

## Result Dataclasses

### ClusteringResult

::: arandu.ClusteringResult
    options:
      show_source: false
      heading_level: 4

### CommunityDetectionResult

::: arandu.CommunityDetectionResult
    options:
      show_source: false
      heading_level: 4

### ConsolidationResult

::: arandu.ConsolidationResult
    options:
      show_source: false
      heading_level: 4

### MemifyResult

::: arandu.MemifyResult
    options:
      show_source: false
      heading_level: 4

### EntityImportanceResult

::: arandu.EntityImportanceResult
    options:
      show_source: false
      heading_level: 4

### SummaryRefreshResult

::: arandu.SummaryRefreshResult
    options:
      show_source: false
      heading_level: 4

---

## See Also: Advanced API

For documentation of internal pipeline functions, sub-module exports, and additional data types not covered here, see the **Advanced** section:

- [Write Pipeline API](../advanced/write-api.md) -- extraction strategy, canonicalization, entity helpers, correction detection, pending operations, and `run_write_pipeline()`.
- [Read Pipeline API](../advanced/read-api.md) -- retrieval agent, query expansion, graph retrieval, spreading activation, context compression, emotional trends, dynamic importance, procedural memory, and `run_read_pipeline()`.
- [Database Utilities](../advanced/database.md) -- `create_engine()`, `create_session_factory()`, `init_db()`, and schema overview.
- [Data Types Reference](../advanced/data-types.md) -- all enums, dataclasses, and result types across write, read, and background modules.
