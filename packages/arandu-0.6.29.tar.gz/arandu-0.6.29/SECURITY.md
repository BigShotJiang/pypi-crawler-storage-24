# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in arandu, please report it responsibly.

**Email:** pedromenezesrs@gmail.com

Please include:

- A description of the vulnerability
- Steps to reproduce
- Potential impact

## Response

You can expect an initial response within 72 hours. We will work with you to understand and address the issue before any public disclosure.

## Scope

This policy applies to the arandu Python package and its official repository at [github.com/pe-menezes/arandu](https://github.com/pe-menezes/arandu).
