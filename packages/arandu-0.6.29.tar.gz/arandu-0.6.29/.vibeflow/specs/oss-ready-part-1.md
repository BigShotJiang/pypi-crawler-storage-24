# Spec: OSS-Ready — Part 1: Core Files

> Source PRD: `.vibeflow/prds/oss-ready.md`

## Objective

Tornar o repositório arandu reconhecível como projeto open-source profissional adicionando os arquivos-base que devs experientes esperam (LICENSE, CONTRIBUTING, README correto, pyproject.toml completo).

## Context

O README atual tem 6 links apontando para `your-org.github.io/personal-genius/` (URL errada — o correto é `pe-menezes.github.io/arandu/`), referencia um path `packages/memory-sdk` que não existe, e não tem badges funcionais. O `pyproject.toml` não tem `[project.urls]` nem email do autor. Não existe arquivo LICENSE (apesar de declarar MIT), nem CONTRIBUTING, CODE_OF_CONDUCT ou SECURITY.

## Definition of Done

1. **LICENSE existe** — Arquivo `LICENSE` na raiz com texto completo da MIT, copyright "Pedro Menezes".
2. **README sem links quebrados** — Todos os links no README.md apontam para URLs reais (`pe-menezes.github.io/arandu/`, `github.com/pe-menezes/arandu`, `pypi.org/project/arandu/`). Nenhuma ocorrência de `your-org` ou `personal-genius`.
3. **README com badges reais** — Badges de CI (workflow `ci.yml`), PyPI, License, e Docs apontam para URLs corretas.
4. **CONTRIBUTING.md existe** — Com seções: Prerequisites, Development Setup, Running Tests, Code Style, Pull Request Guidelines.
5. **CODE_OF_CONDUCT.md e SECURITY.md existem** — Contributor Covenant 2.1 e política de reporte de vulnerabilidades.
6. **pyproject.toml completo** — Contém `[project.urls]` (Homepage, Repository, Documentation, Issues, Changelog) e email do autor.

## Scope

- Criar `LICENSE` (MIT, 2025, Pedro Menezes)
- Reescrever `README.md`: corrigir todos os links, adicionar badges reais, remover referência a `packages/memory-sdk` (trocar por `await memory.initialize()`), remover seção "Database Setup" com alembic (o SDK cria as tabelas automaticamente)
- Criar `CONTRIBUTING.md` em inglês
- Criar `CODE_OF_CONDUCT.md` (Contributor Covenant 2.1)
- Criar `SECURITY.md` (reportar via email pedromenezesrs@gmail.com)
- Atualizar `pyproject.toml`: adicionar `[project.urls]`, adicionar email ao autor

## Anti-scope

- NÃO alterar código-fonte em `src/`
- NÃO criar workflows (Part 2)
- NÃO criar issue/PR templates (Part 2)
- NÃO traduzir CONTRIBUTING/CODE_OF_CONDUCT para PT-BR
- NÃO adicionar CHANGELOG.md
- NÃO modificar conteúdo da documentação MkDocs

## Technical Decisions

| Decisão | Escolha | Justificativa |
|---------|---------|---------------|
| Idioma dos arquivos OSS | Inglês | Padrão da indústria; devs de qualquer país leem |
| License year | 2025 | Ano de início do projeto |
| CONTRIBUTING: install command | `pip install -e ".[dev]"` | Já funciona com o pyproject.toml atual |
| CONTRIBUTING: test command | `pytest` | asyncio_mode=auto já configurado |
| CONTRIBUTING: lint command | `ruff check . && ruff format --check .` | Já configurado no pyproject.toml |
| CONTRIBUTING: type check | `mypy src/` | Strict mode já configurado |
| Badge de CI | Aponta para workflow `ci.yml` | Será criado na Part 2; badge já fica correto |
| Seção "Database Setup" do README | Remover referência a alembic/packages | O path `packages/memory-sdk` não existe; `await memory.initialize()` já é documentado |

## Applicable Patterns

Nenhum `.vibeflow/patterns/` existe. Convenções inferidas do código:
- Markdown files usam heading hierarchy padrão
- pyproject.toml usa hatchling como build backend
- Projeto é bilíngue mas arquivos de governança ficam em inglês

## Risks

| Risco | Mitigação |
|-------|-----------|
| Badge de CI vai mostrar "not found" até Part 2 ser implementada | Aceitável — badge aponta para URL correta, só precisa do workflow existir |
| README pode ter links que dependem de paths futuros | Usar apenas URLs que já existem hoje (GitHub Pages, GitHub repo, PyPI project) |

## Budget

6 arquivos: `LICENSE`, `README.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`, `pyproject.toml`
