# Audit Report: Write Pipeline Code Fixes — enable_llm_resolution + strength reinforcement

**Verdict: PASS**

> Spec: `.vibeflow/specs/write-pipeline-code-fixes.md`
> Audited: 2026-03-19
> Tests: 318 passed, 0 failed

---

### DoD Checklist

- [x] **DoD 1 — `enable_llm_resolution=False` desliga LLM na entity resolution**
  - `_resolve_single()` (entity_resolution.py L446): novo param `enable_llm_resolution: bool = True`.
  - Guard at L550: `if ambiguous and enable_llm_resolution:` — Phase 3 LLM é pulada quando `False`.
  - Propagado: `resolve_entities()` L585 → `_resolve_single()` L626, L657 → `pipeline.py` L148 passa `config.enable_llm_resolution`.
  - Testes: `test_llm_skipped_when_disabled` verifica que `llm.complete` não é chamado quando `False`.

- [x] **DoD 2 — Strength incremental no pipeline**
  - `upsert_relations()` (upsert.py L643): `LEAST(1.0, memory_entity_relationships.strength + 0.1)` substitui `GREATEST(...)`.
  - Relações repetidas agora incrementam `+0.1` com cap em `1.0`.
  - Testes: `test_on_conflict_uses_least_not_greatest` verifica via source inspection.

- [x] **DoD 3 — Testes cobrem ambos os fixes**
  - `tests/test_pipeline_code_fixes.py`: 4 testes em 2 classes:
    - `TestEnableLlmResolution` (3): LLM skipped when disabled, LLM accepted when enabled, signature check.
    - `TestStrengthReinforcement` (1): SQL expression verification.

- [x] **DoD 4 — Testes existentes passando**
  - 318/318 PASS.

---

### Pattern Compliance

- [x] **Data Access** — Seguido. SQL expression `LEAST(1.0, ...)` é SQL padrão PostgreSQL.
- [x] **Error Handling** — Seguido. Skip de LLM é fail-safe (cria nova entidade).
- [x] **Testing** — Seguido. Mock-based, class grouping, `test_<feature>.py` naming.

### Convention Violations

Nenhuma.

### Budget

Arquivos: **4 / ≤ 4** ✅
1. `src/arandu/write/entity_resolution.py` (modified)
2. `src/arandu/write/upsert.py` (modified)
3. `src/arandu/write/pipeline.py` (modified — 1 kwarg)
4. `tests/test_pipeline_code_fixes.py` (created)

### Anti-scope

- `track_entity_relationship()` — not touched ✅
- Prompts — not touched ✅
- models.py — not touched ✅
- Docs — not touched ✅

**Nota**: `pipeline.py` modificado com 1 linha para propagar `config.enable_llm_resolution`. Sem isso o param continuaria dead code. Desvio mínimo e necessário.
