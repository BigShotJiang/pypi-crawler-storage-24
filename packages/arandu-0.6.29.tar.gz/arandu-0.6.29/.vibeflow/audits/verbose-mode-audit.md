# Audit Report: verbose-mode

**Verdict: PASS**

## Tests
14/14 passed (test_verbose.py) — 0 failures.

## DoD Checklist
- [x] **PipelineTrace existe** — `src/arandu/tracing.py:26` contém `PipelineTrace` com `add_step()` (L47), `to_dict()` (L51), e `PipelineStep` (L17).
- [x] **WriteResult tem campo pipeline** — `client.py:28` declara `pipeline: PipelineTrace | None = None`. `write()` aceita `verbose: bool = False` (L98) e passa `trace` para `run_write_pipeline()`. Write pipeline registra 4 steps: `extraction`, `entity_resolution`, `reconciliation`, `upsert`.
- [x] **RetrieveResult tem campo pipeline** — `client.py:51` declara `pipeline: PipelineTrace | None = None`. `retrieve()` aceita `verbose: bool = False` (L139) e passa `trace` para `run_read_pipeline()`. Read pipeline registra 5 steps: `planning`, `retrieval`, `reranking`, `scoring`, `compression`.
- [x] **Zero breaking changes** — `pipeline` default é `None` em ambos os results. `verbose` é keyword-only (`*`) com default `False`. Chamadas existentes sem verbose continuam funcionando identicamente.
- [x] **Cada step tem duration_ms** — `PipelineStep.duration_ms: float` (tracing.py:19). Cada `add_step()` call nos pipelines usa `trace.elapsed()` baseado em `time.perf_counter()`.
- [x] **Testes passam** — 14/14 em test_verbose.py. Cobertura: PipelineTrace unit tests, serialização UUID/datetime, step names do write (4) e read (5), default None, pipeline populated.

## Pattern Compliance
- [x] Dataclass pattern — `PipelineTrace` e `PipelineStep` usam `@dataclass`, consistente com `WriteResult`, `ScoredFact`, `ReadResult`.
- [x] `time.perf_counter()` — Mesmo padrão já usado nos pipelines para `duration_ms` total.
- [x] Lazy imports — `client.py` importa pipelines dentro dos métodos (pattern existente mantido).
- [x] Pydantic `.model_dump()` — Usado em `_serialize()` para converter ExtractedEntity/Fact/Relation.
- [x] Keyword-only param — `verbose` é keyword-only (`*`), prevenindo confusão posicional.

## Convention Violations
Nenhuma.

## Budget
5 / ≤ 6 arquivos: tracing.py (novo), client.py, write/pipeline.py, read/pipeline.py, test_verbose.py (novo).

## Anti-scope
Todos os itens respeitados — nenhuma função interna alterada, nenhum background job tocado, __init__.py inalterado, prompts LLM inalterados.
