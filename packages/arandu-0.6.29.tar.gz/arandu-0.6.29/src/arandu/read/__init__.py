"""Read pipeline — retrieve relevant memory facts for a query."""

from arandu.read.context_compression import (
    CompressedContext,
    compress_broad_context,
    compress_context,
)
from arandu.read.emotional_trends import (
    EmotionalTrendsResult,
    get_emotional_summary_for_context,
    materialize_emotional_trends,
)
from arandu.read.graph_retrieval import GraphRetrievalResult, retrieve_graph_facts
from arandu.read.importance import compute_dynamic_importance
from arandu.read.pipeline import run_read_pipeline
from arandu.read.procedural import (
    ContradictionResult,
    DirectiveBlock,
    check_directive_contradiction,
    effective_confidence,
    generate_optimized_directives,
    invalidate_directive_cache,
)
from arandu.read.query_expansion import ExpandedQuery, expand_query
from arandu.read.retrieval import (
    compute_pattern_signal,
    retrieve_relevant_events,
)
from arandu.read.retrieval_agent import PatternQuery, RetrievalPlan, plan_retrieval
from arandu.read.spreading_activation import (
    SpreadingActivationResult,
    spread_activation,
)

__all__ = [
    "CompressedContext",
    "ContradictionResult",
    "DirectiveBlock",
    "EmotionalTrendsResult",
    "ExpandedQuery",
    "GraphRetrievalResult",
    "PatternQuery",
    "RetrievalPlan",
    "SpreadingActivationResult",
    "check_directive_contradiction",
    "compress_broad_context",
    "compress_context",
    "compute_dynamic_importance",
    "compute_pattern_signal",
    "effective_confidence",
    "expand_query",
    "generate_optimized_directives",
    "get_emotional_summary_for_context",
    "invalidate_directive_cache",
    "materialize_emotional_trends",
    "plan_retrieval",
    "retrieve_graph_facts",
    "retrieve_relevant_events",
    "run_read_pipeline",
    "spread_activation",
]
