# CLAUDE.md — Arandu SDK

## Post-implementation checklist (OBRIGATÓRIO)

Após QUALQUER feature, fix ou mudança de código — SEMPRE, sem perguntar:

1. **Bump de versão** no `pyproject.toml` (patch para fixes, minor para features, major para breaking changes)
2. **Atualizar docs/en/** — documentação em inglês refletindo a mudança (GitHub Pages)
3. **Atualizar docs/pt-BR/** — documentação em português refletindo a mudança (GitHub Pages)
4. **Atualizar mkdocs.yml** se houver nova página de docs
5. **Avisar o usuário** que a versão foi bumpada (ele precisa disparar release manual no GitHub Actions)

Isso NÃO é opcional. NÃO esperar o usuário pedir. Fazer como parte da implementação.

### O que "atualizar docs" significa

Não é só trocar um comentário numa linha. É revisar TODAS as seções dos docs
que falam sobre o comportamento que mudou e atualizar o texto, exemplos e
descrições. Os docs são a documentação pública do GitHub Pages — se o
comportamento mudou no código, os docs TÊM que refletir isso com o mesmo
nível de detalhe. Pensar: "se um dev ler só os docs, ele vai entender o
comportamento atual?" Se não, tá faltando coisa.

## CI antes de push

Rodar ruff + mypy + pytest ANTES de qualquer commit/push. Já quebrou CI 3+ vezes por pular mypy.

```bash
python -m ruff check src/ tests/ && python -m ruff format --check src/ tests/ && python -m mypy src/arandu/ && python -m pytest tests/ -q
```

## Comunicação

- Ter opinião forte, não flip-flopar
- Explicar simples, sem jargão desnecessário
- Português como idioma padrão de conversa

## Obsidian Vault — Integração

Este projeto tem um board Kanban e notas no vault Obsidian do Pedro.

**Caminho do vault:** `~/Documents/Obsidian Vault/`
**Board do projeto:** `~/Documents/Obsidian Vault/Projetos/Arandu/Arandu - Kanban.md`

### Regras de operação

1. **Ao começar a trabalhar numa tarefa:**
   - Ler o board Kanban pra saber o que tá no backlog/sprint
   - Mover a tarefa pro "Fazendo" no board

2. **Ao concluir uma tarefa:**
   - Mover a tarefa pra "Feito" no board Kanban
   - Se surgiram novas tarefas durante o trabalho, adicionar no "Backlog"

3. **Ao descobrir algo relevante sobre o Pedro ou o projeto:**
   - Atualizar `~/Documents/Obsidian Vault/MEMORY.md` com o fato novo
   - Atualizar o log diário em `~/Documents/Obsidian Vault/memory/YYYY-MM-DD.md`

### Formato do board Kanban

O arquivo usa o plugin Kanban do Obsidian. Estrutura:

```markdown
---
kanban-plugin: basic
---

## Backlog
- [ ] tarefa aqui

## A Fazer (Sprint)
- [ ] tarefa aqui

## Fazendo
- [ ] tarefa aqui

## Em Review
- [ ] tarefa aqui

## Feito
- [x] tarefa aqui
```

Para mover uma tarefa entre colunas: cortar a linha de uma seção e colar na outra.

### Formato de tarefas (compatível com Tasks plugin)
- `- [ ] Tarefa 📅 2026-03-20` (com data)
- `- [ ] Tarefa ⏫ 📅 2026-03-20` (prioridade alta)
- `- [x] Tarefa ✅ 2026-03-20` (concluída)

### Página descritiva do projeto

**Arquivo:** `~/Documents/Obsidian Vault/Projetos/Arandu/Arandu - O Projeto.md`

Este documento é a **fonte da verdade** sobre o que é o Arandu — arquitetura, pipeline, modelo de dados, stack, próximos passos. O Claude Code DEVE atualizar este documento sempre que:
- Mudar a arquitetura ou pipeline
- Adicionar/remover funcionalidades significativas
- Bumpar versão (atualizar o campo de versão no topo do doc)
- Mudar stack ou dependências relevantes
- Resolver itens dos "Próximos passos"
