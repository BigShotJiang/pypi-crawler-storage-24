"""PO file backend — reads/writes .po files on disk using polib."""

import base64
import json
import logging
import pathlib
import typing as t

import django.utils.translation.reloader
import polib

from live_translations import conf, history
from live_translations.backends import base
from live_translations.types import LanguageCode, MsgKey, OverrideMap, PluralForms

__all__ = ["LT_PENDING_PREFIX", "POFileBackend"]

logger = logging.getLogger(__name__)

LT_PENDING_PREFIX = "ltpending:"


def _get_pending(entry: polib.POEntry) -> PluralForms | None:
    """Extract the pending PluralForms from the translator comment, or None."""
    if not entry.comment:
        return None
    lines = entry.comment.split("\n")
    for i, line in enumerate(lines):
        if line.startswith(LT_PENDING_PREFIX):
            raw = line[len(LT_PENDING_PREFIX) :]
            for cont in lines[i + 1 :]:
                raw += cont
            try:
                decoded = base64.b64decode(raw).decode()
            except (ValueError, UnicodeDecodeError):
                return {0: raw}
            # New format: JSON-encoded PluralForms dict
            try:
                parsed = json.loads(decoded)
                if isinstance(parsed, dict):
                    return {int(k): v for k, v in parsed.items()}
            except (json.JSONDecodeError, ValueError):
                pass
            # Legacy format: plain string (pre-plural migration)
            return {0: decoded}
    return None


def _set_pending(entry: polib.POEntry, forms: PluralForms) -> None:
    """Store pending PluralForms as JSON+base64 in the translator comment."""
    _clear_pending(entry)
    json_str = json.dumps({str(k): v for k, v in forms.items()}, separators=(",", ":"))
    encoded = base64.b64encode(json_str.encode()).decode()
    pending_line = f"{LT_PENDING_PREFIX}{encoded}"
    entry.comment = f"{entry.comment}\n{pending_line}" if entry.comment else pending_line


def _clear_pending(entry: polib.POEntry) -> None:
    """Remove the pending data (and any continuation lines) from the comment."""
    if not entry.comment:
        return
    lines = entry.comment.split("\n")
    for i, line in enumerate(lines):
        if line.startswith(LT_PENDING_PREFIX):
            entry.comment = "\n".join(lines[:i]).strip()
            return


def _clean_comment(comment: str) -> str:
    """Return the comment with pending data stripped."""
    lines = comment.split("\n")
    for i, line in enumerate(lines):
        if line.startswith(LT_PENDING_PREFIX):
            return "\n".join(lines[:i]).strip()
    return comment.strip()


def _read_msgstr_forms(entry: polib.POEntry) -> PluralForms:
    """Read PluralForms from a polib entry (handles both singular and plural)."""
    if entry.msgid_plural:
        return dict(entry.msgstr_plural)
    return {0: entry.msgstr}


class POFileBackend(base.TranslationBackend):
    """Default backend that reads/writes locale/*.po files."""

    def __init__(
        self,
        locale_dir: pathlib.Path,
        domain: str,
        cache_alias: str = "default",
    ) -> None:
        super().__init__(locale_dir, domain, cache_alias)
        # Mtime-based cache: {path: (mtime, POFile)}
        self._po_cache: dict[pathlib.Path, tuple[float, polib.POFile]] = {}

    def _po_path(self, language: str) -> pathlib.Path:
        return self.locale_dir / language / "LC_MESSAGES" / f"{self.domain}.po"

    def _mo_path(self, language: str) -> pathlib.Path:
        return self.locale_dir / language / "LC_MESSAGES" / f"{self.domain}.mo"

    def _load_po(self, language: str) -> polib.POFile:
        path = self._po_path(language)
        try:
            mtime = path.stat().st_mtime
        except OSError as err:
            raise FileNotFoundError(f"PO file not found: {path}") from err

        cached = self._po_cache.get(path)
        if cached is not None and cached[0] == mtime:
            return cached[1]

        po = polib.pofile(str(path))
        self._po_cache[path] = (mtime, po)
        return po

    def _ensure_po(self, language: LanguageCode) -> polib.POFile:
        """Load the PO file, creating it with a minimal header if it doesn't exist."""
        try:
            return self._load_po(language)
        except FileNotFoundError:
            path = self._po_path(language)
            path.parent.mkdir(parents=True, exist_ok=True)
            po = polib.POFile()
            po.metadata = {
                "Content-Type": "text/plain; charset=UTF-8",
                "Content-Transfer-Encoding": "8bit",
                "Language": language,
            }
            po.save(str(path))
            self._po_cache.pop(path, None)
            return self._load_po(language)

    def _find_entry(
        self,
        po: polib.POFile,
        key: MsgKey,
    ) -> polib.POEntry | None:
        return po.find(key.msgid, msgctxt=key.context or False)

    @t.override
    def get_translations(
        self,
        key: MsgKey,
        languages: list[LanguageCode],
    ) -> dict[LanguageCode, base.TranslationEntry]:
        result: dict[str, base.TranslationEntry] = {}
        for lang in languages:
            try:
                po = self._load_po(lang)
                entry = self._find_entry(po, key)
                if entry is None:
                    result[lang] = base.TranslationEntry(
                        language=lang,
                        msgid=key.msgid,
                        msgstr_forms={0: ""},
                        context=key.context,
                        msgid_plural=key.msgid_plural,
                    )
                    continue
                pending = _get_pending(entry)
                is_active = pending is None
                result[lang] = base.TranslationEntry(
                    language=lang,
                    msgid=key.msgid,
                    msgstr_forms=pending if pending is not None else _read_msgstr_forms(entry),
                    context=key.context,
                    msgid_plural=entry.msgid_plural or key.msgid_plural,
                    fuzzy="fuzzy" in entry.flags,
                    is_active=is_active,
                )
            except FileNotFoundError:
                logger.warning("PO file not found for language '%s'", lang)
                result[lang] = base.TranslationEntry(
                    language=lang,
                    msgid=key.msgid,
                    msgstr_forms={0: ""},
                    context=key.context,
                    msgid_plural=key.msgid_plural,
                )
        return result

    @t.override
    def get_inactive_overrides(self, language: LanguageCode) -> OverrideMap:
        overrides: OverrideMap = {}
        try:
            po = self._load_po(language)
        except FileNotFoundError:
            return overrides
        for entry in po:
            pending = _get_pending(entry)
            if pending:
                overrides[MsgKey(entry.msgid, entry.msgctxt or "", entry.msgid_plural or "")] = pending
        return overrides

    def _create_po_entry(self, key: MsgKey, forms: PluralForms, *, is_active: bool) -> polib.POEntry:
        """Create a new POEntry for a translation that doesn't exist yet."""
        new_entry = polib.POEntry(
            msgid=key.msgid,
            msgstr="" if not is_active else forms.get(0, ""),
            msgctxt=key.context or None,
        )
        if key.msgid_plural:
            new_entry.msgid_plural = key.msgid_plural
            new_entry.msgstr_plural = dict(forms) if is_active else dict.fromkeys(forms, "")
        if not is_active:
            _set_pending(new_entry, forms)
        return new_entry

    def _update_po_entry(self, entry: polib.POEntry, key: MsgKey, forms: PluralForms, *, is_active: bool) -> bool:
        """Update an existing POEntry. Returns the resolved is_active state."""
        if is_active:
            if key.msgid_plural:
                entry.msgstr_plural = dict(forms)
            else:
                entry.msgstr = forms.get(0, "")
            _clear_pending(entry)
        else:
            current_forms = _read_msgstr_forms(entry)
            if forms == current_forms:
                _clear_pending(entry)
                is_active = True
            else:
                _set_pending(entry, forms)
        if "fuzzy" in entry.flags:
            entry.flags.remove("fuzzy")
        return is_active

    @t.override
    def save_translations(
        self,
        key: MsgKey,
        translations: dict[LanguageCode, PluralForms],
        active_flags: dict[LanguageCode, bool] | None = None,
    ) -> None:
        fallback_active = conf.get_settings().translation_active_by_default

        mo_path: pathlib.Path | None = None
        old_entries: dict[str, PluralForms] = {}
        old_active_states: dict[str, bool] = {}
        new_active_states: dict[str, bool] = {}
        for lang, forms in translations.items():
            po = self._ensure_po(lang)
            entry = self._find_entry(po, key)

            is_active = active_flags.get(lang, fallback_active) if active_flags else fallback_active
            new_active_states[lang] = is_active

            if entry is not None:
                pending = _get_pending(entry)
                old_entries[lang] = pending if pending is not None else _read_msgstr_forms(entry)
                old_active_states[lang] = pending is None

            if entry is None:
                po.append(self._create_po_entry(key, forms, is_active=is_active))
            else:
                is_active = self._update_po_entry(entry, key, forms, is_active=is_active)
                new_active_states[lang] = is_active

            po.save()
            mo_path = self._mo_path(lang)
            po.save_as_mofile(str(mo_path))
            self._po_cache.pop(self._po_path(lang), None)

        history.record_text_changes(
            key=key,
            old_entries=old_entries,
            new_entries=translations,
        )
        history.record_active_changes(
            key=key,
            old_states=old_active_states,
            new_states=new_active_states,
        )

        if mo_path is not None:
            django.utils.translation.reloader.translation_file_changed(sender=None, file_path=pathlib.Path(mo_path))

    @t.override
    def bulk_activate(
        self,
        language: LanguageCode,
        msgids: list[MsgKey],
    ) -> list[MsgKey]:
        try:
            po = self._load_po(language)
        except FileNotFoundError:
            return []

        activated: list[MsgKey] = []
        for key in msgids:
            entry = self._find_entry(po, key)
            if entry is None:
                continue
            pending = _get_pending(entry)
            if pending is None:
                continue
            # Apply pending forms to the PO entry
            if key.msgid_plural or entry.msgid_plural:
                entry.msgstr_plural = dict(pending)
            else:
                entry.msgstr = pending.get(0, "")
            _clear_pending(entry)
            if "fuzzy" in entry.flags:
                entry.flags.remove("fuzzy")
            activated.append(key)

        if activated:
            po.save()
            mo_path = self._mo_path(language)
            po.save_as_mofile(str(mo_path))
            self._po_cache.pop(self._po_path(language), None)
            django.utils.translation.reloader.translation_file_changed(sender=None, file_path=pathlib.Path(mo_path))

        return activated

    @t.override
    def get_defaults(
        self,
        key: MsgKey,
        languages: list[LanguageCode],
    ) -> dict[LanguageCode, PluralForms]:
        result: dict[LanguageCode, PluralForms] = {}
        for lang in languages:
            try:
                po = self._load_po(lang)
                entry = self._find_entry(po, key)
                if entry:
                    result[lang] = _read_msgstr_forms(entry)
            except FileNotFoundError:
                pass
        return result

    @t.override
    def get_hint(self, key: MsgKey) -> str:
        return _clean_comment(super().get_hint(key))
