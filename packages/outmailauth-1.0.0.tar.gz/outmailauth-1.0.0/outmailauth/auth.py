import json
import base64
from flask import Flask, request, redirect
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
import firebase_admin
from firebase_admin import credentials, db

PORT = 4000
REDIRECT_URI = f"http://localhost:{PORT}/oauth2callback"

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send"
]

CLIENT_CONFIG = {
    "web": {
        "client_id": "YOUR_CLIENT_ID",
        "client_secret": "YOUR_CLIENT_SECRET",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "redirect_uris": [REDIRECT_URI]
    }
}

# Firebase initialization
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    "databaseURL": "https://utmail-17fba-default-rtdb.firebaseio.com/"
})

app = Flask(__name__)


def create_flow():
    return Flow.from_client_config(
        CLIENT_CONFIG,
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI
    )


def check_api_key(key):
    try:
        ref = db.reference(key)
        data = ref.get()
        if data is None:
            return False
        return True
    except:
        return False


@app.route("/")
def home():
    return """
    <h2>0utmail Authentication</h2>
    <form action="/auth">
        <input name="key" placeholder="Enter API Key" required>
        <button>Continue with Google</button>
    </form>
    """


@app.route("/auth")
def auth():
    key = request.args.get("key")

    if not key:
        return redirect("/")

    if not check_api_key(key):
        return "<h2>Invalid API key</h2>"

    flow = create_flow()

    state = base64.b64encode(json.dumps({"key": key}).encode()).decode()

    auth_url, _ = flow.authorization_url(
        access_type="offline",
        prompt="consent",
        state=state
    )

    return redirect(auth_url)


@app.route("/oauth2callback")
def callback():

    flow = create_flow()

    flow.fetch_token(authorization_response=request.url)

    creds = flow.credentials

    tokens = {
        "token": creds.token,
        "refresh_token": creds.refresh_token,
        "token_uri": creds.token_uri,
        "client_id": creds.client_id
    }

    gmail = build("gmail", "v1", credentials=creds)
    profile = gmail.users().getProfile(userId="me").execute()

    email = profile["emailAddress"]

    state = request.args.get("state")

    api_key = None
    if state:
        try:
            api_key = json.loads(base64.b64decode(state).decode())["key"]
        except:
            pass

    if api_key:
        ref = db.reference(f"{api_key}/emails")
        ref.push({
            "email": email
        })

    return f"""
    <h2>Credentials Generated</h2>

    <h3>api-key.json</h3>
    <pre>{json.dumps({'key': api_key}, indent=2)}</pre>

    <h3>token.json</h3>
    <pre>{json.dumps(tokens, indent=2)}</pre>
    """


if __name__ == "__main__":
    print(f"Server running on http://localhost:{PORT}")
    app.run(port=PORT)
    def main():
    print(f"Server running on http://localhost:{PORT}")
    app.run(port=PORT)

if __name__ == "__main__":
    main()
