# 0utmailauth

A CLI tool to generate Gmail OAuth credentials for 0utmail.

## Usage

You can run this tool directly without installing it globally:

```bash
pipx run 0utmailauth
