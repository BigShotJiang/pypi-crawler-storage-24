from __future__ import annotations

import re
from typing import TYPE_CHECKING, Final, TypeAlias

__all__ = [
    "refine_stock_id",
    "set_universe",
    "set_us_universe",
    "universe",
    "us_universe",
]

if TYPE_CHECKING:
    from collections.abc import Callable
    from types import TracebackType
    from typing import Self

import pandas as pd

# Type alias for parameters accepting a single string or list of strings.
StrOrStrList: TypeAlias = str | list[str]

# Shared universe state used to filter datasets
universe_stocks: set[str] = set()


def _match_categories_by_regex(
    all_values: set[str], patterns: StrOrStrList
) -> set[str]:
    """Match values from a set using regex patterns.

    Args:
        all_values: Set of all possible values to match against
        patterns: Single pattern or list of patterns for regex matching

    Returns:
        Set of matched values
    """
    if isinstance(patterns, str):
        patterns = [patterns]
    matched: set[str] = set()
    for pattern in patterns:
        matched |= {
            v for v in all_values if isinstance(v, str) and re.search(pattern, v)
        }
    return matched


def _resolve_sector_alias(
    new_val: StrOrStrList | None, legacy_val: StrOrStrList | None
) -> StrOrStrList | None:
    """Pick *sector* (new) or *category* (legacy). Raise if both are given."""
    if legacy_val is not None and new_val is not None and new_val != "ALL":
        raise ValueError(
            "Cannot specify both 'sector' and 'category'. Use 'sector' only."
        )
    if legacy_val is not None:
        return legacy_val
    return new_val


# ---------------------------------------------------------------------------
# Constants & helpers for TW legacy market → (exchange, asset_type) mapping
# ---------------------------------------------------------------------------

_TW_LEGACY_MARKET_VALUES: Final[frozenset[str]] = frozenset(
    {
        "ALL",
        "TSE",
        "OTC",
        "TSE_OTC",
        "ETF",
        "STOCK_FUTURE",
    }
)

_TW_MARKET_TO_EXCHANGE_ASSET: Final[dict[str, tuple[list[str] | None, str | None]]] = {
    "ALL": (None, None),
    "TSE": (["TWSE"], None),
    "OTC": (["TPEX"], None),
    "TSE_OTC": (["TWSE", "TPEX"], None),
    "ETF": (None, "ETF"),
    "STOCK_FUTURE": (None, "STOCK_FUTURE"),
}

_TW_EXCHANGE_TO_DB: Final[dict[str, str]] = {
    "TWSE": "sii",
    "TSE": "sii",
    "TPEX": "otc",
    "OTC": "otc",
}


def _resolve_legacy_market_param(
    val: str | None,
) -> tuple[list[str] | None, str | None]:
    """Convert old ``market`` string to ``(exchange, asset_type)`` tuple.

    Returns (exchange_list_or_ALL, asset_type_or_None).
    """
    if val is None:
        return (None, None)
    val_upper = val.upper().replace(" ", "")
    if "TSE" in val_upper and "OTC" in val_upper:
        val_upper = "TSE_OTC"
    if val_upper in _TW_MARKET_TO_EXCHANGE_ASSET:
        return _TW_MARKET_TO_EXCHANGE_ASSET[val_upper]
    raise ValueError(
        f"Invalid legacy market value: {val!r}. "
        f"Must be one of {sorted(_TW_LEGACY_MARKET_VALUES)}"
    )


def _is_legacy_tw_market_value(val: object) -> bool:
    """Check whether *val* looks like a legacy TW ``market`` parameter value."""
    if not isinstance(val, str):
        return False
    upper = val.upper().replace(" ", "")
    if "TSE" in upper and "OTC" in upper:
        return True
    return upper in _TW_LEGACY_MARKET_VALUES


# ---------------------------------------------------------------------------
# TW universe implementation
# ---------------------------------------------------------------------------


def _set_tw_universe_impl(
    exchange: StrOrStrList = "ALL",
    sector: StrOrStrList = "ALL",
    exclude_sector: StrOrStrList | None = None,
    asset_type: str | None = None,
) -> None:
    """Set global TW stock universe filter (internal implementation)."""
    from finlab.compat import resolve_id_column

    from . import data as data_module

    _cats = data_module.get("security_categories").reset_index()
    categories = _cats.set_index(resolve_id_column(_cats))

    # --- exchange / asset_type filter ---
    market_match = pd.Series(True, categories.index)

    if asset_type is not None:
        asset_upper = asset_type.upper()
        if asset_upper == "ETF":
            market_match = categories.market == "etf"
        elif asset_upper == "STOCK_FUTURE":

            def _get_sf_ids(df: pd.DataFrame) -> set[str]:
                col = (
                    resolve_id_column(df)
                    if resolve_id_column(df) in df.columns
                    else "stock_id"
                )
                return set(df[col])

            market_match = (
                data_module.get("single_stock_futures_and_equity_options_underlying")
                .pipe(lambda df: df[df["是否為股票期貨標的"] == "Y"])
                .pipe(
                    lambda df: (
                        pd.Series(True, _get_sf_ids(df))
                        .reindex(categories.index)
                        .fillna(False)
                    )
                )
            )
    elif exchange != "ALL":
        if isinstance(exchange, str):
            exchange = [exchange]
        db_values = [_TW_EXCHANGE_TO_DB.get(e.upper(), e.lower()) for e in exchange]
        market_match = categories.market.isin(db_values)

    # --- sector filter ---
    sector_match = pd.Series(True, categories.index)
    if sector != "ALL":
        all_sectors = set(categories.category)
        matched_sectors = _match_categories_by_regex(all_sectors, sector)
        sector_match = categories.category.isin(list(matched_sectors))

    # --- exclude_sector filter ---
    exclude_match = pd.Series(True, categories.index)
    if exclude_sector is not None:
        all_sectors = set(categories.category)
        matched_excluded = _match_categories_by_regex(all_sectors, exclude_sector)
        exclude_by_sector = ~categories.category.isin(list(matched_excluded))
        exclude_by_market = pd.Series(True, categories.index)
        exclude_list = (
            [exclude_sector] if isinstance(exclude_sector, str) else exclude_sector
        )
        if any(
            isinstance(ca, str) and ca.strip().lower() == "etf" for ca in exclude_list
        ):
            exclude_by_market = categories.market != "etf"
        exclude_match = exclude_by_sector & exclude_by_market

    global universe_stocks
    universe_stocks = set(categories.index[market_match & sector_match & exclude_match])


# ---------------------------------------------------------------------------
# International (non-TW) universe implementation
# ---------------------------------------------------------------------------


def _set_intl_universe_impl(
    market_code: str,
    exchange: StrOrStrList = "ALL",
    sector: StrOrStrList = "ALL",
    industry: StrOrStrList = "ALL",
) -> None:
    """Set global universe filter for a non-TW market (internal implementation).

    Loads ``{market_code}_company_profile`` and filters by available columns.
    Columns that do not exist in the dataset are silently skipped.
    """
    from finlab.compat import resolve_id_column

    from . import data as data_module

    dataset_name = f"{market_code}_company_profile"
    profile = data_module.get(dataset_name)

    # Determine the index column (symbol / stock_id)
    id_col = resolve_id_column(profile)
    if id_col in profile.columns:
        profile = profile.set_index(id_col)
    elif "symbol" in profile.columns:
        profile = profile.set_index("symbol")

    def match_column(column: str, patterns: StrOrStrList) -> pd.Series:
        if patterns == "ALL" or column not in profile.columns:
            return pd.Series(True, profile.index)
        all_values = set(profile[column].dropna())
        matched = _match_categories_by_regex(all_values, patterns)
        return profile[column].isin(list(matched))

    sector_match = match_column("sector", sector)
    industry_match = match_column("industry", industry)

    exchange_match = pd.Series(True, profile.index)
    if exchange != "ALL" and "exchange" in profile.columns:
        if isinstance(exchange, str):
            exchange = [exchange]
        exchange_match = profile.exchange.isin(exchange)

    global universe_stocks
    universe_stocks = set(profile.index[sector_match & industry_match & exchange_match])


# ---------------------------------------------------------------------------
# Unified set_universe — dispatcher
# ---------------------------------------------------------------------------


def set_universe(
    exchange: StrOrStrList = "ALL",
    sector: StrOrStrList = "ALL",
    exclude_sector: StrOrStrList | None = None,
    industry: StrOrStrList = "ALL",
    asset_type: str | None = None,
    *,
    # Legacy aliases (keyword-only)
    market: str | None = None,
    category: StrOrStrList | None = None,
    exclude_category: StrOrStrList | None = None,
) -> None:
    """Set global stock universe filter. Auto-dispatches based on current market.

    When ``data.set_market('tw')`` (or no market set), uses TW logic
    (``security_categories``). For any other market (us, hk, jp, kr, uk),
    loads ``{market}_company_profile`` and filters by available columns.

    Parameters
    ----------
    exchange : str | list[str], default 'ALL'
        TW: 'TWSE', 'TPEx' (or legacy 'TSE', 'OTC').
        International: 'NASDAQ', 'NYSE', 'AMEX', 'HKEX', 'TSE', etc.
    sector : str | list[str], default 'ALL'
        Sector name(s) with regex matching.
    exclude_sector : str | list[str] | None, default None
        Sector(s) to exclude (TW only).
    industry : str | list[str], default 'ALL'
        Industry filter (international markets).
    asset_type : str | None, default None
        TW only: 'ETF' or 'STOCK_FUTURE'.
    market : str | None
        **Legacy alias** for TW exchange+asset_type (e.g. 'TSE_OTC', 'ETF').
    category : str | list[str] | None
        **Legacy alias** for ``sector``.
    exclude_category : str | list[str] | None
        **Legacy alias** for ``exclude_sector``.
    """
    # --- resolve legacy aliases ---
    sector = _resolve_sector_alias(sector, category)
    exclude_sector = _resolve_sector_alias(exclude_sector, exclude_category)

    # Detect legacy market kwarg → exchange + asset_type
    if market is not None:
        leg_exchange, leg_asset = _resolve_legacy_market_param(market)
        if leg_exchange is not None:
            exchange = leg_exchange
        if leg_asset is not None:
            asset_type = leg_asset

    # Detect legacy value passed positionally as exchange (e.g. set_universe('TSE_OTC'))
    if (
        isinstance(exchange, str)
        and _is_legacy_tw_market_value(exchange)
        and exchange != "ALL"
    ):
        leg_exchange, leg_asset = _resolve_legacy_market_param(exchange)
        exchange = leg_exchange if leg_exchange is not None else "ALL"
        if leg_asset is not None:
            asset_type = leg_asset

    # --- dispatch based on current market ---
    from . import data as data_module

    current = data_module._current_market

    if current is None or current == "tw":
        _set_tw_universe_impl(
            exchange=exchange,
            sector=sector,
            exclude_sector=exclude_sector,
            asset_type=asset_type,
        )
    else:
        # All non-TW markets (us, hk, jp, kr, uk, ...)
        _set_intl_universe_impl(
            market_code=current,
            exchange=exchange,
            sector=sector,
            industry=industry,
        )


# ---------------------------------------------------------------------------
# Unified universe context manager
# ---------------------------------------------------------------------------


class universe:
    """Context manager to set a global stock universe filter for data retrieval.

    Auto-dispatches TW vs international logic based on ``data._current_market``.

    Parameters
    ----------
    exchange : str | list[str], default 'ALL'
        TW: 'TWSE'/'TPEx' (or legacy 'TSE'/'OTC').
        International: 'NASDAQ'/'NYSE'/'AMEX'/'HKEX'/'TSE'/etc.
    sector : str | list[str], default 'ALL'
        Sector name(s) with regex matching.
    exclude_sector : str | list[str] | None, default None
        Sector(s) to exclude (TW only).
    industry : str | list[str], default 'ALL'
        Industry filter (international markets).
    asset_type : str | None, default None
        TW only: 'ETF' or 'STOCK_FUTURE'.
    market : str | None
        **Legacy alias** for TW exchange+asset_type.
    category : str | list[str] | None
        **Legacy alias** for ``sector``.
    exclude_category : str | list[str] | None
        **Legacy alias** for ``exclude_sector``.

    Examples
    --------
    TW market (default):

    >>> from finlab import data
    >>> with data.universe(exchange=['TWSE', 'TPEx'], sector=['鋼鐵工業', '航運業']):
    ...     close = data.get('price:收盤價')

    Legacy TW usage (still works):

    >>> with data.universe(market='TSE_OTC', sector='水泥', exclude_sector='ETF'):
    ...     close = data.get('price:收盤價')

    US market:

    >>> data.set_market('us')
    >>> with data.universe(exchange='NASDAQ', sector='Technology'):
    ...     close = data.get('price:close')

    JP market:

    >>> data.set_market('jp')
    >>> with data.universe(sector='Technology'):
    ...     close = data.get('price:close')
    """

    def __init__(
        self,
        exchange: StrOrStrList = "ALL",
        sector: StrOrStrList = "ALL",
        exclude_sector: StrOrStrList | None = None,
        industry: StrOrStrList = "ALL",
        asset_type: str | None = None,
        *,
        # Legacy aliases (keyword-only)
        market: str | None = None,
        category: StrOrStrList | None = None,
        exclude_category: StrOrStrList | None = None,
    ) -> None:
        self._exchange: StrOrStrList = exchange
        self._sector: StrOrStrList | None = _resolve_sector_alias(sector, category)
        self._exclude_sector: StrOrStrList | None = _resolve_sector_alias(
            exclude_sector, exclude_category
        )
        self._industry: StrOrStrList = industry
        self._asset_type: str | None = asset_type
        self._market_legacy: str | None = market
        self._previous_stocks: set[str] = set()

    def __enter__(self) -> Self:
        global universe_stocks
        self._previous_stocks = universe_stocks
        set_universe(
            exchange=self._exchange,
            sector=self._sector,
            exclude_sector=self._exclude_sector,
            industry=self._industry,
            asset_type=self._asset_type,
            market=self._market_legacy,
        )
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        global universe_stocks
        universe_stocks = self._previous_stocks


# ---------------------------------------------------------------------------
# us_universe / set_us_universe — thin backward-compat wrappers
# ---------------------------------------------------------------------------


class us_universe:
    """Context manager to set a global stock universe filter for US market data retrieval.

    This context manager limits the set of US stocks returned by data functions to a specific
    sector, industry, and exchange selection. The filter is applied globally
    within the context and is restored after the context exits.

    Parameters
    ----------
    sector : str | list[str], default 'ALL'
        Sector name(s) to include. Supports regex-like substring matching.
    industry : str | list[str], default 'ALL'
        Industry name(s) to include. Supports regex-like substring matching.
    exchange : str | list[str], default 'ALL'
        Exchange name(s) to include. Common values: 'NASDAQ', 'NYSE', 'AMEX'.

    Examples
    --------
    >>> from finlab import data
    >>> with data.us_universe(sector='Technology', exchange='NASDAQ'):
    ...     close = data.get('us_price:close')
    """

    def __init__(
        self,
        sector: StrOrStrList = "ALL",
        industry: StrOrStrList = "ALL",
        exchange: StrOrStrList = "ALL",
    ) -> None:
        self._sector: StrOrStrList = sector
        self._industry: StrOrStrList = industry
        self._exchange: StrOrStrList = exchange
        self._previous_stocks: set[str] = set()

    def __enter__(self) -> Self:
        global universe_stocks
        self._previous_stocks = universe_stocks
        _set_intl_universe_impl(
            market_code="us",
            exchange=self._exchange,
            sector=self._sector,
            industry=self._industry,
        )
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        global universe_stocks
        universe_stocks = self._previous_stocks


def set_us_universe(
    sector: StrOrStrList = "ALL",
    industry: StrOrStrList = "ALL",
    exchange: StrOrStrList = "ALL",
) -> None:
    """Set global US stock universe filter.

    Thin wrapper around ``_set_intl_universe_impl`` for backward compatibility.

    Parameters
    ----------
    sector : str | list[str], default 'ALL'
        Sector filter with regex-like substring matching.
    industry : str | list[str], default 'ALL'
        Industry filter with regex-like substring matching.
    exchange : str | list[str], default 'ALL'
        Exchange filter (e.g., 'NASDAQ', 'NYSE', 'AMEX').
    """
    _set_intl_universe_impl(
        market_code="us",
        exchange=exchange,
        sector=sector,
        industry=industry,
    )


# ---------------------------------------------------------------------------
# Dataset filtering (unchanged)
# ---------------------------------------------------------------------------

not_available_universe_stocks: list[str] = [
    "benchmark_return",
    "institutional_investors_trading_all_market_summary",
    "margin_balance",
    "intraday_trading_stat",
    "stock_index_price",
    "stock_index_vol",
    "taiex_total_index",
    "broker_info",
    "rotc_monthly_revenue",
    "rotc_price",
    "world_index",
    "rotc_broker_trade_record",
    "security_categories",
    "finlab_tw_stock_market_ind",
    "tw_industry_pmi",
    "tw_industry_nmi",
    "tw_total_pmi",
    "tw_total_nmi",
    "tw_business_indicators",
    "tw_business_indicators_details",
    "tw_monetary_aggregates",
    "us_unemployment_rate_seasonally_adjusted",
    "us_company_profile",
    "hk_company_profile",
    "jp_company_profile",
    "kr_company_profile",
    "uk_company_profile",
]


def refine_stock_id(dataset: str, ret: pd.DataFrame) -> pd.DataFrame:
    from finlab.compat import resolve_id_column

    from .data import process_data  # lazy import to avoid circular dependency

    ret = process_data(dataset, ret)

    if dataset in not_available_universe_stocks:
        return ret

    if not universe_stocks:
        return ret

    if ":" in dataset:
        subset_stocks = [c for c in ret.columns if c in universe_stocks]
        if subset_stocks:
            return ret.loc[:, subset_stocks]

    id_col = resolve_id_column(ret)
    if id_col in ret.columns:
        subset_stocks = ret[id_col].isin(list(universe_stocks))
        if bool(subset_stocks.any()):
            return ret.loc[subset_stocks]

    return ret


refine_symbols: Callable[[str, pd.DataFrame], pd.DataFrame] = refine_stock_id
