from __future__ import annotations

import contextlib
import datetime
import gc
import hashlib
import json
import logging
import sys
import time
from functools import lru_cache, reduce
from io import BytesIO

__all__ = [
    "clear",
    "get",
    "indicator",
    "is_tradable",
    "market",
    "search",
    "set_market",
    "set_storage",
]
from typing import TYPE_CHECKING, Any, Final

if TYPE_CHECKING:
    import types
    from typing import Protocol, Self

    from finlab.market import Market

    class _TalibAbstract(Protocol):
        input_names: dict[str, str | list[str]]


import numpy as np
import pandas as pd

import finlab.dataframe
import finlab.utils
from finlab import config

from .storage import CacheStorage, FileStorage
from .universe import (
    refine_stock_id,
)

logger = logging.getLogger(__name__)

_has_print_free_user_warning: bool = False
_has_shown_quota_warning: bool = False
_role: dict[str, Any] | None = None
use_local_data_only: bool = False
force_cloud_download: bool = False
truncate_start: str | None = None
truncate_end: str | None = None
prefer_local_if_exists: bool = False

_storage: FileStorage = FileStorage()

# Cache for finalized DataFrames, keyed by (dataset, id(raw_df)).
# When the raw df object is the same (returned from FileStorage._cache),
# we can skip expensive process_data transformations.
_finalized_cache: dict[tuple[str, int], pd.DataFrame] = {}

# Tracks which datasets were loaded via get() in this session.
# Used by _get_expiry_dict() to filter out unrelated cached data.
_loaded_datasets: set[str] = set()


def clear() -> None:
    """清除本地端儲存的歷史資料，並還原初始設定。
    Examples:
        ``` py
        from finlab import data
        data.clear()
        ```
    """
    global _storage, _loaded_datasets
    _loaded_datasets = set()
    if isinstance(_storage, FileStorage):
        _storage.clear()
    _storage = FileStorage()


def set_storage(storage: CacheStorage | FileStorage) -> None:
    """設定本地端儲存歷史資料的方式
    假設使用 `data.get` 獲取歷史資料則，在預設情況下，程式會自動在本地複製一份，以避免重複下載大量數據。
    storage 就是用來儲存歷史資料的接口。我們提供兩種 `storage` 接口，分別是 `finlab.data.CacheStorage` (預設) 以及
    `finlab.data.FileStorage`。前者是直接存在記憶體中，後者是存在檔案中。詳情請參考 `CacheStorage` 和 `FileStorage` 來獲得更詳細的資訊。
    在預設情況下，程式會自動使用 `finlab.data.FileStorage` 並將重複索取之歷史資料存在作業系統預設「暫時資料夾」。

    Args:
        storage (data.Storage): The interface of storage

    Examples:
        欲切換成以檔案方式儲存，可以用以下之方式：

        ``` py
        from finlab import data
        data.set_storage(data.FileStorage())
        close = data.get('price:收盤價')
        ```

        可以在本地端的 `./finlab_db/price#收盤價.pickle` 中，看到下載的資料，
        可以使用 `pickle` 調閱歷史資料：
        ``` py
        import pickle
        close = pickle.load(open('finlab_db/price#收盤價.pickle', 'rb'))
        ```
    """

    global _storage
    _storage = storage


_DEFAULT_HEADERS: Final[dict[str, str]] = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
}

_AUTH_ERRORS: Final[list[str]] = [
    "request not valid",
    "User not found",
    "api_token not valid",
    "api_token not match",
]

# Track last token type for retry logic
_last_token_type: str | None = None


_DATASET_PREFIX_TO_BUCKET: Final[dict[str, str]] = {
    "us_": "finlab_us_stock_item",
    "hk_": "fdata-hk-stock-item",
    "jp_": "fdata-jp-stock-item",
    "kr_": "fdata-kr-stock-item",
    "uk_": "fdata-uk-stock-item",
}

_current_market: str | None = None

_KNOWN_MARKET_PREFIXES: Final[frozenset[str]] = frozenset(
    prefix.rstrip("_") for prefix in _DATASET_PREFIX_TO_BUCKET
)

_VALID_MARKETS: Final[frozenset[str]] = frozenset(("tw", *_KNOWN_MARKET_PREFIXES))


def _sync_config_market(market_code: str) -> None:
    """Sync finlab.config market with the given market code."""
    from finlab import config
    from finlab.markets import MARKET_CODE_TO_CLASS

    cls = MARKET_CODE_TO_CLASS.get(market_code)
    if cls is not None:
        config.set_market(cls)


class market:
    """Context manager to set a market prefix for dataset resolution and backtesting.

    Within the context, calls to ``data.get('price:close')`` will automatically
    resolve to ``us_price:close`` (or ``hk_price:close``, etc.) based on the
    market code, without requiring the user to type the prefix every time.
    Also sets ``finlab.config`` market so that ``backtest.sim()`` uses the
    correct market calendar and pricing.

    Parameters
    ----------
    market_code : str
        Market code to set. Supported values: 'tw', 'us', 'hk', 'jp', 'kr', 'uk'.

    Examples
    --------
    >>> from finlab import data
    >>> with data.market('us'):
    ...     close = data.get('price:close')   # resolves to us_price:close
    ...     report = backtest.sim(position)    # uses US calendar
    """

    def __init__(self, market_code: str) -> None:
        market_code = market_code.lower()
        if market_code not in _VALID_MARKETS:
            raise ValueError(
                f"Invalid market: {market_code!r}. "
                f"Must be one of {sorted(_VALID_MARKETS)}"
            )
        self._market_code: str = market_code
        self._previous_market: str | None = None
        self._previous_config_market: Market | None = None

    def __enter__(self) -> Self:
        global _current_market
        from finlab import config

        self._previous_market = _current_market
        self._previous_config_market = config.get_market()
        _current_market = self._market_code
        _sync_config_market(self._market_code)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        value: BaseException | None,
        traceback: types.TracebackType | None,
    ) -> None:
        global _current_market
        from finlab import config

        _current_market = self._previous_market
        config.set_market(self._previous_config_market)


def set_market(market_code: str) -> None:
    """Set the global market context for dataset resolution and backtesting.

    After calling ``set_market('us')``, calls to ``data.get('price:close')``
    will automatically resolve to ``us_price:close``, and ``backtest.sim()``
    will use the US market calendar and pricing.

    Call ``set_market('tw')`` to reset to the default (Taiwan) market.

    Parameters
    ----------
    market_code : str
        Market code to set. Supported values: 'tw', 'us', 'hk', 'jp', 'kr', 'uk'.

    Examples
    --------
    >>> from finlab import data
    >>> data.set_market('us')
    >>> close = data.get('price:close')   # resolves to us_price:close
    >>> report = backtest.sim(position)    # uses US calendar
    >>> data.set_market('tw')             # reset to default
    """
    global _current_market
    market_code = market_code.lower()
    if market_code not in _VALID_MARKETS:
        raise ValueError(
            f"Invalid market: {market_code!r}. Must be one of {sorted(_VALID_MARKETS)}"
        )
    _current_market = market_code
    _sync_config_market(market_code)


def _resolve_dataset(dataset: str) -> str:
    """Prepend market prefix to dataset name based on current market context.

    Returns the dataset unchanged when:
    - No market is set (or market is 'tw')
    - The dataset already has a known market prefix
    - The prefixed version does not exist in the Firestore catalog
      (e.g. ``world_index`` is global and should never be prefixed)
    """
    if _current_market is None or _current_market == "tw":
        return dataset

    table = dataset.split(":", maxsplit=1)[0] if ":" in dataset else dataset
    if any(table.startswith(p) for p in _DATASET_PREFIX_TO_BUCKET):
        return dataset

    # Only prefix if the prefixed name actually exists in the catalog
    prefixed = f"{_current_market}_{dataset}"
    doc_id = _MARKET_TO_FIRESTORE_DOC.get(_current_market)
    if doc_id is not None:
        catalog = _fetch_data_catalog_from_firestore(doc_id)
        if prefixed in catalog:
            return prefixed
    return dataset


def _get_bucket_for_dataset(dataset: str) -> str:
    """Return the GCS bucket name for a dataset based on its table prefix."""
    table = dataset.split(":", maxsplit=1)[0] if ":" in dataset else dataset
    for prefix, bucket in _DATASET_PREFIX_TO_BUCKET.items():
        if table.startswith(prefix):
            return bucket
    # ETL datasets: check the name after "etl:" for region prefix
    if table == "etl" and ":" in dataset:
        etl_name = dataset.split(":", maxsplit=2)[1]
        for prefix, bucket in _DATASET_PREFIX_TO_BUCKET.items():
            if etl_name.startswith(prefix):
                return bucket
    return "finlab_tw_stock_item"


def _build_fetch_params(dataset: str, time_saved: str | None = None) -> dict[str, str]:
    """Build request parameters for data fetch."""
    global _last_token_type
    token_result = finlab.get_token()

    # Handle both old (str) and new (tuple) return types
    if isinstance(token_result, tuple):
        token, token_type = token_result
    else:
        token = token_result
        token_type = "api_token"

    _last_token_type = token_type

    params = {
        "bucket_name": _get_bucket_for_dataset(dataset),
        "blob_name": dataset.replace(":", "#")
        + (".pickle" if "pyodide" in sys.modules else ".feather"),
    }

    if token_type == "id_token":
        params["id_token"] = token
        try:
            from finlab.auth import get_session

            session = get_session()
            if session and session.get("session_id"):
                params["session_id"] = session["session_id"]
        except Exception:
            pass
    else:
        params["api_token"] = token

    if time_saved:
        params["time_saved"] = time_saved.strftime("%Y%m%d%H%M%S")
    return params


def _handle_fetch_error(
    ret: dict[str, Any], dataset: str, time_saved: pd.Timestamp | None
) -> dict[str, Any] | None:
    """Handle error responses from fetch API. Returns None to continue, raises on fatal errors."""
    error = ret.get("error")

    # Token expired: try refreshing id_token and retry once
    if error == "token_expired" and _last_token_type == "id_token":
        try:
            from finlab.auth import get_session, invalidate_token_cache, save_session

            invalidate_token_cache()
            session = get_session()
            if session:
                # Clear cached id_token to force refresh
                session.pop("id_token", None)
                session.pop("id_token_expiry", None)
                save_session(session)
            return fetch_data(dataset, time_saved)
        except Exception as e:
            # Refresh retry failed — raise instead of falling through to login()
            raise RuntimeError(
                "Token expired and refresh failed. "
                "Run `python -m finlab login` to re-authenticate."
            ) from e

    if error in _AUTH_ERRORS:
        finlab.login()
        return fetch_data(dataset, time_saved)

    if error == "Usage exceed 500 MB/day. Please consider upgrade to VIP program.":
        raise RuntimeError(f"**Error: {error}")

    if error == "Usage exceed 5000 MB/day. Please consider upgrade to VIP program.":
        raise RuntimeError(
            "**Error: Usage exceed 5000 MB/day. Please consider reaching out to us at https://discord.gg/tAr4ysPqvR to reset your usage."
        )

    return None


def _download_dataframe(url: str, headers: dict[str, str]) -> pd.DataFrame:
    """Download DataFrame from URL, handling pyodide environment."""
    if "pyodide" in sys.modules:
        if hasattr(finlab.utils.requests, "getBytes"):
            res = finlab.utils.requests.getBytes(url)
            return pd.read_pickle(BytesIO(res), compression="gzip")
        res = finlab.utils.requests.get(url, timeout=300)
        return pd.read_pickle(BytesIO(res.content), compression="gzip")
    res = finlab.utils.requests.get(url, headers=headers, timeout=300)
    return pd.read_feather(BytesIO(res.content))


def fetch_data(
    dataset: str, time_saved: datetime.datetime | None = None
) -> dict[str, Any] | None:
    """
    Fetches data from a specified dataset.

    Args:
        dataset (str): The name of the dataset to fetch.
        time_saved (datetime, optional): The time to fetch the data from. Defaults to None.

    Returns:
        dict: A dictionary containing the fetched data and other information.
    """
    url = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_generate_data_url"
    params = _build_fetch_params(dataset, time_saved)

    try:
        res = finlab.utils.requests.post(
            url, params, headers=_DEFAULT_HEADERS, timeout=300
        )
    except Exception:
        time.sleep(3)
        res = finlab.utils.requests.post(
            url, params, headers=_DEFAULT_HEADERS, timeout=300
        )

    ret = res.json()

    if "error" in ret:
        return _handle_fetch_error(ret, dataset, time_saved)

    # Print free user warning
    global _role, _has_print_free_user_warning
    _role = ret.get("role")
    if not _has_print_free_user_warning and _role in ret and _role == "free":
        print(
            "Due to your status as a free user, the most recent data has been shortened or limited."
        )
        _has_print_free_user_warning = True

    if "quota" in ret and ".recent" not in dataset:
        print(f'Daily usage: {ret["quota"]:.1f} / {ret["limit_size"]} MB - {dataset}')

        global _has_shown_quota_warning
        limit_size = ret.get("limit_size", 0)
        if (
            not _has_shown_quota_warning
            and _role == "free"
            and limit_size > 0
            and ret["quota"] / limit_size >= 0.8
        ):
            quota_val = ret["quota"]
            print(
                f"\n⚠️ 今日用量已達 80%（{quota_val:.0f}/{limit_size} MB）\n"
                f"繼續使用可能會中斷，升級 VIP 可享 10 倍額度\n"
                f"👉 https://www.finlab.finance/payment\n"
            )
            _has_shown_quota_warning = True

    ret["expiry"] = (
        datetime.datetime.strptime(ret["time_scheduled"], "%Y%m%d%H%M%S").replace(
            tzinfo=datetime.timezone.utc
        )
        if "time_scheduled" in ret
        else None
    )

    # Download data if server returned a URL
    if ret.get("url"):
        ret["data"] = _download_dataframe(ret["url"], _DEFAULT_HEADERS)

    return ret


def has_index_name(df: pd.DataFrame, name: str) -> bool:
    """Check if the DataFrame has a specific index name (single or MultiIndex)."""
    if df.index.name == name:
        return True
    return bool(isinstance(df.index, pd.MultiIndex) and name in df.index.names)


# Table index transformations for special data types
TABLE_INDEX_TRANSFORMERS: Final[dict[str, Any]] = {
    "monthly_revenue": lambda df: df._index_to_business_day(),
    "rotc_monthly_revenue": lambda df: df._index_to_business_day(),
    "financial_statement": lambda df: df._index_date_to_str_season(),
    "fundamental_features": lambda df: df._index_date_to_str_season(),
    "us_fundamental": lambda df: df._index_date_to_str_season("-US"),
    "us_fundamental_ART": lambda df: df._index_date_to_str_season("-US"),
    "us_fundamental_all": lambda df: df._index_date_to_str_season("-US-ALL"),
    "us_fundamental_all_ART": lambda df: df._index_date_to_str_season("-US-ALL"),
    **{
        f"{r}_{t}": lambda df, postfix=f"-{r.upper()}": df._index_date_to_str_season(  # noqa: B008
            postfix
        )
        for r in ("us", "jp", "hk", "kr", "uk")
        for t in ("income_statement", "balance_sheet", "cash_flow")
    },
}

_TW_QUARTERLY_TABLES: Final[frozenset[str]] = frozenset(
    {"financial_statement", "fundamental_features"}
)


def _should_mask_quarterly(table_name: str, effective_truncate_end: str | None) -> bool:
    """Check if TW quarterly disclosure-date masking should be applied."""
    return table_name in _TW_QUARTERLY_TABLES and effective_truncate_end is not None


def _set_dataframe_index(df: pd.DataFrame) -> pd.DataFrame:
    """Set appropriate index based on available columns."""
    from finlab.compat import CANONICAL_NAME, LEGACY_NAME, validate_no_dual_columns

    # Accept either 'symbol' or 'stock_id'
    id_col = next((c for c in (CANONICAL_NAME, LEGACY_NAME) if c in df.columns), None)

    if id_col is not None and "date" in df.columns:
        df.set_index([id_col, "date"], inplace=True)
    elif "date" in df.columns:
        df.set_index("date", inplace=True)
    elif id_col is not None:
        df.set_index(id_col, inplace=True)

    # Normalize index name from 'stock_id' → 'symbol'
    if isinstance(df.index, pd.MultiIndex):
        new_names = [CANONICAL_NAME if n == LEGACY_NAME else n for n in df.index.names]
        df.index.names = new_names
    elif df.index.name == LEGACY_NAME:
        df.index.name = CANONICAL_NAME

    validate_no_dual_columns(df)
    return df


def _normalize_stock_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Remove stock names from columns and combine duplicate stock histories."""
    if not (df.columns.str.find(" ") != -1).all():
        return df

    # Remove stock names (e.g., "2330 台積電" -> "2330")
    df.columns = df.columns.str.split(" ").str[0]

    # Combine same stock history according to sid
    if pd.api.types.is_numeric_dtype(df.values):
        return df.transpose().groupby(level=0).mean().transpose()
    return df.fillna(np.nan).transpose().groupby(level=0).last().transpose()


def process_data(dataset: str, df: pd.DataFrame) -> pd.DataFrame:
    """Process raw data into standardized format."""
    df = _set_dataframe_index(df)

    # Special case (to align with tutorial)
    if dataset == "broker_transactions":
        df = df.reset_index().set_index("date")

    # Set column name for stock-column format
    if ":" in dataset:
        df.columns.name = "symbol"
    else:
        # Table format
        df = df.reset_index()
        if "stock_id" in df.columns and "symbol" not in df.columns:
            df = df.rename(columns={"stock_id": "symbol"})
        # Backward compat: add 'stock_id' alias column for table format
        if "symbol" in df.columns and "stock_id" not in df.columns:
            df["stock_id"] = df["symbol"]

    if not has_index_name(df, "date"):
        return df

    table_name = dataset.split(":", maxsplit=1)[0]

    # Align PMI/NMI data to trading dates
    if table_name in {
        "tw_total_pmi",
        "tw_total_nmi",
        "tw_industry_nmi",
        "tw_industry_pmi",
    } and isinstance(df.index[0], pd.Timestamp):
        close = get("price:收盤價")
        df.index = df.index.map(
            lambda d: (
                d
                if len(close.loc[d:]) == 0 or d < close.index[0]
                else close.loc[d:].index[0]
            )
        )

    df = _normalize_stock_columns(df)
    df = finlab.dataframe.FinlabDataFrame(df)

    effective_truncate_end = _get_effective_flag("truncate_end", truncate_end)
    needs_quarterly_masking = _should_mask_quarterly(table_name, effective_truncate_end)

    df = _apply_truncate_if_any(df, skip_end=needs_quarterly_masking)

    # Apply table-specific index transformations
    if table_name in TABLE_INDEX_TRANSFORMERS:
        df = TABLE_INDEX_TRANSFORMERS[table_name](df)

    # For TW quarterly tables: disclosure-date-aware masking after string index conversion
    if needs_quarterly_masking:
        df = _mask_undisclosed_quarterly(df, effective_truncate_end)

    return df


def _get_effective_flag(name: str, default: Any) -> Any:
    """Read a module-level flag from finlab.data, handling re-export decoupling."""
    package_module = sys.modules.get("finlab.data")
    if package_module is not None:
        return getattr(package_module, name, default)
    return default


def _apply_truncate_if_any(df: pd.DataFrame, skip_end: bool = False) -> pd.DataFrame:
    effective_truncate_start = _get_effective_flag("truncate_start", truncate_start)
    effective_truncate_end = _get_effective_flag("truncate_end", truncate_end)
    if isinstance(df.index, pd.DatetimeIndex):
        end = None if skip_end else effective_truncate_end
        return df.loc[effective_truncate_start:end]
    return df


def _mask_undisclosed_quarterly(
    df: pd.DataFrame, truncate_end_str: str
) -> pd.DataFrame:
    """NaN out cells where stock had not disclosed at truncate_end. Drop all-NaN rows."""
    disclosure_dates = get("etl:financial_statements_disclosure_dates")
    end_ts = pd.Timestamp(truncate_end_str)

    common_cols = df.columns.intersection(disclosure_dates.columns)
    if common_cols.empty:
        return df

    aligned = disclosure_dates.reindex(index=df.index, columns=common_cols)

    # True where stock disclosed AFTER cutoff → should be NaN
    # NaT comparison returns False → NaT cells are kept (no info = assume disclosed)
    undisclosed = aligned > end_ts

    result = df.copy()
    result.loc[:, common_cols] = df[common_cols].where(~undisclosed)
    result = result.dropna(how="all")
    return finlab.dataframe.FinlabDataFrame(result)


def _finalize(dataset: str, df: pd.DataFrame) -> pd.DataFrame:
    from .universe import universe_stocks

    effective_truncate_start = _get_effective_flag("truncate_start", truncate_start)
    effective_truncate_end = _get_effective_flag("truncate_end", truncate_end)
    cache_key = (
        dataset,
        id(df),
        frozenset(universe_stocks) if universe_stocks else None,
        effective_truncate_start,
        effective_truncate_end,
    )
    cached = _finalized_cache.get(cache_key)
    if cached is not None:
        return cached

    table_name = dataset.split(":", maxsplit=1)[0]
    skip_end = _should_mask_quarterly(table_name, effective_truncate_end)
    df = _apply_truncate_if_any(df, skip_end=skip_end)

    if not isinstance(df, finlab.dataframe.FinlabDataFrame):
        df = finlab.dataframe.FinlabDataFrame(df)
    result = refine_stock_id(dataset, df)
    _finalized_cache[cache_key] = result
    return result


def hash(df: pd.DataFrame) -> str:
    return hashlib.md5(pd.util.hash_pandas_object(df, index=True).values).hexdigest()[
        :7
    ]


def _get_from_local_only(dataset: str) -> pd.DataFrame:
    """Attempt to get data from local storage only."""
    df = _storage.get_dataframe(dataset)
    if df is not None and not df.empty:
        return _finalize(dataset, df)
    raise FileNotFoundError(
        f"**Error: {dataset} not exists at local storage. Please set data.use_local_data_only = False to download data from cloud."
    )


def _get_from_local_if_valid(
    dataset: str, force_download: bool
) -> tuple[pd.DataFrame | None, pd.DataFrame | None]:
    """Return local data if cache is valid and not expired, else None.

    Returns a tuple (result, df_loaded) where result is the finalized
    DataFrame or None, and df_loaded is the raw DataFrame that was read
    from storage (to avoid re-reading in later stages).
    """
    # Already loaded this session: skip server round-trip but still respect expiry
    if dataset in _loaded_datasets and not force_download:
        time_expired = _storage.get_time_expired(dataset)
        if time_expired and time_expired > CacheStorage.now():
            df = _storage.get_dataframe(dataset)
            if df is not None and not df.empty:
                logger.debug(f"{dataset} already loaded and not expired -> use cache")
                return _finalize(dataset, df), df

    # Prefer local cache without checking expiry (user-set flag)
    effective_prefer_local_if_exists = _get_effective_flag(
        "prefer_local_if_exists", prefer_local_if_exists
    )
    if effective_prefer_local_if_exists and not force_download:
        df = _storage.get_dataframe(dataset)
        if df is not None and not df.empty:
            logger.debug(
                f"{dataset} prefer_local_if_exists enabled -> get data from local without update check"
            )
            return _finalize(dataset, df), df

    # Check expiry BEFORE reading DataFrame to avoid unnecessary I/O
    time_expired = _storage.get_time_expired(dataset)
    if time_expired and time_expired > CacheStorage.now() and not force_download:
        df = _storage.get_dataframe(dataset)
        if df is not None and not df.empty:
            logger.debug(f"{dataset} not expired -> get data from local")
            return _finalize(dataset, df), df

    # Free user can only use historical data without merge
    if _role == "free":
        df = _storage.get_dataframe(dataset)
        if df is not None:
            return _finalize(dataset, df), df

    return None, None


def _try_merge_recent_data(
    dataset: str, df: pd.DataFrame | None
) -> pd.DataFrame | None:
    """Try to merge recent data with existing local data. Returns finalized df or None."""
    if df is None or df.empty:
        return None

    url_data = fetch_data(
        dataset + ".recent", time_saved=_storage.get_time_created(dataset)
    )
    if url_data is None:
        return None

    # Server says local data is still valid
    if "data" not in url_data:
        _storage.set_time_expired(dataset, url_data["expiry"])
        logger.debug(
            f"{dataset} get recent, server says not expired -> get data from local"
        )
        return _finalize(dataset, df)

    # Try to merge
    short_df = url_data["data"]
    try:
        compare_cols = df.columns.intersection(
            ["symbol", "stock_id", "date", "持股分級", "broker"]
        )
        merged_df = (
            pd.concat([df, short_df])
            .pipe(lambda d: d[~d.duplicated(subset=compare_cols, keep="last")])[
                short_df.columns
            ]
            .reset_index(drop=True)
        )
    except Exception:
        return None

    # Verify merge integrity
    hash_df = hash(merged_df)
    logger.debug(f'hash df: {hash_df} url: {url_data.get("hash")}')

    if url_data.get("hash") == hash_df and not merged_df.empty:
        _storage.set_dataframe(dataset, merged_df, expiry=url_data["expiry"])
        logger.debug("get recent, is valid -> and merge recent to local data")
        return _finalize(dataset, merged_df)

    return None


def _download_full_dataset(dataset: str) -> pd.DataFrame:
    """Download full dataset from cloud."""
    global _role, _storage

    url_data = fetch_data(dataset)
    if url_data is None:
        raise FileNotFoundError(f"**Error: {dataset} not exists")

    df = url_data["data"]

    # Fallback to cache storage if user is free user
    if _role is None and url_data.get("role") == "free":
        _role = "free"
        _storage = CacheStorage()

    if not df.empty:
        _storage.set_dataframe(dataset, df, expiry=url_data["expiry"])
    else:
        raise RuntimeError(f"**Error: {dataset} download fail")

    logger.debug(f"{dataset} downloaded full data from cloud")
    return _finalize(dataset, df)


def get_role() -> str | None:
    """取得當前使用者的角色。

    Returns:
        str or None: 使用者角色，例如 ``'free'`` 或 ``'vip'``。
            若尚未進行任何資料請求，則回傳 ``None``。
    """
    return _role


def is_vip() -> bool:
    """判斷當前使用者是否為 VIP 會員。

    Returns:
        bool: 若使用者為 VIP 則回傳 ``True``，否則回傳 ``False``。
            若尚未進行任何資料請求（角色未知），亦回傳 ``False``。
    """
    return _role is not None and _role != "free"


def get(
    dataset: str, save_to_storage: bool = True, force_download: bool = False
) -> pd.DataFrame:
    """下載歷史資料

    請至[歷史資料目錄](https://ai.finlab.tw/database) 來獲得所有歷史資料的名稱，即可使用此函式來獲取歷史資料。
    假設 `save_to_storage` 為 `True` 則，程式會自動在本地複製一份，以避免重複下載大量數據。

    Args:
        dataset (str): The name of dataset.
        save_to_storage (bool): Whether to save the dataset to storage for later use. Default is True. The argument will be removed in the future. Please use data.set_storage(FileStorage(use_cache=True)) instead.
        force_download (bool): Whether to force download the dataset from cloud. Default is False.

    Returns:
        (pd.DataFrame): financial data

    Examples:
        欲下載所有上市上櫃之收盤價歷史資料，只需要使用此函式即可:

        ``` py
        from finlab import data
        close = data.get('price:收盤價')
        close
        ```

        | date       |   0015 |   0050 |   0051 |   0052 |   0053 |
        |:-----------|-------:|-------:|-------:|-------:|-------:|
        | 2007-04-23 |   9.54 |  57.85 |  32.83 |  38.4  |    nan |
        | 2007-04-24 |   9.54 |  58.1  |  32.99 |  38.65 |    nan |
        | 2007-04-25 |   9.52 |  57.6  |  32.8  |  38.59 |    nan |
        | 2007-04-26 |   9.59 |  57.7  |  32.8  |  38.6  |    nan |
        | 2007-04-27 |   9.55 |  57.5  |  32.72 |  38.4  |    nan |

        !!!note
            使用 `data.get` 時，會預設優先下載近期資料，並與本地資料合併，以避免重複下載大量數據。

            假如想要強制下載所有資料，可以在下載資料前，使用
            ```py
            data.force_cloud_download = True
            ```
            假如想要強制使用本地資料，不額外下載，可以在下載資料前，使用
            ```py
            data.use_local_data_only = True
            ```

    """
    finlab.utils.check_version()
    dataset = _resolve_dataset(dataset)

    global _storage

    if not save_to_storage:
        logger.warning(
            "save_to_storage will be deprecated after 2024/06/01. Please use data.set_storage(CacheStorage()) to disable data saved to local storage"
        )

    # Read flags from the package module (handles re-export decoupling)
    effective_force_cloud_download = _get_effective_flag(
        "force_cloud_download", force_cloud_download
    )
    effective_use_local_data_only = _get_effective_flag(
        "use_local_data_only", use_local_data_only
    )

    force_download |= effective_force_cloud_download

    if effective_use_local_data_only and force_download:
        raise ValueError(
            "data.use_local_data_only and data.force_download cannot be both True"
        )

    # Stage 1: Local-only mode
    if effective_use_local_data_only:
        _loaded_datasets.add(dataset)
        return _get_from_local_only(dataset)

    # Stage 2: Try valid local cache
    result, df = _get_from_local_if_valid(dataset, force_download)
    if result is not None:
        _loaded_datasets.add(dataset)
        return result

    # Stage 3: Try merging recent data with local
    # Skip entirely when force_download — merge is not needed and reading
    # a stale pickle may fail on pandas version mismatch.
    if not force_download:
        if df is None:
            df = _storage.get_dataframe(dataset)
        result = _try_merge_recent_data(dataset, df)
        if result is not None:
            _loaded_datasets.add(dataset)
            return result

    # Stage 4: Download full dataset
    del df
    gc.collect()
    _loaded_datasets.add(dataset)
    return _download_full_dataset(dataset)


def get_input_args(attr: _TalibAbstract) -> list[str]:
    input_names = attr.input_names
    refine_input_names: list[str] = []
    for key, val in input_names.items():
        if "price" in key:
            if isinstance(val, list):
                refine_input_names += val
            elif isinstance(val, str):
                refine_input_names.append(val)

    return refine_input_names


def indicator(
    indname: str, adjust_price: bool = False, resample: str = "D", **kwargs: Any
) -> pd.DataFrame | tuple[pd.DataFrame, ...]:
    """支援 Talib 和 pandas_ta 上百種技術指標，計算 2000 檔股票、10年的所有資訊。

    在使用這個函式前，需要安裝計算技術指標的 Packages

    * [Ta-Lib](https://github.com/mrjbq7/ta-lib)
    * [Pandas-ta](https://github.com/twopirllc/pandas-ta)

    Args:
        indname (str): 指標名稱，
            以 TA-Lib 舉例，例如 SMA, STOCH, RSI 等，可以參考 [talib 文件](https://mrjbq7.github.io/ta-lib/doc_index.html)。

            以 Pandas-ta 舉例，例如 supertrend, ssf 等，可以參考 [Pandas-ta 文件](https://twopirllc.github.io/pandas-ta/#indicators-by-category)。
        adjust_price (bool): 是否使用還原股價計算。
        resample (str): 技術指標價格週期，ex: `D` 代表日線, `W` 代表週線, `M` 代表月線。
        market (str): 市場選擇，ex: `TW_STOCK` 代表台股, `US_STOCK` 代表美股。
        **kwargs (dict): 技術指標的參數設定，TA-Lib 中的 RSI 為例，調整項為計算週期 `timeperiod=14`。
    建議使用者可以先參考以下範例，並且搭配 talib官方文件，就可以掌握製作技術指標的方法了。
    """
    package = None

    if not isinstance(adjust_price, bool):
        usage_str = f"data.indicator({indname}, adjust_price={adjust_price}, resample={resample}, **kwargs)"
        example_str = 'k, d = data.indicator("STOCH", adjust_price=True, resample="D", fastk_period=14, fastd_period=3)'
        raise ValueError(
            f"`adjust_price` must be a bool, e.g. `True`, `False`. Usage: {usage_str}, Example: {example_str}"
        )

    try:
        import talib  # noqa: F401
        from talib import abstract

        attr = getattr(abstract, indname)
        package = "talib"
    except ImportError:
        try:
            import pandas_ta  # noqa: F401

            # test df.ta has attribute
            getattr(pd.DataFrame().ta, indname)

            def _pandas_ta_wrapper(df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
                return getattr(df.ta, indname)(**kwargs)

            attr = _pandas_ta_wrapper

            package = "pandas_ta"
        except ImportError as e:
            raise ImportError(
                "Please install TA-Lib or pandas_ta to get indicators."
            ) from e

    if "market" in kwargs:
        market_name = kwargs.pop("market")
        from finlab.markets import get_market_by_name

        config.set_market(get_market_by_name(market_name.lower()))

    market = config.get_market()

    close = market.get_price("close", adj=adjust_price)
    open_ = market.get_price("open", adj=adjust_price)
    high = market.get_price("high", adj=adjust_price)
    low = market.get_price("low", adj=adjust_price)
    volume = market.get_price("volume", adj=adjust_price)

    # check if the dataframes above are same shape
    shape_is_same = all(
        [
            close.shape == open_.shape,
            close.shape == high.shape,
            close.shape == low.shape,
            close.shape == volume.shape,
        ]
    )

    if not shape_is_same:
        dfs = [close, open_, high, low, volume]
        latest_date = min(df.index[-1] for df in dfs)
        logger.warning(
            f"indicator: {indname} market: {market} has different end date, "
            f"cut to {latest_date}. This is due to server updating data. "
            "If you want to get the latest data, please try again 3 minutes later."
        )
        common_idx = reduce(lambda a, b: a.intersection(b), [df.index for df in dfs])
        common_cols = reduce(lambda a, b: a.intersection(b), [df.columns for df in dfs])

        close = close.loc[common_idx, common_cols]
        open_ = open_.loc[common_idx, common_cols]
        high = high.loc[common_idx, common_cols]
        low = low.loc[common_idx, common_cols]
        volume = volume.loc[common_idx, common_cols]

    if resample.upper() != "D":
        close = close.resample(resample).last()
        open_ = open_.resample(resample).first()
        high = high.resample(resample).max()
        low = low.resample(resample).min()
        volume = volume.resample(resample).sum()

    dfs: dict[str, dict[str, Any]] = {}
    default_output_columns: list[str] | None = None
    for key in close.columns:
        prices = {
            "open": open_[key].ffill(),
            "high": high[key].ffill(),
            "low": low[key].ffill(),
            "close": close[key].ffill(),
            "volume": volume[key].ffill(),
        }

        if prices["close"].iloc[-1] != prices["close"].iloc[-1]:
            continue

        if package == "pandas_ta":
            prices = pd.DataFrame(prices)
            s = attr(prices, **kwargs)

        elif package == "talib":
            abstract_input = get_input_args(attr)

            # quick fix talib bug
            if indname == "OBV":
                abstract_input = ["close", "volume"]

            if indname == "BETA":
                abstract_input = ["high", "low"]

            if isinstance(abstract_input, str):
                abstract_input = [abstract_input]
            paras = [prices[k] for k in abstract_input]
            s = attr(*paras, **kwargs)
        else:
            raise RuntimeError("Cannot determine technical package from indname")

        if isinstance(s, list):
            s = dict(enumerate(s))

        if isinstance(s, np.ndarray):
            s = {0: s}

        if isinstance(s, pd.Series):
            s = {0: s.values}

        if isinstance(s, pd.DataFrame):
            s = {i: series.values for i, series in s.items()}

        if default_output_columns is None:
            default_output_columns = list(s)

        for colname, series in s.items():
            dfs.setdefault(colname, {})[key] = series

    newdic: dict[str, pd.DataFrame] = {}
    for key, df in dfs.items():
        newdic[key] = pd.DataFrame(df, index=close.index)

    ret = [newdic[n] for n in default_output_columns]
    ret = [d.apply(lambda s: pd.to_numeric(s, errors="coerce")) for d in ret]

    if len(ret) == 1:
        return finlab.dataframe.FinlabDataFrame(ret[0])

    return tuple([finlab.dataframe.FinlabDataFrame(df) for df in ret])


indicator.us_stock = lambda *args, **kwargs: indicator(
    *args, **{**kwargs, "market": "US_STOCK"}
)
indicator.tw_stock = lambda *args, **kwargs: indicator(
    *args, **{**kwargs, "market": "TW_STOCK"}
)


def get_strategies(api_token: str | None = None) -> dict[str, Any] | str:
    """取得已上傳量化平台的策略回傳資料。

    可取得自己策略儀表板上的數據，例如每個策略的報酬率曲線、報酬率統計、夏普率、近期部位、近期換股日...，
    這些數據可以用來進行多策略彙整的應用喔！


    Args:
        api_token (str): 若未帶入finlab模組的api_token，會自動跳出[GUI](https://ai.finlab.tw/api_token/)頁面，
                         複製網頁內的api_token貼至輸入欄位即可。
    Returns:
        (dict): strategies data
    Response detail:

        ``` py
        {
          strategy1:{
            'asset_type': '',
            'drawdown_details': {
               '2015-06-04': {
                 'End': '2015-11-03',
                 'Length': 152,
                 'drawdown': -0.19879090089478024
                 },
                 ...
              },
            'fee_ratio': 0.000475,
            'last_trading_date': '2022-06-10',
            'last_updated': 'Sun, 03 Jul 2022 12:02:27 GMT',
            'ndays_return': {
              '1': -0.01132480035770611,
              '10': -0.0014737286933147464,
              '20': -0.06658015749110646,
              '5': -0.002292995729485159,
              '60': -0.010108700314771735
              },
            'next_trading_date': '2022-06-10',
            'positions': {
              '1413 宏洲': {
                'entry_date': '2022-05-10',
                'entry_price': 10.05,
                'exit_date': '',
                'next_weight': 0.1,
                'return': -0.010945273631840613,
                'status': '買進',
                'weight': 0.1479332345384493
                },
              'last_updated': 'Sun, 03 Jul 2022 12:02:27 GMT',
              'next_trading_date': '2022-06-10',
              'trade_at': 'open',
              'update_date': '2022-06-10'
              },
            'return_table': {
              '2014': {
                'Apr': 0.0,
                'Aug': 0.06315180932606546,
                'Dec': 0.0537589857541485,
                'Feb': 0.0,
                'Jan': 0.0,
                'Jul': 0.02937490104459939,
                'Jun': 0.01367930162104769,
                'Mar': 0.0,
                'May': 0.0,
                'Nov': -0.0014734320286596825,
                'Oct': -0.045082529665408266,
                'Sep': 0.04630906972509852,
                'YTD': 0.16626214846456966
                },
                ...
              },
            'returns': {
              'time': [
                '2014-06-10',
                '2014-06-11',
                '2014-06-12',
                ...
                ],
              'value': [
                100,
                99.9,
                100.2,
                ...
                ]
              },
            'stats': {
              'avg_down_month': -0.03304015302646822,
              'avg_drawdown': -0.0238021414698247,
              'avg_drawdown_days': 19.77952755905512,
              'avg_up_month': 0.05293384465715908,
              'cagr': 0.33236021285588846,
              'calmar': 1.65261094975066,
              'daily_kurt': 4.008888367138843,
              'daily_mean': 0.3090784769257415,
              'daily_sharpe': 1.747909002374217,
              'daily_skew': -0.6966018726321078,
              'daily_sortino': 2.8300677082214034,
              ...
              },
            'tax_ratio': 0.003,
            'trade_at': 'open',
            'update_date': '2022-06-10'
            },
          strategy2:{...},
          ...}
        ```
    """
    token_type = "api_token"
    if api_token is None:
        token_result = finlab.get_token()
        if isinstance(token_result, tuple):
            api_token, token_type = token_result
        else:
            api_token = token_result

    request_args: dict[str, str] = {}
    if token_type == "id_token":
        request_args["id_token"] = api_token
    else:
        request_args["api_token"] = api_token

    url = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_get_strategies"
    response = finlab.utils.requests.get(url, request_args, timeout=300)
    status_code = response.status_code
    if status_code in {400, 401}:
        logger.error(
            "The authentication code is wrong or the account is not existed. "
            "Please input right authentication code or register account."
        )
        return {}
    with contextlib.suppress(json.JSONDecodeError, ValueError):
        return json.loads(response.text)

    return response.text


def _parse_firestore_value(
    value: dict[str, Any],
) -> str | int | float | bool | list[Any] | dict[str, Any] | None:
    """解析 Firestore REST API 回傳的值格式。"""
    if "stringValue" in value:
        return value["stringValue"]
    if "integerValue" in value:
        return int(value["integerValue"])
    if "doubleValue" in value:
        return float(value["doubleValue"])
    if "booleanValue" in value:
        return value["booleanValue"]
    if "nullValue" in value:
        return None
    if "arrayValue" in value:
        values = value["arrayValue"].get("values", [])
        return [_parse_firestore_value(v) for v in values]
    if "mapValue" in value:
        fields = value["mapValue"].get("fields", {})
        return {k: _parse_firestore_value(v) for k, v in fields.items()}
    if "timestampValue" in value:
        return value["timestampValue"]
    return None


# Market → Firestore document ID mapping (mirrors fdata REGION_BUCKET_MAPPING bulk buckets)
_MARKET_TO_FIRESTORE_DOC: Final[dict[str, str]] = {
    "tw": "finlab_tw_stock",
    "us": "finlab_us_stock",
    "hk": "fdata-hk-stock",
    "jp": "fdata-jp-stock",
    "kr": "fdata-kr-stock",
    "uk": "fdata-uk-stock",
}


@lru_cache(maxsize=8)
def _fetch_data_catalog_from_firestore(document_id: str) -> tuple[str, ...]:
    """從 Firestore REST API 取得資料目錄（使用 lru_cache 快取）。

    Args:
        document_id: Firestore 文件 ID（例如 'finlab_tw_stock' 或 'fdata-jp-stock'）
    """
    import urllib.request

    url = f"https://firestore.googleapis.com/v1/projects/fdata-299302/databases/(default)/documents/data_categories/{document_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = json.loads(response.read().decode("utf-8"))

        fields = raw.get("fields", {})
        categories = _parse_firestore_value(fields.get("categories", {}))

        if not categories:
            return ()

        # 建立 "table:column" 格式的列表
        result: list[str] = []
        for cat in categories:
            table_alias = cat.get("alias", "")
            data_info = cat.get("data_info", [])
            for info in data_info:
                col_alias = info.get("alias", "")
                if col_alias:
                    result.append(col_alias)
                elif table_alias and info.get("name"):
                    result.append(f"{table_alias}:{info.get('name')}")

        # 去除重複項（保持順序）
        return tuple(dict.fromkeys(result))
    except Exception as e:
        logger.warning(f"Failed to fetch data catalog from {document_id}: {e}")
        return ()


def search(keyword: str | None = None, market: str | None = None) -> list[str]:
    """搜尋 FinLab 資料庫可用的資料欄位。

    Args:
        keyword (str, optional): 搜尋關鍵字。若為 None 則列出全部。
        market (str, optional): 市場選擇 ('tw', 'us', 'hk', 'jp', 'kr', 'uk', 'all')。
            預設依據 data.set_market() 設定，若未設定則為 'tw'。

    Returns:
        list: 可用於 data.get() 的資料名稱列表，格式為 "table:column"

    Examples:
        ``` py
        # 列出全部台股資料
        tw_data = data.search()

        # 搜尋台股包含 '收盤' 的欄位
        close_data = data.search('收盤', market='tw')
        # ['price:收盤價']

        # 搜尋美股包含 'close' 的欄位
        us_close = data.search('close', market='us')
        # ['us_price:close', 'us_div_adj_price:adj_close', ...]

        # 搜尋日股包含 'price' 的欄位
        jp_price = data.search('price', market='jp')

        # 搜尋所有市場包含 'price' 的欄位
        all_price = data.search('price', market='all')
        ```
    """
    # 當 keyword 是有效市場名稱（如 'us'）且未指定 market 時，自動視為市場選擇
    _valid_market_names = set(_MARKET_TO_FIRESTORE_DOC) | {"all"}
    if (
        keyword is not None
        and market is None
        and keyword.lower() in _valid_market_names
    ):
        market = keyword.lower()
        keyword = None

    if market is None:
        market = _current_market or "tw"
    market = market.lower()

    # 根據 market 參數取得目錄
    if market == "all":
        catalog: list[str] = []
        for doc_id in _MARKET_TO_FIRESTORE_DOC.values():
            catalog.extend(_fetch_data_catalog_from_firestore(doc_id))
    elif market in _MARKET_TO_FIRESTORE_DOC:
        doc_id = _MARKET_TO_FIRESTORE_DOC[market]
        catalog = list(_fetch_data_catalog_from_firestore(doc_id))
    else:
        valid = ", ".join(sorted(_MARKET_TO_FIRESTORE_DOC)) + ", all"
        raise ValueError(f"Invalid market: '{market}'. Must be one of: {valid}")

    if keyword is None:
        return catalog

    keyword_lower = keyword.lower()
    return [item for item in catalog if keyword_lower in item.lower()]


def _get_expiry_dict() -> dict[str, datetime.datetime]:
    """Get the expiry dict from current storage.

    When datasets have been loaded via get(), only return expiry entries
    for those datasets so that unrelated cached data doesn't affect
    suggested_tradable_time() / is_tradable().
    """
    if isinstance(_storage, FileStorage):
        expiry = _storage._expiry
    elif isinstance(_storage, CacheStorage):
        expiry = _storage._cache_expiry
    else:
        return {}

    if not _loaded_datasets:
        return {}

    return {k: v for k, v in expiry.items() if k in _loaded_datasets}


def next_future_expiry() -> datetime.datetime | None:
    """Next future expiry time among cached datasets (UTC).

    Returns only expiry times in the future, skipping already expired data.

    Returns:
        datetime in UTC representing the next future expiry, or None if
        no future expiries exist or no data is available.
    """
    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return None

    now = datetime.datetime.now(tz=datetime.timezone.utc)

    # Filter to only future expiries
    future_expiries = [
        expiry for expiry in expiry_dict.values() if expiry is not None and expiry > now
    ]

    if not future_expiries:
        return None

    return min(future_expiries)


def suggested_tradable_time(market: Market | None = None) -> datetime.datetime | None:
    """Estimate when is_tradable() will become True.

    If already tradable, returns None.
    Otherwise:
      1. If any loaded dataset is already expired, returns latest expired
         expiry + buffer.
      2. Else (typically before today's market open), returns latest expiry
         that is still before today's open, plus buffer.

    Args:
        market: A Market instance. If None, defaults to TWMarket.

    Returns:
        datetime in UTC, or None if already tradable or no data.
    """
    from finlab.markets.tw import TWMarket

    if market is None:
        market = TWMarket()

    if is_tradable(market):
        return None

    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return None

    now = datetime.datetime.now(tz=datetime.timezone.utc)
    expired_expiries = [
        expiry
        for expiry in expiry_dict.values()
        if expiry is not None and expiry <= now
    ]

    # If data is already stale, suggest based on the latest stale expiry first.
    if expired_expiries:
        return max(expired_expiries) + datetime.timedelta(minutes=15)

    tz = market.tzinfo() or datetime.timezone(datetime.timedelta(hours=8))
    open_hour, open_minute = market.market_open_time()

    # Calculate today's market open in local timezone.
    now_local = now.astimezone(tz)
    today_open_local = now_local.replace(
        hour=open_hour, minute=open_minute, second=0, microsecond=0
    )
    today_open_utc = today_open_local.astimezone(datetime.timezone.utc)

    # Find the latest expiry that is still before today's market open.
    latest_blocking_expiry = None
    for expiry in expiry_dict.values():
        if expiry is None:
            continue
        if expiry <= today_open_utc and (
            latest_blocking_expiry is None or expiry > latest_blocking_expiry
        ):
            latest_blocking_expiry = expiry

    if latest_blocking_expiry is None:
        return None

    # Add 15 min buffer for crawler execution
    return latest_blocking_expiry + datetime.timedelta(minutes=15)


def is_tradable(market: Market | None = None) -> bool:
    """Check if cached data is safe for trading.

    True when:
      1. All data not expired (now < expiry for all datasets)
      2. Before market open only: no more crawl updates before today's open
         (expiry > today's market open time)

    Args:
        market: A Market instance (TWMarket/USMarket). If None, defaults to TWMarket.

    Returns:
        bool: True if data is fresh enough for trading.
    """
    from finlab.markets.tw import TWMarket

    if market is None:
        market = TWMarket()

    expiry_dict = _get_expiry_dict()
    if not expiry_dict:
        return False

    now = datetime.datetime.now(tz=datetime.timezone.utc)

    # Get market timezone and open time
    tz = market.tzinfo() or datetime.timezone(datetime.timedelta(hours=8))
    open_hour, open_minute = market.market_open_time()

    # Calculate today's market open time
    now_local = now.astimezone(tz)
    today_open_local = now_local.replace(
        hour=open_hour, minute=open_minute, second=0, microsecond=0
    )
    today_open_utc = today_open_local.astimezone(datetime.timezone.utc)
    market_opened_today = now_local >= today_open_local

    for expiry in expiry_dict.values():
        if expiry is None:
            continue
        if now >= expiry:
            return False
        # If market has not opened yet, ensure there won't be more updates
        # before today's open.
        if (not market_opened_today) and expiry <= today_open_utc:
            return False

    return True
