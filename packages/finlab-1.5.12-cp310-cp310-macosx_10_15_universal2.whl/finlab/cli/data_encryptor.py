from __future__ import annotations

import json
import os
import uuid
from base64 import urlsafe_b64decode, urlsafe_b64encode
from hashlib import md5
from typing import Any

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


def hash_value(val: str) -> str:
    return md5(val.encode("utf-8")).hexdigest()


class DataEncryptor:
    def __init__(
        self, data: dict[str, Any], password: str = "", default_path: str = ""
    ) -> None:
        self.data: dict[str, Any] = data
        self.password: str = password or self.__get_machine_password()
        self.default_path: str = default_path

    def __generate_key_from_password(self, password: str, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return urlsafe_b64encode(kdf.derive(password.encode()))

    def encrypt_data(self) -> str:
        salt = os.urandom(16)  # Generate a new salt for each encryption
        key = self.__generate_key_from_password(self.password, salt)
        cipher_suite = Fernet(key)
        data_str = json.dumps(self.data)
        encrypted_data = cipher_suite.encrypt(data_str.encode())

        # Combine the salt and the encrypted data for storage/transmission
        return urlsafe_b64encode(salt + encrypted_data).decode()

    @classmethod
    def decrypt_data(cls, encrypted_data: str, password: str = "") -> dict[str, Any]:
        password = password or cls.__get_machine_password_static()
        combined = urlsafe_b64decode(encrypted_data.encode())
        salt = combined[:16]
        encrypted_data = combined[16:]
        key = cls.__generate_key_from_password_static(password, salt)
        cipher_suite = Fernet(key)
        decrypted_data = cipher_suite.decrypt(encrypted_data)
        return json.loads(decrypted_data.decode())

    @staticmethod
    def __generate_key_from_password_static(password: str, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return urlsafe_b64encode(kdf.derive(password.encode()))

    @staticmethod
    def __get_machine_password_static() -> str:
        return hash_value(str(uuid.getnode()))

    def __get_machine_password(self) -> str:
        return self.__get_machine_password_static()

    def to_file(self, path: str = "") -> None:
        if not path:
            path = self.default_path
        if not path:
            raise ValueError("No path provided for saving the file.")

        encrypted_data = self.encrypt_data()
        with open(path, "w", encoding="utf-8") as file:
            file.write(encrypted_data)

    @classmethod
    def from_file(cls, path: str, password: str = "") -> DataEncryptor:

        if os.path.exists(path):
            with open(path, encoding="utf-8") as file:
                encrypted_data = file.read()
        else:
            return cls({}, password, path)

        data = cls.decrypt_data(encrypted_data, password)

        return cls(data, password, path)

    def change_password(self, new_password: str = "") -> None:
        self.password = new_password or self.__get_machine_password()
