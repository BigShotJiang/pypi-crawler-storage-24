import logging
from logging import config as logging_config
from typing import Any

logger = logging.getLogger(__name__)


class _QLibLoggerManager:
    def __init__(self):
        self._loggers = {}

    def setLevel(self, level):
        for logger in self._loggers.values():
            logger.setLevel(level)

    def __call__(self, module_name, level: int | None = None):
        """
        Get a logger for a specific module.

        :param module_name: str
            Logic module name.
        :param level: int
        :return: Logger
            Logger object.
        """
        return logger


get_module_logger = _QLibLoggerManager()


def set_log_with_config(log_config: dict[str, Any]):
    """set log with config

    :param log_config:
    :return:
    """
    logging_config.dictConfig(log_config)
