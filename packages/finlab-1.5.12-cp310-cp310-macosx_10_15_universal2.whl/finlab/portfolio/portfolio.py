from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

__all__ = ["Portfolio"]

if TYPE_CHECKING:
    from collections.abc import Callable

import pandas as pd

from finlab.core.report import Report, ReportExecution

logger = logging.getLogger(__name__)

PositionScheduler: type[ReportExecution] = ReportExecution


class Portfolio(Report):
    def __init__(self, reports: dict[str, tuple[Report, float]] | Report) -> None:
        """建構 Portfolio 物件。

        Parameters:
            - reports (dict[str, tuple[Report, float]]): 代表投資組合的字典，key 為資產名稱，value 是回測報告與部位。
            A dictionary representing the portfolio, where the keys are the names of the assets and the values are tuples containing the asset's report and weight.


        Example:
            **組合多個策略**
            ```
            from finlab import sim
            from finlab.portfolio import Portfolio

            # 請參閱 sim 函數的文件以獲取更多信息
            # https://doc.finlab.tw/getting-start/

            report_strategy1 = sim(...)
            report_strategy2 = sim(...)
            report_strategy3 = sim(...)

            portfolio = Portfolio({
                'strategy1': (report_strategy1, 0.3),
                'strategy2': (report_strategy2, 0.4),
                'strategy3': (report_strategy3, 0.3),
            })
            ```
        """

        # mind user about this is the beta version
        logger.info(
            "Portfolio is in beta version, please report any issue to FinLab Team at https://discord.gg/tAr4ysPqvR"
        )

        if isinstance(reports, Report):
            reports = {"strategy": (reports, 1.0)}

        # Filter out strategies with zero weight to ensure consistency
        # A strategy with weight=0 should behave the same as if it were not included at all
        active_reports = {k: v for k, v in reports.items() if v[1] != 0}

        # Handle edge case: all strategies have zero weight
        if not active_reports:
            raise ValueError(
                "All strategies have zero weight. At least one strategy must have non-zero weight."
            )

        # calculate overall creturn using daily return (portfolio['name'][1].creturn) and weight (portfolio['name'][0])
        # creating pct df - only using active strategies (non-zero weight)
        self.portfolio: dict[str, tuple[Report, float]] = reports
        pct = pd.DataFrame(
            {k: v[0].creturn.pct_change() for k, v in active_reports.items()}
        ).dropna(how="any")
        weight = pd.Series({k: v[1] for k, v in active_reports.items()})

        # calculate overall creturn
        creturn = (pct * weight).sum(axis=1).add(1).cumprod()
        self.creturn: pd.Series = creturn

        # calculate position
        # First, compute the union of all columns across report positions.
        union_cols: set[str] = set()
        for report, _ in reports.values():
            union_cols.update(report.position.columns)
        union_cols = sorted(union_cols)

        # Calculate overall position by reindexing each report's position to the union_cols,
        # then multiplying by the corresponding weight, and finally summing them up.
        position = sum(
            report.position.reindex(union_cols, axis=1, fill_value=0) * w
            for _, (report, w) in reports.items()
        )

        self.position: pd.DataFrame = position.fillna(0)

        # get any fee ratio from report
        sample_report = next(iter(reports.values()))[0]
        fee_ratio = sample_report.fee_ratio
        tax_ratio = sample_report.tax_ratio
        trade_at = sample_report.trade_at
        next_trading_date = min([v[0].next_trading_date for k, v in reports.items()])
        market = sample_report.market

        super().__init__(
            creturn,
            self.position,
            fee_ratio,
            tax_ratio,
            trade_at,
            next_trading_date,
            market,
        )

        self.trades: pd.DataFrame = (
            pd.concat([v[0].trades for k, v in reports.items()])
            .sort_values("entry_sig_date")
            .reset_index(drop=True)
            .tail(500)
        )
        self.trades.index.name = "trade_index"
        self.trades.sort_values("entry_sig_date", inplace=True)
        self.trades.reset_index(drop=True, inplace=True)
        self.trades = self.trades.tail(500)

        self.live_performance_start: pd.Timestamp = self.trades.entry_sig_date.min()
        self.stop_loss: float | None = None
        self.take_profit: float | None = None
        self.trail_stop: float | None = None
        self.resample: str | None = None

        self.position_schedulers: dict[str, PositionScheduler] = {}

        for name, (report, weight) in reports.items():
            if "|" in name:
                raise ValueError('name should not contain "|"')

            source_execution = None
            if hasattr(report, "execution"):
                source_execution = report.execution
            elif hasattr(report, "position_schedulers"):
                source_execution = report.position_schedulers

            if isinstance(source_execution, dict):
                for sub_name, sub_execution in source_execution.items():
                    self.position_schedulers[f"{name}|{sub_name}"] = (
                        sub_execution._replace(
                            total_weight=sub_execution.total_weight * weight
                        )
                    )
            elif isinstance(source_execution, PositionScheduler):
                self.position_schedulers[name] = source_execution._replace(
                    total_weight=source_execution.total_weight * weight
                )
            elif isinstance(report, Report):
                self.position_schedulers[name] = report.execution._replace(
                    total_weight=weight
                )

        # check if the self.position_scheduler is a dict of PositionScheduler
        if not isinstance(self.position_schedulers, dict):
            raise ValueError(
                "position_schedulers should be a dict of PositionScheduler"
            )

        for name, scheduler in self.position_schedulers.items():
            if not isinstance(scheduler, PositionScheduler):
                raise ValueError(
                    "position_schedulers should be a dict of PositionScheduler"
                )

            if not isinstance(scheduler.weights, pd.Series):
                print(name)
                raise ValueError("weights should be a pd.Series")

            if not isinstance(scheduler.next_weights, pd.Series):
                print(name)
                raise ValueError("next_weights should be a pd.Series")

        self.execution: dict[str, PositionScheduler] = self.position_schedulers

    @classmethod
    def from_weight_function(
        cls, reports: dict[str, Report], weight_function: Callable[[], pd.DataFrame]
    ) -> Portfolio:

        creturns = pd.DataFrame({k: r.creturn for k, r in reports.items()})
        weight = weight_function()
        if not creturns.columns.isin(weight.columns).all():
            raise ValueError("Report names must be a subset of weight columns")
        if not weight.iloc[-1].notna().all():
            raise ValueError("Latest weight row contains NaN values")

        current_weight = weight.iloc[-1]
        ret = cls({k: (r, current_weight[k]) for k, r in reports.items()})
        ret.creturn = (creturns.pct_change() * weight).sum(axis=1).add(1).cumprod()
        return ret

    def position_info2(self) -> dict[str, Any]:

        # get position info for all reports in self.portfolio
        position: dict[str, Any] = {}

        for name, (report, weight) in self.portfolio.items():
            pinfo = report.position_info2()

            if "positionConfig" in pinfo:
                pinfo["positionConfig"]["weight"] = weight
                position[name] = pinfo

            # handle recursive position
            else:
                for sub_name, sub_position in pinfo.items():
                    sub_position["positionConfig"]["weight"] *= weight
                    position[f"{name}|{sub_name}"] = sub_position

        return position

    def is_stop_triggered(self) -> bool:

        for scheduler in self.position_schedulers.values():
            if scheduler.actions.isin(["sl", "tp"]).any():
                return True

        return False
