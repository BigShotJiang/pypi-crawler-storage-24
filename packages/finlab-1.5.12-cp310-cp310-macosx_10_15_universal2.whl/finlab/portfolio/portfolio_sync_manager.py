from __future__ import annotations

import copy
import datetime
import json
import logging
import math
import os
from typing import TYPE_CHECKING, Any, ClassVar, Final

__all__ = ["PortfolioSyncManager"]

if TYPE_CHECKING:
    from finlab.online.core.account import Account
    from finlab.schemas import PortfolioData

import pandas as pd
import requests

import finlab
from finlab.compat import is_typed_strict_mode, resolve_position_entry_symbol
from finlab.core.report import Report
from finlab.markets import get_market_by_name
from finlab.markets.tw import TWMarket
from finlab.online.enums import OrderCondition
from finlab.online.order_executor import OrderExecutor, Position
from finlab.utils import get_tmp_dir

from .portfolio import Portfolio, PositionScheduler

logger = logging.getLogger(__name__)

_ODD_LOT_TOLERANCE: Final[float] = 1e-5

logger.setLevel(logging.INFO)


def position_type_check(position_name: str, data: dict[str, Any]) -> None:
    if not isinstance(data.get("timestamp"), str):
        logger.warning(
            f"{position_name}: timestamp must be a string, got {type(data.get('timestamp'))} instead"
        )
    if not isinstance(data.get("next_trading_time"), str):
        logger.warning(f"{position_name}: next_trading_time must be a string")
    if not isinstance(data.get("position"), list):
        logger.warning(
            f"{position_name}: position must be a float or int, got {type(data.get('position'))} instead"
        )
    if not isinstance(data.get("allocation"), (float, int)):
        logger.warning(
            f"{position_name}: allocation must be a float or int, got {type(data.get('allocation'))} instead"
        )
    if not isinstance(data.get("weight"), (float, int)):
        logger.warning(
            f"{position_name}: weight must be a float or int, got {type(data.get('weight'))} instead"
        )
    if not isinstance(data.get("entry_at"), str):
        logger.warning(
            f"{position_name}: entry_at must be a string, got {type(data.get('entry_at'))} instead"
        )
    if not isinstance(data.get("exit_at"), str):
        logger.warning(
            f"{position_name}: exit_at must be a string, got {type(data.get('exit_at'))} instead"
        )
    if not isinstance(data.get("market"), str) and data.get("market") is None:
        data["market"] = "tw_stock"
    if not isinstance(data.get("stop"), list):
        logger.warning(
            f"{position_name}: stop must be a list, got {type(data.get('stop'))} instead"
        )
    if data.get("stop_loss") is not None and not isinstance(
        data.get("stop_loss"), (float, int)
    ):
        logger.warning(
            f"{position_name}: stop_loss must be a float or int, got {type(data.get('stop_loss'))} instead"
        )
    if data.get("take_profit") is not None and not isinstance(
        data.get("take_profit"), (float, int)
    ):
        logger.warning(
            f"{position_name}: take_profit must be a float or int, got {type(data.get('take_profit'))} instead"
        )
    if data.get("trail_stop") is not None and not isinstance(
        data.get("trail_stop"), (float, int)
    ):
        logger.warning(
            f"{position_name}: trail_stop must be a float or int, got {type(data.get('trail_stop'))} instead"
        )


def replace_inf_nan(data: Any) -> Any:
    if isinstance(data, float):
        if math.isinf(data) or math.isnan(data):
            return None
        return data
    if isinstance(data, dict):
        return {k: replace_inf_nan(v) for k, v in data.items()}
    if isinstance(data, list):
        return [replace_inf_nan(item) for item in data]
    if isinstance(data, tuple):
        return tuple(replace_inf_nan(item) for item in data)
    if isinstance(data, set):
        return {replace_inf_nan(item) for item in data}
    return data


class PortfolioSyncManager:
    """
    投資組合類別，用於設定和獲取投資組合資訊。

    Attributes:
        path (str): 投資組合資訊的儲存路徑。

    Methods:
        __init__(self, path=None): 初始化投資組合類別。
        set(self, portfolio:dict[str, tuple[int, Report]]): 設定投資組合的函數。
        get_position(self, combined=True): 獲取持倉資訊。

    Examples:
        ```py
        from finlab.portfolio import Portfolio, PortfolioSyncManager

        # 初始化投資組合
        port = Portfolio({'策略A': (report1, 0.3), '策略B': (report2, 0.7)})

        # 設定投資組合
        # pm = PortfolioSyncManager.from_local() or
        # pm = PortfolioSyncManager.from_cloud()
        pm = PortfolioSyncManager()
        pm.update(port, total_balance=1000000)
        pm.to_cloud() # pm.to_local()

        print(pm)

        # 下單
        account = ... # 請參考 Account 產生方式
        pm.sync(account) # 平盤價格下單
        ```
    """

    LOCAL_DIR: ClassVar[str] = os.path.join(get_tmp_dir(), "workspace")
    CLOUD_URL: ClassVar[str] = (
        "https://asia-east2-fdata-299302.cloudfunctions.net/auth_portfolio"
    )

    @staticmethod
    def _normalize_data_payload(data: dict[str, Any] | None) -> dict[str, Any]:
        if data is None:
            return {"position": {}, "history": {}, "market": None, "config": {}}

        payload = copy.deepcopy(data)
        payload.setdefault("position", {})
        payload.setdefault("history", {})
        payload.setdefault("config", {})
        return payload

    def __init__(
        self, data: dict[str, Any] | None = None, start_with_empty: bool = False
    ) -> None:
        """建構投資組合。"""

        normalized_data = self._normalize_data_payload(data)

        if "position" in normalized_data:
            for k, v in normalized_data["position"].items():
                position_type_check(k, v)

        self.data: dict[str, Any] = normalized_data
        self._start_with_empty: bool = start_with_empty

    @classmethod
    def _get_local_path(cls, name: str) -> str:
        if not os.path.exists(cls.LOCAL_DIR):
            os.makedirs(cls.LOCAL_DIR)
        return os.path.join(cls.LOCAL_DIR, f"{name}.position.json")

    @classmethod
    def from_local(cls, name: str = "default") -> PortfolioSyncManager:
        """
        從本地檔案初始化投資組合。

        Args:
            path (str): 本地檔案的路徑。

        Returns:
            PortfolioSyncManager: 投資組合類別。
        """
        path = cls._get_local_path(name)

        if not os.path.exists(path):
            raise FileNotFoundError(f"path {path} not existed")

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        return cls(data)

    @classmethod
    def from_cloud(cls, name: str = "default") -> PortfolioSyncManager:
        """
        從雲端檔案初始化投資組合。

        Args:
            path (str, optional): 雲端檔案的路徑。預設為 'default'。

        Returns:
            PortfolioSyncManager: 投資組合類別。
        """
        res = requests.post(
            cls.CLOUD_URL,
            params={"pid": name, "api_token": finlab.get_token(), "action": "get"},
            timeout=30,
        )

        data = res.json()

        if data is None:
            raise FileNotFoundError(f"path {name} not existed")

        return cls(data)

    @classmethod
    def from_path(cls, path: str) -> PortfolioSyncManager:
        """
        從本地檔案初始化投資組合。

        Args:
            path (str): 本地檔案的路徑。

        Returns:
            PortfolioSyncManager: 投資組合類別。
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"path {path} not existed")

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        return cls(data)

    def to_local(self, name: str = "default") -> None:
        """
        將投資組合資訊存至本地檔案。

        Returns:
            None
        """
        path = self._get_local_path(name)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=4, default=str)

    def to_cloud(self, name: str = "default") -> requests.Response:
        """
        將投資組合資訊存至雲端檔案。

        Returns:
            None
        """
        return requests.post(
            self.CLOUD_URL,
            params={"pid": name, "api_token": finlab.get_token(), "action": "set"},
            json=replace_inf_nan(self.data),
            timeout=30,
        )

    def to_path(self, path: str) -> None:
        """
        將投資組合資訊存至本地檔案。

        Returns:
            None
        """
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=4, default=str)

    def get_data(self, typed: bool = False) -> dict[str, Any]:
        if is_typed_strict_mode() and not typed:
            return self.get_data_typed()
        if typed:
            return self.get_data_typed()
        return copy.deepcopy(self.data)

    def set_data(
        self, data: dict[str, Any] | Any, typed: bool = False
    ) -> PortfolioSyncManager:
        if is_typed_strict_mode() and not typed:
            raise ValueError(
                "strict mode requires typed data input; use set_data_typed() or set_data(..., typed=True)"
            )

        if typed:
            return self.set_data_typed(data)

        if not isinstance(data, dict):
            raise ValueError(f"data should be dict, got {type(data)}")

        normalized_data = self._normalize_data_payload(data)
        for k, v in normalized_data.get("position", {}).items():
            position_type_check(k, v)

        self.data = normalized_data
        return self

    def get_data_typed(self) -> PortfolioData:
        from finlab.schemas import PortfolioData

        return PortfolioData.from_dict(copy.deepcopy(self.data))

    def set_data_typed(self, data: dict[str, Any] | Any) -> PortfolioSyncManager:
        from finlab.schemas import PortfolioData

        if isinstance(data, dict):
            payload = PortfolioData.from_dict(copy.deepcopy(data)).to_dict()
        elif hasattr(data, "to_dict"):
            payload = data.to_dict()
        else:
            raise ValueError("data should be dict or schema object with to_dict()")

        normalized_data = self._normalize_data_payload(payload)
        for k, v in normalized_data.get("position", {}).items():
            position_type_check(k, v)

        self.data = normalized_data
        return self

    @staticmethod
    def _calc_position_value(
        position: list[dict[str, Any]], lot: float, price: pd.Series
    ) -> float:
        ret = 0

        for p in position:
            sid = resolve_position_entry_symbol(p)
            if sid in price:
                num = float(p["quantity"]) * float(price[sid]) * lot
                if not math.isnan(num):
                    ret += num
                else:
                    logger.warning(
                        f'price of {sid} is {price[sid]}, quantity is {p["quantity"]}'
                    )
            else:
                raise ValueError(f"stock {sid} not found")

        return ret

    def update_same_config(self, portfolio: Portfolio) -> None:
        if "config" not in self.data:
            raise ValueError("config not found")

        params = self.data["config"]["params"]
        kwargs = params.pop("kwargs", {})
        params |= kwargs

        self.update(portfolio, **params)

    def update(
        self,
        portfolio: Portfolio,
        total_balance: float = 0,
        rebalance_safety_weight: float = 0.2,
        smooth_transition: bool | None = None,
        force_override_difference: bool = False,
        custom_position: Position | dict[str, Any] | None = None,
        excluded_stock_ids: list[str] | None = None,
        excluded_symbols: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """
        設定投資組合的函數。

        Args:
            portfolio (Portfolio): 包含投資組合資訊的字典。
            total_balance (float): 總資產。
            rebalance_safety_weight (float): 現金的權重，確保以市價買賣時，新的策略組合價值不超過舊的價值，計算方式為：賣出股票後，有多少比例要變成現金(例如 20％)，再買入新的股票。
            smooth_transition (bool): 是否只在換股日才更新，預設為 None，系統會自行判斷，假如第一次呼叫函示，會是 False，之後會是 True。
            force_override_difference (bool): 是否強制覆蓋不同的部位，預設為 False。
            custom_position (Position or dict): 自定義部位，預設為 None。當 custom_position 不為 None 時，會將 custom_position 加入到部位中。程式在計算部位時，會將 custom_position 排除在外，不列入。
            excluded_stock_ids (list[str], optional): 排除的股票代碼列表。預設為 None。

        Returns:
            None

        Examples:
            ```py
            from finlab.backtest import sim
            from finlab.portfolio import Portfolio, OnlineReport

            # create report 1
            report1 = sim(...) # 請參考回測語法

            # download online report
            report2 = OnlineReport.from_cloud('strategyName') # 下載策略報告

            # create portfolio
            portfolio = Portfolio({'策略1': (report1, 0.5), '策略2': (report2, 0.5)})

            # create PortfolioSyncManager
            pm = PortfolioSyncManager.from_cloud()
            pm.update(portfolio, total_balance=1000000, cash_weight=0.2) # 投資 100 萬元

            # create orders
            account = ... # 請參考 Account 產生方式
            pm.sync(account) # 平盤價格下單
            pm.sync(account, market_order=True) # 市價下單
            ```
        """

        # check the type is portfolio
        if not isinstance(portfolio, Portfolio):
            if isinstance(portfolio, Report):
                portfolio = Portfolio(portfolio)
            else:
                raise ValueError(
                    f"portfolio should be Portfolio or Report object, got {type(portfolio)}"
                )

        if hasattr(portfolio, "position_schedulers"):
            execution_map = portfolio.position_schedulers
        elif hasattr(portfolio, "execution"):
            execution_map = portfolio.execution
        else:
            execution_map = {}
        if not isinstance(execution_map, dict):
            execution_map = {"strategy": execution_map}

        # update config
        self.data["config"] = {
            "weights": {
                k.split("|")[0]: v.total_weight for k, v in execution_map.items()
            },
            "params": {
                "total_balance": total_balance,
                "rebalance_safety_weight": rebalance_safety_weight,
                "smooth_transition": smooth_transition,
                "force_override_difference": force_override_difference,
                "kwargs": kwargs,
            },
        }

        if custom_position:
            if isinstance(custom_position, dict):
                custom_position = Position(custom_position).to_list()
            elif isinstance(custom_position, Position):
                custom_position = custom_position.to_list()
            else:
                raise ValueError(
                    f"custom_position should be Position or dict object, got {type(custom_position)}"
                )
            self.data["config"]["custom_position"] = custom_position

        _excluded = excluded_symbols or excluded_stock_ids
        if _excluded:
            self.data["config"]["excluded_stock_ids"] = _excluded

        portfolio = execution_map

        # check the file exists
        position = self.data["position"]
        history = self.data["history"]
        now = datetime.datetime.now().astimezone()

        if smooth_transition is None:
            if not position and not history and not self._start_with_empty:
                smooth_transition = False
            else:
                smooth_transition = True

        removed_position: list[str] = []

        for sid in position:
            if sid not in portfolio or portfolio[sid].total_weight == 0:
                logger.info(f"remove {sid} from portfolio")
                removed_position.append(sid)

        for sid in removed_position:
            history.setdefault(sid, []).append(position[sid])
            position.pop(sid)

        #####################################
        # Identify strategies to update
        #####################################
        updated_strategies: list[str] = []
        for sid, allocation in portfolio.items():
            market = allocation.market
            weight = allocation.total_weight

            if weight == 0 and sid not in position:
                continue

            weight_is_updated = sid not in position or weight != position[sid]["weight"]
            is_trading_date = allocation.is_rebalance_due()

            update_conditions = [
                (is_trading_date, "today is trading date"),
                (
                    not smooth_transition and weight_is_updated,
                    "weight changed (set smooth_transition=True to avoid this)",
                ),
            ]

            if any(flag for flag, _ in update_conditions):
                logger.info(
                    f"{sid} should be updated because: "
                    + ", ".join(reason for (flag, reason) in update_conditions if flag)
                )
                updated_strategies.append(sid)

            if smooth_transition and weight_is_updated:
                logger.info(
                    f"{sid} weight changed, but not updated because smooth_transition is enabled. It will be updated when next rebalance date comes."
                )
                logger.info(
                    "If you want to update the weight immediately, set smooth_transition=False"
                )

        #####################################
        # Check the position is the same
        #####################################
        for sid, info in position.items():
            if sid in updated_strategies:
                continue

            if sid not in portfolio:
                logger.warning(f"{sid} not in portfolio")
                continue

            # check if the current stock list is the same
            position_sids = sorted(
                [resolve_position_entry_symbol(p) for p in info["position"]]
            )
            report = portfolio[sid]
            report_ids = [
                s.split(" ")[0] for s in sorted(report.weights.index.tolist())
            ]

            # check position_ids is a subset of report_ids
            if not all(s in report_ids for s in position_sids):
                logger.warning(f"{sid} has changed stock list")
                logger.warning(f"current: {position_sids}")
                logger.warning(f"report: {report_ids}")

                if force_override_difference:
                    logger.warning("force override")
                    updated_strategies.append(sid)
                else:
                    logger.warning("please set force_override=True to override")

        #####################################
        # Update position
        #####################################
        asset_value = 0
        total_update_weight = 0

        for sid in updated_strategies:
            total_update_weight += portfolio[sid].total_weight

        # compute current asset value per strategy's market
        for sid, info in position.items():
            if sid not in updated_strategies:
                try:
                    sid_market = (
                        get_market_by_name(info.get("market"))
                        if "market" in info
                        else None
                    )
                    if sid_market is None:
                        sid_market = (
                            portfolio[sid].market if sid in portfolio else TWMarket()
                        )
                except Exception:
                    sid_market = TWMarket()
                sid_lot = sid_market.get_odd_lot()
                sid_price = sid_market.get_price("close", adj=False).ffill().iloc[-1]
                asset_value += self._calc_position_value(
                    info["position"], lot=sid_lot, price=sid_price
                )

        liquid_value = min(
            total_balance - asset_value, total_update_weight * total_balance
        )
        rebalance_safety_fund = liquid_value * rebalance_safety_weight
        cash = total_balance - asset_value - liquid_value
        free_value = max(liquid_value - max(0, rebalance_safety_fund - cash), 0)

        display_info = {
            "投資總額": total_balance,
            "預計股票價值": asset_value,
            "預計賣出後流動資金": liquid_value,
            "預計保留現金": rebalance_safety_fund,
            "預計可買入金額": free_value,
        }

        # pretty print the display info
        for k, v in display_info.items():
            pct = (v / total_balance * 100) if total_balance else 0
            logger.info("%s: %d (%.2f%%)", k, int(v), pct)

        # Save old positions before rebuilding so stop trigger logic can reference them
        old_positions = {
            sid: position[sid].copy() for sid in updated_strategies if sid in position
        }
        for pos in old_positions.values():
            pos["position"] = [p.copy() for p in pos.get("position", [])]

        for sid in updated_strategies:
            allocation = portfolio[sid]

            if not isinstance(allocation, PositionScheduler):
                raise ValueError(
                    f"portfolio[{sid}] should be PositionScheduler, got {type(allocation)}"
                )

            weight = allocation.total_weight
            report = allocation

            fund = (
                free_value * weight / total_update_weight
                if total_update_weight != 0
                else 0
            )

            # calc next trading time
            next_trading_time = report.market.market_close_at_timestamp(
                report.next_trading_date
            )

            market = allocation.market
            last_market_timestamp = market.market_close_at_timestamp(
                market.get_price("close").index[-1]
            )

            try:
                pos = Position.from_report(allocation, fund, **kwargs).to_list()
            except AssertionError as e:
                logger.warning(
                    f"Cannot create position for {sid}, because {e}"
                    "Set the position to zero."
                )

                pos: list[Any] = []

            if sid in position:
                history[sid] = history.get(sid, [])

                while (
                    history[sid]
                    and history[sid][-1]["next_trading_time"]
                    == next_trading_time.isoformat()
                ):
                    history[sid].pop()

                history[sid].append(position[sid])

            position[sid] = {
                "timestamp": now.isoformat(),
                "next_trading_time": next_trading_time.isoformat(),
                "position": pos,
                "allocation": fund,
                "weight": weight,
                "entry_at": report.trade_at
                if isinstance(report.trade_at, str)
                else "close",
                "exit_at": report.trade_at
                if isinstance(report.trade_at, str)
                else "close",
                "stop": [],
                "stop_loss": report.stop_loss,
                "take_profit": report.take_profit
                if report.take_profit == report.take_profit
                else None,
                "trail_stop": report.trail_stop
                if report.trail_stop == report.trail_stop
                else None,
                "market": allocation.market.get_name(),
                "last_market_timestamp": last_market_timestamp.isoformat(),
            }
            logger.info(f"update position {sid}")

        for sid, allocation in portfolio.items():
            if sid not in position:
                continue

            if not isinstance(allocation, PositionScheduler):
                raise ValueError(
                    f"portfolio[{sid}] should be PositionScheduler, got {type(allocation)}"
                )

            # Use old position if strategy was updated, otherwise use current position
            old_pos = old_positions.get(sid, {}).get("position")
            if old_pos is None:
                old_pos = position[sid].get("position", [])

            if allocation.is_stop_triggered():
                # find stock id of sl and tp and record stop info from old position
                for s in allocation.actions[
                    allocation.actions.isin(["sl_", "tp_", "sl", "tp"])
                ].index.tolist():
                    symbol = s.split(" ")[0]
                    for p in old_pos:
                        p_sid = resolve_position_entry_symbol(p)
                        if p_sid == symbol and p["quantity"] != 0:
                            logger.info(
                                f"{sid} {s} has a {allocation.actions[s]} signal, position set to zero"
                            )
                            stop_entry = p.copy()
                            stop_entry["timestamp"] = now.isoformat()
                            stop_entry["reason"] = allocation.actions.to_dict().get(s)
                            position[sid]["stop"].append(stop_entry)
                            # Also zero out the new position
                            for np_ in position[sid]["position"]:
                                np_sid = resolve_position_entry_symbol(np_)
                                if np_sid == symbol:
                                    np_["quantity"] = 0

            if allocation.actions.isin(["sl_enter", "tp_enter"]).any():
                next_trading_time = allocation.market.market_close_at_timestamp(
                    allocation.next_trading_date
                )
                if now < next_trading_time:
                    # find stock id of sl_enter and tp_enter and record stop info from old position
                    for s in allocation.actions[
                        allocation.actions.isin(["sl_enter", "tp_enter"])
                    ].index.tolist():
                        symbol = s.split(" ")[0]
                        for p in old_pos:
                            p_sid = resolve_position_entry_symbol(p)
                            if p_sid == symbol and p["quantity"] != 0:
                                logger.info(
                                    f"{sid} {s} has a {allocation.actions[s]} signal, position set to zero"
                                )
                                stop_entry = p.copy()
                                stop_entry["timestamp"] = now.isoformat()
                                stop_entry["reason"] = allocation.actions.to_dict().get(
                                    s
                                )
                                position[sid]["stop"].append(stop_entry)
                                # Also zero out the new position
                                for np_ in position[sid]["position"]:
                                    np_sid = resolve_position_entry_symbol(np_)
                                    if np_sid == symbol:
                                        np_["quantity"] = 0

    def get_last_market_timestamp(self) -> str | None:
        timestamps = [
            sdata.get("last_market_timestamp")
            for sdata in self.data["position"].values()
            if "last_market_timestamp" in sdata
        ]
        if not timestamps:
            return None
        return max(timestamps)

    def get_strategy_position(
        self, strategy_name: str, at: str
    ) -> list[dict[str, Any]]:
        """
        獲取策略的開倉部位。

        Args:
            strategy_name (str): 策略名稱。

        Returns:
            dict: 開倉部位資訊。
        """

        strategy_position = self.data["position"].get(strategy_name, {})

        # if trade at open, means close and open position are the same

        # TODO: filter the position is entry trade or exit trade
        # for now, we just assume the exit_at is the same as entry_at
        if strategy_position.get("entry_at", "close") != strategy_position.get(
            "exit_at", "close"
        ):
            raise ValueError("entry_at and exit_at difference is not supported")

        market = get_market_by_name(strategy_position["market"])

        has_market_timestamp = (
            strategy_position.get("last_market_timestamp") is not None
        )
        is_trade_at_open = strategy_position["entry_at"] == "open"
        last_market_timestamp_is_the_same = (
            strategy_position.get("last_market_timestamp")
            == market.market_close_at_timestamp(
                market.get_price("close").index[-1]
            ).isoformat()
        )

        latest_market_timestamp = self.get_last_market_timestamp()

        use_previous_position = (
            (at == "open")
            and has_market_timestamp
            and last_market_timestamp_is_the_same
            and not is_trade_at_open
        ) or (
            (at == "prev_close")
            and (
                latest_market_timestamp
                == strategy_position.get("last_market_timestamp")
            )
        )

        if not use_previous_position:
            return strategy_position["position"]

        # try to find the previous position,
        # since at the time of the next trading date, the position is not updated
        strategy_history = self.data["history"].get(strategy_name, [])
        if not strategy_history:
            return strategy_position["position"]

        if strategy_history[-1].get("last_market_timestamp") == strategy_position.get(
            "last_market_timestamp"
        ):
            if len(strategy_history) >= 2:
                return strategy_history[-2]["position"]
            return strategy_position["position"]
        return strategy_history[-1]["position"]

    def get_position(
        self, at: str = "close", market_name: str | None = None
    ) -> Position:
        """
        獲取持倉資訊。

        Args:
            market_name (str, optional): 指定市場名稱。預設為 None，也就是獲取所有市場。

        Returns:
            dict or Position: 若 combined 為 True，則返回合併後的持倉資訊（Position 物件）；
                                若 combined 為 False，則返回原始持倉資訊（dict）。
        """
        position = self.data["position"]
        positions = {
            pname: Position.from_list(self.get_strategy_position(pname, at))
            for pname in position
        }

        for pname, pos in positions.items():
            for p in pos:
                if "weight" in p and p["weight"] is not None:
                    p["weight"] *= self.data["position"][pname]["weight"]
                else:
                    p["weight"] = (
                        1 / len(pos.position) * self.data["position"][pname]["weight"]
                    )

        if market_name is not None:
            positions = {
                pname: pos
                for pname, pos in positions.items()
                if self.data["position"][pname]["market"] == market_name
            }

        ret = sum(list(positions.values()), Position({}))

        if "custom_position" in self.data["config"]:
            ret += Position.from_list(self.data["config"]["custom_position"])

        if "excluded_stock_ids" in self.data["config"]:
            excluded = self.data["config"]["excluded_stock_ids"]
            ret2: list[Any] = []
            for p in ret.position:
                p_sid = resolve_position_entry_symbol(p)
                if p_sid not in excluded:
                    ret2.append(p)
            ret = Position.from_list(ret2)

        return ret

    def clear(self) -> None:
        """
        清除持倉資訊。

        Returns:
            None
        """
        self.data = {"position": {}, "history": {}, "market": None, "config": {}}

    def sync(
        self,
        account: Account,
        at: str = "close",
        consider_margin_as_asset: bool = True,
        market_name: str | None = None,
        **kwargs: Any,
    ) -> OrderExecutor:
        """
        同步持倉資訊。

        Args:
            account (Account): 交易帳戶。
            consider_margin_as_asset (bool, optional): 是否將保證金交易視為資產。預設為 True。
            market_name (str, optional): 指定市場名稱。預設為 None，也就是獲取所有市場。
            market_order (bool): 以類市價盡量即刻成交：所有買單掛漲停價，所有賣單掛跌停價
            best_price_limit (bool): 掛芭樂價：所有買單掛跌停價，所有賣單掛漲停價
            view_only (bool): 預設為 False，會實際下單。若設為 True，不會下單，只會回傳欲執行的委託單資料(dict)
            extra_bid_pct (float): 以該百分比值乘以價格進行追價下單，如設定為 0.05 時，將以當前價的 +(-)5% 的限價進買入(賣出)，也就是更有機會可以成交，但是成交價格可能不理想；
                假如設定為 -0.05 時，將以當前價的 -(+)5% 進行買入賣出，也就是限價單將不會立即成交，然而假如成交後，價格比較理想。參數有效範圍為 -0.1 到 0.1 內。

        Returns:
            None
        """
        account_position = account.get_position()
        ideal_position = self.get_position(market_name=market_name, at=at)

        if consider_margin_as_asset:
            ideal_position = self.margin_cash_position_combine(
                account_position, ideal_position
            )

        oe = OrderExecutor(ideal_position, account)
        oe.create_orders(**kwargs)
        return oe

    def create_order_executor(
        self,
        account: Account,
        at: str = "close",
        consider_margin_as_asset: bool = False,
        market_name: str | None = None,
        **kwargs: Any,
    ) -> OrderExecutor:
        """
        同步持倉資訊。

        Args:
            account (Account): 交易帳戶。
            consider_margin_as_asset (bool, optional): 是否將融資融券視為資產。預設為 True。
            market_name (str, optional): 指定市場名稱。預設為 None，也就是獲取所有市場。
            market_order (bool): 以類市價盡量即刻成交：所有買單掛漲停價，所有賣單掛跌停價
            best_price_limit (bool): 掛芭樂價：所有買單掛跌停價，所有賣單掛漲停價
            view_only (bool): 預設為 False，會實際下單。若設為 True，不會下單，只會回傳欲執行的委託單資料(dict)
            extra_bid_pct (float): 以該百分比值乘以價格進行追價下單，如設定為 0.05 時，將以當前價的 +(-)5% 的限價進買入(賣出)，也就是更有機會可以成交，但是成交價格可能不理想；
                假如設定為 -0.05 時，將以當前價的 -(+)5% 進行買入賣出，也就是限價單將不會立即成交，然而假如成交後，價格比較理想。參數有效範圍為 -0.1 到 0.1 內。

        Returns:
            None
        """
        account_position = account.get_position()
        ideal_position = self.get_position(market_name=market_name, at=at)

        if consider_margin_as_asset:
            ideal_position = self.margin_cash_position_combine(
                account_position, ideal_position
            )

        return OrderExecutor(ideal_position, account)

    def get_total_position(self) -> pd.DataFrame:
        """
        回傳目前持倉的 DataFrame（與 __repr__ 顯示的 df 相同）。

        Returns:
            pd.DataFrame: 持倉資訊的 DataFrame。
        """
        p = self.get_position()

        market = TWMarket()
        ref_price = market.get_reference_price()
        close_price = market.get_price("close", adj=False).iloc[-1].to_dict()
        volume = market.get_price("volume", adj=False).iloc[-1].to_dict()
        total_allocation = sum(
            [v["allocation"] for v in self.data["position"].values()]
        )

        pos = copy.deepcopy(self.data["position"])
        has_strategy: dict[tuple[str, Any], str] = {}
        for name, info in pos.items():
            for stock in info["position"]:
                s_id = resolve_position_entry_symbol(stock)
                key = (s_id, stock["order_condition"])
                if key not in has_strategy:
                    has_strategy[key] = name
                else:
                    has_strategy[key] += "," + name

        if "custom_position" in self.data["config"]:
            for stock in self.data["config"]["custom_position"]:
                s_id = resolve_position_entry_symbol(stock)
                key = (s_id, stock["order_condition"])
                if key not in has_strategy:
                    has_strategy[key] = "custom"
                else:
                    has_strategy[key] += ",custom"

        if p.position:
            df = (
                pd.DataFrame(p.position)
                .pipe(
                    lambda df: df.assign(
                        strategy=df.apply(
                            lambda r: has_strategy.get(
                                (resolve_position_entry_symbol(r), r.order_condition),
                                "",
                            ),
                            axis=1,
                        )
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        type=df.order_condition.map(lambda v: OrderCondition(v).name)
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        price=df.symbol.map(lambda i: ref_price.get(i, 0))
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        weight=df.symbol.map(lambda i: close_price.get(i, 0))
                        * df.quantity
                        / total_allocation
                        * 1000
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        close_price=df.symbol.map(lambda i: close_price.get(i, 0))
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        volume=df.symbol.map(lambda i: volume.get(i, 0) / 1000)
                    )
                )[
                    [
                        "symbol",
                        "quantity",
                        "price",
                        "weight",
                        "close_price",
                        "volume",
                        "strategy",
                        "type",
                    ]
                ]
                .sort_values("symbol")
                .set_index("symbol")
            )

            has_odd_lot = (
                df["quantity"].round(0) - df["quantity"]
            ).abs().sum() > _ODD_LOT_TOLERANCE
            if has_odd_lot:
                df["quantity"] = df["quantity"].map(lambda x: f"{x:.3f}")
        else:
            df = pd.DataFrame()

        return df

    def __repr__(self) -> str:
        p = self.get_position()

        pd.set_option("display.max_rows", None)
        pd.set_option("display.float_format", "{:.2f}".format)

        market = TWMarket()

        ref_price = market.get_reference_price()
        close_price = market.get_price("close", adj=False).iloc[-1].to_dict()
        volume = market.get_price("volume", adj=False).iloc[-1].to_dict()

        total_allocation = sum(
            [v["allocation"] for v in self.data["position"].values()]
        )

        pos = copy.deepcopy(self.data["position"])
        has_strategy = {}  # key: (symbol, order_condition), value: str of strategies
        for name, info in pos.items():
            for stock in info["position"]:
                s_id = resolve_position_entry_symbol(stock)
                if (s_id, stock["order_condition"]) not in has_strategy:
                    has_strategy[(s_id, stock["order_condition"])] = name
                else:
                    has_strategy[(s_id, stock["order_condition"])] += "," + name

        if "custom_position" in self.data["config"]:
            for stock in self.data["config"]["custom_position"]:
                s_id = resolve_position_entry_symbol(stock)
                if (s_id, stock["order_condition"]) not in has_strategy:
                    has_strategy[(s_id, stock["order_condition"])] = "custom"
                else:
                    has_strategy[(s_id, stock["order_condition"])] += ",custom"

        if p.position:
            df = (
                pd.DataFrame(p.position)
                .pipe(
                    lambda df: df.assign(
                        strategy=df.apply(
                            lambda r: has_strategy.get(
                                (resolve_position_entry_symbol(r), r.order_condition),
                                "",
                            ),
                            axis=1,
                        )
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        type=df.order_condition.map(lambda v: OrderCondition(v).name)
                    )
                )
            )

            df = (
                df.pipe(
                    lambda df: df.assign(
                        price=df.symbol.map(lambda i: ref_price.get(i, 0))
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        weight=df.symbol.map(lambda i: close_price.get(i, 0))
                        * df.quantity
                        / total_allocation
                        * 1000
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        close_price=df.symbol.map(lambda i: close_price.get(i, 0))
                    )
                )
                .pipe(
                    lambda df: df.assign(
                        volume=df.symbol.map(lambda i: volume.get(i, 0) / 1000)
                    )
                )[
                    [
                        "symbol",
                        "quantity",
                        "price",
                        "weight",
                        "close_price",
                        "volume",
                        "strategy",
                        "type",
                    ]
                ]
                .sort_values("symbol")
                .set_index("symbol")
            )

            has_odd_lot = (
                df["quantity"].round(0) - df["quantity"]
            ).abs().sum() > _ODD_LOT_TOLERANCE
            if has_odd_lot:
                df["quantity"] = df["quantity"].map(lambda x: f"{x:.3f}")

        else:
            df = pd.DataFrame()

        if len(df) != 0:
            ret = f"Estimate value {int((df.price.astype(float) * df.quantity.astype(float) * 1000).sum())}"
        else:
            ret = "Position"

        # add ret string as the title of df
        # show strategies info
        strategy_info: dict[str, Any] = {}
        for name, strategy in pos.items():
            strategy.pop("position")

            # replace key timestamp to updated
            strategy["updated"] = strategy["timestamp"]
            strategy.pop("timestamp")

            # replace next_trading_time to expired
            strategy["rebalance_after"] = strategy["next_trading_time"]
            strategy.pop("next_trading_time")

            # replace value 1 to 'None' for stop_loss
            strategy["stop_loss"] = (
                strategy["stop_loss"] if strategy["stop_loss"] != 1 else "None"
            )

            # replace value inf to 'None' for take_profit
            strategy["take_profit"] = (
                strategy["take_profit"]
                if strategy["take_profit"] != float("inf")
                else "None"
            )

            # replace value inf to 'None' for trail_stop
            strategy["trail_stop"] = (
                strategy["trail_stop"]
                if strategy["trail_stop"] != float("inf")
                else "None"
            )

            # simplify str '2024-04-10T18:39:33.032248+00:00' format to %Y-%m-%d %H%m for updated and expiry
            strategy["updated"] = pd.to_datetime(strategy["updated"]).strftime(
                "%Y-%m-%d %H:%M"
            )
            strategy["rebalance_after"] = pd.to_datetime(
                strategy["rebalance_after"]
            ).strftime("%Y-%m-%d %H:%M")

            # make allocation to int
            strategy["allocation"] = int(strategy["allocation"])

            strategy_info[name] = strategy

        if strategy_info:
            df2 = (
                pd.DataFrame(strategy_info)
                .loc[
                    [
                        "allocation",
                        "weight",
                        "updated",
                        "stop_loss",
                        "take_profit",
                        "trail_stop",
                        "entry_at",
                        "exit_at",
                    ]
                ]
                .T
            )

            alloc_sum = self.data["config"]["params"]["total_balance"]

            df2["weight"] = (
                (df2.allocation / alloc_sum).map("{:.2%}".format)
                + "/"
                + df2["weight"].map("{:.2%}".format)
                if alloc_sum != 0
                else "0.00%"
            )
        else:
            df2 = pd.DataFrame()

        ret = (
            ret + "\n\n" + df.to_string() + "\n\n\n" + "strategy\n\n" + df2.to_string()
        )
        pd.reset_option("display.max_rows")
        pd.reset_option("display.float_format")
        return ret

    @staticmethod
    def margin_cash_position_combine(acp: Position, idp: Position) -> Position:
        """
        合併現金與保證金部位。

        Args:
            acp (Position): 當前帳戶的股票部位。
            idp (Position): 新的帳戶的股票部位。
        """

        diff = idp - acp

        cash = {
            resolve_position_entry_symbol(p): p.copy()
            for p in diff.position
            if p["order_condition"] == OrderCondition.CASH
        }
        margin_trading = {
            resolve_position_entry_symbol(p): p.copy()
            for p in diff.position
            if p["order_condition"] == OrderCondition.MARGIN_TRADING
        }

        # cancel negative direction amount
        sids = cash.keys() | margin_trading.keys()
        for sid in sids:
            if not (sid in cash and sid in margin_trading):
                continue

            if cash[sid]["quantity"] * margin_trading[sid]["quantity"] < 0:
                reduce_amount = min(
                    abs(cash[sid]["quantity"]), abs(margin_trading[sid]["quantity"])
                )

                # reduce toward zero
                if cash[sid]["quantity"] > 0:
                    cash[sid]["quantity"] -= reduce_amount
                    margin_trading[sid]["quantity"] += reduce_amount
                else:
                    cash[sid]["quantity"] += reduce_amount
                    margin_trading[sid]["quantity"] -= reduce_amount

        newdiff = [p for p in cash.values() if p["quantity"] != 0] + [
            p for p in margin_trading.values() if p["quantity"] != 0
        ]
        newdiff = Position.from_list(newdiff)
        return idp - diff + newdiff

    def compare(self, account: Account) -> None:
        # compare stock assets
        self.get_position()
        account.get_position()
