from __future__ import annotations

import base64
import datetime
import gzip
import json
import logging
from typing import TYPE_CHECKING, Any, NoReturn

__all__ = ["CloudReport", "create_report_from_cloud"]

import pandas as pd
import requests

import finlab
from finlab.core import firestore_rest
from finlab.core.report import Report, ReportExecution
from finlab.markets.tw import TWMarket
from finlab.portfolio.portfolio import PositionScheduler

from .utils import validate_structure

if TYPE_CHECKING:
    from finlab.market import Market

logger = logging.getLogger(__name__)


def create_report_from_cloud(
    strategy_id: str, user_id: str | None = None, market: Market | None = None
) -> CloudReport:
    """根據提供的用戶ID和策略ID創建在線報告。
    Create an online report based on the user id and strategy id provided.


    Args:
        user_id (str): The user id.
        strategy_id (str): The
    """

    return CloudReport.from_cloud(strategy_id, user_id, market)


class CloudReport(Report):
    @staticmethod
    def _extract_report_data(sdata: Any) -> dict[str, Any]:
        if not isinstance(sdata, dict):
            return sdata

        if all(k in sdata for k in ("returns", "metrics", "trades")):
            return sdata

        if "report" in sdata and isinstance(sdata["report"], dict):
            report_payload = sdata["report"]
            if all(
                k in report_payload
                for k in ("timestamps", "strategy", "metrics", "trades")
            ):
                return {
                    "returns": {
                        "time": report_payload["timestamps"],
                        "value": report_payload["strategy"],
                    },
                    "metrics": report_payload["metrics"],
                    "trades": report_payload["trades"],
                }
        return sdata

    @staticmethod
    def _extract_execution_data(
        pdata: dict[str, Any] | list[Any],
    ) -> dict[str, Any] | list[Any]:
        if isinstance(pdata, dict):
            if "execution" in pdata:
                return pdata["execution"]
            if "payload_v1" in pdata and isinstance(pdata["payload_v1"], dict):
                payload_execution = pdata["payload_v1"].get("execution")
                if payload_execution is not None:
                    return payload_execution
            if "position2" in pdata:
                return pdata["position2"]
            if "position" in pdata:
                return pdata["position"]
        return pdata

    @staticmethod
    def _extract_legacy_position_data(
        pdata: dict[str, Any], execution_data: dict[str, Any] | list[Any]
    ) -> dict[str, Any]:
        if isinstance(pdata, dict):
            if "position2" in pdata:
                return pdata["position2"]
            if (
                "position" in pdata
                and isinstance(pdata["position"], dict)
                and "positionConfig" in pdata["position"]
            ):
                return pdata["position"]
            if "positionConfig" in pdata:
                return pdata
        execution = ReportExecution.from_json(execution_data)
        if execution is None:
            return {"positions": [], "positionConfig": {}}
        legacy_position = ReportExecution.to_legacy_position_info2_collection(execution)
        return (
            legacy_position
            if legacy_position is not None
            else {"positions": [], "positionConfig": {}}
        )

    @property
    def position_schedulers(self) -> PositionScheduler | dict[str, PositionScheduler]:
        return self.execution

    @position_schedulers.setter
    def position_schedulers(
        self, value: PositionScheduler | dict[str, PositionScheduler]
    ) -> None:
        self.execution = value

    def __init__(
        self, sdata: dict[str, Any], pdata: dict[str, Any], market: Market | None = None
    ) -> None:
        """
        sdata: dict
        pdata: dict
        """

        sdata = self._extract_report_data(sdata)
        execution_data = self._extract_execution_data(pdata)

        # mind user about this is the beta version
        logger.info(
            "OnlineReport is in beta version, please report any issue to FinLab Team at https://discord.gg/tAr4ysPqvR"
        )

        required_sdata_structure = {
            "returns": {"value": [int, float], "time": [str]},
            "metrics": {
                "backtest": {
                    "feeRatio": (int, float),
                    "taxRatio": (int, float),
                    "tradeAt": str,
                    "nextTradingDate": (int, float),
                    "market": str,
                    "livePerformanceStart": (int, float),
                    "stopLoss": (int, float, type(None)),
                    "takeProfit": (int, float, type(None)),
                    "trailStop": (int, float, type(None)),
                    "freq": str,
                }
            },
            "trades": str,
        }

        validate_structure(sdata, required_sdata_structure)

        self.creturn: pd.Series = pd.Series(
            sdata["returns"]["value"], pd.to_datetime(sdata["returns"]["time"])
        )
        self.fee_ratio: int | float = sdata["metrics"]["backtest"]["feeRatio"]
        self.tax_ratio: int | float = sdata["metrics"]["backtest"]["taxRatio"]
        self.trade_at: str = sdata["metrics"]["backtest"]["tradeAt"]
        self.last_trading_date: datetime.datetime = datetime.datetime.fromtimestamp(
            sdata["metrics"]["backtest"]["nextTradingDate"]
        )

        if market is None:
            cloud_market = sdata["metrics"]["backtest"].get("market")
            if cloud_market in {"tw_stock", "auto", None}:
                market = TWMarket()

        if market is None:
            raise ValueError("Market is not provided. Please provide a market object.")

        self.market: Market = market

        trades = self.reverse_trades(sdata["trades"])

        def _ts_to_dt(t: float | None) -> datetime.datetime | pd.NaTType:
            if t is None or pd.isna(t):
                return pd.NaT
            return datetime.datetime.fromtimestamp(t / 1000)

        for col in ("entry_date", "entry_sig_date", "exit_date", "exit_sig_date"):
            trades[col] = pd.to_datetime(trades[col].map(_ts_to_dt))
        trades.index.name = "trade_index"

        super().__init__(
            self.creturn,
            pd.DataFrame(0, index=self.creturn.index, columns=["1", "2"]),
            self.fee_ratio,
            self.tax_ratio,
            self.trade_at,
            self.last_trading_date,
            self.market,
        )

        self.trades: pd.DataFrame = trades

        if (
            "livePerformanceStart" in sdata["metrics"]["backtest"]
            and sdata["metrics"]["backtest"]["livePerformanceStart"] is not None
        ):
            self.live_performance_start: datetime.datetime | None = (
                datetime.datetime.fromtimestamp(
                    sdata["metrics"]["backtest"]["livePerformanceStart"]
                )
            )
        else:
            self.live_performance_start = None

        self.stop_loss: int | float | None = sdata["metrics"]["backtest"]["stopLoss"]
        self.take_profit: int | float | None = sdata["metrics"]["backtest"][
            "takeProfit"
        ]
        self.trail_stop: int | float | None = sdata["metrics"]["backtest"]["trailStop"]
        self.resample: str = sdata["metrics"]["backtest"]["freq"]
        self.pdata: dict[str, Any] = self._extract_legacy_position_data(
            pdata, execution_data
        )
        # Propagate updated_at → positionConfig.created so callers that
        # build a CloudReport directly from canonical data (not via
        # from_cloud) also get the field downstream code relies on.
        updated_at = pdata.get("updated_at") if isinstance(pdata, dict) else None
        if updated_at is not None and isinstance(self.pdata, dict):
            pc = self.pdata.get("positionConfig")
            if isinstance(pc, dict) and "created" not in pc:
                pc["created"] = updated_at
        self.sdata: dict[str, Any] = sdata
        execution = PositionScheduler.from_json(execution_data)
        if execution is None:
            execution = ReportExecution.from_report(self, total_weight=1.0)
        self.position_schedulers = execution

    def contains_multiple_strategies(self) -> bool:
        return isinstance(self.execution, dict)

    def is_rebalance_due(self) -> bool:
        if self.contains_multiple_strategies():
            return any(v.is_rebalance_due() for v in self.execution.values())

        return self.execution.is_rebalance_due()

    def is_stop_triggered(self) -> bool:
        if self.contains_multiple_strategies():
            return any(v.is_stop_triggered() for v in self.execution.values())

        return self.execution.is_stop_triggered()

    def get_metrics(self) -> dict[str, Any]:
        return self.sdata["metrics"]

    def position_info2(self) -> dict[str, Any]:
        return self.pdata

    def reverse_trades(self, gzip_b64_str: str) -> pd.DataFrame:
        """Reverse trades from gzip_b64_str"""

        # Decode base64 string to gzip bytes
        gzip_bytes = base64.b64decode(gzip_b64_str)

        # Decompress gzip bytes to JSON bytes
        json_bytes = gzip.decompress(gzip_bytes)

        # Decode JSON bytes to JSON string
        json_str = json_bytes.decode("utf-8")

        # Convert JSON string to DataFrame
        return pd.DataFrame(json.loads(json_str))

    @classmethod
    def from_cloud(
        cls, strategy_id: str, user_id: str | None = None, market: Market | None = None
    ) -> CloudReport:
        token, token_type = finlab.get_token()

        if token_type == "id_token":
            resolved_uid = user_id or firestore_rest.extract_uid_from_id_token(token)
            if resolved_uid:
                try:
                    canonical = firestore_rest.get_document(
                        f"users/{resolved_uid}/reports/{strategy_id}",
                        token,
                    )
                    if canonical:
                        payload = Report.from_payload_dict(canonical)
                        report_payload = payload.get("report")
                        execution_payload = payload.get("execution")
                        if report_payload is not None and execution_payload is not None:
                            report = cls(
                                {"report": report_payload},
                                {"execution": execution_payload},
                                market,
                            )
                            # Inject updated_at from canonical doc into
                            # positionConfig.created so downstream code that
                            # relies on this field (e.g. freshness checks)
                            # keeps working after the Firestore migration.
                            updated_at = canonical.get("updated_at")
                            if updated_at is not None and isinstance(
                                report.pdata, dict
                            ):
                                pc = report.pdata.get("positionConfig")
                                if isinstance(pc, dict) and "created" not in pc:
                                    pc["created"] = updated_at
                            return report
                        logger.debug(
                            f"Canonical report payload incomplete for {strategy_id}; falling back to legacy"
                        )
                except Exception as e:
                    logger.debug(
                        f"Canonical report lookup failed for {strategy_id}: {e}"
                    )

        url = "https://asia-east2-fdata-299302.cloudfunctions.net/auth_get_strategy"
        params = {
            token_type: token,
            "sid": strategy_id,
            "uid": user_id,
        }

        if user_id is None:
            del params["uid"]

        res = requests.get(url, params)

        if res.status_code != 200:
            raise RuntimeError(res.text)

        data = json.loads(res.text)

        if not data:
            raise ValueError("No strategy found")

        pdata = data["position"]
        sdata = data["strategy"]

        if pdata is None:
            raise ValueError(f"No strategy {strategy_id} found")

        return cls(sdata, pdata, market)

    def upload(self, *args: Any, **kwargs: Any) -> NoReturn:
        raise NotImplementedError(
            "This method is not implemented (since it is not needed)"
        )
