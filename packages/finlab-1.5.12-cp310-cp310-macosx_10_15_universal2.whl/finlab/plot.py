from __future__ import annotations

import ast
import itertools
import operator
from typing import TYPE_CHECKING, Any, Final, TypeAlias

__all__ = [
    "StrategyReturnStats",
    "StrategySunburst",
    "plot_candles",
    "plot_tw_stock_candles",
    "plot_tw_stock_radar",
    "plot_tw_stock_river",
    "plot_tw_stock_treemap",
]

from collections.abc import Callable

if TYPE_CHECKING:
    from collections.abc import Generator, Sequence

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# A single indicator: DataFrame, Series, ndarray, column name, or a callable returning one of those.
IndicatorSpec: TypeAlias = (
    pd.DataFrame
    | pd.Series
    | np.ndarray
    | str
    | Callable[[pd.DataFrame], pd.DataFrame | pd.Series | np.ndarray]
)

from finlab import data
from finlab.compat import param_alias, resolve_id_column
from finlab.utils import logger

_PLOTLY_PALETTE: Final[list[str]] = px.colors.qualitative.Plotly
_YI: Final[int] = 100_000_000  # 億


def _convert_color(c: str) -> str:
    """Map simple colour names to Plotly palette; pass through others."""
    mapping = {
        "blue": _PLOTLY_PALETTE[0],
        "red": _PLOTLY_PALETTE[1],
        "green": _PLOTLY_PALETTE[2],
        "purple": _PLOTLY_PALETTE[3],
        "orange": _PLOTLY_PALETTE[4],
        "yellow": _PLOTLY_PALETTE[4],
        "cyan": _PLOTLY_PALETTE[5],
        "pink": _PLOTLY_PALETTE[6],
        "brown": _PLOTLY_PALETTE[7],
        "grey": "lightgray",
        "gray": "lightgray",
    }
    return mapping.get(str(c).lower(), c)


def _add_last_point_marker(
    fig: go.Figure, x: pd.Timestamp, y: float, colour: str
) -> None:
    fig.add_trace(
        go.Scatter(
            x=[x],
            y=[y],
            mode="markers",
            marker={"size": 16, "color": colour, "line": {"width": 0}},
            hoverinfo="skip",
            showlegend=False,
        ),
    )
    fig.add_annotation(
        x=x,
        y=y,
        text=f"{y:.2f}",
        showarrow=False,
        xshift=10,
        font={"size": 16, "color": colour},
        xanchor="left",
        yanchor="middle",
    )


def _in_range(val: float, lower: float | None, upper: float | None) -> bool:
    """Return True if lower <= val <= upper with None = -/+∞."""
    if lower is None:
        lower = float("-inf")
    if upper is None:
        upper = float("inf")
    return lower <= val <= upper


def _resolve_color(
    x: float,
    y: float,
    default_color: str,
    h_line_ranges: list[Sequence[Any]],
    v_line_ranges: list[Sequence[Any]],
) -> str:
    """
    Decide colour for point (x,y). Later ranges覆寫 earlier ranges.
    Accept formats:
        [lower, upper, color]      # 完整
        [threshold, color]         # 只有下限
    """
    colour = default_color

    # horizontal (y) ranges
    for rng in h_line_ranges:
        if len(rng) == 3:
            lo, hi, clr = rng
        elif len(rng) == 2:
            lo, clr = rng
            hi = None
        else:
            continue  # skip malformed
        if _in_range(y, lo, hi):
            colour = _convert_color(clr)  # 覆寫
    # vertical (x) ranges
    for rng in v_line_ranges:
        if len(rng) == 3:
            lo, hi, clr = rng
        elif len(rng) == 2:
            lo, clr = rng
            hi = None
        else:
            continue
        if _in_range(x, lo, hi):
            colour = _convert_color(clr)  # 覆寫
    return colour


def plot_line(
    df: pd.Series | pd.DataFrame,
    benchmark: pd.Series | None = None,
    unit: str = ".2f",
    hlines: Sequence[dict[str, float | str]] | None = None,
    vlines: Sequence[dict[str, float | str]] | None = None,
    h_color_ranges: Sequence[Sequence[Any]] | None = None,
    v_color_ranges: Sequence[Sequence[Any]] | None = None,
    h_line_color_ranges: Sequence[Sequence[Any]] | None = None,
    v_line_color_ranges: Sequence[Sequence[Any]] | None = None,
    useMarker: bool = False,
    bg_color: str | None = "black",
    title: str | None = None,
    show_legend: bool = True,
) -> go.Figure:
    """
    Plots a line chart with advanced customization options.

    Features:
        - Zone-colored line segments:
            Use `h_line_color_ranges` and `v_line_color_ranges` to color line segments based on y (horizontal) or x (vertical) value ranges.
        - Guide lines:
            Add horizontal (`hlines`) and vertical (`vlines`) reference lines, with optional custom colors.
        - Colored bands:
            Highlight horizontal (`h_color_ranges`) or vertical (`v_color_ranges`) value regions with background color bands.
        - Benchmark:
            Optionally plot a benchmark series for comparison.
        - Last-point marker:
            Optionally highlight the last data point with a marker.
        - Customization:
            Set background color, legend visibility, plot title, and value formatting.

    Args:
        df (pd.Series or pd.DataFrame): Data to plot (index as x-axis).
        benchmark (pd.Series, optional): Series to plot as a benchmark.
        unit (str): Format string for y-axis values (default: ".2f").
        hlines (list of dict, optional): Horizontal guide lines.
        vlines (list of dict, optional): Vertical guide lines.
        h_color_ranges (list, optional): Horizontal colored bands.
        v_color_ranges (list, optional): Vertical colored bands.
        h_line_color_ranges (list, optional): Y-value ranges for line segment coloring.
        v_line_color_ranges (list, optional): X-value ranges for line segment coloring.
        useMarker (bool): Whether to mark the last data point.
        bg_color (str, optional): Background color.
        title (str, optional): Plot title.
        show_legend (bool): Whether to show the legend.

    Returns:
        plotly.graph_objs.Figure: The resulting plotly figure.

    Examples:
        Basic usage with a single series:
            ```python
            import pandas as pd
            from finlab.plot import plot_line

            # Simple line plot
            data = pd.Series([1, 2, 3, 4, 5], index=pd.date_range('2023-01-01', periods=5))
            fig = plot_line(data)
            fig.show()
            ```

        Advanced usage with all features:
            ```python
            import pandas as pd
            import numpy as np

            # Create sample data
            dates = pd.date_range('2023-01-01', '2023-12-31', freq='D')
            stock_a = 100 + np.cumsum(np.random.randn(len(dates)) * 0.5)
            stock_b = 95 + np.cumsum(np.random.randn(len(dates)) * 0.3)

            df = pd.DataFrame({
                'Stock A': stock_a,
                'Stock B': stock_b
            }, index=dates)

            # Benchmark data
            benchmark = pd.Series(100 + np.cumsum(np.random.randn(len(dates)) * 0.2),
                                index=dates, name='Market Index')

            # Create comprehensive chart
            fig = plot_line(
                df=df,
                benchmark=benchmark,
                unit=".1f",
                hlines=[
                    {"pos": 105, "color": "red"},
                    {"pos": 95, "color": "green"}
                ],
                vlines=[
                    {"pos": "2023-06-15", "color": "blue"}
                ],
                h_color_ranges=[
                    (90, 100, "lightgreen"),
                    (110, 120, "lightcoral")
                ],
                v_color_ranges=[
                    ("2023-01-01", "2023-06-30", "lightyellow"),
                    ("2023-07-01", "2023-12-31", "lightcyan")
                ],
                h_line_color_ranges=[
                    (90, 100, "green"),
                    (110, 120, "red")
                ],
                v_line_color_ranges=[
                    ("2023-01-01", "2023-06-30", "orange"),
                    ("2023-07-01", "2023-12-31", "purple")
                ],
                useMarker=True,
                bg_color="white",
                title="Stock Performance Analysis",
                show_legend=True
            )
            fig.show()
            ```
    """

    # ── sanitise inputs ──────────────────────────────────────────────────────
    if isinstance(df, pd.Series):
        df = df.to_frame()
    hlines = hlines or []
    vlines = vlines or []
    h_color_ranges = h_color_ranges or []
    v_color_ranges = v_color_ranges or []
    h_line_color_ranges = h_line_color_ranges or []
    v_line_color_ranges = v_line_color_ranges or []

    # ── scaffold ─────────────────────────────────────────────────────────────
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    palette_iter = itertools.cycle(_PLOTLY_PALETTE)

    # ── main series ──────────────────────────────────────────────────────────
    for col in df.columns:
        series = df[col].dropna()
        default_color = next(palette_iter)

        # segment the series by colour
        segments: list[tuple[list[Any], list[Any], str]] = []
        cur_xs: list[Any] = []
        cur_ys: list[Any] = []
        cur_col: str | None = None

        for i, (x, y) in enumerate(series.items()):
            new_col = _resolve_color(
                x, y, default_color, h_line_color_ranges, v_line_color_ranges
            )
            if cur_col is None:
                # first point
                cur_col = new_col
                cur_xs.append(x)
                cur_ys.append(y)
                continue

            if new_col == cur_col:
                cur_xs.append(x)
                cur_ys.append(y)
            else:
                # close segment
                segments.append((cur_xs, cur_ys, cur_col))
                # new segment starts with previous + current to keep continuity
                prev_x, prev_y = series.index[i - 1], series.iloc[i - 1]
                cur_xs = [prev_x, x]
                cur_ys = [prev_y, y]
                cur_col = new_col

        # push final
        if cur_xs:
            segments.append((cur_xs, cur_ys, cur_col))

        # add traces
        for j, (xs, ys, c) in enumerate(segments):
            fig.add_trace(
                go.Scatter(
                    x=xs,
                    y=ys,
                    mode="lines",
                    line={"color": c, "width": 2},
                    name=str(col) if j == 0 else None,
                    showlegend=(j == 0 and show_legend),
                ),
                secondary_y=False,
            )

        # last-point marker
        if useMarker and len(series):
            # consider .0%

            _add_last_point_marker(
                fig, series.index[-1], series.iloc[-1], segments[-1][2]
            )

    # ── benchmark ────────────────────────────────────────────────────────────
    if benchmark is not None:
        bench = benchmark.dropna()
        fig.add_trace(
            go.Scatter(
                x=bench.index,
                y=bench.values,
                mode="lines",
                line={"color": "#777777", "width": 1},
                name=str(getattr(benchmark, "name", "benchmark")),
                opacity=0.6,
                showlegend=show_legend,
            ),
            secondary_y=True,
        )

    # ── guide lines ──────────────────────────────────────────────────────────
    shapes = [
        {
            "type": "line",
            "xref": "paper",
            "x0": 0,
            "x1": 1,
            "yref": "y",
            "y0": ln["pos"],
            "y1": ln["pos"],
            "line": {
                "color": _convert_color(ln["color"]),
                "width": 1,
                "dash": "dot",
            },
        }
        for ln in hlines
    ]
    shapes.extend(
        {
            "type": "line",
            "yref": "paper",
            "y0": 0,
            "y1": 1,
            "xref": "x",
            "x0": ln["pos"],
            "x1": ln["pos"],
            "line": {
                "color": _convert_color(ln["color"]),
                "width": 1,
                "dash": "dot",
            },
        }
        for ln in vlines
    )

    # coloured background bands (保持舊功能)
    for lo, hi, clr in h_color_ranges:
        shapes.append(
            {
                "type": "rect",
                "xref": "paper",
                "x0": 0,
                "x1": 1,
                "yref": "y",
                "y0": lo,
                "y1": hi,
                "fillcolor": _convert_color(clr),
                "opacity": 0.15,
                "line_width": 0,
            }
        )
    for lo, hi, clr in v_color_ranges:
        shapes.append(
            {
                "type": "rect",
                "yref": "paper",
                "y0": 0,
                "y1": 1,
                "xref": "x",
                "x0": lo,
                "x1": hi,
                "fillcolor": _convert_color(clr),
                "opacity": 0.15,
                "line_width": 0,
            }
        )

    # ── layout ───────────────────────────────────────────────────────────────
    fig.update_layout(
        title={
            "text": title,
            "y": 0.9,
            "x": 0.05,
            "xanchor": "left",
            "yanchor": "top",
            "font": {"size": 18, "color": "#777777"},
        },
        template="plotly_dark",
        shapes=shapes,
        legend={"title": ""} if len(df.columns) > 1 and show_legend else None,
        margin={"t": 80, "b": 60, "l": 40, "r": 40},
        width=800,
        height=450,
        paper_bgcolor=bg_color,
        plot_bgcolor=bg_color,
        yaxis={
            "showgrid": False,
            "tickformat": unit,
            "nticks": 10,
            "zeroline": False,
            "side": "right",
            "showline": False,
        },
        xaxis={"showgrid": False, "showline": True},
        yaxis2={"visible": False},
    )
    if benchmark is not None:
        fig.update_yaxes(showgrid=False, secondary_y=True)

    return fig


def plot_line_example() -> go.Figure:
    """
    Comprehensive example demonstrating all features of plot_line function.

    This example shows how to use all parameters and features of the plot_line function:
    - Multiple data series
    - Benchmark comparison
    - Horizontal and vertical guide lines
    - Colored background bands
    - Zone-colored line segments
    - Last point markers
    - Custom styling and formatting

    Returns:
        plotly.graph_objs.Figure: Example figure with all features
    """

    import numpy as np
    import pandas as pd

    # Create sample data
    dates = pd.date_range("2023-01-01", "2023-12-31", freq="D")
    np.random.seed(42)

    # Main data series
    stock_a = 100 + np.cumsum(np.random.randn(len(dates)) * 0.5)
    stock_b = 95 + np.cumsum(np.random.randn(len(dates)) * 0.3)
    stock_c = 110 + np.cumsum(np.random.randn(len(dates)) * 0.4)

    df = pd.DataFrame(
        {"Stock A": stock_a, "Stock B": stock_b, "Stock C": stock_c}, index=dates
    )

    # Benchmark data
    benchmark = 100 + np.cumsum(np.random.randn(len(dates)) * 0.2)
    benchmark_series = pd.Series(benchmark, index=dates, name="Market Index")

    # Example with all features
    return plot_line(
        df=df,
        benchmark=benchmark_series,
        unit=".1f",  # Format y-axis values to 1 decimal place
        hlines=[  # Horizontal guide lines
            {"pos": 105, "color": "red"},
            {"pos": 95, "color": "green"},
            {"pos": 115, "color": "orange"},
        ],
        vlines=[  # Vertical guide lines
            {"pos": "2023-03-15", "color": "blue"},
            {"pos": "2023-06-15", "color": "purple"},
            {"pos": "2023-09-15", "color": "cyan"},
        ],
        h_color_ranges=[  # Horizontal colored background bands
            (90, 100, "lightgreen"),  # Green band for 90-100
            (110, 120, "lightcoral"),  # Red band for 110-120
            (100, 110, "lightblue"),  # Blue band for 100-110
        ],
        v_color_ranges=[  # Vertical colored background bands
            ("2023-01-01", "2023-03-31", "lightyellow"),  # Q1
            ("2023-04-01", "2023-06-30", "lightcyan"),  # Q2
            ("2023-07-01", "2023-09-30", "lightpink"),  # Q3
            ("2023-10-01", "2023-12-31", "lightgray"),  # Q4
        ],
        h_line_color_ranges=[  # Y-value ranges for line segment coloring
            (90, 100, "green"),  # Green line when y < 100
            (110, 120, "red"),  # Red line when y > 110
            (100, 110, "blue"),  # Blue line when 100 < y < 110
        ],
        v_line_color_ranges=[  # X-value ranges for line segment coloring
            ("2023-01-01", "2023-06-30", "orange"),  # Orange line in first half
            ("2023-07-01", "2023-12-31", "purple"),  # Purple line in second half
        ],
        useMarker=True,  # Show markers at last data points
        bg_color="white",  # White background
        title="Comprehensive Stock Performance Analysis with All Features",
        show_legend=True,  # Show legend
    )


def plot_line_financial_example() -> go.Figure:
    """
    Real-world financial example using finlab data.

    This example demonstrates plot_line with actual stock data and common
    financial analysis features like support/resistance levels and trend zones.

    Returns:
        plotly.graph_objs.Figure: Financial analysis chart
    """
    import pandas as pd

    from finlab import data

    # Get real stock data for Taiwan Semiconductor (2330)
    try:
        close_prices = data.get("price:收盤價")["2330"]
        # Get last 100 trading days
        close_prices = close_prices.tail(100)

        # Calculate moving averages as additional series
        ma_20 = close_prices.rolling(20).mean()
        ma_50 = close_prices.rolling(50).mean()

        # Create DataFrame with multiple series
        df = pd.DataFrame({"TSMC Close": close_prices, "MA 20": ma_20, "MA 50": ma_50})

        # Get market benchmark (Taiwan Weighted Index)
        benchmark = data.get("benchmark_return:發行量加權股價報酬指數")[
            "發行量加權股價報酬指數"
        ]
        benchmark = benchmark.tail(100)

        # Calculate support and resistance levels
        recent_high = close_prices.max()
        recent_low = close_prices.min()
        mid_level = (recent_high + recent_low) / 2

        # Example with financial analysis features
        return plot_line(
            df=df,
            benchmark=benchmark,
            unit=".0f",  # No decimal places for stock prices
            hlines=[  # Support and resistance levels
                {"pos": recent_high, "color": "red"},
                {"pos": recent_low, "color": "green"},
                {"pos": mid_level, "color": "orange"},
            ],
            vlines=[  # Important dates (quarterly earnings, etc.)
                {"pos": close_prices.index[-30], "color": "blue"},  # 30 days ago
                {"pos": close_prices.index[-60], "color": "purple"},  # 60 days ago
            ],
            h_color_ranges=[  # Price zones
                (recent_low, mid_level, "lightgreen"),  # Bullish zone
                (mid_level, recent_high, "lightcoral"),  # Bearish zone
            ],
            h_line_color_ranges=[  # Trend-based line coloring
                (recent_low, mid_level, "green"),  # Green when above support
                (mid_level, recent_high, "red"),  # Red when below resistance
            ],
            useMarker=True,
            bg_color="black",
            title="TSMC (2330) Stock Analysis with Technical Indicators",
            show_legend=True,
        )

    except Exception as e:
        # Fallback example if data is not available
        print(f"Data not available, using fallback example: {e}")

        # Create synthetic data
        dates = pd.date_range("2023-01-01", "2023-12-31", freq="D")
        np.random.seed(42)

        stock_price = 500 + np.cumsum(np.random.randn(len(dates)) * 2)
        ma_short = pd.Series(stock_price).rolling(20).mean()
        ma_long = pd.Series(stock_price).rolling(50).mean()

        df = pd.DataFrame(
            {"Stock Price": stock_price, "MA 20": ma_short, "MA 50": ma_long},
            index=dates,
        )

        return plot_line(
            df=df,
            unit=".0f",
            hlines=[{"pos": 550, "color": "red"}, {"pos": 450, "color": "green"}],
            h_color_ranges=[(450, 500, "lightgreen"), (500, 550, "lightcoral")],
            useMarker=True,
            title="Sample Stock Analysis (Fallback Data)",
            show_legend=True,
        )


"""
Candles
"""


def str_to_indicator(s: str, df: pd.DataFrame) -> pd.DataFrame | pd.Series:
    import talib
    from talib import abstract

    params: dict[str, Any] = {}
    if "(" in s:
        param_str = s.rsplit("(", maxsplit=1)[-1].rstrip(")")
        for pair in param_str.split(","):
            if "=" not in pair:
                continue
            key, value = pair.split("=", 1)
            params[key.strip()] = ast.literal_eval(value.strip())
    s = s.split("(", maxsplit=1)[0]

    func = getattr(abstract, s)
    real_func = getattr(talib, s)

    abstract_input = next(iter(func.input_names.values()))
    if isinstance(abstract_input, str):
        abstract_input = [abstract_input]

    pos_paras = [df[k] for k in abstract_input]

    ret = real_func(*pos_paras, **params)

    if isinstance(ret, np.ndarray):
        ret = pd.Series(ret, index=df.index)

    if isinstance(ret, pd.Series):
        return ret.to_frame(s)
    return ret


def color_generator() -> Generator[str]:
    yield from itertools.cycle(px.colors.qualitative.Plotly)


def average(series: pd.Series, n: int) -> pd.Series:
    return series.rolling(n, min_periods=int(n / 2)).mean()


def evaluate_to_df(node: IndicatorSpec, symbol: str, df: pd.DataFrame) -> pd.DataFrame:
    if callable(node):
        node = node(df)

    if isinstance(node, str):
        node = str_to_indicator(node, df)

    if isinstance(node, pd.Series):
        return node.to_frame("0")

    if isinstance(node, np.ndarray):
        return pd.Series(node, df.index).to_frame("0")

    if isinstance(node, pd.DataFrame):
        if symbol in node.columns:
            return pd.DataFrame({"0": node[symbol]})
        return node

    if isinstance(node, (list, tuple)):
        new_node: dict[str | int, Any] = {}
        ivalue = 0
        for n in node:
            if isinstance(n, str):
                new_node[n] = n
            else:
                new_node[ivalue] = n
                ivalue += 1
        node = new_node

    if isinstance(node, dict):
        dfs: list[pd.DataFrame] = []
        for name, n in node.items():
            nn = evaluate_to_df(n, symbol, df)
            if len(nn.columns) == 1:
                nn.columns = [name]
            dfs.append(nn)

        return pd.concat(dfs, axis=1)

    raise ValueError(f"Unsupported indicator type: {type(node).__name__}")


def format_indicators(
    indicators: IndicatorSpec | list[IndicatorSpec],
    symbol: str,
    stock_df: pd.DataFrame,
) -> list[pd.DataFrame]:
    if not isinstance(indicators, list):
        indicators = [indicators]

    return [evaluate_to_df(i, symbol, stock_df) for i in indicators]


@param_alias("stock_id", "symbol")
def plot_candles(
    symbol: str,
    close: pd.Series,
    open_: pd.Series,
    high: pd.Series,
    low: pd.Series,
    volume: pd.Series,
    recent_days: int = 250,
    resample: str = "D",
    overlay_func: dict[str, Any] | list[dict[str, Any]] | None = None,
    technical_func: list[dict[str, Any]] | dict[str, Any] | None = None,
) -> go.Figure:
    c = color_generator()
    next(c)
    next(c)

    df = pd.DataFrame(
        {
            "close": close.values,
            "open": open_.values,
            "high": high.values,
            "low": low.values,
            "volume": volume.values,
        },
        index=close.index,
    ).iloc[-abs(recent_days) :]

    if resample:
        df = df.resample(resample).agg(
            {
                "close": "last",
                "open": "first",
                "high": "max",
                "low": "min",
                "volume": "sum",
            }
        )

    if overlay_func is None:
        upperband, middleband, lowerband = data.indicator("BBANDS")
        overlay_func = {
            "upperband": upperband,
            "middleband": middleband,
            "lowerband": lowerband,
        }

    if technical_func is None:
        k, d = data.indicator("STOCH")
        technical_func = [{"K": k, "D": d}]

    overlay_indicator = format_indicators(overlay_func, symbol, df)

    # merge overlay indicator if it has multiple plots
    if len(overlay_indicator) > 1:
        overlay_indicator = [pd.concat(overlay_indicator, axis=1)]
        overlay_indicator[0].columns = range(len(overlay_indicator[0].columns))

    technical_indicator = format_indicators(technical_func, symbol, df)

    # truncate recent days
    for i, d in enumerate(overlay_indicator):
        o_ind = d.iloc[-abs(recent_days) :]
        if resample != "D":
            o_ind = o_ind.reindex(df.index, method="ffill")
        overlay_indicator[i] = o_ind
    for i, d in enumerate(technical_indicator):
        t_ind = d.iloc[-abs(recent_days) :]
        if resample != "D":
            t_ind = t_ind.reindex(df.index, method="ffill")
        technical_indicator[i] = t_ind

    technical_func_num = len(technical_indicator)
    index_value = close.index

    nrows = 1 + len(technical_indicator)

    fig_titles = [""]
    if isinstance(technical_func, list):
        fig_titles.extend(",".join(t) for t in technical_func)
    elif isinstance(technical_func, dict):
        fig_titles.append(",".join(technical_func))

    fig = make_subplots(
        rows=nrows,
        specs=[[{"secondary_y": True}]] * nrows,
        shared_xaxes=True,
        vertical_spacing=0.05,
        subplot_titles=fig_titles,
        row_heights=[0.4] + [0.1] * (nrows - 1),
    )

    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df.volume,
            opacity=0.3,
            name="volume",
            marker={"color": "gray", "line_width": 0},
        ),
        row=1,
        col=1,
    )

    fig.add_trace(
        go.Candlestick(
            x=df.index,
            open=df.open,
            high=df.high,
            low=df.low,
            close=df.close,
            increasing_line_color="#ff5084",
            decreasing_line_color="#2bbd91",
            legendgroup="1",
            name="candle",
        ),
        row=1,
        col=1,
        secondary_y=True,
    )

    # overlay plot
    if overlay_indicator:
        fig_overlay = px.line(overlay_indicator[0])
        for o in fig_overlay.data:
            fig.add_trace(
                go.Scatter(
                    x=o["x"],
                    y=o["y"],
                    name=o["name"],
                    line={"color": next(c)},
                    legendgroup="1",
                ),
                row=1,
                col=1,
                secondary_y=True,
            )

    for num, tech_ind in enumerate(technical_indicator):
        fig_tech = px.line(tech_ind)
        for t in fig_tech.data:
            color = next(c)

            fig.add_trace(
                go.Scatter(
                    x=t["x"],
                    y=t["y"],
                    name=t["name"],
                    line={"color": color},
                    legendgroup=str(2 + num),
                ),
                row=2 + num,
                col=1,
            )

    # hide holiday
    if resample == "D":
        dt_all = pd.date_range(start=index_value[0], end=index_value[-1])
        # retrieve the dates that are in the original dataset
        dt_obs = [d.strftime("%Y-%m-%d") for d in pd.to_datetime(index_value)]
        # define dates with missing values
        dt_breaks = [d for d in dt_all.strftime("%Y-%m-%d").tolist() if d not in dt_obs]
        # hide dates with no values
        fig.update_xaxes(rangebreaks=[{"values": dt_breaks}])

    fig.update_layout(
        height=600 + 100 * technical_func_num,
    )

    fig.update_layout(
        yaxis1={
            "title": "volume",
            "titlefont": {"color": "#777"},
            "tickfont": {"color": "#777"},
            "range": [df.volume.min(), df.volume.max() * 2],
        },
        yaxis2={
            "title": "price",
            "titlefont": {"color": "#777"},
            "tickfont": {"color": "#777"},
            "showgrid": False,
        },
        hovermode="x unified",
    )

    fig.update_layout(
        **{
            "xaxis1_rangeslider_visible": False,
            "xaxis": {
                "rangeselector": {
                    "buttons": [
                        {
                            "count": 6,
                            "label": "6m",
                            "step": "month",
                            "stepmode": "backward",
                        },
                        {
                            "count": 1,
                            "label": "YTD",
                            "step": "year",
                            "stepmode": "todate",
                        },
                        {
                            "count": 1,
                            "label": "1y",
                            "step": "year",
                            "stepmode": "backward",
                        },
                        {"step": "all"},
                    ]
                },
            },
            f"xaxis{nrows}": {
                "rangeslider": {
                    "visible": True,
                    "thickness": 0.1,
                    "bgcolor": "gainsboro",
                },
                "type": "date",
            },
        }
    )

    fig.update_xaxes(showspikes=True)
    fig.update_yaxes(showspikes=True, spikemode="across")
    fig.update_layout(showlegend=False)
    fig.update_layout(plot_bgcolor="white")
    fig.update_xaxes(showline=True, linecolor="#ddd")
    fig.update_yaxes(showline=True, linecolor="#ddd")
    fig.update_yaxes(titlefont={"color": "#777"}, tickfont={"color": "#777"})

    fig.update_layout(
        title={
            "text": f"Candlestick Plot {symbol}",
            "font": {"size": 18, "color": "gray"},
        }
    )

    return fig


@param_alias("stock_id", "symbol")
def plot_tw_stock_candles(
    symbol: str,
    recent_days: int = 400,
    adjust_price: bool = False,
    resample: str = "D",
    overlay_func: dict[str, Any] | list[dict[str, Any]] | None = None,
    technical_func: list[dict[str, Any]] | dict[str, Any] | None = None,
) -> go.Figure:
    """繪製台股技術線圖圖組
    Args:
        symbol (str): 台股股號，ex:`'2330'`。
        recent_days (int):取近n個交易日資料。
        adjust_price (bool):是否使用還原股價計算。
        resample (str): 技術指標價格週期，ex: `D` 代表日線, `W` 代表週線, `M` 代表月線。
        overlay_func (dict):
            K線圖輔助線，預設使用布林通道。
             ```py
             from finlab.data import indicator

             overlay_func={
                          'ema_5':indicator('EMA',timeperiod=5),
                          'ema_10':indicator('EMA',timeperiod=10),
                          'ema_20':indicator('EMA',timeperiod=20),
                          'ema_60':indicator('EMA',timeperiod=60),
                         }
             ```
        technical_func (list):
            技術指標子圖，預設使用KD技術指標單組子圖。

            設定多組技術指標：
            ```py
            from finlab.data import indicator

            k,d = indicator('STOCH')
            rsi = indicator('RSI')
            technical_func = [{'K':k,'D':d},{'RSI':rsi}]
            ```

    Returns:
        (plotly.graph_objects.Figure): 技術線圖

    Examples:
        ```py
        from finlab.plot import plot_tw_stock_candles
        from finlab.data import indicator

        overlay_func={
                      'ema_5':indicator('EMA',timeperiod=5),
                      'ema_10':indicator('EMA',timeperiod=10),
                      'ema_20':indicator('EMA',timeperiod=20),
                      'ema_60':indicator('EMA',timeperiod=60),
                     }
        k,d = indicator('STOCH')
        rsi = indicator('RSI')
        technical_func = [{'K':k,'D':d},{'RSI':rsi}]
        plot_tw_stock_candles(symbol='2330',recent_days=600,adjust_price=False,overlay_func=overlay_func,technical_func=technical_func)
        ```
    """
    if adjust_price:
        close = data.get("etl:adj_close")[symbol]
        open_ = data.get("etl:adj_open")[symbol]
        high = data.get("etl:adj_high")[symbol]
        low = data.get("etl:adj_low")[symbol]
    else:
        close = data.get("price:收盤價")[symbol]
        open_ = data.get("price:開盤價")[symbol]
        high = data.get("price:最高價")[symbol]
        low = data.get("price:最低價")[symbol]

    volume = data.get("price:成交股數")[symbol]

    return plot_candles(
        symbol,
        close,
        open_,
        high,
        low,
        volume,
        recent_days=recent_days,
        resample=resample,
        overlay_func=overlay_func,
        technical_func=technical_func,
    )


"""
Treemap
"""


def df_date_filter(
    df: pd.DataFrame, start: str | None = None, end: str | None = None
) -> pd.DataFrame:
    if start:
        df = df[df.index >= start]
    if end:
        df = df[df.index <= end]
    return df


def create_treemap_data(
    start: str,
    end: str,
    item: str = "return_ratio",
    clip: tuple[float, float] | None = None,
) -> pd.DataFrame | None:
    """產生台股板塊圖資料

    產生繪製樹狀圖所用的資料，可再外加FinLab資料庫以外的指標製作客製化DataFrame，
    並傳入`plot_tw_stock_treemap(treemap_data=treemap_data)。`

    Args:
      start (str): 資料開始日，ex:`"2021-01-02"`。
      end (str):資料結束日，ex:`"2021-01-05"`。
      item (str): 決定板塊顏色深淺的指標。
                  除了可選擇依照 start 與 end 計算的`"return_ratio"`(報酬率)，
                  亦可選擇[FinLab資料庫](https://ai.finlab.tw/database)內的指標顯示近一期資料。
          example:

          * `'price_earning_ratio:本益比'` - 顯示近日產業的本益比高低。
          * `'monthly_revenue:去年同月增減(%)'` - 顯示近月的單月營收年增率。

      clip (tuple): 將item邊界外的值分配給邊界值，防止資料上限值過大或過小，造成顏色深淺變化不明顯。
                    ex:(0,100)，將數值低高界線，設為0~100，超過的數值。
        !!! note

            參考[pandas文件](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.clip.html)更了解`pd.clip`細節。

    Returns:
        (pd.DataFrame): 台股個股指標
    Examples:

        欲下載所有上市上櫃之價量歷史資料與產業分類，只需執行此函式:

        ``` py
        from finlab.plot import create_treemap_data
        create_treemap_data(start= '2021-07-01',end = '2021-07-02')
        ```

        | stock_id   |  close |turnover|category|market|market_value|return_ratio|country|
        |:-----------|-------:|-------:|-------:|-------:|-------:|-------:|-------:|
        | 1101       |   20 |  57.85 |  水泥工業 |  sii   |    111  |    0.1  |  TW-Stock|
        | 1102       |  20 |  58.1  |  水泥工業 |  sii    |    111  |    -0.1 |  TW-Stock|


    """
    close = data.get("price:收盤價")
    basic_info = data.get("company_basic_info")
    turnover = data.get("price:成交金額")
    close_data = df_date_filter(close, start, end)
    turnover_data = df_date_filter(turnover, start, end).iloc[1:].sum() / _YI
    return_ratio = (
        (close_data.loc[end] / close_data.loc[start]).dropna().replace(np.inf, 0)
    )
    return_ratio = round((return_ratio - 1) * 100, 2)

    concat_list = [close_data.iloc[-1], turnover_data, return_ratio]
    col_names = ["symbol", "close", "turnover", "return_ratio"]
    if item not in {"return_ratio", "turnover_ratio"}:
        try:
            custom_item = df_date_filter(data.get(item), start, end).iloc[-1].fillna(0)
        except Exception as e:
            logger.error("data error, check the data is existed between start and end.")
            logger.error(e)
            return None
        if clip:
            custom_item = custom_item.clip(*clip)
        concat_list.append(custom_item)
        col_names.append(item)

    df = pd.concat(concat_list, axis=1).dropna()
    df = df.reset_index()
    df.columns = col_names

    basic_info_df = basic_info.copy().reset_index()
    _id_col = resolve_id_column(basic_info_df)
    basic_info_df["stock_id_name"] = (
        basic_info_df[_id_col].astype(str) + basic_info_df["公司簡稱"]
    )

    # Normalize to 'symbol' for merge
    if _id_col == "stock_id" and "symbol" not in basic_info_df.columns:
        basic_info_df = basic_info_df.rename(columns={"stock_id": "symbol"})
    df = df.merge(
        basic_info_df[
            ["symbol", "stock_id_name", "產業類別", "市場別", "實收資本額(元)"]
        ],
        how="left",
        on="symbol",
    )
    df = df.rename(
        columns={"產業類別": "category", "市場別": "market", "實收資本額(元)": "base"}
    )
    df = df.dropna(thresh=5)
    df["market_value"] = round(df["base"] / 10 * df["close"] / _YI, 2)
    df["country"] = "TW-Stock"
    return df


def plot_tw_stock_treemap(
    start: str | None = None,
    end: str | None = None,
    area_ind: str = "market_value",
    item: str = "return_ratio",
    clip: tuple[float, float] | None = None,
    color_continuous_scale: str = "Temps",
    treemap_data: pd.DataFrame | None = None,
) -> go.Figure | None:
    """繪製台股板塊圖資料

    巢狀樹狀圖可以顯示多維度資料，將依照產業分類的台股資料絢麗顯示。

    Args:
      start (str): 資料開始日，ex:`'2021-01-02'`。
      end (str): 資料結束日，ex:`'2021-01-05'`。
      area_ind (str): 決定板塊面積數值的指標。
                      可選擇`["market_value","turnover"]`，數值代表含義分別為市值、成交金額。
      item (str): 決定板塊顏色深淺的指標。
                  除了可選擇依照 start 與 end 計算的`"return_ratio"`(報酬率)，
                  亦可選擇[FinLab資料庫](https://ai.finlab.tw/database)內的指標顯示近一期資料。
          example:

          * `'price_earning_ratio:本益比'` - 顯示近日產業的本益比高低。
          * `'monthly_revenue:去年同月增減(%)'` - 顯示近月的單月營收年增率。

      clip (tuple): 將 item 邊界外的值分配給邊界值，防止資料上限值過大或過小，造成顏色深淺變化不明顯。
                    ex:(0,100)，將數值低高界線，設為 0~100，超過的數值。
        !!!note

            參考[pandas文件](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.clip.html)更了解`pd.clip`細節。
      color_continuous_scale (str):[顏色變化序列的樣式名稱](https://plotly.com/python/builtin-colorscales/)
      treemap_data (pd.DataFrame): 客製化資料，格式參照 `create_treemap_data()` 返回值。
    Returns:
        (plotly.graph_objects.Figure): 樹狀板塊圖
    Examples:
        ex1:
        板塊面積顯示成交金額，顏色顯示'2021-07-01'～'2021-07-02'的報酬率變化，可以觀察市場資金集中的產業與漲跌強弱。
        ```py
        from finlab.plot import plot_tw_stock_treemap
        plot_tw_stock_treemap(start= '2021-07-01',end = '2021-07-02',area_ind="turnover",item="return_ratio")
        ```
        ![成交佔比/報酬率板塊圖](img/plot/treemap_return.png)
        ex2:
        板塊面積顯示市值(股本*收盤價)，顏色顯示近期本益比，可以觀察全市場哪些是權值股？哪些產業本益比評價高？限制數值範圍在(0,50)，
        將過高本益比的數值壓在50，不讓顏色變化突兀，能分出高低階層即可。
        ```py
        from finlab.plot import plot_tw_stock_treemap
        plot_tw_stock_treemap(area_ind="market_value",item="price_earning_ratio:本益比",clip=(0,50), color_continuous_scale='RdBu_r')
        ```
        ![市值/本益比板塊圖](img/plot/treemap_pe.png)
    """
    if treemap_data is None:
        df = create_treemap_data(start, end, item, clip)
    else:
        df = treemap_data.copy()

    if df is None:
        return None
    df["custom_item_label"] = round(df[item], 2).astype(str)
    df.dropna(how="any", inplace=True)

    if area_ind not in df.columns:
        return None

    if item == "return_ratio":
        color_continuous_midpoint = 0
    else:
        color_continuous_midpoint = np.average(df[item], weights=df[area_ind])

    fig = px.treemap(
        df,
        path=["country", "market", "category", "stock_id_name"],
        values=area_ind,
        color=item,
        color_continuous_scale=color_continuous_scale,
        color_continuous_midpoint=color_continuous_midpoint,
        custom_data=["custom_item_label", "close", "turnover"],
        title=f"TW-Stock Market TreeMap({start}~{end})"
        f"---area_ind:{area_ind}---item:{item}",
        width=1600,
        height=800,
    )

    fig.update_traces(
        textposition="middle center",
        textfont_size=24,
        texttemplate="%{label}<br>(%{customdata[1]})<br>%{customdata[0]}",
    )
    return fig


"""
Radar
"""


def plot_radar(
    df: pd.DataFrame,
    mode: str = "bar_polar",
    line_polar_fill: str | None = None,
    title: str | None = None,
    polar_range: int = 10,
) -> go.Figure:
    args = {
        "data_frame": df,
        "r": "value",
        "theta": "variable",
        "color": "symbol",
        "line_close": True,
        "color_discrete_sequence": px.colors.sequential.Plasma_r,
        "template": "plotly_dark",
    }
    if mode != "line_polar":
        args.pop("line_close")

    fig = getattr(px, mode)(**args)
    if title is None:
        title = "Features Radar"
    fig.update_layout(
        title={
            "text": title,
            "x": 0.49,
            "y": 0.99,
            "xanchor": "center",
            "yanchor": "top",
        },
        paper_bgcolor="rgb(41, 30, 109)",
        polar={"radialaxis": {"visible": True, "range": [0, polar_range]}},
        width=1200,
        height=600,
    )
    if mode == "line_polar":
        # None,toself,tonext
        fig.update_traces(fill=line_polar_fill)
    return fig


def get_rank(item: str, period: str | None = None, cut_bins: int = 10) -> pd.Series:
    df = data.get(item)
    df = df.iloc[-1] if period is None else df.loc[period]

    df_rank = df.rank(pct=True)
    return pd.cut(x=df_rank, bins=cut_bins, labels=list(range(1, cut_bins + 1)))


def get_rank_df(
    feats: list[str], period: str | None = None, cut_bins: int = 10
) -> pd.DataFrame:
    df = pd.concat([get_rank(f, period, cut_bins) for f in feats], axis=1)
    columns_name = [f[f.index(":") + 1 :] for f in feats]
    df.columns = columns_name
    df.index.name = "symbol"
    return df


def plot_tw_stock_radar(
    portfolio: list[str],
    feats: list[str] | None = None,
    mode: str = "line_polar",
    line_polar_fill: str | None = None,
    period: str | None = None,
    cut_bins: int = 10,
    title: str | None = None,
    custom_data: pd.DataFrame | None = None,
) -> go.Figure | None:
    """繪製台股雷達圖

    比較持股組合的指標分級特性。若數值為nan，則不顯示分級。

    Args:
      portfolio (list):持股組合，ex:`['1101','1102']`。
      feats (list): 選定FinLab資料庫內的指標組成資料集。預設為18項財務指標。
                    ex:['fundamental_features:營業毛利率','fundamental_features:營業利益率']
      mode (str): 雷達圖模式 ，ex:'bar_polar','scatter_polar','line_polar'`。
        !!!note

            參考[不同模式的差異](https://plotly.com/python-api-reference/generated/plotly.express.html)
      line_polar_fill (str):將區域設置為用純色填充 。ex:`None,'toself','tonext'`
                           `'toself'`將跡線的端點（或跡線的每一段，如果它有間隙）連接成一個封閉的形狀。
                           如果一條完全包圍另一條（例如連續的等高線），則`'tonext'`填充兩條跡線之間的空間，如果之前沒有跡線，
                           則其行為類似於`'toself'`。如果一條跡線不包含另一條跡線，則不應使用`'tonext'`。
        欲使用 line_polar，請將pandas版本降至 1.4.4。
        !!!note

            參考[plotly.graph_objects.Scatterpolar.fill](https://plotly.github.io/plotly.py-docs/generated/plotly.graph_objects.Scatterpolar.html)

      period (str): 選擇第幾期的特徵資料，預設為近一季。
                    ex: 設定數值為'2020-Q2，取得2020年第二季資料比較。
      cut_bins (int):特徵分級級距。
      title (str):圖片標題名稱。
      custom_data (pd.DataFrame): 客製化指標分級，欄名為特徵
                    格式範例:

        | stock_id   |  營業毛利率 |營業利益率|稅後淨利率|
        |:-----------|-------:|-------:|-------:|
        | 1101       |   2    |    5   |      3|
        | 1102       |   1    |    8   |      4|
    Returns:
        (plotly.graph_objects.Figure): 雷達圖
    Examples:
        ex1:比較持股組合累計分數，看持股組合偏重哪像特徵。
        ```py
        from finlab.plot import plot_tw_stock_radar
        plot_tw_stock_radar(portfolio=["1101", "2330", "8942", "6263"], mode="bar_polar", line_polar_fill='None')
        ```
        ![持股組合雷達圖](img/plot/radar_many.png)
        ex2:看單一個股特徵分級落點。
        ```py
        from finlab.plot import plot_tw_stock_radar
        feats = ['fundamental_features:營業毛利率', 'fundamental_features:營業利益率', 'fundamental_features:稅後淨利率',
                 'fundamental_features:現金流量比率', 'fundamental_features:負債比率']
        plot_tw_stock_radar(portfolio=["9939"], feats=feats, mode="line_polar", line_polar_fill='toself', cut_bins=8)
        ```
        ![單檔標的子選指標雷達圖](img/plot/radar_single.png)
    """
    if custom_data is None:
        if feats is None:
            feats = [
                "fundamental_features:營業毛利率",
                "fundamental_features:營業利益率",
                "fundamental_features:稅後淨利率",
                "fundamental_features:ROA綜合損益",
                "fundamental_features:ROE綜合損益",
                "fundamental_features:業外收支營收率",
                "fundamental_features:現金流量比率",
                "fundamental_features:負債比率",
                "fundamental_features:流動比率",
                "fundamental_features:速動比率",
                "fundamental_features:存貨週轉率",
                "fundamental_features:營收成長率",
                "fundamental_features:營業毛利成長率",
                "fundamental_features:營業利益成長率",
                "fundamental_features:稅前淨利成長率",
                "fundamental_features:稅後淨利成長率",
                "fundamental_features:資產總額成長率",
                "fundamental_features:淨值成長率",
            ]
        df = get_rank_df(feats, period=period, cut_bins=cut_bins)
    else:
        df = custom_data.copy()

    col_name = df.columns
    portfolio = df.index.intersection(portfolio)
    if len(portfolio) < 1:
        logger.error("data is not existed.")
        return None
    df = df.loc[portfolio]
    df = df.reset_index()
    df = pd.melt(df, id_vars=["symbol"], value_vars=col_name)
    polar_range = cut_bins * len(portfolio)
    return plot_radar(
        df=df,
        mode=mode,
        line_polar_fill=line_polar_fill,
        title=title,
        polar_range=polar_range,
    )


"""
PE PB River
"""


@param_alias("stock_id", "symbol")
def get_pe_river_data(
    start: str | None = None,
    end: str | None = None,
    symbol: str = "2330",
    mode: str = "pe",
    split_range: int = 6,
) -> pd.DataFrame | None:
    if mode not in {"pe", "pb"}:
        logger.error("mode error")
        return None
    close = df_date_filter(data.get("price:收盤價"), start, end)
    pe = df_date_filter(data.get("price_earning_ratio:本益比"), start, end)
    pb = df_date_filter(data.get("price_earning_ratio:股價淨值比"), start, end)
    df = {"pe": pe, "pb": pb}[mode]
    if symbol not in df.columns:
        logger.error("symbol input is not in data.")
        return None
    df = df[symbol]
    max_value = df.max()
    min_value = df.min()
    quan_value = (max_value - min_value) / split_range
    river_borders = [
        round(min_value + quan_value * i, 2) for i in range(split_range + 1)
    ]
    result = (close[symbol] / df).dropna().to_frame()
    index_name = f"{mode}/close"
    result.columns = [index_name]
    result["close"] = close[symbol]
    result["pe"] = pe[symbol]
    result["pb"] = pb[symbol]
    for r in river_borders:
        col_name = f"{r} {mode}"
        result[col_name] = result[index_name] * r
    return round(result, 2)


@param_alias("stock_id", "symbol")
def plot_tw_stock_river(
    symbol: str = "2330",
    start: str | None = None,
    end: str | None = None,
    mode: str = "pe",
    split_range: int = 8,
) -> go.Figure | None:
    """繪製台股河流圖

    使用 PE or PB 的最高與最低值繪製河流圖，判斷指標所處位階。

    Args:
      symbol (str): 台股股號，ex:`'2330'`。
      start (str): 資料開始日，ex:`'2020-01-02'`。
      end (str): 資料結束日，ex:`'2022-01-05'`。
      mode (str): `'pe'` or `'pb'` (本益比或股價淨值比)。
      split_range (int): 河流階層數。
    Returns:
        (plotly.graph_objects.Figure): 河流圖
    Examples:
      ```py
      from finlab.plot import plot_tw_stock_river
      plot_tw_stock_river(symbol='2330', start='2015-1-1', end='2022-7-1', mode='pe', split_range=10)
      ```
      ![單檔標的子選指標雷達圖](img/plot/pe_river.png)
    """
    df = get_pe_river_data(start, end, symbol, mode, split_range)
    if df is None:
        logger.error("data error")
        return None
    col_name_set = [i for i in df.columns if any(map(str.isdigit, i))]

    fig = go.Figure()
    for n, c in enumerate(col_name_set):
        fill_mode = None if n == 0 else "tonexty"
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df[c],
                fill=fill_mode,
                line={"width": 0, "color": px.colors.qualitative.Prism[n]},
                name=c,
            )
        )
    customdata = [(c, p) for c, p in zip(df["close"], df[mode], strict=True)]
    hovertemplate = (
        "<br>date:%{x|%Y/%m/%d}<br>close:%{customdata[0]}"
        f"<br>{mode}:%{{customdata[1]}}"
    )
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df["close"],
            line={"width": 2.5, "color": "#2e4391"},
            customdata=customdata,
            hovertemplate=hovertemplate,
            name="close",
        )
    )

    _cats = data.get("security_categories")
    security_categories = _cats.set_index(resolve_id_column(_cats))
    stock_name = security_categories.loc[symbol]["name"]
    fig.update_layout(
        title=f"{symbol} {stock_name} {mode.upper()} River Chart",
        template="ggplot2",
        yaxis={
            "title": "price",
        },
    )
    fig.update_xaxes(showspikes=True)
    fig.update_yaxes(showspikes=True)
    return fig


class StrategySunburst:
    def __init__(self) -> None:
        """繪製策略部位旭日圖

        監控多策略。
        """
        d = data.get_strategies()
        for k, v in d.items():
            if "position" in v["positions"]:
                d[k]["positions"] = v["positions"]["position"]
        self.s_data: dict[str, Any] = d

    def process_position(self, s_name: str, s_weight: float = 1) -> pd.DataFrame:
        if s_name == "現金":
            result = pd.DataFrame(
                {"return": 0, "weight": 1, "category": "現金", "market": "現金"},
                index=["現金"],
            )
            result.index.name = "symbol"
        else:
            df = pd.DataFrame(self.s_data[s_name]["positions"])
            df = df[[c for c in df.columns if " " in c]]
            df = df.T
            df["weight"] = df["weight"].apply(
                lambda s: abs(pd.to_numeric(s, errors="coerce"))
            )
            df = df[df["weight"] > 0]
            if len(df) == 0:
                df["weight"] = 0
            df.index.name = "symbol"
            old_security_categories = data.get("security_categories").reset_index()
            security_categories = old_security_categories.copy()
            security_categories["category"] = security_categories["category"].fillna(
                "other_securities"
            )
            _id_col = resolve_id_column(security_categories)
            security_categories[_id_col] = (
                security_categories[_id_col] + " " + security_categories["name"]
            )
            security_categories = security_categories.set_index([_id_col])
            result = df.join(security_categories)

            asset_type = self.s_data[s_name]["asset_type"]
            if asset_type == "":
                asset_type = "tw_stock"
            elif asset_type == "crypto":
                category = "crypto"
                result["category"] = category

            result["market"] = asset_type
            cash = pd.DataFrame(
                {
                    "return": 0,
                    "weight": 1 - (df["weight"].sum()),
                    "category": "現金",
                    "market": "現金",
                },
                index=["現金"],
            )
            cash.index.name = "symbol"
            result = pd.concat([result, cash])

        result["s_name"] = s_name
        result["s_weight"] = s_weight
        return result

    def get_strategy_df(
        self, select_strategy: dict[str, float] | None = None
    ) -> pd.DataFrame | None:
        """獲取策略部位與分配權重後計算的資料

        Args:
          select_strategy (dict): 選擇策略名稱並設定權重，預設是抓取權策略並平分資金比例到各策略。
                                 ex:`{'低波動本益成長比':0.5,'研發魔人':0.2, '現金':0.2}`
        Returns:
            (pd.DataFrame): strategies data
        """
        if select_strategy is None:
            s_name = self.s_data.keys()
            s_num = len(s_name)
            if s_num == 0:
                return None
            s_weight = [1 / s_num] * len(s_name)
        else:
            s_name = select_strategy.keys()
            s_weight = select_strategy.values()

        all_position = pd.concat(
            [
                self.process_position(name, weight)
                for name, weight in zip(s_name, s_weight, strict=True)
            ]
        )
        all_position["weight"] *= all_position["s_weight"]
        all_position["return"] = round(all_position["return"].astype(float), 2)
        all_position["color"] = round(
            all_position["return"].clip(
                all_position["return"].min() / 2, all_position["return"].max() / 2
            ),
            2,
        )
        all_position = all_position[all_position["weight"] > 0]
        all_position = all_position.reset_index()
        all_position = all_position[all_position["s_name"] != "playground"]
        all_position["category"] = all_position["category"].fillna("other_securities")
        return all_position

    def plot(
        self,
        select_strategy: dict[str, float] | None = None,
        path: list[str] | None = None,
        color_continuous_scale: str = "RdBu_r",
    ) -> go.Figure | None:
        """繪圖

        Args:
          select_strategy (dict): 選擇策略名稱並設定權重，預設是抓取權策略並平分資金比例到各策略。
                                 ex:`{'低波動本益成長比':0.5,'研發魔人':0.2, '現金':0.2}`
          path (list): 旭日圖由裡到外的顯示路徑，預設為`['s_name', 'market', 'category', 'stock_id']`。
                       `['market', 'category','stock_id','s_name']`也是常用選項。
          color_continuous_scale (str):[顏色變化序列的樣式名稱](https://plotly.com/python/builtin-colorscales/)

        Returns:
            (plotly.graph_objects.Figure): 策略部位旭日圖
        Examples:
            ```py
            from finlab.plot import StrategySunburst

            # 實例化物件
            strategies = StrategySunburst()
            strategies.plot().show()
            strategies.plot(select_strategy={'高殖利率烏龜':0.4,'營收強勢動能瘋狗':0.25,'低波動本益成長比':0.2,'現金':0.15},path =  ['market', 'category','stock_id','s_name']).show()
            ```
        ex1:策略選到哪些標的?
        ![市值/本益比板塊圖](img/plot/sunburst1.png)

        ex2:部位被哪些策略選到，標的若被不同策略選到，可能有獨特之處喔！
        ![市值/本益比板塊圖](img/plot/sunburst2.png)
        """
        position = self.get_strategy_df(select_strategy)
        if position is None:
            return None
        position = position[
            (position["return"] != np.inf) | (position["weight"] != np.inf)
        ]
        if path is None:
            path = ["s_name", "market", "category", "stock_id"]
        return px.sunburst(
            position,
            path=path,
            values="weight",
            color="color",
            hover_data=["return"],
            color_continuous_scale=color_continuous_scale,
            color_continuous_midpoint=0,
            width=1000,
            height=800,
        )


class StrategyReturnStats:
    def __init__(
        self,
        start_date: str,
        end_date: str,
        strategy_names: list[str] | None = None,
        benchmark_return: pd.Series | None = None,
    ) -> None:
        """繪製策略報酬率統計比較圖

        監控策略群體相對對標指數的表現。

        Args:
            start_date (str): 報酬率計算開始日
            end_date (str): 報酬率計算結束日
            strategy_names (list): 用戶本人的策略集設定，填入欲納入統計的策略名稱，只限定自己的策略。ex:`['膽小貓','三頻率RSI策略', '二次創高股票',...]`，預設為全部已上傳的策略。
            benchmark_return (pandas.Series): 策略比對基準序列，預設為台股加權報酬指數。


        Examples:

            統計2022-12-31~2023-07-31的報酬率數據
            ``` py
            # 回測起始時間
            start_date = '2022-12-31'
            end_date  = '2023-07-31'

            # 選定策略範圍
            strategy_names = ['膽小貓','三頻率RSI策略', '二次創高股票', '低波動本益成長比', '合約負債建築工', '多產業價投', '小蝦米跟大鯨魚', '小資族資優生策略', '本益成長比', '營收股價雙渦輪', '現金流價值成長', '研發魔人', '股價淨值比策略', '藏獒', '高殖利率烏龜','監獄兔', '財報指標20大']

            report = StrategyReturnStats(start_date ,end_date, strategy_names)
            # 繪製策略報酬率近期報酬率長條圖
            report.plot_strategy_last_return().show()
            # 繪製策略累積報酬率時間序列
            report.plot_strategy_creturn().show()
            ```

        """
        # 回測起始時間
        self.start_date: str = start_date
        self.end_date: str = end_date

        # 選定策略範圍
        self.s_data: dict[str, Any] = data.get_strategies()
        self.strategy_names: list[str] = (
            strategy_names if strategy_names is not None else []
        )
        self.benchmark_return: pd.Series = (
            data.get("benchmark_return:發行量加權股價報酬指數")[
                "發行量加權股價報酬指數"
            ]
            if benchmark_return is None
            else benchmark_return
        )
        self.returns_set: dict[str, float] = self._get_returns_set()

    def _get_returns_set(self) -> dict[str, float]:
        """計算報酬率數據
        Returns:
            (dict): 報酬率數據，ex: `{'膽小貓': -5.98,'股價淨值比策略': -1.68,...}`
        """
        returns_set: dict[str, float] = {}
        strategy_names = (
            self.s_data.keys() if not self.strategy_names else self.strategy_names
        )
        for s_name in strategy_names:
            try:
                s_df = self.s_data[s_name]
                returns = pd.Series(
                    s_df["returns"]["value"], index=s_df["returns"]["time"]
                )
                if self.start_date:
                    returns = returns[returns.index >= self.start_date]
                if self.end_date:
                    returns = returns[returns.index <= self.end_date]
                return_value = round(
                    ((returns.iloc[-1] / returns.iloc[0]) - 1) * 100, 2
                )
                returns_set[s_name] = return_value
            except Exception:
                pass

        return dict(sorted(returns_set.items(), key=operator.itemgetter(1)))

    def get_benchmark_return(self) -> pd.Series:
        """設定對標指數
        Returns:
            (pandas.Series): 對標指數時間序列
        """
        benchmark_return = self.benchmark_return
        return benchmark_return[
            (benchmark_return.index >= self.start_date)
            & (benchmark_return.index <= self.end_date)
        ]

    def plot_strategy_last_return(self) -> go.Figure:
        """繪製策略報酬率近期報酬率長條圖
        Returns:
            (plotly.graph_objects.Figure): 圖表物件
        ![繪製策略報酬率近期報酬率長條圖](img/plot/finlab_strategy_performance.png)
        """
        returns_set = self.returns_set
        benchmark_return = self.get_benchmark_return()
        benchmark_last_return = round(
            ((benchmark_return.iloc[-1] / benchmark_return.iloc[0]) - 1) * 100, 2
        )

        fig = go.Figure(
            go.Bar(
                x=list(returns_set.values()),
                y=list(returns_set.keys()),
                marker={
                    "color": "rgba(50, 171, 96, 0.6)",
                    "line": {"color": "rgba(50, 171, 96, 1)", "width": 3},
                },
                orientation="h",
            )
        )

        fig.add_vline(
            x=benchmark_last_return,
            line_width=3,
            line_dash="dash",
            line_color="#4a6dce",
            annotation_text=f"benchmark:{benchmark_last_return}",
            annotation_position="top left",
        )

        if returns_set:
            returns_mean = round(sum(returns_set.values()) / len(returns_set), 2)
        else:
            returns_mean = 0

        fig.add_vline(
            x=returns_mean,
            line_width=3,
            line_dash="dash",
            line_color="#aa00ff",
            annotation_font_color="#aa00ff",
            annotation_text=f"strategy_mean:{returns_mean}",
            annotation_position="bottom right",
        )

        fig.update_layout(
            title=f"FinLab Strategy Performance ({self.start_date}~{self.end_date})",
            legend={"x": 0.029, "y": 1.038, "font_size": 12},
            margin={"l": 100, "r": 20, "t": 70, "b": 70},
            paper_bgcolor="rgb(248, 248, 255)",
            plot_bgcolor="rgb(248, 248, 255)",
            xaxis_title="return(%)",
        )

        return fig

    def plot_strategy_creturn(self) -> go.Figure:
        """繪製策略累積報酬率時間序列
        Returns:
            (plotly.graph_objects.Figure): 圖表物件
        ![繪製策略累積報酬率時間序列](img/plot/finlab_strategy_creturn.png)
        """

        returns_set = self.returns_set
        benchmark_return = self.get_benchmark_return()

        sorted_s_names = list(returns_set.keys())[::-1]

        returns_set2: dict[str, pd.Series] = {}
        for s_name in sorted_s_names:
            s_df = self.s_data[s_name]
            returns = pd.Series(s_df["returns"]["value"], index=s_df["returns"]["time"])
            if self.start_date:
                returns = returns[returns.index >= self.start_date]
            if self.end_date:
                returns = returns[returns.index <= self.end_date]
            returns_set2[s_name] = round(((returns / returns.iloc[0]) - 1) * 100, 2)

        returns_df = pd.DataFrame(returns_set2).unstack().to_frame().reset_index()
        returns_df.columns = ["strategy", "date", "creturns"]
        benchmark_creturn = round(
            ((benchmark_return / benchmark_return.iloc[0]) - 1) * 100, 2
        )

        fig = px.line(returns_df, x="date", y="creturns", color="strategy")
        fig.add_trace(
            go.Scatter(
                x=benchmark_creturn.index,
                y=benchmark_creturn.values,
                fill="tonexty",
                name="benchmark",
                opacity=0.2,
                marker={
                    "color": "LightSkyBlue",
                    "opacity": 0.2,
                    "size": 20,
                    "line": {"color": "MediumPurple", "width": 2},
                },
            )
        )

        fig.update_layout(
            title=f"FinLab Strategy Creturn ({self.start_date}~{self.end_date})",
            margin={"l": 100, "r": 20, "t": 70, "b": 70},
            paper_bgcolor="rgb(248, 248, 255)",
            plot_bgcolor="rgb(248, 248, 255)",
            yaxis_title="creturn (%)",
        )

        fig.update_layout(
            yaxis_range=(
                returns_df["creturns"].min() - 0.1,
                returns_df["creturns"].max() + 0.1,
            )
        )

        return fig
