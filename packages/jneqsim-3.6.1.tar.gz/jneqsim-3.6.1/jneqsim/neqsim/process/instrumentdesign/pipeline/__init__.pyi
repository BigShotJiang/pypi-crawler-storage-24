
import sys
if sys.version_info >= (3, 8):
    from typing import Protocol
else:
    from typing_extensions import Protocol

import jneqsim.neqsim.process.equipment
import jneqsim.neqsim.process.instrumentdesign
import typing



class PipelineInstrumentDesign(jneqsim.neqsim.process.instrumentdesign.InstrumentDesign):
    def __init__(self, processEquipmentInterface: jneqsim.neqsim.process.equipment.ProcessEquipmentInterface): ...
    def calcDesign(self) -> None: ...
    def isIncludeLeakDetection(self) -> bool: ...
    def isIncludePigDetection(self) -> bool: ...
    def setIncludeLeakDetection(self, boolean: bool) -> None: ...
    def setIncludePigDetection(self, boolean: bool) -> None: ...


class __module_protocol__(Protocol):
    # A module protocol which reflects the result of ``jp.JPackage("jneqsim.neqsim.process.instrumentdesign.pipeline")``.

    PipelineInstrumentDesign: typing.Type[PipelineInstrumentDesign]
