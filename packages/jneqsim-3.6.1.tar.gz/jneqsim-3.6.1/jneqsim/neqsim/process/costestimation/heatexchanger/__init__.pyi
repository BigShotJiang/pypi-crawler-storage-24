
import sys
if sys.version_info >= (3, 8):
    from typing import Protocol
else:
    from typing_extensions import Protocol

import java.lang
import java.util
import jneqsim.neqsim.process.costestimation
import jneqsim.neqsim.process.mechanicaldesign.heatexchanger
import typing



class HeatExchangerCostEstimate(jneqsim.neqsim.process.costestimation.UnitCostEstimateBaseClass):
    def __init__(self, heatExchangerMechanicalDesign: jneqsim.neqsim.process.mechanicaldesign.heatexchanger.HeatExchangerMechanicalDesign): ...
    def calcUtilityOperatingCost(self, string: typing.Union[java.lang.String, str], double: float) -> float: ...
    def getCostBreakdown(self) -> java.util.Map[java.lang.String, typing.Any]: ...
    def getExchangerType(self) -> java.lang.String: ...
    def getTotalCost(self) -> float: ...
    def setExchangerType(self, string: typing.Union[java.lang.String, str]) -> None: ...
    def setTemaType(self, string: typing.Union[java.lang.String, str]) -> None: ...


class __module_protocol__(Protocol):
    # A module protocol which reflects the result of ``jp.JPackage("jneqsim.neqsim.process.costestimation.heatexchanger")``.

    HeatExchangerCostEstimate: typing.Type[HeatExchangerCostEstimate]
