"""
Polymarket API client (root-level shim for local dev / market_radar.py).
Re-exports everything from the package.
"""

from polymarket_mcp.client import (  # noqa: F401
    search_markets_api,
    get_markets,
    get_market_by_id,
    get_orderbook,
)
