"""
Polymarket MCP Server — local entry point.

For development, run:   python server.py
For production, use:    polymarket-mcp  (after pip install)
                   or:  uvx polymarket-mcp
"""

from polymarket_mcp.server import main

if __name__ == "__main__":
    main()
