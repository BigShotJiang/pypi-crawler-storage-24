"""Polymarket MCP Server — query prediction-market data with AI agents."""
