"""
Polymarket MCP Server

The simplest way to query Polymarket prediction-market data
with AI agents via the Model Context Protocol.
"""

from fastmcp import FastMCP
from polymarket_mcp.tools import register_tools

mcp = FastMCP(
    name="Polymarket MCP",
    instructions=(
        "You are a Polymarket data assistant. "
        "Use the available tools to search, discover, and analyse "
        "prediction markets. Return clear, structured answers."
    ),
)

register_tools(mcp)


def main() -> None:
    """Entry point for the console script."""
    mcp.run()


if __name__ == "__main__":
    main()
