"""
Example queries you can run against the Polymarket MCP server.

These show how to call each tool programmatically using
the FastMCP Client.  Run:

    python examples/example_queries.py
"""

import asyncio
import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastmcp import Client


def pp(data) -> None:
    """Pretty-print JSON-serialisable data."""
    print(json.dumps(data, indent=2, default=str))


async def main() -> None:
    async with Client("python server.py") as client:
        print("Connected to Polymarket MCP server\n")
        tools = await client.list_tools()
        print(f"Available tools: {[t.name for t in tools]}\n")

        # 1 — Search markets
        print("=" * 60)
        print("🔍  search_markets('bitcoin')")
        print("=" * 60)
        result = await client.call_tool("search_markets", {"query": "bitcoin", "limit": 5})
        pp(result)

        # 2 — Trending markets
        print("\n" + "=" * 60)
        print("🔥  trending_markets(limit=5)")
        print("=" * 60)
        result = await client.call_tool("trending_markets", {"limit": 5})
        pp(result)

        # 3 — Newest markets
        print("\n" + "=" * 60)
        print("🆕  new_markets(limit=5)")
        print("=" * 60)
        result = await client.call_tool("new_markets", {"limit": 5})
        pp(result)

        # 4 — Markets closing soon
        print("\n" + "=" * 60)
        print("⏳  markets_closing_soon(hours=48)")
        print("=" * 60)
        result = await client.call_tool("markets_closing_soon", {"hours": 48})
        pp(result)


asyncio.run(main())
