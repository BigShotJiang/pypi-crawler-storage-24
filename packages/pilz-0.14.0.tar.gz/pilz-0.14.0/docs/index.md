# Pilz


Disclaimer the docu still work in progress.


The code of the project can be found here:
gitlab : https://gitlab.com/gwhe/pilz


## Install 

At the moment the project is only running on mac (arm) and linux (x86). Since it requires mi-amore and mi-amore is not available for windows.


```bash
pip install pilz
```

or in case you use uv

```bash
uv init --python 3.13 pmushroom
cd mushroom
uv add pilz
source .venv/bin/activate
```

## Run 

### Download Data

got to https://www.kaggle.com/datasets/uciml/iris and Donwload the dataset.

```bash
pilz create-dc --src Iris.csv --out df_iris.yaml
```