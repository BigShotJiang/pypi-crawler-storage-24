<p align="center">
  <img src="logthread-logo.png" alt="Log Thread" width="420" />
</p>

# Log Thread

**Code intelligence that makes AI assistants dramatically more accurate.**

Log Thread analyzes your codebase and provides deep contextual understanding to AI coding assistants, enabling them to write better code with fewer errors and hallucinations.

```
$ logthread analyze .

Analyzing your codebase...
✓ Indexed 142 files
✓ Found 623 symbols and their relationships
✓ Detected 8 architectural modules
✓ Identified 34 execution flows

Done in 4.2s
```

---

## Why Log Thread?

**Stop AI hallucinations. Start shipping accurate code.**

Traditional AI coding assistants guess at your codebase structure, leading to duplicate functions, broken imports, and code that doesn't match your patterns. Log Thread solves this by understanding your entire codebase before making suggestions.

**Benefits:**
- ✅ **No more duplicate code** — AI sees what already exists
- ✅ **Accurate imports** — Knows exactly where functions live
- ✅ **Consistent patterns** — Follows your existing code style
- ✅ **Impact awareness** — Understands what will break before suggesting changes
- ✅ **Works with any AI** — Cursor, Windsurf, Claude, ChatGPT, or any MCP-compatible tool

---

## Quick Start

```bash
# Install
pip install logthread

# Authenticate (required)
logthread login

# Index your codebase
cd your-project
logthread analyze .

# Start using with your AI assistant
logthread serve --watch
```

---

## Features

### 🔍 Smart Code Search
Find exactly what you need, not just keyword matches. Results are organized by how code actually flows together.

### 🎯 Impact Analysis
See what will break before you change it. Log Thread shows which parts of your code depend on each function.

### 🏗️ Architecture Understanding
Automatically identifies which parts of your codebase work together as modules and subsystems.

### 💀 Dead Code Detection
Find unused functions and files that are safe to delete.

### 🔄 Live Updates
Automatically re-indexes when you save files, keeping context fresh.

### 📊 Visual Dashboard
Browse your codebase visually with an interactive web interface.

---

## Supported Languages

Python • TypeScript • JavaScript • Go • Java • C# • Ruby

---

## Setup with Your AI Assistant

### Cursor
Add to your MCP settings (`~/.cursor/mcp.json`):
```json
{
  "logthread": {
    "command": "logthread",
    "args": ["serve", "--watch", "--path", "/absolute/path/to/your/project"]
  }
}
```

### Windsurf
Add to your MCP config (`~/.codeium/windsurf/mcp_config.json`):
```json
{
  "mcpServers": {
    "logthread": {
      "command": "logthread",
      "args": ["serve", "--watch", "--path", "/absolute/path/to/your/project"]
    }
  }
}
```

### Claude Desktop
Add to your Claude config (`~/Library/Application Support/Claude/claude_desktop_config.json`):
```json
{
  "mcpServers": {
    "logthread": {
      "command": "logthread",
      "args": ["serve", "--watch", "--path", "/absolute/path/to/your/project"]
    }
  }
}
```

> **Note:** Replace `/absolute/path/to/your/project` with the full path to your indexed repository. The `--path` option is required so the MCP server knows which codebase to serve.

After setup, restart your AI assistant. Log Thread will automatically provide code intelligence context.

---

## Pricing

**$4.99/month** — Unlimited repositories, unlimited AI queries

Start with a free account at [logthread.dev](https://logthread.dev)

---

## CLI Commands

```bash
logthread login              # Authenticate
logthread analyze .          # Index current directory
logthread serve --watch      # Start MCP server
logthread ui                 # Open dashboard
logthread status             # Show index info
```

---

## Support

Questions or issues? Email us at hello@logthread.dev

---

**Log Thread** — Make your AI assistant smarter.
