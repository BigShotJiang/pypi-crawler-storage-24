# Log Thread VS Code Extension

AI-powered code intelligence with graph context — make even smaller models write production-quality code.

## Features

- **AI Chat with Graph Context** — Every conversation automatically includes relevant code context from the knowledge graph
- **Symbol Context View** — See callers, callees, type references, and community membership for any symbol
- **Impact Analysis** — Know what breaks before you make changes
- **Inline Completions** — AI completions enriched with structural understanding
- **Multi-Provider Support** — Works with Gemini, Claude, GPT, and Ollama

## Requirements

- Python 3.11+
- Log Thread CLI installed: `pip install logthread`
- API key for your chosen AI provider

## Installation

1. Install the Log Thread Python package:
   ```bash
   pip install logthread
   ```

2. Install this extension from VS Code marketplace (or build from source)

3. Configure your AI provider in settings:
   - `logthread.aiProvider`: Choose from `gemini`, `anthropic`, `openai`, `ollama`
   - `logthread.apiKey`: Your API key
   - `logthread.aiModel`: Model to use (e.g., `gemini-2.5-flash-preview-05-20`)

## Usage

### Index Your Workspace

1. Open a project folder in VS Code
2. Run `Log Thread: Analyze Workspace` from the command palette (Cmd+Shift+P)
3. Wait for indexing to complete

### AI Chat

1. Press `Cmd+Shift+L` to open the AI chat panel
2. Ask questions about your code — the graph context is automatically included
3. Get accurate responses that understand your codebase structure

### Symbol Context

1. Place cursor on any symbol
2. Press `Cmd+Shift+K` or right-click → "Log Thread: Show Context"
3. See the full 360° view: callers, callees, types, community

### Impact Analysis

1. Right-click on a symbol
2. Select "Log Thread: Impact Analysis"
3. See all affected symbols grouped by depth

## Configuration

| Setting | Description | Default |
|---------|-------------|---------|
| `logthread.aiProvider` | AI provider (gemini/anthropic/openai/ollama) | `gemini` |
| `logthread.aiModel` | Model identifier | `gemini-2.5-flash-preview-05-20` |
| `logthread.apiKey` | API key for the provider | - |
| `logthread.autoIndex` | Auto-index on workspace open | `true` |
| `logthread.watchFiles` | Re-index on file changes | `true` |
| `logthread.contextDepth` | Depth of context to fetch | `3` |
| `logthread.includeCoupling` | Include change coupling info | `true` |

## Commands

| Command | Shortcut | Description |
|---------|----------|-------------|
| Log Thread: Analyze Workspace | - | Index the current workspace |
| Log Thread: Open AI Chat | Cmd+Shift+L | Open the AI chat panel |
| Log Thread: Show Context | Cmd+Shift+K | Show context for symbol at cursor |
| Log Thread: Impact Analysis | - | Analyze impact of changing symbol |
| Log Thread: Show Knowledge Graph | - | Open the graph explorer |
| Log Thread: Configure | - | Open settings |

## How It Works

```
┌─────────────────────────────────────────────┐
│              YOUR CODE EDITOR               │
└─────────────────────┬───────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────┐
│           LOG THREAD EXTENSION              │
│                                             │
│  1. Intercepts AI requests                  │
│  2. Queries knowledge graph for context     │
│  3. Enriches prompts with:                  │
│     - Related functions                     │
│     - Type definitions                      │
│     - Call relationships                    │
│     - Existing patterns                     │
└─────────────────────┬───────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────┐
│              AI MODEL                       │
│  (Gemini Flash / Haiku / GPT-4o-mini)      │
│                                             │
│  Produces accurate code that:               │
│  ✓ Reuses existing utilities                │
│  ✓ Follows established patterns             │
│  ✓ Maintains type safety                    │
└─────────────────────────────────────────────┘
```

## Development

```bash
cd vscode-extension
npm install
npm run compile
```

To test:
1. Press F5 in VS Code to launch Extension Development Host
2. Open a project and test the features

## Building

```bash
npm run package
```

This creates a `.vsix` file you can install manually.

## License

MIT
