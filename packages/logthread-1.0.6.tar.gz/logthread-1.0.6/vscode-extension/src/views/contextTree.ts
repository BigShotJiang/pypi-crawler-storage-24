import * as vscode from 'vscode';
import { SymbolContext } from '../services/logthread';

export class ContextTreeProvider implements vscode.TreeDataProvider<ContextItem> {
    private _onDidChangeTreeData = new vscode.EventEmitter<ContextItem | undefined>();
    readonly onDidChangeTreeData = this._onDidChangeTreeData.event;

    private currentContext: SymbolContext | null = null;

    constructor(private logthreadService: any) {}

    refresh(context: SymbolContext): void {
        this.currentContext = context;
        this._onDidChangeTreeData.fire(undefined);
    }

    getTreeItem(element: ContextItem): vscode.TreeItem {
        return element;
    }

    getChildren(element?: ContextItem): Thenable<ContextItem[]> {
        if (!this.currentContext) {
            return Promise.resolve([
                new ContextItem(
                    'No symbol selected',
                    'Select a symbol and use "Log Thread: Show Context"',
                    vscode.TreeItemCollapsibleState.None
                )
            ]);
        }

        if (!element) {
            // Root level - show main sections
            const items: ContextItem[] = [];

            // Symbol info
            const symbolItem = new ContextItem(
                this.currentContext.name,
                this.currentContext.type,
                vscode.TreeItemCollapsibleState.Expanded,
                'symbol'
            );
            symbolItem.iconPath = this.getIconForType(this.currentContext.type);
            items.push(symbolItem);

            // Location
            const locationItem = new ContextItem(
                'Location',
                `${this.currentContext.filePath}:${this.currentContext.startLine}`,
                vscode.TreeItemCollapsibleState.None,
                'location'
            );
            locationItem.iconPath = new vscode.ThemeIcon('file-code');
            items.push(locationItem);

            // Callers
            if (this.currentContext.callers.length > 0) {
                items.push(new ContextItem(
                    'Callers',
                    `${this.currentContext.callers.length} symbols call this`,
                    vscode.TreeItemCollapsibleState.Collapsed,
                    'callers'
                ));
            }

            // Callees
            if (this.currentContext.callees.length > 0) {
                items.push(new ContextItem(
                    'Calls',
                    `Calls ${this.currentContext.callees.length} symbols`,
                    vscode.TreeItemCollapsibleState.Collapsed,
                    'callees'
                ));
            }

            // Type references
            if (this.currentContext.typeRefs.length > 0) {
                items.push(new ContextItem(
                    'Type References',
                    `${this.currentContext.typeRefs.length} types`,
                    vscode.TreeItemCollapsibleState.Collapsed,
                    'types'
                ));
            }

            // Community
            if (this.currentContext.community) {
                const communityItem = new ContextItem(
                    'Community',
                    this.currentContext.community,
                    vscode.TreeItemCollapsibleState.None,
                    'community'
                );
                communityItem.iconPath = new vscode.ThemeIcon('symbol-namespace');
                items.push(communityItem);
            }

            // Dead code warning
            if (this.currentContext.isDead) {
                const deadItem = new ContextItem(
                    '⚠️ Dead Code',
                    'This symbol appears to be unreachable',
                    vscode.TreeItemCollapsibleState.None,
                    'dead'
                );
                deadItem.iconPath = new vscode.ThemeIcon('warning');
                items.push(deadItem);
            }

            return Promise.resolve(items);
        }

        // Child items
        switch (element.contextType) {
            case 'callers':
                return Promise.resolve(
                    this.currentContext.callers.map(caller => {
                        const item = new ContextItem(
                            caller,
                            'caller',
                            vscode.TreeItemCollapsibleState.None
                        );
                        item.iconPath = new vscode.ThemeIcon('arrow-left');
                        item.command = {
                            command: 'logthread.contextForSymbol',
                            title: 'Show Context',
                            arguments: [caller]
                        };
                        return item;
                    })
                );

            case 'callees':
                return Promise.resolve(
                    this.currentContext.callees.map(callee => {
                        const item = new ContextItem(
                            callee,
                            'callee',
                            vscode.TreeItemCollapsibleState.None
                        );
                        item.iconPath = new vscode.ThemeIcon('arrow-right');
                        item.command = {
                            command: 'logthread.contextForSymbol',
                            title: 'Show Context',
                            arguments: [callee]
                        };
                        return item;
                    })
                );

            case 'types':
                return Promise.resolve(
                    this.currentContext.typeRefs.map(type => {
                        const item = new ContextItem(
                            type,
                            'type reference',
                            vscode.TreeItemCollapsibleState.None
                        );
                        item.iconPath = new vscode.ThemeIcon('symbol-interface');
                        return item;
                    })
                );

            default:
                return Promise.resolve([]);
        }
    }

    private getIconForType(type: string): vscode.ThemeIcon {
        switch (type.toLowerCase()) {
            case 'function':
                return new vscode.ThemeIcon('symbol-function');
            case 'class':
                return new vscode.ThemeIcon('symbol-class');
            case 'method':
                return new vscode.ThemeIcon('symbol-method');
            case 'interface':
                return new vscode.ThemeIcon('symbol-interface');
            case 'enum':
                return new vscode.ThemeIcon('symbol-enum');
            default:
                return new vscode.ThemeIcon('symbol-variable');
        }
    }
}

class ContextItem extends vscode.TreeItem {
    constructor(
        public readonly label: string,
        public readonly description: string,
        public readonly collapsibleState: vscode.TreeItemCollapsibleState,
        public readonly contextType?: string
    ) {
        super(label, collapsibleState);
        this.tooltip = `${this.label} - ${this.description}`;
    }
}
