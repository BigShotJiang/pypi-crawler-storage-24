import * as vscode from 'vscode';
import { LogThreadService } from '../services/logthread';
import { AIService, ChatMessage } from '../services/ai';

export class ChatViewProvider implements vscode.WebviewViewProvider {
    private webviewView?: vscode.WebviewView;
    private messages: ChatMessage[] = [];

    constructor(
        private context: vscode.ExtensionContext,
        private logthreadService: LogThreadService,
        private aiService: AIService
    ) {}

    resolveWebviewView(
        webviewView: vscode.WebviewView,
        _context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken
    ): void {
        this.webviewView = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this.context.extensionUri]
        };

        webviewView.webview.html = this.getHtmlContent();

        webviewView.webview.onDidReceiveMessage(async (message) => {
            switch (message.type) {
                case 'sendMessage':
                    await this.handleUserMessage(message.text);
                    break;
                case 'clear':
                    this.messages = [];
                    this.updateChat();
                    break;
            }
        });
    }

    private async handleUserMessage(text: string): Promise<void> {
        // Add user message
        this.messages.push({ role: 'user', content: text });
        this.updateChat();

        // Get relevant context from knowledge graph
        const editor = vscode.window.activeTextEditor;
        let graphContext = null;

        if (editor) {
            const position = editor.selection.active;
            graphContext = await this.logthreadService.getContextForPosition(
                editor.document.uri.fsPath,
                position.line,
                position.character
            );
        }

        try {
            // Generate AI response with graph context
            const response = await this.aiService.generateChatResponse(
                this.messages,
                graphContext
            );

            this.messages.push({ role: 'assistant', content: response });
            this.updateChat();
        } catch (error) {
            this.messages.push({ 
                role: 'assistant', 
                content: `Error: ${error instanceof Error ? error.message : 'Unknown error'}` 
            });
            this.updateChat();
        }
    }

    private updateChat(): void {
        if (this.webviewView) {
            this.webviewView.webview.postMessage({
                type: 'updateMessages',
                messages: this.messages
            });
        }
    }

    private getHtmlContent(): string {
        return `<!DOCTYPE html>
<html>
<head>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: var(--vscode-font-family);
            background: var(--vscode-editor-background);
            color: var(--vscode-editor-foreground);
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .messages {
            flex: 1;
            overflow-y: auto;
            padding: 12px;
        }
        .message {
            margin-bottom: 12px;
            padding: 10px 14px;
            border-radius: 8px;
            max-width: 90%;
        }
        .message.user {
            background: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
            margin-left: auto;
        }
        .message.assistant {
            background: var(--vscode-editor-inactiveSelectionBackground);
        }
        .message pre {
            background: var(--vscode-textCodeBlock-background);
            padding: 8px;
            border-radius: 4px;
            overflow-x: auto;
            margin: 8px 0;
        }
        .message code {
            font-family: var(--vscode-editor-font-family);
            font-size: 12px;
        }
        .input-area {
            padding: 12px;
            border-top: 1px solid var(--vscode-panel-border);
            display: flex;
            gap: 8px;
        }
        textarea {
            flex: 1;
            background: var(--vscode-input-background);
            color: var(--vscode-input-foreground);
            border: 1px solid var(--vscode-input-border);
            border-radius: 4px;
            padding: 8px;
            font-family: var(--vscode-font-family);
            font-size: 13px;
            resize: none;
            min-height: 60px;
        }
        textarea:focus {
            outline: 1px solid var(--vscode-focusBorder);
        }
        button {
            background: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
        }
        button:hover {
            background: var(--vscode-button-hoverBackground);
        }
        .header {
            padding: 8px 12px;
            border-bottom: 1px solid var(--vscode-panel-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h3 {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--vscode-descriptionForeground);
        }
        .clear-btn {
            background: transparent;
            color: var(--vscode-descriptionForeground);
            padding: 4px 8px;
            font-size: 11px;
        }
        .context-indicator {
            font-size: 10px;
            color: var(--vscode-descriptionForeground);
            padding: 4px 12px;
            background: var(--vscode-editor-inactiveSelectionBackground);
        }
    </style>
</head>
<body>
    <div class="header">
        <h3>Log Thread AI</h3>
        <button class="clear-btn" onclick="clearChat()">Clear</button>
    </div>
    <div class="context-indicator">
        📊 Graph context is automatically included with each message
    </div>
    <div class="messages" id="messages"></div>
    <div class="input-area">
        <textarea id="input" placeholder="Ask about your code..." 
            onkeydown="handleKeydown(event)"></textarea>
        <button onclick="sendMessage()">Send</button>
    </div>

    <script>
        const vscode = acquireVsCodeApi();
        const messagesDiv = document.getElementById('messages');
        const input = document.getElementById('input');

        function sendMessage() {
            const text = input.value.trim();
            if (!text) return;
            
            vscode.postMessage({ type: 'sendMessage', text });
            input.value = '';
        }

        function clearChat() {
            vscode.postMessage({ type: 'clear' });
        }

        function handleKeydown(e) {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                sendMessage();
            }
        }

        function renderMessage(msg) {
            const div = document.createElement('div');
            div.className = 'message ' + msg.role;
            
            // Simple markdown rendering
            let content = msg.content
                .replace(/\`\`\`(\\w*)\\n([\\s\\S]*?)\`\`\`/g, '<pre><code>$2</code></pre>')
                .replace(/\`([^\`]+)\`/g, '<code>$1</code>')
                .replace(/\\n/g, '<br>');
            
            div.innerHTML = content;
            return div;
        }

        window.addEventListener('message', event => {
            const message = event.data;
            if (message.type === 'updateMessages') {
                messagesDiv.innerHTML = '';
                message.messages.forEach(msg => {
                    messagesDiv.appendChild(renderMessage(msg));
                });
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }
        });
    </script>
</body>
</html>`;
    }
}
