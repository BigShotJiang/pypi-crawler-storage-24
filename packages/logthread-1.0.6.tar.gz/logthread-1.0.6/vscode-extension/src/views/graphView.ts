import * as vscode from 'vscode';
import { LogThreadService } from '../services/logthread';

export class GraphViewProvider implements vscode.WebviewViewProvider {
    private webviewView?: vscode.WebviewView;

    constructor(
        private context: vscode.ExtensionContext,
        private logthreadService: LogThreadService
    ) {}

    resolveWebviewView(
        webviewView: vscode.WebviewView,
        _context: vscode.WebviewViewResolveContext,
        _token: vscode.CancellationToken
    ): void {
        this.webviewView = webviewView;

        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this.context.extensionUri]
        };

        webviewView.webview.html = this.getHtmlContent();

        webviewView.webview.onDidReceiveMessage(async (message) => {
            switch (message.type) {
                case 'nodeClick':
                    await this.handleNodeClick(message.nodeId);
                    break;
                case 'search':
                    await this.handleSearch(message.query);
                    break;
                case 'openFullGraph':
                    await this.openFullGraph();
                    break;
                case 'cloudSync':
                    await this.handleCloudSync();
                    break;
            }
        });
    }

    private async handleNodeClick(nodeId: string): Promise<void> {
        const context = await this.logthreadService.getContext(nodeId);
        if (context) {
            // Open the file at the symbol location
            const doc = await vscode.workspace.openTextDocument(context.filePath);
            const editor = await vscode.window.showTextDocument(doc);
            const position = new vscode.Position(context.startLine - 1, 0);
            editor.selection = new vscode.Selection(position, position);
            editor.revealRange(
                new vscode.Range(position, position),
                vscode.TextEditorRevealType.InCenter
            );
        }
    }

    private async handleSearch(query: string): Promise<void> {
        const results = await this.logthreadService.query(query, 10);
        if (this.webviewView) {
            this.webviewView.webview.postMessage({
                type: 'searchResults',
                results
            });
        }
    }

    private async openFullGraph(): Promise<void> {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (workspaceFolders) {
            const cloudUrl = this.logthreadService.getCloudExploreUrl(workspaceFolders[0].uri.fsPath);
            vscode.env.openExternal(vscode.Uri.parse(cloudUrl));
        } else {
            vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/dashboard'));
        }
    }

    private async handleCloudSync(): Promise<void> {
        const workspaceFolders = vscode.workspace.workspaceFolders;
        if (!workspaceFolders) {
            vscode.window.showWarningMessage('No workspace folder open');
            return;
        }

        if (!this.logthreadService.isLoggedIn) {
            const login = await vscode.window.showInformationMessage(
                'You need to log in to sync to Log Thread Cloud',
                'Login'
            );
            if (login === 'Login') {
                await this.logthreadService.login();
            }
            return;
        }

        if (!this.logthreadService.hasCloudSyncConsent()) {
            const consent = await vscode.window.showInformationMessage(
                'To sync your code graph to Log Thread Cloud, you must agree to our Terms of Service and Privacy Policy.',
                { modal: true },
                'View Terms',
                'I Agree'
            );

            if (consent === 'View Terms') {
                vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/terms'));
                return;
            }
            
            if (consent !== 'I Agree') {
                return;
            }
        }

        await vscode.window.withProgress(
            {
                location: vscode.ProgressLocation.Notification,
                title: 'Syncing to Log Thread Cloud...',
                cancellable: false
            },
            async () => {
                const success = await this.logthreadService.syncToCloud(workspaceFolders[0].uri.fsPath);
                if (success) {
                    const cloudUrl = this.logthreadService.getCloudExploreUrl(workspaceFolders[0].uri.fsPath);
                    vscode.window.showInformationMessage(
                        'Synced to Log Thread Cloud!',
                        'Open in Browser'
                    ).then(selection => {
                        if (selection === 'Open in Browser') {
                            vscode.env.openExternal(vscode.Uri.parse(cloudUrl));
                        }
                    });
                } else {
                    vscode.window.showErrorMessage('Failed to sync to cloud. Check the output for details.');
                }
            }
        );
    }

    private getHtmlContent(): string {
        return `<!DOCTYPE html>
<html>
<head>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: var(--vscode-font-family);
            background: var(--vscode-editor-background);
            color: var(--vscode-editor-foreground);
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            padding: 8px 12px;
            border-bottom: 1px solid var(--vscode-panel-border);
        }
        .header h3 {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--vscode-descriptionForeground);
            margin-bottom: 8px;
        }
        .search-box {
            display: flex;
            gap: 8px;
        }
        input {
            flex: 1;
            background: var(--vscode-input-background);
            color: var(--vscode-input-foreground);
            border: 1px solid var(--vscode-input-border);
            border-radius: 4px;
            padding: 6px 10px;
            font-size: 12px;
        }
        input:focus {
            outline: 1px solid var(--vscode-focusBorder);
        }
        .graph-container {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .graph-placeholder {
            text-align: center;
            color: var(--vscode-descriptionForeground);
        }
        .graph-placeholder svg {
            width: 64px;
            height: 64px;
            margin-bottom: 12px;
            opacity: 0.5;
        }
        .results {
            flex: 1;
            overflow-y: auto;
            padding: 8px;
        }
        .result-item {
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 4px;
        }
        .result-item:hover {
            background: var(--vscode-list-hoverBackground);
        }
        .result-name {
            font-weight: 500;
            font-size: 13px;
        }
        .result-type {
            font-size: 11px;
            color: var(--vscode-descriptionForeground);
        }
        .result-path {
            font-size: 10px;
            color: var(--vscode-descriptionForeground);
            margin-top: 2px;
        }
        .footer {
            padding: 8px 12px;
            border-top: 1px solid var(--vscode-panel-border);
            text-align: center;
        }
        button {
            background: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }
        button:hover {
            background: var(--vscode-button-hoverBackground);
        }
    </style>
</head>
<body>
    <div class="header">
        <h3>Graph Explorer</h3>
        <div class="search-box">
            <input type="text" id="search" placeholder="Search symbols..." 
                onkeyup="handleSearch(event)" />
        </div>
    </div>
    
    <div class="results" id="results">
        <div class="graph-placeholder">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <circle cx="12" cy="5" r="3"/>
                <circle cx="5" cy="19" r="3"/>
                <circle cx="19" cy="19" r="3"/>
                <line x1="12" y1="8" x2="5" y2="16"/>
                <line x1="12" y1="8" x2="19" y2="16"/>
            </svg>
            <p>Search for symbols to explore<br>the knowledge graph</p>
        </div>
    </div>
    
    <div class="footer">
        <button onclick="cloudSync()" class="sync-btn">☁️ Sync to Cloud</button>
        <button onclick="openFullGraph()">Open Full Graph UI</button>
    </div>

    <script>
        const vscode = acquireVsCodeApi();
        const resultsDiv = document.getElementById('results');
        const searchInput = document.getElementById('search');
        let searchTimeout;

        function handleSearch(e) {
            clearTimeout(searchTimeout);
            const query = e.target.value.trim();
            
            if (query.length < 2) {
                resultsDiv.innerHTML = \`
                    <div class="graph-placeholder">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="12" cy="5" r="3"/>
                            <circle cx="5" cy="19" r="3"/>
                            <circle cx="19" cy="19" r="3"/>
                            <line x1="12" y1="8" x2="5" y2="16"/>
                            <line x1="12" y1="8" x2="19" y2="16"/>
                        </svg>
                        <p>Search for symbols to explore<br>the knowledge graph</p>
                    </div>
                \`;
                return;
            }
            
            searchTimeout = setTimeout(() => {
                vscode.postMessage({ type: 'search', query });
            }, 300);
        }

        function openFullGraph() {
            vscode.postMessage({ type: 'openFullGraph' });
        }

        function cloudSync() {
            vscode.postMessage({ type: 'cloudSync' });
        }

        function clickNode(nodeId) {
            vscode.postMessage({ type: 'nodeClick', nodeId });
        }

        window.addEventListener('message', event => {
            const message = event.data;
            if (message.type === 'searchResults') {
                if (message.results.length === 0) {
                    resultsDiv.innerHTML = '<div class="graph-placeholder"><p>No results found</p></div>';
                    return;
                }
                
                resultsDiv.innerHTML = message.results.map(r => \`
                    <div class="result-item" onclick="clickNode('\${r.name}')">
                        <div class="result-name">\${r.name}</div>
                        <div class="result-type">\${r.type}</div>
                        <div class="result-path">\${r.filePath}:\${r.startLine}</div>
                    </div>
                \`).join('');
            }
        });
    </script>
</body>
</html>`;
    }
}
