import * as vscode from 'vscode';
import { GraphContext } from './logthread';

export interface AIProvider {
    name: string;
    generateCompletion(prompt: string, context: GraphContext | null): Promise<string>;
    generateChat(messages: ChatMessage[], context: GraphContext | null): Promise<string>;
}

export interface ChatMessage {
    role: 'user' | 'assistant' | 'system';
    content: string;
}

export class AIService {
    private provider: AIProvider | null = null;

    constructor(private context: vscode.ExtensionContext) {
        this.initializeProvider();
        
        vscode.workspace.onDidChangeConfiguration(e => {
            if (e.affectsConfiguration('logthread.aiProvider') || 
                e.affectsConfiguration('logthread.aiModel') ||
                e.affectsConfiguration('logthread.apiKey')) {
                this.initializeProvider();
            }
        });
    }

    private initializeProvider(): void {
        const config = vscode.workspace.getConfiguration('logthread');
        const providerName = config.get<string>('aiProvider', 'gemini');
        const model = config.get<string>('aiModel', 'gemini-2.5-flash-native-audio-preview-09-2025');
        const apiKey = config.get<string>('apiKey', '');
        const ollamaEndpoint = config.get<string>('ollamaEndpoint', 'http://localhost:11434');

        switch (providerName) {
            case 'gemini':
                this.provider = new GeminiProvider(apiKey, model);
                break;
            case 'anthropic':
                this.provider = new AnthropicProvider(apiKey, model);
                break;
            case 'openai':
                this.provider = new OpenAIProvider(apiKey, model);
                break;
            case 'ollama':
                this.provider = new OllamaProvider(ollamaEndpoint, model);
                break;
            case 'disabled':
                this.provider = null;
                break;
            default:
                this.provider = new GeminiProvider(apiKey, model);
        }
    }

    async generateCompletion(
        documentText: string,
        position: vscode.Position,
        linePrefix: string,
        graphContext: GraphContext | null
    ): Promise<string | null> {
        if (!this.provider) {
            return null;
        }

        const prompt = this.buildCompletionPrompt(documentText, position, linePrefix, graphContext);
        
        try {
            return await this.provider.generateCompletion(prompt, graphContext);
        } catch (error) {
            console.error('AI completion error:', error);
            return null;
        }
    }

    async generateChatResponse(
        messages: ChatMessage[],
        graphContext: GraphContext | null
    ): Promise<string> {
        if (!this.provider) {
            throw new Error('No AI provider configured');
        }

        // Inject graph context into system message
        const systemMessage = this.buildSystemMessage(graphContext);
        const messagesWithContext: ChatMessage[] = [
            { role: 'system', content: systemMessage },
            ...messages
        ];

        return await this.provider.generateChat(messagesWithContext, graphContext);
    }

    private buildCompletionPrompt(
        documentText: string,
        position: vscode.Position,
        linePrefix: string,
        context: GraphContext | null
    ): string {
        let prompt = `You are an expert code assistant. Complete the following code.

Current file content:
\`\`\`
${documentText}
\`\`\`

Cursor is at line ${position.line + 1}, column ${position.character + 1}.
Current line prefix: "${linePrefix}"

`;

        if (context && context.symbols.length > 0) {
            prompt += `\n## Relevant Code Context from Knowledge Graph\n\n`;
            
            for (const symbol of context.symbols) {
                prompt += `### ${symbol.type}: ${symbol.name}\n`;
                prompt += `File: ${symbol.filePath}:${symbol.startLine}\n`;
                if (symbol.signature) {
                    prompt += `Signature: ${symbol.signature}\n`;
                }
                if (symbol.callers.length > 0) {
                    prompt += `Called by: ${symbol.callers.slice(0, 3).join(', ')}\n`;
                }
                if (symbol.callees.length > 0) {
                    prompt += `Calls: ${symbol.callees.slice(0, 3).join(', ')}\n`;
                }
                prompt += '\n';
            }

            if (context.relationships.length > 0) {
                prompt += `### Relationships\n`;
                for (const rel of context.relationships.slice(0, 10)) {
                    prompt += `- ${rel.from} --[${rel.type}]--> ${rel.to}\n`;
                }
                prompt += '\n';
            }
        }

        prompt += `\nProvide ONLY the code completion, no explanations. The completion should continue naturally from the cursor position.`;

        return prompt;
    }

    private buildSystemMessage(context: GraphContext | null): string {
        let systemMsg = `You are Log Thread AI, an expert code assistant with deep understanding of the user's codebase.

Your capabilities:
- You understand the full structure of the codebase through a knowledge graph
- You can see function calls, type relationships, and architectural patterns
- You write code that follows existing patterns and reuses existing utilities
- You never duplicate code that already exists
- You maintain type safety and follow the codebase's conventions

`;

        if (context && context.symbols.length > 0) {
            systemMsg += `## Current Codebase Context\n\n`;
            systemMsg += `The following symbols are relevant to the current task:\n\n`;
            
            for (const symbol of context.symbols) {
                systemMsg += `### ${symbol.type}: \`${symbol.name}\`\n`;
                systemMsg += `- Location: \`${symbol.filePath}:${symbol.startLine}\`\n`;
                if (symbol.signature) {
                    systemMsg += `- Signature: \`${symbol.signature}\`\n`;
                }
                if (symbol.community) {
                    systemMsg += `- Module/Community: ${symbol.community}\n`;
                }
                if (symbol.callers.length > 0) {
                    systemMsg += `- Called by: ${symbol.callers.slice(0, 5).join(', ')}\n`;
                }
                if (symbol.callees.length > 0) {
                    systemMsg += `- Calls: ${symbol.callees.slice(0, 5).join(', ')}\n`;
                }
                if (symbol.typeRefs.length > 0) {
                    systemMsg += `- Uses types: ${symbol.typeRefs.slice(0, 5).join(', ')}\n`;
                }
                if (symbol.isDead) {
                    systemMsg += `- ⚠️ This symbol appears to be dead code\n`;
                }
                systemMsg += '\n';
            }

            if (context.relationships.length > 0) {
                systemMsg += `## Code Relationships\n\n`;
                for (const rel of context.relationships) {
                    systemMsg += `- \`${rel.from}\` --[${rel.type}]--> \`${rel.to}\` (confidence: ${rel.confidence})\n`;
                }
                systemMsg += '\n';
            }

            if (context.relevantCode.length > 0) {
                systemMsg += `## Relevant Code Snippets\n\n`;
                for (const code of context.relevantCode) {
                    systemMsg += `### ${code.path}:${code.startLine}-${code.endLine}\n`;
                    systemMsg += `\`\`\`\n${code.content}\n\`\`\`\n\n`;
                }
            }
        }

        systemMsg += `\nWhen writing code:
1. Reuse existing functions and utilities shown in the context
2. Follow the patterns established in the codebase
3. Maintain consistent naming conventions
4. Ensure type safety
5. Don't duplicate existing functionality`;

        return systemMsg;
    }
}

class GeminiProvider implements AIProvider {
    name = 'gemini';

    constructor(private apiKey: string, private model: string) {}

    async generateCompletion(prompt: string, _context: GraphContext | null): Promise<string> {
        const { GoogleGenerativeAI } = await import('@google/generative-ai');
        const genAI = new GoogleGenerativeAI(this.apiKey);
        const model = genAI.getGenerativeModel({ model: this.model });

        const result = await model.generateContent(prompt);
        const response = await result.response;
        return response.text();
    }

    async generateChat(messages: ChatMessage[], _context: GraphContext | null): Promise<string> {
        const { GoogleGenerativeAI } = await import('@google/generative-ai');
        const genAI = new GoogleGenerativeAI(this.apiKey);
        const model = genAI.getGenerativeModel({ model: this.model });

        const chat = model.startChat({
            history: messages.slice(0, -1).map(m => ({
                role: m.role === 'assistant' ? 'model' : 'user',
                parts: [{ text: m.content }]
            }))
        });

        const lastMessage = messages[messages.length - 1];
        const result = await chat.sendMessage(lastMessage.content);
        const response = await result.response;
        return response.text();
    }
}

class AnthropicProvider implements AIProvider {
    name = 'anthropic';

    constructor(private apiKey: string, private model: string) {}

    async generateCompletion(prompt: string, _context: GraphContext | null): Promise<string> {
        const Anthropic = (await import('@anthropic-ai/sdk')).default;
        const client = new Anthropic({ apiKey: this.apiKey });

        const response = await client.messages.create({
            model: this.model || 'claude-3-haiku-20240307',
            max_tokens: 1024,
            messages: [{ role: 'user', content: prompt }]
        });

        const content = response.content[0];
        return content.type === 'text' ? content.text : '';
    }

    async generateChat(messages: ChatMessage[], _context: GraphContext | null): Promise<string> {
        const Anthropic = (await import('@anthropic-ai/sdk')).default;
        const client = new Anthropic({ apiKey: this.apiKey });

        const systemMsg = messages.find(m => m.role === 'system')?.content || '';
        const chatMessages = messages
            .filter(m => m.role !== 'system')
            .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));

        const response = await client.messages.create({
            model: this.model || 'claude-3-haiku-20240307',
            max_tokens: 4096,
            system: systemMsg,
            messages: chatMessages
        });

        const content = response.content[0];
        return content.type === 'text' ? content.text : '';
    }
}

class OpenAIProvider implements AIProvider {
    name = 'openai';

    constructor(private apiKey: string, private model: string) {}

    async generateCompletion(prompt: string, _context: GraphContext | null): Promise<string> {
        const OpenAI = (await import('openai')).default;
        const client = new OpenAI({ apiKey: this.apiKey });

        const response = await client.chat.completions.create({
            model: this.model || 'gpt-4o-mini',
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 1024
        });

        return response.choices[0]?.message?.content || '';
    }

    async generateChat(messages: ChatMessage[], _context: GraphContext | null): Promise<string> {
        const OpenAI = (await import('openai')).default;
        const client = new OpenAI({ apiKey: this.apiKey });

        const response = await client.chat.completions.create({
            model: this.model || 'gpt-4o-mini',
            messages: messages.map(m => ({
                role: m.role,
                content: m.content
            })),
            max_tokens: 4096
        });

        return response.choices[0]?.message?.content || '';
    }
}

class OllamaProvider implements AIProvider {
    name = 'ollama';

    constructor(private endpoint: string, private model: string) {}

    async generateCompletion(prompt: string, _context: GraphContext | null): Promise<string> {
        const response = await fetch(`${this.endpoint}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: this.model || 'llama3',
                prompt,
                stream: false
            })
        });

        const data = await response.json() as { response?: string };
        return data.response || '';
    }

    async generateChat(messages: ChatMessage[], _context: GraphContext | null): Promise<string> {
        const response = await fetch(`${this.endpoint}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: this.model || 'llama3',
                messages: messages.map(m => ({
                    role: m.role,
                    content: m.content
                })),
                stream: false
            })
        });

        const data = await response.json() as { message?: { content?: string } };
        return data.message?.content || '';
    }
}
