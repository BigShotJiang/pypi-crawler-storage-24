import * as vscode from 'vscode';
import { spawn, ChildProcess, execSync } from 'child_process';
import * as path from 'path';
import * as os from 'os';
import * as fs from 'fs';

export interface SymbolContext {
    name: string;
    type: string;
    filePath: string;
    startLine: number;
    endLine: number;
    callers: string[];
    callees: string[];
    typeRefs: string[];
    community?: string;
    isDead: boolean;
    signature?: string;
}

export interface ImpactResult {
    symbol: string;
    affectedCount: number;
    direct: string[];
    indirect: string[];
    transitive: string[];
}

export interface GraphContext {
    symbols: SymbolContext[];
    relationships: Array<{
        from: string;
        to: string;
        type: string;
        confidence: number;
    }>;
    relevantCode: Array<{
        path: string;
        content: string;
        startLine: number;
        endLine: number;
    }>;
}

export class LogThreadService {
    private mcpProcess: ChildProcess | null = null;
    private outputChannel: vscode.OutputChannel;
    private isIndexed: boolean = false;
    private _isLoggedIn: boolean = false;
    private _userEmail: string | null = null;

    constructor(private context: vscode.ExtensionContext) {
        this.outputChannel = vscode.window.createOutputChannel('Log Thread');
        this.checkAuthStatus();
    }

    get isLoggedIn(): boolean {
        return this._isLoggedIn;
    }

    get userEmail(): string | null {
        return this._userEmail;
    }

    private getConfigDir(): string {
        if (process.platform === 'darwin') {
            return path.join(os.homedir(), 'Library', 'Application Support', 'logthread');
        } else if (process.platform === 'win32') {
            return path.join(process.env.APPDATA || os.homedir(), 'logthread');
        }
        return path.join(os.homedir(), '.local', 'share', 'logthread');
    }

    async checkAuthStatus(): Promise<boolean> {
        try {
            const configDir = this.getConfigDir();
            const tokenPath = path.join(configDir, 'token.json');
            
            if (fs.existsSync(tokenPath)) {
                const tokenData = JSON.parse(fs.readFileSync(tokenPath, 'utf-8'));
                this._isLoggedIn = !!tokenData.access_token;
                this._userEmail = tokenData.email || null;
                return this._isLoggedIn;
            }
            return false;
        } catch (error) {
            this.outputChannel.appendLine(`Auth check error: ${error}`);
            return false;
        }
    }

    async login(): Promise<boolean> {
        return new Promise((resolve, reject) => {
            const process = spawn('logthread', ['login'], {
                stdio: ['inherit', 'pipe', 'pipe']
            });

            process.stdout?.on('data', (data: Buffer) => {
                this.outputChannel.appendLine(data.toString());
            });

            process.stderr?.on('data', (data: Buffer) => {
                this.outputChannel.appendLine(data.toString());
            });

            process.on('close', async (code: number | null) => {
                if (code === 0) {
                    await this.checkAuthStatus();
                    resolve(this._isLoggedIn);
                } else {
                    reject(new Error('Login failed'));
                }
            });

            process.on('error', reject);
        });
    }

    async logout(): Promise<void> {
        return new Promise((resolve, reject) => {
            const process = spawn('logthread', ['logout'], {
                stdio: ['pipe', 'pipe', 'pipe']
            });

            process.on('close', () => {
                this._isLoggedIn = false;
                this._userEmail = null;
                resolve();
            });

            process.on('error', reject);
        });
    }

    hasCloudSyncConsent(): boolean {
        try {
            const configDir = this.getConfigDir();
            const consentPath = path.join(configDir, 'cloud_consent.json');
            return fs.existsSync(consentPath);
        } catch {
            return false;
        }
    }

    async syncToCloud(workspacePath: string): Promise<boolean> {
        return new Promise((resolve, reject) => {
            const process = spawn('logthread', ['sync'], {
                cwd: workspacePath,
                stdio: ['pipe', 'pipe', 'pipe']
            });

            let output = '';
            process.stdout?.on('data', (data: Buffer) => {
                output += data.toString();
                this.outputChannel.appendLine(data.toString());
            });

            process.stderr?.on('data', (data: Buffer) => {
                this.outputChannel.appendLine(`[ERROR] ${data.toString()}`);
            });

            process.on('close', (code: number | null) => {
                resolve(code === 0);
            });

            process.on('error', reject);
        });
    }

    getCloudExploreUrl(workspacePath: string): string {
        try {
            const configDir = this.getConfigDir();
            const projectId = this.getProjectId(workspacePath);
            const metaPath = path.join(configDir, 'projects', projectId, 'meta.json');
            
            if (fs.existsSync(metaPath)) {
                const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
                if (meta.cloud_repo_id) {
                    return `https://logthread.dev/explore/${meta.cloud_repo_id}`;
                }
            }
        } catch (error) {
            this.outputChannel.appendLine(`Error getting cloud URL: ${error}`);
        }
        return 'https://logthread.dev/dashboard';
    }

    private getProjectId(workspacePath: string): string {
        const crypto = require('crypto');
        return crypto.createHash('sha256').update(workspacePath).digest('hex').substring(0, 16);
    }

    async analyze(workspacePath: string): Promise<void> {
        return new Promise((resolve, reject) => {
            this.outputChannel.appendLine(`Analyzing: ${workspacePath}`);

            const process = spawn('logthread', ['analyze', workspacePath], {
                cwd: workspacePath,
                stdio: ['pipe', 'pipe', 'pipe']
            });

            process.stdout?.on('data', (data: Buffer) => {
                this.outputChannel.appendLine(data.toString());
            });

            process.stderr?.on('data', (data: Buffer) => {
                this.outputChannel.appendLine(`[ERROR] ${data.toString()}`);
            });

            process.on('close', (code: number | null) => {
                if (code === 0) {
                    this.isIndexed = true;
                    this.startMcpServer(workspacePath);
                    resolve();
                } else {
                    reject(new Error(`Analysis failed with code ${code}`));
                }
            });

            process.on('error', (err: Error) => {
                reject(err);
            });
        });
    }

    private async startMcpServer(workspacePath: string): Promise<void> {
        if (this.mcpProcess) {
            this.mcpProcess.kill();
        }

        const config = vscode.workspace.getConfiguration('logthread');
        const watchEnabled = config.get('watchFiles', true);

        const args = ['serve'];
        if (watchEnabled) {
            args.push('--watch');
        }

        this.mcpProcess = spawn('logthread', args, {
            cwd: workspacePath,
            stdio: ['pipe', 'pipe', 'pipe']
        });

        this.mcpProcess.stderr?.on('data', (data: Buffer) => {
            this.outputChannel.appendLine(`[MCP] ${data.toString()}`);
        });

        this.outputChannel.appendLine('MCP server started');
    }

    async getContext(symbol: string): Promise<SymbolContext | null> {
        try {
            const result = await this.callMcpTool('logthread_context', { symbol });
            return this.parseContextResult(result);
        } catch (error) {
            this.outputChannel.appendLine(`Error getting context: ${error}`);
            return null;
        }
    }

    async getImpact(symbol: string, depth: number = 3): Promise<ImpactResult | null> {
        try {
            const result = await this.callMcpTool('logthread_impact', { symbol, depth });
            return this.parseImpactResult(result, symbol);
        } catch (error) {
            this.outputChannel.appendLine(`Error getting impact: ${error}`);
            return null;
        }
    }

    async getContextForPosition(
        filePath: string,
        line: number,
        character: number
    ): Promise<GraphContext | null> {
        try {
            // Get file context first
            const fileContext = await this.callMcpTool('logthread_file_context', {
                file_path: filePath
            });

            // Find the symbol at the position
            const symbols = this.parseFileContext(fileContext);
            const currentSymbol = symbols.find(s => 
                line >= s.startLine && line <= s.endLine
            );

            if (!currentSymbol) {
                return null;
            }

            // Get full context for the symbol
            const context = await this.getContext(currentSymbol.name);
            if (!context) {
                return null;
            }

            // Build graph context for AI
            const graphContext: GraphContext = {
                symbols: [context],
                relationships: [],
                relevantCode: []
            };

            // Add caller contexts
            for (const caller of context.callers.slice(0, 5)) {
                const callerContext = await this.getContext(caller);
                if (callerContext) {
                    graphContext.symbols.push(callerContext);
                    graphContext.relationships.push({
                        from: caller,
                        to: context.name,
                        type: 'CALLS',
                        confidence: 1.0
                    });
                }
            }

            // Add callee contexts
            for (const callee of context.callees.slice(0, 5)) {
                const calleeContext = await this.getContext(callee);
                if (calleeContext) {
                    graphContext.symbols.push(calleeContext);
                    graphContext.relationships.push({
                        from: context.name,
                        to: callee,
                        type: 'CALLS',
                        confidence: 1.0
                    });
                }
            }

            return graphContext;
        } catch (error) {
            this.outputChannel.appendLine(`Error getting position context: ${error}`);
            return null;
        }
    }

    async query(searchQuery: string, limit: number = 20): Promise<SymbolContext[]> {
        try {
            const result = await this.callMcpTool('logthread_query', { 
                query: searchQuery, 
                limit 
            });
            return this.parseQueryResult(result);
        } catch (error) {
            this.outputChannel.appendLine(`Error querying: ${error}`);
            return [];
        }
    }

    async reindexFile(filePath: string): Promise<void> {
        // The watch mode handles this automatically
        this.outputChannel.appendLine(`File changed: ${filePath}`);
    }

    async removeFile(filePath: string): Promise<void> {
        this.outputChannel.appendLine(`File removed: ${filePath}`);
    }

    private async callMcpTool(toolName: string, args: Record<string, unknown>): Promise<string> {
        // For now, use CLI as fallback. In production, this would use proper MCP client
        return new Promise((resolve, reject) => {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders) {
                reject(new Error('No workspace folder'));
                return;
            }

            let command: string;
            let cliArgs: string[];

            switch (toolName) {
                case 'logthread_context':
                    command = 'logthread';
                    cliArgs = ['context', args.symbol as string];
                    break;
                case 'logthread_impact':
                    command = 'logthread';
                    cliArgs = ['impact', args.symbol as string, '--depth', String(args.depth || 3)];
                    break;
                case 'logthread_query':
                    command = 'logthread';
                    cliArgs = ['query', args.query as string, '--limit', String(args.limit || 20)];
                    break;
                case 'logthread_file_context':
                    command = 'logthread';
                    cliArgs = ['cypher', `MATCH (f:File {path: "${args.file_path}"}) RETURN f`];
                    break;
                default:
                    reject(new Error(`Unknown tool: ${toolName}`));
                    return;
            }

            const process = spawn(command, cliArgs, {
                cwd: workspaceFolders[0].uri.fsPath
            });

            let output = '';
            process.stdout?.on('data', (data: Buffer) => {
                output += data.toString();
            });

            process.on('close', (code: number | null) => {
                if (code === 0) {
                    resolve(output);
                } else {
                    reject(new Error(`Tool call failed with code ${code}`));
                }
            });

            process.on('error', reject);
        });
    }

    private parseContextResult(result: string): SymbolContext | null {
        try {
            // Parse the CLI output format
            const lines = result.split('\n');
            const context: Partial<SymbolContext> = {
                callers: [],
                callees: [],
                typeRefs: [],
                isDead: false
            };

            for (const line of lines) {
                if (line.includes('Name:')) {
                    context.name = line.split('Name:')[1].trim();
                } else if (line.includes('Type:')) {
                    context.type = line.split('Type:')[1].trim();
                } else if (line.includes('File:')) {
                    context.filePath = line.split('File:')[1].trim();
                } else if (line.includes('Callers:')) {
                    // Parse callers list
                } else if (line.includes('Callees:')) {
                    // Parse callees list
                }
            }

            return context as SymbolContext;
        } catch {
            return null;
        }
    }

    private parseImpactResult(result: string, symbol: string): ImpactResult {
        const impact: ImpactResult = {
            symbol,
            affectedCount: 0,
            direct: [],
            indirect: [],
            transitive: []
        };

        // Parse the CLI output
        const lines = result.split('\n');
        let currentSection = '';

        for (const line of lines) {
            if (line.includes('Depth 1') || line.includes('Direct')) {
                currentSection = 'direct';
            } else if (line.includes('Depth 2') || line.includes('Indirect')) {
                currentSection = 'indirect';
            } else if (line.includes('Depth 3') || line.includes('Transitive')) {
                currentSection = 'transitive';
            } else if (line.trim().startsWith('-') || line.trim().startsWith('•')) {
                const symbolName = line.replace(/[-•]/g, '').trim();
                if (symbolName && currentSection) {
                    impact[currentSection as 'direct' | 'indirect' | 'transitive'].push(symbolName);
                }
            }
        }

        impact.affectedCount = impact.direct.length + impact.indirect.length + impact.transitive.length;
        return impact;
    }

    private parseFileContext(result: string): SymbolContext[] {
        // Parse file context from CLI output
        return [];
    }

    private parseQueryResult(result: string): SymbolContext[] {
        // Parse query results from CLI output
        return [];
    }

    dispose(): void {
        if (this.mcpProcess) {
            this.mcpProcess.kill();
            this.mcpProcess = null;
        }
        this.outputChannel.dispose();
    }
}
