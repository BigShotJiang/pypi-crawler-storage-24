import * as vscode from 'vscode';
import { LogThreadService } from './services/logthread';
import { AIService } from './services/ai';
import { ChatViewProvider } from './views/chatView';
import { ContextTreeProvider } from './views/contextTree';
import { GraphViewProvider } from './views/graphView';

let logthreadService: LogThreadService;
let aiService: AIService;

export async function activate(context: vscode.ExtensionContext) {
    console.log('Log Thread extension activating...');

    // Initialize services
    logthreadService = new LogThreadService(context);
    aiService = new AIService(context);

    // Register view providers
    const chatViewProvider = new ChatViewProvider(context, logthreadService, aiService);
    const contextTreeProvider = new ContextTreeProvider(logthreadService);
    const graphViewProvider = new GraphViewProvider(context, logthreadService);

    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider('logthread.chat', chatViewProvider),
        vscode.window.registerTreeDataProvider('logthread.context', contextTreeProvider),
        vscode.window.registerWebviewViewProvider('logthread.graph', graphViewProvider)
    );

    // Auto-select symbol on cursor position change
    context.subscriptions.push(
        vscode.window.onDidChangeTextEditorSelection(async (e) => {
            const editor = e.textEditor;
            const position = e.selections[0].active;
            const wordRange = editor.document.getWordRangeAtPosition(position);
            
            if (wordRange) {
                const symbol = editor.document.getText(wordRange);
                if (symbol && symbol.length > 1) {
                    const ctx = await logthreadService.getContext(symbol);
                    if (ctx) {
                        contextTreeProvider.refresh(ctx);
                    }
                }
            }
        })
    );

    // Register commands
    context.subscriptions.push(
        vscode.commands.registerCommand('logthread.analyze', async () => {
            await analyzeWorkspace();
        }),

        vscode.commands.registerCommand('logthread.showGraph', async () => {
            await vscode.commands.executeCommand('logthread.graph.focus');
        }),

        vscode.commands.registerCommand('logthread.contextForSymbol', async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) return;

            const position = editor.selection.active;
            const wordRange = editor.document.getWordRangeAtPosition(position);
            if (!wordRange) return;

            const symbol = editor.document.getText(wordRange);
            const context = await logthreadService.getContext(symbol);
            
            if (context) {
                contextTreeProvider.refresh(context);
                vscode.commands.executeCommand('logthread.context.focus');
            }
        }),

        vscode.commands.registerCommand('logthread.impactAnalysis', async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) return;

            const position = editor.selection.active;
            const wordRange = editor.document.getWordRangeAtPosition(position);
            if (!wordRange) return;

            const symbol = editor.document.getText(wordRange);
            const impact = await logthreadService.getImpact(symbol);
            
            if (impact) {
                vscode.window.showInformationMessage(
                    `Impact Analysis: ${impact.affectedCount} symbols affected`,
                    'Show Details'
                ).then(selection => {
                    if (selection === 'Show Details') {
                        showImpactDetails(impact);
                    }
                });
            }
        }),

        vscode.commands.registerCommand('logthread.openChat', async () => {
            await vscode.commands.executeCommand('logthread.chat.focus');
        }),

        vscode.commands.registerCommand('logthread.configure', async () => {
            await vscode.commands.executeCommand(
                'workbench.action.openSettings',
                'logthread'
            );
        }),

        vscode.commands.registerCommand('logthread.login', async () => {
            try {
                const success = await logthreadService.login();
                if (success) {
                    vscode.window.showInformationMessage(`Logged in as ${logthreadService.userEmail}`);
                }
            } catch (error) {
                vscode.window.showErrorMessage('Login failed. Please try again.');
            }
        }),

        vscode.commands.registerCommand('logthread.logout', async () => {
            await logthreadService.logout();
            vscode.window.showInformationMessage('Logged out from Log Thread');
        }),

        vscode.commands.registerCommand('logthread.cloudSync', async () => {
            const workspaceFolders = vscode.workspace.workspaceFolders;
            if (!workspaceFolders) {
                vscode.window.showWarningMessage('No workspace folder open');
                return;
            }

            if (!logthreadService.isLoggedIn) {
                const login = await vscode.window.showInformationMessage(
                    'You need to log in to sync to Log Thread Cloud',
                    'Login'
                );
                if (login === 'Login') {
                    await vscode.commands.executeCommand('logthread.login');
                }
                return;
            }

            if (!logthreadService.hasCloudSyncConsent()) {
                const consent = await vscode.window.showInformationMessage(
                    'To sync to Log Thread Cloud, you must agree to our Terms of Service and Privacy Policy.',
                    { modal: true },
                    'View Terms',
                    'View Privacy',
                    'I Agree'
                );

                if (consent === 'View Terms') {
                    vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/terms'));
                    return;
                }
                if (consent === 'View Privacy') {
                    vscode.env.openExternal(vscode.Uri.parse('https://logthread.dev/privacy'));
                    return;
                }
                if (consent !== 'I Agree') {
                    return;
                }
            }

            await vscode.window.withProgress(
                {
                    location: vscode.ProgressLocation.Notification,
                    title: 'Syncing to Log Thread Cloud...',
                    cancellable: false
                },
                async () => {
                    const success = await logthreadService.syncToCloud(workspaceFolders[0].uri.fsPath);
                    if (success) {
                        vscode.window.showInformationMessage('Successfully synced to Log Thread Cloud!');
                    } else {
                        vscode.window.showErrorMessage('Failed to sync. Check the output for details.');
                    }
                }
            );
        })
    );

    // Auto-index on startup if enabled
    const config = vscode.workspace.getConfiguration('logthread');
    if (config.get('autoIndex')) {
        await analyzeWorkspace();
    }

    // Watch for file changes if enabled
    if (config.get('watchFiles')) {
        const watcher = vscode.workspace.createFileSystemWatcher('**/*.{py,ts,tsx,js,jsx}');
        
        watcher.onDidChange(async (uri) => {
            await logthreadService.reindexFile(uri.fsPath);
        });

        watcher.onDidCreate(async (uri) => {
            await logthreadService.reindexFile(uri.fsPath);
        });

        watcher.onDidDelete(async (uri) => {
            await logthreadService.removeFile(uri.fsPath);
        });

        context.subscriptions.push(watcher);
    }

    // Register inline completion provider for AI-assisted editing
    const inlineProvider = vscode.languages.registerInlineCompletionItemProvider(
        { pattern: '**/*.{py,ts,tsx,js,jsx,go,java,cs,rb}' },
        {
            async provideInlineCompletionItems(document, position, context, token) {
                // Only trigger on explicit request or after typing
                if (context.triggerKind !== vscode.InlineCompletionTriggerKind.Invoke) {
                    return undefined;
                }

                const linePrefix = document.lineAt(position.line).text.substring(0, position.character);
                
                // Get relevant context from knowledge graph
                const graphContext = await logthreadService.getContextForPosition(
                    document.uri.fsPath,
                    position.line,
                    position.character
                );

                // Generate completion with AI
                const completion = await aiService.generateCompletion(
                    document.getText(),
                    position,
                    linePrefix,
                    graphContext
                );

                if (!completion || token.isCancellationRequested) {
                    return undefined;
                }

                return [
                    new vscode.InlineCompletionItem(
                        completion,
                        new vscode.Range(position, position)
                    )
                ];
            }
        }
    );

    context.subscriptions.push(inlineProvider);

    console.log('Log Thread extension activated');
}

async function analyzeWorkspace(): Promise<void> {
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders || workspaceFolders.length === 0) {
        vscode.window.showWarningMessage('No workspace folder open');
        return;
    }

    await vscode.window.withProgress(
        {
            location: vscode.ProgressLocation.Notification,
            title: 'Log Thread: Analyzing workspace...',
            cancellable: true
        },
        async (progress, token) => {
            for (const folder of workspaceFolders) {
                if (token.isCancellationRequested) break;

                progress.report({ message: `Indexing ${folder.name}...` });
                await logthreadService.analyze(folder.uri.fsPath);
            }

            vscode.window.showInformationMessage('Log Thread: Workspace analysis complete');
        }
    );
}

function showImpactDetails(impact: any): void {
    const panel = vscode.window.createWebviewPanel(
        'logthreadImpact',
        'Impact Analysis',
        vscode.ViewColumn.Two,
        { enableScripts: true }
    );

    panel.webview.html = generateImpactHtml(impact);
}

function generateImpactHtml(impact: any): string {
    const directCallers = impact.direct?.map((s: string) => `<li class="direct">${s}</li>`).join('') || '';
    const indirectCallers = impact.indirect?.map((s: string) => `<li class="indirect">${s}</li>`).join('') || '';
    const transitive = impact.transitive?.map((s: string) => `<li class="transitive">${s}</li>`).join('') || '';

    return `<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: var(--vscode-font-family); padding: 20px; }
        h2 { color: var(--vscode-foreground); }
        ul { list-style: none; padding: 0; }
        li { padding: 8px 12px; margin: 4px 0; border-radius: 4px; }
        .direct { background: rgba(239, 68, 68, 0.2); border-left: 3px solid #ef4444; }
        .indirect { background: rgba(245, 158, 11, 0.2); border-left: 3px solid #f59e0b; }
        .transitive { background: rgba(59, 130, 246, 0.2); border-left: 3px solid #3b82f6; }
        .section { margin-bottom: 24px; }
        .count { color: var(--vscode-descriptionForeground); font-size: 12px; }
    </style>
</head>
<body>
    <h1>Impact Analysis: ${impact.symbol}</h1>
    <p class="count">Total affected: ${impact.affectedCount} symbols</p>
    
    <div class="section">
        <h2>🔴 Direct Callers (will break)</h2>
        <ul>${directCallers || '<li>None</li>'}</ul>
    </div>
    
    <div class="section">
        <h2>🟡 Indirect Callers (may break)</h2>
        <ul>${indirectCallers || '<li>None</li>'}</ul>
    </div>
    
    <div class="section">
        <h2>🔵 Transitive (review)</h2>
        <ul>${transitive || '<li>None</li>'}</ul>
    </div>
</body>
</html>`;
}

export function deactivate() {
    if (logthreadService) {
        logthreadService.dispose();
    }
}
