# Log Thread Deployment Guide

Complete guide to deploying Log Thread as a paid SaaS product.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         USERS                                       │
│                                                                     │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐            │
│   │   Browser   │    │  CLI/MCP    │    │  VS Code    │            │
│   │  (Web UI)   │    │   Server    │    │  Extension  │            │
│   └──────┬──────┘    └──────┬──────┘    └──────┬──────┘            │
└──────────┼──────────────────┼──────────────────┼────────────────────┘
           │                  │                  │
           ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    LOG THREAD CLOUD API                             │
│                                                                     │
│   ┌──────────────────────────────────────────────────────────────┐ │
│   │  FastAPI Application (api.logthread.dev)                     │ │
│   │  - Authentication (device flow, JWT)                         │ │
│   │  - Billing (Stripe integration)                              │ │
│   │  - Graph sync (S3 storage)                                   │ │
│   └──────────────────────────────────────────────────────────────┘ │
│                              │                                      │
│              ┌───────────────┼───────────────┐                     │
│              ▼               ▼               ▼                     │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │
│   │  PostgreSQL  │  │    Stripe    │  │   AWS S3     │            │
│   │  (Users,     │  │  (Payments)  │  │  (Graphs)    │            │
│   │  Subscriptions)│  │              │  │              │            │
│   └──────────────┘  └──────────────┘  └──────────────┘            │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Step 1: Set Up Stripe

### Create Stripe Account
1. Go to https://dashboard.stripe.com
2. Create a new account or use existing

### Create Product & Price
1. Go to Products → Add Product
2. **Name**: Log Thread
3. **Price**: $4.99/month (recurring)
4. Save and copy the **Price ID** (starts with `price_`)

### Set Up Webhook
1. Go to Developers → Webhooks → Add endpoint
2. **URL**: `https://api.logthread.dev/billing/webhook`
3. **Events**: 
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
4. Copy the **Webhook Secret** (starts with `whsec_`)

### Get API Keys
1. Go to Developers → API Keys
2. Copy **Secret key** (starts with `sk_`)
3. Copy **Publishable key** (starts with `pk_`)

---

## Step 2: Set Up Email (Resend)

1. Go to https://resend.com
2. Create account and verify domain
3. Get API key from Settings → API Keys
4. Add DNS records for your domain

---

## Step 3: Set Up AWS S3 (Optional - for graph sync)

1. Create S3 bucket: `logthread-graphs`
2. Create IAM user with S3 access
3. Get Access Key ID and Secret Access Key

---

## Step 4: Set Up PostgreSQL

### Option A: Managed (Recommended)
- **Supabase**: https://supabase.com (free tier available)
- **Neon**: https://neon.tech (free tier available)
- **Railway**: https://railway.app

### Option B: Self-hosted
```bash
docker run -d \
  --name logthread-db \
  -e POSTGRES_USER=logthread \
  -e POSTGRES_PASSWORD=your-secure-password \
  -e POSTGRES_DB=logthread \
  -p 5432:5432 \
  postgres:15-alpine
```

### Initialize Schema
```bash
psql postgresql://logthread:password@host:5432/logthread < cloud-api/schema.sql
```

---

## Step 5: Deploy Cloud API

### Option A: Railway (Easiest)

1. Push code to GitHub
2. Go to https://railway.app
3. New Project → Deploy from GitHub repo
4. Select the `cloud-api` directory
5. Add environment variables from `.env.example`
6. Deploy

### Option B: Render

1. Go to https://render.com
2. New Web Service → Connect GitHub
3. **Root Directory**: `cloud-api`
4. **Build Command**: `pip install -r requirements.txt`
5. **Start Command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
6. Add environment variables

### Option C: Docker (Any VPS)

```bash
cd cloud-api
cp .env.example .env
# Edit .env with your values

docker-compose up -d
```

### Option D: Fly.io

```bash
cd cloud-api
fly launch
fly secrets set DATABASE_URL="..." STRIPE_SECRET_KEY="..." ...
fly deploy
```

---

## Step 6: Configure DNS

Add DNS records for your domain:

| Type | Name | Value |
|------|------|-------|
| A | logthread.dev | your-server-ip |
| A | api.logthread.dev | your-api-server-ip |
| CNAME | www | logthread.dev |

---

## Step 7: Update Client Configuration

Edit `src/logthread/cloud/client.py`:

```python
API_URL = "https://api.logthread.dev"  # Your actual API URL
```

---

## Step 8: Publish Python Package

```bash
cd logthread

# Build
uv build

# Publish to PyPI
uv publish
```

---

## Step 9: Publish VS Code Extension

```bash
cd vscode-extension
npm install
npm run package

# Publish to VS Code Marketplace
vsce publish
```

---

## Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql+asyncpg://user:pass@host:5432/db` |
| `JWT_SECRET_KEY` | Secret for JWT signing | 64-char random string |
| `STRIPE_SECRET_KEY` | Stripe secret key | `sk_live_...` |
| `STRIPE_PUBLISHABLE_KEY` | Stripe public key | `pk_live_...` |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook secret | `whsec_...` |
| `STRIPE_PRICE_ID` | Price ID for $4.99 plan | `price_...` |
| `RESEND_API_KEY` | Resend API key | `re_...` |
| `FROM_EMAIL` | Email sender address | `hello@logthread.dev` |
| `APP_URL` | Frontend URL | `https://logthread.dev` |
| `API_URL` | API URL | `https://api.logthread.dev` |
| `AWS_ACCESS_KEY_ID` | AWS access key (optional) | |
| `AWS_SECRET_ACCESS_KEY` | AWS secret (optional) | |
| `S3_BUCKET` | S3 bucket name (optional) | `logthread-graphs` |

---

## User Flow

### New User
1. User visits `logthread.dev`
2. Clicks "Get Started" → Registration page
3. Creates account → Receives verification email
4. Verifies email → Redirected to pricing
5. Clicks "Subscribe" → Stripe checkout
6. Payment successful → Redirected to dashboard
7. Dashboard shows quick start instructions

### CLI Login
1. User runs `logthread login`
2. Browser opens to `/device?code=xxx`
3. User authorizes device
4. CLI receives token, saves to `~/.logthread/auth.json`
5. User can now run `logthread analyze .`

### Using Log Thread
1. `logthread analyze .` - Indexes codebase (requires subscription)
2. `logthread serve --watch` - Starts MCP server
3. Add to Cursor/Windsurf MCP config
4. AI assistant now has full codebase intelligence

---

## Monitoring

### Key Metrics to Track
- New registrations per day
- Trial-to-paid conversion rate
- Monthly recurring revenue (MRR)
- Churn rate
- Active users (daily/weekly/monthly)
- API response times

### Recommended Tools
- **Stripe Dashboard**: Revenue, subscriptions
- **PostHog/Mixpanel**: Product analytics
- **Sentry**: Error tracking
- **Grafana/Datadog**: Infrastructure monitoring

---

## Cost Estimate

| Service | Free Tier | Paid Estimate |
|---------|-----------|---------------|
| Railway/Render | $0 | $5-20/mo |
| PostgreSQL (Supabase) | Free | $25/mo |
| Stripe | 2.9% + $0.30 per transaction | |
| Resend | 3k emails/mo free | $20/mo |
| S3 | Minimal | ~$5/mo |
| Domain | - | $12/year |

**Total at launch**: ~$0-50/month
**Break-even**: ~10-15 paying customers

---

## Security Checklist

- [ ] Use HTTPS everywhere
- [ ] Store secrets in environment variables
- [ ] Enable Stripe webhook signature verification
- [ ] Use bcrypt for password hashing
- [ ] Implement rate limiting
- [ ] Set up CORS properly
- [ ] Regular security audits
- [ ] Keep dependencies updated

---

## Support

For questions: hello@logthread.dev
