"""Telemetry for Log Thread — privacy-respecting usage analytics."""

from typing import Optional
from datetime import datetime
import asyncio

from .auth import CloudAuth, CLOUD_API_URL


class Telemetry:
    """Privacy-respecting telemetry for Log Thread.
    
    What we track:
    - Anonymous usage counts (queries, analyses)
    - Feature usage (which tools are popular)
    - Error rates (to improve reliability)
    
    What we DON'T track:
    - Code content
    - File names or paths
    - Query contents
    - Any PII
    """

    def __init__(self, auth: Optional[CloudAuth] = None):
        self.auth = auth or CloudAuth()
        self._enabled = True
        self._queue: list[dict] = []
        self._flush_task: Optional[asyncio.Task] = None

    def disable(self) -> None:
        """Opt out of telemetry."""
        self._enabled = False

    def enable(self) -> None:
        """Opt in to telemetry."""
        self._enabled = True

    def track(
        self,
        event: str,
        properties: Optional[dict] = None,
    ) -> None:
        """Track an event (non-blocking)."""
        if not self._enabled:
            return

        self._queue.append({
            "event": event,
            "properties": properties or {},
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": self.auth.user_id or self.auth.get_anonymous_id(),
            "tier": self.auth.tier,
        })

        # Flush every 10 events or start background flush
        if len(self._queue) >= 10:
            asyncio.create_task(self._flush())

    async def _flush(self) -> None:
        """Send queued events to server."""
        if not self._queue:
            return

        events = self._queue.copy()
        self._queue.clear()

        try:
            import httpx
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    f"{CLOUD_API_URL}/telemetry/events",
                    json={"events": events},
                )
        except Exception:
            # Silently fail - telemetry should never break the user's workflow
            pass


# Global instance
_telemetry: Optional[Telemetry] = None


def get_telemetry() -> Telemetry:
    global _telemetry
    if _telemetry is None:
        _telemetry = Telemetry()
    return _telemetry


def track(event: str, properties: Optional[dict] = None) -> None:
    """Convenience function to track an event."""
    get_telemetry().track(event, properties)
