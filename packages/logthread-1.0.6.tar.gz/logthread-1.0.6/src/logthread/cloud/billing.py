"""Billing integration for Log Thread Cloud using Stripe."""

from typing import Optional
from dataclasses import dataclass

STRIPE_PRICING = {
    "pro_monthly": {
        "price_id": "price_pro_monthly",  # Replace with actual Stripe price ID
        "amount": 900,  # $9.00
        "interval": "month",
    },
    "pro_yearly": {
        "price_id": "price_pro_yearly",  # Replace with actual Stripe price ID
        "amount": 7900,  # $79.00 (save ~27%)
        "interval": "year",
    },
    "enterprise": {
        "price_id": "price_enterprise",  # Custom pricing
        "amount": None,
        "interval": "month",
    },
}


@dataclass
class Subscription:
    """User subscription details."""
    tier: str
    status: str  # active, canceled, past_due
    current_period_end: str
    cancel_at_period_end: bool


class BillingClient:
    """Client for Log Thread billing operations."""

    def __init__(self, api_url: str = "https://api.logthread.dev"):
        self.api_url = api_url

    async def get_subscription(self, token: str) -> Optional[Subscription]:
        """Get current subscription status."""
        import httpx
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.api_url}/billing/subscription",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if response.status_code == 200:
                    data = response.json()
                    return Subscription(**data)
        except Exception:
            pass
        return None

    async def create_checkout_session(
        self, 
        token: str, 
        price_key: str = "pro_monthly"
    ) -> Optional[str]:
        """Create Stripe checkout session and return URL."""
        import httpx
        
        pricing = STRIPE_PRICING.get(price_key)
        if not pricing:
            return None

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.api_url}/billing/checkout",
                    headers={"Authorization": f"Bearer {token}"},
                    json={"price_id": pricing["price_id"]},
                )
                if response.status_code == 200:
                    return response.json().get("checkout_url")
        except Exception:
            pass
        return None

    async def create_portal_session(self, token: str) -> Optional[str]:
        """Create Stripe customer portal session for subscription management."""
        import httpx
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.api_url}/billing/portal",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if response.status_code == 200:
                    return response.json().get("portal_url")
        except Exception:
            pass
        return None


def get_pricing_table() -> str:
    """Return formatted pricing table for CLI display."""
    return """
╭─────────────────────────────────────────────────────────────────╮
│                    LOG THREAD PRICING                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  FREE                    PRO                    ENTERPRISE      │
│  $0/month                $9/month               Custom          │
│                          $79/year (save 27%)                    │
│                                                                 │
│  ✓ 3 repositories        ✓ Unlimited repos      ✓ Everything    │
│  ✓ Local indexing        ✓ Cloud sync           ✓ SSO/SAML      │
│  ✓ MCP server            ✓ Usage analytics      ✓ Audit logs    │
│  ✓ CLI tools             ✓ Priority indexing    ✓ Dedicated     │
│                          ✓ Email support          support       │
│                                                 ✓ On-prem       │
│                                                   deployment    │
│                                                                 │
╰─────────────────────────────────────────────────────────────────╯

Upgrade at: https://logthread.dev/pricing
"""
