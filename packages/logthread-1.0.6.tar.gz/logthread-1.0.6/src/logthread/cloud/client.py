"""Log Thread Cloud client for CLI and MCP authentication."""

import json
import time
import webbrowser
from pathlib import Path
from typing import Optional
import httpx

API_URL = "https://api.logthread.dev"
CONFIG_DIR = Path.home() / ".logthread"
AUTH_FILE = CONFIG_DIR / "auth.json"


class CloudClient:
    """Client for Log Thread Cloud API."""

    def __init__(self, api_url: str = API_URL):
        self.api_url = api_url
        self._token: Optional[str] = None
        self._email: Optional[str] = None
        self._load_auth()

    def _load_auth(self) -> None:
        if AUTH_FILE.exists():
            try:
                data = json.loads(AUTH_FILE.read_text())
                self._token = data.get("token")
                self._email = data.get("email")
            except Exception:
                pass

    def _save_auth(self, token: str, email: str) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        AUTH_FILE.write_text(json.dumps({
            "token": token,
            "email": email,
        }))
        self._token = token
        self._email = email

    def clear_auth(self) -> None:
        if AUTH_FILE.exists():
            AUTH_FILE.unlink()
        self._token = None
        self._email = None

    @property
    def is_authenticated(self) -> bool:
        return self._token is not None

    @property
    def email(self) -> Optional[str]:
        return self._email

    @property
    def token(self) -> Optional[str]:
        return self._token

    def device_login(self, device_name: str = "Log Thread CLI") -> bool:
        """Perform device authorization flow."""
        try:
            # Initiate device auth
            with httpx.Client(timeout=30.0) as client:
                response = client.post(
                    f"{self.api_url}/device/auth",
                    json={"device_name": device_name, "device_type": "cli"}
                )
                response.raise_for_status()
                data = response.json()

            device_code = data["device_code"]
            verification_url = data["verification_url"]

            print(f"\n🔗 Opening browser to authorize...")
            print(f"   If it doesn't open, visit: {verification_url}\n")
            
            webbrowser.open(verification_url)

            # Poll for authorization
            print("⏳ Waiting for authorization...", end="", flush=True)
            
            for _ in range(60):  # 5 minutes timeout
                time.sleep(5)
                print(".", end="", flush=True)
                
                with httpx.Client(timeout=10.0) as client:
                    try:
                        response = client.post(
                            f"{self.api_url}/device/token",
                            json={"device_code": device_code}
                        )
                        
                        if response.status_code == 200:
                            data = response.json()
                            self._save_auth(data["access_token"], data["user_email"])
                            print("\n")
                            return True
                        elif response.status_code == 400:
                            error = response.json().get("detail", "")
                            if error != "authorization_pending":
                                print(f"\n❌ Authorization failed: {error}")
                                return False
                    except Exception:
                        pass

            print("\n❌ Authorization timed out")
            return False

        except Exception as e:
            print(f"\n❌ Login failed: {e}")
            return False

    def validate_subscription(self) -> tuple[bool, str]:
        """Validate that the user has an active subscription."""
        if not self._token:
            return False, "Not logged in. Run 'logthread login' first."

        try:
            with httpx.Client(timeout=10.0) as client:
                response = client.post(
                    f"{self.api_url}/device/validate",
                    headers={"Authorization": f"Bearer {self._token}"}
                )
                
                if response.status_code == 200:
                    return True, ""
                elif response.status_code == 401:
                    self.clear_auth()
                    return False, "Session expired. Run 'logthread login' to re-authenticate."
                elif response.status_code == 402:
                    return False, "Subscription required. Visit https://logthread.dev/pricing to subscribe."
                else:
                    return False, f"Validation failed: {response.text}"

        except httpx.ConnectError:
            # Allow offline usage if previously authenticated
            return True, ""
        except Exception as e:
            return False, f"Validation error: {e}"

    def sync_repo_metadata(
        self,
        repo_name: str,
        repo_path_hash: str,
        symbols_count: int,
        edges_count: int,
        files_count: int
    ) -> Optional[str]:
        """Sync repository metadata to cloud. Returns upload URL if available."""
        if not self._token:
            return None

        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.post(
                    f"{self.api_url}/graph/sync",
                    headers={"Authorization": f"Bearer {self._token}"},
                    json={
                        "repo_name": repo_name,
                        "repo_path_hash": repo_path_hash,
                        "symbols_count": symbols_count,
                        "edges_count": edges_count,
                        "files_count": files_count,
                    }
                )
                
                if response.status_code == 200:
                    return response.json().get("upload_url")

        except Exception:
            pass

        return None


# Global client instance
_client: Optional[CloudClient] = None


def get_client() -> CloudClient:
    global _client
    if _client is None:
        _client = CloudClient()
    return _client


def require_subscription() -> tuple[bool, str]:
    """Check if user has valid subscription. Returns (is_valid, error_message)."""
    return get_client().validate_subscription()
