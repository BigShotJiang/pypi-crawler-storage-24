"""Authentication for Log Thread Cloud."""

from pathlib import Path
from typing import Optional
import json
import hashlib

CLOUD_API_URL = "https://api.logthread.dev"
CONFIG_DIR = Path.home() / ".logthread"


class CloudAuth:
    """Handles authentication with Log Thread Cloud."""

    def __init__(self):
        self.config_path = CONFIG_DIR / "cloud.json"
        self._token: Optional[str] = None
        self._user_id: Optional[str] = None
        self._tier: str = "free"
        self._load_config()

    def _load_config(self) -> None:
        if self.config_path.exists():
            try:
                data = json.loads(self.config_path.read_text())
                self._token = data.get("token")
                self._user_id = data.get("user_id")
                self._tier = data.get("tier", "free")
            except Exception:
                pass

    def _save_config(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps({
            "token": self._token,
            "user_id": self._user_id,
            "tier": self._tier,
        }))

    @property
    def is_authenticated(self) -> bool:
        return self._token is not None

    @property
    def is_pro(self) -> bool:
        return self._tier in ("pro", "enterprise")

    @property
    def user_id(self) -> Optional[str]:
        return self._user_id

    @property
    def tier(self) -> str:
        return self._tier

    def get_anonymous_id(self) -> str:
        """Generate anonymous ID for free tier usage tracking."""
        machine_id_path = CONFIG_DIR / ".machine_id"
        if machine_id_path.exists():
            return machine_id_path.read_text().strip()

        # Generate stable anonymous ID from machine characteristics
        import platform
        import uuid
        
        machine_info = f"{platform.node()}-{uuid.getnode()}"
        anonymous_id = hashlib.sha256(machine_info.encode()).hexdigest()[:16]
        
        machine_id_path.parent.mkdir(parents=True, exist_ok=True)
        machine_id_path.write_text(anonymous_id)
        return anonymous_id

    async def login(self, email: str) -> dict:
        """Initiate login flow - sends magic link to email."""
        import httpx
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{CLOUD_API_URL}/auth/magic-link",
                json={"email": email}
            )
            return response.json()

    async def verify_token(self, token: str) -> bool:
        """Verify and store authentication token."""
        import httpx
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{CLOUD_API_URL}/auth/verify",
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code == 200:
                data = response.json()
                self._token = token
                self._user_id = data.get("user_id")
                self._tier = data.get("tier", "free")
                self._save_config()
                return True
            return False

    def logout(self) -> None:
        """Clear authentication."""
        self._token = None
        self._user_id = None
        self._tier = "free"
        if self.config_path.exists():
            self.config_path.unlink()
