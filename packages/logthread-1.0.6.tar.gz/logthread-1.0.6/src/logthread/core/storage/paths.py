"""Cross-platform storage path management for Log Thread.

All Log Thread data is stored in the user's profile directory to keep
project directories completely clean. No files are created in the project.

Storage Locations:
- macOS: ~/Library/Application Support/logthread/
- Linux: ~/.local/share/logthread/
- Windows: %APPDATA%/logthread/

Structure:
logthread/
├── config.json          # User preferences and cloud sync settings
├── cloud.json           # Cloud authentication token
├── registry.json        # Global list of indexed repositories
└── projects/
    └── {project_id}/
        ├── meta.json    # Project metadata
        ├── kuzu/        # Graph database
        └── cache/       # Temporary files
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
from pathlib import Path
from typing import Optional
from datetime import datetime


def get_app_data_dir() -> Path:
    """Get the application data directory for the current platform."""
    system = platform.system()
    
    if system == "Darwin":
        base = Path.home() / "Library" / "Application Support"
    elif system == "Windows":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    
    app_dir = base / "logthread"
    app_dir.mkdir(parents=True, exist_ok=True)
    return app_dir


def get_projects_dir() -> Path:
    """Get the directory where all project data is stored."""
    projects_dir = get_app_data_dir() / "projects"
    projects_dir.mkdir(parents=True, exist_ok=True)
    return projects_dir


def get_project_id(repo_path: Path) -> str:
    """Generate a unique, stable ID for a repository path."""
    abs_path = repo_path.resolve()
    path_hash = hashlib.sha256(str(abs_path).encode()).hexdigest()[:16]
    name = "".join(c for c in abs_path.name[:24] if c.isalnum() or c in "-_")
    return f"{name}_{path_hash}"


def get_project_dir(repo_path: Path) -> Path:
    """Get the full project directory in user profile."""
    project_id = get_project_id(repo_path)
    project_dir = get_projects_dir() / project_id
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir


def get_db_path(repo_path: Path) -> Path:
    """Get the database path for a repository."""
    return get_project_dir(repo_path) / "kuzu"


def get_project_meta_path(repo_path: Path) -> Path:
    """Get the path to the project's metadata file in user profile."""
    return get_project_dir(repo_path) / "meta.json"


def get_project_cache_dir(repo_path: Path) -> Path:
    """Get the cache directory for temporary project files."""
    cache_dir = get_project_dir(repo_path) / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_global_registry_path() -> Path:
    """Get the path to the global repository registry."""
    return get_app_data_dir() / "registry.json"


def get_config_path() -> Path:
    """Get the path to user configuration file."""
    return get_app_data_dir() / "config.json"


def get_cloud_sync_consent_path() -> Path:
    """Get the path to cloud sync consent record."""
    return get_app_data_dir() / "cloud_consent.json"


def load_config() -> dict:
    """Load user configuration."""
    config_path = get_config_path()
    if config_path.exists():
        try:
            return json.loads(config_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"cloud_sync_enabled": False, "tos_accepted": False}


def save_config(config: dict) -> None:
    """Save user configuration."""
    config_path = get_config_path()
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")


def has_cloud_sync_consent() -> bool:
    """Check if user has accepted ToS and Privacy Policy for cloud sync."""
    consent_path = get_cloud_sync_consent_path()
    if consent_path.exists():
        try:
            data = json.loads(consent_path.read_text(encoding="utf-8"))
            return data.get("tos_accepted", False) and data.get("privacy_accepted", False)
        except (json.JSONDecodeError, OSError):
            pass
    return False


def save_cloud_sync_consent(tos_accepted: bool, privacy_accepted: bool) -> None:
    """Save cloud sync consent record."""
    consent_path = get_cloud_sync_consent_path()
    consent_path.write_text(json.dumps({
        "tos_accepted": tos_accepted,
        "privacy_accepted": privacy_accepted,
        "accepted_at": datetime.utcnow().isoformat(),
        "tos_version": "1.0",
        "privacy_version": "1.0",
    }, indent=2) + "\n", encoding="utf-8")


def load_project_meta(repo_path: Path) -> Optional[dict]:
    """Load project metadata from user profile."""
    meta_path = get_project_meta_path(repo_path)
    if meta_path.exists():
        try:
            return json.loads(meta_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None


def save_project_meta(repo_path: Path, meta: dict) -> None:
    """Save project metadata to user profile."""
    meta_path = get_project_meta_path(repo_path)
    meta["_storage_version"] = 3
    meta["_project_id"] = get_project_id(repo_path)
    meta["_repo_path"] = str(repo_path.resolve())
    meta["_updated_at"] = datetime.utcnow().isoformat()
    meta_path.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")


def load_project_link(repo_path: Path) -> Optional[dict]:
    """Alias for load_project_meta for backward compatibility."""
    return load_project_meta(repo_path)


def save_project_link(repo_path: Path, meta: dict) -> None:
    """Alias for save_project_meta for backward compatibility."""
    save_project_meta(repo_path, meta)


def migrate_legacy_storage(repo_path: Path) -> bool:
    """Migrate legacy .logthread directory to centralized location.
    
    Moves all files from project's .logthread/ to user profile.
    Returns True if migration was performed.
    """
    legacy_dir = repo_path / ".logthread"
    if not legacy_dir.exists():
        return False
    
    project_dir = get_project_dir(repo_path)
    migrated = False
    
    legacy_db = legacy_dir / "kuzu"
    if legacy_db.exists():
        new_db = project_dir / "kuzu"
        if not new_db.exists():
            shutil.move(str(legacy_db), str(new_db))
            migrated = True
    
    legacy_meta = legacy_dir / "meta.json"
    if legacy_meta.exists():
        new_meta = project_dir / "meta.json"
        if not new_meta.exists():
            shutil.move(str(legacy_meta), str(new_meta))
            migrated = True
    
    for shadow_file in legacy_dir.glob("*.shadow"):
        shadow_file.unlink(missing_ok=True)
    
    for host_file in legacy_dir.glob("host*"):
        if host_file.is_file():
            host_file.unlink(missing_ok=True)
        elif host_file.is_dir():
            shutil.rmtree(host_file, ignore_errors=True)
    
    try:
        if legacy_dir.exists() and not any(legacy_dir.iterdir()):
            legacy_dir.rmdir()
    except OSError:
        pass
    
    return migrated


def cleanup_legacy_files(repo_path: Path) -> None:
    """Remove entire legacy .logthread directory from project."""
    legacy_dir = repo_path / ".logthread"
    if legacy_dir.exists():
        shutil.rmtree(legacy_dir, ignore_errors=True)


def get_all_projects() -> list[dict]:
    """Get list of all indexed projects from registry."""
    registry_path = get_global_registry_path()
    if registry_path.exists():
        try:
            data = json.loads(registry_path.read_text(encoding="utf-8"))
            return data.get("projects", [])
        except (json.JSONDecodeError, OSError):
            pass
    return []


def register_project(repo_path: Path, meta: dict) -> None:
    """Register a project in the global registry."""
    registry_path = get_global_registry_path()
    projects = []
    
    if registry_path.exists():
        try:
            data = json.loads(registry_path.read_text(encoding="utf-8"))
            projects = data.get("projects", [])
        except (json.JSONDecodeError, OSError):
            pass
    
    project_id = get_project_id(repo_path)
    projects = [p for p in projects if p.get("id") != project_id]
    
    projects.append({
        "id": project_id,
        "name": meta.get("name", repo_path.name),
        "path": str(repo_path.resolve()),
        "symbols": meta.get("symbols", 0),
        "files": meta.get("files", 0),
        "updated_at": datetime.utcnow().isoformat(),
    })
    
    registry_path.write_text(json.dumps({
        "version": 1,
        "projects": projects,
    }, indent=2) + "\n", encoding="utf-8")


def get_graphs_dir() -> Path:
    """Alias for get_projects_dir for backward compatibility."""
    return get_projects_dir()
