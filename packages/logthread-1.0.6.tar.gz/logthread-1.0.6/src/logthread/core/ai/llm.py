"""LLM Interface for Log Thread AI code modifications."""

import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class AIProviderConfig:
    def __init__(self):
        self.provider = os.getenv("AXON_AI_PROVIDER", "openai").lower()
        self.api_key = os.getenv("AXON_AI_API_KEY", "")
        self.model = os.getenv("AXON_AI_MODEL", "gpt-4o")

        # Set anthropic defaults if they selected it
        if self.provider == "anthropic" and self.model == "gpt-4o":
            self.model = "claude-3-5-sonnet-latest"


class AIClient:
    def __init__(self, config: Optional[AIProviderConfig] = None):
        self.config = config or AIProviderConfig()
        
        if not self.config.api_key:
            logger.warning("AXON_AI_API_KEY is not set. AI modify features will fail.")
            
        self._setup_client()

    def _setup_client(self):
        if self.config.provider == "anthropic":
            from anthropic import Anthropic
            self.client = Anthropic(api_key=self.config.api_key)
        else:
            from openai import OpenAI
            self.client = OpenAI(api_key=self.config.api_key)

    def suggest_edit(self, instruction: str, file_path: str, file_content: str, context: str = "") -> str:
        """Call the LLM to get a suggested code modification."""
        
        system_prompt = (
            "You are an expert AI software engineer. You are given a specific instruction to modify a file.\n"
            "Respond ONLY with the complete updated file content. Do not include markdown code block formatting like ```python, "
            "do not include explanations, do not include diff blocks. Just the raw, valid code file content."
        )
        
        user_prompt = (
            f"File to modify: {file_path}\n"
            f"Task: {instruction}\n\n"
        )
        if context:
            user_prompt += f"Supporting Graph Context:\n{context}\n\n"
            
        user_prompt += f"Original File Content:\n{file_content}\n"
        
        try:
            if self.config.provider == "anthropic":
                from anthropic.types import Message
                response = self.client.messages.create(
                    model=self.config.model,
                    max_tokens=4096,
                    system=system_prompt,
                    messages=[
                        {"role": "user", "content": user_prompt}
                    ]
                )
                return response.content[0].text
            else:
                response = self.client.chat.completions.create(
                    model=self.config.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ]
                )
                # Ensure no markdown blocks
                content = response.choices[0].message.content or ""
                return self._strip_markdown(content)
        except Exception as e:
            logger.error(f"Error calling LLM: {e}")
            raise

    def _strip_markdown(self, content: str) -> str:
        """Strip markdown code blocks if the model stubbornly included them."""
        lines = content.splitlines()
        if not lines:
            return content
            
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
            
        return "\n".join(lines)
