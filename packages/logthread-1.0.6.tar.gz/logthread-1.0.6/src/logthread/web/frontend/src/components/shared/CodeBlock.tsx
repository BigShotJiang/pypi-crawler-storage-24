import { useEffect, useState } from 'react';
import { codeToHtml } from 'shiki';
import DOMPurify from 'dompurify';

interface CodeBlockProps {
  code: string;
  language?: string;
  className?: string;
}

export function CodeBlock({ code, language = 'text', className = '' }: CodeBlockProps) {
  const [html, setHtml] = useState<string>('');

  useEffect(() => {
    let active = true;
    async function highlight() {
      try {
        const result = await codeToHtml(code, {
          lang: language,
          theme: 'github-dark',
        });
        if (active) setHtml(result);
      } catch (err) {
        if (active) setHtml(`<pre><code>${DOMPurify.sanitize(code)}</code></pre>`);
      }
    }
    void highlight();
    return () => { active = false; };
  }, [code, language]);

  return (
    <div 
      className={`text-xs font-mono overflow-auto bg-bg-surface ${className}`}
      dangerouslySetInnerHTML={{ __html: html ? DOMPurify.sanitize(html) : '' }}
    />
  );
}
