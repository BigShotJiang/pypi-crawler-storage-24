import { useState, useEffect } from 'react';
import { useGraphStore } from '@/stores/graphStore';
import { CodeBlock } from '@/components/shared/CodeBlock';
import { Play, Check, X, AlertTriangle, Loader2 } from 'lucide-react';

interface AITabProps {
  nodeId: string;
}

export function AITab({ nodeId }: AITabProps) {
  const node = useGraphStore((s) => s.nodes.find((n) => n.id === nodeId));
  const [instruction, setInstruction] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [diff, setDiff] = useState<string | null>(null);
  const [suggestedContent, setSuggestedContent] = useState<string | null>(null);
  const [filePath, setFilePath] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Auto-clear states when node changes
  useEffect(() => {
    setInstruction('');
    setDiff(null);
    setSuggestedContent(null);
    setError(null);
    setSuccessMsg(null);
  }, [nodeId]);

  if (!node) return null;

  // We need a file path to modify. Find it from the node or its parents.
  const path = node.filePath || (node.id.includes(':') ? node.id.split(':')[1] : null);
  
  if (!path) {
    return (
      <div className="p-4 text-xs text-text-secondary">
        Cannot determine file path for this node.
      </div>
    );
  }

  const handleSuggest = async () => {
    if (!instruction.trim()) return;
    setLoading(true);
    setError(null);
    setDiff(null);
    setSuggestedContent(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/api/ai/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          file_path: path,
          instruction: instruction,
          context: `Target node: ${node.name} (${node.label})\nID: ${node.id}`
        }),
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }

      const data = await res.json();
      setDiff(data.diff);
      setSuggestedContent(data.suggested_content);
      setFilePath(data.file_path);
    } catch (err: any) {
      setError(err.message || 'Failed to get suggestion');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    if (!filePath || !suggestedContent) return;
    
    setApplying(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          file_path: filePath,
          suggested_content: suggestedContent,
        }),
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }
      
      setSuccessMsg('Changes applied successfully!');
      setDiff(null); // hide diff on success
    } catch (err: any) {
      setError(err.message || 'Failed to apply changes');
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-bg-primary text-text-primary">
      <div className="p-4 border-b border-border space-y-3 shrink-0">
        <h3 className="font-mono text-xs text-accent uppercase tracking-wider">
          AI Modify
        </h3>
        <p className="text-xs text-text-secondary">
          Instruct the AI to modify <strong>{path}</strong>
        </p>

        <textarea
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
          placeholder="e.g. Add error handling to this function..."
          disabled={loading || applying}
          className="w-full h-24 p-2 text-sm bg-bg-surface border border-border rounded focus:outline-none focus:border-accent resize-none placeholder-text-muted text-text-primary"
        />

        <div className="flex justify-end pt-1">
          <button
            onClick={handleSuggest}
            disabled={!instruction.trim() || loading || applying}
            className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded bg-accent text-bg-primary hover:bg-accent-hover disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
            Generate
          </button>
        </div>

        {error && (
          <div className="flex items-start gap-2 p-2 mt-2 text-xs text-red-400 bg-red-400/10 rounded border border-red-400/20">
            <AlertTriangle size={14} className="shrink-0 mt-0.5" />
            <span className="break-all">{error}</span>
          </div>
        )}
        {successMsg && (
          <div className="flex items-start gap-2 p-2 mt-2 text-xs text-green-400 bg-green-400/10 rounded border border-green-400/20">
            <Check size={14} className="shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-auto p-4">
        {loading && (
          <div className="flex flex-col items-center justify-center h-full text-text-secondary space-y-3">
            <Loader2 size={24} className="animate-spin text-accent" />
            <p className="text-xs">Analyzing and generating code...</p>
          </div>
        )}

        {diff && !loading && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Proposed Changes</h4>
              <div className="space-x-2">
                <button
                  onClick={() => setDiff(null)}
                  disabled={applying}
                  className="px-2 py-1 text-xs border border-border rounded hover:bg-bg-surface text-text-secondary transition-colors"
                >
                  <X size={14} className="inline mr-1 mb-0.5" />
                  Discard
                </button>
                <button
                  onClick={handleApply}
                  disabled={applying}
                  className="px-2 py-1 text-xs border border-green-500/50 bg-green-500/10 text-green-400 rounded hover:bg-green-500/20 transition-colors"
                >
                  {applying ? (
                    <Loader2 size={14} className="animate-spin inline mr-1 mb-0.5" />
                  ) : (
                    <Check size={14} className="inline mr-1 mb-0.5" />
                  )}
                  Apply to File
                </button>
              </div>
            </div>
            
            <div className="border border-border rounded overflow-hidden">
              <CodeBlock code={diff} language="diff" />
            </div>
          </div>
        )}
        
        {!diff && !loading && !successMsg && (
          <div className="flex flex-col items-center justify-center h-full text-text-muted space-y-2 opacity-50">
            <Play size={24} />
            <p className="text-xs">Enter an instruction to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}
