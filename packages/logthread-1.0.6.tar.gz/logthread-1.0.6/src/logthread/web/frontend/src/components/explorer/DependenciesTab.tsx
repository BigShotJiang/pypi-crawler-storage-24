import { useState, useEffect } from 'react';
import { Package, Search } from 'lucide-react';
import { useGraphStore } from '@/stores/graphStore';

interface DependencyUsage {
  file_id: string;
  file_path: string;
}

interface DependencyResponse {
  dep_id: string;
  name: string;
  language: string;
  version: string;
  used_by: DependencyUsage[];
}

export function DependenciesTab() {
  const [deps, setDeps] = useState<DependencyResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  
  const selectNode = useGraphStore((s) => s.selectNode);

  useEffect(() => {
    fetch('/api/dependencies')
      .then(res => res.json())
      .then(data => {
        // Sort alphabetically by name
        data.sort((a: DependencyResponse, b: DependencyResponse) => 
          a.name.localeCompare(b.name)
        );
        setDeps(data);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const filteredDeps = deps.filter(d => 
    d.name.toLowerCase().includes(filter.toLowerCase()) ||
    d.language.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-bg-primary text-text-primary">
      <div className="p-3 border-b border-border space-y-3 shrink-0">
        <h3 className="font-mono text-xs text-accent uppercase tracking-wider">
          External Dependencies
        </h3>
        
        <div className="relative">
          <Search size={14} className="absolute left-2 top-2 text-text-muted" />
          <input
            type="text"
            placeholder="Filter dependencies..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="w-full bg-bg-surface border border-border rounded pl-8 pr-2 py-1.5 text-xs focus:outline-none focus:border-accent text-text-primary placeholder-text-muted"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {loading ? (
          <div className="p-4 text-xs text-text-secondary text-center">Loading dependencies...</div>
        ) : error ? (
          <div className="p-4 text-xs text-red-400 text-center">{error}</div>
        ) : filteredDeps.length === 0 ? (
          <div className="p-4 text-xs text-text-secondary text-center">No dependencies found</div>
        ) : (
          <div className="space-y-1">
            {filteredDeps.map(dep => (
              <details key={dep.dep_id} className="group">
                <summary className="flex items-center gap-2 p-1.5 cursor-pointer rounded hover:bg-bg-surface text-sm select-none">
                  <Package size={14} className="text-accent shrink-0 group-open:text-accent-hover transition-colors" />
                  <span className="truncate flex-1">{dep.name}</span>
                  {dep.version && (
                    <span className="text-xs text-text-secondary truncate shrink-0 max-w-[80px]">
                      {dep.version}
                    </span>
                  )}
                  <span className="text-[10px] uppercase font-mono px-1 border border-border rounded text-text-muted">
                    {dep.language}
                  </span>
                </summary>
                <div className="pl-6 pr-2 py-1 text-xs space-y-1">
                  <div className="text-text-muted mb-1">Files ({dep.used_by.length}):</div>
                  {dep.used_by.map(usage => (
                    <button
                      key={usage.file_id}
                      onClick={() => selectNode(usage.file_id)}
                      className="block w-full text-left truncate text-text-secondary hover:text-accent py-0.5"
                      title={usage.file_path}
                    >
                      {usage.file_path}
                    </button>
                  ))}
                </div>
              </details>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
