"""API routes for external dependencies."""

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from logthread.core.graph.model import NodeLabel, RelType
from logthread.core.storage.base import StorageBackend

router = APIRouter(prefix="/dependencies", tags=["dependencies"])

class DependencyUsage(BaseModel):
    file_id: str
    file_path: str

class DependencyResponse(BaseModel):
    dep_id: str
    name: str
    language: str
    version: str
    used_by: list[DependencyUsage]

@router.get("", response_model=list[DependencyResponse])
def get_all_dependencies(request: Request):
    """Get all external dependencies and the files that use them."""
    storage = request.app.state.storage
    # We can use the graph or raw queries. Since the storage might not
    # expose a direct "get all nodes of label" method, we can do a raw query.
    # The exact raw query depends on the backend, but Kuzu accepts Cypher.
    
    # Alternatively, load the in-memory graph if raw querying isn't standard enough,
    # but querying is faster. Let's try raw cypher for KuzuDB.
    query = f"MATCH (f:File)-[:DEPENDS_ON]->(d:ExternalDep) RETURN d.id, d.name, d.language, d.version, f.id, f.file_path"
    try:
        results = storage.execute_raw(query)
    except Exception:
        # Fallback if the storage backend isn't Kuzu or doesn't support this Cypher
        graph = storage.load_graph()
        deps = {}
        for node in graph.get_nodes_by_label(NodeLabel.EXTERNAL_DEP):
            deps[node.id] = DependencyResponse(
                dep_id=node.id,
                name=node.name,
                language=node.language,
                version=node.properties.get("version", ""),
                used_by=[]
            )
            
        for edge in graph.get_relationships_by_type(RelType.DEPENDS_ON):
            dep = deps.get(edge.target)
            if dep:
                f_node = graph.get_node(edge.source)
                if f_node:
                    dep.used_by.append(DependencyUsage(
                        file_id=f_node.id,
                        file_path=f_node.file_path or f_node.name
                    ))
        return list(deps.values())
        
    # Process Cypher results
    import pandas as pd
    if isinstance(results, pd.DataFrame):
        deps = {}
        for _, row in results.iterrows():
            d_id = row.get("d.id")
            if d_id not in deps:
                deps[d_id] = DependencyResponse(
                    dep_id=d_id,
                    name=row.get("d.name", ""),
                    language=row.get("d.language", ""),
                    version=row.get("d.version", ""),
                    used_by=[]
                )
            deps[d_id].used_by.append(DependencyUsage(
                file_id=row.get("f.id", ""),
                file_path=row.get("f.file_path", "")
            ))
        return list(deps.values())
        
    # If not a dataframe, fallback to iterating Assuming list of dicts or tuples
    deps = {}
    if not results:
        return []
        
    for row in results:
        # handle list/tuple or dict based on backend
        if isinstance(row, dict):
            d_id = row.get("d.id") or row.get("d", {}).get("id")
            name = row.get("d.name") or row.get("d", {}).get("name", "")
            lang = row.get("d.language") or row.get("d", {}).get("language", "")
            ver = row.get("d.version") or row.get("d", {}).get("version", "")
            f_id = row.get("f.id") or row.get("f", {}).get("id", "")
            f_path = row.get("f.file_path") or row.get("f", {}).get("file_path", "")
        else:
            # Tuple fallback (id, name, lang, ver, f_id, f_path)
            d_id, name, lang, ver, f_id, f_path = row[:6]
            
        if d_id not in deps:
            deps[d_id] = DependencyResponse(
                dep_id=d_id, name=name, language=lang, version=ver, used_by=[]
            )
        deps[d_id].used_by.append(DependencyUsage(file_id=f_id, file_path=f_path))
        
    return list(deps.values())
