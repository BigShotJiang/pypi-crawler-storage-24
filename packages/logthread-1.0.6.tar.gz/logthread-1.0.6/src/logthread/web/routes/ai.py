"""API routes for AI code modifications."""

import difflib
import logging
from pathlib import Path
from pydantic import BaseModel
from fastapi import APIRouter, HTTPException, Request, status

from logthread.core.ai.llm import AIClient

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ai", tags=["ai"])

class SuggestRequest(BaseModel):
    file_path: str
    instruction: str
    context: str = ""

class SuggestResponse(BaseModel):
    file_path: str
    original_content: str
    suggested_content: str
    diff: str

class ApplyRequest(BaseModel):
    file_path: str
    suggested_content: str

class ApplyResponse(BaseModel):
    success: bool
    message: str

def _generate_diff(original: str, modified: str, fromfile: str, tofile: str) -> str:
    """Generate a unified diff between two strings."""
    original_lines = original.splitlines(keepends=True)
    modified_lines = modified.splitlines(keepends=True)
    
    diff = list(difflib.unified_diff(
        original_lines,
        modified_lines,
        fromfile=fromfile,
        tofile=tofile,
        n=3
    ))
    return "".join(diff)

@router.post("/suggest", response_model=SuggestResponse)
def suggest_edit(
    req: SuggestRequest, 
    request: Request
):
    """Ask the AI to suggest an edit for a specific file."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")
        
    abs_path = repo_path / req.file_path
    if not abs_path.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")
        
    try:
        content = abs_path.read_text(encoding="utf-8")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read file: {e}")
        
    # Get suggestion from LLM
    try:
        client = AIClient()
        new_content = client.suggest_edit(
            instruction=req.instruction,
            file_path=req.file_path,
            file_content=content,
            context=req.context
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI service failed: {e}")
        
    # Generate diff
    diff_text = _generate_diff(
        original=content,
        modified=new_content,
        fromfile=f"a/{req.file_path}",
        tofile=f"b/{req.file_path}"
    )
    
    return SuggestResponse(
        file_path=req.file_path,
        original_content=content,
        suggested_content=new_content,
        diff=diff_text
    )

@router.post("/apply", response_model=ApplyResponse)
def apply_edit(
    req: ApplyRequest,
    request: Request
):
    """Apply the suggested edit to the file on disk."""
    repo_path = request.app.state.repo_path
    if repo_path is None:
        raise HTTPException(status_code=400, detail="Repository path is not configured.")
        
    abs_path = repo_path / req.file_path
    if not abs_path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")
        
    try:
        abs_path.write_text(req.suggested_content, encoding="utf-8")
        return ApplyResponse(
            success=True,
            message=f"Successfully updated {req.file_path}"
        )
    except Exception as e:
        logger.error(f"Failed to write changes to {abs_path}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to apply changes: {e}")
