"""Log Thread — AI-powered code intelligence with graph context."""

__version__ = "1.0.6"
