"""Cloud storage abstraction for Log Thread.

Supports both OCI Object Storage (preferred) and AWS S3.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import BinaryIO, Optional
import os

from ..config import get_settings

settings = get_settings()


class StorageBackend(ABC):
    """Abstract storage backend interface."""
    
    @abstractmethod
    def upload(self, key: str, data: BinaryIO) -> str:
        """Upload data and return the storage URL."""
        pass
    
    @abstractmethod
    def download(self, key: str) -> bytes:
        """Download data from storage."""
        pass
    
    @abstractmethod
    def get_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        """Get a presigned URL for downloading."""
        pass
    
    @abstractmethod
    def delete(self, key: str) -> bool:
        """Delete an object from storage."""
        pass


class OCIStorage(StorageBackend):
    """OCI Object Storage backend."""
    
    def __init__(self):
        import oci

        auth_mode = (settings.oci_auth or "config").lower()
        signer = None

        if auth_mode == "instance_principal":
            signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
            region = (
                getattr(signer, "region", None)
                or os.environ.get("OCI_REGION")
                or "us-ashburn-1"
            )
            self.config = {"region": region}
        else:
            config_file = os.path.expanduser(settings.oci_config_file)
            if os.path.exists(config_file):
                self.config = oci.config.from_file(config_file, settings.oci_config_profile)
            else:
                self.config = {
                    "user": os.environ.get("OCI_USER_OCID", ""),
                    "key_file": os.environ.get("OCI_KEY_FILE", ""),
                    "fingerprint": os.environ.get("OCI_FINGERPRINT", ""),
                    "tenancy": os.environ.get("OCI_TENANCY_OCID", ""),
                    "region": os.environ.get("OCI_REGION", "us-ashburn-1"),
                }
        
        if signer:
            self.client = oci.object_storage.ObjectStorageClient(self.config, signer=signer)
        else:
            self.client = oci.object_storage.ObjectStorageClient(self.config)
        self.namespace = settings.oci_namespace or self.client.get_namespace().data
        self.bucket = settings.oci_bucket
    
    def upload(self, key: str, data: BinaryIO) -> str:
        self.client.put_object(
            namespace_name=self.namespace,
            bucket_name=self.bucket,
            object_name=key,
            put_object_body=data,
        )
        return f"oci://{self.namespace}/{self.bucket}/{key}"
    
    def download(self, key: str) -> bytes:
        response = self.client.get_object(
            namespace_name=self.namespace,
            bucket_name=self.bucket,
            object_name=key,
        )
        return response.data.content
    
    def get_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        from datetime import datetime, timedelta
        import oci
        
        details = oci.object_storage.models.CreatePreauthenticatedRequestDetails(
            name=f"download-{key.replace('/', '-')}",
            access_type="ObjectRead",
            object_name=key,
            time_expires=datetime.utcnow() + timedelta(seconds=expires_in),
        )
        
        par = self.client.create_preauthenticated_request(
            namespace_name=self.namespace,
            bucket_name=self.bucket,
            create_preauthenticated_request_details=details,
        )
        
        region = self.config.get("region", "us-ashburn-1")
        return f"https://objectstorage.{region}.oraclecloud.com{par.data.access_uri}"
    
    def delete(self, key: str) -> bool:
        try:
            self.client.delete_object(
                namespace_name=self.namespace,
                bucket_name=self.bucket,
                object_name=key,
            )
            return True
        except Exception:
            return False


class S3Storage(StorageBackend):
    """AWS S3 storage backend."""
    
    def __init__(self):
        import boto3
        
        self.client = boto3.client(
            "s3",
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
            region_name=settings.aws_region,
        )
        self.bucket = settings.s3_bucket
    
    def upload(self, key: str, data: BinaryIO) -> str:
        self.client.upload_fileobj(data, self.bucket, key)
        return f"s3://{self.bucket}/{key}"
    
    def download(self, key: str) -> bytes:
        import io
        buffer = io.BytesIO()
        self.client.download_fileobj(self.bucket, key, buffer)
        buffer.seek(0)
        return buffer.read()
    
    def get_presigned_url(self, key: str, expires_in: int = 3600) -> str:
        return self.client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket, "Key": key},
            ExpiresIn=expires_in,
        )
    
    def delete(self, key: str) -> bool:
        try:
            self.client.delete_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:
            return False


def get_storage() -> StorageBackend:
    """Get the configured storage backend."""
    if settings.storage_provider == "oci":
        return OCIStorage()
    elif settings.storage_provider == "s3":
        return S3Storage()
    else:
        raise ValueError(f"Unknown storage provider: {settings.storage_provider}")
