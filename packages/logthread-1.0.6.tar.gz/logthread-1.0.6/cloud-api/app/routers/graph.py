from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from datetime import datetime
import hashlib

from ..database import get_db
from ..services import auth
from ..services.storage import get_storage
from ..models import Repository
from ..config import get_settings

router = APIRouter(prefix="/graph", tags=["graph"])
settings = get_settings()


class SyncRequest(BaseModel):
    repo_name: str
    repo_path_hash: str
    symbols_count: int
    edges_count: int
    files_count: int


async def get_current_user(request: Request, db: AsyncSession = Depends(get_db)):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    
    if token.startswith("lt_"):
        user = await auth.validate_api_key(db, token)
    else:
        payload = auth.decode_token(token)
        if not payload:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await auth.get_user_by_id(db, payload["sub"])
        
        if user and not await auth.is_subscription_active(db, str(user.id)):
            raise HTTPException(status_code=402, detail="Subscription required")
    
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    return user


@router.get("/repos")
async def list_repos(db: AsyncSession = Depends(get_db), user=Depends(get_current_user)):
    """List all synced repositories"""
    result = await db.execute(
        select(Repository).where(Repository.user_id == user.id).order_by(Repository.updated_at.desc())
    )
    repos = result.scalars().all()
    
    return {
        "repositories": [
            {
                "id": str(r.id),
                "name": r.name,
                "symbols_count": r.symbols_count,
                "edges_count": r.edges_count,
                "files_count": r.files_count,
                "last_analyzed": r.last_analyzed.isoformat() if r.last_analyzed else None,
                "has_cloud_data": bool(r.graph_data_url),
            }
            for r in repos
        ]
    }


@router.post("/sync")
async def sync_repo_metadata(
    req: SyncRequest,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user)
):
    """Sync repository metadata (called after analysis)"""
    result = await db.execute(
        select(Repository).where(
            Repository.user_id == user.id,
            Repository.path_hash == req.repo_path_hash
        )
    )
    repo = result.scalar_one_or_none()
    
    if not repo:
        repo = Repository(
            user_id=user.id,
            name=req.repo_name,
            path_hash=req.repo_path_hash,
        )
        db.add(repo)
    
    repo.name = req.repo_name
    repo.symbols_count = req.symbols_count
    repo.edges_count = req.edges_count
    repo.files_count = req.files_count
    repo.last_analyzed = datetime.utcnow()
    
    await db.commit()
    await db.refresh(repo)
    
    return {
        "id": str(repo.id),
        "upload_url": f"/graph/upload/{repo.id}" if settings.aws_access_key_id else None
    }


@router.post("/upload/{repo_id}")
async def upload_graph_data(
    repo_id: str,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user)
):
    """Upload graph data to cloud storage (OCI or S3)"""
    result = await db.execute(
        select(Repository).where(Repository.id == repo_id, Repository.user_id == user.id)
    )
    repo = result.scalar_one_or_none()
    
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    storage = get_storage()
    key = f"graphs/{user.id}/{repo_id}/graph.db"
    
    storage_url = storage.upload(key, file.file)
    
    repo.graph_data_url = storage_url
    await db.commit()
    
    return {"message": "Graph uploaded successfully"}


@router.get("/download/{repo_id}")
async def get_graph_download_url(
    repo_id: str,
    db: AsyncSession = Depends(get_db),
    user=Depends(get_current_user)
):
    """Get presigned URL to download graph data"""
    result = await db.execute(
        select(Repository).where(Repository.id == repo_id, Repository.user_id == user.id)
    )
    repo = result.scalar_one_or_none()
    
    if not repo or not repo.graph_data_url:
        raise HTTPException(status_code=404, detail="Graph data not found")
    
    storage = get_storage()
    
    if repo.graph_data_url.startswith("oci://"):
        parts = repo.graph_data_url.replace("oci://", "").split("/", 2)
        key = parts[2] if len(parts) > 2 else ""
    elif repo.graph_data_url.startswith("s3://"):
        parts = repo.graph_data_url.replace("s3://", "").split("/", 1)
        key = parts[1] if len(parts) > 1 else ""
    else:
        key = repo.graph_data_url
    
    url = storage.get_presigned_url(key, expires_in=3600)
    
    return {"download_url": url}
