from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel, EmailStr
from datetime import datetime

from ..database import get_db
from ..services import auth, email
from ..config import get_settings

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


@router.post("/register")
async def register(req: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await auth.get_user_by_email(db, req.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user = await auth.create_user(db, req.email, req.password, req.name)
    await email.send_verification_email(user.email, user.verification_token)
    
    return {"message": "Account created. Please check your email to verify."}


@router.post("/login", response_model=TokenResponse)
async def login(req: LoginRequest, db: AsyncSession = Depends(get_db)):
    user = await auth.get_user_by_email(db, req.email)
    
    if not user or not auth.verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    if not user.email_verified:
        raise HTTPException(status_code=401, detail="Please verify your email first")
    
    if not user.is_active:
        raise HTTPException(status_code=401, detail="Account is disabled")
    
    # Check subscription
    is_active = await auth.is_subscription_active(db, str(user.id))
    
    # Update last login
    user.last_login = datetime.utcnow()
    await db.commit()
    
    token = auth.create_access_token({"sub": str(user.id)})
    
    return TokenResponse(
        access_token=token,
        user={
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "subscription_active": is_active,
        }
    )


@router.get("/verify")
async def verify_email(token: str, db: AsyncSession = Depends(get_db)):
    user = await auth.verify_email(db, token)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired verification token")
    
    return RedirectResponse(url=f"{settings.app_url}/login?verified=true")


@router.get("/me")
async def get_current_user(request: Request, db: AsyncSession = Depends(get_db)):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    payload = auth.decode_token(token)
    
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await auth.get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    subscription = await auth.get_subscription(db, str(user.id))
    is_active = await auth.is_subscription_active(db, str(user.id))
    
    return {
        "id": str(user.id),
        "email": user.email,
        "name": user.name,
        "created_at": user.created_at.isoformat(),
        "subscription": {
            "active": is_active,
            "status": subscription.status if subscription else "none",
            "current_period_end": subscription.current_period_end.isoformat() if subscription and subscription.current_period_end else None,
        } if subscription else None
    }


@router.post("/api-key")
async def create_api_key(request: Request, db: AsyncSession = Depends(get_db)):
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    token = auth_header.split(" ")[1]
    payload = auth.decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await auth.get_user_by_id(db, payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    if not await auth.is_subscription_active(db, str(user.id)):
        raise HTTPException(status_code=402, detail="Active subscription required")
    
    full_key, api_key = await auth.create_api_key_for_user(db, str(user.id))
    
    return {
        "key": full_key,
        "prefix": api_key.key_prefix,
        "created_at": api_key.created_at.isoformat(),
        "message": "Save this key securely - it won't be shown again"
    }
