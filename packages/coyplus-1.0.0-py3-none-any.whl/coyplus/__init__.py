"""
Coy++ - библиотека полезных функций без внешних зависимостей.
Версия 1.0.0
"""

import os
import sys
import re
import math
import random
import time
import datetime
import hashlib
import base64
import json
import pickle
import socket
import struct
import threading
import queue
import gzip
import zipfile
import tarfile
import shutil
import glob
import tempfile
import subprocess
import platform
import webbrowser
import urllib.parse
import urllib.request
import http.client
import csv
import sqlite3
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict, OrderedDict, deque
from functools import wraps, lru_cache
from itertools import chain, cycle, permutations, combinations
import warnings

__version__ = "1.0.0"
__author__ = "Coy++ Team"
__license__ = "MIT"

# ======================== СТРОКИ ========================

def reverse_string(s: str) -> str:
    """Переворачивает строку."""
    return s[::-1]

def count_words(s: str) -> int:
    """Считает количество слов в строке (разделитель пробел)."""
    return len(s.split())

def is_palindrome(s: str) -> bool:
    """Проверяет, является ли строка палиндромом (игнорируя регистр и пробелы)."""
    s_clean = re.sub(r'\s+', '', s.lower())
    return s_clean == s_clean[::-1]

def extract_emails(text: str) -> list:
    """Извлекает все email из текста."""
    pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    return re.findall(pattern, text)

def extract_urls(text: str) -> list:
    """Извлекает все URL из текста."""
    pattern = r'https?://[^\s]+'
    return re.findall(pattern, text)

def slugify(text: str) -> str:
    """Преобразует текст в slug (только буквы, цифры, дефисы)."""
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text

def random_string(length: int = 8, chars: str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') -> str:
    """Генерирует случайную строку заданной длины из указанных символов."""
    return ''.join(random.choice(chars) for _ in range(length))

def mask_string(s: str, visible: int = 4, mask_char: str = '*') -> str:
    """Маскирует строку, оставляя видимыми только первые visible символов."""
    if len(s) <= visible:
        return s
    return s[:visible] + mask_char * (len(s) - visible)

def pluralize(word: str, count: int) -> str:
    """Очень простое склонение: добавляет s, если count != 1."""
    if count == 1:
        return word
    return word + 's'

# ======================== ЧИСЛА И МАТЕМАТИКА ========================

def is_prime(n: int) -> bool:
    """Проверяет, является ли число простым."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        if n % i == 0:
            return False
    return True

def fibonacci(n: int) -> list:
    """Возвращает список первых n чисел Фибоначчи."""
    if n <= 0:
        return []
    if n == 1:
        return [0]
    fib = [0, 1]
    for i in range(2, n):
        fib.append(fib[-1] + fib[-2])
    return fib

def gcd(a: int, b: int) -> int:
    """Наибольший общий делитель (алгоритм Евклида)."""
    while b:
        a, b = b, a % b
    return a

def lcm(a: int, b: int) -> int:
    """Наименьшее общее кратное."""
    return a * b // gcd(a, b)

def factors(n: int) -> list:
    """Возвращает все положительные делители числа n."""
    result = []
    for i in range(1, int(math.sqrt(n)) + 1):
        if n % i == 0:
            result.append(i)
            if i != n // i:
                result.append(n // i)
    return sorted(result)

def is_even(n: int) -> bool:
    return n % 2 == 0

def is_odd(n: int) -> bool:
    return n % 2 != 0

def clamp(value, min_val, max_val):
    """Ограничивает значение диапазоном [min_val, max_val]."""
    return max(min_val, min(value, max_val))

def lerp(a, b, t: float):
    """Линейная интерполяция между a и b с коэффициентом t (0..1)."""
    return a + (b - a) * t

def map_range(value, from_min, from_max, to_min, to_max):
    """Переносит значение из одного диапазона в другой."""
    return to_min + (to_max - to_min) * ((value - from_min) / (from_max - from_min))

# ======================== РАБОТА С ФАЙЛАМИ ========================

def read_file(path: str, encoding='utf-8') -> str:
    """Читает содержимое текстового файла."""
    with open(path, 'r', encoding=encoding) as f:
        return f.read()

def write_file(path: str, content: str, encoding='utf-8'):
    """Записывает строку в файл."""
    with open(path, 'w', encoding=encoding) as f:
        f.write(content)

def append_file(path: str, content: str, encoding='utf-8'):
    """Добавляет строку в конец файла."""
    with open(path, 'a', encoding=encoding) as f:
        f.write(content)

def read_lines(path: str, encoding='utf-8') -> list:
    """Читает файл и возвращает список строк."""
    with open(path, 'r', encoding=encoding) as f:
        return f.readlines()

def write_lines(path: str, lines: list, encoding='utf-8'):
    """Записывает список строк в файл."""
    with open(path, 'w', encoding=encoding) as f:
        f.writelines(lines)

def file_exists(path: str) -> bool:
    return os.path.isfile(path)

def dir_exists(path: str) -> bool:
    return os.path.isdir(path)

def mkdir(path: str, exist_ok: bool = True):
    """Создаёт директорию."""
    os.makedirs(path, exist_ok=exist_ok)

def delete_file(path: str):
    """Удаляет файл."""
    os.remove(path)

def delete_dir(path: str, recursive: bool = False):
    """Удаляет директорию (рекурсивно при необходимости)."""
    if recursive:
        shutil.rmtree(path)
    else:
        os.rmdir(path)

def list_files(path: str, pattern: str = '*') -> list:
    """Возвращает список файлов в директории, соответствующих шаблону."""
    return glob.glob(os.path.join(path, pattern))

def get_file_size(path: str) -> int:
    return os.path.getsize(path)

def get_file_extension(path: str) -> str:
    return os.path.splitext(path)[1]

def copy_file(src: str, dst: str):
    shutil.copy2(src, dst)

def move_file(src: str, dst: str):
    shutil.move(src, dst)

def compress_gz(src: str, dst: str = None):
    """Сжимает файл в gz."""
    if dst is None:
        dst = src + '.gz'
    with open(src, 'rb') as f_in:
        with gzip.open(dst, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

def decompress_gz(src: str, dst: str = None):
    """Распаковывает gz файл."""
    if dst is None:
        dst = src[:-3] if src.endswith('.gz') else src + '.out'
    with gzip.open(src, 'rb') as f_in:
        with open(dst, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)

def create_zip(src_dir: str, dst_zip: str):
    """Создаёт zip-архив из директории."""
    with zipfile.ZipFile(dst_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(src_dir):
            for file in files:
                zf.write(os.path.join(root, file),
                         os.path.relpath(os.path.join(root, file), src_dir))

def extract_zip(zip_path: str, dst_dir: str):
    """Распаковывает zip-архив."""
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(dst_dir)

# ======================== ДАТА И ВРЕМЯ ========================

def timestamp() -> float:
    """Текущая метка времени (секунды с эпохи)."""
    return time.time()

def datetime_now() -> datetime.datetime:
    return datetime.datetime.now()

def date_now() -> datetime.date:
    return datetime.date.today()

def format_datetime(dt: datetime.datetime, fmt: str = '%Y-%m-%d %H:%M:%S') -> str:
    return dt.strftime(fmt)

def parse_datetime(s: str, fmt: str = '%Y-%m-%d %H:%M:%S') -> datetime.datetime:
    return datetime.datetime.strptime(s, fmt)

def sleep(seconds: float):
    time.sleep(seconds)

def timer(func):
    """Декоратор для измерения времени выполнения функции."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        print(f"{func.__name__} executed in {end - start:.4f} seconds")
        return result
    return wrapper

def countdown(seconds: int):
    """Обратный отсчёт."""
    for i in range(seconds, 0, -1):
        print(i, end=' ', flush=True)
        time.sleep(1)
    print("Time's up!")

# ======================== СЛУЧАЙНОСТИ ========================

def randint(a: int, b: int) -> int:
    return random.randint(a, b)

def randfloat(a: float, b: float) -> float:
    return random.uniform(a, b)

def choice(seq):
    return random.choice(seq)

def shuffle(seq):
    random.shuffle(seq)

def sample(population, k: int):
    return random.sample(population, k)

def weighted_choice(items, weights):
    """Выбирает элемент с учётом весов."""
    total = sum(weights)
    r = random.uniform(0, total)
    upto = 0
    for item, w in zip(items, weights):
        upto += w
        if upto >= r:
            return item
    return items[-1]

# ======================== ШИФРОВАНИЕ (ПРОСТОЕ) ========================

def md5(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()

def sha1(s: str) -> str:
    return hashlib.sha1(s.encode()).hexdigest()

def sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()

def base64_encode(data: bytes) -> str:
    return base64.b64encode(data).decode()

def base64_decode(s: str) -> bytes:
    return base64.b64decode(s)

def rot13(text: str) -> str:
    """Шифр Цезаря ROT13."""
    result = []
    for ch in text:
        if 'a' <= ch <= 'z':
            result.append(chr((ord(ch) - ord('a') + 13) % 26 + ord('a')))
        elif 'A' <= ch <= 'Z':
            result.append(chr((ord(ch) - ord('A') + 13) % 26 + ord('A')))
        else:
            result.append(ch)
    return ''.join(result)

def xor_cipher(data: bytes, key: bytes) -> bytes:
    """Простое XOR-шифрование."""
    key_len = len(key)
    return bytes(data[i] ^ key[i % key_len] for i in range(len(data)))

# ======================== СЕТЬ ========================

def get_local_ip() -> str:
    """Возвращает локальный IP-адрес."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip

def ping(host: str, count: int = 1) -> bool:
    """Проверяет доступность хоста (ICMP ping) через системную команду."""
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    result = subprocess.run(['ping', param, str(count), host],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    return result.returncode == 0

def download_file(url: str, dest: str):
    """Скачивает файл по URL."""
    urllib.request.urlretrieve(url, dest)

def url_encode(s: str) -> str:
    return urllib.parse.quote(s)

def url_decode(s: str) -> str:
    return urllib.parse.unquote(s)

def http_get(url: str, timeout: int = 10) -> str:
    """Выполняет GET-запрос и возвращает тело ответа."""
    with urllib.request.urlopen(url, timeout=timeout) as response:
        return response.read().decode()

def http_post(url: str, data: dict = None, headers: dict = None) -> str:
    """Выполняет POST-запрос с данными."""
    data_bytes = urllib.parse.urlencode(data or {}).encode()
    req = urllib.request.Request(url, data=data_bytes, headers=headers or {})
    with urllib.request.urlopen(req) as response:
        return response.read().decode()

def is_port_open(host: str, port: int, timeout: int = 2) -> bool:
    """Проверяет, открыт ли TCP-порт на хосте."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    result = sock.connect_ex((host, port))
    sock.close()
    return result == 0

# ======================== КОНВЕРТАЦИЯ ТИПОВ ========================

def to_int(s: str, default: int = 0) -> int:
    try:
        return int(s)
    except:
        return default

def to_float(s: str, default: float = 0.0) -> float:
    try:
        return float(s)
    except:
        return default

def to_bool(s: str) -> bool:
    return s.lower() in ('true', 'yes', '1', 'on')

def bytes_to_str(b: bytes, encoding='utf-8') -> str:
    return b.decode(encoding)

def str_to_bytes(s: str, encoding='utf-8') -> bytes:
    return s.encode(encoding)

def list_to_csv(data: list, path: str):
    """Сохраняет список списков в CSV."""
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(data)

def csv_to_list(path: str) -> list:
    """Читает CSV в список списков."""
    with open(path, 'r', newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        return list(reader)

def json_encode(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)

def json_decode(s: str):
    return json.loads(s)

def pickle_dump(obj, path: str):
    with open(path, 'wb') as f:
        pickle.dump(obj, f)

def pickle_load(path: str):
    with open(path, 'rb') as f:
        return pickle.load(f)

# ======================== КОЛЛЕКЦИИ ========================

def count_occurrences(seq):
    """Возвращает словарь с подсчётом элементов в последовательности."""
    return dict(Counter(seq))

def flatten(lst):
    """Разворачивает вложенный список на один уровень."""
    return [item for sublist in lst for item in sublist]

def unique(seq):
    """Возвращает список уникальных элементов с сохранением порядка."""
    seen = set()
    result = []
    for item in seq:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

def chunk_list(lst, chunk_size: int):
    """Разбивает список на части указанного размера."""
    for i in range(0, len(lst), chunk_size):
        yield lst[i:i + chunk_size]

def merge_dicts(*dicts):
    """Объединяет несколько словарей (последующие перезаписывают предыдущие)."""
    result = {}
    for d in dicts:
        result.update(d)
    return result

def dict_get(d, path: str, default=None):
    """Безопасно получает значение по точечному пути (например, 'a.b.c')."""
    keys = path.split('.')
    for key in keys:
        if isinstance(d, dict) and key in d:
            d = d[key]
        else:
            return default
    return d

# ======================== СИСТЕМА ========================

def system_info() -> dict:
    """Возвращает информацию о системе."""
    return {
        'platform': platform.system(),
        'release': platform.release(),
        'version': platform.version(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'python_version': platform.python_version(),
        'hostname': socket.gethostname(),
        'cpus': os.cpu_count(),
    }

def clear_screen():
    """Очищает экран терминала."""
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def open_url(url: str):
    """Открывает URL в браузере по умолчанию."""
    webbrowser.open(url)

def run_command(cmd: str, capture_output: bool = False):
    """Выполняет команду в оболочке."""
    if capture_output:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True)
    else:
        subprocess.run(cmd, shell=True)

def get_env(key: str, default=None):
    return os.environ.get(key, default)

def set_env(key: str, value: str):
    os.environ[key] = value

def exit(code: int = 0):
    sys.exit(code)

# ======================== МАТЕМАТИЧЕСКИЕ КОНСТАНТЫ ========================

PI = math.pi
E = math.e
TAU = 2 * math.pi

# ======================== ДЕКОРАТОРЫ ========================

def retry(max_attempts: int = 3, delay: float = 1.0):
    """Декоратор для повторной попытки выполнения функции при исключении."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts - 1:
                        raise
                    time.sleep(delay)
            return None
        return wrapper
    return decorator

def memoize(func):
    """Кэширует результат функции (для неизменяемых аргументов)."""
    cache = {}
    @wraps(func)
    def wrapper(*args):
        if args in cache:
            return cache[args]
        result = func(*args)
        cache[args] = result
        return result
    return wrapper

def deprecated(func):
    """Декоратор, помечающий функцию как устаревшую."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        warnings.warn(f"{func.__name__} is deprecated and will be removed in future versions.",
                      DeprecationWarning, stacklevel=2)
        return func(*args, **kwargs)
    return wrapper

# ======================== АСИНХРОННОСТЬ (ПРОСТАЯ) ========================

class BackgroundTask:
    """Простой класс для выполнения задачи в фоновом потоке."""
    def __init__(self, target, args=(), kwargs=None):
        self.target = target
        self.args = args
        self.kwargs = kwargs or {}
        self.thread = threading.Thread(target=self._run)
        self.result = queue.Queue()
        self.thread.daemon = True

    def _run(self):
        try:
            res = self.target(*self.args, **self.kwargs)
            self.result.put(res)
        except Exception as e:
            self.result.put(e)

    def start(self):
        self.thread.start()

    def join(self, timeout=None):
        self.thread.join(timeout)

    def get_result(self, timeout=None):
        return self.result.get(timeout=timeout)

def parallel_map(func, items, max_workers: int = 4):
    """Параллельно применяет функцию к элементам списка (простая реализация через потоки)."""
    results = []
    threads = []
    result_queue = queue.Queue()

    def worker(item):
        result_queue.put((item, func(item)))

    for item in items:
        t = threading.Thread(target=worker, args=(item,))
        t.start()
        threads.append(t)
        if len(threads) >= max_workers:
            for t in threads:
                t.join()
            threads = []

    for t in threads:
        t.join()

    while not result_queue.empty():
        results.append(result_queue.get())
    return [res for _, res in sorted(results, key=lambda x: items.index(x[0]))]

# ======================== ГЕОГРАФИЯ (ПРОСТАЯ) ========================

def haversine(lat1, lon1, lat2, lon2):
    """Вычисляет расстояние между двумя точками на сфере (в км)."""
    R = 6371  # радиус Земли в км
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    return R * c

# ======================== ЭКСПОРТ ВСЕГО ========================

__all__ = [
    'reverse_string', 'count_words', 'is_palindrome', 'extract_emails', 'extract_urls',
    'slugify', 'random_string', 'mask_string', 'pluralize',
    'is_prime', 'fibonacci', 'gcd', 'lcm', 'factors', 'is_even', 'is_odd', 'clamp', 'lerp', 'map_range',
    'read_file', 'write_file', 'append_file', 'read_lines', 'write_lines',
    'file_exists', 'dir_exists', 'mkdir', 'delete_file', 'delete_dir', 'list_files',
    'get_file_size', 'get_file_extension', 'copy_file', 'move_file',
    'compress_gz', 'decompress_gz', 'create_zip', 'extract_zip',
    'timestamp', 'datetime_now', 'date_now', 'format_datetime', 'parse_datetime', 'sleep', 'timer', 'countdown',
    'randint', 'randfloat', 'choice', 'shuffle', 'sample', 'weighted_choice',
    'md5', 'sha1', 'sha256', 'base64_encode', 'base64_decode', 'rot13', 'xor_cipher',
    'get_local_ip', 'ping', 'download_file', 'url_encode', 'url_decode', 'http_get', 'http_post', 'is_port_open',
    'to_int', 'to_float', 'to_bool', 'bytes_to_str', 'str_to_bytes', 'list_to_csv', 'csv_to_list',
    'json_encode', 'json_decode', 'pickle_dump', 'pickle_load',
    'count_occurrences', 'flatten', 'unique', 'chunk_list', 'merge_dicts', 'dict_get',
    'system_info', 'clear_screen', 'open_url', 'run_command', 'get_env', 'set_env', 'exit',
    'PI', 'E', 'TAU',
    'retry', 'memoize', 'deprecated',
    'BackgroundTask', 'parallel_map',
    'haversine',
]