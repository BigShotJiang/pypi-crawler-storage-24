"""gfo webhook サブコマンドのハンドラ。"""

from __future__ import annotations

import argparse

from gfo.commands import get_adapter
from gfo.output import output


def handle_list(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo webhook list のハンドラ。"""
    adapter = get_adapter()
    webhooks = adapter.list_webhooks(limit=args.limit)
    output(webhooks, fmt=fmt, fields=["id", "url", "events", "active"], jq=jq)


def handle_create(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo webhook create --url URL --event EVENT のハンドラ。"""
    adapter = get_adapter()
    webhook = adapter.create_webhook(url=args.url, events=args.event, secret=args.secret)
    output(webhook, fmt=fmt, jq=jq)


def handle_delete(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo webhook delete <id> のハンドラ。"""
    adapter = get_adapter()
    adapter.delete_webhook(hook_id=args.id)


def handle_test(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo webhook test <id> のハンドラ。"""
    adapter = get_adapter()
    adapter.test_webhook(hook_id=args.id)


def handle_edit(args: argparse.Namespace, *, fmt: str, jq: str | None = None) -> None:
    """gfo webhook edit <id> のハンドラ。"""
    adapter = get_adapter()
    active = getattr(args, "active", None)
    webhook = adapter.update_webhook(
        args.id,
        url=getattr(args, "url", None),
        events=getattr(args, "event", None),
        secret=getattr(args, "secret", None),
        active=active,
    )
    output(webhook, fmt=fmt, jq=jq)
