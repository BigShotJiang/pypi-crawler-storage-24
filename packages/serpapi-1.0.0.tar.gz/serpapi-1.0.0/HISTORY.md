Release History
===============

1.0.0 (2026-03-18)
------------------

- Automated PyPI release pipeline via GitHub Actions (tag-triggered: test → build → publish → smoke test).
- Modernized packaging to PEP 621 (pyproject.toml), removing legacy setup.py and Pipfile.
- Added Python 3.13 support.

0.1.6 (2026-02-16)
------------------

- Add support for request timeouts.
- Add status and error codes support - https://serpapi.com/api-status-and-error-codes

0.1.5 (2023-11-01)
------------------

- Python 3.12 support. 

0.1.4 (2023-10-11)
------------------

- Add README documentation for various engines.

0.1.3 (2023-10-06)
------------------

- Replace deprecated serpapi_pagination.next_link with 'next'. 
- Improve documentation: how to use the client directly for pagination searches.

0.1.2 (2023-10-03)
------------------

- Update project status to Production/Stable.

0.1.1 (2023-10-03)
------------------

- Update documentation link to point to Read the Docs.

0.1.0 (2023-10-03)
------------------

- First release on PyPI.
