/**
 * 工作流 JSON 上传到 OSS（用于 draft 保存）
 * 复用 uploadFile 的 OSS 表单上传逻辑，但不调用 commit_input_resource
 */
import { getCookie } from "../utils.js";

async function hmacSha1(message, key) {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(key);
  const messageData = encoder.encode(message);
  const cryptoKey = await window.crypto.subtle.importKey(
    "raw",
    keyData,
    { name: "HMAC", hash: "SHA-1" },
    false,
    ["sign"]
  );
  const signature = await window.crypto.subtle.sign(
    "HMAC",
    cryptoKey,
    messageData
  );
  const bytes = new Uint8Array(signature);
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * 上传工作流 JSON 到 OSS
 * @param {string} workflowStr - 工作流 JSON 字符串
 * @param {string} filename - 文件名，默认 workflow.json
 * @returns {Promise<{object_key: string, ossTokenFile: object}>}
 */
export async function workflowToOss(workflowStr, filename = "workflow.json") {
  const authToken = getCookie("auth_token");
  if (!authToken) {
    throw new Error("未找到认证Token，请先登录");
  }

  const tokenRes = await fetch(
    `/bizyair/upload_token?file_name=${encodeURIComponent(
      filename
    )}&file_type=drafts`,
    {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${authToken}`,
      },
    }
  );

  if (!tokenRes.ok) {
    const errorText = await tokenRes.text();
    throw new Error(`获取上传凭证失败: ${tokenRes.status} ${errorText}`);
  }

  const tokenData = await tokenRes.json();
  const data = tokenData.data;
  if (!data?.file || !data?.storage) {
    throw new Error("上传凭证格式错误");
  }

  const ossConfig = {
    accessKeyId: data.file.access_key_id,
    accessKeySecret: data.file.access_key_secret,
    securityToken: data.file.security_token,
    objectKey: data.file.object_key,
    bucket: data.storage.bucket,
    region: data.storage.region,
  };

  const file = new File([workflowStr], filename, {
    type: "application/json",
  });

  const expiration = new Date();
  expiration.setHours(expiration.getHours() + 1);
  const policyObj = {
    expiration: expiration.toISOString(),
    conditions: [
      ["content-length-range", 0, 1048576000],
      ["starts-with", "$key", ossConfig.objectKey.split("/")[0]],
    ],
  };
  const policy = btoa(JSON.stringify(policyObj));
  const signature = await hmacSha1(policy, ossConfig.accessKeySecret);

  const formData = new FormData();
  formData.append("key", ossConfig.objectKey);
  formData.append("OSSAccessKeyId", ossConfig.accessKeyId);
  formData.append("policy", policy);
  formData.append("signature", signature);
  formData.append("success_action_status", "200");
  if (ossConfig.securityToken) {
    formData.append("x-oss-security-token", ossConfig.securityToken);
  }
  formData.append("file", file);

  const host = `https://${ossConfig.bucket}.${ossConfig.region}.aliyuncs.com`;
  const uploadRes = await fetch(host, { method: "POST", body: formData });

  if (!uploadRes.ok) {
    const errorText = await uploadRes.text();
    throw new Error(`上传失败: ${uploadRes.status} ${errorText}`);
  }

  return {
    object_key: data.file.object_key,
    ossTokenFile: data.file,
  };
}
