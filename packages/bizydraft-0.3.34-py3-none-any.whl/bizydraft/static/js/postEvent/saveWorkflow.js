/**
 * getWorkflow 内部实现：保存工作流到 OSS 并调用 draft save API
 * 发送 workflowSaved 事件，不传输 workflow 数据
 */
import { app } from "../../../scripts/app.js";
import { saveWork } from "./saveWork.js";
import { workflowToOss } from "./workflowToOss.js";
import { draftFetch } from "../utils/draftFetch.js";

function emitWorkflowSaved(payload) {
  if (typeof window !== "undefined" && window.parent) {
    window.parent.postMessage({ type: "workflowSaved", ...payload }, "*");
  }
}

/**
 * 保存工作流到服务端
 * @param {Object} params - { workflowId, type? } type: 0=普通保存 2=运行前保存
 * @returns {Promise<void>}
 */
export async function saveWorkflowToServer(params) {
  const { workflowId, type = 0 } = params || {};
  if (!workflowId) {
    emitWorkflowSaved({ success: false, error: "workflowId 缺失" });
    return;
  }

  try {
    const graph = await app.graphToPrompt();
    let workflow = graph.workflow;
    if (workflow.workflow && typeof workflow.workflow === "object") {
      workflow = workflow.workflow;
    }

    delete workflow.extra;
    const node_num = workflow.nodes?.length || 0;

    const { checksum, workflowStr, md5Hash } = await saveWork(workflow);

    const cachedHash = sessionStorage.getItem("workflowHash");
    if (checksum === cachedHash) {
      emitWorkflowSaved({ success: true, checksum, silent: type === 2 });
      return;
    }

    sessionStorage.setItem("workflowHash", checksum);

    const { object_key } = await workflowToOss(workflowStr);

    const saveRes = await draftFetch(`/bizyair/draft/${workflowId}/save`, {
      method: "PUT",
      body: {
        content_key: object_key,
        node_num,
        checksum,
        type,
      },
    });

    if (saveRes?.code === 401) {
      emitWorkflowSaved({ success: false, error: "请先登录" });
      return;
    }

    emitWorkflowSaved({
      success: true,
      checksum,
      content_key: object_key,
      md5Hash: md5Hash || null,
      silent: type === 2,
    });
  } catch (error) {
    console.error("[saveWorkflowToServer]", error);
    emitWorkflowSaved({
      success: false,
      error: error?.message || "保存失败",
    });
  }
}
