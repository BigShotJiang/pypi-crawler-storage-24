"""Schema definitions and validation."""
