# Implement Job Steps

## Objective

Generate step instruction files for each step based on the `job.yml` specification from the define step.

## Task

Read the `job.yml` specification file created by the define step and generate comprehensive instruction files for each step. The define step has already created the job directory structure.

**Note**: Throughout this document, `<job_dir>` refers to the `job_dir` path returned in the workflow response when this workflow was started. It points to the directory containing this job's definition and templates.

### Step 1: Read and Validate the Specification

1. **Locate the job.yml file**
   - Read `.deepwork/jobs/[job_name]/job.yml` from the define step
   - Parse the YAML content

2. **Validate the specification**
   - Ensure it follows the schema (name, version, summary, common_job_info_provided_to_all_steps_at_runtime, steps)
   - Check that all dependencies reference existing steps
   - Verify no circular dependencies
   - Confirm file inputs match dependencies

3. **Extract key information**
   - Job name, version, summary, common_job_info_provided_to_all_steps_at_runtime
   - List of all steps with their details
   - Understand the workflow structure

### Step 2: Generate Step Instruction Files

For each step in the job.yml, create a comprehensive instruction file at `.deepwork/jobs/[job_name]/steps/[step_id].md`.

**Template reference**: See `<job_dir>/templates/step_instruction.md.template` for the standard structure.

**Complete example**: See `<job_dir>/templates/step_instruction.md.example` for a fully worked example.

**Available templates in `<job_dir>/templates/`** (replace `<job_dir>` with the `job_dir` path from the workflow response):
- `job.yml.template` - Job specification structure
- `step_instruction.md.template` - Step instruction file structure
- `agents.md.template` - AGENTS.md file structure
- `job.yml.example` - Complete job specification example
- `step_instruction.md.example` - Complete step instruction example

**Guidelines for generating instructions:**

1. **Use the common job info** - The `common_job_info_provided_to_all_steps_at_runtime` from job.yml provides crucial context
2. **Be specific** - Don't write generic instructions; tailor them to the step's purpose
3. **Provide output format examples** - Include a markdown code block in an "Output Format" section showing the expected file structure. A template with `[bracket placeholders]` is acceptable. For complex outputs, also include a concrete filled-in example showing realistic data — this is especially valuable for the first step in a workflow where there's no prior output to reference.
4. **Explain the "why"** - Help the user understand the step's role in the workflow
5. **Quality over quantity** - Detailed, actionable instructions are better than vague ones
6. **Align with reviews** - If the step has `reviews` defined, ensure the quality criteria in the instruction file match the review criteria
7. **Ask structured questions (when applicable)** - When a step has user-provided inputs (name/description inputs in job.yml), the instructions MUST explicitly tell the agent to "ask structured questions" using the AskUserQuestion tool. Steps that only have file inputs from prior steps do NOT need this phrase — they process data without user interaction.
8. **Handle edge cases** - If inputs might be missing, ambiguous, or incomplete, tell the agent to ask structured questions to clarify how to proceed rather than guessing

#### Handling Reviews

If a step in the job.yml has `reviews` defined, the generated instruction file should:

1. **Mirror the quality criteria** - The "Quality Criteria" section should match what the reviews will validate
2. **Be explicit about success** - Help the agent understand when the step is truly complete
3. **Explain what's reviewed** - If reviews target specific outputs (via `run_each`), mention which outputs will be reviewed

**Example: If the job.yml has:**
```yaml
- id: research_competitors
  name: "Research Competitors"
  reviews:
    - run_each: research_notes.md
      quality_criteria:
        "Sufficient Data": "Each competitor has at least 3 data points."
        "Sources Cited": "Sources are cited for key claims."
        "Current Information": "Information is current (within last year)."
```

**The instruction file should include:**
```markdown
## Quality Criteria

- Each competitor has at least 3 distinct data points
- All information is sourced with citations
- Data is current (from within the last year)
```

This alignment ensures the AI agent knows exactly what will be validated and can self-check before completing.

#### Writing Loop Instructions (go_to_step)

If a step in the job.yml is designed as a decision point that may loop back to an earlier step (see the "Iterative Loop Pattern" in the define step), the instruction file for that step must include clear guidance on when and how to use `go_to_step`.

**What to include in the instruction file:**

1. **Evaluation criteria** — Explicit conditions that determine whether to loop back or proceed
2. **Which step to go back to** — The specific `step_id` to pass to `go_to_step`, and why that step (not an earlier or later one)
3. **Maximum iterations** — A bound to prevent infinite loops (e.g., "After 3 iterations, proceed to the next step regardless and note remaining issues")
4. **How to call it** — Tell the agent to call the `go_to_step` MCP tool with the target `step_id`

**Example instruction snippet for a review/decision step:**

```markdown
## Evaluation

Review the draft against the acceptance criteria defined in the job description.

### If the draft needs more data:
Call `go_to_step` with `step_id: "gather_data"` to loop back and collect additional
information. This will clear progress from gather_data onward — you will re-execute
gather_data, write_draft, and this review step with the new data.

### If the draft needs revision but data is sufficient:
Call `go_to_step` with `step_id: "write_draft"` to revise the draft.

### If the draft meets all criteria:
Proceed normally by calling `finished_step` with the review output.

**Maximum iterations**: If this is the 3rd review cycle, proceed to the next step
regardless and document any remaining issues in the output.
```

**Important**: Only add `go_to_step` instructions to steps that are explicitly designed as loop decision points in the workflow. Most steps should NOT reference `go_to_step`.

#### Using Supplementary Reference Files

Step instructions can include additional `.md` files in the `steps/` directory for detailed examples, templates, or reference material. Reference them using the full path from the project root.

See `<job_dir>/steps/supplemental_file_references.md` for detailed documentation and examples.

### Step 3: Verify Files

Verify that all files are in their correct locations:
- `job.yml` at `.deepwork/jobs/[job_name]/job.yml` (created by define step)
- Step instruction files at `.deepwork/jobs/[job_name]/steps/[step_id].md`

## Example Implementation

For a complete worked example showing a job.yml and corresponding step instruction file, see:
- **Job specification**: `<job_dir>/templates/job.yml.example`
- **Step instruction**: `<job_dir>/templates/step_instruction.md.example`

## Completion Checklist

Before marking this step complete, ensure:
- [ ] job.yml validated and in job directory
- [ ] All step instruction files created
- [ ] Each instruction file uses the same structure (consistent with the template)
- [ ] Each instruction file has an Output Format section with examples
- [ ] Quality criteria in instruction files align with reviews defined in job.yml
- [ ] Steps with user-provided inputs include guidance to ask structured questions

## Note: Workflow Availability

Once the job.yml and step instruction files are created, the workflow is immediately available through the DeepWork MCP server. The MCP server reads job definitions directly from `.deepwork/jobs/` - no separate sync or installation step is required.