import os
import sys
import time
import shutil
import platform
import threading

IS_WINDOWS = platform.system() == "Windows"


def _w(s: str | bytes) -> None:
    if isinstance(s, str):
        s = s.encode()
    sys.stdout.buffer.write(s)
    sys.stdout.buffer.flush()


def ansi_set_scroll_region(top: int, bottom: int) -> None:
    _w(f"\x1b[{top};{bottom}r")


def ansi_clear_scroll_region() -> None:
    _w("\x1b[r")


def ansi_move(row: int, col: int = 1) -> None:
    _w(f"\x1b[{row};{col}H")


def ansi_erase_line() -> None:
    _w("\x1b[2K")


def ansi_clear_screen() -> None:
    _w("\x1b[2J")
    ansi_move(1, 1)


def terminal_size() -> tuple[int, int]:
    sz = shutil.get_terminal_size(fallback=(80, 24))
    return sz.columns, sz.lines


def enable_windows_vt() -> bool:
    if not IS_WINDOWS:
        return True
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        STD_OUTPUT_HANDLE = -11
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        ENABLE_PROCESSED_OUTPUT = 0x0001
        handle = kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
        old_mode = ctypes.c_ulong(0)
        kernel32.GetConsoleMode(handle, ctypes.byref(old_mode))
        new_mode = old_mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING | ENABLE_PROCESSED_OUTPUT
        ok = kernel32.SetConsoleMode(handle, new_mode)
        return bool(ok)
    except Exception as e:
        print(f"[warn] VT mode activation failed: {e}")
        return False


class LineModeTerminal:
    PROMPT = "> "

    def __init__(self, hex_mode: bool = False):
        self.hex_mode = hex_mode
        self._buf: list[str] = []
        self._cols, self._rows = terminal_size()
        self._input_row = self._rows
        self._scroll_top = 1
        self._scroll_bottom = self._rows - 1
        self._error_msg: str = ""

    def setup(self) -> None:
        if self._rows < 3:
            raise RuntimeError(f"Terminal too small (rows={self._rows}, min 3 required)")
        ansi_clear_screen()
        ansi_set_scroll_region(self._scroll_top, self._scroll_bottom)
        ansi_move(self._scroll_bottom, 1)
        self._draw_input()
        if not IS_WINDOWS:
            import signal
            signal.signal(signal.SIGWINCH, self._on_resize)

    def restore(self) -> None:
        ansi_clear_scroll_region()
        ansi_move(self._input_row, 1)
        ansi_erase_line()
        _w("\r\n")

    def write_output(self, data: bytes) -> None:
        if not data:
            return
        data = data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        if not IS_WINDOWS:
            data = data.replace(b"\n", b"\r\n")
        ansi_move(self._scroll_bottom, 1)
        _w(data)
        self._draw_input()

    def handle_key(self, ch: bytes) -> bytes | None:
        if ch in (b"\r", b"\n"):
            return self._commit()
        if ch in (b"\x7f", b"\x08"):
            return self._backspace()
        if ch == b"\x15":
            self._buf.clear()
            self._error_msg = ""
            self._draw_input()
            return None
        if len(ch) == 1 and 0x20 <= ch[0] <= 0x7E:
            self._buf.append(ch.decode("ascii"))
            self._error_msg = ""
            self._draw_input()
        return None

    def _draw_input(self) -> None:
        ansi_move(self._input_row, 1)
        ansi_erase_line()
        mode_tag = "[hex] " if self.hex_mode else ""
        err = f"  \x1b[31m{self._error_msg}\x1b[0m" if self._error_msg else ""
        content = "".join(self._buf)
        _w(f"{self.PROMPT}{mode_tag}{content}{err}")

    def _backspace(self) -> None:
        if self._buf:
            self._buf.pop()
        self._error_msg = ""
        self._draw_input()
        return None

    def _commit(self) -> bytes | None:
        raw = "".join(self._buf).strip()
        self._buf.clear()
        if not raw:
            self._draw_input()
            return None
        if self.hex_mode:
            payload, err = self._parse_hex(raw)
            if err:
                self._error_msg = err
                self._draw_input()
                return None
        else:
            payload = raw.encode("utf-8")
        self._error_msg = ""
        self._draw_input()
        return payload + b"\r"

    @staticmethod
    def _parse_hex(s: str) -> tuple[bytes | None, str | None]:
        s = s.replace(" ", "").replace("_", "")
        valid = set("0123456789abcdefABCDEF")
        for ch in s:
            if ch not in valid:
                return None, f"invalid hex char: {ch!r}"
        if len(s) % 2:
            return None, f"odd length: {s!r}"
        try:
            return bytes.fromhex(s), None
        except ValueError as e:
            return None, f"conversion error: {e}"

    def _on_resize(self, signum, frame) -> None:
        self._cols, self._rows = terminal_size()
        self._input_row = self._rows
        self._scroll_bottom = self._rows - 1
        ansi_set_scroll_region(self._scroll_top, self._scroll_bottom)
        self._draw_input()


class RawTerminal:
    def __enter__(self):
        if IS_WINDOWS:
            enable_windows_vt()
        else:
            import tty, termios
            self._fd = sys.stdin.fileno()
            self._old = termios.tcgetattr(self._fd)
            tty.setraw(self._fd)
        return self

    def __exit__(self, *_):
        if not IS_WINDOWS:
            import termios
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old)

    @staticmethod
    def read_key() -> bytes | None:
        if IS_WINDOWS:
            import msvcrt
            if not msvcrt.kbhit():
                return None
            w = msvcrt.getwch()
            if w in ("\x00", "\xe0"):
                msvcrt.getwch()
                return b""
            return w.encode("utf-8", errors="replace")
        else:
            import select
            r, _, _ = select.select([sys.stdin], [], [], 0)
            if not r:
                return None
            return os.read(sys.stdin.fileno(), 1)


def scenario_1():
    print("\n[Scenario 1] Output scroll - input line must stay fixed at the bottom")
    print("  Printing 30 lines at 0.15s intervals. Press any key when done.")
    time.sleep(1.5)

    term = LineModeTerminal()
    with RawTerminal():
        term.setup()
        try:
            for i in range(1, 31):
                term.write_output(f"[output {i:02d}] Hello from board! data={i*100:#06x}\n".encode())
                time.sleep(0.15)
            term.write_output("\n--- Output complete. Press any key to exit ---\n".encode())
            while True:
                ch = RawTerminal.read_key()
                if ch is not None:
                    break
                time.sleep(0.01)
        finally:
            term.restore()

    print("\n[Scenario 1] Done. Did the input line stay at the bottom? (y/n) ", end="", flush=True)
    return input().strip().lower() == "y"


def scenario_2():
    print("\n[Scenario 2] Simultaneous output + input - output must not overwrite the input line")
    print("  Output streams for 8s. Type text and press Enter to send.")
    print("  Press Ctrl+C to stop early.")
    time.sleep(1.5)

    term = LineModeTerminal()
    sent_lines: list[str] = []
    stop_output = threading.Event()

    def output_thread():
        count = 0
        while not stop_output.is_set():
            count += 1
            term.write_output(f"[stream {count:03d}] board output line\n".encode())
            time.sleep(0.3)

    with RawTerminal():
        term.setup()
        t = threading.Thread(target=output_thread, daemon=True)
        t.start()
        try:
            deadline = time.time() + 8.0
            while time.time() < deadline:
                ch = RawTerminal.read_key()
                if ch is None:
                    time.sleep(0.005)
                    continue
                if ch == b"\x03":
                    break
                result = term.handle_key(ch)
                if result is not None:
                    sent_lines.append(repr(result))
                    term.write_output(f"[sent] {repr(result)}\n".encode())
        finally:
            stop_output.set()
            term.restore()

    print(f"\n[Scenario 2] Done. Sent lines: {sent_lines}")
    print("Did output avoid overwriting the input line? (y/n) ", end="", flush=True)
    return input().strip().lower() == "y"


def scenario_3():
    print("\n[Scenario 3] Enter payload validation (automated, no terminal needed)")

    ok = True

    def feed(term, chars):
        for c in chars:
            if isinstance(c, str):
                c = c.encode()
            r = term.handle_key(c)
            if r is not None:
                return r
        return None

    cases = [
        (LineModeTerminal(hex_mode=False), ["h","e","l","l","o", b"\r"],        b"hello\r",              "text hello"),
        (LineModeTerminal(hex_mode=False), [b"\r"],                              None,                   "text empty Enter"),
        (LineModeTerminal(hex_mode=False), ["a","b","c", b"\x7f", b"\r"],        b"ab\r",                "text abc + BS"),
        (LineModeTerminal(hex_mode=True),  list("0102ff") + [b"\r"],             b"\x01\x02\xff\r",      "hex 0102ff"),
        (LineModeTerminal(hex_mode=True),  list("01 02") + [b"\r"],              b"\x01\x02\r",          "hex 01 02 (space)"),
    ]

    for t, chars, expected, desc in cases:
        result = feed(t, chars)
        status = "OK" if result == expected else "FAIL"
        if status == "FAIL":
            ok = False
        print(f"  {desc:<28} -> {repr(result):<22} [{status}]  (expected: {repr(expected)})")

    print(f"\n[Scenario 3] {'All passed' if ok else 'Some failed'}")
    return ok


def scenario_4():
    print("\n[Scenario 4] Hex error handling (automated)")

    ok = True

    def feed_and_check(desc, chars, expect_none=True, expect_error_contains=""):
        t = LineModeTerminal(hex_mode=True)
        result = None
        for c in chars:
            if isinstance(c, str):
                c = c.encode()
            r = t.handle_key(c)
            if r is not None:
                result = r
        payload_ok = (result is None) if expect_none else (result is not None)
        error_ok = (expect_error_contains in t._error_msg) if expect_error_contains else True
        status = "OK" if (payload_ok and error_ok) else "FAIL"
        nonlocal ok
        if status == "FAIL":
            ok = False
        print(f"  {desc:<30} result={repr(result):<8} error={repr(t._error_msg):<40} [{status}]")

    feed_and_check("odd length 010",         list("010") + [b"\r"],     expect_none=True, expect_error_contains="odd")
    feed_and_check("invalid hex xyz",        list("xyz") + [b"\r"],     expect_none=True, expect_error_contains="invalid")
    feed_and_check("odd+valid 0102bad",      list("0102bad") + [b"\r"], expect_none=True, expect_error_contains="odd")
    feed_and_check("invalid hex xyzw",       list("xyzw") + [b"\r"],    expect_none=True, expect_error_contains="invalid")
    feed_and_check("valid 0304",             list("0304") + [b"\r"],    expect_none=False)

    print(f"\n[Scenario 4] {'All passed' if ok else 'Some failed'}")
    return ok


def scenario_5():
    if IS_WINDOWS:
        print("\n[Scenario 5] SIGWINCH not available on Windows - SKIP")
        return True

    print("\n[Scenario 5] Terminal resize - resize the window during the 5s window")
    print("  Input line must reposition to the new last row after resize.")
    time.sleep(1.5)

    term = LineModeTerminal()
    with RawTerminal():
        term.setup()
        try:
            deadline = time.time() + 5.0
            count = 0
            while time.time() < deadline:
                ch = RawTerminal.read_key()
                if ch == b"\x03":
                    break
                count += 1
                if count % 20 == 0:
                    cols, rows = terminal_size()
                    term.write_output(f"[size] {cols}x{rows}\n".encode())
                time.sleep(0.05)
        finally:
            term.restore()

    print("\n[Scenario 5] Done. Did the input line reposition correctly after resize? (y/n) ", end="", flush=True)
    return input().strip().lower() == "y"


def scenario_6():
    print("\n[Scenario 6] VT mode / ANSI escape support check")

    if IS_WINDOWS:
        ok = enable_windows_vt()
        print(f"  ENABLE_VIRTUAL_TERMINAL_PROCESSING: {'OK' if ok else 'FAILED'}")
    else:
        ok = True
        print("  Unix - VT mode not required, SKIP")

    _w("\x1b[32m  [green text - ANSI is working]\x1b[0m\n")
    _w("  \x1b[1mbold text\x1b[0m  \x1b[4munderline text\x1b[0m\n")

    print("\n[Scenario 6] Are the ANSI escape codes rendered as formatting (not raw text)? (y/n) ", end="", flush=True)
    visual_ok = input().strip().lower() == "y"
    return ok and visual_ok


SCENARIOS = {
    "1": ("Output scroll",          scenario_1),
    "2": ("Output + input echo",    scenario_2),
    "3": ("Enter payload check",    scenario_3),
    "4": ("Hex error handling",     scenario_4),
    "5": ("SIGWINCH resize",        scenario_5),
    "6": ("Windows VT mode",        scenario_6),
}

if __name__ == "__main__":
    sel = sys.argv[1] if len(sys.argv) > 1 else None

    if sel and sel in SCENARIOS:
        name, fn = SCENARIOS[sel]
        print(f"\n{'='*60}")
        print(f"  Scenario {sel}: {name}")
        print(f"{'='*60}")
        result = fn()
        print(f"\nResult: {'PASS' if result else 'FAIL'}")
    else:
        results = {}
        for k, (name, fn) in SCENARIOS.items():
            print(f"\n{'='*60}")
            print(f"  Scenario {k}: {name}")
            print(f"{'='*60}")
            try:
                results[k] = fn()
            except KeyboardInterrupt:
                print("\n[interrupted]")
                results[k] = False

        print(f"\n{'='*60}")
        print("  Final results")
        print(f"{'='*60}")
        for k, (name, _) in SCENARIOS.items():
            r = results.get(k)
            mark = "PASS" if r else ("FAIL" if r is False else "SKIP")
            print(f"  {k}. {name:<25} {mark}")
