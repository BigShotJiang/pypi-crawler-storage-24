import asyncio, struct, machine, micropython
from termio import ReplSerial
from termio_async import AsyncReplSerial

# 프로토콜: [CMD:1B][VALUE:2B][CRC:1B] = 4바이트
PKTSIZE      = 4
CMD_ON_MS    = 0x01   # VALUE = LED 켜짐 구간 ms  (예: 0x0064 → 100 ms)
CMD_INTERVAL = 0x02   # VALUE = 깜빡임 전체 주기 ms (예: 0x07D0 → 2000 ms)

led      = machine.Pin("LED", machine.Pin.OUT)
on_ms    = 100    # 초기 켜짐 구간 ms
interval = 1000   # 초기 깜빡임 주기 ms

async def ctrl_task(aser):
    global on_ms, interval
    buf = bytearray()
    while True:
        chunk = await aser.read(PKTSIZE - len(buf), timeout_ms=500)
        buf.extend(chunk)
        if len(buf) >= PKTSIZE:
            cmd, value, crc = struct.unpack(">BHB", buf)
            expected = (cmd + (value >> 8) + (value & 0xFF)) & 0xFF
            if crc == expected:
                if cmd == CMD_ON_MS:
                    on_ms = max(50, min(value, interval - 50))
                    aser.write(f"OK on_ms={on_ms}ms\r\n".encode())
                elif cmd == CMD_INTERVAL:
                    interval = max(100, value)
                    aser.write(f"OK interval={interval}ms\r\n".encode())
                else:
                    aser.write(b"ERR unknown\r\n")
            else:
                aser.write(b"ERR crc\r\n")
            buf = bytearray()  # MicroPython: .clear()·del buf[:] 미지원 → 재할당

async def blink_task():
    # 시리얼 출력 없음 — ctrl_task read() 대기 중에 LED만 제어
    while True:
        led.on()
        await asyncio.sleep_ms(on_ms)
        led.off()
        await asyncio.sleep_ms(interval - on_ms)

async def main():
    micropython.kbd_intr(-1)   # 수신 데이터의 0x03 바이트가 Ctrl+C로 해석되지 않도록
    try:
        with ReplSerial(timeout=0) as ser:
            aser = AsyncReplSerial(ser)
            await asyncio.gather(ctrl_task(aser), blink_task())
    finally:
        micropython.kbd_intr(3)    # 복원

asyncio.run(main())