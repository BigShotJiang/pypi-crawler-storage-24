from enum import StrEnum


class ModelEnum(StrEnum):
    UNKNOWN = "Unknown"
    HUMIDIFIER_H35I = "Blueair Humidifier H35i"
    HUMIDIFIER_H38I = "Blueair DreamWell Humidifier H38i"
    HUMIDIFIER_H76I = "Blueair DreamWell Humidifier H76i"
    PROTECT_7440I = "Blueair Protect 7440i"
    PROTECT_7470I = "Blueair Protect 7470i"
    PROTECT_7770I = "Blueair Protect 7770i"
    MAX_211I = "Blueair Blue Pure 211i Max"
    MAX_311I = "Blueair Blue Pure 311i Max"
    MAX_311I_PLUS = "Blueair Blue Pure 311i+ Max"
    MAX_3250I = "Blueair Blue Pure 3250i Max"
    MAX_3650I = "Blueair Blue Pure 3650i Max"
    MAX_411I = "Blueair Blue Pure 411i Max"
    MAX_511I = "Blueair Blue Pure 511i Max"
    T10I = "T10i ComfortPure 3-in-1 Filter/Heater/Fan"
    TWO_IN_ONE = "2-in-1 Pro Purify + Humidify"
    MINI_RESTFUL = "Blueair Mini Restful"
    BLUE_SIGNATURE = "Blue Signature"
    PET_AIR_PRO = "PetAir Pro"
