"""Tests for dh hz users SSM management."""

from unittest.mock import MagicMock, patch

import pytest
from click.exceptions import Exit

from dh_cli.hz.users import _format_csv, _parse_csv, compute_user_tiers


class TestParseCSV:
    def test_parses_comma_separated(self):
        assert _parse_csv("alice@x.com,bob@y.com") == {"alice@x.com", "bob@y.com"}

    def test_strips_whitespace(self):
        assert _parse_csv(" alice@x.com , bob@y.com ") == {"alice@x.com", "bob@y.com"}

    def test_lowercases(self):
        assert _parse_csv("Alice@X.COM") == {"alice@x.com"}

    def test_empty_string(self):
        assert _parse_csv("") == set()

    def test_trailing_comma(self):
        assert _parse_csv("alice@x.com,") == {"alice@x.com"}

    def test_deduplicates(self):
        assert _parse_csv("a@x.com,a@x.com") == {"a@x.com"}


class TestFormatCSV:
    def test_sorts_alphabetically(self):
        assert _format_csv({"bob@y.com", "alice@x.com"}) == "alice@x.com,bob@y.com"

    def test_empty_set(self):
        assert _format_csv(set()) == ""

    def test_single_email(self):
        assert _format_csv({"alice@x.com"}) == "alice@x.com"


class TestAddUser:
    def _make_ssm(self, params: dict[str, str]):
        """Create a mock SSM client with given param values."""
        ssm = MagicMock()

        not_found = type("ParameterNotFound", (Exception,), {})
        ssm.exceptions.ParameterNotFound = not_found

        def get_parameter(Name):
            if Name in params:
                return {"Parameter": {"Value": params[Name]}}
            raise not_found()

        ssm.get_parameter.side_effect = get_parameter

        def put_parameter(Name, Value, Type, Overwrite):
            params[Name] = Value

        ssm.put_parameter.side_effect = put_parameter
        return ssm

    def test_add_beta_user(self):
        params = {"/horizyn/prod/auth/allowed_emails": "existing@x.com"}
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import add_user

            # Invoke the typer command's underlying logic
            ctx = MagicMock()
            add_user("new@y.com", env="prod", tier="beta")

        assert "new@y.com" in params["/horizyn/prod/auth/allowed_emails"]
        assert "existing@x.com" in params["/horizyn/prod/auth/allowed_emails"]

    def test_add_alpha_user(self):
        params = {
            "/horizyn/prod/auth/allowed_emails": "existing@x.com",
            "/horizyn/prod/auth/alpha_emails": "",
        }
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import add_user

            add_user("new@y.com", env="prod", tier="alpha")

        assert "new@y.com" in params["/horizyn/prod/auth/allowed_emails"]
        assert "new@y.com" in params["/horizyn/prod/auth/alpha_emails"]

    def test_add_existing_user_is_idempotent(self):
        params = {"/horizyn/prod/auth/allowed_emails": "existing@x.com"}
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import add_user

            add_user("existing@x.com", env="prod", tier="beta")

        ssm.put_parameter.assert_not_called()


class TestRemoveUser:
    def _make_ssm(self, params: dict[str, str]):
        ssm = MagicMock()

        not_found = type("ParameterNotFound", (Exception,), {})
        ssm.exceptions.ParameterNotFound = not_found

        def get_parameter(Name):
            if Name in params:
                return {"Parameter": {"Value": params[Name]}}
            raise not_found()

        ssm.get_parameter.side_effect = get_parameter

        def put_parameter(Name, Value, Type, Overwrite):
            params[Name] = Value

        ssm.put_parameter.side_effect = put_parameter
        return ssm

    def test_remove_from_all_lists(self):
        params = {
            "/horizyn/prod/auth/allowed_emails": "alice@x.com,bob@y.com",
            "/horizyn/prod/auth/admin_emails": "alice@x.com",
            "/horizyn/prod/auth/alpha_emails": "alice@x.com",
        }
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import remove_user

            remove_user("alice@x.com", env="prod")

        assert "alice@x.com" not in params["/horizyn/prod/auth/allowed_emails"]
        assert "bob@y.com" in params["/horizyn/prod/auth/allowed_emails"]
        assert "alice@x.com" not in params["/horizyn/prod/auth/admin_emails"]
        assert "alice@x.com" not in params["/horizyn/prod/auth/alpha_emails"]

    def test_remove_nonexistent_user_is_noop(self):
        params = {
            "/horizyn/prod/auth/allowed_emails": "bob@y.com",
            "/horizyn/prod/auth/admin_emails": "",
            "/horizyn/prod/auth/alpha_emails": "",
        }
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import remove_user

            remove_user("ghost@z.com", env="prod")

        ssm.put_parameter.assert_not_called()


class TestPromoteUser:
    def _make_ssm(self, params: dict[str, str]):
        ssm = MagicMock()

        not_found = type("ParameterNotFound", (Exception,), {})
        ssm.exceptions.ParameterNotFound = not_found

        def get_parameter(Name):
            if Name in params:
                return {"Parameter": {"Value": params[Name]}}
            raise not_found()

        ssm.get_parameter.side_effect = get_parameter

        def put_parameter(Name, Value, Type, Overwrite):
            params[Name] = Value

        ssm.put_parameter.side_effect = put_parameter
        return ssm

    def test_promote_to_alpha(self):
        params = {
            "/horizyn/prod/auth/allowed_emails": "alice@x.com",
            "/horizyn/prod/auth/alpha_emails": "",
        }
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import promote_user

            promote_user("alice@x.com", tier="alpha", env="prod")

        assert "alice@x.com" in params["/horizyn/prod/auth/alpha_emails"]

    def test_promote_nonexistent_user_exits(self):
        params = {
            "/horizyn/prod/auth/allowed_emails": "bob@y.com",
        }
        ssm = self._make_ssm(params)

        with patch("dh_cli.hz.users._ssm_client", return_value=ssm):
            from dh_cli.hz.users import promote_user

            with pytest.raises(Exit):
                promote_user("ghost@z.com", tier="alpha", env="prod")

    def test_promote_invalid_tier_exits(self):
        with pytest.raises(Exit):
            from dh_cli.hz.users import promote_user

            promote_user("alice@x.com", tier="superadmin", env="prod")


class TestComputeUserTiers:
    def test_beta_is_allowed_minus_alpha_minus_admin(self):
        beta, alpha_only, orphaned = compute_user_tiers(
            allowed_emails={"a@x.com", "b@x.com", "c@x.com"},
            alpha_emails={"b@x.com"},
            admin_emails=set(),
        )
        assert beta == {"a@x.com", "c@x.com"}
        assert alpha_only == {"b@x.com"}
        assert orphaned == set()

    def test_admin_emails_excluded_from_alpha_and_beta(self):
        beta, alpha_only, orphaned = compute_user_tiers(
            allowed_emails={"a@x.com", "b@x.com", "c@x.com"},
            alpha_emails={"b@x.com", "c@x.com"},
            admin_emails={"c@x.com"},
        )
        assert beta == {"a@x.com"}
        assert alpha_only == {"b@x.com"}
        assert orphaned == set()

    def test_orphaned_alpha_not_in_allowed(self):
        beta, alpha_only, orphaned = compute_user_tiers(
            allowed_emails={"a@x.com"},
            alpha_emails={"ghost@x.com"},
            admin_emails=set(),
        )
        assert beta == {"a@x.com"}
        assert alpha_only == set()
        assert orphaned == {"ghost@x.com"}

    def test_orphaned_admin_not_in_allowed(self):
        beta, alpha_only, orphaned = compute_user_tiers(
            allowed_emails={"a@x.com"},
            alpha_emails=set(),
            admin_emails={"ghost@x.com"},
        )
        assert beta == {"a@x.com"}
        assert orphaned == {"ghost@x.com"}

    def test_all_empty(self):
        beta, alpha_only, orphaned = compute_user_tiers(set(), set(), set())
        assert beta == set()
        assert alpha_only == set()
        assert orphaned == set()
