"""ORCA quantum chemistry batch pipeline command.

Unlike Boltz/ProtMPNN, ORCA jobs are typically one-per-submission (each
calculation runs for hours). Multiple .inp files are submitted as separate
Batch jobs, not as an array job.
"""

import os
import shutil
from pathlib import Path

import click

from ..aws_batch import BatchClient, BatchError, resolve_dependency
from ..job_id import generate_job_id, get_aws_username
from ..manifest import (
    BATCH_JOBS_BASE,
    BatchConfig,
    InputConfig,
    JobManifest,
    JobStatus,
    OutputConfig,
    create_job_directory,
    save_manifest,
    save_manifest_s3,
    save_local_stub,
)
from ..s3_transport import s3_job_prefix, upload_directory

DEFAULT_QUEUE = "cpu-ondemand"
DEFAULT_JOB_DEFINITION = "dayhoff-orca"
DEFAULT_IMAGE_URI = (
    "074735440724.dkr.ecr.us-east-1.amazonaws.com/dayhoff:orca-latest"
)
DEFAULT_VCPUS = 16
DEFAULT_MEMORY_MB = 64000
DEFAULT_TIMEOUT_H = 24

S3_MAX_FILES = 100


def _is_primordial_path(path: Path) -> bool:
    return str(path).startswith("/primordial/")


def _find_inp_files(input_path: Path) -> list[Path]:
    """Find .inp files — either a single file or all files in a directory."""
    if input_path.is_file() and input_path.suffix == ".inp":
        return [input_path]
    if input_path.is_dir():
        return sorted(input_path.glob("*.inp"))
    return []


@click.command()
@click.argument("input_path", type=click.Path(exists=True))
@click.option(
    "--queue", default=DEFAULT_QUEUE,
    help=f"Batch queue [default: {DEFAULT_QUEUE}]",
)
@click.option(
    "--vcpus", default=DEFAULT_VCPUS, type=int,
    help=f"vCPUs per job [default: {DEFAULT_VCPUS}]",
)
@click.option(
    "--memory", default=DEFAULT_MEMORY_MB, type=int,
    help=f"Memory in MB per job [default: {DEFAULT_MEMORY_MB}]",
)
@click.option(
    "--timeout", "timeout_h", default=DEFAULT_TIMEOUT_H, type=float,
    help=f"Timeout in hours per job [default: {DEFAULT_TIMEOUT_H}]",
)
@click.option(
    "--local", "run_local", is_flag=True,
    help="Run ORCA locally in a Docker container instead of Batch",
)
@click.option(
    "--shell", "run_shell", is_flag=True,
    help="Drop into container shell for debugging",
)
@click.option("--dry-run", is_flag=True, help="Show plan without submitting")
@click.option("--base-path", default=BATCH_JOBS_BASE, help="Base path for job data")
@click.option(
    "--after", multiple=True,
    help="Job ID(s) to wait for before starting",
)
def orca(input_path, queue, vcpus, memory, timeout_h, run_local, run_shell,
         dry_run, base_path, after):
    """Run ORCA DFT calculations on AWS Batch.

    INPUT_PATH can be a single .inp file or a directory of .inp files.
    Each .inp file is submitted as a separate Batch job (ORCA calculations
    are long-running, so array jobs are not used).

    \b
    Examples:
      # Submit a single calculation
      dh batch orca /primordial/calculations/ts_opt.inp

      # Submit all .inp files in a directory
      dh batch orca /primordial/calculations/

      # Use more CPUs for a heavy job
      dh batch orca ts_opt.inp --vcpus 32 --memory 128000

      # Test locally in container
      dh batch orca ts_opt.inp --local

    \b
    After job completes:
      dh batch status <job-id>
      dh batch logs <job-id>
      dh batch finalize <job-id> --output /primordial/results/
    """
    path = Path(input_path).resolve()

    if run_shell:
        _run_shell_mode(path)
        return

    if run_local:
        _run_local_mode(path, vcpus)
        return

    _submit_batch_jobs(path, queue, vcpus, memory, timeout_h, dry_run,
                       base_path, after)


def _submit_batch_jobs(
    input_path: Path,
    queue: str,
    vcpus: int,
    memory: int,
    timeout_h: float,
    dry_run: bool,
    base_path: str,
    after: tuple[str, ...] = (),
):
    """Submit ORCA job(s) to AWS Batch."""
    inp_files = _find_inp_files(input_path)

    if not inp_files:
        click.echo(
            click.style("Error: No .inp files found", fg="red"), err=True,
        )
        raise SystemExit(1)

    click.echo(f"Found {len(inp_files)} ORCA input file(s)")

    use_s3 = not _is_primordial_path(input_path)
    if use_s3 and len(inp_files) > S3_MAX_FILES:
        click.echo(f"Error: {len(inp_files)} files exceeds S3 limit ({S3_MAX_FILES}).")
        click.echo("Copy inputs to /primordial/ for large jobs.")
        raise SystemExit(1)

    timeout_s = int(timeout_h * 3600)

    for inp_file in inp_files:
        job_id = generate_job_id("orca")

        click.echo()
        click.echo(f"Job ID:          {job_id}")
        click.echo(f"Input:           {inp_file.name}")
        click.echo(f"Queue:           {queue}")
        click.echo(f"vCPUs:           {vcpus}")
        click.echo(f"Memory:          {memory} MB")
        click.echo(f"Timeout:         {timeout_h}h")
        click.echo(f"Job definition:  {DEFAULT_JOB_DEFINITION}")
        click.echo(f"Storage:         {'S3' if use_s3 else 'Primordial'}")

        if dry_run:
            click.echo(click.style("  Dry run — not submitted", fg="yellow"))
            continue

        if len(inp_files) == 1 and not click.confirm("\nSubmit job?", default=True):
            click.echo("Cancelled.")
            raise SystemExit(0)

        s3_prefix = s3_job_prefix(job_id) if use_s3 else None
        job_dir_path = Path(base_path) / job_id

        if use_s3:
            click.echo("Uploading input to S3...")
            upload_directory(inp_file.parent, f"{s3_prefix}input/", glob=inp_file.name)
        else:
            job_dir_path = create_job_directory(job_id, base_path)
            inp_dest = job_dir_path / "input"
            inp_dest.mkdir(parents=True, exist_ok=True)
            shutil.copy2(inp_file, inp_dest / inp_file.name)
            click.echo(f"Copied {inp_file.name} to {inp_dest}")

        manifest = JobManifest(
            job_id=job_id,
            user=job_id.split("-")[0],
            pipeline="orca",
            status=JobStatus.PENDING,
            image_uri=DEFAULT_IMAGE_URI,
            storage_mode="s3" if use_s3 else "primordial",
            s3_prefix=s3_prefix,
            input=InputConfig(
                source=str(inp_file),
                num_sequences=1,
                num_chunks=1,
            ),
            batch=BatchConfig(
                queue=queue,
                job_definition=DEFAULT_JOB_DEFINITION,
                array_size=None,  # Single job, not array
            ),
            output=OutputConfig(destination=None, finalized=False),
            depends_on=list(after) if after else None,
        )

        if use_s3:
            save_manifest_s3(manifest)
            save_local_stub(job_id, s3_prefix)
        else:
            save_manifest(manifest, base_path)

        try:
            resolved = [resolve_dependency(jid, base_path) for jid in after]
            depends_on = (
                [{"jobId": aws_id} for aws_id in resolved if aws_id is not None]
                or None
            )

            client = BatchClient()
            environment = {
                "JOB_DIR": str(job_dir_path),
                "JOB_ID": job_id,
                "BATCH_ARRAY_SIZE": "1",
                "BATCH_NUM_FILES": "1",
            }
            if use_s3:
                environment["STORAGE_MODE"] = "s3"
                environment["S3_JOB_PREFIX"] = s3_prefix

            batch_job_id = client.submit_job(
                job_name=job_id,
                job_definition=DEFAULT_JOB_DEFINITION,
                job_queue=queue,
                array_size=None,  # Single job
                environment=environment,
                timeout_seconds=timeout_s,
                retry_attempts=2,
                depends_on=depends_on,
                share_identifier=get_aws_username(),
                vcpus=vcpus,
                memory_mb=memory,
            )

            manifest.status = JobStatus.SUBMITTED
            manifest.batch.job_id = batch_job_id
            if use_s3:
                save_manifest_s3(manifest)
            else:
                save_manifest(manifest, base_path)

            click.echo()
            click.echo(click.style("Job submitted!", fg="green"))
            click.echo(f"  AWS Job ID:  {batch_job_id}")
            click.echo(f"  Status:      dh batch status {job_id}")
            click.echo(f"  Logs:        dh batch logs {job_id}")

        except BatchError as e:
            manifest.status = JobStatus.FAILED
            manifest.error_message = str(e)
            if use_s3:
                save_manifest_s3(manifest)
            else:
                save_manifest(manifest, base_path)
            click.echo(
                click.style(f"Failed to submit: {e}", fg="red"), err=True,
            )
            raise SystemExit(1)

    if dry_run:
        click.echo()
        click.echo(click.style("Dry run complete — no jobs submitted", fg="yellow"))


def _run_local_mode(input_path: Path, vcpus: int = DEFAULT_VCPUS):
    """Run ORCA locally in a Docker container."""
    import subprocess

    inp_files = _find_inp_files(input_path)
    if not inp_files:
        click.echo(click.style("Error: No .inp files found", fg="red"), err=True)
        raise SystemExit(1)

    inp_file = inp_files[0]
    click.echo(f"Running ORCA locally: {inp_file.name}")

    work_dir = inp_file.parent
    job_dir = work_dir / ".local_orca_job"
    inp_dir = job_dir / "input"
    if job_dir.exists():
        shutil.rmtree(job_dir)
    inp_dir.mkdir(parents=True)
    (job_dir / "output").mkdir()
    shutil.copy2(inp_file, inp_dir / inp_file.name)

    cmd = [
        "docker", "run", "--rm",
        "-v", "/primordial:/primordial:ro",
        "-v", f"{job_dir}:{job_dir}",
        "-e", f"JOB_DIR={job_dir}",
        "-e", "AWS_BATCH_JOB_ARRAY_INDEX=0",
        "-e", "BATCH_ARRAY_SIZE=1",
        "-e", "BATCH_NUM_FILES=1",
        DEFAULT_IMAGE_URI,
    ]

    click.echo(f"Output: {job_dir / 'output'}")
    click.echo()

    result = subprocess.run(cmd)
    if result.returncode != 0:
        click.echo(
            click.style(f"Container exited with code {result.returncode}", fg="red"),
            err=True,
        )
        raise SystemExit(result.returncode)

    output_dir = job_dir / "output"
    outputs = list(output_dir.rglob("*.out"))
    if outputs:
        click.echo()
        click.echo(click.style("ORCA completed!", fg="green"))
        for f in outputs:
            click.echo(f"  {f}")
    else:
        click.echo(click.style("Warning: No .out files found", fg="yellow"))


def _run_shell_mode(input_path: Path):
    """Drop into container shell for debugging."""
    import subprocess

    click.echo("Dropping into ORCA container shell...")

    mount_path = input_path if input_path.is_dir() else input_path.parent
    cmd = [
        "docker", "run", "--rm", "-it",
        "-v", "/primordial:/primordial:ro",
        "-v", f"{mount_path}:/work",
        "--entrypoint", "/bin/bash",
        DEFAULT_IMAGE_URI,
    ]

    click.echo(f"Input available at: /work/")
    subprocess.run(cmd)
