"""Run integration test suites."""

import os
import re
from pathlib import Path
from typing import Optional

import typer

from dh_cli.hz import require_repo, run_script

test_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})


def _discover_suites(test_dir: Path) -> list[tuple[int, str, Path]]:
    """Return sorted list of (number, name, path) for numbered test scripts."""
    suites = []
    for f in test_dir.glob("*.sh"):
        m = re.match(r"^(\d+)_(.+)\.sh$", f.name)
        if m:
            suites.append((int(m.group(1)), m.group(2), f))
    return sorted(suites, key=lambda t: t[0])


def _resolve_suites(
    available: list[tuple[int, str, Path]], selectors: list[str]
) -> list[tuple[int, str, Path]]:
    """Match selectors (numbers or name substrings) to available suites."""
    matched = []
    for sel in selectors:
        sel = sel.strip()
        found = False
        if sel.isdigit():
            num = int(sel)
            for suite in available:
                if suite[0] == num:
                    matched.append(suite)
                    found = True
                    break
        if not found:
            for suite in available:
                if sel.lower() in suite[1].lower():
                    matched.append(suite)
                    found = True
                    break
        if not found:
            typer.echo(f"No suite matching '{sel}'.", err=True)
            raise typer.Exit(1)
    return matched


def _ensure_jwt_token(env: str, test_dir: Path) -> None:
    """Ensure HORIZYN_TOKEN is set, prompting interactively if needed.

    Checks (in order): env var with expiry validation, cached token file,
    then falls back to interactive Cognito passwordless auth.
    Sets os.environ["HORIZYN_TOKEN"] so child processes inherit it.
    """
    import json
    import subprocess
    import time

    token_script = test_dir / "get_jwt_token.py"
    cache_dir = Path.home() / ".horizyn"
    cache_file = cache_dir / f"token_{env}"

    def _token_valid(token: str) -> bool:
        """Check JWT expiry without verification (5-minute buffer)."""
        import base64

        try:
            payload = token.split(".")[1]
            padding = 4 - len(payload) % 4
            if padding != 4:
                payload += "=" * padding
            decoded = json.loads(base64.urlsafe_b64decode(payload))
            return time.time() < (decoded.get("exp", 0) - 300)
        except Exception:
            return False

    # 1. Check existing env var
    existing = os.environ.get("HORIZYN_TOKEN", "")
    if existing and _token_valid(existing):
        typer.secho("  Using existing HORIZYN_TOKEN", fg=typer.colors.GREEN)
        return

    # 2. Check cached token file
    if cache_file.exists():
        cached = cache_file.read_text().strip()
        if cached and _token_valid(cached):
            os.environ["HORIZYN_TOKEN"] = cached
            typer.secho(f"  Using cached token from {cache_file}", fg=typer.colors.GREEN)
            return
        cache_file.unlink(missing_ok=True)

    # 3. Interactive: run get_jwt_token.py (prompts go to stderr, token to stdout)
    typer.echo()
    typer.secho("  No valid token found — starting authentication.", fg=typer.colors.YELLOW)
    typer.echo()

    result = subprocess.run(
        ["python3", str(token_script), "--env", env],
        capture_output=False,
        stdout=subprocess.PIPE,
        text=True,
    )

    if result.returncode != 0 or not result.stdout.strip():
        typer.secho("  Authentication failed.", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    token = result.stdout.strip()
    os.environ["HORIZYN_TOKEN"] = token

    # Cache for future runs
    cache_dir.mkdir(mode=0o700, exist_ok=True)
    cache_file.write_text(token)
    cache_file.chmod(0o600)


@test_app.command("list")
def list_tests(
    target: str = typer.Option("local", "--target", "-t", help="local or deployed."),
):
    """Show available test suites."""
    repo = require_repo("horizyn-api")
    test_dir = repo / f"test/server/{target}"
    if not test_dir.is_dir():
        typer.echo(f"Test directory not found: {test_dir}", err=True)
        raise typer.Exit(1)

    suites = _discover_suites(test_dir)
    typer.echo(f"\n  {target} test suites:\n")
    for num, name, path in suites:
        typer.echo(f"  {num:3d}  {name}")
    typer.echo()


@test_app.command("local")
def test_local(
    suites: Optional[list[str]] = typer.Argument(None, help="Suite numbers or names. Omit to run all."),
):
    """Run local integration tests."""
    repo = require_repo("horizyn-api")
    test_dir = repo / "test/server/local"

    if not suites:
        run_script(test_dir / "run_all_tests.sh", cwd=test_dir)
        return

    available = _discover_suites(test_dir)
    selected = _resolve_suites(available, suites)

    for num, name, path in selected:
        typer.echo(f"\n{'='*60}")
        typer.echo(f"  Running: {num}_{name}")
        typer.echo(f"{'='*60}\n")
        run_script(path, cwd=test_dir)


@test_app.command("deployed")
def test_deployed(
    suites: Optional[list[str]] = typer.Argument(None, help="Suite numbers or names. Omit to run all."),
    env: str = typer.Option("dev", "--env", "-e", help="Environment: dev or prod."),
):
    """Run deployed integration tests."""
    repo = require_repo("horizyn-api")
    test_dir = repo / "test/server/deployed"

    if not suites:
        # run_all_tests.sh handles its own token flow
        run_script(test_dir / "run_all_tests.sh", args=[env], cwd=test_dir)
        return

    _ensure_jwt_token(env, test_dir)

    available = _discover_suites(test_dir)
    selected = _resolve_suites(available, suites)

    for num, name, path in selected:
        typer.echo(f"\n{'='*60}")
        typer.echo(f"  Running: {num}_{name}")
        typer.echo(f"{'='*60}\n")
        run_script(path, args=[env], cwd=test_dir)
