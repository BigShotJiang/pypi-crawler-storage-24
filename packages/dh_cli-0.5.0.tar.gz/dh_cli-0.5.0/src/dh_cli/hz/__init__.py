"""dh hz — Horizyn API management commands."""

import os
from pathlib import Path

import typer

hz_app = typer.Typer(
    help="Manage Horizyn API: users, deployments, local servers, and tests.",
    context_settings={"help_option_names": ["-h", "--help"]},
)

API_URLS = {
    "prod": "https://api.horizyn.dayhofflabs.com",
    "dev": "https://horizyn-api-dev.dayhofflabs.com",
}


@hz_app.command()
def health(
    detailed: bool = typer.Option(False, "-d", "--detailed", help="Include GPU and EFS details."),
):
    """Check API health for both prod and dev environments."""
    import json
    from concurrent.futures import ThreadPoolExecutor
    from urllib.request import urlopen
    from urllib.error import URLError

    path = "/healthz/detailed" if detailed else "/healthz"

    def _fetch(env: str) -> tuple[str, dict | str]:
        try:
            with urlopen(f"{API_URLS[env]}{path}", timeout=10) as resp:
                return env, json.loads(resp.read())
        except (URLError, OSError) as exc:
            return env, f"unreachable ({exc})"
        except json.JSONDecodeError:
            return env, "invalid response"

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = dict(pool.map(_fetch, API_URLS))

    for env in ("prod", "dev"):
        label = f"[{env}] {API_URLS[env]}"
        data = results[env]
        if isinstance(data, str):
            typer.secho(f"{label}  ✗ {data}", fg=typer.colors.RED)
        else:
            status = data.get("status", "unknown")
            version = data.get("version", "?")
            color = typer.colors.GREEN if status == "healthy" else typer.colors.YELLOW
            typer.secho(f"{label}  v{version}  {status}", fg=color)
            typer.echo(json.dumps(data, indent=2))


def _find_workspace_root() -> Path:
    root = os.environ.get("WORKSPACE_ROOT")
    if root:
        p = Path(root)
        if p.is_dir():
            return p

    for child in Path("/workspaces").iterdir():
        if child.is_dir() and not child.name.startswith("."):
            return child

    typer.echo("Cannot determine workspace root. Set $WORKSPACE_ROOT.", err=True)
    raise typer.Exit(1)


def require_repo(name: str) -> Path:
    """Return the path to a cloned repo, or exit with a helpful error."""
    root = _find_workspace_root()
    repo = root / name
    if not repo.is_dir():
        typer.echo(
            f"Repository '{name}' not found at {repo}.\n"
            f"Clone it with: dc clone {name}",
            err=True,
        )
        raise typer.Exit(1)
    return repo


def run_script(script: Path, args: list[str] | None = None, cwd: Path | None = None) -> None:
    """Run a shell script, streaming output. Exit on failure."""
    import subprocess

    if not script.exists():
        typer.echo(f"Script not found: {script}", err=True)
        raise typer.Exit(1)

    cmd = ["bash", str(script)] + (args or [])
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode != 0:
        raise typer.Exit(result.returncode)


from dh_cli.hz.users import users_app  # noqa: E402
from dh_cli.hz.deploy import deploy_app  # noqa: E402
from dh_cli.hz.local import local_app  # noqa: E402
from dh_cli.hz.test import test_app  # noqa: E402
from dh_cli.hz.tf import tf_app  # noqa: E402

hz_app.add_typer(users_app, name="users", help="Manage authorized users and tiers.")
hz_app.add_typer(deploy_app, name="deploy", help="Deploy API, docking, or frontend.")
hz_app.add_typer(local_app, name="local", help="Run local development servers.")
hz_app.add_typer(test_app, name="test", help="Run integration test suites.")
hz_app.add_typer(tf_app, name="tf", help="Terraform apply for Horizyn infrastructure.")
