"""Terraform deployments for Horizyn infrastructure."""

import typer

from dh_cli.hz import require_repo, run_script

tf_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})

TF_MODULES = {
    ("api", "dev"): "terraform/environments/dev/horizyn_api/api",
    ("api", "prod"): "terraform/environments/dev/horizyn_api_prod",
    ("frontend", "dev"): "terraform/environments/dev/horizyn_frontend",
    ("frontend", "prod"): "terraform/environments/dev/horizyn_frontend_prod",
    ("docking", "dev"): "terraform/environments/dev/boltz_docking/service",
    ("docking", "prod"): "terraform/environments/dev/boltz_docking_prod/service",
}


def _confirm_tf(target: str, env: str) -> None:
    color = typer.colors.RED if env == "prod" else typer.colors.BRIGHT_GREEN
    env_styled = typer.style(env, fg=color, bold=True)
    typer.echo(f"\n  Terraform apply: {target} in {env_styled}\n")
    if not typer.confirm("  Continue?"):
        raise typer.Abort()
    typer.echo()


def _run_tf(target: str, env: str, action: str) -> None:
    repo = require_repo("blueprints")
    module_path = TF_MODULES.get((target, env))
    if not module_path:
        typer.echo(f"Unknown combination: {target} / {env}", err=True)
        raise typer.Exit(1)
    script = repo / "scripts/terraform-deploy"
    run_script(script, args=[module_path, action], cwd=repo)


@tf_app.command("api")
def tf_api(
    env: str = typer.Option("dev", "--env", "-e", help="Environment: prod or dev."),
    yolo: bool = typer.Option(False, "--yolo", help="Auto-approve (no confirmation prompt)."),
):
    """Terraform apply for the Horizyn API server."""
    if not yolo:
        _confirm_tf("api", env)
    _run_tf("api", env, "yolo" if yolo else "plan")


@tf_app.command("frontend")
def tf_frontend(
    env: str = typer.Option("dev", "--env", "-e", help="Environment: prod or dev."),
    yolo: bool = typer.Option(False, "--yolo", help="Auto-approve (no confirmation prompt)."),
):
    """Terraform apply for the Horizyn frontend."""
    if not yolo:
        _confirm_tf("frontend", env)
    _run_tf("frontend", env, "yolo" if yolo else "plan")


@tf_app.command("docking")
def tf_docking(
    env: str = typer.Option("dev", "--env", "-e", help="Environment: prod or dev."),
    yolo: bool = typer.Option(False, "--yolo", help="Auto-approve (no confirmation prompt)."),
):
    """Terraform apply for the Boltz docking service."""
    if not yolo:
        _confirm_tf("docking", env)
    _run_tf("docking", env, "yolo" if yolo else "plan")
