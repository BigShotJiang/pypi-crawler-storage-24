# SPDX-FileCopyrightText: 2024-2026 Stanford University
# SPDX-License-Identifier: AGPL-3.0-or-later

## Constants
PI = 3.14159265358979323846
TWO_PI = 2.0 * PI

# Molar Masses
MW_G_PER_MOL_NO2 = 46.0055
MW_G_PER_MOL_SO2 = 64.0638
MW_G_PER_MOL_CO2 = 44.0095