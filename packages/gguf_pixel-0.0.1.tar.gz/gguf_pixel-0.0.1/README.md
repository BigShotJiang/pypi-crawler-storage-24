## gguf-pixel

example:
```
pixel --num_images 3
```