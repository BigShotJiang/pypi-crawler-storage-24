from __future__ import annotations

from typing import Literal

import httpx
import pandas as pd


def expand_dict_columns(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Expand a column of dicts into prefixed sub-columns and drop the original.

    Parameters
    ----------
    df : pd.DataFrame
    col : str
        Name of the column whose values are dicts.

    Returns
    -------
    pd.DataFrame
        DataFrame with ``col`` replaced by ``{col}_{key}`` sub-columns.
    """
    expanded = pd.json_normalize(df[col].tolist()).add_prefix(f"{col}_")
    expanded.index = df.index
    return pd.concat([df.drop(columns=[col]), expanded], axis=1)

ETF_BASES = ["btc", "eth", "sol", "doge", "ltc", "link", "avax"]
ETF_TYPES = [f"us-{base}-spot" for base in ETF_BASES]
EtfType = Literal[
    "us-btc-spot",
    "us-eth-spot",
    "us-sol-spot",
    "us-doge-spot",
    "us-ltc-spot",
    "us-link-spot",
    "us-avax-spot",
]


class SoSoValueError(Exception):
    """Raised when the SoSoValue API returns an error response."""


class SoSoValueClient:
    """HTTP client for the SoSoValue OpenAPI, returning pandas DataFrames.

    Parameters
    ----------
    api_key : str
        Your SoSoValue API key.
    base_url : str
        API base URL (default: ``https://openapi.sosovalue.com``).
    timeout : float
        Request timeout in seconds (default: 15).

    Examples
    --------
    >>> with SoSoValueClient(api_key="...") as client:
    ...     df = client.get_etf_historical_inflow_chart("us-btc-spot")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://openapi.sosovalue.com",
        timeout: float = 15.0,
    ) -> None:
        self._http = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={"x-soso-api-key": api_key},
        )

    def close(self) -> None:
        """Close the underlying HTTP client and release connections."""
        self._http.close()

    def __enter__(self) -> SoSoValueClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"SoSoValueClient(base_url={self._http.base_url!r})"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict) -> dict:
        r = self._http.post(path, json=body)
        r.raise_for_status()
        payload: dict = r.json()
        if payload.get("code", 0) != 0:
            raise SoSoValueError(payload.get("msg", "Unknown API error"))
        return payload

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_etf_historical_inflow_chart(self, etf: EtfType) -> pd.DataFrame:
        """Fetch last ~300 daily data points for a US spot ETF inflow chart.

        Parameters
        ----------
        etf : str
            ETF type string, e.g. ``"us-btc-spot"``.

        Returns
        -------
        pd.DataFrame
            Columns: ``date``, ``totalNetInflow``, ``totalValueTraded``,
            ``totalNetAssets``, ``cumNetInflow``, ``etf``
        """
        payload = self._post("/openapi/v2/etf/historicalInflowChart", {"type": etf})
        df = pd.DataFrame(payload.get("data") or [])
        if not df.empty:
            df["date"] = pd.to_datetime(df["date"], format="%Y-%m-%d", errors="coerce")
            df["etf"] = etf
            df = df.sort_values("date").reset_index(drop=True)
        return df

    def get_all_etf_inflows(self) -> pd.DataFrame:
        """Fetch inflow data for all supported ETF types in one DataFrame.

        Returns
        -------
        pd.DataFrame
            Same columns as :meth:`get_etf_historical_inflow_chart`,
            concatenated across all ETF types.
        """
        frames = [self.get_etf_historical_inflow_chart(etf) for etf in ETF_TYPES]
        return pd.concat(frames, ignore_index=True)

    def get_all_listed_currencies(self) -> pd.DataFrame:
        """Fetch all cryptocurrencies listed on SoSoValue.

        Returns
        -------
        pd.DataFrame
            Columns: ``currencyId`` (int), ``fullName`` (str),
            ``currencyName`` (str)
        """
        payload = self._post("/openapi/v1/data/default/coin/list", {})
        return pd.DataFrame(payload.get("data") or [])

    def get_current_etf_data_metrics(self, etf: EtfType) -> pd.DataFrame:
        """Fetch current data metrics for all ETFs in a US spot product.

        Each row represents one individual ETF. Dict-valued columns
        (``netAssets``, ``netAssetsPercentage``, ``dailyNetInflow``,
        ``cumNetInflow``, ``dailyValueTraded``, ``fee``,
        ``discountPremiumRate``) are flattened into prefixed sub-columns,
        e.g. ``netAssets_value``, ``netAssets_lastUpdateDate``,
        ``netAssets_status``.

        Parameters
        ----------
        etf : str
            ETF type string, e.g. ``"us-btc-spot"``.

        Returns
        -------
        pd.DataFrame
            Columns: ``id``, ``ticker``, ``institute``,
            ``netAssets_value``, ``netAssets_lastUpdateDate``,
            ``netAssets_status``, … (one group per dict column), ``etf``
        """
        _DICT_COLS = [
            "netAssets",
            "netAssetsPercentage",
            "dailyNetInflow",
            "cumNetInflow",
            "dailyValueTraded",
            "fee",
            "discountPremiumRate",
        ]
        payload = self._post("/openapi/v2/etf/currentEtfDataMetrics", {"type": etf})
        items = (payload.get("data") or {}).get("list") or []
        df = pd.DataFrame(items)
        if not df.empty:
            for col in _DICT_COLS:
                if col in df.columns:
                    df = expand_dict_columns(df, col)
            date_cols = [c for c in df.columns if c.endswith("_lastUpdateDate")]
            for col in date_cols:
                df[col] = pd.to_datetime(df[col], format="%Y-%m-%d", errors="coerce")
            df["etf"] = etf
        return df
