#!/usr/bin/env python3
"""
debugger.help VPS Agent v4.0.0 — Action-Based Execution

Key changes from v3:
- Action-based command system: only predefined actions execute, no raw commands
- Fixed error/warning log flood: deduplication + excluded agent's own logs
- Deterministic execution: AI selects from action registry, agent maps to commands
"""

import os
import sys
import time
import json
import socket
import logging
import traceback
import threading
import subprocess
import io
import re
import glob
import ssl
from datetime import datetime, timezone
from collections import deque
from pathlib import Path

try:
    import psutil
except ImportError:
    print("ERROR: psutil required. Install with: pip install psutil")
    sys.exit(1)

try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError:
    print("ERROR: requests required. Install with: pip install requests")
    sys.exit(1)

# Optional GPU monitoring
try:
    import pynvml
    pynvml.nvmlInit()
    GPU_AVAILABLE = True
    GPU_DRIVER_VERSION = pynvml.nvmlSystemGetDriverVersion()
    if isinstance(GPU_DRIVER_VERSION, bytes):
        GPU_DRIVER_VERSION = GPU_DRIVER_VERSION.decode()
    try:
        GPU_CUDA_VERSION = pynvml.nvmlSystemGetCudaDriverVersion_v2()
        GPU_CUDA_VERSION = "{}.{}".format(GPU_CUDA_VERSION // 1000, (GPU_CUDA_VERSION % 1000) // 10)
    except Exception:
        GPU_CUDA_VERSION = "unknown"
except (ImportError, Exception):
    GPU_AVAILABLE = False
    GPU_DRIVER_VERSION = None
    GPU_CUDA_VERSION = None

# Optional Docker monitoring
try:
    import docker
    DOCKER_CLIENT = docker.from_env()
    DOCKER_AVAILABLE = True
except Exception:
    DOCKER_CLIENT = None
    DOCKER_AVAILABLE = False

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger("debugger-agent")

# Configuration
API_KEY = os.environ.get("DEBUGGER_API_KEY", "")
INGEST_URL = os.environ.get("DEBUGGER_INGEST_URL", "")
SOURCE_NAME = os.environ.get("DEBUGGER_SOURCE", "vps-{}".format(socket.gethostname()))
PLATFORM = os.environ.get("DEBUGGER_PLATFORM", "Python (VPS)")
INTERVAL = int(os.environ.get("DEBUGGER_INTERVAL", "10"))
VERSION = "4.1.0"

# Derive poll-commands URL from ingest URL
POLL_COMMANDS_URL = INGEST_URL.replace("/ingest", "/poll-commands") if INGEST_URL else ""

# Additional log files to watch
WATCH_LOG_FILES = [
    p for p in os.environ.get("DEBUGGER_WATCH_LOGS", "").split(",") if p.strip()
] or []

# SSL domains to check
SSL_CHECK_DOMAINS = [
    d for d in os.environ.get("DEBUGGER_SSL_DOMAINS", "").split(",") if d.strip()
] or []

if not API_KEY:
    logger.error("DEBUGGER_API_KEY not set.")
    sys.exit(1)
if not INGEST_URL:
    logger.error("DEBUGGER_INGEST_URL not set.")
    sys.exit(1)

# --- HTTP Session with Retry ---

session = requests.Session()
retry = Retry(total=3, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
session.mount("https://", HTTPAdapter(max_retries=retry))
session.mount("http://", HTTPAdapter(max_retries=retry))

HEADERS = {
    "Authorization": "Bearer {}".format(API_KEY),
    "Content-Type": "application/json",
}


def send(payload):
    """Send payload with auto-retry."""
    try:
        resp = session.post(INGEST_URL, json=payload, headers=HEADERS, timeout=15)
        if resp.status_code != 200:
            logger.warning("Send failed [%s %s]: %s", payload.get("type"), resp.status_code, resp.text[:200])
        return resp.status_code == 200
    except Exception as e:
        logger.warning("Send error [%s]: %s", payload.get("type"), e)
        return False


def run_cmd(cmd, timeout=10):
    """Run shell command and return output."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return (result.stdout + result.stderr).strip()
    except subprocess.TimeoutExpired:
        return "[timeout after {}s]".format(timeout)
    except Exception as e:
        return "[error: {}]".format(e)


# =============================================================================
# ACTION REGISTRY — the ONLY commands that can be executed remotely
# =============================================================================

ACTION_COMMANDS = {
    "check_gpu": "nvidia-smi",
    "check_gpu_detailed": "nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu,temperature.gpu --format=csv,noheader,nounits",
    "check_docker": "systemctl status docker",
    "restart_docker": "sudo systemctl restart docker",
    "check_comfy": "pm2 logs yourstudio-gpu --nostream --lines 100 2>/dev/null || pm2 logs --nostream --lines 100 2>/dev/null",
    "restart_comfy": "pm2 restart yourstudio-gpu 2>/dev/null || pm2 restart all",
    "check_processes": "ps aux --sort=-%cpu | head -30",
    "check_ports": "ss -tulnp",
    "check_health": "curl -fsS --connect-timeout 5 --max-time 10 http://127.0.0.1:8188/health 2>&1 || echo 'Health check failed'",
    "check_disk": "df -h",
    "check_memory": "free -h",
    "check_uptime": "uptime",
    "check_pm2": "pm2 list",
    "check_systemd": "systemctl --failed --no-pager --plain 2>/dev/null | head -20",
    "check_journal_errors": "journalctl -p err --since '1 hour ago' --no-pager -q 2>/dev/null | tail -50",
    "check_dmesg": "dmesg --time-format iso -T 2>/dev/null | tail -50",
    "check_network": "ip addr show",

    # ComfyUI / Flux Dev workflow actions (use ComfyUI API at localhost:8188)
    "comfy_list_models": "curl -fsS http://127.0.0.1:8188/object_info/CheckpointLoaderSimple 2>/dev/null | python3 -c \"import sys,json; d=json.load(sys.stdin); ckpts=d.get('CheckpointLoaderSimple',{}).get('input',{}).get('required',{}).get('ckpt_name',[[]])[0]; print(json.dumps({'checkpoints':ckpts},indent=2))\" 2>/dev/null || echo '{\"error\":\"ComfyUI API not responding\"}'",
    "comfy_queue_status": "curl -fsS http://127.0.0.1:8188/queue 2>/dev/null || echo '{\"error\":\"ComfyUI API not responding\"}'",
    "comfy_history": "curl -fsS 'http://127.0.0.1:8188/history?max_items=10' 2>/dev/null || echo '{\"error\":\"ComfyUI API not responding\"}'",
    "comfy_system_stats": "curl -fsS http://127.0.0.1:8188/system_stats 2>/dev/null || echo '{\"error\":\"ComfyUI API not responding\"}'",
    "comfy_view_output": "ls -lt ~/ComfyUI/output/ 2>/dev/null | head -30 || ls -lt /workspace/ComfyUI/output/ 2>/dev/null | head -30 || echo 'No output directory found'",
    "comfy_interrupt": "curl -fsS -X POST http://127.0.0.1:8188/interrupt 2>/dev/null || echo '{\"error\":\"ComfyUI API not responding\"}'",
    "comfy_clear_queue": "curl -fsS -X POST http://127.0.0.1:8188/queue -H 'Content-Type: application/json' -d '{\"clear\":true}' 2>/dev/null || echo '{\"error\":\"ComfyUI API not responding\"}'",
}

# Actions that use the ComfyUI API and need special handling (payload-based)
COMFY_API_ACTIONS = {
    "comfy_queue_prompt",   # needs workflow JSON payload
    "comfy_save_workflow",  # needs workflow JSON + filename
    "comfy_delete_workflow", # needs filename
    "comfy_get_workflow",   # needs filename
    "comfy_list_workflows", # lists workflow files
    "comfy_object_info",    # gets node definitions
}

# Workflow storage directory
COMFY_WORKFLOW_DIR = os.environ.get(
    "COMFY_WORKFLOW_DIR",
    os.path.expanduser("~/ComfyUI/user/default/workflows")
)
# Fallback locations
COMFY_WORKFLOW_DIRS = [
    COMFY_WORKFLOW_DIR,
    os.path.expanduser("~/ComfyUI/custom_workflows"),
    "/workspace/ComfyUI/user/default/workflows",
    "/workspace/ComfyUI/custom_workflows",
]

# Actions that are never auto-executed even if the server says so
DANGEROUS_ACTIONS = {"restart_docker", "restart_comfy"}


# =============================================================================
# Stdout/Stderr Capture (with deduplication)
# =============================================================================

class StreamCapture(io.TextIOBase):
    """Captures writes to stdout/stderr and buffers them for batch sending."""

    def __init__(self, original_stream, level="info", max_buffer=500):
        self.original = original_stream
        self.level = level
        self.buffer = deque(maxlen=max_buffer)
        self.pending = deque(maxlen=100)
        self.lock = threading.Lock()
        self._sending = False
        self._recent_hashes = deque(maxlen=200)

    def write(self, text):
        self.original.write(text)
        if text.strip() and not self._sending:
            msg_hash = hash(text.strip()[:200])
            with self.lock:
                # Deduplicate: skip if we've seen this exact message recently
                if msg_hash in self._recent_hashes:
                    return len(text)
                self._recent_hashes.append(msg_hash)
                self.buffer.append(text.strip())
                lower = text.lower()
                detected_level = self.level
                if any(kw in lower for kw in [
                    "error", "exception", "traceback", "failed", "critical",
                    "cuda", "oom", "killed", "segfault", "abort", "panic"
                ]):
                    detected_level = "error"
                elif any(kw in lower for kw in ["warning", "warn", "deprecat"]):
                    detected_level = "warn"
                self.pending.append((detected_level, text.strip()[:2000]))
        return len(text)

    def flush(self):
        self.original.flush()

    def flush_pending(self):
        """Send buffered messages from main loop to avoid recursion."""
        items = []
        with self.lock:
            while self.pending:
                items.append(self.pending.popleft())
        self._sending = True
        try:
            for level, msg in items:
                send({
                    "type": "log",
                    "source": SOURCE_NAME,
                    "platform": PLATFORM,
                    "version": VERSION,
                    "level": level,
                    "message": "[std{}] {}".format(self.level, msg),
                    "context": {"capturedFrom": "std{}".format(self.level)},
                })
        finally:
            self._sending = False

    def get_recent(self, n=100):
        with self.lock:
            return list(self.buffer)[-n:]


# =============================================================================
# GPU Metrics (Deep)
# =============================================================================

def get_gpu_metrics():
    if not GPU_AVAILABLE:
        return {}
    try:
        device_count = pynvml.nvmlDeviceGetCount()
        gpus = []
        for i in range(device_count):
            handle = pynvml.nvmlDeviceGetHandleByIndex(i)
            temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
            mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
            power = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            name = pynvml.nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode("utf-8")

            gpu_info = {
                "index": i,
                "name": name,
                "temp_c": temp,
                "vram_used_gb": round(mem.used / 1e9, 2),
                "vram_total_gb": round(mem.total / 1e9, 2),
                "vram_free_gb": round(mem.free / 1e9, 2),
                "vram_pct": round((mem.used / mem.total) * 100, 1) if mem.total > 0 else 0,
                "gpu_util_pct": util.gpu,
                "mem_util_pct": util.memory,
                "power_w": round(power, 1),
            }

            try:
                power_limit = pynvml.nvmlDeviceGetPowerManagementLimit(handle) / 1000
                gpu_info["power_limit_w"] = round(power_limit, 1)
            except Exception:
                pass

            try:
                throttle = pynvml.nvmlDeviceGetCurrentClocksThrottleReasons(handle)
                reasons = []
                if throttle & 0x0000000000000002: reasons.append("idle")
                if throttle & 0x0000000000000004: reasons.append("app_clocks")
                if throttle & 0x0000000000000008: reasons.append("sw_power_cap")
                if throttle & 0x0000000000000020: reasons.append("hw_slowdown")
                if throttle & 0x0000000000000040: reasons.append("sync_boost")
                if throttle & 0x0000000000000080: reasons.append("sw_thermal")
                if throttle & 0x0000000000000100: reasons.append("hw_thermal")
                if throttle & 0x0000000000000200: reasons.append("hw_power_brake")
                gpu_info["throttle_reasons"] = reasons if reasons else ["none"]
            except Exception:
                pass

            try:
                gpu_info["clock_graphics_mhz"] = pynvml.nvmlDeviceGetClockInfo(handle, pynvml.NVML_CLOCK_GRAPHICS)
                gpu_info["clock_mem_mhz"] = pynvml.nvmlDeviceGetClockInfo(handle, pynvml.NVML_CLOCK_MEM)
            except Exception:
                pass

            try:
                procs = pynvml.nvmlDeviceGetComputeRunningProcesses(handle)
                gpu_procs = []
                for p in procs[:10]:
                    try:
                        proc = psutil.Process(p.pid)
                        gpu_procs.append({
                            "pid": p.pid,
                            "name": proc.name(),
                            "vram_mb": round(p.usedGpuMemory / 1e6, 1) if p.usedGpuMemory else 0,
                            "cmdline": " ".join(proc.cmdline()[:5])
                        })
                    except Exception:
                        gpu_procs.append({"pid": p.pid, "vram_mb": round(p.usedGpuMemory / 1e6, 1) if p.usedGpuMemory else 0})
                gpu_info["processes"] = gpu_procs
            except Exception:
                pass

            try:
                ecc_single = pynvml.nvmlDeviceGetTotalEccErrors(handle, pynvml.NVML_SINGLE_BIT_ECC, pynvml.NVML_VOLATILE_ECC)
                ecc_double = pynvml.nvmlDeviceGetTotalEccErrors(handle, pynvml.NVML_DOUBLE_BIT_ECC, pynvml.NVML_VOLATILE_ECC)
                gpu_info["ecc_single_bit"] = ecc_single
                gpu_info["ecc_double_bit"] = ecc_double
            except Exception:
                pass

            gpus.append(gpu_info)

        return {
            "driver_version": GPU_DRIVER_VERSION,
            "cuda_version": GPU_CUDA_VERSION,
            "device_count": device_count,
            "gpus": gpus,
            "gpu_temp": gpus[0]["temp_c"] if gpus else None,
            "gpu_vram": gpus[0]["vram_used_gb"] if gpus else None,
        }
    except Exception as e:
        return {"error": str(e)}


# =============================================================================
# PM2 Integration
# =============================================================================

def get_pm2_status():
    raw = run_cmd("pm2 jlist 2>/dev/null")
    if not raw or raw.startswith("[error") or raw.startswith("[timeout"):
        return {"available": False, "raw": raw}

    try:
        processes = json.loads(raw)
        result = {"available": True, "processes": []}
        for p in processes:
            env = p.get("pm2_env", {})
            monit = p.get("monit", {})
            proc_info = {
                "name": p.get("name"),
                "pid": p.get("pid"),
                "pm_id": p.get("pm_id"),
                "status": env.get("status"),
                "restart_count": env.get("restart_time", 0),
                "unstable_restarts": env.get("unstable_restarts", 0),
                "uptime_ms": int(time.time() * 1000) - env.get("pm_uptime", 0) if env.get("pm_uptime") else None,
                "cpu_pct": monit.get("cpu"),
                "memory_mb": round(monit.get("memory", 0) / 1e6, 1),
                "exec_mode": env.get("exec_mode"),
                "node_version": env.get("node_version"),
                "script": env.get("pm_exec_path"),
                "cwd": env.get("pm_cwd"),
                "created_at": env.get("created_at"),
                "instances": env.get("instances"),
                "exit_code": env.get("exit_code"),
            }
            result["processes"].append(proc_info)
        return result
    except json.JSONDecodeError:
        return {"available": True, "raw_output": raw[:2000]}


def get_pm2_logs(lines=100):
    output = run_cmd("pm2 logs --nostream --lines {} 2>/dev/null".format(lines), timeout=10)
    return output[-5000:] if output else ""


# =============================================================================
# System Metrics (Deep)
# =============================================================================

def get_disk_io():
    try:
        io_counters = psutil.disk_io_counters(perdisk=False)
        if io_counters:
            return {
                "read_mb": round(io_counters.read_bytes / 1e6, 1),
                "write_mb": round(io_counters.write_bytes / 1e6, 1),
                "read_count": io_counters.read_count,
                "write_count": io_counters.write_count,
                "read_time_ms": io_counters.read_time,
                "write_time_ms": io_counters.write_time,
            }
    except Exception:
        pass
    return {}


def get_network_details():
    result = {}
    try:
        net_io = psutil.net_io_counters(pernic=True)
        interfaces = {}
        for name, counters in net_io.items():
            if name == "lo":
                continue
            interfaces[name] = {
                "sent_mb": round(counters.bytes_sent / 1e6, 1),
                "recv_mb": round(counters.bytes_recv / 1e6, 1),
                "packets_sent": counters.packets_sent,
                "packets_recv": counters.packets_recv,
                "errors_in": counters.errin,
                "errors_out": counters.errout,
                "drops_in": counters.dropin,
                "drops_out": counters.dropout,
            }
        result["interfaces"] = interfaces
    except Exception:
        pass

    try:
        connections = psutil.net_connections(kind="tcp")
        states = {}
        for conn in connections:
            s = conn.status
            states[s] = states.get(s, 0) + 1
        result["tcp_states"] = states
        result["total_connections"] = len(connections)
    except Exception:
        pass

    try:
        listening = []
        for conn in psutil.net_connections(kind="tcp"):
            if conn.status == "LISTEN":
                listening.append({
                    "port": conn.laddr.port,
                    "addr": conn.laddr.ip,
                    "pid": conn.pid,
                })
        result["listening_ports"] = listening[:30]
    except Exception:
        pass

    try:
        start = time.time()
        socket.getaddrinfo("google.com", 80)
        result["dns_resolve_ms"] = round((time.time() - start) * 1000, 1)
    except Exception as e:
        result["dns_error"] = str(e)

    return result


def get_top_processes(n=15):
    procs = []
    for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status", "num_fds", "num_threads", "create_time", "cmdline"]):
        try:
            info = p.info
            if info["cpu_percent"] is None:
                continue
            procs.append({
                "pid": info["pid"],
                "name": info["name"],
                "cpu_pct": info["cpu_percent"],
                "mem_pct": round(info["memory_percent"] or 0, 1),
                "status": info["status"],
                "fds": info.get("num_fds"),
                "threads": info.get("num_threads"),
                "cmd": " ".join((info.get("cmdline") or [])[:5])[:200],
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    procs.sort(key=lambda x: x["cpu_pct"], reverse=True)
    return procs[:n]


def get_zombie_processes():
    zombies = []
    for p in psutil.process_iter(["pid", "name", "status", "ppid"]):
        try:
            if p.info["status"] == psutil.STATUS_ZOMBIE:
                zombies.append({
                    "pid": p.info["pid"],
                    "name": p.info["name"],
                    "ppid": p.info["ppid"],
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return zombies


def get_disk_details():
    mounts = []
    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
            info = {
                "mount": part.mountpoint,
                "device": part.device,
                "fstype": part.fstype,
                "total_gb": round(usage.total / 1e9, 1),
                "used_gb": round(usage.used / 1e9, 1),
                "free_gb": round(usage.free / 1e9, 1),
                "pct": usage.percent,
            }
            try:
                inode_output = run_cmd("df -i {} | tail -1".format(part.mountpoint), timeout=3)
                parts = inode_output.split()
                if len(parts) >= 5:
                    info["inodes_used"] = parts[2]
                    info["inodes_free"] = parts[3]
                    info["inodes_pct"] = parts[4]
            except Exception:
                pass
            mounts.append(info)
        except Exception:
            pass
    return mounts


def get_systemd_failed():
    output = run_cmd("systemctl --failed --no-pager --plain 2>/dev/null", timeout=5)
    if not output or "0 loaded" in output:
        return []
    failed = []
    for line in output.split("\n"):
        line = line.strip()
        if line and not line.startswith("UNIT") and not line.startswith("LOAD") and "loaded" not in line.lower():
            parts = line.split()
            if len(parts) >= 1:
                failed.append(parts[0])
    return failed[:20]


def get_docker_status():
    if not DOCKER_AVAILABLE:
        return {"available": False}
    try:
        containers = []
        for c in DOCKER_CLIENT.containers.list(all=True):
            stats = {}
            if c.status == "running":
                try:
                    s = c.stats(stream=False)
                    cpu_delta = s["cpu_stats"]["cpu_usage"]["total_usage"] - s["precpu_stats"]["cpu_usage"]["total_usage"]
                    system_delta = s["cpu_stats"]["system_cpu_usage"] - s["precpu_stats"]["system_cpu_usage"]
                    cpu_pct = round((cpu_delta / system_delta) * 100, 1) if system_delta > 0 else 0
                    mem_usage = s["memory_stats"].get("usage", 0)
                    mem_limit = s["memory_stats"].get("limit", 1)
                    stats = {
                        "cpu_pct": cpu_pct,
                        "memory_mb": round(mem_usage / 1e6, 1),
                        "memory_limit_mb": round(mem_limit / 1e6, 1),
                    }
                except Exception:
                    pass
            containers.append({
                "name": c.name,
                "image": c.image.tags[0] if c.image.tags else str(c.image.id)[:12],
                "status": c.status,
                "restart_count": c.attrs.get("RestartCount", 0),
                **stats,
            })
        return {"available": True, "containers": containers}
    except Exception as e:
        return {"available": False, "error": str(e)}


def check_ssl_certs():
    results = []
    for domain in SSL_CHECK_DOMAINS:
        try:
            ctx = ssl.create_default_context()
            with ctx.wrap_socket(socket.socket(), server_hostname=domain) as s:
                s.settimeout(5)
                s.connect((domain, 443))
                cert = s.getpeercert()
                expires = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z")
                days_left = (expires - datetime.now()).days
                results.append({
                    "domain": domain,
                    "expires": cert["notAfter"],
                    "days_left": days_left,
                    "issuer": dict(x[0] for x in cert.get("issuer", [])).get("organizationName", "unknown"),
                    "warning": days_left < 30,
                })
        except Exception as e:
            results.append({"domain": domain, "error": str(e)})
    return results


def get_system_logs():
    logs = {}
    dmesg = run_cmd("dmesg --time-format iso -T 2>/dev/null | tail -50", timeout=5)
    if dmesg and not dmesg.startswith("[error"):
        logs["dmesg"] = dmesg[-3000:]
    oom = run_cmd("dmesg | grep -i 'oom\\|killed process\\|out of memory' | tail -10 2>/dev/null", timeout=5)
    if oom and not oom.startswith("[error"):
        logs["oom_kills"] = oom
    journal = run_cmd("journalctl -p err --since '1 hour ago' --no-pager -q 2>/dev/null | tail -30", timeout=5)
    if journal and not journal.startswith("[error"):
        logs["journal_errors"] = journal[-2000:]
    auth = run_cmd("tail -20 /var/log/auth.log 2>/dev/null || tail -20 /var/log/secure 2>/dev/null", timeout=5)
    if auth and not auth.startswith("[error"):
        logs["auth_log"] = auth[-1000:]
    return logs


def get_env_sanitized():
    relevant_prefixes = [
        "NODE_", "PYTHON", "PATH", "HOME", "USER", "SHELL", "LANG",
        "CUDA", "NVIDIA", "GPU", "LD_LIBRARY", "VIRTUAL_ENV", "CONDA",
        "PM2_", "PORT", "HOST", "DISPLAY", "XDG_", "DBUS",
    ]
    env = {}
    for key, value in os.environ.items():
        if any(key.startswith(p) for p in relevant_prefixes):
            if any(s in key.upper() for s in ["KEY", "SECRET", "TOKEN", "PASS", "AUTH"]):
                env[key] = "[REDACTED]"
            else:
                env[key] = value[:500]
    return env


def get_installed_packages():
    pkgs = {}
    pip_list = run_cmd("pip list --format=json 2>/dev/null", timeout=10)
    if pip_list and pip_list.startswith("["):
        try:
            pkgs["python"] = {p["name"]: p["version"] for p in json.loads(pip_list)}
        except Exception:
            pass
    npm_list = run_cmd("npm list -g --depth=0 --json 2>/dev/null", timeout=10)
    if npm_list and npm_list.startswith("{"):
        try:
            deps = json.loads(npm_list).get("dependencies", {})
            pkgs["node_global"] = {k: v.get("version", "?") for k, v in deps.items()}
        except Exception:
            pass
    pm2_conf = run_cmd("cat ecosystem.config.js 2>/dev/null || cat ecosystem.config.cjs 2>/dev/null", timeout=3)
    if pm2_conf and not pm2_conf.startswith("[error"):
        pkgs["pm2_ecosystem"] = pm2_conf[:3000]
    return pkgs


def get_firewall_rules():
    ufw = run_cmd("ufw status verbose 2>/dev/null", timeout=5)
    if ufw and "Status:" in ufw:
        return ufw[:2000]
    ipt = run_cmd("iptables -L -n --line-numbers 2>/dev/null | head -40", timeout=5)
    return ipt[:2000] if ipt else ""


# =============================================================================
# File Watcher Thread (with deduplication + agent log exclusion)
# =============================================================================

class LogFileWatcher(threading.Thread):
    def __init__(self, files):
        super().__init__(daemon=True)
        self.files = files
        self.positions = {}
        self._recent_hashes = deque(maxlen=500)

    def run(self):
        for f in self.files:
            try:
                self.positions[f] = os.path.getsize(f)
            except Exception:
                self.positions[f] = 0

        while True:
            for filepath in self.files:
                try:
                    size = os.path.getsize(filepath)
                    if size > self.positions.get(filepath, 0):
                        with open(filepath, "r") as fh:
                            fh.seek(self.positions[filepath])
                            new_lines = fh.read(10000)
                            self.positions[filepath] = fh.tell()

                        if new_lines.strip():
                            # Deduplicate
                            msg_hash = hash(new_lines.strip()[:300])
                            if msg_hash in self._recent_hashes:
                                continue
                            self._recent_hashes.append(msg_hash)

                            level = "info"
                            lower = new_lines.lower()
                            if any(kw in lower for kw in ["error", "exception", "traceback", "failed", "critical"]):
                                level = "error"
                            elif "warn" in lower:
                                level = "warn"

                            send({
                                "type": "log",
                                "source": SOURCE_NAME,
                                "platform": PLATFORM,
                                "version": VERSION,
                                "level": level,
                                "message": "[file:{}] {}".format(os.path.basename(filepath), new_lines.strip()[:2000]),
                                "context": {"capturedFrom": "file_watcher", "file": filepath},
                            })
                    elif size < self.positions.get(filepath, 0):
                        self.positions[filepath] = 0
                except Exception:
                    pass
            time.sleep(2)


# =============================================================================
# Collect Metrics
# =============================================================================

def collect_full_metrics():
    cpu = psutil.cpu_percent(interval=1)
    cpu_per_core = psutil.cpu_percent(interval=0, percpu=True)
    mem = psutil.virtual_memory()
    swap = psutil.swap_memory()

    data = {
        "cpu": cpu,
        "memory": mem.percent,
        "network_latency": 0,
        "custom": {
            "cpu_per_core": cpu_per_core,
            "cpu_count_logical": psutil.cpu_count(),
            "cpu_count_physical": psutil.cpu_count(logical=False),
            "load_avg": list(os.getloadavg()) if hasattr(os, "getloadavg") else [],
            "memory_used_gb": round(mem.used / 1e9, 2),
            "memory_total_gb": round(mem.total / 1e9, 2),
            "memory_available_gb": round(mem.available / 1e9, 2),
            "memory_cached_gb": round(getattr(mem, "cached", 0) / 1e9, 2),
            "memory_buffers_gb": round(getattr(mem, "buffers", 0) / 1e9, 2),
            "swap_used_gb": round(swap.used / 1e9, 2),
            "swap_total_gb": round(swap.total / 1e9, 2),
            "swap_pct": swap.percent,
            "disk_io": get_disk_io(),
            "os": "{} {}".format(os.uname().sysname, os.uname().release) if hasattr(os, "uname") else "unknown",
            "hostname": socket.gethostname(),
            "python_version": sys.version.split()[0],
            "node_version": run_cmd("node --version 2>/dev/null"),
            "uptime_hours": round((time.time() - psutil.boot_time()) / 3600, 1),
        },
    }

    try:
        freq = psutil.cpu_freq()
        if freq:
            data["custom"]["cpu_freq_mhz"] = round(freq.current, 0)
            data["custom"]["cpu_freq_max_mhz"] = round(freq.max, 0)
    except Exception:
        pass

    try:
        ctx = psutil.cpu_stats()
        data["custom"]["ctx_switches"] = ctx.ctx_switches
        data["custom"]["interrupts"] = ctx.interrupts
    except Exception:
        pass

    gpu = get_gpu_metrics()
    if gpu:
        data["gpu_temp"] = gpu.get("gpu_temp")
        data["gpu_vram"] = gpu.get("gpu_vram")
        data["custom"]["gpu"] = gpu

    return data


def collect_deep_snapshot():
    snapshot = {
        "system": {
            "hostname": socket.gethostname(),
            "uptime_hours": round((time.time() - psutil.boot_time()) / 3600, 1),
            "cpu_count": psutil.cpu_count(),
            "memory_total_gb": round(psutil.virtual_memory().total / 1e9, 2),
            "python_version": sys.version.split()[0],
            "os": "{} {}".format(os.uname().sysname, os.uname().release) if hasattr(os, "uname") else "unknown",
            "kernel": run_cmd("uname -r 2>/dev/null"),
        },
        "gpu": get_gpu_metrics() if GPU_AVAILABLE else {"available": False},
        "pm2": get_pm2_status(),
        "disks": get_disk_details(),
        "network": get_network_details(),
        "top_processes": get_top_processes(15),
        "zombie_processes": get_zombie_processes(),
        "docker": get_docker_status(),
        "systemd_failed": get_systemd_failed(),
        "firewall": get_firewall_rules(),
        "environment": get_env_sanitized(),
    }
    state = job_tracker.get_state()
    if state:
        snapshot["current_job"] = state
    return snapshot


# =============================================================================
# Job State Tracking
# =============================================================================

class JobTracker:
    def __init__(self):
        self.current_job = None
        self.job_history = deque(maxlen=50)
        self.lock = threading.Lock()

    def update(self, job_id, status, progress=0, last_action="", error=None, metadata=None):
        with self.lock:
            job = {
                "job_id": job_id,
                "status": status,
                "progress": progress,
                "last_action": last_action,
                "error": error,
                "metadata": metadata or {},
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            self.current_job = job
            self.job_history.append(job)

    def get_state(self):
        with self.lock:
            return self.current_job.copy() if self.current_job else None

    def get_history(self, n=20):
        with self.lock:
            return list(self.job_history)[-n:]

    def send_update(self):
        state = self.get_state()
        if not state:
            return
        send({
            "type": "inspect",
            "source": SOURCE_NAME,
            "platform": PLATFORM,
            "version": VERSION,
            "variables": {"current_job": state, "job_history": self.get_history()},
        })


# =============================================================================
# Public API
# =============================================================================

job_tracker = JobTracker()
stdout_capture = None
stderr_capture = None


def send_log(level, message, context=None):
    send({
        "type": "log",
        "source": SOURCE_NAME,
        "platform": PLATFORM,
        "version": VERSION,
        "level": level,
        "message": message,
        "context": context or {},
    })


def send_error(title, stack_trace="", context=None):
    send({
        "type": "error",
        "source": SOURCE_NAME,
        "platform": PLATFORM,
        "version": VERSION,
        "title": title,
        "stackTrace": stack_trace,
        "context": context or {},
    })


def update_job(job_id, status, progress=0, last_action="", error=None, metadata=None):
    job_tracker.update(job_id, status, progress, last_action, error, metadata)
    job_tracker.send_update()
    if error:
        send_error("Job {} failed: {}".format(job_id, error), context={
            "job_id": job_id, "status": status, "last_action": last_action,
            **(metadata or {}),
        })


def capture_image_gen(job_id, model, params, result=None, error=None, duration_s=None):
    context = {"job_id": job_id, "model": model, "params": params, "duration_s": duration_s}
    if result:
        context["result"] = result
        send_log("info", "Image gen complete: {} ({:.1f}s)".format(model, duration_s or 0), context)
    if error:
        context["error"] = error
        send_error("Image gen failed: {} — {}".format(model, error), context=context)
    update_job(job_id, "completed" if result else "failed",
               progress=100 if result else 0,
               last_action="generate:{}".format(model),
               error=error, metadata=context)


# =============================================================================
# Action-Based Command Execution
# =============================================================================

def execute_comfy_api_action(action_id, payload=None, timeout=30):
    """Execute ComfyUI API actions that need special handling."""
    start = time.time()
    comfy_url = "http://127.0.0.1:8188"

    try:
        if action_id == "comfy_queue_prompt":
            if not payload or "prompt" not in payload:
                return {"output": "[Error: workflow JSON required in payload.prompt]", "exit_code": -1, "duration_ms": 0}
            resp = requests.post("{}/prompt".format(comfy_url), json={"prompt": payload["prompt"]}, timeout=timeout)
            duration_ms = int((time.time() - start) * 1000)
            return {"output": resp.text[:50000], "exit_code": 0 if resp.ok else 1, "duration_ms": duration_ms}

        elif action_id == "comfy_save_workflow":
            if not payload or "filename" not in payload or "workflow" not in payload:
                return {"output": "[Error: filename and workflow required]", "exit_code": -1, "duration_ms": 0}
            wf_dir = _get_workflow_dir()
            os.makedirs(wf_dir, exist_ok=True)
            filename = payload["filename"]
            if not filename.endswith(".json"):
                filename += ".json"
            # Sanitize filename
            filename = re.sub(r'[^\w\-_.]', '_', filename)
            filepath = os.path.join(wf_dir, filename)
            with open(filepath, "w") as f:
                json.dump(payload["workflow"], f, indent=2)
            duration_ms = int((time.time() - start) * 1000)
            return {"output": "Saved workflow to {}".format(filepath), "exit_code": 0, "duration_ms": duration_ms}

        elif action_id == "comfy_delete_workflow":
            if not payload or "filename" not in payload:
                return {"output": "[Error: filename required]", "exit_code": -1, "duration_ms": 0}
            wf_dir = _get_workflow_dir()
            filename = payload["filename"]
            if not filename.endswith(".json"):
                filename += ".json"
            filename = re.sub(r'[^\w\-_.]', '_', filename)
            filepath = os.path.join(wf_dir, filename)
            if os.path.exists(filepath):
                os.remove(filepath)
                duration_ms = int((time.time() - start) * 1000)
                return {"output": "Deleted {}".format(filepath), "exit_code": 0, "duration_ms": duration_ms}
            duration_ms = int((time.time() - start) * 1000)
            return {"output": "[File not found: {}]".format(filepath), "exit_code": 1, "duration_ms": duration_ms}

        elif action_id == "comfy_get_workflow":
            if not payload or "filename" not in payload:
                return {"output": "[Error: filename required]", "exit_code": -1, "duration_ms": 0}
            wf_dir = _get_workflow_dir()
            filename = payload["filename"]
            if not filename.endswith(".json"):
                filename += ".json"
            filepath = os.path.join(wf_dir, filename)
            if os.path.exists(filepath):
                with open(filepath, "r") as f:
                    content = f.read()
                duration_ms = int((time.time() - start) * 1000)
                return {"output": content[:50000], "exit_code": 0, "duration_ms": duration_ms}
            duration_ms = int((time.time() - start) * 1000)
            return {"output": "[File not found: {}]".format(filepath), "exit_code": 1, "duration_ms": duration_ms}

        elif action_id == "comfy_list_workflows":
            workflows = []
            wf_dir = _get_workflow_dir()
            if os.path.isdir(wf_dir):
                for f in sorted(os.listdir(wf_dir)):
                    if f.endswith(".json"):
                        fpath = os.path.join(wf_dir, f)
                        size = os.path.getsize(fpath)
                        mtime = datetime.fromtimestamp(os.path.getmtime(fpath)).isoformat()
                        workflows.append({"name": f, "size_bytes": size, "modified": mtime})
            duration_ms = int((time.time() - start) * 1000)
            return {"output": json.dumps({"workflows": workflows, "directory": wf_dir}, indent=2), "exit_code": 0, "duration_ms": duration_ms}

        elif action_id == "comfy_object_info":
            resp = requests.get("{}/object_info".format(comfy_url), timeout=timeout)
            duration_ms = int((time.time() - start) * 1000)
            # Summarize — full object_info is huge
            if resp.ok:
                data = resp.json()
                nodes = sorted(data.keys())
                summary = {"total_nodes": len(nodes), "nodes": nodes[:200]}
                return {"output": json.dumps(summary, indent=2), "exit_code": 0, "duration_ms": duration_ms}
            return {"output": resp.text[:5000], "exit_code": 1, "duration_ms": duration_ms}

        return {"output": "[Unknown ComfyUI action: {}]".format(action_id), "exit_code": -1, "duration_ms": 0}

    except requests.exceptions.ConnectionError:
        duration_ms = int((time.time() - start) * 1000)
        return {"output": "[ComfyUI API not responding at {}]".format(comfy_url), "exit_code": 1, "duration_ms": duration_ms}
    except Exception as e:
        duration_ms = int((time.time() - start) * 1000)
        return {"output": "[Error: {}]".format(e), "exit_code": -1, "duration_ms": duration_ms}


def _get_workflow_dir():
    """Find the first existing workflow directory or create the primary one."""
    for d in COMFY_WORKFLOW_DIRS:
        if os.path.isdir(d):
            return d
    # Create primary
    os.makedirs(COMFY_WORKFLOW_DIR, exist_ok=True)
    return COMFY_WORKFLOW_DIR


def execute_action(action_id, timeout=30, payload=None):
    """Execute a predefined action and return result."""
    # Handle ComfyUI API actions specially
    if action_id in COMFY_API_ACTIONS:
        return execute_comfy_api_action(action_id, payload=payload, timeout=timeout)

    cmd = ACTION_COMMANDS.get(action_id)
    if not cmd:
        return {
            "output": "[Unknown action: {}]".format(action_id),
            "exit_code": -1,
            "duration_ms": 0,
        }

    start = time.time()
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        duration_ms = int((time.time() - start) * 1000)
        output = result.stdout
        if result.stderr:
            output += ("\n--- stderr ---\n" + result.stderr) if output else result.stderr
        return {
            "output": output.strip()[:50000],
            "exit_code": result.returncode,
            "duration_ms": duration_ms,
        }
    except subprocess.TimeoutExpired:
        duration_ms = int((time.time() - start) * 1000)
        return {
            "output": "[Action timed out after {}s]".format(timeout),
            "exit_code": -1,
            "duration_ms": duration_ms,
        }
    except Exception as e:
        duration_ms = int((time.time() - start) * 1000)
        return {
            "output": "[Execution error: {}]".format(e),
            "exit_code": -1,
            "duration_ms": duration_ms,
        }


def poll_and_execute_commands():
    """Poll for pending actions and execute them."""
    if not POLL_COMMANDS_URL:
        return

    try:
        resp = session.post(
            POLL_COMMANDS_URL,
            json={"action": "poll", "source_name": SOURCE_NAME},
            headers=HEADERS,
            timeout=10,
        )
        if resp.status_code != 200:
            return

        data = resp.json()
        commands = data.get("commands", [])
        settings = data.get("settings") or {}
        max_timeout = settings.get("max_timeout_s", 30)

        for cmd_entry in commands:
            cmd_id = cmd_entry["id"]
            cmd_str = cmd_entry["command"]

            # Only accept ACTION: prefixed commands
            if not cmd_str.startswith("ACTION:"):
                logger.warning("Rejected non-action command: %s", cmd_str[:50])
                session.post(
                    POLL_COMMANDS_URL,
                    json={
                        "action": "result",
                        "command_id": cmd_id,
                        "output": "[REJECTED] Only predefined actions are allowed. Raw commands are disabled.",
                        "exit_code": -2,
                        "duration_ms": 0,
                        "source_name": SOURCE_NAME,
                    },
                    headers=HEADERS,
                    timeout=10,
                )
                continue

            action_id = cmd_str.replace("ACTION:", "", 1)
            payload = None
            # Check for embedded payload: ACTION:action_id:{json}
            if ":" in action_id:
                parts = action_id.split(":", 1)
                action_id = parts[0]
                try:
                    payload = json.loads(parts[1])
                except (json.JSONDecodeError, IndexError):
                    pass
            
            if action_id not in ACTION_COMMANDS and action_id not in COMFY_API_ACTIONS:
                logger.warning("Unknown action: %s", action_id)
                session.post(
                    POLL_COMMANDS_URL,
                    json={
                        "action": "result",
                        "command_id": cmd_id,
                        "output": "[REJECTED] Unknown action: {}".format(action_id),
                        "exit_code": -2,
                        "duration_ms": 0,
                        "source_name": SOURCE_NAME,
                    },
                    headers=HEADERS,
                    timeout=10,
                )
                continue

            logger.info("Executing action: %s (id=%s...)", action_id, cmd_id[:8])

            # Claim
            session.post(
                POLL_COMMANDS_URL,
                json={"action": "claim", "command_id": cmd_id},
                headers=HEADERS,
                timeout=10,
            )

            # Execute the mapped command
            result = execute_action(action_id, timeout=min(max_timeout, 60), payload=payload)
            logger.info("Action %s completed: exit_code=%s (%sms)", action_id, result["exit_code"], result["duration_ms"])

            # Report result
            session.post(
                POLL_COMMANDS_URL,
                json={
                    "action": "result",
                    "command_id": cmd_id,
                    "output": result["output"],
                    "exit_code": result["exit_code"],
                    "duration_ms": result["duration_ms"],
                    "source_name": SOURCE_NAME,
                },
                headers=HEADERS,
                timeout=10,
            )

            # Log execution
            send_log(
                "info" if result["exit_code"] == 0 else "warn",
                "[action] {} -> exit {} ({}ms)".format(action_id, result["exit_code"], result["duration_ms"]),
                {"action": action_id, "exit_code": result["exit_code"], "command_id": cmd_id},
            )

    except Exception as e:
        logger.debug("Command poll error: %s", e)


# =============================================================================
# PM2 Log Tracker (prevents re-sending same lines)
# =============================================================================

class PM2LogTracker:
    """Tracks which PM2 log lines have been sent to prevent duplicates."""
    def __init__(self):
        self._seen_hashes = deque(maxlen=1000)

    def get_new_errors(self, pm2_output):
        """Return only error lines that haven't been seen before."""
        new_errors = []
        for line in pm2_output.split("\n"):
            lower = line.lower()
            if any(kw in lower for kw in ["error", "exception", "failed", "crash", "enoent", "eacces", "killed"]):
                line_hash = hash(line.strip()[:200])
                if line_hash not in self._seen_hashes:
                    self._seen_hashes.append(line_hash)
                    new_errors.append(line.strip()[:500])
        return new_errors


pm2_log_tracker = PM2LogTracker()


# =============================================================================
# Main Loop
# =============================================================================

def main():
    global stdout_capture, stderr_capture

    stdout_capture = StreamCapture(sys.stdout, "info")
    stderr_capture = StreamCapture(sys.stderr, "error")
    sys.stdout = stdout_capture
    sys.stderr = stderr_capture

    logger.info("debugger.help Agent v%s — Action-Based Execution", VERSION)
    logger.info("Source: %s | GPU: %s | Docker: %s", SOURCE_NAME, "yes" if GPU_AVAILABLE else "no", "yes" if DOCKER_AVAILABLE else "no")
    logger.info("Interval: %ss | Endpoint: %s", INTERVAL, INGEST_URL)
    logger.info("Registered actions: %s", ", ".join(sorted(ACTION_COMMANDS.keys())))

    # Start file watchers — exclude agent's own log files
    watch_files = list(WATCH_LOG_FILES)
    pm2_log_dir = os.path.expanduser("~/.pm2/logs")
    if os.path.isdir(pm2_log_dir):
        pm2_logs = glob.glob(os.path.join(pm2_log_dir, "*.log"))
        # Exclude the debugger agent's own log files to prevent feedback loop
        pm2_logs = [f for f in pm2_logs if "debugger-agent" not in os.path.basename(f).lower()
                    and "debugger_agent" not in os.path.basename(f).lower()]
        watch_files.extend(pm2_logs)
        logger.info("Watching %d pm2 log files (excluded agent logs)", len(pm2_logs))

    if watch_files:
        watcher = LogFileWatcher(watch_files)
        watcher.start()
        logger.info("File watcher started for %d files", len(watch_files))

    # Initial connection
    send({"type": "heartbeat", "source": SOURCE_NAME, "platform": PLATFORM, "version": VERSION})
    send_log("info", "Agent v{} started on {}".format(VERSION, socket.gethostname()), {
        "hostname": socket.gethostname(),
        "python_version": sys.version,
        "gpu_available": GPU_AVAILABLE,
        "docker_available": DOCKER_AVAILABLE,
        "pid": os.getpid(),
        "gpu_driver": GPU_DRIVER_VERSION,
        "cuda_version": GPU_CUDA_VERSION,
        "available_actions": list(ACTION_COMMANDS.keys()),
    })

    # Send initial deep snapshot
    try:
        pkgs = get_installed_packages()
        send({
            "type": "inspect",
            "source": SOURCE_NAME,
            "platform": PLATFORM,
            "version": VERSION,
            "variables": {"installed_packages": pkgs},
        })
    except Exception:
        pass

    tick = 0
    consecutive_failures = 0

    while True:
        try:
            # Metrics every tick
            metrics = collect_full_metrics()
            ok = send({
                "type": "metric",
                "source": SOURCE_NAME,
                "platform": PLATFORM,
                "version": VERSION,
                **metrics,
            })

            if ok:
                consecutive_failures = 0
            else:
                consecutive_failures += 1

            if consecutive_failures > 5:
                backoff = min(consecutive_failures * 5, 60)
                logger.warning("Connection issues. Backing off %ss...", backoff)
                time.sleep(backoff)
                send({"type": "heartbeat", "source": SOURCE_NAME, "platform": PLATFORM, "version": VERSION})
                consecutive_failures = 0
                continue

            # Deep snapshot every ~1 min
            if tick % 6 == 0:
                snapshot = collect_deep_snapshot()
                send({
                    "type": "inspect",
                    "source": SOURCE_NAME,
                    "platform": PLATFORM,
                    "version": VERSION,
                    "variables": snapshot,
                })

            # PM2 logs check every ~30s (with deduplication)
            if tick % 3 == 0:
                pm2_logs = get_pm2_logs(50)
                if pm2_logs:
                    new_errors = pm2_log_tracker.get_new_errors(pm2_logs)
                    for line in new_errors[:5]:  # Max 5 new errors per check
                        send_log("error", "[pm2] {}".format(line), {"capturedFrom": "pm2_logs"})

            # System logs check every ~2 min
            if tick % 12 == 0:
                sys_logs = get_system_logs()
                if sys_logs:
                    send({
                        "type": "inspect",
                        "source": SOURCE_NAME,
                        "platform": PLATFORM,
                        "version": VERSION,
                        "variables": {"system_logs": sys_logs},
                    })

            # SSL cert check every ~10 min
            if tick % 60 == 0 and SSL_CHECK_DOMAINS:
                ssl_results = check_ssl_certs()
                for r in ssl_results:
                    if r.get("warning") or r.get("error"):
                        days = r.get("days_left")
                        detail = r.get("error") or "{} days left".format(days)
                        send_log("warn", "SSL cert issue: {} — {}".format(r.get("domain"), detail), r)
                send({
                    "type": "inspect",
                    "source": SOURCE_NAME,
                    "platform": PLATFORM,
                    "version": VERSION,
                    "variables": {"ssl_certs": ssl_results},
                })

            # GPU warnings every ~30s (only when thresholds exceeded)
            if GPU_AVAILABLE and tick % 3 == 0:
                gpu = get_gpu_metrics()
                gpus = gpu.get("gpus", [])
                for g in gpus:
                    if g.get("temp_c", 0) > 85:
                        send_log("warn", "GPU {} temperature critical: {}C".format(g["index"], g["temp_c"]), g)
                    if g.get("vram_pct", 0) > 90:
                        send_log("warn", "GPU {} VRAM critical: {}% ({}/{} GB)".format(
                            g["index"], g["vram_pct"], g["vram_used_gb"], g["vram_total_gb"]), g)
                    throttle = g.get("throttle_reasons", [])
                    if throttle and throttle != ["none"] and throttle != ["idle"]:
                        send_log("warn", "GPU {} throttling: {}".format(g["index"], ", ".join(throttle)), g)

            # Heartbeat every ~5 min
            if tick % 30 == 0 and tick > 0:
                send({"type": "heartbeat", "source": SOURCE_NAME, "platform": PLATFORM, "version": VERSION})

            # Packages update every ~30 min
            if tick % 180 == 0 and tick > 0:
                pkgs = get_installed_packages()
                send({
                    "type": "inspect",
                    "source": SOURCE_NAME,
                    "platform": PLATFORM,
                    "version": VERSION,
                    "variables": {"installed_packages": pkgs},
                })

            # Poll for remote actions every tick
            poll_and_execute_commands()

            # Flush captured stdout/stderr
            if stdout_capture:
                stdout_capture.flush_pending()
            if stderr_capture:
                stderr_capture.flush_pending()

            tick += 1
            time.sleep(INTERVAL)

        except KeyboardInterrupt:
            send_log("info", "Agent shutting down gracefully")
            logger.info("Shutting down...")
            sys.stdout = stdout_capture.original
            sys.stderr = stderr_capture.original
            break
        except Exception as e:
            logger.error("Main loop error: %s", e)
            send_error(str(e), traceback.format_exc())
            time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
