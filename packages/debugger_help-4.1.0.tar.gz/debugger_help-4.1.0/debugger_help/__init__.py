"""debugger.help VPS Agent — Deep system monitoring + ComfyUI workflow management."""
__version__ = "4.1.0"
