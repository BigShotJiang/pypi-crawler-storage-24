from __future__ import annotations
import random

from .config import RetryConfig


def compute_delay(config: RetryConfig, attempt: int) -> float:
    """
    Compute sleep delay for a 1-based attempt number.
    attempt=1 means first failure before second try.
    """
    if config.backoff == "fixed":
        base = config.delay
    elif config.backoff == "linear":
        base = config.delay * attempt
    else:  # exponential
        base = config.delay * (2 ** (attempt - 1))

    if config.max_delay is not None:
        base = min(base, config.max_delay)

    if config.jitter > 0:
        base += random.uniform(0, config.jitter)

    return max(0.0, base)
