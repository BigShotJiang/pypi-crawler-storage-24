import logging

from retryxpy import retry


def test_logger_integration(caplog):
    caplog.set_level(logging.WARNING)
    logger = logging.getLogger("retryxpy-test")

    state = {"count": 0}

    @retry(
        max_attempts=3,
        delay=0,
        logger=logger,
        exceptions=(ValueError,),
    )
    def flaky():
        state["count"] += 1
        if state["count"] < 3:
            raise ValueError("temporary")
        return "ok"

    result = flaky()

    assert result == "ok"
    assert "Retrying flaky attempt 1/3" in caplog.text
    assert "Retrying flaky attempt 2/3" in caplog.text
