from retryxpy import retry


def test_on_retry_hook_called():
    events = []

    def hook(state):
        events.append(
            {
                "attempt": state.attempt,
                "delay": state.delay,
                "function_name": state.function_name,
                "exception_type": (
                    type(state.exception).__name__ if state.exception else None
                ),
                "result": state.result,
            }
        )

    counter = {"count": 0}

    @retry(max_attempts=3, delay=0, on_retry=hook)
    def flaky():
        counter["count"] += 1
        if counter["count"] < 3:
            raise ValueError("temporary")
        return "done"

    result = flaky()

    assert result == "done"
    assert len(events) == 2
    assert events[0]["attempt"] == 1
    assert events[1]["attempt"] == 2
    assert events[0]["function_name"] == "flaky"
