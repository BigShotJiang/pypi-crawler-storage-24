import pytest

from retryxpy import retry


def test_sync_success_after_retries():
    state = {"count": 0}

    @retry(max_attempts=3, delay=0)
    def flaky():
        state["count"] += 1
        if state["count"] < 3:
            raise ValueError("temporary")
        return "ok"

    result = flaky()

    assert result == "ok"
    assert state["count"] == 3


def test_sync_raises_after_max_attempts():
    state = {"count": 0}

    @retry(max_attempts=2, delay=0, exceptions=(ValueError,))
    def always_fail():
        state["count"] += 1
        raise ValueError("bad")

    with pytest.raises(ValueError):
        always_fail()

    assert state["count"] == 2


def test_sync_does_not_retry_unlisted_exception():
    state = {"count": 0}

    @retry(max_attempts=5, delay=0, exceptions=(ValueError,))
    def fail_with_type_error():
        state["count"] += 1
        raise TypeError("wrong type")

    with pytest.raises(TypeError):
        fail_with_type_error()

    assert state["count"] == 1
