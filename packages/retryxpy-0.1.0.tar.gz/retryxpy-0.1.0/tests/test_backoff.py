from retryxpy.config import RetryConfig
from retryxpy.utils import compute_delay


def test_fixed_backoff():
    cfg = RetryConfig(max_attempts=3, delay=2, backoff="fixed")
    assert compute_delay(cfg, 1) == 2
    assert compute_delay(cfg, 2) == 2


def test_linear_backoff():
    cfg = RetryConfig(max_attempts=3, delay=2, backoff="linear")
    assert compute_delay(cfg, 1) == 2
    assert compute_delay(cfg, 2) == 4
    assert compute_delay(cfg, 3) == 6


def test_exponential_backoff():
    cfg = RetryConfig(max_attempts=4, delay=2, backoff="exponential")
    assert compute_delay(cfg, 1) == 2
    assert compute_delay(cfg, 2) == 4
    assert compute_delay(cfg, 3) == 8


def test_max_delay_cap():
    cfg = RetryConfig(max_attempts=4, delay=2, backoff="exponential", max_delay=5)
    assert compute_delay(cfg, 1) == 2
    assert compute_delay(cfg, 2) == 4
    assert compute_delay(cfg, 3) == 5
