from retryxpy import retry


def test_before_and_after_retry_hooks_called():
    events = []

    def before_hook(state):
        events.append(("before", state.attempt, state.function_name))

    def after_hook(state):
        events.append(("after", state.attempt, state.function_name))

    counter = {"count": 0}

    @retry(
        max_attempts=3,
        delay=0,
        before_retry=before_hook,
        after_retry=after_hook,
    )
    def flaky():
        counter["count"] += 1
        if counter["count"] < 3:
            raise ValueError("temporary")
        return "done"

    result = flaky()

    assert result == "done"
    assert events == [
        ("before", 1, "flaky"),
        ("after", 1, "flaky"),
        ("before", 2, "flaky"),
        ("after", 2, "flaky"),
    ]
