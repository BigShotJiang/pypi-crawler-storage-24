import pytest

from retryxpy import retry


@pytest.mark.asyncio
async def test_async_success_after_retries():
    state = {"count": 0}

    @retry(max_attempts=4, delay=0)
    async def flaky():
        state["count"] += 1
        if state["count"] < 3:
            raise RuntimeError("temporary")
        return 42

    result = await flaky()

    assert result == 42
    assert state["count"] == 3


@pytest.mark.asyncio
async def test_async_raises_after_max_attempts():
    state = {"count": 0}

    @retry(max_attempts=2, delay=0, exceptions=(RuntimeError,))
    async def always_fail():
        state["count"] += 1
        raise RuntimeError("bad")

    with pytest.raises(RuntimeError):
        await always_fail()

    assert state["count"] == 2
