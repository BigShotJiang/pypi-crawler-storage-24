import time
import pytest

from retryxpy import RetryError, retry


def test_timeout_aware_retry_stops():
    @retry(
        max_attempts=10,
        delay=0.05,
        timeout=0.12,
        exceptions=(ValueError,),
    )
    def always_fail():
        raise ValueError("nope")

    with pytest.raises(RetryError) as exc:
        always_fail()

    assert "exceeded retry timeout" in str(exc.value)


@pytest.mark.asyncio
async def test_async_timeout_aware_retry_stops():
    import asyncio

    @retry(
        max_attempts=10,
        delay=0.05,
        timeout=0.12,
        exceptions=(RuntimeError,),
    )
    async def always_fail_async():
        raise RuntimeError("nope")

    with pytest.raises(RetryError) as exc:
        await always_fail_async()

    assert "exceeded retry timeout" in str(exc.value)
