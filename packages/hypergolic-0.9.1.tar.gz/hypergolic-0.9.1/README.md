# Hypergolic

A local, native AI coding assistant. Hypergolic runs as a desktop app on your machine, giving you a chat interface backed by an agentic loop with full access to your filesystem, shell, and git history.

## Key Features

- **Agentic tool loop** — Files, shell, git, browser automation, and more. Dangerous operations require explicit approval.
- **Persistent knowledge graph** — Accumulates corrections, preferences, and project context in a local SQLite database.
- **Layered system prompt** — Compose behavior from a base prompt, user prompt, and per-project prompt.
- **Session continuity** — Conversations persist and are resumable.
- **Skills and roles** — Activate specialized expertise (debugging, frontend, product thinking, etc.) on demand.
- **MCP integration** — Connect external tool servers via Model Context Protocol.
- **Custom tools** — Wrap any shell command as a tool the assistant can invoke.

## Quick Start

```bash
# Install dependencies
curl -LsSf https://astral.sh/uv/install.sh | sh
brew install ripgrep

# Install Hypergolic
uv tool install hypergolic

# Set API credentials
export HYPERGOLIC_API_KEY="your-api-key"
export HYPERGOLIC_BASE_URL="https://api.anthropic.com"

# Launch (from any git repo)
h
```

See the [Installation Guide](docs/installation.md) for full details.

## Documentation

- [Installation](docs/installation.md) — Requirements, install, environment setup
- [Getting Started](docs/getting-started.md) — First launch, interface overview, keyboard shortcuts
- [Configuration](docs/configuration.md) — Config files, system prompt assembly, user and project prompts
- [Tools](docs/tools.md) — Built-in tools, approval system, custom tools
- [Advanced Usage](docs/advanced-usage.md) — Custom tools, MCP servers, skills, roles, knowledge graph, browser automation

## Development

```bash
# Launch with auto UI rebuilds
HYPERGOLIC_DEV_MODE=true uv run h

# Run the full validation suite
./bin/validate

# Run UI dev server separately (hot reload)
cd ui && pnpm run dev
```

The backend is Python (FastAPI + SQLAlchemy + Alembic) and the frontend is React (Redux Toolkit + Ant Design + React Router).

## License

MIT
