from pathlib import Path
from typing import Any

from sqlalchemy import select

from hypergolic.config.settings import _load_user_config, load_project_config, load_user_project_config
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill

BUILT_IN_SKILLS: list[dict[str, Any]] = [
    {
        "id": "tool-builder",
        "name": "Tool Building",
        "description": "Audit a project and build custom tools, scripts, and config to make the agent maximally effective",
        "prompt_path": str(Path(__file__).parent.parent / "prompts" / "skills" / "tool-builder.md"),
        "source": "built-in",
    },
    {
        "id": "hypergolic-expert",
        "name": "Hypergolic Expert",
        "description": "Navigate Hypergolic internals, advise on configuration, and proactively improve the user's setup over time",
        "prompt_path": str(Path(__file__).parent.parent / "prompts" / "skills" / "hypergolic-expert.md"),
        "source": "built-in",
    },
]

DEFAULT_ROLES: list[dict[str, Any]] = [
    {
        "id": "default",
        "name": "Default",
        "prompt_path": str(Path(__file__).parent.parent / "prompts" / "base_prompt.md"),
        "skills": [],
        "source": "built-in",
    },
    {
        "id": "reviewer",
        "name": "Code Review",
        "prompt_path": str(Path(__file__).parent.parent / "prompts" / "roles" / "reviewer.md"),
        "skills": [],
        "source": "built-in",
    },
]


def resolve_roles(project_path: Path | None = None) -> list[dict[str, Any]]:
    seen_ids: set[str] = set()
    roles: list[dict[str, Any]] = []

    for role in DEFAULT_ROLES:
        roles.append(role)
        seen_ids.add(role["id"])

    user_config = _load_user_config()
    for role in user_config.roles:
        if role.id not in seen_ids:
            roles.append({
                "id": role.id,
                "name": role.name,
                "prompt_path": str(Path(role.prompt_path).expanduser()),
                "skills": list(role.skills),
                "source": "user",
            })
            seen_ids.add(role.id)

    if project_path:
        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for role in user_project_config.roles:
                if role.id not in seen_ids:
                    roles.append({
                        "id": role.id,
                        "name": role.name,
                        "prompt_path": str(Path(role.prompt_path).expanduser()),
                        "skills": list(role.skills),
                        "source": "user-project",
                    })
                    seen_ids.add(role.id)

        project_config = load_project_config(project_path)
        for role in project_config.roles:
            if role.id not in seen_ids:
                roles.append({
                    "id": role.id,
                    "name": role.name,
                    "prompt_path": str((project_path / role.prompt_path).resolve()),
                    "skills": list(role.skills),
                    "source": "project",
                })
                seen_ids.add(role.id)

    return roles


def resolve_skills(project_path: Path | None = None) -> list[dict[str, Any]]:
    seen_ids: set[str] = set()
    skills: list[dict[str, Any]] = []

    for skill in BUILT_IN_SKILLS:
        skills.append(skill)
        seen_ids.add(skill["id"])

    user_config = _load_user_config()
    for skill in user_config.skills:
        if skill.id not in seen_ids:
            skills.append({
                "id": skill.id,
                "name": skill.name,
                "description": skill.description,
                "prompt_path": str(Path(skill.prompt_path).expanduser()),
                "source": "user",
            })
            seen_ids.add(skill.id)

    if project_path:
        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            for skill in user_project_config.skills:
                if skill.id not in seen_ids:
                    skills.append({
                        "id": skill.id,
                        "name": skill.name,
                        "description": skill.description,
                        "prompt_path": str(Path(skill.prompt_path).expanduser()),
                        "source": "user-project",
                    })
                    seen_ids.add(skill.id)

        project_config = load_project_config(project_path)
        for skill in project_config.skills:
            if skill.id not in seen_ids:
                skills.append({
                    "id": skill.id,
                    "name": skill.name,
                    "description": skill.description,
                    "prompt_path": str((project_path / skill.prompt_path).resolve()),
                    "source": "project",
                })
                seen_ids.add(skill.id)

    return skills


def get_skill_prompt_content(skill_id: str, project_path: Path | None = None) -> tuple[str, str] | None:
    """Returns (name, prompt_content) for a skill, or None if not found."""
    for skill in resolve_skills(project_path):
        if skill["id"] == skill_id:
            prompt_path = Path(skill["prompt_path"])
            if prompt_path.exists():
                content = prompt_path.read_text()
                return skill["name"], content
            return skill["name"], f"(Skill prompt file not found: {prompt_path})"
    return None


def get_active_skill_prompts(session_id: str, project_path: Path | None = None) -> list[tuple[str, str]]:
    with get_db() as db:
        active_ids = list(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
                .order_by(DBSessionSkill.created_at)
            ).scalars().all()
        )

    if not active_ids:
        return []

    all_skills = {s["id"]: s for s in resolve_skills(project_path)}
    results: list[tuple[str, str]] = []
    for sid in active_ids:
        skill = all_skills.get(sid)
        if not skill:
            continue
        prompt_path = Path(skill["prompt_path"])
        if prompt_path.exists():
            results.append((skill["name"], prompt_path.read_text()))
    return results
