from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from anthropic.types import MessageParam, ToolResultBlockParam, ToolUseBlock
from anthropic.types.message import Message

from hypergolic.mcptools.tool_bridge import execute_mcp_tool
from hypergolic.tools.approval import (
    RuleAction,
    get_effective_action,
)
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput

import logging

from anthropic.types.tool_result_block_param import Content

logger = logging.getLogger(__name__)

MAX_TOOL_OUTPUT_CHARS = 200_000


def _truncate_tool_output(output: ToolOutput, limit: int = MAX_TOOL_OUTPUT_CHARS) -> ToolOutput:
    total_chars = 0
    for block in output.content:
        if isinstance(block, dict) and block.get("type") == "text":
            total_chars += len(block.get("text", ""))

    if total_chars <= limit:
        return output

    truncated_content: list[Content] = []
    remaining = limit

    for block in output.content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text", "")
            if len(text) <= remaining:
                truncated_content.append(block)
                remaining -= len(text)
            elif remaining > 0:
                truncated_content.append({"type": "text", "text": text[:remaining]})
                remaining = 0
        else:
            truncated_content.append(block)

    truncated_content.append({
        "type": "text",
        "text": f"\n\n[Output truncated: {total_chars:,} chars exceeded {limit:,} char limit. Request smaller ranges or more specific queries.]",
    })

    logger.warning("Tool output truncated: %s chars -> %s char limit", total_chars, limit)

    return ToolOutput(content=truncated_content, is_error=output.is_error)


@dataclass
class ToolUseResult:
    message: MessageParam


@dataclass
class ApprovalRequest:
    tool_use_id: str
    tool_name: str
    tool_input: dict[str, Any]


@dataclass
class ApprovalResponse:
    approved: bool
    denial_reason: str | None = None


@dataclass
class UserQuestionRequest:
    tool_use_id: str
    question: str
    options: list[str] = field(default_factory=list)


@dataclass
class UserQuestionResponse:
    response: str


ApprovalCallback = Callable[[ApprovalRequest], Awaitable[ApprovalResponse]]
UserQuestionCallback = Callable[[UserQuestionRequest], Awaitable[UserQuestionResponse]]


async def _execute_tool(tool: Tool, raw_input: Any, session: Session) -> ToolOutput:
    try:
        parsed_input = tool.input.model_validate(raw_input)
        return await tool.call_tool(parsed_input, session)
    except Exception as e:
        logger.error("Tool '%s' failed: %s", tool.id, e, exc_info=True)
        return ToolOutput(
            content=[{"type": "text", "text": f"Error with tool call: {e}"}],
            is_error=True,
        )


async def handle_tool_use(
    agent_message: Message,
    tools: list[Tool],
    session: Session,
    approval_callback: ApprovalCallback | None = None,
    user_question_callback: UserQuestionCallback | None = None,
) -> ToolUseResult:
    tool_map = {tool.id: tool for tool in tools}
    tool_result_blocks: list[ToolResultBlockParam] = []

    for content in agent_message.content:
        if not isinstance(content, ToolUseBlock):
            continue

        tool = tool_map[content.name]

        if content.name == "ask_user" and user_question_callback:
            raw_input = content.input if isinstance(content.input, dict) else {}
            question = str(raw_input.get("question", ""))
            raw_options = raw_input.get("options")
            options = [str(o) for o in raw_options] if isinstance(raw_options, list) else []
            request = UserQuestionRequest(
                tool_use_id=content.id,
                question=question,
                options=options,
            )
            response = await user_question_callback(request)
            output = ToolOutput(
                content=[{"type": "text", "text": response.response}],
            )
            block = ToolResultBlockParam(
                tool_use_id=content.id,
                type="tool_result",
                content=output.content,
                is_error=output.is_error,
            )
            tool_result_blocks.append(block)
            continue

        tool_input = content.input if isinstance(content.input, dict) else {}
        action = get_effective_action(
            content.name, tool_input,
            project_id=session.project_id,
            session_id=session.id,
            project_path=session.project_path,
        )

        if action == RuleAction.DENY:
            output = ToolOutput(
                content=[{"type": "text", "text": "Tool call denied by approval rule."}],
                is_error=True,
            )
            block = ToolResultBlockParam(
                tool_use_id=content.id,
                type="tool_result",
                content=output.content,
                is_error=output.is_error,
            )
            tool_result_blocks.append(block)
            continue

        if action == RuleAction.REQUIRE_APPROVAL:
            if approval_callback:
                request = ApprovalRequest(
                    tool_use_id=content.id,
                    tool_name=content.name,
                    tool_input=tool_input,
                )
                response = await approval_callback(request)

                if not response.approved:
                    denial_text = "User denied tool call."
                    if response.denial_reason:
                        denial_text += f" Reason: {response.denial_reason}"
                    output = ToolOutput(
                        content=[{"type": "text", "text": denial_text}],
                        is_error=True,
                    )
                    block = ToolResultBlockParam(
                        tool_use_id=content.id,
                        type="tool_result",
                        content=output.content,
                        is_error=output.is_error,
                    )
                    tool_result_blocks.append(block)
                    continue

        if content.name.startswith("mcp_"):
            raw = content.input if isinstance(content.input, dict) else {}
            output = await execute_mcp_tool(content.name, raw)
        else:
            output = await _execute_tool(tool, content.input, session)

        output = _truncate_tool_output(output)

        block = ToolResultBlockParam(
            tool_use_id=content.id,
            type="tool_result",
            content=output.content,
            is_error=output.is_error,
        )
        tool_result_blocks.append(block)

    return ToolUseResult(
        message=MessageParam(role="user", content=tool_result_blocks),
    )
