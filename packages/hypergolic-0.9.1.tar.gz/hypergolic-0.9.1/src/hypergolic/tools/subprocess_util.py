import asyncio
import subprocess
from typing import Any, cast


async def run_subprocess(
    *args: Any, **kwargs: Any
) -> subprocess.CompletedProcess[str]:
    """Run subprocess.run in a thread to avoid blocking the event loop."""
    kwargs.setdefault("capture_output", True)
    kwargs.setdefault("text", True)
    result = await asyncio.to_thread(subprocess.run, *args, **kwargs)
    return cast(subprocess.CompletedProcess[str], result)
