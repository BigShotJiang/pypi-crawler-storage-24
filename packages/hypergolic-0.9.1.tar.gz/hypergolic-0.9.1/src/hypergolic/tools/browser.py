import base64
import subprocess
import shutil
from pathlib import Path
from typing import Literal, Optional

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput
from hypergolic.tools.subprocess_util import run_subprocess

RODNEY_BIN = "rodney"

BROWSER_COMMANDS = Literal[
    "start",
    "stop",
    "status",
    "help",
    "open",
    "back",
    "forward",
    "reload",
    "clear_cache",
    "url",
    "title",
    "text",
    "html",
    "attr",
    "pdf",
    "js",
    "click",
    "input",
    "clear",
    "file",
    "select",
    "submit",
    "hover",
    "focus",
    "wait",
    "waitload",
    "waitstable",
    "waitidle",
    "sleep",
    "screenshot",
    "screenshot_element",
    "pages",
    "page",
    "newpage",
    "closepage",
    "exists",
    "count",
    "visible",
    "assert",
    "ax_tree",
    "ax_find",
    "ax_node",
    "download",
]

COMMAND_TO_RODNEY = {
    "clear_cache": "clear-cache",
    "screenshot_element": "screenshot-el",
    "ax_tree": "ax-tree",
    "ax_find": "ax-find",
    "ax_node": "ax-node",
}


class BrowserInput(BaseModel):
    command: BROWSER_COMMANDS = Field(
        description="The browser command to execute.",
    )
    url: Optional[str] = Field(
        default=None,
        description="URL to navigate to.",
    )
    selector: Optional[str] = Field(
        default=None,
        description="CSS selector for element targeting.",
    )
    expression: Optional[str] = Field(
        default=None,
        description="JavaScript expression (for 'js', 'assert').",
    )
    text: Optional[str] = Field(
        default=None,
        description="Text to type, value to select, or expected value for assert.",
    )
    attribute: Optional[str] = Field(
        default=None,
        description="Attribute name to read (for 'attr').",
    )
    file_path: Optional[str] = Field(
        default=None,
        description="File path for screenshots, pdf, file input, or download.",
    )
    width: Optional[int] = Field(
        default=None,
        description="Viewport width in pixels (for 'screenshot').",
    )
    height: Optional[int] = Field(
        default=None,
        description="Viewport height in pixels (for 'screenshot').",
    )
    tab_index: Optional[int] = Field(
        default=None,
        description="Tab index (for 'page', 'closepage').",
    )
    hard: bool = Field(
        default=False,
        description="Bypass cache on reload.",
    )
    seconds: Optional[float] = Field(
        default=None,
        description="Number of seconds (for 'sleep').",
    )
    role: Optional[str] = Field(
        default=None,
        description="Accessibility role filter (for 'ax_find').",
    )
    name: Optional[str] = Field(
        default=None,
        description="Accessible name filter (for 'ax_find').",
    )
    depth: Optional[int] = Field(
        default=None,
        description="Tree depth limit (for 'ax_tree').",
    )
    json_output: bool = Field(
        default=False,
        description="Output as JSON (for 'ax_tree', 'ax_find', 'ax_node').",
    )
    message: Optional[str] = Field(
        default=None,
        description="Custom failure message (for 'assert').",
    )
    insecure: bool = Field(
        default=False,
        description="Ignore TLS errors (for 'start').",
    )
    use_local: bool = Field(
        default=True,
        description="Use directory-scoped session. False for global.",
    )


def _build_args(inp: BrowserInput) -> list[str]:
    rodney_cmd = COMMAND_TO_RODNEY.get(inp.command, inp.command)
    args = [rodney_cmd]

    if inp.command == "start":
        if inp.insecure:
            args.append("--insecure")
        return args

    if inp.command == "open":
        if not inp.url:
            return []
        args.append(inp.url)
        return args

    if inp.command == "reload":
        if inp.hard:
            args.append("--hard")
        return args

    if inp.command in ("click", "clear", "submit", "hover", "focus", "wait"):
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "input":
        if inp.selector:
            args.append(inp.selector)
        if inp.text is not None:
            args.append(inp.text)
        return args

    if inp.command == "text":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "html":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "attr":
        if inp.selector:
            args.append(inp.selector)
        if inp.attribute:
            args.append(inp.attribute)
        return args

    if inp.command == "js":
        if inp.expression:
            args.append(inp.expression)
        return args

    if inp.command == "assert":
        if inp.expression:
            args.append(inp.expression)
        if inp.text is not None:
            args.append(inp.text)
        if inp.message:
            args.extend(["--message", inp.message])
        return args

    if inp.command == "select":
        if inp.selector:
            args.append(inp.selector)
        if inp.text is not None:
            args.append(inp.text)
        return args

    if inp.command == "file":
        if inp.selector:
            args.append(inp.selector)
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "download":
        if inp.selector:
            args.append(inp.selector)
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "screenshot":
        if inp.width:
            args.extend(["-w", str(inp.width)])
        if inp.height:
            args.extend(["-h", str(inp.height)])
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "screenshot_element":
        if inp.selector:
            args.append(inp.selector)
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "pdf":
        if inp.file_path:
            args.append(inp.file_path)
        return args

    if inp.command == "page":
        if inp.tab_index is not None:
            args.append(str(inp.tab_index))
        return args

    if inp.command == "newpage":
        if inp.url:
            args.append(inp.url)
        return args

    if inp.command == "closepage":
        if inp.tab_index is not None:
            args.append(str(inp.tab_index))
        return args

    if inp.command == "sleep":
        if inp.seconds is not None:
            args.append(str(inp.seconds))
        return args

    if inp.command == "exists":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "count":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "visible":
        if inp.selector:
            args.append(inp.selector)
        return args

    if inp.command == "ax_tree":
        if inp.depth is not None:
            args.extend(["--depth", str(inp.depth)])
        if inp.json_output:
            args.append("--json")
        return args

    if inp.command == "ax_find":
        if inp.role:
            args.extend(["--role", inp.role])
        if inp.name:
            args.extend(["--name", inp.name])
        if inp.json_output:
            args.append("--json")
        return args

    if inp.command == "ax_node":
        if inp.selector:
            args.append(inp.selector)
        if inp.json_output:
            args.append("--json")
        return args

    return args


SCREENSHOT_MEDIA_TYPES: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _read_screenshot_block(file_path: str | None, default: str = "screenshot.png") -> dict | None:
    path = Path(file_path or default)
    if not path.is_file():
        return None
    media_type = SCREENSHOT_MEDIA_TYPES.get(path.suffix.lower())
    if not media_type:
        return None
    data = base64.standard_b64encode(path.read_bytes()).decode("ascii")
    return {
        "type": "image",
        "source": {
            "type": "base64",
            "media_type": media_type,
            "data": data,
        },
    }


async def run_browser(inp: BrowserInput, session: Session) -> ToolOutput:
    rodney = shutil.which(RODNEY_BIN)
    if not rodney:
        return ToolOutput(
            content=[{"type": "text", "text": f"'{RODNEY_BIN}' is not installed or not found in PATH. Install it with: uv tool install rodney"}],
            is_error=True,
        )

    sub_args = _build_args(inp)
    if not sub_args:
        return ToolOutput(
            content=[{"type": "text", "text": f"Missing required parameters for command '{inp.command}'."}],
            is_error=True,
        )

    cmd = [rodney]
    if inp.use_local:
        cmd.append("--local")
    else:
        cmd.append("--global")
    cmd.extend(sub_args)

    if inp.command == "help":
        cmd = [rodney, "--help"]
        try:
            result = await run_subprocess(cmd, timeout=10)
            text = result.stdout.strip() or result.stderr.strip() or "(no output)"
            return ToolOutput(content=[{"type": "text", "text": text}])
        except Exception as e:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error getting help: {e}"}],
                is_error=True,
            )

    timeout = 60 if inp.command in ("start", "stop", "screenshot", "screenshot_element", "pdf", "waitload", "waitstable", "waitidle", "download") else 30

    cwd = str(session.working_directory())

    try:
        result = await run_subprocess(
            cmd,
            timeout=timeout,
            cwd=cwd,
        )

        output_parts = []
        if result.stdout:
            output_parts.append(result.stdout.rstrip())
        if result.stderr:
            output_parts.append(f"STDERR: {result.stderr.rstrip()}")

        text = "\n".join(output_parts) if output_parts else "(no output)"

        # Rodney exit codes: 0=success, 1=check failed (not an error), 2=error
        is_error = result.returncode >= 2

        content: list = [{"type": "text", "text": text}]

        if not is_error and inp.command in ("screenshot", "screenshot_element"):
            image_block = _read_screenshot_block(inp.file_path)
            if image_block:
                content.append(image_block)

        return ToolOutput(
            content=content,
            is_error=is_error,
        )

    except subprocess.TimeoutExpired:
        return ToolOutput(
            content=[{"type": "text", "text": f"Browser command '{inp.command}' timed out after {timeout} seconds."}],
            is_error=True,
        )
    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error running browser command: {e}"}],
            is_error=True,
        )


BrowserTool = Tool(
    id="browser",
    name="Browser",
    description="Control a headless Chrome browser via rodney CLI. Call 'start' before other commands, 'help' for usage details.",
    strict=True,
    input=BrowserInput,
    call_tool=run_browser,
)
