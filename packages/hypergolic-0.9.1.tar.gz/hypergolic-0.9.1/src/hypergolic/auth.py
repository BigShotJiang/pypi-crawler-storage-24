import secrets

_token: str = ""


def init_token() -> str:
    global _token
    _token = secrets.token_urlsafe(32)
    return _token


def get_token() -> str:
    return _token


def verify_token(value: str) -> bool:
    if not _token:
        return False
    return secrets.compare_digest(value, _token)
