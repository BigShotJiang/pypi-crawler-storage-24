import asyncio
import logging
from typing import Any

from anthropic.types import MessageParam
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.enums import SessionStatus
from hypergolic.messages.conversation import create_message
from hypergolic.messages.types import BroadcastEvent, UserInterrupt
from hypergolic.providers import create_client
from hypergolic.schemas import Session
from hypergolic.sessions.operations import create_session
from hypergolic.sessions.status import set_session_status, set_session_status_and_broadcast
from hypergolic.tools.handlers import ApprovalRequest, ApprovalResponse, UserQuestionRequest, UserQuestionResponse
from hypergolic.websocket.helpers import (
    build_content_blocks,
    format_error_detail,
    persist_error_message,
    serialize_event,
)
from hypergolic.auth import verify_token
from hypergolic.websocket.schemas import (
    ApprovalResponseMessage,
    ConnectMessage,
    UserQuestionResponseMessage,
    parse_client_message,
)

logger = logging.getLogger(__name__)

router = APIRouter()

_client = None


def get_client():
    global _client
    if _client is None:
        _client = create_client()
    return _client


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    token = ws.cookies.get("h_token", "")
    if not verify_token(token):
        await ws.close(code=4003, reason="Unauthorized")
        return
    await ws.accept()
    session_tasks: dict[str, asyncio.Task[Any]] = {}
    session_cancel_events: dict[str, asyncio.Event] = {}
    pending_approvals: dict[str, asyncio.Future[ApprovalResponse]] = {}
    pending_questions: dict[str, asyncio.Future[UserQuestionResponse]] = {}

    async def _run_turn(request: ConnectMessage, cancel_event: asyncio.Event) -> None:
        client = get_client()
        session_id: str | None = None

        try:
            if request.session_id:
                with get_db() as db:
                    row = db.execute(
                        select(DBSession, DBProject.path)
                        .join(DBProject, DBSession.project_id == DBProject.id)
                        .where(DBSession.id == request.session_id)
                    ).one()
                    db_session, project_path = row
                    session = Session(
                        id=db_session.id,
                        model_tier=db_session.model_tier,
                        project_id=db_session.project_id,
                        project_path=project_path,
                        role=db_session.role,
                    )
            else:
                if not request.project_id:
                    raise ValueError("project_id is required to create a new session")
                session = create_session(project_id=request.project_id, model_tier=request.model_tier)

            session_id = session.id

            async def broadcast(event: BroadcastEvent) -> None:
                await ws.send_json(serialize_event(event))

            async def approval_callback(req: ApprovalRequest) -> ApprovalResponse:
                await set_session_status_and_broadcast(
                    session_id, SessionStatus.AWAITING_APPROVAL, broadcast,
                )
                await ws.send_json({
                    "type": "tool_approval_request",
                    "tool_use_id": req.tool_use_id,
                    "tool_name": req.tool_name,
                    "tool_input": req.tool_input,
                    "session_id": session_id,
                })

                loop = asyncio.get_event_loop()
                future: asyncio.Future[ApprovalResponse] = loop.create_future()
                pending_approvals[req.tool_use_id] = future

                try:
                    return await future
                finally:
                    pending_approvals.pop(req.tool_use_id, None)

            async def user_question_callback(req: UserQuestionRequest) -> UserQuestionResponse:
                await set_session_status_and_broadcast(
                    session_id, SessionStatus.AWAITING_USER, broadcast,
                )
                await ws.send_json({
                    "type": "user_question_request",
                    "tool_use_id": req.tool_use_id,
                    "question": req.question,
                    "options": req.options,
                    "session_id": session_id,
                })

                loop = asyncio.get_event_loop()
                future: asyncio.Future[UserQuestionResponse] = loop.create_future()
                pending_questions[req.tool_use_id] = future

                try:
                    return await future
                finally:
                    pending_questions.pop(req.tool_use_id, None)

            content_blocks = build_content_blocks(request)
            user_message: MessageParam = {
                "role": "user",
                "content": content_blocks,
            }

            await create_message(
                client=client,
                session=session,
                message=user_message,
                broadcast=broadcast,
                cancel_event=cancel_event,
                approval_callback=approval_callback,
                user_question_callback=user_question_callback,
            )

            set_session_status(session.id, SessionStatus.IDLE)
            await ws.send_json({"type": "done", "session_id": session.id})
        except UserInterrupt as ui:
            if session_id:
                set_session_status(session_id, SessionStatus.IDLE)
            try:
                payload: dict[str, Any] = {"type": "interrupted", "session_id": session_id}
                if ui.partial_text:
                    payload["partial_text"] = ui.partial_text
                await ws.send_json(payload)
            except Exception:
                logger.warning("Failed to send interrupt payload to WebSocket", exc_info=True)
        except Exception as exc:
            logger.error("Error during WebSocket turn", exc_info=True)
            detail = format_error_detail(exc)
            if session_id:
                set_session_status(session_id, SessionStatus.ERROR)
                persist_error_message(session_id, detail)
            try:
                await ws.send_json({"type": "error", "detail": detail, "session_id": session_id})
            except Exception:
                logger.warning("Failed to send error payload to WebSocket", exc_info=True)

    try:
        while True:
            raw = await ws.receive_json()
            msg = parse_client_message(raw)

            if isinstance(msg, ApprovalResponseMessage):
                future = pending_approvals.get(msg.tool_use_id)
                if future and not future.done():
                    future.set_result(ApprovalResponse(
                        approved=msg.approved,
                        denial_reason=msg.denial_reason,
                    ))
                continue

            if isinstance(msg, UserQuestionResponseMessage):
                q_future = pending_questions.get(msg.tool_use_id)
                if q_future and not q_future.done():
                    q_future.set_result(UserQuestionResponse(
                        response=msg.response,
                    ))
                continue

            request = msg

            target_session_id = request.session_id or "__new__"
            existing_task = session_tasks.get(target_session_id)
            if existing_task and not existing_task.done():
                existing_cancel = session_cancel_events.get(target_session_id)
                if existing_cancel:
                    existing_cancel.set()
                for fut in pending_approvals.values():
                    if not fut.done():
                        fut.cancel()
                pending_approvals.clear()
                for fut in pending_questions.values():
                    if not fut.done():
                        fut.cancel()
                pending_questions.clear()
                try:
                    await asyncio.wait_for(existing_task, timeout=0.5)
                except (asyncio.TimeoutError, Exception):
                    existing_task.cancel()
                    try:
                        await existing_task
                    except (asyncio.CancelledError, Exception):
                        logger.debug("Previous task cancelled during new turn", exc_info=True)

            new_cancel_event = asyncio.Event()
            session_cancel_events[target_session_id] = new_cancel_event
            task = asyncio.create_task(_run_turn(request, new_cancel_event))
            session_tasks[target_session_id] = task

            def _cleanup_task(t: asyncio.Task[Any], sid: str = target_session_id) -> None:
                if session_tasks.get(sid) is t:
                    session_tasks.pop(sid, None)
                    session_cancel_events.pop(sid, None)
            task.add_done_callback(_cleanup_task)
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception:
        logger.error("Unexpected WebSocket error", exc_info=True)
    finally:
        for fut in pending_approvals.values():
            if not fut.done():
                fut.cancel()
        pending_approvals.clear()
        for fut in pending_questions.values():
            if not fut.done():
                fut.cancel()
        pending_questions.clear()
        for sid, evt in session_cancel_events.items():
            evt.set()
        for sid, task in list(session_tasks.items()):
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    logger.debug("Task cancelled during WebSocket cleanup", exc_info=True)
        session_tasks.clear()
        session_cancel_events.clear()
        try:
            await ws.close()
        except Exception:
            logger.debug("Failed to close WebSocket cleanly", exc_info=True)
