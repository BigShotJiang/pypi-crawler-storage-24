from pathlib import Path

from fastapi import APIRouter
from sqlalchemy import select, delete as sa_delete, func

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession, DBMessage, DBProject, DBSessionSkill
from hypergolic.mcptools.tool_bridge import parse_mcp_tool_id
from hypergolic.prompts.builder import build_prompt_blocks
from hypergolic.schemas import Session
from hypergolic.sessions.operations import create_session
from hypergolic.sessions.schemas import (
    CreateSessionRequest,
    MessageResponse,
    PromptPartInfo,
    RoleInfo,
    SessionResponse,
    SkillInfo,
    ToolInfo,
)
from hypergolic.skills.resolver import resolve_roles, resolve_skills
from hypergolic.tools.approval import get_effective_action, RuleAction
from hypergolic.tools.tool_list import build_tools, get_tool_source

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


def _session_response(row: DBSession, project_name: str, message_count: int = 0) -> SessionResponse:
    return SessionResponse(
        id=row.id,
        model_tier=row.model_tier,
        project_id=row.project_id,
        project_name=project_name,
        role=row.role,
        status=row.status,
        created_at=row.created_at.isoformat(),
        updated_at=row.updated_at.isoformat(),
        message_count=message_count,
    )


@router.get("", response_model=list[SessionResponse])
def list_sessions(project_id: str | None = None):
    with get_db() as db:
        msg_count_subq = (
            select(
                DBMessage.session_id,
                func.count(DBMessage.id).label("msg_count"),
            )
            .group_by(DBMessage.session_id)
            .subquery()
        )
        stmt = (
            select(DBSession, DBProject.name, msg_count_subq.c.msg_count)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .outerjoin(msg_count_subq, DBSession.id == msg_count_subq.c.session_id)
            .order_by(
                (func.coalesce(msg_count_subq.c.msg_count, 0) == 0).desc(),
                DBSession.updated_at.desc(),
            )
        )
        if project_id:
            stmt = stmt.where(DBSession.project_id == project_id)
        rows = db.execute(stmt).all()
        return [
            _session_response(session, project_name, msg_count or 0)
            for session, project_name, msg_count in rows
        ]


@router.post("", response_model=SessionResponse)
def create_session_endpoint(req: CreateSessionRequest):
    session = create_session(project_id=req.project_id, model_tier=req.model_tier, role=req.role)
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.name)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session.id)
        ).one()
        return _session_response(row[0], row[1])


@router.get("/roles", response_model=list[RoleInfo])
def list_roles(project_id: str | None = None):
    project_path: Path | None = None
    if project_id:
        with get_db() as db:
            project = db.execute(
                select(DBProject).where(DBProject.id == project_id)
            ).scalar_one_or_none()
            if project:
                project_path = Path(project.path)

    roles = resolve_roles(project_path)
    return [RoleInfo(id=r["id"], name=r["name"], source=r["source"]) for r in roles]


@router.delete("/{session_id}")
def delete_session_endpoint(session_id: str):
    with get_db() as db:
        db.execute(
            sa_delete(DBSessionSkill).where(DBSessionSkill.session_id == session_id)
        )
        db.execute(
            sa_delete(DBMessage).where(DBMessage.session_id == session_id)
        )
        db.execute(
            sa_delete(DBSession).where(DBSession.id == session_id)
        )
    return {"status": "deleted"}


@router.get("/{session_id}/messages", response_model=list[MessageResponse])
def get_session_messages(session_id: str):
    with get_db() as db:
        rows = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .order_by(DBMessage.created_at)
        ).scalars().all()
        return [
            MessageResponse(
                id=r.id,
                session_id=r.session_id,
                role=r.role,
                content=r.content,
                model=r.model,
                stop_reason=r.stop_reason,
                usage=r.usage,
                truncated=r.truncated,
                created_at=r.created_at.isoformat(),
            )
            for r in rows
        ]



def _load_session(session_id: str) -> Session:
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.path)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session_id)
        ).one()
        db_session, project_path = row
        return Session(
            id=db_session.id,
            model_tier=db_session.model_tier,
            project_id=db_session.project_id,
            project_path=project_path,
            role=db_session.role,
        )


@router.get("/{session_id}/tools", response_model=list[ToolInfo])
def get_session_tools(session_id: str):
    session = _load_session(session_id)

    tools = build_tools(session=session)
    result = []
    for t in tools:
        mcp_parsed = parse_mcp_tool_id(t.id)
        action = get_effective_action(
            t.id, {}, project_id=session.project_id,
            session_id=session.id, project_path=session.project_path,
        )
        result.append(ToolInfo(
            id=t.id,
            name=t.name,
            description=t.description,
            source=get_tool_source(t.id),
            requires_approval=action != RuleAction.ALLOW,
            mcp_server=mcp_parsed[0] if mcp_parsed else None,
        ))
    return result


@router.get("/{session_id}/prompt", response_model=list[PromptPartInfo])
def get_session_prompt(session_id: str):
    session = _load_session(session_id)

    blocks = build_prompt_blocks(session)

    return [
        PromptPartInfo(
            source=block.source,
            content=block.text,
            token_estimate=len(block.text) // 4,
        )
        for block in blocks
    ]


@router.get("/{session_id}/skills", response_model=list[SkillInfo])
def get_session_skills(session_id: str):
    session = _load_session(session_id)
    project_path = session.working_directory()

    with get_db() as db:
        active_skill_ids = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
            ).scalars().all()
        )

    all_skills = resolve_skills(project_path)
    return [
        SkillInfo(
            id=s["id"],
            name=s["name"],
            description=s["description"],
            source=s["source"],
            active=s["id"] in active_skill_ids,
        )
        for s in all_skills
    ]

