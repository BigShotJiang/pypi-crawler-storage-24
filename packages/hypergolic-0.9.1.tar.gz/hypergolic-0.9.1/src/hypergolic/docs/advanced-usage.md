# Advanced Usage

## Custom Tools

Custom tools wrap shell commands and expose them to the assistant as first-class tools. Define them in `~/.agents/config.json` (user-level) or `<repo>/.agents/config.json` (project-level).

```json
{
  "tools": [
    {
      "id": "validate",
      "name": "validate",
      "description": "Run the project's full validation suite: type checking, linting, and tests.",
      "command": "./bin/validate",
      "working_directory": null,
      "timeout": 30,
      "requires_approval": false,
      "parameters": []
    }
  ]
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | Yes | Unique identifier, used as the tool name |
| `name` | string | Yes | Display name |
| `description` | string | Yes | Shown to the assistant so it knows when to use the tool |
| `command` | string | Yes | Shell command to execute. Parameters are substituted as `$param_name` |
| `working_directory` | string | No | Directory to run the command in. Defaults to session working directory |
| `timeout` | integer | No | Max seconds to wait (default: 30) |
| `requires_approval` | boolean | No | Whether to prompt for approval (default: false) |
| `parameters` | array | No | Parameters the assistant can pass to the command |

### Tool Parameters

Parameters let the assistant provide dynamic input to your command:

```json
{
  "parameters": [
    {
      "name": "file",
      "type": "string",
      "description": "File path to lint",
      "required": true
    }
  ]
}
```

In the command, reference parameters as `$file`. Supported types: `string`, `integer`, `boolean`.

## MCP Servers

Hypergolic supports the [Model Context Protocol](https://modelcontextprotocol.io/) for connecting external tool servers. MCP servers expose their own tools that the assistant can invoke.

### Configuration

Add MCP servers to `~/.agents/config.json` or `<repo>/.agents/config.json`:

```json
{
  "mcp_servers": {
    "my-server": {
      "transport": "stdio",
      "command": "npx",
      "args": ["-y", "@my-org/mcp-server"]
    }
  }
}
```

### Supported Transports

| Transport | Fields | Description |
|-----------|--------|-------------|
| `stdio` | `command`, `args`, `env` | Spawns a local process and communicates over stdin/stdout |
| `streamable_http` | `url`, `auth` | Connects to an HTTP endpoint |
| `sse` | `url`, `auth` | Connects via Server-Sent Events |

### Authentication

For HTTP-based transports, you can configure auth:

```json
{
  "my-server": {
    "transport": "streamable_http",
    "url": "https://my-server.example.com/mcp",
    "auth": {
      "type": "token",
      "token_env_var": "MY_SERVER_TOKEN",
      "token_header": "Authorization",
      "token_prefix": "Bearer"
    }
  }
}
```

The token is read from the specified environment variable at runtime.

### Managing MCP Servers

The assistant can use the `manage_mcp` tool to list, enable, and disable MCP servers during a session. You can also manage them from the UI.

## Skills

Skills are specialized prompt injections that shape the assistant's behavior for specific tasks. When activated, a skill's prompt is appended to the system prompt for the remainder of the session.

### Built-in Skills

| Skill | Description |
|-------|-------------|
| `tool-builder` | Audit a project and build custom tools, scripts, and config |
| `frontend-expert` | Deep expertise in React, TypeScript, CSS, and frontend architecture |
| `debugger` | Systematic bug hunting: reproduce, narrow scope, trace data flow, fix |
| `planner` | Decompose complex tasks into phased, actionable plans |
| `product-manager` | Product thinking: user value, scope, UX flows, trade-offs |
| `skill-builder` | Create and organize skills for the agent system |
| `qa-tester` | Systematic testing: functional, edge cases, integration, regression |
| `hypergolic-expert` | Navigate Hypergolic internals, advise on configuration, and improve user setup |

Activate skills during conversation by asking the assistant, or it may activate them on its own when appropriate.

### Custom Skills

Define custom skills in config:

```json
{
  "skills": [
    {
      "id": "security-reviewer",
      "name": "Security Review",
      "description": "Review code for security vulnerabilities and suggest mitigations",
      "prompt_path": "~/.agents/skills/security-reviewer.md"
    }
  ]
}
```

The `prompt_path` points to a Markdown file containing the skill's prompt. Write it as instructions the assistant should follow when that skill is active.

## Roles

Roles replace the base system prompt entirely. While skills are additive (they append to the prompt), a role changes the foundational behavior of the assistant.

### Built-in Roles

| Role | Description |
|------|-------------|
| `default` | The standard coding assistant role |
| `reviewer` | Focused on code review |

### Custom Roles

```json
{
  "roles": [
    {
      "id": "architect",
      "name": "System Architect",
      "prompt_path": "~/.agents/roles/architect.md",
      "skills": ["planner"]
    }
  ]
}
```

The `skills` field lists skill IDs that are automatically activated when this role is selected. The `prompt_path` is used *instead of* the default base prompt.

## Knowledge Graph

The knowledge graph is a persistent, tagged store of facts that the assistant builds over time.

### Scopes

| Scope | Injected When |
|-------|---------------|
| `universal` | Every session |
| `user` | Every session |
| `project` | When working in the matching project |
| `session` | Only in that session |

### Default Tags

`code-style` · `tooling` · `architecture` · `domain` · `team` · `workflow` · `debugging` · `preference` · `correction`

You can create custom tags and delete defaults from the Knowledge panel in the sidebar.

### How It Works

- When you correct the assistant or state a preference, it stores that as a knowledge item.
- Items are tagged and scoped.
- Relevant items are automatically retrieved and injected into the system prompt each turn.
- You can browse, create, edit, and delete items from the Knowledge panel (`⌘/Ctrl + 3`).

## Browser Automation

The `browser` tool provides headless Chrome automation via [rodney](https://github.com/nichochar/rodney). The assistant can:

- Navigate to URLs, click elements, fill forms
- Take screenshots and PDFs
- Execute JavaScript
- Read page text, HTML, and accessibility trees
- Wait for load states and network idle

Useful for testing web apps, scraping, and verifying UI changes.

## Session History

The assistant can search across past sessions using the `history` tool. This enables it to recall previous conversations, find how a problem was solved before, or continue interrupted work.
