from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/docs", tags=["docs"])

_DOCS_DIR = Path(__file__).resolve().parent

_DOC_ORDER = [
    "README.md",
    "installation.md",
    "getting-started.md",
    "configuration.md",
    "tools.md",
    "advanced-usage.md",
]


class DocEntry(BaseModel):
    slug: str
    title: str
    filename: str


class DocContent(BaseModel):
    slug: str
    title: str
    content: str


def _slug_from_filename(filename: str) -> str:
    if filename == "README.md":
        return "readme"
    return filename.removesuffix(".md")


def _title_from_content(content: str, filename: str) -> str:
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("# "):
            return stripped[2:].strip()
    if filename == "README.md":
        return "README"
    return filename.removesuffix(".md").replace("-", " ").title()


@router.get("/list", response_model=list[DocEntry])
def list_docs():
    entries: list[DocEntry] = []
    for filename in _DOC_ORDER:
        path = _DOCS_DIR / filename
        if path.is_file():
            content = path.read_text(errors="replace")
            entries.append(
                DocEntry(
                    slug=_slug_from_filename(filename),
                    title=_title_from_content(content, filename),
                    filename=filename,
                )
            )
    for path in sorted(_DOCS_DIR.glob("*.md")):
        if path.name not in _DOC_ORDER and path.name != "__init__.md":
            content = path.read_text(errors="replace")
            entries.append(
                DocEntry(
                    slug=_slug_from_filename(path.name),
                    title=_title_from_content(content, path.name),
                    filename=path.name,
                )
            )
    return entries


@router.get("/read/{slug}", response_model=DocContent)
def read_doc(slug: str):
    if slug == "readme":
        filename = "README.md"
    else:
        filename = f"{slug}.md"

    path = (_DOCS_DIR / filename).resolve()
    try:
        path.relative_to(_DOCS_DIR.resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Doc not found")

    content = path.read_text(errors="replace")
    return DocContent(
        slug=slug,
        title=_title_from_content(content, filename),
        content=content,
    )
