from setuptools import setup, find_packages

setup(
   name='meu_investimento_aula_fiap_jeff',
   version='0.1',
   packages=find_packages(),
   install_requires=[],
   author='Jefferson A P Silva',
   author_email='jeffkd35@gmail.com@gmail.com',
   description='Uma biblioteca para cálculos de investimentos.',
   url='https://github.com/jeffersonP/meu_investimento',
   python_requires='>=3.6',
)