# word_generator_mcp.py
# 基于 MCP Python SDK 开发

import os
import json
import uuid
import datetime

from mcp.server import Server
from mcp.types import Tool, TextContent
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

app = Server("word-generator")

@app.list_tools()
async def list_tools():
    return [
        Tool(
            name="generate_bid_document",
            description="根据投标书结构化内容生成Word格式(.docx)的投标响应文件，返回OSS下载链接",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_name": {
                        "type": "string",
                        "description": "招标项目名称"
                    },
                    "document_content": {
                        "type": "object",
                        "description": "投标书各章节内容的JSON结构"
                    }
                },
                "required": ["project_name", "document_content"]
            }
        )
    ]

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "generate_bid_document":
        import oss2

        doc = Document()
        style = doc.styles['Normal']
        style.font.name = '宋体'
        style.font.size = Pt(12)

        project_name = arguments["project_name"]
        content = arguments["document_content"]

        title = doc.add_heading(project_name, 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        sub = doc.add_heading("投标响应文件", 1)
        sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_page_break()

        for section in content.get("sections", []):
            doc.add_heading(section["title"], level=section.get("level", 1))
            doc.add_paragraph(section["content"])

        filename = f"{project_name}_投标响应文件_{datetime.date.today()}.docx"
        tmp_path = f"/tmp/{filename}"
        doc.save(tmp_path)

        auth = oss2.Auth(os.environ['OSS_ACCESS_KEY'], os.environ['OSS_SECRET_KEY'])
        bucket = oss2.Bucket(auth, os.environ['OSS_ENDPOINT'], os.environ['OSS_BUCKET'])
        oss_key = f"bid-documents/{uuid.uuid4()}/{filename}"
        bucket.put_object_from_file(oss_key, tmp_path)

        download_url = bucket.sign_url('GET', oss_key, 3600)

        return [TextContent(
            type="text",
            text=f"✅ Word文档已生成！\n文件名：{filename}\n下载链接（1小时有效）：{download_url}"
        )]


# 删掉原来整个 main() 函数，替换为以下内容

def main():
    import asyncio
    from mcp.server.stdio import stdio_server  # ✅ 使用 stdio

    async def run():
        async with stdio_server() as (read_stream, write_stream):
            await app.run(
                read_stream,
                write_stream,
                app.create_initialization_options()
            )

    asyncio.run(run())


if __name__ == "__main__":
    main()
