"""
International Standard Atmosphere (ISA) model for Mach and CAS calculations.

Aligned with Tacview formulas (no QNH corrections).
Reference: https://tacview.fandom.com/wiki/Formulas
"""

import math

# ISA constants
SEA_LEVEL_TEMP = 288.15       # K (15°C)
SEA_LEVEL_PRESSURE = 101325   # Pa
SEA_LEVEL_DENSITY = 1.225     # kg/m³
LAPSE_RATE = 0.0065           # K/m (troposphere temperature gradient)
TROPOPAUSE_ALT = 11000        # m (tropopause altitude)
TROPOPAUSE_TEMP = 216.65      # K (-56.5°C)
GAMMA = 1.4                   # Ratio of specific heats for air
R_AIR = 287.05                # J/(kg·K) - specific gas constant for dry air


def get_isa_temperature(altitude_m: float) -> float:
    """
    Calculate ISA temperature at altitude.
    
    Args:
        altitude_m: Altitude in meters MSL
        
    Returns:
        Temperature in Kelvin
    """
    if altitude_m <= TROPOPAUSE_ALT:
        # Troposphere: linear decrease with altitude
        return SEA_LEVEL_TEMP - LAPSE_RATE * altitude_m
    else:
        # Stratosphere: constant temperature
        return TROPOPAUSE_TEMP


def get_isa_pressure(altitude_m: float) -> float:
    """
    Calculate ISA pressure at altitude.
    
    Args:
        altitude_m: Altitude in meters MSL
        
    Returns:
        Pressure in Pascals
    """
    if altitude_m <= TROPOPAUSE_ALT:
        # Troposphere: exponential decrease
        temp = get_isa_temperature(altitude_m)
        pressure = SEA_LEVEL_PRESSURE * (temp / SEA_LEVEL_TEMP) ** 5.2559
        return pressure
    else:
        # Stratosphere: exponential decay with constant temperature
        p_tropopause = get_isa_pressure(TROPOPAUSE_ALT)
        g = 9.80665  # Use standard gravity for pressure calculation
        exponent = -g * (altitude_m - TROPOPAUSE_ALT) / (R_AIR * TROPOPAUSE_TEMP)
        return p_tropopause * math.exp(exponent)


def get_isa_density(altitude_m: float) -> float:
    """
    Calculate ISA air density at altitude.
    
    Args:
        altitude_m: Altitude in meters MSL
        
    Returns:
        Density in kg/m³
    """
    pressure = get_isa_pressure(altitude_m)
    temp = get_isa_temperature(altitude_m)
    # Ideal gas law: ρ = P / (R * T)
    return pressure / (R_AIR * temp)


def get_speed_of_sound(altitude_m: float) -> float:
    """
    Calculate speed of sound at altitude using ISA model.
    
    Tacview formula: a = sqrt(γ * R * T)
    
    Args:
        altitude_m: Altitude in meters MSL
        
    Returns:
        Speed of sound in m/s
    """
    temp = get_isa_temperature(altitude_m)
    return math.sqrt(GAMMA * R_AIR * temp)


def tas_to_mach(tas_mps: float, altitude_m: float) -> float:
    """
    Convert True Airspeed to Mach number.
    
    Tacview formula: Mach = TAS / speed_of_sound
    
    Args:
        tas_mps: True Airspeed in m/s
        altitude_m: Altitude in meters MSL
        
    Returns:
        Mach number (dimensionless)
    """
    if tas_mps is None or altitude_m is None:
        return None
    
    speed_of_sound = get_speed_of_sound(altitude_m)
    return tas_mps / speed_of_sound


def tas_to_cas(tas_mps: float, altitude_m: float) -> float:
    """
    Convert True Airspeed to Calibrated Airspeed using ISA model.
    
    Tacview uses Falcon 4/BMS CalcKIAS() formula for accuracy.
    This is a simplified version using the adiabatic flow relationship.
    
    Args:
        tas_mps: True Airspeed in m/s
        altitude_m: Altitude in meters MSL
        
    Returns:
        Calibrated Airspeed in m/s
    """
    if tas_mps is None or altitude_m is None:
        return None
    
    # Get atmospheric conditions at altitude
    pressure = get_isa_pressure(altitude_m)
    density = get_isa_density(altitude_m)
    mach = tas_to_mach(tas_mps, altitude_m)
    
    # Dynamic pressure at altitude
    q = 0.5 * density * tas_mps**2
    
    # Subsonic vs supersonic regimes
    if mach < 1.0:
        # Subsonic: adiabatic compression
        # CAS formula: sqrt(2 * P0 / ρ0 * ((1 + q/P)^(2/7) - 1))
        pressure_ratio = 1 + q / pressure
        if pressure_ratio > 0:
            term = pressure_ratio ** (2.0/7.0) - 1
            if term >= 0:
                cas = math.sqrt(2 * SEA_LEVEL_PRESSURE / SEA_LEVEL_DENSITY * term)
            else:
                cas = 0
        else:
            cas = 0
    else:
        # Supersonic: simplified approximation
        # For combat sims, use density ratio scaling
        cas = tas_mps * math.sqrt(density / SEA_LEVEL_DENSITY)
    
    return cas

