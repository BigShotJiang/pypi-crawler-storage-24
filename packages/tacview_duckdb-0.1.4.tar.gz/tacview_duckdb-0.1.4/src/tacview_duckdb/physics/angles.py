"""
Angle calculations for flight dynamics.

Aligned with Tacview formulas.
Reference: https://tacview.fandom.com/wiki/Formulas
"""

import math
from typing import Tuple, Optional


def calculate_aoa(
    velocity_vector: Tuple[float, float, float],
    forward_vector: Tuple[float, float, float]
) -> Optional[float]:
    """
    Calculate Angle of Attack (AoA).
    
    AoA is the angle between the aircraft's longitudinal axis (forward vector)
    and its velocity vector (direction of motion).
    
    Args:
        velocity_vector: (vx, vy, vz) in m/s - aircraft velocity in world frame
        forward_vector: (fx, fy, fz) - aircraft forward direction (unit vector)
        
    Returns:
        Angle of Attack in degrees, or None if cannot calculate
    """
    # Magnitude of velocity
    v_mag = math.sqrt(velocity_vector[0]**2 + velocity_vector[1]**2 + velocity_vector[2]**2)
    if v_mag < 0.1:  # Too slow, AoA undefined
        return None
    
    # Normalize velocity vector
    v_norm = (
        velocity_vector[0] / v_mag,
        velocity_vector[1] / v_mag,
        velocity_vector[2] / v_mag
    )
    
    # Dot product to get cosine of angle
    dot = v_norm[0] * forward_vector[0] + v_norm[1] * forward_vector[1] + v_norm[2] * forward_vector[2]
    
    # Clamp to valid range for arccos
    dot = max(-1.0, min(1.0, dot))
    
    # AoA is angle between velocity and forward axis
    aoa_rad = math.acos(dot)
    aoa_deg = math.degrees(aoa_rad)
    
    # Determine sign: positive when pitching up (velocity below forward vector)
    # Use vertical component of velocity relative to forward vector
    # Cross product gives perpendicular, dot with up vector gives sign
    cross_x = forward_vector[1] * v_norm[2] - forward_vector[2] * v_norm[1]
    cross_y = forward_vector[2] * v_norm[0] - forward_vector[0] * v_norm[2]
    cross_z = forward_vector[0] * v_norm[1] - forward_vector[1] * v_norm[0]
    
    # Project onto right vector to determine sign
    # Positive AoA = nose up relative to velocity
    sign = 1.0 if cross_y > 0 else -1.0
    
    return aoa_deg * sign


def calculate_aos(
    velocity_vector: Tuple[float, float, float],
    right_vector: Tuple[float, float, float]
) -> Optional[float]:
    """
    Calculate Angle of Sideslip (AoS/Beta).
    
    AoS is the angle between the aircraft's lateral axis (right vector)
    and its velocity vector projected onto the lateral plane.
    
    Args:
        velocity_vector: (vx, vy, vz) in m/s - aircraft velocity in world frame
        right_vector: (rx, ry, rz) - aircraft right direction (unit vector)
        
    Returns:
        Angle of Sideslip in degrees, or None if cannot calculate
    """
    # Magnitude of velocity
    v_mag = math.sqrt(velocity_vector[0]**2 + velocity_vector[1]**2 + velocity_vector[2]**2)
    if v_mag < 0.1:  # Too slow, AoS undefined
        return None
    
    # Normalize velocity vector
    v_norm = (
        velocity_vector[0] / v_mag,
        velocity_vector[1] / v_mag,
        velocity_vector[2] / v_mag
    )
    
    # Dot product with right vector gives lateral component
    lateral_component = v_norm[0] * right_vector[0] + v_norm[1] * right_vector[1] + v_norm[2] * right_vector[2]
    
    # Clamp to valid range for arcsin
    lateral_component = max(-1.0, min(1.0, lateral_component))
    
    # AoS is angle of lateral deviation
    aos_rad = math.asin(lateral_component)
    aos_deg = math.degrees(aos_rad)
    
    return aos_deg


def heading_to_forward_vector(heading_deg: float, pitch_deg: float = 0.0) -> Tuple[float, float, float]:
    """
    Convert heading and pitch to a forward vector in world frame.
    
    Assumes flat world coordinates (DCS U/V system).
    
    Args:
        heading_deg: Heading in degrees (0 = North, 90 = East)
        pitch_deg: Pitch in degrees (positive = nose up)
        
    Returns:
        Forward unit vector (fx, fy, fz) in world frame
    """
    heading_rad = math.radians(heading_deg)
    pitch_rad = math.radians(pitch_deg)
    
    # In DCS flat world: +U = East, +V = North, +altitude = Up
    # Heading 0 = North (+V), Heading 90 = East (+U)
    cos_pitch = math.cos(pitch_rad)
    
    fx = math.sin(heading_rad) * cos_pitch  # U component (East)
    fy = math.cos(heading_rad) * cos_pitch  # V component (North)
    fz = math.sin(pitch_rad)                # Altitude component
    
    return (fx, fy, fz)


def heading_to_right_vector(heading_deg: float, roll_deg: float = 0.0) -> Tuple[float, float, float]:
    """
    Convert heading and roll to a right vector in world frame.
    
    Assumes flat world coordinates (DCS U/V system).
    
    Args:
        heading_deg: Heading in degrees (0 = North, 90 = East)
        roll_deg: Roll in degrees (positive = right wing down) - currently unused
        
    Returns:
        Right unit vector (rx, ry, rz) in world frame
    """
    heading_rad = math.radians(heading_deg)
    
    # Right vector is 90° right of heading
    # In DCS flat world: right = heading + 90°
    rx = math.sin(heading_rad + math.pi/2)  # U component
    ry = math.cos(heading_rad + math.pi/2)  # V component
    rz = 0.0  # No altitude component for lateral axis
    
    return (rx, ry, rz)

