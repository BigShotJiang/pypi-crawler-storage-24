"""Aircraft lifecycle enrichment with AGL-based detection.

Requires AGL (Above Ground Level) data from telemetry source.
Does NOT support MSL-only altitude data - see 'lifecycle copy.py' for legacy implementation.

Handles lifecycle events for all object types:
- Aircraft (fixed-wing and rotorcraft): takeoff, landing, air start, removal/destruction
- Ground/Sea units: weapon-caused destruction

Works identically in batch and JIT modes - uses flags and deduplication for both.
"""

from typing import List, Optional, Dict
from collections import defaultdict
import duckdb
import queue
from .pipeline import Enricher
from .flags import ProcessingFlags


class AircraftLifecycleEnricher(Enricher):
    """
    Unified lifecycle detection for all aircraft types using AGL.
    
    Detects:
    - Air starts (spawned in flight)
    - Takeoff events (TakenOff)
    - Landing events (Landed)
    - Removal classification (Destroyed vs LeftArea based on speed)
    
    Uses flag-based tracking and event deduplication for both batch and JIT modes.
    REQUIRES AGL data - will skip takeoff/landing detection if no AGL data available.
    """
    
    # AGL thresholds (meters)
    AGL_GROUND = 5.0           # Below this = on ground
    AGL_AIRBORNE = 30.0        # Above this = definitely flying
    AGL_AIR_START = 100.0      # Above this at spawn = air start
    AGL_FIXED_WING_TAKEOFF = 15.0  # Fixed-wing liftoff gate
    AGL_ROTOR_LOOKBACK = 12.0  # Rotorcraft near-ground lookback threshold
    
    # Speed thresholds (m/s)
    SPEED_GROUND = 10.0        # Below this = ground operations
    SPEED_AIRBORNE = 20.0      # Above this = flying
    SPEED_AIR_START = 30.0     # Above this at spawn = air start
    SPEED_DESTROYED = 30.0     # Above this at removal = destroyed
    SPEED_CLEAN_EXIT = 1.0     # Below this at removal = clean despawn
    
    # Lookback samples (at 5Hz, 75 samples = 15 seconds)
    LOOKBACK_SAMPLES = 75
    
    # Deduplication window (seconds)
    DEDUPE_WINDOW = 60.0
    
    def __init__(
        self,
        conn: duckdb.DuckDBPyConnection,
        event_queue: queue.Queue = None,
        use_airport_database: bool = False,
        airport_max_distance_km: float = 5.0,
        # Allow customization of thresholds
        agl_ground: float = None,
        agl_airborne: float = None,
        speed_ground: float = None,
        speed_airborne: float = None,
        speed_destroyed: float = None,
        speed_clean_exit: float = None,
        # Legacy parameters (ignored, kept for API compatibility)
        airbase_database: Optional[Dict[str, Dict]] = None,
        min_altitude_change: float = None,
        max_ground_speed: float = None,
        min_transition_speed: float = None,
        detect_removals: bool = True,
        destruction_speed_threshold: float = None,
        clean_removal_speed_threshold: float = None,
        num_states_to_check: int = 3,
        jit_mode: bool = None,  # Deprecated - always uses unified logic
    ):
        """
        Initialize aircraft lifecycle enricher.
        
        Args:
            use_airport_database: Use OurAirports database for location identification
            airport_max_distance_km: Maximum distance to search for airports (default: 5 km)
            agl_ground: AGL threshold for "on ground" (default: 5.0m)
            agl_airborne: AGL threshold for "airborne" (default: 30.0m)
            speed_ground: Speed threshold for ground operations (default: 10.0 m/s)
            speed_airborne: Speed threshold for flying (default: 20.0 m/s)
            speed_destroyed: Speed above which removal = destroyed (default: 30.0 m/s)
            speed_clean_exit: Speed below which removal = clean exit (default: 1.0 m/s)
        """
        self.conn = conn
        self.queue = event_queue
        self.use_airport_database = use_airport_database
        self.airport_max_distance_km = airport_max_distance_km
        self.detect_removals = detect_removals
        self.num_states_to_check = num_states_to_check
    
        # Apply custom thresholds if provided
        if agl_ground is not None:
            self.AGL_GROUND = agl_ground
        if agl_airborne is not None:
            self.AGL_AIRBORNE = agl_airborne
        if speed_ground is not None:
            self.SPEED_GROUND = speed_ground
        if speed_airborne is not None:
            self.SPEED_AIRBORNE = speed_airborne
        if speed_destroyed is not None or destruction_speed_threshold is not None:
            self.SPEED_DESTROYED = speed_destroyed or destruction_speed_threshold
        if speed_clean_exit is not None or clean_removal_speed_threshold is not None:
            self.SPEED_CLEAN_EXIT = speed_clean_exit or clean_removal_speed_threshold
    
    def enrich(self) -> dict:
        """
        Run lifecycle enrichment.
        
        Uses unified logic for both batch and JIT modes:
        - Checks flags to find aircraft needing analysis
        - Deduplicates against existing events
        - Updates flags after analysis
            
        Returns:
            Dictionary with enrichment statistics
        """
        stats = {
            "air_starts": 0,
            "takeoffs": 0,
            "landings": 0,
            "destroyed": 0,
            "left_area": 0,
            "agl_available": False,
        }
        
        # Verify AGL data exists
        has_agl = self.conn.execute("""
            SELECT EXISTS(SELECT 1 FROM states WHERE agl IS NOT NULL LIMIT 1)
        """).fetchone()[0]
        
        if not has_agl:
            print("  Warning: No AGL data available - skipping takeoff/landing detection")
            # Still run removal classification (doesn't need AGL)
            if self.detect_removals:
                removal_events = self._detect_removals()
                if removal_events:
                    self._insert_events(removal_events)
                    stats["destroyed"] = sum(1 for e in removal_events if e[2] == 'Destroyed')
                    stats["left_area"] = sum(1 for e in removal_events if e[2] == 'LeftArea')
            return stats
        
        stats["agl_available"] = True
        
        # Airports table is always available in the database (v0.2.0+)
        airports_table = "airports"
        
        try:
            # Get aircraft needing analysis (flag not set = needs analysis)
            aircraft_ids = self._get_aircraft_to_analyze()
            
            if not aircraft_ids:
                # Still run removal classification for removed aircraft
                if self.detect_removals:
                    removal_events = self._detect_removals()
                    if removal_events:
                        self._insert_events(removal_events)
                        stats["destroyed"] = sum(1 for e in removal_events if e[2] == 'Destroyed')
                        stats["left_area"] = sum(1 for e in removal_events if e[2] == 'LeftArea')
                return stats
            
            events = []
            
            # 1. Detect air starts (one-time per aircraft)
            air_start_events = self._detect_air_starts(aircraft_ids, airports_table)
            events.extend(air_start_events)
            stats["air_starts"] = len(air_start_events)
            
            # 2. Detect takeoffs and landings
            to_landing_events = self._detect_takeoff_landing(aircraft_ids, airports_table)
            events.extend(to_landing_events)
            stats["takeoffs"] = sum(1 for e in to_landing_events if e[2] == 'TakenOff')
            stats["landings"] = sum(1 for e in to_landing_events if e[2] == 'Landed')
            
            # 3. Detect removal classifications
            if self.detect_removals:
                removal_events = self._detect_removals()
                events.extend(removal_events)
                stats["destroyed"] = sum(1 for e in removal_events if e[2] == 'Destroyed')
                stats["left_area"] = sum(1 for e in removal_events if e[2] == 'LeftArea')
            
            # 4. Deduplicate against existing events table
            events = self._dedupe_against_existing(events)
            
            # 5. Insert new events
            if events:
                self._insert_events(events)
            
            # 6. Mark aircraft as analyzed
            self._mark_analyzed(aircraft_ids)
            
            return stats
        
        except Exception as e:
            # Re-raise exceptions for proper error handling
            raise
    
    def _get_aircraft_to_analyze(self) -> List[str]:
        """Get aircraft IDs needing analysis (flag not set)."""
        return [r[0] for r in self.conn.execute(f"""
            SELECT DISTINCT o.id
            FROM objects o
            JOIN states s ON o.id = s.object_id
            WHERE o.type_class = 'Air'
              AND s.agl IS NOT NULL
              AND (COALESCE(o.processed_flags, 0) & {ProcessingFlags.TAKEOFF_LANDING_CURRENT}) = 0
        """).fetchall()]
    
    def _detect_air_starts(
        self, 
        aircraft_ids: List[str],
        airports_table: Optional[str]
    ) -> List[tuple]:
        """Detect aircraft that spawned in flight using AGL."""
        if not aircraft_ids:
            return []
        
        # Get mission start time
        mission_start_result = self.conn.execute("""
            SELECT MIN(timestamp) FROM states
        """).fetchone()
        mission_start = mission_start_result[0] if mission_start_result else 0.0
        
        query = f"""
        WITH spawn_states AS (
            SELECT 
                s.object_id,
                s.timestamp,
                s.agl,
                s.speed,
                s.longitude,
                s.latitude,
                o.name,
                o.pilot,
                ROW_NUMBER() OVER (PARTITION BY s.object_id ORDER BY s.timestamp) as rn
            FROM states s
            JOIN objects o ON o.id = s.object_id
            WHERE s.object_id IN (SELECT UNNEST(?::VARCHAR[]))
              AND s.agl IS NOT NULL
              AND s.speed IS NOT NULL
              AND o.first_seen >= {mission_start + 10.0}
        ),
        -- Check first 5 states to confirm sustained flight (not sim loading artifact)
        confirmed_air_starts AS (
            SELECT object_id, MIN(timestamp) as spawn_time
            FROM spawn_states
            WHERE rn <= 5
            GROUP BY object_id
            HAVING 
                MIN(agl) > {self.AGL_AIR_START}
                AND MIN(speed) > {self.SPEED_AIR_START}
        )
        SELECT 
            c.object_id,
            c.spawn_time,
            s.longitude,
            s.latitude,
            s.name,
            s.pilot
        FROM confirmed_air_starts c
        JOIN spawn_states s ON s.object_id = c.object_id AND s.rn = 1
        -- Skip if already checked for air start
        JOIN objects o ON o.id = c.object_id
        WHERE (COALESCE(o.processed_flags, 0) & {ProcessingFlags.AIR_START_CHECKED}) = 0
        """
        
        results = self.conn.execute(query, [aircraft_ids]).fetchall()
        
        if not results:
            return []
        
        events = []
        air_start_ids = []
        
        for obj_id, spawn_time, longitude, latitude, name, pilot in results:
            location_name = self._identify_location(self.conn, latitude, longitude, airports_table)
            pilot_text = f"pilot '{pilot}'" if pilot else "pilot"
            event_msg = f"{pilot_text} ({name}) has spawned at {location_name}"
            
            # Include lat/lon for async geocoding enrichment
            events.append((obj_id, spawn_time, 'TakenOff', event_msg, latitude, longitude))
            air_start_ids.append(obj_id)
        
        # Mark air start as checked
        if air_start_ids:
            self.conn.execute(f"""
                UPDATE objects
                SET processed_flags = COALESCE(processed_flags, 0) | {ProcessingFlags.AIR_START_CHECKED}
                WHERE id IN (SELECT UNNEST(?::VARCHAR[]))
            """, [air_start_ids])
        
        return events

    def _enforce_transition_order(self, events: List[tuple]) -> List[tuple]:
        """Keep only alternating TakenOff/Landed transitions per aircraft."""
        if not events:
            return []

        grouped = defaultdict(list)
        for event in events:
            grouped[event[0]].append(event)

        filtered = []
        for _, group in grouped.items():
            group.sort(key=lambda x: x[1])

            last_event_name = None
            for event in group:
                event_name = event[2]

                # Ignore repeated same-phase transitions like TakenOff->TakenOff
                # or Landed->Landed without an opposite transition in between.
                if event_name == last_event_name:
                    continue

                filtered.append(event)
                last_event_name = event_name

        filtered.sort(key=lambda x: (x[0], x[1]))
        return filtered
    
    def _detect_takeoff_landing(
        self,
        aircraft_ids: List[str],
        airports_table: Optional[str]
    ) -> List[tuple]:
        """Detect takeoff and landing events using AGL transitions."""
        if not aircraft_ids:
            return []
        
        query = f"""
        WITH agl_data AS (
            SELECT 
                s.object_id,
                s.timestamp,
                s.agl,
                s.speed,
                s.longitude,
                s.latitude,
                s.heading,
                o.name,
                o.type_basic,
                LAG(s.agl, {self.LOOKBACK_SAMPLES}) OVER w as agl_ago,
                LAG(s.speed, {self.LOOKBACK_SAMPLES}) OVER w as speed_ago,
                LAG(s.agl) OVER w as agl_prev
            FROM states s
            JOIN objects o ON o.id = s.object_id
            WHERE s.object_id IN (SELECT UNNEST(?::VARCHAR[]))
              AND s.agl IS NOT NULL
              AND s.speed IS NOT NULL
            WINDOW w AS (PARTITION BY s.object_id ORDER BY s.timestamp)
        ),
        transitions AS (
            SELECT 
                object_id,
                timestamp,
                longitude,
                latitude,
                heading,
                name,
                CASE
                    -- Landing: was flying (high AGL), now on ground (low AGL)
                    WHEN agl < {self.AGL_GROUND} 
                     AND speed < {self.SPEED_GROUND}
                     AND agl_ago IS NOT NULL 
                     AND agl_ago > {self.AGL_AIRBORNE}
                    THEN 'Landed'
                    -- Rotorcraft takeoff: allow low-altitude fast departures,
                    -- while requiring historical near-ground, low-speed context
                    WHEN type_basic = 'Rotorcraft'
                     AND agl > {self.AGL_GROUND}
                     AND speed > {self.SPEED_AIRBORNE}
                     AND agl_ago IS NOT NULL
                     AND agl_ago < {self.AGL_ROTOR_LOOKBACK}
                     AND speed_ago IS NOT NULL
                     AND speed_ago < {self.SPEED_GROUND}
                    THEN 'TakenOff'
                    -- Fixed-wing takeoff: runway roll can be fast while still on ground
                    WHEN COALESCE(type_basic, '') != 'Rotorcraft'
                     AND agl > {self.AGL_FIXED_WING_TAKEOFF}
                     AND speed > {self.SPEED_AIRBORNE}
                     AND agl_ago IS NOT NULL
                     AND agl_ago < {self.AGL_GROUND}
                     AND agl_prev IS NOT NULL
                     AND agl_prev <= {self.AGL_FIXED_WING_TAKEOFF}
                    THEN 'TakenOff'
                END as event_name
            FROM agl_data
        )
        SELECT object_id, timestamp, event_name, longitude, latitude, heading, name
        FROM transitions
        WHERE event_name IS NOT NULL
        ORDER BY object_id, timestamp
        """
        
        results = self.conn.execute(query, [aircraft_ids]).fetchall()
        
        if not results:
            return []
        
        # Deduplicate within results (same event type within DEDUPE_WINDOW seconds)
        deduped = self._deduplicate_detected(results)
        # Enforce valid phase transitions (alternating TakenOff/Landed)
        deduped = self._enforce_transition_order(deduped)
        
        # Build event tuples with location names
        events = []
        for obj_id, timestamp, event_name, longitude, latitude, heading, name in deduped:
            location_name = self._identify_location(self.conn, latitude, longitude, airports_table)
            runway = self._heading_to_runway(heading) if heading else None
            location_str = f"{location_name}" + (f" (Runway {runway})" if runway else "")
            
            if event_name == 'TakenOff':
                event_msg = f"{name} has taken off from {location_str}"
            else:
                event_msg = f"{name} has landed at {location_str}"
            
            # Include lat/lon for async geocoding enrichment
            events.append((obj_id, timestamp, event_name, event_msg, latitude, longitude))
        
        return events
    
    def _detect_removals(self) -> List[tuple]:
        """Classify aircraft removals as Destroyed or LeftArea based on speed."""
        query = f"""
        WITH removed_aircraft AS (
            SELECT id, name, removed_at
            FROM objects
            WHERE type_class = 'Air'
              AND removed_at IS NOT NULL
              AND (COALESCE(processed_flags, 0) & {ProcessingFlags.REMOVAL_CLASSIFIED}) = 0
        ),
        last_states AS (
            SELECT 
                r.id,
                r.name,
                r.removed_at,
                AVG(s.speed) as avg_speed,
                -- Get last known position
                (ARRAY_AGG(s.latitude ORDER BY s.timestamp DESC))[1] as last_lat,
                (ARRAY_AGG(s.longitude ORDER BY s.timestamp DESC))[1] as last_lon
            FROM removed_aircraft r
            JOIN LATERAL (
                SELECT speed, latitude, longitude, timestamp
                FROM states
                WHERE object_id = r.id
                  AND timestamp <= r.removed_at
                  AND speed IS NOT NULL
                ORDER BY timestamp DESC
                LIMIT {self.num_states_to_check}
            ) s ON TRUE
            GROUP BY r.id, r.name, r.removed_at
        )
        SELECT 
            id,
            removed_at,
            CASE 
                WHEN avg_speed > {self.SPEED_DESTROYED} THEN 'Destroyed'
                WHEN avg_speed < {self.SPEED_CLEAN_EXIT} THEN 'LeftArea'
            END as event_name,
            name,
            avg_speed,
            last_lat,
            last_lon
        FROM last_states
        WHERE avg_speed > {self.SPEED_DESTROYED} OR avg_speed < {self.SPEED_CLEAN_EXIT}
        """
        
        results = self.conn.execute(query).fetchall()
        
        if not results:
            return []
        
        events = []
        classified_ids = []
        
        for obj_id, removed_at, event_name, name, avg_speed, last_lat, last_lon in results:
            display_name = name or obj_id
            if event_name == 'Destroyed':
                event_msg = f"{display_name} was destroyed"
            else:
                event_msg = f"{display_name} left the area"
            
            # Include lat/lon for async geocoding enrichment
            events.append((obj_id, removed_at, event_name, event_msg, last_lat, last_lon))
            classified_ids.append(obj_id)
        
        # Mark as classified
        if classified_ids:
            self.conn.execute(f"""
                UPDATE objects
                SET processed_flags = COALESCE(processed_flags, 0) | {ProcessingFlags.REMOVAL_CLASSIFIED}
                WHERE id IN (SELECT UNNEST(?::VARCHAR[]))
            """, [classified_ids])
        
        return events
    
    def _deduplicate_detected(self, events: List[tuple]) -> List[tuple]:
        """Remove duplicate events within time window (same aircraft, same event type)."""
        if not events:
            return []
        
        # Group by (object_id, event_name)
        groups = defaultdict(list)
        for e in events:
            obj_id, timestamp, event_name = e[0], e[1], e[2]
            groups[(obj_id, event_name)].append(e)
        
        deduped = []
        for key, group in groups.items():
            group.sort(key=lambda x: x[1])  # Sort by timestamp
            kept = [group[0]]
            for e in group[1:]:
                if e[1] - kept[-1][1] >= self.DEDUPE_WINDOW:
                    kept.append(e)
            deduped.extend(kept)
        
        return deduped
    
    def _dedupe_against_existing(self, events: List[tuple]) -> List[tuple]:
        """Filter out events that already exist in events table."""
        if not events:
            return []
        
        new_events = []
        for e in events:
            obj_id, timestamp, event_name = e[0], e[1], e[2]
            existing = self.conn.execute("""
                SELECT 1 FROM events
                WHERE object_id = ?
                  AND event_name = ?
                  AND ABS(timestamp - ?) < ?
                LIMIT 1
            """, [obj_id, event_name, timestamp, self.DEDUPE_WINDOW]).fetchone()
            
            if not existing:
                new_events.append(e)
        
        return new_events
    
    def _mark_analyzed(self, aircraft_ids: List[str]):
        """Mark aircraft as analyzed."""
        if not aircraft_ids:
            return
        self.conn.execute(f"""
            UPDATE objects
            SET processed_flags = COALESCE(processed_flags, 0) | {ProcessingFlags.TAKEOFF_LANDING_CURRENT}
            WHERE id IN (SELECT UNNEST(?::VARCHAR[]))
        """, [aircraft_ids])
    
    def _insert_events(self, events: List[tuple]):
        """
        Insert events into events table with coordinates.
        
        Events tuple: (obj_id, timestamp, event_name, event_params, lat, lon)
        """
        self.conn.executemany("""
            INSERT OR REPLACE INTO events (
                object_id, timestamp, event_name, event_params,
                location_lat, location_lon
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, events)
    
    def _identify_location(
        self,
        conn: duckdb.DuckDBPyConnection,
        latitude: float,
        longitude: float,
        airports_table: Optional[str] = "airports"
    ) -> str:
        """
        Identify location using airport database or coordinates.
        
        Args:
            conn: DuckDB connection
            latitude: Latitude in degrees
            longitude: Longitude in degrees
            airports_table: Name of airports table (default: "airports")
            
        Returns:
            Location string like "Nellis AFB (KLSV)" or coordinates
        """
        # Always try airports table (it's always available in v0.2.0+)
        try:
            from . import airports
            airport_info = airports.find_nearest_airport(
                conn,
                latitude,
                longitude,
                max_distance_km=self.airport_max_distance_km,
                table_name=airports_table or "airports",
                airport_types=['large_airport', 'medium_airport', 'small_airport', 
                             'heliport', 'seaplane_base']
            )
            if airport_info:
                return airports.format_airport_description(airport_info)
        except Exception:
            pass  # Fall back to coordinates
        
        return f"({latitude:.3f}, {longitude:.3f})"
    
    def _heading_to_runway(self, heading: Optional[float]) -> Optional[str]:
        """Convert heading to runway designation."""
        if heading is None:
            return None
        
        heading = heading % 360
        runway_num = int((heading + 5) / 10) % 36
        if runway_num == 0:
            runway_num = 36
        
        return f"{runway_num:02d}"


# Backwards compatibility aliases
FixedWingEnricher = AircraftLifecycleEnricher
RotorcraftEnricher = AircraftLifecycleEnricher


class GroundSeaEnricher(Enricher):
    """
    Creates destruction events for Ground and Sea units hit by weapons.
    
    When ground/sea units are hit and subsequently removed within a time window,
    creates 'Destroyed' events with hit information. Handles:
    - Ground targets that burn before being destroyed
    - Ships that sink after taking damage
    - Multiple hits (uses latest hit time)
    
    Note: Aircraft destruction is handled by AircraftLifecycleEnricher
    based on speed analysis at removal time.
    
    Args:
        time_window: Maximum seconds between last hit and removal to attribute
                     destruction to weapons (default: 120 seconds / 2 minutes)
    """
    
    def __init__(self, conn: duckdb.DuckDBPyConnection, event_queue: queue.Queue, time_window: float = 120.0):
        self.time_window = time_window
        self.conn = conn
        self.queue = event_queue
    
    def enrich(self) -> dict:
        """
        Create Destroyed events for ground/sea units that were hit and removed.
        
        Args:
            conn: DuckDB connection
            
        Returns:
            Dictionary with enrichment statistics
        """
        # Find ground/sea units that were hit and subsequently removed
        query = """
        WITH weapon_hits AS (
            SELECT 
                te.target_id,
                te.timestamp as hit_time,
                te.initiator_id as weapon_id
            FROM tactical_events te
            JOIN objects o ON o.id = te.target_id
            WHERE te.event_type = 'WEAPON_HIT'
              AND te.target_id IS NOT NULL
              AND o.type_class IN ('Ground', 'Sea')
        ),
        removals AS (
            SELECT 
                o.id,
                o.name,
                o.type_class,
                o.removed_at
            FROM objects o
            WHERE o.type_class IN ('Ground', 'Sea')
              AND o.removed_at IS NOT NULL
        )
        SELECT 
            r.id,
            r.name,
            r.type_class,
            r.removed_at,
            MAX(h.hit_time) as latest_hit_time,
            COUNT(DISTINCT h.weapon_id) as hit_count
        FROM removals r
        JOIN weapon_hits h ON h.target_id = r.id
        WHERE r.removed_at >= h.hit_time
          AND r.removed_at <= h.hit_time + ?
        GROUP BY r.id, r.name, r.type_class, r.removed_at
        """
        
        destructions = self.conn.execute(query, [self.time_window]).fetchall()
        
        if not destructions:
            return {
                "ground_sea_destroyed_created": 0,
                "time_window_seconds": self.time_window
            }
        
        # Check which ones don't already have Destroyed events
        events_to_insert = []
        
        for unit_id, unit_name, type_class, removed_at, latest_hit, hit_count in destructions:
            # Check if Destroyed event already exists
            existing = self.conn.execute("""
                SELECT 1 FROM events
                WHERE object_id = ?
                  AND timestamp = ?
                  AND event_name = 'Destroyed'
            """, [unit_id, removed_at]).fetchone()
            
            if existing:
                continue  # Already has Destroyed event
            
            name = unit_name or unit_id
            time_to_destruction = removed_at - latest_hit
            
            # Build message with hit count
            if hit_count == 1:
                hit_info = f"{int(time_to_destruction)}s after being hit"
            else:
                hit_info = f"{int(time_to_destruction)}s after being hit {hit_count} times"
            
            event_params = f"{name} was destroyed ({hit_info})"
            
            events_to_insert.append((
                unit_id,
                removed_at,
                'Destroyed',
                event_params
            ))
        
        if events_to_insert:
            self.conn.executemany("""
                INSERT OR REPLACE INTO events (object_id, timestamp, event_name, event_params)
                VALUES (?, ?, ?, ?)
            """, events_to_insert)
        
        return {
            "ground_sea_destroyed_created": len(events_to_insert),
            "time_window_seconds": self.time_window
        }
