"""Enrichment pipeline module."""

from .pipeline import EnrichmentPipeline, Enricher
from .coalitions import CoalitionPropagator, CoalitionEnricher
from .ejection_events import EjectedPilotEnricher
from .weapons import WeaponEnricher
from .missed_weapons import MissedWeaponAnalyzer
from .spatial_clusters import SpatialClusterEnricher
from .lifecycle import (
    AircraftLifecycleEnricher,
    GroundSeaEnricher,
    # Backwards compatibility aliases
    FixedWingEnricher,
    RotorcraftEnricher,
)
from .containers import ContainerEnricher
from .decoys import DecoyEnricher
from .geodata import EventGeodataEnricher
from .projectile import ProjectileEnricher
from .async_geodata import AsyncGeodataEnricher
from . import airports

__all__ = [
    "EnrichmentPipeline",
    "Enricher",
    "CoalitionPropagator",
    "CoalitionEnricher",
    "EjectedPilotEnricher",
    "WeaponEnricher",
    "MissedWeaponAnalyzer",
    "SpatialClusterEnricher",
    "AircraftLifecycleEnricher",
    "GroundSeaEnricher",
    # Backwards compatibility
    "FixedWingEnricher",
    "RotorcraftEnricher",
    "ContainerEnricher",
    "DecoyEnricher",
    "EventGeodataEnricher",
    "ProjectileEnricher",
    "AsyncGeodataEnricher",
    "airports",
]
