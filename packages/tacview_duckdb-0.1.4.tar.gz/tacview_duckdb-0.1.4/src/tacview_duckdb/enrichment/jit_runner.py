"""JIT (Just-In-Time) Enrichment Runner.

Orchestrates enrichments that run immediately after data is flushed to Parquet,
enabling real-time analysis for streaming telemetry.

Spawn enrichments:
- Launcher association (weapons, projectiles)
- Parent detection (decoys, containers, ejections)

Removal enrichments (order critical):
1. spatial_clusters - Detect splash damage, intercepts
2. missed_weapons - Proximity analysis, kinematic defeats
3. lifecycle - Classify removal type (Destroyed vs LeftArea)
"""

from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    import duckdb
    import queue
    from ..storage.ingestion import PendingSpawn, PendingRemoval


class JITEnrichmentRunner:
    """
    Runs enrichments immediately after flush.
    
    Uses wrapper methods from enricher classes to detect launchers/parents,
    then applies all updates in a single batched operation.
    """

    def __init__(self, conn: "duckdb.DuckDBPyConnection", event_queue: "queue.Queue"):
        """
        Initialize JIT enrichment runner.
        
        Args:
            conn: DuckDB connection for queries
            queue: Queue to put enrichment results into
        """
        self.conn = conn
        self.queue = event_queue
        # Initialize enricher instances (lazy import to avoid circular dependency)
        from .coalitions import CoalitionEnricher
        from .weapons import WeaponEnricher
        from .projectile import ProjectileEnricher
        from .decoys import DecoyEnricher
        from .ejection_events import EjectedPilotEnricher
        from .containers import ContainerEnricher
        from .spatial_clusters import SpatialClusterEnricher
        from .weapons import WeaponEnricher
        from .missed_weapons import MissedWeaponAnalyzer

        self.coalition_enricher = CoalitionEnricher(conn, event_queue)
        self.decoy_enricher = DecoyEnricher(conn, event_queue)
        self.ejection_enricher = EjectedPilotEnricher(conn, event_queue)
        self.container_enricher = ContainerEnricher(conn, event_queue)
        self.weapon_enricher = WeaponEnricher(conn, event_queue)
        self.projectile_enricher = ProjectileEnricher(conn, event_queue)
        self.spatial_cluster_enricher = SpatialClusterEnricher(conn, event_queue)
        self.missed_weapon_enricher = MissedWeaponAnalyzer(conn, event_queue)

    def run_spawn_enrichments(self, spawns: List['PendingSpawn']) -> None:
        """
        Run spawn-time enrichments on newly spawned objects.
        
        Each enricher's wrapper method automatically processes only unmatched objects
        (WHERE parent_id IS NULL), so there's no need to track specific object_ids.
        
        Args:
            spawns: List of pending spawns to enrich (triggers enrichment run)
        """
        if not spawns:
            return

        # Call each enricher:
        # - Weapons: detect_launchers() (enrich() does both launchers + targets)
        # - Projectiles: find_launchers() (enrich() does launchers + hits + bursts)
        # - Decoys/ejections/containers: enrich() (ONLY does parent detection, no wrapper needed)
        decoy_count = self.decoy_enricher.enrich()
        ejection_count = self.ejection_enricher.enrich()
        container_count = self.container_enricher.enrich()
        weapon_count = self.weapon_enricher.detect_launchers()
        projectile_count = self.projectile_enricher.find_launchers()

        # Debug output
        if weapon_count or projectile_count or decoy_count or ejection_count or container_count:
            print(f"JIT Spawn: weapons={weapon_count}, projectiles={projectile_count}, decoys={decoy_count}, ejections={ejection_count}, containers={container_count}")

    def run_removal_enrichments(self, removals: List['PendingRemoval']) -> None:
        """
        Run removal-time enrichments in correct order.
        
        Order is critical:
        1. spatial_clusters - Can upgrade MISS → HIT
        2. missed_weapons - Analyzes remaining MISSes
        3. lifecycle - Classifies removal type
        
        Args:
            removals: List of pending removals to enrich

        TODO: figure out how to prevent enrichment from running twice on already enriched objects. a weapon that completly missed, had completly missed. there is no need to re-test that weapon.
        """
        # Stub - future implementation
        if not removals:
            return

        # Ensure spatial extension is loaded for missed weapons analysis
        self.conn.execute("INSTALL spatial")
        self.conn.execute("LOAD spatial")

        spatial_cluster_count = self.spatial_cluster_enricher.enrich()
        weapon_hit_count = self.weapon_enricher.detect_targets()
        projectile_hit_count = self.projectile_enricher.find_hits()
        missed_weapon_count = self.missed_weapon_enricher.analyze_proximity()

        if weapon_hit_count or projectile_hit_count or spatial_cluster_count or missed_weapon_count:
            print(f"JIT Removal: Spatial cluster: {spatial_cluster_count}, Weapon hits: {weapon_hit_count}, Projectile hits: {projectile_hit_count}, Missed weapons: {missed_weapon_count}")
