"""Bitwise flags for tracking enrichment processing state.

Each flag represents completion of a specific enrichment stage.
Flags are stored in objects.processed_flags (UINTEGER, 32 bits).

Design principles:
- Use flags for complex multi-stage enrichments that should not re-run
- Use direct SQL filters (parent_id IS NOT NULL, target_id IS NOT NULL) for simple checks
- Flags indicate "processing attempted", not "processing succeeded"

Usage:
    # Find weapons that haven't been analyzed for decoys yet
    # IMPORTANT: Use COALESCE to handle NULL values!
    SELECT * FROM objects 
    WHERE type_basic = 'Missile'
      AND removed_at IS NOT NULL
      AND (COALESCE(processed_flags, 0) & {ProcessingFlags.DECOY_ANALYSIS_DONE}) = 0
    
    # Mark decoy analysis as complete
    UPDATE objects 
    SET processed_flags = COALESCE(processed_flags, 0) | {ProcessingFlags.DECOY_ANALYSIS_DONE}
    WHERE id IN (?)
    
    # Check if ALL missed weapon stages are complete
    SELECT * FROM objects 
    WHERE (COALESCE(processed_flags, 0) & {ProcessingFlags.ALL_MISSED_WEAPON_STAGES}) = {ProcessingFlags.ALL_MISSED_WEAPON_STAGES}
"""

class ProcessingFlags:
    """Bitwise flags for enrichment processing state (32-bit).
    
    These flags track completion of multi-stage enrichments that should not be re-run.
    For simple checks (like parent_id IS NOT NULL, target_id IS NOT NULL), 
    use direct SQL filters instead - no need for flags.
    """
    
    # Removal enrichments (run when object is removed)
    SPATIAL_CLUSTER_ANALYZED = 1 << 0   # 0x00000001 - Spatial clustering done
    REMOVAL_CLASSIFIED = 1 << 1         # 0x00000002 - Destroyed/LeftArea determined (one-time)
    
    # Hit detection stages
    WEAPON_HIT_ANALYZED = 1 << 2        # 0x00000004 - Weapon hit detection done
    PROJECTILE_HIT_ANALYZED = 1 << 3    # 0x00000008 - Projectile hit detection done
    
    # Missed weapon analysis stages (complex multi-stage process)
    DECOY_ANALYSIS_DONE = 1 << 4        # 0x00000010 - Decoy proximity analysis done
    PROXIMITY_ANALYSIS_DONE = 1 << 5    # 0x00000020 - General proximity analysis done
    KINEMATIC_DEFEAT_DONE = 1 << 6      # 0x00000040 - Kinematic defeat analysis done
    ENERGY_DEFEAT_DONE = 1 << 7         # 0x00000080 - Energy depletion defeat done
    
    # Lifecycle tracking (for continuous events like takeoff/landing)
    TAKEOFF_LANDING_CURRENT = 1 << 8    # 0x00000100 - T/O & Landing analysis up-to-date
    AIR_START_CHECKED = 1 << 9          # 0x00000200 - Air start detection done (one-time at spawn)
    
    # Reserved for future use (bits 10-31)
    # FUTURE_FLAG_1 = 1 << 10, etc.
    
    # Combined flag for all missed weapon stages
    ALL_MISSED_WEAPON_STAGES = (DECOY_ANALYSIS_DONE | PROXIMITY_ANALYSIS_DONE | 
                                KINEMATIC_DEFEAT_DONE | ENERGY_DEFEAT_DONE)
    
    # Legacy alias for backwards compatibility
    LIFECYCLE_ANALYZED = REMOVAL_CLASSIFIED


def has_flag(flags: int, flag: int) -> bool:
    """Check if a specific flag is set."""
    return (flags & flag) != 0


def set_flag(flags: int, flag: int) -> int:
    """Return flags with the specified flag set."""
    return flags | flag


def clear_flag(flags: int, flag: int) -> int:
    """Return flags with the specified flag cleared."""
    return flags & ~flag


def get_flag_names(flags: int) -> list[str]:
    """Return list of flag names that are set."""
    flag_map = {
        ProcessingFlags.SPATIAL_CLUSTER_ANALYZED: "SPATIAL_CLUSTER_ANALYZED",
        ProcessingFlags.REMOVAL_CLASSIFIED: "REMOVAL_CLASSIFIED",
        ProcessingFlags.WEAPON_HIT_ANALYZED: "WEAPON_HIT_ANALYZED",
        ProcessingFlags.PROJECTILE_HIT_ANALYZED: "PROJECTILE_HIT_ANALYZED",
        ProcessingFlags.DECOY_ANALYSIS_DONE: "DECOY_ANALYSIS_DONE",
        ProcessingFlags.PROXIMITY_ANALYSIS_DONE: "PROXIMITY_ANALYSIS_DONE",
        ProcessingFlags.KINEMATIC_DEFEAT_DONE: "KINEMATIC_DEFEAT_DONE",
        ProcessingFlags.ENERGY_DEFEAT_DONE: "ENERGY_DEFEAT_DONE",
        ProcessingFlags.TAKEOFF_LANDING_CURRENT: "TAKEOFF_LANDING_CURRENT",
        ProcessingFlags.AIR_START_CHECKED: "AIR_START_CHECKED",
    }
    return [name for flag, name in flag_map.items() if has_flag(flags, flag)]
