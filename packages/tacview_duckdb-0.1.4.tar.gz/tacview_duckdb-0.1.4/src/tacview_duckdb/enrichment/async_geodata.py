"""Batch geodata enrichment for events.

This module enriches events that have coordinates but no geocoded location string.
Events are created with lat/lon, then this enricher fills in human-readable 
location names in a batch process.

Design:
- Batch processing: Run after parsing or on-demand
- Efficient: Deduplicates coordinates before geocoding
- Resilient: Falls back gracefully if geocoding fails
- Observable: Tracks progress and success rates

Usage:
    # After parsing:
    store = parse_acmi('mission.acmi')
    store.enrich_event_geodata()  # Batch-fill location names
    
    # Or on existing database:
    enricher = AsyncGeodataEnricher(conn, enable_reverse_geocoding=True)
    stats = enricher.enrich()
"""

import time
from typing import Dict, List, Tuple, Optional
import duckdb
from .pipeline import Enricher
from . import airports, geocoding


class AsyncGeodataEnricher(Enricher):
    """
    Batch enricher for event geodata.
    
    Fills in location_geocoded for events that have lat/lon but no location string.
    
    Strategy:
    1. SELECT events with coords but NULL location_geocoded
    2. Deduplicate coordinates (many events at same location)
    3. Resolve locations (airports first, then reverse geocoding)
    4. UPDATE events with resolved location strings
    """
    
    def __init__(
        self,
        conn: duckdb.DuckDBPyConnection,
        airport_max_distance_km: float = 5.0,
        enable_reverse_geocoding: bool = False,
        geocoding_timeout: int = 2,
        rate_limit_delay: float = 1.0,
    ):
        """
        Initialize geodata enricher.
        
        Args:
            conn: DuckDB connection
            airport_max_distance_km: Max distance for airport matching (default: 5 km)
            enable_reverse_geocoding: Enable reverse geocoding via geopy (default: False)
            geocoding_timeout: Timeout for geocoding requests in seconds (default: 2)
            rate_limit_delay: Delay between geocoding requests in seconds (default: 1.0)
        """
        self.conn = conn
        self.airport_max_distance_km = airport_max_distance_km
        self.enable_reverse_geocoding = enable_reverse_geocoding
        self.geocoding_timeout = geocoding_timeout
        self.rate_limit_delay = rate_limit_delay
    
    def enrich(self) -> dict:
        """
        Run batch geodata enrichment.
        
        Returns:
            Dictionary with enrichment statistics
        """
        stats = {
            "events_found": 0,
            "unique_locations": 0,
            "airports_matched": 0,
            "geocoded": 0,
            "skipped": 0,
            "events_updated": 0,
        }
        
        # 1. Find events needing geodata
        events_to_enrich = self._get_events_without_geodata()
        stats["events_found"] = len(events_to_enrich)
        
        if not events_to_enrich:
            return stats
        
        # 2. Deduplicate coordinates (round to ~1km precision)
        unique_coords = self._deduplicate_coordinates(events_to_enrich)
        stats["unique_locations"] = len(unique_coords)
        
        # 3. Resolve locations
        geocoded_results = self._resolve_locations(unique_coords, stats)
        
        # 4. Batch UPDATE events with resolved locations
        updated_count = self._update_events(geocoded_results)
        stats["events_updated"] = updated_count
        
        return stats
    
    def _get_events_without_geodata(self) -> List[Tuple]:
        """
        Find events with coordinates but missing geocoded location.
        
        Returns:
            List of (object_id, timestamp, event_name, lat, lon) tuples
        """
        return self.conn.execute("""
            SELECT object_id, timestamp, event_name, location_lat, location_lon
            FROM events
            WHERE location_lat IS NOT NULL
              AND location_lon IS NOT NULL
              AND location_geocoded IS NULL
            ORDER BY timestamp
        """).fetchall()
    
    def _deduplicate_coordinates(self, events: List[Tuple]) -> Dict[Tuple[float, float], int]:
        """
        Deduplicate coordinates to minimize geocoding requests.
        
        Args:
            events: List of event tuples
            
        Returns:
            Dictionary mapping (rounded_lat, rounded_lon) -> count
        """
        coord_counts = {}
        for obj_id, timestamp, event_name, lat, lon in events:
            if lat is None or lon is None:
                continue
            # Round to 2 decimal places (~1km precision) for deduplication
            coord_key = (round(lat, 2), round(lon, 2))
            coord_counts[coord_key] = coord_counts.get(coord_key, 0) + 1
        return coord_counts
    
    def _resolve_locations(
        self,
        coords: Dict[Tuple[float, float], int],
        stats: dict
    ) -> Dict[Tuple[float, float], Dict]:
        """
        Resolve coordinates to location strings.
        
        Strategy:
        1. Check airports first (fast, local, precise)
        2. Try reverse geocoding if enabled (slow, external, general)
        3. Skip if no match found (leave location_geocoded NULL)
        
        Args:
            coords: Dictionary of (lat, lon) -> count
            stats: Statistics dictionary to update
            
        Returns:
            Dictionary mapping (lat, lon) -> {location, type}
        """
        results = {}
        total = len(coords)
        
        for idx, (lat, lon) in enumerate(coords.keys(), 1):
            # Progress indicator
            if idx % 10 == 0 or idx == total:
                print(f"  Resolving locations: {idx}/{total}")
            
            # Try airports first (fast, local)
            try:
                airport = airports.find_nearest_airport(
                    self.conn,
                    lat,
                    lon,
                    max_distance_km=self.airport_max_distance_km,
                    table_name="airports"
                )
                
                if airport:
                    results[(lat, lon)] = {
                        'location': airports.format_airport_description(airport),
                        'type': 'airport'
                    }
                    stats["airports_matched"] += 1
                    continue
            except Exception:
                pass  # Airport lookup failed, try geocoding
            
            # Try reverse geocoding (slow, external)
            if self.enable_reverse_geocoding:
                try:
                    location = geocoding.reverse_geocode(
                        lat, lon,
                        timeout=self.geocoding_timeout
                    )
                    if location:
                        results[(lat, lon)] = {
                            'location': f"near {location}",
                            'type': 'geocoded'
                        }
                        stats["geocoded"] += 1
                        # Rate limiting for external API (Nominatim: 1 req/sec)
                        time.sleep(self.rate_limit_delay)
                        continue
                except Exception:
                    pass  # Geocoding failed
            
            # No match - skip (leave location_geocoded NULL for this coordinate)
            stats["skipped"] += 1
        
        return results
    
    def _update_events(self, results: Dict[Tuple[float, float], Dict]) -> int:
        """
        Batch update events with resolved geodata.
        
        Uses coordinate matching with tolerance to handle floating point imprecision.
        
        Args:
            results: Dictionary mapping (lat, lon) -> {location, type}
            
        Returns:
            Number of events updated
        """
        if not results:
            return 0
        
        updated = 0
        for (lat, lon), data in results.items():
            # Update all events near this coordinate
            # Use 0.005 tolerance (~500m) to match rounded coordinates
            try:
                self.conn.execute("""
                    UPDATE events
                    SET location_geocoded = ?,
                        location_type = ?,
                        location_enriched_at = CURRENT_TIMESTAMP
                    WHERE location_lat IS NOT NULL
                      AND location_lon IS NOT NULL
                      AND location_geocoded IS NULL
                      AND ABS(location_lat - ?) < 0.005
                      AND ABS(location_lon - ?) < 0.005
                """, [data['location'], data['type'], lat, lon])
                
                # Count affected rows
                row_count = self.conn.execute("SELECT changes()").fetchone()[0]
                updated += row_count
            except Exception as e:
                print(f"  Warning: Failed to update events at ({lat}, {lon}): {e}")
        
        return updated

