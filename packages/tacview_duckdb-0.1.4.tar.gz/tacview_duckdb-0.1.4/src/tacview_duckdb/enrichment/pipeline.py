"""Enrichment pipeline orchestration."""

from abc import ABC, abstractmethod
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    import duckdb
    import queue

from ..parser.types import TacviewObject
from ..storage.duckdb_store import DuckDBStore


class Enricher(ABC):
    """Abstract base class for enrichers."""

    def __init__(self, conn: 'duckdb.DuckDBPyConnection', event_queue: 'queue.Queue' = None):
        """
        Initialize enricher with database connection.
        
        Args:
            conn: DuckDB connection for queries and updates
        """
        self.conn = conn
        if event_queue is not None:
            self.queue = event_queue

    @abstractmethod
    def enrich(self) -> int:
        """
        Enrich objects with additional data.
        
        Returns:
            Number of objects enriched
        """
        pass


class EnrichmentPipeline:
    """Pipeline for running multiple enrichers."""

    def __init__(self, store: DuckDBStore):
        """
        Initialize enrichment pipeline.

        Args:
            store: DuckDB store instance
        """
        self.store = store
        self.enrichers: List[Enricher] = []

    def add_enricher(self, enricher: Enricher):
        """
        Add enricher to pipeline.

        Args:
            enricher: Enricher instance
        """
        self.enrichers.append(enricher)

    def run(self, objects: List[TacviewObject]):
        """
        Run all enrichers in sequence.

        Args:
            objects: List of TacviewObject instances
        """
        for enricher in self.enrichers:
            enricher.enrich(objects, self.store)
