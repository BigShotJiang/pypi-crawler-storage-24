"""Command-line interface for py-tacview-duckdb."""

import argparse
import sys
from pathlib import Path

from ..api import parse_acmi
from ..storage.duckdb_store import DuckDBStore
from ..__version__ import __version__


def stream_command(args) -> int:
    """Run the real-time telemetry stream command."""
    import asyncio
    import signal

    from ..api import stream_tacview

    def on_mission_start(token: str, store) -> None:
        print(f"[stream] Mission started  token={token}  db={Path(store.database_path).name}")

    def on_mission_end(token: str, store) -> None:
        print(f"[stream] Mission finished  token={token}  db={Path(store.database_path).name}")

    async def _run():
        print(
            f"[stream] Connecting to {args.telemetry}:{args.port}"
            + (" (password set)" if args.password else " (no password)")
        )
        print("[stream] Press Ctrl+C to stop")
        try:
            enrichments = None  # product-specific defaults
            if args.no_enrich:
                enrichments = []
            elif args.enrich:
                enrichments = [e.strip() for e in args.enrich.split(",")]

            await stream_tacview(
                host=args.telemetry,
                port=args.port,
                client_hostname=args.client_hostname,
                password=args.password,
                output_dir=args.output,
                connection_timeout=args.connection_timeout,
                time_flush_interval=args.time_flush_interval,
                flush_threshold=args.flush_threshold,
                enrichments=enrichments,
                enable_jit_enrichments=args.jit_enrichments,
                on_mission_start=on_mission_start,
                on_mission_end=on_mission_end,
            )
        except asyncio.CancelledError:
            pass

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    main_task = None

    def _stop(signum, frame):
        if main_task and not main_task.done():
            main_task.cancel()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    try:
        main_task = loop.create_task(_run())
        loop.run_until_complete(main_task)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        loop.close()

    print("[stream] Stopped")
    return 0

# Load .env file if available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed, env vars must be set manually


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="tacview-parse",
        description="Parse Tacview ACMI files into DuckDB, or stream live telemetry.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Parse local ACMI file
  tacview-parse --input recording.acmi -o timeline_data/

  # Parse with JIT enrichments
  tacview-parse --input recording.acmi --jit

  # Parse without enrichments (fast)
  tacview-parse --input recording.acmi --no-enrich

  # Show summary / query existing database
  tacview-parse --input timeline_data/a3f5d9c2b1e8f4a7.duckdb --summary
  tacview-parse --input timeline_data/a3f5d9c2b1e8f4a7.duckdb --query "SELECT COUNT(*) FROM objects"

  # Stream real-time telemetry
  tacview-parse --telemetry 192.168.1.10
  tacview-parse --telemetry 192.168.1.10 --port 42674 --password secret -o timeline_data/
        """,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    # --- input source (mutually exclusive) ---
    src = parser.add_mutually_exclusive_group()
    src.add_argument(
        "--input", "--file", "--acmi",
        metavar="PATH",
        dest="file",
        help="ACMI recording or .duckdb database file to parse / query",
    )
    src.add_argument(
        "--telemetry", "--stream",
        metavar="HOST",
        help="Connect to Tacview real-time telemetry server at HOST",
    )

    # --- shared options ---
    parser.add_argument("-o", "--output", default="timeline_data",
                        help="Output directory (default: timeline_data)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")

    # --- file/parse options ---
    parser.add_argument("--enrich",
                        help="Comma-separated enrichments (weapons,coalitions,...). Default: auto per product")
    parser.add_argument("--no-enrich", action="store_true", help="Disable all enrichments")
    parser.add_argument("--async", "--async-enrichments", dest="async_enrichments",
                        action="store_true", help="Run enrichments in background thread")
    parser.add_argument("--keep", action="store_true",
                        help="Keep existing database (default: drop and recreate)")
    parser.add_argument("--legacy-mode", action="store_true",
                        help="Use legacy state storage mode")
    parser.add_argument("--jit", "--jit-enrichments", dest="jit_enrichments",
                        action="store_true", default=None,
                        help="Enable JIT enrichments. Default ON for --telemetry, OFF for --input")
    parser.add_argument("--no-jit", dest="jit_enrichments",
                        action="store_false",
                        help="Disable JIT enrichments (useful to override --telemetry default)")
    parser.add_argument("--flush-threshold", type=int,
                        help="States to accumulate before flush (default: 50000)")
    parser.add_argument("--time-flush-interval", type=float,
                        help="Telemetry seconds between flushes (default: 120.0)")
    parser.add_argument("--summary", action="store_true", help="Show database summary")
    parser.add_argument("--query", help="Execute SQL query on database")
    parser.add_argument("--shell", action="store_true", help="Open interactive database shell")

    # --- telemetry/stream options ---
    parser.add_argument("--port", type=int, default=42674,
                        help="Telemetry port (default: 42674)")
    parser.add_argument("--password", default="", help="Telemetry password (default: empty)")
    parser.add_argument("--client-hostname", default="tacview-duckdb",
                        help="Client identifier sent in handshake (default: tacview-duckdb)")
    parser.add_argument("--connection-timeout", type=float, default=10.0,
                        help="TCP connect timeout in seconds (default: 10.0)")

    args = parser.parse_args()

    # --- dispatch ---
    if args.telemetry:
        # JIT default ON for streaming (missions can be hours long)
        if args.jit_enrichments is None:
            args.jit_enrichments = True
        return stream_command(args)

    if not args.file:
        parser.print_help()
        return 1

    try:
        input_path = Path(args.file)
        is_database = input_path.suffix == ".duckdb"

        if is_database:
            # Working with existing database
            if not input_path.exists():
                print(f"Error: Database not found: {input_path}", file=sys.stderr)
                return 1

            store = DuckDBStore.from_path(input_path)

            if args.summary or (not args.query and not args.shell):
                show_summary(store)

            if args.query:
                execute_query(store, args.query)

            if args.shell:
                open_shell(store)

        else:
            # Parsing ACMI file
            if not input_path.exists():
                print(f"Error: File not found: {input_path}", file=sys.stderr)
                return 1

            # Parse enrichments
            # Default is None = use product-specific defaults (DCS auto-enables 7 enrichments)
            enrichments = None  # default: auto-detect based on product

            if args.no_enrich:
                enrichments = []  # Explicitly disable all enrichments
            elif args.enrich:
                enrichments = [e.strip() for e in args.enrich.split(",")]

            # Parse ACMI
            store = parse_acmi(
                input_path,
                output_dir=args.output,
                enrichments=enrichments,
                async_enrichments=args.async_enrichments,
                progress=args.verbose,
                drop_existing=not args.keep,
                parquet_native=not args.legacy_mode,  # Default True, unless --legacy-mode
                enable_jit_enrichments=args.jit_enrichments,
                flush_threshold=args.flush_threshold,
                time_flush_interval=args.time_flush_interval,
            )

            # Handle async enrichments - always wait for completion in CLI
            if args.async_enrichments:
                if args.verbose:
                    print("Waiting for background enrichments to complete...")
                store.wait_for_enrichments()
                if args.verbose:
                    print("Enrichments complete!")

            if args.summary or args.verbose:
                show_summary(store)

            if args.query:
                execute_query(store, args.query)

            if args.shell:
                open_shell(store)

            if not args.verbose:
                print(f"Database created: {Path(store.database_path).name}")
                print(f"Full path: {store.database_path}")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback

            traceback.print_exc()
        return 1


def show_summary(store: DuckDBStore):
    """Show database summary."""
    summary = store.get_summary()

    print("\n=== Database Summary ===")
    print(f"Objects: {summary.get('object_count', 0)}")
    print(f"States: {summary.get('state_count', 0)}")

    if "start_time" in summary:
        print(f"Time Range: {summary['start_time']:.2f}s - {summary['end_time']:.2f}s")
        print(f"Duration: {summary['duration']:.2f}s")

    if "metadata" in summary and summary["metadata"]:
        print("\n=== Metadata ===")
        for key, value in summary["metadata"].items():
            print(f"{key}: {value}")

    print()


def execute_query(store: DuckDBStore, query: str):
    """Execute SQL query and print results."""
    try:
        results = store.query_sql(query)

        if not results:
            print("No results")
            return

        # Print as table
        if results:
            # Get column names
            columns = list(results[0].keys())
            
            # Calculate column widths
            col_widths = {col: len(col) for col in columns}
            for row in results:
                for col in columns:
                    value_str = str(row[col])
                    col_widths[col] = max(col_widths[col], len(value_str))

            # Print header
            header = " | ".join(col.ljust(col_widths[col]) for col in columns)
            print(header)
            print("-" * len(header))

            # Print rows
            for row in results:
                print(" | ".join(str(row[col]).ljust(col_widths[col]) for col in columns))

            print(f"\n{len(results)} row(s)")

    except Exception as e:
        print(f"Query error: {e}", file=sys.stderr)


def open_shell(store: DuckDBStore):
    """Open interactive database shell."""
    try:
        import duckdb
    except ImportError:
        print("Error: duckdb package required for shell", file=sys.stderr)
        return

    print(f"\nOpening interactive shell for: {store.database_path}")
    print("Type SQL queries or .exit to quit\n")

    conn = store.get_query_connection()

    while True:
        try:
            query = input("duckdb> ")
            
            if not query.strip():
                continue
                
            if query.strip() in [".exit", ".quit", "exit", "quit"]:
                break

            # Execute query
            result = conn.execute(query).fetchall()
            
            if result:
                # Get column names
                columns = [desc[0] for desc in conn.description]
                
                # Print header
                print(" | ".join(columns))
                print("-" * (sum(len(col) for col in columns) + 3 * (len(columns) - 1)))
                
                # Print rows
                for row in result:
                    print(" | ".join(str(val) for val in row))
                    
                print(f"\n{len(result)} row(s)\n")
            else:
                print("Query executed successfully\n")

        except KeyboardInterrupt:
            print("\nUse .exit to quit")
        except EOFError:
            break
        except Exception as e:
            print(f"Error: {e}\n")

    conn.close()
    print("Goodbye!")


if __name__ == "__main__":
    sys.exit(main())
