"""Asyncio TCP client for Tacview real-time telemetry.

Mirrors the reconnect/stream logic from skyeye/pkg/telemetry/telemetry.go.

Connection lifecycle:
  1. TCP connect with timeout
  2. Read host handshake (null-terminated)
  3. Send client handshake (with hashed password)
  4. Read ACMI lines until EOF / timeout / error
  5. On failure: wait 10 seconds, reconnect (alternating CRC algorithm)
  6. Grace period: if no data received for 10 minutes, force reconnect
"""

from __future__ import annotations

import asyncio
import logging
from typing import AsyncIterator, Callable, Awaitable, Optional

from .handshake import (
    HostHandshake,
    ClientHandshake,
    HashAlgorithm,
    PACKET_TERMINATOR,
)

logger = logging.getLogger(__name__)

DEFAULT_PORT = 42674
_RECONNECT_DELAY_SECONDS = 10.0
_GRACE_PERIOD_SECONDS = 600.0  # 10 minutes


class RealTimeTelemetryClient:
    """
    Asyncio TCP client for Tacview real-time telemetry.

    Connects to a Tacview server, performs the XtraLib handshake, then
    yields ACMI lines for as long as the context runs. Automatically
    reconnects on error with a 10-second backoff and alternates the
    password-hash algorithm on each attempt (matching the Go reference).

    Usage::

        client = RealTimeTelemetryClient(
            host="192.168.1.10",
            port=42674,
            client_hostname="my-client",
            password="",
            connection_timeout=10.0,
        )
        async for line in client.lines(ctx):
            process(line)

    Or with a callback::

        await client.run(ctx, on_line=process_line)
    """

    def __init__(
        self,
        host: str,
        port: int = DEFAULT_PORT,
        client_hostname: str = "tacview-duckdb",
        password: str = "",
        connection_timeout: float = 10.0,
    ):
        self.host = host
        self.port = port
        self.client_hostname = client_hostname
        self.password = password
        self.connection_timeout = connection_timeout

        # Alternates on every reconnect attempt (CRC64WE first, like Go)
        self._hash_algorithm = HashAlgorithm.CRC64WE

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(
        self,
        ctx: asyncio.AbstractEventLoop | None = None,
        on_line: Optional[Callable[[str], Awaitable[None]]] = None,
    ) -> None:
        """
        Run the client until the task is cancelled.

        Args:
            ctx: Unused – cancellation is handled via task cancellation.
            on_line: Async callback invoked with each ACMI line received.
                     If None, lines are silently discarded.
        """
        async for line in self.lines():
            if on_line is not None:
                await on_line(line)

    async def lines(self) -> AsyncIterator[str]:
        """
        Async generator that yields ACMI lines indefinitely, reconnecting on failure.

        Yields:
            Decoded ACMI text lines (without trailing newline).

        Note:
            The generator will re-yield the ACMI file header (FileType=, FileVersion=,
            and global object-0 lines) on each reconnect because Tacview re-sends the
            full header when a client connects.
        """
        while True:
            try:
                async for line in self._connect_and_stream():
                    yield line
            except asyncio.CancelledError:
                logger.info("Telemetry client cancelled")
                return
            except Exception as exc:
                logger.error("Telemetry read error, reconnecting in %ss: %s",
                             _RECONNECT_DELAY_SECONDS, exc)
                try:
                    await asyncio.sleep(_RECONNECT_DELAY_SECONDS)
                except asyncio.CancelledError:
                    return

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _connect_and_stream(self) -> AsyncIterator[str]:
        """Open one TCP connection, handshake, then stream lines."""
        logger.info("Connecting to %s:%s", self.host, self.port)
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(self.host, self.port),
                timeout=self.connection_timeout,
            )
        except asyncio.TimeoutError:
            raise ConnectionError(
                f"Connection to {self.host}:{self.port} timed out after {self.connection_timeout}s"
            )

        try:
            await self._handshake(reader, writer)
            logger.info("Handshake complete, reading ACMI stream")
            async for line in self._read_lines(reader):
                yield line
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            # Alternate algorithm for next reconnect
            self._hash_algorithm = self._hash_algorithm.next()

    async def _handshake(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """
        Perform the host ↔ client handshake.

        1. Read null-terminated host handshake.
        2. Log host info.
        3. Send client handshake with hashed password.
        """
        # Read until null byte
        host_packet_bytes = await reader.readuntil(b"\x00")
        host_packet = host_packet_bytes.decode("utf-8", errors="replace")
        host_hs = HostHandshake.decode(host_packet)
        logger.info(
            "Host handshake: hostname=%r llp=%s hlp=%s",
            host_hs.hostname,
            host_hs.low_level_protocol_version,
            host_hs.high_level_protocol_version,
        )

        client_hs = ClientHandshake(
            hostname=self.client_hostname,
            password=self.password,
        )
        payload = client_hs.encode(self._hash_algorithm)
        logger.debug(
            "Sending client handshake: hostname=%r algorithm=%s",
            self.client_hostname,
            self._hash_algorithm,
        )
        writer.write(payload.encode("utf-8"))
        await writer.drain()

    async def _read_lines(self, reader: asyncio.StreamReader) -> AsyncIterator[str]:
        """
        Read ACMI lines from the stream, handling:
          - Line continuations (backslash at end of line)
          - Grace period (10 min without data → raise)
          - EOF
        """
        accumulated: list[str] = []
        last_data_time = asyncio.get_event_loop().time()

        while True:
            # Enforce grace period
            elapsed = asyncio.get_event_loop().time() - last_data_time
            if elapsed > _GRACE_PERIOD_SECONDS:
                raise TimeoutError(
                    f"No data received for {_GRACE_PERIOD_SECONDS:.0f}s (grace period exceeded)"
                )

            try:
                raw = await asyncio.wait_for(
                    reader.readline(),
                    timeout=60.0,  # wake up periodically to check grace period
                )
            except asyncio.TimeoutError:
                continue  # loop back → re-check grace period

            if not raw:
                raise EOFError("Connection closed by remote host")

            last_data_time = asyncio.get_event_loop().time()
            line = raw.decode("utf-8", errors="replace").rstrip("\n\r")

            # Handle line continuation (backslash at end)
            if line.endswith("\\"):
                accumulated.append(line[:-1] + "\n")
                continue

            if accumulated:
                line = "".join(accumulated) + line
                accumulated.clear()

            yield line
