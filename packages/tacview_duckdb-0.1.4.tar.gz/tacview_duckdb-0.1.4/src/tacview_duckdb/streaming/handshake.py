"""Tacview real-time telemetry handshake protocol.

Implements the XtraLib.Stream / Tacview.RealTimeTelemetry handshake as described
in the Tacview real-time telemetry specification and mirroring the Go implementation
in skyeye/pkg/telemetry/handshake.go.

Protocol:
  1. Host sends: "XtraLib.Stream.0\\nTacview.RealTimeTelemetry.0\\n<hostname>\\n\\x00"
  2. Client responds: "XtraLib.Stream.0\\nTacview.RealTimeTelemetry.0\\n<hostname>\\n<password_hash>\\x00"

Password hashing:
  - Encode password as UTF-16LE bytes
  - Apply CRC-64/WE or CRC-32/ISO-HDLC
  - Format as lowercase hex (no zero-padding, "0" for empty password)
  - Algorithm alternates CRC-64/WE ↔ CRC-32/ISO-HDLC on each reconnect attempt
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import crcmod

LOW_LEVEL_PROTOCOL = "XtraLib.Stream"
LOW_LEVEL_PROTOCOL_VERSION = "0"
HIGH_LEVEL_PROTOCOL = "Tacview.RealTimeTelemetry"
HIGH_LEVEL_PROTOCOL_VERSION = "0"

# Null-byte packet terminator used in handshake
PACKET_TERMINATOR = "\x00"


class HashAlgorithm(Enum):
    """CRC hash algorithm used for password hashing."""
    CRC64WE = "CRC-64/WE"
    CRC32ISOHDLC = "CRC-32/ISO-HDLC"

    def __str__(self) -> str:
        return self.value

    def next(self) -> "HashAlgorithm":
        """Return the other algorithm (for alternating on reconnect)."""
        if self == HashAlgorithm.CRC64WE:
            return HashAlgorithm.CRC32ISOHDLC
        return HashAlgorithm.CRC64WE


# CRC-64/WE: poly=0x42F0E1EBA9EA3693, init=0xFFFFFFFFFFFFFFFF, refin=False, refout=False, xorout=0xFFFFFFFFFFFFFFFF
_crc64we_fn = crcmod.predefined.mkCrcFun("crc-64-we")

# CRC-32/ISO-HDLC: poly=0x04C11DB7, init=0xFFFFFFFF, refin=True, refout=True, xorout=0xFFFFFFFF
# (same as CRC-32/BZIP2 but with bit reflection — crcmod "crc-32" is CRC-32/ISO-HDLC)
_crc32isohdlc_fn = crcmod.predefined.mkCrcFun("crc-32")


def hash_password(password: str, algorithm: HashAlgorithm) -> str:
    """
    Hash a Tacview telemetry password using the given CRC algorithm.

    The password is UTF-16LE encoded before hashing, matching the Tacview
    and Go reference implementations.

    Args:
        password: Plain-text password (empty string for no password).
        algorithm: Which CRC algorithm to use.

    Returns:
        Lowercase hex string without zero-padding. Returns "0" for empty password.

    Examples:
        >>> hash_password("", HashAlgorithm.CRC64WE)
        '0'
        >>> hash_password("", HashAlgorithm.CRC32ISOHDLC)
        '0'
        >>> hash_password("local", HashAlgorithm.CRC32ISOHDLC)
        'e528f7a6'
        >>> hash_password("local", HashAlgorithm.CRC64WE)
        '16d6497244e5930b'
    """
    if not password:
        return "0"

    # Encode as UTF-16LE (little-endian, no BOM)
    utf16_bytes = password.encode("utf-16-le")

    if algorithm == HashAlgorithm.CRC64WE:
        value = _crc64we_fn(utf16_bytes)
    else:
        value = _crc32isohdlc_fn(utf16_bytes)

    return format(value, "x")


@dataclass
class HostHandshake:
    """Handshake packet sent by the Tacview host (server)."""

    hostname: str = ""
    low_level_protocol_version: str = LOW_LEVEL_PROTOCOL_VERSION
    high_level_protocol_version: str = HIGH_LEVEL_PROTOCOL_VERSION

    def encode(self) -> str:
        """Encode to wire format (null-terminated string)."""
        packet = (
            f"{LOW_LEVEL_PROTOCOL}.{self.low_level_protocol_version}\n"
            f"{HIGH_LEVEL_PROTOCOL}.{self.high_level_protocol_version}\n"
            f"{self.hostname}\n"
            f"{PACKET_TERMINATOR}"
        )
        return packet

    @classmethod
    def decode(cls, packet: str) -> "HostHandshake":
        """
        Decode a host handshake from the wire format.

        Args:
            packet: Raw packet string (may include null terminator).

        Returns:
            Decoded HostHandshake instance.
        """
        handshake = cls()
        for line in packet.split("\n"):
            line = line.rstrip(PACKET_TERMINATOR)
            if not line:
                continue
            if line.startswith(LOW_LEVEL_PROTOCOL + "."):
                handshake.low_level_protocol_version = line[len(LOW_LEVEL_PROTOCOL) + 1:]
            elif line.startswith(HIGH_LEVEL_PROTOCOL + "."):
                handshake.high_level_protocol_version = line[len(HIGH_LEVEL_PROTOCOL) + 1:]
            else:
                handshake.hostname = line
        return handshake


@dataclass
class ClientHandshake:
    """Handshake packet sent by the client in response to the host."""

    hostname: str
    password: str = ""
    low_level_protocol_version: str = LOW_LEVEL_PROTOCOL_VERSION
    high_level_protocol_version: str = HIGH_LEVEL_PROTOCOL_VERSION

    def encode(self, algorithm: HashAlgorithm = HashAlgorithm.CRC64WE) -> str:
        """
        Encode to wire format (null-terminated string).

        Args:
            algorithm: Hash algorithm to use for the password.

        Returns:
            Encoded packet string.
        """
        pw_hash = hash_password(self.password, algorithm)
        packet = (
            f"{LOW_LEVEL_PROTOCOL}.{self.low_level_protocol_version}\n"
            f"{HIGH_LEVEL_PROTOCOL}.{self.high_level_protocol_version}\n"
            f"{self.hostname}\n"
            f"{pw_hash}"
            f"{PACKET_TERMINATOR}"
        )
        return packet

    @classmethod
    def decode(cls, packet: str) -> "ClientHandshake":
        """
        Decode a client handshake from the wire format.

        Args:
            packet: Raw packet string.

        Returns:
            Decoded ClientHandshake instance.
        """
        lines = packet.split("\n")
        handshake = cls(hostname="")
        for i, line in enumerate(lines):
            # Strip null terminator from last meaningful line
            line = line.rstrip(PACKET_TERMINATOR)
            if not line:
                continue
            if line.startswith(LOW_LEVEL_PROTOCOL + "."):
                handshake.low_level_protocol_version = line[len(LOW_LEVEL_PROTOCOL) + 1:]
            elif line.startswith(HIGH_LEVEL_PROTOCOL + "."):
                handshake.high_level_protocol_version = line[len(HIGH_LEVEL_PROTOCOL) + 1:]
            elif i == 2:
                handshake.hostname = line
            elif i >= 3:
                # The last field is the password hash (stored as-is, not reversible)
                handshake.password = line  # This is the hash, not the plain password
        return handshake
