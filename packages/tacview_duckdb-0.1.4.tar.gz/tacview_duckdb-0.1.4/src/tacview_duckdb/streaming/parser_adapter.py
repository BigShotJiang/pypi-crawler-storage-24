"""Bridges RealTimeTelemetryClient → ACMIParser + ParquetIngestionStrategy.

The adapter:
  1. Consumes async lines from RealTimeTelemetryClient
  2. Feeds them synchronously into ACMIParser._parse_stream() via a queue bridge
  3. Detects mission changes (new FileType= header mid-stream) and resets the
     parser + DuckDBStore for the new mission, generating a fresh mission token
  4. Configures ParquetIngestionStrategy with streaming-optimised flush params
"""

from __future__ import annotations

import asyncio
import logging
import math
import queue
import threading
from pathlib import Path
from typing import AsyncIterator, Callable, Optional

from ..constants import METERS_PER_DEGREE_LAT
from ..parser.acmi_parser import ACMIParser
from ..storage.duckdb_store import DuckDBStore
from ..storage.ingestion import ParquetIngestionStrategy

logger = logging.getLogger(__name__)

# Sentinel to signal the sync reader that the async producer is done
_SENTINEL = object()

# Streaming-optimised flush parameters
_DEFAULT_TIME_FLUSH_INTERVAL = 5.0   # telemetry seconds between flushes
_DEFAULT_FLUSH_THRESHOLD = 0         # flush on every time tick (safety: 0 = time-based only)


class StreamingParserAdapter:
    """
    Connects a RealTimeTelemetryClient to an ACMIParser pipeline.

    The adapter bridges the async TCP stream to the synchronous parser by
    running the parser in a background thread fed via an in-process queue.

    Usage::

        adapter = StreamingParserAdapter(
            output_dir="timeline_data/",
            client_hostname="tacview-duckdb",
        )
        await adapter.run(client)                # blocks until cancelled
        store = adapter.current_store            # query live data any time

    Mission changes:
        When a new ``FileType=`` line appears mid-stream (Tacview mission restart),
        the adapter finalises the current parser, creates a new DuckDBStore for the
        new mission, and continues parsing seamlessly.
    """

    def __init__(
        self,
        output_dir: str | Path = "timeline_data",
        time_flush_interval: float = _DEFAULT_TIME_FLUSH_INTERVAL,
        flush_threshold: int = _DEFAULT_FLUSH_THRESHOLD,
        enrichments: Optional[list] = None,
        enable_jit_enrichments: bool = True,
        on_mission_start: Optional[Callable[[str, DuckDBStore], None]] = None,
        on_mission_end: Optional[Callable[[str, DuckDBStore], None]] = None,
        on_events: Optional[Callable[[str, list], None]] = None,
    ):
        """
        Args:
            output_dir: Directory where per-mission DuckDB databases are stored.
            time_flush_interval: Telemetry seconds between Parquet flushes (default 5s).
            flush_threshold: Count-based safety flush threshold (default 0 = disabled).
            enrichments: List of enrichment names to apply after each mission finalises.
                         None = product-specific defaults (DCS auto-enables all),
                         [] = no enrichments.
            enable_jit_enrichments: Enable JIT enrichments during streaming (default False).
            on_mission_start: Optional callback invoked with (mission_token, store) when
                              a new mission begins (after header is parsed).
            on_mission_end: Optional callback invoked with (mission_token, store) when
                            the current mission ends / is replaced.
            on_events: Optional callback invoked with (mission_token, events) after each
                       DB flush. events is a list of (object_id, timestamp, event_name,
                       event_params) tuples. Called only when events exist and only after
                       all states/objects are committed to DB.
        """
        self.output_dir = Path(output_dir)
        self.time_flush_interval = time_flush_interval
        self.flush_threshold = flush_threshold
        self.enrichments = enrichments
        self.enable_jit_enrichments = enable_jit_enrichments
        self.on_mission_start = on_mission_start
        self.on_mission_end = on_mission_end
        self.on_events = on_events

        self.current_store: Optional[DuckDBStore] = None
        self.current_mission_token: Optional[str] = None
        self._parser: Optional[ACMIParser] = None
        self._strategy: Optional[ParquetIngestionStrategy] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(self, line_source: AsyncIterator[str]) -> None:
        """
        Consume lines from an async iterator and feed them to the parser.

        Intended to be driven by RealTimeTelemetryClient.lines()::

            async for line in client.lines():
                ...

        but accepts any async iterator of ACMI lines.

        Args:
            line_source: Async iterator yielding ACMI text lines.
        """
        line_queue: queue.Queue = queue.Queue(maxsize=10000)

        # Start background parser thread
        parse_thread = threading.Thread(
            target=self._parser_thread,
            args=(line_queue,),
            name="ACMIParserThread",
            daemon=True,
        )
        parse_thread.start()

        try:
            async for line in line_source:
                line_queue.put(line)
        except asyncio.CancelledError:
            logger.info("StreamingParserAdapter cancelled")
        except Exception as exc:
            logger.error("Error reading line source: %s", exc)
        finally:
            line_queue.put(_SENTINEL)
            parse_thread.join(timeout=30.0)

    # ------------------------------------------------------------------
    # Internal: parser thread
    # ------------------------------------------------------------------

    def _parser_thread(self, line_queue: queue.Queue) -> None:
        """
        Run in a background thread: dequeue lines and feed to ACMIParser.

        Detects mission-change headers (new FileType= after initial header)
        and resets the pipeline for the new mission.

        Header accumulation strategy:
          - Collect header lines until we see the first timestamp (#) or
            a non-global object line, so we have enough metadata to build
            the mission token and initialise DuckDBStore.
          - Header lines are fed to the parser AFTER the parser is created,
            so they are only processed once.
        """
        header_lines: list[str] = []
        header_complete = False
        in_mission = False

        for line in self._dequeue_lines(line_queue):
            # ---- Mission change detection ----
            # A new FileType= line after the initial header signals a new mission
            if line.startswith("FileType=") and in_mission:
                logger.info("Mission change detected — resetting pipeline")
                self._finalize_current_mission()
                header_lines = [line]
                header_complete = False
                in_mission = False
                continue

            # ---- Header accumulation (before first mission starts) ----
            if not header_complete:
                header_lines.append(line)
                # Header is complete once we see the first time-frame or a
                # non-header object line (anything with a comma that isn't "0,")
                is_timestamp = line.startswith("#")
                is_data_object = (
                    "," in line
                    and not line.startswith("FileType=")
                    and not line.startswith("FileVersion=")
                    and not line.startswith("0,")
                )
                if is_timestamp or is_data_object:
                    header_complete = True
                    # Initialise parser with the accumulated header lines
                    # (includes the current line — _start_mission feeds all of them)
                    self._start_mission(header_lines)
                    in_mission = True
                continue

            # ---- Normal ACMI data ----
            self._feed_line(line)

        # Stream ended — finalise whatever mission is active
        if in_mission:
            self._finalize_current_mission()

    def _dequeue_lines(self, line_queue: queue.Queue):
        """Generator: yield lines from queue until sentinel."""
        while True:
            item = line_queue.get()
            if item is _SENTINEL:
                return
            yield item

    # ------------------------------------------------------------------
    # Internal: mission lifecycle
    # ------------------------------------------------------------------

    def _start_mission(self, header_lines: list[str]) -> None:
        """Initialise DuckDBStore + ACMIParser for a new mission."""
        header_chunk = "\n".join(header_lines)
        token = ACMIParser.generate_mission_token(header_chunk)
        logger.info("Starting mission token=%s", token)

        # Parse metadata from header for store initialisation
        metadata = self._extract_metadata(header_lines)

        store = DuckDBStore(self.output_dir)
        store.initialize_from_metadata(metadata, drop_existing=True)

        # Register distance UDF (needed by JIT enrichments)
        meters_lat = METERS_PER_DEGREE_LAT
        meters_lon = METERS_PER_DEGREE_LAT
        ref_lat = metadata.get("ReferenceLatitude")
        if ref_lat:
            try:
                meters_lon = METERS_PER_DEGREE_LAT * math.cos(math.radians(float(ref_lat)))
            except (TypeError, ValueError):
                pass
        _ml, _mo = meters_lat, meters_lon

        def _calc_dist_sq(delta_lat: float, delta_lon: float) -> float:
            return (delta_lat * _ml) ** 2 + (delta_lon * _mo) ** 2

        try:
            import duckdb.sqltypes as _sqltypes
            store.register_udf("calculate_approximate_distance_squared", _calc_dist_sq,
                               [_sqltypes.DOUBLE, _sqltypes.DOUBLE], _sqltypes.DOUBLE)
        except Exception:
            import duckdb.typing as _typing
            store.register_udf("calculate_approximate_distance_squared", _calc_dist_sq,
                               [_typing.DOUBLE, _typing.DOUBLE], _typing.DOUBLE)

        store.begin_bulk_load()

        # Guard against None flush params passed from CLI
        time_flush = self.time_flush_interval if self.time_flush_interval is not None else _DEFAULT_TIME_FLUSH_INTERVAL
        flush_thresh = self.flush_threshold if self.flush_threshold is not None else _DEFAULT_FLUSH_THRESHOLD

        staging_dir = self.output_dir / ".staging" / store.db_hash / "states"
        strategy = ParquetIngestionStrategy(
            store=store,
            flush_threshold=flush_thresh,
            enable_jit_enrichments=self.enable_jit_enrichments,
            time_flush_interval=time_flush,
            post_flush_hook=self._on_post_flush,
        )
        strategy.initialize(staging_dir)

        parser = ACMIParser(store=store, ingestion_strategy=strategy)

        self.current_store = store
        self.current_mission_token = token
        self._parser = parser
        self._strategy = strategy

        # Feed all accumulated header lines (including the triggering timestamp /
        # object line) through the parser so metadata and reference coords are set.
        for line in header_lines:
            if line:
                self._feed_line(line)

        if self.on_mission_start:
            try:
                self.on_mission_start(token, store)
            except Exception as exc:
                logger.error("on_mission_start callback raised: %s", exc)

    def _finalize_current_mission(self) -> None:
        """Flush and close the current parser/store, then run enrichments."""
        if self._strategy is not None:
            try:
                self._strategy.finalize()
            except Exception as exc:
                logger.error("Error finalizing ingestion strategy: %s", exc)

        self._parser = None
        self._strategy = None

        if self.current_store is not None:
            try:
                self.current_store.end_bulk_load()
                self.current_store.create_indexes()
            except Exception as exc:
                logger.error("Error finalizing store: %s", exc)

            try:
                self._run_enrichments(self.current_store)
            except Exception as exc:
                logger.error("Error running enrichments: %s", exc)

        if self.on_mission_end and self.current_mission_token and self.current_store:
            try:
                self.on_mission_end(self.current_mission_token, self.current_store)
            except Exception as exc:
                logger.error("on_mission_end callback raised: %s", exc)

        logger.info("Mission %s finalised", self.current_mission_token)

    def _run_enrichments(self, store: DuckDBStore) -> None:
        """Apply post-parse enrichments to a finalised mission store."""
        metadata = store.get_metadata() if hasattr(store, 'get_metadata') else {}
        data_source = metadata.get('DataSource', '') if metadata else ''

        enrichments = self.enrichments
        if enrichments is None:
            # Product-specific defaults — mirror batch behaviour
            if data_source.startswith('DCS'):
                enrichments = [
                    'coalitions', 'ejections', 'containers', 'decoys',
                    'weapons', 'missed_weapons', 'lifecycle',
                ]
            else:
                enrichments = []

        if not enrichments:
            return

        logger.info("Running enrichments for mission %s: %s", self.current_mission_token, enrichments)
        store.apply_enrichments(enrichments=enrichments, async_enrichments=False, progress=False)

    def _on_post_flush(self) -> None:
        """Called by strategy after each DB flush. Drains parser events to DB and emits callback."""
        if self._parser is None or not self._parser.events:
            return

        events = list(self._parser.events)
        self._parser.events.clear()

        if self.current_store is not None:
            try:
                self.current_store.add_events(events)
                # Commit so read connections can see events immediately (MVCC)
                self.current_store.commit_and_reopen_transaction()
            except Exception as exc:
                logger.error("Error writing events to DB in post_flush: %s", exc)
                return

        if self.on_events and self.current_mission_token:
            try:
                self.on_events(self.current_mission_token, events)
            except Exception as exc:
                logger.warning("on_events callback error: %s", exc)

    def _feed_line(self, line: str) -> None:
        """Feed a single ACMI line into the parser's internal handler."""
        if self._parser is None:
            return
        try:
            # Reuse the parser's internal line-dispatch logic
            self._parser._handle_line(line)
        except Exception as exc:
            logger.warning("Parser error on line %r: %s", line[:80], exc)

    # ------------------------------------------------------------------
    # Internal: header metadata extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_metadata(header_lines: list[str]) -> dict:
        """
        Extract mission metadata from header lines for DuckDBStore initialisation.

        Parses FileType, FileVersion and global object-0 properties.
        """
        import math
        from ..constants import METERS_PER_DEGREE_LAT
        from ..__version__ import __version__

        metadata: dict = {}
        for line in header_lines:
            if line.startswith("FileType="):
                metadata["FileType"] = line.split("=", 1)[1]
            elif line.startswith("FileVersion="):
                metadata["FileVersion"] = line.split("=", 1)[1]
            elif line.startswith("0,"):
                props_str = line[2:]
                parts = props_str.split(",")
                for part in parts:
                    if "=" in part:
                        k, v = part.split("=", 1)
                        metadata[k.strip()] = v.strip()

        metadata["parser_version"] = __version__
        metadata["MetersPerDegLat"] = METERS_PER_DEGREE_LAT
        ref_lat = metadata.get("ReferenceLatitude")
        if ref_lat:
            try:
                metadata["MetersPerDegLon"] = METERS_PER_DEGREE_LAT * math.cos(
                    math.radians(float(ref_lat))
                )
            except (ValueError, TypeError):
                metadata["MetersPerDegLon"] = METERS_PER_DEGREE_LAT
        else:
            metadata["MetersPerDegLon"] = METERS_PER_DEGREE_LAT

        return metadata
