"""Data types for ACMI parsing."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import math

from ..constants import EARTH_G


@dataclass
class Transform:
    """Transform data from ACMI file with computed kinematic fields."""

    # Raw data from ACMI
    longitude: Optional[float] = None
    latitude: Optional[float] = None
    altitude: Optional[float] = None  # meters MSL
    agl: Optional[float] = None  # meters AGL (DCS 1.9.5+ aircraft only)
    roll: Optional[float] = None  # degrees
    pitch: Optional[float] = None  # degrees
    yaw: Optional[float] = None  # degrees
    u: Optional[float] = None  # Flat world X coordinate (meters)
    v: Optional[float] = None  # Flat world Y coordinate (meters)
    heading: Optional[float] = None  # degrees

    # Computed kinematic fields
    speed: Optional[float] = None  # m/s - 3D speed (TAS)
    vertical_speed: Optional[float] = None  # m/s
    turn_rate: Optional[float] = None  # deg/sec
    turn_radius: Optional[float] = None  # meters
    
    # Airspeed (from BMS or calculated from TAS)
    mach: Optional[float] = None  # Mach number
    ias: Optional[float] = None  # m/s - Indicated Airspeed
    cas: Optional[float] = None  # m/s - Calibrated Airspeed (Tacview formula)
    
    # Angles (from BMS or calculated)
    aoa: Optional[float] = None  # degrees - Angle of Attack
    aos: Optional[float] = None  # degrees - Angle of Sideslip
    
    # Acceleration (m/s²) - world frame
    ax: Optional[float] = None
    ay: Optional[float] = None
    az: Optional[float] = None
    
    # G-forces (body frame - from BMS or calculated)
    g_vertical: Optional[float] = None  # 1.0 = 1g (cockpit g-meter)
    g_lateral: Optional[float] = None  # 1.0 = 1g (sideslip)
    g_longitudinal: Optional[float] = None  # 1.0 = 1g (acceleration/deceleration)
    
    # Legacy g_load (kept for backward compatibility, maps to g_vertical)
    g_load: Optional[float] = None
    
    # Energy state (for fixed-wing aircraft)
    potential_energy: Optional[float] = None  # Joules (PE = mgh)
    kinetic_energy: Optional[float] = None    # Joules (KE = 0.5mv²)
    specific_energy: Optional[float] = None   # meters (Es = h + v²/2g)


@dataclass
class ObjectState:
    """Object state at a specific timestamp."""

    timestamp: float
    transform: Transform
    properties: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TacviewObject:
    """Tacview object with all attributes and states."""

    object_id: str
    name: Optional[str] = None
    type: Optional[str] = None
    type_class: Optional[str] = None
    type_attributes: Optional[str] = None  # Comma-separated attributes
    type_basic: Optional[str] = None
    type_specific: Optional[str] = None
    pilot: Optional[str] = None
    group: Optional[str] = None
    coalition: Optional[str] = None
    color: Optional[str] = None
    country: Optional[str] = None
    parent_id: Optional[str] = None  # For weapons - launching platform object_id
    properties: Dict[str, Any] = field(default_factory=dict)
    states: List[ObjectState] = field(default_factory=list)

    # Computed fields
    first_seen: Optional[float] = None
    last_seen: Optional[float] = None
    removed_at: Optional[float] = None  # Timestamp when object was explicitly removed
    
    # Keep first and last states for efficient enrichment (spawn/impact detection)
    first_state: Optional[ObjectState] = None
    last_state: Optional[ObjectState] = None

    def should_compute_kinematics(self) -> str:
        """
        Determine what kinematics to compute based on parsed object type.
        
        Returns:
            'full' - All kinematics (aircraft, weapons)
            'speed' - Speed only (ground vehicles, ships)
            'none' - No kinematics (static, decoys, buildings)
        """
        # Check if static
        if self.type_attributes and 'Static' in self.type_attributes:
            return 'none'
        
        # Aircraft - full kinematics
        if self.type_class == 'Air':
            return 'full'
        
        # Weapons - full kinematics
        if self.type_class == 'Weapon':
            return 'full'
        
        # Ground vehicles - speed only (not static)
        if self.type_class == 'Ground' and self.type_basic in ['Vehicle', 'Armor', 'AntiAircraft']:
            return 'speed'
        
        # Ships - speed only
        if self.type_class == 'Sea':
            return 'speed'
        
        # Everything else (buildings, decoys, waypoints, etc.) - nothing
        return 'none'

    def add_state(self, new_state: ObjectState):
        """
        Add state with enhanced kinematics computation.
        Memory-efficient: keeps last 6 states for 1-second smoothing window.
        
        Computes for Air/Weapon types:
        - Velocity, speed, vertical speed, turn rate (1-second smoothing)
        - Acceleration (ax, ay, az) starting at State N=2
        - G-forces (body frame) starting at State N=2
        - Mach, CAS, IAS (from BMS or calculated)
        - AoA, AoS (from BMS or calculated)
        - Turn radius from speed and turn rate
        """
        kinematic_mode = self.should_compute_kinematics()
        
        # Target smoothing window (Tacview uses 1.0s)
        SMOOTHING_WINDOW = 1.0
        
        if len(self.states) >= 1:
            # Find the best reference state for smoothing
            # Prefer state closest to SMOOTHING_WINDOW seconds ago
            current_time = new_state.timestamp
            
            ref_state = None
            for state in self.states:  # Oldest to newest
                time_delta = current_time - state.timestamp
                if time_delta >= SMOOTHING_WINDOW:
                    ref_state = state  # Keep updating to find closest to 1s
                elif ref_state is None:
                    ref_state = state  # Use oldest if we don't have 1s yet
                    break
            
            # If no state found >= 1s, use the oldest available
            if ref_state is None:
                ref_state = self.states[0]
            
            time_delta = current_time - ref_state.timestamp
            
            if time_delta > 0:
                # 1. Compute velocity components (world frame using U/V coordinates)
                if all(x is not None for x in [
                    new_state.transform.u, new_state.transform.v, new_state.transform.altitude,
                    ref_state.transform.u, ref_state.transform.v, ref_state.transform.altitude
                ]):
                    vx = (new_state.transform.u - ref_state.transform.u) / time_delta
                    vy = (new_state.transform.v - ref_state.transform.v) / time_delta
                    vz = (new_state.transform.altitude - ref_state.transform.altitude) / time_delta
                    
                    # 2. Speed (3D TAS) - smoothed over time_delta
                    speed = math.sqrt(vx**2 + vy**2 + vz**2)
                    new_state.transform.speed = speed
                    
                    # Cache velocity for next iteration
                    new_state._velocity_cache = (vx, vy, vz)
                    new_state._velocity_time_delta = time_delta
                    
                    # 3. Acceleration (also uses smoothing)
                    if kinematic_mode == 'full':
                        if hasattr(ref_state, '_velocity_cache'):
                            prev_vx, prev_vy, prev_vz = ref_state._velocity_cache
                            
                            # Acceleration components
                            ax = (vx - prev_vx) / time_delta
                            ay = (vy - prev_vy) / time_delta
                            az = (vz - prev_vz) / time_delta
                            
                            new_state.transform.ax = ax
                            new_state.transform.ay = ay
                            new_state.transform.az = az
                            
                            # 4. G-forces calculation
                            self._calculate_gforces(new_state, ax, ay, az)
                        else:
                            # First velocity state - defaults
                            new_state.transform.ax = 0.0
                            new_state.transform.ay = 0.0
                            new_state.transform.az = 0.0
                            new_state.transform.g_vertical = 1.0
                            new_state.transform.g_lateral = 0.0
                            new_state.transform.g_longitudinal = 0.0
                            new_state.transform.g_load = 1.0
                
                # 5. Vertical speed (for all kinematic modes)
                if kinematic_mode == 'full':
                    if new_state.transform.altitude is not None and ref_state.transform.altitude is not None:
                        new_state.transform.vertical_speed = (
                            new_state.transform.altitude - ref_state.transform.altitude
                        ) / time_delta
                    
                    # 6. Mach, CAS, IAS calculations
                    self._calculate_airspeeds(new_state)
                    
                    # 7. AoA, AoS calculations (only when velocity was computed above)
                    if hasattr(new_state, '_velocity_cache'):
                        vx, vy, vz = new_state._velocity_cache
                        self._calculate_angles(new_state, vx, vy, vz)
                    
                    # 8. Energy state
                    if new_state.transform.altitude is not None and new_state.transform.speed is not None:
                        mass = 17000.0  # kg (36,000 lbs rounded)
                        new_state.transform.potential_energy = mass * EARTH_G * new_state.transform.altitude
                        new_state.transform.kinetic_energy = 0.5 * mass * (new_state.transform.speed ** 2)
                        new_state.transform.specific_energy = new_state.transform.altitude + ((new_state.transform.speed ** 2) / (2 * EARTH_G))
                    
                    # 9. Turn rate
                    if new_state.transform.yaw is not None and ref_state.transform.yaw is not None:
                        yaw_delta = new_state.transform.yaw - ref_state.transform.yaw
                        # Handle 360-degree wraparound
                        if yaw_delta > 180:
                            yaw_delta -= 360
                        elif yaw_delta < -180:
                            yaw_delta += 360
                        new_state.transform.turn_rate = yaw_delta / time_delta
                        
                        # 10. Turn radius
                        if new_state.transform.speed and abs(new_state.transform.turn_rate) > 0.01:
                            omega_rad = abs(new_state.transform.turn_rate) * math.pi / 180.0
                            new_state.transform.turn_radius = new_state.transform.speed / omega_rad
        
        # Update state buffer
        if self.first_state is None:
            self.first_state = new_state
            # First state defaults for full kinematics
            if self.should_compute_kinematics() == 'full':
                if new_state.transform.g_vertical is None:
                    new_state.transform.g_vertical = 1.0
                if new_state.transform.g_lateral is None:
                    new_state.transform.g_lateral = 0.0
                if new_state.transform.g_longitudinal is None:
                    new_state.transform.g_longitudinal = 0.0
                if new_state.transform.g_load is None:
                    new_state.transform.g_load = 1.0
                if new_state.transform.ax is None:
                    new_state.transform.ax = 0.0
                if new_state.transform.ay is None:
                    new_state.transform.ay = 0.0
                if new_state.transform.az is None:
                    new_state.transform.az = 0.0
        
        self.last_state = new_state
        
        # Keep last 6 states for 1-second smoothing window (at 5Hz = ~1.2s history)
        self.states.append(new_state)
        if len(self.states) > 6:
            self.states.pop(0)
        
        self.update_time_bounds_from_timestamp(new_state.timestamp)
    
    def update_time_bounds_from_timestamp(self, timestamp: float):
        """Update time bounds from timestamp without iterating states."""
        if self.first_seen is None or timestamp < self.first_seen:
            self.first_seen = timestamp
        if self.last_seen is None or timestamp > self.last_seen:
            self.last_seen = timestamp
    
    def _calculate_gforces(self, state: ObjectState, ax: float, ay: float, az: float):
        """
        Calculate G-forces in body frame.
        
        If provided by simulator (BMS), use those values.
        Otherwise calculate from acceleration.
        """
        # If BMS provided G-forces, use them and also set g_load
        if state.transform.g_vertical is not None:
            # BMS provides all three, just ensure g_load mirrors g_vertical
            state.transform.g_load = state.transform.g_vertical
            return
        
        # Calculate from acceleration (DCS)
        # World frame calculation - simplified (not true body frame without roll/pitch/yaw)
        g_total = math.sqrt(ax**2 + ay**2 + (az + EARTH_G)**2) / EARTH_G
        
        # For now, put all G into vertical (approximation)
        # TODO: True body-frame requires rotation matrix from roll/pitch/yaw
        state.transform.g_vertical = g_total
        state.transform.g_lateral = 0.0
        state.transform.g_longitudinal = 0.0
        state.transform.g_load = g_total
    
    def _calculate_airspeeds(self, state: ObjectState):
        """
        Calculate Mach, CAS, IAS.
        
        Logic:
        - Use BMS-provided values if available
        - Calculate from TAS + altitude if missing
        - IAS falls back to CAS
        """
        from ..physics.atmosphere import tas_to_mach, tas_to_cas
        
        tas = state.transform.speed
        altitude = state.transform.altitude
        
        # Mach: Use provided or calculate
        if state.transform.mach is None and tas is not None and altitude is not None:
            state.transform.mach = tas_to_mach(tas, altitude)
        
        # CAS: Use provided or calculate
        if state.transform.cas is None and tas is not None and altitude is not None:
            state.transform.cas = tas_to_cas(tas, altitude)
        
        # IAS: Use provided or fallback to CAS
        if state.transform.ias is None:
            state.transform.ias = state.transform.cas
    
    def _calculate_angles(self, state: ObjectState, vx: float, vy: float, vz: float):
        """
        Calculate AoA and AoS.
        
        Logic:
        - Use BMS-provided values if available
        - Calculate from velocity and heading if missing
        """
        # If BMS provided angles, use them
        if state.transform.aoa is not None and state.transform.aos is not None:
            return
        
        # Need heading to calculate forward/right vectors
        if state.transform.heading is None:
            return
        
        from ..physics.angles import (
            calculate_aoa,
            calculate_aos,
            heading_to_forward_vector,
            heading_to_right_vector
        )
        
        velocity_vector = (vx, vy, vz)
        pitch = state.transform.pitch if state.transform.pitch is not None else 0.0
        
        # AoA: Use provided or calculate
        if state.transform.aoa is None:
            forward_vector = heading_to_forward_vector(state.transform.heading, pitch)
            state.transform.aoa = calculate_aoa(velocity_vector, forward_vector)
        
        # AoS: Use provided or calculate
        if state.transform.aos is None:
            right_vector = heading_to_right_vector(state.transform.heading)
            state.transform.aos = calculate_aos(velocity_vector, right_vector)

    def update_time_bounds(self):
        """Update first_seen and last_seen from states (legacy - prefer update_time_bounds_from_timestamp)."""
        if self.states:
            # Use running update for each state instead of iteration
            for state in self.states:
                self.update_time_bounds_from_timestamp(state.timestamp)

