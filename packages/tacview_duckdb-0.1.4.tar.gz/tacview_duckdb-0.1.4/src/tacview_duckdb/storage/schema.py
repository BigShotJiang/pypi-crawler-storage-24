"""DuckDB schema definitions."""

# SQL for creating objects table
CREATE_OBJECTS_TABLE = """
CREATE TABLE IF NOT EXISTS objects (
    id VARCHAR PRIMARY KEY,
    name VARCHAR,
    type_class VARCHAR,
    type_attributes VARCHAR,
    type_basic VARCHAR,
    type_specific VARCHAR,
    pilot VARCHAR,
    group_name VARCHAR,
    coalition VARCHAR,
    color VARCHAR,
    country VARCHAR,
    parent_id VARCHAR,
    first_seen DOUBLE,
    last_seen DOUBLE,
    removed_at DOUBLE,
    properties JSON,
    processed_flags UINTEGER DEFAULT 0
)
"""

# SQL for creating states table with spatial support
# NOTE: In Parquet-native mode, states is a VIEW over Parquet files
# This table definition is kept for backward compatibility and fallback mode
CREATE_STATES_TABLE = """
CREATE SEQUENCE IF NOT EXISTS states_id_seq START 1;
CREATE TABLE IF NOT EXISTS states (
    id UBIGINT PRIMARY KEY DEFAULT nextval('states_id_seq'),
    object_id VARCHAR,
    timestamp DOUBLE,
    longitude DOUBLE,
    latitude DOUBLE,
    altitude DOUBLE,
    agl DOUBLE,
    roll DOUBLE,
    pitch DOUBLE,
    yaw DOUBLE,
    u DOUBLE,
    v DOUBLE,
    heading DOUBLE,
    speed DOUBLE,
    vertical_speed DOUBLE,
    turn_rate DOUBLE,
    turn_radius DOUBLE,
    mach DOUBLE,
    ias DOUBLE,
    cas DOUBLE,
    aoa DOUBLE,
    aos DOUBLE,
    ax DOUBLE,
    ay DOUBLE,
    az DOUBLE,
    g_vertical DOUBLE,
    g_lateral DOUBLE,
    g_longitudinal DOUBLE,
    g_load DOUBLE,
    potential_energy DOUBLE,
    kinetic_energy DOUBLE,
    specific_energy DOUBLE,
    UNIQUE (object_id, timestamp)
)
"""

# SQL for creating metadata table
CREATE_METADATA_TABLE = """
CREATE TABLE IF NOT EXISTS metadata (
    key VARCHAR PRIMARY KEY,
    value VARCHAR
)
"""

# SQL for creating events table
CREATE_EVENTS_TABLE = """
CREATE TABLE IF NOT EXISTS events (
    object_id VARCHAR,
    timestamp DOUBLE,
    event_name VARCHAR,
    event_params VARCHAR,
    location_lat DOUBLE,
    location_lon DOUBLE,
    location_geocoded VARCHAR,
    location_type VARCHAR,
    location_enriched_at TIMESTAMP,
    PRIMARY KEY (object_id, timestamp, event_name)
)
"""

# SQL for creating tactical_events table
CREATE_TACTICAL_EVENTS_TABLE = """
CREATE SEQUENCE IF NOT EXISTS tactical_events_id_seq START 1;
CREATE TABLE IF NOT EXISTS tactical_events (
    id BIGINT PRIMARY KEY DEFAULT nextval('tactical_events_id_seq'),
    event_type VARCHAR NOT NULL,
    timestamp DOUBLE NOT NULL,
    initiator_id VARCHAR NOT NULL,
    target_id VARCHAR,
    initiator_type VARCHAR,
    target_type VARCHAR,
    initiator_coalition VARCHAR,
    target_coalition VARCHAR,
    longitude DOUBLE,
    latitude DOUBLE,
    altitude DOUBLE,
    initiator_state_id UBIGINT,
    target_state_id UBIGINT,
    initiator_parent_state_id UBIGINT,
    metadata JSON
)
"""

# SQL for creating airports table (placeholder - actual schema auto-detected from CSV)
# The airports table is created from OurAirports CSV during initialization
# This placeholder ensures the table exists for schema checks
CREATE_AIRPORTS_TABLE = """
CREATE TABLE IF NOT EXISTS airports (
    id INTEGER,
    ident VARCHAR,
    type VARCHAR,
    name VARCHAR,
    latitude_deg DOUBLE,
    longitude_deg DOUBLE
)
"""

# SQL for creating indexes (now created as part of table definitions for optimal bulk load)
# Additional secondary indexes for query performance
# NOTE: Indexes on states table only apply in non-VIEW mode
# In Parquet-native mode, query optimization is handled by:
# - DuckDB's automatic filter/projection pushdown to Parquet
# - Parquet file zonemaps (min/max statistics per row group)
# - Parquet columnar format (only read needed columns)
CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_states_object_id ON states(object_id)",
    "CREATE INDEX IF NOT EXISTS idx_states_timestamp ON states(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_objects_type_class ON objects(type_class)",
    "CREATE INDEX IF NOT EXISTS idx_objects_type_basic ON objects(type_basic)",
    "CREATE INDEX IF NOT EXISTS idx_objects_type_specific ON objects(type_specific)",
    "CREATE INDEX IF NOT EXISTS idx_objects_coalition ON objects(coalition)",
    "CREATE INDEX IF NOT EXISTS idx_objects_parent_id ON objects(parent_id)",
    "CREATE INDEX IF NOT EXISTS idx_objects_first_seen ON objects(first_seen)",
    "CREATE INDEX IF NOT EXISTS idx_objects_last_seen ON objects(last_seen)",
    "CREATE INDEX IF NOT EXISTS idx_objects_removed_at ON objects(removed_at)",
    "CREATE INDEX IF NOT EXISTS idx_events_object_id ON events(object_id)",
    "CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_events_event_name ON events(event_name)",
    "CREATE INDEX IF NOT EXISTS idx_events_location ON events(location_lat, location_lon)",
    # Projectile burst enrichment indexes
    "CREATE INDEX IF NOT EXISTS idx_objects_type_basic_parent ON objects(type_basic, parent_id)",
    "CREATE INDEX IF NOT EXISTS idx_states_object_timestamp ON states(object_id, timestamp)",
    # Tactical events indexes
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_type ON tactical_events(event_type)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_timestamp ON tactical_events(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_initiator ON tactical_events(initiator_id)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_target ON tactical_events(target_id)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_coalition_pair ON tactical_events(initiator_coalition, target_coalition)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_type_time ON tactical_events(event_type, timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_initiator_state ON tactical_events(initiator_state_id)",
    "CREATE INDEX IF NOT EXISTS idx_tactical_events_target_state ON tactical_events(target_state_id)",
    # Airports indexes
    "CREATE INDEX IF NOT EXISTS idx_airports_coords ON airports(latitude_deg, longitude_deg)",
    "CREATE INDEX IF NOT EXISTS idx_airports_type ON airports(type)",
    "CREATE INDEX IF NOT EXISTS idx_airports_country ON airports(iso_country)",
]


def get_schema_sql() -> list:
    """Get list of SQL statements to create tables with primary keys."""
    return [
        CREATE_OBJECTS_TABLE,
        CREATE_STATES_TABLE,
        CREATE_EVENTS_TABLE,
        CREATE_TACTICAL_EVENTS_TABLE,
        CREATE_AIRPORTS_TABLE,
        CREATE_METADATA_TABLE,
    ]


def get_schema_sql_parquet_native() -> list:
    """
    Get list of SQL statements for Parquet-native mode (states as VIEW).
    
    In this mode, states table is NOT created - it will be replaced by a VIEW
    over Parquet files created via create_states_view().
    """
    return [
        CREATE_OBJECTS_TABLE,
        # CREATE_STATES_TABLE intentionally omitted - will be VIEW
        CREATE_EVENTS_TABLE,
        CREATE_TACTICAL_EVENTS_TABLE,
        CREATE_AIRPORTS_TABLE,
        CREATE_METADATA_TABLE,
    ]


def get_index_sql() -> list:
    """Get list of SQL statements to create secondary indexes (to be run post-load)."""
    return CREATE_INDEXES


def apply_schema_migrations(conn) -> None:
    """
    Apply schema migrations for existing databases.
    
    Adds missing columns with defaults to avoid breaking existing databases.
    Safe to run multiple times - uses IF NOT EXISTS / ALTER TABLE IF EXISTS.
    """
    # Migration: Add processed_flags column (v0.1.3+)
    try:
        conn.execute("""
            ALTER TABLE objects 
            ADD COLUMN IF NOT EXISTS processed_flags UINTEGER DEFAULT 0
        """)
    except Exception:
        pass  # Column might already exist or table might not exist yet
    
    # Migration: Add Tacview formula alignment fields (v0.2.0+)
    new_state_columns = [
        "mach DOUBLE",
        "ias DOUBLE",
        "cas DOUBLE",
        "aoa DOUBLE",
        "aos DOUBLE",
        "g_vertical DOUBLE",
        "g_lateral DOUBLE",
        "g_longitudinal DOUBLE",
    ]
    
    for column_def in new_state_columns:
        try:
            conn.execute(f"ALTER TABLE states ADD COLUMN IF NOT EXISTS {column_def}")
        except Exception:
            pass  # Column might already exist or table might not exist yet
    
    # Migration: Add geodata columns to events table (v0.2.0+)
    geodata_columns = [
        "location_lat DOUBLE",
        "location_lon DOUBLE",
        "location_geocoded VARCHAR",
        "location_type VARCHAR",
        "location_enriched_at TIMESTAMP",
    ]
    
    for column_def in geodata_columns:
        try:
            conn.execute(f"ALTER TABLE events ADD COLUMN IF NOT EXISTS {column_def}")
        except Exception:
            pass  # Column might already exist or table might not exist yet
    
    # Migration: Create airports table if it doesn't exist (v0.2.0+)
    try:
        conn.execute(CREATE_AIRPORTS_TABLE)
    except Exception:
        pass  # Table might already exist

