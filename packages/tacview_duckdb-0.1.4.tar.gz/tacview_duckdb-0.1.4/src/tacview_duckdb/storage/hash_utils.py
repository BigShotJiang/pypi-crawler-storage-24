"""Hash generation utilities for database naming."""

import hashlib
from typing import Dict, Any


def generate_db_hash(metadata: Dict[str, Any]) -> str:
    """
    Generate hash from recording metadata for database filename.

    Uses key metadata fields (Title, RecordingTime, Author) to create
    a unique identifier for the recording.

    Args:
        metadata: Recording metadata dictionary

    Returns:
        16-character hex hash string
    """
    # Use key metadata fields for hash.
    # RecordingTime is the wallclock time the session started — unique per server reload.
    # ReferenceTime is the in-mission start (fixed per scenario) — used as fallback.
    title = metadata.get("Title", "")
    recording_time = metadata.get("RecordingTime", "") or metadata.get("RecorderDateTime", "")
    reference_time = metadata.get("ReferenceTime", "")
    author = metadata.get("Author", "")
    data_source = metadata.get("DataSource", "")

    hash_input = f"{title}-{recording_time}-{reference_time}-{author}-{data_source}"
    return hashlib.sha256(hash_input.encode()).hexdigest()[:16]

