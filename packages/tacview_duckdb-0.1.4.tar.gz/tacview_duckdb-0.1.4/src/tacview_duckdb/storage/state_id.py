"""State ID generation utilities.

Provides deterministic state ID generation from object_id and timestamp,
enabling Parquet-native state storage without DuckDB sequences.
"""

import hashlib


def generate_state_id(object_id: str, timestamp: float) -> int:
    """
    Generate deterministic 64-bit state ID from object_id and timestamp.
    
    Uses SHA256 hash of "object_id:timestamp", taking first 8 bytes as an
    unsigned 64-bit integer (matching DuckDB's UBIGINT type).
    
    64-bit provides ~18 quintillion unique IDs, making collisions virtually
    impossible. The 1% overhead vs 32-bit is negligible for the simplicity.
    
    Args:
        object_id: Object identifier (e.g., "4000001")
        timestamp: State timestamp in seconds (e.g., 100.5)
    
    Returns:
        Deterministic 64-bit unsigned integer suitable for use as UBIGINT primary key
    
    Example:
        >>> id1 = generate_state_id("4000001", 100.5)
        >>> id2 = generate_state_id("4000001", 100.5)
        >>> assert id1 == id2  # Same inputs always produce same ID
        >>> id3 = generate_state_id("4000001", 100.6)
        >>> assert id1 != id3  # Different timestamp produces different ID
    """
    # Create composite key with high precision for timestamp
    data = f"{object_id}:{timestamp:.6f}".encode('utf-8')
    
    # SHA256 hash provides good distribution
    hash_bytes = hashlib.sha256(data).digest()
    
    # Take first 8 bytes as unsigned 64-bit integer
    # This gives us positive IDs in range 0 to 18,446,744,073,709,551,615 (2^64-1)
    return int.from_bytes(hash_bytes[:8], byteorder='big', signed=False)

