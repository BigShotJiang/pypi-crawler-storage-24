"""Unified ingestion strategy for batch and streaming modes.

Implements Parquet-native state storage with deterministic IDs,
timestamp-frame processing, and batched DuckDB operations.
"""

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set
import pyarrow as pa
import pyarrow.parquet as pq

from ..parser.types import ObjectState, TacviewObject
from .state_id import generate_state_id

logger = logging.getLogger(__name__)


@dataclass
class PendingSpawn:
    """Tracks newly spawned objects for JIT enrichment."""
    object_id: str
    type_class: Optional[str]
    type_basic: Optional[str]
    type_specific: Optional[str]
    spawn_timestamp: float


@dataclass
class PendingRemoval:
    """Tracks removed objects for JIT enrichment."""
    object_id: str
    timestamp: float
    type_class: Optional[str]
    type_basic: Optional[str]


class ParquetIngestionStrategy:
    """
    Unified ingestion strategy for batch and streaming modes.
    
    Key behaviors:
    - Accumulates states across timestamp frames until threshold
    - Merges same-timestamp updates in memory (current frame)
    - Flushes on timestamp change when threshold met
    - Batches all DuckDB operations together
    
    Args:
        store: DuckDBStore instance for database operations
        flush_threshold: Number of states to accumulate before flush
                        (Batch=50000, Stream=0)
        enable_jit_enrichments: Run enrichments immediately after flush
                               (Batch=False, Stream=True)
    """
    
    def __init__(
        self,
        store: 'DuckDBStore',  # Type hint as string to avoid circular import
        flush_threshold: int = 50000,
        enable_jit_enrichments: bool = False,
        time_flush_interval: float = 120.0,  # Telemetry seconds between flushes
        num_shards: int = 6,  # Fixed number of Parquet shards
        post_flush_hook=None,  # Optional Callable[[], None] — called after every DB flush
    ):
        self.store = store
        self.flush_threshold = flush_threshold  # Safety threshold (fallback)
        self.enable_jit_enrichments = enable_jit_enrichments
        self.time_flush_interval = time_flush_interval  # Batch: 60-120s, Streaming: 5-10s
        self.num_shards = num_shards  # Fixed shard count (distribute by state_id)
        self.post_flush_hook = post_flush_hook  # Fired after each _process_flush()
        
        # Current frame (single timestamp)
        self.current_timestamp: float = 0.0
        self.frame_states: Dict[str, ObjectState] = {}  # object_id → merged state
        
        # Accumulated across frames (until flush)
        self.states_buffer: List[Tuple[str, ObjectState]] = []
        self.pending_objects: Dict[str, TacviewObject] = {}  # Objects with metadata changes
        self.timestamp_to_objects: Dict[float, List[str]] = {}  # timestamp → [object_ids] for bulk last_seen updates
        self.pending_removals: List[PendingRemoval] = []
        self.pending_spawns: List[PendingSpawn] = []  # For JIT enrichments
        
        # Flush tracking
        self.last_flush_timestamp: float = 0.0  # Track telemetry time of last flush
        self.flush_counter: int = 0  # Track flush number for file naming
        self.last_temp_file = None  # Track previous temp file to delete on next flush
        
        # Parquet shard writers (fixed count, opened once)
        self.shard_writers: Dict[int, pq.ParquetWriter] = {}
        self.shard_buffers: Dict[int, List[dict]] = {i: [] for i in range(num_shards)}
        
        self.staging_dir: Optional[Path] = None
        self._view_created: bool = False  # Track if VIEW has been created
        
        # Statistics
        self.states_written: int = 0  # Total states written to Parquet
        
        # JIT enrichment runner (initialized if needed)
        self.jit_runner = None  # Will be set if enable_jit_enrichments=True
    
    def initialize(self, staging_dir: Path) -> None:
        """
        Set up Parquet staging directory and open shard writers.
        
        Opens one ParquetWriter per shard for incremental appends.
        
        Args:
            staging_dir: Directory where Parquet shards will be written
        """
        self.staging_dir = staging_dir
        staging_dir.mkdir(parents=True, exist_ok=True)
        
        # Define schema for all shards (store as instance attribute for reopening writers)
        self._states_arrow_schema = pa.schema([
            ('id', pa.uint64()),  # Unsigned 64-bit state ID (simple, collision-free)
            ('object_id', pa.string()),
            ('timestamp', pa.float64()),
            ('longitude', pa.float64()),
            ('latitude', pa.float64()),
            ('altitude', pa.float64()),
            ('agl', pa.float64()),
            ('roll', pa.float64()),
            ('pitch', pa.float64()),
            ('yaw', pa.float64()),
            ('u', pa.float64()),
            ('v', pa.float64()),
            ('heading', pa.float64()),
            ('speed', pa.float64()),
            ('vertical_speed', pa.float64()),
            ('turn_rate', pa.float64()),
            ('turn_radius', pa.float64()),
            ('mach', pa.float64()),
            ('ias', pa.float64()),
            ('cas', pa.float64()),
            ('aoa', pa.float64()),
            ('aos', pa.float64()),
            ('ax', pa.float64()),
            ('ay', pa.float64()),
            ('az', pa.float64()),
            ('g_vertical', pa.float64()),
            ('g_lateral', pa.float64()),
            ('g_longitudinal', pa.float64()),
            ('g_load', pa.float64()),
            ('potential_energy', pa.float64()),
            ('kinetic_energy', pa.float64()),
            ('specific_energy', pa.float64()),
        ])
        
        # Don't create writers yet - they'll be created lazily on first write
        # (ParquetWriter creates empty files immediately, which breaks DuckDB reads)
        
        # Ensure states table has proper index for efficient queries
        try:
            self.store._write_conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_states_object_ts ON states(object_id, timestamp)"
            )
        except Exception:
            pass  # Index might already exist
        
        # Initialize JIT enrichment runner if enabled
        if self.enable_jit_enrichments:
            # Import here to avoid circular dependency
            from ..enrichment.jit_runner import JITEnrichmentRunner
            # Use write connection for JIT enrichments (need to do UPDATEs)
            conn = self.store._write_conn
            self.jit_runner = JITEnrichmentRunner(conn, self.store.get_event_queue())
    
    def on_timestamp(self, new_timestamp: float) -> None:
        """
        Called when parser encounters a timestamp line.
        This is THE trigger point for all processing.
        
        Flush conditions (checked AFTER finalizing previous frame):
        1. Time-based: Telemetry time elapsed >= time_flush_interval
        2. Count-based (safety): States accumulated >= flush_threshold
        
        Args:
            new_timestamp: The new timestamp value from #timestamp line
        """
        if new_timestamp != self.current_timestamp:
            # 1. Finalize previous frame (move states to global buffer)
            self._finalize_frame()
            
            # 2. Check flush conditions (AFTER frame is complete)
            time_since_flush = new_timestamp - self.last_flush_timestamp
            should_flush = (
                time_since_flush >= self.time_flush_interval or  # Primary: Time-based
                len(self.states_buffer) >= self.flush_threshold   # Safety: Count-based
            )
            
            if should_flush:
                self._process_flush()
                self.last_flush_timestamp = new_timestamp
            
            # 3. Start new frame
            self.current_timestamp = new_timestamp
            self.frame_states.clear()
    
    def on_state_update(self, object_id: str, state: ObjectState) -> None:
        """
        Called when parser extracts state data from an object line.
        Merges with existing state if same timestamp.
        
        Args:
            object_id: Object identifier
            state: New or partial state for this object at current timestamp
        """
        if object_id in self.frame_states:
            # Merge: update existing state's transform
            existing = self.frame_states[object_id]
            for key, value in vars(state.transform).items():
                if value is not None:
                    setattr(existing.transform, key, value)
        else:
            # New state for this object in this frame
            self.frame_states[object_id] = state
        
        # Track objects by timestamp for bulk last_seen updates
        # Only if it's not already in pending_objects (which will do full upsert)
        if object_id not in self.pending_objects:
            timestamp = state.timestamp
            if timestamp not in self.timestamp_to_objects:
                self.timestamp_to_objects[timestamp] = []
            # Only add if not already in the list for this timestamp
            if object_id not in self.timestamp_to_objects[timestamp]:
                self.timestamp_to_objects[timestamp].append(object_id)
    
    def on_object_spawn(self, obj: TacviewObject) -> None:
        """
        Called when a new object is first seen.
        
        Args:
            obj: The newly spawned TacviewObject
        """
        self.pending_objects[obj.object_id] = obj
        # Remove from timestamp_to_objects since we're doing full upsert
        for obj_list in self.timestamp_to_objects.values():
            if obj.object_id in obj_list:
                obj_list.remove(obj.object_id)
        if self.enable_jit_enrichments:
            self.pending_spawns.append(PendingSpawn(
                object_id=obj.object_id,
                type_class=obj.type_class,
                type_basic=obj.type_basic,
                type_specific=obj.type_specific,
                spawn_timestamp=self.current_timestamp
            ))
    
    def on_object_update(self, obj: TacviewObject) -> None:
        """
        Called when object metadata is updated.
        
        Args:
            obj: The updated TacviewObject
        """
        self.pending_objects[obj.object_id] = obj
        # Remove from timestamp_to_objects since we're doing full upsert
        for obj_list in self.timestamp_to_objects.values():
            if obj.object_id in obj_list:
                obj_list.remove(obj.object_id)
    
    def on_object_removal(self, object_id: str, obj: Optional[TacviewObject] = None) -> None:
        """
        Called when object is removed (- prefix in ACMI).
        
        Args:
            object_id: ID of removed object
            obj: The TacviewObject if available (for type info)
        """
        # Always track removals for removed_at updates (needed for batch enrichments too)
        self.pending_removals.append(PendingRemoval(
            object_id=object_id,
            timestamp=self.current_timestamp,
            type_class=obj.type_class if obj else None,
            type_basic=obj.type_basic if obj else None
        ))
    
    def _finalize_frame(self) -> None:
        """Move current frame states to global buffer."""
        for object_id, state in self.frame_states.items():
            self.states_buffer.append((object_id, state))
    
    def _process_flush(self) -> None:
        """
        Write Parquet shards and update DuckDB.
        Distributes states across fixed shards by state_id % num_shards.
        
        Always processes pending objects, removals, and JIT enrichments,
        even if states_buffer is empty.
        """
        # 1. Generate IDs and distribute to shard buffers (only if we have states)
        if self.states_buffer:
            for object_id, state in self.states_buffer:
                state_id = generate_state_id(object_id, state.timestamp)
                shard_id = state_id % self.num_shards  # Distribute by state_id hash
                row = self._state_to_row(state_id, object_id, state)
                self.shard_buffers[shard_id].append(row)
        
        # 2. Write states: Parquet → INSERT INTO states (only if we have data)
        # Delete previous flush's temp file, keep current one until next flush
        all_rows = []
        for rows in self.shard_buffers.values():
            all_rows.extend(rows)
        
        if all_rows:
            # Delete previous flush's temp file (if exists)
            if self.last_temp_file and self.last_temp_file.exists():
                self.last_temp_file.unlink()
            
            # Ensure staging directory exists
            self.staging_dir.mkdir(parents=True, exist_ok=True)
            
            # Write temporary Parquet file
            temp_file = self.staging_dir / f"states_flush_{self.flush_counter:04d}.parquet"
            writer = pq.ParquetWriter(
                temp_file,
                self._states_arrow_schema,
                compression='snappy',
                use_dictionary=['object_id'],
                write_statistics=True
            )
            table = pa.Table.from_pylist(all_rows, schema=self._states_arrow_schema)
            writer.write_table(table)
            writer.close()
            
            # INSERT from Parquet into states table (with indexes)
            # Use ON CONFLICT to handle any duplicate states gracefully
            # Convert Path to absolute string for DuckDB
            temp_file_str = str(temp_file.absolute())
            self.store._write_conn.execute(f"""
                INSERT INTO states 
                SELECT * FROM read_parquet('{temp_file_str}')
                ON CONFLICT (object_id, timestamp) DO NOTHING
            """)
            
            # Keep temp file until next flush (ensures DuckDB has finished reading)
            self.last_temp_file = temp_file
            
            self.states_written += len(all_rows)
            self.flush_counter += 1
        
        # Clear shard buffers
        self.shard_buffers = {i: [] for i in range(self.num_shards)}
        
        # Mark that we've written data (for potential future use)
        if not self._view_created:
            self._view_created = True  # Mark as ready, but don't create VIEW yet
        
        # 3. Batch upsert objects with metadata changes (spawn/update)
        if self.pending_objects:
            self.store.upsert_objects_batch(list(self.pending_objects.values()))
        
        # 4. Bulk update last_seen for objects with only state changes
        #    Grouped by timestamp for maximum efficiency!
        if self.timestamp_to_objects:
            self.store.bulk_update_last_seen_by_timestamp(self.timestamp_to_objects)
        
        # 5. Batch update removals
        if self.pending_removals:
            removal_data = [(r.object_id, r.timestamp) for r in self.pending_removals]
            self.store.update_objects_removed_batch(removal_data)
        
        # 6. Run JIT enrichments (if enabled)
        if self.enable_jit_enrichments and self.jit_runner:
            self._run_jit_enrichments()
        else:
            # Clear removal/spawn buffers even if JIT is disabled (they were used for DB updates above)
            self.pending_removals.clear()
            self.pending_spawns.clear()
        
        # 7. Clear buffers
        self.states_buffer.clear()
        self.pending_objects.clear()
        self.timestamp_to_objects.clear()

        # 8. Post-flush hook — called after all DB writes are complete
        if self.post_flush_hook is not None:
            try:
                self.post_flush_hook()
            except Exception as exc:
                logger.warning("post_flush_hook error: %s", exc)
    
    def _run_jit_enrichments(self) -> None:
        """Run just-in-time enrichments on newly flushed data."""
        if not self.jit_runner:
            return
        
        # Run spawn enrichments
        if self.pending_spawns:
            self.jit_runner.run_spawn_enrichments(self.pending_spawns)
        
        # Run removal enrichments (in correct order)
        if self.pending_removals:
            self.jit_runner.run_removal_enrichments(self.pending_removals)
        
        # Clear buffers after running enrichments
        self.pending_removals.clear()
        self.pending_spawns.clear()
    
    def _state_to_row(self, state_id: int, object_id: str, state: ObjectState) -> dict:
        """
        Convert ObjectState to dictionary for Parquet row.
        
        Args:
            state_id: Deterministic state ID
            object_id: Object identifier
            state: ObjectState to convert
        
        Returns:
            Dictionary with all state fields
        """
        t = state.transform
        return {
            'id': state_id,
            'object_id': object_id,
            'timestamp': state.timestamp,
            'longitude': t.longitude,
            'latitude': t.latitude,
            'altitude': t.altitude,
            'agl': t.agl,
            'roll': t.roll,
            'pitch': t.pitch,
            'yaw': t.yaw,
            'u': t.u,
            'v': t.v,
            'heading': t.heading,
            'speed': t.speed,
            'vertical_speed': t.vertical_speed,
            'turn_rate': t.turn_rate,
            'turn_radius': t.turn_radius,
            'mach': t.mach,
            'ias': t.ias,
            'cas': t.cas,
            'aoa': t.aoa,
            'aos': t.aos,
            'ax': t.ax,
            'ay': t.ay,
            'az': t.az,
            'g_vertical': t.g_vertical,
            'g_lateral': t.g_lateral,
            'g_longitudinal': t.g_longitudinal,
            'g_load': t.g_load,
            'potential_energy': t.potential_energy,
            'kinetic_energy': t.kinetic_energy,
            'specific_energy': t.specific_energy,
        }
    
    def finalize(self) -> None:
        """
        Called at end of parsing - flush remaining data and close shard writers.
        
        Always flushes to ensure all pending objects, removals, and states are processed.
        """
        # Finalize the last frame
        self._finalize_frame()
        
        # Always flush remaining data (states, objects, removals, JIT enrichments)
        self._process_flush()
        
        # Clean up last temp file
        if self.last_temp_file and self.last_temp_file.exists():
            self.last_temp_file.unlink()
        
        # Close all ParquetWriters
        for writer in self.shard_writers.values():
            writer.close()
        
        # Create VIEW if not already created
        if not self._view_created and self.staging_dir:
            self.store.create_states_view(self.staging_dir)
            self._view_created = True

