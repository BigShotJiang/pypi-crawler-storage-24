"""MissionRegistry — unified token → MissionInfo lookup for live, uploaded, and historical missions."""

from __future__ import annotations

import logging
from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..storage.duckdb_store import DuckDBStore

logger = logging.getLogger(__name__)


class MissionStatus(Enum):
    LIVE = "live"           # Currently receiving streaming data
    FINALIZING = "finalizing"  # Stream ended, flushing to disk
    FINALIZED = "finalized" # Complete, queryable on disk
    ERROR = "error"


@dataclass
class MissionInfo:
    token: str
    server_id: str
    status: MissionStatus
    store: Optional[DuckDBStore]
    metadata: Dict[str, Any] = field(default_factory=dict)
    started_at: float = 0.0       # wall-clock time
    ended_at: Optional[float] = None
    db_path: Optional[Path] = None


class MissionRegistry:
    """
    Thread-safe in-memory registry mapping mission tokens to MissionInfo.

    Live missions are kept indefinitely while streaming.  Finalized missions
    are subject to LRU eviction once ``max_missions`` is reached.
    """

    def __init__(self, output_dir: str | Path, max_missions: int = 100) -> None:
        self.output_dir = Path(output_dir)
        self.max_missions = max_missions
        # Separate dicts: live missions never evicted, finalized missions use LRU
        self._live: Dict[str, MissionInfo] = {}
        self._finalized: OrderedDict[str, MissionInfo] = OrderedDict()

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def register(self, info: MissionInfo) -> None:
        """Register a new or updated mission."""
        if info.status == MissionStatus.LIVE:
            self._live[info.token] = info
        else:
            self._finalize_internal(info)

    def mark_live(self, token: str, store: DuckDBStore, server_id: str, metadata: dict, started_at: float) -> MissionInfo:
        """Register a new live mission and return its MissionInfo."""
        info = MissionInfo(
            token=token,
            server_id=server_id,
            status=MissionStatus.LIVE,
            store=store,
            metadata=metadata,
            started_at=started_at,
        )
        self._live[token] = info
        logger.debug("Registry: mission %s marked LIVE (server=%s)", token, server_id)
        return info

    def mark_finalizing(self, token: str) -> None:
        """Transition a live mission to FINALIZING status."""
        if token in self._live:
            self._live[token].status = MissionStatus.FINALIZING

    def mark_finalized(self, token: str, ended_at: float, db_path: Optional[Path] = None) -> None:
        """Move a mission from live to finalized. Subject to LRU eviction."""
        info = self._live.pop(token, None)
        if info is None:
            info = self._finalized.get(token)
        if info is None:
            logger.warning("Registry: mark_finalized called for unknown token %s", token)
            return
        info.status = MissionStatus.FINALIZED
        info.ended_at = ended_at
        if db_path:
            info.db_path = db_path
        self._finalize_internal(info)

    def mark_error(self, token: str, error: str) -> None:
        info = self._live.pop(token, None) or self._finalized.get(token)
        if info:
            info.status = MissionStatus.ERROR
            info.metadata["error"] = error

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def get(self, token: str) -> Optional[MissionInfo]:
        """Look up any mission by token (live or finalized)."""
        return self._live.get(token) or self._finalized.get(token)

    def get_store(self, token: str) -> Optional[DuckDBStore]:
        """Return DuckDBStore for a mission if available."""
        info = self.get(token)
        return info.store if info else None

    def get_active(self, server_id: str) -> Optional[MissionInfo]:
        """Return the currently LIVE mission for a server, if any."""
        for info in self._live.values():
            if info.server_id == server_id and info.status == MissionStatus.LIVE:
                return info
        return None

    def list_missions(
        self,
        server_id: Optional[str] = None,
        status: Optional[MissionStatus] = None,
    ) -> List[MissionInfo]:
        """List missions, optionally filtered by server or status."""
        all_missions = list(self._live.values()) + list(self._finalized.values())
        if server_id:
            all_missions = [m for m in all_missions if m.server_id == server_id]
        if status:
            all_missions = [m for m in all_missions if m.status == status]
        return all_missions

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _finalize_internal(self, info: MissionInfo) -> None:
        """Insert into finalized LRU, evicting oldest if over capacity."""
        token = info.token
        if token in self._finalized:
            self._finalized.move_to_end(token)
        self._finalized[token] = info
        self._finalized.move_to_end(token)
        # LRU eviction
        while len(self._finalized) > self.max_missions:
            evicted_token, evicted = self._finalized.popitem(last=False)
            logger.debug("Registry: evicted finalized mission %s (LRU)", evicted_token)
            if evicted.store:
                try:
                    evicted.store.close()
                except Exception:
                    pass
