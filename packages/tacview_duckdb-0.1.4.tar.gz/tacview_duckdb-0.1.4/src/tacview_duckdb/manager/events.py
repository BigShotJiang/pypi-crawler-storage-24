"""Event types and EventBus for the real-time outbound event stream."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class Event:
    """
    A structured event emitted by the DataManager event bus.

    event_type values:
      - ``"mission_started"``  — a new mission began streaming
      - ``"mission_ended"``    — a mission stream ended / was replaced
      - ``"acmi_event"``       — one or more ACMI Event= properties were detected

    For ``"acmi_event"`` the ``data`` dict contains a ``"events"`` key with
    a list of raw tuples ``(object_id, timestamp, event_name, event_params)``.
    These are guaranteed to already be committed to the DuckDB store when the
    event is published — consumers may safely query the store for context.
    """

    event_type: str
    server_id: str
    mission_token: str
    timestamp: float  # wall-clock time (time.time())
    acmi_timestamp: float = 0.0  # in-game time; 0 for mission lifecycle events
    data: Dict = field(default_factory=dict)


class EventBus:
    """
    Simple fan-out event bus backed by asyncio.Queue subscribers.

    Usage::

        bus = EventBus()

        # Producer (sync, e.g. parser thread via call_soon_threadsafe)
        bus.publish(event)

        # Consumer (async)
        q = bus.subscribe()
        event = await q.get()

    Filtering::

        q = bus.subscribe(event_types=["acmi_event"], server_id="dcs_1")

    Thread safety:
        ``publish()`` is safe to call from any thread. It uses
        ``loop.call_soon_threadsafe`` when called from outside the event loop.
    """

    def __init__(self) -> None:
        self._subscribers: List[_Subscription] = []
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Register the running event loop. Called by DataManager on start."""
        self._loop = loop

    def subscribe(
        self,
        event_types: Optional[List[str]] = None,
        server_id: Optional[str] = None,
        maxsize: int = 1000,
    ) -> asyncio.Queue:
        """
        Subscribe to events. Returns an asyncio.Queue that receives matching Events.

        Args:
            event_types: If set, only deliver events whose ``event_type`` is in the list.
            server_id: If set, only deliver events from this server.
            maxsize: Queue capacity. Oldest events are dropped if full.
        """
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subscribers.append(_Subscription(q, event_types, server_id))
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        """Remove a subscription queue."""
        self._subscribers = [s for s in self._subscribers if s.queue is not q]

    def publish(self, event: Event) -> None:
        """
        Publish an event to all matching subscribers.

        Safe to call from any thread. If a subscriber queue is full the event
        is dropped for that subscriber (non-blocking).
        """
        if not self._subscribers:
            return

        matching = [s for s in self._subscribers if s.matches(event)]
        if not matching:
            return

        loop = self._loop
        if loop is not None and loop.is_running():
            loop.call_soon_threadsafe(self._deliver, event, matching)
        else:
            # Fallback: best-effort put_nowait if no loop registered
            self._deliver(event, matching)

    def _deliver(self, event: Event, subscribers: List["_Subscription"]) -> None:
        """Called inside the event loop to enqueue event to subscribers."""
        for sub in subscribers:
            try:
                sub.queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.debug(
                    "EventBus: subscriber queue full, dropping event %s", event.event_type
                )


class _Subscription:
    """Internal: a subscriber filter + queue pair."""

    def __init__(
        self,
        queue: asyncio.Queue,
        event_types: Optional[List[str]],
        server_id: Optional[str],
    ) -> None:
        self.queue = queue
        self.event_types = set(event_types) if event_types else None
        self.server_id = server_id

    def matches(self, event: Event) -> bool:
        if self.event_types and event.event_type not in self.event_types:
            return False
        if self.server_id and event.server_id != self.server_id:
            return False
        return True
