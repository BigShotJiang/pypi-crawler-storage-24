"""ServerConnection — manages the lifecycle of one Tacview server connection."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

from .config import ServerConfig, ServerStatus
from .events import Event, EventBus
from .mission_registry import MissionRegistry
from ..storage.duckdb_store import DuckDBStore

logger = logging.getLogger(__name__)


class ServerConnection:
    """
    Wraps RealTimeTelemetryClient + StreamingParserAdapter for one server.

    Bridges mission lifecycle and ACMI events to the MissionRegistry and EventBus.
    All callbacks fire in the parser background thread; EventBus.publish() handles
    the thread→asyncio handoff via call_soon_threadsafe.
    """

    def __init__(
        self,
        config: ServerConfig,
        registry: MissionRegistry,
        event_bus: EventBus,
    ) -> None:
        self.config = config
        self._registry = registry
        self._event_bus = event_bus
        self._task: Optional[asyncio.Task] = None
        self._connected = False
        self._error: Optional[str] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Start streaming in a background asyncio task."""
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(
            self._run(), name=f"stream-{self.config.server_id}"
        )

    async def disconnect(self) -> None:
        """Cancel the streaming task and wait for it to finish."""
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected and (self._task is not None and not self._task.done())

    def status(self) -> ServerStatus:
        return ServerStatus(
            server_id=self.config.server_id,
            host=self.config.host,
            port=self.config.port,
            connected=self.connected,
            active_mission_token=(
                m.token
                if (m := self._registry.get_active(self.config.server_id))
                else None
            ),
            error=self._error,
        )

    # ------------------------------------------------------------------
    # Internal streaming loop
    # ------------------------------------------------------------------

    async def _run(self) -> None:
        from ..streaming.client import RealTimeTelemetryClient
        from ..streaming.parser_adapter import StreamingParserAdapter

        client = RealTimeTelemetryClient(
            host=self.config.host,
            port=self.config.port,
            password=self.config.password,
            client_hostname=self.config.client_hostname,
        )
        adapter = StreamingParserAdapter(
            output_dir=self._registry.output_dir,
            time_flush_interval=5.0,
            flush_threshold=0,
            on_mission_start=self._on_mission_start,
            on_mission_end=self._on_mission_end,
            on_events=self._on_events,
        )
        try:
            self._connected = True
            self._error = None
            await adapter.run(client.lines())
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._connected = False
            self._error = str(exc)
            logger.error("ServerConnection %s error: %s", self.config.server_id, exc)

    # ------------------------------------------------------------------
    # Callbacks (fired from parser background thread)
    # ------------------------------------------------------------------

    def _on_mission_start(self, token: str, store: DuckDBStore) -> None:
        self._registry.mark_live(
            token=token,
            store=store,
            server_id=self.config.server_id,
            metadata={},
            started_at=time.time(),
        )
        self._event_bus.publish(Event(
            event_type="mission_started",
            server_id=self.config.server_id,
            mission_token=token,
            timestamp=time.time(),
        ))
        logger.info("ServerConnection %s: mission_started token=%s", self.config.server_id, token)

    def _on_mission_end(self, token: str, store: DuckDBStore) -> None:
        self._registry.mark_finalized(
            token=token,
            ended_at=time.time(),
            db_path=store.database_path if store else None,
        )
        self._event_bus.publish(Event(
            event_type="mission_ended",
            server_id=self.config.server_id,
            mission_token=token,
            timestamp=time.time(),
        ))
        logger.info("ServerConnection %s: mission_ended token=%s", self.config.server_id, token)

    def _on_events(self, mission_token: str, events: list) -> None:
        """Forward post-flush ACMI events to the EventBus."""
        if not events:
            return
        self._event_bus.publish(Event(
            event_type="acmi_event",
            server_id=self.config.server_id,
            mission_token=mission_token,
            timestamp=time.time(),
            acmi_timestamp=events[-1][1] if events else 0.0,
            data={"events": events},
        ))
