"""Configuration dataclasses for DataManager."""

from dataclasses import dataclass, field
from typing import List


@dataclass
class ServerConfig:
    """Configuration for a single Tacview real-time telemetry server connection."""

    server_id: str
    host: str
    port: int = 42674
    password: str = ""
    client_hostname: str = "tacview-duckdb"
    auto_connect: bool = True


@dataclass
class ManagerConfig:
    """Top-level configuration for DataManager."""

    output_dir: str = "timeline_data"
    servers: List[ServerConfig] = field(default_factory=list)
    time_flush_interval: float = 5.0
    flush_threshold: int = 0
    max_missions: int = 100  # LRU eviction cap for finalized missions


@dataclass
class ServerStatus:
    """Runtime status of a managed server connection."""

    server_id: str
    host: str
    port: int
    connected: bool
    active_mission_token: str | None = None
    error: str | None = None
