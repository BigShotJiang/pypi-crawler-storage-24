"""DataManager — top-level orchestrator for concurrent Tacview server connections."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Dict, List, Optional

from .config import ManagerConfig, ServerConfig, ServerStatus
from .events import Event, EventBus
from .mission_registry import MissionInfo, MissionRegistry, MissionStatus
from .server_connection import ServerConnection
from ..storage.duckdb_store import DuckDBStore

logger = logging.getLogger(__name__)


class DataManager:
    """
    Manages concurrent Tacview server connections and a unified mission registry.

    Acts as the primary integration point for real-time streaming, batch file
    ingestion, and event subscription. All server connections and their missions
    are accessible through a single interface.

    Usage::

        from tacview_duckdb.manager import DataManager, ManagerConfig, ServerConfig

        config = ManagerConfig(
            output_dir="timeline_data",
            servers=[
                ServerConfig(server_id="dcs_1", host="192.168.1.10"),
            ],
        )
        dm = DataManager(config)
        await dm.start()

        # Subscribe to events
        q = dm.subscribe(event_types=["acmi_event"])
        async def consumer():
            while True:
                event = await q.get()
                print(event)

        # Query live mission
        store = dm.get_store(some_token)

        await dm.stop()
    """

    def __init__(self, config: ManagerConfig) -> None:
        self._config = config
        self._registry = MissionRegistry(
            output_dir=config.output_dir,
            max_missions=config.max_missions,
        )
        self._event_bus = EventBus()
        self._connections: Dict[str, ServerConnection] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Connect to all configured servers. Non-blocking; connections run as tasks."""
        self._loop = asyncio.get_running_loop()
        self._event_bus.set_loop(self._loop)

        for server_cfg in self._config.servers:
            await self.add_server(server_cfg)

    async def stop(self) -> None:
        """Graceful shutdown: disconnect all servers."""
        for conn in list(self._connections.values()):
            await conn.disconnect()
        self._connections.clear()

    # ------------------------------------------------------------------
    # Server management
    # ------------------------------------------------------------------

    async def add_server(self, server: ServerConfig) -> str:
        """Add and connect to a server. Returns server_id."""
        if server.server_id in self._connections:
            logger.warning("Server %s already registered", server.server_id)
            return server.server_id

        conn = ServerConnection(
            config=server,
            registry=self._registry,
            event_bus=self._event_bus,
        )
        self._connections[server.server_id] = conn

        if server.auto_connect:
            await conn.connect()

        return server.server_id

    async def remove_server(self, server_id: str) -> None:
        """Disconnect and remove a server."""
        conn = self._connections.pop(server_id, None)
        if conn:
            await conn.disconnect()

    def list_servers(self) -> List[ServerStatus]:
        """Get current status of all configured servers."""
        return [conn.status() for conn in self._connections.values()]

    # ------------------------------------------------------------------
    # Mission registry
    # ------------------------------------------------------------------

    def get_mission(self, token: str) -> Optional[MissionInfo]:
        """Look up any mission by token (live or finalized)."""
        return self._registry.get(token)

    def list_missions(
        self,
        server_id: Optional[str] = None,
        status: Optional[MissionStatus] = None,
    ) -> List[MissionInfo]:
        """List missions, optionally filtered by server or status."""
        return self._registry.list_missions(server_id=server_id, status=status)

    def get_store(self, token: str) -> Optional[DuckDBStore]:
        """Return DuckDBStore for a mission. Works for live AND finalized missions."""
        return self._registry.get_store(token)

    def get_active_mission(self, server_id: str) -> Optional[MissionInfo]:
        """Return the currently streaming mission for a server."""
        return self._registry.get_active(server_id)

    # ------------------------------------------------------------------
    # Batch ingestion
    # ------------------------------------------------------------------

    async def ingest_file(
        self,
        filepath: str | Path,
        server_id: str = "upload",
    ) -> MissionInfo:
        """
        Parse an ACMI file and register it in the mission registry.

        Runs the parse in a thread executor to avoid blocking the event loop.
        Returns a MissionInfo with status=FINALIZED.
        """
        from ..api import parse_acmi
        import time

        filepath = Path(filepath)
        loop = asyncio.get_running_loop()

        store: DuckDBStore = await loop.run_in_executor(
            None,
            lambda: parse_acmi(str(filepath), output_dir=self._config.output_dir),
        )

        token = store.db_hash
        info = MissionInfo(
            token=token,
            server_id=server_id,
            status=MissionStatus.FINALIZED,
            store=store,
            metadata=store.get_summary() if hasattr(store, "get_summary") else {},
            started_at=time.time(),
            ended_at=time.time(),
            db_path=Path(store.database_path),
        )
        self._registry.register(info)
        logger.info("DataManager: ingested file %s → token=%s", filepath.name, token)
        return info

    # ------------------------------------------------------------------
    # Event subscription
    # ------------------------------------------------------------------

    def subscribe(
        self,
        event_types: Optional[List[str]] = None,
        server_id: Optional[str] = None,
        maxsize: int = 1000,
    ) -> asyncio.Queue:
        """
        Subscribe to DataManager events.

        Returns an asyncio.Queue that receives Event objects. The queue is
        non-blocking: if full, the oldest event is dropped for this subscriber.

        Args:
            event_types: Filter to specific types: ``"mission_started"``,
                         ``"mission_ended"``, ``"acmi_event"``.
                         ``None`` = all events.
            server_id: Filter to a specific server. ``None`` = all servers.
            maxsize: Queue capacity (default 1000).

        Example::

            q = dm.subscribe(event_types=["acmi_event"], server_id="dcs_1")
            event = await q.get()
            for obj_id, ts, name, params in event.data["events"]:
                if name == "Destroyed":
                    print(f"Kill at t={ts}: {obj_id}")
        """
        if self._loop is None:
            # If start() hasn't been called yet, register loop lazily
            try:
                self._loop = asyncio.get_running_loop()
                self._event_bus.set_loop(self._loop)
            except RuntimeError:
                pass

        return self._event_bus.subscribe(
            event_types=event_types,
            server_id=server_id,
            maxsize=maxsize,
        )

    def unsubscribe(self, q: asyncio.Queue) -> None:
        """Remove a subscription queue."""
        self._event_bus.unsubscribe(q)
