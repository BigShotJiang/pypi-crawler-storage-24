"""
tacview_duckdb.manager
======================

Library-level orchestration module for managing concurrent Tacview server
connections, a unified mission registry, and a real-time outbound event bus.

Public API::

    from tacview_duckdb.manager import DataManager, ManagerConfig, ServerConfig
    from tacview_duckdb.manager import Event, EventBus

"""

from .config import ManagerConfig, ServerConfig, ServerStatus
from .events import Event, EventBus
from .mission_registry import MissionInfo, MissionStatus, MissionRegistry
from .data_manager import DataManager

__all__ = [
    "DataManager",
    "ManagerConfig",
    "ServerConfig",
    "ServerStatus",
    "Event",
    "EventBus",
    "MissionInfo",
    "MissionStatus",
    "MissionRegistry",
]
