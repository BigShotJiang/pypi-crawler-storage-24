"""
Tacview-compatible constants for physics calculations.

These constants are aligned with Tacview 1.x formulas to ensure
consistency between database values and Tacview UI display.

Reference: https://tacview.fandom.com/wiki/Formulas
"""

import math

# WGS84 semi-major axis (Earth equatorial radius)
# https://en.wikipedia.org/wiki/Geodetic_datum
WGS84_EARTH_RADIUS = 6378137.0  # meters

# Meters per degree latitude (derived from WGS84 radius)
# Formula: 2 * π * radius / 360
# Used for flat-earth distance approximations
METERS_PER_DEGREE_LAT = 2 * math.pi * WGS84_EARTH_RADIUS / 360  # ~111319.49 meters

# Standard gravity
# https://en.wikipedia.org/wiki/Standard_gravity
EARTH_G = 9.80665  # m/s² (ISO 80000-3)

# OpenGL coordinate system vectors (Tacview native)
# Note: DCS uses flat-world U/V coordinates instead
FORWARD_VECTOR = (0.0, 0.0, -1.0)
UP_VECTOR = (0.0, 1.0, 0.0)
RIGHT_VECTOR = (1.0, 0.0, 0.0)
