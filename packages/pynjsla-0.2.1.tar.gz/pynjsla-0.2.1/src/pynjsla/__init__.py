from .njsla import njsla_split

__version__ = "0.2.1"
__all__ = 'njsla_split'
