"""LangChain tools for Revettr counterparty risk scoring."""

from typing import Any, Optional, Type

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


class ScoreCounterpartyInput(BaseModel):
    """Input for scoring a counterparty."""
    domain: Optional[str] = Field(None, description="Domain or URL of the counterparty (e.g., 'uniswap.org')")
    ip: Optional[str] = Field(None, description="IP address of the counterparty server")
    wallet_address: Optional[str] = Field(None, description="EVM wallet address (0x...)")
    chain: str = Field("base", description="Blockchain network (default: 'base')")
    company_name: Optional[str] = Field(None, description="Legal name to screen against sanctions lists")


class ScoreCounterpartyTool(BaseTool):
    """Score a counterparty before sending money.

    Returns a risk score 0-100 with per-signal breakdown.
    Score 80-100 = low risk, 60-79 = medium, 30-59 = high, 0-29 = critical.

    Requires: pip install revettr langchain-revettr
    Optional: pip install revettr[x402] for automatic payment
    """

    name: str = "score_counterparty"
    description: str = (
        "Score a counterparty before sending money. Returns a risk score 0-100 "
        "with breakdown by domain intelligence, IP reputation, wallet history, "
        "and sanctions screening. Use before any x402 payment or financial transaction. "
        "Send any combination of: domain, ip, wallet_address, company_name."
    )
    args_schema: Type[BaseModel] = ScoreCounterpartyInput

    wallet_private_key: Optional[str] = None
    base_url: str = "https://revettr.com"

    def _run(
        self,
        domain: Optional[str] = None,
        ip: Optional[str] = None,
        wallet_address: Optional[str] = None,
        chain: str = "base",
        company_name: Optional[str] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Score a counterparty and return the result as a string."""
        from revettr import Revettr

        client = Revettr(
            base_url=self.base_url,
            wallet_private_key=self.wallet_private_key,
        )

        try:
            result = client.score(
                domain=domain,
                ip=ip,
                wallet_address=wallet_address,
                chain=chain,
                company_name=company_name,
            )
            return (
                f"Score: {result.score}/100 (tier: {result.tier}, confidence: {result.confidence})\n"
                f"Flags: {', '.join(result.flags) if result.flags else 'none'}\n"
                f"Signals checked: {result.signals_checked}"
            )
        except Exception as e:
            return f"Error scoring counterparty: {e}"


class ShouldPayInput(BaseModel):
    """Input for payment decision."""
    url: str = Field(..., description="URL of the service to pay")
    amount: Optional[float] = Field(None, description="Payment amount in USD")
    min_score: int = Field(60, description="Minimum acceptable risk score (0-100)")


class ShouldPayTool(BaseTool):
    """Decide whether an agent should pay a counterparty.

    Returns a clear YES/NO/WARN decision based on Revettr risk scoring.
    Use this before any x402 payment to determine if the counterparty is safe.
    """

    name: str = "should_pay"
    description: str = (
        "Decide whether to pay a counterparty. Returns YES, NO, or WARN "
        "with the risk score and reasoning. Use before sending any payment."
    )
    args_schema: Type[BaseModel] = ShouldPayInput

    wallet_private_key: Optional[str] = None
    base_url: str = "https://revettr.com"

    def _run(
        self,
        url: str,
        amount: Optional[float] = None,
        min_score: int = 60,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Return a payment decision."""
        from urllib.parse import urlparse
        from revettr import Revettr

        domain = urlparse(url).hostname or url
        client = Revettr(
            base_url=self.base_url,
            wallet_private_key=self.wallet_private_key,
        )

        try:
            result = client.score(domain=domain)

            if result.score >= min_score:
                decision = "YES"
                reason = f"Counterparty scored {result.score}/100 ({result.tier} risk) — safe to proceed."
            elif result.score >= 30:
                decision = "WARN"
                reason = (
                    f"Counterparty scored {result.score}/100 ({result.tier} risk). "
                    f"Flags: {', '.join(result.flags)}. Proceed with caution."
                )
            else:
                decision = "NO"
                reason = (
                    f"Counterparty scored {result.score}/100 ({result.tier} risk). "
                    f"Flags: {', '.join(result.flags)}. Do NOT send payment."
                )

            return f"Decision: {decision}\n{reason}"
        except Exception as e:
            return f"Decision: WARN\nCould not score counterparty: {e}. Proceed with caution."
