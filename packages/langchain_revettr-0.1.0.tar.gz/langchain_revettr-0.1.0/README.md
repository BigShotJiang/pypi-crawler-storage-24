# langchain-revettr

LangChain tools for [Revettr](https://revettr.com) counterparty risk scoring. Score wallets, domains, IPs, and companies 0-100 before sending payments in agentic commerce.

## Install

```bash
pip install langchain-revettr

# With x402 auto-payment:
pip install langchain-revettr[x402]
```

## Tools

### `ScoreCounterpartyTool`

Score any counterparty 0-100 with per-signal breakdown.

```python
from langchain_revettr import ScoreCounterpartyTool

tool = ScoreCounterpartyTool(wallet_private_key="0x...")  # Optional: for x402 payment
result = tool.invoke({"domain": "uniswap.org"})
print(result)
# Score: 92/100 (tier: low, confidence: 0.75)
# Flags: none
# Signals checked: 3
```

### `ShouldPayTool`

Get a clear YES/NO/WARN decision before sending payment.

```python
from langchain_revettr import ShouldPayTool

tool = ShouldPayTool(wallet_private_key="0x...")
result = tool.invoke({"url": "https://some-api.com", "min_score": 60})
print(result)
# Decision: YES
# Counterparty scored 92/100 (low risk) — safe to proceed.
```

### With a LangChain Agent

```python
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_revettr import ScoreCounterpartyTool, ShouldPayTool

tools = [ScoreCounterpartyTool(), ShouldPayTool()]
llm = ChatOpenAI(model="gpt-4")
agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)

result = executor.invoke({"input": "Should I pay the service at sketchy-crypto.xyz?"})
```

## Pricing

$0.01 USDC per score via [x402](https://x402.org) on Base. No API keys needed.

## Links

- [Revettr API](https://revettr.com)
- [revettr SDK](https://pypi.org/project/revettr/)
- [MCP Server](https://github.com/AlexanderLawson17/revettr-python) — works with Claude Desktop, Cursor, CrewAI
