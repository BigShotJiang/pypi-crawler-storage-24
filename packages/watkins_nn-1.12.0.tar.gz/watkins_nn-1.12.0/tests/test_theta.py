"""
Tests for the theta module: Jacobi theta functions at the golden nome
and the Theta-Lucas dictionary.

Phase 88.0 | CSID: THETA-TEST-001
"""

import math
import pytest

from watkins_nn.constants import PHI, PHI_INV
from watkins_nn.kaleidoscope import lucas, fibonacci
from watkins_nn.theta import (
    golden_nome,
    golden_tau,
    theta2_golden,
    theta3_golden,
    theta4_golden,
    lucas_reciprocal_sum,
    fibonacci_reciprocal_sum,
    theta_lucas_identity,
    jacobi_triple_product,
    jacobi_triple_product_sum,
    eta_dedekind_golden,
    eta_quotient_golden,
    hecke_T_p,
    theta3_coefficients,
    theta3_squared_coefficients,
    delta_modular_golden,
    eisenstein_E4_golden,
    eisenstein_E6_golden,
    theta_lucas_report,
)


# =============================================================================
# GOLDEN NOME
# =============================================================================

class TestGoldenNome:
    def test_golden_nome_value(self):
        assert golden_nome() == pytest.approx(1.0 / PHI ** 2, abs=1e-15)

    def test_golden_nome_is_phi_inv_squared(self):
        assert golden_nome() == pytest.approx(PHI_INV ** 2, abs=1e-15)

    def test_golden_nome_less_than_one(self):
        assert 0 < golden_nome() < 1

    def test_golden_nome_numerical(self):
        assert golden_nome() == pytest.approx(0.3819660112501052, abs=1e-12)


# =============================================================================
# GOLDEN TAU
# =============================================================================

class TestGoldenTau:
    def test_tau_is_purely_imaginary(self):
        tau = golden_tau()
        assert tau.real == pytest.approx(0.0, abs=1e-15)
        assert tau.imag > 0

    def test_tau_gives_golden_nome(self):
        """e^{2*pi*i*tau} should equal the golden nome."""
        import cmath
        tau = golden_tau()
        q_recovered = cmath.exp(2 * math.pi * 1j * tau)
        assert q_recovered.real == pytest.approx(golden_nome(), abs=1e-12)
        assert abs(q_recovered.imag) < 1e-12


# =============================================================================
# THETA FUNCTIONS
# =============================================================================

class TestThetaFunctions:
    def test_theta3_positive(self):
        assert theta3_golden() > 1.0

    def test_theta2_positive(self):
        assert theta2_golden() > 0.0

    def test_theta4_positive(self):
        assert theta4_golden() > 0.0

    def test_theta3_value(self):
        assert theta3_golden() == pytest.approx(1.8068510462253213, abs=1e-10)

    def test_theta2_value(self):
        assert theta2_golden() == pytest.approx(1.8065967824482834, abs=1e-10)

    def test_theta4_value(self):
        assert theta4_golden() == pytest.approx(0.27829471999592426, abs=1e-10)

    def test_theta3_convergence(self):
        """More terms should not change the result significantly."""
        t50 = theta3_golden(50)
        t100 = theta3_golden(100)
        assert abs(t50 - t100) < 1e-14


# =============================================================================
# THETA-LUCAS IDENTITY
# =============================================================================

class TestThetaLucasIdentity:
    def test_identity_holds(self):
        """theta_3(q)^2 = 1 + 4 * sum 1/L(2n) at golden nome."""
        t3 = theta3_golden(100)
        lrs = lucas_reciprocal_sum(100)
        assert t3 ** 2 == pytest.approx(1.0 + 4.0 * lrs, abs=1e-12)

    def test_identity_dict(self):
        result = theta_lucas_identity(100)
        assert 'theta3_squared' in result
        assert 'lucas_side' in result
        assert 'difference' in result
        assert 'terms' in result
        assert result['terms'] == 100
        assert result['difference'] < 1e-12

    def test_lucas_reciprocal_sum_positive(self):
        assert lucas_reciprocal_sum(50) > 0

    def test_lucas_reciprocal_sum_convergence(self):
        s50 = lucas_reciprocal_sum(50)
        s100 = lucas_reciprocal_sum(100)
        assert abs(s50 - s100) < 1e-14

    def test_fibonacci_reciprocal_sum_positive(self):
        assert fibonacci_reciprocal_sum(50) > 0


# =============================================================================
# JACOBI IDENTITY: theta3^4 = theta2^4 + theta4^4
# =============================================================================

class TestJacobiIdentity:
    def test_jacobi_quartic_identity(self):
        t2 = theta2_golden(100)
        t3 = theta3_golden(100)
        t4 = theta4_golden(100)
        assert t3 ** 4 == pytest.approx(t2 ** 4 + t4 ** 4, abs=1e-10)

    def test_jacobi_quartic_values(self):
        t3 = theta3_golden(100)
        assert t3 ** 4 == pytest.approx(10.658335975885977, abs=1e-8)


# =============================================================================
# JACOBI TRIPLE PRODUCT
# =============================================================================

class TestJacobiTripleProduct:
    def test_triple_product_equals_series(self):
        """Product form should equal series form."""
        q = 0.3
        z = 1.0
        prod_val = jacobi_triple_product(q, z, 50)
        series_val = jacobi_triple_product_sum(q, z, 50)
        assert prod_val == pytest.approx(series_val, rel=1e-8)

    def test_triple_product_z1_is_theta3(self):
        """JTP with z=1 should give theta_3."""
        q = golden_nome()
        # theta3 = JTP(q^{1/2}, 1) when using the standard convention
        # Direct series: sum z^n q^{n^2} with z=1 is theta3
        series_val = jacobi_triple_product_sum(q, 1.0, 50)
        t3 = theta3_golden(50)
        assert series_val == pytest.approx(t3, abs=1e-10)

    def test_invalid_q_raises(self):
        with pytest.raises(ValueError):
            jacobi_triple_product(1.5, 1.0)

    def test_invalid_z_raises(self):
        with pytest.raises(ValueError):
            jacobi_triple_product(0.5, 0.0)


# =============================================================================
# DEDEKIND ETA
# =============================================================================

class TestDedekindEta:
    def test_eta_positive(self):
        assert eta_dedekind_golden() > 0

    def test_eta_value(self):
        assert eta_dedekind_golden(200) == pytest.approx(0.46251828769836895, abs=1e-10)

    def test_eta_quotient_self(self):
        """eta(tau)/eta(tau) = 1."""
        assert eta_quotient_golden(1, 1) == pytest.approx(1.0, abs=1e-10)

    def test_delta_modular_positive(self):
        assert delta_modular_golden() > 0

    def test_delta_equals_eta_24(self):
        eta = eta_dedekind_golden(100)
        delta = delta_modular_golden(100)
        assert delta == pytest.approx(eta ** 24, rel=1e-6)


# =============================================================================
# Q-EXPANSION COEFFICIENTS
# =============================================================================

class TestCoefficients:
    def test_theta3_coefficients_constant(self):
        c = theta3_coefficients(10)
        assert c[0] == 1

    def test_theta3_coefficients_squares(self):
        c = theta3_coefficients(10)
        assert c[1] == 2  # q^1 = q^{1^2}
        assert c[4] == 2  # q^4 = q^{2^2}
        assert c[9] == 2  # q^9 = q^{3^2}

    def test_theta3_coefficients_nonsquares(self):
        c = theta3_coefficients(10)
        assert c[2] == 0
        assert c[3] == 0
        assert c[5] == 0

    def test_theta3_squared_coefficients_r2(self):
        """Coefficient of q^n in theta3^2 is r_2(n), representations as sum of 2 squares."""
        c = theta3_squared_coefficients(10)
        assert c[0] == 1  # 0 = 0^2 + 0^2
        assert c[1] == 4  # 1 = (+-1)^2 + 0^2 or 0^2 + (+-1)^2
        assert c[2] == 4  # 2 = (+-1)^2 + (+-1)^2
        assert c[5] == 8  # 5 = (+-1)^2 + (+-2)^2 or (+-2)^2 + (+-1)^2


# =============================================================================
# HECKE OPERATORS
# =============================================================================

class TestHeckeOperators:
    def test_hecke_T2_on_theta3(self):
        """T_2 should produce valid coefficients."""
        c = theta3_coefficients(20)
        c_float = [float(x) for x in c]
        result = hecke_T_p(2, c_float)
        assert len(result) > 0
        assert isinstance(result[0], float)

    def test_hecke_T2_coefficient_0(self):
        """(T_2 f)_0 = a_0 + a_0 = 2*a_0 for theta3."""
        c = [float(x) for x in theta3_coefficients(20)]
        result = hecke_T_p(2, c)
        # n=0: a_{2*0} + a_{0/2} = a_0 + a_0 = 2
        assert result[0] == pytest.approx(2.0)

    def test_hecke_T2_coefficient_1(self):
        """(T_2 f)_1 = a_2 for theta3 (since 2 does not divide 1)."""
        c = [float(x) for x in theta3_coefficients(20)]
        result = hecke_T_p(2, c)
        # n=1: a_{2} + 0 = 0
        assert result[1] == pytest.approx(0.0)

    def test_hecke_invalid_p(self):
        with pytest.raises(ValueError):
            hecke_T_p(1, [1.0, 0.0, 1.0])


# =============================================================================
# EISENSTEIN SERIES
# =============================================================================

class TestEisenstein:
    def test_e4_greater_than_1(self):
        assert eisenstein_E4_golden(50) > 1.0

    def test_e6_less_than_1(self):
        # E6 starts at 1 but subtracts, so for large enough q it should be < 1
        assert eisenstein_E6_golden(50) < 1.0

    def test_e4_e6_discriminant_relation(self):
        """Delta = (E4^3 - E6^2) / 1728."""
        e4 = eisenstein_E4_golden(80)
        e6 = eisenstein_E6_golden(80)
        delta_from_eis = (e4 ** 3 - e6 ** 2) / 1728.0
        delta_direct = delta_modular_golden(80)
        assert delta_from_eis == pytest.approx(delta_direct, rel=0.05)


# =============================================================================
# FULL REPORT
# =============================================================================

class TestThetaLucasReport:
    def test_report_keys(self):
        report = theta_lucas_report(20)
        expected_keys = {
            'golden_nome', 'golden_tau', 'theta2', 'theta3', 'theta4',
            'theta3_squared', 'lucas_sum', 'lucas_identity_rhs',
            'lucas_identity_error', 'jacobi_identity_lhs',
            'jacobi_identity_rhs', 'jacobi_identity_error',
            'eta_dedekind', 'theta2_over_theta3', 'theta4_over_theta3',
        }
        assert set(report.keys()) == expected_keys

    def test_report_identities_hold(self):
        report = theta_lucas_report(50)
        assert report['lucas_identity_error'] < 1e-12
        assert report['jacobi_identity_error'] < 1e-10
