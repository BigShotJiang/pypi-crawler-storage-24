/**
 * Sandbox class for interacting with a specific sandbox instance.
 */

import type { SandboxClient } from "./client.js";
import type { ExecutionResult, RunOptions, SandboxData } from "./types.js";
import {
  LangSmithDataplaneNotConfiguredError,
  LangSmithSandboxNotReadyError,
} from "./errors.js";
import { handleSandboxHttpError } from "./helpers.js";
import { CommandHandle } from "./command_handle.js";
import { reconnectWsStream, runWsStream } from "./ws_execute.js";

/**
 * Represents an active sandbox for running commands and file operations.
 *
 * This class is typically obtained from SandboxClient.createSandbox() and
 * provides methods for command execution and file I/O within the sandbox
 * environment.
 *
 * @example
 * ```typescript
 * const sandbox = await client.createSandbox("python-sandbox");
 * try {
 *   const result = await sandbox.run("python --version");
 *   console.log(result.stdout);
 * } finally {
 *   await sandbox.delete();
 * }
 * ```
 */
export class Sandbox {
  /** Display name (can be updated). */
  readonly name: string;
  /** Name of the template used to create this sandbox. */
  readonly template_name: string;
  /** URL for data plane operations (file I/O, command execution). */
  readonly dataplane_url?: string;
  /** Provisioning status ("provisioning", "ready", "failed"). */
  readonly status?: string;
  /** Human-readable status message (e.g., error details when failed). */
  readonly status_message?: string;
  /** Unique identifier (UUID). Remains constant even if name changes. */
  readonly id?: string;
  /** Timestamp when the sandbox was created. */
  readonly created_at?: string;
  /** Timestamp when the sandbox was last updated. */
  readonly updated_at?: string;

  private _client: SandboxClient;

  /** @internal */
  constructor(data: SandboxData, client: SandboxClient) {
    this.name = data.name;
    this.template_name = data.template_name;
    this.dataplane_url = data.dataplane_url;
    this.status = data.status;
    this.status_message = data.status_message;
    this.id = data.id;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
    this._client = client;
  }

  /**
   * Validate and return the dataplane URL.
   * @throws LangSmithSandboxNotReadyError if sandbox status is not "ready".
   * @throws LangSmithDataplaneNotConfiguredError if dataplane_url is not configured.
   */
  private requireDataplaneUrl(): string {
    if (this.status && this.status !== "ready") {
      throw new LangSmithSandboxNotReadyError(
        `Sandbox '${this.name}' is not ready (status: ${this.status}). ` +
          "Use waitForSandbox() to wait for the sandbox to become ready."
      );
    }
    if (!this.dataplane_url) {
      throw new LangSmithDataplaneNotConfiguredError(
        `Sandbox '${this.name}' does not have a dataplane_url configured. ` +
          "Runtime operations require a dataplane URL."
      );
    }
    return this.dataplane_url;
  }

  /**
   * Execute a command in the sandbox.
   *
   * When `wait` is true (default) and no streaming callbacks are provided,
   * tries WebSocket first and falls back to HTTP POST.
   *
   * When `wait` is false or streaming callbacks are provided, uses WebSocket
   * (required). Returns a CommandHandle for streaming output.
   *
   * @param command - Shell command to execute.
   * @param options - Execution options.
   * @returns ExecutionResult when wait=true, CommandHandle when wait=false.
   *
   * @example
   * ```typescript
   * // Blocking (default)
   * const result = await sandbox.run("echo hello");
   * console.log(result.stdout);
   *
   * // Streaming with callbacks
   * const result = await sandbox.run("make build", {
   *   onStdout: (data) => process.stdout.write(data),
   * });
   *
   * // Non-blocking with CommandHandle
   * const handle = await sandbox.run("make build", { wait: false });
   * for await (const chunk of handle) {
   *   process.stdout.write(chunk.data);
   * }
   * const result = await handle.result;
   * ```
   */
  async run(
    command: string,
    options: RunOptions & { wait: false }
  ): Promise<CommandHandle>;
  async run(
    command: string,
    options?: RunOptions & { wait?: true }
  ): Promise<ExecutionResult>;
  async run(
    command: string,
    options?: RunOptions
  ): Promise<ExecutionResult | CommandHandle>;
  async run(
    command: string,
    options: RunOptions = {}
  ): Promise<ExecutionResult | CommandHandle> {
    const {
      wait = true,
      onStdout,
      onStderr,
      idleTimeout,
      killOnDisconnect,
      ttlSeconds,
      pty,
      ...restOptions
    } = options;
    const hasCallbacks = onStdout !== undefined || onStderr !== undefined;

    if (!wait || hasCallbacks) {
      // WebSocket required for streaming / non-blocking
      const handle = await this._runWs(command, {
        ...restOptions,
        idleTimeout,
        killOnDisconnect,
        ttlSeconds,
        pty,
        onStdout,
        onStderr,
      });

      if (!wait) {
        return handle;
      }

      // wait=true with callbacks: drain stream and return result
      return handle.result;
    }

    // wait=true, no callbacks: try WS, fall back to HTTP
    try {
      const handle = await this._runWs(command, {
        ...restOptions,
        idleTimeout,
        killOnDisconnect,
        ttlSeconds,
        pty,
      });
      return await handle.result;
    } catch (e) {
      // Fall back to HTTP on connection errors or missing ws package
      const name = e != null && typeof e === "object" ? (e as Error).name : "";
      const message =
        e != null && typeof e === "object" ? (e as Error).message ?? "" : "";
      if (
        name === "LangSmithSandboxConnectionError" ||
        name === "LangSmithSandboxServerReloadError" ||
        message.includes("'ws' package")
      ) {
        return this._runHttp(command, restOptions);
      }
      throw e;
    }
  }

  /**
   * Execute a command via WebSocket streaming.
   * @internal
   */
  private async _runWs(
    command: string,
    options: Omit<RunOptions, "wait"> = {}
  ): Promise<CommandHandle> {
    const {
      timeout = 60,
      env,
      cwd,
      shell = "/bin/bash",
      onStdout,
      onStderr,
      idleTimeout,
      killOnDisconnect,
      ttlSeconds,
      pty,
    } = options;
    const dataplaneUrl = this.requireDataplaneUrl();

    const [stream, control] = await runWsStream(
      dataplaneUrl,
      this._client.getApiKey(),
      command,
      {
        timeout,
        env,
        cwd,
        shell,
        onStdout,
        onStderr,
        idleTimeout,
        killOnDisconnect,
        ttlSeconds,
        pty,
      }
    );

    const handle = new CommandHandle(stream, control, this);
    await handle._ensureStarted();
    return handle;
  }

  /**
   * Execute a command via HTTP POST (blocking).
   * @internal
   */
  private async _runHttp(
    command: string,
    options: Omit<RunOptions, "wait" | "onStdout" | "onStderr"> = {}
  ): Promise<ExecutionResult> {
    const { timeout = 60, env, cwd, shell = "/bin/bash" } = options;
    const dataplaneUrl = this.requireDataplaneUrl();
    const url = `${dataplaneUrl}/execute`;

    const payload: Record<string, unknown> = {
      command,
      timeout,
      shell,
    };
    if (env !== undefined) {
      payload.env = env;
    }
    if (cwd !== undefined) {
      payload.cwd = cwd;
    }

    const response = await this._client._fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout((timeout + 10) * 1000),
    });

    if (!response.ok) {
      await handleSandboxHttpError(response);
    }

    const data = await response.json();
    return {
      stdout: data.stdout ?? "",
      stderr: data.stderr ?? "",
      exit_code: data.exit_code ?? -1,
    };
  }

  /**
   * Reconnect to a running command by its command ID.
   *
   * Returns a new CommandHandle that resumes output from the given offsets.
   *
   * @param commandId - The server-assigned command ID.
   * @param options - Reconnection options with byte offsets.
   * @returns A new CommandHandle.
   */
  async reconnect(
    commandId: string,
    options: {
      stdoutOffset?: number;
      stderrOffset?: number;
    } = {}
  ): Promise<CommandHandle> {
    const { stdoutOffset = 0, stderrOffset = 0 } = options;
    const dataplaneUrl = this.requireDataplaneUrl();

    const [stream, control] = await reconnectWsStream(
      dataplaneUrl,
      this._client.getApiKey(),
      commandId,
      { stdoutOffset, stderrOffset }
    );

    return new CommandHandle(stream, control, this, {
      commandId,
      stdoutOffset,
      stderrOffset,
    });
  }

  /**
   * Write content to a file in the sandbox.
   *
   * @param path - Target file path in the sandbox.
   * @param content - File content (string or bytes).
   * @param timeout - Request timeout in seconds.
   *
   * @example
   * ```typescript
   * await sandbox.write("/tmp/script.py", 'print("Hello!")');
   * ```
   */
  async write(
    path: string,
    content: string | Uint8Array,
    timeout = 60
  ): Promise<void> {
    const dataplaneUrl = this.requireDataplaneUrl();
    const url = `${dataplaneUrl}/upload?path=${encodeURIComponent(path)}`;

    // Ensure content is bytes for multipart upload
    const bytes =
      typeof content === "string" ? new TextEncoder().encode(content) : content;

    const formData = new FormData();
    // Create a copy to ensure we have a plain ArrayBuffer (not SharedArrayBuffer)
    const buffer = new Uint8Array(bytes).buffer as ArrayBuffer;
    const blob = new Blob([buffer], { type: "application/octet-stream" });
    formData.append("file", blob, "file");

    const response = await this._client._fetch(url, {
      method: "POST",
      body: formData,
      signal: AbortSignal.timeout(timeout * 1000),
    });

    if (!response.ok) {
      await handleSandboxHttpError(response);
    }
  }

  /**
   * Read a file from the sandbox.
   *
   * @param path - File path to read.
   * @param timeout - Request timeout in seconds.
   * @returns File contents as Uint8Array.
   *
   * @example
   * ```typescript
   * const content = await sandbox.read("/tmp/output.txt");
   * const text = new TextDecoder().decode(content);
   * console.log(text);
   * ```
   */
  async read(path: string, timeout = 60): Promise<Uint8Array> {
    const dataplaneUrl = this.requireDataplaneUrl();
    const url = `${dataplaneUrl}/download?path=${encodeURIComponent(path)}`;

    const response = await this._client._fetch(url, {
      method: "GET",
      signal: AbortSignal.timeout(timeout * 1000),
    });

    if (!response.ok) {
      await handleSandboxHttpError(response);
    }

    const buffer = await response.arrayBuffer();
    return new Uint8Array(buffer);
  }

  /**
   * Delete this sandbox.
   *
   * @example
   * ```typescript
   * const sandbox = await client.createSandbox("python-sandbox");
   * try {
   *   await sandbox.run("echo hello");
   * } finally {
   *   await sandbox.delete();
   * }
   * ```
   */
  async delete(): Promise<void> {
    await this._client.deleteSandbox(this.name);
  }
}
