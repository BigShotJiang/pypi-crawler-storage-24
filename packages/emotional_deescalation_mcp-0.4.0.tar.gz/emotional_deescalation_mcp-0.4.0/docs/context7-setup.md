[Русская версия](context7-setup.ru.md)

# Using with Context7

[Context7](https://context7.com) provides up-to-date documentation for LLMs and AI code editors. Once indexed, any LLM agent using Context7 MCP can instantly access the Emotional De-escalation MCP documentation — tools, parameters, usage patterns, and integration guides.

## Step 1: Add Context7 MCP Server

Add Context7 to your MCP client configuration.

### Claude Desktop / Claude Code

Add to `~/.claude/settings.json` or `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    }
  }
}
```

### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    }
  }
}
```

### Windsurf

Add to `~/.codeium/windsurf/mcp_config.json`:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    }
  }
}
```

## Step 2: Add the Emotional De-escalation MCP Server

Add the emotional de-escalation server alongside Context7:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    },
    "emotional-deescalation": {
      "command": "uvx",
      "args": ["emotional-deescalation-mcp"]
    }
  }
}
```

For API mode (direct LLM calls), add the API key:

```json
{
  "mcpServers": {
    "emotional-deescalation": {
      "command": "uvx",
      "args": ["emotional-deescalation-mcp"],
      "env": {
        "ANTHROPIC_API_KEY": "sk-ant-...",
        "EMOTION_MCP_MODE": "api"
      }
    }
  }
}
```

## Step 3: Query Documentation via Context7

Once both servers are running, ask your LLM agent to use Context7 to look up the emotional de-escalation MCP documentation:

**Example prompts:**

```
use context7 to look up emotional-deescalation-mcp docs, then call strategy_suggest for this dialogue
```

```
use context7: how does emotion_de_escalate work? what parameters does it accept?
```

```
use context7 to find the integration guide for emotional-deescalation MCP, then help me set up the REST API webhook
```

Context7 will resolve the library, fetch the relevant docs, and inject them directly into the LLM context — ensuring the agent always has accurate, up-to-date information about tools and parameters.

## How Context7 Indexes This Project

The `context7.json` file in the repository root controls what Context7 indexes:

- **Included**: `README.md`, `AGENTS.md`, `CONTRIBUTING.md`, all files in `docs/`, `prompts/`, `config/`
- **Excluded**: source code internals (`nlp_service/`, `tests/`), build artifacts, IDE config
- **Rules**: best practices injected into every Context7 query about this project

This means Context7 will always have access to:
- Tool reference (`AGENTS.md`) — parameters, return types, usage patterns
- Integration guide (`docs/integration_guide.md`) — REST API, webhooks, escalation signals
- System prompts (`prompts/`) — ready-to-use bot configurations
- Pattern config (`config/patterns.toml`) — customizable keywords and thresholds

## Submitting to Context7

The library is submitted to Context7 via the web interface:

1. Go to [context7.com/add-library](https://context7.com/add-library)
2. Paste the GitHub repository URL
3. Context7 automatically detects `context7.json` and indexes the documentation
4. The library becomes available as `emotional-deescalation-mcp` for all Context7 users

After indexing, any LLM agent with Context7 MCP can query the docs using:
```
use context7: emotional-deescalation-mcp strategy_suggest
```
