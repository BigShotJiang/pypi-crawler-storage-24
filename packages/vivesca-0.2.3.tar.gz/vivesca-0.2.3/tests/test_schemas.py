"""Tests for vivesca base output schemas."""

from pydantic import BaseModel


def test_tool_output_is_base_model():
    from vivesca.schemas import ToolOutput
    assert issubclass(ToolOutput, BaseModel)


def test_tool_output_allows_extra_fields():
    from vivesca.schemas import ToolOutput
    obj = ToolOutput.model_validate({"unexpected": "value"})
    assert obj.unexpected == "value"


def test_tool_output_json_schema():
    from vivesca.schemas import ToolOutput

    class MyOutput(ToolOutput):
        name: str
        count: int

    schema = MyOutput.model_json_schema()
    assert "name" in schema["properties"]
    assert "count" in schema["properties"]


def test_error_output_fields():
    from vivesca.schemas import ErrorOutput
    err = ErrorOutput(error="not found", code="NOT_FOUND")
    assert err.error == "not found"
    assert err.code == "NOT_FOUND"
    assert err.details == {}


def test_error_output_with_details():
    from vivesca.schemas import ErrorOutput
    err = ErrorOutput(error="timeout", code="TIMEOUT", details={"elapsed": 30})
    assert err.details["elapsed"] == 30


def test_error_output_json_roundtrip():
    from vivesca.schemas import ErrorOutput
    err = ErrorOutput(error="fail", code="ERR")
    data = err.model_dump()
    restored = ErrorOutput.model_validate(data)
    assert restored == err


def test_list_output_fields():
    from vivesca.schemas import ListOutput
    out = ListOutput(items=[{"id": 1}, {"id": 2}], count=2)
    assert out.count == 2
    assert len(out.items) == 2


def test_list_output_auto_count():
    from vivesca.schemas import ListOutput
    out = ListOutput(items=[{"a": 1}, {"b": 2}, {"c": 3}])
    assert out.count == 3


def test_status_output_fields():
    from vivesca.schemas import StatusOutput
    out = StatusOutput(status="ok", message="All systems nominal")
    assert out.status == "ok"
    assert out.details == {}


def test_action_output_fields():
    from vivesca.schemas import ActionOutput
    out = ActionOutput(success=True, message="Created event")
    assert out.success is True
    assert out.data == {}