# AGENTS.md — Vivesca

## What this is
Vivesca is a Python framework for scaffolding opinionated MCP (Model Context Protocol) tool ecosystems.
It provides CLI commands (vivesca init/add/check), Jinja2 templates, and Pydantic base schemas.

## Build & test
```
uv sync
uv run pytest tests/ -v
```

## Conventions
- Python 3.11+, type hints everywhere
- Tests in tests/, mirror src structure
- Click for CLI, Jinja2 for templates, Pydantic for schemas
- Templates live in src/vivesca/templates/ as .j2 files
- TDD: write failing test first, then implement