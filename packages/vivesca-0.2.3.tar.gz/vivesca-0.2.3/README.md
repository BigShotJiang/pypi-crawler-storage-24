# vivesca

Unified MCP server with structured output — tools for messaging, search, calendar, memory, browser automation, and health monitoring.

<!-- mcp-name: org.vivesca/vivesca -->

## Install

```bash
uv add vivesca
```

## What it provides

- **24 tools** across 7 domains (deltos, noesis, fasti, keryx, oghma, navigator, vigilis)
- **Structured output** — every tool returns Pydantic models with `outputSchema`
- **Tool annotations** — `readOnlyHint`, `destructiveHint` on every tool
- **4 resources** — budget, calendar, search log, memory stats
- **3 prompts** — research, draft message, morning brief

## Philosophy

Token economics creates selection pressure. Context windows are finite environments.
Tools that waste tokens get replaced. Tools that return structured, lean output survive.

[vivesca.org](https://vivesca.org)
