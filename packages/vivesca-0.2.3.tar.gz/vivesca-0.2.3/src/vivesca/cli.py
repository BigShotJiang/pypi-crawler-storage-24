# src/vivesca/cli.py
"""vivesca CLI — scaffold and validate MCP tool ecosystems."""

from pathlib import Path

import click


@click.group()
@click.version_option()
def cli():
    """Vivesca — opinionated MCP tool ecosystem framework."""
    pass


@cli.command()
@click.argument("name")
@click.option("--description", "-d", default="An MCP server built with vivesca.", help="Project description.")
def init(name: str, description: str):
    """Scaffold a new MCP server project."""
    from vivesca.scaffold.init import scaffold_project

    target = Path.cwd() / name
    scaffold_project(name, target, description)
    click.echo(f"Created {name}/ — cd {name} && uv sync to get started.")


@cli.group()
def add():
    """Add a component to the current project."""
    pass


@add.command("tool")
@click.argument("name")
@click.option("--domain", "-d", help="Tool domain prefix (default: derived from name).")
@click.option("--verb", "-v", help="Tool verb (default: derived from name).")
@click.option("--description", default="TODO: describe this tool.", help="Tool description.")
@click.option("--read-only/--no-read-only", default=True, help="Whether tool is read-only.")
def add_tool(name: str, domain: str | None, verb: str | None, description: str, read_only: bool):
    """Add a tool to the current project.

    NAME can be 'domain_verb' (e.g., 'weather_fetch') or just 'domain'
    with --verb flag.
    """
    from vivesca.scaffold.add import add_tool_to_project

    if "_" in name and not domain:
        parts = name.split("_", 1)
        domain, verb = parts[0], parts[1]
    elif not domain:
        domain = name
    if not verb:
        verb = "get"

    path = add_tool_to_project(Path.cwd(), domain=domain, verb=verb, description=description, read_only=read_only)
    click.echo(f"Created {path.relative_to(Path.cwd())}")


@add.command("prompt")
@click.argument("name")
@click.option("--description", default="TODO: describe this prompt.", help="Prompt description.")
def add_prompt(name: str, description: str):
    """Add a prompt to the current project."""
    from vivesca.scaffold.add import add_prompt_to_project

    path = add_prompt_to_project(Path.cwd(), name=name, description=description)
    click.echo(f"Created {path.relative_to(Path.cwd())}")


@add.command("resource")
@click.argument("name")
@click.option("--description", default="TODO: describe this resource.", help="Resource description.")
@click.option("--uri-path", default="", help="Custom URI path (default: name).")
def add_resource(name: str, description: str, uri_path: str):
    """Add a resource to the current project."""
    from vivesca.scaffold.add import add_resource_to_project

    path = add_resource_to_project(Path.cwd(), name=name, description=description, uri_path=uri_path)
    click.echo(f"Created {path.relative_to(Path.cwd())}")


@cli.command()
def check():
    """Validate project against vivesca conventions."""
    from vivesca.scaffold.check import check_project

    issues = check_project(Path.cwd())
    if not issues:
        click.echo("All checks passed.")
    else:
        click.echo(f"Found {len(issues)} issue(s):\n")
        for issue in issues:
            click.echo(f"  - {issue}")
        raise SystemExit(1)