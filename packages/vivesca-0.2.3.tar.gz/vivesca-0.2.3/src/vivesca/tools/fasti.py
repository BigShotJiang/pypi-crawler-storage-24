"""fasti — Google Calendar management.

Tools:
  fasti_list_events  — list events for a date (read-only)
  fasti_create_event — create a new event
  fasti_move_event   — reschedule an existing event
  fasti_delete_event — remove an event (destructive)
"""

from typing import Optional

from vivesca.base import run_cli
from vivesca.schemas import ActionOutput, ToolOutput

from fastmcp.tools import tool
from mcp.types import ToolAnnotations

BINARY = "~/bin/fasti"


class EventListResult(ToolOutput):
    """Calendar events listing."""
    events: str


class EventActionResult(ActionOutput):
    """Result of a calendar mutation."""
    pass


@tool(
    name="fasti_list_events",
    description="List calendar events for a date (HKT). Call first to get event IDs.",
    annotations=ToolAnnotations(readOnlyHint=True),
)
def fasti_list_events(date: str = "today") -> EventListResult:
    """List Google Calendar events for a date."""
    result = run_cli(BINARY, ["list", date])
    return EventListResult(events=result)


@tool(
    name="fasti_create_event",
    description="Create a calendar event. Date: YYYY-MM-DD. Time: 24h HH:MM.",
    annotations=ToolAnnotations(idempotentHint=False),
)
def fasti_create_event(
    summary: str,
    date: str,
    from_time: str,
    to_time: str,
    description: Optional[str] = None,
    location: Optional[str] = None,
) -> EventActionResult:
    """Create a new Google Calendar event."""
    args = ["create", summary, "--date", date, "--from", from_time, "--to", to_time]
    if description:
        args.extend(["--description", description])
    if location:
        args.extend(["--location", location])
    result = run_cli(BINARY, args)
    return EventActionResult(success=True, message=result)


@tool(
    name="fasti_move_event",
    description="Reschedule an event. event_id from fasti_list_events — never guess.",
    annotations=ToolAnnotations(idempotentHint=True),
)
def fasti_move_event(event_id: str, date: str, time: str) -> EventActionResult:
    """Reschedule an existing event."""
    result = run_cli(BINARY, ["move", event_id, date, time])
    return EventActionResult(success=True, message=result)


@tool(
    name="fasti_delete_event",
    description="Delete an event. event_id from fasti_list_events — never guess.",
    annotations=ToolAnnotations(destructiveHint=True),
)
def fasti_delete_event(event_id: str) -> EventActionResult:
    """Remove an event from Google Calendar."""
    result = run_cli(BINARY, ["delete", event_id])
    return EventActionResult(success=True, message=result)
