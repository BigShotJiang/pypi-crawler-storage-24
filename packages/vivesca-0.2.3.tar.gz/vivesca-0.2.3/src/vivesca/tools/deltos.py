"""deltos — Telegram messaging via @TekmarBot.

Tools:
  deltos_send_text  — send a text/HTML message
  deltos_send_image — send an image file with optional caption
"""

import os

from vivesca.base import run_cli
from vivesca.schemas import ActionOutput

from fastmcp.tools import tool
from mcp.types import ToolAnnotations


class SendResult(ActionOutput):
    """Result of sending a Telegram message or image."""
    pass


BINARY = "~/bin/deltos"


@tool(
    name="deltos_send_text",
    description="Send text to Telegram. HTML by default; format='plain' for raw.",
    annotations=ToolAnnotations(destructiveHint=False, idempotentHint=False),
)
def deltos_send_text(text: str, format: str = "html") -> SendResult:
    """Send a text message to Telegram."""
    args: list[str] = []
    if format == "plain":
        args.append("--plain")
    result = run_cli(BINARY, args, stdin_text=text)
    return SendResult(success=True, message=result)


@tool(
    name="deltos_send_image",
    description="Send an image to Telegram with optional caption.",
    annotations=ToolAnnotations(destructiveHint=False, idempotentHint=False),
)
def deltos_send_image(path: str, caption: str = "") -> SendResult:
    """Send an image file to Telegram."""
    expanded = os.path.expanduser(path)
    if not os.path.isfile(expanded):
        raise ValueError(f"File not found: {expanded}")

    args = ["--photo", expanded]
    if caption:
        args.insert(0, caption)
    result = run_cli(BINARY, args)
    return SendResult(success=True, message=result)
