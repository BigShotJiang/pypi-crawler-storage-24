"""oghma — extracted memory database (FTS5 + vector embeddings).

Tools:
  oghma_search — search memories (keyword/vector/hybrid)
  oghma_stats  — database statistics
  oghma_status — DB path, count, daemon state
  oghma_add    — manually insert a memory
"""

from vivesca.base import run_cli
from vivesca.schemas import ActionOutput, StatusOutput, ToolOutput

from fastmcp.tools import tool
from mcp.types import ToolAnnotations

BINARY = "~/bin/oghma"


class MemorySearchResult(ToolOutput):
    """Memory search results."""
    results: str


class MemoryStatsResult(ToolOutput):
    """Memory database statistics."""
    stats: str


@tool(
    name="oghma_search",
    description="Search memories: keyword/vector/hybrid. Use for past session recall.",
    annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False),
)
def oghma_search(
    query: str,
    category: str = "",
    source_tool: str = "",
    limit: int = 10,
    mode: str = "hybrid",
) -> MemorySearchResult:
    """Search extracted memories."""
    args = ["search", query, "-n", str(limit), "--mode", mode]
    if category:
        args.extend(["-c", category])
    if source_tool:
        args.extend(["-t", source_tool])
    result = run_cli(BINARY, args)
    return MemorySearchResult(results=result)


@tool(
    name="oghma_stats",
    description="Memory DB stats: counts by category and source.",
    annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False),
)
def oghma_stats() -> MemoryStatsResult:
    """Get memory database statistics."""
    result = run_cli(BINARY, ["stats"])
    return MemoryStatsResult(stats=result)


@tool(
    name="oghma_status",
    description="Memory DB status: path, count, daemon state.",
    annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False),
)
def oghma_status() -> StatusOutput:
    """Show oghma daemon status."""
    result = run_cli(BINARY, ["status"])
    return StatusOutput(status="ok", message=result)


@tool(
    name="oghma_add",
    description="Add a memory manually.",
    annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=False),
)
def oghma_add(content: str, category: str = "gotcha", confidence: float = 0.8) -> ActionOutput:
    """Manually add a memory."""
    args = ["add", content, "-c", category, "--confidence", str(confidence)]
    result = run_cli(BINARY, args)
    return ActionOutput(success=True, message=result)
