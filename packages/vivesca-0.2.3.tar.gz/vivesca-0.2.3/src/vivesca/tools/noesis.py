"""noesis — web-grounded search via Perplexity API.

Tools:
  noesis_search   — quick search (~$0.006)
  noesis_ask      — thorough survey (~$0.01)
  noesis_research — deep research (~$0.40, EXPENSIVE)
"""

from vivesca.base import run_cli
from vivesca.schemas import ToolOutput

from fastmcp.tools import tool
from mcp.types import ToolAnnotations

BINARY = "~/.cargo/bin/noesis"
_RESEARCH_TIMEOUT = 300


class SearchResult(ToolOutput):
    """Web search synthesis with citations."""
    synthesis: str


@tool(
    name="noesis_search",
    description="Quick web search (~$0.006). Cited synthesis for factual lookups.",
    annotations=ToolAnnotations(readOnlyHint=False),
)
def noesis_search(query: str) -> SearchResult:
    """Quick web search."""
    result = run_cli(BINARY, ["search", query])
    return SearchResult(synthesis=result)


@tool(
    name="noesis_ask",
    description="Thorough web search (~$0.01). Structured survey with citations.",
    annotations=ToolAnnotations(readOnlyHint=False),
)
def noesis_ask(query: str) -> SearchResult:
    """Thorough web search."""
    result = run_cli(BINARY, ["ask", query])
    return SearchResult(synthesis=result)


@tool(
    name="noesis_research",
    description="Deep research (~$0.40). EXPENSIVE — depth must justify cost. Saves to ~/docs/.",
    annotations=ToolAnnotations(readOnlyHint=False),
)
def noesis_research(query: str) -> SearchResult:
    """Deep research (expensive)."""
    result = run_cli(BINARY, ["research", "--save", query], timeout=_RESEARCH_TIMEOUT)
    return SearchResult(synthesis=result)
