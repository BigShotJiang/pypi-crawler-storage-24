"""Allow `python -m vivesca` to run the server."""

from vivesca.server import main

main()
