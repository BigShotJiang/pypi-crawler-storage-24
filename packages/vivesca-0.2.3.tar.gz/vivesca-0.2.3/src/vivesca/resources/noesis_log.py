"""Noesis search log resource.

Resources:
  vivesca://noesis/search-log — last 10 search queries
"""

import os
import subprocess

from fastmcp.resources import resource

BINARY = "~/.cargo/bin/noesis"


@resource("vivesca://noesis/search-log")
def noesis_search_log() -> str:
    """Returns the last 10 noesis queries from the usage log."""
    path = os.path.expanduser(BINARY)
    try:
        result = subprocess.run(
            [path, "log"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        lines = result.stdout.strip().splitlines()
        return "\n".join(lines[-10:]) if len(lines) > 10 else result.stdout.strip()
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() or str(e)
        raise ValueError(f"noesis log error: {error_msg}")
