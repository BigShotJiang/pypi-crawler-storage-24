"""Oghma stats resource.

Resources:
  vivesca://oghma/stats — memory database overview
"""

from vivesca.base import run_cli

from fastmcp.resources import resource

BINARY = "~/bin/oghma"


@resource("vivesca://oghma/stats")
def oghma_stats_resource() -> str:
    """Returns current memory database statistics."""
    return run_cli(BINARY, ["stats"])
