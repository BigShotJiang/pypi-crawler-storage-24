"""Budget resource — current Claude Code token usage.

Resources:
  vivesca://budget — current token budget and usage status
"""

from vivesca.base import run_cli

from fastmcp.resources import resource

BINARY = "~/bin/usus"


@resource("vivesca://budget")
def budget_status() -> str:
    """Returns current Claude Code Max plan token budget and usage."""
    return run_cli(BINARY, ["--statusline"], timeout=20)
