"""Calendar resource — today's events snapshot.

Resources:
  vivesca://calendar/today — Google Calendar events for today (HKT)
"""

from vivesca.base import run_cli

from fastmcp.resources import resource

BINARY = "~/bin/fasti"


@resource("vivesca://calendar/today")
def calendar_today() -> str:
    """Returns today's Google Calendar events in HKT."""
    return run_cli(BINARY, ["list", "today"])
