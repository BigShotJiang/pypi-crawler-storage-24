"""Base Pydantic models for vivesca structured output.

All vivesca tool outputs should inherit from ToolOutput.
This ensures consistent outputSchema generation and
forward-compatible structured content.
"""

from pydantic import BaseModel, ConfigDict


class ToolOutput(BaseModel):
    """Base class for all vivesca tool outputs.

    Inherit from this to get:
    - Automatic outputSchema generation via FastMCP
    - Forward-compatible extra fields
    - Consistent JSON serialization
    """

    model_config = ConfigDict(extra="allow")


class ErrorOutput(BaseModel):
    """Standard error format for tool failures.

    Use this as the return type when a tool needs to
    communicate structured error information.
    """

    error: str
    code: str = "unknown"
    details: dict = {}


class ListOutput(ToolOutput):
    """Standard pattern for tools that return a list of items.

    If count is not provided, it defaults to len(items).
    """

    items: list[dict]
    count: int = 0

    def model_post_init(self, __context) -> None:
        if self.count == 0 and self.items:
            self.count = len(self.items)


class StatusOutput(ToolOutput):
    """Standard pattern for health/status checks."""

    status: str  # "ok", "warning", "error"
    message: str
    details: dict = {}


class ActionOutput(ToolOutput):
    """Standard pattern for mutation results."""

    success: bool
    message: str
    data: dict = {}