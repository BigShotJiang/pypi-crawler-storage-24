"""vivesca — unified MCP server.

Composes tools, resources, and prompts using FastMCP 3's
FileSystemProvider. Each domain is a standalone .py file.
"""

from pathlib import Path

from fastmcp import FastMCP
from fastmcp.server.providers import FileSystemProvider

INSTRUCTIONS = (
    "vivesca — unified MCP server. Tools prefixed by domain: "
    "deltos (Telegram), noesis (search), fasti (calendar, HKT), "
    "keryx (WhatsApp, NEVER sends), oghma (memory DB), "
    "navigator (browser), vigilis (health/system)."
)

_src = Path(__file__).resolve().parent


def create_server() -> FastMCP:
    """Build and return the vivesca FastMCP server."""
    mcp = FastMCP(
        "vivesca",
        instructions=INSTRUCTIONS,
        providers=[
            FileSystemProvider(_src / "tools"),
            FileSystemProvider(_src / "resources"),
            FileSystemProvider(_src / "prompts"),
        ],
    )
    return mcp


mcp = create_server()


def main():
    """Entry point for `vivesca` CLI and stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
