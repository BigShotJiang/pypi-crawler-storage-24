from pathlib import PurePosixPath

_INDEX_STEMS: frozenset[str] = frozenset({"__init__", "index"})


def compute_module_path_segments(file_path: str) -> list[str]:
    posix = PurePosixPath(file_path)
    stem = posix.stem

    if stem in _INDEX_STEMS:
        parent_name = posix.parent.name
        return [parent_name] if parent_name else []

    return [stem]
