from unittest.mock import MagicMock, patch

import pytest
from aiogram.fsm.storage.memory import MemoryStorage

from aiogram_prometheus.fsm.storages import ActionStorageManager


class TestActionStorageManager(object):
    @pytest.mark.asyncio
    async def test_execution_time_is_non_negative(self):
        collector = MagicMock()
        manager = ActionStorageManager(collector, MemoryStorage(), 'get_state', None)

        with patch('aiogram_prometheus.fsm.storages.time.time', side_effect=[2.0, 3.2]):
            await manager.__aenter__()
            await manager.__aexit__(None, None, None)

        assert collector.action.call_count == 1
        assert collector.action.call_args.args[3] == pytest.approx(1.2)

    @pytest.mark.asyncio
    async def test_exception_is_propagated_and_marked(self):
        collector = MagicMock()
        manager = ActionStorageManager(collector, MemoryStorage(), 'get_state', None)

        with pytest.raises(ValueError):
            async with manager:
                raise ValueError('boom')

        assert collector.action.call_count == 1
        assert isinstance(collector.action.call_args.args[4], ValueError)
