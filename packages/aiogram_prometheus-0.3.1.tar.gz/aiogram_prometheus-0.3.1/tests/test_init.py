def test_init():
    import aiogram_prometheus  # noqa: F401
