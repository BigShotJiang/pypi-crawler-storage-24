from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from aiogram_prometheus import PrometheusUpdatesMiddleware
from aiogram_prometheus.dispatchers.middlewares import UpdateMiddlewareManager


class TestPrometheusUpdatesMiddleware(object):
    def test_init(self):
        assert PrometheusUpdatesMiddleware(MagicMock())

    @pytest.mark.asyncio
    async def test_call(self):
        middleware = PrometheusUpdatesMiddleware(MagicMock())
        assert await middleware(AsyncMock(), MagicMock(), MagicMock())

    @pytest.mark.asyncio
    async def test_handler_exception_is_propagated_and_marked(self):
        middleware = PrometheusUpdatesMiddleware(MagicMock())
        middleware.collector = MagicMock()
        handler = AsyncMock(side_effect=RuntimeError('boom'))
        event = MagicMock()

        with pytest.raises(RuntimeError):
            await middleware(handler, event, {})

        assert middleware.collector.update.call_count == 1
        assert middleware.collector.update_executed.call_count == 1
        assert isinstance(middleware.collector.update_executed.call_args.args[2], RuntimeError)


class TestUpdateMiddlewareManager(object):
    @pytest.mark.asyncio
    async def test_execution_time_is_non_negative(self):
        collector = MagicMock()
        manager = UpdateMiddlewareManager(collector, MagicMock())

        with patch('aiogram_prometheus.dispatchers.middlewares.time.time', side_effect=[1.0, 2.5]):
            await manager.__aenter__()
            await manager.__aexit__(None, None, None)

        assert collector.update_executed.call_count == 1
        assert collector.update_executed.call_args.args[1] == pytest.approx(1.5)
