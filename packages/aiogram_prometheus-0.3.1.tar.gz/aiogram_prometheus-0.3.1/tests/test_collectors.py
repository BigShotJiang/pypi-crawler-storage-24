from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from aiogram.fsm.storage.base import StorageKey
from aiogram.fsm.storage.memory import MemoryStorage
from prometheus_client import CollectorRegistry
from prometheus_client.metrics_core import Metric

from aiogram_prometheus import FsmCollector, UpdatesCollector
from aiogram_prometheus.base_collector import SafeCollector
from aiogram_prometheus.dispatchers.collectors import get_unknown_attr


class TestFsmCollector(object):
    @pytest.fixture()
    def collector(self, prometheus_registry: CollectorRegistry):
        return FsmCollector.get_collector(prometheus_registry)

    def test_init(self, collector: FsmCollector) -> None:
        assert isinstance(collector, FsmCollector)

    def test_action(self, collector: FsmCollector) -> None:
        collector.action(MemoryStorage(), 'test', MagicMock(), 1, BaseException())

    def test_collect(self, collector: FsmCollector) -> None:
        for metric in collector.collect():
            assert isinstance(metric, Metric)

    def test_collect_with_storage_key(self, collector: FsmCollector) -> None:
        key = StorageKey(bot_id=1, chat_id=2, user_id=3, thread_id=4, business_connection_id='bc')
        collector.action(MemoryStorage(), 'get_state', key, 0.1)

        metrics = list(collector.collect())
        metric_names = {metric.name for metric in metrics}
        assert 'bots' in metric_names
        assert 'chats' in metric_names


class TestUpdatesCollector(object):
    @pytest.fixture()
    def collector(self, prometheus_registry: CollectorRegistry):
        return UpdatesCollector.get_collector(prometheus_registry)

    def test_init(self, collector: UpdatesCollector) -> None:
        assert isinstance(collector, UpdatesCollector)

    def test_update(self, collector: UpdatesCollector) -> None:
        collector.update(MagicMock())

    def test_update_executed(self, collector: UpdatesCollector) -> None:
        collector.update_executed(MagicMock(), 1, BaseException())

    def test_collect(self, collector: UpdatesCollector) -> None:
        for metric in collector.collect():
            assert isinstance(metric, Metric)

    def test_metric_names_are_distinct(self, collector: UpdatesCollector) -> None:
        metric_names = {metric.name for metric in collector.collect()}
        assert 'aiogram_updates_received' in metric_names
        assert 'aiogram_updates_processed' in metric_names


class TestGetUnknownAttr(object):
    @pytest.mark.parametrize(
        ('obj', 'attrs', 'expected'),
        [
            (None, 'bot.id', 'unknown'),
            (SimpleNamespace(bot=SimpleNamespace(id=123)), 'bot.id', 123),
            (SimpleNamespace(bot=None), 'bot.id', 'unknown'),
            (SimpleNamespace(bot=SimpleNamespace()), 'bot.id', 'unknown'),
            (SimpleNamespace(bot=SimpleNamespace(id=123)), '', 'unknown'),
            (SimpleNamespace(bot=SimpleNamespace(id=123)), '.', 'unknown'),
            (SimpleNamespace(bot=SimpleNamespace(id=123)), 'bot..id', 123),
        ],
    )
    def test_table_driven(self, obj: object, attrs: str, expected: object) -> None:
        assert get_unknown_attr(obj, attrs) == expected


class TestSafeCollector(object):
    def test_get_collector_cache_isolated_per_class(self, prometheus_registry: CollectorRegistry) -> None:
        class CollectorA(SafeCollector):
            def collect(self):
                return iter(())

        class CollectorB(SafeCollector):
            def collect(self):
                return iter(())

        collector_a = CollectorA.get_collector(prometheus_registry, 'ns')
        collector_b = CollectorB.get_collector(prometheus_registry, 'ns')

        assert collector_a is not collector_b
