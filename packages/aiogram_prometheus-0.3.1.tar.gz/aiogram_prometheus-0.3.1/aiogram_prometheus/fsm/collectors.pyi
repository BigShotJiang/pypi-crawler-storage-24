from _typeshed import Incomplete
from aiogram.fsm.storage.base import BaseStorage as BaseStorage, StorageKey as StorageKey
from aiogram_prometheus.base_collector import SafeCollector as SafeCollector
from collections.abc import Iterable
from prometheus_client import CollectorRegistry as CollectorRegistry
from prometheus_client.metrics_core import Metric as Metric
from typing import Any

logger: Incomplete

class FsmCollector(SafeCollector):
    DEFAULT_NAMESPACE: str
    uniq_sets: dict[str, dict[str, set[Any]]]
    storages: set[BaseStorage]
    m_storage: Incomplete
    m_storage_actions: Incomplete
    m_storage_actions_time: Incomplete
    m_bots: Incomplete
    m_chats: Incomplete
    m_threads: Incomplete
    m_destinies: Incomplete
    m_users: Incomplete
    m_business_connection: Incomplete
    def __init__(self, registry: CollectorRegistry, namespace: str) -> None: ...
    def action(self, storage: BaseStorage, action: str, key: StorageKey | None, executing_time: float, ex: BaseException | None = None): ...
    def collect(self) -> Iterable[Metric]: ...
