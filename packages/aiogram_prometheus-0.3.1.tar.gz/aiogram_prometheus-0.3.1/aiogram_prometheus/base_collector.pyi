from prometheus_client import CollectorRegistry as CollectorRegistry
from prometheus_client.registry import Collector
from typing import Any, Self

class SafeCollector(Collector):
    DEFAULT_NAMESPACE: str
    registry: CollectorRegistry
    namespace: str
    COLLECTORS_STORAGE: dict[tuple[type[Self], int, str], Self]
    def __init__(self, registry: CollectorRegistry, namespace: str) -> None: ...
    @classmethod
    def get_collector(cls, registry: CollectorRegistry | None = None, namespace: str | None = None, *args: Any, **kwargs: Any) -> Self: ...
