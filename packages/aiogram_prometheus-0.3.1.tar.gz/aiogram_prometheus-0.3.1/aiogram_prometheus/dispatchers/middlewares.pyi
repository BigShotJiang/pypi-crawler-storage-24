import aiogram
from _typeshed import Incomplete
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from aiogram_prometheus.dispatchers.collectors import UpdatesCollector
from collections.abc import Awaitable, Callable
from inspect import Traceback
from prometheus_client import CollectorRegistry
from typing import Any

__all__ = ['PrometheusUpdatesMiddleware']

class PrometheusUpdatesMiddleware(BaseMiddleware):
    collector: UpdatesCollector
    def __init__(self, registry: CollectorRegistry | None = None, namespace: str | None = None) -> None: ...
    async def __call__(self, handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]], event: TelegramObject, data: dict[str, Any]) -> Any: ...

class UpdateMiddlewareManager:
    started_at: float
    collector: Incomplete
    update: Incomplete
    def __init__(self, collector: UpdatesCollector, update: aiogram.types.Update) -> None: ...
    async def __aenter__(self): ...
    async def __aexit__(self, exc_type: type[BaseException] | None = None, exc_value: BaseException | None = None, traceback: Traceback | None = None): ...
