from __future__ import annotations

from pathlib import Path

import pytest

from typing import Sequence

from tenzir_ship import Changelog
from tenzir_ship.config import Config, save_config
from tenzir_ship import cli as cli_module
from tenzir_ship.entries import read_entry


def _bootstrap_project(tmp_path: Path) -> Path:
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    save_config(Config(id="project", name="Project"), project_dir / "config.yaml")
    return project_dir


def test_python_api_add_entry_creates_file(tmp_path: Path) -> None:
    project_dir = _bootstrap_project(tmp_path)
    client = Changelog(root=project_dir)

    path = client.add(
        title="API entry",
        entry_type="feature",
        components=["core"],
        authors=["codex"],
        prs=["42"],
        description="Body",
    )

    assert path.exists()
    assert path.parent == project_dir / "unreleased"
    contents = path.read_text(encoding="utf-8")
    assert "API entry" in contents
    assert "feature" in contents


def test_python_api_show_delegates(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    project_dir = _bootstrap_project(tmp_path)
    # populate data needed for context
    client = Changelog(root=project_dir)

    captured: dict[str, object] = {}

    def fake_run_show_entries(
        ctx: cli_module.CLIContext,
        *,
        identifiers: Sequence[str] | None,
        view: str,
        project_filter: Sequence[str] | None,
        component_filter: Sequence[str] | None,
        banner: bool,
        compact: bool | None,
        include_emoji: bool,
        explicit_links: bool = False,
        release_mode: bool = False,
        select_all: bool = False,
        released_only: bool = False,
    ) -> None:
        captured["ctx"] = ctx
        captured["identifiers"] = identifiers
        captured["view"] = view
        captured["project_filter"] = project_filter
        captured["component_filter"] = component_filter
        captured["banner"] = banner
        captured["compact"] = compact
        captured["include_emoji"] = include_emoji
        captured["explicit_links"] = explicit_links
        captured["release_mode"] = release_mode
        captured["select_all"] = select_all
        captured["released_only"] = released_only

    monkeypatch.setattr("tenzir_ship.api.run_show_entries", fake_run_show_entries)

    client.show(
        identifiers=["latest"],
        view="table",
        project_filter=["project"],
        component_filter=["core"],
        banner=True,
        include_emoji=False,
    )

    assert captured["ctx"] is client.context
    assert captured["identifiers"] == ["latest"]
    assert captured["view"] == "table"
    assert captured["project_filter"] == ["project"]
    assert captured["component_filter"] == ["core"]
    assert captured["banner"] is True
    assert captured["compact"] is None
    assert captured["include_emoji"] is False


def test_python_api_add_handles_missing_authors(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    project_dir = _bootstrap_project(tmp_path)
    monkeypatch.setattr("tenzir_ship.cli._add.detect_github_login", lambda log_success=False: None)
    client = Changelog(root=project_dir)

    path = client.add(
        title="No author entry",
        entry_type="feature",
        description="Body",
        authors=None,
    )

    entry = read_entry(path)
    assert entry.metadata.get("authors") is None


def test_python_api_add_defaults_entry_type(tmp_path: Path) -> None:
    project_dir = _bootstrap_project(tmp_path)
    client = Changelog(root=project_dir)

    path = client.add(
        title="Default type entry",
        description="Body",
    )

    entry = read_entry(path)
    assert entry.metadata.get("type") == "feature"


def test_python_api_release_version_defaults_to_tag(tmp_path: Path) -> None:
    project_dir = _bootstrap_project(tmp_path)
    client = Changelog(root=project_dir)

    client.add(
        title="Release me",
        entry_type="feature",
        authors=["codex"],
        description="Body",
    )
    client.release_create(version="v1.2.3", assume_yes=True)

    assert client.release_version() == "v1.2.3"
    assert client.release_version(bare=True) == "1.2.3"


def test_python_api_release_version_ignores_release_candidates(tmp_path: Path) -> None:
    project_dir = _bootstrap_project(tmp_path)
    client = Changelog(root=project_dir)

    client.add(
        title="Stable release",
        entry_type="feature",
        authors=["codex"],
        description="Body",
    )
    client.release_create(version="v1.2.3", assume_yes=True)

    client.add(
        title="Preview release",
        entry_type="feature",
        authors=["codex"],
        description="Body",
    )
    client.release_create(version="v1.2.4", release_candidate=True, assume_yes=True)

    assert client.release_version() == "v1.2.3"


def test_python_api_release_create_supports_implicit_release_candidates(tmp_path: Path) -> None:
    project_dir = _bootstrap_project(tmp_path)
    client = Changelog(root=project_dir)

    client.add(
        title="Preview release",
        entry_type="feature",
        authors=["codex"],
        description="Body",
    )
    client.release_create(release_candidate=True, assume_yes=True)
    client.release_create(release_candidate=True, assume_yes=True)

    assert (project_dir / "releases" / "v0.1.0-rc.1").exists()
    assert (project_dir / "releases" / "v0.1.0-rc.2").exists()
