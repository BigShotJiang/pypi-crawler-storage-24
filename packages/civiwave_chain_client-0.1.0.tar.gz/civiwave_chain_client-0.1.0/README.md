# civiwave-chain-client (Python)

Python SDK for Civiwave blockchain — typed queries and extrinsic builders for all pallets.

Equivalent to [`@civiwave/chain-client`](https://www.npmjs.com/package/@civiwave/chain-client) (npm).

## Install

```bash
pip install civiwave-chain-client
```

## Usage

```python
from civiwave_chain_client import CiviwaveClient

client = CiviwaveClient(endpoint="ws://127.0.0.1:9944")

# Query a DID
did_info = client.get_did("5GrwvaEF5zXb26Fz9rcQpDWS57CtERHpNehXCPcNoHGKutQY")

# Submit a step event claim
client.submit_step_event_claim(
    keypair=keypair,
    hub_netuid=1,
    goal_hash="0xabc...",
    claim_hash="0xdef...",
    claimant_did="did:civiwave:5Grw...",
    subject_did="did:civiwave:5FHn...",
    initiative_category=0,
)

# Add stake
client.add_stake(keypair, hotkey="5FHn...", netuid=1, amount=1_000_000_000)
```

## API

See the full API reference in [SDK docs](https://github.com/civiwave/civiwave/blob/main/docs/user-guide/developer/sdk.md).

## Development

```bash
pip install -e ".[dev]"
pytest
ruff check .
mypy civiwave_chain_client/
```

## License

MIT
