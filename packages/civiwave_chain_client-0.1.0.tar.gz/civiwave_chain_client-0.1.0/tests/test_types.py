"""Tests for type dataclasses."""

from civiwave_chain_client.types import (
    DIDInfo,
    EntityStakeInfo,
    ClaimInfo,
    HubInfo,
    IdentityHubSummary,
)


class TestTypes:
    def test_did_info(self):
        d = DIDInfo(did_hash=b"\x01" * 32, public_key=b"\x02" * 32, consent_root=b"\x00" * 32, created_at=100)
        assert len(d.did_hash) == 32
        assert d.created_at == 100

    def test_entity_stake_info(self):
        e = EntityStakeInfo(amount=1000, netuid=1, tier=2, registered_at=50)
        assert e.tier == 2

    def test_claim_info(self):
        c = ClaimInfo(
            claim_hash="0x01",
            claimant_did=b"\x01",
            subject_did=b"\x02",
            goal_hash="0x03",
            initiative_category=1,
            points=100,
            status="Pending",
        )
        assert c.status == "Pending"

    def test_hub_info_defaults(self):
        h = HubInfo(netuid=1)
        assert h.name == ""
        assert h.raw == {}

    def test_identity_hub_summary(self):
        s = IdentityHubSummary(did_count=42, reserved_alpha_ratio=4000)
        assert s.did_count == 42
        assert s.reserved_alpha_ratio == 4000
