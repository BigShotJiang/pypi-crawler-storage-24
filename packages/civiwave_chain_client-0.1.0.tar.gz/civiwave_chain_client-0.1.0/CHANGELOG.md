# Changelog

All notable changes to `civiwave-chain-client` (Python) will be documented in this file.

Follows [Semantic Versioning](https://semver.org/). Pre-1.0 releases use `0.MINOR.PATCH`.

---

## [0.1.0] — 2026-03-16

### Added
- `CiviwaveClient` — typed Substrate RPC client wrapping `substrate-interface`
- Identity Hub: `get_did`, `get_did_count`, `get_entity_stake`, `register_did`, `update_consent_root`, `entity_stake`, `entity_unstake`
- Outcome Settlement: `get_outcome_pool`, `get_did_outcome_earnings`, `submit_step_event_claim`, `confirm_step_event_claim`, `propose_settlement`, `vote_settlement`, `report_outcome_trust`
- Staking: `add_stake`, `remove_stake`
- CiviwaveModule: `register_network`, `burned_register`, `set_weights`, `endorse_miner`, `revoke_endorsement`
- Coverage Devices: `register_device`, `verify_device`, `report_device_activity`
- Low-level: `query()`, `compose_and_send()` for arbitrary pallet access
- Custom RPC method definitions for all 9 Civiwave RPC namespaces
- Type dataclasses: `DIDInfo`, `EntityStakeInfo`, `DeviceInfo`, `ClaimInfo`, `HubInfo`, `NeuronInfo`, `StakeInfo`, `SettlementInfo`, `IdentityHubSummary`
