"""Shared types for the Civiwave SDK."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class DIDInfo:
    """On-chain DID registration info."""

    did_hash: bytes
    public_key: bytes
    consent_root: bytes
    created_at: int


@dataclass
class EntityStakeInfo:
    """Entity stake info from the Identity Hub."""

    amount: int
    netuid: int
    tier: int
    registered_at: int


@dataclass
class DeviceInfo:
    """Coverage device info."""

    device_uid: int
    owner: str
    hub_netuid: int
    device_id: str
    device_type: str
    location_hash: str
    is_public: bool
    is_verified: bool
    last_activity: int


@dataclass
class ClaimInfo:
    """Step event claim info."""

    claim_hash: str
    claimant_did: bytes
    subject_did: bytes
    goal_hash: str
    initiative_category: int
    points: int
    status: str  # "Pending", "Confirmed", "Settled"


@dataclass
class HubInfo:
    """Hub (subnet) information."""

    netuid: int
    name: str = ""
    tempo: int = 0
    emission: int = 0
    max_n: int = 0
    raw: dict = field(default_factory=dict)


@dataclass
class NeuronInfo:
    """Neuron information within a hub."""

    uid: int
    hotkey: str
    coldkey: str
    stake: int = 0
    trust: float = 0.0
    consensus: float = 0.0
    incentive: float = 0.0
    emission: int = 0
    raw: dict = field(default_factory=dict)


@dataclass
class StakeInfo:
    """Stake position info."""

    hotkey: str
    coldkey: str
    netuid: int
    stake: int
    raw: dict = field(default_factory=dict)


@dataclass
class SettlementInfo:
    """Settlement metadata for a hub."""

    netuid: int
    outcome_pool: int
    last_settlement_block: int
    settlement_count: int
    raw: dict = field(default_factory=dict)


@dataclass
class IdentityHubSummary:
    """Summary of the Identity Hub state."""

    did_count: int
    reserved_alpha_ratio: int


@dataclass
class OutcomeTrustScore:
    """Trust score for a neuron."""

    netuid: int
    uid: int
    score: int
    raw: dict = field(default_factory=dict)
