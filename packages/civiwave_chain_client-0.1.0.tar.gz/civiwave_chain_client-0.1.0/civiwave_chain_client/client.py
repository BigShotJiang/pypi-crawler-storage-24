"""
CiviwaveClient — typed Substrate RPC client for all Civiwave pallets.

Wraps substrate-interface with Civiwave-specific custom RPC methods,
extrinsic builders, and SCALE decoding for all 35 pallets.

Equivalent to @civiwave/chain-client CiviwaveClient class.
"""

from __future__ import annotations

from typing import Any, Optional

from substrateinterface import Keypair, SubstrateInterface

from civiwave_chain_client.types import (
    DIDInfo,
    EntityStakeInfo,
)


class CiviwaveClient:
    """Typed client for Civiwave chain queries and extrinsic submission."""

    def __init__(self, endpoint: str = "ws://127.0.0.1:9944") -> None:
        self._endpoint = endpoint
        self._substrate: Optional[SubstrateInterface] = None

    @property
    def endpoint(self) -> str:
        return self._endpoint

    def connect(self) -> SubstrateInterface:
        if self._substrate is None:
            self._substrate = SubstrateInterface(url=self._endpoint)
        return self._substrate

    def disconnect(self) -> None:
        if self._substrate is not None:
            self._substrate.close()
            self._substrate = None

    @property
    def substrate(self) -> SubstrateInterface:
        return self.connect()

    # ──────────────────────────────────────────────
    #  Identity Hub queries
    # ──────────────────────────────────────────────

    def get_did(self, account: str) -> Optional[DIDInfo]:
        """Query DID info for an SS58 account address.

        CLI equivalent: ax stakeholder show <name>
        """
        result = self.substrate.query(
            module="IdentityHub",
            storage_function="DIDRegistry",
            params=[account],
        )
        if result is None or result.value is None:
            return None
        v = result.value
        return DIDInfo(
            did_hash=bytes(v.get("did_hash", [])),
            public_key=bytes(v.get("public_key", [])),
            consent_root=bytes(v.get("consent_root", [])),
            created_at=v.get("created_at", 0),
        )

    def get_did_count(self) -> int:
        """Query total number of registered DIDs.

        CLI equivalent: ax chain info
        """
        result = self.substrate.query(
            module="IdentityHub",
            storage_function="DIDCount",
        )
        return int(result.value) if result and result.value is not None else 0

    def get_entity_stake(self, account: str) -> Optional[EntityStakeInfo]:
        """Query entity stake info for an account."""
        result = self.substrate.query(
            module="IdentityHub",
            storage_function="EntityStakes",
            params=[account],
        )
        if result is None or result.value is None:
            return None
        v = result.value
        return EntityStakeInfo(
            amount=v.get("amount", 0),
            netuid=v.get("netuid", 0),
            tier=v.get("tier", 0),
            registered_at=v.get("registered_at", 0),
        )

    def get_hub_parent(self, child_netuid: int) -> Optional[int]:
        """Query parent hub for a child hub."""
        result = self.substrate.query(
            module="IdentityHub",
            storage_function="HubParent",
            params=[child_netuid],
        )
        return int(result.value) if result and result.value is not None else None

    def get_reserved_alpha_ratio(self) -> int:
        """Query the reserved alpha ratio for DID holders."""
        result = self.substrate.query(
            module="IdentityHub",
            storage_function="ReservedAlphaRatio",
        )
        return int(result.value) if result and result.value is not None else 0

    # ──────────────────────────────────────────────
    #  Identity Hub extrinsics
    # ──────────────────────────────────────────────

    def register_did(
        self,
        keypair: Keypair,
        did_hash: str,
        public_key: str,
        proof: str,
    ) -> str:
        """Register a sovereign DID on-chain.

        CLI equivalent: ax identity register-did

        Args:
            keypair: Signing keypair (coldkey)
            did_hash: Blake2b-256 hash of the DID (hex)
            public_key: Ed25519 public key (hex)
            proof: Proof-of-ownership signature (hex)

        Returns:
            Extrinsic hash (hex)
        """
        call = self.substrate.compose_call(
            call_module="IdentityHub",
            call_function="register_did",
            call_params={
                "did_hash": did_hash,
                "public_key": public_key,
                "proof": proof,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def update_consent_root(self, keypair: Keypair, new_root: str) -> str:
        """Update the consent Merkle root for the caller's DID.

        CLI equivalent: ax stakeholder consent <name> (partial)
        """
        call = self.substrate.compose_call(
            call_module="IdentityHub",
            call_function="update_consent_root",
            call_params={"new_root": new_root},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def entity_stake(self, keypair: Keypair, hub_netuid: int, amount: int) -> str:
        """Stake as an entity into the Identity Hub.

        CLI equivalent: ax stakeholder join-hub <name>
        """
        call = self.substrate.compose_call(
            call_module="IdentityHub",
            call_function="entity_stake",
            call_params={"hub_netuid": hub_netuid, "amount": amount},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def entity_unstake(self, keypair: Keypair) -> str:
        """Unstake entity from the Identity Hub (subject to cooldown)."""
        call = self.substrate.compose_call(
            call_module="IdentityHub",
            call_function="entity_unstake",
            call_params={},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    # ──────────────────────────────────────────────
    #  Outcome Settlement queries
    # ──────────────────────────────────────────────

    def get_outcome_pool(self, netuid: int) -> int:
        """Query the outcome pool balance for a hub.

        CLI equivalent: ax chain info
        """
        result = self.substrate.query(
            module="OutcomeSettlement",
            storage_function="OutcomePool",
            params=[netuid],
        )
        return int(result.value) if result and result.value is not None else 0

    def get_did_outcome_earnings(self, did_hash: str) -> int:
        """Query cumulative outcome earnings for a DID.

        CLI equivalent: ax stakeholder earnings <name>
        """
        result = self.substrate.query(
            module="OutcomeSettlement",
            storage_function="DIDOutcomeEarnings",
            params=[did_hash],
        )
        return int(result.value) if result and result.value is not None else 0

    # ──────────────────────────────────────────────
    #  Outcome Settlement extrinsics
    # ──────────────────────────────────────────────

    def submit_step_event_claim(
        self,
        keypair: Keypair,
        hub_netuid: int,
        goal_hash: str,
        claim_hash: str,
        claimant_did: bytes,
        subject_did: bytes,
        initiative_category: int,
    ) -> str:
        """Submit a step event claim for a registered goal.

        CLI equivalent: ax chain submit-claim (planned)

        Stores the claim with Pending status. A validator must call
        confirm_step_event_claim to advance to Confirmed.
        """
        call = self.substrate.compose_call(
            call_module="OutcomeSettlement",
            call_function="submit_step_event_claim",
            call_params={
                "hub_netuid": hub_netuid,
                "goal_hash": goal_hash,
                "claim_hash": claim_hash,
                "claimant_did": list(claimant_did),
                "subject_did": list(subject_did),
                "initiative_category": initiative_category,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def confirm_step_event_claim(
        self,
        keypair: Keypair,
        hub_netuid: int,
        claim_hash: str,
    ) -> str:
        """Confirm a pending step event claim (validator only).

        CLI equivalent: ax chain confirm-claim <netuid> <hash>
        """
        call = self.substrate.compose_call(
            call_module="OutcomeSettlement",
            call_function="confirm_step_event_claim",
            call_params={
                "hub_netuid": hub_netuid,
                "claim_hash": claim_hash,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def propose_settlement(
        self,
        keypair: Keypair,
        hub_netuid: int,
        goal_hash: str,
        contribution_root: str,
        workflow_commit: str,
        claims: list[tuple[str, int]],
    ) -> str:
        """Propose a settlement for validator quorum approval.

        CLI equivalent: ax chain propose-settlement (planned)
        """
        call = self.substrate.compose_call(
            call_module="OutcomeSettlement",
            call_function="propose_settlement",
            call_params={
                "hub_netuid": hub_netuid,
                "goal_hash": goal_hash,
                "contribution_root": contribution_root,
                "workflow_commit": workflow_commit,
                "claims": claims,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def vote_settlement(
        self,
        keypair: Keypair,
        hub_netuid: int,
        outcome_id: int,
        approve: bool,
    ) -> str:
        """Vote on a pending settlement (validator only).

        CLI equivalent: ax chain vote-settlement (planned)
        """
        call = self.substrate.compose_call(
            call_module="OutcomeSettlement",
            call_function="vote_settlement",
            call_params={
                "hub_netuid": hub_netuid,
                "outcome_id": outcome_id,
                "approve": approve,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def report_outcome_trust(
        self,
        keypair: Keypair,
        netuid: int,
        uid: int,
        is_positive: bool,
    ) -> str:
        """Report a trust outcome for a neuron (validator only).

        CLI equivalent: ax chain report-trust (planned)
        """
        call = self.substrate.compose_call(
            call_module="OutcomeSettlement",
            call_function="report_outcome_trust",
            call_params={"netuid": netuid, "uid": uid, "is_positive": is_positive},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    # ──────────────────────────────────────────────
    #  Staking
    # ──────────────────────────────────────────────

    def add_stake(
        self, keypair: Keypair, hotkey: str, netuid: int, amount: int
    ) -> str:
        """Add stake to a hotkey on a hub.

        CLI equivalent: ax staking add-stake
        """
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="add_stake",
            call_params={"hotkey": hotkey, "netuid": netuid, "amount_staked": amount},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def remove_stake(
        self, keypair: Keypair, hotkey: str, netuid: int, amount: int
    ) -> str:
        """Remove stake from a hotkey on a hub.

        CLI equivalent: ax staking remove-stake
        """
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="remove_stake",
            call_params={
                "hotkey": hotkey,
                "netuid": netuid,
                "amount_unstaked": amount,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    # ──────────────────────────────────────────────
    #  CiviwaveModule extrinsics
    # ──────────────────────────────────────────────

    def register_network(self, keypair: Keypair, hotkey: str) -> str:
        """Register a new hub (network)."""
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="register_network",
            call_params={"hotkey": hotkey},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def burned_register(self, keypair: Keypair, netuid: int, hotkey: str) -> str:
        """Register a neuron by burning CIVL."""
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="burned_register",
            call_params={"netuid": netuid, "hotkey": hotkey},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def set_weights(
        self,
        keypair: Keypair,
        netuid: int,
        uids: list[int],
        values: list[int],
        version_key: int,
    ) -> str:
        """Set validator weights on miners."""
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="set_weights",
            call_params={
                "netuid": netuid,
                "dests": uids,
                "weights": values,
                "version_key": version_key,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def endorse_miner(self, keypair: Keypair, netuid: int, miner_hotkey: str) -> str:
        """Endorse a miner to build their trust score.

        CLI equivalent: ax chain endorse-miner (planned)
        """
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="endorse_miner",
            call_params={"netuid": netuid, "miner_hotkey": miner_hotkey},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def revoke_endorsement(
        self, keypair: Keypair, netuid: int, miner_hotkey: str
    ) -> str:
        """Revoke endorsement from a miner."""
        call = self.substrate.compose_call(
            call_module="CiviwaveModule",
            call_function="revoke_endorsement",
            call_params={"netuid": netuid, "miner_hotkey": miner_hotkey},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    # ──────────────────────────────────────────────
    #  Coverage Devices
    # ──────────────────────────────────────────────

    def register_device(
        self,
        keypair: Keypair,
        hub_netuid: int,
        device_id: str,
        device_type: str,
        location_hash: str,
        visibility: str,
    ) -> str:
        """Register a coverage device.

        CLI equivalent: ax device register
        """
        call = self.substrate.compose_call(
            call_module="CoverageDevices",
            call_function="register_device",
            call_params={
                "hub_netuid": hub_netuid,
                "device_id": device_id,
                "device_type": device_type,
                "location_hash": location_hash,
                "visibility": visibility,
            },
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def verify_device(self, keypair: Keypair, device_uid: int) -> str:
        """Verify a device (root only).

        CLI equivalent: ax device verify
        """
        call = self.substrate.compose_call(
            call_module="CoverageDevices",
            call_function="verify_device",
            call_params={"device_uid": device_uid},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    def report_device_activity(self, keypair: Keypair, device_uid: int) -> str:
        """Report device activity heartbeat.

        CLI equivalent: ax device report-activity
        """
        call = self.substrate.compose_call(
            call_module="CoverageDevices",
            call_function="report_device_activity",
            call_params={"device_uid": device_uid},
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(extrinsic, wait_for_inclusion=True)
        return receipt.extrinsic_hash

    # ──────────────────────────────────────────────
    #  Low-level access
    # ──────────────────────────────────────────────

    def query(self, module: str, function: str, params: Optional[list] = None) -> Any:
        """Execute a raw storage query."""
        return self.substrate.query(
            module=module,
            storage_function=function,
            params=params or [],
        )

    def compose_and_send(
        self,
        keypair: Keypair,
        module: str,
        function: str,
        params: dict,
        wait_for_inclusion: bool = True,
    ) -> str:
        """Compose, sign, and submit an arbitrary extrinsic."""
        call = self.substrate.compose_call(
            call_module=module,
            call_function=function,
            call_params=params,
        )
        extrinsic = self.substrate.create_signed_extrinsic(call=call, keypair=keypair)
        receipt = self.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=wait_for_inclusion
        )
        return receipt.extrinsic_hash
