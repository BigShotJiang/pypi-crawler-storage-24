"""
Custom RPC method definitions for Civiwave pallets.

These map directly to the chain's custom RPC endpoints. The definitions
are passed to SubstrateInterface for custom method registration.

Equivalent to @civiwave/chain-client rpc-definitions.ts.
"""

CUSTOM_RPC_METHODS: dict[str, dict] = {
    # --- Delegate Info ---
    "delegateInfo_getDelegates": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "Bytes",
    },
    "delegateInfo_getDelegate": {
        "params": [
            {"name": "delegate_account_vec", "type": "Vec<u8>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "delegateInfo_getDelegated": {
        "params": [
            {"name": "delegatee_account_vec", "type": "Vec<u8>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    # --- Neuron Info ---
    "neuronInfo_getNeurons": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "neuronInfo_getNeuron": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "uid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "neuronInfo_getNeuronsLite": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "neuronInfo_getNeuronLite": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "uid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    # --- Hub Info ---
    "hubInfo_getHubInfo": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "hubInfo_getHubsInfo": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "Bytes",
    },
    "hubInfo_getHubHyperparams": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "hubInfo_getDynamicInfo": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "hubInfo_getAllDynamicInfo": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "Bytes",
    },
    "hubInfo_getMetagraph": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "hubInfo_getAllMetagraphs": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "Bytes",
    },
    "hubInfo_getHubState": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "hubInfo_getLockCost": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "u64",
    },
    "hubInfo_getHubToPrune": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "Option<u16>",
    },
    # --- Stake Info ---
    "stakeInfo_getStakeInfoForColdkey": {
        "params": [
            {"name": "coldkey_account_vec", "type": "Vec<u8>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "stakeInfo_getStakeInfoForColdkeys": {
        "params": [
            {"name": "coldkey_account_vecs", "type": "Vec<Vec<u8>>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    # --- Swap ---
    "swap_currentAlphaPrice": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "u64",
    },
    "swap_simSwapTaoForAlpha": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "tao", "type": "u64"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "swap_simSwapAlphaForTao": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "alpha", "type": "u64"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    # --- Outcome Settlement ---
    "outcomeSettlement_getOutcomePool": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "u64",
    },
    "outcomeSettlement_getDIDOutcomeEarnings": {
        "params": [
            {"name": "did_hash", "type": "H256"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "u64",
    },
    "outcomeSettlement_getSettlementInfo": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "outcomeSettlement_getTrustScore": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "uid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    # --- Coverage Devices ---
    "coverageDevices_getDevice": {
        "params": [
            {"name": "device_uid", "type": "u64"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "coverageDevices_getNeuronDevices": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "uid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "coverageDevices_getPublicDeviceIndex": {
        "params": [
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "coverageDevices_getDeviceHubAccess": {
        "params": [
            {"name": "device_uid", "type": "u64"},
            {"name": "netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "bool",
    },
    # --- Contribution Tracker ---
    "contributionTracker_getContributionScore": {
        "params": [
            {"name": "account_vec", "type": "Vec<u8>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "u64",
    },
    "contributionTracker_getTotalContributions": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "u64",
    },
    # --- Identity Hub ---
    "identityHub_getDid": {
        "params": [
            {"name": "account_vec", "type": "Vec<u8>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "identityHub_getDidCount": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "u64",
    },
    "identityHub_getEntityStake": {
        "params": [
            {"name": "account_vec", "type": "Vec<u8>"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Bytes",
    },
    "identityHub_getHubParent": {
        "params": [
            {"name": "child_netuid", "type": "u16"},
            {"name": "at", "type": "BlockHash", "optional": True},
        ],
        "type": "Option<u16>",
    },
    "identityHub_getReservedAlphaRatio": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "u16",
    },
    "identityHub_getSummary": {
        "params": [{"name": "at", "type": "BlockHash", "optional": True}],
        "type": "Bytes",
    },
}
