"""
civiwave-chain-client — Python SDK for Civiwave blockchain queries and extrinsic submission.

Equivalent to @civiwave/chain-client (npm).
"""

from civiwave_chain_client.client import CiviwaveClient
from civiwave_chain_client.types import (
    DIDInfo,
    EntityStakeInfo,
    DeviceInfo,
    ClaimInfo,
    HubInfo,
    NeuronInfo,
    StakeInfo,
    SettlementInfo,
    IdentityHubSummary,
)

__version__ = "0.1.0"

__all__ = [
    "CiviwaveClient",
    "DIDInfo",
    "EntityStakeInfo",
    "DeviceInfo",
    "ClaimInfo",
    "HubInfo",
    "NeuronInfo",
    "StakeInfo",
    "SettlementInfo",
    "IdentityHubSummary",
]
