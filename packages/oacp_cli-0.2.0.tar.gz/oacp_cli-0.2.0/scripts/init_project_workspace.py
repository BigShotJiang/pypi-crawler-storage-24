#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Kiloloop
# SPDX-License-Identifier: Apache-2.0
"""Initialize an OACP project workspace."""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import sys
from typing import Dict, List, Optional, Sequence, Tuple

from _oacp_constants import AGENT_RE, _write_if_missing

DEFAULT_AGENTS = ("claude", "codex", "gemini")


def _validate_agent_name(name: str) -> None:
    if not AGENT_RE.fullmatch(name):
        raise ValueError(
            f"Invalid agent name '{name}': must start with alphanumeric, "
            f"contain only [A-Za-z0-9._-], and be 1-64 chars"
        )


DEFAULT_PROJECT_FACTS = """# Project Facts

## Agent Roles
- Implementer (<domain>): <agent name>
- QA/Reviewer: <agent name>
- Deploy/Ops: <agent name>

## Protocol
- Shared handoff protocol version: v0.2.0
"""

KNOWN_DEBT_TEMPLATE = """# Known Debt

Use this file to track verified, unresolved project debt that future sessions
should not rediscover from scratch.

| Item | Severity | Date Found | Source | Status |
| --- | --- | --- | --- | --- |
| _None yet._ |  |  |  |  |
"""

STATIC_DIRECTORIES = (
    "packets/review",
    "packets/findings",
    "packets/test",
    "packets/deploy",
    "checkpoints",
    "merges",
    "memory",
    "memory/archive",
    "artifacts",
    "state",
    "logs",
)

STATIC_GITKEEP_PATHS = (
    "packets/review/.gitkeep",
    "packets/findings/.gitkeep",
    "packets/test/.gitkeep",
    "packets/deploy/.gitkeep",
    "checkpoints/.gitkeep",
    "merges/.gitkeep",
    "artifacts/.gitkeep",
)

AGENT_SUBDIRS = ("inbox", "outbox", "dead_letter")


def _agent_dirs(agents: Sequence[str]) -> List[str]:
    """Return directory paths for the given agents."""
    dirs: List[str] = []
    for agent in agents:
        for sub in AGENT_SUBDIRS:
            dirs.append(f"agents/{agent}/{sub}")
    return dirs


def _agent_gitkeeps(agents: Sequence[str]) -> List[str]:
    """Return .gitkeep paths for the given agents."""
    keeps: List[str] = []
    for agent in agents:
        for sub in AGENT_SUBDIRS:
            keeps.append(f"agents/{agent}/{sub}/.gitkeep")
    return keeps


def _parse_link(value: str) -> Tuple[str, str]:
    if ":" not in value:
        raise argparse.ArgumentTypeError("link must be SRC:DST")
    src, dst = value.split(":", 1)
    if not src or not dst:
        raise argparse.ArgumentTypeError("link must be SRC:DST")
    return src, dst


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create a new project workspace under $OACP_HOME/projects/.",
    )
    parser.add_argument("project_name", help="Project workspace name")
    parser.add_argument(
        "--repo",
        default=None,
        help="Repo root used for artifact symlinks and recorded in workspace.json",
    )
    parser.add_argument(
        "--link",
        action="append",
        type=_parse_link,
        default=[],
        metavar="SRC:DST",
        help="Create artifacts/DST -> REPO/SRC symlink (repeatable; requires --repo)",
    )
    parser.add_argument(
        "--agents",
        default=",".join(DEFAULT_AGENTS),
        help=(
            "Comma-separated list of agents to create "
            f"(default: {','.join(DEFAULT_AGENTS)}). "
            'Pass "" for none.'
        ),
    )
    return parser.parse_args(list(argv))


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _standards_version() -> str:
    candidates = (
        Path(__file__).resolve().parent / "VERSION",
        _repo_root() / "VERSION",
    )
    for path in candidates:
        try:
            return path.read_text(encoding="utf-8").splitlines()[0].strip()
        except (FileNotFoundError, IndexError):
            continue
    return "0.1.0"


def _project_facts_template() -> str:
    # Installed wheels ship the default template but not repo examples.
    candidates = (
        Path(__file__).resolve().parent / "examples" / "project_facts.example.md",
        _repo_root() / "examples" / "project_facts.example.md",
    )
    for path in candidates:
        if path.is_file():
            return path.read_text(encoding="utf-8")
    return DEFAULT_PROJECT_FACTS


def _validate_project_name(name: str) -> None:
    if name.startswith(".") or "/" in name or "\\" in name:
        raise ValueError("project name must not contain path separators or start with '.'")


def initialize_workspace(
    project_name: str,
    *,
    oacp_root: Path,
    repo_dir: Optional[Path] = None,
    artifact_links: Sequence[Tuple[str, str]] = (),
    agents: Sequence[str] = DEFAULT_AGENTS,
) -> Dict[str, object]:
    _validate_project_name(project_name)
    for agent in agents:
        _validate_agent_name(agent)
    project_root = oacp_root / "projects" / project_name

    all_dirs = _agent_dirs(agents) + list(STATIC_DIRECTORIES)
    for relative_dir in all_dirs:
        (project_root / relative_dir).mkdir(parents=True, exist_ok=True)

    all_gitkeeps = _agent_gitkeeps(agents) + list(STATIC_GITKEEP_PATHS)
    for relative_path in all_gitkeeps:
        (project_root / relative_path).touch()

    _write_if_missing(project_root / "memory" / "project_facts.md", _project_facts_template())
    _write_if_missing(
        project_root / "memory" / "decision_log.md",
        f"# Decision Log\n\n## {dt.date.today().isoformat()}\n- Project workspace initialized.\n",
    )
    _write_if_missing(
        project_root / "memory" / "open_threads.md",
        "# Open Threads\n\n- None yet.\n",
    )
    _write_if_missing(project_root / "memory" / "known_debt.md", KNOWN_DEBT_TEMPLATE)

    workspace_path = project_root / "workspace.json"
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    workspace = {
        "project_name": project_name,
        "repo_path": str(repo_dir) if repo_dir else None,
        "created_at": now,
        "updated_at": now,
        "standards_version": _standards_version(),
    }
    workspace_path.write_text(json.dumps(workspace, indent=2) + "\n", encoding="utf-8")

    warnings: List[str] = []
    created_links: List[Tuple[str, str]] = []
    if artifact_links:
        if repo_dir is None:
            raise ValueError("--link requires --repo")
        for src, dst in artifact_links:
            source = repo_dir / src
            destination = project_root / "artifacts" / dst
            if not source.exists():
                warnings.append(f"Skipped artifacts/{dst} — {source} not found")
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.is_symlink() or destination.is_file():
                destination.unlink()
            elif destination.exists():
                raise ValueError(f"artifact destination exists and is not a symlink: {destination}")
            destination.symlink_to(source)
            created_links.append((dst, str(source)))

    return {
        "project_root": project_root,
        "workspace_path": workspace_path,
        "repo_dir": repo_dir,
        "created_links": created_links,
        "warnings": warnings,
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    from _oacp_env import resolve_oacp_home
    oacp_root = resolve_oacp_home()
    repo_dir = Path(args.repo).expanduser().resolve() if args.repo else None

    agents_list: Sequence[str] = (
        [a.strip() for a in args.agents.split(",") if a.strip()]
        if args.agents
        else ()
    )

    try:
        result = initialize_workspace(
            args.project_name,
            oacp_root=oacp_root,
            repo_dir=repo_dir,
            artifact_links=args.link,
            agents=agents_list,
        )
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    if result["created_links"]:
        print(f"Creating artifact symlinks from repo: {repo_dir}")
        for dst, source in result["created_links"]:
            print(f"  + artifacts/{dst} -> {source}")
    for warning in result["warnings"]:
        print(f"  ! {warning}")

    project_root = result["project_root"]
    print(f"Initialized project workspace: {project_root}")
    if repo_dir is not None:
        print("  To link a runtime repo, symlink workspace.json into the repo root:")
        print(f"    ln -sf {project_root / 'workspace.json'} <repo>/.oacp")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
