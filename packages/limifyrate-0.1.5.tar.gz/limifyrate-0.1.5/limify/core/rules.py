from dataclasses import dataclass

@dataclass(frozen=True)
class Rule:
    id: str
    method: str
    path: str
    rate: str
    burst: int = 1
    priority: int = 0
    queue: bool = False

    @staticmethod
    def rules_constructor(user_rules) -> list:
        # convert to Rule objects
        rules = [
            Rule(
                id=r["id"],
                method=r["method"],
                path=r["path"],
                rate=str(r["rate"]),
                burst=int(r.get("burst", 1)),
                priority=int(r.get("priority", 0)),
                queue=r.get("queue", False)
            )
            for r in user_rules
        ]

        # sort by priority descending
        rules.sort(key=lambda r: r.priority, reverse=True)
        return(rules)

