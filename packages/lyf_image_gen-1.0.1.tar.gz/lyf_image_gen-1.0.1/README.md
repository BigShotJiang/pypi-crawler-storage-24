# Image Generator

独立图像生成工具，支持多种 AI 图像生成 API。

## 特点

- ✅ **独立可执行** - 无需安装 Python 或依赖
- ✅ **跨平台** - 支持 Windows/Linux/macOS
- ✅ **多 API** - 支持智谱AI、OpenAI、自定义API
- ✅ **MCP 服务器** - 可集成到 Claude Code/OpenClaw
- ✅ **零依赖** - 仅使用 Python 标准库

## 安装

### 方式一：PyPI 安装（推荐）

```bash
pip install image-gen-mcp
```

安装后可直接使用：
```bash
# 命令行工具
image-gen -k YOUR_KEY -t "一只可爱的橘猫"

# MCP 服务器配置到 ~/.claude/settings.json
image-gen-mcp
```

### 方式二：下载可执行文件

从 [Releases](https://github.com/your-username/image-gen/releases) 下载对应平台的可执行文件。

### 方式三：从源码运行

```bash
git clone https://github.com/your-username/image-gen.git
cd image_gen
python3 img_gen.py -k YOUR_KEY -t "风景"
```

## 快速开始

### 命令行使用

```bash
# 智谱AI（默认）
image-gen -k YOUR_KEY -t "日落风景" -o ~/sunset.png

# OpenAI DALL-E
image-gen -p openai -k YOUR_KEY -m dall-e-3 -t "森林小屋"

# 自定义 API
image-gen -p custom -u https://api.example.com/v1/images -k KEY -t "山水画"
```

### 作为 MCP 服务器使用

1. 编辑 `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "image-gen": {
      "command": "image-gen-mcp",
      "env": {
        "IMAGE_GEN_API_KEY": "your-api-key",
        "IMAGE_GEN_MODEL": "cogview-3-flash"
      }
    }
  }
}
```

2. 重启 Claude Code，然后直接对话：
```
你: 生成一张赛博朋克城市的图片
```

## 命令行参数

| 参数 | 说明 | 必需 |
|------|------|------|
| `--provider, -p` | API 提供商 (zhipu/openai/custom) | 否 |
| `--api-key, -k` | API 密钥 | **是** |
| `--model, -m` | 模型名称 | 否 |
| `--api-url, -u` | 自定义 API 地址 | 否 |
| `--prompt, -t` | 图片描述 | **是** |
| `--size, -s` | 图片尺寸 | 否 |
| `--output, -o` | 输出路径 | 否 |

## 支持的模型

### 智谱AI (zhipu)

| 模型 | 说明 |
|------|------|
| `cogview-3-flash` | 快速生成（推荐） |
| `cogview-3` | 高质量生成 |

API 密钥: https://open.bigmodel.cn/usercenter/apikeys

### OpenAI (openai)

| 模型 | 说明 |
|------|------|
| `dall-e-2` | 标准质量 |
| `dall-e-3` | 高质量 |

API 密钥: https://platform.openai.com/api-keys

## 开发

### 打包可执行文件

```bash
# Linux/macOS
chmod +x build.sh && ./build.sh

# Windows
build.bat
```

### 发布到 PyPI

```bash
chmod +x publish.sh && ./publish.sh
```

## 文件结构

```
image_gen/
├── img_gen.py        # 独立可执行程序源码
├── mcp_server.py     # MCP 服务器
├── build.sh          # Linux/macOS 打包脚本
├── build.bat         # Windows 打包脚本
├── publish.sh        # PyPI 发布脚本
├── pyproject.toml    # 项目配置
├── .github/workflows/ # CI/CD 配置
├── README.md         # 本文档
└── LICENSE           # MIT 许可证
```

## 技术实现

- **仅用标准库** - `urllib`, `json`, `pathlib`, `argparse`
- **PyInstaller 打包** - 单文件可执行
- **MCP 协议** - 与 LLM 集成

## 许可证

[MIT](LICENSE)
