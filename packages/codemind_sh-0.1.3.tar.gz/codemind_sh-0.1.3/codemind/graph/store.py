"""Atomic persistence for the CodeGraph — save to and load from graph.json.

The file format is plain JSON (human-readable, git-diffable).
Writes are atomic: we write to a ``.tmp`` file then ``replace()`` it,
so a crash mid-write never corrupts the existing graph.
"""

from __future__ import annotations

import json
import os
import threading
from pathlib import Path

# Serialise concurrent saves so two watcher threads never race on the same
# .tmp file (e.g. when many files change simultaneously).
_SAVE_LOCK = threading.Lock()

from codemind.core.graph import CodeGraph, GraphEdge, GraphNode

_GRAPH_FILE = "graph.json"
_SOURCE_EXTS = {".java", ".ts", ".tsx", ".py"}


def is_graph_stale(project_root: Path, codemind_dir: Path) -> bool:
    """Return True if any source file is newer than graph.json.

    Compares the mtime of graph.json against every ``.java``, ``.ts``,
    ``.tsx``, and ``.py`` file under *project_root* (excluding
    ``.codemind/`` itself and ``.d.ts`` compiler output).

    Short-circuits on the first newer file found — safe on large repos.
    Returns False when graph.json does not exist yet (missing ≠ stale).
    """
    graph_path = codemind_dir / _GRAPH_FILE
    if not graph_path.exists():
        return False

    graph_mtime = graph_path.stat().st_mtime

    for ext in _SOURCE_EXTS:
        for src in project_root.rglob(f"*{ext}"):
            if src.name.endswith(".d.ts"):
                continue
            if codemind_dir in src.parents or src.parent == codemind_dir:
                continue
            try:
                if src.stat().st_mtime > graph_mtime:
                    return True
            except OSError:
                continue
    return False


class GraphStore:
    """Saves and loads a CodeGraph to/from ``graph.json``.

    Usage::

        store = GraphStore()
        store.save(graph, codemind_dir)          # writes .codemind/graph.json
        graph = store.load(codemind_dir)         # None if file absent / corrupt
    """

    def save(self, graph: CodeGraph, codemind_dir: Path) -> None:
        """Atomically write graph.json inside *codemind_dir*.

        Args:
            graph:       The graph to persist.
            codemind_dir: The ``.codemind/`` directory.
        """
        data = {
            "project": graph.project,
            "scanned_at": graph.scanned_at,
            "languages": graph.languages,
            "frameworks": graph.frameworks,
            "nodes": {
                nid: {
                    "id": n.id,
                    "name": n.name,
                    "type": n.type,
                    "language": n.language,
                    "package": n.package,
                    "file": n.file,
                    "methods": n.methods,
                    "annotations": n.annotations,
                    "interfaces": n.interfaces,
                    "superclass": n.superclass,
                    "line": n.line,
                    **({"metadata": n.metadata} if n.metadata else {}),
                }
                for nid, n in graph.nodes.items()
            },
            "edges": [
                {
                    "source": e.source,
                    "target": e.target,
                    "kind": e.kind,
                    "meta": e.meta,
                }
                for e in graph.edges
            ],
        }
        path = codemind_dir / _GRAPH_FILE
        # Use a per-process unique tmp name to avoid races between concurrent
        # watcher threads (each thread gets its own tmp file).
        tmp = path.parent / f"graph.{os.getpid()}.tmp"
        with _SAVE_LOCK:
            tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp.replace(path)

    def load(self, codemind_dir: Path) -> CodeGraph | None:
        """Load graph.json from *codemind_dir*.

        Returns:
            A CodeGraph or None if the file is absent or cannot be parsed.
        """
        path = codemind_dir / _GRAPH_FILE
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            nodes: dict[str, GraphNode] = {}
            for nid, n in data.get("nodes", {}).items():
                nodes[nid] = GraphNode(
                    id=n["id"],
                    name=n["name"],
                    type=n["type"],
                    language=n["language"],
                    package=n["package"],
                    file=n["file"],
                    methods=n.get("methods", []),
                    annotations=n.get("annotations", []),
                    interfaces=n.get("interfaces", []),
                    superclass=n.get("superclass", ""),
                    line=n.get("line", 0),
                    metadata=n.get("metadata", {}),
                )
            edges = [
                GraphEdge(
                    source=e["source"],
                    target=e["target"],
                    kind=e["kind"],
                    meta=e.get("meta", {}),
                )
                for e in data.get("edges", [])
            ]
            return CodeGraph(
                project=data.get("project", ""),
                scanned_at=data.get("scanned_at", ""),
                languages=data.get("languages", []),
                frameworks=data.get("frameworks", []),
                nodes=nodes,
                edges=edges,
            )
        except (KeyError, TypeError, json.JSONDecodeError):
            return None
