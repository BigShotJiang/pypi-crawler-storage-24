"""Graph query engine — answers precise structural questions about the codebase.

All five MCP tools delegate here.  Every answer is derived entirely from the
graph's nodes and edges — no heuristics, no keyword dictionaries, no scoring.

Public API
----------
get_connections(graph, name)    → what a component injects, calls, extends, and who depends on it
impact_of(graph, name)          → BFS: all components that would be affected by changing X
find_components(graph, query)   → components matching a free-text query
find_for_task(graph, description) → relevant components + detected gaps for a task
get_domain_pattern(graph)       → best existing full-stack domain to use as a template
"""

from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass, field

from codemind.core.graph import (
    EDGE_CALLS,
    EDGE_EXTENDS,
    EDGE_IMPLEMENTS,
    EDGE_IMPORTS,
    EDGE_INJECTS,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
    NODE_SERVICE,
    CodeGraph,
    GraphEdge,
    GraphNode,
)


# ── Result types ──────────────────────────────────────────────────────────────


@dataclass
class ConnectionResult:
    """All direct connections of a component."""
    node: GraphNode
    injects: list[GraphNode]             = field(default_factory=list)  # what it injects
    calls: list[tuple[GraphNode, str]]   = field(default_factory=list)  # (node, method)
    extends: GraphNode | None            = None
    implements: list[GraphNode]          = field(default_factory=list)
    injected_by: list[GraphNode]         = field(default_factory=list)  # who injects it
    called_by: list[GraphNode]           = field(default_factory=list)  # who calls it


@dataclass
class ImpactResult:
    """Result of impact analysis for a component change."""
    node: GraphNode
    direct: list[GraphNode]   = field(default_factory=list)   # distance 1
    indirect: list[GraphNode] = field(default_factory=list)   # distance 2+


@dataclass
class FoundComponent:
    """A component match with its relevance score."""
    node: GraphNode
    score: float
    reason: str


@dataclass
class TaskResult:
    """Components relevant to a task, plus detected gaps."""
    relevant: list[FoundComponent]   = field(default_factory=list)
    gaps: list[str]                  = field(default_factory=list)
    suggested_insertions: list[str]  = field(default_factory=list)


@dataclass
class DomainPattern:
    """A complete existing module that can be used as a template."""
    domain: str
    service: GraphNode | None      = None
    controller: GraphNode | None   = None
    entity: GraphNode | None       = None
    repository: GraphNode | None   = None
    extras: list[GraphNode]        = field(default_factory=list)


# ── Query functions ────────────────────────────────────────────────────────────


def get_connections(graph: CodeGraph, name: str) -> ConnectionResult | None:
    """Return all direct connections of the component named *name*.

    Args:
        graph: The code graph.
        name:  Simple class name or fully-qualified ID.

    Returns:
        A ConnectionResult, or None if the component is not found.
    """
    node = graph.resolve(name)
    if not node:
        return None

    result = ConnectionResult(node=node)

    # Outgoing edges (what this component does)
    for edge in graph.edges_from(node.id):
        target = graph.resolve(edge.target)
        if not target:
            continue
        if edge.kind == EDGE_INJECTS:
            result.injects.append(target)
        elif edge.kind == EDGE_CALLS:
            result.calls.append((target, edge.meta.get("method", "")))
        elif edge.kind == EDGE_EXTENDS:
            result.extends = target
        elif edge.kind == EDGE_IMPLEMENTS:
            result.implements.append(target)

    # Incoming edges (who depends on this component)
    for edge in graph.edges_to(node.id):
        src = graph.resolve(edge.source)
        if not src:
            continue
        if edge.kind == EDGE_INJECTS:
            result.injected_by.append(src)
        elif edge.kind == EDGE_CALLS:
            result.called_by.append(src)

    return result


def impact_of(graph: CodeGraph, name: str) -> ImpactResult | None:
    """BFS upward through the injection graph to find all dependents.

    Answers: "if I change X, what else breaks?"

    Args:
        graph: The code graph.
        name:  Simple class name or fully-qualified ID.

    Returns:
        An ImpactResult sorted by distance, or None if not found.
    """
    node = graph.resolve(name)
    if not node:
        return None

    result = ImpactResult(node=node)
    visited: set[str] = {node.id}
    queue: deque[tuple[str, int]] = deque([(node.id, 0)])

    while queue:
        current_id, depth = queue.popleft()
        for edge in graph.edges_to(current_id):
            if edge.kind not in (EDGE_INJECTS, EDGE_CALLS, EDGE_EXTENDS, EDGE_IMPLEMENTS):
                continue
            src = graph.resolve(edge.source)
            if not src or src.id in visited:
                continue
            visited.add(src.id)
            if depth == 0:
                result.direct.append(src)
            else:
                result.indirect.append(src)
            queue.append((src.id, depth + 1))

    return result


def find_components(graph: CodeGraph, query: str, limit: int = 20) -> list[FoundComponent]:
    """Find components whose name, package, methods, or type match *query*.

    Scoring:
      - 10 pts: query word found in component name
      -  5 pts: component type matches a word in query (e.g. "service")
      -  3 pts: query word found in package
      -  2 pts: query word found in a method name
      -  1 pt:  query word found in an annotation

    Args:
        graph: The code graph.
        query: Free-text search string.
        limit: Maximum number of results.

    Returns:
        Matched components sorted by score (highest first).
    """
    words = _keywords(query)
    if not words:
        return []

    scored: list[FoundComponent] = []
    for node in graph.nodes.values():
        score, reasons = _score_node(node, words)
        if score > 0:
            scored.append(FoundComponent(
                node=node,
                score=score,
                reason="; ".join(reasons),
            ))

    scored.sort(key=lambda x: -x.score)
    return scored[:limit]


def find_for_task(graph: CodeGraph, description: str) -> TaskResult:
    """Analyse the task description and return relevant components + gaps.

    Gaps are identified as:
    - A needed type (e.g. ``NotificationService``) whose interface exists but has
      no implementation connected to the relevant flow.
    - A service that is NOT connected to the flow but clearly should be
      (e.g. EmailService is not connected to ThresholdEvaluator).

    Args:
        graph:       The code graph.
        description: Free-text task description.

    Returns:
        A TaskResult with relevant components and detected gaps.
    """
    result = TaskResult()

    # Find relevant components
    matches = find_components(graph, description, limit=15)
    result.relevant = matches

    if not matches:
        return result

    # Gap analysis: look for disconnected services relevant to the task
    top_nodes = {fc.node.id for fc in matches[:5]}
    words = _keywords(description)

    for fc in matches[:5]:
        conns = get_connections(graph, fc.node.id)
        if not conns:
            continue
        # Check for interfaces with no implementations
        for impl_node in conns.implements:
            implementors = [
                graph.resolve(e.source)
                for e in graph.edges_to(impl_node.id)
                if e.kind == EDGE_IMPLEMENTS
            ]
            real_impls = [n for n in implementors if n and n.id != fc.node.id]
            if not real_impls:
                result.gaps.append(
                    f"`{impl_node.name}` has no implementations connected to `{fc.node.name}`"
                )

    # Suggest connection points for frequently-mentioned but unconnected components
    for fc in matches[5:10]:
        already_connected = any(
            e.target == fc.node.id or e.source == fc.node.id
            for top_id in top_nodes
            for e in graph.edges_from(top_id) + graph.edges_to(top_id)
        )
        if not already_connected and fc.score > 3:
            result.suggested_insertions.append(
                f"`{fc.node.name}` ({fc.node.type}) — found in `{fc.node.package}` "
                f"but not yet connected to the main flow"
            )

    return result


def get_domain_pattern(graph: CodeGraph) -> DomainPattern | None:
    """Find the most complete existing domain (service+controller+entity+repository).

    Preference: business domains over infrastructure/auth domains.
    Used by MCP ``get_pattern`` tool so engineers can copy a proven structure.

    Args:
        graph: The code graph.

    Returns:
        A DomainPattern for the best-matching domain, or None if the graph is
        too sparse to identify a meaningful pattern.
    """
    # Group nodes by their 5th package segment (typical domain key in layered arch)
    from collections import defaultdict
    domain_nodes: dict[str, list[GraphNode]] = defaultdict(list)
    domain_types: dict[str, set[str]] = defaultdict(set)

    for node in graph.nodes.values():
        if node.language != "java":
            continue
        parts = node.package.split(".")
        if len(parts) >= 5:
            domain = parts[4]
        elif len(parts) >= 4:
            domain = parts[3]
        else:
            continue
        domain_nodes[domain].append(node)
        domain_types[domain].add(node.type)

    if not domain_nodes:
        return None

    # Score each domain by completeness, with a tiebreak for business packages
    best_domain = ""
    best_score = -1
    best_is_business = False

    for domain, types in domain_types.items():
        score = (
            (3 if NODE_SERVICE in types else 0)
            + (2 if NODE_CONTROLLER in types else 0)
            + (2 if NODE_ENTITY in types else 0)
            + (1 if NODE_REPOSITORY in types else 0)
        )
        is_business = any(
            len(n.package.split(".")) >= 4
            and n.package.split(".")[3] == "business"
            for n in domain_nodes[domain]
        )
        if score > best_score or (
            score == best_score and is_business and not best_is_business
        ):
            best_score = score
            best_domain = domain
            best_is_business = is_business

    if best_score < 3 or not best_domain:
        return None

    pattern = DomainPattern(domain=best_domain)
    extras: list[GraphNode] = []
    for node in domain_nodes[best_domain]:
        if node.type == NODE_SERVICE and not pattern.service:
            pattern.service = node
        elif node.type == NODE_CONTROLLER and not pattern.controller:
            pattern.controller = node
        elif node.type == NODE_ENTITY and not pattern.entity:
            pattern.entity = node
        elif node.type == NODE_REPOSITORY and not pattern.repository:
            pattern.repository = node
        else:
            extras.append(node)
    pattern.extras = extras
    return pattern


# ── Formatting helpers (used by MCP tools) ─────────────────────────────────────


def format_connections(result: ConnectionResult) -> str:
    """Render a ConnectionResult as human-readable text for MCP output."""
    lines: list[str] = [f"## `{result.node.name}` ({result.node.type})"]
    lines.append(f"**Package:** `{result.node.package}`")
    lines.append(f"**File:** `{result.node.file}`")

    ai_notes = (result.node.metadata or {}).get("ai_notes", "")
    if ai_notes:
        lines.append(f"\n> **AI notes:** {ai_notes}")

    if result.node.methods:
        lines.append(f"**Methods:** {', '.join(f'`{m}`' for m in result.node.methods[:10])}")

    if result.injects:
        lines.append("\n### Injects (dependencies)")
        for n in result.injects:
            lines.append(f"- `{n.name}` ({n.type}) — `{n.package}`")

    if result.calls:
        lines.append("\n### Calls")
        for n, method in result.calls:
            lines.append(f"- `{n.name}.{method}()` — `{n.package}`")

    if result.extends:
        lines.append(f"\n### Extends\n- `{result.extends.name}`")

    if result.implements:
        lines.append("\n### Implements")
        for n in result.implements:
            lines.append(f"- `{n.name}`")

    if result.injected_by:
        lines.append("\n### Injected by (dependents)")
        for n in result.injected_by:
            lines.append(f"- `{n.name}` ({n.type})")

    if result.called_by:
        lines.append("\n### Called by")
        for n in result.called_by:
            lines.append(f"- `{n.name}` ({n.type})")

    return "\n".join(lines)


def format_impact(result: ImpactResult) -> str:
    """Render an ImpactResult as human-readable text."""
    lines = [
        f"## Impact analysis for `{result.node.name}`",
        f"Changing `{result.node.name}` directly affects **{len(result.direct)}** "
        f"component(s) and indirectly **{len(result.indirect)}** more.\n",
    ]
    if result.direct:
        lines.append("### Direct dependents (distance 1)")
        for n in result.direct:
            lines.append(f"- `{n.name}` ({n.type}) — `{n.file}`")
    if result.indirect:
        lines.append("\n### Indirect dependents (distance 2+)")
        for n in result.indirect[:10]:
            lines.append(f"- `{n.name}` ({n.type}) — `{n.file}`")
        if len(result.indirect) > 10:
            lines.append(f"  *…and {len(result.indirect) - 10} more*")
    return "\n".join(lines)


def format_found(results: list[FoundComponent]) -> str:
    """Render a list of FoundComponent results."""
    if not results:
        return "*No matching components found.*"
    lines = [f"Found **{len(results)}** component(s):\n"]
    for fc in results:
        lines.append(
            f"- **`{fc.node.name}`** ({fc.node.type}) — `{fc.node.package}`  "
            f"*(score: {fc.score:.0f} — {fc.reason})*"
        )
    return "\n".join(lines)


def format_task_result(result: TaskResult) -> str:
    """Render a TaskResult as human-readable text."""
    lines: list[str] = []
    if result.relevant:
        lines.append("## Relevant components\n")
        for fc in result.relevant[:8]:
            lines.append(
                f"- **`{fc.node.name}`** ({fc.node.type}) — `{fc.node.package}`"
            )
            if fc.node.methods:
                lines.append(
                    f"  Methods: {', '.join(f'`{m}`' for m in fc.node.methods[:5])}"
                )
    if result.gaps:
        lines.append("\n## Gaps detected\n")
        for gap in result.gaps:
            lines.append(f"- {gap}")
    if result.suggested_insertions:
        lines.append("\n## Suggested connection points\n")
        for s in result.suggested_insertions:
            lines.append(f"- {s}")
    return "\n".join(lines) if lines else "*No relevant components found.*"


def format_pattern(pattern: DomainPattern) -> str:
    """Render a DomainPattern as a copy-me template."""
    lines = [
        f"## Copy this pattern — domain: `{pattern.domain}`\n",
        "*Follow this structure when creating a new module:*\n",
    ]
    for label, node in [
        ("Service",    pattern.service),
        ("Controller", pattern.controller),
        ("Entity",     pattern.entity),
        ("Repository", pattern.repository),
    ]:
        if node:
            lines.append(f"- **{label}:** `{node.name}` → `{node.package}`")
    if pattern.extras:
        lines.append("\n*Additional classes in this domain:*")
        for n in pattern.extras[:5]:
            lines.append(f"- `{n.name}` ({n.type})")
    return "\n".join(lines)


# ── Internal helpers ───────────────────────────────────────────────────────────

_STOP = frozenset({
    "add", "create", "implement", "build", "fix", "update", "change", "the",
    "a", "an", "and", "or", "for", "in", "on", "to", "of", "with", "by",
    "that", "this", "is", "are", "was", "i", "me", "my", "we", "how",
    "new", "get", "find", "show", "use", "using", "then", "also", "need",
    "want", "make", "when", "module", "feature", "service", "component",
    "class", "function", "method", "file", "code", "api", "endpoint",
})


def _keywords(text: str) -> list[str]:
    words = re.findall(r"[A-Za-z]{3,}", text)
    return [w.lower() for w in words if w.lower() not in _STOP]


def _score_node(node: GraphNode, words: list[str]) -> tuple[float, list[str]]:
    """Score a node against a list of query keywords."""
    score = 0.0
    reasons: list[str] = []
    name_lower = node.name.lower()
    pkg_lower = node.package.lower()
    methods_lower = " ".join(node.methods).lower()
    anns_lower = " ".join(node.annotations).lower()

    for word in words:
        if word in name_lower:
            score += 10.0
            reasons.append(f"name:{word}")
        if word == node.type:
            score += 5.0
            reasons.append(f"type:{word}")
        if word in pkg_lower:
            score += 3.0
            reasons.append(f"pkg:{word}")
        if word in methods_lower:
            score += 2.0
            reasons.append(f"method:{word}")
        if word in anns_lower:
            score += 1.0
            reasons.append(f"ann:{word}")

    return score, reasons
