"""Graph layer — build, persist, and query the CodeGraph."""
