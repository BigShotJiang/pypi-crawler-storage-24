"""Graph builder — orchestrates parsing and assembles the CodeGraph.

Algorithm
---------
1. Walk the project tree; skip excluded directories / files.
2. For each parseable file, call the appropriate parser → ParseResult.
3. Add all nodes to the graph first (so the node name-set is complete).
4. Add all edges; resolve simple-name targets to fully-qualified IDs where
   possible, so edges always point at real graph nodes when the target exists.
5. Detect languages and frameworks from collected data.
6. AI enrichment (optional, Pro): detect orphaned structural nodes, call Claude
   to discover missing edges + generalizable rules, persist rules to cache.
7. Save graph.json atomically.

The builder is also called by the file watcher for incremental updates:
``rebuild_file()`` re-parses a single changed file and patches the graph.
"""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path
from datetime import datetime, timezone
from typing import Callable

from codemind.core.graph import CodeGraph, GraphEdge, GraphNode
from codemind.graph.store import GraphStore
from codemind.parser.base import ParseResult
from codemind.parser.registry import ParserRegistry

# Directories / patterns always excluded from scanning
_DEFAULT_EXCLUDE: frozenset[str] = frozenset({
    "node_modules", "target", "build", "dist", ".git", ".codemind",
    "__pycache__", ".venv", "venv", ".idea", ".vscode",
    "test-output", "coverage", ".nyc_output",
})

# Framework detection: dependency artifact substring → framework name
_FRAMEWORK_SIGNALS: list[tuple[str, str]] = [
    ("spring-boot", "Spring Boot"),
    ("spring-web",  "Spring Boot"),
    ("angular",     "Angular"),
    ("nestjs",      "NestJS"),
    ("react",       "React"),
    ("vue",         "Vue"),
    ("fastapi",     "FastAPI"),
    ("django",      "Django"),
]


class GraphBuilder:
    """Builds and incrementally updates a CodeGraph for a project.

    Usage::

        builder = GraphBuilder()
        graph = builder.build(project_root, codemind_dir)
    """

    def __init__(self) -> None:
        self._registry = ParserRegistry()
        self._store = GraphStore()

    # ── Full build ────────────────────────────────────────────────────────────

    def build(
        self,
        project_root: Path,
        codemind_dir: Path,
        project_name: str = "",
        extra_exclude: list[str] | None = None,
        ai_enrich: bool | None = None,
        progress_callback: Callable[[str], None] | None = None,
    ) -> CodeGraph:
        """Scan the entire project and return a populated CodeGraph.

        Args:
            project_root:       Absolute project directory.
            codemind_dir:       The ``.codemind/`` directory (where graph.json is written).
            project_name:       Human-readable project name (from config).
            extra_exclude:      Additional glob patterns to exclude.
            ai_enrich:          ``True``/``False`` to force on/off; ``None`` = auto-detect
                                (enabled when ANTHROPIC_API_KEY is set).
            progress_callback:  Optional callable for status messages during scan.

        Returns:
            A fully-built CodeGraph; also persisted to graph.json.
        """
        def _progress(msg: str) -> None:
            if progress_callback:
                progress_callback(msg)

        exclude = set(_DEFAULT_EXCLUDE) | set(extra_exclude or [])
        graph = CodeGraph.empty(project_name or project_root.name)

        # Step 1: collect all ParseResults
        results: list[ParseResult] = []
        for path in _walk(project_root, exclude):
            if self._registry.can_parse(path):
                try:
                    pr = self._registry.parse(path, project_root)
                    if pr:
                        results.append(pr)
                except Exception:
                    pass

        # Step 2: add all nodes first (builds the known-name set)
        for pr in results:
            for node in pr.nodes:
                graph.add_node(node)

        # Step 3: add edges, resolving simple-name targets → full IDs
        name_to_id = _build_name_index(graph)
        for pr in results:
            for edge in pr.edges:
                resolved = _resolve_target(edge.target, name_to_id)
                graph.add_edge(GraphEdge(
                    source=edge.source,
                    target=resolved,
                    kind=edge.kind,
                    meta=edge.meta,
                ))

        _progress(f"tree-sitter: {len(graph.nodes)} nodes, {len(graph.edges)} connections")

        # Step 4: AI enrichment (optional)
        should_enrich = ai_enrich if ai_enrich is not None else bool(
            os.environ.get("ANTHROPIC_API_KEY")
        )

        supported_exts = set(self._registry.supported_extensions)

        if should_enrich:
            # Step 4a: Discover completely new stacks (no parser exists)
            stack_results = _run_stack_discovery(
                graph, project_root, supported_exts, _progress
            )
            for sr in stack_results:
                if sr.discovered:
                    _progress(
                        f"AI discovered {sr.language}: +{sr.nodes_added} nodes"
                        f", +{sr.edges_added} connections"
                        + (f", {sr.rules_learned} patterns cached"
                           if sr.rules_learned else "")
                    )

            # Step 4b: Fill edge gaps in already-parsed nodes
            enrich_result = _run_ai_enrichment(graph, project_root, _progress)
            if enrich_result and enrich_result.enhanced:
                _progress(
                    f"AI enhanced: +{enrich_result.edges_added} connections"
                    + (f", {enrich_result.rules_learned} new patterns cached"
                       if enrich_result.rules_learned else "")
                )
        else:
            # Report what AI could improve (both gap fill + new stacks)
            gap_count = _count_gaps(graph)
            unsupported = _count_unsupported_files(project_root, supported_exts)
            hints: list[str] = []
            if gap_count > 0:
                hints.append(f"{gap_count} components may have undetected connections")
            if unsupported:
                from codemind.ai.stack_learner import _EXT_LANG
                lang_list = ", ".join(
                    f"{v} {_EXT_LANG.get(k, k[1:].upper())} files"
                    for k, v in sorted(unsupported.items())
                )
                hints.append(f"unsupported stack: {lang_list}")
            if hints:
                _progress(
                    "note: " + "; ".join(hints)
                    + " (set ANTHROPIC_API_KEY for AI enhancement)"
                )

        # Metadata
        graph.languages = sorted({n.language for n in graph.nodes.values()})
        graph.frameworks = _detect_frameworks(project_root)
        graph.scanned_at = datetime.now(timezone.utc).isoformat()

        self._store.save(graph, codemind_dir)
        return graph

    # ── Incremental update ────────────────────────────────────────────────────

    def rebuild_file(
        self,
        changed_file: Path,
        project_root: Path,
        graph: CodeGraph,
        codemind_dir: Path,
    ) -> CodeGraph:
        """Re-parse a single changed file and patch the graph in place.

        Called by the file watcher.  Fast: only touches nodes/edges from
        this one file.

        Args:
            changed_file: Absolute path to the file that changed.
            project_root: Project root.
            graph:        The existing in-memory graph to patch.
            codemind_dir: Where to save the updated graph.json.

        Returns:
            The patched CodeGraph (same object, mutated).
        """
        try:
            rel = changed_file.relative_to(project_root)
            file_rel = "/".join(rel.parts)
        except ValueError:
            return graph

        # Remove stale data for this file
        graph.remove_file(file_rel)

        # Re-parse
        if not self._registry.can_parse(changed_file) or not changed_file.exists():
            self._store.save(graph, codemind_dir)
            return graph

        try:
            pr = self._registry.parse(changed_file, project_root)
        except Exception:
            self._store.save(graph, codemind_dir)
            return graph

        if pr is None:
            self._store.save(graph, codemind_dir)
            return graph

        # Add new nodes
        for node in pr.nodes:
            graph.add_node(node)

        # Add new edges (resolve targets)
        name_to_id = _build_name_index(graph)
        for edge in pr.edges:
            resolved = _resolve_target(edge.target, name_to_id)
            graph.add_edge(GraphEdge(
                source=edge.source,
                target=resolved,
                kind=edge.kind,
                meta=edge.meta,
            ))

        self._store.save(graph, codemind_dir)
        return graph


# ── Helpers ────────────────────────────────────────────────────────────────────


def _walk(root: Path, exclude: set[str]):
    """Yield all files under root, skipping excluded directories."""
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        # Skip if any part of the path matches an excluded dir
        if any(part in exclude for part in path.parts):
            continue
        # Skip glob-pattern exclusions
        name = path.name
        if any(fnmatch.fnmatch(name, pat) for pat in exclude if "*" in pat or "?" in pat):
            continue
        yield path


def _build_name_index(graph: CodeGraph) -> dict[str, str]:
    """``{simple_name → fully_qualified_id}`` for all nodes in the graph."""
    index: dict[str, str] = {}
    for nid, node in graph.nodes.items():
        # Prefer the first match (don't overwrite if name is ambiguous)
        if node.name not in index:
            index[node.name] = nid
    return index


def _resolve_target(target: str, name_to_id: dict[str, str]) -> str:
    """Resolve a simple class name to its fully-qualified ID if possible."""
    # Already a full ID (contains dot or slash and exists directly)
    if target in name_to_id.values():
        return target
    # Simple name → full ID
    return name_to_id.get(target, target)


def _run_stack_discovery(
    graph: CodeGraph,
    project_root: Path,
    supported_extensions: set[str],
    progress: "Callable[[str], None]",
) -> list:
    """Run StackLearner for unsupported file types; returns list of DiscoveryResult."""
    try:
        from codemind.ai.stack_learner import StackLearner
        from codemind.parser.rule_cache import RuleCache

        if not StackLearner.is_available():
            return []

        learner = StackLearner()
        rule_cache = RuleCache()
        unsupported = learner.unsupported_extensions(project_root, supported_extensions)
        if unsupported:
            lang_list = ", ".join(
                f"{v} {k[1:].upper()} files" for k, v in sorted(unsupported.items())
            )
            progress(f"stack discovery: {lang_list} found, analysing…")
        return learner.discover(project_root, graph, supported_extensions, rule_cache)
    except Exception:
        return []


def _count_unsupported_files(project_root: Path, supported_extensions: set[str]) -> dict:
    """Count unsupported files grouped by extension (no API key path)."""
    try:
        from codemind.ai.stack_learner import StackLearner
        learner = StackLearner()
        return learner.unsupported_extensions(project_root, supported_extensions)
    except Exception:
        return {}


def _run_ai_enrichment(
    graph: CodeGraph,
    project_root: Path,
    progress: "Callable[[str], None]",
) -> "EnrichmentResult | None":
    """Run gap detection + AI enrichment; returns None on any error."""
    try:
        from codemind.ai.enricher import AIEnricher, EnrichmentResult
        from codemind.parser.gap_detector import GapDetector
        from codemind.parser.rule_cache import RuleCache

        if not AIEnricher.is_available():
            return None

        gaps = GapDetector().detect(graph, project_root)
        if not gaps:
            return None

        progress(f"gap detection: {len(gaps)} components with no connections, analysing…")
        rule_cache = RuleCache()
        enricher = AIEnricher()
        return enricher.enrich(gaps, graph, project_root, rule_cache)
    except Exception:
        return None


def _count_gaps(graph: CodeGraph) -> int:
    """Count structural nodes with zero connections (no AI key available)."""
    try:
        from codemind.parser.gap_detector import GapDetector
        return len(GapDetector().detect(graph))
    except Exception:
        return 0


def _detect_frameworks(project_root: Path) -> list[str]:
    """Heuristic framework detection from build files."""
    frameworks: set[str] = set()
    for build_file in ("pom.xml", "build.gradle", "package.json"):
        bf = project_root / build_file
        if bf.exists():
            try:
                content = bf.read_text(encoding="utf-8", errors="ignore").lower()
                for signal, name in _FRAMEWORK_SIGNALS:
                    if signal in content:
                        frameworks.add(name)
            except OSError:
                pass
    return sorted(frameworks)
