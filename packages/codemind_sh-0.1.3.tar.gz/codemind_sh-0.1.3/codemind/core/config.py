"""Configuration file handler for .codemind/config.yml."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import yaml


@dataclass
class TechStackConfig:
    """Technology stack configuration."""

    backend_language: str = ""
    backend_framework: str = ""
    backend_version: str = ""
    backend_build_tool: str = ""
    frontend_language: str = ""
    frontend_framework: str = ""
    frontend_version: str = ""
    database_type: str = ""
    database_version: str = ""
    auth_provider: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to nested dict for YAML output."""
        result: dict[str, Any] = {}
        if self.backend_language:
            result["backend"] = {
                "language": self.backend_language,
                "framework": self.backend_framework,
                "version": self.backend_version,
                "build_tool": self.backend_build_tool,
            }
        if self.frontend_language:
            result["frontend"] = {
                "language": self.frontend_language,
                "framework": self.frontend_framework,
                "version": self.frontend_version,
            }
        if self.database_type:
            result["database"] = {
                "type": self.database_type,
                "version": self.database_version,
            }
        if self.auth_provider:
            result["auth"] = {"provider": self.auth_provider}
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TechStackConfig:
        """Create from nested dict (YAML input)."""
        config = cls()
        if backend := data.get("backend"):
            config.backend_language = backend.get("language", "")
            config.backend_framework = backend.get("framework", "")
            config.backend_version = backend.get("version", "")
            config.backend_build_tool = backend.get("build_tool", "")
        if frontend := data.get("frontend"):
            config.frontend_language = frontend.get("language", "")
            config.frontend_framework = frontend.get("framework", "")
            config.frontend_version = frontend.get("version", "")
        if database := data.get("database"):
            config.database_type = database.get("type", "")
            config.database_version = database.get("version", "")
        if auth := data.get("auth"):
            config.auth_provider = auth.get("provider", "")
        return config


@dataclass
class ConventionsConfig:
    """Project conventions."""

    api_prefix: str = "/api/v1"
    package_base: str = ""
    test_suffix: str = "Test"
    i18n_languages: list[str] = field(default_factory=lambda: ["en"])


@dataclass
class AIConfig:
    """AI integration settings."""

    provider: str = "anthropic"
    model: str = "claude-sonnet-4-5-20250929"
    api_key_env: str = "CLAUDE_API_KEY"
    max_tokens_per_analysis: int = 4096
    context_token_budget: int = 8000


@dataclass
class ScanConfig:
    """Scan configuration."""

    include: list[str] = field(default_factory=lambda: ["src/**", "*.xml", "*.yml", "*.json"])
    exclude: list[str] = field(default_factory=lambda: [
        "node_modules/**", "target/**", "dist/**", ".git/**",
        "__pycache__/**", ".venv/**", "*.min.js", "*.min.css",
    ])


@dataclass
class MCPConfig:
    """MCP server settings."""

    enabled: bool = True
    port: int = 3333
    host: str = "127.0.0.1"


@dataclass
class StructureConfig:
    """Project structure — single repo vs fullstack monorepo."""

    project_type: str = "single"    # "single" | "fullstack"
    frontend_path: str = ""         # Relative path to frontend root, e.g. "client/"
    backend_path: str = ""          # Relative path to backend root, e.g. "server/"


@dataclass
class CodemindConfig:
    """Complete CodeMind configuration for a project."""

    project_name: str = ""
    project_description: str = ""
    project_version: str = "1.0.0"
    project_id: str = ""      # UUID — identifies this project for Hotel Key licensing
    tech_stack: TechStackConfig = field(default_factory=TechStackConfig)
    structure: StructureConfig = field(default_factory=StructureConfig)
    conventions: ConventionsConfig = field(default_factory=ConventionsConfig)
    ai: AIConfig = field(default_factory=AIConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)
    mcp: MCPConfig = field(default_factory=MCPConfig)

    def save(self, path: Path) -> None:
        """Save configuration to YAML file."""
        # Auto-generate project_id on first save (needed for Hotel Key licensing)
        if not self.project_id:
            self.project_id = str(uuid.uuid4())
        data: dict[str, Any] = {
            "project": {
                "name": self.project_name,
                "description": self.project_description,
                "version": self.project_version,
                "id": self.project_id,
            },
            "tech_stack": self.tech_stack.to_dict(),
            "conventions": asdict(self.conventions),
            "ai": asdict(self.ai),
            "scan": asdict(self.scan),
            "mcp": asdict(self.mcp),
        }
        # Only write structure section when it has meaningful values
        if self.structure.project_type != "single" or self.structure.frontend_path or self.structure.backend_path:
            data["structure"] = asdict(self.structure)

        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    @classmethod
    def load(cls, path: Path) -> CodemindConfig:
        """Load configuration from YAML file."""
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        config = cls()

        if project := data.get("project"):
            config.project_name = project.get("name", "")
            config.project_description = project.get("description", "")
            config.project_version = project.get("version", "1.0.0")
            config.project_id = project.get("id", "")

        if tech := data.get("tech_stack"):
            config.tech_stack = TechStackConfig.from_dict(tech)

        if structure := data.get("structure"):
            config.structure = StructureConfig(
                project_type=structure.get("project_type", "single"),
                frontend_path=structure.get("frontend_path", ""),
                backend_path=structure.get("backend_path", ""),
            )

        if conventions := data.get("conventions"):
            config.conventions = ConventionsConfig(**conventions)

        if ai := data.get("ai"):
            config.ai = AIConfig(**ai)

        if scan := data.get("scan"):
            config.scan = ScanConfig(**scan)

        if mcp := data.get("mcp"):
            config.mcp = MCPConfig(**mcp)

        return config
