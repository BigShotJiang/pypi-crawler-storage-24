"""Project model — manages the .codemind/ directory and its contents."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from codemind.core.config import CodemindConfig
from codemind.core.constants import (
    CODEMIND_DIR,
    CONFIG_FILE,
    GRAPH_FILE,
    MODULES_DIR,
    TEMPLATES_DIR,
    TASKS_DIR,
    KNOWLEDGE_FILES,
)


class CodemindProject:
    """Represents a project with CodeMind intelligence."""

    def __init__(self, project_root: Path) -> None:
        self.root = project_root.resolve()
        self.codemind_dir = self.root / CODEMIND_DIR
        self.config_path = self.codemind_dir / CONFIG_FILE
        self._config: Optional[CodemindConfig] = None

    @property
    def config(self) -> CodemindConfig:
        """Lazy-load configuration."""
        if self._config is None:
            if self.config_path.exists():
                self._config = CodemindConfig.load(self.config_path)
            else:
                self._config = CodemindConfig()
        return self._config

    @property
    def is_initialized(self) -> bool:
        """Check if .codemind/ exists in this project."""
        return self.codemind_dir.exists() and self.config_path.exists()

    @property
    def modules_dir(self) -> Path:
        return self.codemind_dir / MODULES_DIR

    @property
    def templates_dir(self) -> Path:
        return self.codemind_dir / TEMPLATES_DIR

    @property
    def tasks_dir(self) -> Path:
        return self.codemind_dir / TASKS_DIR

    @property
    def graph_path(self) -> Path:
        """Path to the primary knowledge graph (graph.json)."""
        return self.codemind_dir / GRAPH_FILE

    def knowledge_file(self, name: str) -> Path:
        """Get path to a knowledge file."""
        return self.codemind_dir / name

    def module_file(self, module_name: str) -> Path:
        """Get path to a module knowledge file."""
        return self.modules_dir / f"{module_name}.md"

    def task_file(self, feature_name: str) -> Path:
        """Get path to a task file."""
        return self.tasks_dir / f"{feature_name}.tasks.md"

    def initialize(self, config: CodemindConfig) -> None:
        """Create .codemind/ directory structure and initial files."""
        # Create directories
        self.codemind_dir.mkdir(exist_ok=True)
        self.modules_dir.mkdir(exist_ok=True)
        self.templates_dir.mkdir(exist_ok=True)
        self.tasks_dir.mkdir(exist_ok=True)

        # Save config
        config.save(self.config_path)
        self._config = config

        # Create empty knowledge files with headers
        for filename in KNOWLEDGE_FILES:
            filepath = self.codemind_dir / filename
            if not filepath.exists():
                title = filename.replace(".md", "").replace("_", " ").title()
                header = self._generate_file_header(title, config.project_name)
                filepath.write_text(header, encoding="utf-8")

        # Create .gitignore for optional files
        gitignore_path = self.codemind_dir / ".gitignore"
        if not gitignore_path.exists():
            gitignore_content = (
                "# Auto-generated files (regenerate with: codemind scan)\n"
                "index.json\n"
                "vectors.json\n"
                "\n"
                "# Keep everything else in git\n"
                "# Knowledge files, templates, tasks — all version controlled\n"
            )
            gitignore_path.write_text(gitignore_content, encoding="utf-8")

    def _generate_file_header(self, title: str, project_name: str) -> str:
        """Generate initial content for a knowledge file."""
        headers: dict[str, str] = {
            "Architecture": (
                f"# {project_name} — Architecture\n\n"
                "## Overview\n\n"
                "*Run `codemind scan` to auto-generate this file from your codebase.*\n\n"
                "## Tech Stack\n\n"
                "## Module Map\n\n"
                "## Data Flow\n\n"
                "## Key Conventions\n\n"
            ),
            "Decisions": (
                f"# {project_name} — Architectural Decisions\n\n"
                "*Record decisions with: `codemind decide \"what\" --why \"reason\"`*\n\n"
                "## Decision Log\n\n"
                "| # | Decision | Why | Date | Status |\n"
                "|---|----------|-----|------|--------|\n"
                "| | | | | |\n"
            ),
            "Patterns": (
                f"# {project_name} — Code Patterns & Conventions\n\n"
                "*Run `codemind scan` to auto-detect patterns from your codebase.*\n\n"
                "## Naming Conventions\n\n"
                "## Service Patterns\n\n"
                "## Error Handling\n\n"
                "## Testing Patterns\n\n"
            ),
            "Dependencies": (
                f"# {project_name} — Dependencies & Integrations\n\n"
                "*Run `codemind scan` to auto-detect dependencies.*\n\n"
                "## External Systems\n\n"
                "## Libraries\n\n"
                "## API Integrations\n\n"
            ),
            "Risks": (
                f"# {project_name} — Risks & Tech Debt\n\n"
                "*Run `codemind check` to auto-detect risks.*\n\n"
                "## Known Issues\n\n"
                "## Tech Debt\n\n"
                "## Security Concerns\n\n"
            ),
            "Roadmap": (
                f"# {project_name} — Roadmap\n\n"
                "*This file is manually maintained. Add your planned features here.*\n\n"
                "## Planned\n\n"
                "## In Progress\n\n"
                "## Completed\n\n"
            ),
        }
        return headers.get(title, f"# {project_name} — {title}\n\n")

    def get_all_knowledge_content(self) -> dict[str, str]:
        """Read all knowledge files and return as dict."""
        content: dict[str, str] = {}
        for filename in KNOWLEDGE_FILES:
            filepath = self.codemind_dir / filename
            if filepath.exists():
                content[filename] = filepath.read_text(encoding="utf-8")

        # Also read module files
        if self.modules_dir.exists():
            for module_file in sorted(self.modules_dir.glob("*.md")):
                key = f"modules/{module_file.name}"
                content[key] = module_file.read_text(encoding="utf-8")

        return content

    @classmethod
    def find_project(cls, start_path: Optional[Path] = None) -> Optional[CodemindProject]:
        """Walk up from start_path to find a .codemind/ directory."""
        path = (start_path or Path.cwd()).resolve()

        while path != path.parent:
            candidate = path / CODEMIND_DIR
            if candidate.is_dir() and (candidate / CONFIG_FILE).exists():
                return cls(path)
            path = path.parent

        return None
