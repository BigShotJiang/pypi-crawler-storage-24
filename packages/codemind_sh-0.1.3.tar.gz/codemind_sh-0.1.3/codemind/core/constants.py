"""Shared constants for CodeMind."""

from pathlib import Path

# Directory names
CODEMIND_DIR = ".codemind"
MODULES_DIR = "modules"
TEMPLATES_DIR = "templates"
TASKS_DIR = "tasks"

# Knowledge files
ARCHITECTURE_FILE = "ARCHITECTURE.md"
CONNECTIONS_FILE = "CONNECTIONS.md"
DECISIONS_FILE = "DECISIONS.md"
PATTERNS_FILE = "PATTERNS.md"
DEPENDENCIES_FILE = "DEPENDENCIES.md"
RISKS_FILE = "RISKS.md"
ROADMAP_FILE = "ROADMAP.md"

# Data files — graph.json is the primary source of truth
GRAPH_FILE = "graph.json"
CONFIG_FILE = "config.yml"

# Legacy (kept for backward compatibility during transition)
INDEX_FILE = "index.json"

# All knowledge files (for iteration)
KNOWLEDGE_FILES = [
    ARCHITECTURE_FILE,
    CONNECTIONS_FILE,
    DECISIONS_FILE,
    PATTERNS_FILE,
    DEPENDENCIES_FILE,
    RISKS_FILE,
    ROADMAP_FILE,
]

# Default scan exclusions
DEFAULT_EXCLUDE = [
    "node_modules",
    "target",
    "build",
    "dist",
    ".git",
    ".codemind",
    "__pycache__",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "*.min.js",
    "*.min.css",
    "*.map",
    "package-lock.json",
    "yarn.lock",
    "pom.xml.bak",
]

# Supported languages and their file extensions
LANGUAGE_EXTENSIONS: dict[str, list[str]] = {
    "java": [".java"],
    "typescript": [".ts", ".tsx"],
    "python": [".py"],
    "javascript": [".js", ".jsx"],
}

# Dependency files to scan
DEPENDENCY_FILES: dict[str, str] = {
    "pom.xml": "maven",
    "build.gradle": "gradle",
    "package.json": "npm",
    "requirements.txt": "pip",
    "pyproject.toml": "poetry",
    "Cargo.toml": "cargo",
    "go.mod": "go",
}

# MCP defaults
MCP_DEFAULT_HOST = "127.0.0.1"
MCP_DEFAULT_PORT = 3333

# Context defaults
DEFAULT_TOKEN_BUDGET = 8000
MAX_TOKEN_BUDGET = 32000
