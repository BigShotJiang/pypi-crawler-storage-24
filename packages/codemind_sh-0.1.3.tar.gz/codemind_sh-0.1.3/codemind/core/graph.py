"""CodeMind graph data model — nodes, typed edges, and the code knowledge graph.

This is the single source of truth for the entire system.  Everything else
(parsers, query engine, MCP tools, watcher) reads from or writes to a CodeGraph.

Design decisions
----------------
- Nodes are components: classes, interfaces, enums, Angular components, etc.
- Edges are typed directed relationships: injects, calls, extends, implements, imports.
- Node IDs are fully-qualified names (package.ClassName) for Java, path/ClassName for TS.
- The graph is always current — the file watcher patches it on every save.
- Runtime edge indices (_edges_from / _edges_to) are rebuilt after every mutation;
  they are not stored on disk.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterator

# ── Edge kinds ────────────────────────────────────────────────────────────────

EDGE_INJECTS     = "injects"      # A injects B (Spring @Autowired / constructor / Angular DI)
EDGE_CALLS       = "calls"        # A.method() explicitly calls a method on B
EDGE_IMPLEMENTS  = "implements"   # A implements interface B
EDGE_EXTENDS     = "extends"      # A extends class B
EDGE_IMPORTS     = "imports"      # A imports B (TypeScript / general)
EDGE_CROSS_LAYER = "cross_layer"  # Frontend component → Backend controller (via matched HTTP route)

# ── Node types ────────────────────────────────────────────────────────────────

NODE_SERVICE       = "service"
NODE_CONTROLLER    = "controller"
NODE_ENTITY        = "entity"
NODE_REPOSITORY    = "repository"
NODE_COMPONENT     = "component"      # Angular component
NODE_MODULE        = "module"         # Angular NgModule
NODE_CONFIGURATION = "configuration"
NODE_INTERFACE     = "interface"
NODE_ENUM          = "enum"
NODE_CLASS         = "class"          # generic / unclassified
NODE_GUARD         = "guard"
NODE_INTERCEPTOR   = "interceptor"
NODE_ASPECT        = "aspect"
NODE_DIRECTIVE     = "directive"
NODE_PIPE          = "pipe"


# ── Core data types ───────────────────────────────────────────────────────────


@dataclass
class GraphNode:
    """A single component (class / interface / enum) in the code graph.

    Attributes:
        id:           Unique stable identifier.  For Java: ``com.app.kpi.business.crud.DeptService``.
                      For TypeScript: ``src/app/dashboard/dashboard.component``.
        name:         Simple unqualified name (e.g. ``DeptService``).
        type:         Semantic type — one of the ``NODE_*`` constants.
        language:     ``"java"`` | ``"typescript"`` | ``"python"``.
        package:      Java package or TypeScript directory path.
        file:         Relative file path using forward slashes.
        methods:      Public method / function names.
        annotations:  Class-level annotations or decorators (without ``@``).
        interfaces:   Names of implemented interfaces.
        superclass:   Parent class name; empty string if none.
        line:         1-based line number of the declaration.
    """

    id: str
    name: str
    type: str
    language: str
    package: str
    file: str
    methods: list[str] = field(default_factory=list)
    annotations: list[str] = field(default_factory=list)
    interfaces: list[str] = field(default_factory=list)
    superclass: str = ""
    line: int = 0
    metadata: dict = field(default_factory=dict)  # Extra data: routes, api_calls, etc.


@dataclass
class GraphEdge:
    """A typed directed relationship between two components.

    Attributes:
        source: ID of the originating node (always a project component).
        target: Simple name or ID of the destination (may be external to the project).
        kind:   Relationship type — one of the ``EDGE_*`` constants.
        meta:   Extra context, e.g. ``{"via": "@Autowired"}`` or ``{"method": "evaluate"}``.
    """

    source: str
    target: str
    kind: str
    meta: dict[str, str] = field(default_factory=dict)


@dataclass
class CodeGraph:
    """The complete, living knowledge graph of a codebase.

    Nodes represent components; edges represent typed relationships.
    The graph is incrementally updated by the file watcher on every save —
    it is always current, never a stale snapshot.

    Runtime edge indices (``_edges_from`` / ``_edges_to``) are rebuilt after
    every mutation and are not persisted to disk.
    """

    project: str
    scanned_at: str
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    nodes: dict[str, GraphNode] = field(default_factory=dict)   # id → node
    edges: list[GraphEdge] = field(default_factory=list)

    # Runtime indices — not persisted
    _edges_from: dict[str, list[GraphEdge]] = field(
        default_factory=dict, repr=False, compare=False
    )
    _edges_to: dict[str, list[GraphEdge]] = field(
        default_factory=dict, repr=False, compare=False
    )

    def __post_init__(self) -> None:
        self._rebuild_indices()

    # ── Mutation ──────────────────────────────────────────────────────────────

    def add_node(self, node: GraphNode) -> None:
        """Add or replace a node (upsert by id)."""
        self.nodes[node.id] = node

    def add_edge(self, edge: GraphEdge) -> None:
        """Append an edge and update runtime indices."""
        self.edges.append(edge)
        self._edges_from.setdefault(edge.source, []).append(edge)
        self._edges_to.setdefault(edge.target, []).append(edge)

    def remove_file(self, file_path: str) -> None:
        """Remove all nodes and edges that originated from *file_path*.

        Called by the file watcher before re-parsing a changed file so that
        stale data never accumulates.
        """
        stale_ids = {n.id for n in self.nodes.values() if n.file == file_path}
        for nid in stale_ids:
            del self.nodes[nid]
        self.edges = [
            e for e in self.edges
            if e.source not in stale_ids
        ]
        self._rebuild_indices()

    # ── Query primitives ──────────────────────────────────────────────────────

    def edges_from(self, node_id: str) -> list[GraphEdge]:
        """All edges where ``source == node_id``."""
        return list(self._edges_from.get(node_id, []))

    def edges_to(self, node_id: str) -> list[GraphEdge]:
        """All edges where ``target`` resolves to *node_id* or the simple name."""
        node = self.nodes.get(node_id)
        simple_name = node.name if node else node_id
        result = list(self._edges_to.get(node_id, []))
        # Also match edges that used the simple name as target
        if simple_name != node_id:
            result += self._edges_to.get(simple_name, [])
        return result

    def resolve(self, query: str) -> GraphNode | None:
        """Find a node by full ID or simple class name (case-insensitive fallback)."""
        if query in self.nodes:
            return self.nodes[query]
        lower = query.lower()
        for node in self.nodes.values():
            if node.name.lower() == lower:
                return node
        return None

    def nodes_by_file(self, file_path: str) -> list[GraphNode]:
        """All nodes declared in *file_path*."""
        return [n for n in self.nodes.values() if n.file == file_path]

    def nodes_by_type(self, *types: str) -> Iterator[GraphNode]:
        """Iterate nodes matching any of the given type strings."""
        for node in self.nodes.values():
            if node.type in types:
                yield node

    def internal_targets(self, node_id: str) -> list[GraphEdge]:
        """Edges from *node_id* whose target is a known project node."""
        return [
            e for e in self.edges_from(node_id)
            if self.resolve(e.target) is not None
        ]

    def stats(self) -> dict[str, int | str]:
        """Return aggregate statistics about the graph."""
        by_lang: dict[str, int] = {}
        by_type: dict[str, int] = {}
        for node in self.nodes.values():
            by_lang[node.language] = by_lang.get(node.language, 0) + 1
            by_type[node.type] = by_type.get(node.type, 0) + 1
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            **{f"lang_{k}": v for k, v in sorted(by_lang.items())},
            **{f"type_{k}": v for k, v in sorted(by_type.items())},
        }

    # ── Factory ───────────────────────────────────────────────────────────────

    @classmethod
    def empty(cls, project: str) -> CodeGraph:
        """Create a new empty graph for *project*."""
        return cls(
            project=project,
            scanned_at=datetime.now(timezone.utc).isoformat(),
        )

    # ── Internal ──────────────────────────────────────────────────────────────

    def _rebuild_indices(self) -> None:
        """Rebuild _edges_from / _edges_to from self.edges."""
        self._edges_from = {}
        self._edges_to = {}
        for edge in self.edges:
            self._edges_from.setdefault(edge.source, []).append(edge)
            self._edges_to.setdefault(edge.target, []).append(edge)
