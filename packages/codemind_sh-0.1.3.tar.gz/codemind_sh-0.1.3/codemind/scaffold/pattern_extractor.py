"""Pattern extractor — derives ScaffoldContext from an existing graph domain pattern.

Takes the richest existing domain (from get_domain_pattern) and projects it
onto a new name so generated code uses the project's own package structure,
naming conventions, and source layout rather than generic defaults.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from codemind.core.graph import CodeGraph, GraphNode
from codemind.graph.query import DomainPattern

# Layer segment names that should be stripped when inferring domain_package
_LAYER_SUFFIXES = frozenset({
    "service", "services",
    "controller", "controllers",
    "repository", "repositories",
    "entity", "entities",
    "model", "models",
    "dto", "dtos",
    "mapper", "mappers",
    "util", "utils",
    "helper", "helpers",
    "config", "configuration",
    "exception", "exceptions",
})

# Ordered preference for picking the richest node from a pattern
_NODE_PREF = ["service", "controller", "entity", "repository"]


@dataclass
class ScaffoldContext:
    """All coordinates needed by ScaffoldGenerator to render templates.

    Attributes:
        base_name:       PascalCase name without layer suffix, e.g. "KpiAlert".
        language:        "java" or "typescript".
        domain_package:  Java package root for the new domain,
                         e.g. "com.app.kpi.business.kpialert".
        java_src_root:   Relative path to the Java source root,
                         e.g. "kpi-manager/src/main/java/".  May be "".
        ts_src_root:     Relative path to the TypeScript source root,
                         e.g. "ut-kpi-app-flex/src/app/".  May be "".
        api_path:        REST base path, e.g. "/api/kpi-alert".
        table_name:      JPA table name, e.g. "kpi_alert".
    """

    base_name: str
    language: str
    domain_package: str
    java_src_root: str
    ts_src_root: str
    api_path: str
    table_name: str


class PatternExtractor:
    """Derive a ScaffoldContext from a DomainPattern (or from defaults).

    Usage::

        ctx = PatternExtractor().extract("KpiAlert", pattern, graph)
    """

    def extract(
        self,
        name: str,
        pattern: DomainPattern | None,
        graph: CodeGraph | None,
    ) -> ScaffoldContext:
        """Build a ScaffoldContext for the given *name* and optional *pattern*.

        Args:
            name:    Raw user input ("KpiAlert", "kpi-alert", "KpiAlertService").
            pattern: Best existing domain from get_domain_pattern(), or None.
            graph:   The live CodeGraph — used to detect TypeScript source roots.

        Returns:
            A fully-populated ScaffoldContext.
        """
        base_name = self._normalise(name)
        language = self._detect_language(pattern, graph)

        if pattern is not None:
            node = self._best_node(pattern)
            if node is not None:
                domain_pkg = self._domain_package(node)
                java_src = self._java_src_root(node)
                # Replace the last package segment (old domain) with new name
                new_domain_pkg = self._replace_last_segment(domain_pkg, base_name.lower())
                ts_src = self._ts_src_root(graph)
                return ScaffoldContext(
                    base_name=base_name,
                    language=language,
                    domain_package=new_domain_pkg,
                    java_src_root=java_src,
                    ts_src_root=ts_src,
                    api_path="/api/" + _to_kebab(base_name),
                    table_name=_to_snake(base_name),
                )

        # ── Fallback ──
        return ScaffoldContext(
            base_name=base_name,
            language=language,
            domain_package="com.example.app",
            java_src_root="src/main/java/",
            ts_src_root="src/app/",
            api_path="/api/" + _to_kebab(base_name),
            table_name=_to_snake(base_name),
        )

    # ── Private helpers ────────────────────────────────────────────────────

    def _normalise(self, name: str) -> str:
        """Strip layer suffix, convert to PascalCase.

        Examples:
            "kpi-alert"          → "KpiAlert"
            "KpiAlertService"    → "KpiAlert"
            "KPI_ALERT"          → "KpiAlert"
        """
        # Convert kebab / snake / space to PascalCase first
        pascal = _to_pascal(name)
        # Strip known layer suffixes (case-insensitive)
        for suffix in _LAYER_SUFFIXES:
            if pascal.lower().endswith(suffix) and len(pascal) > len(suffix):
                pascal = pascal[: -len(suffix)]
                break
        return pascal

    def _detect_language(
        self,
        pattern: DomainPattern | None,
        graph: CodeGraph | None,
    ) -> str:
        """Return "java" or "typescript".  Java wins if any Java node exists."""
        if pattern is not None:
            node = self._best_node(pattern)
            if node is not None:
                return node.language
        if graph is not None:
            for node in graph.nodes.values():
                if node.language == "java":
                    return "java"
            for node in graph.nodes.values():
                if node.language == "typescript":
                    return "typescript"
        return "java"

    def _best_node(self, pattern: DomainPattern) -> GraphNode | None:
        """Pick the richest node from the pattern by priority order."""
        for pref in _NODE_PREF:
            node = getattr(pattern, pref, None)
            if node is not None:
                return node
        # Try extras
        if pattern.extras:
            return pattern.extras[0]
        return None

    def _domain_package(self, node: GraphNode) -> str:
        """Strip the last layer segment from the package, returning the domain root.

        Example:
            "com.app.kpi.business.kpibuilder.service" → "com.app.kpi.business.kpibuilder"
            "com.app.kpi.business.kpibuilder"         → "com.app.kpi.business.kpibuilder"
        """
        parts = node.package.split(".")
        if parts and parts[-1].lower() in _LAYER_SUFFIXES:
            parts = parts[:-1]
        return ".".join(parts) if parts else node.package

    def _java_src_root(self, node: GraphNode) -> str:
        """Extract the Java source root prefix from the node's file path.

        Looks for 'src/main/java/' in the path and returns everything up to
        (and including) that segment, e.g. "kpi-manager/src/main/java/".

        Falls back to "src/main/java/" if not found.
        """
        file = node.file.replace("\\", "/")
        marker = "src/main/java/"
        idx = file.find(marker)
        if idx != -1:
            return file[: idx + len(marker)]
        return "src/main/java/"

    def _ts_src_root(self, graph: CodeGraph | None) -> str:
        """Find the Angular/TypeScript source root from any TS node in the graph."""
        if graph is None:
            return "src/app/"
        for node in graph.nodes.values():
            if node.language == "typescript" and node.file:
                file = node.file.replace("\\", "/")
                marker = "/src/app/"
                idx = file.find(marker)
                if idx != -1:
                    return file[: idx + len(marker)]
        return "src/app/"

    def _replace_last_segment(self, package: str, new_segment: str) -> str:
        """Replace the last dot-separated segment with *new_segment*."""
        parts = package.split(".")
        if parts:
            parts[-1] = new_segment
        return ".".join(parts)


# ── Module-level helpers ───────────────────────────────────────────────────────


def _to_kebab(name: str) -> str:
    """Convert PascalCase or camelCase to kebab-case.

    Examples:
        "KpiAlert" → "kpi-alert"
        "HTTPSConnection" → "https-connection"
    """
    # Insert hyphen before each uppercase letter that follows a lowercase letter or digit
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", name)
    # Also handle sequences like "HTTPSFoo" → "HTTPS-Foo"
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1-\2", s)
    return s.lower().replace("_", "-")


def _to_snake(name: str) -> str:
    """Convert PascalCase or camelCase to snake_case.

    Examples:
        "KpiAlert" → "kpi_alert"
    """
    return _to_kebab(name).replace("-", "_")


def _to_pascal(name: str) -> str:
    """Convert kebab-case, snake_case, or space-separated text to PascalCase.

    Examples:
        "kpi-alert"    → "KpiAlert"
        "kpi_alert"    → "KpiAlert"
        "kpi alert"    → "KpiAlert"
        "KpiAlert"     → "KpiAlert"
        "kpiAlert"     → "KpiAlert"
    """
    # Split on non-alphanumeric delimiters (hyphens, underscores, spaces)
    parts = re.split(r"[-_\s]+", name)
    if len(parts) > 1:
        return "".join(p.capitalize() for p in parts if p)
    # Already PascalCase or camelCase — just capitalise the first letter
    if name:
        return name[0].upper() + name[1:]
    return name
