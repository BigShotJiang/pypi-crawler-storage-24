"""Scaffold generator — renders Jinja2 templates from a ScaffoldContext.

Produces framework-correct code files (Java Spring Boot / Angular TypeScript)
that mirror the project's own package structure and naming conventions,
plus a markdown task checklist in .codemind/tasks/.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Sequence

try:
    from jinja2 import Environment, FileSystemLoader, TemplateNotFound
    _JINJA_AVAILABLE = True
except ImportError:  # pragma: no cover
    _JINJA_AVAILABLE = False

from codemind.scaffold.pattern_extractor import ScaffoldContext, _to_snake, _to_kebab

# ── Scaffold type → (files to generate, language)
_SCAFFOLD_TYPES: dict[str, list[str]] = {
    "service":   ["service", "test"],
    "module":    ["service", "controller", "entity", "repository", "test"],
    "api":       ["service", "controller", "test"],
    "component": ["service"],   # TypeScript component service
}

_JAVA_EXT = "java"
_TS_EXT = "ts"


@dataclass
class GeneratedFile:
    """One file produced by the scaffold generator.

    Attributes:
        path:     Absolute path where the file should be written.
        content:  Rendered file content.
        label:    Short display label (e.g. "KpiAlertService.java").
        existed:  True if the file was already present on disk.
    """

    path: Path
    content: str
    label: str
    existed: bool = False


class ScaffoldGenerator:
    """Render scaffold templates and write generated files to disk.

    Usage::

        gen = ScaffoldGenerator()
        files = gen.generate("service", ctx, project_root, codemind_dir)
    """

    # Template directory bundled with the package
    _TEMPLATE_DIR = Path(__file__).parent / "templates"

    def generate(
        self,
        scaffold_type: str,
        ctx: ScaffoldContext,
        project_root: Path,
        codemind_dir: Path,
        dry_run: bool = False,
        force: bool = False,
    ) -> list[GeneratedFile]:
        """Generate scaffold files for *scaffold_type* using *ctx*.

        Args:
            scaffold_type: "service" | "module" | "api" | "component".
            ctx:           ScaffoldContext from PatternExtractor.
            project_root:  Root of the project being scaffolded into.
            codemind_dir:  Path to .codemind/ for writing the task file.
            dry_run:       If True, populate GeneratedFile objects but do NOT write.
            force:         If True, overwrite existing files.

        Returns:
            List of GeneratedFile objects (one per generated file + task file).

        Raises:
            ValueError: If *scaffold_type* is not one of the known types.
        """
        if scaffold_type not in _SCAFFOLD_TYPES:
            raise ValueError(
                f"Unknown scaffold type {scaffold_type!r}. "
                f"Expected one of: {', '.join(sorted(_SCAFFOLD_TYPES))}."
            )

        kinds = _SCAFFOLD_TYPES[scaffold_type]
        results: list[GeneratedFile] = []

        for kind in kinds:
            gf = self._render_one(kind, ctx, project_root)
            if not dry_run:
                if gf.path.exists() and not force:
                    gf.existed = True
                else:
                    gf.path.parent.mkdir(parents=True, exist_ok=True)
                    gf.path.write_text(gf.content, encoding="utf-8")
            results.append(gf)

        # Task file
        task_file = self._render_task(scaffold_type, ctx, results, codemind_dir)
        if not dry_run:
            task_file.path.parent.mkdir(parents=True, exist_ok=True)
            if task_file.path.exists() and not force:
                task_file.existed = True
            else:
                task_file.path.write_text(task_file.content, encoding="utf-8")
        results.append(task_file)

        return results

    # ── Private helpers ────────────────────────────────────────────────────

    def _render_one(self, kind: str, ctx: ScaffoldContext, project_root: Path) -> GeneratedFile:
        """Render a single template kind and return a GeneratedFile."""
        language = ctx.language
        # component type always uses typescript
        if kind == "service" and language == "typescript":
            ext = _TS_EXT
        elif language == "typescript":
            ext = _TS_EXT
        else:
            ext = _JAVA_EXT

        template_path = self._TEMPLATE_DIR / language / f"{kind}.{ext}.j2"
        if not template_path.exists():
            # TypeScript fallback: only "service" template exists
            template_path = self._TEMPLATE_DIR / language / f"service.{ext}.j2"

        content = self._render_template(template_path, ctx, kind)
        dest = self._destination(kind, ctx, ext, project_root)
        label = dest.name

        return GeneratedFile(path=dest, content=content, label=label)

    def _render_template(self, template_path: Path, ctx: ScaffoldContext, kind: str) -> str:
        """Render *template_path* with variables derived from *ctx*."""
        base = ctx.base_name
        pkg = self._kind_package(ctx.domain_package, kind, ctx.language)
        class_name = self._class_name(base, kind)

        variables = {
            "class_name":       class_name,
            "package":          pkg,
            "service_name":     f"{base}Service",
            "controller_name":  f"{base}Controller",
            "entity_name":      f"{base}Entity",
            "repository_name":  f"{base}Repository",
            "api_path":         ctx.api_path,
            "table_name":       ctx.table_name,
            "test_class_name":  f"{class_name}Test",
            "tested_class":     self._tested_class(base, kind),
        }

        if not _JINJA_AVAILABLE:
            # Minimal fallback: plain string formatting
            return self._simple_render(template_path.read_text(encoding="utf-8"), variables)

        env = Environment(
            loader=FileSystemLoader(str(template_path.parent)),
            autoescape=False,
            keep_trailing_newline=True,
        )
        tmpl = env.get_template(template_path.name)
        return tmpl.render(**variables)

    @staticmethod
    def _simple_render(template: str, variables: dict[str, str]) -> str:
        """Replace ``{{ var }}`` tokens without Jinja2."""
        for key, value in variables.items():
            template = template.replace("{{ " + key + " }}", value)
            template = template.replace("{{" + key + "}}", value)
        return template

    def _kind_package(self, domain_package: str, kind: str, language: str) -> str:
        """Append the layer sub-package for Java; return domain_package for TS."""
        if language != "java":
            return domain_package
        layer_map = {
            "service":    "service",
            "controller": "controller",
            "entity":     "entity",
            "repository": "repository",
            "test":       "service",  # test lives in same package as service
        }
        layer = layer_map.get(kind, kind)
        return f"{domain_package}.{layer}"

    @staticmethod
    def _class_name(base: str, kind: str) -> str:
        """Return the class name for *kind*."""
        if kind == "test":
            return f"{base}ServiceTest"
        suffix_map = {
            "service":    "Service",
            "controller": "Controller",
            "entity":     "Entity",
            "repository": "Repository",
        }
        suffix = suffix_map.get(kind, "")
        return f"{base}{suffix}"

    @staticmethod
    def _tested_class(base: str, kind: str) -> str:
        """For test templates: the class under test."""
        return f"{base}Service"

    def _destination(
        self, kind: str, ctx: ScaffoldContext, ext: str, project_root: Path
    ) -> Path:
        """Compute absolute output path for a generated file."""
        class_name = self._class_name(ctx.base_name, kind)
        pkg = self._kind_package(ctx.domain_package, kind, ctx.language)

        if ctx.language == "java":
            src_root = project_root / ctx.java_src_root
            pkg_path = pkg.replace(".", "/")
            if kind == "test":
                # Mirror layout: replace src/main/java with src/test/java
                test_root = str(ctx.java_src_root).replace("src/main/java", "src/test/java")
                src_root = project_root / test_root
            return src_root / pkg_path / f"{class_name}.{ext}"
        else:
            # TypeScript: flat in the domain directory
            domain_dir = _to_kebab(ctx.base_name)
            src_root = project_root / ctx.ts_src_root
            return src_root / domain_dir / f"{_to_kebab(ctx.base_name)}.service.{ext}"

    def _render_task(
        self,
        scaffold_type: str,
        ctx: ScaffoldContext,
        source_files: list[GeneratedFile],
        codemind_dir: Path,
    ) -> GeneratedFile:
        """Build the .codemind/tasks/<name>.tasks.md checklist."""
        base = ctx.base_name
        snake = _to_snake(base)
        today = date.today().isoformat()

        file_list = "\n".join(f"- `{gf.label}`" for gf in source_files)

        checklist_items: list[str] = [
            f"Implement {base}Service business logic",
        ]
        if scaffold_type in ("module", "api"):
            checklist_items += [
                f"Define fields in {base}Entity",
                f"Add custom queries in {base}Repository",
                f"Set up REST endpoints in {base}Controller",
            ]
        checklist_items += [
            "Write unit tests",
            "Run `codemind scan` to update the knowledge graph",
        ]

        checklist = "\n".join(f"- [ ] {item}" for item in checklist_items)

        content = (
            f"# {base} — Implementation Tasks\n"
            f"*Generated by `codemind scaffold {scaffold_type} {base}` on {today}*\n\n"
            f"## Files Created\n"
            f"{file_list}\n\n"
            f"## Implementation Checklist\n"
            f"{checklist}\n"
        )

        task_path = codemind_dir / "tasks" / f"{snake}.tasks.md"
        return GeneratedFile(path=task_path, content=content, label=f"{snake}.tasks.md")
