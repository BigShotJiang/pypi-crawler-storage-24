"""Health checker orchestrator — runs all checks and produces a HealthReport."""

from __future__ import annotations

from dataclasses import dataclass, field

from codemind.core.graph import CodeGraph


@dataclass
class HealthViolation:
    """A single health rule violation.

    Attributes:
        rule:       Rule name: "naming" | "layer_violation" | "missing_test" |
                    "orphan" | "domain_incomplete".
        component:  Name of the offending component or domain.
        message:    Human-readable description of the problem.
        severity:   "error" (blocks commit) or "warning" (advisory only).
        file:       Relative file path for context; empty string if not applicable.
    """

    rule: str
    component: str
    message: str
    severity: str
    file: str = ""


@dataclass
class HealthReport:
    """Aggregated result of all health checks.

    Attributes:
        violations:    All violations found across all checks.
        total_checked: Number of nodes inspected.
        checks_run:    Names of checks that were executed.
    """

    violations: list[HealthViolation] = field(default_factory=list)
    total_checked: int = 0
    checks_run: list[str] = field(default_factory=list)

    @property
    def errors(self) -> list[HealthViolation]:
        """Violations with severity == "error" (commit-blocking)."""
        return [v for v in self.violations if v.severity == "error"]

    @property
    def warnings(self) -> list[HealthViolation]:
        """Violations with severity == "warning" (advisory)."""
        return [v for v in self.violations if v.severity == "warning"]

    @property
    def passed(self) -> bool:
        """True when there are no error-level violations."""
        return len(self.errors) == 0


class HealthChecker:
    """Run all health checks against a CodeGraph and return a HealthReport.

    Usage::

        report = HealthChecker().run(graph)
        if not report.passed:
            ...  # handle errors
    """

    def run(self, graph: CodeGraph, quick: bool = False) -> HealthReport:
        """Execute health checks.

        Args:
            graph: The code graph to inspect.
            quick: If True, only run fast checks (naming + layer violations).
                   Deep checks (orphan, missing_test, domain_incomplete) are skipped.

        Returns:
            A populated HealthReport.
        """
        from codemind.health.dependency_check import DomainCompletenessCheck, OrphanCheck
        from codemind.health.pattern_check import LayerViolationCheck, NamingCheck
        from codemind.health.test_coverage import TestCoverageCheck

        report = HealthReport()

        # ── Fast checks (always run) ──
        naming = NamingCheck()
        report.violations.extend(naming.check(graph))
        report.checks_run.append("naming")

        layer = LayerViolationCheck()
        report.violations.extend(layer.check(graph))
        report.checks_run.append("layer_violation")

        if not quick:
            # ── Deep checks ──
            test_cov = TestCoverageCheck()
            report.violations.extend(test_cov.check(graph))
            report.checks_run.append("missing_test")

            orphan = OrphanCheck()
            report.violations.extend(orphan.check(graph))
            report.checks_run.append("orphan")

            domain = DomainCompletenessCheck()
            report.violations.extend(domain.check(graph))
            report.checks_run.append("domain_incomplete")

        report.total_checked = len(graph.nodes)
        return report
