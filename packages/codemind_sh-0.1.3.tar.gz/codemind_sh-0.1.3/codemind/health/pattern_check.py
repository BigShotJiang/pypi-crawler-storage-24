"""Pattern checks — naming conventions and layer violation detection."""

from __future__ import annotations

from codemind.core.graph import (
    EDGE_INJECTS,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
    NODE_SERVICE,
    CodeGraph,
)
from codemind.health.checker import HealthViolation

# Acceptable name suffixes per node type.
# Multiple values cover common framework variants (JAX-RS "Resource", DAO pattern, etc.).
_EXPECTED_SUFFIXES: dict[str, list[str]] = {
    NODE_SERVICE:    ["Service"],
    NODE_CONTROLLER: ["Controller", "Resource"],
    NODE_REPOSITORY: ["Repository", "Repo", "Dao"],
    NODE_ENTITY:     ["Entity", "Model"],
}


class NamingCheck:
    """Verify that component names match their semantic type.

    A service node whose name does not end in "Service" is confusing and
    often a sign that the graph parser has mis-classified it, or that the
    team's naming convention has drifted.
    """

    def check(self, graph: CodeGraph) -> list[HealthViolation]:
        """Return a warning for every node whose name contradicts its type."""
        violations: list[HealthViolation] = []
        for node in graph.nodes.values():
            if node.language not in ("java", "typescript"):
                continue
            expected = _EXPECTED_SUFFIXES.get(node.type)
            if expected is None:
                continue
            if not any(node.name.endswith(s) for s in expected):
                quoted = " or ".join(repr(s) for s in expected)
                violations.append(HealthViolation(
                    rule="naming",
                    component=node.name,
                    message=(
                        f"{node.name!r} is classified as '{node.type}' "
                        f"but its name does not end in {quoted}"
                    ),
                    severity="warning",
                    file=node.file,
                ))
        return violations


class LayerViolationCheck:
    """Detect controllers that directly inject repositories.

    Controllers should delegate persistence to a service layer.
    A direct controller → repository injection bypasses transactional
    boundaries and business logic, making the architecture fragile.
    """

    def check(self, graph: CodeGraph) -> list[HealthViolation]:
        """Return an error for every controller → repository injection edge."""
        violations: list[HealthViolation] = []
        for node in graph.nodes.values():
            if node.type != NODE_CONTROLLER:
                continue
            for edge in graph.edges_from(node.id):
                if edge.kind != EDGE_INJECTS:
                    continue
                target = graph.resolve(edge.target)
                if target is not None and target.type == NODE_REPOSITORY:
                    violations.append(HealthViolation(
                        rule="layer_violation",
                        component=node.name,
                        message=(
                            f"{node.name} (controller) directly injects "
                            f"{target.name} (repository) — "
                            f"delegate persistence to a service layer"
                        ),
                        severity="error",
                        file=node.file,
                    ))
        return violations
