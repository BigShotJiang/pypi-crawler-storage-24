"""Dependency checks — orphan nodes and incomplete domain detection."""

from __future__ import annotations

from collections import defaultdict

from codemind.core.graph import (
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
    NODE_SERVICE,
    CodeGraph,
)
from codemind.health.checker import HealthViolation

# Only these structural types are checked for orphan status.
# Interface / enum / configuration orphans are expected and intentionally ignored.
_STRUCTURAL_TYPES = frozenset({NODE_SERVICE, NODE_CONTROLLER, NODE_ENTITY, NODE_REPOSITORY})


class OrphanCheck:
    """Detect structural nodes that have no connections whatsoever.

    An orphan service or repository suggests a component that was created
    but never wired into the application.  It may be dead code.
    """

    def check(self, graph: CodeGraph) -> list[HealthViolation]:
        """Return a warning for every isolated structural node."""
        violations: list[HealthViolation] = []
        for node in graph.nodes.values():
            if node.type not in _STRUCTURAL_TYPES:
                continue
            if node.language not in ("java", "typescript"):
                continue
            has_out = bool(graph.edges_from(node.id))
            has_in = bool(graph.edges_to(node.id))
            if not has_out and not has_in:
                violations.append(HealthViolation(
                    rule="orphan",
                    component=node.name,
                    message=(
                        f"{node.name} ({node.type}) has no connections — "
                        f"it is not injected by or injecting anything"
                    ),
                    severity="warning",
                    file=node.file,
                ))
        return violations


class DomainCompletenessCheck:
    """Detect domains with structurally incomplete layer stacks.

    Two rules are enforced (as warnings):
    - A domain that has a controller but no service layer.
    - A domain that has both a service and an entity but no repository.
    """

    def check(self, graph: CodeGraph) -> list[HealthViolation]:
        """Return warnings for every incomplete domain."""
        violations: list[HealthViolation] = []

        # Group Java nodes by domain key (5th or 4th package segment)
        domain_types: dict[str, set[str]] = defaultdict(set)

        for node in graph.nodes.values():
            if node.language != "java":
                continue
            parts = node.package.split(".")
            if len(parts) >= 5:
                domain = parts[4]
            elif len(parts) >= 4:
                domain = parts[3]
            else:
                continue
            domain_types[domain].add(node.type)

        for domain, types in domain_types.items():
            # Controller without a service layer
            if NODE_CONTROLLER in types and NODE_SERVICE not in types:
                violations.append(HealthViolation(
                    rule="domain_incomplete",
                    component=domain,
                    message=(
                        f"Domain '{domain}' has a controller but no service — "
                        f"controllers should delegate business logic to a service"
                    ),
                    severity="warning",
                    file="",
                ))
            # Service + entity but no repository
            if (NODE_SERVICE in types and NODE_ENTITY in types
                    and NODE_REPOSITORY not in types):
                violations.append(HealthViolation(
                    rule="domain_incomplete",
                    component=domain,
                    message=(
                        f"Domain '{domain}' has a service and entity but no repository — "
                        f"add a repository or remove the entity"
                    ),
                    severity="warning",
                    file="",
                ))
        return violations
