"""Test coverage check — detects services and controllers without test classes."""

from __future__ import annotations

from codemind.core.graph import (
    NODE_CONTROLLER,
    NODE_SERVICE,
    CodeGraph,
)
from codemind.health.checker import HealthViolation

# Node types that should have a corresponding test
_TESTED_TYPES = frozenset({NODE_SERVICE, NODE_CONTROLLER})

# Suffixes that identify a test class
_TEST_SUFFIXES = ("Test", "Tests", "Spec", "IT")


class TestCoverageCheck:
    """Check that each service and controller has a corresponding test class.

    Looks for a node in the graph whose name starts with the component name
    and ends in a recognised test suffix (Test, Tests, Spec, IT).

    Note: this relies on test classes being present in the scanned source tree.
    It does NOT read the file system directly.
    """

    def check(self, graph: CodeGraph) -> list[HealthViolation]:
        """Return a warning for every service/controller with no visible test."""
        violations: list[HealthViolation] = []

        # Collect names of all test nodes in the graph
        test_names: set[str] = {
            node.name
            for node in graph.nodes.values()
            if any(node.name.endswith(s) for s in _TEST_SUFFIXES)
        }

        for node in graph.nodes.values():
            if node.type not in _TESTED_TYPES:
                continue
            if node.language not in ("java", "typescript"):
                continue
            # A test exists if any test node name begins with this node's name
            has_test = any(t.startswith(node.name) for t in test_names)
            if not has_test:
                violations.append(HealthViolation(
                    rule="missing_test",
                    component=node.name,
                    message=(
                        f"No test class found for {node.name} "
                        f"(expected {node.name}Test or similar)"
                    ),
                    severity="warning",
                    file=node.file,
                ))
        return violations
