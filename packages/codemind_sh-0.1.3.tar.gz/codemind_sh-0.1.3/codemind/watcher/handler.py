"""File system watcher — keeps graph.json always current.

When ``codemind serve --watch`` is running, a watchdog Observer monitors
the project directory.  Every time a ``.java`` or ``.ts`` file is saved:

1. ``GraphChangeHandler.on_modified`` fires.
2. ``GraphBuilder.rebuild_file()`` re-parses the changed file.
3. The graph is patched in-place (old nodes/edges for that file removed,
   new ones added).
4. graph.json is atomically overwritten.

This means the graph is never more than one file-save out of date.
Latency is typically <100 ms for a single file on a modern machine.
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from codemind.core.graph import CodeGraph
from codemind.graph.builder import GraphBuilder

logger = logging.getLogger(__name__)

# Debounce: if the same file triggers multiple events within this window
# (e.g. editor writes twice in quick succession), only process once.
_DEBOUNCE_SECONDS = 0.5

# File extensions to watch
_WATCH_EXTS = frozenset({".java", ".ts", ".tsx"})


class GraphChangeHandler(FileSystemEventHandler):
    """watchdog event handler that incrementally updates the graph on file changes.

    Args:
        graph:        The in-memory CodeGraph to keep current.
        project_root: Absolute project root directory.
        codemind_dir: The ``.codemind/`` directory (graph.json lives here).
        builder:      GraphBuilder instance (shared, thread-safe for our use).
        on_update:    Optional callback invoked after each successful patch.
    """

    def __init__(
        self,
        graph: CodeGraph,
        project_root: Path,
        codemind_dir: Path,
        builder: GraphBuilder | None = None,
        on_update: object = None,
    ) -> None:
        super().__init__()
        self.graph = graph
        self.project_root = project_root
        self.codemind_dir = codemind_dir
        self.builder = builder or GraphBuilder()
        self.on_update = on_update

        # Debounce: {path_str → scheduled timer}
        self._timers: dict[str, threading.Timer] = {}
        self._lock = threading.Lock()

    # ── watchdog callbacks ────────────────────────────────────────────────────

    def on_modified(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        self._schedule(Path(str(event.src_path)))

    def on_created(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        self._schedule(Path(str(event.src_path)))

    def on_deleted(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        path = Path(str(event.src_path))
        if path.suffix in _WATCH_EXTS:
            self._handle_delete(path)

    def on_moved(self, event: FileSystemEvent) -> None:
        """Handle rename: remove old path, add new path."""
        if event.is_directory:
            return
        old = Path(str(event.src_path))
        new = Path(str(event.dest_path))
        if old.suffix in _WATCH_EXTS:
            self._handle_delete(old)
        if new.suffix in _WATCH_EXTS:
            self._schedule(new)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _schedule(self, path: Path) -> None:
        """Debounce: cancel any pending timer for this file and re-schedule."""
        if path.suffix not in _WATCH_EXTS:
            return
        # Skip TypeScript declaration files (.d.ts) — compiler output, not source
        if path.name.endswith(".d.ts"):
            return
        key = str(path)
        with self._lock:
            existing = self._timers.pop(key, None)
            if existing:
                existing.cancel()
            timer = threading.Timer(_DEBOUNCE_SECONDS, self._process, args=(path,))
            self._timers[key] = timer
            timer.start()

    def _process(self, path: Path) -> None:
        """Re-parse the file and patch the graph."""
        with self._lock:
            self._timers.pop(str(path), None)
        try:
            logger.debug("Rebuilding graph for changed file: %s", path.name)
            self.builder.rebuild_file(
                path, self.project_root, self.graph, self.codemind_dir
            )
            logger.debug("Graph updated — %d nodes", len(self.graph.nodes))
            if callable(self.on_update):
                self.on_update(path, self.graph)
        except Exception as exc:
            logger.warning("Failed to rebuild graph for %s: %s", path.name, exc)

    def _handle_delete(self, path: Path) -> None:
        """Remove nodes/edges for a deleted file."""
        try:
            rel = path.relative_to(self.project_root)
            file_rel = "/".join(rel.parts)
            self.graph.remove_file(file_rel)
            from codemind.graph.store import GraphStore
            GraphStore().save(self.graph, self.codemind_dir)
            logger.debug("Removed deleted file from graph: %s", file_rel)
        except Exception as exc:
            logger.warning("Failed to remove deleted file from graph: %s", exc)


# ── Watcher lifecycle ──────────────────────────────────────────────────────────


class CodeMindWatcher:
    """Manages the watchdog Observer lifecycle.

    Usage::

        watcher = CodeMindWatcher(graph, project_root, codemind_dir)
        watcher.start()   # non-blocking
        # ... run MCP server ...
        watcher.stop()
    """

    def __init__(
        self,
        graph: CodeGraph,
        project_root: Path,
        codemind_dir: Path,
        on_update: object = None,
    ) -> None:
        self._handler = GraphChangeHandler(
            graph=graph,
            project_root=project_root,
            codemind_dir=codemind_dir,
            on_update=on_update,
        )
        self._observer = Observer()
        self._observer.schedule(self._handler, str(project_root), recursive=True)

    def start(self) -> None:
        """Start monitoring. Non-blocking."""
        self._observer.start()
        logger.info("CodeMind file watcher started.")

    def stop(self) -> None:
        """Stop monitoring and clean up."""
        self._observer.stop()
        self._observer.join()
        logger.info("CodeMind file watcher stopped.")

    def __enter__(self) -> CodeMindWatcher:
        self.start()
        return self

    def __exit__(self, *_) -> None:
        self.stop()
