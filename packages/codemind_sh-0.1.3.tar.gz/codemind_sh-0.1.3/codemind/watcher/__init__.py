"""File watcher — incremental graph updates on every file save."""
