"""Entry point for `python -m codemind`."""

from codemind.cli import app

if __name__ == "__main__":
    app()
