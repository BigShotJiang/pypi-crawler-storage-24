"""CodeMind CLI — All commands defined here."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.tree import Tree
from rich import print as rprint

from codemind import __version__
from codemind.core.config import CodemindConfig, StructureConfig, TechStackConfig
from codemind.core.project import CodemindProject
from codemind.core.constants import CODEMIND_DIR
from codemind.license.license import LicenseManager
from codemind.license.enforcer import LicenseEnforcer
from codemind.license.client import LicenseClient

# ── App Setup ──
app = typer.Typer(
    name="codemind",
    help="🧠 CodeMind — Local-first intelligence layer for software projects.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
console = Console()
# MCP protocol owns stdout — all serve-command output must go to stderr
_err = Console(stderr=True)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"[cyan]CodeMind[/cyan] v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None, "--version", "-v", help="Show version.", callback=version_callback, is_eager=True
    ),
) -> None:
    """🧠 CodeMind — Your codebase finally remembers everything."""
    pass


# ══════════════════════════════════════
# INIT COMMAND
# ══════════════════════════════════════
@app.command()
def init(
    path: Optional[Path] = typer.Argument(None, help="Project directory (default: current)"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Project name"),
    non_interactive: bool = typer.Option(False, "--yes", "-y", help="Skip prompts, use defaults"),
) -> None:
    """Initialize CodeMind in a project directory.

    Creates a .codemind/ directory with knowledge files, templates, and configuration.
    """
    project_root = (path or Path.cwd()).resolve()

    # ── License check ──────────────────────────────────────────────────────────
    _lic_mgr = LicenseManager()
    if not _lic_mgr.exists():
        # First run — generate trial key (server → local fallback)
        console.print()
        console.print("  [cyan]◆[/cyan]  First run detected — activating free license…")
        trial_state = LicenseClient().generate_trial()
        _lic_mgr.save(trial_state)
        console.print(
            f"  [green]✓[/green]  Free license activated ([bold]{trial_state.license_key}[/bold]). "
            "1 project included — no credit card required."
        )
        # Optional email for license recovery
        console.print()
        _email = Prompt.ask(
            "  [dim]Add your email to recover this key if you reinstall "
            "(optional — press Enter to skip)[/dim]\n  Email",
            default="",
        )
        if _email.strip():
            trial_state.email = _email.strip()
            _lic_mgr.save(trial_state)
            LicenseClient().register_email(trial_state.license_key, trial_state.email)
            console.print("  [green]✓[/green]  Email saved — we'll use it to restore your key.")
        else:
            console.print("  [dim]Skipped. You can always recover via your license key.[/dim]")

    _lic_state = _lic_mgr.load()

    # Load project_id if project already exists (reinit case)
    _existing_project = CodemindProject(project_root)
    _project_id = _existing_project.config.project_id if _existing_project.is_initialized else ""

    _check = LicenseEnforcer().check_init(_lic_state, _project_id)
    if not _check.allowed:
        console.print()
        console.print(f"  [red]✗[/red]  {_check.reason}")
        console.print()
        raise typer.Exit(1)
    if _check.warning:
        console.print()
        console.print(f"  [yellow]⚠[/yellow]  {_check.warning}")
    # ── End license check ──────────────────────────────────────────────────────

    # Check if already initialized
    if (project_root / CODEMIND_DIR).exists():
        console.print(
            f"[yellow]⚠[/yellow]  CodeMind already initialized in [cyan]{project_root}[/cyan]"
        )
        if not Confirm.ask("  Reinitialize? (existing files will be preserved)"):
            raise typer.Exit()

    console.print()
    console.print(
        Panel(
            "[bold cyan]🧠 CodeMind — Project Initialization[/bold cyan]\n\n"
            "This will create a [green].codemind/[/green] directory in your project\n"
            "with knowledge files, templates, and configuration.",
            border_style="cyan",
        )
    )
    console.print()

    # ── Gather project info ──
    config = CodemindConfig()

    if non_interactive:
        config.project_name = name or project_root.name
        config.project_description = ""
        config.tech_stack = _detect_tech_stack(project_root)
    else:
        # Project name
        default_name = name or project_root.name
        config.project_name = Prompt.ask(
            "  [bold]Project name[/bold]", default=default_name
        )

        # Description
        config.project_description = Prompt.ask(
            "  [bold]Short description[/bold]", default=""
        )

        # Auto-detect tech stack
        detected = _detect_tech_stack(project_root)
        if detected:
            console.print()
            console.print("  [green]✓[/green] Detected tech stack:")
            if detected.backend_language:
                console.print(
                    f"    Backend: [cyan]{detected.backend_framework or detected.backend_language}"
                    f"[/cyan]"
                )
            if detected.frontend_language:
                console.print(
                    f"    Frontend: [cyan]{detected.frontend_framework or detected.frontend_language}"
                    f"[/cyan]"
                )
            if detected.database_type:
                console.print(f"    Database: [cyan]{detected.database_type}[/cyan]")
            console.print()

            if Confirm.ask("  Use detected tech stack?", default=True):
                config.tech_stack = detected

    # ── Project structure (fullstack monorepo?) ──
    if not non_interactive:
        console.print()
        is_fullstack = Confirm.ask(
            "  [bold]Is this a fullstack project with separate frontend/backend folders?[/bold]",
            default=False,
        )
        if is_fullstack:
            config.structure.project_type = "fullstack"
            # Suggest common frontend folder names found in project_root
            _fe_hint = _detect_frontend_path(project_root)
            _be_hint = _detect_backend_path(project_root)
            config.structure.frontend_path = Prompt.ask(
                "  [bold]Frontend folder[/bold] (relative path)",
                default=_fe_hint or "frontend/",
            )
            config.structure.backend_path = Prompt.ask(
                "  [bold]Backend folder[/bold] (relative path)",
                default=_be_hint or "backend/",
            )

    # ── Initialize ──
    project = CodemindProject(project_root)
    project.initialize(config)

    # Register project as Class A (activated during valid license)
    _lic_mgr.add_activated_project(project.config.project_id)
    # Best-effort: also tell the server so Class A survives key migration
    if project.config.project_id and _lic_state.license_key:
        try:
            updated = LicenseClient().validate(
                _lic_state.license_key, project.config.project_id
            )
            if updated:
                _lic_mgr.save(updated)
        except Exception:
            pass  # offline — local activated_projects is enough

    # ── Show result ──
    console.print()
    console.print(f"  [green]✓[/green] CodeMind initialized in [cyan]{project_root}[/cyan]")
    console.print()

    # Show directory tree
    tree = Tree(f"[bold]{CODEMIND_DIR}/[/bold]", guide_style="dim")
    _build_tree(project.codemind_dir, tree, project_root)
    console.print(tree)

    # ── Auto-connect AI tools ─────────────────────────────────────────────────
    from codemind.mcp.connect import connect_all, detected_tools
    _connect_results = connect_all(project_root)
    console.print()
    if _connect_results:
        for _r in _connect_results:
            if _r.success and not _r.already_configured:
                console.print(
                    f"  [green]✓[/green]  {_r.label} configured — "
                    f"[dim]{_r.restart_hint}[/dim]"
                )
            elif _r.success and _r.already_configured:
                console.print(
                    f"  [green]✓[/green]  {_r.label} already configured"
                )
    else:
        console.print(
            "  [dim]○  No AI tools detected. "
            "Run [bold cyan]codemind connect[/bold cyan] after installing Claude Code or Cursor.[/dim]"
        )
    # ── End auto-connect ──────────────────────────────────────────────────────

    console.print()
    console.print("  [dim]Next steps:[/dim]")
    console.print("  [green]1.[/green] Run [bold cyan]codemind scan[/bold cyan] to build your knowledge graph")
    console.print("  [green]2.[/green] Run [bold cyan]codemind serve[/bold cyan] to start MCP for Claude Code / Cursor")
    console.print()


# ══════════════════════════════════════
# STATUS COMMAND
# ══════════════════════════════════════
@app.command()
def status(
    path: Optional[Path] = typer.Argument(None, help="Project directory"),
) -> None:
    """Show CodeMind project status and overview."""
    project = _get_project(path)

    config = project.config

    # Header
    console.print()
    console.print(
        Panel(
            f"[bold cyan]🧠 {config.project_name or 'Unnamed Project'}[/bold cyan]\n"
            f"[dim]{config.project_description}[/dim]",
            border_style="cyan",
            subtitle=f"CodeMind v{__version__}",
        )
    )

    # Tech stack
    ts = config.tech_stack
    if ts.backend_language or ts.frontend_language:
        console.print()
        console.print("  [bold]Tech Stack[/bold]")
        if ts.backend_language:
            console.print(
                f"    Backend:  [cyan]{ts.backend_framework} {ts.backend_version}"
                f"[/cyan] ({ts.backend_language})"
            )
        if ts.frontend_language:
            console.print(
                f"    Frontend: [cyan]{ts.frontend_framework} {ts.frontend_version}"
                f"[/cyan] ({ts.frontend_language})"
            )
        if ts.database_type:
            console.print(f"    Database: [cyan]{ts.database_type} {ts.database_version}[/cyan]")
        if ts.auth_provider:
            console.print(f"    Auth:     [cyan]{ts.auth_provider}[/cyan]")

    # Knowledge files status
    console.print()
    console.print("  [bold]Knowledge Files[/bold]")
    from codemind.core.constants import KNOWLEDGE_FILES

    for filename in KNOWLEDGE_FILES:
        filepath = project.knowledge_file(filename)
        if filepath.exists():
            size = filepath.stat().st_size
            if size > 200:  # More than just the header template
                console.print(f"    [green]●[/green] {filename} [dim]({_human_size(size)})[/dim]")
            else:
                console.print(f"    [yellow]○[/yellow] {filename} [dim](empty — needs scan)[/dim]")
        else:
            console.print(f"    [red]✗[/red] {filename} [dim](missing)[/dim]")

    # Modules
    if project.modules_dir.exists():
        modules = sorted(project.modules_dir.glob("*.md"))
        if modules:
            console.print()
            console.print(f"  [bold]Modules[/bold] ({len(modules)})")
            for mod in modules:
                name = mod.stem
                console.print(f"    [green]●[/green] {name}")

    # Tasks
    if project.tasks_dir.exists():
        tasks = sorted(project.tasks_dir.glob("*.tasks.md"))
        if tasks:
            console.print()
            console.print(f"  [bold]Task Lists[/bold] ({len(tasks)})")
            for task in tasks:
                name = task.stem.replace(".tasks", "")
                console.print(f"    [cyan]📋[/cyan] {name}")

    # Knowledge graph status
    console.print()
    console.print("  [bold]Knowledge Graph[/bold]")
    if project.graph_path.exists():
        from codemind.graph.store import GraphStore
        graph = GraphStore().load(project.codemind_dir)
        if graph:
            s = graph.stats()
            console.print(
                f"    [green]●[/green] graph.json — "
                f"[cyan]{s['total_nodes']:,}[/cyan] components, "
                f"[cyan]{s['total_edges']:,}[/cyan] connections"
            )
            console.print(f"    [dim]    Scanned: {graph.scanned_at[:19].replace('T', ' ')} UTC[/dim]")
        else:
            size = project.graph_path.stat().st_size
            console.print(f"    [green]●[/green] graph.json [dim]({_human_size(size)})[/dim]")
    else:
        console.print(
            "    [yellow]○[/yellow] graph.json [dim](run [bold cyan]codemind scan[/bold cyan])[/dim]"
        )

    console.print()


# ══════════════════════════════════════
# SCAN COMMAND
# ══════════════════════════════════════
@app.command()
def scan(
    path: Optional[Path] = typer.Argument(None, help="Project directory (default: current)"),
) -> None:
    """Analyze codebase and build the knowledge graph (graph.json).

    Parses all Java and TypeScript source files, extracts components and their
    typed connections (injects, calls, extends, implements), and writes the
    result to .codemind/graph.json.

    The graph is the single source of truth — always human-readable JSON,
    always git-diffable, always queryable via ``codemind query`` or MCP tools.
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

    from codemind.graph.builder import GraphBuilder

    project = _get_project(path)

    # ── License check ──────────────────────────────────────────────────────────
    _lic_mgr = LicenseManager()
    _lic_state = _lic_mgr.load()
    _project_id = project.config.project_id
    _graph_exists = project.graph_path.exists()

    # Legacy projects (pre-Phase 7) have no project_id — treat as Class A
    if not _project_id and _graph_exists:
        _project_id = "__legacy__"
        if "__legacy__" not in _lic_state.activated_projects:
            _lic_mgr.add_activated_project("__legacy__")
            _lic_state = _lic_mgr.load()

    _scan_check = LicenseEnforcer().check_scan(_lic_state, _project_id, _graph_exists)
    if not _scan_check.allowed:
        console.print()
        console.print(f"  [red]✗[/red]  {_scan_check.reason}")
        console.print()
        raise typer.Exit(1)
    if _scan_check.warning:
        console.print()
        console.print(f"  [yellow]⚠[/yellow]  {_scan_check.warning}")

    _ai_ok = LicenseEnforcer().ai_allowed(_lic_state)
    # ── End license check ──────────────────────────────────────────────────────

    console.print()
    console.print(
        f"  [cyan]Scanning[/cyan] [bold]{project.config.project_name or project.root.name}[/bold]…"
    )
    console.print()

    ai_notes: list[str] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("  [cyan]{task.description}[/cyan]"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        t = progress.add_task("Parsing source files and building knowledge graph…", total=None)

        def _scan_progress(msg: str) -> None:
            if msg.startswith("note:") or "ANTHROPIC_API_KEY" in msg:
                ai_notes.append(msg)
            else:
                progress.update(t, description=msg)

        graph = GraphBuilder().build(
            project_root=project.root,
            codemind_dir=project.codemind_dir,
            project_name=project.config.project_name or project.root.name,
            progress_callback=_scan_progress,
            ai_enrich=_ai_ok,
        )
        progress.remove_task(t)

    # Ensure project is registered as Class A after every successful scan
    _real_id = project.config.project_id
    if _real_id:
        _lic_mgr.add_activated_project(_real_id)

    # ── Cross-layer routing enrichment (fullstack projects) ──────────────────
    if project.config.structure.project_type == "fullstack" or _has_fullstack_signals(graph):
        from codemind.router.route_extractor import enrich_graph_with_routes
        from codemind.router.call_extractor import enrich_graph_with_api_calls
        from codemind.router.linker import create_cross_layer_edges, route_first_link
        from codemind.graph.store import GraphStore

        _routes_added = enrich_graph_with_routes(graph, project.root)
        _calls_added = enrich_graph_with_api_calls(graph, project.root)
        _cross_edges = create_cross_layer_edges(graph)
        # Route-first pass: catch any connections missed by call extraction
        # (works for any URL construction pattern: constants, env vars, helpers…)
        _cross_edges += route_first_link(graph, project.root)
        if _cross_edges > 0:
            GraphStore().save(graph, project.codemind_dir)
            console.print(
                f"  [green]✓[/green] Cross-layer routing: "
                f"[cyan]{_cross_edges}[/cyan] frontend→backend connection(s) mapped"
            )
        elif _routes_added > 0 or _calls_added > 0:
            GraphStore().save(graph, project.codemind_dir)
    # ── End cross-layer routing ───────────────────────────────────────────────

    # Generate knowledge files from graph
    from codemind.knowledge.generator import KnowledgeGenerator
    written = KnowledgeGenerator().generate_all(graph, project.codemind_dir, project.config)
    console.print(f"  [green]✓[/green] {len(written)} knowledge file(s) written")
    for label in written:
        console.print(f"    [dim]{label}[/dim]")

    stats = graph.stats()
    nodes = stats.get("total_nodes", 0)
    edges = stats.get("total_edges", 0)

    console.print(f"  [green]✓[/green] graph.json built")
    console.print()
    console.print("  [bold]Graph summary[/bold]")
    console.print(f"    Components (nodes): [cyan]{nodes:,}[/cyan]")
    console.print(f"    Connections (edges): [cyan]{edges:,}[/cyan]")

    if graph.languages:
        console.print(f"    Languages: [cyan]{', '.join(graph.languages)}[/cyan]")
    if graph.frameworks:
        console.print(f"    Frameworks: [cyan]{', '.join(graph.frameworks)}[/cyan]")

    # Type breakdown
    type_counts: dict[str, int] = {}
    for key, val in stats.items():
        if key.startswith("type_") and isinstance(val, int) and val > 0:
            type_counts[key[5:]] = val
    if type_counts:
        breakdown = ", ".join(
            f"{count} {t}" for t, count in sorted(type_counts.items(), key=lambda x: -x[1])
        )
        console.print(f"    Types: [dim]{breakdown}[/dim]")

    # Show AI enhancement notes (unsupported stacks, gap count)
    for note in ai_notes:
        clean = note.replace("note: ", "").strip()
        console.print(f"\n  [yellow]○[/yellow]  [dim]{clean}[/dim]")

    console.print()
    console.print("  [dim]To keep the graph live as you code:[/dim]")
    console.print("    [bold cyan]codemind watch[/bold cyan]   [dim]— file watcher only[/dim]")
    console.print("    [bold cyan]codemind serve[/bold cyan]   [dim]— MCP + file watcher, for AI tools[/dim]")
    console.print()


# ══════════════════════════════════════
# WATCH COMMAND
# ══════════════════════════════════════
@app.command()
def watch(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
) -> None:
    """Watch for file changes and keep graph.json current.

    Monitors .java, .ts, .tsx, and .py files in your project.
    Every save patches graph.json in under 100 ms — no full rescan needed.

    Use this when you don't need the MCP server (e.g. CLI-only workflow).
    For AI tool integration use ``codemind serve`` instead (includes the watcher).

    Press Ctrl+C to stop.
    """
    import time
    from datetime import datetime

    from codemind.core.graph import CodeGraph
    from codemind.graph.store import GraphStore
    from codemind.watcher.handler import CodeMindWatcher

    project = _get_project(path)

    graph = GraphStore().load(project.codemind_dir)
    if graph is None:
        console.print(
            "\n  [red]✗[/red]  No graph.json found. "
            "Run [bold cyan]codemind scan[/bold cyan] first.\n"
        )
        raise typer.Exit(1)

    node_count = len(graph.nodes)
    edge_count = len(graph.edges)

    console.print()
    console.print(
        Panel(
            f"[bold cyan]CodeMind — File Watcher[/bold cyan]\n\n"
            f"Project:  [bold]{project.config.project_name or project.root.name}[/bold]\n"
            f"Watching: [green]{project.root}[/green]\n\n"
            f"[dim]Tracking .java · .ts · .tsx · .py  |  Press [bold]Ctrl+C[/bold] to stop[/dim]",
            border_style="cyan",
        )
    )
    console.print()
    console.print(
        f"  [green]●[/green]  Watcher active — "
        f"[cyan]{node_count:,}[/cyan] nodes · [cyan]{edge_count:,}[/cyan] edges in graph"
    )
    console.print()

    def _on_update(changed_path: Path, g: CodeGraph) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        console.print(
            f"  [green]✓[/green]  [dim]{ts}[/dim]  "
            f"[cyan]{changed_path.name}[/cyan]  →  "
            f"[bold]{len(g.nodes):,}[/bold] nodes · [bold]{len(g.edges):,}[/bold] edges"
        )

    try:
        with CodeMindWatcher(
            graph, project.root, project.codemind_dir, on_update=_on_update
        ):
            while True:
                time.sleep(0.5)
    except KeyboardInterrupt:
        console.print()
        console.print("  [yellow]●[/yellow]  Watcher stopped.")
        console.print()


# ══════════════════════════════════════
# CONTEXT COMMAND
# ══════════════════════════════════════
@app.command()
def context(
    query: str = typer.Argument(..., help="What you want to do (e.g., 'add user authentication')"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    clipboard: bool = typer.Option(False, "--clipboard", "-c", help="Copy to clipboard"),
    tokens: int = typer.Option(8000, "--tokens", "-t", help="Max token budget"),
) -> None:
    """Generate context for an AI coding tool.

    Assembles relevant architecture, decisions, patterns, and dependencies
    based on your task description.
    """
    from codemind.context.engine import ContextEngine

    project = _get_project(path)

    console.print()
    console.print(f"  [cyan]🧠[/cyan] Generating context for: [bold]{query}[/bold]")
    console.print(f"  [dim]Token budget: {tokens:,}[/dim]")
    console.print()

    ctx = ContextEngine().get_context(query, project.codemind_dir, tokens)

    # Print context to terminal inside a panel for clarity
    from rich.markdown import Markdown
    console.print(Markdown(ctx))

    if clipboard:
        try:
            import pyperclip
            pyperclip.copy(ctx)
            console.print()
            console.print(f"  [green]✓[/green] Copied to clipboard ({len(ctx):,} chars)")
        except Exception:
            console.print()
            console.print("  [yellow]⚠[/yellow]  Could not copy to clipboard (pyperclip not available)")

    console.print()


# ══════════════════════════════════════
# NOTE COMMAND
# ══════════════════════════════════════
@app.command()
def note(
    text: str = typer.Argument(..., help="Quick annotation to add"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
) -> None:
    """Add a quick note/annotation to DECISIONS.md."""
    project = _get_project(path)

    from datetime import datetime

    decisions_path = project.knowledge_file("DECISIONS.md")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    entry = f"\n### Note — {timestamp}\n\n{text}\n"

    with open(decisions_path, "a", encoding="utf-8") as f:
        f.write(entry)

    console.print(f"  [green]✓[/green] Note added to DECISIONS.md")


# ══════════════════════════════════════
# DECIDE COMMAND
# ══════════════════════════════════════
@app.command()
def decide(
    summary: Optional[str] = typer.Argument(None, help="One-line summary of what was done"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    components: Optional[str] = typer.Option(
        None, "--components", "-c",
        help="Comma-separated component names (e.g. 'KpiAlertService,EmailService')",
    ),
    reason: Optional[str] = typer.Option(
        None, "--reason", "-r", help="Business reason for the decision"
    ),
    pattern_notes: Optional[str] = typer.Option(
        None, "--pattern", help="Optional pattern notes"
    ),
) -> None:
    """Record an architectural decision into .codemind/decisions/.

    Examples:

      codemind decide "Add email alert on KPI drop"
        --components KpiAlertService,EmailService
        --reason "Faculty head must be notified when KPI < 70%"

      codemind decide   (interactive — will prompt for all fields)
    """
    from codemind.mcp.decisions import record_decision
    from codemind.graph.store import GraphStore

    project = _get_project(path)

    console.print()

    # ── Collect inputs (flags or interactive prompts) ──
    if not summary:
        summary = typer.prompt("  Summary (one-line: what was done)")

    if components is None:
        comp_input = typer.prompt(
            "  Components (comma-separated, Enter to skip)", default=""
        )
    else:
        comp_input = components

    component_names = [c.strip() for c in comp_input.split(",") if c.strip()]

    if not reason:
        reason = typer.prompt("  Business reason (why was this done?)")

    # ── Enrich component names from live graph ──
    graph = GraphStore().load(project.codemind_dir)
    enriched: list[str] = []
    unknown: list[str] = []
    for name in component_names:
        if graph:
            node = graph.resolve(name)
            if node:
                enriched.append(f"{node.name} ({node.type}) — {node.package}")
                continue
        enriched.append(f"{name} (new)")
        unknown.append(name)

    # ── Write the decision ──
    path_written = record_decision(
        project.codemind_dir,
        summary=summary,
        components=enriched,
        reason=reason,
        pattern_notes=pattern_notes or "",
    )

    # ── Confirmation ──
    console.print()
    console.print(f"  [green]✓[/green] Decision recorded: [cyan]{path_written.name}[/cyan]")
    if enriched:
        for comp in enriched:
            tag = "[yellow](new)[/yellow]" if "(new)" in comp else "[green](graph)[/green]"
            console.print(f"    {tag} {comp}")
    if not graph and component_names:
        console.print(
            "  [dim]  Tip: run [bold cyan]codemind scan[/bold cyan] first to enrich "
            "component names with type + package.[/dim]"
        )
    console.print()
    console.print(
        "  [dim]Use [bold cyan]codemind decisions[/bold cyan] to review recent decisions.[/dim]"
    )
    console.print()


# ══════════════════════════════════════
# DECISIONS COMMAND
# ══════════════════════════════════════
@app.command()
def decisions(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    limit: int = typer.Option(5, "--limit", "-n", help="Number of decisions to show"),
    show: Optional[str] = typer.Option(
        None, "--show", "-s",
        help="Show full content of a decision by filename or slug (partial match ok)",
    ),
) -> None:
    """List or show decision records from .codemind/decisions/.

    Examples:

      codemind decisions              (list 5 most recent)

      codemind decisions --limit 10   (list 10 most recent)

      codemind decisions --show kpi-threshold   (show a specific decision)
    """
    from rich.markdown import Markdown
    from codemind.mcp.decisions import get_decisions

    project = _get_project(path)
    decisions_dir = project.codemind_dir / "decisions"

    console.print()

    # ── Show a single decision ──
    if show:
        if not decisions_dir.exists():
            console.print("  [yellow]○[/yellow]  No decisions recorded yet.")
            console.print(
                "  [dim]Use [bold cyan]codemind decide[/bold cyan] to record one.[/dim]"
            )
            console.print()
            return

        # Find the file — exact match first, then partial slug match
        candidates = sorted(decisions_dir.glob("*.md"), reverse=True)
        match = next(
            (f for f in candidates if show in f.name),
            None,
        )
        if not match:
            console.print(f"  [red]✗[/red]  No decision matching [cyan]{show!r}[/cyan]")
            console.print(
                "  [dim]Run [bold cyan]codemind decisions[/bold cyan] to see available decisions.[/dim]"
            )
            console.print()
            raise typer.Exit(1)

        console.print(
            Panel(
                Markdown(match.read_text(encoding="utf-8")),
                title=f"[cyan]{match.name}[/cyan]",
                border_style="cyan",
            )
        )
        console.print()
        return

    # ── List recent decisions ──
    records = get_decisions(project.codemind_dir, limit=limit)

    if not records:
        console.print("  [yellow]○[/yellow]  No decisions recorded yet.")
        console.print()
        console.print("  Record your first decision:")
        console.print(
            '  [bold cyan]codemind decide "What you built" --reason "Why you built it"[/bold cyan]'
        )
        console.print()
        return

    console.print(
        f"  [bold]Recent decisions[/bold] "
        f"[dim]({len(records)} of {len(list(decisions_dir.glob('*.md')))} total)[/dim]"
    )
    console.print()

    from rich.table import Table

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("File", style="cyan", no_wrap=True)
    table.add_column("Summary")

    for r in records:
        # Extract first heading from content as summary
        first_line = ""
        for line in r["content"].splitlines():
            if line.startswith("# "):
                first_line = line[2:].strip()
                break
        table.add_row(r["file"], first_line)

    console.print(table)
    console.print()
    console.print(
        "  [dim]Use [bold cyan]codemind decisions --show <slug>[/bold cyan] to read a full decision.[/dim]"
    )
    console.print()


# ══════════════════════════════════════
# QUERY COMMAND
# ══════════════════════════════════════
@app.command()
def query(
    description: str = typer.Argument(..., help="What you want to know or build"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    component: Optional[str] = typer.Option(None, "--connections", "-c",
                                             help="Show connections for a specific component"),
    impact: Optional[str] = typer.Option(None, "--impact", "-i",
                                          help="Show impact analysis for a specific component"),
    pattern: bool = typer.Option(False, "--pattern", help="Show the best existing module pattern"),
) -> None:
    """Query the knowledge graph for components relevant to your task.

    Examples:

      codemind query "send email when KPI drops below threshold"

      codemind query "" --connections KpiCalculationService

      codemind query "" --impact ThresholdEvaluator

      codemind query "" --pattern
    """
    from rich.markdown import Markdown
    from codemind.graph.store import GraphStore
    from codemind.mcp.tools import (
        tool_find_for_task,
        tool_get_connections,
        tool_get_pattern,
        tool_impact_analysis,
    )

    project = _get_project(path)
    graph = GraphStore().load(project.codemind_dir)

    if graph is None:
        console.print(
            "[red]✗[/red] No graph.json found. Run [bold cyan]codemind scan[/bold cyan] first."
        )
        raise typer.Exit(1)

    _warn_if_stale(project)
    console.print()

    if component:
        console.print(f"  [cyan]Connections:[/cyan] [bold]{component}[/bold]")
        console.print()
        result = tool_get_connections(graph, component)
    elif impact:
        console.print(f"  [cyan]Impact analysis:[/cyan] [bold]{impact}[/bold]")
        console.print()
        result = tool_impact_analysis(graph, impact)
    elif pattern:
        console.print("  [cyan]Module pattern:[/cyan] best existing domain")
        console.print()
        result = tool_get_pattern(graph)
    else:
        console.print(f"  [cyan]Task analysis:[/cyan] [bold]{description}[/bold]")
        console.print(f"  [dim]{len(graph.nodes):,} components in graph[/dim]")
        console.print()
        result = tool_find_for_task(graph, description)

    console.print(Markdown(result))
    console.print()


# ══════════════════════════════════════
# SERVE COMMAND
# ══════════════════════════════════════
@app.command()
def serve(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
) -> None:
    """Start the MCP server for AI tool integration (Claude Code, Cursor, etc.).

    Always includes the file watcher — graph.json is kept current on every
    save so the AI always gets structural facts, never stale data.

    To connect from Claude Code, add to ~/.claude/mcp.json:

      {
        "mcpServers": {
          "codemind": {
            "command": "codemind",
            "args": ["serve", "--path", "/path/to/your/project"]
          }
        }
      }
    """
    import asyncio
    from codemind.mcp.server import run_server

    project = _get_project(path)

    # All output goes to stderr — stdout is reserved exclusively for MCP protocol
    _err.print()
    _err.print(
        Panel(
            f"[bold cyan]CodeMind MCP Server[/bold cyan]\n\n"
            f"Project: [bold]{project.config.project_name or project.root.name}[/bold]\n"
            f"Graph:   [green]{project.graph_path}[/green]\n\n"
            f"[dim]Transport: stdio (MCP protocol) · File watcher: always active[/dim]",
            border_style="cyan",
        )
    )
    _err.print()
    _err.print("  [green]●[/green] File watcher active — graph updates on every save")
    _err.print("  [dim]Waiting for MCP connections…[/dim]")
    _err.print()

    asyncio.run(run_server(project.codemind_dir, watch=True))


# ══════════════════════════════════════
# SHOW COMMAND
# ══════════════════════════════════════
@app.command()
def show(
    what: str = typer.Argument(..., help="'architecture' or a module name"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
) -> None:
    """Show a generated knowledge file.

    Examples:

      codemind show architecture

      codemind show auth

      codemind show business-kpibuilder
    """
    from rich.markdown import Markdown

    project = _get_project(path)

    console.print()

    if what.lower() == "architecture":
        arch_path = project.codemind_dir / "ARCHITECTURE.md"
        if not arch_path.exists():
            console.print(
                "  [yellow]○[/yellow]  ARCHITECTURE.md not found. "
                "Run [bold cyan]codemind scan[/bold cyan] to generate it."
            )
            console.print()
            raise typer.Exit(1)
        console.print(Markdown(arch_path.read_text(encoding="utf-8")))
        console.print()
        return

    # Module lookup — exact match first, then partial
    modules_dir = project.codemind_dir / "modules"
    if not modules_dir.exists():
        console.print(
            "  [yellow]○[/yellow]  No modules directory found. "
            "Run [bold cyan]codemind scan[/bold cyan] to generate it."
        )
        console.print()
        raise typer.Exit(1)

    exact = modules_dir / f"{what}.md"
    if exact.exists():
        match = exact
    else:
        candidates = sorted(modules_dir.glob("*.md"))
        match = next((f for f in candidates if what in f.stem), None)

    if match is None:
        console.print(
            f"  [red]✗[/red]  No module matching [cyan]{what!r}[/cyan] found."
        )
        available = [f.stem for f in sorted(modules_dir.glob("*.md"))]
        if available:
            console.print(f"  [dim]Available modules: {', '.join(available)}[/dim]")
        else:
            console.print(
                "  [dim]Run [bold cyan]codemind scan[/bold cyan] to generate module files.[/dim]"
            )
        console.print()
        raise typer.Exit(1)

    console.print(Markdown(match.read_text(encoding="utf-8")))
    console.print()


# ══════════════════════════════════════
# SCAFFOLD COMMAND
# ══════════════════════════════════════
@app.command()
def scaffold(
    what: str = typer.Argument(..., help="module | service | api | component"),
    name: str = typer.Argument(..., help="Name (e.g. KpiAlert, Attendance)"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    dry_run: bool = typer.Option(False, "--dry-run", "-d", help="Preview without writing"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files"),
) -> None:
    """Generate code scaffolding from graph patterns.

    Examples:

      codemind scaffold service KpiAlert

      codemind scaffold module Attendance

      codemind scaffold api ReportExport --dry-run

      codemind scaffold component UserProfile
    """
    from rich.table import Table

    from codemind.graph.query import get_domain_pattern
    from codemind.graph.store import GraphStore
    from codemind.scaffold.generator import ScaffoldGenerator
    from codemind.scaffold.pattern_extractor import PatternExtractor

    _VALID_TYPES = {"service", "module", "api", "component"}
    if what not in _VALID_TYPES:
        console.print(
            f"[red]✗[/red] Unknown scaffold type [bold]{what!r}[/bold]. "
            f"Expected one of: {', '.join(sorted(_VALID_TYPES))}."
        )
        raise typer.Exit(1)

    project = _get_project(path)

    # Load graph (optional — falls back to defaults if missing)
    graph = GraphStore().load(project.codemind_dir)
    pattern = get_domain_pattern(graph) if graph else None

    ctx = PatternExtractor().extract(name, pattern, graph)

    console.print()
    if dry_run:
        console.print(
            f"  [cyan]Scaffold (dry-run):[/cyan] [bold]{what} {ctx.base_name}[/bold]"
        )
    else:
        console.print(f"  [cyan]Scaffold:[/cyan] [bold]{what} {ctx.base_name}[/bold]")

    if pattern:
        console.print(f"  [dim]Pattern: {pattern.domain} domain[/dim]")
    console.print(f"  [dim]Package: {ctx.domain_package}[/dim]")
    console.print()

    files = ScaffoldGenerator().generate(
        scaffold_type=what,
        ctx=ctx,
        project_root=project.root,
        codemind_dir=project.codemind_dir,
        dry_run=dry_run,
        force=force,
    )

    # Display results table
    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("File")
    table.add_column("Status")

    task_file = None
    for gf in files:
        if gf.label.endswith(".tasks.md"):
            task_file = gf
            continue
        if dry_run:
            status = "[dim]dry-run[/dim]"
        elif gf.existed:
            status = "[yellow]skipped[/yellow] (exists)"
        else:
            status = "[green]created[/green]"
        table.add_row(str(gf.path.relative_to(project.root)), status)

    console.print(table)

    if task_file:
        console.print()
        if dry_run:
            console.print(f"  [dim]Task file (dry-run): {task_file.path}[/dim]")
        elif task_file.existed:
            console.print(f"  [yellow]○[/yellow]  Task file already exists: {task_file.path}")
        else:
            console.print(f"  [green]✓[/green]  Task file: {task_file.path}")

    if not dry_run:
        console.print()
        console.print("  [dim]Run [bold cyan]codemind scan[/bold cyan] to update the knowledge graph.[/dim]")
    console.print()


# ══════════════════════════════════════
# CHECK COMMAND
# ══════════════════════════════════════
@app.command()
def check(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    quick: bool = typer.Option(False, "--quick", help="Fast checks only (naming + layer violations)"),
    pre_commit: bool = typer.Option(False, "--pre-commit", help="Git hook mode: exit 1 on errors"),
) -> None:
    """Run health checks on the knowledge graph.

    Checks for:

      naming          — component names match their semantic type

      layer_violation — controller injects repository directly (error)

      missing_test    — services/controllers without a test class

      orphan          — structural nodes with no connections

      domain_incomplete — domains missing key layers

    Use --quick for fast pre-save checks (naming + layer only).
    Use --pre-commit as a git hook to block bad commits.
    """
    from rich.table import Table

    from codemind.graph.store import GraphStore
    from codemind.health.checker import HealthChecker

    project = _get_project(path)
    graph = GraphStore().load(project.codemind_dir)

    if graph is None:
        if not pre_commit:
            console.print(
                "[red]✗[/red] No graph.json found. "
                "Run [bold cyan]codemind scan[/bold cyan] first."
            )
        raise typer.Exit(1)

    if not pre_commit:
        console.print()
        console.print(
            f"  [cyan]Health check:[/cyan] "
            f"[bold]{project.config.project_name or project.root.name}[/bold]"
        )
        console.print(
            f"  [dim]{len(graph.nodes):,} components · "
            f"{'fast mode' if quick else 'full analysis'}[/dim]"
        )
        console.print()

    report = HealthChecker().run(graph, quick=quick)

    # ── Pre-commit mode: compact output, exit 1 on errors ──
    if pre_commit:
        for v in report.errors:
            loc = f"  [{v.file}]" if v.file else ""
            console.print(f"[red]✗ {v.rule}:[/red] {v.message}{loc}")
        if report.errors:
            console.print(
                f"\n[red]{len(report.errors)} error(s) found. Commit blocked.[/red]"
            )
            raise typer.Exit(1)
        raise typer.Exit(0)

    # ── Full output ──
    if not report.violations:
        console.print("  [green]✓[/green]  All checks passed — no violations found.")
        console.print()
        return

    if report.errors:
        console.print(f"  [bold red]Errors[/bold red]  ({len(report.errors)})")
        for v in report.errors:
            console.print(f"    [red]✗[/red]  [bold]{v.component}[/bold]")
            console.print(f"       {v.message}")
            if v.file:
                console.print(f"       [dim]{v.file}[/dim]")
        console.print()

    if report.warnings:
        console.print(f"  [bold yellow]Warnings[/bold yellow]  ({len(report.warnings)})")
        for v in report.warnings:
            console.print(f"    [yellow]⚠[/yellow]  [bold]{v.component}[/bold]")
            console.print(f"       {v.message}")
            if v.file:
                console.print(f"       [dim]{v.file}[/dim]")
        console.print()

    # Summary line
    if report.passed:
        console.print(
            f"  [green]✓[/green]  {len(report.warnings)} warning(s) — no blocking errors"
        )
    else:
        console.print(
            f"  [red]✗[/red]  {len(report.errors)} error(s), "
            f"{len(report.warnings)} warning(s)"
        )
        console.print()
        console.print(
            "  [dim]Fix errors before committing. "
            "Install as a git hook: [bold cyan]codemind check --pre-commit[/bold cyan][/dim]"
        )
    console.print()


def _warn_if_stale(project: "CodemindProject") -> None:
    """Print a warning when graph.json is older than the newest source file."""
    from codemind.graph.store import is_graph_stale
    if is_graph_stale(project.root, project.codemind_dir):
        console.print(
            "  [yellow]⚠[/yellow]  [bold]graph.json is out of date[/bold] — "
            "source files changed since last scan."
        )
        console.print(
            "  [dim]Run [bold cyan]codemind scan[/bold cyan] to rebuild, "
            "or [bold cyan]codemind watch[/bold cyan] to keep it live automatically.[/dim]"
        )
        console.print(
            "  [dim]Showing results from last scan.[/dim]"
        )
        console.print()


def _require_api_key() -> str:
    """Return ANTHROPIC_API_KEY from environment or exit with a helpful message."""
    import os
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        console.print(
            "\n  [red]✗[/red]  [bold]ANTHROPIC_API_KEY[/bold] not set.\n\n"
            "  Set your key to use Pro AI features:\n"
            "    [bold cyan]export ANTHROPIC_API_KEY=sk-ant-...[/bold cyan]\n\n"
            "  Pro subscribers: upgrade at [cyan]codemind.sh/upgrade[/cyan] to use AI without a key.\n"
        )
        raise typer.Exit(1)
    return key


@app.command()
def review(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    force: bool = typer.Option(False, "--force", "-f", help="Regenerate even if cached"),
) -> None:
    """AI Architectural Review — analyse risks and patterns from the graph.

    Sends a compact graph summary to Claude and returns structured feedback:
    strengths, risks, recommendations, and key metrics.
    Output is written to ``.codemind/REVIEW.md`` and cached.

    Requires ``ANTHROPIC_API_KEY`` (or Pro license).

    Example::

      codemind review
      codemind review --force   # regenerate even if cached
    """
    from codemind.ai.pro_features import generate_review
    from codemind.graph.store import GraphStore

    api_key = _require_api_key()
    project = _get_project(path)
    graph = GraphStore().load(project.codemind_dir)

    if graph is None:
        console.print(
            "[red]✗[/red] No graph found. Run [bold cyan]codemind scan[/bold cyan] first."
        )
        raise typer.Exit(1)

    _warn_if_stale(project)
    console.print()
    console.print(
        f"  [cyan]AI Architectural Review:[/cyan] [bold]{project.config.project_name or project.root.name}[/bold]"
    )
    console.print(f"  [dim]{len(graph.nodes):,} components · analysing with Claude...[/dim]")
    console.print()

    try:
        content, was_cached = generate_review(graph, project.codemind_dir, api_key, force=force)
    except Exception as exc:
        console.print(f"  [red]✗[/red]  AI review failed: {exc}")
        raise typer.Exit(1)

    console.print(content)
    console.print()
    out = project.codemind_dir / "REVIEW.md"
    if was_cached:
        console.print(f"  [dim](cached) Written to [cyan]{out}[/cyan][/dim]")
    else:
        console.print(f"  [green]✓[/green]  Written to [cyan]{out}[/cyan]")
    console.print()


@app.command()
def brief(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    force: bool = typer.Option(False, "--force", "-f", help="Regenerate even if cached"),
) -> None:
    """AI Onboarding Brief — new-developer guide generated from the graph.

    Generates: what the system does, the 5 most important components,
    the 3 domains to understand first, key patterns, and a glossary.
    Output is written to ``.codemind/BRIEF.md`` and cached.

    Requires ``ANTHROPIC_API_KEY`` (or Pro license).

    Example::

      codemind brief
      codemind brief --force
    """
    from codemind.ai.pro_features import generate_brief
    from codemind.graph.store import GraphStore

    api_key = _require_api_key()
    project = _get_project(path)
    graph = GraphStore().load(project.codemind_dir)

    if graph is None:
        console.print(
            "[red]✗[/red] No graph found. Run [bold cyan]codemind scan[/bold cyan] first."
        )
        raise typer.Exit(1)

    _warn_if_stale(project)
    console.print()
    console.print(
        f"  [cyan]AI Onboarding Brief:[/cyan] [bold]{project.config.project_name or project.root.name}[/bold]"
    )
    console.print(f"  [dim]{len(graph.nodes):,} components · generating with Claude...[/dim]")
    console.print()

    try:
        content, was_cached = generate_brief(graph, project.codemind_dir, api_key, force=force)
    except Exception as exc:
        console.print(f"  [red]✗[/red]  AI brief failed: {exc}")
        raise typer.Exit(1)

    console.print(content)
    console.print()
    out = project.codemind_dir / "BRIEF.md"
    if was_cached:
        console.print(f"  [dim](cached) Written to [cyan]{out}[/cyan][/dim]")
    else:
        console.print(f"  [green]✓[/green]  Written to [cyan]{out}[/cyan]")
    console.print()


@app.command()
def impact(
    component: str = typer.Argument(..., help="Component name (simple or fully-qualified)"),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    ai: bool = typer.Option(False, "--ai", help="Add AI risk assessment (requires API key)"),
) -> None:
    """Impact analysis — what breaks if a component changes.

    Without ``--ai``: runs the structural BFS (same as ``codemind query --impact``).
    With ``--ai``: adds Claude's risk assessment on top of the structural result.

    Requires ``ANTHROPIC_API_KEY`` for ``--ai`` (or Pro license).

    Examples::

      codemind impact ThresholdEvaluator
      codemind impact ThresholdEvaluator --ai
    """
    from codemind.graph import query as gq
    from codemind.graph.store import GraphStore

    project = _get_project(path)
    graph = GraphStore().load(project.codemind_dir)

    if graph is None:
        console.print(
            "[red]✗[/red] No graph found. Run [bold cyan]codemind scan[/bold cyan] first."
        )
        raise typer.Exit(1)

    _warn_if_stale(project)
    console.print()

    # Structural impact (always)
    result = gq.impact_of(graph, component)
    if result is None:
        console.print(
            f"  [red]✗[/red]  Component `{component}` not found in the graph.\n"
            "  Use [bold cyan]codemind query[/bold cyan] to search for it."
        )
        raise typer.Exit(1)

    console.print(gq.format_impact(result))

    if not ai:
        return

    # AI-enhanced risk assessment
    api_key = _require_api_key()
    console.print()
    console.print("  [cyan]AI risk assessment...[/cyan]")
    console.print()

    from codemind.ai.pro_features import predict_impact
    try:
        prediction = predict_impact(graph, component, api_key)
        console.print(prediction)
    except Exception as exc:
        console.print(f"  [yellow]⚠[/yellow]  AI assessment failed: {exc}")
    console.print()


# ══════════════════════════════════════
# CONNECT COMMAND
# ══════════════════════════════════════
@app.command()
def connect(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    global_mode: bool = typer.Option(False, "--global", "-g", help="Register globally (~/.claude/settings.json etc.)"),
    tool: Optional[str] = typer.Option(None, "--tool", "-t", help="Specific tool: claude, cursor, claude_desktop (default: all detected)"),
) -> None:
    """Register CodeMind as an MCP server with your AI coding tools.

    Auto-detects Claude Code, Cursor, and Claude Desktop and writes the
    correct config file for each so the AI tool launches ``codemind serve``
    automatically when you open the project.

    Run once per project. Restart your AI tool to activate.

    Examples::

      codemind connect                      # auto-detect all tools, project-level
      codemind connect --global             # register in global config (~/.claude/)
      codemind connect --tool claude        # Claude Code only
      codemind connect --tool cursor        # Cursor only
    """
    from codemind.mcp.connect import (
        connect_all,
        detected_tools,
        TOOL_CLAUDE_CODE, TOOL_CURSOR, TOOL_CLAUDE_DESKTOP,
    )

    project_root = (path or Path.cwd()).resolve()
    tools = [tool] if tool else None

    console.print()

    results = connect_all(project_root, global_mode=global_mode, tools=tools)

    if not results:
        found = detected_tools()
        if not found:
            console.print(
                "  [yellow]○[/yellow]  No supported AI tools detected on this machine.\n"
                "  Install [bold]Claude Code[/bold], [bold]Cursor[/bold], or "
                "[bold]Claude Desktop[/bold] then run [bold cyan]codemind connect[/bold cyan] again."
            )
        else:
            console.print(
                f"  [yellow]○[/yellow]  Tool [bold]{tool}[/bold] not recognised. "
                f"Available: claude, cursor, claude_desktop"
            )
        console.print()
        raise typer.Exit(1)

    any_fail = False
    for r in results:
        if not r.success:
            console.print(f"  [red]✗[/red]  {r.label}: {r.error}")
            any_fail = True
        elif r.already_configured:
            console.print(
                f"  [green]✓[/green]  {r.label}: already configured "
                f"([dim]{r.config_path}[/dim])"
            )
        else:
            action = "created" if r.created else "updated"
            console.print(
                f"  [green]✓[/green]  {r.label}: {action} "
                f"[dim]{r.config_path}[/dim]"
            )
            console.print(
                f"  [dim]     → {r.restart_hint}[/dim]"
            )

    console.print()
    if any_fail:
        raise typer.Exit(1)


@app.command("install-hook")
def install_hook(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project directory"),
    uninstall: bool = typer.Option(False, "--uninstall", help="Remove the pre-commit hook"),
) -> None:
    """Install (or remove) codemind as a git pre-commit hook.

    The hook runs ``codemind check --pre-commit`` before every commit.
    If health errors are found the commit is blocked.

    Examples::

      codemind install-hook           # install in current project
      codemind install-hook --uninstall  # remove the hook
    """
    import stat

    root = path or Path.cwd()
    git_dir = root / ".git"
    if not git_dir.is_dir():
        console.print(
            "[red]✗[/red]  No `.git/` directory found. "
            "Run this command from inside a git repository."
        )
        raise typer.Exit(1)

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    hook_file = hooks_dir / "pre-commit"

    _HOOK_MARKER = "# codemind-managed"
    _HOOK_BODY = f"""#!/bin/sh
{_HOOK_MARKER}
codemind check --pre-commit
"""

    console.print()

    if uninstall:
        if hook_file.exists():
            content = hook_file.read_text(encoding="utf-8")
            if _HOOK_MARKER in content:
                hook_file.unlink()
                console.print("  [green]✓[/green]  Pre-commit hook removed.")
            else:
                console.print(
                    "  [yellow]⚠[/yellow]  Pre-commit hook exists but was not installed by CodeMind. "
                    "Remove it manually: [dim].git/hooks/pre-commit[/dim]"
                )
        else:
            console.print("  [yellow]○[/yellow]  No pre-commit hook found.")
        console.print()
        return

    if hook_file.exists():
        content = hook_file.read_text(encoding="utf-8")
        if _HOOK_MARKER in content:
            console.print(
                "  [green]✓[/green]  Pre-commit hook already installed — no changes made."
            )
            console.print()
            return
        else:
            console.print(
                "[red]✗[/red]  A pre-commit hook already exists at `.git/hooks/pre-commit` "
                "and was not created by CodeMind.\n"
                "  Add this line manually to the hook:\n\n"
                "    [bold cyan]codemind check --pre-commit[/bold cyan]\n"
            )
            console.print()
            return

    hook_file.write_text(_HOOK_BODY, encoding="utf-8")
    # Make executable
    current = hook_file.stat().st_mode
    hook_file.chmod(current | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    console.print("  [green]✓[/green]  Pre-commit hook installed at `.git/hooks/pre-commit`.")
    console.print(
        "  [dim]Every commit will now run [bold cyan]codemind check --pre-commit[/bold cyan].[/dim]"
    )
    console.print(
        "  [dim]Errors block the commit. Warnings are advisory only.[/dim]"
    )
    console.print()


# ══════════════════════════════════════
# HELPER FUNCTIONS
# ══════════════════════════════════════

_SKIP_DIRS = frozenset({
    "node_modules", "target", "dist", ".git", "__pycache__", ".venv", ".codemind",
})


def _find_first(root: Path, filename: str, max_depth: int = 2) -> Path | None:
    """Return the first file matching filename up to max_depth directory levels below root."""
    candidate = root / filename
    if candidate.exists():
        return candidate
    if max_depth <= 0:
        return None
    try:
        for child in sorted(root.iterdir()):
            if child.is_dir() and child.name not in _SKIP_DIRS and not child.name.startswith("."):
                result = _find_first(child, filename, max_depth - 1)
                if result:
                    return result
    except PermissionError:
        pass
    return None


def _find_all(root: Path, filename: str, max_depth: int = 5) -> list[Path]:
    """Return all files matching filename up to max_depth directory levels below root."""
    results: list[Path] = []
    candidate = root / filename
    if candidate.exists():
        results.append(candidate)
    if max_depth <= 0:
        return results
    try:
        for child in sorted(root.iterdir()):
            if child.is_dir() and child.name not in _SKIP_DIRS and not child.name.startswith("."):
                results.extend(_find_all(child, filename, max_depth - 1))
    except PermissionError:
        pass
    return results


def _get_project(path: Optional[Path] = None) -> CodemindProject:
    """Find and validate a CodeMind project."""
    if path:
        project = CodemindProject(path)
    else:
        project = CodemindProject.find_project() or CodemindProject(Path.cwd())

    if not project.is_initialized:
        console.print(
            "[red]✗[/red] No CodeMind project found. Run [bold cyan]codemind init[/bold cyan] first."
        )
        raise typer.Exit(1)

    return project


def _detect_tech_stack(project_root: Path) -> TechStackConfig:
    """Auto-detect tech stack from project files, searching up to 2 levels deep."""
    import json
    import re

    config = TechStackConfig()

    # Java / Spring Boot — search up to 2 levels deep
    pom = _find_first(project_root, "pom.xml", max_depth=2)
    if pom:
        config.backend_language = "java"
        config.backend_build_tool = "maven"
        content = pom.read_text(encoding="utf-8")
        if "spring-boot" in content:
            config.backend_framework = "spring-boot"
            m = re.search(r"<spring-boot[^>]*version>([^<]+)", content)
            if m:
                config.backend_version = m.group(1)

    if not config.backend_language:
        gradle = _find_first(project_root, "build.gradle", max_depth=2)
        if gradle:
            config.backend_language = "java"
            config.backend_build_tool = "gradle"

    # TypeScript / Angular / React — search up to 2 levels deep
    # Prefer angular.json location so package.json is found in the same dir
    angular_json = _find_first(project_root, "angular.json", max_depth=2)
    if angular_json:
        pkg_candidate = angular_json.parent / "package.json"
        package_json = pkg_candidate if pkg_candidate.exists() else _find_first(project_root, "package.json", max_depth=2)
    else:
        package_json = _find_first(project_root, "package.json", max_depth=2)

    if package_json and package_json.exists():
        try:
            pkg = json.loads(package_json.read_text(encoding="utf-8"))
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}

            if "@angular/core" in deps or angular_json:
                config.frontend_language = "typescript"
                config.frontend_framework = "angular"
                config.frontend_version = deps.get("@angular/core", "").lstrip("^~")
            elif "react" in deps:
                config.frontend_language = "typescript" if "typescript" in deps else "javascript"
                config.frontend_framework = "react"
                config.frontend_version = deps.get("react", "").lstrip("^~")
            elif "vue" in deps:
                config.frontend_language = "typescript" if "typescript" in deps else "javascript"
                config.frontend_framework = "vue"
                config.frontend_version = deps.get("vue", "").lstrip("^~")
        except (json.JSONDecodeError, KeyError):
            pass

    # Python / Django / FastAPI — search up to 2 levels deep
    pyproject = _find_first(project_root, "pyproject.toml", max_depth=2)
    requirements = _find_first(project_root, "requirements.txt", max_depth=2)
    if (pyproject or requirements) and not config.backend_language:
        config.backend_language = "python"
        content = ""
        if pyproject:
            content = pyproject.read_text(encoding="utf-8")
        elif requirements:
            content = requirements.read_text(encoding="utf-8")
        if "django" in content.lower():
            config.backend_framework = "django"
        elif "fastapi" in content.lower():
            config.backend_framework = "fastapi"
        elif "flask" in content.lower():
            config.backend_framework = "flask"

    # Database / auth detection — search all subfolders for Spring config files
    for config_filename in ["application.yml", "application.properties"]:
        for app_config in _find_all(project_root, config_filename, max_depth=5):
            content = app_config.read_text(encoding="utf-8").lower()
            if not config.database_type:
                if "oracle" in content:
                    config.database_type = "oracle"
                elif "postgresql" in content or "postgres" in content:
                    config.database_type = "postgresql"
                elif "mysql" in content:
                    config.database_type = "mysql"
            if not config.auth_provider and "keycloak" in content:
                config.auth_provider = "keycloak"
            if config.database_type and config.auth_provider:
                break
        if config.database_type and config.auth_provider:
            break

    return config


def _build_tree(directory: Path, tree: Tree, root: Path) -> None:
    """Build a Rich tree from directory contents."""
    try:
        entries = sorted(
            directory.iterdir(),
            key=lambda p: (not p.is_dir(), p.name.lower()),
        )
    except PermissionError:
        return

    for entry in entries:
        if entry.name.startswith(".") and entry.name != ".gitignore":
            continue
        if entry.is_dir():
            branch = tree.add(f"[bold blue]{entry.name}/[/bold blue]")
            _build_tree(entry, branch, root)
        else:
            size = entry.stat().st_size
            tree.add(f"{entry.name} [dim]({_human_size(size)})[/dim]")


def _human_size(size: int) -> str:
    """Convert bytes to human readable."""
    for unit in ("B", "KB", "MB"):
        if size < 1024:
            return f"{size:.0f}{unit}" if unit == "B" else f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}GB"


# Common frontend folder names (checked in order)
_FRONTEND_HINTS = ("frontend", "client", "web", "ui", "app", "angular", "react", "vue")
# Common backend folder names
_BACKEND_HINTS = ("backend", "server", "api", "service", "java", "spring")


def _has_fullstack_signals(graph: "CodeGraph") -> bool:
    """Return True if the graph looks like a fullstack project.

    Detects:
    - Java + TypeScript (Spring Boot + Angular/React)
    - TypeScript + TypeScript monorepo (NestJS + React/Angular): must have both
      frontend ``component`` nodes and backend ``class``/``controller`` nodes.
    """
    langs = {n.language for n in graph.nodes.values()}
    # Classic Spring + Angular/React
    if "java" in langs and "typescript" in langs:
        return True
    # TypeScript monorepo: NestJS (class/controller) + React/Angular (component)
    if "typescript" in langs:
        ts_types = {n.type for n in graph.nodes.values() if n.language == "typescript"}
        has_frontend = "component" in ts_types
        has_backend = bool(ts_types & {"class", "controller"})
        if has_frontend and has_backend:
            return True
    return False


def _detect_frontend_path(project_root: Path) -> str:
    """Suggest a frontend folder based on common names found in the project root."""
    for name in _FRONTEND_HINTS:
        candidate = project_root / name
        if candidate.is_dir():
            return name + "/"
    # Look for package.json one level deep
    for child in project_root.iterdir():
        if child.is_dir() and (child / "package.json").exists():
            return child.name + "/"
    return ""


def _detect_backend_path(project_root: Path) -> str:
    """Suggest a backend folder based on common names found in the project root."""
    for name in _BACKEND_HINTS:
        candidate = project_root / name
        if candidate.is_dir():
            return name + "/"
    # Look for pom.xml one level deep
    for child in project_root.iterdir():
        if child.is_dir() and (child / "pom.xml").exists():
            return child.name + "/"
    return ""
