"""TypeScript / Angular / React AST parser — extracts GraphNodes and GraphEdges.

What is extracted
-----------------
**Nodes:**
  - Classes (Angular, NestJS, plain TypeScript):
    Name, type, package, methods, decorators.
    Node type from decorators: @Component → component, @Injectable → service, etc.
  - React functional components: ``const Foo = () => <JSX>`` → component node.
  - React custom hooks: ``const useMyHook = () => {}`` → service node.

**Edges** (typed relationships):
  - ``injects``  — constructor parameters with type annotations (Angular DI).
  - ``imports``  — import statements referencing project files (not node_modules).
  - ``extends``  — superclass from class heritage.
  - ``implements``— interface from class heritage.
  - ``calls``    — method invocations on injected fields + hook calls (useXxx()).

Targets use simple class names.  The graph builder post-processes to resolve
them against fully-qualified node IDs.

Files handled: .ts, .tsx, .jsx
  - .ts  → TypeScript language (no JSX)
  - .tsx / .jsx → TSX language (JSX support for React components)
"""

from __future__ import annotations

from pathlib import Path

import tree_sitter_typescript as tsts
from tree_sitter import Language, Parser

from codemind.core.graph import (
    EDGE_CALLS,
    EDGE_EXTENDS,
    EDGE_IMPLEMENTS,
    EDGE_IMPORTS,
    EDGE_INJECTS,
    NODE_CLASS,
    NODE_COMPONENT,
    NODE_DIRECTIVE,
    NODE_ENUM,
    NODE_GUARD,
    NODE_INTERCEPTOR,
    NODE_INTERFACE,
    NODE_MODULE,
    NODE_PIPE,
    NODE_SERVICE,
    GraphEdge,
    GraphNode,
)
from codemind.parser.base import BaseParser, ParseResult

# ── Decorator → node type ─────────────────────────────────────────────────────

_DEC_TYPE: dict[str, str] = {
    "Component":      NODE_COMPONENT,
    "Injectable":     NODE_SERVICE,
    "NgModule":       NODE_MODULE,
    "Pipe":           NODE_PIPE,
    "Directive":      NODE_DIRECTIVE,
    "Controller":     NODE_CLASS,   # NestJS
    "Guard":          NODE_GUARD,
    "Interceptor":    NODE_INTERCEPTOR,
    "CanActivate":    NODE_GUARD,
    "CanActivateFn":  NODE_GUARD,
}

# ── TypeScript stdlib / framework types to skip ───────────────────────────────

_SKIP: frozenset[str] = frozenset({
    "string", "number", "boolean", "any", "void", "never", "null", "undefined",
    "object", "unknown",
    "Array", "Promise", "Observable", "Subject", "BehaviorSubject",
    "EventEmitter", "HttpClient", "HttpHeaders", "HttpParams",
    "ActivatedRoute", "Router", "FormBuilder", "FormGroup", "FormControl",
    "ChangeDetectorRef", "ElementRef", "ViewContainerRef",
    "Date", "Error", "Map", "Set",
    "OnInit", "OnDestroy", "OnChanges", "AfterViewInit",
})


# ── AST helpers ────────────────────────────────────────────────────────────────


def _text(node, src: bytes) -> str:
    return src[node.start_byte:node.end_byte].decode("utf-8", errors="replace").strip()


def _find_children(node, *types: str) -> list:
    return [c for c in node.children if c.type in types]


def _find_all(node, *types: str) -> list:
    result: list = []
    def walk(n) -> None:
        if n.type in types:
            result.append(n)
        for c in n.children:
            walk(c)
    walk(node)
    return result


def _decorators(node, src: bytes) -> list[str]:
    """Extract decorator names from a class declaration."""
    names: list[str] = []
    for child in node.children:
        if child.type == "decorator":
            # decorator body: "@" + identifier or call_expression
            for c in child.children:
                if c.type == "identifier":
                    names.append(_text(c, src))
                    break
                if c.type == "call_expression":
                    fn = c.child_by_field_name("function")
                    if fn:
                        names.append(_text(fn, src))
                    break
    return names


def _node_type(name: str, decorators: list[str], decl_kind: str) -> str:
    if decl_kind == "interface_declaration":
        return NODE_INTERFACE
    if decl_kind == "enum_declaration":
        return NODE_ENUM
    for dec in decorators:
        if dec in _DEC_TYPE:
            return _DEC_TYPE[dec]
    # Suffix heuristics
    for suffix, t in [
        ("Service",     NODE_SERVICE),
        ("Component",   NODE_COMPONENT),
        ("Guard",       NODE_GUARD),
        ("Interceptor", NODE_INTERCEPTOR),
        ("Pipe",        NODE_PIPE),
        ("Directive",   NODE_DIRECTIVE),
        ("Module",      NODE_MODULE),
    ]:
        if name.endswith(suffix):
            return t
    return NODE_CLASS


def _heritage(node, src: bytes) -> tuple[str, list[str]]:
    """Return (superclass_name, [interface_names]) from class heritage clause."""
    superclass = ""
    ifaces: list[str] = []
    for clause in _find_all(node, "class_heritage"):
        for extends_clause in _find_children(clause, "extends_clause"):
            for t in _find_children(extends_clause, "identifier", "type_identifier"):
                superclass = _text(t, src)
                break
        for impl_clause in _find_children(clause, "implements_clause"):
            for t in _find_all(impl_clause, "type_identifier"):
                ifaces.append(_text(t, src))
    return superclass, ifaces


def _methods_ts(body, src: bytes) -> list[str]:
    """Method names from a class body."""
    names: list[str] = []
    for child in body.children:
        if child.type == "method_definition":
            n = child.child_by_field_name("name")
            if n:
                txt = _text(n, src)
                if txt not in ("constructor", "ngOnInit", "ngOnDestroy"):
                    names.append(txt)
    return names


def _constructor_injects(body, src: bytes) -> dict[str, str]:
    """``{param_name → type_name}`` from the constructor's parameter list."""
    result: dict[str, str] = {}
    for child in body.children:
        if child.type != "method_definition":
            continue
        n = child.child_by_field_name("name")
        if not n or _text(n, src) != "constructor":
            continue
        params = child.child_by_field_name("parameters")
        if not params:
            continue
        for param in params.children:
            if param.type in ("required_parameter", "optional_parameter"):
                # param: modifiers? pattern : type_annotation
                pattern = param.child_by_field_name("pattern")
                type_ann = param.child_by_field_name("type")
                if pattern and type_ann:
                    param_name = _text(pattern, src)
                    # type_annotation node: ":" + type_identifier
                    type_nodes = _find_all(type_ann, "type_identifier")
                    if type_nodes:
                        type_name = _text(type_nodes[0], src)
                        result[param_name] = type_name
    return result


def _call_edges_ts(
    body,
    src: bytes,
    node_id: str,
    field_map: dict[str, str],
) -> list[GraphEdge]:
    """``calls`` edges from method invocations on injected fields."""
    if not field_map:
        return []
    edges: list[GraphEdge] = []
    seen: set[str] = set()

    def walk(n) -> None:
        if n.type == "call_expression":
            fn = n.child_by_field_name("function")
            if fn and fn.type == "member_expression":
                obj = fn.child_by_field_name("object")
                prop = fn.child_by_field_name("property")
                if obj and prop:
                    receiver = _text(obj, src)
                    # strip leading "this."
                    if receiver.startswith("this."):
                        receiver = receiver[5:]
                    target_type = field_map.get(receiver)
                    if target_type and target_type not in seen and target_type not in _SKIP:
                        seen.add(target_type)
                        edges.append(GraphEdge(
                            source=node_id,
                            target=target_type,
                            kind=EDGE_CALLS,
                            meta={"method": _text(prop, src)},
                        ))
        for child in n.children:
            walk(child)

    walk(body)
    return edges


def _import_edges(root, src: bytes, node_id: str, file_rel: str) -> list[GraphEdge]:
    """``imports`` edges for project-local imports (not ``node_modules``)."""
    edges: list[GraphEdge] = []

    for child in root.children:
        if child.type != "import_statement":
            continue
        # Get the module specifier (named field "source")
        source_node = child.child_by_field_name("source")
        if not source_node:
            continue
        raw = _text(source_node, src).strip("'\"")
        # Only project-relative imports (start with . or ..)
        if not raw.startswith("."):
            continue
        # import_clause is NOT a named field — find it by type
        imports_clause = next(
            (c for c in child.children if c.type == "import_clause"), None
        )
        if not imports_clause:
            continue
        for id_node in _find_all(imports_clause, "identifier"):
            imported_name = _text(id_node, src)
            if imported_name and imported_name[0].isupper():
                edges.append(GraphEdge(
                    source=node_id,
                    target=imported_name,
                    kind=EDGE_IMPORTS,
                    meta={"from": raw},
                ))
    return edges


# ── React / functional component helpers ─────────────────────────────────────

_JSX_TYPES: frozenset[str] = frozenset({
    "jsx_element",
    "jsx_fragment",
    "jsx_self_closing_element",
    "jsx_opening_element",
})


def _has_jsx(node) -> bool:
    """Return True if the AST subtree contains any JSX element."""
    if node.type in _JSX_TYPES:
        return True
    return any(_has_jsx(c) for c in node.children)


def _is_hook_name(name: str) -> bool:
    """Return True for valid React hook names: starts with 'use' + uppercase letter."""
    return len(name) > 3 and name.startswith("use") and name[3].isupper()


def _hook_call_edges(func_body, src: bytes, node_id: str) -> list[GraphEdge]:
    """EDGE_CALLS edges for hook calls (useXxx()) referenced inside a function body."""
    edges: list[GraphEdge] = []
    seen: set[str] = set()

    def walk(n) -> None:
        if n.type == "call_expression":
            fn = n.child_by_field_name("function")
            if fn and fn.type == "identifier":
                callee = _text(fn, src)
                if _is_hook_name(callee) and callee not in seen and callee not in _SKIP:
                    seen.add(callee)
                    edges.append(GraphEdge(
                        source=node_id,
                        target=callee,
                        kind=EDGE_CALLS,
                        meta={"via": "hook_call"},
                    ))
        for child in n.children:
            walk(child)

    walk(func_body)
    return edges


# ── Parser ────────────────────────────────────────────────────────────────────


class TypeScriptParser(BaseParser):
    """Parses TypeScript/Angular/React source files into CodeGraph nodes and edges."""

    language = "typescript"
    extensions = [".ts", ".tsx", ".jsx"]

    def __init__(self) -> None:
        ts_lang = Language(tsts.language_typescript())
        self._parser = Parser(ts_lang)
        tsx_lang = Language(tsts.language_tsx())
        self._tsx_parser = Parser(tsx_lang)

    def parse(self, path: Path, project_root: Path) -> ParseResult:
        src = path.read_bytes()
        # Use TSX language for .tsx/.jsx files (JSX support)
        parser = self._tsx_parser if path.suffix in (".tsx", ".jsx") else self._parser
        tree = parser.parse(src)

        try:
            rel = path.relative_to(project_root)
            file_rel = "/".join(rel.parts)
        except ValueError:
            file_rel = path.name

        # Package = directory path (Angular convention)
        pkg = "/".join(file_rel.split("/")[:-1])

        result = ParseResult(file=file_rel, language="typescript")

        _DECL_TYPES = ("class_declaration", "interface_declaration", "enum_declaration")
        _FUNC_TYPES = ("lexical_declaration", "function_declaration")

        for child in tree.root_node.children:
            if child.type == "export_statement":
                # In tree-sitter-typescript, `export class Foo {}` and
                # `@Decorator() export class Foo {}` are both wrapped in an
                # export_statement.  Decorators are siblings of the class
                # inside export_statement, NOT children of class_declaration.
                decl = child.child_by_field_name("declaration")
                if decl is None:
                    continue
                if decl.type in _DECL_TYPES:
                    node, edges = self._process(
                        decl, src, file_rel, pkg, tree.root_node,
                        decorator_container=child,
                    )
                    if node:
                        result.nodes.append(node)
                        result.edges.extend(edges)
                elif decl.type in _FUNC_TYPES:
                    # React functional components / hooks
                    nodes, edges = self._process_func_decl(
                        decl, src, file_rel, pkg, tree.root_node,
                    )
                    result.nodes.extend(nodes)
                    result.edges.extend(edges)
            elif child.type in _DECL_TYPES:
                # Plain (non-exported) declaration — decorators would live on the
                # class node itself (rare in Angular but handle it anyway).
                node, edges = self._process(child, src, file_rel, pkg, tree.root_node)
                if node:
                    result.nodes.append(node)
                    result.edges.extend(edges)
            elif child.type in _FUNC_TYPES:
                # Non-exported functional component / hook
                nodes, edges = self._process_func_decl(
                    child, src, file_rel, pkg, tree.root_node,
                )
                result.nodes.extend(nodes)
                result.edges.extend(edges)

        return result

    def _process_func_decl(
        self,
        decl,
        src: bytes,
        file_rel: str,
        pkg: str,
        root,
    ) -> tuple[list[GraphNode], list[GraphEdge]]:
        """Process functional components (const Foo = () => <JSX>) and hooks (useXxx)."""
        nodes: list[GraphNode] = []
        edges_all: list[GraphEdge] = []

        if decl.type == "lexical_declaration":
            # `const Foo = () => ...` or `const useFoo = () => ...`
            for child in decl.children:
                if child.type != "variable_declarator":
                    continue
                name_node = child.child_by_field_name("name")
                if not name_node or name_node.type != "identifier":
                    continue
                name = _text(name_node, src)
                value = child.child_by_field_name("value")
                if value is None or value.type not in ("arrow_function", "function"):
                    continue
                func_body = value.child_by_field_name("body")
                if func_body is None:
                    continue
                g_node, edges = self._build_func_node(
                    name, func_body, src, file_rel, pkg, root, decl,
                )
                if g_node:
                    nodes.append(g_node)
                    edges_all.extend(edges)

        elif decl.type == "function_declaration":
            # `function Foo() { ... }`
            name_node = decl.child_by_field_name("name")
            if name_node and name_node.type == "identifier":
                name = _text(name_node, src)
                func_body = decl.child_by_field_name("body")
                if func_body:
                    g_node, edges = self._build_func_node(
                        name, func_body, src, file_rel, pkg, root, decl,
                    )
                    if g_node:
                        nodes.append(g_node)
                        edges_all.extend(edges)

        return nodes, edges_all

    def _build_func_node(
        self,
        name: str,
        func_body,
        src: bytes,
        file_rel: str,
        pkg: str,
        root,
        decl_node,
    ) -> tuple[GraphNode | None, list[GraphEdge]]:
        """Build a GraphNode for a functional component or hook, or return None."""
        if _is_hook_name(name):
            ntype = NODE_SERVICE
        elif name and name[0].isupper() and _has_jsx(func_body):
            ntype = NODE_COMPONENT
        else:
            return None, []

        node_id = f"{pkg}/{name}" if pkg else name
        g_node = GraphNode(
            id=node_id,
            name=name,
            type=ntype,
            language="typescript",
            package=pkg,
            file=file_rel,
            methods=[],
            annotations=["functional"],
            interfaces=[],
            superclass="",
            line=decl_node.start_point[0] + 1,
        )

        edges: list[GraphEdge] = []
        edges.extend(_hook_call_edges(func_body, src, node_id))
        edges.extend(_import_edges(root, src, node_id, file_rel))
        return g_node, edges

    def _process(
        self,
        decl,
        src: bytes,
        file_rel: str,
        pkg: str,
        root,
        decorator_container=None,
    ) -> tuple[GraphNode | None, list[GraphEdge]]:
        name_node = decl.child_by_field_name("name")
        if not name_node:
            return None, []

        name = _text(name_node, src)
        # Decorators live in the export_statement wrapper (decorator_container),
        # not inside the class_declaration itself.
        decorators = _decorators(decorator_container if decorator_container is not None else decl, src)
        ntype = _node_type(name, decorators, decl.type)
        superclass, ifaces = _heritage(decl, src)
        body = decl.child_by_field_name("body")
        methods = _methods_ts(body, src) if body else []

        node_id = f"{pkg}/{name}" if pkg else name

        g_node = GraphNode(
            id=node_id,
            name=name,
            type=ntype,
            language="typescript",
            package=pkg,
            file=file_rel,
            methods=methods,
            annotations=decorators,
            interfaces=ifaces,
            superclass=superclass,
            line=decl.start_point[0] + 1,
        )

        edges: list[GraphEdge] = []

        if superclass and superclass not in _SKIP:
            edges.append(GraphEdge(source=node_id, target=superclass, kind=EDGE_EXTENDS))

        for iface in ifaces:
            if iface not in _SKIP:
                edges.append(GraphEdge(source=node_id, target=iface, kind=EDGE_IMPLEMENTS))

        # Constructor injection
        inject_map = _constructor_injects(body, src) if body else {}
        for param_name, type_name in inject_map.items():
            if type_name and type_name not in _SKIP and type_name[0].isupper():
                edges.append(GraphEdge(
                    source=node_id,
                    target=type_name,
                    kind=EDGE_INJECTS,
                    meta={"via": "constructor"},
                ))

        # Calls
        if body:
            edges.extend(_call_edges_ts(body, src, node_id, inject_map))

        # Project imports
        edges.extend(_import_edges(root, src, node_id, file_rel))

        return g_node, edges
