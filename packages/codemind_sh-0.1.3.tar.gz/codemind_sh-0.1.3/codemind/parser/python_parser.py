"""Python AST parser — extracts GraphNodes and GraphEdges using tree-sitter.

What is extracted
-----------------
**Nodes** (one per class / function decorated as a route):
  - FastAPI routers → NODE_CONTROLLER
  - Django/Flask views → NODE_CONTROLLER
  - class *Service → NODE_SERVICE
  - class *Repository / *Dao → NODE_REPOSITORY
  - SQLAlchemy model (Base subclass) → NODE_ENTITY
  - Pydantic model → NODE_ENTITY

**Edges**:
  - ``injects`` — constructor (__init__) parameter type hints pointing to
    project-internal classes.
  - ``calls``   — method calls on injected fields (best-effort).
  - ``extends`` — superclass (filtered to non-stdlib types).

Two-pass resolution is NOT needed; the graph builder resolves names post-parse.
"""

from __future__ import annotations

from pathlib import Path

import tree_sitter_python as tspython
from tree_sitter import Language, Parser

from codemind.core.graph import (
    EDGE_CALLS,
    EDGE_EXTENDS,
    EDGE_INJECTS,
    NODE_CLASS,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
    NODE_SERVICE,
    GraphEdge,
    GraphNode,
)
from codemind.parser.base import BaseParser, ParseResult

# ── Python stdlib + common lib types — never create project edges to these ───

_SKIP: frozenset[str] = frozenset({
    # Builtins
    "str", "int", "float", "bool", "bytes", "list", "dict", "set", "tuple",
    "None", "Any", "Optional", "Union", "List", "Dict", "Set", "Tuple",
    "Type", "Callable", "Iterator", "Generator", "AsyncGenerator",
    "Awaitable", "Coroutine",
    # Pydantic / common
    "BaseModel", "BaseSettings",
    # SQLAlchemy
    "Base", "DeclarativeBase", "DeclarativeMeta",
    # FastAPI / Starlette
    "APIRouter", "FastAPI", "Request", "Response", "Depends",
    "HTTPException", "BackgroundTasks",
    # Django
    "Model", "ModelForm", "View", "ListView", "DetailView",
    "CreateView", "UpdateView", "DeleteView",
    # Standard exceptions
    "Exception", "ValueError", "TypeError", "RuntimeError",
    "KeyError", "IndexError", "AttributeError", "NotImplementedError",
    # Logging
    "Logger",
    # IO
    "Path", "IO",
})

# Decorator → node type
_DECORATOR_TYPE: dict[str, str] = {
    "router.get":      NODE_CONTROLLER,
    "router.post":     NODE_CONTROLLER,
    "router.put":      NODE_CONTROLLER,
    "router.delete":   NODE_CONTROLLER,
    "router.patch":    NODE_CONTROLLER,
    "app.get":         NODE_CONTROLLER,
    "app.post":        NODE_CONTROLLER,
    "app.put":         NODE_CONTROLLER,
    "app.delete":      NODE_CONTROLLER,
    "app.route":       NODE_CONTROLLER,
}

# Class name suffix → node type
_SUFFIX_TYPE: list[tuple[str, str]] = [
    ("ServiceImpl", NODE_SERVICE),
    ("Service",     NODE_SERVICE),
    ("Controller",  NODE_CONTROLLER),
    ("Router",      NODE_CONTROLLER),
    ("Repository",  NODE_REPOSITORY),
    ("Dao",         NODE_REPOSITORY),
    ("Entity",      NODE_ENTITY),
    ("Schema",      NODE_ENTITY),
]

# Superclass names → node type override
_SUPER_TYPE: dict[str, str] = {
    "BaseModel":      NODE_ENTITY,   # Pydantic
    "DeclarativeBase": NODE_ENTITY,  # SQLAlchemy 2.x
}


# ── AST helpers ────────────────────────────────────────────────────────────────


def _text(node, src: bytes) -> str:
    return src[node.start_byte:node.end_byte].decode("utf-8", errors="replace").strip()


def _get_decorators(node, src: bytes) -> list[str]:
    """Return decorator names from a class or function declaration."""
    result: list[str] = []
    for child in node.children:
        if child.type == "decorator":
            # decorator → "@" + (identifier | attribute | call)
            for c in child.children:
                if c.type in ("identifier", "attribute"):
                    result.append(_text(c, src))
                    break
                elif c.type == "call":
                    func = c.child_by_field_name("function")
                    if func:
                        result.append(_text(func, src))
                    break
    return result


def _strip_generics(t: str) -> str:
    """``List[User]`` → ``List``,  ``Optional[User]`` → ``Optional``."""
    return t.split("[")[0].strip()


def _superclasses(node, src: bytes) -> list[str]:
    """Return base class simple names from a class definition."""
    args = node.child_by_field_name("superclasses")
    if not args:
        return []
    result: list[str] = []
    for c in args.children:
        if c.type == "identifier":
            result.append(_text(c, src))
        elif c.type == "attribute":
            # e.g. models.Model → Model
            parts = _text(c, src).split(".")
            result.append(parts[-1])
    return result


def _class_name(node, src: bytes) -> str:
    n = node.child_by_field_name("name")
    return _text(n, src) if n else ""


def _node_type(name: str, decorators: list[str], superclasses: list[str]) -> str:
    # Superclass override (Pydantic BaseModel, SQLAlchemy Base)
    for sc in superclasses:
        sc_clean = _strip_generics(sc)
        if sc_clean in _SUPER_TYPE:
            return _SUPER_TYPE[sc_clean]
    # Decorator → type
    for dec in decorators:
        if dec in _DECORATOR_TYPE:
            return _DECORATOR_TYPE[dec]
    # Name suffix
    for suffix, t in _SUFFIX_TYPE:
        if name.endswith(suffix):
            return t
    return NODE_CLASS


def _init_injection_map(body, src: bytes) -> dict[str, str]:
    """Extract {param_name → type_name} from __init__ type hints.

    In tree-sitter-python, ``typed_parameter`` exposes:
      - The parameter name as the first ``identifier`` child (no field name).
      - The type via ``child_by_field_name("type")``.
    """
    if body is None:
        return {}
    result: dict[str, str] = {}
    for child in body.children:
        if child.type != "function_definition":
            continue
        fname = child.child_by_field_name("name")
        if not fname or _text(fname, src) != "__init__":
            continue
        params = child.child_by_field_name("parameters")
        if not params:
            continue
        for param in params.children:
            if param.type != "typed_parameter":
                continue
            # Name: first identifier child (no named field in tree-sitter-python)
            name_node = next(
                (c for c in param.children if c.type == "identifier"),
                None,
            )
            type_node = param.child_by_field_name("type")
            if not name_node or not type_node:
                continue
            pname = _text(name_node, src)
            if pname == "self":
                continue
            ptype = _strip_generics(_text(type_node, src))
            if ptype and ptype[0].isupper():
                result[pname] = ptype
    return result


def _methods(body, src: bytes) -> list[str]:
    if body is None:
        return []
    names: list[str] = []
    for child in body.children:
        if child.type == "function_definition":
            n = child.child_by_field_name("name")
            if n and not _text(n, src).startswith("_"):
                names.append(_text(n, src))
    return names


def _call_edges(body, src: bytes, node_id: str, field_map: dict[str, str]) -> list[GraphEdge]:
    """Emit ``calls`` edges for method calls on injected fields."""
    if body is None or not field_map:
        return []
    edges: list[GraphEdge] = []
    seen: set[str] = set()

    def walk(n) -> None:
        if n.type == "call":
            func = n.child_by_field_name("function")
            if func and func.type == "attribute":
                obj = func.child_by_field_name("object")
                attr = func.child_by_field_name("attribute")
                if obj and attr:
                    receiver = _text(obj, src)
                    if receiver.startswith("self."):
                        receiver = receiver[5:]
                    target_type = field_map.get(receiver)
                    if target_type and target_type not in seen and target_type not in _SKIP:
                        seen.add(target_type)
                        edges.append(GraphEdge(
                            source=node_id,
                            target=target_type,
                            kind=EDGE_CALLS,
                            meta={"method": _text(attr, src)},
                        ))
        for child in n.children:
            walk(child)

    walk(body)
    return edges


def _package_from_file(path: Path, project_root: Path) -> str:
    """Derive a dotted module path from the file's relative location."""
    try:
        rel = path.relative_to(project_root)
    except ValueError:
        rel = path
    parts = list(rel.parts)
    if parts and parts[-1].endswith(".py"):
        parts[-1] = parts[-1][:-3]
    # Drop leading "src" if present
    if parts and parts[0] == "src":
        parts = parts[1:]
    return ".".join(parts)


# ── Parser ────────────────────────────────────────────────────────────────────


class PythonParser(BaseParser):
    """Parses Python source files into CodeGraph nodes and edges."""

    language = "python"
    extensions = [".py"]

    def __init__(self) -> None:
        py_lang = Language(tspython.language())
        self._parser = Parser(py_lang)

    def parse(self, path: Path, project_root: Path) -> ParseResult:
        src = path.read_bytes()
        tree = self._parser.parse(src)

        try:
            rel = path.relative_to(project_root)
            file_rel = "/".join(rel.parts)
        except ValueError:
            file_rel = path.name

        pkg = _package_from_file(path, project_root)
        result = ParseResult(file=file_rel, language="python")

        for child in tree.root_node.children:
            if child.type == "class_definition":
                node, edges = self._process_class(child, src, file_rel, pkg)
                if node:
                    result.nodes.append(node)
                    result.edges.extend(edges)

        return result

    def _process_class(
        self,
        decl,
        src: bytes,
        file_rel: str,
        pkg: str,
    ) -> tuple[GraphNode | None, list[GraphEdge]]:
        name = _class_name(decl, src)
        if not name:
            return None, []

        # Skip test classes and private classes
        if name.startswith("_") or name.startswith("Test") or name.endswith("Test"):
            return None, []

        decorators = _get_decorators(decl, src)
        supers = _superclasses(decl, src)
        ntype = _node_type(name, decorators, supers)
        body = decl.child_by_field_name("body")
        methods = _methods(body, src)

        node_id = f"{pkg}.{name}" if pkg else name

        g_node = GraphNode(
            id=node_id,
            name=name,
            type=ntype,
            language="python",
            package=pkg,
            file=file_rel,
            methods=methods,
            annotations=decorators,
            superclass=supers[0] if supers else "",
            interfaces=[s for s in supers[1:] if s not in _SKIP],
            line=decl.start_point[0] + 1,
        )

        edges: list[GraphEdge] = []

        for sc in supers:
            sc_clean = _strip_generics(sc)
            # Always create extends edges, even for framework types like BaseModel —
            # they tell consumers what kind of component this is.
            if sc_clean and sc_clean[0].isupper():
                edges.append(GraphEdge(source=node_id, target=sc_clean, kind=EDGE_EXTENDS))

        imap = _init_injection_map(body, src)
        injected: set[str] = set()
        for _var, type_name in imap.items():
            if type_name in _SKIP or type_name in injected:
                continue
            injected.add(type_name)
            edges.append(GraphEdge(
                source=node_id,
                target=type_name,
                kind=EDGE_INJECTS,
                meta={"via": "__init__"},
            ))

        edges.extend(_call_edges(body, src, node_id, imap))

        return g_node, edges
