"""Gap detector — finds structural nodes that have zero graph connections.

A structural node (service, controller, entity, repository) with no inbound
OR outbound edges is evidence that the parser missed its dependency annotations
— for example, Lombok @RequiredArgsConstructor without explicit constructors,
@Resource injection, or a framework pattern the tree-sitter parser doesn't
know about yet.

These "orphaned" structural nodes are candidates for AI enrichment.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from codemind.core.graph import (
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
    NODE_SERVICE,
    CodeGraph,
)

# Only structural types are candidates for gap detection.
# Interfaces, enums, configs, etc. are intentionally ignored.
_STRUCTURAL: frozenset[str] = frozenset({
    NODE_SERVICE,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
})

# Languages the AI enricher knows how to analyse
_AI_LANGUAGES: frozenset[str] = frozenset({"java", "typescript", "python"})


@dataclass
class GapResult:
    """A single structural node with no detected connections.

    Attributes:
        node_id:   Fully-qualified node identifier.
        node_name: Simple class name (e.g. ``AdminService``).
        node_type: One of the ``NODE_*`` constants.
        language:  ``"java"`` | ``"typescript"`` | ``"python"``.
        file_path: Source file path relative to project root.
    """

    node_id: str
    node_name: str
    node_type: str
    language: str
    file_path: str

    @property
    def abs_path(self) -> Path:
        return Path(self.file_path)


class GapDetector:
    """Identifies structural nodes that have zero in/out edges.

    Usage::

        gaps = GapDetector().detect(graph, project_root)
        # gaps is a list of GapResult — nodes without any detected connections
    """

    def detect(
        self,
        graph: CodeGraph,
        project_root: Path | None = None,
    ) -> list[GapResult]:
        """Return every structural node that has no in or out edges.

        Nodes covered by at least one edge (any kind) are NOT returned.
        Test-class names (ends with Test/Tests/Spec/IT) are excluded — they
        are expected to be isolated in the graph.

        Args:
            graph:        The CodeGraph to inspect.
            project_root: Optional; used only for resolving absolute paths.

        Returns:
            Ordered list of GapResult (same order as graph.nodes iteration).
        """
        gaps: list[GapResult] = []
        for node in graph.nodes.values():
            if node.type not in _STRUCTURAL:
                continue
            if node.language not in _AI_LANGUAGES:
                continue
            # Skip test classes — they rarely inject anything
            if _is_test_class(node.name):
                continue
            has_out = bool(graph.edges_from(node.id))
            has_in = bool(graph.edges_to(node.id))
            if not has_out and not has_in:
                file_path = node.file
                if project_root:
                    abs_candidate = project_root / node.file
                    if abs_candidate.exists():
                        file_path = str(abs_candidate)
                gaps.append(GapResult(
                    node_id=node.id,
                    node_name=node.name,
                    node_type=node.type,
                    language=node.language,
                    file_path=file_path,
                ))
        return gaps


def _is_test_class(name: str) -> bool:
    """Return True if the class name looks like a test helper."""
    return (
        name.endswith("Test")
        or name.endswith("Tests")
        or name.endswith("Spec")
        or name.endswith("IT")
        or name.startswith("Test")
    )
