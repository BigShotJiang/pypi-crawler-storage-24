"""Parser registry — maps file extensions to the right parser instance."""

from __future__ import annotations

from pathlib import Path

from codemind.parser.base import BaseParser, ParseResult
from codemind.parser.java_parser import JavaParser
from codemind.parser.python_parser import PythonParser
from codemind.parser.typescript_parser import TypeScriptParser


class ParserRegistry:
    """Holds one instance of each parser and routes files to the right one.

    Usage::

        registry = ParserRegistry()
        result = registry.parse(path, project_root)  # None if no parser found
    """

    def __init__(self) -> None:
        self._parsers: list[BaseParser] = [
            JavaParser(),
            TypeScriptParser(),
            PythonParser(),
        ]

    def can_parse(self, path: Path) -> bool:
        """Return True if any registered parser handles this file extension."""
        return any(p.can_parse(path) for p in self._parsers)

    def parse(self, path: Path, project_root: Path) -> ParseResult | None:
        """Parse *path* with the appropriate parser.

        Args:
            path:         Absolute path to the source file.
            project_root: Project root directory (for relative path computation).

        Returns:
            A ParseResult, or None if no parser handles this file type.
        """
        for parser in self._parsers:
            if parser.can_parse(path):
                return parser.parse(path, project_root)
        return None

    @property
    def supported_extensions(self) -> list[str]:
        """All file extensions handled by registered parsers."""
        exts: list[str] = []
        for p in self._parsers:
            exts.extend(p.extensions)
        return exts
