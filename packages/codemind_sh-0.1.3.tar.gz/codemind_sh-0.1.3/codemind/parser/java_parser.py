"""Java AST parser — extracts GraphNodes and GraphEdges using tree-sitter.

What is extracted
-----------------
**Nodes** (one per class / interface / enum):
  - Name, fully-qualified ID (package.ClassName), type, package, methods, annotations.
  - Node type inferred from Spring annotations first, then class-name suffix heuristic.

**Edges** (typed relationships originating from each class):
  - ``injects``    — constructor parameters + @Autowired fields whose type is project-internal.
  - ``extends``    — superclass (filtered to non-stdlib types).
  - ``implements`` — interfaces (filtered to non-stdlib types).
  - ``calls``      — method invocations on injected fields, resolved via the field map.

Two-pass resolution is NOT needed here.  The parser emits edges using simple class
names as targets (e.g. ``"ThresholdEvaluator"``).  The graph builder performs a
post-pass to match targets to fully-qualified node IDs, so edges always point to
real graph nodes.
"""

from __future__ import annotations

from pathlib import Path

import tree_sitter_java as tsjava
from tree_sitter import Language, Parser

from codemind.core.graph import (
    EDGE_CALLS,
    EDGE_EXTENDS,
    EDGE_IMPLEMENTS,
    EDGE_INJECTS,
    NODE_ASPECT,
    NODE_CLASS,
    NODE_CONFIGURATION,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_ENUM,
    NODE_INTERCEPTOR,
    NODE_INTERFACE,
    NODE_REPOSITORY,
    NODE_SERVICE,
    GraphEdge,
    GraphNode,
)
from codemind.parser.base import BaseParser, ParseResult

# ── Java stdlib / framework types — never create project edges to these ────────

_SKIP: frozenset[str] = frozenset({
    # Primitives & wrappers
    "String", "Integer", "Long", "Double", "Float", "Boolean", "Byte", "Short",
    "Character", "Object", "Number", "Void", "Class",
    # Collections
    "List", "ArrayList", "LinkedList", "Map", "HashMap", "LinkedHashMap",
    "TreeMap", "Set", "HashSet", "LinkedHashSet", "TreeSet",
    "Collection", "Iterable", "Iterator", "Queue", "Deque", "EnumMap",
    # Functional
    "Optional", "Stream", "Comparable", "Serializable", "Cloneable",
    "Runnable", "Callable", "Supplier", "Function", "Consumer", "Predicate",
    "BiFunction", "BiConsumer",
    # I/O
    "InputStream", "OutputStream", "Reader", "Writer", "Path", "File",
    # Lang
    "Exception", "RuntimeException", "Error", "Throwable",
    "IllegalArgumentException", "IllegalStateException", "UnsupportedOperationException",
    "NullPointerException", "IndexOutOfBoundsException",
    "StringBuilder", "StringBuffer",
    # Spring framework classes (not project components)
    "ApplicationContext", "ApplicationEventPublisher", "MessageSource",
    "EntityManager", "PlatformTransactionManager",
    "HttpServletRequest", "HttpServletResponse", "HttpSession",
    "ResponseEntity", "HttpStatus",
    "BindingResult", "Model", "ModelAndView",
    "Pageable", "Page", "Sort", "Specification",
    # Lombok / common libs
    "Logger", "ObjectMapper", "ModelMapper",
    # JWT / auth
    "Claims", "Key",
    # Test
    "Assertions", "ArgumentMatchers", "MockMvc",
})

# ── Annotation → node type ────────────────────────────────────────────────────

_ANN_TYPE: dict[str, str] = {
    "Service":               NODE_SERVICE,
    "Component":             NODE_CLASS,
    "Repository":            NODE_REPOSITORY,
    "Controller":            NODE_CONTROLLER,
    "RestController":        NODE_CONTROLLER,
    "Entity":                NODE_ENTITY,
    "Table":                 NODE_ENTITY,
    "MappedSuperclass":      NODE_ENTITY,
    "Embeddable":            NODE_ENTITY,
    "Configuration":         NODE_CONFIGURATION,
    "EnableWebSecurity":     NODE_CONFIGURATION,
    "EnableAsync":           NODE_CONFIGURATION,
    "EnableScheduling":      NODE_CONFIGURATION,
    "Aspect":                NODE_ASPECT,
    "ControllerAdvice":      NODE_CLASS,
    "RestControllerAdvice":  NODE_CLASS,
    "HandlerInterceptor":    NODE_INTERCEPTOR,
}

# ── Class-name suffix → node type (fallback) ──────────────────────────────────

_SUFFIX_TYPE: list[tuple[str, str]] = [
    ("ServiceImpl",   NODE_SERVICE),
    ("Service",       NODE_SERVICE),
    ("Controller",    NODE_CONTROLLER),
    ("Resource",      NODE_CONTROLLER),
    ("RepositoryImpl",NODE_REPOSITORY),
    ("Repository",    NODE_REPOSITORY),
    ("Dao",           NODE_REPOSITORY),
    ("Entity",        NODE_ENTITY),
    ("Aspect",        NODE_ASPECT),
    ("Configuration", NODE_CONFIGURATION),
    ("Config",        NODE_CONFIGURATION),
    ("Interceptor",   NODE_INTERCEPTOR),
    ("Filter",        NODE_INTERCEPTOR),
]


# ── AST helpers ────────────────────────────────────────────────────────────────


def _text(node, src: bytes) -> str:
    """Decode the byte slice covered by *node*."""
    return src[node.start_byte:node.end_byte].decode("utf-8", errors="replace").strip()


def _child_text(node, field: str, src: bytes) -> str:
    c = node.child_by_field_name(field)
    return _text(c, src) if c else ""


def _get_modifiers(node):
    """Return the modifiers child node, with a type-based fallback.

    tree-sitter-java does not always expose ``modifiers`` as a named field —
    this depends on the installed grammar version.  We try the field name first,
    then scan children by node type to guarantee we find it.
    """
    mods = node.child_by_field_name("modifiers")
    if mods:
        return mods
    for child in node.children:
        if child.type == "modifiers":
            return child
    return None


def _annotations(node, src: bytes) -> list[str]:
    """Return annotation names from a declaration's ``modifiers`` child."""
    mods = _get_modifiers(node)
    if not mods:
        return []
    result: list[str] = []
    for child in mods.children:
        if child.type in ("marker_annotation", "annotation"):
            name_node = child.child_by_field_name("name")
            if name_node:
                result.append(_text(name_node, src))
    return result


def _node_type(name: str, anns: list[str], decl_kind: str) -> str:
    # Annotations take priority — @Repository on an interface → NODE_REPOSITORY
    for ann in anns:
        if ann in _ANN_TYPE:
            return _ANN_TYPE[ann]
    if decl_kind == "interface_declaration":
        return NODE_INTERFACE
    if decl_kind == "enum_declaration":
        return NODE_ENUM
    for suffix, t in _SUFFIX_TYPE:
        if name.endswith(suffix):
            return t
    return NODE_CLASS


def _package(root, src: bytes) -> str:
    for child in root.children:
        if child.type == "package_declaration":
            for c in child.children:
                if c.type in ("scoped_identifier", "identifier"):
                    return _text(c, src)
    return ""


def _superclass(node, src: bytes) -> str:
    sc = node.child_by_field_name("superclass")
    if not sc:
        return ""
    for c in sc.children:
        if c.type == "type_identifier":
            return _text(c, src)
    return ""


def _interfaces(node, src: bytes) -> list[str]:
    ifaces = node.child_by_field_name("interfaces")
    if not ifaces:
        return []
    result: list[str] = []
    for c in ifaces.children:
        if c.type == "type_list":
            for t in c.children:
                if t.type == "type_identifier":
                    result.append(_text(t, src))
        elif c.type == "type_identifier":
            result.append(_text(c, src))
    return result


def _methods(body, src: bytes) -> list[str]:
    if body is None:
        return []
    names: list[str] = []
    for child in body.children:
        if child.type == "method_declaration":
            n = child.child_by_field_name("name")
            if n:
                names.append(_text(n, src))
    return names


def _strip_generics(type_str: str) -> str:
    """``List<UserEntity>`` → ``List``."""
    return type_str.split("<")[0].strip()


def _field_map(body, src: bytes) -> dict[str, str]:
    """``{variable_name → type_name}`` for @Autowired / @Inject / final fields."""
    if body is None:
        return {}
    result: dict[str, str] = {}
    for child in body.children:
        if child.type != "field_declaration":
            continue
        mods = _get_modifiers(child)
        is_autowired = is_final = False
        if mods:
            for mc in mods.children:
                if mc.type in ("marker_annotation", "annotation"):
                    ann = _child_text(mc, "name", src)
                    if ann in ("Autowired", "Inject"):
                        is_autowired = True
                elif mc.type == "modifier" and _text(mc, src) == "final":
                    is_final = True
        if not is_autowired and not is_final:
            continue
        type_node = child.child_by_field_name("type")
        decl = child.child_by_field_name("declarator")
        if not type_node or not decl:
            continue
        type_name = _strip_generics(_text(type_node, src))
        var_node = decl.child_by_field_name("name")
        if var_node:
            result[_text(var_node, src)] = type_name
    return result


def _constructor_map(body, src: bytes) -> dict[str, str]:
    """``{param_name → type_name}`` from constructor parameters."""
    if body is None:
        return {}
    result: dict[str, str] = {}
    for child in body.children:
        if child.type != "constructor_declaration":
            continue
        params = child.child_by_field_name("parameters")
        if not params:
            continue
        for param in params.children:
            if param.type == "formal_parameter":
                t = param.child_by_field_name("type")
                n = param.child_by_field_name("name")
                if t and n:
                    result[_text(n, src)] = _strip_generics(_text(t, src))
    return result


def _call_edges(
    body,
    src: bytes,
    node_id: str,
    field_map: dict[str, str],
) -> list[GraphEdge]:
    """Walk method bodies; emit ``calls`` edges for invocations on injected fields."""
    if body is None or not field_map:
        return []
    edges: list[GraphEdge] = []
    seen: set[str] = set()

    def walk(n) -> None:
        if n.type == "method_invocation":
            obj = n.child_by_field_name("object")
            method = n.child_by_field_name("name")
            if obj and method:
                receiver = _text(obj, src)
                # Handle ``this.fieldName`` pattern
                if "." in receiver:
                    receiver = receiver.rsplit(".", 1)[-1]
                target_type = field_map.get(receiver)
                if target_type and target_type not in seen and target_type not in _SKIP:
                    seen.add(target_type)
                    edges.append(GraphEdge(
                        source=node_id,
                        target=target_type,
                        kind=EDGE_CALLS,
                        meta={"method": _text(method, src)},
                    ))
        for child in n.children:
            walk(child)

    walk(body)
    return edges


# ── Parser ────────────────────────────────────────────────────────────────────


class JavaParser(BaseParser):
    """Parses Java source files into CodeGraph nodes and edges."""

    language = "java"
    extensions = [".java"]

    def __init__(self) -> None:
        java_lang = Language(tsjava.language())
        self._parser = Parser(java_lang)

    def parse(self, path: Path, project_root: Path) -> ParseResult:
        src = path.read_bytes()
        tree = self._parser.parse(src)

        try:
            rel = path.relative_to(project_root)
            file_rel = "/".join(rel.parts)
        except ValueError:
            file_rel = path.name

        result = ParseResult(file=file_rel, language="java")
        pkg = _package(tree.root_node, src)

        for child in tree.root_node.children:
            if child.type in (
                "class_declaration",
                "interface_declaration",
                "enum_declaration",
            ):
                node, edges = self._process(child, src, file_rel, pkg)
                if node:
                    result.nodes.append(node)
                    result.edges.extend(edges)

        return result

    def _process(
        self,
        decl,
        src: bytes,
        file_rel: str,
        pkg: str,
    ) -> tuple[GraphNode | None, list[GraphEdge]]:
        name_node = decl.child_by_field_name("name")
        if not name_node:
            return None, []

        name = _text(name_node, src)
        anns = _annotations(decl, src)
        ntype = _node_type(name, anns, decl.type)
        superclass = _superclass(decl, src)
        ifaces = _interfaces(decl, src)
        body = decl.child_by_field_name("body")
        methods = _methods(body, src)

        node_id = f"{pkg}.{name}" if pkg else name

        g_node = GraphNode(
            id=node_id,
            name=name,
            type=ntype,
            language="java",
            package=pkg,
            file=file_rel,
            methods=methods,
            annotations=anns,
            interfaces=ifaces,
            superclass=superclass,
            line=decl.start_point[0] + 1,
        )

        edges: list[GraphEdge] = []

        if superclass and superclass not in _SKIP:
            edges.append(GraphEdge(source=node_id, target=superclass, kind=EDGE_EXTENDS))

        for iface in ifaces:
            if iface not in _SKIP:
                edges.append(GraphEdge(source=node_id, target=iface, kind=EDGE_IMPLEMENTS))

        fmap = _field_map(body, src)
        cmap = _constructor_map(body, src)
        combined = {**fmap, **cmap}  # constructor injection takes priority

        injected: set[str] = set()
        for var_name, type_name in combined.items():
            if type_name in _SKIP or not type_name or not type_name[0].isupper():
                continue
            if type_name in injected:
                continue
            injected.add(type_name)
            via = "constructor" if var_name in cmap else "@Autowired"
            edges.append(GraphEdge(
                source=node_id,
                target=type_name,
                kind=EDGE_INJECTS,
                meta={"via": via},
            ))

        edges.extend(_call_edges(body, src, node_id, combined))

        return g_node, edges
