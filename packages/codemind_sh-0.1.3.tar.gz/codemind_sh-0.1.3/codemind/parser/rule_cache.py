"""Rule cache — persist and apply AI-learned parser rules.

When Claude teaches CodeMind how to detect a new injection pattern (e.g.
Lombok @RequiredArgsConstructor, @Resource, or a custom DI framework),
the learned rule is written to:

    ~/.codemind/learned-parsers/{language}-rules.json

On the NEXT scan the rule is loaded and applied BEFORE gap detection runs,
so Claude's API is never called twice for the same pattern.

Rule format (JSON array of objects):
    {
        "language":     "java",
        "pattern_name": "lombok_required_args",
        "description":  "Lombok @RequiredArgsConstructor injects final fields",
        "annotation":   "RequiredArgsConstructor",
        "trigger":      "class_annotation",   // "class_annotation" | "field_annotation"
        "edge_kind":    "injects",
        "source":       "annotated_class",    // "annotated_class" | "annotated_field_owner"
        "target":       "final_field_types"   // "final_field_types" | "field_type" | "param_types"
    }
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

_DEFAULT_CACHE_DIR = Path.home() / ".codemind" / "learned-parsers"


@dataclass
class LearnedRule:
    """A single AI-taught injection pattern.

    Attributes:
        language:     ``"java"`` | ``"typescript"`` | ``"python"``.
        pattern_name: Stable identifier, e.g. ``"lombok_required_args"``.
        description:  Human-readable explanation of the rule.
        annotation:   Class or field annotation that triggers the rule (without @).
        trigger:      ``"class_annotation"`` or ``"field_annotation"``.
        edge_kind:    Typically ``"injects"``; could be ``"calls"`` etc.
        source:       ``"annotated_class"`` — the class carrying the annotation.
        target:       ``"final_field_types"`` | ``"field_type"`` | ``"param_types"``.
    """

    language: str
    pattern_name: str
    description: str
    annotation: str
    trigger: str
    edge_kind: str
    source: str
    target: str


class RuleCache:
    """Read/write AI-learned rules from/to the user's global cache.

    Usage::

        cache = RuleCache()
        rules = cache.load("java")                # empty list on first run
        cache.append(new_rule)                    # persists automatically
        all_rules = cache.load_all()              # across all languages
    """

    def __init__(self, cache_dir: Path | None = None) -> None:
        self._dir = cache_dir or _DEFAULT_CACHE_DIR

    # ── Loading ───────────────────────────────────────────────────────────────

    def load(self, language: str) -> list[LearnedRule]:
        """Load all cached rules for *language*.

        Returns an empty list if no cache file exists or the file is corrupt.
        """
        path = self._dir / f"{language}-rules.json"
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return [LearnedRule(**r) for r in data]
        except Exception:
            return []

    def load_all(self) -> list[LearnedRule]:
        """Load rules for every language that has a cache file."""
        if not self._dir.exists():
            return []
        rules: list[LearnedRule] = []
        for path in self._dir.glob("*-rules.json"):
            lang = path.stem.replace("-rules", "")
            rules.extend(self.load(lang))
        return rules

    # ── Saving ────────────────────────────────────────────────────────────────

    def save(self, language: str, rules: list[LearnedRule]) -> None:
        """Overwrite the cache file for *language* with *rules*."""
        self._dir.mkdir(parents=True, exist_ok=True)
        path = self._dir / f"{language}-rules.json"
        path.write_text(
            json.dumps([asdict(r) for r in rules], indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def append(self, rule: LearnedRule) -> None:
        """Add *rule* to the cache if its pattern_name is not already stored."""
        existing = self.load(rule.language)
        known = {r.pattern_name for r in existing}
        if rule.pattern_name not in known:
            existing.append(rule)
            self.save(rule.language, existing)

    def append_many(self, rules: list[LearnedRule]) -> int:
        """Append multiple rules, skipping duplicates.

        Returns the count of newly persisted rules.
        """
        added = 0
        # Group by language to minimise file I/O
        by_lang: dict[str, list[LearnedRule]] = {}
        for r in rules:
            by_lang.setdefault(r.language, []).append(r)
        for lang, lang_rules in by_lang.items():
            existing = self.load(lang)
            known = {r.pattern_name for r in existing}
            new = [r for r in lang_rules if r.pattern_name not in known]
            if new:
                self.save(lang, existing + new)
                added += len(new)
        return added

    # ── Clearing ──────────────────────────────────────────────────────────────

    def clear(self, language: str | None = None) -> None:
        """Remove cached rules for one language (or all if *language* is None)."""
        if language:
            path = self._dir / f"{language}-rules.json"
            if path.exists():
                path.unlink()
        else:
            if self._dir.exists():
                for path in self._dir.glob("*-rules.json"):
                    path.unlink()

    # ── Rule application ──────────────────────────────────────────────────────

    def rule_names(self, language: str) -> set[str]:
        """Return the set of pattern_names already cached for *language*."""
        return {r.pattern_name for r in self.load(language)}
