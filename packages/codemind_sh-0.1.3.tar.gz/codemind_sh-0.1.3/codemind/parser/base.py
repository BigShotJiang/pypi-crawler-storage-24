"""Base types shared by all language parsers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from codemind.core.graph import GraphEdge, GraphNode


@dataclass
class ParseResult:
    """Output of parsing a single source file.

    Attributes:
        file:     Relative path using forward slashes (e.g. ``src/main/java/.../Foo.java``).
        language: ``"java"`` | ``"typescript"`` | ``"python"``.
        nodes:    Components declared in this file.
        edges:    Relationships originating from components in this file.
                  Edges whose ``target`` does not exist in the project graph are
                  silently kept — the builder will later filter to internal ones
                  when needed, but storing external edges provides useful context.
    """

    file: str
    language: str
    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)


class BaseParser:
    """Abstract base for language-specific parsers.

    Subclasses must set:
        language:   Language string (``"java"``, ``"typescript"``, etc.)
        extensions: File suffixes this parser handles (e.g. ``[".java"]``).

    And implement:
        parse(path, project_root) → ParseResult
    """

    language: str = ""
    extensions: list[str] = []

    def can_parse(self, path: Path) -> bool:
        """Return True if this parser handles the given file."""
        return path.suffix.lower() in self.extensions

    def parse(self, path: Path, project_root: Path) -> ParseResult:
        """Parse *path* and return nodes + edges found in it.

        Args:
            path:         Absolute path to the source file.
            project_root: Absolute project root (used to compute relative paths).

        Returns:
            A ParseResult with nodes and edges for this file.
        """
        raise NotImplementedError
