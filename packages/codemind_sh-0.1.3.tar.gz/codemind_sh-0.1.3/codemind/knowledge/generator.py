"""Knowledge file generator — turns graph.json into human-readable markdown.

Produces two kinds of output on every ``codemind scan``:
- ``.codemind/ARCHITECTURE.md`` — project-wide overview (tech stack, domains, key components)
- ``.codemind/modules/{domain}.md`` — per-domain deep knowledge

Design notes
------------
- All writes are atomic (write to ``.tmp`` → rename) so a crashed scan never
  leaves a partially-written file.
- The old ``architecture.py`` uses the deprecated ``AnalyzerResult`` model and
  is not modified.  This module operates purely on ``CodeGraph``.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from codemind.core.graph import (
    CodeGraph,
    GraphNode,
    EDGE_INJECTS,
    EDGE_CALLS,
    EDGE_EXTENDS,
    EDGE_IMPLEMENTS,
    EDGE_IMPORTS,
    NODE_SERVICE,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_REPOSITORY,
    NODE_COMPONENT,
    NODE_MODULE,
    NODE_CONFIGURATION,
    NODE_INTERFACE,
    NODE_ENUM,
    NODE_CLASS,
    NODE_GUARD,
    NODE_INTERCEPTOR,
    NODE_ASPECT,
    NODE_DIRECTIVE,
    NODE_PIPE,
)

# ── Internal helpers ──────────────────────────────────────────────────────────


def _java_common_prefix_length(packages: list[str]) -> int:
    """Return the number of shared leading segments across all Java packages.

    Example: ``["com.app.kpi.auth", "com.app.kpi.business.kpi"]`` → ``3``
    """
    if not packages:
        return 0
    split = [p.split(".") for p in packages]
    min_len = min(len(parts) for parts in split)
    prefix_len = 0
    for i in range(min_len):
        if len({parts[i] for parts in split}) == 1:
            prefix_len += 1
        else:
            break
    return prefix_len


def _java_domain(package: str, prefix_len: int) -> str:
    """Map a Java package to a domain key using the computed prefix length.

    The segment at ``prefix_len`` is the domain name.  Special case: if that
    segment is ``"business"``, the next segment is appended (e.g.
    ``"business-kpi"``).
    """
    parts = package.split(".")
    if prefix_len >= len(parts):
        return "core"
    domain = parts[prefix_len]
    if domain == "business" and prefix_len + 1 < len(parts):
        domain = f"business-{parts[prefix_len + 1]}"
    return domain


def _ts_domain(package: str) -> str:
    """Map a TypeScript package path to a domain key.

    Looks for ``"src/app/"`` in the path and returns the first directory
    segment that follows it.  Falls back to ``"core"``.
    """
    marker = "src/app/"
    idx = package.find(marker)
    if idx == -1:
        return "core"
    rest = package[idx + len(marker):]
    parts = rest.split("/")
    if parts and parts[0]:
        return parts[0]
    return "core"


def _atomic_write(path: Path, content: str) -> None:
    """Write *content* to *path* atomically via a ``.md.tmp`` staging file."""
    tmp = path.with_suffix(".md.tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


# ── Public API ────────────────────────────────────────────────────────────────


def group_nodes_by_domain(graph: CodeGraph) -> dict[str, list[GraphNode]]:
    """Group every node in *graph* by its architectural domain.

    **Java**: common-prefix detection → domain is the segment immediately after
    the shared prefix.  If that segment is ``"business"``, the next segment is
    appended with a dash (``"business-kpi"``).

    **TypeScript**: find ``"src/app/"`` in the package path → domain is the
    first directory segment after it.

    **Fallback**: any node that cannot be classified → ``"core"``.

    Returns a ``dict`` sorted alphabetically by domain name.
    """
    java_packages = [
        n.package for n in graph.nodes.values()
        if n.language == "java" and n.package
    ]
    prefix_len = _java_common_prefix_length(java_packages)

    result: dict[str, list[GraphNode]] = {}
    for node in graph.nodes.values():
        if node.language == "java":
            domain = _java_domain(node.package, prefix_len)
        elif node.language == "typescript":
            domain = _ts_domain(node.package)
        else:
            domain = "core"
        result.setdefault(domain, []).append(node)

    return dict(sorted(result.items()))


def _generate_architecture_md(graph: CodeGraph, config=None) -> str:  # type: ignore[assignment]
    """Build ARCHITECTURE.md content from *graph*.

    Args:
        graph:  The live code knowledge graph.
        config: Optional ``CodemindConfig`` for tech-stack framework labels.

    Returns:
        Markdown string ready to be written to disk.
    """
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    project_name = graph.project or (
        config.project_name if config and config.project_name else "Project"
    )
    stats = graph.stats()

    lines: list[str] = []

    # ── Heading ──
    lines.append(f"# {project_name} — Architecture")
    lines.append("")
    lines.append(
        f"*Generated: {generated_at} — "
        f"{stats['total_nodes']:,} components, {stats['total_edges']:,} connections*"
    )
    lines.append("")

    # ── Tech Stack ──
    lines.append("## Tech Stack")
    lines.append("")
    lines.append("| Language | Framework |")
    lines.append("|----------|-----------|")

    lang_fw_map: dict[str, str] = {}
    if config:
        ts = config.tech_stack
        if ts.backend_language:
            lang_fw_map[ts.backend_language] = ts.backend_framework
        if ts.frontend_language:
            lang_fw_map[ts.frontend_language] = ts.frontend_framework

    rows: list[tuple[str, str]] = []
    for lang in graph.languages:
        rows.append((lang, lang_fw_map.get(lang, "")))

    # Frameworks not already mapped to a language
    mapped_fws = set(lang_fw_map.values())
    for fw in graph.frameworks:
        if fw not in mapped_fws:
            rows.append(("", fw))

    if not rows:
        rows = [("—", "—")]

    for lang, fw in rows:
        lines.append(f"| {lang} | {fw} |")
    lines.append("")

    # ── Domains ──
    domains = group_nodes_by_domain(graph)
    lines.append("## Domains")
    lines.append("")
    lines.append("| Domain | Language | Nodes | Services | Controllers | Entities | Repos |")
    lines.append("|--------|----------|-------|----------|-------------|----------|-------|")

    if domains:
        for domain, nodes in domains.items():
            langs = sorted({n.language for n in nodes})
            lang_str = ", ".join(langs)
            svc = sum(1 for n in nodes if n.type == NODE_SERVICE)
            ctrl = sum(1 for n in nodes if n.type == NODE_CONTROLLER)
            entity = sum(1 for n in nodes if n.type == NODE_ENTITY)
            repo = sum(1 for n in nodes if n.type == NODE_REPOSITORY)
            lines.append(
                f"| {domain} | {lang_str} | {len(nodes)} | {svc} | {ctrl} | {entity} | {repo} |"
            )
    else:
        lines.append("| — | — | 0 | 0 | 0 | 0 | 0 |")
    lines.append("")

    # ── Key Components ──
    lines.append("## Key Components")
    lines.append("")
    lines.append("| Name | Type | Package | Connections |")
    lines.append("|------|------|---------|-------------|")

    node_edge_counts: list[tuple[GraphNode, int]] = []
    for node_id, node in graph.nodes.items():
        total = len(graph.edges_from(node_id)) + len(graph.edges_to(node_id))
        node_edge_counts.append((node, total))

    node_edge_counts.sort(key=lambda x: -x[1])
    for node, count in node_edge_counts[:10]:
        lines.append(f"| {node.name} | {node.type} | {node.package} | {count} |")

    if not node_edge_counts:
        lines.append("| — | — | — | 0 |")
    lines.append("")

    # ── Connection Summary ──
    lines.append("## Connection Summary")
    lines.append("")

    edge_kinds: dict[str, int] = {}
    for edge in graph.edges:
        edge_kinds[edge.kind] = edge_kinds.get(edge.kind, 0) + 1

    if edge_kinds:
        for kind, count in sorted(edge_kinds.items()):
            lines.append(f"- {kind}: {count:,}")
    else:
        lines.append("*No connections yet.*")
    lines.append("")

    return "\n".join(lines)


# Node type → display section name, in preferred order
_TYPE_SECTIONS: list[tuple[str, str]] = [
    (NODE_SERVICE, "Services"),
    (NODE_CONTROLLER, "Controllers"),
    (NODE_ENTITY, "Entities"),
    (NODE_REPOSITORY, "Repositories"),
    (NODE_COMPONENT, "Components"),
    (NODE_MODULE, "Modules"),
    (NODE_CONFIGURATION, "Configurations"),
    (NODE_INTERFACE, "Interfaces"),
    (NODE_ENUM, "Enums"),
    (NODE_GUARD, "Guards"),
    (NODE_INTERCEPTOR, "Interceptors"),
    (NODE_ASPECT, "Aspects"),
    (NODE_DIRECTIVE, "Directives"),
    (NODE_PIPE, "Pipes"),
    (NODE_CLASS, "Classes"),
]


def _generate_module_md(domain: str, nodes: list[GraphNode], graph: CodeGraph) -> str:
    """Build a ``modules/{domain}.md`` file content.

    Args:
        domain: Domain key (e.g. ``"auth"``, ``"business-kpi"``).
        nodes:  All nodes that belong to this domain.
        graph:  Full graph (needed for cross-module connection analysis).

    Returns:
        Markdown string.
    """
    lines: list[str] = []
    langs = sorted({n.language for n in nodes})
    lang_str = ", ".join(langs)

    lines.append(f"# Module: {domain}")
    lines.append("")
    lines.append(f"*{len(nodes)} component(s) — {lang_str}*")
    lines.append("")

    # ── Per-type sections ──
    for node_type, section_name in _TYPE_SECTIONS:
        type_nodes = sorted(
            [n for n in nodes if n.type == node_type], key=lambda n: n.name
        )
        if not type_nodes:
            continue
        lines.append(f"### {section_name}")
        lines.append("")
        for node in type_nodes:
            if node.methods:
                shown = node.methods[:5]
                methods_str = " — " + ", ".join(f"{m}()" for m in shown)
            else:
                methods_str = ""
            lines.append(f"- **{node.name}**{methods_str}")
        lines.append("")

    # ── Cross-module connections ──
    lines.append("## Cross-module connections")
    lines.append("")

    all_domains = group_nodes_by_domain(graph)
    node_to_domain: dict[str, str] = {
        n.id: d for d, ns in all_domains.items() for n in ns
    }
    domain_node_ids = {n.id for n in nodes}
    cross_domains: dict[str, int] = {}

    for node in nodes:
        for edge in graph.edges_from(node.id):
            target_node = graph.resolve(edge.target)
            if target_node and target_node.id not in domain_node_ids:
                target_domain = node_to_domain.get(target_node.id, "core")
                cross_domains[target_domain] = cross_domains.get(target_domain, 0) + 1
        for edge in graph.edges_to(node.id):
            source_node = graph.nodes.get(edge.source)
            if source_node and source_node.id not in domain_node_ids:
                source_domain = node_to_domain.get(source_node.id, "core")
                cross_domains[source_domain] = cross_domains.get(source_domain, 0) + 1

    if cross_domains:
        for d, count in sorted(cross_domains.items(), key=lambda x: -x[1]):
            lines.append(f"- **{d}** — {count} connection(s)")
    else:
        lines.append("*No cross-module connections.*")
    lines.append("")

    return "\n".join(lines)


class KnowledgeGenerator:
    """Orchestrates generation of all knowledge files from a ``CodeGraph``.

    Usage::

        written = KnowledgeGenerator().generate_all(graph, project.codemind_dir, config)
        # returns {"ARCHITECTURE.md": Path(...), "modules/auth.md": Path(...), ...}
    """

    def generate_all(
        self,
        graph: CodeGraph,
        codemind_dir: Path,
        config=None,  # type: ignore[assignment]
    ) -> dict[str, Path]:
        """Write ARCHITECTURE.md and all modules/*.md files atomically.

        Args:
            graph:        The live code knowledge graph.
            codemind_dir: Path to the ``.codemind/`` directory.
            config:       Optional ``CodemindConfig`` for enriched tech-stack labels.

        Returns:
            Mapping of label (e.g. ``"ARCHITECTURE.md"``, ``"modules/auth.md"``)
            to the absolute path of the written file.
        """
        written: dict[str, Path] = {}

        # Write ARCHITECTURE.md
        arch_path = codemind_dir / "ARCHITECTURE.md"
        _atomic_write(arch_path, _generate_architecture_md(graph, config))
        written["ARCHITECTURE.md"] = arch_path

        # Write modules/*.md
        modules_dir = codemind_dir / "modules"
        modules_dir.mkdir(exist_ok=True)

        for domain, nodes in group_nodes_by_domain(graph).items():
            module_path = modules_dir / f"{domain}.md"
            _atomic_write(module_path, _generate_module_md(domain, nodes, graph))
            written[f"modules/{domain}.md"] = module_path

        return written
