"""index.json builder — component map and keyword index for fast lookup."""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path

from codemind.analyzer.base import AnalyzerResult
from codemind.analyzer.dependency_analyzer import DependencyResult
from codemind.core.config import CodemindConfig

# ── Data models ───────────────────────────────────────────────────────────────


@dataclass
class ComponentEntry:
    """A single code component recorded in the index.

    Attributes:
        name: Simple class / type name (e.g. ``UserService``).
        type: Semantic class type (``service``, ``controller``, ``entity``, …).
        language: Source language (``java``, ``typescript``, ``python``).
        package: Fully-qualified package / Angular module path.
        file: Relative file path using forward slashes.
        methods: Public method names (for keyword matching).
        annotations: Class-level annotations / decorators.
        superclass: Parent class name, empty if none.
        interfaces: Implemented interface names.
        uses: Component names that this component directly imports.
        used_by: Component names that import this component.
    """

    name: str
    type: str
    language: str
    package: str
    file: str
    methods: list[str] = field(default_factory=list)
    annotations: list[str] = field(default_factory=list)
    superclass: str = ""
    interfaces: list[str] = field(default_factory=list)
    uses: list[str] = field(default_factory=list)
    used_by: list[str] = field(default_factory=list)


@dataclass
class DependencyEntry:
    """A single dependency recorded in the index.

    Attributes:
        name: Package / artifact name.
        version: Resolved version string (empty if BOM-managed).
        category: Semantic category (``framework``, ``database``, ``auth``, …).
        scope: Lifecycle scope (``compile``, ``test``, ``dev``, …).
        source: Build file type (``maven``, ``npm``, ``pip``, ``poetry``).
    """

    name: str
    version: str
    category: str
    scope: str
    source: str


@dataclass
class ProjectIndex:
    """Complete project index for fast component lookup and context assembly.

    Attributes:
        project_name: Name of the project (from config).
        generated_at: ISO 8601 timestamp in UTC.
        languages: Languages found in the project (e.g. ``["java", "typescript"]``).
        frameworks: Detected primary frameworks (e.g. ``["spring-boot", "angular"]``).
        stats: Aggregate counts (total_classes, total_files, total_deps, prod_deps).
        components: All discovered classes / types.
        dependencies: All declared dependencies (deduplicated across build files).
        keywords: Lowercase keyword → list of component names (for fast lookup).
    """

    project_name: str
    generated_at: str
    languages: list[str]
    frameworks: list[str]
    stats: dict[str, int]
    components: list[ComponentEntry]
    dependencies: list[DependencyEntry]
    keywords: dict[str, list[str]]


# ── IndexBuilder ──────────────────────────────────────────────────────────────


class IndexBuilder:
    """Builds, saves, and loads the project index (index.json)."""

    def build(
        self,
        results: list[AnalyzerResult],
        dep_results: list[DependencyResult],
        config: CodemindConfig,
        project_root: Path,
    ) -> ProjectIndex:
        """Build a ProjectIndex from analyzer results.

        Args:
            results: Output of language analyzers (Java, TypeScript, Python).
            dep_results: Output of DependencyAnalyzer.
            config: Project configuration.
            project_root: Absolute project root (for computing relative paths).

        Returns:
            A fully-populated ProjectIndex.
        """
        components = self._build_components(results, project_root)
        dependencies = self._build_dependencies(dep_results)
        keywords = _build_keyword_index(components)

        languages = sorted({r.language for r in results if r.classes or r.files_analyzed})
        frameworks = sorted({dr.framework for dr in dep_results if dr.framework})

        total_classes = sum(len(r.classes) for r in results)
        total_files = sum(r.files_analyzed for r in results)
        total_deps = sum(len(dr.dependencies) for dr in dep_results)
        prod_deps = sum(len(dr.production_deps) for dr in dep_results)

        return ProjectIndex(
            project_name=config.project_name,
            generated_at=datetime.now(timezone.utc).isoformat(),
            languages=languages,
            frameworks=frameworks,
            stats={
                "total_classes": total_classes,
                "total_files": total_files,
                "total_deps": total_deps,
                "prod_deps": prod_deps,
            },
            components=components,
            dependencies=dependencies,
            keywords=keywords,
        )

    def save(self, index: ProjectIndex, path: Path) -> None:
        """Atomically write index.json (write to .tmp then rename).

        Args:
            index: The index to persist.
            path: Destination path (typically ``.codemind/index.json``).
        """
        data = {
            "project_name": index.project_name,
            "generated_at": index.generated_at,
            "languages": index.languages,
            "frameworks": index.frameworks,
            "stats": index.stats,
            "components": [asdict(c) for c in index.components],
            "dependencies": [asdict(d) for d in index.dependencies],
            "keywords": index.keywords,
        }
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, path: Path) -> ProjectIndex | None:
        """Load an existing index.json; return None if missing or corrupt.

        Args:
            path: Path to index.json.

        Returns:
            A ProjectIndex or None if the file cannot be parsed.
        """
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            _comp_fields = frozenset(f.name for f in fields(ComponentEntry))
            _dep_fields = frozenset(f.name for f in fields(DependencyEntry))
            components = [
                ComponentEntry(**{k: v for k, v in c.items() if k in _comp_fields})
                for c in data.get("components", [])
            ]
            dependencies = [
                DependencyEntry(**{k: v for k, v in d.items() if k in _dep_fields})
                for d in data.get("dependencies", [])
            ]
            return ProjectIndex(
                project_name=data.get("project_name", ""),
                generated_at=data.get("generated_at", ""),
                languages=data.get("languages", []),
                frameworks=data.get("frameworks", []),
                stats=data.get("stats", {}),
                components=components,
                dependencies=dependencies,
                keywords=data.get("keywords", {}),
            )
        except (KeyError, TypeError, json.JSONDecodeError):
            return None

    # ── Private ───────────────────────────────────────────────────────────────

    def _build_components(
        self, results: list[AnalyzerResult], project_root: Path
    ) -> list[ComponentEntry]:
        components: list[ComponentEntry] = []
        for result in results:
            for cls in result.classes:
                try:
                    rel = cls.file_path.relative_to(project_root)
                    file_str = "/".join(rel.parts)
                except ValueError:
                    file_str = cls.file_path.name

                components.append(
                    ComponentEntry(
                        name=cls.name,
                        type=cls.class_type,
                        language=result.language,
                        package=cls.package,
                        file=file_str,
                        methods=[m.name for m in cls.methods],
                        annotations=list(cls.annotations),
                        superclass=cls.superclass,
                        interfaces=list(cls.interfaces),
                    )
                )
        return components

    def _build_dependencies(
        self, dep_results: list[DependencyResult]
    ) -> list[DependencyEntry]:
        """Merge deps across all build files, deduplicating by (name, source_type)."""
        seen: set[tuple[str, str]] = set()
        deps: list[DependencyEntry] = []
        for dr in dep_results:
            for dep in dr.dependencies:
                key = (dep.name, dr.source_type)
                if key not in seen:
                    seen.add(key)
                    deps.append(
                        DependencyEntry(
                            name=dep.name,
                            version=dep.version,
                            category=dep.category,
                            scope=dep.scope,
                            source=dr.source_type,
                        )
                    )
        return deps


# ── Keyword index helpers ─────────────────────────────────────────────────────

_CAMEL_RE = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")

_STOP_WORDS: frozenset[str] = frozenset(
    {
        "the", "and", "for", "not", "with", "this", "that", "from",
        "base", "abstract", "impl", "helper", "util", "utils",
        "test", "spec", "mock", "stub", "dto", "config",
    }
)


def _camel_split(name: str) -> list[str]:
    """Split a CamelCase name into individual words (e.g. 'UserService' → ['User', 'Service'])."""
    return [p for p in _CAMEL_RE.split(name) if p]


def _build_keyword_index(components: list[ComponentEntry]) -> dict[str, list[str]]:
    """Build keyword → [component_name] mapping from CamelCase splits of class/package names."""
    index: dict[str, list[str]] = {}

    for comp in components:
        # Words from the class name itself
        words = _camel_split(comp.name)
        # Words from the leaf package segment (e.g. "service" from "com.example.service")
        if comp.package:
            leaf = comp.package.split(".")[-1]
            words += _camel_split(leaf) if leaf else []

        for word in words:
            w = word.lower()
            if len(w) >= 3 and w not in _STOP_WORDS:
                bucket = index.setdefault(w, [])
                if comp.name not in bucket:
                    bucket.append(comp.name)

    return dict(sorted(index.items()))
