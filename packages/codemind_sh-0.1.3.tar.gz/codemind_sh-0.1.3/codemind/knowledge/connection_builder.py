"""Build component connection maps from source-file import analysis.

Strategy
--------
* Java imports are fully-qualified names (``com.app.kpi…ClassName``).
  Extract the simple class name (last ``.``-segment) and match against
  the known component name set.

* TypeScript imports are module paths (``../../services/dept-service``).
  Extract the path basename (``dept-service``), strip ``.ts`` if present,
  and look up in a stem → component names map built from all TS component
  file paths.

* API mapping is name-based: strip the ``Service`` / ``Controller`` suffix,
  split CamelCase, and match Angular services to Java controllers that share
  at least one meaningful word.
"""

from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

from codemind.analyzer.base import AnalyzerResult
from codemind.knowledge.index_builder import ComponentEntry, ProjectIndex

# ── Java import exclusions ─────────────────────────────────────────────────────

_JAVA_SKIP_PREFIXES: frozenset[str] = frozenset({
    "java.", "javax.", "jakarta.", "org.springframework.", "org.hibernate.",
    "com.fasterxml.", "org.slf4j.", "lombok.", "org.junit.", "org.mockito.",
    "io.jsonwebtoken.", "org.mapstruct.", "org.apache.", "com.oracle.",
    "reactor.", "io.swagger.", "net.sf.", "org.thymeleaf.",
})

# ── TypeScript import exclusions ───────────────────────────────────────────────

_TS_SKIP_SOURCES: frozenset[str] = frozenset({
    "@angular", "rxjs", "@ngrx", "primeng", "ng-bootstrap",
    "@ng-bootstrap", "chart.js", "@swimlane", "primeflex",
    "@types", "moment", "date-fns", "lodash", "@material",
    "@angular/material",
})

# ── CamelCase splitter ─────────────────────────────────────────────────────────

_CAMEL_RE = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def _camel_words(name: str) -> list[str]:
    """Split ``DepartmentManagementService`` → ``['Department', 'Management', 'Service']``."""
    return [p for p in _CAMEL_RE.split(name) if p]


# ── ConnectionBuilder ──────────────────────────────────────────────────────────


class ConnectionBuilder:
    """Builds component-level ``uses`` / ``used_by`` connection maps.

    Usage::

        conn_data = ConnectionBuilder().build(index, analyzer_results, project_root)
        # conn_data = {"uses": {...}, "used_by": {...}}
        api_map = ConnectionBuilder().api_mapping(index.components)
    """

    def build(
        self,
        index: ProjectIndex,
        analyzer_results: list[AnalyzerResult],
        project_root: Path,
    ) -> dict[str, dict[str, list[str]]]:
        """Analyse import statements and return a bidirectional connection map.

        Args:
            index: The project index (components already built, imports not yet set).
            analyzer_results: Raw analyzer output containing ``AnalyzedClass.imports``.
            project_root: Absolute project root used to resolve relative file paths.

        Returns:
            ``{"uses": {comp_name: [comp_name, ...]}, "used_by": {comp_name: [...]}}``
        """
        name_set: set[str] = {c.name for c in index.components}

        # Build file→imports lookup from analyzer results
        # Key: absolute file path string; Value: raw import strings
        abs_file_imports: dict[str, list[str]] = {}
        abs_file_injections: dict[str, list[str]] = {}
        for result in analyzer_results:
            for cls in result.classes:
                abs_file_imports[str(cls.file_path)] = cls.imports
                if cls.injected_types:
                    abs_file_injections[str(cls.file_path)] = cls.injected_types

        # TypeScript: stem → component names (for module-path import resolution)
        ts_stem_map = self._build_ts_stem_map(index.components)

        uses_map: dict[str, list[str]] = defaultdict(list)
        used_by_map: dict[str, list[str]] = defaultdict(list)

        for comp in index.components:
            abs_path = str(project_root / comp.file)
            raw_imports = abs_file_imports.get(abs_path, [])

            if comp.language == "java":
                resolved = _resolve_java_imports(raw_imports, name_set)
                resolved += _resolve_java_injections(
                    abs_file_injections.get(abs_path, []), name_set
                )
            else:
                resolved = _resolve_ts_imports(raw_imports, name_set, ts_stem_map)

            if not resolved:
                continue

            resolved = [n for n in resolved if n != comp.name]
            if resolved:
                uses_map[comp.name] = sorted(set(resolved))
                for dep_name in resolved:
                    used_by_map[dep_name].append(comp.name)

        return {
            "uses": dict(uses_map),
            "used_by": {k: sorted(set(v)) for k, v in used_by_map.items()},
        }

    def api_mapping(
        self, components: list[ComponentEntry]
    ) -> list[tuple[str, str]]:
        """Match Angular services to Spring controllers by shared CamelCase words.

        Returns:
            Sorted list of ``(ts_service_name, java_controller_name)`` pairs.
        """
        _STRIP_SVC = ["ManagementService", "MappingService", "MapperService", "Service"]
        _STRIP_CTRL = ["Controller"]

        def core_words(name: str, strip_list: list[str]) -> set[str]:
            stripped = name
            for suffix in strip_list:
                if stripped.endswith(suffix):
                    stripped = stripped[: -len(suffix)]
                    break
            return {
                w.lower()
                for w in _camel_words(stripped)
                if len(w) >= 3 and w.lower() not in {"get", "set", "kpi", "app"}
            }

        controllers = {
            c.name: core_words(c.name, _STRIP_CTRL)
            for c in components
            if c.language == "java" and c.type == "controller"
        }
        ts_services = {
            c.name: core_words(c.name, _STRIP_SVC)
            for c in components
            if c.language == "typescript" and c.type == "service"
        }

        mappings: list[tuple[str, str]] = []
        seen: set[tuple[str, str]] = set()
        for svc_name, svc_words in ts_services.items():
            if not svc_words:
                continue
            for ctrl_name, ctrl_words in controllers.items():
                if svc_words & ctrl_words and (svc_name, ctrl_name) not in seen:
                    seen.add((svc_name, ctrl_name))
                    mappings.append((svc_name, ctrl_name))

        return sorted(mappings)

    # ── Private ───────────────────────────────────────────────────────────────

    @staticmethod
    def _build_ts_stem_map(components: list[ComponentEntry]) -> dict[str, list[str]]:
        """Map TypeScript file basenames (without extension) to component names.

        e.g. ``dept-service.ts`` → ``["DepartmentService"]``
        """
        stem_map: dict[str, list[str]] = defaultdict(list)
        for comp in components:
            if comp.language != "typescript":
                continue
            p = Path(comp.file)
            stem = p.stem.lower()  # e.g. "department.service" or "dept-service"
            stem_map[stem].append(comp.name)
            # Also map the last part after '.' for Angular convention filenames
            # "department.service" → also index as "department"
            dot_stem = stem.split(".")[0]
            if dot_stem != stem:
                stem_map[dot_stem].append(comp.name)
        return dict(stem_map)


# ── Import resolution helpers ──────────────────────────────────────────────────


def _resolve_java_imports(raw_imports: list[str], name_set: set[str]) -> list[str]:
    """Resolve Java FQN imports to simple component names.

    ``com.app.kpi.business.crud.service.DepartmentManagementService``
    → ``DepartmentManagementService``
    """
    result: list[str] = []
    for imp in raw_imports:
        if any(imp.startswith(prefix) for prefix in _JAVA_SKIP_PREFIXES):
            continue
        class_name = imp.split(".")[-1]
        if class_name == "*" or not class_name:
            continue
        if class_name in name_set:
            result.append(class_name)
    return result


def _resolve_java_injections(injected_types: list[str], name_set: set[str]) -> list[str]:
    """Resolve simple injected type names to known component names.

    Unlike :func:`_resolve_java_imports` (which parses FQN import statements),
    these are already simple names extracted directly from constructor parameters
    and ``@Autowired``/``final`` fields.  A direct set lookup is therefore
    sufficient — no package-prefix stripping required.

    This enables detection of same-package dependencies that have no import
    statement (e.g. ``PasswordResetService`` injecting ``EmailService`` when both
    live in ``com.app.kpi.auth.jwt.services``).
    """
    return [t for t in injected_types if t in name_set]


def _resolve_ts_imports(
    raw_imports: list[str],
    name_set: set[str],
    ts_stem_map: dict[str, list[str]],
) -> list[str]:
    """Resolve TypeScript module-path imports to component names.

    ``../../../../services/dept-service`` → ``["DepartmentService"]``
    """
    result: list[str] = []
    for imp in raw_imports:
        # Skip external packages
        if any(imp.startswith(skip) for skip in _TS_SKIP_SOURCES):
            continue
        if not imp.startswith("."):
            continue  # only process relative imports (project files)

        # Extract the last path segment as the stem
        stem = Path(imp).stem.lower()  # e.g. "dept-service" or "department.service"
        # Remove .ts if accidentally included
        if stem.endswith(".ts"):
            stem = stem[:-3]

        candidates = ts_stem_map.get(stem, [])
        # Also try just the first dot-part
        dot_stem = stem.split(".")[0]
        if dot_stem != stem:
            candidates = candidates + ts_stem_map.get(dot_stem, [])

        for name in candidates:
            if name in name_set and name not in result:
                result.append(name)

    return result


# ── Apply connections back to ComponentEntry objects ───────────────────────────


def apply_connections(
    components: list[ComponentEntry],
    conn_data: dict[str, dict[str, list[str]]],
) -> None:
    """Write ``uses`` / ``used_by`` back into each ``ComponentEntry`` in-place."""
    uses = conn_data.get("uses", {})
    used_by = conn_data.get("used_by", {})
    for comp in components:
        if comp.name in uses:
            comp.uses = uses[comp.name]
        if comp.name in used_by:
            comp.used_by = used_by[comp.name]
