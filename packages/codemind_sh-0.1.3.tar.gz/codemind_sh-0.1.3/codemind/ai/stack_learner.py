"""Stack learner — discovers component structure in completely unsupported stacks.

Unlike ``AIEnricher`` (which fills EDGE gaps for already-parsed nodes),
``StackLearner`` handles stacks where NO tree-sitter parser exists at all.
It sends sample source files to Claude and asks it to identify nodes AND edges
from scratch, then saves generalizable rules for future offline use.

Supported via this module: Dart/Flutter, C#/.NET, Ruby/Rails, Go, PHP, Swift,
Kotlin (standalone), Rust — anything lacking a built-in tree-sitter parser.

Workflow
--------
1. Walk project tree, collect files whose extension is not supported by any
   registered parser.
2. Group by extension. Skip extensions with too few files (< 2).
3. Sample up to ``_MAX_SAMPLE`` files per extension.
4. Call Claude with a "from-scratch structural analysis" prompt.
5. Materialise GraphNode + GraphEdge objects from the response.
6. Save generalizable rules to RuleCache for future offline use.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codemind.core.graph import CodeGraph

from codemind.core.graph import (
    EDGE_CALLS,
    EDGE_EXTENDS,
    EDGE_IMPLEMENTS,
    EDGE_INJECTS,
    NODE_CLASS,
    NODE_CONTROLLER,
    NODE_ENTITY,
    NODE_INTERFACE,
    NODE_REPOSITORY,
    NODE_SERVICE,
    GraphEdge,
    GraphNode,
)
from codemind.parser.rule_cache import LearnedRule, RuleCache

_MAX_SAMPLE = 10
_MAX_LINES = 80

# Map extension → language name hint sent to Claude
_EXT_LANG: dict[str, str] = {
    ".dart":   "Dart/Flutter",
    ".cs":     "C#/.NET",
    ".rb":     "Ruby/Rails",
    ".go":     "Go",
    ".php":    "PHP",
    ".swift":  "Swift/iOS",
    ".kt":     "Kotlin",
    ".rs":     "Rust",
    ".ex":     "Elixir",
    ".exs":    "Elixir",
}

_NODE_TYPE_MAP: dict[str, str] = {
    "service":     NODE_SERVICE,
    "controller":  NODE_CONTROLLER,
    "entity":      NODE_ENTITY,
    "repository":  NODE_REPOSITORY,
    "interface":   NODE_INTERFACE,
    "class":       NODE_CLASS,
}

_EDGE_KIND_MAP: dict[str, str] = {
    "injects":    EDGE_INJECTS,
    "calls":      EDGE_CALLS,
    "extends":    EDGE_EXTENDS,
    "implements": EDGE_IMPLEMENTS,
}

# Structural keywords — files matching these are sampled first
_STRUCTURAL_KEYWORDS = frozenset({
    "service", "controller", "repository", "handler", "router",
    "model", "entity", "dao", "manager", "provider", "store",
    "usecase", "interactor", "presenter", "viewmodel",
})


def _smart_sample(files: list[Path], max_n: int = _MAX_SAMPLE) -> list[Path]:
    """Return up to *max_n* files, prioritising structural ones over test/config files."""
    structural: list[Path] = []
    others: list[Path] = []
    for f in files:
        stem = f.stem.lower()
        # Skip obvious test files
        if stem.startswith("test_") or stem.endswith("_test") or stem.endswith("_spec"):
            continue
        if any(kw in stem for kw in _STRUCTURAL_KEYWORDS):
            structural.append(f)
        else:
            others.append(f)
    combined = structural + others
    return combined[:max_n]


_SYSTEM_PROMPT = """\
You are a senior software architect analyzing source files from an unfamiliar stack.
Given the files below, identify every significant component (class, provider, service,
repository, widget, controller, model, etc.) and its dependencies.

Respond ONLY with valid JSON matching this exact schema:
{
  "language": "Dart",
  "nodes": [
    {
      "name": "AuthService",
      "type": "service",
      "package": "lib/core/services",
      "file": "lib/core/services/auth_service.dart",
      "methods": ["signIn", "signOut"],
      "superclass": "ChangeNotifier",
      "interfaces": []
    }
  ],
  "edges": [
    {
      "source_name": "AuthService",
      "target_name": "ApiService",
      "kind": "injects",
      "via": "constructor parameter"
    }
  ],
  "rules": [
    {
      "language": "dart",
      "pattern_name": "riverpod_provider",
      "description": "Riverpod StateNotifierProvider — provides a service to widgets",
      "annotation": "StateNotifierProvider",
      "trigger": "class_annotation",
      "edge_kind": "injects",
      "source": "annotated_class",
      "target": "param_types"
    }
  ]
}

Valid "type" values: service, controller, entity, repository, interface, class.
Valid "kind" values: injects, calls, extends, implements.

Use "package" as the directory path (not dotted), e.g. "lib/core/services".
Only include edges between components that APPEAR in the files provided.
Return empty arrays if nothing applies. Do NOT include text outside the JSON.\
"""


@dataclass
class DiscoveryResult:
    """Result of a StackLearner.discover() call.

    Attributes:
        nodes_added:   Count of new graph nodes created.
        edges_added:   Count of new graph edges created.
        rules_learned: Count of rules saved to cache.
        language:      Language discovered (e.g. ``"Dart/Flutter"``).
        new_nodes:     The actual GraphNode objects added.
        new_edges:     The actual GraphEdge objects added.
        skipped_files: Files that could not be read.
    """

    nodes_added: int = 0
    edges_added: int = 0
    rules_learned: int = 0
    language: str = ""
    new_nodes: list[GraphNode] = field(default_factory=list)
    new_edges: list[GraphEdge] = field(default_factory=list)
    skipped_files: list[str] = field(default_factory=list)

    @property
    def discovered(self) -> bool:
        return self.nodes_added > 0


class StackLearner:
    """Discover component structure for unsupported languages via Claude.

    Usage::

        learner = StackLearner()
        results = learner.discover(project_root, graph, supported_exts, rule_cache)
        for r in results:
            print(f"Discovered {r.nodes_added} nodes from {r.language}")
    """

    def __init__(self, api_key: str | None = None) -> None:
        self._api_key = api_key

    @staticmethod
    def is_available(api_key: str | None = None) -> bool:
        """Return True if anthropic is installed and an API key exists."""
        try:
            import anthropic  # noqa: F401
        except ImportError:
            return False
        import os
        return bool(api_key or os.environ.get("ANTHROPIC_API_KEY"))

    def discover(
        self,
        project_root: Path,
        graph: "CodeGraph",
        supported_extensions: set[str],
        rule_cache: RuleCache | None = None,
        extra_exclude: set[str] | None = None,
    ) -> list[DiscoveryResult]:
        """Scan for unsupported files, call Claude, add nodes + edges.

        Args:
            project_root:        Project root directory.
            graph:               In-memory graph to patch.
            supported_extensions: Extensions already handled by tree-sitter parsers.
            rule_cache:          Optional cache for persisting learned rules.
            extra_exclude:       Additional path parts to exclude (same as builder).

        Returns:
            One DiscoveryResult per discovered language.
        """
        exclude = (extra_exclude or set()) | {
            "node_modules", "target", "build", "dist", ".git", ".codemind",
            "__pycache__", ".venv", "venv",
        }
        # Collect unsupported files grouped by extension
        ext_files: dict[str, list[Path]] = {}
        for path in project_root.rglob("*"):
            if not path.is_file():
                continue
            if any(part in exclude for part in path.parts):
                continue
            ext = path.suffix.lower()
            if ext in supported_extensions or ext not in _EXT_LANG:
                continue
            ext_files.setdefault(ext, []).append(path)

        results: list[DiscoveryResult] = []
        for ext, files in ext_files.items():
            if len(files) < 2:
                continue
            lang = _EXT_LANG.get(ext, ext)
            result = self._discover_extension(
                lang, _smart_sample(files), graph, project_root, rule_cache
            )
            results.append(result)

        return results

    def unsupported_extensions(
        self,
        project_root: Path,
        supported_extensions: set[str],
        extra_exclude: set[str] | None = None,
    ) -> dict[str, int]:
        """Return {extension: file_count} for files we cannot yet parse.

        Useful for showing the user what they would gain by setting an API key.
        """
        exclude = (extra_exclude or set()) | {
            "node_modules", "target", "build", "dist", ".git", ".codemind",
            "__pycache__", ".venv", "venv",
        }
        counts: dict[str, int] = {}
        for path in project_root.rglob("*"):
            if not path.is_file():
                continue
            if any(part in exclude for part in path.parts):
                continue
            ext = path.suffix.lower()
            if ext in supported_extensions or ext not in _EXT_LANG:
                continue
            counts[ext] = counts.get(ext, 0) + 1
        return counts

    # ── Private ───────────────────────────────────────────────────────────────

    def _discover_extension(
        self,
        language: str,
        files: list[Path],
        graph: "CodeGraph",
        project_root: Path,
        rule_cache: RuleCache | None,
    ) -> DiscoveryResult:
        result = DiscoveryResult(language=language)
        sample = files[:_MAX_SAMPLE]

        snippets: list[str] = []
        for f in sample:
            content = self._read_file(f)
            if content is None:
                result.skipped_files.append(str(f))
                continue
            try:
                rel = "/".join(f.relative_to(project_root).parts)
            except ValueError:
                rel = f.name
            snippets.append(f"=== [{rel}] ===\n{content}")

        if not snippets:
            return result

        user_message = (
            f"Language: {language}\n\n"
            + "\n\n".join(snippets)
        )

        try:
            payload = self._call_claude(user_message)
        except Exception:
            return result

        # Materialise nodes
        name_to_node: dict[str, GraphNode] = {}
        for nd in payload.get("nodes", []):
            name = nd.get("name", "")
            if not name:
                continue
            ntype = _NODE_TYPE_MAP.get(nd.get("type", "").lower(), NODE_CLASS)
            pkg = nd.get("package", "")
            lang_lower = payload.get("language", language).lower().split("/")[0].strip()
            file_rel = nd.get("file", f"{pkg}/{name}")
            node_id = f"{pkg}.{name}".replace("/", ".") if pkg else name
            g_node = GraphNode(
                id=node_id,
                name=name,
                type=ntype,
                language=lang_lower,
                package=pkg,
                file=file_rel,
                methods=nd.get("methods", []),
                superclass=nd.get("superclass", ""),
                interfaces=nd.get("interfaces", []),
                annotations=[],
            )
            graph.add_node(g_node)
            name_to_node[name] = g_node
            result.new_nodes.append(g_node)
            result.nodes_added += 1

        # Materialise edges
        for ed in payload.get("edges", []):
            src_name = ed.get("source_name", "")
            tgt_name = ed.get("target_name", "")
            kind = _EDGE_KIND_MAP.get(ed.get("kind", "").lower(), EDGE_INJECTS)
            via = ed.get("via", "ai_discovered")

            src_node = name_to_node.get(src_name)
            tgt_node = name_to_node.get(tgt_name)
            if not src_node or not tgt_node:
                continue
            edge = GraphEdge(
                source=src_node.id,
                target=tgt_node.id,
                kind=kind,
                meta={"via": via, "source": "ai_discovered"},
            )
            graph.add_edge(edge)
            result.new_edges.append(edge)
            result.edges_added += 1

        # Persist rules
        new_rules: list[LearnedRule] = []
        for rd in payload.get("rules", []):
            try:
                new_rules.append(LearnedRule(**rd))
            except (TypeError, KeyError):
                pass
        if new_rules and rule_cache:
            added = rule_cache.append_many(new_rules)
            result.rules_learned = added

        return result

    def _read_file(self, path: Path) -> str | None:
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            return "\n".join(lines[:_MAX_LINES])
        except OSError:
            return None

    def _call_claude(self, user_message: str) -> dict:
        import anthropic
        import os

        api_key = self._api_key or os.environ.get("ANTHROPIC_API_KEY")
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=3000,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_message}],
        )
        text = response.content[0].text.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        return json.loads(text)
