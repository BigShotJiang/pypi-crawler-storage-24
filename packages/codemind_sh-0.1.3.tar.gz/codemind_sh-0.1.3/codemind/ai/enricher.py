"""AI enricher — Claude teaches CodeMind about unknown injection patterns.

How it works
------------
1. The gap detector finds structural nodes (services, controllers, etc.) with
   zero connections in the graph.
2. The enricher reads those source files and sends them to Claude with a
   structured prompt asking: "what dependencies does this component inject?"
3. Claude returns a JSON payload with two parts:
      a. ``edges``   — specific edges to add RIGHT NOW for these files.
      b. ``rules``   — generalizable patterns to cache for future offline use.
4. The enricher adds the edges to the graph and persists the rules via
   RuleCache so no API call is made again for the same pattern.

This module deliberately has NO required imports from the ``anthropic`` package
at module level — it imports lazily so the package works without the AI extra.

Privacy
-------
Only file paths and source code of **orphaned** structural nodes are sent to
Claude.  No graph metadata, no business data, no unrelated files.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codemind.core.graph import CodeGraph

from codemind.core.graph import EDGE_INJECTS, GraphEdge, GraphNode
from codemind.parser.gap_detector import GapResult
from codemind.parser.rule_cache import LearnedRule, RuleCache

# Maximum source lines sent per file to keep tokens under control
_MAX_LINES_PER_FILE = 120

# Maximum number of gap files sent per enrichment call
_MAX_FILES_PER_CALL = 8

# Maximum lines of CLAUDE.md to include as project context
_MAX_CLAUDE_MD_LINES = 60

_SYSTEM_PROMPT = """\
You are a senior software architect analysing source code dependency patterns.
Given a set of source files, identify:
1. The injection dependencies each component uses (what it injects/requires).
2. Any GENERAL annotation-based rule that applies to all similar components.

Respond ONLY with valid JSON matching this schema exactly:
{
  "edges": [
    {
      "source_name": "ClassName",
      "target_name": "DependencyClassName",
      "kind": "injects",
      "via": "short description of injection mechanism"
    }
  ],
  "rules": [
    {
      "language": "java",
      "pattern_name": "unique_snake_case_id",
      "description": "Human-readable description",
      "annotation": "AnnotationName",
      "trigger": "class_annotation",
      "edge_kind": "injects",
      "source": "annotated_class",
      "target": "final_field_types"
    }
  ]
}

Rules for "trigger": "class_annotation" means the annotation is on the class
itself (e.g. @RequiredArgsConstructor). "field_annotation" means it is on the
field (e.g. @Autowired, @Resource).

Rules for "target":
- "final_field_types"  → inject all private final fields whose type is a known component
- "field_type"         → inject the type of the annotated field
- "param_types"        → inject all constructor parameter types

Return an empty list for edges or rules if none apply.
Do NOT include any text outside the JSON object.\
"""


def _read_claude_md(project_root: Path) -> str:
    """Read and truncate the project's CLAUDE.md for enrichment context.

    Returns an empty string if no CLAUDE.md exists.
    Only the first _MAX_CLAUDE_MD_LINES lines are included to keep token usage low.
    """
    candidate = project_root / "CLAUDE.md"
    if not candidate.exists():
        return ""
    try:
        lines = candidate.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[:_MAX_CLAUDE_MD_LINES])
    except OSError:
        return ""


@dataclass
class EnrichmentResult:
    """Output of a single Claude enrichment call.

    Attributes:
        edges_added:   Count of new graph edges that were injected.
        rules_learned: Count of new rules persisted to the cache.
        new_edges:     The actual GraphEdge objects added to the graph.
        new_rules:     The LearnedRule objects saved to cache.
        skipped_files: Files that could not be read.
    """

    edges_added: int = 0
    rules_learned: int = 0
    new_edges: list[GraphEdge] = None  # type: ignore[assignment]
    new_rules: list[LearnedRule] = None  # type: ignore[assignment]
    skipped_files: list[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.new_edges is None:
            self.new_edges = []
        if self.new_rules is None:
            self.new_rules = []
        if self.skipped_files is None:
            self.skipped_files = []

    @property
    def enhanced(self) -> bool:
        """True if at least one edge was added."""
        return self.edges_added > 0


@dataclass
class IndexResult:
    """Output of an index_file read operation.

    Attributes:
        nodes_added: Count of new GraphNode objects added to the graph.
        edges_added: Count of new GraphEdge objects added to the graph.
        new_nodes:   The actual GraphNode objects added.
        error:       Non-empty string if the operation failed.
        content:     Raw file snippet (populated by read_file_for_indexing).
        language:    Detected language name (populated by read_file_for_indexing).
        rel_path:    Project-relative file path (populated by read_file_for_indexing).
    """

    nodes_added: int = 0
    edges_added: int = 0
    new_nodes: list[GraphNode] = None  # type: ignore[assignment]
    error: str = ""
    content: str = ""
    language: str = ""
    rel_path: str = ""

    def __post_init__(self) -> None:
        if self.new_nodes is None:
            self.new_nodes = []


def add_component_to_graph(
    graph: "CodeGraph",
    codemind_dir: Path,
    name: str,
    node_type: str,
    file: str,
    language: str,
    description: str = "",
    methods: list[str] | None = None,
) -> GraphNode:
    """Add a single component to the graph and persist graph.json.

    Called by the ``add_component`` MCP tool after Claude has analysed a
    file with ``index_file`` and extracted each component.

    Args:
        graph:        The live CodeGraph to patch.
        codemind_dir: The ``.codemind/`` directory (for saving).
        name:         Class / service / widget name.
        node_type:    Component type (service, controller, widget, …).
        file:         Project-relative file path.
        language:     Language name (dart, kotlin, swift, …).
        description:  Optional one-line description.
        methods:      Optional list of public method names.

    Returns:
        The new GraphNode (already added to graph and saved).
    """
    pkg = str(Path(file).parent).replace("\\", "/")
    node_id = f"{pkg}/{name}".replace("\\", "/")
    node = GraphNode(
        id=node_id,
        name=name,
        type=node_type,
        language=language,
        package=pkg,
        file=file,
        methods=list(methods or []),
        metadata={"source": "ai_indexed", "description": description},
    )
    graph.add_node(node)
    from codemind.graph.store import GraphStore
    GraphStore().save(graph, codemind_dir)
    return node


# Map file extension → language name for index_file
_EXT_TO_LANG: dict[str, str] = {
    ".dart": "dart",
    ".kt": "kotlin",
    ".swift": "swift",
    ".go": "go",
    ".rb": "ruby",
    ".rs": "rust",
    ".cs": "csharp",
    ".php": "php",
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".java": "java",
}


class AIEnricher:
    """Uses Claude to discover missing edges for orphaned structural nodes.

    Usage (integrated into GraphBuilder)::

        enricher = AIEnricher(api_key="sk-...")
        result = enricher.enrich(gaps, graph, project_root, rule_cache)

    Usage (check availability)::

        if AIEnricher.is_available():
            enricher = AIEnricher()  # reads ANTHROPIC_API_KEY from env
    """

    MODEL = "claude-haiku-4-5-20251001"  # fast + cheap for structural analysis

    def __init__(self, api_key: str | None = None) -> None:
        self._api_key = api_key

    @staticmethod
    def is_available(api_key: str | None = None) -> bool:
        """Return True if the anthropic package is installed and an API key exists."""
        try:
            import anthropic  # noqa: F401
        except ImportError:
            return False
        import os
        return bool(api_key or os.environ.get("ANTHROPIC_API_KEY"))

    def enrich(
        self,
        gaps: list[GapResult],
        graph: "CodeGraph",
        project_root: Path,
        rule_cache: RuleCache | None = None,
    ) -> EnrichmentResult:
        """Call Claude with orphaned-node source files; add resulting edges + rules.

        Args:
            gaps:         Orphaned nodes from GapDetector.detect().
            graph:        The live CodeGraph to patch with new edges.
            project_root: Project root for resolving relative file paths.
            rule_cache:   Optional RuleCache; if provided, new rules are persisted.

        Returns:
            EnrichmentResult summary.
        """
        if not gaps:
            return EnrichmentResult()

        # Read project CLAUDE.md for domain context (truncated to keep tokens low)
        claude_md_context = _read_claude_md(project_root)

        result = EnrichmentResult()

        # Process in batches to stay within token budget
        for i in range(0, len(gaps), _MAX_FILES_PER_CALL):
            batch = gaps[i: i + _MAX_FILES_PER_CALL]
            batch_result = self._enrich_batch(
                batch, graph, project_root, rule_cache, claude_md_context
            )
            result.edges_added += batch_result.edges_added
            result.rules_learned += batch_result.rules_learned
            result.new_edges.extend(batch_result.new_edges)
            result.new_rules.extend(batch_result.new_rules)
            result.skipped_files.extend(batch_result.skipped_files)

        return result

    # ── Private helpers ───────────────────────────────────────────────────────

    def _enrich_batch(
        self,
        gaps: list[GapResult],
        graph: "CodeGraph",
        project_root: Path,
        rule_cache: RuleCache | None,
        claude_md_context: str = "",
    ) -> EnrichmentResult:
        result = EnrichmentResult()

        # Build file snippets
        snippets: list[str] = []
        for gap in gaps:
            content = self._read_file(gap, project_root)
            if content is None:
                result.skipped_files.append(gap.file_path)
                continue
            snippets.append(
                f"=== {gap.node_name} ({gap.node_type}, {gap.language}) "
                f"[{gap.file_path}] ===\n{content}"
            )

        if not snippets:
            return result

        # Prepend project context if available — helps Claude understand domain patterns
        parts: list[str] = []
        if claude_md_context:
            parts.append(
                f"=== PROJECT CONTEXT (from CLAUDE.md) ===\n{claude_md_context}\n"
                "=== END PROJECT CONTEXT ==="
            )
        parts.extend(snippets)
        user_message = "\n\n".join(parts)

        # Call Claude
        try:
            payload = self._call_claude(user_message)
        except Exception:
            return result

        # Apply edges
        name_to_id = {n.name: nid for nid, n in graph.nodes.items()}
        for edge_data in payload.get("edges", []):
            src_name = edge_data.get("source_name", "")
            tgt_name = edge_data.get("target_name", "")
            kind = edge_data.get("kind", EDGE_INJECTS)
            via = edge_data.get("via", "ai_enriched")

            src_id = name_to_id.get(src_name, src_name)
            tgt_id = name_to_id.get(tgt_name, tgt_name)

            if src_id and tgt_id and src_id != tgt_id:
                edge = GraphEdge(
                    source=src_id,
                    target=tgt_id,
                    kind=kind,
                    meta={"via": via, "source": "ai_enriched"},
                )
                graph.add_edge(edge)
                result.new_edges.append(edge)
                result.edges_added += 1

        # Persist rules
        new_rules: list[LearnedRule] = []
        for rule_data in payload.get("rules", []):
            try:
                rule = LearnedRule(**rule_data)
                new_rules.append(rule)
            except (TypeError, KeyError):
                pass

        if new_rules and rule_cache:
            added = rule_cache.append_many(new_rules)
            result.rules_learned = added
            result.new_rules = new_rules

        return result

    def _read_file(self, gap: GapResult, project_root: Path) -> str | None:
        """Read and truncate the source file for a gap node."""
        # Try absolute path first, then relative to project_root
        candidates = [
            Path(gap.file_path),
            project_root / gap.file_path,
        ]
        for candidate in candidates:
            if candidate.exists():
                try:
                    lines = candidate.read_text(encoding="utf-8", errors="replace").splitlines()
                    return "\n".join(lines[:_MAX_LINES_PER_FILE])
                except OSError:
                    return None
        return None

    def index_file(
        self,
        file_path: Path,
        graph: "CodeGraph",
        codemind_dir: Path,
    ) -> "IndexResult":
        """Read any source file and use AI to extract components + edges.

        Works for any language — Dart, Python, Kotlin, Swift, etc.
        Extracted nodes are added to the graph and persisted to graph.json.

        Args:
            file_path:    Absolute path to the source file.
            graph:        The live CodeGraph to patch with new nodes+edges.
            codemind_dir: The ``.codemind/`` directory (for saving graph).

        Returns:
            IndexResult with counts of nodes and edges added.
        """
        if not file_path.exists():
            return IndexResult(error=f"File not found: {file_path}")
        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return IndexResult(error=str(exc))

        ext = file_path.suffix.lower()
        language = _EXT_TO_LANG.get(ext, ext.lstrip(".") or "unknown")
        rel_path = str(file_path)
        try:
            project_root = codemind_dir.parent
            rel_path = str(file_path.relative_to(project_root))
        except ValueError:
            pass

        lines = content.splitlines()[:_MAX_LINES_PER_FILE]
        snippet = "\n".join(lines)

        user_message = (
            f"=== {file_path.name} ({language}) [{rel_path}] ===\n{snippet}"
        )

        try:
            payload = self._call_claude_index(user_message)
        except Exception as exc:
            return IndexResult(error=str(exc))

        result = IndexResult()
        for node_data in payload.get("nodes", []):
            name = node_data.get("name", "").strip()
            if not name:
                continue
            pkg = str(file_path.parent.relative_to(codemind_dir.parent)) if file_path.is_absolute() else str(Path(rel_path).parent)
            try:
                pkg = str(file_path.parent.relative_to(codemind_dir.parent))
            except ValueError:
                pkg = str(Path(rel_path).parent)
            node_id = f"{pkg}/{name}".replace("\\", "/")
            node = GraphNode(
                id=node_id,
                name=name,
                type=node_data.get("type", "class"),
                language=language,
                package=pkg,
                file=rel_path,
                methods=list(node_data.get("methods", [])),
                metadata={"source": "ai_indexed", "description": node_data.get("description", "")},
            )
            graph.add_node(node)
            result.nodes_added += 1
            result.new_nodes.append(node)

        name_to_id = {n.name: n.id for n in graph.nodes.values()}
        for edge_data in payload.get("edges", []):
            src = edge_data.get("source", "")
            tgt = edge_data.get("target", "")
            kind = edge_data.get("kind", "injects")
            src_id = name_to_id.get(src, src)
            tgt_id = name_to_id.get(tgt, tgt)
            if src_id and tgt_id and src_id != tgt_id:
                edge = GraphEdge(source=src_id, target=tgt_id, kind=kind,
                                 meta={"via": "ai_indexed"})
                graph.add_edge(edge)
                result.edges_added += 1

        if result.nodes_added > 0:
            from codemind.graph.store import GraphStore
            GraphStore().save(graph, codemind_dir)

        return result

    def read_file_for_indexing(self, file_path: Path, project_root: Path) -> IndexResult:
        """Read a source file and return its content for AI analysis.

        This does NOT call the Claude API. It reads the file and packages
        its content so the calling AI (Claude Code session) can analyze it
        and subsequently call ``add_component`` to persist each found component.

        Args:
            file_path:    Absolute path to the source file.
            project_root: Project root for computing relative paths.

        Returns:
            IndexResult with ``content`` (the file snippet) or ``error``.
        """
        if not file_path.exists():
            return IndexResult(error=f"File not found: {file_path}")
        try:
            raw = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return IndexResult(error=str(exc))

        ext = file_path.suffix.lower()
        language = _EXT_TO_LANG.get(ext, ext.lstrip(".") or "unknown")
        try:
            rel_path = str(file_path.relative_to(project_root))
        except ValueError:
            rel_path = str(file_path)

        lines = raw.splitlines()[:_MAX_LINES_PER_FILE]
        snippet = "\n".join(lines)
        result = IndexResult()
        result.content = snippet
        result.language = language
        result.rel_path = rel_path
        return result

    def _call_claude(self, user_message: str) -> dict:
        """Send the user message to Claude and parse the JSON response."""
        import anthropic
        import os

        api_key = self._api_key or os.environ.get("ANTHROPIC_API_KEY")
        client = anthropic.Anthropic(api_key=api_key)

        response = client.messages.create(
            model=self.MODEL,
            max_tokens=2048,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_message}],
        )

        text = response.content[0].text.strip()
        # Strip markdown code fences if present
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        return json.loads(text)

