"""Context engine — assembles relevant project context for AI coding tools."""

from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

from codemind.core.constants import ARCHITECTURE_FILE, DEFAULT_TOKEN_BUDGET
from codemind.knowledge.index_builder import ComponentEntry, IndexBuilder, ProjectIndex

# Rough characters-per-token estimate (conservative)
_CHARS_PER_TOKEN = 4

# ── Intent detection ───────────────────────────────────────────────────────────

_FIX_SIGNALS = frozenset({
    "fix", "repair", "debug", "solve", "resolve", "patch",
    "bug", "issue", "broken", "error", "crash", "wrong", "incorrect",
})
_MODULE_SIGNALS = frozenset({"module", "subsystem", "full", "complete", "end-to-end"})
_ADD_SIGNALS = frozenset({
    "add", "create", "implement", "build", "develop", "new", "write",
    "integrate", "connect",
})


def _parse_intent(query: str) -> str:
    """Classify the developer's intent: fix_bug | add_module | add_feature | general."""
    words = set(re.findall(r"[a-z]+", query.lower()))
    if words & _FIX_SIGNALS:
        return "fix_bug"
    if (words & _ADD_SIGNALS) and (words & _MODULE_SIGNALS):
        return "add_module"
    if words & _ADD_SIGNALS:
        return "add_feature"
    return "general"


# ── Keyword extraction ─────────────────────────────────────────────────────────

# Words filtered out before domain keyword matching.
# Includes: pure intent verbs, structural nouns, grammar words.
_STOP_WORDS: frozenset[str] = frozenset({
    # Grammar / articles / prepositions
    "the", "a", "an", "and", "or", "for", "in", "on", "at", "to",
    "of", "with", "by", "from", "that", "this", "is", "are", "was",
    "were", "be", "been", "being", "have", "has", "had", "do", "does",
    "did", "will", "would", "could", "should", "may", "might", "can",
    "i", "me", "my", "we", "our", "you", "your", "it", "its",
    # Intent verbs (not domain-specific)
    "add", "create", "implement", "build", "write", "fix", "update",
    "change", "show", "get", "find", "search", "look", "need", "want",
    "make", "new", "how", "develop", "integrate", "connect", "link",
    "attach", "improve", "refactor", "optimize", "debug", "solve",
    "resolve", "repair", "modify", "patch", "use", "uses", "using",
    "then", "also",
    # Structural nouns (too generic to discriminate)
    "module", "feature", "functionality", "system", "subsystem", "code",
    "service", "component", "class", "function", "method", "file",
    "page", "view", "layer", "api", "endpoint", "logic", "pattern",
})

_WORD_RE = re.compile(r"[A-Za-z]{3,}")


def _extract_keywords(query: str) -> set[str]:
    """Extract meaningful lowercase domain keywords from a natural language query."""
    words = _WORD_RE.findall(query)
    return {w.lower() for w in words if w.lower() not in _STOP_WORDS}


# ── Domain synonym expansion ───────────────────────────────────────────────────

_DOMAIN_SYNONYMS: dict[str, list[str]] = {
    # Strategic / planning
    "strategic":    ["department", "hierarchy", "organization", "goal", "initiative", "plan", "objective"],
    "planning":     ["department", "hierarchy", "goal", "initiative", "kpibuilder", "template", "objective"],
    "initiative":   ["kpibuilder", "goal", "plan", "strategic", "objective"],
    "initiatives":  ["kpibuilder", "goal", "plan", "strategic", "objective"],
    "goal":         ["kpi", "initiative", "target", "threshold", "metric", "objective"],
    "goals":        ["kpi", "initiative", "target", "threshold", "metric", "objective"],
    "objective":    ["goal", "kpi", "initiative", "target"],
    "target":       ["threshold", "kpi", "goal", "objective"],
    "plan":         ["planning", "strategic", "initiative", "goal"],
    # KPI / metrics
    "kpi":          ["kpibuilder", "kpicalculation", "kpihistory", "kpidefinition", "metric", "threshold", "performance"],
    "kpis":         ["kpibuilder", "kpicalculation", "kpihistory", "kpidefinition", "metric", "threshold", "performance"],
    "metric":       ["kpibuilder", "calculation", "history", "threshold", "kpi"],
    "metrics":      ["kpibuilder", "calculation", "history", "threshold", "kpi"],
    "calculation":  ["kpibuilder", "kpicalculation", "engine", "formula", "dataset", "parameter"],
    "engine":       ["kpicalculation", "calculation", "processor", "executor"],
    "formula":      ["kpibuilder", "kpicalculation", "calculation", "parameter"],
    "threshold":    ["kpibuilder", "kpicalculation", "notification", "email", "alert"],
    "thresholds":   ["kpibuilder", "kpicalculation", "notification", "email", "alert"],
    "performance":  ["kpi", "analytics", "dashboard", "history", "trend", "report"],
    "history":      ["kpihistory", "trend", "snapshot", "record", "archive"],
    "trend":        ["history", "kpihistory", "chart", "analytics", "performance"],
    "snapshot":     ["kpihistory", "history", "record"],
    # Email / notifications
    "email":        ["notification", "mail", "alert", "send", "smtp", "template", "message"],
    "notification": ["email", "mail", "alert", "scheduling", "event", "threshold", "message"],
    "alert":        ["email", "notification", "threshold", "scheduling", "event"],
    "mail":         ["email", "notification", "smtp", "message"],
    "smtp":         ["email", "mail", "notification"],
    "message":      ["email", "notification", "event", "alert"],
    "send":         ["email", "mail", "notification"],
    "drop":         ["threshold", "notification", "alert", "email", "kpicalculation"],
    "drops":        ["threshold", "notification", "alert", "email", "kpicalculation"],
    "below":        ["threshold", "kpicalculation", "kpihistory"],
    # Hierarchy / org structure
    "hierarchy":    ["department", "organization", "tree", "parent", "children", "node"],
    "organization": ["department", "hierarchy", "structure", "unit"],
    "department":   ["hierarchy", "organization", "crud", "management", "unit"],
    "departments":  ["hierarchy", "organization", "crud", "management", "unit"],
    "unit":         ["department", "organization", "hierarchy"],
    "org":          ["organization", "department", "hierarchy"],
    # Workflow / approval
    "workflow":     ["approval", "state", "transition", "process", "action", "status"],
    "workflows":    ["approval", "state", "transition", "process", "action", "status"],
    "approval":     ["workflow", "action", "state", "status", "transition", "review"],
    "transition":   ["workflow", "state", "approval", "status"],
    "transitions":  ["workflow", "state", "approval", "status"],
    "process":      ["workflow", "execution", "handler", "pipeline"],
    # Data / datasets
    "dataset":      ["datasource", "data", "query", "column", "warehouse", "table"],
    "datasource":   ["dataset", "connection", "database", "query", "source"],
    "data":         ["dataset", "datasource", "repository", "query"],
    "query":        ["dataset", "datasource", "repository", "database", "filter"],
    "database":     ["datasource", "dataset", "repository", "query", "connection"],
    # Auth / security
    "auth":         ["jwt", "security", "permission", "role", "keycloak", "sso", "token"],
    "authentication": ["auth", "jwt", "security", "keycloak", "login", "password"],
    "authorization": ["auth", "security", "role", "permission", "access"],
    "security":     ["auth", "jwt", "role", "permission", "access", "token"],
    "jwt":          ["auth", "token", "security", "authentication"],
    "keycloak":     ["auth", "sso", "security", "jwt"],
    "sso":          ["keycloak", "auth", "security"],
    "login":        ["auth", "authentication", "jwt", "security"],
    "password":     ["auth", "security", "reset", "email", "otp"],
    "otp":          ["password", "auth", "email", "verification"],
    "role":         ["auth", "permission", "authorization", "security"],
    "permission":   ["role", "auth", "security", "authorization"],
    "token":        ["jwt", "auth", "security"],
    # User management
    "user":         ["auth", "management", "role", "profile", "permission"],
    "profile":      ["user", "auth", "management"],
    # Analytics / reporting
    "report":       ["analytics", "dashboard", "chart", "performance", "export"],
    "dashboard":    ["chart", "analytics", "performance", "kpi", "department"],
    "analytics":    ["dashboard", "report", "chart", "performance", "trend"],
    "chart":        ["dashboard", "analytics", "trend", "performance"],
    "export":       ["report", "file", "download"],
    # Templates
    "template":     ["builder", "definition", "pattern", "scaffold", "templatebuilder"],
    "builder":      ["template", "kpibuilder", "definition", "factory", "templatebuilder"],
    # Scheduling
    "scheduling":   ["scheduler", "cron", "periodic", "background", "event"],
    "scheduler":    ["scheduling", "cron", "periodic", "background"],
    "cron":         ["scheduling", "scheduler", "periodic"],
    "background":   ["scheduling", "async", "event", "queue"],
    # Attendance
    "attendance":   ["employee", "record", "schedule", "tracking"],
}


def _expand_keywords(keywords: set[str]) -> set[str]:
    """Expand domain keywords with related synonyms (one hop)."""
    expanded = set(keywords)
    for kw in keywords:
        for related in _DOMAIN_SYNONYMS.get(kw, []):
            expanded.add(related)
    return expanded


# ── Component scoring ──────────────────────────────────────────────────────────

_TYPE_WEIGHTS: dict[str, float] = {
    "service":       3.0,
    "controller":    3.0,
    "entity":        2.5,
    "repository":    2.0,
    "component":     2.0,
    "advice":        1.5,
    "aspect":        1.5,
    "guard":         1.5,
    "interceptor":   1.5,
    "configuration": 1.2,
    "module":        1.0,
    "directive":     1.0,
    "class":         0.8,
    "interface":     0.5,
    "enum":          0.3,
}

_INTENT_TYPE_BOOST: dict[str, dict[str, float]] = {
    "add_module": {
        "service": 1.5, "controller": 1.5, "entity": 1.5,
        "repository": 1.4, "component": 1.5,
    },
    "fix_bug": {
        "service": 1.3, "controller": 1.2, "entity": 1.2,
        "aspect": 1.5, "advice": 1.5,
    },
    "add_feature": {
        "service": 1.3, "controller": 1.3, "entity": 1.2, "component": 1.3,
    },
}


def _leaf_package(package: str, language: str) -> str:
    """Extract the non-common-prefix (leaf) portion of a package for scoring.

    For Java ``com.app.kpi.business.crud.service`` → last 3 segments → ``kpi.business.crud``
    keeping enough context without matching the universal base prefix.
    For TypeScript paths, similar logic using ``/`` as separator.
    """
    if language == "java":
        parts = package.split(".")
        # Keep last 3 meaningful segments (skip universal prefix like com.app.kpi)
        return ".".join(parts[-3:]).lower() if len(parts) >= 3 else package.lower()
    else:
        parts = package.replace("\\", "/").split("/")
        return "/".join(parts[-3:]).lower() if len(parts) >= 3 else package.lower()


def _score_component(
    comp: ComponentEntry,
    direct_kws: set[str],
    expanded_kws: set[str],
    intent: str = "general",
) -> float:
    """Score a component for relevance to the query.

    Scoring weights:
    - Direct name match:      5.0 pts per keyword
    - Expanded name match:    2.0 pts per keyword
    - Direct leaf-pkg match:  2.0 pts per keyword
    - Expanded leaf-pkg:      0.5 pts per keyword
    - Direct method match:    1.0 pts per keyword
    - Expanded method match:  0.5 pts per keyword
    - Annotation / iface:     0.5 pts per keyword (direct only)
    - Method count bonus:     up to +0.5
    - Type weight multiplier: 0.3 (enum) – 3.0 (service/controller)
    - Intent boost:           up to 1.5×
    """
    score = 0.0
    name_lower = comp.name.lower()
    leaf_pkg = _leaf_package(comp.package, comp.language)
    method_text = " ".join(comp.methods).lower()
    annotation_text = " ".join(comp.annotations + comp.interfaces).lower()

    # Direct keyword matches (from the raw query)
    for kw in direct_kws:
        if kw in name_lower:
            score += 5.0
        if kw in leaf_pkg:
            score += 2.0
        if kw in method_text:
            score += 1.0
        if kw in annotation_text:
            score += 0.5

    # Expanded keyword matches (synonyms — lower weight)
    for kw in expanded_kws - direct_kws:
        if kw in name_lower:
            score += 2.0
        if kw in leaf_pkg:
            score += 0.5
        if kw in method_text:
            score += 0.5

    if score == 0.0:
        return 0.0

    # Method count bonus: richer classes rank higher
    score += min(len(comp.methods) * 0.1, 0.5)

    # Type weight (service/controller/entity outrank enums/interfaces)
    score *= _TYPE_WEIGHTS.get(comp.type, 1.0)

    # Intent-specific boost
    score *= _INTENT_TYPE_BOOST.get(intent, {}).get(comp.type, 1.0)

    return score


# ── Output formatting ──────────────────────────────────────────────────────────

_GROUP_ORDER = [
    "Backend — Services",
    "Backend — Controllers",
    "Backend — Entities",
    "Backend — Repositories",
    "Backend — Other",
    "Frontend — Components",
    "Frontend — Services",
    "Frontend — Other",
]

_BACKEND_GROUPS: dict[str, str] = {
    "service":       "Backend — Services",
    "controller":    "Backend — Controllers",
    "entity":        "Backend — Entities",
    "repository":    "Backend — Repositories",
}

_FRONTEND_GROUPS: dict[str, str] = {
    "component": "Frontend — Components",
    "service":   "Frontend — Services",
}


def _group_key(comp: ComponentEntry) -> str:
    """Assign a display group based on language + component type."""
    if comp.language == "java":
        return _BACKEND_GROUPS.get(comp.type, "Backend — Other")
    else:
        return _FRONTEND_GROUPS.get(comp.type, "Frontend — Other")


def _format_component(comp: ComponentEntry) -> str:
    """Format a ComponentEntry as a concise markdown block."""
    lines = [f"### `{comp.name}` ({comp.type})"]
    lines.append(f"- **Language:** {comp.language}")
    lines.append(f"- **Package:** `{comp.package}`")
    if comp.superclass:
        lines.append(f"- **Extends:** `{comp.superclass}`")
    if comp.interfaces:
        ifaces = ", ".join(f"`{i}`" for i in comp.interfaces)
        lines.append(f"- **Implements:** {ifaces}")
    if comp.annotations:
        lines.append(f"- **Annotations:** {', '.join(comp.annotations)}")
    if comp.methods:
        shown = comp.methods[:8]
        methods_str = ", ".join(f"`{m}`" for m in shown)
        if len(comp.methods) > 8:
            methods_str += f" *+{len(comp.methods) - 8} more*"
        lines.append(f"- **Methods:** {methods_str}")
    lines.append("")
    return "\n".join(lines)


# ── Connection traversal ───────────────────────────────────────────────────────

_CONN_SCORE_RATIO = 0.35  # connected components get 35% of connector's score
_CONN_THRESHOLD = 5.0     # only traverse from components with score ≥ this
_CONN_TOP_N = 5           # traverse at most the top N scoring components


def _expand_with_connections(
    scored: list[tuple[float, ComponentEntry]],
    index: ProjectIndex,
    direct_kws: frozenset[str],
) -> list[tuple[float, ComponentEntry]]:
    """Pull in components connected to top-scoring results via uses/used_by links.

    For each of the top-N components (score ≥ threshold), look up their
    ``uses`` and ``used_by`` neighbours and add them at a fraction of the
    connector's score.  Components already in the scored list are never
    duplicated.

    Only components whose name (lowercased) contains at least one direct query
    keyword are traversed.  This prevents high-scoring same-package neighbours
    (which score highly for package/type reasons) from cascading their unrelated
    connections into the results.
    """
    if not scored:
        return scored

    name_map: dict[str, ComponentEntry] = {c.name: c for c in index.components}
    already: set[str] = {comp.name for _, comp in scored}
    extras: dict[str, float] = {}

    for score, comp in scored[:_CONN_TOP_N]:
        if score < _CONN_THRESHOLD:
            break
        # Only traverse from components whose name directly matched the query
        name_lower = comp.name.lower()
        if not any(kw in name_lower for kw in direct_kws):
            continue
        conn_score = score * _CONN_SCORE_RATIO
        for connected_name in (comp.uses or []) + (comp.used_by or []):
            if connected_name not in already:
                extras[connected_name] = max(extras.get(connected_name, 0.0), conn_score)

    if not extras:
        return scored

    result = list(scored)
    for name, conn_score in extras.items():
        neighbour = name_map.get(name)
        if neighbour:
            result.append((conn_score, neighbour))

    result.sort(key=lambda x: -x[0])
    return result


# ── ContextEngine ──────────────────────────────────────────────────────────────


class ContextEngine:
    """Assembles relevant project context for a given natural language query.

    Strategy
    --------
    1. Always include the ARCHITECTURE.md header (overview + tech stack),
       stopping before the verbose Module Map section.
    2. Detect intent (fix_bug / add_module / add_feature / general).
    3. Extract domain keywords, expand with synonyms.
    4. Score each component with type weights and intent boosts.
    5. Output grouped by Backend/Frontend — Services/Controllers/Entities.
    6. For add_module: append a pattern example from an existing complete module.
    7. Append a compact dependency summary.
    """

    def get_context(
        self,
        query: str,
        codemind_dir: Path,
        token_budget: int = DEFAULT_TOKEN_BUDGET,
    ) -> str:
        """Generate a context string for the given natural language query.

        Args:
            query: Developer task description (e.g. "add user authentication").
            codemind_dir: Path to the ``.codemind/`` directory.
            token_budget: Approximate number of tokens to stay within.

        Returns:
            A formatted markdown context string suitable for prepending to an
            AI prompt.
        """
        char_budget = token_budget * _CHARS_PER_TOKEN
        parts: list[str] = []

        # 1. Architecture header ───────────────────────────────────────────────
        arch_header = self._load_arch_header(codemind_dir)
        parts.append(arch_header)
        char_budget -= len(arch_header)

        # 2. Load index
        index = IndexBuilder.load(codemind_dir / "index.json")
        if not index or char_budget <= 600:
            return "\n\n---\n\n".join(parts)

        # 3. Parse query ───────────────────────────────────────────────────────
        intent = _parse_intent(query)
        direct_kws = _extract_keywords(query)
        expanded_kws = _expand_keywords(direct_kws)

        # 4. Relevant components ──────────────────────────────────────────────
        comp_section = self._relevant_components(
            direct_kws, expanded_kws, intent, index, char_budget - 500
        )
        if comp_section:
            parts.append(comp_section)
            char_budget -= len(comp_section)

        # 5. Pattern example (add_module only) ────────────────────────────────
        if intent == "add_module" and char_budget > 500:
            pattern = self._pattern_section(index)
            if pattern:
                parts.append(pattern)
                char_budget -= len(pattern)

        # 6. Dependency summary ───────────────────────────────────────────────
        if char_budget > 200:
            parts.append(self._dep_summary(index))

        return "\n\n---\n\n".join(parts)

    # ── Private ───────────────────────────────────────────────────────────────

    def _load_arch_header(self, codemind_dir: Path) -> str:
        """Return ARCHITECTURE.md up to (but not including) the Module Map section."""
        arch_path = codemind_dir / ARCHITECTURE_FILE
        if not arch_path.exists():
            return (
                "# Project Architecture\n\n"
                "*Run `codemind scan` to generate architecture documentation.*"
            )

        lines = arch_path.read_text(encoding="utf-8").splitlines()

        # Cut off before the verbose Module Map or Statistics sections
        cutoff = len(lines)
        for i, line in enumerate(lines):
            if line.startswith("## Module Map") or line.startswith("## Statistics"):
                cutoff = i
                break

        return "\n".join(lines[:cutoff]).strip()

    def _relevant_components(
        self,
        direct_kws: set[str],
        expanded_kws: set[str],
        intent: str,
        index: ProjectIndex,
        char_budget: int,
    ) -> str:
        """Find and format the most relevant components, grouped by type category."""
        if not direct_kws and not expanded_kws:
            return ""

        # Score every component
        scored: list[tuple[float, ComponentEntry]] = []
        for comp in index.components:
            score = _score_component(comp, direct_kws, expanded_kws, intent)
            if score > 0:
                scored.append((score, comp))

        scored.sort(key=lambda x: -x[0])
        if not scored:
            return ""

        # Connection traversal: pull in directly linked components
        scored = _expand_with_connections(scored, index, frozenset(direct_kws))

        # Group by display category
        groups: dict[str, list[tuple[float, ComponentEntry]]] = defaultdict(list)
        for score, comp in scored:
            groups[_group_key(comp)].append((score, comp))

        header = "## Relevant Components\n"
        body_parts: list[str] = []
        used = len(header)

        for group_name in _GROUP_ORDER:
            comps_in_group = groups.get(group_name, [])
            if not comps_in_group:
                continue

            group_header = f"\n### {group_name}\n\n"
            group_entries: list[str] = []

            for _, comp in comps_in_group[:5]:  # max 5 per group
                entry = _format_component(comp)
                if used + len(group_header) + len(entry) + sum(len(e) for e in group_entries) > char_budget:
                    break
                group_entries.append(entry)

            if group_entries:
                block = group_header + "\n".join(group_entries)
                body_parts.append(block)
                used += len(block)

        if not body_parts:
            # Fallback: flat list for small budgets
            for _, comp in scored[:10]:
                entry = _format_component(comp)
                if used + len(entry) > char_budget:
                    break
                body_parts.append(entry)
                used += len(entry)

        if not body_parts:
            return ""

        return header + "".join(body_parts)

    def _pattern_section(self, index: ProjectIndex) -> str:
        """Show the most complete existing Java module as a copy-me pattern."""
        domain_types: dict[str, set[str]] = defaultdict(set)
        domain_comps: dict[str, list[ComponentEntry]] = defaultdict(list)

        for comp in index.components:
            if comp.language != "java":
                continue
            parts = comp.package.split(".")
            # Use the 5th segment as the domain key (e.g. "crud", "kpibuilder")
            if len(parts) >= 5:
                domain = parts[4]
                domain_types[domain].add(comp.type)
                domain_comps[domain].append(comp)

        # Find domain with the most complete service+controller+entity+repository stack.
        # Tiebreak: prefer domains whose components live under a "business" parent package
        # (package segment index 3 == "business") so auth/jwt modules don't win on ties.
        best_domain = ""
        best_score = 0
        best_is_business = False
        for domain, types in domain_types.items():
            completeness = (
                (3 if "service" in types else 0)
                + (2 if "controller" in types else 0)
                + (2 if "entity" in types else 0)
                + (1 if "repository" in types else 0)
            )
            is_business = any(
                len(comp.package.split(".")) >= 4
                and comp.package.split(".")[3] == "business"
                for comp in domain_comps[domain]
            )
            if completeness > best_score or (
                completeness == best_score and is_business and not best_is_business
            ):
                best_score = completeness
                best_domain = domain
                best_is_business = is_business

        if not best_domain or best_score < 4:
            return ""

        lines = [f"## Example Module Pattern: `{best_domain}`\n"]
        lines.append("*Follow this structure when creating a new module:*\n")
        for comp in domain_comps[best_domain]:
            if comp.type in ("service", "controller", "entity", "repository"):
                lines.append(
                    f"- **{comp.type.title()}**: `{comp.name}` → `{comp.package}`"
                )
        lines.append("")
        return "\n".join(lines)

    def _dep_summary(self, index: ProjectIndex) -> str:
        """Return a compact dependency overview grouped by category."""
        lines: list[str] = ["## Key Dependencies", ""]

        if index.frameworks:
            lines.append(f"**Frameworks:** {', '.join(index.frameworks)}")

        # Group production deps by category (framework already shown above)
        by_cat: dict[str, list[str]] = {}
        for dep in index.dependencies:
            if dep.scope not in ("test", "dev") and dep.category != "framework":
                by_cat.setdefault(dep.category, []).append(dep.name)

        for cat in ("database", "auth", "cache", "messaging", "http", "ui", "utility"):
            names = by_cat.get(cat, [])
            if names:
                lines.append(f"**{cat.title()}:** {', '.join(names[:6])}")

        return "\n".join(lines)
