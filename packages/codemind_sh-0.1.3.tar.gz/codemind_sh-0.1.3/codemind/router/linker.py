"""Cross-layer linker — matches frontend API calls to backend routes.

After `route_extractor.enrich_graph_with_routes` and
`call_extractor.enrich_graph_with_api_calls` have populated node metadata,
this module creates EDGE_CROSS_LAYER edges connecting:

  Frontend component/service  →  Backend controller

Two complementary strategies are used:

1. **HTTP call detection** (``create_cross_layer_edges``):
   Reads ``metadata.api_calls`` populated by the call extractor.
   High precision when URL construction patterns are recognised.

2. **Route-first path fragment matching** (``route_first_link``):
   Entry-point-first: only processes files that actually use an HTTP client
   (HttpClient, fetch, axios, …).  Extracts path evidence in two ways:

   a. Path string literals directly in the service file (high confidence).
   b. Constant resolution: for patterns like
      ``buildApiUrl(API_CONFIG.AUTH.LOGIN)``, the full dotted reference
      ``AUTH.LOGIN`` is extracted and its specific value is looked up in
      the imported constants file — NOT the entire file.  This prevents
      the false-positive explosion when a shared ``API_CONFIG`` contains
      all routes but each service uses only a subset.

   Works for any URL construction pattern without project-specific
   configuration.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

from codemind.core.graph import EDGE_CROSS_LAYER, GraphEdge

if TYPE_CHECKING:
    from codemind.core.graph import CodeGraph


# ── Path-match helpers ────────────────────────────────────────────────────────

def _paths_match(frontend_path: str, backend_path: str) -> bool:
    """Check if a frontend call path matches a backend route.

    Both paths should already be normalised (lowercase, variables → {*}).
    """
    if frontend_path == backend_path:
        return True
    if frontend_path.startswith(backend_path.rstrip("/") + "/"):
        return True
    if backend_path.startswith(frontend_path.rstrip("/") + "/"):
        return True
    return False


# ── Strategy 1: HTTP-call-based matching ─────────────────────────────────────

def create_cross_layer_edges(graph: "CodeGraph") -> int:
    """Scan graph nodes and create EDGE_CROSS_LAYER edges.

    For every frontend node with ``metadata.api_calls`` and every backend
    controller with ``metadata.routes``, create an edge when any call path
    matches any route path.

    Returns the number of new edges created.
    """
    route_index: dict[str, list[str]] = {}
    for node in graph.nodes.values():
        routes = node.metadata.get("routes", []) if node.metadata else []
        for path in routes:
            route_index.setdefault(path, []).append(node.id)

    if not route_index:
        return 0

    existing: set[tuple[str, str]] = {
        (e.source, e.target) for e in graph.edges if e.kind == EDGE_CROSS_LAYER
    }

    new_edges: list[GraphEdge] = []
    for node in graph.nodes.values():
        api_calls = node.metadata.get("api_calls", []) if node.metadata else []
        if not api_calls:
            continue
        matched_targets: set[str] = set()
        for call_path in api_calls:
            for route_path, controller_ids in route_index.items():
                if _paths_match(call_path, route_path):
                    for cid in controller_ids:
                        if cid != node.id and (node.id, cid) not in existing:
                            matched_targets.add(cid)
        for target_id in matched_targets:
            new_edges.append(GraphEdge(
                source=node.id,
                target=target_id,
                kind=EDGE_CROSS_LAYER,
                meta={"via": "http_route"},
            ))
            existing.add((node.id, target_id))

    graph.edges.extend(new_edges)
    graph._rebuild_indices()
    return len(new_edges)


# ── Strategy 2: Route-first path fragment matching ────────────────────────────

# Entry-point signal: file actually uses an HTTP client
_HTTP_CLIENT_RE = re.compile(
    r'\b(?:HttpClient|fetch\s*\(|axios(?:\s*\.\s*(?:get|post|put|delete|patch|create))?'
    r'|useSWR|useQuery|useFetch|http\s*\.\s*(?:get|post|put|delete|patch)'
    r'|XMLHttpRequest|\$http|HttpService)\b',
    re.MULTILINE | re.IGNORECASE,
)

# HTTP call site — used to locate argument spans
_HTTP_CALL_RE = re.compile(
    r'(?:this\.)?\bhttp\s*\n?\s*\.\s*(?:get|post|put|delete|patch|request)'
    r'|(?:^|\s)fetch\s*\('
    r'|\baxios\s*\.\s*(?:get|post|put|delete|patch)\s*\(',
    re.MULTILINE | re.IGNORECASE,
)

# Full dotted constant reference, e.g. API_CONFIG.AUTH.LOGIN
# (2+ segments, each UPPERCASE_WITH_UNDERSCORES)
_DOTTED_CONST_RE = re.compile(
    r'\b[A-Z_][A-Z0-9_]*(?:\.[A-Z_][A-Z0-9_]+){1,}\b'
)

# Quoted path strings: '/api/kpis/definitions'  or  `/api/kpis/${id}`
_PATH_LITERAL_RE = re.compile(
    r"""(?:["'])(/[a-zA-Z0-9_\-/]+)(?:["'])"""
    r"""|`(/[a-zA-Z0-9_\-/${}/*]+)`""",
    re.MULTILINE,
)

# Segments too generic to prove a match on their own
_GENERIC_SEGS = frozenset({
    "api", "v1", "v2", "v3", "v4", "app", "rest", "service",
    "web", "public", "private", "data", "info",
})


def _extract_path_literals(source: str) -> list[str]:
    """Extract URL path string literals (2+ meaningful segments) from source."""
    paths: list[str] = []
    for m in _PATH_LITERAL_RE.finditer(source):
        raw = m.group(1) or m.group(2) or ""
        p = re.sub(r"\$\{[^}]+\}|:\w+|\{[^}]+\}", "{*}", raw).lower()
        segs = [s for s in p.strip("/").split("/") if s]
        if len(segs) < 2:
            continue
        meaningful = [s for s in segs if s != "{*}" and s not in _GENERIC_SEGS]
        if not meaningful:
            continue
        paths.append(p if p.startswith("/") else "/" + p)
    return paths


def _const_refs_near_http(source: str, window: int = 6) -> list[tuple[str, ...]]:
    """Extract dotted constant references that appear near HTTP call sites.

    Returns tuples of segments (skipping the top-level variable name)::

        buildApiUrl(API_CONFIG.AUTH.LOGIN)  →  ('AUTH', 'LOGIN')
        http.get(ROUTES.USERS.BASE)         →  ('USERS', 'BASE')

    Only multi-segment references are returned (single words are too noisy).
    """
    lines = source.split("\n")
    http_line_nos: set[int] = set()
    for i, line in enumerate(lines):
        if _HTTP_CALL_RE.search(line):
            for j in range(max(0, i - window), min(len(lines), i + window + 1)):
                http_line_nos.add(j)

    if not http_line_nos:
        return []

    near_source = "\n".join(lines[j] for j in sorted(http_line_nos))
    refs = []
    for m in _DOTTED_CONST_RE.finditer(near_source):
        parts = m.group(0).split(".")
        # Skip top-level variable name (API_CONFIG, ROUTES, etc.), keep the rest
        if len(parts) >= 2:
            refs.append(tuple(parts[1:]))   # e.g. ('AUTH', 'LOGIN')
    return refs


def _resolve_const_refs(refs: list[tuple[str, ...]], const_source: str) -> list[str]:
    """Look up specific constant values in a constants/config file.

    For each ref tuple, finds the string value of the deepest key scoped
    within the parent namespace::

        ('AUTH', 'LOGIN') →
            AUTH: { LOGIN: '/api/auth/login' }  →  '/api/auth/login'

        ('KPI_BUILDER', 'BASE') →
            KPI_BUILDER: { BASE: '/api/kpis/definitions' }  →  '/api/kpis/definitions'

    This is precise: only the paths actually referenced by the importing
    service are returned, not every path in the constants file.
    """
    paths: list[str] = []
    for ref in refs:
        if len(ref) == 1:
            # Single key: look up anywhere (less precise but acceptable)
            key = ref[0]
            for m in re.finditer(
                rf'\b{re.escape(key)}\s*:\s*["\']([^"\']+)["\']', const_source
            ):
                val = m.group(1)
                if val.startswith("/"):
                    paths.append(val.lower())
        else:
            # Namespace.KEY: scope search to the namespace block
            namespace = re.escape(ref[-2])
            key = re.escape(ref[-1])
            # Match: NAMESPACE: { ... KEY: '/path' ... }
            ns_pattern = re.compile(
                rf'\b{namespace}\s*:\s*\{{([^}}]{{1,500}})}}',
                re.DOTALL,
            )
            for ns_m in ns_pattern.finditer(const_source):
                section = ns_m.group(1)
                for km in re.finditer(
                    rf'\b{key}\s*:\s*["\']([^"\']+)["\']', section
                ):
                    val = km.group(1)
                    if val.startswith("/"):
                        paths.append(val.lower())
    return paths


def _segment_match(frontend_path: str, backend_path: str) -> bool:
    """Check if a frontend path string is a meaningful fragment of a backend route.

    Examples::
        _segment_match('/kpis/definitions', '/api/kpis/definitions')  → True
        _segment_match('/api/kpis/definitions', '/api/kpis/definitions')  → True
        _segment_match('/offers', '/api/offers')  → False (only 1 segment)
    """
    f_segs = [s for s in frontend_path.strip("/").split("/") if s]
    b_segs = [s for s in backend_path.strip("/").split("/") if s]

    if len(f_segs) < 2 or len(f_segs) > len(b_segs) + 1:
        return False

    for start in range(len(b_segs) - len(f_segs) + 1):
        match = True
        for i, fs in enumerate(f_segs):
            bs = b_segs[start + i]
            if fs == "{*}" or bs == "{*}":
                continue
            if fs != bs:
                match = False
                break
        if match:
            return True
    return False


def route_first_link(graph: "CodeGraph", project_root: Path) -> int:
    """Route-first cross-layer linking — universal, pattern-agnostic.

    Algorithm
    ---------
    1. Build a backend route index from the graph.
    2. For each TypeScript ``service`` / ``component`` node:
       a. Skip if no HTTP client is used (entry-point filter).
       b. Extract path string literals directly from the service source.
       c. Extract dotted constant references near HTTP calls
          (e.g. ``API_CONFIG.AUTH.LOGIN`` → ``('AUTH', 'LOGIN')``).
       d. For each 1-level import:
          - If the imported file also makes HTTP calls → extract its
            path literals normally.
          - Otherwise (constants / config file) → resolve only the
            specific constant references found in step (c).  This keeps
            precision high even when a shared ``API_CONFIG`` file contains
            every route in the application.
       e. Match all candidates against the backend route index.
       f. Create ``EDGE_CROSS_LAYER`` edges for new matches.

    Returns the number of *new* edges created beyond ``create_cross_layer_edges``.
    """
    from codemind.router.call_extractor import _resolve_ts_import, _TS_IMPORT_RE

    # Build backend route index
    route_index: dict[str, list[str]] = {}
    for node in graph.nodes.values():
        for path in (node.metadata or {}).get("routes", []):
            route_index.setdefault(path, []).append(node.id)

    if not route_index:
        return 0

    existing: set[tuple[str, str]] = {
        (e.source, e.target) for e in graph.edges if e.kind == EDGE_CROSS_LAYER
    }

    new_edges: list[GraphEdge] = []

    for node in graph.nodes.values():
        if node.language != "typescript":
            continue
        if node.type not in {"service", "component"}:
            continue
        if not node.file:
            continue

        src_path = project_root / node.file
        if not src_path.exists():
            continue

        try:
            source = src_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        # Entry-point check: skip files that don't make HTTP calls
        if not _HTTP_CLIENT_RE.search(source):
            continue

        # Path strings directly in the service's own source
        candidates: set[str] = set(_extract_path_literals(source))

        # Dotted constant references near HTTP calls — used to resolve imports
        const_refs = _const_refs_near_http(source)

        # Follow 1-level imports
        for imp_m in _TS_IMPORT_RE.finditer(source):
            imported = _resolve_ts_import(src_path, imp_m.group(1))
            if not imported:
                continue
            try:
                imp_src = imported.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            if _HTTP_CLIENT_RE.search(imp_src):
                # Another HTTP-calling file — extract its own path literals
                candidates.update(_extract_path_literals(imp_src))
            elif const_refs:
                # Constants/config file — resolve only referenced keys
                candidates.update(_resolve_const_refs(const_refs, imp_src))

        if not candidates:
            continue

        # Match candidates against backend routes
        matched_targets: set[str] = set()
        for candidate in candidates:
            for route_path, controller_ids in route_index.items():
                if _segment_match(candidate, route_path) or _paths_match(candidate, route_path):
                    for cid in controller_ids:
                        if cid != node.id and (node.id, cid) not in existing:
                            matched_targets.add(cid)

        for target_id in matched_targets:
            new_edges.append(GraphEdge(
                source=node.id,
                target=target_id,
                kind=EDGE_CROSS_LAYER,
                meta={"via": "path_fragment"},
            ))
            existing.add((node.id, target_id))

    graph.edges.extend(new_edges)
    graph._rebuild_indices()
    return len(new_edges)
