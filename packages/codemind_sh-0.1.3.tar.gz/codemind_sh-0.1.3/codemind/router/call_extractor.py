"""HTTP call extraction from frontend source files.

Detects outgoing API calls from:
- Angular:    this.http.get('/api/...'), this.http.post('/api/...')
- React:      fetch('/api/...'), axios.get('/api/...'), useQuery('/api/...')
- GraphQL:    gql`` tagged template literals → virtual ``gql:/<field>`` paths
              (Apollo Client, urql, graphql-tag)
- Axios inst: const api = axios.create({ baseURL: '/api' }); api.get('/users')

All calls are stored as ``metadata["api_calls"]`` on the frontend GraphNode, and
are used by the cross-layer linker to create EDGE_CROSS_LAYER edges.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codemind.core.graph import CodeGraph


@dataclass
class ApiCall:
    """An outgoing HTTP (or virtual GraphQL) call detected in frontend source code."""

    node_id: str      # graph node that makes the call
    method: str       # GET | POST | PUT | DELETE | PATCH | QUERY | MUTATION | *
    path: str         # normalised path, e.g. "/api/offers" or "gql:/cars"
    raw: str = ""     # original string


# ── Angular HttpClient ────────────────────────────────────────────────────────

# Matches: this.http.get<T>('/api/...') and this.http.post('/api/...')
_ANGULAR_HTTP_RE = re.compile(
    r'(?:this\.)?\bhttp\s*\.\s*(get|post|put|delete|patch|request)'
    r'(?:<[^(]*>)?\s*\(\s*[`"\'](.*?)[`"\']',
    re.MULTILINE | re.IGNORECASE,
)
# Matches: this.http.get(this.fieldName, ...) — direct field reference (no quotes)
# Also handles method chaining across lines: this.http\n  .get(this.field, ...)
_ANGULAR_HTTP_FIELD_RE = re.compile(
    r'(?:this\.)?\bhttp\s*\.\s*(get|post|put|delete|patch|request)'
    r'(?:<[^(]*>)?\s*\(\s*this\.(\w+)',
    re.MULTILINE | re.IGNORECASE,
)

# ── Angular environment URL parsing ──────────────────────────────────────────

_ENV_API_URL_RE = re.compile(
    r'\bapiUrl\s*:\s*["\']([^"\']+)["\']',
    re.MULTILINE,
)
_ENV_FILE_GLOBS = (
    "environments/environment.ts",
    "environments/environment.prod.ts",
    "src/environments/environment.ts",
)


def _angular_env_api_path(project_root: Path) -> str:
    """Extract the path component of ``apiUrl`` from Angular environment files.

    For example, ``apiUrl: 'http://localhost:8081/api'`` → ``/api``.
    Returns ``""`` if not found.
    """
    for pattern in _ENV_FILE_GLOBS:
        for env_file in project_root.rglob(pattern):
            try:
                content = env_file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            m = _ENV_API_URL_RE.search(content)
            if m:
                url = m.group(1)
                # Strip protocol+host, keep only path portion
                if "://" in url:
                    url = url.split("://", 1)[1]  # remove http://
                    url = url[url.find("/"):]      # remove host:port, keep /path
                return url.rstrip("/")
    return ""


# ── Angular class-field URL base detection ───────────────────────────────────

# Detect class field URL bases, e.g.:
#   private readonly baseUrl = buildApiUrl('/api/action-plans')
#   private apiUrl = `${environment.apiUrl}/api/users`
#   private URL = environment.apiUrl + '/api/kpis'
#   private baseUrl = `${this.env.apiUrl}/api/kpis`
#   private baseUrl = `${environment.apiUrl}/offers`   (env already has /api)
_ANGULAR_FIELD_BUILD_URL_RE = re.compile(
    r'(?:private|protected|public)\s+(?:readonly\s+)?(\w+)\s*=\s*'
    r'\w+\s*\(\s*["\']([^"\']+)["\']',   # anyHelper('/api/path')
    re.MULTILINE,
)
_ANGULAR_FIELD_TEMPLATE_RE = re.compile(
    r'(?:private|protected|public)\s+(?:readonly\s+)?(\w+)\s*=\s*'
    r'`[^`]*?(/api/[^`${}]+)[^`]*`',     # `${env.url}/api/path`
    re.MULTILINE,
)
_ANGULAR_FIELD_CONCAT_RE = re.compile(
    r'(?:private|protected|public)\s+(?:readonly\s+)?(\w+)\s*=\s*'
    r'[^"\'`\n]+\+\s*["\']([^"\']+)["\']',  # env.url + '/api/path'
    re.MULTILINE,
)
# `${environment.xxx}/endpoint` where env var already contains /api
_ANGULAR_FIELD_ENV_SUFFIX_RE = re.compile(
    r'(?:private|protected|public)\s+(?:readonly\s+)?(\w+)\s*=\s*'
    r'`\$\{(?:environment|this\.env|\w+)\.\w+\}(/[^`{$\n]+)`',
    re.MULTILINE,
)


def _extract_angular_base_urls(source: str, env_api_path: str = "") -> dict[str, str]:
    """Extract Angular service field → base API path mappings.

    Resolves common patterns where the HTTP call URL is built from a class field:

        private baseUrl = buildApiUrl('/api/action-plans')   → {baseUrl: '/api/action-plans'}
        private apiUrl = `${environment.apiUrl}/api/auth`    → {apiUrl: '/api/auth'}
        private url    = environment.apiUrl + '/api/kpis'    → {url: '/api/kpis'}
        private baseUrl = `${environment.apiUrl}/offers`     → {baseUrl: '/api/offers'}
          (when env_api_path='/api', combines to '/api/offers')

    ``env_api_path`` is the path segment of the environment ``apiUrl`` (e.g.
    ``/api`` from ``http://localhost:8081/api``), used to resolve the last
    pattern above.
    """
    mapping: dict[str, str] = {}

    for m in _ANGULAR_FIELD_BUILD_URL_RE.finditer(source):
        path = m.group(2)
        if path.startswith("/"):
            mapping[m.group(1)] = path

    for m in _ANGULAR_FIELD_TEMPLATE_RE.finditer(source):
        path = m.group(2).rstrip()
        if path.startswith("/api"):
            mapping[m.group(1)] = path

    for m in _ANGULAR_FIELD_CONCAT_RE.finditer(source):
        path = m.group(2)
        if path.startswith("/"):
            mapping[m.group(1)] = path

    # `${environment.apiUrl}/endpoint` — combine env path with suffix
    for m in _ANGULAR_FIELD_ENV_SUFFIX_RE.finditer(source):
        field = m.group(1)
        suffix = m.group(2).rstrip()
        if field in mapping:
            continue  # Already resolved by a more specific pattern
        if env_api_path:
            # env_api_path already ends with e.g. /api → combine
            combined = env_api_path.rstrip("/") + suffix
            if combined.startswith("/"):
                mapping[field] = combined
        elif suffix.startswith("/api"):
            # No env hint but suffix already has /api
            mapping[field] = suffix

    return mapping


def _resolve_angular_path(raw_path: str, base_urls: dict[str, str]) -> str:
    """Replace ``${this.fieldName}`` or ``${fieldName}`` placeholders with known base paths."""
    resolved = raw_path
    for field_name, base_path in base_urls.items():
        resolved = resolved.replace(f"${{{field_name}}}", base_path)
        resolved = resolved.replace(f"${{this.{field_name}}}", base_path)
    return resolved


def _extract_angular_calls(source: str, node_id: str, env_api_path: str = "") -> list[ApiCall]:
    base_urls = _extract_angular_base_urls(source, env_api_path)
    calls: list[ApiCall] = []
    for m in _ANGULAR_HTTP_RE.finditer(source):
        method = m.group(1).upper()
        raw_path = m.group(2)
        # Resolve class-field URL variables to their embedded API paths
        resolved = _resolve_angular_path(raw_path, base_urls) if base_urls else raw_path
        if resolved.startswith(("/", "${", "this.", "env")):
            calls.append(ApiCall(
                node_id=node_id,
                method=method,
                path=_normalise_path(resolved),
                raw=raw_path,
            ))
    # Handle: this.http.get(this.fieldName, ...) — direct field reference without quotes
    for m in _ANGULAR_HTTP_FIELD_RE.finditer(source):
        field = m.group(2)
        if field in base_urls:
            calls.append(ApiCall(
                node_id=node_id,
                method=m.group(1).upper(),
                path=_normalise_path(base_urls[field]),
                raw=f"this.{field}",
            ))
    return calls


# ── React / fetch / axios ─────────────────────────────────────────────────────

# fetch('/api/offers')
_FETCH_RE = re.compile(
    r'\bfetch\s*\(\s*[`"\'](.*?)[`"\']',
    re.MULTILINE,
)
# axios.get('/api/...'), axios.post(...), axios({ url: '/api/...' })
_AXIOS_RE = re.compile(
    r'\baxios\.(get|post|put|delete|patch)\s*\(\s*[`"\'](.*?)[`"\']'
    r'|\baxios\s*\(\s*\{[^}]*url\s*:\s*[`"\'](.*?)[`"\']',
    re.MULTILINE | re.IGNORECASE,
)
# useQuery('/api/...'), useSWR('/api/...'), useFetch('/api/...')
_QUERY_HOOK_RE = re.compile(
    r'\buse(?:Query|SWR|Fetch)\s*\(\s*[`"\'](.*?)[`"\']',
    re.MULTILINE | re.IGNORECASE,
)


def _extract_react_calls(source: str, node_id: str) -> list[ApiCall]:
    calls: list[ApiCall] = []
    for m in _FETCH_RE.finditer(source):
        raw = m.group(1)
        if _is_api_path(raw):
            calls.append(ApiCall(node_id=node_id, method="*", path=_normalise_path(raw), raw=raw))
    for m in _AXIOS_RE.finditer(source):
        if m.group(2):       # axios.get('/...')
            method = m.group(1).upper()
            raw = m.group(2)
        elif m.group(3):     # axios({ url: '/...' })
            method = "*"
            raw = m.group(3)
        else:
            continue
        if _is_api_path(raw):
            calls.append(ApiCall(node_id=node_id, method=method, path=_normalise_path(raw), raw=raw))
    for m in _QUERY_HOOK_RE.finditer(source):
        raw = m.group(1)
        if _is_api_path(raw):
            calls.append(ApiCall(node_id=node_id, method="GET", path=_normalise_path(raw), raw=raw))
    return calls


def _is_api_path(path: str) -> bool:
    """Accept paths that look like real API endpoints (not protocol-relative)."""
    return path.startswith("/") and not path.startswith("//")


def _normalise_path(path: str) -> str:
    """Normalise an API path: lowercase, replace variables, strip query string.

    Also strips a leading ``{*}`` segment that represents a dynamic base URL
    such as ``${this.apiUrl}`` (common in Angular services), so that
    ``${this.apiUrl}/api/users`` normalises to ``/api/users`` for matching.
    """
    # gql: scheme — pass through
    if path.startswith("gql:"):
        return path.lower()
    p = path.split("?")[0].split("#")[0]   # strip query / fragment
    p = re.sub(r"\$\{[^}]+\}", "{*}", p)   # ${varName} → {*}
    p = re.sub(r"\{[^}]+\}", "{*}", p)      # {id} → {*}
    p = re.sub(r":[A-Za-z_][A-Za-z0-9_]*", "{*}", p)  # :id → {*}
    # Strip leading {*} that represents a dynamic base URL (e.g. Angular apiUrl)
    # e.g. "{*}/api/users" → "/api/users"
    if p.startswith("{*}/"):
        p = p[3:]   # Remove "{*}" prefix, keep "/" and the rest
    p = p.rstrip("/") or "/"
    return p.lower()


# ── GraphQL (Apollo / urql / graphql-tag) ─────────────────────────────────────

# gql`query GetCars { cars { id name } }`
_GQL_TAG_RE = re.compile(r"\bgql\s*`(.*?)`", re.DOTALL)

# Find the *first* root field inside a named or anonymous operation:
#   query GetCars { cars { ... } }
#   mutation CreateCar { createCar { ... } }
#   { cars { ... } }   (shorthand anonymous query)
_GQL_OP_FIELD_RE = re.compile(
    r"(?:query|mutation|subscription)\s*(?:\w+\s*)?(?:\([^)]*\)\s*)?\{\s*(\w+)",
    re.IGNORECASE | re.MULTILINE,
)
_GQL_SHORTHAND_RE = re.compile(r"^\s*\{\s*(\w+)", re.MULTILINE)


def _gql_root_fields(query_text: str) -> list[str]:
    """Extract root selection field names from a GraphQL document string."""
    fields = []
    for m in _GQL_OP_FIELD_RE.finditer(query_text):
        fields.append(m.group(1))
    if not fields:
        # Shorthand anonymous query: { fieldName { ... } }
        for m in _GQL_SHORTHAND_RE.finditer(query_text):
            fields.append(m.group(1))
    return fields


def _extract_graphql_calls(source: str, node_id: str) -> list[ApiCall]:
    """Detect outgoing GraphQL calls via ``gql`` tagged template literals.

    Each ``gql`` tag is parsed for its root selection field(s).  Each field
    becomes a virtual call path ``gql:/<fieldName>`` that can be matched against
    NestJS Resolver routes of the form ``gql:/<methodName>``.

    Example::

        const GET_CARS = gql`query GetCars { cars { id } }`;
        → ApiCall(method="QUERY", path="gql:/cars")
    """
    calls: list[ApiCall] = []
    seen: set[str] = set()
    for gql_m in _GQL_TAG_RE.finditer(source):
        for field in _gql_root_fields(gql_m.group(1)):
            path = _normalise_path(f"gql:/{field}")
            if path not in seen:
                seen.add(path)
                calls.append(ApiCall(
                    node_id=node_id,
                    method="QUERY",
                    path=path,
                    raw=field,
                ))
    return calls


# ── Axios instance calls ──────────────────────────────────────────────────────

# const api = axios.create({ baseURL: '/api', ... })
_AXIOS_CREATE_RE = re.compile(
    r'(?:const|let|var)\s+(\w+)\s*=\s*axios\.create\s*\(\s*\{[^}]*'
    r'baseURL\s*:\s*["\']([^"\']+)["\']',
    re.MULTILINE | re.DOTALL,
)


def _extract_axios_instance_calls(source: str, node_id: str) -> list[ApiCall]:
    """Detect HTTP calls made via a named Axios instance created with ``axios.create``.

    Example::

        const api = axios.create({ baseURL: '/api' });
        api.get('/users')   →  ApiCall(path="/api/users")
    """
    calls: list[ApiCall] = []

    # Collect all named Axios instances
    instances: dict[str, str] = {}
    for m in _AXIOS_CREATE_RE.finditer(source):
        instances[m.group(1)] = m.group(2).rstrip("/")

    for var_name, base_url in instances.items():
        pattern = re.compile(
            r"\b" + re.escape(var_name) +
            r"\.(get|post|put|delete|patch)\s*\(\s*[`\"\'](.*?)[`\"\']",
            re.MULTILINE,
        )
        for m in pattern.finditer(source):
            method = m.group(1).upper()
            raw_path = m.group(2)
            full_path = _normalise_path(base_url + "/" + raw_path.lstrip("/"))
            calls.append(ApiCall(
                node_id=node_id,
                method=method,
                path=full_path,
                raw=raw_path,
            ))
    return calls


# ── Unified extractor ─────────────────────────────────────────────────────────


def extract_api_calls_from_source(source: str, node_id: str, language: str) -> list[ApiCall]:
    """Extract outgoing HTTP and GraphQL calls from frontend source code."""
    calls: list[ApiCall] = []
    if language == "typescript":
        calls.extend(_extract_angular_calls(source, node_id))
        calls.extend(_extract_react_calls(source, node_id))
        calls.extend(_extract_graphql_calls(source, node_id))
        calls.extend(_extract_axios_instance_calls(source, node_id))
    return calls


# ── TypeScript import resolution ─────────────────────────────────────────────

_TS_IMPORT_RE = re.compile(
    r'import\s+.*?from\s+["\'](\.[^"\']+)["\']',
    re.MULTILINE,
)
_TS_EXTENSIONS = (".ts", ".tsx", ".js", ".jsx")


def _resolve_ts_import(source_file: Path, import_path: str) -> Path | None:
    """Resolve a relative TypeScript import path to an actual file on disk.

    Tries extensions and ``/index.ts`` fallbacks in order.
    """
    parent = source_file.parent
    base = (parent / import_path).resolve()
    # Try direct with extensions
    for ext in _TS_EXTENSIONS:
        candidate = Path(str(base) + ext)
        if candidate.exists():
            return candidate
    # Try as directory with index file
    for ext in _TS_EXTENSIONS:
        candidate = base / f"index{ext}"
        if candidate.exists():
            return candidate
    # Already has extension?
    if base.exists() and base.is_file():
        return base
    return None


def _read_imported_gql_calls(source: str, src_path: Path, node_id: str) -> list[ApiCall]:
    """Follow one level of relative imports to find ``gql`` tags in imported files.

    This handles the common pattern where gql query constants are defined in a
    separate ``queries.ts`` file and imported by the service/component file.
    """
    calls: list[ApiCall] = []
    for m in _TS_IMPORT_RE.finditer(source):
        imported_path = _resolve_ts_import(src_path, m.group(1))
        if imported_path is None:
            continue
        try:
            imported_source = imported_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        calls.extend(_extract_graphql_calls(imported_source, node_id))
    return calls


# ── Graph-level API call enrichment ──────────────────────────────────────────


def enrich_graph_with_api_calls(graph: "CodeGraph", project_root: Path) -> int:
    """Scan frontend nodes for outgoing HTTP / GraphQL calls and store in metadata.

    REST calls (Angular/React) are extracted only from ``component`` and
    ``service`` nodes to avoid noise from backend files.

    GraphQL (``gql`` tag) calls are extracted from *all* TypeScript nodes.
    Additionally, one level of relative imports is followed so that ``gql``
    constants defined in a separate ``queries.ts`` file are attributed to the
    importing service/component node.

    Returns the number of unique call paths added.
    """
    count = 0
    # Resolve Angular environment apiUrl once for the whole project
    env_api_path = _angular_env_api_path(project_root)

    for node in graph.nodes.values():
        if not node.file or node.language != "typescript":
            continue
        src_path = project_root / node.file
        if not src_path.exists():
            continue
        try:
            source = src_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        calls: list[ApiCall] = []

        # REST + Axios: only from recognised frontend node types
        if node.type in {"component", "service"}:
            calls.extend(_extract_angular_calls(source, node.id, env_api_path))
            calls.extend(_extract_react_calls(source, node.id))
            calls.extend(_extract_axios_instance_calls(source, node.id))

        # GraphQL: scan node's own source AND 1-level imported files
        calls.extend(_extract_graphql_calls(source, node.id))
        calls.extend(_read_imported_gql_calls(source, src_path, node.id))

        if calls:
            if node.metadata is None:
                node.metadata = {}
            existing = set(node.metadata.get("api_calls", []))
            new_paths = [c.path for c in calls if c.path not in existing]
            if new_paths:
                node.metadata["api_calls"] = list(existing) + new_paths
                count += len(new_paths)

    return count
