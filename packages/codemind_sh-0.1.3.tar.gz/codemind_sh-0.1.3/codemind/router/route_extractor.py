"""HTTP route extraction from backend source files.

Detects routes from:
- Spring Boot:    @RequestMapping, @GetMapping, @PostMapping, @PutMapping,
                  @DeleteMapping, @PatchMapping — class-level prefix, array values,
                  bare (no-arg) decorators.
- NestJS REST:    @Controller(), @Get(), @Post(), @Put(), @Delete(), @Patch()
- NestJS GraphQL: @Resolver() + @Query() / @Mutation() → virtual ``gql:/<method>``
- Express:        router.get/post/put/delete/patch/all, app.use() prefix detection
- FastAPI:        @app.get/router.get, APIRouter(prefix=…) honoured per variable
- Next.js:        pages/api/**/*.ts|js and app/api/**/route.ts → route from file path

Routes are stored as ``metadata["routes"]`` on the GraphNode that owns them, and
are consumed by the cross-layer linker to create EDGE_CROSS_LAYER edges.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codemind.core.graph import CodeGraph


# ── Route record ─────────────────────────────────────────────────────────────


@dataclass
class RouteRecord:
    """A single HTTP (or virtual GraphQL) route registered on a backend component."""

    node_id: str           # graph node that owns this route
    method: str            # GET | POST | PUT | DELETE | PATCH | QUERY | MUTATION | *
    path: str              # normalised path, e.g. "/api/offers" or "gql:/cars"
    raw: str = ""          # original string as seen in source


# ── Path normalisation ────────────────────────────────────────────────────────


def _normalise(path: str) -> str:
    """Normalise a route path for matching.

    - Strip surrounding whitespace; strip quotes.
    - ``gql:`` scheme is preserved as-is (lowercased only).
    - Ensure exactly one leading slash.
    - Replace path variables ({id}, :id, {uuid}) with ``{*}``.
    - Strip trailing slash (except root "/").
    """
    p = path.strip()
    if p.startswith("gql:"):
        return p.lower()
    p = p.strip("'\"/")
    if not p or p == "/":
        return "/"
    p = "/" + p.lstrip("/")
    # {id}, {userId}, {uuid:...}  →  {*}
    p = re.sub(r"\{[^}]+\}", "{*}", p)
    # :id, :userId at a path-segment boundary  →  {*}
    p = re.sub(r":[A-Za-z_][A-Za-z0-9_]*(?=/|$)", "{*}", p)
    p = p.rstrip("/") or "/"
    return p.lower()


def _join_paths(*parts: str) -> str:
    """Join route path segments and normalise the result."""
    joined = "/".join(p.strip("/") for p in parts if p.strip("/"))
    return _normalise(joined)


# ── Spring Boot route extractor ───────────────────────────────────────────────

# Match @GetMapping("/path"), @GetMapping, @RequestMapping(value={"/a","/b"})
# Group 1: annotation name; Group 2: content inside parens (may be absent)
_SPRING_MAPPING = re.compile(
    r'@(RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping)'
    r'(?:\s*\(([^)]*)\))?',
    re.MULTILINE,
)
_SPRING_METHOD_FROM_DEC = {
    "GetMapping": "GET",
    "PostMapping": "POST",
    "PutMapping": "PUT",
    "DeleteMapping": "DELETE",
    "PatchMapping": "PATCH",
    "RequestMapping": "*",
}


def _spring_paths_from_args(args: str) -> list[str]:
    """Extract route path(s) from Spring mapping annotation arguments.

    Handles:
    - Bare string:      ``"/api/offers"``
    - Named value:      ``value = "/api/offers"``
    - Array:            ``{"/api/offers", "/api/exports"}``
    - Named array:      ``value = {"/api/offers", "/api/exports"}``
    - Mixed attrs:      ``value="/api", produces="application/json"``
      (non-path strings are filtered out)
    """
    paths = []
    for s in re.findall(r'["\']([^"\']+)["\']', args or ""):
        # Keep only strings that look like URL path segments
        if s.startswith("/") or s.startswith("${") or s.startswith("#{"):
            paths.append(s)
    return paths


def extract_spring_class_prefix(source: str) -> str:
    """Extract the class-level @RequestMapping path (controller prefix).

    Scans only the class *header* (text before the opening ``{`` that follows
    the ``class`` keyword) to avoid matching method-level annotations or
    annotation arguments containing ``{``.
    """
    class_decl = re.search(r'\bclass\s+\w+', source)
    if class_decl:
        body_start = source.find("{", class_decl.end())
        header = source[:body_start] if body_start != -1 else source
    else:
        header = source

    if "@RequestMapping" not in header:
        return ""

    rm_start = header.rfind("@RequestMapping")
    snippet = header[rm_start:]
    args_m = re.search(r'\(([^)]*)\)', snippet)
    if not args_m:
        return ""
    paths = _spring_paths_from_args(args_m.group(1))
    return paths[0] if paths else ""


def _extract_spring_routes(source: str, node_id: str, class_prefix: str = "") -> list[RouteRecord]:
    """Extract routes from a Spring Boot controller source string.

    Skips the class *header* section (where the class-level ``@RequestMapping``
    prefix was already captured) to avoid duplicating the prefix as a route.
    Only annotations inside the class body are processed as route registrations.
    """
    # Find the class body opening brace so we only scan method-level annotations
    class_decl = re.search(r'\bclass\s+\w+', source)
    if class_decl:
        body_start = source.find("{", class_decl.end())
        scan_source = source[body_start:] if body_start != -1 else source
    else:
        scan_source = source

    routes: list[RouteRecord] = []
    for m in _SPRING_MAPPING.finditer(scan_source):
        dec_name = m.group(1)
        args = m.group(2) or ""
        method = _SPRING_METHOD_FROM_DEC.get(dec_name, "*")
        paths = _spring_paths_from_args(args)

        if not paths:
            if dec_name == "RequestMapping":
                # Class-level @RequestMapping — only records a prefix placeholder
                if class_prefix:
                    routes.append(RouteRecord(
                        node_id=node_id, method="*",
                        path=_normalise(class_prefix), raw="",
                    ))
            else:
                # @GetMapping / @PostMapping without a path — inherit class prefix
                if class_prefix:
                    routes.append(RouteRecord(
                        node_id=node_id, method=method,
                        path=_normalise(class_prefix), raw="",
                    ))
        else:
            for raw_path in paths:
                full_path = _join_paths(class_prefix, raw_path)
                routes.append(RouteRecord(
                    node_id=node_id, method=method, path=full_path, raw=raw_path,
                ))
    return routes


# ── NestJS REST route extractor ───────────────────────────────────────────────

_NEST_CONTROLLER_RE = re.compile(r'@Controller\s*\(\s*["\']([^"\']*)["\']', re.MULTILINE)
_NEST_ROUTE_RE = re.compile(
    r'@(Get|Post|Put|Delete|Patch)\s*\((?:\s*["\']([^"\']*)["\'])?\s*\)',
    re.MULTILINE,
)


def _extract_nest_routes(source: str, node_id: str) -> list[RouteRecord]:
    """Extract REST routes from a NestJS controller source string."""
    routes: list[RouteRecord] = []
    prefix_m = _NEST_CONTROLLER_RE.search(source)
    prefix = prefix_m.group(1) if prefix_m else ""

    for m in _NEST_ROUTE_RE.finditer(source):
        method = m.group(1).upper()
        sub_path = m.group(2) or ""
        full_path = _join_paths(prefix, sub_path)
        routes.append(RouteRecord(
            node_id=node_id, method=method, path=full_path, raw=sub_path,
        ))
    return routes


# ── NestJS GraphQL route extractor ───────────────────────────────────────────


def _extract_nest_graphql_routes(source: str, node_id: str) -> list[RouteRecord]:
    """Extract GraphQL operations from a NestJS resolver as virtual ``gql:`` routes.

    For each ``@Query`` / ``@Mutation`` / ``@Subscription`` decorator, reads the
    associated method name and emits a virtual path ``gql:/<methodName>``.  This
    allows the cross-layer linker to connect it to an Apollo Client call that
    queries the same field name.

    Example::

        @Query((returns) => [Car])
        async cars(): Promise<Car[]> { ... }
        → RouteRecord(method="QUERY", path="gql:/cars")
    """
    if "@Resolver" not in source:
        return []

    routes: list[RouteRecord] = []
    seen: set[str] = set()

    # Strip comments to avoid false positives
    clean = re.sub(r"//[^\n]*", "", source)
    clean = re.sub(r"/\*.*?\*/", "", clean, flags=re.DOTALL)

    op_re = re.compile(r"@(Query|Mutation|Subscription)\s*\(", re.MULTILINE)
    # Method names start with a lowercase letter (unlike class/type refs)
    method_re = re.compile(r"(?:async\s+)?([a-z_]\w*)\s*\(")

    for op_m in op_re.finditer(clean):
        op_type = op_m.group(1)

        # Depth-count to find the closing ')' of the decorator
        depth, pos = 1, op_m.end()
        while pos < len(clean) and depth > 0:
            c = clean[pos]
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            pos += 1

        # Scan the next 400 chars for the method name (lowercase start)
        snippet = clean[pos: pos + 400]
        mm = method_re.search(snippet)
        if mm:
            method_name = mm.group(1)
            path = _normalise(f"gql:/{method_name}")
            if path not in seen:
                seen.add(path)
                routes.append(RouteRecord(
                    node_id=node_id,
                    method=op_type.upper(),
                    path=path,
                    raw=method_name,
                ))

    return routes


# ── Express route extractor ───────────────────────────────────────────────────

# router.get, app.get, anyVar.get/post/…
_EXPRESS_RE = re.compile(
    r'(?:router|app|[\w$]+)\s*\.'
    r'(get|post|put|delete|patch|all)\s*\(\s*["\']([^"\']+)["\']',
    re.MULTILINE | re.IGNORECASE,
)
# app.use('/prefix', someRouter) — used to detect mount prefixes
_EXPRESS_USE_RE = re.compile(
    r'(?:app|server)\s*\.\s*use\s*\(\s*["\']([^"\']+)["\']',
    re.MULTILINE,
)


def _extract_express_routes(source: str, node_id: str, app_prefix: str = "") -> list[RouteRecord]:
    """Extract routes from an Express/Node.js source string."""
    routes: list[RouteRecord] = []
    for m in _EXPRESS_RE.finditer(source):
        method = m.group(1).upper()
        raw_path = m.group(2)
        full_path = _join_paths(app_prefix, raw_path) if app_prefix else _normalise(raw_path)
        routes.append(RouteRecord(
            node_id=node_id, method=method, path=full_path, raw=raw_path,
        ))
    return routes


# ── FastAPI route extractor ───────────────────────────────────────────────────

# Detect: router = APIRouter(prefix="/api/users")
_FASTAPI_ROUTER_CREATE_RE = re.compile(
    r'(\w+)\s*=\s*APIRouter\s*\([^)]*prefix\s*=\s*["\']([^"\']+)["\']',
    re.MULTILINE,
)
# Detect: @router.get("/path"), @app.get("/path"), @any_var.get("/path")
_FASTAPI_ROUTE_RE = re.compile(
    r'@(\w+)\.(get|post|put|delete|patch)\s*\(\s*["\']([^"\']+)["\']',
    re.MULTILINE | re.IGNORECASE,
)


def _extract_fastapi_routes(source: str, node_id: str) -> list[RouteRecord]:
    """Extract routes from a FastAPI source string, honouring APIRouter prefixes."""
    # Build prefix map: var_name → prefix
    router_prefixes: dict[str, str] = {}
    for m in _FASTAPI_ROUTER_CREATE_RE.finditer(source):
        router_prefixes[m.group(1)] = m.group(2)

    routes: list[RouteRecord] = []
    for m in _FASTAPI_ROUTE_RE.finditer(source):
        var_name = m.group(1)
        method = m.group(2).upper()
        raw_path = m.group(3)
        prefix = router_prefixes.get(var_name, "")
        full_path = _join_paths(prefix, raw_path) if prefix else _normalise(raw_path)
        routes.append(RouteRecord(
            node_id=node_id, method=method, path=full_path, raw=raw_path,
        ))
    return routes


# ── Django DRF route extractor ────────────────────────────────────────────────

# router.register(r'users', UserViewSet) or router.register('users', UserViewSet)
_DJANGO_ROUTER_REGISTER_RE = re.compile(
    r'router\.register\s*\(\s*r?["\']([^"\']+)["\']',
    re.MULTILINE,
)
# path('users/', views.user_list) or path('users/<int:pk>/', ...)
_DJANGO_PATH_RE = re.compile(
    r'\bpath\s*\(\s*["\']([^"\']+)["\']',
    re.MULTILINE,
)
# @api_view(['GET', 'POST'])
_DJANGO_API_VIEW_RE = re.compile(
    r'@api_view\s*\(\s*\[([^\]]+)\]',
    re.MULTILINE,
)


def _extract_django_routes(source: str, node_id: str) -> list[RouteRecord]:
    """Extract routes from a Django DRF urls.py or view file."""
    routes: list[RouteRecord] = []

    # ViewSet registrations (generate collection + detail routes)
    for m in _DJANGO_ROUTER_REGISTER_RE.finditer(source):
        prefix_path = m.group(1).rstrip("/")
        routes.append(RouteRecord(
            node_id=node_id, method="*",
            path=_normalise("/" + prefix_path),
            raw=prefix_path,
        ))
        routes.append(RouteRecord(
            node_id=node_id, method="*",
            path=_normalise("/" + prefix_path + "/{*}"),
            raw=prefix_path + "/<pk>",
        ))

    # Explicit path() calls
    for m in _DJANGO_PATH_RE.finditer(source):
        raw_path = m.group(1)
        # Replace Django path converters: <int:pk>, <str:slug>, <pk>
        clean_path = re.sub(r"<(?:\w+:)?(\w+)>", "{*}", raw_path)
        routes.append(RouteRecord(
            node_id=node_id, method="*",
            path=_normalise("/" + clean_path),
            raw=raw_path,
        ))

    return routes


# ── Next.js file-based route detection ────────────────────────────────────────

_NEXTJS_API_RE = re.compile(
    r'(?:^|[/\\])(?:pages|app)[/\\]api[/\\](.+?)(?:[/\\]route|[/\\]index)?'
    r'\.(?:ts|tsx|js|jsx)$',
    re.IGNORECASE,
)


def _nextjs_route_from_path(file_path: str) -> str | None:
    """Derive a Next.js API route from the file path, or ``None`` if not applicable.

    Examples::

        pages/api/users/index.ts          → /api/users
        pages/api/users/[id].ts           → /api/users/{*}
        app/api/orders/route.ts           → /api/orders
        app/api/orders/[orderId]/route.ts → /api/orders/{*}
    """
    normalised_path = file_path.replace("\\", "/")
    m = _NEXTJS_API_RE.search(normalised_path)
    if not m:
        return None

    route_part = m.group(1)
    # Replace [param] and [[...slug]] with {*}
    route_part = re.sub(r"\[+[^\]]+\]+", "{*}", route_part)
    # Split into segments and clean
    segments = [s for s in route_part.replace("\\", "/").split("/") if s]
    if not segments:
        return "/api"
    return _normalise("/api/" + "/".join(segments))


# ── Unified extractor ─────────────────────────────────────────────────────────


def extract_routes_from_source(source: str, node_id: str, language: str) -> list[RouteRecord]:
    """Extract HTTP (and virtual GraphQL) routes from source code.

    Dispatches to the appropriate framework extractor based on language and
    detected patterns in the source.  Multiple extractors may run for the same
    source (e.g. NestJS REST and GraphQL are both TypeScript).
    """
    routes: list[RouteRecord] = []

    if language == "java":
        prefix = extract_spring_class_prefix(source)
        routes.extend(_extract_spring_routes(source, node_id, class_prefix=prefix))

    elif language == "typescript":
        # NestJS GraphQL (check first — resolvers have no @Controller)
        if "@Resolver" in source:
            gql = _extract_nest_graphql_routes(source, node_id)
            if gql:
                routes.extend(gql)
                # Resolvers don't also expose REST — return early
                return routes

        # NestJS REST
        if "@Controller" in source or "@Get(" in source or "@Post(" in source:
            routes.extend(_extract_nest_routes(source, node_id))
        # Express (may coexist with a partial NestJS project)
        elif "router." in source or "app.get(" in source or "app.post(" in source:
            routes.extend(_extract_express_routes(source, node_id))

    elif language == "python":
        routes.extend(_extract_fastapi_routes(source, node_id))
        # Django DRF (urls.py or view with router.register / path())
        if "router.register" in source or ("path(" in source and "urlpatterns" in source):
            routes.extend(_extract_django_routes(source, node_id))

    return routes


# ── Graph-level route enrichment ──────────────────────────────────────────────

_ROUTE_BEARING_TYPES = frozenset({"controller", "class", "service", "function"})
_ROUTE_BEARING_LANGS = frozenset({"java", "typescript", "python"})


def enrich_graph_with_routes(graph: "CodeGraph", project_root: Path) -> int:
    """Read source files for backend nodes and store routes in ``metadata["routes"]``.

    Also derives Next.js API routes directly from file paths (no source read
    needed for those).

    Returns the total number of route paths added across all nodes.
    """
    count = 0
    for node in graph.nodes.values():
        if not node.file:
            continue
        if node.language not in _ROUTE_BEARING_LANGS:
            continue

        # ── Next.js: derive route from file path, no source read needed ──────
        if node.language == "typescript":
            nextjs_route = _nextjs_route_from_path(node.file)
            if nextjs_route:
                if node.metadata is None:
                    node.metadata = {}
                existing = set(node.metadata.get("routes", []))
                if nextjs_route not in existing:
                    node.metadata.setdefault("routes", []).append(nextjs_route)
                    count += 1
                continue  # Skip source-based extraction for Next.js API files

        if node.type not in _ROUTE_BEARING_TYPES:
            continue

        src_path = project_root / node.file
        if not src_path.exists():
            continue
        try:
            source = src_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        routes = extract_routes_from_source(source, node.id, node.language)
        if routes:
            if node.metadata is None:
                node.metadata = {}
            # Deduplicate, preserving order
            existing = list(node.metadata.get("routes", []))
            existing_set = set(existing)
            for r in routes:
                if r.path not in existing_set:
                    existing.append(r.path)
                    existing_set.add(r.path)
            node.metadata["routes"] = existing
            count += len(routes)

    return count
