"""Cross-layer routing — extract HTTP routes from backends and calls from frontends,
then create EDGE_CROSS_LAYER edges connecting frontend components to backend controllers.
"""
