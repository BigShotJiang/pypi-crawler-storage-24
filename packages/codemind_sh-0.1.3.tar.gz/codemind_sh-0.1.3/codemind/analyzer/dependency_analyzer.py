"""Dependency analyzer — parses pom.xml, package.json, requirements.txt, pyproject.toml.

Extracts declared dependencies, detects the primary framework and its version,
and categorizes each dependency so the knowledge generator can produce a rich
DEPENDENCIES.md without needing the Claude API.
"""

from __future__ import annotations

import json
import logging
import re
import tomllib
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ── Data models ───────────────────────────────────────────────────────────────


@dataclass
class AnalyzedDependency:
    """A single declared dependency from a build file.

    Attributes:
        name: Display name — artifactId for Maven, package name for npm/pip.
        version: Version string or constraint (e.g. "3.2.1", "^17.0.0", ">=4.2").
            Empty string when version is managed by a parent BOM.
        scope: Lifecycle scope — "compile", "runtime", "test", "dev", "peer",
            "provided", "optional".
        category: Semantic category for DEPENDENCIES.md grouping — "framework",
            "database", "auth", "http", "messaging", "cache", "ui", "test",
            "utility", or "other".
        group_id: Maven group ID (e.g. "org.springframework.boot"). Empty for npm/pip.
        artifact_id: Maven artifact ID. Same as ``name`` for non-Maven sources.
    """

    name: str
    version: str
    scope: str
    category: str
    group_id: str = ""
    artifact_id: str = ""


@dataclass
class DependencyResult:
    """Parsed result from one build file.

    Attributes:
        source_file: Absolute path to the build file.
        source_type: "maven", "npm", "pip", or "poetry".
        language: Primary language — "java", "typescript", or "python".
        project_name: Own artifact/package name.
        project_version: Own artifact/package version.
        framework: Detected primary framework (e.g. "spring-boot", "angular").
            Empty string if none detected.
        framework_version: Detected primary framework version. Empty if unknown.
        dependencies: All declared dependencies (production + dev/test).
        errors: Non-fatal warnings encountered during parsing.
    """

    source_file: Path
    source_type: str
    language: str
    project_name: str
    project_version: str
    framework: str
    framework_version: str
    dependencies: list[AnalyzedDependency] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    # ── Convenience views ──────────────────────────────────────────────────

    @property
    def production_deps(self) -> list[AnalyzedDependency]:
        """Dependencies with scope compile / runtime / provided."""
        return [d for d in self.dependencies if d.scope not in ("test", "dev", "peer")]

    @property
    def test_deps(self) -> list[AnalyzedDependency]:
        """Dependencies with scope test or dev."""
        return [d for d in self.dependencies if d.scope in ("test", "dev")]

    @property
    def by_category(self) -> dict[str, list[AnalyzedDependency]]:
        """Dependencies grouped by category."""
        groups: dict[str, list[AnalyzedDependency]] = {}
        for dep in self.dependencies:
            groups.setdefault(dep.category, []).append(dep)
        return groups


# ── DependencyAnalyzer ────────────────────────────────────────────────────────


class DependencyAnalyzer:
    """Finds and parses all build files in a project tree.

    Supported build files:
    - ``pom.xml``          → Maven (Java)
    - ``package.json``     → npm (TypeScript / JavaScript)
    - ``requirements.txt`` → pip (Python)
    - ``pyproject.toml``   → Poetry or PEP 621 (Python)
    """

    def analyze(self, project_root: Path) -> list[DependencyResult]:
        """Recursively find and parse all supported build files.

        Args:
            project_root: Root directory to scan.

        Returns:
            One DependencyResult per build file found. Files inside excluded
            directories (``target/``, ``node_modules/``, etc.) are skipped.
        """
        results: list[DependencyResult] = []

        parsers: list[tuple[str, object]] = [
            ("pom.xml", self._parse_pom),
            ("package.json", self._parse_package_json),
            ("requirements.txt", self._parse_requirements),
            ("pyproject.toml", self._parse_pyproject),
        ]

        for filename, parser in parsers:
            for build_file in sorted(project_root.rglob(filename)):
                if _is_excluded(build_file):
                    continue
                try:
                    result = parser(build_file)  # type: ignore[operator]
                    results.append(result)
                except Exception as exc:
                    logger.warning("Failed to parse %s: %s", build_file, exc)

        return results

    # ── Maven (pom.xml) ────────────────────────────────────────────────────

    def _parse_pom(self, path: Path) -> DependencyResult:
        """Parse a Maven pom.xml and return a DependencyResult."""
        root = ET.fromstring(path.read_bytes())

        # Resolve properties for version substitution
        properties = _pom_properties(root)

        # Own coordinates
        project_name = _pom_text(root, "artifactId")
        project_version = _pom_text(root, "version")

        # Framework detection from <parent>
        framework = ""
        framework_version = ""
        parent = _pom_find(root, "parent")
        if parent is not None:
            parent_artifact = _pom_text(parent, "artifactId")
            parent_group = _pom_text(parent, "groupId")
            parent_version = _pom_text(parent, "version")
            if "spring-boot" in parent_artifact or "springframework.boot" in parent_group:
                framework = "spring-boot"
                framework_version = _resolve_property(parent_version, properties)

        deps: list[AnalyzedDependency] = []
        deps_elem = _pom_find(root, "dependencies")
        if deps_elem is not None:
            for dep_elem in _pom_find_all(deps_elem, "dependency"):
                dep = self._parse_pom_dependency(dep_elem, properties, framework)
                deps.append(dep)
                # Refine framework detection if not found in parent
                if not framework and dep.category == "framework":
                    if "spring-boot" in dep.artifact_id or "springframework.boot" in dep.group_id:
                        framework = "spring-boot"
                        framework_version = dep.version

        return DependencyResult(
            source_file=path,
            source_type="maven",
            language="java",
            project_name=project_name,
            project_version=project_version,
            framework=framework,
            framework_version=framework_version,
            dependencies=deps,
        )

    def _parse_pom_dependency(
        self, dep_elem: ET.Element, properties: dict[str, str], framework: str
    ) -> AnalyzedDependency:
        group_id = _pom_text(dep_elem, "groupId")
        artifact_id = _pom_text(dep_elem, "artifactId")
        raw_version = _pom_text(dep_elem, "version")
        scope_text = _pom_text(dep_elem, "scope") or "compile"
        is_optional = _pom_text(dep_elem, "optional") == "true"

        version = _resolve_property(raw_version, properties)
        scope = "optional" if is_optional else scope_text
        category = _categorize_maven(group_id, artifact_id, scope)

        return AnalyzedDependency(
            name=artifact_id,
            version=version,
            scope=scope,
            category=category,
            group_id=group_id,
            artifact_id=artifact_id,
        )

    # ── npm (package.json) ─────────────────────────────────────────────────

    def _parse_package_json(self, path: Path) -> DependencyResult:
        """Parse an npm package.json and return a DependencyResult."""
        pkg = json.loads(path.read_text(encoding="utf-8"))

        # Skip lock files and non-project package.json (no name / private internal)
        if not isinstance(pkg, dict):
            raise ValueError("Not a valid package.json object")

        project_name = pkg.get("name", "")
        project_version = pkg.get("version", "")

        prod_raw: dict[str, str] = pkg.get("dependencies", {})
        dev_raw: dict[str, str] = pkg.get("devDependencies", {})
        peer_raw: dict[str, str] = pkg.get("peerDependencies", {})

        # Framework detection
        framework, framework_version = _detect_npm_framework(prod_raw)

        deps: list[AnalyzedDependency] = []
        for pkg_name, ver in prod_raw.items():
            deps.append(_make_npm_dep(pkg_name, ver, "compile"))
        for pkg_name, ver in dev_raw.items():
            deps.append(_make_npm_dep(pkg_name, ver, "dev"))
        for pkg_name, ver in peer_raw.items():
            deps.append(_make_npm_dep(pkg_name, ver, "peer"))

        return DependencyResult(
            source_file=path,
            source_type="npm",
            language="typescript",
            project_name=project_name,
            project_version=project_version,
            framework=framework,
            framework_version=framework_version,
            dependencies=deps,
        )

    # ── pip (requirements.txt) ─────────────────────────────────────────────

    def _parse_requirements(self, path: Path) -> DependencyResult:
        """Parse a requirements.txt and return a DependencyResult."""
        deps: list[AnalyzedDependency] = []
        framework = ""
        framework_version = ""

        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue

            name, version = _parse_req_line(line)
            if not name:
                continue

            category = _categorize_pip(name)
            deps.append(
                AnalyzedDependency(
                    name=name,
                    version=version,
                    scope="compile",
                    category=category,
                )
            )

            if not framework and category == "framework":
                framework, framework_version = _detect_pip_framework(name, version)

        return DependencyResult(
            source_file=path,
            source_type="pip",
            language="python",
            project_name="",
            project_version="",
            framework=framework,
            framework_version=framework_version,
            dependencies=deps,
        )

    # ── Poetry / PEP 621 (pyproject.toml) ─────────────────────────────────

    def _parse_pyproject(self, path: Path) -> DependencyResult:
        """Parse a pyproject.toml (Poetry or PEP 621) and return a DependencyResult."""
        data = tomllib.loads(path.read_text(encoding="utf-8"))

        project_name = (
            data.get("tool", {}).get("poetry", {}).get("name", "")
            or data.get("project", {}).get("name", "")
        )
        project_version = (
            data.get("tool", {}).get("poetry", {}).get("version", "")
            or data.get("project", {}).get("version", "")
        )

        deps: list[AnalyzedDependency] = []
        framework = ""
        framework_version = ""

        # ── Poetry format ──────────────────────────────────────────────────
        poetry = data.get("tool", {}).get("poetry", {})
        if poetry:
            prod = poetry.get("dependencies", {})
            for pkg_name, ver_spec in prod.items():
                if pkg_name.lower() == "python":
                    continue
                version = _poetry_version(ver_spec)
                category = _categorize_pip(pkg_name)
                deps.append(
                    AnalyzedDependency(
                        name=pkg_name,
                        version=version,
                        scope="compile",
                        category=category,
                    )
                )
                if not framework and category == "framework":
                    framework, framework_version = _detect_pip_framework(pkg_name, version)

            # Dev groups: [tool.poetry.group.X.dependencies] or [tool.poetry.dev-dependencies]
            dev_groups: list[dict] = [poetry.get("dev-dependencies", {})]
            for group in poetry.get("group", {}).values():
                dev_groups.append(group.get("dependencies", {}))

            for dev_map in dev_groups:
                for pkg_name, ver_spec in dev_map.items():
                    version = _poetry_version(ver_spec)
                    deps.append(
                        AnalyzedDependency(
                            name=pkg_name,
                            version=version,
                            scope="dev",
                            category=_categorize_pip(pkg_name),
                        )
                    )

        # ── PEP 621 format ─────────────────────────────────────────────────
        pep621_deps: list[str] = data.get("project", {}).get("dependencies", [])
        if pep621_deps:
            for req_str in pep621_deps:
                name, version = _parse_req_line(req_str)
                if not name:
                    continue
                category = _categorize_pip(name)
                deps.append(
                    AnalyzedDependency(
                        name=name,
                        version=version,
                        scope="compile",
                        category=category,
                    )
                )
                if not framework and category == "framework":
                    framework, framework_version = _detect_pip_framework(name, version)

        return DependencyResult(
            source_file=path,
            source_type="poetry" if poetry else "pip",
            language="python",
            project_name=project_name,
            project_version=project_version,
            framework=framework,
            framework_version=framework_version,
            dependencies=deps,
        )


# ── Maven helpers ─────────────────────────────────────────────────────────────

_POM_NS_RE = re.compile(r"\{[^}]+\}")


def _strip_ns(tag: str) -> str:
    """Strip XML namespace prefix from a tag (e.g. '{ns}tag' → 'tag')."""
    return _POM_NS_RE.sub("", tag)


def _pom_find(element: ET.Element, tag: str) -> ET.Element | None:
    """Find first direct child with *tag*, ignoring namespace."""
    for child in element:
        if _strip_ns(child.tag) == tag:
            return child
    return None


def _pom_find_all(element: ET.Element, tag: str) -> list[ET.Element]:
    """Find all direct children with *tag*, ignoring namespace."""
    return [child for child in element if _strip_ns(child.tag) == tag]


def _pom_text(element: ET.Element, tag: str, default: str = "") -> str:
    """Return text of first child with *tag*, or *default*."""
    child = _pom_find(element, tag)
    return (child.text or "").strip() if child is not None else default


def _pom_properties(root: ET.Element) -> dict[str, str]:
    """Extract <properties> as a flat dict for version substitution."""
    props: dict[str, str] = {}
    props_elem = _pom_find(root, "properties")
    if props_elem is not None:
        for child in props_elem:
            key = _strip_ns(child.tag)
            props[key] = (child.text or "").strip()
    return props


def _resolve_property(value: str, properties: dict[str, str]) -> str:
    """Substitute ${property.name} references from the properties dict."""
    def replace(m: re.Match) -> str:
        return properties.get(m.group(1), m.group(0))

    return re.sub(r"\$\{([^}]+)\}", replace, value)


def _categorize_maven(group_id: str, artifact_id: str, scope: str) -> str:
    """Map a Maven coordinate to a semantic dependency category."""
    g = group_id.lower()
    a = artifact_id.lower()

    # Test scope always wins
    if scope == "test":
        return "test"
    if any(x in a for x in ("junit", "mockito", "assertj", "testcontainer", "hamcrest")):
        return "test"
    if any(x in g for x in ("junit", "mockito", "assertj")):
        return "test"

    # Database
    if any(x in g + a for x in ("oracle", "ojdbc", "postgresql", "mysql", "mariadb",
                                  "h2database", "h2", "mongodb", "liquibase", "flyway")):
        return "database"
    if "data-jpa" in a or ("data" in a and "redis" not in a and "mongodb" not in a):
        if any(x in a for x in ("jpa", "jdbc", "r2dbc")):
            return "database"

    # Auth
    if "keycloak" in g or "keycloak" in a:
        return "auth"
    if "security" in a or "oauth" in a or "jwt" in a:
        return "auth"
    if "auth0" in g or "okta" in g:
        return "auth"

    # Cache
    if any(x in a for x in ("redis", "lettuce", "jedis", "memcached", "ehcache", "caffeine")):
        return "cache"
    if "data-redis" in a:
        return "cache"

    # Messaging
    if any(x in a for x in ("kafka", "rabbitmq", "amqp", "activemq", "artemis", "pulsar")):
        return "messaging"
    if any(x in g for x in ("kafka", "rabbitmq", "activemq")):
        return "messaging"

    # Utility
    if any(x in a for x in ("lombok", "mapstruct", "jackson", "gson", "commons",
                              "guava", "slf4j", "log4j", "logback")):
        return "utility"

    # Framework (broad — after specific patterns)
    if "springframework" in g or "spring-boot" in a or "spring" in a:
        return "framework"
    if any(x in g for x in ("io.quarkus", "io.micronaut", "jakarta")):
        return "framework"

    return "other"


# ── npm helpers ───────────────────────────────────────────────────────────────


def _detect_npm_framework(prod: dict[str, str]) -> tuple[str, str]:
    """Return (framework_name, version) from production dependencies."""
    if "@angular/core" in prod:
        return "angular", _strip_version_prefix(prod["@angular/core"])
    if "react" in prod:
        return "react", _strip_version_prefix(prod["react"])
    if "vue" in prod:
        return "vue", _strip_version_prefix(prod["vue"])
    if "svelte" in prod:
        return "svelte", _strip_version_prefix(prod["svelte"])
    if "next" in prod:
        return "next.js", _strip_version_prefix(prod["next"])
    if "nuxt" in prod:
        return "nuxt", _strip_version_prefix(prod["nuxt"])
    return "", ""


def _make_npm_dep(pkg_name: str, version: str, scope: str) -> AnalyzedDependency:
    return AnalyzedDependency(
        name=pkg_name,
        version=_strip_version_prefix(version),
        scope=scope,
        category=_categorize_npm(pkg_name, scope),
    )


def _strip_version_prefix(version: str) -> str:
    """Remove leading ^ ~ > < = from npm version strings."""
    return version.lstrip("^~>=<").split(" ")[0]


def _categorize_npm(package: str, scope: str) -> str:
    """Map an npm package name to a semantic category."""
    p = package.lower()

    # Test always wins for dev scope + test-related names
    if scope in ("dev", "peer") and any(
        x in p for x in ("jest", "jasmine", "karma", "mocha", "chai",
                          "testing-library", "cypress", "playwright", "spec")
    ):
        return "test"
    if p.startswith("@types/jasmine") or p.startswith("@types/node"):
        return "test"

    # Framework
    if p.startswith("@angular/") or p in ("rxjs", "zone.js"):
        return "framework"
    if p.startswith("@ngrx/") or p.startswith("@ngxs/") or p == "ng-zorro-antd":
        return "framework"
    if p in ("react", "react-dom") or p.startswith("react-router"):
        return "framework"
    if p in ("vue", "vue-router", "vuex", "pinia") or p.startswith("@vue/"):
        return "framework"
    if p in ("svelte", "next", "nuxt", "remix", "astro"):
        return "framework"

    # UI
    if any(x in p for x in ("bootstrap", "tailwind", "material", "primeng",
                              "antd", "chakra", "mantine", "@ng-bootstrap", "toastr")):
        return "ui"

    # Auth
    if any(x in p for x in ("keycloak", "auth0", "okta", "jwt", "oidc", "oauth")):
        return "auth"

    # HTTP
    if p in ("axios", "node-fetch", "got", "superagent", "ky"):
        return "http"

    # Test (catch-all for test frameworks)
    if any(x in p for x in ("jest", "jasmine", "karma", "mocha", "chai",
                              "testing-library", "cypress", "playwright", "storybook")):
        return "test"

    # Utility (build tools, type definitions, dev tooling)
    if p.startswith("@types/") or p in ("typescript",):
        return "utility"
    if any(x in p for x in ("webpack", "vite", "esbuild", "rollup", "babel",
                              "@angular/cli", "@angular/compiler-cli",
                              "ts-node", "eslint", "prettier")):
        return "utility"

    return "other"


# ── Python / pip helpers ──────────────────────────────────────────────────────

# Parses "django>=4.2", "fastapi==0.110.0", "celery[redis]>=5.3"
_REQ_PATTERN = re.compile(
    r"^([A-Za-z0-9_.-]+)(?:\[.*?\])?\s*([>=<!~^,\s\d.*|]+)?$"
)


def _parse_req_line(line: str) -> tuple[str, str]:
    """Parse one requirements line into (name, version_constraint)."""
    # Strip inline comments
    line = line.split("#")[0].strip()
    m = _REQ_PATTERN.match(line)
    if not m:
        return "", ""
    name = m.group(1).strip()
    version = (m.group(2) or "").strip()
    return name, version


def _poetry_version(ver_spec: object) -> str:
    """Extract version string from a Poetry dependency spec (str or dict)."""
    if isinstance(ver_spec, str):
        return ver_spec
    if isinstance(ver_spec, dict):
        return ver_spec.get("version", "")
    return ""


def _detect_pip_framework(name: str, version: str) -> tuple[str, str]:
    """Return (framework_name, version) from a Python package name."""
    n = name.lower()
    if n.startswith("django"):
        return "django", version
    if n in ("fastapi", "starlette"):
        return "fastapi" if n == "fastapi" else "fastapi (starlette)", version
    if n == "flask":
        return "flask", version
    if n in ("tornado", "aiohttp", "sanic", "litestar"):
        return n, version
    return "", ""


def _categorize_pip(name: str) -> str:
    """Map a Python package name to a semantic category."""
    n = name.lower()

    # Framework
    if any(n.startswith(x) for x in ("django", "flask", "fastapi",
                                       "starlette", "tornado", "aiohttp", "sanic")):
        return "framework"

    # Database
    if any(x in n for x in ("psycopg", "pymysql", "mysqlclient", "cx_oracle",
                              "sqlalchemy", "alembic", "pymongo", "motor",
                              "peewee", "tortoise", "databases")):
        return "database"
    if any(n.startswith(x) for x in ("db-",)):
        return "database"

    # Cache
    if "redis" in n or "memcache" in n or "celery" in n:
        return "cache" if "redis" in n or "memcache" in n else "messaging"

    # Auth
    if any(x in n for x in ("jwt", "jose", "oauth", "keycloak", "authlib",
                              "passlib", "bcrypt", "cryptography")):
        return "auth"

    # Test
    if any(n.startswith(x) for x in ("pytest", "unittest", "coverage", "mock",
                                       "faker", "factory-boy", "hypothesis")):
        return "test"
    if n in ("responses", "httpretty", "vcrpy"):
        return "test"

    # HTTP
    if n in ("requests", "httpx", "aiohttp", "urllib3", "websockets"):
        return "http"

    # Utility
    if n in ("pydantic", "attrs", "marshmallow", "click", "typer", "rich",
              "pyyaml", "toml", "tomli", "python-dotenv", "loguru",
              "pillow", "celery", "kombu"):
        return "utility"

    return "other"


# ── Shared helpers ────────────────────────────────────────────────────────────

_EXCLUDED_DIRS: frozenset[str] = frozenset(
    {"node_modules", "target", "dist", "build", ".git", "__pycache__",
     ".venv", "venv", ".codemind", ".angular"}
)


def _is_excluded(path: Path) -> bool:
    """Return True if the path passes through any excluded directory."""
    return any(part in _EXCLUDED_DIRS for part in path.parts)
