"""TypeScript/Angular analyzer — extracts classes, methods, and imports via tree-sitter AST."""

from __future__ import annotations

import logging
from pathlib import Path

from tree_sitter import Language, Node, Parser
import tree_sitter_typescript as tsts

from codemind.analyzer.base import (
    AnalyzedClass,
    AnalyzedMethod,
    AnalyzerResult,
    BaseAnalyzer,
)

logger = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────────

# Angular decorator name → semantic class type
_DECORATOR_TO_CLASS_TYPE: dict[str, str] = {
    "Component": "component",
    "Injectable": "service",   # services, guards, interceptors all use @Injectable
    "NgModule": "module",
    "Pipe": "pipe",
    "Directive": "directive",
}

# Directories that are never scanned
_EXCLUDED_DIRS: frozenset[str] = frozenset(
    {"node_modules", "dist", ".git", "__pycache__", ".venv", ".codemind", "target", ".angular"}
)

# tree-sitter method-like node types to extract
_METHOD_NODE_TYPES: frozenset[str] = frozenset(
    {"method_definition", "abstract_method_signature"}
)

# tree-sitter declaration node types that represent a named type
_CLASS_LIKE_NODE_TYPES: frozenset[str] = frozenset(
    {"class_declaration", "abstract_class_declaration"}
)

# Angular guard interfaces — refine @Injectable to "guard" when implemented
_GUARD_INTERFACES: frozenset[str] = frozenset(
    {"CanActivate", "CanActivateChild", "CanDeactivate", "CanLoad", "CanMatch"}
)

# Angular interceptor interfaces
_INTERCEPTOR_INTERFACES: frozenset[str] = frozenset(
    {"HttpInterceptor", "HttpInterceptorFn"}
)

# Common Angular prefix directories stripped when computing "package"
_ANGULAR_ROOTS: tuple[str, ...] = ("src/app/", "src/app", "app/", "app", "src/", "src")


# ── TypeScriptAnalyzer ─────────────────────────────────────────────────────────


class TypeScriptAnalyzer(BaseAnalyzer):
    """Analyzes TypeScript/Angular source files using tree-sitter AST parsing.

    Extracts from each .ts file:
    - Import statements (module paths)
    - Exported class / interface / enum declarations with:
        - Name and Angular semantic type (component, service, module, pipe, directive)
        - Angular decorators (@Component, @Injectable, @NgModule, @Pipe, @Directive)
        - Superclass and implemented interfaces
        - Methods (name, return type, visibility, parameter types)
        - "Module path" derived from the directory structure (Angular module grouping)
    """

    language = "typescript"

    def __init__(self) -> None:
        self._lang = Language(tsts.language_typescript())
        self._parser = Parser(self._lang)

    # ── Public API ─────────────────────────────────────────────────────────

    def can_analyze(self, file_path: Path) -> bool:
        """Return True for .ts files (excluding .d.ts declaration files)."""
        return file_path.suffix == ".ts" and not file_path.name.endswith(".d.ts")

    def analyze(self, project_root: Path) -> AnalyzerResult:
        """Scan all .ts files under *project_root* and return analysis results.

        Skips directories in :data:`_EXCLUDED_DIRS` (e.g. ``node_modules/``).

        Args:
            project_root: Root directory to scan.

        Returns:
            AnalyzerResult containing all discovered classes and any parse errors.
        """
        result = AnalyzerResult(language="typescript")

        ts_files = sorted(
            f for f in project_root.rglob("*.ts")
            if self.can_analyze(f) and not _is_excluded(f)
        )

        for ts_file in ts_files:
            try:
                classes = self._analyze_file(ts_file, project_root)
                result.classes.extend(classes)
                result.files_analyzed += 1
            except Exception as exc:
                msg = f"{ts_file.relative_to(project_root)}: {exc}"
                logger.warning("Failed to analyze %s: %s", ts_file, exc)
                result.errors.append(msg)

        return result

    # ── Private: file-level extraction ────────────────────────────────────

    def _analyze_file(self, file_path: Path, project_root: Path) -> list[AnalyzedClass]:
        """Parse one .ts file; return all exported class/interface/enum declarations."""
        source = file_path.read_bytes()
        tree = self._parser.parse(source)
        root = tree.root_node

        imports = _extract_imports(root)
        module_path = _compute_module_path(file_path, project_root)

        classes: list[AnalyzedClass] = []
        for node in root.children:
            if node.type == "export_statement":
                extracted = self._extract_from_export(node, file_path, module_path, imports)
                classes.extend(extracted)

        return classes

    def _extract_from_export(
        self,
        export_node: Node,
        file_path: Path,
        module_path: str,
        imports: list[str],
    ) -> list[AnalyzedClass]:
        """Handle one export_statement — may contain decorators + class/interface/enum."""
        decorators: list[str] = []
        results: list[AnalyzedClass] = []

        for child in export_node.children:
            match child.type:
                case "decorator":
                    name = _extract_decorator_name(child)
                    if name:
                        decorators.append(f"@{name}")
                case t if t in _CLASS_LIKE_NODE_TYPES:
                    cls = self._extract_class(
                        child, file_path, module_path, imports, decorators
                    )
                    results.append(cls)
                    decorators = []  # consumed
                case "interface_declaration":
                    iface = self._extract_interface(child, file_path, module_path, imports)
                    results.append(iface)
                case "enum_declaration":
                    enum = self._extract_enum(child, file_path, module_path, imports)
                    results.append(enum)

        return results

    # ── Class extraction ───────────────────────────────────────────────────

    def _extract_class(
        self,
        node: Node,
        file_path: Path,
        module_path: str,
        imports: list[str],
        decorators: list[str],
    ) -> AnalyzedClass:
        """Build an AnalyzedClass from a class_declaration / abstract_class_declaration."""
        name = ""
        superclass = ""
        interfaces: list[str] = []
        methods: list[AnalyzedMethod] = []

        for child in node.children:
            match child.type:
                case "type_identifier":
                    if not name:
                        name = child.text.decode("utf-8")
                case "class_heritage":
                    superclass, interfaces = _extract_heritage(child)
                case "class_body":
                    methods = self._extract_methods(child)

        class_type = _determine_class_type(decorators, interfaces)

        return AnalyzedClass(
            name=name,
            file_path=file_path,
            package=module_path,
            class_type=class_type,
            annotations=decorators,
            methods=methods,
            imports=imports,
            superclass=superclass,
            interfaces=interfaces,
        )

    def _extract_interface(
        self,
        node: Node,
        file_path: Path,
        module_path: str,
        imports: list[str],
    ) -> AnalyzedClass:
        """Build an AnalyzedClass (type='interface') from an interface_declaration."""
        name = ""
        for child in node.children:
            if child.type == "type_identifier":
                name = child.text.decode("utf-8")
                break

        return AnalyzedClass(
            name=name,
            file_path=file_path,
            package=module_path,
            class_type="interface",
            annotations=[],
            methods=[],
            imports=imports,
        )

    def _extract_enum(
        self,
        node: Node,
        file_path: Path,
        module_path: str,
        imports: list[str],
    ) -> AnalyzedClass:
        """Build an AnalyzedClass (type='enum') from an enum_declaration."""
        name = ""
        for child in node.children:
            if child.type == "identifier":
                name = child.text.decode("utf-8")
                break

        return AnalyzedClass(
            name=name,
            file_path=file_path,
            package=module_path,
            class_type="enum",
            annotations=[],
            methods=[],
            imports=imports,
        )

    # ── Method extraction ──────────────────────────────────────────────────

    def _extract_methods(self, class_body: Node) -> list[AnalyzedMethod]:
        """Return all method definitions found inside a class body."""
        return [
            self._extract_method(child)
            for child in class_body.children
            if child.type in _METHOD_NODE_TYPES
        ]

    def _extract_method(self, node: Node) -> AnalyzedMethod:
        """Build an AnalyzedMethod from a method_definition or abstract_method_signature."""
        name = ""
        visibility = "public"   # TypeScript default
        return_type = ""
        parameters: list[str] = []

        for child in node.children:
            match child.type:
                case "accessibility_modifier":
                    # child contains the keyword node (private/public/protected)
                    for kw in child.children:
                        if kw.type in ("private", "public", "protected"):
                            visibility = kw.type
                case "property_identifier":
                    if not name:
                        name = child.text.decode("utf-8")
                case "formal_parameters":
                    parameters = _extract_parameter_types(child)
                case "type_annotation":
                    return_type = _type_annotation_text(child)

        return AnalyzedMethod(
            name=name,
            return_type=return_type,
            annotations=[],   # TypeScript method-level decorators not common in Angular
            visibility=visibility,
            parameters=parameters,
        )


# ── Module-level helpers ───────────────────────────────────────────────────────


def _extract_imports(root: Node) -> list[str]:
    """Collect unique module paths from all import statements."""
    seen: set[str] = set()
    imports: list[str] = []
    for child in root.children:
        if child.type == "import_statement":
            module = _import_module_path(child)
            if module and module not in seen:
                seen.add(module)
                imports.append(module)
    return imports


def _import_module_path(import_node: Node) -> str:
    """Extract the module path string from an import_statement node."""
    for child in import_node.children:
        if child.type == "string":
            for part in child.children:
                if part.type == "string_fragment":
                    return part.text.decode("utf-8")
    return ""


def _extract_decorator_name(decorator_node: Node) -> str:
    """Return the decorator name (e.g. 'Component' from '@Component({...})')."""
    for child in decorator_node.children:
        match child.type:
            case "call_expression":
                # @Decorator(args) — name is first identifier in call_expression
                for c in child.children:
                    if c.type == "identifier":
                        return c.text.decode("utf-8")
            case "identifier":
                # @Decorator — plain decorator with no args
                return child.text.decode("utf-8")
            case "member_expression":
                # @ns.Decorator — rare, use full text
                return child.text.decode("utf-8")
    return ""


def _extract_heritage(heritage_node: Node) -> tuple[str, list[str]]:
    """Return (superclass_name, [interface_names]) from a class_heritage node."""
    superclass = ""
    interfaces: list[str] = []

    for child in heritage_node.children:
        match child.type:
            case "extends_clause":
                for part in child.children:
                    if part.type in ("type_identifier", "generic_type"):
                        superclass = part.text.decode("utf-8")
                        break
            case "implements_clause":
                for part in child.children:
                    if part.type == "type_identifier":
                        interfaces.append(part.text.decode("utf-8"))
                    elif part.type == "generic_type":
                        # e.g. CanDeactivate<MyComponent> — extract outer name
                        for p in part.children:
                            if p.type == "type_identifier":
                                interfaces.append(p.text.decode("utf-8"))
                                break

    return superclass, interfaces


def _extract_parameter_types(params_node: Node) -> list[str]:
    """Return the type name of each parameter (skipping constructor access modifiers)."""
    types: list[str] = []
    for child in params_node.children:
        if child.type in ("required_parameter", "optional_parameter"):
            type_ann = _find_child(child, "type_annotation")
            if type_ann:
                types.append(_type_annotation_text(type_ann))
    return types


def _type_annotation_text(annotation_node: Node) -> str:
    """Extract the type text from a type_annotation node (strips leading ':')."""
    for child in annotation_node.children:
        if child.type != ":":
            return child.text.decode("utf-8").strip()
    return ""


def _determine_class_type(decorators: list[str], interfaces: list[str]) -> str:
    """Map Angular decorators + implemented interfaces to a semantic class type.

    Guards and interceptors both use @Injectable — refine via their interfaces.
    """
    for dec in decorators:
        name = dec.lstrip("@")
        if name == "Injectable":
            # Refine by implemented interfaces
            if any(i in _GUARD_INTERFACES for i in interfaces):
                return "guard"
            if any(i in _INTERCEPTOR_INTERFACES for i in interfaces):
                return "interceptor"
            return "service"
        if name in _DECORATOR_TO_CLASS_TYPE:
            return _DECORATOR_TO_CLASS_TYPE[name]
    return "class"


def _compute_module_path(file_path: Path, project_root: Path) -> str:
    """Derive a logical module path from a TypeScript file's directory.

    Strips common Angular root prefixes (``src/app/``) and returns the
    remaining directory path using ``/`` separators, e.g. ``users/components``.
    Falls back to the raw relative parent path if no Angular root is found.
    """
    try:
        rel = file_path.relative_to(project_root)
    except ValueError:
        return file_path.parent.name

    # Convert to forward-slash string and strip filename
    rel_dir = "/".join(rel.parts[:-1])

    for root_prefix in _ANGULAR_ROOTS:
        if rel_dir.startswith(root_prefix):
            stripped = rel_dir[len(root_prefix):].strip("/")
            return stripped or "app"

    return rel_dir or "."


def _find_child(node: Node, child_type: str) -> Node | None:
    """Return the first direct child of *node* with the given type, or None."""
    for child in node.children:
        if child.type == child_type:
            return child
    return None


def _is_excluded(path: Path) -> bool:
    """Return True if the path passes through any excluded directory."""
    return any(part in _EXCLUDED_DIRS for part in path.parts)
