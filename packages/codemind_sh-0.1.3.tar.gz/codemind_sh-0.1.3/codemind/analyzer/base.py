"""Base classes and data models for all code analyzers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class AnalyzedMethod:
    """A method or function extracted from source code.

    Attributes:
        name: Method name.
        return_type: Return type as a string (e.g. "String", "List<User>", "void").
        annotations: Spring/Jakarta annotations (e.g. ["@GetMapping", "@Transactional"]).
        visibility: "public", "protected", "private", or "package-private".
        parameters: List of parameter type names (e.g. ["Long", "String"]).
    """

    name: str
    return_type: str
    annotations: list[str] = field(default_factory=list)
    visibility: str = "public"
    parameters: list[str] = field(default_factory=list)


@dataclass
class AnalyzedClass:
    """A class, interface, or enum extracted from source code.

    Attributes:
        name: Simple class name (e.g. "UserService").
        file_path: Absolute path to the source file.
        package: Fully-qualified package (e.g. "com.example.service").
        class_type: Semantic type — "service", "controller", "repository",
            "entity", "component", "configuration", "interface", "enum", or "class".
        annotations: Class-level annotations (e.g. ["@Service", "@Transactional"]).
        methods: All method declarations in this class.
        imports: All import statements (fully-qualified, e.g. "org.springframework…").
        superclass: Name of the extended class, empty string if none.
        interfaces: Names of implemented interfaces.
        injected_types: Simple type names of constructor/field-injected dependencies
            (e.g. ["EmailService", "UserRepository"]).  Populated by JavaAnalyzer;
            enables same-package dependency detection that imports cannot provide.
    """

    name: str
    file_path: Path
    package: str
    class_type: str
    annotations: list[str] = field(default_factory=list)
    methods: list[AnalyzedMethod] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    superclass: str = ""
    interfaces: list[str] = field(default_factory=list)
    injected_types: list[str] = field(default_factory=list)

    @property
    def fully_qualified_name(self) -> str:
        """Return the fully-qualified class name."""
        if self.package:
            return f"{self.package}.{self.name}"
        return self.name


@dataclass
class AnalyzerResult:
    """Aggregated result of analyzing a project's source files.

    Attributes:
        language: Language key (e.g. "java", "typescript").
        files_analyzed: Number of successfully parsed files.
        classes: All extracted class/interface/enum declarations.
        errors: Files that failed to parse (path + error message).
    """

    language: str
    files_analyzed: int = 0
    classes: list[AnalyzedClass] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    # ── Convenience filters ────────────────────────────────────────────────

    @property
    def services(self) -> list[AnalyzedClass]:
        """All classes annotated as services."""
        return [c for c in self.classes if c.class_type == "service"]

    @property
    def controllers(self) -> list[AnalyzedClass]:
        """All classes annotated as controllers."""
        return [c for c in self.classes if c.class_type == "controller"]

    @property
    def repositories(self) -> list[AnalyzedClass]:
        """All classes annotated as repositories."""
        return [c for c in self.classes if c.class_type == "repository"]

    @property
    def entities(self) -> list[AnalyzedClass]:
        """All classes annotated as JPA entities."""
        return [c for c in self.classes if c.class_type == "entity"]

    @property
    def components(self) -> list[AnalyzedClass]:
        """All generic Spring components."""
        return [c for c in self.classes if c.class_type == "component"]

    @property
    def interfaces(self) -> list[AnalyzedClass]:
        """All interface declarations."""
        return [c for c in self.classes if c.class_type == "interface"]


class BaseAnalyzer(ABC):
    """Abstract base class for language-specific code analyzers.

    Concrete subclasses implement :meth:`analyze` and :meth:`can_analyze`
    for a specific language (Java, TypeScript, Python, etc.).
    """

    language: str = ""

    @abstractmethod
    def analyze(self, project_root: Path) -> AnalyzerResult:
        """Scan all source files under *project_root* and return analysis results.

        Args:
            project_root: Root directory to scan recursively.

        Returns:
            AnalyzerResult with extracted classes, methods, and any parse errors.
        """
        ...

    @abstractmethod
    def can_analyze(self, file_path: Path) -> bool:
        """Return True if this analyzer can handle the given file.

        Args:
            file_path: Path to check.

        Returns:
            True if the file extension / name matches this language.
        """
        ...
