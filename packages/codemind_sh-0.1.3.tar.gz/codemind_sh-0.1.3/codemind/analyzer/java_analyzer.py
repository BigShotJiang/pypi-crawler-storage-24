"""Java code analyzer — extracts classes, methods, and imports via tree-sitter AST."""

from __future__ import annotations

import logging
from pathlib import Path

from tree_sitter import Language, Node, Parser
import tree_sitter_java as tsjava

from codemind.analyzer.base import (
    AnalyzedClass,
    AnalyzedMethod,
    AnalyzerResult,
    BaseAnalyzer,
)

logger = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────────

# Maps class-level annotation names → semantic class type
_ANNOTATION_TO_CLASS_TYPE: dict[str, str] = {
    "@Service": "service",
    "@RestController": "controller",
    "@Controller": "controller",
    "@Repository": "repository",
    "@Entity": "entity",
    "@Component": "component",
    "@Configuration": "configuration",
    "@ControllerAdvice": "advice",
    "@Aspect": "aspect",
}

# Directories whose contents are never analyzed
_EXCLUDED_DIRS: frozenset[str] = frozenset(
    {"target", "build", ".git", "node_modules", "__pycache__", ".venv", ".codemind"}
)

# tree-sitter node types that represent a method return type
_RETURN_TYPE_NODES: frozenset[str] = frozenset(
    {
        "void_type",
        "type_identifier",
        "generic_type",
        "array_type",
        "integral_type",
        "floating_point_type",
        "boolean_type",
        "scoped_type_identifier",
    }
)

# Visibility modifier keywords in Java
_VISIBILITY_KEYWORDS: frozenset[str] = frozenset(
    {"public", "protected", "private"}
)


# ── JavaAnalyzer ───────────────────────────────────────────────────────────────


class JavaAnalyzer(BaseAnalyzer):
    """Analyzes Java source files using tree-sitter AST parsing.

    Extracts from each .java file:
    - Package declaration
    - Import statements
    - Class / interface / enum declarations with:
        - Name, package, file path
        - Semantic class type (service, controller, repository, entity, …)
        - Class-level annotations
        - Superclass and implemented interfaces
        - Method declarations (name, return type, annotations, visibility, params)
    """

    language = "java"

    def __init__(self) -> None:
        self._lang = Language(tsjava.language())
        self._parser = Parser(self._lang)

    # ── Public API ─────────────────────────────────────────────────────────

    def can_analyze(self, file_path: Path) -> bool:
        """Return True for .java files."""
        return file_path.suffix == ".java"

    def analyze(self, project_root: Path) -> AnalyzerResult:
        """Scan all .java files under *project_root* and return analysis results.

        Skips directories in :data:`_EXCLUDED_DIRS` (e.g. ``target/``, ``build/``).

        Args:
            project_root: Root directory to scan.

        Returns:
            AnalyzerResult containing all discovered classes and any parse errors.
        """
        result = AnalyzerResult(language="java")

        java_files = sorted(
            f for f in project_root.rglob("*.java") if not _is_excluded(f)
        )

        for java_file in java_files:
            try:
                classes = self._analyze_file(java_file)
                result.classes.extend(classes)
                result.files_analyzed += 1
            except Exception as exc:
                msg = f"{java_file.relative_to(project_root)}: {exc}"
                logger.warning("Failed to analyze %s: %s", java_file, exc)
                result.errors.append(msg)

        return result

    # ── Private: file-level extraction ────────────────────────────────────

    def _analyze_file(self, file_path: Path) -> list[AnalyzedClass]:
        """Parse one .java file; return all top-level class/interface/enum declarations."""
        source = file_path.read_bytes()
        tree = self._parser.parse(source)
        root = tree.root_node

        package = _extract_package(root)
        imports = _extract_imports(root)

        classes: list[AnalyzedClass] = []
        for node in root.children:
            if node.type in (
                "class_declaration",
                "interface_declaration",
                "enum_declaration",
            ):
                cls = self._extract_class(node, file_path, package, imports)
                classes.append(cls)

        return classes

    def _extract_class(
        self,
        node: Node,
        file_path: Path,
        package: str,
        imports: list[str],
    ) -> AnalyzedClass:
        """Build an AnalyzedClass from a class/interface/enum declaration node."""
        annotations: list[str] = []
        name = ""
        superclass = ""
        interfaces: list[AnalyzedMethod] = []
        methods: list[AnalyzedMethod] = []
        injected_types: list[str] = []

        for child in node.children:
            match child.type:
                case "modifiers":
                    annotations = _extract_annotations(child)
                case "identifier":
                    if not name:  # first identifier = class name
                        name = child.text.decode("utf-8")
                case "superclass":
                    superclass = _extract_superclass(child)
                case "super_interfaces":
                    interfaces = _extract_interface_names(child)
                case "class_body" | "interface_body" | "enum_body":
                    methods = self._extract_methods(child)
                    injected_types = _extract_injected_types(child)

        class_type = _determine_class_type(annotations, node.type)

        return AnalyzedClass(
            name=name,
            file_path=file_path,
            package=package,
            class_type=class_type,
            annotations=annotations,
            methods=methods,
            imports=imports,
            superclass=superclass,
            interfaces=interfaces,
            injected_types=injected_types,
        )

    def _extract_methods(self, body_node: Node) -> list[AnalyzedMethod]:
        """Return all method declarations found directly inside a class body."""
        return [
            self._extract_method(child)
            for child in body_node.children
            if child.type == "method_declaration"
        ]

    def _extract_method(self, node: Node) -> AnalyzedMethod:
        """Build an AnalyzedMethod from a method_declaration node."""
        annotations: list[str] = []
        visibility = "package-private"
        return_type = "void"
        name = ""
        parameters: list[str] = []
        name_found = False

        for child in node.children:
            match child.type:
                case "modifiers":
                    annotations = _extract_annotations(child)
                    visibility = _extract_visibility(child)
                case "identifier" if not name_found:
                    name = child.text.decode("utf-8")
                    name_found = True
                case "formal_parameters":
                    parameters = _extract_parameter_types(child)
                case t if t in _RETURN_TYPE_NODES:
                    return_type = child.text.decode("utf-8").strip()

        return AnalyzedMethod(
            name=name,
            return_type=return_type,
            annotations=annotations,
            visibility=visibility,
            parameters=parameters,
        )


# ── Module-level helpers (pure functions, no parser state) ────────────────────


def _extract_package(root: Node) -> str:
    """Return the package name from the program root, or empty string."""
    for child in root.children:
        if child.type == "package_declaration":
            for part in child.children:
                if part.type in ("scoped_identifier", "identifier"):
                    return part.text.decode("utf-8")
    return ""


def _extract_imports(root: Node) -> list[str]:
    """Return all fully-qualified import names."""
    imports: list[str] = []
    for child in root.children:
        if child.type == "import_declaration":
            for part in child.children:
                if part.type in ("scoped_identifier", "identifier"):
                    imports.append(part.text.decode("utf-8"))
    return imports


def _extract_annotations(modifiers_node: Node) -> list[str]:
    """Extract annotation names (e.g. '@Service') from a modifiers node."""
    annotations: list[str] = []
    for child in modifiers_node.children:
        if child.type in ("marker_annotation", "annotation"):
            for part in child.children:
                if part.type == "identifier":
                    annotations.append(f"@{part.text.decode('utf-8')}")
                    break  # only need the name, skip argument_list
    return annotations


def _extract_visibility(modifiers_node: Node) -> str:
    """Return 'public', 'protected', 'private', or 'package-private'."""
    for child in modifiers_node.children:
        if child.type in _VISIBILITY_KEYWORDS:
            return child.type
    return "package-private"


def _extract_superclass(superclass_node: Node) -> str:
    """Return the name of the extended class."""
    for child in superclass_node.children:
        if child.type == "type_identifier":
            return child.text.decode("utf-8")
    return ""


def _extract_interface_names(super_interfaces_node: Node) -> list[str]:
    """Return names of all implemented interfaces."""
    names: list[str] = []
    for child in super_interfaces_node.children:
        if child.type == "type_list":
            for part in child.children:
                if part.type == "type_identifier":
                    names.append(part.text.decode("utf-8"))
    return names


def _extract_parameter_types(params_node: Node) -> list[str]:
    """Return the type name of each formal parameter."""
    types: list[str] = []
    for child in params_node.children:
        if child.type in ("formal_parameter", "spread_parameter"):
            for part in child.children:
                if part.type in _RETURN_TYPE_NODES:
                    suffix = "..." if child.type == "spread_parameter" else ""
                    types.append(part.text.decode("utf-8") + suffix)
                    break
    return types


def _extract_injected_types(body_node: Node) -> list[str]:
    """Extract dependency type names from constructors and injected fields.

    Handles three Spring/Lombok injection patterns:
    - Constructor injection: ``public Svc(EmailService es)`` → ``["EmailService"]``
    - ``@Autowired`` field: ``@Autowired private EmailService es;`` → ``["EmailService"]``
    - ``final`` field (Lombok ``@RequiredArgsConstructor``): ``private final EmailService es;``

    Generic outer types (e.g. ``List<Foo>``) are stripped to their base type
    (``"List"``).  Lowercase-starting types (primitives like ``int``, ``boolean``)
    are excluded automatically.  Wrapper types such as ``String`` / ``Long`` are
    included here but will be silently dropped by the ``name_set`` lookup in the
    connection builder.
    """
    types: set[str] = set()

    for child in body_node.children:
        if child.type == "constructor_declaration":
            for part in child.children:
                if part.type == "formal_parameters":
                    for t in _extract_parameter_types(part):
                        clean = t.split("<")[0].strip()
                        if clean and clean[0].isupper():
                            types.add(clean)

        elif child.type == "field_declaration":
            has_autowired = False
            is_final = False
            field_type = ""

            for part in child.children:
                if part.type == "modifiers":
                    for mod in part.children:
                        if mod.type in ("marker_annotation", "annotation"):
                            for a in mod.children:
                                if a.type == "identifier" and a.text.decode("utf-8") in (
                                    "Autowired", "Inject"
                                ):
                                    has_autowired = True
                        elif mod.type == "final":
                            is_final = True
                elif part.type == "type_identifier":
                    field_type = part.text.decode("utf-8")
                elif part.type == "generic_type":
                    raw = part.text.decode("utf-8")
                    field_type = raw.split("<")[0].strip()

            if field_type and (has_autowired or is_final) and field_type[0].isupper():
                types.add(field_type)

    return sorted(types)


def _determine_class_type(annotations: list[str], node_type: str) -> str:
    """Map annotations + AST node type to a semantic class type string.

    Spring annotations take priority over structural type — a @Repository
    interface is semantically a repository (Spring Data JPA pattern), not
    a generic interface.
    """
    # Annotation-based detection always wins
    for annotation in annotations:
        if annotation in _ANNOTATION_TO_CLASS_TYPE:
            return _ANNOTATION_TO_CLASS_TYPE[annotation]
    # Fall back to structural node type
    if node_type == "interface_declaration":
        return "interface"
    if node_type == "enum_declaration":
        return "enum"
    return "class"


def _is_excluded(path: Path) -> bool:
    """Return True if the path passes through any excluded directory."""
    return any(part in _EXCLUDED_DIRS for part in path.parts)
