"""Register CodeMind as an MCP server with installed AI coding tools.

Supports:
  - Claude Code   → project-level .claude/settings.json
                  → global      ~/.claude/settings.json
  - Cursor        → project-level .cursor/mcp.json
                  → global      ~/.cursor/mcp.json
  - Claude Desktop → global only (platform config dir)

Design:
  - Never overwrites existing mcpServers entries — merges codemind in.
  - Writes atomically (tmp → replace).
  - All writes are idempotent: re-running connect on an already-configured
    project is safe and reports already_configured=True.
  - Absolute executable path derived from the active Python env so the
    config works regardless of PATH or pyenv shim resolution in subprocesses.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

# ── Tool identifiers ──────────────────────────────────────────────────────────

TOOL_CLAUDE_CODE = "claude"
TOOL_CURSOR = "cursor"
TOOL_CLAUDE_DESKTOP = "claude_desktop"

_TOOL_LABELS = {
    TOOL_CLAUDE_CODE: "Claude Code",
    TOOL_CURSOR: "Cursor",
    TOOL_CLAUDE_DESKTOP: "Claude Desktop",
}

_RESTART_HINTS = {
    TOOL_CLAUDE_CODE: "restart Claude Code (or open a new session) to activate",
    TOOL_CURSOR: "restart Cursor to activate",
    TOOL_CLAUDE_DESKTOP: "restart Claude Desktop to activate",
}


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class ConnectResult:
    """Outcome of registering one AI tool."""

    tool: str              # TOOL_* constant
    config_path: Path
    success: bool = True
    already_configured: bool = False   # entry existed and was unchanged
    created: bool = False              # config file did not exist before
    error: str = ""

    @property
    def label(self) -> str:
        return _TOOL_LABELS.get(self.tool, self.tool)

    @property
    def restart_hint(self) -> str:
        return _RESTART_HINTS.get(self.tool, "restart the AI tool to activate")


# ── Executable discovery ──────────────────────────────────────────────────────

def _codemind_exe() -> str:
    """Absolute path to the codemind CLI in the active Python environment.

    Checks the interpreter's bin/ directory first (most reliable in venvs
    and pyenv environments), then falls back to shutil.which.
    """
    candidate = Path(sys.executable).parent / "codemind"
    if candidate.exists():
        return str(candidate)
    found = shutil.which("codemind")
    return found or "codemind"


# ── Config file paths ─────────────────────────────────────────────────────────

def _claude_code_project_config(project_root: Path) -> Path:
    # Claude Code reads project-level MCP from .mcp.json at the project root.
    # Writing to .claude/settings.json is NOT correct — mcpServers is not a
    # valid key there and causes schema validation errors in recent Claude Code.
    return project_root / ".mcp.json"

def _claude_code_global_config() -> Path:
    # Claude Code reads user-level MCP from ~/.claude.json (not ~/.claude/settings.json)
    return Path.home() / ".claude.json"

def _cursor_project_config(project_root: Path) -> Path:
    return project_root / ".cursor" / "mcp.json"

def _cursor_global_config() -> Path:
    return Path.home() / ".cursor" / "mcp.json"

def _claude_desktop_config() -> Path | None:
    system = platform.system()
    if system == "Darwin":
        return (
            Path.home()
            / "Library" / "Application Support" / "Claude"
            / "claude_desktop_config.json"
        )
    if system == "Windows":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
    return None


# ── Detection ─────────────────────────────────────────────────────────────────

def is_claude_code_installed() -> bool:
    """True when ~/.claude/ directory exists (created on first Claude Code run)."""
    return (Path.home() / ".claude").is_dir()

def is_cursor_installed() -> bool:
    """True when ~/.cursor/ exists or the Cursor.app is present on macOS."""
    if (Path.home() / ".cursor").is_dir():
        return True
    if platform.system() == "Darwin":
        return Path("/Applications/Cursor.app").exists()
    return False

def is_claude_desktop_installed() -> bool:
    """True when the Claude Desktop config directory exists."""
    path = _claude_desktop_config()
    return path is not None and path.parent.is_dir()


def detected_tools() -> list[str]:
    """Return list of tool IDs that appear to be installed on this machine."""
    found = []
    if is_claude_code_installed():
        found.append(TOOL_CLAUDE_CODE)
    if is_cursor_installed():
        found.append(TOOL_CURSOR)
    if is_claude_desktop_installed():
        found.append(TOOL_CLAUDE_DESKTOP)
    return found


# ── JSON helpers ──────────────────────────────────────────────────────────────

def _read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8")) or {}
    except (json.JSONDecodeError, OSError):
        return {}


def _write_json(path: Path, data: dict) -> None:
    """Atomically write JSON — parent dirs created if missing."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    tmp.replace(path)


def _mcp_entry(project_root: Path) -> dict:
    """Build the mcpServers entry for this project."""
    return {
        "command": _codemind_exe(),
        "args": ["serve", "--path", str(project_root.resolve())],
    }


def _merge_entry(config: dict, project_root: Path) -> tuple[dict, bool]:
    """Add/update codemind entry in mcpServers.

    Returns:
        (updated_config, already_had_identical_entry)
    """
    servers = config.setdefault("mcpServers", {})
    entry = _mcp_entry(project_root)
    already = servers.get("codemind") == entry
    servers["codemind"] = entry
    return config, already


# ── Per-tool connect ──────────────────────────────────────────────────────────

def connect_claude_code(
    project_root: Path, global_mode: bool = False
) -> ConnectResult:
    """Write/merge CodeMind into Claude Code's MCP config."""
    path = (
        _claude_code_global_config()
        if global_mode
        else _claude_code_project_config(project_root)
    )
    config = _read_json(path)
    updated, already = _merge_entry(config, project_root)
    created = not path.exists()
    try:
        _write_json(path, updated)
        return ConnectResult(
            tool=TOOL_CLAUDE_CODE,
            config_path=path,
            success=True,
            already_configured=already,
            created=created,
        )
    except OSError as exc:
        return ConnectResult(
            tool=TOOL_CLAUDE_CODE, config_path=path, success=False, error=str(exc)
        )


def connect_cursor(
    project_root: Path, global_mode: bool = False
) -> ConnectResult:
    """Write/merge CodeMind into Cursor's MCP config."""
    path = (
        _cursor_global_config()
        if global_mode
        else _cursor_project_config(project_root)
    )
    config = _read_json(path)
    updated, already = _merge_entry(config, project_root)
    created = not path.exists()
    try:
        _write_json(path, updated)
        return ConnectResult(
            tool=TOOL_CURSOR,
            config_path=path,
            success=True,
            already_configured=already,
            created=created,
        )
    except OSError as exc:
        return ConnectResult(
            tool=TOOL_CURSOR, config_path=path, success=False, error=str(exc)
        )


def connect_claude_desktop(project_root: Path) -> ConnectResult | None:
    """Write/merge CodeMind into Claude Desktop's config (global only)."""
    path = _claude_desktop_config()
    if path is None:
        return None
    config = _read_json(path)
    updated, already = _merge_entry(config, project_root)
    created = not path.exists()
    try:
        _write_json(path, updated)
        return ConnectResult(
            tool=TOOL_CLAUDE_DESKTOP,
            config_path=path,
            success=True,
            already_configured=already,
            created=created,
        )
    except OSError as exc:
        return ConnectResult(
            tool=TOOL_CLAUDE_DESKTOP, config_path=path, success=False, error=str(exc)
        )


# ── Main entry point ──────────────────────────────────────────────────────────

def connect_all(
    project_root: Path,
    global_mode: bool = False,
    tools: list[str] | None = None,
) -> list[ConnectResult]:
    """Register CodeMind with all detected (or specified) AI tools.

    Args:
        project_root: Absolute path to the project being connected.
        global_mode:  Write to global config (~/.claude/settings.json etc.)
                      instead of project-level config.
        tools:        Explicit list of TOOL_* ids to connect. If None,
                      auto-detects installed tools.

    Returns:
        One ConnectResult per tool attempted (empty if none found).
    """
    want = set(tools) if tools else set(detected_tools())
    results: list[ConnectResult] = []

    if TOOL_CLAUDE_CODE in want:
        results.append(connect_claude_code(project_root, global_mode))

    if TOOL_CURSOR in want:
        results.append(connect_cursor(project_root, global_mode))

    if TOOL_CLAUDE_DESKTOP in want:
        r = connect_claude_desktop(project_root)
        if r:
            results.append(r)

    return results
