"""MCP tool implementations — eleven precise structural queries.

Each function takes the in-memory CodeGraph and tool arguments, then
returns a plain string (markdown) for the AI to consume.

Tools
-----
get_connections(component)    — direct injection / call / inheritance neighbors
impact_analysis(component)    — BFS: everything that breaks if X changes
find_components(query)        — free-text search across names / packages / methods
find_for_task(description)    — relevant components + gaps for a stated task
get_pattern()                 — best existing full-stack domain as a copy-me template
record_decision(...)          — write a decision record into .codemind/decisions/
get_decisions(limit)          — read recent decision records for session context
trace_request(path)           — trace an HTTP path from frontend to backend (cross-layer)
enrich_node(component, notes) — store AI-discovered notes on a graph node
index_file(path)              — read any source file for you to analyse and index
add_component(name, …)        — persist a component extracted from index_file to the graph
"""

from __future__ import annotations

import re as _re
from pathlib import Path

from codemind.core.graph import CodeGraph
from codemind.graph import query as gq

# Source file extensions that may contain unindexed components
_SOURCE_EXTS: frozenset[str] = frozenset({
    ".dart", ".kt", ".kts", ".swift", ".go", ".rb", ".rs",
    ".cs", ".php", ".java", ".ts", ".tsx", ".py", ".js", ".jsx",
})

# Directories that never contain user source code
_SKIP_DIRS: frozenset[str] = frozenset({
    "node_modules", ".git", "build", "dist", ".dart_tool",
    "__pycache__", ".gradle", "target", ".idea", ".vscode",
    ".pub-cache", "vendor", "Pods",
})


def _find_unindexed_files(
    project_root: Path,
    query: str,
    graph: CodeGraph,
    max_results: int = 3,
) -> list[Path]:
    """Glob project for source files whose name matches *query* but aren't in the graph.

    Only files with meaningful (≥5-char) terms in the query are searched to
    avoid flooding results for generic queries like 'mobile' or 'service'.
    Files already tracked in the graph are skipped.
    """
    terms = [w.lower() for w in _re.split(r"\W+", query) if len(w) >= 5]
    if not terms:
        return []

    # Normalise: remove separators for fuzzy matching
    norm_terms = [t.replace("_", "").replace("-", "") for t in terms]

    # Files already indexed — skip them
    indexed_files: set[str] = {n.file for n in graph.nodes.values() if n.file}

    found: list[Path] = []
    try:
        for path in project_root.rglob("*"):
            if not path.is_file():
                continue
            # Skip hidden dirs and known noise dirs
            rel_parts = path.relative_to(project_root).parts
            if any(
                p.startswith(".") or p in _SKIP_DIRS
                for p in rel_parts[:-1]
            ):
                continue
            if path.suffix.lower() not in _SOURCE_EXTS:
                continue
            rel_str = "/".join(rel_parts)
            if rel_str in indexed_files:
                continue

            stem_norm = path.stem.lower().replace("_", "").replace("-", "")
            # All query terms must appear in the filename stem
            if all(t in stem_norm for t in norm_terms[:2]):
                found.append(path)
                if len(found) >= max_results:
                    break
    except (PermissionError, OSError):
        pass

    return found


def tool_get_connections(graph: CodeGraph, component: str) -> str:
    """Return all direct connections of *component*.

    Args:
        graph:     The live code graph.
        component: Simple class name or fully-qualified ID.

    Returns:
        Markdown listing injected deps, calls, inheritance, and dependents.
    """
    result = gq.get_connections(graph, component)
    if result is None:
        return (
            f"Component `{component}` not found in the graph.\n\n"
            "Run `codemind scan` to (re-)build the knowledge graph, "
            "or use `find_components` to search for the component."
        )
    return gq.format_connections(result)


def tool_impact_analysis(graph: CodeGraph, component: str) -> str:
    """Return the full impact of changing *component*.

    Args:
        graph:     The live code graph.
        component: Simple class name or fully-qualified ID.

    Returns:
        Markdown listing direct and indirect dependents, sorted by distance.
    """
    result = gq.impact_of(graph, component)
    if result is None:
        return (
            f"Component `{component}` not found in the graph.\n\n"
            "Run `codemind scan` first."
        )
    if not result.direct and not result.indirect:
        return (
            f"**`{result.node.name}`** has no known dependents in this project.\n\n"
            f"It is safe to change without cascading effects."
        )
    return gq.format_impact(result)


def tool_find_components(graph: CodeGraph, codemind_dir: Path, query: str) -> str:
    """Search for components matching *query* across names, packages, and methods.

    When no match is found in the graph, automatically searches the project
    filesystem for source files whose name matches the query.  If unindexed
    files are found, their content is returned with a mandatory instruction
    to call ``add_component`` for each discovered class/service/widget —
    so the graph is updated without the user needing to ask explicitly.

    Args:
        graph:        The live code graph.
        codemind_dir: The ``.codemind/`` directory (used for filesystem fallback).
        query:        Free-text description (e.g. "LoginScreen", "product service").

    Returns:
        Markdown list of matching components, or file content ready for indexing.
    """
    results = gq.find_components(graph, query)
    if results:
        return gq.format_found(results)

    # ── Filesystem fallback ────────────────────────────────────────────────────
    # Even if the graph is empty, search the project for matching source files
    # before giving up — this handles mobile/unsupported-language components.
    project_root = codemind_dir.parent
    unindexed = _find_unindexed_files(project_root, query, graph)

    if not unindexed:
        if not graph.nodes:
            return (
                "The knowledge graph is empty. "
                "Run `codemind scan` to build it first."
            )
        return (
            f"*No components matching `{query}` found in the graph.*\n\n"
            "If the component is in a file not yet parsed (e.g. Dart, Kotlin, Swift), "
            "use `index_file(path)` to read the file, then call `add_component` "
            "for each component you find."
        )

    # Read each unindexed file and return with mandatory indexing instruction
    from codemind.ai.enricher import AIEnricher
    enricher = AIEnricher()

    parts: list[str] = [
        f"*`{query}` not found in graph — found {len(unindexed)} unindexed "
        f"file(s) on disk.*\n\n"
        "**Before answering the user, call `add_component` for every class, "
        "service, widget, provider, or repository in the files below. "
        "Then use `get_connections` to answer the original question.**\n",
    ]

    for fp in unindexed:
        read_result = enricher.read_file_for_indexing(fp, project_root)
        if read_result.error:
            continue
        parts.append(
            f"\n---\n"
            f"### `{read_result.rel_path}` ({read_result.language})\n\n"
            f"```{read_result.language}\n{read_result.content}\n```\n\n"
            f"Use for `add_component`: "
            f"`file=\"{read_result.rel_path}\"`, "
            f"`language=\"{read_result.language}\"`"
        )

    return "\n".join(parts)


def tool_find_for_task(graph: CodeGraph, description: str) -> str:
    """Analyse a task and return relevant components + detected gaps.

    Use this when you're about to implement a feature and want to know:
    - What already exists that is relevant?
    - What is missing or disconnected?
    - Where should the new code plug in?

    Args:
        graph:       The live code graph.
        description: The task in plain English (e.g. "send email when KPI drops below threshold").

    Returns:
        Markdown with relevant components and gap analysis.
    """
    if not graph.nodes:
        return (
            "The knowledge graph is empty. "
            "Run `codemind scan` to build it first."
        )
    result = gq.find_for_task(graph, description)
    return gq.format_task_result(result)


def tool_record_decision(
    graph: CodeGraph,
    codemind_dir: Path,
    summary: str,
    components: list[str],
    reason: str,
    pattern_notes: str = "",
) -> str:
    """Write a decision record, enriching component names from the live graph.

    Args:
        graph:         The live code graph (used to resolve component metadata).
        codemind_dir:  The ``.codemind/`` directory for this project.
        summary:       One-line summary of the task completed.
        components:    Component names involved (simple or fully-qualified).
        reason:        Business reason for the decision.
        pattern_notes: Optional notes about the pattern followed.

    Returns:
        Confirmation message with the filename and component count.
    """
    from codemind.mcp.decisions import record_decision

    enriched = []
    for name in components:
        node = graph.resolve(name)
        if node:
            enriched.append(f"{node.name} ({node.type}) — {node.package}")
        else:
            enriched.append(f"{name} (new)")

    path = record_decision(codemind_dir, summary, enriched, reason, pattern_notes)
    return (
        f"Decision recorded: `{path.name}`\n\n"
        f"{len(enriched)} component(s) captured. "
        f"Future sessions will see this via `get_decisions`."
    )


def tool_get_decisions(codemind_dir: Path, limit: int = 5) -> str:
    """Return recent decision records as markdown.

    Args:
        codemind_dir: The ``.codemind/`` directory for this project.
        limit:        Maximum number of records to return (default 5).

    Returns:
        Markdown summary of recent decisions, or a prompt to start recording.
    """
    from codemind.mcp.decisions import get_decisions

    records = get_decisions(codemind_dir, limit)
    if not records:
        return "No decisions recorded yet. Use `record_decision` at the end of each task."
    parts = [f"## {len(records)} recent decision(s)\n"]
    for r in records:
        parts.append(f"### {r['file']}\n{r['content']}\n---\n")
    return "\n".join(parts)


def tool_trace_request(graph: CodeGraph, path: str) -> str:
    """Trace an HTTP request path from frontend to backend.

    Given an API path (e.g. ``/api/offers``), finds:
    - All frontend components calling that path
    - All backend controllers handling that path
    - The connection between them

    Args:
        graph: The live code graph.
        path:  HTTP path to trace, e.g. ``/api/offers`` or ``/api/offers/{id}``.

    Returns:
        Markdown showing the full frontend → backend trace.
    """
    from codemind.router.linker import _paths_match
    from codemind.router.route_extractor import _normalise

    if not graph.nodes:
        return "The knowledge graph is empty. Run `codemind scan` first."

    # Normalise user input: structural variables AND literal ID-like segments
    # e.g. /api/offers/123  →  /api/offers/{*}
    #      /api/users/abc-def-123  →  /api/users/{*}
    import re as _re
    _normalised = _normalise(path)
    query_path = _re.sub(
        r"/(?:[0-9]+|[0-9a-f]{8}-[0-9a-f-]{27}|[0-9a-f]{24,})(?=/|$)",
        "/{*}",
        _normalised,
    )

    # Find backend controllers whose routes match the path
    backend_matches: list[tuple[str, str]] = []  # (node_id, matched_route)
    for node in graph.nodes.values():
        routes = node.metadata.get("routes", []) if node.metadata else []
        for route in routes:
            if _paths_match(query_path, route):
                backend_matches.append((node.id, route))
                break

    # Find frontend components whose api_calls match the path
    frontend_matches: list[str] = []
    for node in graph.nodes.values():
        api_calls = node.metadata.get("api_calls", []) if node.metadata else []
        for call in api_calls:
            if _paths_match(query_path, call):
                frontend_matches.append(node.id)
                break

    if not backend_matches and not frontend_matches:
        return (
            f"No components found for path `{path}`.\n\n"
            "Ensure `codemind scan` has been run on a fullstack project. "
            "The graph needs both frontend and backend source files."
        )

    lines = [f"## Request trace: `{path}`\n"]

    if backend_matches:
        lines.append("### Backend (handles request)")
        for nid, route in backend_matches:
            node = graph.nodes.get(nid)
            if node:
                lines.append(f"- **`{node.name}`** ({node.type}) — route: `{route}`")
                lines.append(f"  - file: `{node.file}`")
                # Show what the controller injects
                deps = [e.target for e in graph.edges_from(nid) if e.kind in ("injects", "calls")]
                if deps:
                    lines.append(f"  - depends on: {', '.join(f'`{d}`' for d in deps[:5])}")
        lines.append("")

    if frontend_matches:
        lines.append("### Frontend (calls this endpoint)")
        for nid in frontend_matches:
            node = graph.nodes.get(nid)
            if node:
                lines.append(f"- **`{node.name}`** ({node.type}) — file: `{node.file}`")
        lines.append("")

    # EDGE_CROSS_LAYER edges between matched nodes
    cross_pairs = set()
    for edge in graph.edges:
        if edge.kind == "cross_layer":
            if edge.source in set(frontend_matches) and edge.target in {b[0] for b in backend_matches}:
                cross_pairs.add((edge.source, edge.target))
    if cross_pairs:
        lines.append("### Cross-layer connections")
        for src, tgt in sorted(cross_pairs):
            src_node = graph.nodes.get(src)
            tgt_node = graph.nodes.get(tgt)
            s = src_node.name if src_node else src
            t = tgt_node.name if tgt_node else tgt
            lines.append(f"- `{s}` (frontend) → `{t}` (backend)")

    return "\n".join(lines)


def tool_enrich_node(
    graph: CodeGraph,
    codemind_dir: Path,
    component: str,
    notes: str,
) -> str:
    """Store AI-discovered notes on a graph node and persist to graph.json.

    Use this when you discover something structural about a component that
    isn't captured in the graph — business rules, non-obvious dependencies,
    architectural intent. The notes survive across sessions.

    Args:
        graph:        The live code graph.
        codemind_dir: The ``.codemind/`` directory for this project.
        component:    Simple class name or fully-qualified ID.
        notes:        Free-text notes to attach to the node.

    Returns:
        Confirmation message, or an error if the component was not found.
    """
    node = graph.resolve(component)
    if node is None:
        return (
            f"Component `{component}` not found in the graph.\n\n"
            "Use `find_components` to search, then retry with the exact name."
        )
    if node.metadata is None:
        node.metadata = {}
    node.metadata["ai_notes"] = notes

    from codemind.graph.store import GraphStore
    GraphStore().save(graph, codemind_dir)

    return (
        f"✓ Notes saved for **`{node.name}`** (`{node.type}` — `{node.package}`).\n\n"
        "Available in future sessions via `get_connections`."
    )


def tool_index_file(graph: CodeGraph, codemind_dir: Path, path: str) -> str:
    """Read a source file and return its content for you to analyse and index.

    Call this when ``find_components`` returns no results for a file written
    in a language not natively parsed by CodeMind (Dart, Kotlin, Swift, Go,
    Ruby, Rust, C#, PHP, …).

    Workflow:
    1. Call ``index_file(path)`` — returns the file content.
    2. Analyse the returned code yourself: identify every class, service,
       provider, widget, or repository.
    3. Call ``add_component(name, type, file, language, ...)`` once per
       component to persist it to the graph permanently.

    No API key required — you are the AI doing the analysis.

    Args:
        graph:        The live code graph.
        codemind_dir: The ``.codemind/`` directory.
        path:         Absolute or project-relative path to the source file.

    Returns:
        File content with extraction instructions, or an error message.
    """
    from codemind.ai.enricher import AIEnricher, _EXT_TO_LANG

    file_path = Path(path)
    project_root = codemind_dir.parent
    if not file_path.exists():
        file_path = project_root / path

    if not file_path.exists():
        return f"File not found: `{path}`\n\nCheck the path and retry."

    enricher = AIEnricher()
    result = enricher.read_file_for_indexing(file_path, project_root)

    if result.error:
        return f"Error reading `{Path(path).name}`: {result.error}"

    return (
        f"## File: `{result.rel_path}` ({result.language})\n\n"
        f"```{result.language}\n{result.content}\n```\n\n"
        "---\n"
        "**Please analyse the code above and call `add_component` once for each "
        "class, service, provider, widget, or repository you find.**\n\n"
        "For each component use:\n"
        f"- `file`: `\"{result.rel_path}\"`\n"
        f"- `language`: `\"{result.language}\"`\n"
        "- `type`: one of `service`, `controller`, `repository`, `entity`, "
        "`component`, `widget`, `provider`, `class`\n"
        "- `methods`: list of public method names\n"
        "- `description`: one-line summary of what this component does"
    )


def tool_add_component(
    graph: CodeGraph,
    codemind_dir: Path,
    name: str,
    node_type: str,
    file: str,
    language: str,
    description: str = "",
    methods: list[str] | None = None,
) -> str:
    """Add a single component to the knowledge graph and persist it.

    Call this after analysing a file with ``index_file``. One call per
    component. The component will be available to ``find_components``,
    ``get_connections``, and ``impact_analysis`` in all future sessions.

    Args:
        graph:        The live code graph.
        codemind_dir: The ``.codemind/`` directory.
        name:         Class / service / widget name, e.g. ``ProductService``.
        node_type:    Component type: service | controller | repository |
                      entity | component | widget | provider | class.
        file:         Project-relative file path, e.g. ``lib/services/product_service.dart``.
        language:     Language name, e.g. ``dart``, ``kotlin``, ``swift``.
        description:  Optional one-line description of what this component does.
        methods:      Optional list of public method names.

    Returns:
        Confirmation message with the component's graph ID.
    """
    from codemind.ai.enricher import add_component_to_graph

    if not name.strip():
        return "Error: `name` must not be empty."
    if not file.strip():
        return "Error: `file` must not be empty."

    node = add_component_to_graph(
        graph, codemind_dir,
        name=name.strip(),
        node_type=node_type or "class",
        file=file.strip(),
        language=language or "unknown",
        description=description,
        methods=list(methods or []),
    )

    method_summary = f", {len(node.methods)} method(s)" if node.methods else ""
    return (
        f"✓ Added **`{node.name}`** ({node.type}{method_summary}) "
        f"to graph.\n"
        f"  - ID: `{node.id}`\n"
        f"  - File: `{node.file}`\n\n"
        "Use `get_connections` to explore its relationships."
    )


def tool_get_pattern(graph: CodeGraph) -> str:
    """Return the most complete existing domain as a copy-me module template.

    Use this when creating a new module to follow the project's established
    structure (service + controller + entity + repository).

    Args:
        graph: The live code graph.

    Returns:
        Markdown showing the best existing domain with its file / package layout.
    """
    pattern = gq.get_domain_pattern(graph)
    if pattern is None:
        return (
            "No complete domain pattern found yet. "
            "The graph may not have enough classes, "
            "or `codemind scan` has not been run."
        )
    return gq.format_pattern(pattern)
