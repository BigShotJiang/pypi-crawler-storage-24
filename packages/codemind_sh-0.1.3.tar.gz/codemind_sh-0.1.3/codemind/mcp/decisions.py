"""Core read/write logic for decision records.

Decision records live in ``.codemind/decisions/`` as dated markdown files.
They capture the *why* behind each task: which components were touched,
the business reason, and optional pattern notes.

These functions have no MCP dependency and can be unit-tested directly.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path

_DECISIONS_DIR = "decisions"


def record_decision(
    codemind_dir: Path,
    summary: str,
    components: list[str],
    reason: str,
    pattern_notes: str = "",
) -> Path:
    """Write a decision record to ``.codemind/decisions/``.

    Args:
        codemind_dir:  The ``.codemind/`` directory for this project.
        summary:       One-line summary of what was done (used as heading + filename slug).
        components:    Pre-enriched component strings, e.g.
                       ``"KpiAlertService (service) — com.app.kpi.alerts"``.
        reason:        Business reason / context for the decision.
        pattern_notes: Optional notes about the pattern followed (empty → section omitted).

    Returns:
        Path to the written decision file.
    """
    decisions_dir = codemind_dir / _DECISIONS_DIR
    decisions_dir.mkdir(exist_ok=True)

    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H%M")
    slug = re.sub(r"[^a-z0-9]+", "-", summary.lower())[:40].strip("-")
    filename = f"{date_str}-{time_str}-{slug}.md"

    comp_lines = (
        "\n".join(f"- {c}" for c in components) if components else "- (none specified)"
    )
    content = (
        f"# {summary}\n\n"
        f"**Date:** {now.strftime('%Y-%m-%d %H:%M UTC')}\n\n"
        f"## Summary\n{summary}\n\n"
        f"## Components\n{comp_lines}\n\n"
        f"## Why\n{reason}\n"
    )
    if pattern_notes:
        content += f"\n## Pattern notes\n{pattern_notes}\n"

    path = decisions_dir / filename
    tmp = path.with_suffix(".md.tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)  # atomic — same pattern as GraphStore
    return path


def get_decisions(codemind_dir: Path, limit: int = 5) -> list[dict[str, str]]:
    """Return the most recent decision records.

    Args:
        codemind_dir: The ``.codemind/`` directory for this project.
        limit:        Maximum number of records to return (most recent first).

    Returns:
        List of ``{"file": filename, "content": markdown_text}`` dicts,
        sorted descending by filename (ISO date prefix guarantees chronological order).
        Returns ``[]`` if the decisions directory does not exist or is empty.
    """
    decisions_dir = codemind_dir / _DECISIONS_DIR
    if not decisions_dir.exists():
        return []
    files = sorted(decisions_dir.glob("*.md"), reverse=True)[:limit]
    result = []
    for f in files:
        try:
            result.append({"file": f.name, "content": f.read_text(encoding="utf-8")})
        except OSError:
            pass
    return result
