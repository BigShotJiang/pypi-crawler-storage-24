"""MCP server — exposes eleven CodeMind tools over the MCP protocol.

The server is started by ``codemind serve`` (or ``codemind serve --watch``).
It communicates over stdio so any MCP-compatible host (Claude Code, Cursor,
etc.) can connect simply by pointing at the process.

Tools exposed
-------------
  get_connections   — direct injection / call / inheritance graph for a component
  impact_analysis   — everything that would break if a component changes
  find_components   — free-text search across the graph
  find_for_task     — relevant components + gaps for a stated engineering task
  get_pattern       — best existing full-stack domain as a copy-me template
  record_decision   — write a decision record into .codemind/decisions/
  get_decisions     — read recent decision records for session context
  trace_request     — trace HTTP path from frontend component to backend controller
  enrich_node       — store AI-discovered notes on a graph node
  index_file        — read any source file for you to analyse and index
  add_component     — persist a component extracted from index_file to the graph

The CodeGraph is loaded from graph.json on startup; if ``--watch`` is active,
the graph is kept current by the file watcher and the server always answers
with up-to-date structural facts.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from codemind.core.graph import CodeGraph
from codemind.graph.store import GraphStore
from codemind.mcp.tools import (
    tool_add_component,
    tool_enrich_node,
    tool_find_components,
    tool_find_for_task,
    tool_get_connections,
    tool_get_decisions,
    tool_get_pattern,
    tool_impact_analysis,
    tool_index_file,
    tool_record_decision,
    tool_trace_request,
)

logger = logging.getLogger(__name__)

# ── Tool schemas ───────────────────────────────────────────────────────────────

_TOOLS: list[Tool] = [
    Tool(
        name="get_connections",
        description=(
            "Return all direct connections of a component: what it injects, what it calls, "
            "what it extends/implements, which components depend on it, and — for fullstack "
            "projects — which frontend services call it or which backend controllers it connects to "
            "(cross-layer edges). "
            "Use this to understand how a class fits into the system before modifying it, "
            "or to answer 'what frontend components call OfferController?'"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "component": {
                    "type": "string",
                    "description": (
                        "Simple class name (e.g. 'KpiCalculationService') "
                        "or fully-qualified ID (e.g. 'com.app.kpi.business.kpicalculation.KpiCalculationService')."
                    ),
                },
            },
            "required": ["component"],
        },
    ),
    Tool(
        name="impact_analysis",
        description=(
            "Show everything that would be affected if a component changes. "
            "Returns direct dependents (distance 1) and indirect dependents (distance 2+). "
            "Run this before refactoring to understand blast radius."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "component": {
                    "type": "string",
                    "description": "Simple class name or fully-qualified ID.",
                },
            },
            "required": ["component"],
        },
    ),
    Tool(
        name="find_components",
        description=(
            "Search for components by name, package, method names, or type. "
            "Use this to discover what already exists before writing new code. "
            "When a component is not in the graph, automatically searches the project "
            "filesystem for matching source files and returns their content — "
            "you must then call add_component for each discovered class/service/widget "
            "before answering the user."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": (
                        "Free-text search string, e.g. 'threshold evaluation', "
                        "'kpi calculation', 'email notification'."
                    ),
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="find_for_task",
        description=(
            "Given a task description, find all relevant existing components and "
            "identify gaps (missing implementations, disconnected services). "
            "Use this at the start of any new feature to understand what already exists "
            "and where to plug the new code in."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "description": {
                    "type": "string",
                    "description": (
                        "Plain-English task description, e.g. "
                        "'send email notification when KPI drops below threshold'."
                    ),
                },
            },
            "required": ["description"],
        },
    ),
    Tool(
        name="get_pattern",
        description=(
            "Return the most complete existing module in the project "
            "(service + controller + entity + repository) as a copy-me template. "
            "Use this when creating a new module to follow the project's structure."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="record_decision",
        description=(
            "Record a decision at the end of a task: what was built, which components "
            "were created or modified, and the business reason. "
            "Call this after every completed task so future sessions have context."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": "One-line summary of the task completed, e.g. 'Add email alert on KPI drop'.",
                },
                "components": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Names of components created or modified, "
                        "e.g. ['KpiAlertService', 'ThresholdEvaluator']. "
                        "Simple class names are fine; the tool resolves metadata from the graph."
                    ),
                },
                "reason": {
                    "type": "string",
                    "description": "Business reason or context, e.g. 'Requirement: notify faculty head when KPI falls below 70%'.",
                },
                "pattern_notes": {
                    "type": "string",
                    "description": "Optional notes about the pattern followed (e.g. which existing module was used as a template).",
                },
            },
            "required": ["summary", "components", "reason"],
        },
    ),
    Tool(
        name="get_decisions",
        description=(
            "Return recent decision records from .codemind/decisions/. "
            "Call this at the start of any task that touches existing features "
            "to see what was already built and why."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of recent decisions to return (default 5).",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="trace_request",
        description=(
            "Trace an HTTP API path across the fullstack: find which frontend component "
            "calls the endpoint, and which backend controller handles it. "
            "Use this to understand the full request flow for any API route, "
            "e.g. '/api/offers' or '/api/users/{id}'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": (
                        "HTTP API path to trace, e.g. '/api/offers', '/api/users/{id}'. "
                        "Leading slash is required."
                    ),
                },
            },
            "required": ["path"],
        },
    ),
    Tool(
        name="enrich_node",
        description=(
            "Store AI-discovered notes on a graph node so they persist across sessions. "
            "Use this when you discover something structural about a component that the "
            "graph doesn't capture: business rules, non-obvious dependencies, architectural intent. "
            "The notes are saved to graph.json and shown by get_connections in future sessions. "
            "Call this whenever you learn something important about a component."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "component": {
                    "type": "string",
                    "description": (
                        "Simple class name (e.g. 'KpiCalculationService') "
                        "or fully-qualified ID."
                    ),
                },
                "notes": {
                    "type": "string",
                    "description": (
                        "Free-text notes about this component, e.g. "
                        "'Implements threshold comparison using a configurable tolerance. "
                        "Always called before AlertService in the evaluation pipeline.'"
                    ),
                },
            },
            "required": ["component", "notes"],
        },
    ),
    Tool(
        name="index_file",
        description=(
            "Read a source file and return its content so you can analyse and index it. "
            "Use this when find_components returns no results for a file in a language "
            "not natively parsed by CodeMind (Dart, Kotlin, Swift, Go, Ruby, Rust, C#, PHP). "
            "Workflow: (1) call index_file(path) to get the file content, "
            "(2) analyse the code yourself, "
            "(3) call add_component once per class/service/widget/provider found. "
            "No API key required."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": (
                        "Absolute or project-relative path to the source file, "
                        "e.g. 'lib/services/product_service.dart'."
                    ),
                },
            },
            "required": ["path"],
        },
    ),
    Tool(
        name="add_component",
        description=(
            "Add a single component to the knowledge graph and persist it permanently. "
            "Call this after index_file — once per class, service, provider, widget, or "
            "repository you identify in the file. "
            "The component will be available to find_components, get_connections, and "
            "impact_analysis in all future sessions."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Class or service name, e.g. 'ProductService'.",
                },
                "node_type": {
                    "type": "string",
                    "description": (
                        "Component type: service | controller | repository | entity | "
                        "component | widget | provider | class."
                    ),
                },
                "file": {
                    "type": "string",
                    "description": (
                        "Project-relative file path, "
                        "e.g. 'lib/services/product_service.dart'."
                    ),
                },
                "language": {
                    "type": "string",
                    "description": "Language name, e.g. 'dart', 'kotlin', 'swift'.",
                },
                "description": {
                    "type": "string",
                    "description": "Optional one-line description of what this component does.",
                },
                "methods": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional list of public method names.",
                },
            },
            "required": ["name", "node_type", "file", "language"],
        },
    ),
]


# ── Server ─────────────────────────────────────────────────────────────────────


def create_server(graph: CodeGraph, codemind_dir: Path) -> Server:
    """Build and configure the MCP server with the given graph.

    Both *graph* and *codemind_dir* are captured by closure. The file watcher
    mutates *graph* in-place, so the server always reads current data.

    Args:
        graph:        The live code graph (mutated in-place by the file watcher).
        codemind_dir: The ``.codemind/`` directory (for decision record I/O).
    """
    server = Server("codemind")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return _TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        try:
            if name == "get_connections":
                text = tool_get_connections(graph, arguments.get("component", ""))
            elif name == "impact_analysis":
                text = tool_impact_analysis(graph, arguments.get("component", ""))
            elif name == "find_components":
                text = tool_find_components(graph, codemind_dir, arguments.get("query", ""))
            elif name == "find_for_task":
                text = tool_find_for_task(graph, arguments.get("description", ""))
            elif name == "get_pattern":
                text = tool_get_pattern(graph)
            elif name == "record_decision":
                text = tool_record_decision(
                    graph,
                    codemind_dir,
                    arguments.get("summary", ""),
                    arguments.get("components", []),
                    arguments.get("reason", ""),
                    arguments.get("pattern_notes", ""),
                )
            elif name == "get_decisions":
                text = tool_get_decisions(codemind_dir, arguments.get("limit", 5))
            elif name == "trace_request":
                text = tool_trace_request(graph, arguments.get("path", ""))
            elif name == "enrich_node":
                text = tool_enrich_node(
                    graph,
                    codemind_dir,
                    arguments.get("component", ""),
                    arguments.get("notes", ""),
                )
            elif name == "index_file":
                text = tool_index_file(graph, codemind_dir, arguments.get("path", ""))
            elif name == "add_component":
                text = tool_add_component(
                    graph,
                    codemind_dir,
                    name=arguments.get("name", ""),
                    node_type=arguments.get("node_type", "class"),
                    file=arguments.get("file", ""),
                    language=arguments.get("language", "unknown"),
                    description=arguments.get("description", ""),
                    methods=arguments.get("methods", []),
                )
            else:
                text = f"Unknown tool: `{name}`"
        except Exception as exc:
            logger.exception("Tool %s failed: %s", name, exc)
            text = f"Tool `{name}` encountered an error: {exc}"

        return [TextContent(type="text", text=text)]

    return server


async def run_server(codemind_dir: Path, watch: bool = True) -> None:
    """Load the graph and run the MCP server over stdio.

    Args:
        codemind_dir: The ``.codemind/`` directory.
        watch:        If True, start a file watcher to keep the graph current.
    """
    store = GraphStore()
    graph = store.load(codemind_dir)

    if graph is None:
        # Start with an empty graph so the server still launches
        logger.warning(
            "graph.json not found in %s — run 'codemind scan' first.", codemind_dir
        )
        from codemind.core.graph import CodeGraph
        graph = CodeGraph.empty("unknown")

    watcher = None
    if watch:
        project_root = codemind_dir.parent
        from codemind.watcher.handler import CodeMindWatcher
        watcher = CodeMindWatcher(graph, project_root, codemind_dir)
        watcher.start()

    server = create_server(graph, codemind_dir)

    try:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )
    finally:
        if watcher:
            watcher.stop()
