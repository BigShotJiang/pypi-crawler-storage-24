"""CodeMind license system — Hotel Key model."""
