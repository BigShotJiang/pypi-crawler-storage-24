"""License state model and manager for ~/.codemind/license.yml."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import yaml

# ── Paths ─────────────────────────────────────────────────────────────────────

LICENSE_DIR = Path.home() / ".codemind"
LICENSE_FILE = LICENSE_DIR / "license.yml"

# ── Tier constants ─────────────────────────────────────────────────────────────

TIER_FREE = "free"
TIER_TRIAL = "trial"        # legacy — old installs may have this; treated as free
TIER_PRO = "pro"
TIER_TEAM = "team"
TIER_ENTERPRISE = "enterprise"

# ── Feature constants ──────────────────────────────────────────────────────────

FEATURE_AI_ENRICHMENT = "ai_enrichment"           # Pro: we pay
FEATURE_AI_ENRICHMENT_BYOK = "ai_enrichment_byok" # Free: user pays own key
FEATURE_STACK_DISCOVERY = "stack_discovery"
FEATURE_STACK_DISCOVERY_BYOK = "stack_discovery_byok"
FEATURE_UNLIMITED_PROJECTS = "unlimited_projects"
FEATURE_TEAM_DASHBOARD = "team_dashboard"
FEATURE_PRO_REVIEW = "pro_review"
FEATURE_PRO_BRIEF = "pro_brief"
FEATURE_PRO_IMPACT = "pro_impact"

FREE_FEATURES: list[str] = [FEATURE_AI_ENRICHMENT_BYOK, FEATURE_STACK_DISCOVERY_BYOK]
PRO_FEATURES: list[str] = [
    FEATURE_AI_ENRICHMENT,
    FEATURE_STACK_DISCOVERY,
    FEATURE_UNLIMITED_PROJECTS,
    FEATURE_PRO_REVIEW,
    FEATURE_PRO_BRIEF,
    FEATURE_PRO_IMPACT,
]
TEAM_FEATURES: list[str] = PRO_FEATURES + [FEATURE_TEAM_DASHBOARD]

# Legacy alias so old code referencing TRIAL_FEATURES still works
TRIAL_FEATURES = FREE_FEATURES

FREE_PROJECT_LIMIT = 1
EXPIRY_WARNING_DAYS = 5   # warn when <= 5 days left (paid tiers with expiry)
OFFLINE_GRACE_DAYS = 7    # days without server check before AI features warn


@dataclass
class LicenseState:
    """In-memory representation of ~/.codemind/license.yml.

    The *features* list is server-controlled: to add a feature to a tier,
    push a server-side change — zero CLI update needed.
    """

    license_key: str = ""
    tier: str = TIER_TRIAL
    expires_at: date | None = None
    features: list[str] = field(default_factory=list)
    project_limit: int | None = FREE_PROJECT_LIMIT
    grace_days: int = OFFLINE_GRACE_DAYS
    validated_at: date | None = None
    activated_projects: list[str] = field(default_factory=list)
    email: str = ""  # optional — for license recovery if user reinstalls

    # ── Derived properties ────────────────────────────────────────────────────

    @property
    def is_free(self) -> bool:
        """True for permanent free tier (and legacy 'trial' tier)."""
        return self.tier in (TIER_FREE, TIER_TRIAL)

    @property
    def is_paid(self) -> bool:
        return self.tier in (TIER_PRO, TIER_TEAM, TIER_ENTERPRISE)

    @property
    def is_expired(self) -> bool:
        """Only paid tiers with a set expires_at can expire. Free is permanent."""
        if self.is_free:
            return False   # free tier never expires
        if self.expires_at is None:
            return False
        return date.today() > self.expires_at

    @property
    def days_until_expiry(self) -> int | None:
        """Days until expiry; None if perpetual; negative if already expired."""
        if self.expires_at is None:
            return None
        return (self.expires_at - date.today()).days

    @property
    def in_warning_window(self) -> bool:
        """True when <= EXPIRY_WARNING_DAYS days remain (and not yet expired)."""
        days = self.days_until_expiry
        if days is None:
            return False
        return 0 < days <= EXPIRY_WARNING_DAYS

    @property
    def offline_too_long(self) -> bool:
        """True if last server validation is older than grace_days."""
        if self.validated_at is None:
            return False
        age = (date.today() - self.validated_at).days
        return age > self.grace_days

    def is_class_a(self, project_id: str) -> bool:
        """Project was activated while license was valid — works offline forever."""
        return bool(project_id) and project_id in self.activated_projects

    def has_feature(self, feature: str) -> bool:
        """True if feature is unlocked AND license is not expired."""
        return not self.is_expired and feature in self.features

    @property
    def active_project_count(self) -> int:
        return len(self.activated_projects)

    def within_project_limit(self) -> bool:
        if self.project_limit is None:
            return True
        return self.active_project_count < self.project_limit


class LicenseManager:
    """Read/write ~/.codemind/license.yml atomically."""

    def __init__(self, license_file: Path = LICENSE_FILE) -> None:
        self._path = license_file

    def exists(self) -> bool:
        return self._path.exists()

    def load(self) -> LicenseState:
        """Load license state. Returns empty (no key) if file missing or corrupt."""
        if not self._path.exists():
            return LicenseState()
        try:
            raw = yaml.safe_load(self._path.read_text(encoding="utf-8")) or {}
            return self._from_dict(raw)
        except Exception:
            return LicenseState()

    def save(self, state: LicenseState) -> None:
        """Atomically write license state to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".yml.tmp")
        tmp.write_text(
            yaml.dump(self._to_dict(state), default_flow_style=False,
                      allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
        tmp.replace(self._path)

    def add_activated_project(self, project_id: str) -> None:
        """Register project_id as Class A (idempotent)."""
        if not project_id:
            return
        state = self.load()
        if project_id not in state.activated_projects:
            state.activated_projects.append(project_id)
            self.save(state)

    # ── Private ───────────────────────────────────────────────────────────────

    def _from_dict(self, data: dict[str, Any]) -> LicenseState:
        expires_raw = data.get("expires_at")
        validated_raw = data.get("validated_at")
        return LicenseState(
            license_key=data.get("license_key", ""),
            tier=data.get("tier", TIER_TRIAL),
            expires_at=date.fromisoformat(str(expires_raw)) if expires_raw else None,
            features=list(data.get("features") or []),
            project_limit=data.get("project_limit", FREE_PROJECT_LIMIT),
            grace_days=int(data.get("grace_days", OFFLINE_GRACE_DAYS)),
            validated_at=date.fromisoformat(str(validated_raw)) if validated_raw else None,
            activated_projects=list(data.get("activated_projects") or []),
            email=data.get("email", ""),
        )

    def _to_dict(self, state: LicenseState) -> dict[str, Any]:
        return {
            "license_key": state.license_key,
            "tier": state.tier,
            "expires_at": state.expires_at.isoformat() if state.expires_at else None,
            "features": state.features,
            "project_limit": state.project_limit,
            "grace_days": state.grace_days,
            "validated_at": state.validated_at.isoformat() if state.validated_at else None,
            "activated_projects": state.activated_projects,
            "email": state.email,
        }
