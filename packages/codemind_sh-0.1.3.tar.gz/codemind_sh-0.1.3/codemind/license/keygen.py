"""HMAC-signed license key generation and offline verification.

Key format: ``CM-XXXX-XXXX-XXXX-HHHH``
  - ``CM-``          static prefix
  - ``XXXX-XXXX-XXXX`` 12 random alphanumeric chars (uppercase)
  - ``HHHH``         4-char HMAC-SHA256 checksum of the 12-char payload

The same secret must be set on the license server via the
``CODEMIND_LICENSE_SECRET`` environment variable.  In development the
fallback secret is used so keys generated locally will validate locally —
server keys use the real secret and so have a different checksum.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import string

_ALPHABET = string.ascii_uppercase + string.digits
_SECRET_ENV = "CODEMIND_LICENSE_SECRET"
_FALLBACK_SECRET = "codemind-dev-secret-2026-onix"  # only for offline dev trials


def _secret() -> bytes:
    return os.environ.get(_SECRET_ENV, _FALLBACK_SECRET).encode()


def generate_trial_key() -> str:
    """Generate a locally-signed trial key (offline fallback).

    Returns a key of the form ``CM-XXXX-XXXX-XXXX-HHHH``.
    This key validates offline with :func:`is_valid_key` but the server
    will not find it in its database until a successful online activation.
    """
    parts = ["".join(secrets.choice(_ALPHABET) for _ in range(4)) for _ in range(3)]
    payload = "-".join(parts)
    checksum = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()[:4].upper()
    return f"CM-{payload}-{checksum}"


def is_valid_key(key: str) -> bool:
    """Verify the HMAC checksum of a license key (offline, O(1))."""
    if not isinstance(key, str) or not key.startswith("CM-"):
        return False
    inner = key[3:]   # strip "CM-"
    parts = inner.split("-")
    if len(parts) != 4:
        return False
    payload = "-".join(parts[:3])
    expected = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()[:4].upper()
    return hmac.compare_digest(parts[3], expected)


def key_payload(key: str) -> str:
    """Return the random payload portion (first 12 chars, no prefix or checksum)."""
    if not key.startswith("CM-"):
        return ""
    parts = key[3:].split("-")
    return "".join(parts[:3])
