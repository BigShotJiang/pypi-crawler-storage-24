"""License server HTTP client — graceful offline fallback.

All network calls are wrapped so that any failure (no internet, server
down, timeout) silently falls back to local behaviour.  The CLI must
never crash or block because of a license-server outage.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from datetime import date
from typing import Any

from codemind.license.keygen import generate_trial_key
from codemind.license.license import (
    LICENSE_FILE,
    LicenseManager,
    LicenseState,
    TIER_FREE,
    FREE_FEATURES,
    FREE_PROJECT_LIMIT,
    OFFLINE_GRACE_DAYS,
)

_TIMEOUT = 5   # seconds — fast enough for CLI startup, long enough to work on slow VPS

_DEFAULT_SERVER = "https://codemind.sh"


def _server_url() -> str:
    return os.environ.get("CODEMIND_LICENSE_SERVER", _DEFAULT_SERVER).rstrip("/")


def _post(path: str, payload: dict[str, Any]) -> dict[str, Any] | None:
    """POST JSON to the license server. Returns parsed JSON or None on any error."""
    url = f"{_server_url()}{path}"
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", "User-Agent": "codemind-cli/0.1"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, OSError, json.JSONDecodeError, TimeoutError):
        return None


def _get(path: str) -> dict[str, Any] | None:
    url = f"{_server_url()}{path}"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "codemind-cli/0.1"},
    )
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, OSError, json.JSONDecodeError, TimeoutError):
        return None


def _parse_state(data: dict[str, Any]) -> LicenseState:
    return LicenseManager()._from_dict(data)  # type: ignore[attr-defined]


def _local_free() -> LicenseState:
    """Create an offline free-tier key when the license server is unreachable.

    Permanent free — 1 project, no expiry. The server will register it
    properly when connectivity is restored.
    """
    key = generate_trial_key()
    return LicenseState(
        license_key=key,
        tier=TIER_FREE,
        expires_at=None,            # permanent — no expiry
        features=list(FREE_FEATURES),
        project_limit=FREE_PROJECT_LIMIT,
        grace_days=OFFLINE_GRACE_DAYS,
        validated_at=date.today(),
        activated_projects=[],
    )


class LicenseClient:
    """Talk to the license server. All methods fall back gracefully offline."""

    def generate_trial(self) -> LicenseState:
        """Request a permanent free-tier license from the server; local fallback if offline."""
        result = _post("/api/licenses/trial", {})
        if result:
            try:
                return _parse_state(result)
            except Exception:
                pass
        return _local_free()

    def validate(self, license_key: str, project_id: str) -> LicenseState | None:
        """Validate key + register project activation on server.

        Returns updated LicenseState (possibly with project_id added to
        activated_projects) or None if the server is unreachable.
        """
        result = _post(
            "/api/licenses/validate",
            {"license_key": license_key, "project_id": project_id},
        )
        if result:
            try:
                return _parse_state(result)
            except Exception:
                pass
        return None

    def register_email(self, license_key: str, email: str) -> bool:
        """Associate an email with a license key for recovery purposes.

        Silently returns False if the server is unreachable — the caller
        should store the email locally regardless.
        """
        result = _post(
            "/api/licenses/register-email",
            {"license_key": license_key, "email": email},
        )
        return result is not None

    def refresh(self, license_key: str) -> LicenseState | None:
        """Pull latest tier/features/expiry from server. None if offline."""
        result = _get(f"/api/licenses/{license_key}/status")
        if result:
            try:
                return _parse_state(result)
            except Exception:
                pass
        return None
