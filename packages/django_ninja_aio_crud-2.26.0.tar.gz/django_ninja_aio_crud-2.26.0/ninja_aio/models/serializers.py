from typing import (
    Annotated,
    Any,
    Generic,
    List,
    Literal,
    Optional,
    TypeVar,
    Union,
    get_args,
    get_origin,
    ForwardRef,
)
import types
import warnings
import sys
import threading
from functools import lru_cache
from asgiref.sync import sync_to_async

from django.conf import settings
from ninja import Schema
from ninja.orm import create_schema
from django.db import models
from django.http import HttpRequest
from django.db.models.fields.related_descriptors import (
    ReverseManyToOneDescriptor,
    ReverseOneToOneDescriptor,
    ManyToManyDescriptor,
    ForwardManyToOneDescriptor,
    ForwardOneToOneDescriptor,
)
from pydantic import BeforeValidator, Field
from pydantic._internal._decorators import PydanticDescriptorProxy

from ninja_aio.types import (
    S_TYPES,
    F_TYPES,
    SCHEMA_TYPES,
    ModelSerializerMeta,
    SerializerMeta,
    get_ninja_aio_meta_attr,
)
from ninja_aio.schemas.helpers import (
    ModelQuerySetSchema,
    ModelQuerySetExtraSchema,
)

# TypeVar for generic model typing in Serializers
ModelT = TypeVar("ModelT", bound=models.Model)


def _extract_pk(v: Any) -> Any:
    """Extract primary key from a model instance or return value as-is."""
    if hasattr(v, "pk"):
        return v.pk
    return v


class PkFromModel:
    """Subscriptable type for extracting PK from model instances during serialization.

    Usage:
        PkFromModel[int]   -> for integer PKs
        PkFromModel[str]   -> for string PKs
        PkFromModel[UUID]  -> for UUID PKs
        PkFromModel        -> defaults to int (backwards compatible)
    """

    _default = Annotated[int, BeforeValidator(_extract_pk)]

    def __class_getitem__(cls, pk_type: type) -> type:
        return Annotated[pk_type, BeforeValidator(_extract_pk)]

    def __new__(cls):
        return cls._default


class BaseSerializer:
    """
    BaseSerializer
    --------------
    Shared serializer utilities used by both ModelSerializer (model-bound) and
    Serializer (Meta-driven). Centralizes common field normalization, relation
    schema construction and schema generation helpers.

    Subclasses must implement:
    - _get_fields(s_type, f_type): source raw config for fields/optionals/customs/excludes
    - _get_model(): return the Django model class associated with the serializer
    - _get_relations_serializers(): optional mapping of relation field -> serializer (may be empty)
    """

    class QuerySet:
        """
        Configuration container describing how to build query schemas for a model.
        Purpose
        -------
        Describes which fields and extras are available when querying for model
        instances. A factory/metaclass can read this configuration to generate
        Pydantic / Ninja query schemas.
        Attributes
        ----------
        read : ModelQuerySetSchema
            Schema configuration for read operations.
        queryset_request : ModelQuerySetSchema
            Schema configuration for queryset_request hook.
        extras : list[ModelQuerySetExtraSchema]
            Additional computed / synthetic query parameters.
        """

        read = ModelQuerySetSchema()
        detail = ModelQuerySetSchema()
        queryset_request = ModelQuerySetSchema()
        extras: list[ModelQuerySetExtraSchema] = []

    # Thread-local storage for tracking circular reference resolution
    _resolution_context = threading.local()

    @classmethod
    def _get_resolution_stack(cls) -> list[str]:
        """
        Get the current resolution stack for detecting circular references.

        Returns
        -------
        list[str]
            Stack of model names currently being resolved (thread-safe).
        """
        if not hasattr(cls._resolution_context, "stack"):
            cls._resolution_context.stack = []
        return cls._resolution_context.stack

    @classmethod
    def _is_circular_reference(cls, model: models.Model) -> bool:
        """
        Check if resolving this model would create a circular reference.

        Security: Prevents infinite recursion and stack overflow attacks.

        Parameters
        ----------
        model : models.Model
            The model to check

        Returns
        -------
        bool
            True if the model is already being resolved (circular reference detected)
        """
        model_key = f"{model._meta.app_label}.{model._meta.model_name}"
        return model_key in cls._get_resolution_stack()

    @classmethod
    def _push_resolution(cls, model: models.Model) -> None:
        """Add a model to the resolution stack."""
        model_key = f"{model._meta.app_label}.{model._meta.model_name}"
        cls._get_resolution_stack().append(model_key)

    @classmethod
    def _pop_resolution(cls) -> None:
        """Remove the most recent model from the resolution stack."""
        stack = cls._get_resolution_stack()
        if stack:
            stack.pop()

    # Attributes on inner classes that are configuration, not schema overrides
    _CONFIG_ATTRS = frozenset(
        {
            "fields",
            "customs",
            "optionals",
            "excludes",
            "relations_as_id",
            "model_config",
        }
    )

    @classmethod
    def _collect_schema_overrides(cls, source_class) -> dict:
        """
        Collect callable schema method overrides from a class.

        Scans the class for regular methods (not validators, not config attrs,
        not dunder) that should be injected into the generated schema subclass.

        Parameters
        ----------
        source_class : type | None
            The class to scan for method overrides.

        Returns
        -------
        dict
            Mapping of method name to callable.
        """
        overrides = {}
        if source_class is None:
            return overrides
        for attr_name, attr_value in vars(source_class).items():
            if attr_name.startswith("_"):
                continue
            if attr_name in cls._CONFIG_ATTRS:
                continue
            if isinstance(attr_value, PydanticDescriptorProxy):
                continue
            if callable(attr_value) or isinstance(
                attr_value, (classmethod, staticmethod)
            ):
                overrides[attr_name] = attr_value
        return overrides

    @classmethod
    def _collect_validators(cls, source_class) -> dict:
        """
        Collect Pydantic validator descriptors from a class.

        Iterates over the class attributes looking for ``PydanticDescriptorProxy``
        instances (created by ``@field_validator`` and ``@model_validator`` decorators).

        Parameters
        ----------
        source_class : type | None
            The class to scan for validators.

        Returns
        -------
        dict
            Mapping of attribute name to ``PydanticDescriptorProxy`` instance.
        """
        validators = {}
        if source_class is None:
            return validators
        for attr_name, attr_value in vars(source_class).items():
            if isinstance(attr_value, PydanticDescriptorProxy):
                validators[attr_name] = attr_value
        return validators

    @classmethod
    def _apply_validators(
        cls,
        schema,
        validators: dict,
        model_config: dict = None,
        schema_overrides: dict = None,
    ):
        """
        Create a subclass of the given schema with validators, model_config,
        and schema method overrides attached.

        Pydantic discovers validators via ``PydanticDescriptorProxy`` instances
        during class creation, so placing them on a subclass is sufficient.
        ``model_config`` (a ``ConfigDict``) is also applied as a class attribute
        when provided. Schema overrides are regular methods injected into the
        subclass namespace with ``__class__`` cell rebinding for bare ``super()``.

        Parameters
        ----------
        schema : Schema | None
            The base schema class generated by ``create_schema``.
        validators : dict
            Mapping of validator names to ``PydanticDescriptorProxy`` instances.
        model_config : dict, optional
            A Pydantic ``ConfigDict`` to apply to the generated schema.
        schema_overrides : dict, optional
            Mapping of method names to callables to inject as overrides.

        Returns
        -------
        Schema | None
            A subclass with validators, model_config, and/or overrides applied,
            or the original schema if nothing needs to be applied.
        """
        if not schema:
            return schema
        namespace = dict(validators) if validators else {}
        if model_config:
            namespace["model_config"] = model_config
        if schema_overrides:
            namespace.update(schema_overrides)
        if not namespace:
            return schema
        subclass = type(schema.__name__, (schema,), namespace)
        # Rebind __class__ cell in overrides so bare super() resolves correctly
        if schema_overrides:
            for attr_name, attr_value in schema_overrides.items():
                if not isinstance(attr_value, types.FunctionType):
                    continue
                freevars = attr_value.__code__.co_freevars
                if "__class__" not in freevars:
                    continue
                idx = freevars.index("__class__")
                old_closure = attr_value.__closure__ or ()
                new_cells = list(old_closure)
                new_cells[idx] = types.CellType(subclass)
                rebound = types.FunctionType(
                    attr_value.__code__,
                    attr_value.__globals__,
                    attr_value.__name__,
                    attr_value.__defaults__,
                    tuple(new_cells),
                )
                rebound.__kwdefaults__ = attr_value.__kwdefaults__
                setattr(subclass, attr_name, rebound)
        return subclass

    @classmethod
    def _get_validators(cls, schema_type: type[SCHEMA_TYPES]) -> dict:
        """
        Return collected validators for the given schema type.

        Subclasses must implement this to map schema types to the appropriate
        validator source class.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict
            Mapping of validator names to ``PydanticDescriptorProxy`` instances.
        """
        return {}

    @classmethod
    def _get_model_config(cls, schema_type: type[SCHEMA_TYPES]) -> dict | None:
        """
        Return Pydantic ``ConfigDict`` for the given schema type.

        Subclasses may override this to source ``model_config`` from their
        configuration classes.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict | None
            A ``ConfigDict`` instance, or ``None`` if not configured.
        """
        return None

    @classmethod
    def _get_schema_overrides(cls, schema_type: type[SCHEMA_TYPES]) -> dict:
        """
        Return collected schema method overrides for the given schema type.

        Subclasses must implement this to map schema types to the appropriate
        source class for method overrides.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict
            Mapping of method names to callables.
        """
        return {}

    @classmethod
    def _get_fields(cls, s_type: type[S_TYPES], f_type: type[F_TYPES]):
        """
        Return raw configuration list for the given serializer/field category.

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type (``"create"`` | ``"update"`` | ``"read"`` | ``"detail"``).
        f_type : F_TYPES
            Field category (``"fields"`` | ``"optionals"`` | ``"customs"`` | ``"excludes"``).

        Returns
        -------
        list
            Raw configuration list for the requested category.

        Raises
        ------
        NotImplementedError
            Subclasses must provide an implementation.
        """
        raise NotImplementedError

    @classmethod
    def _get_model(cls) -> models.Model:
        """
        Return the Django model class associated with this serializer.

        Returns
        -------
        models.Model
            The Django model class.

        Raises
        ------
        NotImplementedError
            Subclasses must provide an implementation.
        """
        raise NotImplementedError

    @classmethod
    def _resolve_string_reference(cls, string_ref: str) -> type:
        """
        Resolve a string serializer reference to an actual class.

        Parameters
        ----------
        string_ref : str
            String reference (local class name or absolute import path).

        Returns
        -------
        type
            The resolved serializer class.

        Raises
        ------
        ValueError
            If the string reference cannot be resolved.
        """
        # Check if it's an absolute import path (contains dots)
        if "." in string_ref:
            # Absolute import path: "myapp.serializers.UserSerializer"
            module_path, class_name = string_ref.rsplit(".", 1)

            try:
                # Try to get or import the module
                module = sys.modules.get(module_path)
                if module is None:
                    import importlib

                    module = importlib.import_module(module_path)

                # Get the serializer class from the module
                serializer_class = getattr(module, class_name, None)

                if serializer_class is None:
                    raise ValueError(
                        f"Cannot resolve serializer reference '{string_ref}': "
                        f"class '{class_name}' not found in module '{module_path}'."
                    )

                return serializer_class
            except ImportError as e:
                raise ValueError(
                    f"Cannot resolve serializer reference '{string_ref}': "
                    f"failed to import module '{module_path}': {e}"
                )

        # Local reference: simple class name in the same module
        module = sys.modules.get(cls.__module__)

        if module is None:
            raise ValueError(
                f"Cannot resolve serializer reference '{string_ref}': "
                f"module '{cls.__module__}' not found in sys.modules."
            )

        serializer_class = getattr(module, string_ref, None)

        if serializer_class is None:
            raise ValueError(
                f"Cannot resolve serializer reference '{string_ref}' in module '{cls.__module__}'. "
                f"Make sure the serializer class '{string_ref}' is defined in the same module as {cls.__name__}."
            )

        return serializer_class

    @classmethod
    def _resolve_serializer_reference(
        cls, serializer_ref: str | type | Any
    ) -> type | Any:
        """
        Resolve a serializer reference that may be a string, a class, or a Union of serializers.

        This method performs lazy resolution, meaning it will attempt to resolve
        string references only when called, allowing for forward references and
        circular dependencies between serializers in the same module.

        Parameters
        ----------
        serializer_ref : str | type | Union
            Either a string reference to a serializer class, an actual serializer class,
            or a Union of serializer references. String references can be:
            - A class name in the same module (e.g., "UserSerializer")
            - An absolute import path (e.g., "myapp.serializers.UserSerializer")

        Returns
        -------
        type | Union
            The resolved serializer class or Union of serializer classes.

        Raises
        ------
        ValueError
            If the string reference cannot be resolved.

        Examples
        --------
        >>> # Single reference
        >>> cls._resolve_serializer_reference("UserSerializer")
        >>> cls._resolve_serializer_reference(UserSerializer)
        >>>
        >>> # Union reference
        >>> from typing import Union
        >>> cls._resolve_serializer_reference(Union[UserSerializer, AdminSerializer])
        >>> cls._resolve_serializer_reference(Union["UserSerializer", "AdminSerializer"])
        """
        # Handle Union types
        origin = get_origin(serializer_ref)
        if origin is Union:
            resolved_types = tuple(
                cls._resolve_serializer_reference(arg)
                for arg in get_args(serializer_ref)
            )
            # Optimize single-type unions
            if len(resolved_types) == 1:
                return resolved_types[0]
            # Create Union using indexing syntax for Python 3.10+ compatibility
            return Union[resolved_types]

        # Handle ForwardRef (created when using Union["StringType"])
        if isinstance(serializer_ref, ForwardRef):
            return cls._resolve_serializer_reference(serializer_ref.__forward_arg__)

        # Handle string references
        if isinstance(serializer_ref, str):
            return cls._resolve_string_reference(serializer_ref)

        # Already a class, return as-is
        return serializer_ref

    @classmethod
    def _get_relations_serializers(cls) -> dict[str, "Serializer"]:
        """
        Return mapping of relation field names to their serializer classes.

        Subclasses may override to provide explicit serializer mappings for
        relation fields used during read schema generation.

        Returns
        -------
        dict[str, Serializer]
            Mapping of field name to serializer class. Empty by default.
        """
        return {}

    @classmethod
    def _get_relations_as_id(cls) -> list[str]:
        """
        Return relation field names that should be serialized as IDs.

        Subclasses may override to specify which relation fields should be
        represented as primary key values instead of nested objects.

        Returns
        -------
        list[str]
            Field names to serialize as IDs. Empty by default.
        """
        return []

    @classmethod
    def _generate_union_schema(cls, resolved_union: Any) -> Any:
        """
        Generate a Union schema from multiple resolved serializers.

        Parameters
        ----------
        resolved_union : Union
            A Union type containing resolved serializer classes.

        Returns
        -------
        Schema | Union[Schema, ...] | None
            Union of generated schemas or None if all schemas are None.
        """
        # Generate schemas for each serializer in the Union (single call per serializer)
        schemas = tuple(
            schema
            for serializer_type in get_args(resolved_union)
            if (schema := serializer_type.generate_related_s()) is not None
        )

        if not schemas:
            return None

        # Optimize single-schema unions
        if len(schemas) == 1:
            return schemas[0]

        # Create Union of schemas using indexing syntax for Python 3.10+ compatibility
        return Union[schemas]

    @classmethod
    def _resolve_relation_schema(cls, field_name: str, rel_model: models.Model):
        """
        Resolve and generate schema for a related model.

        Parameters
        ----------
        field_name : str
            Name of the relation field.
        rel_model : models.Model
            The related model class.

        Returns
        -------
        Schema | Union[Schema, ...] | None
            Generated schema, Union of schemas, or None if cannot be resolved.

        Notes
        -----
        Includes circular reference detection to prevent infinite recursion.
        """
        # Security: Check for circular references to prevent infinite recursion
        if cls._is_circular_reference(rel_model):
            # Circular reference detected - return None to break the cycle
            warnings.warn(
                f"Circular reference detected for {rel_model._meta.label} "
                f"in field '{field_name}' of {cls._get_model()._meta.label}. "
                f"Skipping nested schema generation to prevent infinite recursion.",
                UserWarning,
                stacklevel=2,
            )
            return None

        # Track this model in the resolution stack
        cls._push_resolution(rel_model)
        try:
            # Auto-resolve ModelSerializer with readable fields
            if isinstance(rel_model, ModelSerializerMeta):
                has_readable_fields = rel_model.get_fields(
                    "read"
                ) or rel_model.get_custom_fields("read")
                return rel_model.generate_related_s() if has_readable_fields else None

            # Resolve from explicit serializer mapping
            rel_serializers = cls._get_relations_serializers() or {}
            serializer_ref = rel_serializers.get(field_name)

            if not serializer_ref:
                return None

            resolved = cls._resolve_serializer_reference(serializer_ref)

            # Handle Union of serializers
            if get_origin(resolved) is Union:
                return cls._generate_union_schema(resolved)

            # Handle single serializer
            return resolved.generate_related_s()
        finally:
            # Always pop from resolution stack when done
            cls._pop_resolution()

    @classmethod
    def _is_special_field(
        cls, s_type: type[S_TYPES], field: str, f_type: type[F_TYPES]
    ) -> bool:
        """
        Check whether a field appears in the given category for a serializer type.

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type (``"create"`` | ``"update"`` | ``"read"`` | ``"detail"``).
        field : str
            The field name to look up.
        f_type : F_TYPES
            Field category (``"fields"`` | ``"optionals"`` | ``"customs"`` | ``"excludes"``).

        Returns
        -------
        bool
            ``True`` if the field is found in the specified category.
        """
        special_fields = cls._get_fields(s_type, f_type)
        return any(field in special_f for special_f in special_fields)

    @classmethod
    def get_custom_fields(cls, s_type: type[S_TYPES]) -> list[tuple[str, type, Any]]:
        """
        Normalize declared custom field specs into ``(name, py_type, default)`` tuples.

        Accepted tuple shapes:

        - ``(name, py_type, default)`` -- field with explicit default.
        - ``(name, py_type)`` -- required field (default set to ``Ellipsis``).

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type whose custom fields to retrieve.

        Returns
        -------
        list[tuple[str, type, Any]]
            Normalized list of ``(name, type, default)`` tuples.

        Raises
        ------
        ValueError
            If a custom field spec is not a tuple or has an invalid length.
        """
        raw_customs = cls._get_fields(s_type, "customs") or []
        normalized: list[tuple[str, Any, Any]] = []
        for spec in raw_customs:
            if not isinstance(spec, tuple):
                raise ValueError(f"Custom field spec must be a tuple, got {type(spec)}")
            match len(spec):
                case 3:
                    name, py_type, default = spec
                case 2:
                    name, py_type = spec
                    default = ...
                case _:
                    raise ValueError(
                        f"Custom field tuple must have length 2 or 3 (name, type[, default]); got {len(spec)}"
                    )
            normalized.append((name, py_type, default))
        return normalized

    @classmethod
    def get_optional_fields(cls, s_type: type[S_TYPES]):
        """
        Return optional field specs normalized to ``(name, type, None)`` tuples.

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type whose optional fields to retrieve.

        Returns
        -------
        list[tuple[str, type, None]]
            Normalized list where each entry defaults to ``None``.
        """
        return [
            (field, field_type, None)
            for field, field_type in cls._get_fields(s_type, "optionals")
        ]

    @classmethod
    def get_excluded_fields(cls, s_type: S_TYPES):
        """
        Return excluded field names for the given serializer type.

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type whose exclusions to retrieve.

        Returns
        -------
        list[str]
            Field names excluded from schema generation.
        """
        return cls._get_fields(s_type, "excludes")

    @classmethod
    def get_fields(cls, s_type: S_TYPES):
        """
        Return explicit declared field names for the serializer type.

        Filters out inline custom field tuples from the fields list, returning
        only string field names.

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type whose fields to retrieve.

        Returns
        -------
        list[str]
            Model field names (excludes inline custom tuples).
        """
        fields = cls._get_fields(s_type, "fields")
        # Filter out inline custom field tuples, return only string field names
        return [f for f in fields if isinstance(f, str)]

    @classmethod
    def get_inline_customs(cls, s_type: S_TYPES) -> list[tuple[str, Any, Any]]:
        """
        Return inline custom field tuples declared directly in the fields list.

        These are tuples in the format (name, type, default) or (name, type) mixed
        with regular string field names in the fields list.

        Returns
        -------
        list[tuple[str, Any, Any]]
            Normalized list of (name, type, default) tuples.
        """
        fields = cls._get_fields(s_type, "fields")
        inline_customs: list[tuple[str, Any, Any]] = []
        for spec in fields:
            if isinstance(spec, tuple):
                match len(spec):
                    case 3:
                        inline_customs.append(spec)
                    case 2:
                        name, py_type = spec
                        inline_customs.append((name, py_type, ...))
                    case _:
                        raise ValueError(
                            f"Inline custom field tuple must have length 2 or 3 (name, type[, default]); got {len(spec)}"
                        )
        return inline_customs

    @classmethod
    def is_custom(cls, field: str) -> bool:
        """
        Check if a field is declared as a custom input in create or update.

        Parameters
        ----------
        field : str
            The field name to check.

        Returns
        -------
        bool
            ``True`` if the field appears in the customs category for either
            ``create`` or ``update`` serializer types.
        """
        return cls._is_special_field(
            "create", field, "customs"
        ) or cls._is_special_field("update", field, "customs")

    @classmethod
    def is_optional(cls, field: str) -> bool:
        """
        Check if a field is declared as optional in create or update.

        Parameters
        ----------
        field : str
            The field name to check.

        Returns
        -------
        bool
            ``True`` if the field appears in the optionals category for either
            ``create`` or ``update`` serializer types.
        """
        return cls._is_special_field(
            "create", field, "optionals"
        ) or cls._is_special_field("update", field, "optionals")

    @classmethod
    def _build_schema_reverse_rel(
        cls, field_name: str, descriptor: Any, relations_as_id: list[str]
    ):
        """
        Build a reverse relation schema component for 'Out' schema generation.

        Parameters
        ----------
        field_name : str
            Name of the relation field.
        descriptor : Any
            Django field descriptor (ManyToManyDescriptor, ReverseManyToOneDescriptor, etc.).
        relations_as_id : list[str]
            Pre-fetched list of fields to serialize as IDs.

        Returns
        -------
        tuple | None
            Custom field tuple for schema generation, or None to skip.
        """
        # Resolve related model and cardinality
        if isinstance(descriptor, ManyToManyDescriptor):
            # M2M uses the same descriptor on both sides; rely on .reverse to pick the model
            rel_model: models.Model = (
                descriptor.field.model
                if descriptor.reverse
                else descriptor.field.related_model
            )
            many = True
        elif isinstance(descriptor, ReverseManyToOneDescriptor):
            rel_model = descriptor.field.model
            many = True
        else:  # ReverseOneToOneDescriptor
            rel_model = descriptor.related.related_model
            many = False

        # Handle relations_as_id for reverse relations
        if field_name in relations_as_id:
            from ninja_aio.models.utils import ModelUtil

            pk_field_type = ModelUtil(rel_model).pk_field_type
            if many:
                # For many relations, use PkFromModel to extract PKs from model instances
                return (
                    field_name,
                    list[PkFromModel[pk_field_type]],
                    Field(default_factory=list),
                )
            else:
                # For single reverse relations (ReverseOneToOne), extract pk
                return (field_name, PkFromModel[pk_field_type] | None, None)

        schema = cls._resolve_relation_schema(field_name, rel_model)
        if not schema:
            return None

        rel_schema_type = schema if not many else list[schema]
        return (field_name, rel_schema_type | None, None)

    @classmethod
    def _build_schema_forward_rel(
        cls, field_name: str, descriptor: Any, relations_as_id: list[str]
    ):
        """
        Build a forward relation schema component for 'Out' schema generation.

        Parameters
        ----------
        field_name : str
            Name of the relation field.
        descriptor : Any
            Django field descriptor (ForwardOneToOneDescriptor, ForwardManyToOneDescriptor).
        relations_as_id : list[str]
            Pre-fetched list of fields to serialize as IDs.

        Returns
        -------
        True | tuple | None
            True to treat as plain field, a custom field tuple to include relation schema,
            or None to skip entirely.
        """
        rel_model = descriptor.field.related_model

        # Handle relations_as_id: serialize as the raw FK ID
        if field_name in relations_as_id:
            from ninja_aio.models.utils import ModelUtil

            pk_field_type = ModelUtil(rel_model).pk_field_type
            # Use PkFromModel to extract pk from the related instance during serialization
            return (field_name, PkFromModel[pk_field_type] | None, None)

        # Special case: ModelSerializer with no readable fields should be skipped entirely
        if isinstance(rel_model, ModelSerializerMeta) and not (
            rel_model.get_fields("read") or rel_model.get_custom_fields("read")
        ):
            return None

        schema = cls._resolve_relation_schema(field_name, rel_model)
        if not schema:
            # Could not build a schema: treat as a plain field (serialize as-is)
            return True

        # Forward relations are single objects; allow nullability
        return (field_name, schema | None, None)

    @classmethod
    def _is_reverse_relation(cls, field_obj) -> bool:
        """
        Check if a field descriptor represents a reverse relation.

        Parameters
        ----------
        field_obj : Any
            Django model field descriptor.

        Returns
        -------
        bool
            ``True`` if the descriptor is a ``ManyToManyDescriptor``,
            ``ReverseManyToOneDescriptor``, or ``ReverseOneToOneDescriptor``.
        """
        return isinstance(
            field_obj,
            (
                ManyToManyDescriptor,
                ReverseManyToOneDescriptor,
                ReverseOneToOneDescriptor,
            ),
        )

    @classmethod
    def _is_forward_relation(cls, field_obj) -> bool:
        """
        Check if a field descriptor represents a forward relation.

        Parameters
        ----------
        field_obj : Any
            Django model field descriptor.

        Returns
        -------
        bool
            ``True`` if the descriptor is a ``ForwardOneToOneDescriptor``
            or ``ForwardManyToOneDescriptor``.
        """
        return isinstance(
            field_obj, (ForwardOneToOneDescriptor, ForwardManyToOneDescriptor)
        )

    @classmethod
    def _warn_missing_relation_serializer(cls, field_name: str, model) -> None:
        """
        Emit a warning for reverse relations without an explicit serializer mapping.

        Only warns when the related model is not a ``ModelSerializer`` and the
        ``NINJA_AIO_RAISE_SERIALIZATION_WARNINGS`` setting is enabled (default).

        Parameters
        ----------
        field_name : str
            Name of the reverse relation field.
        model : type
            The Django model class owning the field.
        """
        if not isinstance(model, ModelSerializerMeta) and getattr(
            settings, "NINJA_AIO_RAISE_SERIALIZATION_WARNINGS", True
        ):
            warnings.warn(
                f"{cls.__name__}: reverse relation '{field_name}' is listed in read fields "
                "but has no entry in relations_serializers; it will be auto-resolved only "
                "for ModelSerializer relations, otherwise skipped.",
                UserWarning,
                stacklevel=3,
            )

    @classmethod
    def _process_field(
        cls,
        field_name: str,
        model,
        relations_serializers: dict,
        relations_as_id: list[str],
    ) -> tuple[str | None, tuple | None, tuple | None]:
        """
        Process a single field and determine its classification.

        Parameters
        ----------
        field_name : str
            Name of the field to process.
        model : Model
            Django model class.
        relations_serializers : dict
            Mapping of relation field names to serializer classes.
        relations_as_id : list[str]
            Pre-fetched list of fields to serialize as IDs.

        Returns
        -------
        tuple
            (plain_field, reverse_rel, forward_rel) - only one will be non-None
        """
        field_obj = getattr(model, field_name)

        if cls._is_reverse_relation(field_obj):
            if (
                field_name not in relations_serializers
                and field_name not in relations_as_id
            ):
                cls._warn_missing_relation_serializer(field_name, model)
            rel_tuple = cls._build_schema_reverse_rel(
                field_name, field_obj, relations_as_id
            )
            return (None, rel_tuple, None)

        if cls._is_forward_relation(field_obj):
            rel_tuple = cls._build_schema_forward_rel(
                field_name, field_obj, relations_as_id
            )
            if rel_tuple is True:
                return (field_name, None, None)
            return (None, None, rel_tuple)

        return (field_name, None, None)

    @classmethod
    def get_schema_out_data(cls, schema_type: Literal["Out", "Detail"] = "Out"):
        """
        Collect components for output schema generation (Out or Detail).

        Parameters
        ----------
        schema_type : Literal["Out", "Detail"]
            Type of schema to generate.

        Returns
        -------
        tuple
            (fields, reverse_rels, excludes, customs_with_forward_rels, optionals)
        """
        if schema_type not in ("Out", "Detail"):
            raise ValueError(
                "get_schema_out_data only supports 'Out' or 'Detail' types"
            )

        fields_type = "read" if schema_type == "Out" else "detail"
        model = cls._get_model()
        relations_serializers = cls._get_relations_serializers() or {}
        # Fetch once to avoid repeated method calls during field processing
        relations_as_id = cls._get_relations_as_id()

        fields: list[str] = []
        reverse_rels: list[tuple] = []
        forward_rels: list[tuple] = []

        for field_name in cls.get_fields(fields_type):
            plain, reverse, forward = cls._process_field(
                field_name, model, relations_serializers, relations_as_id
            )
            if plain:
                fields.append(plain)
            if reverse:
                reverse_rels.append(reverse)
            if forward:
                forward_rels.append(forward)

        # Combine explicit customs, inline customs, and forward relation schemas
        all_customs = (
            cls.get_custom_fields(fields_type)
            + cls.get_inline_customs(fields_type)
            + forward_rels
        )

        return (
            fields,
            reverse_rels,
            cls.get_excluded_fields(fields_type),
            all_customs,
            cls.get_optional_fields(fields_type),
        )

    @classmethod
    def _create_out_or_detail_schema(
        cls,
        schema_type: type[SCHEMA_TYPES],
        model,
        validators,
        depth: int = None,
        model_config: dict = None,
        schema_overrides: dict = None,
    ) -> Schema | None:
        """Create schema for Out or Detail types."""
        fields, reverse_rels, excludes, customs, optionals = cls.get_schema_out_data(
            schema_type
        )
        if not any([fields, reverse_rels, excludes, customs]):
            return None
        schema_name = "SchemaOut" if schema_type == "Out" else "DetailSchemaOut"
        schema = create_schema(
            model=model,
            name=f"{model._meta.model_name}{schema_name}",
            depth=depth,
            fields=fields,
            custom_fields=reverse_rels + customs + optionals,
            exclude=excludes,
        )
        return cls._apply_validators(schema, validators, model_config, schema_overrides)

    @classmethod
    def _create_related_schema(
        cls, model, validators, model_config: dict = None, schema_overrides: dict = None
    ) -> Schema | None:
        """Create schema for Related type."""
        fields, customs = cls.get_related_schema_data()
        if not fields and not customs:
            return None
        schema = create_schema(
            model=model,
            name=f"{model._meta.model_name}SchemaRelated",
            fields=fields,
            custom_fields=customs,
        )
        return cls._apply_validators(schema, validators, model_config, schema_overrides)

    @classmethod
    def _create_in_or_patch_schema(
        cls,
        schema_type: type[SCHEMA_TYPES],
        model,
        validators,
        model_config: dict = None,
        schema_overrides: dict = None,
    ) -> Schema | None:
        """Create schema for In or Patch types."""
        s_type = "create" if schema_type == "In" else "update"
        fields = cls.get_fields(s_type)
        optionals = cls.get_optional_fields(s_type)
        customs = (
            cls.get_custom_fields(s_type) + optionals + cls.get_inline_customs(s_type)
        )
        excludes = cls.get_excluded_fields(s_type)

        # If no explicit fields and no excludes specified
        if not fields and not excludes:
            if optionals:
                # Use optional field names as the fields to include
                fields = [f[0] for f in optionals]
            elif customs:
                # Only customs defined - exclude all model fields to prevent auto-inclusion
                excludes = [
                    f.name
                    for f in model._meta.get_fields()
                    if getattr(f, "concrete", False)
                ]

        # Only create schema if we have something to include
        if not any([fields, customs, excludes]):
            return None

        schema = create_schema(
            model=model,
            name=f"{model._meta.model_name}Schema{schema_type}",
            fields=fields,
            custom_fields=customs,
            exclude=excludes,
        )
        return cls._apply_validators(schema, validators, model_config, schema_overrides)

    @classmethod
    def _generate_model_schema(
        cls,
        schema_type: type[SCHEMA_TYPES],
        depth: int = None,
    ) -> Schema:
        """
        Core schema factory bridging serializer configuration to ``ninja.orm.create_schema``.

        Dispatches to the appropriate field/custom/exclude gathering logic based
        on the requested schema type and delegates to Django Ninja's
        ``create_schema`` for the actual Pydantic model construction.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.
        depth : int, optional
            Nesting depth for related model schemas (used by ``Out`` and ``Detail``).

        Returns
        -------
        Schema | None
            Generated Pydantic schema, or ``None`` if no fields are configured.
        """
        model = cls._get_model()
        validators = cls._get_validators(schema_type)
        model_config = cls._get_model_config(schema_type)
        schema_overrides = cls._get_schema_overrides(schema_type)

        if schema_type in ("Out", "Detail"):
            return cls._create_out_or_detail_schema(
                schema_type, model, validators, depth, model_config, schema_overrides
            )

        if schema_type == "Related":
            return cls._create_related_schema(
                model, validators, model_config, schema_overrides
            )

        return cls._create_in_or_patch_schema(
            schema_type, model, validators, model_config, schema_overrides
        )

    @classmethod
    def get_related_schema_data(cls):
        """
        Build field/custom lists for 'Related' schema, flattening non-relational fields.

        Custom fields (both explicit and inline) are always included since they
        are computed/synthetic and not relation descriptors.
        """
        fields = cls.get_fields("read")
        customs = cls.get_custom_fields("read") + cls.get_inline_customs("read")
        model = cls._get_model()

        # Filter out relation fields from model fields
        non_relation_fields = []
        for f in fields:
            field_obj = getattr(model, f, None)
            if field_obj is None or not isinstance(
                field_obj,
                (
                    ManyToManyDescriptor,
                    ReverseManyToOneDescriptor,
                    ReverseOneToOneDescriptor,
                    ForwardManyToOneDescriptor,
                    ForwardOneToOneDescriptor,
                ),
            ):
                non_relation_fields.append(f)

        # No fields or customs means nothing to include
        if not non_relation_fields and not customs:
            return None, None

        return non_relation_fields, customs

    @classmethod
    @lru_cache(maxsize=128)
    def generate_read_s(cls, depth: int = 1) -> Schema:
        """
        Generate the read (Out) schema for list responses.

        Performance: Results are cached per (class, depth) combination.

        Parameters
        ----------
        depth : int, optional
            Nesting depth for related models. Defaults to ``1``.

        Returns
        -------
        Schema | None
            Generated Pydantic schema, or ``None`` if no read fields are configured.
        """
        return cls._generate_model_schema("Out", depth)

    @classmethod
    @lru_cache(maxsize=128)
    def generate_detail_s(cls, depth: int = 1) -> Schema:
        """
        Generate the detail (single-object) read schema.

        Falls back to the standard read schema if no detail-specific
        configuration is defined.

        Performance: Results are cached per (class, depth) combination.

        Parameters
        ----------
        depth : int, optional
            Nesting depth for related models. Defaults to ``1``.

        Returns
        -------
        Schema
            Generated Pydantic schema (never ``None``; falls back to read schema).
        """
        return cls._generate_model_schema("Detail", depth) or cls.generate_read_s(depth)

    @classmethod
    @lru_cache(maxsize=128)
    def generate_create_s(cls) -> Schema:
        """
        Generate the create (In) schema for input validation.

        Performance: Results are cached per class.

        Returns
        -------
        Schema | None
            Generated Pydantic schema, or ``None`` if no create fields are configured.
        """
        return cls._generate_model_schema("In")

    @classmethod
    @lru_cache(maxsize=128)
    def generate_update_s(cls) -> Schema:
        """
        Generate the update (Patch) schema for partial updates.

        Performance: Results are cached per class.

        Returns
        -------
        Schema | None
            Generated Pydantic schema, or ``None`` if no update fields are configured.
        """
        return cls._generate_model_schema("Patch")

    @classmethod
    @lru_cache(maxsize=128)
    def generate_related_s(cls) -> Schema:
        """
        Generate the related (nested) schema for embedding in parent schemas.

        Includes only non-relational model fields and custom fields, preventing
        infinite nesting of related objects.

        Performance: Results are cached per class.

        Returns
        -------
        Schema | None
            Generated Pydantic schema, or ``None`` if no fields are configured.
        """
        return cls._generate_model_schema("Related")

    @classmethod
    async def queryset_request(cls, request: HttpRequest):
        """
        Override to return a request-scoped filtered queryset.

        Parameters
        ----------
        request : HttpRequest

        Returns
        -------
        QuerySet
        """
        raise NotImplementedError


class ModelSerializer(models.Model, BaseSerializer, metaclass=ModelSerializerMeta):
    """
    ModelSerializer
    =================
    Model-bound serializer mixin centralizing declarative configuration directly
    on the model class. Inherits common behavior from BaseSerializer and adds
    lifecycle hooks and query utilities.
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        from ninja_aio.models.utils import ModelUtil
        from ninja_aio.helpers.query import QueryUtil

        # Bind a ModelUtil instance to the subclass for convenient access
        cls.util = ModelUtil(cls)
        cls.query_util = QueryUtil(cls)

    class Meta:
        abstract = True

    class CreateSerializer:
        """Configuration container describing how to build a create (input) schema for a model.

        Purpose
        -------
        Describes which fields are accepted (and in what form) when creating a new
        instance. A factory/metaclass can read this configuration to generate a
        Pydantic / Ninja input schema.

        Attributes
        ----------
        fields : list[str]
            REQUIRED model fields.
        optionals : list[tuple[str, type]]
            Optional model fields (nullable / patch-like).
        customs : list[tuple[str, type, Any]]
            Synthetic input fields (non-model).
        excludes : list[str]
            Disallowed model fields on create (e.g., id, timestamps).
        """

        fields: list[str | tuple[str, Any, Any] | tuple[str, Any]] = []
        customs: list[tuple[str, Any, Any] | tuple[str, Any]] = []
        optionals: list[tuple[str, Any]] = []
        excludes: list[str] = []

    class ReadSerializer:
        """Configuration describing how to build a read (output) schema.

        Attributes
        ----------
        fields : list[str]
            Explicit model fields to include.
        excludes : list[str]
            Fields to force exclude (safety).
        customs : list[tuple[str, type, Any]]
            Computed / synthetic output attributes.
        optionals : list[tuple[str, type]]
            Optional output fields.
        relations_as_id : list[str]
            Relation fields to serialize as IDs instead of nested objects.
        """

        fields: list[str | tuple[str, Any, Any] | tuple[str, Any]] = []
        customs: list[tuple[str, Any, Any] | tuple[str, Any]] = []
        optionals: list[tuple[str, Any]] = []
        excludes: list[str] = []
        relations_as_id: list[str] = []

    class DetailSerializer:
        """Configuration describing detail (single object) read schema.

        Attributes
        ----------
        fields : list[str]
            Explicit model fields to include.
        excludes : list[str]
            Fields to force exclude (safety).
        customs : list[tuple[str, type, Any]]
            Computed / synthetic output attributes.
        optionals : list[tuple[str, type]]
            Optional output fields.
        """

        fields: list[str | tuple[str, Any, Any] | tuple[str, Any]] = []
        customs: list[tuple[str, Any, Any] | tuple[str, Any]] = []
        optionals: list[tuple[str, Any]] = []
        excludes: list[str] = []

    class UpdateSerializer:
        """Configuration describing update (PATCH/PUT) schema.

        Attributes
        ----------
        fields : list[str]
            Required update fields (rare).
        optionals : list[tuple[str, type]]
            Editable optional fields.
        customs : list[tuple[str, type, Any]]
            Synthetic operational inputs.
        excludes : list[str]
            Immutable / blocked fields.
        """

        fields: list[str | tuple[str, Any, Any]] = []
        customs: list[tuple[str, Any, Any]] = []
        optionals: list[tuple[str, Any]] = []
        excludes: list[str] = []

    # Serializer type to configuration class mapping
    _SERIALIZER_CONFIG_MAP = {
        "create": "CreateSerializer",
        "update": "UpdateSerializer",
        "read": "ReadSerializer",
        "detail": "DetailSerializer",
    }

    # Schema type to serializer type mapping for validator resolution
    _SCHEMA_TO_S_TYPE = {
        "In": "create",
        "Patch": "update",
        "Out": "read",
        "Detail": "detail",
        "Related": "read",
    }

    @classmethod
    def _get_validators(cls, schema_type: type[SCHEMA_TYPES]) -> dict:
        """
        Collect validators from the inner serializer class for the given schema type.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict
            Mapping of validator names to ``PydanticDescriptorProxy`` instances.
        """
        s_type = cls._SCHEMA_TO_S_TYPE.get(schema_type)
        config_name = cls._SERIALIZER_CONFIG_MAP.get(s_type)
        config_class = getattr(cls, config_name, None) if config_name else None
        return cls._collect_validators(config_class)

    @classmethod
    def _get_model_config(cls, schema_type: type[SCHEMA_TYPES]) -> dict | None:
        """
        Return Pydantic ``ConfigDict`` from the inner serializer class.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict | None
            A ``ConfigDict`` instance, or ``None`` if not configured.
        """
        s_type = cls._SCHEMA_TO_S_TYPE.get(schema_type)
        config_name = cls._SERIALIZER_CONFIG_MAP.get(s_type)
        config_class = getattr(cls, config_name, None) if config_name else None
        if config_class is None:
            return None
        return getattr(config_class, "model_config", None)

    @classmethod
    def _get_schema_overrides(cls, schema_type: type[SCHEMA_TYPES]) -> dict:
        """
        Collect schema method overrides from the inner serializer class.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict
            Mapping of method names to callables.
        """
        s_type = cls._SCHEMA_TO_S_TYPE.get(schema_type)
        config_name = cls._SERIALIZER_CONFIG_MAP.get(s_type)
        config_class = getattr(cls, config_name, None) if config_name else None
        return cls._collect_schema_overrides(config_class)

    @classmethod
    def _get_relations_as_id(cls) -> list[str]:
        """
        Return relation fields to serialize as primary key values.

        Reads the ``relations_as_id`` attribute from ``ReadSerializer``.

        Returns
        -------
        list[str]
            Field names whose related objects should be serialized as IDs.
        """
        return getattr(cls.ReadSerializer, "relations_as_id", [])

    @classmethod
    def _get_fields(cls, s_type: type[S_TYPES], f_type: type[F_TYPES]):
        """
        Internal accessor for raw configuration lists.

        Parameters
        ----------
        s_type : str
            Serializer type ("create" | "update" | "read").
        f_type : str
            Field category ("fields" | "optionals" | "customs" | "excludes").

        Returns
        -------
        list
            Raw configuration list or empty list.
        """
        config_class_name = cls._SERIALIZER_CONFIG_MAP.get(s_type)
        if not config_class_name:
            return []
        config_class = getattr(cls, config_class_name)
        fields = getattr(config_class, f_type, [])
        if not fields and s_type == "detail":
            fields = getattr(cls.ReadSerializer, f_type, [])
        return fields

    @classmethod
    def _get_model(cls) -> "ModelSerializer":
        """
        Return the model class itself.

        Since ``ModelSerializer`` is mixed directly into the model, the model
        class is the serializer class.

        Returns
        -------
        ModelSerializer
            The model/serializer class.
        """
        return cls

    @classmethod
    def verbose_name_path_resolver(cls) -> str:
        """
        Slugify the plural verbose name for use as a URL path segment.

        Replaces spaces with hyphens in the model's ``verbose_name_plural``.

        Returns
        -------
        str
            Hyphen-separated URL-safe path segment.
        """
        verbose_plural = (
            get_ninja_aio_meta_attr(cls, "verbose_name_plural")
            or cls._meta.verbose_name_plural
        )
        return "-".join(verbose_plural.split(" "))

    def has_changed(self, field: str) -> bool:
        """
        Check if a model field has changed compared to the persisted value.

        Parameters
        ----------
        field : str
            Field name.

        Returns
        -------
        bool
            True if in-memory value differs from DB value.
        """
        if not self.pk:
            return False
        old_value = (
            self.__class__._default_manager.filter(pk=self.pk)
            .values(field)
            .get()[field]
        )
        return getattr(self, field) != old_value

    async def ahas_changed(self, field: str) -> bool:
        """
        Async version of has_changed.

        Parameters
        ----------
        field : str
            Field name.

        Returns
        -------
        bool
            True if in-memory value differs from DB value.
        """
        return await sync_to_async(self.has_changed)(field)

    @classmethod
    async def queryset_request(cls, request: HttpRequest):
        return cls.query_util.apply_queryset_optimizations(
            queryset=cls.objects.all(),
            scope=cls.query_util.SCOPES.QUERYSET_REQUEST,
        )

    async def post_create(self) -> None:
        """
        Async hook executed after first persistence (create path).
        """
        pass

    async def custom_actions(self, payload: dict[str, Any]):
        """
        Async hook for reacting to provided custom (synthetic) fields.

        Parameters
        ----------
        payload : dict
            Custom field name/value pairs.
        """
        pass

    def after_save(self):
        """
        Sync hook executed after any save (create or update).
        """
        pass

    def before_save(self):
        """
        Sync hook executed before any save (create or update).
        """
        pass

    def on_create_after_save(self):
        """
        Sync hook executed only after initial creation save.
        """
        pass

    def on_create_before_save(self):
        """
        Sync hook executed only before initial creation save.
        """
        pass

    def on_delete(self):
        """
        Sync hook executed after delete.
        """
        pass

    def save(self, *args, **kwargs):
        """
        Override save lifecycle to inject create/update hooks.
        """
        state_adding = self._state.adding
        if state_adding:
            self.on_create_before_save()
        self.before_save()
        super().save(*args, **kwargs)
        if state_adding:
            self.on_create_after_save()
        self.after_save()

    def delete(self, *args, **kwargs):
        """
        Override delete to inject on_delete hook.

        Returns
        -------
        tuple(int, dict)
            Django delete return signature.
        """
        res = super().delete(*args, **kwargs)
        self.on_delete()
        return res


class SchemaModelConfig(Schema):
    """
    SchemaModelConfig
    -----------------
    Configuration container for declarative schema definitions.
    Attributes
    ----------
    fields : Optional[List[str | tuple]]
        Explicit model fields to include. Can also contain inline custom field tuples:
        - 2-tuple: (name, type) - required field
        - 3-tuple: (name, type, default) - optional field with default
    optionals : Optional[List[tuple[str, Any]]]
        Optional model fields. Type can be any valid type annotation including Union.
    exclude : Optional[List[str]]
        Model fields to exclude.
    customs : Optional[List[tuple[str, Any, Any] | tuple[str, Any]]]
        Custom / synthetic fields. Type can be any valid type annotation including Union.
        - 2-tuple: (name, type) - required field
        - 3-tuple: (name, type, default) - optional field with default
    """

    fields: Optional[List[str | tuple[str, Any, Any] | tuple[str, Any]]] = None
    optionals: Optional[List[tuple[str, Any]]] = None
    exclude: Optional[List[str]] = None
    customs: Optional[List[tuple[str, Any, Any] | tuple[str, Any]]] = None
    model_config_override: Optional[dict] = None


class Serializer(BaseSerializer, Generic[ModelT], metaclass=SerializerMeta):
    """
    Serializer
    ----------
    Generic, Meta-driven serializer for Django models providing type-safe CRUD operations.

    This class is generic over the model type, providing proper type hints for all
    methods. When you specify the model type parameter, methods like create(), update(),
    save(), and model_dump() are automatically typed to work with that specific model.

    Type Safety Example
    -------------------
    >>> class BookSerializer(Serializer[Book]):
    ...     class Meta:
    ...         model = Book
    ...         schema_in = SchemaModelConfig(fields=["title", "author"])
    ...
    >>> serializer = BookSerializer()
    >>> book: Book = await serializer.create({"title": "1984"})        # Returns Book
    >>> book: Book = await serializer.save(book)                        # Accepts/returns Book
    >>> data: dict = await serializer.model_dump(book)                  # Accepts Book
    >>>
    >>> # Instance-bound usage — pass instance once, omit it from calls
    >>> serializer = BookSerializer(instance=book)
    >>> book: Book = await serializer.update({"title": "New title"})   # Uses bound instance
    >>> data: dict = await serializer.model_dump()                      # Uses bound instance
    >>> changed: bool = serializer.has_changed("title")                 # Uses bound instance
    >>>
    >>> # Or assign after construction
    >>> serializer = BookSerializer()
    >>> serializer.instance = book
    >>> data: dict = await serializer.model_dump()

    Configuration
    -------------
    Configure via the nested Meta class with SchemaModelConfig objects for each
    operation type (create, read, update, detail). Supports relations_serializers
    mapping to explicitly include related schema components during read schema generation.

    See Also
    --------
    BaseSerializer : Parent class providing shared serializer utilities
    SchemaModelConfig : Configuration object for defining field sets per operation
    """

    # Serializer type to Meta schema attribute mapping
    _SCHEMA_META_MAP = {
        "create": "in",
        "update": "update",
        "read": "out",
        "detail": "detail",
    }

    # Schema type to validators inner class mapping
    _VALIDATORS_CLASS_MAP = {
        "In": "CreateValidators",
        "Patch": "UpdateValidators",
        "Out": "ReadValidators",
        "Detail": "DetailValidators",
        "Related": "ReadValidators",
    }

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        from ninja_aio.models.utils import ModelUtil
        from ninja_aio.helpers.query import QueryUtil

        cls.model = cls._get_model()
        cls.util = ModelUtil(cls.model, serializer_class=cls)
        cls.query_util = QueryUtil(cls)
        cls._meta = cls.Meta

    class Meta:
        model: Optional[type[ModelT]] = None
        schema_in: Optional[SchemaModelConfig] = None
        schema_out: Optional[SchemaModelConfig] = None
        schema_update: Optional[SchemaModelConfig] = None
        schema_detail: Optional[SchemaModelConfig] = None
        relations_serializers: dict[str, "Serializer"] = {}
        relations_as_id: list[str] = []

    def __init__(self, instance: Optional[ModelT] = None):
        """
        Initialize the serializer with an optional bound model instance.

        Binding an instance allows you to omit the ``instance`` argument on
        ``save``, ``update``, ``model_dump``, ``has_changed``, and
        ``ahas_changed`` calls made on this serializer object. The binding
        can also be set or replaced at any time via attribute assignment::

            serializer = BookSerializer(instance=book)
            await serializer.update({"title": "New title"})

            # or assign after construction
            serializer = BookSerializer()
            serializer.instance = book
            data = await serializer.model_dump()

        Parameters
        ----------
        instance : ModelT | None
            The model instance to bind to this serializer. Defaults to
            ``None`` (no bound instance).
        """
        self.instance = instance

    def _resolve_instance(self, instance: Optional[ModelT]) -> ModelT:
        """
        Return the effective model instance, raising ``ValueError`` when none is available.

        Prefers the explicitly-supplied *instance* argument over the
        serializer's bound ``self.instance``.

        Parameters
        ----------
        instance : ModelT | None
            Caller-supplied instance, or ``None`` to fall back to
            ``self.instance``.

        Returns
        -------
        ModelT
            The resolved model instance.

        Raises
        ------
        ValueError
            If both *instance* and ``self.instance`` are ``None``.
        """
        resolved = instance if instance is not None else self.instance
        if resolved is None:
            raise ValueError(
                "No instance bound to this serializer and no instance argument was "
                "provided. Either pass an instance to the method or bind one via "
                "BookSerializer(instance=obj) or serializer.instance = obj."
            )
        return resolved

    def _parse_payload(self, payload: dict[str, Any] | Schema) -> dict[str, Any]:
        """
        Parse and return the input payload.

        Can be overridden to implement custom parsing logic.

        Parameters
        ----------
        payload : dict | Schema
            Input data.

        Returns
        -------
        dict
            Parsed payload.
        """
        return payload.model_dump() if isinstance(payload, Schema) else payload

    @classmethod
    def _get_validators(cls, schema_type: type[SCHEMA_TYPES]) -> dict:
        """
        Collect validators from the inner validators class for the given schema type.

        Looks for inner classes named ``CreateValidators``, ``ReadValidators``,
        ``UpdateValidators``, or ``DetailValidators`` on the serializer.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict
            Mapping of validator names to ``PydanticDescriptorProxy`` instances.
        """
        class_name = cls._VALIDATORS_CLASS_MAP.get(schema_type)
        validators_class = getattr(cls, class_name, None) if class_name else None
        return cls._collect_validators(validators_class)

    @classmethod
    def _get_model_config(cls, schema_type: type[SCHEMA_TYPES]) -> dict | None:
        """
        Return Pydantic ``ConfigDict`` from the ``SchemaModelConfig`` for the given schema type.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict | None
            A ``ConfigDict`` instance, or ``None`` if not configured.
        """
        schema_type_to_key = {
            "In": "in",
            "Patch": "update",
            "Out": "out",
            "Detail": "detail",
            "Related": "out",
        }
        schema_key = schema_type_to_key.get(schema_type)
        if not schema_key:
            return None
        schema_meta = cls._get_schema_meta(schema_key)
        if schema_meta is None:
            return None
        return getattr(schema_meta, "model_config_override", None)

    @classmethod
    def _get_schema_overrides(cls, schema_type: type[SCHEMA_TYPES]) -> dict:
        """
        Collect schema method overrides from the validator inner class.

        Parameters
        ----------
        schema_type : SCHEMA_TYPES
            One of ``"In"``, ``"Patch"``, ``"Out"``, ``"Detail"``, or ``"Related"``.

        Returns
        -------
        dict
            Mapping of method names to callables.
        """
        class_name = cls._VALIDATORS_CLASS_MAP.get(schema_type)
        validators_class = getattr(cls, class_name, None) if class_name else None
        return cls._collect_schema_overrides(validators_class)

    @classmethod
    def _get_relations_as_id(cls) -> list[str]:
        """
        Return relation fields to serialize as primary key values.

        Reads the ``relations_as_id`` attribute from ``Meta``.

        Returns
        -------
        list[str]
            Field names whose related objects should be serialized as IDs.
        """
        relations_as_id = cls._get_meta_data("relations_as_id")
        return relations_as_id or []

    @classmethod
    def _get_meta_data(cls, attr_name: str) -> Any:
        """
        Retrieve an attribute from the nested ``Meta`` class.

        Parameters
        ----------
        attr_name : str
            Name of the ``Meta`` attribute to look up.

        Returns
        -------
        Any
            The attribute value, or ``None`` if not defined.
        """
        return getattr(cls.Meta, attr_name, None)

    @classmethod
    def _get_model(cls) -> models.Model:
        """
        Return the Django model class from ``Meta.model``.

        Returns
        -------
        models.Model
            The validated Django model class.
        """
        return cls._validate_model()

    @classmethod
    def _get_relations_serializers(cls) -> dict[str, "Serializer"]:
        """
        Return the explicit relation-to-serializer mapping from ``Meta``.

        Returns
        -------
        dict[str, Serializer]
            Mapping of relation field names to serializer classes.
        """
        relations_serializers = cls._get_meta_data("relations_serializers")
        return relations_serializers or {}

    @classmethod
    def _get_schema_meta(cls, schema_type: str) -> SchemaModelConfig | None:
        """
        Retrieve the ``SchemaModelConfig`` for the given schema type.

        Parameters
        ----------
        schema_type : str
            One of ``"in"``, ``"out"``, ``"update"``, or ``"detail"``.

        Returns
        -------
        SchemaModelConfig | None
            The configuration object, or ``None`` if not defined.
        """
        match schema_type:
            case "in":
                return cls._get_meta_data("schema_in")
            case "out":
                return cls._get_meta_data("schema_out")
            case "update":
                return cls._get_meta_data("schema_update")
            case "detail":
                return cls._get_meta_data("schema_detail")
            case _:
                return None

    @classmethod
    def _validate_model(cls):
        """
        Validate and return the model defined in ``Meta.model``.

        Returns
        -------
        models.Model
            The validated Django model class.

        Raises
        ------
        ValueError
            If ``Meta.model`` is not defined or is not a Django model subclass.
        """
        model = cls._get_meta_data("model")
        if not model:
            raise ValueError("Meta.model must be defined for Serializer.")
        if not issubclass(model, models.Model):
            raise ValueError("Meta.model must be a Django model")
        return model

    @classmethod
    def _get_fields(cls, s_type: type[S_TYPES], f_type: type[F_TYPES]):
        """
        Return raw configuration list from the Meta schema for the given categories.

        Falls back to the ``out`` schema when ``detail`` is requested but not defined.

        Parameters
        ----------
        s_type : S_TYPES
            Serializer type (``"create"`` | ``"update"`` | ``"read"`` | ``"detail"``).
        f_type : F_TYPES
            Field category (``"fields"`` | ``"optionals"`` | ``"customs"`` | ``"excludes"``).

        Returns
        -------
        list
            Raw configuration list, or empty list if not configured.
        """
        schema_key = cls._SCHEMA_META_MAP.get(s_type)
        if not schema_key:
            return []
        schema = cls._get_schema_meta(schema_key)
        if not schema:
            if s_type == "detail":
                schema = cls._get_schema_meta("out")
            else:
                return []
        return getattr(schema, f_type, []) or []

    def _get_dump_schema(self, schema: Schema = None) -> Schema:
        if schema is None:
            detail_schema = self.generate_detail_s()
            if detail_schema is None:
                return self.generate_read_s()
            return detail_schema
        return schema

    @classmethod
    async def queryset_request(cls, request: HttpRequest):
        return cls.query_util.apply_queryset_optimizations(
            queryset=cls.model._default_manager.all(),
            scope=cls.query_util.SCOPES.QUERYSET_REQUEST,
        )

    def has_changed(self, field: str, instance: Optional[ModelT] = None) -> bool:
        """
        Check if a model field has changed compared to the persisted value.

        If *instance* is omitted the serializer's bound ``self.instance`` is
        used.  A ``ValueError`` is raised when neither is available.

        Parameters
        ----------
        field : str
            Field name to compare.
        instance : ModelT | None
            Model instance to inspect. Falls back to ``self.instance`` when
            ``None``.

        Returns
        -------
        bool
            ``True`` if the in-memory value differs from the DB value,
            ``False`` if the instance has no primary key yet.
        """
        instance = self._resolve_instance(instance)
        if not instance.pk:
            return False
        old_value = (
            instance.__class__._default_manager.filter(pk=instance.pk)
            .values(field)
            .get()[field]
        )
        return getattr(instance, field) != old_value

    async def ahas_changed(self, field: str, instance: Optional[ModelT] = None) -> bool:
        """
        Async version of :meth:`has_changed`.

        If *instance* is omitted the serializer's bound ``self.instance`` is
        used.  A ``ValueError`` is raised when neither is available.

        Parameters
        ----------
        field : str
            Field name to compare.
        instance : ModelT | None
            Model instance to inspect. Falls back to ``self.instance`` when
            ``None``.

        Returns
        -------
        bool
            ``True`` if the in-memory value differs from the DB value.
        """
        return await sync_to_async(self.has_changed)(field, instance)

    async def post_create(self, instance: models.Model) -> None:
        """
        Async hook executed after first persistence (create path).
        """
        pass

    async def custom_actions(self, payload: dict[str, Any], instance: models.Model):
        """
        Async hook for reacting to provided custom (synthetic) fields.

        Parameters
        ----------
        payload : dict
            Custom field name/value pairs.
        """
        pass

    async def save(self, instance: Optional[ModelT] = None) -> ModelT:
        """
        Async helper to save a model instance with lifecycle hooks.

        If *instance* is omitted the serializer's bound ``self.instance`` is
        used.  A ``ValueError`` is raised when neither is available.

        Parameters
        ----------
        instance : ModelT | None
            The model instance to save. Falls back to ``self.instance`` when
            ``None``.

        Returns
        -------
        ModelT
            The saved model instance.
        """
        instance = self._resolve_instance(instance)
        creation = instance._state.adding
        if creation:
            await sync_to_async(self.on_create_before_save)(instance)
        await sync_to_async(self.before_save)(instance)
        await instance.asave()
        if creation:
            await sync_to_async(self.on_create_after_save)(instance)
        await sync_to_async(self.after_save)(instance)
        return instance

    async def create(self, payload: dict[str, Any] | Schema) -> ModelT:
        """
        Create a new model instance from the provided payload.

        Parameters
        ----------
        payload : dict | Schema
            Input data.

        Returns
        -------
        ModelT
            Created model instance.
        """
        instance: ModelT = self.model(**self._parse_payload(payload))
        return await self.save(instance)

    async def update(
        self,
        payload: dict[str, Any] | Schema,
        instance: Optional[ModelT] = None,
    ) -> ModelT:
        """
        Update an existing model instance with the provided payload.

        If *instance* is omitted the serializer's bound ``self.instance`` is
        used.  A ``ValueError`` is raised when neither is available.

        Parameters
        ----------
        payload : dict | Schema
            Input data to apply to the instance.
        instance : ModelT | None
            The model instance to update. Falls back to ``self.instance``
            when ``None``.

        Returns
        -------
        ModelT
            The updated model instance.
        """
        instance = self._resolve_instance(instance)
        for attr, value in self._parse_payload(payload).items():
            setattr(instance, attr, value)
        return await self.save(instance)

    async def model_dump(
        self,
        instance: Optional[ModelT] = None,
        schema: Schema = None,
    ) -> dict[str, Any]:
        """
        Serialize a model instance to a dictionary using the Out schema.

        If *instance* is omitted the serializer's bound ``self.instance`` is
        used.  A ``ValueError`` is raised when neither is available.

        Parameters
        ----------
        instance : ModelT | None
            The model instance to serialize. Falls back to ``self.instance``
            when ``None``.
        schema : Schema | None
            The Pydantic schema to use for serialization. Defaults to the
            detail schema if defined, otherwise the read schema.

        Returns
        -------
        dict
            Serialized data.
        """
        instance = self._resolve_instance(instance)
        return await self.util.read_s(
            schema=self._get_dump_schema(schema), instance=instance
        )

    async def models_dump(
        self, instances: models.QuerySet[models.Model], schema: Schema = None
    ) -> list[dict[str, Any]]:
        """
        Serialize a list of model instances to a list of dictionaries using the Out schema.

        Parameters
        ----------
        instances : list[models.Model]
            The list of model instances to serialize.

        Returns
        -------
        list[dict]
            List of serialized data.
        """
        return await self.util.list_read_s(
            schema=self._get_dump_schema(schema), instances=instances
        )

    def after_save(self, instance: models.Model):
        """
        Sync hook executed after any save (create or update).
        """
        pass

    def before_save(self, instance: models.Model):
        """
        Sync hook executed before any save (create or update).
        """
        pass

    def on_create_after_save(self, instance: models.Model):
        """
        Sync hook executed only after initial creation save.
        """
        pass

    def on_create_before_save(self, instance: models.Model):
        """
        Sync hook executed only before initial creation save.
        """
        pass

    def on_delete(self, instance: models.Model):
        """
        Sync hook executed after delete.
        """
        pass
