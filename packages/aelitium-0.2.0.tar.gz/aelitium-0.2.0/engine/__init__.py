"""AELITIUM engine package."""
