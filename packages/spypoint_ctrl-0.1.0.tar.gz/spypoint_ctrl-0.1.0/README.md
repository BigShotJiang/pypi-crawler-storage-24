# Spypoint Control

A comprehensive Python client for interacting with the Spypoint API. Unlike other libraries, `spypoint-ctrl` supports **updating camera settings**, including the "Take Photo at Next Sync" feature.

## Features

*   **Authentication**: Login securely using your Spypoint credentials.
*   **Camera Management**: Retrieve a list of all cameras on your account.
*   **Photo Management**: Fetch and download the latest photos.
*   **Settings Control**: Read and **Update** camera configuration (e.g., capture mode, sync frequency, etc.).

## Installation

```bash
pip install spypoint-ctrl
```

*(Note: Once published to PyPI. For now, install from source)*

```bash
git clone https://github.com/beardface/spypoint-ctrl.git
cd spypoint-ctrl
pip install .
```

## Usage

### Basic Example

```python
from spypoint_ctrl import SpypointClient

# Initialize
client = SpypointClient("your_email", "your_password")
client.login()

# Get Cameras
cameras = client.get_cameras()
for cam in cameras:
    print(f"Camera: {cam['name']} (ID: {cam['id']})")

# Get Settings
cam_id = cameras[0]['id']
settings = client.get_camera_settings(cam_id)
print(f"Current Capture Mode: {settings.get('capture')}")

# Update Settings: Enable "Take Photo at Next Sync"
client.update_camera_settings(cam_id, {"capture": True})

# Download Latest Photo
photos = client.get_photos(cam_id, limit=1)
if photos:
    url = photos[0].get('url') # or 'large' depending on API response
    client.download_photo(url, "latest.jpg")
```

## Disclaimer

This is an unofficial library. Spypoint does not provide a public API, so endpoints may change without notice. Use at your own risk.
