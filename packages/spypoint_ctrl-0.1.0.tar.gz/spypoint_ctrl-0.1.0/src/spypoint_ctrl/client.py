import requests
import json
from .constants import LOGIN_URL, CAMERA_ALL_URL, CAMERA_BASE_URL

class SpypointError(Exception):
    pass

class SpypointClient:
    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.token = None
        self._headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def login(self):
        """Authenticates with Spypoint API."""
        payload = {"username": self.username, "password": self.password}
        response = self.session.post(LOGIN_URL, json=payload)
        
        if response.status_code != 200:
            raise SpypointError(f"Login failed: {response.status_code} {response.text}")
        
        data = response.json()
        self.token = data.get("token")
        self._headers["Authorization"] = f"Bearer {self.token}"
        self.session.headers.update(self._headers)
        return data

    def get_cameras(self):
        """Retrieves all cameras associated with the account."""
        response = self.session.get(CAMERA_ALL_URL)
        if response.status_code != 200:
            raise SpypointError(f"Failed to get cameras: {response.status_code}")
        return response.json()

    def get_camera_settings(self, camera_id):
        """Retrieves the current settings for a specific camera."""
        url = f"{CAMERA_BASE_URL}/settings/{camera_id}"
        response = self.session.get(url)
        if response.status_code != 200:
            raise SpypointError(f"Failed to get settings for {camera_id}: {response.status_code}")
        return response.json()

    def update_camera_settings(self, camera_id, settings_dict):
        """
        Updates camera settings. 
        It first fetches the current config to ensure we send a complete object back,
        then updates the specific keys provided in settings_dict.
        """
        # 1. Get current settings
        current_settings = self.get_camera_settings(camera_id)
        
        # 2. Update local object
        current_settings.update(settings_dict)
        
        # 3. Send PUT request
        url = f"{CAMERA_BASE_URL}/settings/{camera_id}"
        response = self.session.put(url, json=current_settings)
        
        if response.status_code not in [200, 204]:
            raise SpypointError(f"Failed to update settings: {response.status_code} {response.text}")
        
        return True

    def get_photos(self, camera_id, limit=20):
        """Retrieves photos for a specific camera."""
        # Using the POST endpoint which pyspypoint uses, usually /api/v3/photo/all
        # but let's try to find photos via the camera object or standard endpoint.
        # pyspypoint uses: https://restapi.spypoint.com/api/v3/photo/all with a body
        url = "https://restapi.spypoint.com/api/v3/photo/all"
        payload = {
            "camera": [camera_id],
            "limit": limit
        }
        response = self.session.post(url, json=payload)
        if response.status_code != 200:
            raise SpypointError(f"Failed to get photos: {response.status_code}")
        
        return response.json().get("photos", [])

    def download_photo(self, photo_url, output_path):
        """Downloads a photo from a URL to a local path."""
        # Use a fresh request to avoid sending Spypoint auth headers to S3/external hosts
        response = requests.get(photo_url, stream=True)
        if response.status_code == 200:
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(1024):
                    f.write(chunk)
            return True
        else:
            raise SpypointError(f"Failed to download photo: {response.status_code}")
