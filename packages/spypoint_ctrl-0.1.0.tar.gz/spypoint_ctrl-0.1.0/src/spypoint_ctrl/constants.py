API_BASE = "https://restapi.spypoint.com/api/v3"
LOGIN_URL = f"{API_BASE}/user/login"
CAMERA_ALL_URL = f"{API_BASE}/camera/all"
CAMERA_BASE_URL = f"{API_BASE}/camera"
