def main():
    print("Hello from alenax!")


if __name__ == "__main__":
    main()
