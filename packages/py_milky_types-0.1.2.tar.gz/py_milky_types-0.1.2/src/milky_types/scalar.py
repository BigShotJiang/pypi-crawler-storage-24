from typing import Any

from pydantic import Field
from pydantic_core import PydanticUndefined, PydanticUndefinedType


def t_list(
	description: str | None = None,
	default: Any | PydanticUndefinedType | None = PydanticUndefined,
) -> Any:
	"""列表类型"""
	return Field(description=description, default=default)


def t_str(
	description: str | None = None,
	default: str | PydanticUndefinedType | None = PydanticUndefined,
) -> Any:
	"""字符串类型"""
	return Field(description=description, default=default)


def t_bool(
	description: str | None = None,
	default: bool | PydanticUndefinedType | None = PydanticUndefined,
) -> Any:
	"""布尔类型"""
	return Field(description=description, default=default)


def t_int32(
	description: str | None = None,
	default: int | PydanticUndefinedType | None = PydanticUndefined,
) -> Any:
	"""32位整数类型"""
	return Field(
		description=description, default=default, ge=-2147483648, le=2147483647
	)


def t_int64(
	description: str | None = None,
	default: int | PydanticUndefinedType | None = PydanticUndefined,
) -> Any:
	"""64位整数类型"""
	return Field(
		description=description,
		ge=-9223372036854775808,
		le=9223372036854775807,
		default=default,
	)


def t_object(
	description: str | None = None,
	default: Any | PydanticUndefinedType | None = PydanticUndefined,
) -> Any:
	"""对象类型"""
	return Field(description=description, default=default)
