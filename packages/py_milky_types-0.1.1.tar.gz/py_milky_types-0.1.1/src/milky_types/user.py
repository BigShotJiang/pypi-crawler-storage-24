from typing import Literal

from pydantic import BaseModel

from milky_types.scalar import t_bool, t_int32, t_int64, t_object, t_str

__all__ = ['FriendCategoryEntity', 'FriendEntity', 'FriendRequest']


class FriendCategoryEntity(BaseModel):
	category_id: int = t_int32('好友分组 ID')
	category_name: str = t_str('好友分组名称')


class FriendEntity(BaseModel):
	user_id: int = t_int64('用户 QQ 号')
	nickname: str = t_str('用户昵称')
	sex: Literal['male', 'female', 'unknown'] = t_str('用户性别')
	qid: str = t_str('用户 QID')
	remark: str = t_str('好友备注')
	category: FriendCategoryEntity = t_object('好友分组')


class FriendRequest(BaseModel):
	time: int = t_int64('请求发起时的 Unix 时间戳（秒）')
	initiator_id: int = t_int64('请求发起者 QQ 号')
	initiator_uid: str = t_str('请求发起者 UID')
	target_user_id: int = t_int64('目标用户 QQ 号')
	target_user_uid: str = t_str('目标用户 UID')
	state: Literal['pending', 'accepted', 'rejected', 'ignored'] = t_str(
		'请求状态，可能值：pending accepted rejected ignored'
	)
	comment: str = t_str('申请附加信息')
	via: str = t_str('申请来源')
	is_filtered: bool = t_bool('请求是否被过滤（发起自风险账户）')
