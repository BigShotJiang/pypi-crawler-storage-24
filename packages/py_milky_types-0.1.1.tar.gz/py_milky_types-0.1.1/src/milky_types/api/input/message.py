from typing import Literal

from pydantic import BaseModel

from milky_types.message import OutgoingSegment
from milky_types.scalar import t_int32, t_int64, t_list, t_str

__all__ = [
	'SendPrivateMessageInput',
	'SendGroupMessageInput',
	'RecallPrivateMessageInput',
	'RecallGroupMessageInput',
	'GetMessageInput',
	'GetHistoryMessagesInput',
	'GetResourceTempUrlInput',
	'GetForwardedMessagesInput',
	'MarkMessageAsReadInput',
]


class SendPrivateMessageInput(BaseModel):
	"""发送私聊消息"""

	user_id: int = t_int64('好友 QQ 号')
	message: list[OutgoingSegment] = t_list('消息内容')


class SendGroupMessageInput(BaseModel):
	"""发送群聊消息"""

	group_id: int = t_int64('群号')
	message: list[OutgoingSegment] = t_list('消息内容')


class RecallPrivateMessageInput(BaseModel):
	"""撤回私聊消息"""

	user_id: int = t_int64('好友 QQ 号')
	message_seq: int = t_int64('消息序列号')


class RecallGroupMessageInput(BaseModel):
	"""撤回群聊消息"""

	group_id: int = t_int64('群号')
	message_seq: int = t_int64('消息序列号')


class GetMessageInput(BaseModel):
	"""获取消息"""

	message_scene: Literal['friend', 'group', 'temp'] = t_str(
		'消息场景，可能值：friend group temp'
	)
	peer_id: int = t_int64('好友 QQ 号或群号')
	message_seq: int = t_int64('消息序列号')


class GetHistoryMessagesInput(BaseModel):
	"""获取历史消息列表"""

	message_scene: Literal['friend', 'group', 'temp'] = t_str(
		'消息场景，可能值：friend group temp'
	)
	peer_id: int = t_int64('好友 QQ 号或群号')
	start_message_seq: int | None = t_int64(
		'起始消息序列号，由此开始从新到旧查询，不提供则从最新消息开始', default=None
	)
	limit: int = t_int32('期望获取到的消息数量，最多 30 条，默认值：20', default=20)


class GetResourceTempUrlInput(BaseModel):
	"""获取临时资源链接"""

	resource_id: str = t_str('资源 ID')


class GetForwardedMessagesInput(BaseModel):
	"""获取合并转发消息内容"""

	forward_id: str = t_str('转发消息 ID')


class MarkMessageAsReadInput(BaseModel):
	"""标记消息为已读"""

	message_scene: Literal['friend', 'group', 'temp'] = t_str(
		'消息场景，可能值：friend group temp'
	)
	peer_id: int = t_int64('好友 QQ 号或群号')
	message_seq: int = t_int64('标为已读的消息序列号，该消息及更早的消息将被标记为已读')
