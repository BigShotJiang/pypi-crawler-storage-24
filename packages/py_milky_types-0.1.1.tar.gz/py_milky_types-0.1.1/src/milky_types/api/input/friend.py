from pydantic import BaseModel

from milky_types.scalar import t_bool, t_int32, t_int64, t_str

__all__ = [
	'SendFriendNudgeInput',
	'SendProfileLikeInput',
	'DeleteFriendInput',
	'GetFriendRequestsInput',
	'AcceptFriendRequestInput',
	'RejectFriendRequestInput',
]


class SendFriendNudgeInput(BaseModel):
	"""发送好友戳一戳"""

	user_id: int = t_int64('好友 QQ 号')
	is_self: bool = t_bool('是否戳自己，默认值：false', default=False)


class SendProfileLikeInput(BaseModel):
	"""发送名片点赞"""

	user_id: int = t_int64('好友 QQ 号')
	count: int = t_int32('点赞数量，默认值：1', default=1)


class DeleteFriendInput(BaseModel):
	"""删除好友"""

	user_id: int = t_int64('好友 QQ 号')


class GetFriendRequestsInput(BaseModel):
	"""获取好友请求列表"""

	limit: int = t_int32('获取的最大请求数量，默认值：20', default=20)
	is_filtered: bool = t_bool(
		'true 表示只获取被过滤（由风险账号发起）的通知，false 表示只获取未被过滤的通知，默认值：false',
		default=False,
	)


class AcceptFriendRequestInput(BaseModel):
	"""同意好友请求"""

	initiator_uid: str = t_str('请求发起者 UID')
	is_filtered: bool = t_bool('是否是被过滤的请求，默认值：false', default=False)


class RejectFriendRequestInput(BaseModel):
	"""拒绝好友请求"""

	initiator_uid: str = t_str('请求发起者 UID')
	is_filtered: bool = t_bool('是否是被过滤的请求，默认值：false', default=False)
	reason: str | None = t_str('拒绝理由', default=None)
