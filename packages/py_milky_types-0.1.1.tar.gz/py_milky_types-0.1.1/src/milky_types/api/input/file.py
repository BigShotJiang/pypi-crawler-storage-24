from pydantic import BaseModel

from milky_types.scalar import t_int64, t_str

__all__ = [
	'UploadPrivateFileInput',
	'UploadGroupFileInput',
	'GetPrivateFileDownloadUrlInput',
	'GetGroupFileDownloadUrlInput',
	'GetGroupFilesInput',
	'MoveGroupFileInput',
	'RenameGroupFileInput',
	'DeleteGroupFileInput',
	'CreateGroupFolderInput',
	'RenameGroupFolderInput',
	'DeleteGroupFolderInput',
]


class UploadPrivateFileInput(BaseModel):
	"""上传私聊文件"""

	user_id: int = t_int64('好友 QQ 号')
	file_uri: str = t_str('文件 URI，支持 file:// http(s):// base64:// 三种格式')
	file_name: str = t_str('文件名称')


class UploadGroupFileInput(BaseModel):
	"""上传群文件"""

	group_id: int = t_int64('群号')
	parent_folder_id: str = t_str('目标文件夹 ID，默认值：/', default='/')
	file_uri: str = t_str('文件 URI，支持 file:// http(s):// base64:// 三种格式')
	file_name: str = t_str('文件名称')


class GetPrivateFileDownloadUrlInput(BaseModel):
	"""获取私聊文件下载链接"""

	user_id: int = t_int64('好友 QQ 号')
	file_id: str = t_str('文件 ID')
	file_hash: str = t_str('文件的 TriSHA1 哈希值')


class GetGroupFileDownloadUrlInput(BaseModel):
	"""获取群文件下载链接"""

	group_id: int = t_int64('群号')
	file_id: str = t_str('文件 ID')


class GetGroupFilesInput(BaseModel):
	"""获取群文件列表"""

	group_id: int = t_int64('群号')
	parent_folder_id: str = t_str('父文件夹 ID，默认值：/', default='/')


class MoveGroupFileInput(BaseModel):
	"""移动群文件"""

	group_id: int = t_int64('群号')
	file_id: str = t_str('文件 ID')
	parent_folder_id: str = t_str('文件所在的文件夹 ID，默认值：/', default='/')
	target_folder_id: str = t_str('目标文件夹 ID，默认值：/', default='/')


class RenameGroupFileInput(BaseModel):
	"""重命名群文件"""

	group_id: int = t_int64('群号')
	file_id: str = t_str('文件 ID')
	parent_folder_id: str = t_str('文件所在的文件夹 ID，默认值：/', default='/')
	new_file_name: str = t_str('新文件名称')


class DeleteGroupFileInput(BaseModel):
	"""删除群文件"""

	group_id: int = t_int64('群号')
	file_id: str = t_str('文件 ID')


class CreateGroupFolderInput(BaseModel):
	"""创建群文件夹"""

	group_id: int = t_int64('群号')
	folder_name: str = t_str('文件夹名称')


class RenameGroupFolderInput(BaseModel):
	"""重命名群文件夹"""

	group_id: int = t_int64('群号')
	folder_id: str = t_str('文件夹 ID')
	new_folder_name: str = t_str('新文件夹名')


class DeleteGroupFolderInput(BaseModel):
	"""删除群文件夹"""

	group_id: int = t_int64('群号')
	folder_id: str = t_str('文件夹 ID')
