from typing import Literal

from pydantic import BaseModel

from milky_types.scalar import t_bool, t_int32, t_int64, t_str

__all__ = [
	'SetGroupNameInput',
	'SetGroupAvatarInput',
	'SetGroupMemberCardInput',
	'SetGroupMemberSpecialTitleInput',
	'SetGroupMemberAdminInput',
	'SetGroupMemberMuteInput',
	'SetGroupWholeMuteInput',
	'KickGroupMemberInput',
	'GetGroupAnnouncementsInput',
	'SendGroupAnnouncementInput',
	'DeleteGroupAnnouncementInput',
	'GetGroupEssenceMessagesInput',
	'SetGroupEssenceMessageInput',
	'QuitGroupInput',
	'SendGroupMessageReactionInput',
	'SendGroupNudgeInput',
	'GetGroupNotificationsInput',
	'AcceptGroupRequestInput',
	'RejectGroupRequestInput',
	'AcceptGroupInvitationInput',
	'RejectGroupInvitationInput',
]


class SetGroupNameInput(BaseModel):
	"""设置群名称"""

	group_id: int = t_int64('群号')
	new_group_name: str = t_str('新群名称')


class SetGroupAvatarInput(BaseModel):
	"""设置群头像"""

	group_id: int = t_int64('群号')
	image_uri: str = t_str('头像文件 URI，支持 file:// http(s):// base64:// 三种格式')


class SetGroupMemberCardInput(BaseModel):
	"""设置群名片"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('被设置的群成员 QQ 号')
	card: str = t_str('新群名片')


class SetGroupMemberSpecialTitleInput(BaseModel):
	"""设置群成员专属头衔"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('被设置的群成员 QQ 号')
	special_title: str = t_str('新专属头衔')


class SetGroupMemberAdminInput(BaseModel):
	"""设置群管理员"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('被设置的 QQ 号')
	is_set: bool = t_bool(
		'是否设置为管理员，false 表示取消管理员，默认值：true', default=True
	)


class SetGroupMemberMuteInput(BaseModel):
	"""设置群成员禁言"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('被设置的 QQ 号')
	duration: int = t_int32(
		'禁言持续时间（秒），设为 0 为取消禁言，默认值：0', default=0
	)


class SetGroupWholeMuteInput(BaseModel):
	"""设置群全员禁言"""

	group_id: int = t_int64('群号')
	is_mute: bool = t_bool(
		'是否开启全员禁言，false 表示取消全员禁言，默认值：true', default=True
	)


class KickGroupMemberInput(BaseModel):
	"""踢出群成员"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('被踢的 QQ 号')
	reject_add_request: bool = t_bool(
		'是否拒绝加群申请，false 表示不拒绝，默认值：false', default=False
	)


class GetGroupAnnouncementsInput(BaseModel):
	"""获取群公告列表"""

	group_id: int = t_int64('群号')


class SendGroupAnnouncementInput(BaseModel):
	"""发送群公告"""

	group_id: int = t_int64('群号')
	content: str = t_str('公告内容')
	image_uri: str | None = t_str(
		'公告附带图像文件 URI，支持 file:// http(s):// base64:// 三种格式', default=None
	)


class DeleteGroupAnnouncementInput(BaseModel):
	"""删除群公告"""

	group_id: int = t_int64('群号')
	announcement_id: str = t_str('公告 ID')


class GetGroupEssenceMessagesInput(BaseModel):
	"""获取群精华消息列表"""

	group_id: int = t_int64('群号')
	page_index: int = t_int32('页码索引，从 0 开始')
	page_size: int = t_int32('每页包含的精华消息数量')


class SetGroupEssenceMessageInput(BaseModel):
	"""设置群精华消息"""

	group_id: int = t_int64('群号')
	message_seq: int = t_int64('消息序列号')
	is_set: bool = t_bool(
		'是否设置为精华消息，false 表示取消精华，默认值：true', default=True
	)


class QuitGroupInput(BaseModel):
	"""退出群"""

	group_id: int = t_int64('群号')


class SendGroupMessageReactionInput(BaseModel):
	"""发送群消息表情回应"""

	group_id: int = t_int64('群号')
	message_seq: int = t_int64('要回应的消息序列号')
	reaction: str = t_str('表情 ID')
	is_add: bool = t_bool('是否添加表情，false 表示取消，默认值：true', default=True)


class SendGroupNudgeInput(BaseModel):
	"""发送群戳一戳"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('被戳的群成员 QQ 号')


class GetGroupNotificationsInput(BaseModel):
	"""获取群通知列表"""

	start_notification_seq: int | None = t_int64('起始通知序列号', default=None)
	is_filtered: bool = t_bool(
		'true 表示只获取被过滤（由风险账号发起）的通知，false 表示只获取未被过滤的通知，默认值：false',
		default=False,
	)
	limit: int = t_int32('获取的最大通知数量，默认值：20', default=20)


class AcceptGroupRequestInput(BaseModel):
	"""同意入群/邀请他人入群请求"""

	notification_seq: int = t_int64('请求对应的通知序列号')
	notification_type: Literal['join_request', 'invited_join_request'] = t_str(
		'请求对应的通知类型'
	)
	group_id: int = t_int64('请求所在的群号')
	is_filtered: bool = t_bool('是否是被过滤的请求，默认值：false', default=False)


class RejectGroupRequestInput(BaseModel):
	"""拒绝入群/邀请他人入群请求"""

	notification_seq: int = t_int64('请求对应的通知序列号')
	notification_type: Literal['join_request', 'invited_join_request'] = t_str(
		'请求对应的通知类型'
	)
	group_id: int = t_int64('请求所在的群号')
	is_filtered: bool = t_bool('是否是被过滤的请求，默认值：false', default=False)
	reason: str | None = t_str('拒绝理由', default=None)


class AcceptGroupInvitationInput(BaseModel):
	"""同意他人邀请自身入群"""

	group_id: int = t_int64('群号')
	invitation_seq: int = t_int64('邀请序列号')


class RejectGroupInvitationInput(BaseModel):
	"""拒绝他人邀请自身入群"""

	group_id: int = t_int64('群号')
	invitation_seq: int = t_int64('邀请序列号')
