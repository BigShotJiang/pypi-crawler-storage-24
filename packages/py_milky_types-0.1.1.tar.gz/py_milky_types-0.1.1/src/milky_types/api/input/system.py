from pydantic import BaseModel

from milky_types.scalar import t_bool, t_int64, t_str

__all__ = [
	'GetLoginInfoInput',
	'GetImplInfoInput',
	'GetUserProfileInput',
	'GetFriendListInput',
	'GetFriendInfoInput',
	'GetGroupListInput',
	'GetGroupInfoInput',
	'GetGroupMemberListInput',
	'GetGroupMemberInfoInput',
	'SetAvatarInput',
	'SetNicknameInput',
	'SetBioInput',
	'GetCustomFaceUrlListInput',
	'GetCookiesInput',
	'GetCsrfTokenInput',
]


class GetLoginInfoInput(BaseModel):
	"""获取登录信息"""

	pass


class GetImplInfoInput(BaseModel):
	"""获取协议端信息"""

	pass


class GetUserProfileInput(BaseModel):
	"""获取用户个人信息"""

	user_id: int = t_int64('用户 QQ 号')


class GetFriendListInput(BaseModel):
	"""获取好友列表"""

	no_cache: bool = t_bool('是否强制不使用缓存', default=False)


class GetFriendInfoInput(BaseModel):
	"""获取好友信息"""

	user_id: int = t_int64('好友 QQ 号')
	no_cache: bool = t_bool('是否强制不使用缓存', default=False)


class GetGroupListInput(BaseModel):
	"""获取群列表"""

	no_cache: bool = t_bool('是否强制不使用缓存', default=False)


class GetGroupInfoInput(BaseModel):
	"""获取群信息"""

	group_id: int = t_int64('群号')
	no_cache: bool = t_bool('是否强制不使用缓存', default=False)


class GetGroupMemberListInput(BaseModel):
	"""获取群成员列表"""

	group_id: int = t_int64('群号')
	no_cache: bool = t_bool('是否强制不使用缓存', default=False)


class GetGroupMemberInfoInput(BaseModel):
	"""获取群成员信息"""

	group_id: int = t_int64('群号')
	user_id: int = t_int64('群成员 QQ 号')
	no_cache: bool = t_bool('是否强制不使用缓存', default=False)


class SetAvatarInput(BaseModel):
	"""设置 QQ 账号头像"""

	uri: str = t_str('头像文件 URI，支持 file:// http(s):// base64:// 三种格式')


class SetNicknameInput(BaseModel):
	"""设置 QQ 账号昵称"""

	new_nickname: str = t_str('新昵称')


class SetBioInput(BaseModel):
	"""设置 QQ 账号个性签名"""

	new_bio: str = t_str('新个性签名')


class GetCustomFaceUrlListInput(BaseModel):
	"""获取自定义表情 URL 列表"""

	pass


class GetCookiesInput(BaseModel):
	"""获取 Cookies"""

	domain: str = t_str('需要获取 Cookies 的域名')


class GetCsrfTokenInput(BaseModel):
	"""获取 CSRF Token"""

	pass
