from pydantic import BaseModel

from milky_types.group import GroupFileEntity, GroupFolderEntity
from milky_types.scalar import t_list, t_str

__all__ = [
	'UploadPrivateFileOutput',
	'UploadGroupFileOutput',
	'GetPrivateFileDownloadUrlOutput',
	'GetGroupFileDownloadUrlOutput',
	'GetGroupFilesOutput',
	'MoveGroupFileOutput',
	'RenameGroupFileOutput',
	'DeleteGroupFileOutput',
	'CreateGroupFolderOutput',
	'RenameGroupFolderOutput',
	'DeleteGroupFolderOutput',
]


class UploadPrivateFileOutput(BaseModel):
	"""上传私聊文件输出"""

	file_id: str = t_str('文件 ID')


class UploadGroupFileOutput(BaseModel):
	"""上传群文件输出"""

	file_id: str = t_str('文件 ID')


class GetPrivateFileDownloadUrlOutput(BaseModel):
	"""获取私聊文件下载链接输出"""

	download_url: str = t_str('文件下载链接')


class GetGroupFileDownloadUrlOutput(BaseModel):
	"""获取群文件下载链接输出"""

	download_url: str = t_str('文件下载链接')


class GetGroupFilesOutput(BaseModel):
	"""获取群文件列表输出"""

	files: list[GroupFileEntity] = t_list('文件列表')
	folders: list[GroupFolderEntity] = t_list('文件夹列表')


class MoveGroupFileOutput(BaseModel):
	"""移动群文件输出"""

	pass


class RenameGroupFileOutput(BaseModel):
	"""重命名群文件输出"""

	pass


class DeleteGroupFileOutput(BaseModel):
	"""删除群文件输出"""

	pass


class CreateGroupFolderOutput(BaseModel):
	"""创建群文件夹输出"""

	folder_id: str = t_str('文件夹 ID')


class RenameGroupFolderOutput(BaseModel):
	"""重命名群文件夹输出"""

	pass


class DeleteGroupFolderOutput(BaseModel):
	"""删除群文件夹输出"""

	pass
