from pydantic import BaseModel

from milky_types.scalar import t_list
from milky_types.user import FriendRequest

__all__ = [
	'SendFriendNudgeOutput',
	'SendProfileLikeOutput',
	'DeleteFriendOutput',
	'GetFriendRequestsOutput',
	'AcceptFriendRequestOutput',
	'RejectFriendRequestOutput',
]


class SendFriendNudgeOutput(BaseModel):
	"""发送好友戳一戳输出"""

	pass


class SendProfileLikeOutput(BaseModel):
	"""发送名片点赞输出"""

	pass


class DeleteFriendOutput(BaseModel):
	"""删除好友输出"""

	pass


class GetFriendRequestsOutput(BaseModel):
	"""获取好友请求列表输出"""

	requests: list[FriendRequest] = t_list('好友请求列表')


class AcceptFriendRequestOutput(BaseModel):
	"""同意好友请求输出"""

	pass


class RejectFriendRequestOutput(BaseModel):
	"""拒绝好友请求输出"""

	pass
