from pydantic import BaseModel

from milky_types.message import IncomingForwardedMessage, IncomingMessage
from milky_types.scalar import t_int64, t_list, t_str

__all__ = [
	'SendPrivateMessageOutput',
	'SendGroupMessageOutput',
	'RecallPrivateMessageOutput',
	'RecallGroupMessageOutput',
	'GetMessageOutput',
	'GetHistoryMessagesOutput',
	'GetResourceTempUrlOutput',
	'GetForwardedMessagesOutput',
	'MarkMessageAsReadOutput',
]


class SendPrivateMessageOutput(BaseModel):
	"""发送私聊消息输出"""

	message_seq: int = t_int64('消息序列号')
	time: int = t_int64('消息发送时间')


class SendGroupMessageOutput(BaseModel):
	"""发送群聊消息输出"""

	message_seq: int = t_int64('消息序列号')
	time: int = t_int64('消息发送时间')


class RecallPrivateMessageOutput(BaseModel):
	"""撤回私聊消息输出"""

	pass


class RecallGroupMessageOutput(BaseModel):
	"""撤回群聊消息输出"""

	pass


class GetMessageOutput(BaseModel):
	"""获取消息输出"""

	message: IncomingMessage = t_str('消息内容')


class GetHistoryMessagesOutput(BaseModel):
	"""获取历史消息列表输出"""

	messages: list[IncomingMessage] = t_list('获取到的消息')
	next_message_seq: int | None = t_int64('下一页起始消息序列号', default=None)


class GetResourceTempUrlOutput(BaseModel):
	"""获取临时资源链接输出"""

	url: str = t_str('临时资源链接')


class GetForwardedMessagesOutput(BaseModel):
	"""获取合并转发消息内容输出"""

	messages: list[IncomingForwardedMessage] = t_list('转发消息内容')


class MarkMessageAsReadOutput(BaseModel):
	"""标记消息为已读输出"""

	pass
