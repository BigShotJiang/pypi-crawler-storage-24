from typing import Literal

from pydantic import BaseModel

from milky_types.group import GroupEntity, GroupMemberEntity
from milky_types.scalar import t_int32, t_int64, t_list, t_str
from milky_types.user import FriendEntity

__all__ = [
	'GetLoginInfoOutput',
	'GetImplInfoOutput',
	'GetUserProfileOutput',
	'GetFriendListOutput',
	'GetFriendInfoOutput',
	'GetGroupListOutput',
	'GetGroupInfoOutput',
	'GetGroupMemberListOutput',
	'GetGroupMemberInfoOutput',
	'SetAvatarOutput',
	'SetNicknameOutput',
	'SetBioOutput',
	'GetCustomFaceUrlListOutput',
	'GetCookiesOutput',
	'GetCsrfTokenOutput',
]


class GetLoginInfoOutput(BaseModel):
	"""获取登录信息输出"""

	uin: int = t_int64('登录 QQ 号')
	nickname: str = t_str('登录昵称')


class GetImplInfoOutput(BaseModel):
	"""获取协议端信息输出"""

	impl_name: str = t_str('协议端名称')
	impl_version: str = t_str('协议端版本')
	qq_protocol_version: str = t_str('协议端使用的 QQ 协议版本')
	qq_protocol_type: Literal[
		'windows',
		'linux',
		'macos',
		'android_pad',
		'android_phone',
		'ipad',
		'iphone',
		'harmony',
		'watch',
	] = t_str(
		'协议端使用的 QQ 协议平台，可能值：windows linux macos android_pad android_phone ipad iphone harmony watch'
	)
	milky_version: str = t_str('协议端实现的 Milky 协议版本，目前为 "1.1"')


class GetUserProfileOutput(BaseModel):
	"""获取用户个人信息输出"""

	nickname: str = t_str('昵称')
	qid: str = t_str('QID')
	age: int = t_int32('年龄')
	sex: Literal['male', 'female', 'unknown'] = t_str('性别')
	remark: str = t_str('备注')
	bio: str = t_str('个性签名')
	level: int = t_int32('QQ 等级')
	country: str = t_str('国家或地区')
	city: str = t_str('城市')
	school: str = t_str('学校')


class GetFriendListOutput(BaseModel):
	"""获取好友列表输出"""

	friends: list[FriendEntity] = t_list('好友列表')


class GetFriendInfoOutput(BaseModel):
	"""获取好友信息输出"""

	friend: FriendEntity = t_str('好友信息')


class GetGroupListOutput(BaseModel):
	"""获取群列表输出"""

	groups: list[GroupEntity] = t_list('群列表')


class GetGroupInfoOutput(BaseModel):
	"""获取群信息输出"""

	group: GroupEntity = t_str('群信息')


class GetGroupMemberListOutput(BaseModel):
	"""获取群成员列表输出"""

	members: list[GroupMemberEntity] = t_list('群成员列表')


class GetGroupMemberInfoOutput(BaseModel):
	"""获取群成员信息输出"""

	member: GroupMemberEntity = t_str('群成员信息')


class SetAvatarOutput(BaseModel):
	"""设置 QQ 账号头像输出"""

	pass


class SetNicknameOutput(BaseModel):
	"""设置 QQ 账号昵称输出"""

	pass


class SetBioOutput(BaseModel):
	"""设置 QQ 账号个性签名输出"""

	pass


class GetCustomFaceUrlListOutput(BaseModel):
	"""获取自定义表情 URL 列表输出"""

	urls: list[str] = t_list('自定义表情 URL 列表')


class GetCookiesOutput(BaseModel):
	"""获取 Cookies 输出"""

	cookies: str = t_str('域名对应的 Cookies 字符串')


class GetCsrfTokenOutput(BaseModel):
	"""获取 CSRF Token 输出"""

	csrf_token: str = t_str('CSRF Token')
