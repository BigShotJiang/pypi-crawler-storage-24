from pydantic import BaseModel

from milky_types.group import (
	GroupAnnouncementEntity,
	GroupEssenceMessage,
	GroupNotification,
)
from milky_types.scalar import t_bool, t_int64, t_list

__all__ = [
	'SetGroupNameOutput',
	'SetGroupAvatarOutput',
	'SetGroupMemberCardOutput',
	'SetGroupMemberSpecialTitleOutput',
	'SetGroupMemberAdminOutput',
	'SetGroupMemberMuteOutput',
	'SetGroupWholeMuteOutput',
	'KickGroupMemberOutput',
	'GetGroupAnnouncementsOutput',
	'SendGroupAnnouncementOutput',
	'DeleteGroupAnnouncementOutput',
	'GetGroupEssenceMessagesOutput',
	'SetGroupEssenceMessageOutput',
	'QuitGroupOutput',
	'SendGroupMessageReactionOutput',
	'SendGroupNudgeOutput',
	'GetGroupNotificationsOutput',
	'AcceptGroupRequestOutput',
	'RejectGroupRequestOutput',
	'AcceptGroupInvitationOutput',
	'RejectGroupInvitationOutput',
]


class SetGroupNameOutput(BaseModel):
	"""设置群名称输出"""

	pass


class SetGroupAvatarOutput(BaseModel):
	"""设置群头像输出"""

	pass


class SetGroupMemberCardOutput(BaseModel):
	"""设置群名片输出"""

	pass


class SetGroupMemberSpecialTitleOutput(BaseModel):
	"""设置群成员专属头衔输出"""

	pass


class SetGroupMemberAdminOutput(BaseModel):
	"""设置群管理员输出"""

	pass


class SetGroupMemberMuteOutput(BaseModel):
	"""设置群成员禁言输出"""

	pass


class SetGroupWholeMuteOutput(BaseModel):
	"""设置群全员禁言输出"""

	pass


class KickGroupMemberOutput(BaseModel):
	"""踢出群成员输出"""

	pass


class GetGroupAnnouncementsOutput(BaseModel):
	"""获取群公告列表输出"""

	announcements: list[GroupAnnouncementEntity] = t_list('群公告列表')


class SendGroupAnnouncementOutput(BaseModel):
	"""发送群公告输出"""

	pass


class DeleteGroupAnnouncementOutput(BaseModel):
	"""删除群公告输出"""

	pass


class GetGroupEssenceMessagesOutput(BaseModel):
	"""获取群精华消息列表输出"""

	messages: list[GroupEssenceMessage] = t_list('精华消息列表')
	is_end: bool = t_bool('是否已到最后一页')


class SetGroupEssenceMessageOutput(BaseModel):
	"""设置群精华消息输出"""

	pass


class QuitGroupOutput(BaseModel):
	"""退出群输出"""

	pass


class SendGroupMessageReactionOutput(BaseModel):
	"""发送群消息表情回应输出"""

	pass


class SendGroupNudgeOutput(BaseModel):
	"""发送群戳一戳输出"""

	pass


class GetGroupNotificationsOutput(BaseModel):
	"""获取群通知列表输出"""

	notifications: list[GroupNotification] = t_list(
		'获取到的群通知（notification_seq 降序排列），序列号不一定连续'
	)
	next_notification_seq: int | None = t_int64('下一页起始通知序列号', default=None)


class AcceptGroupRequestOutput(BaseModel):
	"""同意入群/邀请他人入群请求输出"""

	pass


class RejectGroupRequestOutput(BaseModel):
	"""拒绝入群/邀请他人入群请求输出"""

	pass


class AcceptGroupInvitationOutput(BaseModel):
	"""同意他人邀请自身入群输出"""

	pass


class RejectGroupInvitationOutput(BaseModel):
	"""拒绝他人邀请自身入群输出"""

	pass
