from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from milky_types.scalar import t_bool, t_int32, t_int64, t_list, t_object, t_str

__all__ = [
	'IncomingSegmentTextData',
	'IncomingSegmentText',
	'IncomingSegmentMentionData',
	'IncomingSegmentMention',
	'IncomingSegmentMentionAllData',
	'IncomingSegmentMentionAll',
	'IncomingSegmentFaceData',
	'IncomingSegmentFace',
	'IncomingSegmentReplyData',
	'IncomingSegmentReply',
	'IncomingSegmentImageData',
	'IncomingSegmentImage',
	'IncomingSegmentRecordData',
	'IncomingSegmentRecord',
	'IncomingSegmentVideoData',
	'IncomingSegmentVideo',
	'IncomingSegmentForwardData',
	'IncomingSegmentForward',
	'IncomingSegmentMarketFaceData',
	'IncomingSegmentMarketFace',
	'IncomingSegmentLightAppData',
	'IncomingSegmentLightApp',
	'IncomingSegmentXmlData',
	'IncomingSegmentXml',
	'IncomingSegment',
]


class IncomingSegmentTextData(BaseModel):
	text: str = t_str('文本内容')


class IncomingSegmentText(BaseModel):
	type: Literal['text'] = t_str('类型区分字段')
	data: IncomingSegmentTextData = t_object('文本消息段')


class IncomingSegmentMentionData(BaseModel):
	user_id: int = t_int64('提及的 QQ 号')


class IncomingSegmentMention(BaseModel):
	type: Literal['mention'] = t_str('类型区分字段')
	data: IncomingSegmentMentionData = t_object('提及消息段')


class IncomingSegmentMentionAllData(BaseModel):
	pass


class IncomingSegmentMentionAll(BaseModel):
	type: Literal['mention_all'] = t_str('类型区分字段')
	data: IncomingSegmentMentionAllData = t_object('提及全体消息段')


class IncomingSegmentFaceData(BaseModel):
	face_id: str = t_str('表情 ID')
	is_large: bool = t_bool('是否为超级表情')


class IncomingSegmentFace(BaseModel):
	type: Literal['face'] = t_str('类型区分字段')
	data: IncomingSegmentFaceData = t_object('表情消息段')


class IncomingSegmentReplyData(BaseModel):
	message_seq: int = t_int64('被引用的消息序列号')


class IncomingSegmentReply(BaseModel):
	type: Literal['reply'] = t_str('类型区分字段')
	data: IncomingSegmentReplyData = t_object('回复消息段')


class IncomingSegmentImageData(BaseModel):
	resource_id: str = t_str('资源 ID')
	temp_url: str = t_str('临时 URL')
	width: int = t_int32('图片宽度')
	height: int = t_int32('图片高度')
	summary: str = t_str('图片预览文本')
	sub_type: Literal['normal', 'sticker'] = t_str('图片类型')


class IncomingSegmentImage(BaseModel):
	type: Literal['image'] = t_str('类型区分字段')
	data: IncomingSegmentImageData = t_object('图片消息段')


class IncomingSegmentRecordData(BaseModel):
	resource_id: str = t_str('资源 ID')
	temp_url: str = t_str('临时 URL')
	duration: int = t_int32('语音时长（秒）')


class IncomingSegmentRecord(BaseModel):
	type: Literal['record'] = t_str('类型区分字段')
	data: IncomingSegmentRecordData = t_object('语音消息段')


class IncomingSegmentVideoData(BaseModel):
	resource_id: str = t_str('资源 ID')
	temp_url: str = t_str('临时 URL')
	width: int = t_int32('视频宽度')
	height: int = t_int32('视频高度')
	duration: int = t_int32('视频时长（秒）')


class IncomingSegmentVideo(BaseModel):
	type: Literal['video'] = t_str('类型区分字段')
	data: IncomingSegmentVideoData = t_object('视频消息段')


class IncomingSegmentFileData(BaseModel):
	file_id: str = t_str('文件 ID')
	file_name: str = t_str('文件名称')
	file_size: int = t_int64('文件大小（字节）')
	file_hash: str | None = t_str('文件的 TriSHA1 哈希值', default=None)


class IncomingSegmentFile(BaseModel):
	type: Literal['file'] = t_str('类型区分字段')
	data: IncomingSegmentFileData = t_object('文件消息段')


class IncomingSegmentForwardData(BaseModel):
	forward_id: str = t_str('合并转发 ID')
	title: str = t_str('合并转发标题')
	preview: list[str] = t_list('合并转发预览文本')
	summary: str = t_str('合并转发摘要')


class IncomingSegmentForward(BaseModel):
	type: Literal['forward'] = t_str('类型区分字段')
	data: IncomingSegmentForwardData = t_object('合并转发消息段')


class IncomingSegmentMarketFaceData(BaseModel):
	emoji_package_id: int = t_int32('市场表情包 ID')
	emoji_id: str = t_str('市场表情 ID')
	key: str = t_str('市场表情 Key')
	summary: str = t_str('市场表情预览文本')
	url: str = t_str('市场表情 URL')


class IncomingSegmentMarketFace(BaseModel):
	type: Literal['market_face'] = t_str('类型区分字段')
	data: IncomingSegmentMarketFaceData = t_object('市场表情消息段')


class IncomingSegmentLightAppData(BaseModel):
	app_name: str = t_str('小程序名称')
	json_payload: str = t_str('小程序 JSON 数据')


class IncomingSegmentLightApp(BaseModel):
	type: Literal['light_app'] = t_str('类型区分字段')
	data: IncomingSegmentLightAppData = t_object('小程序消息段')


class IncomingSegmentXmlData(BaseModel):
	service_id: int = t_int32('服务 ID')
	xml_payload: str = t_str('XML 数据')


class IncomingSegmentXml(BaseModel):
	type: Literal['xml'] = t_str('类型区分字段')
	data: IncomingSegmentXmlData = t_object('XML 消息段')


IncomingSegment = Annotated[
	Union[
		IncomingSegmentText,
		IncomingSegmentMention,
		IncomingSegmentMentionAll,
		IncomingSegmentFace,
		IncomingSegmentReply,
		IncomingSegmentImage,
		IncomingSegmentRecord,
		IncomingSegmentVideo,
		IncomingSegmentFile,
		IncomingSegmentForward,
		IncomingSegmentMarketFace,
		IncomingSegmentLightApp,
		IncomingSegmentXml,
	],
	Field(discriminator='type', description='接收消息段'),
]
