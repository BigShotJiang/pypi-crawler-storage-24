from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from milky_types.group import GroupEntity, GroupMemberEntity
from milky_types.scalar import t_int64, t_list, t_object, t_str
from milky_types.user import FriendEntity

from .segment import IncomingSegment

__all__ = [
	'IncomingForwardedMessage',
	'FriendIncomingMessage',
	'GroupIncomingMessage',
	'TempIncomingMessage',
	'IncomingMessage',
]


class IncomingForwardedMessage(BaseModel):
	sender_name: str = t_str('发送者名称')
	avatar_url: str = t_str('发送者头像 URL')
	time: int = t_str('消息 Unix 时间戳（秒）')
	segments: list[IncomingSegment] = t_list('消息段列表')


class FriendIncomingMessage(BaseModel):
	message_scene: Literal['friend'] = t_str('固定值 friend，表示好友消息')
	peer_id: int = t_int64('好友 QQ 号或群号')
	message_seq: int = t_int64('消息序列号')
	sender_id: int = t_int64('发送者 QQ 号')
	time: int = t_int64('消息 Unix 时间戳（秒）')
	segments: list[IncomingSegment] = t_list('消息段列表')
	friend: FriendEntity = t_object('好友信息')


class GroupIncomingMessage(BaseModel):
	message_scene: Literal['group'] = t_str('固定值 group，表示群消息')
	peer_id: int = t_int64('好友 QQ 号或群号')
	message_seq: int = t_int64('消息序列号')
	sender_id: int = t_int64('发送者 QQ 号')
	time: int = t_int64('消息 Unix 时间戳（秒）')
	segments: list[IncomingSegment] = t_list('消息段列表')
	group: GroupEntity = t_object('群信息')
	group_member: GroupMemberEntity = t_object('群成员信息')


class TempIncomingMessage(BaseModel):
	message_scene: Literal['temp'] = t_str('固定值 temp，表示临时会话消息')
	peer_id: int = t_int64('好友 QQ 号或群号')
	message_seq: int = t_int64('消息序列号')
	sender_id: int = t_int64('发送者 QQ 号')
	time: int = t_int64('消息 Unix 时间戳（秒）')
	segments: list[IncomingSegment] = t_list('消息段列表')
	group: GroupEntity | None = t_object('临时会话发送者的所在的群信息', default=None)


IncomingMessage = Annotated[
	Union[
		FriendIncomingMessage,
		GroupIncomingMessage,
		TempIncomingMessage,
	],
	Field(discriminator='message_scene', description='接收消息'),
]
