from typing import TYPE_CHECKING, Annotated, Literal, Union

from pydantic import BaseModel, Field

from milky_types.scalar import t_bool, t_int64, t_list, t_object, t_str

if TYPE_CHECKING:
	from .message import OutgoingForwardedMessage

__all__ = [
	'OutgoingSegmentTextData',
	'OutgoingSegmentText',
	'OutgoingSegmentMentionData',
	'OutgoingSegmentMention',
	'OutgoingSegmentMentionAllData',
	'OutgoingSegmentMentionAll',
	'OutgoingSegmentFaceData',
	'OutgoingSegmentFace',
	'OutgoingSegmentReplyData',
	'OutgoingSegmentReply',
	'OutgoingSegmentImageData',
	'OutgoingSegmentImage',
	'OutgoingSegmentRecordData',
	'OutgoingSegmentRecord',
	'OutgoingSegmentVideoData',
	'OutgoingSegmentVideo',
	'OutgoingSegmentForwardData',
	'OutgoingSegmentForward',
	'OutgoingSegment',
]


class OutgoingSegmentTextData(BaseModel):
	text: str = t_str('文本内容')


class OutgoingSegmentText(BaseModel):
	type: Literal['text'] = t_str('类型区分字段')
	data: OutgoingSegmentTextData = t_object('文本消息段')


class OutgoingSegmentMentionData(BaseModel):
	user_id: int = t_int64('提及的 QQ 号')


class OutgoingSegmentMention(BaseModel):
	type: Literal['mention'] = t_str('类型区分字段')
	data: OutgoingSegmentMentionData = t_object('提及消息段')


class OutgoingSegmentMentionAllData(BaseModel):
	pass


class OutgoingSegmentMentionAll(BaseModel):
	type: Literal['mention_all'] = t_str('类型区分字段')
	data: OutgoingSegmentMentionAllData = t_object('提及全体消息段')


class OutgoingSegmentFaceData(BaseModel):
	face_id: str = t_str('表情 ID')
	is_large: bool = t_bool('是否为超级表情', default=False)


class OutgoingSegmentFace(BaseModel):
	type: Literal['face'] = t_str('类型区分字段')
	data: OutgoingSegmentFaceData = t_object('表情消息段')


class OutgoingSegmentReplyData(BaseModel):
	message_seq: int = t_int64('被引用的消息序列号')


class OutgoingSegmentReply(BaseModel):
	type: Literal['reply'] = t_str('类型区分字段')
	data: OutgoingSegmentReplyData = t_object('回复消息段')


class OutgoingSegmentImageData(BaseModel):
	uri: str = t_str('文件 URI，支持 file:// http(s):// base64:// 三种格式')
	sub_type: Literal['normal', 'sticker'] = t_str('图片类型', default='normal')
	summary: str | None = t_str('图片预览文本', default=None)


class OutgoingSegmentImage(BaseModel):
	type: Literal['image'] = t_str('类型区分字段')
	data: OutgoingSegmentImageData = t_object('图片消息段')


class OutgoingSegmentRecordData(BaseModel):
	uri: str = t_str('文件 URI，支持 file:// http(s):// base64:// 三种格式')


class OutgoingSegmentRecord(BaseModel):
	type: Literal['record'] = t_str('类型区分字段')
	data: OutgoingSegmentRecordData = t_object('语音消息段')


class OutgoingSegmentVideoData(BaseModel):
	uri: str = t_str('文件 URI，支持 file:// http(s):// base64:// 三种格式')
	thumb_uri: str | None = t_str('封面图片 URI', default=None)


class OutgoingSegmentVideo(BaseModel):
	type: Literal['video'] = t_str('类型区分字段')
	data: OutgoingSegmentVideoData = t_object('视频消息段')


class OutgoingSegmentForwardData(BaseModel):
	messages: list['OutgoingForwardedMessage'] = t_list('合并转发消息段')


class OutgoingSegmentForward(BaseModel):
	type: Literal['forward'] = t_str('类型区分字段')
	data: OutgoingSegmentForwardData = t_object('合并转发消息段')


OutgoingSegment = Annotated[
	Union[
		OutgoingSegmentText,
		OutgoingSegmentMention,
		OutgoingSegmentMentionAll,
		OutgoingSegmentFace,
		OutgoingSegmentReply,
		OutgoingSegmentImage,
		OutgoingSegmentRecord,
		OutgoingSegmentVideo,
		OutgoingSegmentForward,
	],
	Field(discriminator='type', description='发送消息段'),
]
