from pydantic import BaseModel

from milky_types.scalar import t_int64, t_list, t_str

from .segment import OutgoingSegment

__all__ = ['OutgoingForwardedMessage']


class OutgoingForwardedMessage(BaseModel):
	user_id: int = t_int64('发送者 QQ 号')
	sender_name: str = t_str('发送者名称')
	segments: list[OutgoingSegment] = t_list('消息段列表')
