from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from milky_types.scalar import t_bool, t_int32, t_int64, t_str

__all__ = [
	'GroupEntity',
	'GroupMemberEntity',
	'GroupAnnouncementEntity',
	'GroupFileEntity',
	'GroupFolderEntity',
	'GroupEssenceMessage',
	'GroupJoinRequestNotification',
	'GroupAdminChangeNotification',
	'GroupKickNotification',
	'GroupQuitNotification',
	'GroupInvitedJoinRequestNotification',
	'GroupNotification',
]


class GroupEntity(BaseModel):
	group_id: int = t_int64('群号')
	group_name: str = t_str('群名称')
	member_count: int = t_int32('群成员数量')
	max_member_count: int = t_int32('群容量')


class GroupMemberEntity(BaseModel):
	user_id: int = t_int64('用户 QQ 号')
	nickname: str = t_str('用户昵称')
	sex: Literal['male', 'female', 'unknown'] = t_str('用户性别')
	group_id: int = t_int64('群号')
	card: str = t_str('成员备注')
	title: str = t_str('专属头衔')
	level: int = t_int32('群等级')
	role: Literal['owner', 'admin', 'member'] = t_str('权限等级')
	join_time: int = t_int64('入群时间，Unix 时间戳（秒）')
	last_sent_time: int = t_int64('最后发言时间，Unix 时间戳（秒）')
	shut_up_end_time: int | None = t_int64(
		'禁言结束时间，Unix 时间戳（秒）', default=None
	)


class GroupAnnouncementEntity(BaseModel):
	group_id: int = t_int64('群号')
	announcement_id: str = t_str('公告 ID')
	user_id: int = t_int64('发送者 QQ 号')
	time: int = t_int64('Unix 时间戳（秒）')
	content: str = t_str('公告内容')
	image_url: str | None = t_str('公告图片 URL', default=None)


class GroupFileEntity(BaseModel):
	group_id: int = t_int64('群号')
	file_id: str = t_str('文件 ID')
	file_name: str = t_str('文件名称')
	parent_folder_id: str = t_str('父文件夹 ID')
	file_size: int = t_int64('文件大小（字节）')
	uploaded_time: int = t_int64('上传时的 Unix 时间戳（秒）')
	expire_time: int | None = t_int64('过期时的 Unix 时间戳（秒）', default=None)
	uploader_id: int = t_int64('上传者 QQ 号')
	downloaded_times: int = t_int32('下载次数')


class GroupFolderEntity(BaseModel):
	group_id: int = t_int64('群号')
	folder_id: str = t_str('文件夹 ID')
	parent_folder_id: str = t_str('父文件夹 ID')
	folder_name: str = t_str('文件夹名称')
	created_time: int = t_int64('创建时的 Unix 时间戳（秒）')
	last_modified_time: int = t_int64('最后修改时的 Unix 时间戳（秒）')
	creator_id: int = t_int64('创建者 QQ 号')
	file_count: int = t_int32('文件数量')


class GroupEssenceMessage(BaseModel):
	"""精华消息"""

	group_id: int = t_int64('群号')
	message_seq: int = t_int64('消息序列号')
	operator_id: int = t_int64('操作者 QQ 号')
	sender_id: int = t_int64('发送者 QQ 号')
	sender_nickname: str = t_str('发送者昵称')
	time: int = t_int64('加入精华的时间，Unix 时间戳（秒）')


class GroupJoinRequestNotification(BaseModel):
	type: Literal['join_request'] = t_str('用户入群请求')
	group_id: int = t_int64('群号')
	notification_seq: int = t_int64('通知序列号')
	is_filtered: bool = t_bool('请求是否被过滤（发起自风险账户）')
	initiator_id: int = t_int64('发起者 QQ 号')
	state: Literal['pending', 'accepted', 'rejected', 'ignored'] = t_str('请求状态')
	operator_id: int | None = t_int64('处理请求的管理员 QQ 号', default=None)
	comment: str = t_str('入群请求附加信息')


class GroupAdminChangeNotification(BaseModel):
	type: Literal['admin_change'] = t_str('群管理员变更通知')
	group_id: int = t_int64('群号')
	notification_seq: int = t_int64('通知序列号')
	target_user_id: int = t_int64('被设置/取消用户 QQ 号')
	is_set: bool = t_bool('是否被设置为管理员')
	operator_id: int = t_int64('操作者（群主）QQ 号')


class GroupKickNotification(BaseModel):
	type: Literal['kick'] = t_str('群成员被移除通知')
	group_id: int = t_int64('群号')
	notification_seq: int = t_int64('通知序列号')
	target_user_id: int = t_int64('被移除用户 QQ 号')
	operator_id: int = t_int64('移除用户的管理员 QQ 号')


class GroupQuitNotification(BaseModel):
	type: Literal['quit'] = t_str('群成员退群通知')
	group_id: int = t_int64('群号')
	notification_seq: int = t_int64('通知序列号')
	target_user_id: int = t_int64('退群用户 QQ 号')


class GroupInvitedJoinRequestNotification(BaseModel):
	type: Literal['invited_join_request'] = t_str('群成员邀请他人入群请求')
	group_id: int = t_int64('群号')
	notification_seq: int = t_int64('通知序列号')
	initiator_id: int = t_int64('邀请者 QQ 号')
	target_user_id: int = t_int64('被邀请用户 QQ 号')
	state: Literal['pending', 'accepted', 'rejected', 'ignored'] = t_str('请求状态')
	operator_id: int | None = t_int64('处理请求的管理员 QQ 号', default=None)


GroupNotification = Annotated[
	Union[
		GroupJoinRequestNotification,
		GroupAdminChangeNotification,
		GroupKickNotification,
		GroupQuitNotification,
		GroupInvitedJoinRequestNotification,
	],
	Field(discriminator='type', description='群通知实体'),
]
