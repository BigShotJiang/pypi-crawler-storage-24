# Py Milky Types

这是 Milky 协议的 Python 类型定义包，使用 Pydantic2 进行运行时类型验证。

# 快速上手

```shell
pip install py-milky-types
```

```python
from milky_types import *

data = GetLoginInfoOutput.model_validate(response_data)
```

# 目录结构

```text
milky_types/
├── api/                # API 输入输出定义
│   ├── input/          # API 请求参数模型
│   └── output/         # API 响应数据模型
├── message/            # 消息段与消息模型
│   ├── incoming/       # 入站消息定义
│   └── outgoing/       # 出站消息定义
├── event.py            # 事件类型定义
├── group.py            # 群组相关模型
└── user.py             # 用户相关模型
```

你可以按需导入所需要的模型