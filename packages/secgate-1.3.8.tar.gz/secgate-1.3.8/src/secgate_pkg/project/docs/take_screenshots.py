"""截取 SecGate Dashboard 核心功能截图"""
import time
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:5000"
USER = "admin"
PASSWORD = "Sec@2026!"
OUT = "/root/pj226/docs/screenshots"


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        context = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=2,
            http_credentials={"username": USER, "password": PASSWORD},
        )
        page = context.new_page()

        # 1. 安全看板 - 攻击态势总览
        print("[1/5] 安全看板 - 攻击态势总览")
        page.goto(f"{BASE}/services")
        time.sleep(3)
        # 点击安全看板标签
        page.click('text=安全看板')
        time.sleep(4)
        page.screenshot(path=f"{OUT}/dashboard-overview.png", full_page=False)

        # 2. 服务管理 - 端口保护
        print("[2/5] 服务管理 - 端口认证网关")
        page.click('text=服务管理')
        time.sleep(4)
        page.screenshot(path=f"{OUT}/service-management.png", full_page=False)

        # 3. 网关认证
        print("[3/5] 网关认证管理")
        page.click('text=网关认证')
        time.sleep(4)
        page.screenshot(path=f"{OUT}/gateway-auth.png", full_page=False)

        # 4. 安全扫描
        print("[4/5] 安全扫描")
        page.click('text=安全扫描')
        time.sleep(4)
        page.screenshot(path=f"{OUT}/security-scan.png", full_page=False)

        # 5. AI 安全
        print("[5/5] AI 安全")
        page.click('text=AI 安全')
        time.sleep(4)
        page.screenshot(path=f"{OUT}/ai-security.png", full_page=False)

        browser.close()
        print(f"\n截图完成，保存在 {OUT}/")


if __name__ == "__main__":
    main()
