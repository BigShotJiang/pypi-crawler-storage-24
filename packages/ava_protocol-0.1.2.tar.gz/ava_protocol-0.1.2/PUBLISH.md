# Publishing AVA to PyPI

This guide covers publishing `ava-protocol` to the Python Package Index (PyPI).

## Authors

- Gerald Enrique Nelson Mc Kenzie (https://github.com/lordxmen2k)

## Date

- 3/13/2026

---

## 📋 Prerequisites

1. **PyPI Account**: Register at [pypi.org/account/register](https://pypi.org/account/register/)
2. **API Token**: Create at [pypi.org/manage/account/token](https://pypi.org/manage/account/token/)
   - Select "Entire account" scope (or project-specific if available)
   - Copy the token immediately (shown only once)

---

## 🚀 Quick Publish (First Time)

### 1. Install Build Tools

```bash
pip install build twine
```

### 2. Configure Credentials

**Option A: Environment Variable (Recommended for CI)**
```bash
export PYPI_API_TOKEN="pypi-AgEIcHlwaS5vcmcCJD..."
```

**Option B: Config File ( ~/.pypirc )**
```ini
[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJD...
```

### 3. Build the Package

```bash
cd ava-protocol
python -m build
```

This creates:
```
dist/
├── ava_protocol-0.1.0-py3-none-any.whl
└── ava_protocol-0.1.0.tar.gz
```

### 4. Test on TestPyPI First

```bash
# Upload to test server
python -m twine upload --repository testpypi dist/*

# Verify installation
pip install --index-url https://test.pypi.org/simple/ ava-protocol
```

### 5. Publish to Production PyPI

```bash
# Upload to real PyPI (PERMANENT!)
python -m twine upload dist/*
```

**Note**: PyPI packages are **immutable**. You cannot overwrite version 0.1.0. You must bump the version in `pyproject.toml` for subsequent releases.

---

## 🔧 Version Management

### Semantic Versioning

Follow [SemVer](https://semver.org/):
- `0.1.0` → `0.2.0` (new features, backwards compatible)
- `0.2.0` → `0.2.1` (bug fixes only)
- `0.2.1` → `1.0.0` (breaking changes)

### Bumping Version

Edit `pyproject.toml`:
```toml
[project]
version = "0.2.0"  # ← Change this
```

Or use `hatch`:
```bash
pip install hatch
hatch version patch   # 0.1.0 → 0.1.1
hatch version minor   # 0.1.0 → 0.2.0
hatch version major   # 0.1.0 → 1.0.0
```

---

## 🔄 Continuous Deployment (GitHub Actions)

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]  # Trigger on GitHub Release
  workflow_dispatch:    # Or manual trigger

jobs:
  build-and-publish:
    runs-on: ubuntu-latest
    permissions:
      id-token: write  # For OIDC trusted publishing

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install build tools
        run: pip install build

      - name: Build package
        run: python -m build

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        # For API token auth (legacy):
        # with:
        #   password: ${{ secrets.PYPI_API_TOKEN }}
```

### Setting Up Trusted Publishing (Recommended)

Instead of API tokens, use OIDC (more secure):

1. Go to [pypi.org/manage/account/publishing](https://pypi.org/manage/account/publishing/)
2. Add a new pending publisher:
   - **PyPI Project Name**: `ava-protocol`
   - **Owner**: `ava-protocol` (your GitHub org/user)
   - **Repository name**: `ava-protocol`
   - **Workflow name**: `publish.yml`
   - **Environment name**: `pypi` (optional but recommended)

3. Create GitHub Environment (optional security):
   - Repository → Settings → Environments → New environment
   - Name: `pypi`
   - Add protection rules (required reviewers, wait timer)

---

## ✅ Pre-Publish Checklist

Before every release:

- [ ] Version bumped in `pyproject.toml`
- [ ] `CHANGELOG.md` updated
- [ ] All tests pass: `pytest`
- [ ] Linting passes: `black src/` and `ruff check src/`
- [ ] README reflects current features
- [ ] `dist/` directory cleaned: `rm -rf dist/`
- [ ] Build succeeds: `python -m build`
- [ ] TestPyPI upload works
- [ ] Test install works: `pip install --index-url https://test.pypi.org/simple/ ava-protocol`

---

## 🐛 Troubleshooting

### "File already exists" Error
```
HTTPError: 400 Bad Request from https://upload.pypi.org/legacy/
File already exists. See https://pypi.org/help/#file-name-reuse
```

**Solution**: Bump version in `pyproject.toml`. You cannot overwrite releases.

### "Invalid distribution file" Error
```
ERROR: Invalid distribution file
```

**Solution**: Clean and rebuild:
```bash
rm -rf dist/ build/ *.egg-info
python -m build
```

### Authentication Failed
```
HTTPError: 403 Forbidden from https://upload.pypi.org/legacy/
Invalid or non-existent authentication information.
```

**Solution**: 
- Verify API token format: `pypi-AgEIcHlwaS5vcmc...`
- Username is literally `__token__`
- Password is the token itself

### Package Name Taken
```
HTTPError: 403 The name 'ava-protocol' isn't allowed
```

**Solution**: Choose a different name. Check availability:
```bash
pip search ava-protocol  # Deprecated, use pypi.org directly
# Or visit: https://pypi.org/project/ava-protocol/
```

### Large File Warning (>100MB)
```
ERROR: Maximum allowed package size is 100MB
```

**Solution**: 
- Presidio models are large (~50MB). They're optional dependencies.
- Don't bundle models in wheel.
- Users download models separately: `python -m spacy download en_core_web_lg`

---

## 📦 Post-Publication

After successful publish:

1. **Verify on PyPI**: https://pypi.org/project/ava-protocol/
2. **Test installation**: `pip install ava-protocol`
3. **Update documentation**: Deploy to ReadTheDocs
4. **Announce**: GitHub Releases, Twitter, Discord, etc.

---

## 🎯 Release Commands Cheat Sheet

```bash
# Full manual release flow
cd ava-protocol
rm -rf dist/
python -m build
python -m twine upload --repository testpypi dist/*   # Test first
pip install --index-url https://test.pypi.org/simple/ --no-deps ava-protocol  # Verify
python -m twine upload dist/*                          # Real release

# Or with hatch (if using)
hatch build
hatch publish -u __token__ -a $PYPI_API_TOKEN

# Or with flit (alternative)
flit build
flit publish
```

---

## 🔗 Useful Links

- **PyPI**: https://pypi.org/
- **TestPyPI**: https://test.pypi.org/
- **Python Packaging Guide**: https://packaging.python.org/
- **Hatch Documentation**: https://hatch.pypa.io/
- **Twine Documentation**: https://twine.readthedocs.io/

---

**Happy Publishing!** 🚀
