"""Tests for detection engines"""
import pytest
from ava.engines.base import MockEngine
from ava.protocol.entities import DetectedEntity

# Check if Presidio is actually available
try:
    import presidio_analyzer
    PRESIDIO_AVAILABLE = True
except ImportError:
    PRESIDIO_AVAILABLE = False


class TestMockEngine:
    def test_detect_email(self):
        engine = MockEngine()
        text = "Contact us at support@example.com for help"
        entities = engine.detect(text)

        assert len(entities) == 1
        assert entities[0].type == "EMAIL_ADDRESS"
        assert entities[0].value == "support@example.com"
        # "support@example.com" is 19 chars, starts at 14, ends at 33
        assert entities[0].position == (14, 33)

    def test_detect_ssn(self):
        engine = MockEngine()
        text = "My SSN is 123-45-6789"
        entities = engine.detect(text)

        assert len(entities) == 1
        assert entities[0].type == "SSN"
        assert entities[0].value == "123-45-6789"

    def test_detect_multiple(self):
        engine = MockEngine()
        text = "Email john@example.com or call 555-123-4567"
        entities = engine.detect(text)

        assert len(entities) == 2
        # Should be sorted by position
        assert entities[0].type == "EMAIL_ADDRESS"
        assert entities[1].type == "PHONE_NUMBER"

    def test_no_entities(self):
        engine = MockEngine()
        text = "This is just plain text with no PII"
        entities = engine.detect(text)

        assert len(entities) == 0


@pytest.mark.skipif(not PRESIDIO_AVAILABLE, reason="Presidio not installed")
class TestPresidioEngine:
    def test_presidio_detection(self):
        from ava.engines.presidio import PresidioEngine
        engine = PresidioEngine()

        text = "Patient John Doe lives at john.doe@example.com"
        entities = engine.detect(text)

        assert len(entities) >= 2
        types = [e.type for e in entities]
        assert "PERSON_NAME" in types
        assert "EMAIL_ADDRESS" in types
