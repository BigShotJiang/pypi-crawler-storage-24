# test_ava.py
import ava

print("=== AVA Protocol Quick Test ===\n")

# Test 1: Mock Engine (no dependencies)
print("1. Testing Mock Engine...")
client = ava.Client(engine="mock", policy="general_moderate")

with client.session(reversibility=True) as session:
    text = "Contact john@example.com or call 555-123-4567"
    print(f"   Original: {text}")

    clean = session.sanitize(text)
    print(f"   Sanitized: {clean}")

    restored = session.restore(clean)
    print(f"   Restored: {restored}")

    assert restored == text, "Restoration failed!"
    print("   ✓ Mock engine works!\n")

# Test 2: Config loading
print("2. Testing Configuration...")
config = ava.Config.from_dict({
    "mode": "embedded",
    "engine": "mock",
    "policy": "strict",
    "retention": 1800
})
client2 = ava.create_client(config)
print("   ✓ Config loading works!\n")

print("=== All tests passed! ===")