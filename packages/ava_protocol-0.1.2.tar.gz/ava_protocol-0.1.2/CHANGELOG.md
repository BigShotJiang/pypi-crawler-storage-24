# Changelog

## Authors

- Gerald Enrique Nelson Mc Kenzie (https://github.com/lordxmen2k)

## Date

- 3/13/2026

All notable changes to the AVA Protocol project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Core protocol layer with AVA Manifest format
- Pluggable detection engine architecture
- Microsoft Presidio engine adapter
- Mock engine for testing
- Memory-based and SQLite token vaults
- HTTP gateway client for remote AVA services
- Configuration management (env, YAML, dict)
- Context manager session interface

### Security
- Zero-retention token vault with configurable TTL
- Session-scoped token isolation
- Hash-only audit trails (no original values in manifests)

## [0.1.0] - 2025-03-13

### Added
- Initial release of AVA Protocol Python library
- Basic client interface with embedded and gateway modes
- PyPI package with optional dependencies: `[local]`, `[aws]`, `[all]`
- Complete documentation: README, PUBLISH guide
- CI/CD with GitHub Actions (test, build, publish)
- MIT License

---

[Unreleased]: https://github.com/ava-protocol/ava-protocol/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ava-protocol/ava-protocol/releases/tag/v0.1.0
