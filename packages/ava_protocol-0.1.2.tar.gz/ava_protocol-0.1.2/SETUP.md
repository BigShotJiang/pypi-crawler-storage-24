# Local Setup & Testing Guide (Windows)

This guide shows you how to test the AVA Protocol package on your Windows computer before publishing to PyPI.

## Authors

- Gerald Enrique Nelson Mc Kenzie (https://github.com/lordxmen2k)

## Date

- 3/13/2026

---

## ✅ Prerequisites

1. **Python 3.9 or higher** installed
   - Check: `python --version` or `py --version`
   - Download from https://python.org if needed

2. **Git** (optional, for version control)
   - Download from https://git-scm.com/download/win

---

## 📦 Step 1: Extract the Package

1. Right-click `ava-protocol-v0.1.0.zip` → **Extract All...**
2. Choose a location like `C:\Users\YourName\Projects\`
3. You should now have: `C:\Users\YourName\Projects\ava-protocol\`

Or using PowerShell:
```powershell
Expand-Archive -Path ava-protocol-v0.1.0.zip -DestinationPath C:\Users\$env:USERNAME\Projects
```

---

## 🌿 Step 2: Create Virtual Environment

Open **Command Prompt** or **PowerShell** and navigate to the package:

```cmd
cd C:\Users\YourName\Projects\ava-protocol
```

Create a virtual environment:

```cmd
python -m venv venv
```

Activate it:

```cmd
:: Command Prompt
venv\Scripts\activate.bat

:: PowerShell
venv\Scripts\Activate.ps1
```

You should see `(venv)` in your prompt:
```
(venv) C:\Users\YourName\Projects\ava-protocol>
```

---

## 📥 Step 3: Install AVA Protocol (Development Mode)

With the virtual environment activated:

```cmd
:: Install core + development tools
pip install -e ".[dev]"

:: OR install with local Presidio engine (recommended for testing)
pip install -e ".[local,dev]"
```

> **Note:** Installing `[local]` will download large ML models (~50MB).

---

## 🧪 Step 4: Run the Test Suite

```cmd
pytest
```

Expected output:
```
========================== test session starts ==========================
platform win32 -- Python 3.11.x, pytest-7.x.x, pluggy-1.x.x
rootdir: C:\Users\YourName\Projects\ava-protocol
collected 15 items

tests\test_protocol.py .................                           [ 80%]
tests\test_engines.py ....                                         [100%]

========================== 15 passed in 0.5s ============================
```

---

## ✋ Step 5: Manual Quick Test

Create a test file `test_ava.py`:

```python
# test_ava.py
import ava

print("=== AVA Protocol Quick Test ===\n")

# Test 1: Mock Engine (no dependencies)
print("1. Testing Mock Engine...")
client = ava.Client(engine="mock", policy="general_moderate")

with client.session(reversibility=True) as session:
    text = "Contact john@example.com or call 555-123-4567"
    print(f"   Original: {text}")

    clean = session.sanitize(text)
    print(f"   Sanitized: {clean}")

    restored = session.restore(clean)
    print(f"   Restored: {restored}")

    assert restored == text, "Restoration failed!"
    print("   ✓ Mock engine works!\n")

# Test 2: Config loading
print("2. Testing Configuration...")
config = ava.Config.from_dict({
    "mode": "embedded",
    "engine": "mock",
    "policy": "strict",
    "retention": 1800
})
client2 = ava.create_client(config)
print("   ✓ Config loading works!\n")

print("=== All tests passed! ===")
```

Run it:
```cmd
python test_ava.py
```

---

## 🔧 Step 6: Test Presidio Engine (Optional)

If you installed `[local]`, test the real PII detection:

```python
# test_presidio.py
import ava

print("Testing Presidio Engine...")

try:
    client = ava.Client(engine="presidio", policy="healthcare_strict")

    with client.session() as session:
        text = "Patient John Doe (john.doe@email.com) visited on March 13, 2025"
        print(f"Original: {text}")

        clean = session.sanitize(text)
        print(f"Sanitized: {clean}")

        # Get the manifest
        manifest = session.get_manifest()
        print(f"\nDetected {len(manifest.entities)} entities:")
        for entity in manifest.entities:
            print(f"  - {entity.type}: {entity.token}")

except ImportError as e:
    print(f"Presidio not installed: {e}")
    print("Run: pip install presidio-analyzer presidio-anonymizer")
```

---

## 🧹 Step 7: Clean Up (Before Publishing)

Before building for PyPI, clean build artifacts:

```cmd
:: Remove build directories
rmdir /s /q build dist *.egg-info

:: Or using Python
python -c "import shutil; shutil.rmtree('build', ignore_errors=True); shutil.rmtree('dist', ignore_errors=True); import glob; [shutil.rmtree(p, ignore_errors=True) for p in glob.glob('*.egg-info')]"
```

---

## 📦 Step 8: Build Package (Dry Run)

Test that the package builds correctly:

```cmd
pip install build
python -m build
```

You should see:
```
Successfully built ava-protocol-0.1.0.tar.gz and ava_protocol-0.1.0-py3-none-any.whl
```

Check the contents:
```cmd
dir dist
```

---

## ✅ Pre-Publish Checklist

Before uploading to PyPI, verify:

- [ ] All tests pass (`pytest`)
- [ ] Manual test script works
- [ ] Package builds (`python -m build`)
- [ ] No secrets in code (check for API keys, passwords)
- [ ] Version is correct in `pyproject.toml`
- [ ] README.md is up to date
- [ ] CHANGELOG.md has entry for this version

---

## 🐛 Windows Troubleshooting

### Issue: "'python' is not recognized"
**Fix:** Use `py` instead of `python`, or add Python to your PATH during installation.

### Issue: "cannot activate venv in PowerShell"
**Fix:** Run PowerShell as Administrator, or use Command Prompt instead.

### Issue: "Presidio model not found"
**Fix:** Download the spaCy model:
```cmd
python -m spacy download en_core_web_lg
```

### Issue: "Permission denied" during pip install
**Fix:** Make sure virtual environment is activated, or run as Administrator.

### Issue: Tests fail with import errors
**Fix:** Ensure you're in the project root and installed with `-e ".[dev]"`:
```cmd
cd C:\Users\YourName\Projects\ava-protocol
venv\Scripts\activate
pip install -e ".[dev]"
```

---

## 🚀 Ready to Publish?

Once everything works locally, follow **PUBLISH.md** for PyPI publication.

**Quick preview:**
```cmd
:: Test on TestPyPI first
python -m twine upload --repository testpypi dist/*

:: Then real PyPI
python -m twine upload dist/*
```

---

Happy testing! 🎉
