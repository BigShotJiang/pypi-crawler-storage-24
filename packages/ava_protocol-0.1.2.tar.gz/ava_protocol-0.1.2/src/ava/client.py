"""AVA Client - Main entry point for protocol operations"""
from __future__ import annotations
import os
from typing import Optional, Dict, Any, Union
from contextlib import contextmanager

from ava.config import Config
from ava.session import Session
from ava.protocol.token_vault import MemoryVault, TokenVault
from ava.protocol.manifest import AVAManifest


class Client:
    """Embedded AVA client with local detection engine."""

    def __init__(
        self,
        engine: str = "presidio",
        policy: str = "general_moderate",
        vault: Optional[TokenVault] = None,
        retention: int = 3600,
        config: Optional[Dict[str, Any]] = None
    ):
        self.engine_name = engine
        self.policy = policy
        self.retention = retention
        self.vault = vault or MemoryVault(ttl_seconds=retention)
        self._engine = None
        self.config = config or {}

        self._load_engine()

    def _load_engine(self):
        """Lazy-load detection engine."""
        if self._engine is not None:
            return

        if self.engine_name == "presidio":
            try:
                from ava.engines.presidio import PresidioEngine
                self._engine = PresidioEngine()
            except ImportError as e:
                raise ImportError(
                    "Presidio engine not available. "
                    "Install with: pip install ava-protocol[local]"
                ) from e
        elif self.engine_name == "mock":
            from ava.engines.base import MockEngine
            self._engine = MockEngine()
        else:
            raise ValueError(f"Unknown engine: {self.engine_name}")

    @contextmanager
    def session(self, reversibility: bool = True):
        """Create an AVA session for sanitize/restore operations."""
        session = Session(
            engine=self._engine,
            vault=self.vault,
            policy=self.policy,
            reversibility=reversibility
        )
        try:
            yield session
        finally:
            session.close()

    def sanitize(self, text: str) -> str:
        """One-shot sanitize (no session context)."""
        with self.session() as s:
            return s.sanitize(text)

    def close(self):
        """Cleanup resources."""
        if self.vault:
            self.vault.close()


class GatewayClient:
    """Client for remote AVA Gateway."""

    def __init__(
        self,
        url: str,
        api_key: Optional[str] = None,
        policy: str = "general_moderate",
        timeout: float = 30.0
    ):
        self.url = url.rstrip("/")
        self.api_key = api_key or os.getenv("AVA_API_KEY")
        self.policy = policy
        self.timeout = timeout
        self._session: Optional[Any] = None

    def _get_client(self):
        """Lazy init HTTP client."""
        if self._session is None:
            import httpx
            headers = {"X-AVA-Policy": self.policy}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            self._session = httpx.Client(
                base_url=self.url,
                headers=headers,
                timeout=self.timeout
            )
        return self._session

    @contextmanager
    def session(self, reversibility: bool = True):
        """Gateway-backed session."""
        from ava.gateways.http import GatewaySession
        s = GatewaySession(
            client=self._get_client(),
            policy=self.policy,
            reversibility=reversibility
        )
        try:
            yield s
        finally:
            s.close()

    def health(self) -> Dict[str, Any]:
        """Check gateway health and capabilities."""
        client = self._get_client()
        resp = client.get("/v1/health")
        resp.raise_for_status()
        return resp.json()

    def close(self):
        """Close HTTP session."""
        if self._session:
            self._session.close()


def create_client(config: Union[Config, Dict[str, Any], str, None] = None) -> Union[Client, GatewayClient]:
    """Factory function to create appropriate client from config."""
    if isinstance(config, str):
        config = Config.from_yaml(config)
    elif isinstance(config, dict):
        config = Config.from_dict(config)
    elif config is None:
        config = Config.from_env()

    if config.mode == "embedded":
        return Client(
            engine=config.engine,
            policy=config.policy,
            retention=config.retention
        )
    elif config.mode == "gateway":
        return GatewayClient(
            url=config.url,
            api_key=config.api_key,
            policy=config.policy
        )
    else:
        raise ValueError(f"Unknown mode: {config.mode}")
