"""AVA Protocol - AI Visibility Anonymizer"""

__version__ = "0.1.0"
__author__ = "AVA Team"
__license__ = "MIT"

from ava.client import Client, GatewayClient, create_client
from ava.config import Config
from ava.session import Session

try:
    from ava.engines.presidio import PresidioEngine
except ImportError:
    PresidioEngine = None

__all__ = [
    "Client",
    "GatewayClient", 
    "Config",
    "Session",
    "create_client",
    "PresidioEngine",
]
