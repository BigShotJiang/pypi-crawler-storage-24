"""AVA Configuration management"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import Dict, Any, Optional


@dataclass
class Config:
    """AVA client configuration."""
    mode: str = "embedded"  # embedded or gateway
    engine: str = "presidio"
    policy: str = "general_moderate"
    retention: int = 3600
    # Gateway mode
    url: Optional[str] = None
    api_key: Optional[str] = None
    # Extensions
    extensions: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls, prefix: str = "AVA_") -> Config:
        """Load config from environment variables."""
        mode = os.getenv(f"{prefix}MODE", "embedded").lower()

        config = cls(
            mode=mode,
            engine=os.getenv(f"{prefix}ENGINE", "presidio"),
            policy=os.getenv(f"{prefix}POLICY", "general_moderate"),
            retention=int(os.getenv(f"{prefix}RETENTION", "3600")),
        )

        if mode == "gateway":
            config.url = os.getenv(f"{prefix}GATEWAY_URL")
            config.api_key = os.getenv(f"{prefix}API_KEY")
            if not config.url:
                raise ValueError(f"{prefix}GATEWAY_URL required for gateway mode")

        return config

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Config:
        """Load config from dictionary."""
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    @classmethod
    def from_yaml(cls, path: str) -> Config:
        """Load config from YAML file."""
        import yaml
        with open(path) as f:
            return cls.from_dict(yaml.safe_load(f))
