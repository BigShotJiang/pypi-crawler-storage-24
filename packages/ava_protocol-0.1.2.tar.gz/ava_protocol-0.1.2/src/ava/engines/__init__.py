"""AVA Detection Engines"""
from ava.engines.base import DetectionEngine, MockEngine

try:
    from ava.engines.presidio import PresidioEngine
except ImportError:
    PresidioEngine = None

__all__ = ["DetectionEngine", "MockEngine", "PresidioEngine"]
