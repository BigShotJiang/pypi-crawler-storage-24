"""Base detection engine interface"""
from abc import ABC, abstractmethod
from typing import List, Optional
import re

from ava.protocol.entities import DetectedEntity


class DetectionEngine(ABC):
    """Abstract base for PII detection engines."""

    @abstractmethod
    def detect(self, text: str, policy: Optional[str] = None) -> List[DetectedEntity]:
        """Detect entities in text."""
        pass


class MockEngine(DetectionEngine):
    """Mock engine for testing - uses regex patterns."""

    PATTERNS = {
        "EMAIL_ADDRESS": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        "PHONE_NUMBER": r"\b\+?1?[-.]?\(?[0-9]{3}\)?[-.]?[0-9]{3}[-.]?[0-9]{4}\b",
        "SSN": r"\d{3}-\d{2}-\d{4}",
        "CREDIT_CARD": r"\b\d{4}[-]?\d{4}[-]?\d{4}[-]?\d{4}\b",
    }

    def detect(self, text: str, policy: Optional[str] = None) -> List[DetectedEntity]:
        entities = []

        for entity_type, pattern in self.PATTERNS.items():
            for match in re.finditer(pattern, text):
                entities.append(DetectedEntity(
                    type=entity_type,
                    value=match.group(),
                    position=(match.start(), match.end()),
                    confidence=0.95
                ))

        # Sort by position
        entities.sort(key=lambda e: e.position[0])
        return entities
