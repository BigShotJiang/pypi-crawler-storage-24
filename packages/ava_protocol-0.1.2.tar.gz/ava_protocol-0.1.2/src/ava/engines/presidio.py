"""Presidio-based detection engine"""
from typing import List, Optional, Dict

from ava.engines.base import DetectionEngine
from ava.protocol.entities import DetectedEntity


class PresidioEngine(DetectionEngine):
    """Microsoft Presidio-based entity detection."""

    # Map Presidio entities to AVA types
    ENTITY_MAP: Dict[str, str] = {
        "PERSON": "PERSON_NAME",
        "EMAIL_ADDRESS": "EMAIL_ADDRESS",
        "PHONE_NUMBER": "PHONE_NUMBER",
        "CREDIT_CARD": "CREDIT_CARD_NUMBER",
        "US_SSN": "SSN",
        "US_BANK_NUMBER": "BANK_ACCOUNT",
        "IBAN": "IBAN",
        "US_PASSPORT": "PASSPORT",
        "US_DRIVER_LICENSE": "DRIVER_LICENSE",
        "IP_ADDRESS": "IP_ADDRESS",
        "LOCATION": "LOCATION",
        "DATE_TIME": "DATE_TIME",
        "NRP": "NATIONALITY",
        "MEDICAL_LICENSE": "MEDICAL_LICENSE",
        "URL": "URL",
    }

    def __init__(self, languages: Optional[List[str]] = None):
        try:
            from presidio_analyzer import AnalyzerEngine
            from presidio_anonymizer import AnonymizerEngine
        except ImportError as e:
            raise ImportError(
                "Presidio not installed. "
                "Install with: pip install presidio-analyzer presidio-anonymizer"
            ) from e

        self.languages = languages or ["en"]
        self._analyzer = AnalyzerEngine()
        self._anonymizer = AnonymizerEngine()

        # Policy strictness mapping
        self._score_thresholds = {
            "permissive": 0.3,
            "moderate": 0.5,
            "strict": 0.7,
            "paranoid": 0.3,  # Low threshold = more detections
        }

    def detect(self, text: str, policy: Optional[str] = None) -> List[DetectedEntity]:
        """Detect entities using Presidio analyzer."""
        from presidio_analyzer import RecognizerResult

        # Determine threshold from policy
        strictness = "moderate"
        if policy:
            for s in ["permissive", "moderate", "strict", "paranoid"]:
                if s in policy.lower():
                    strictness = s
                    break

        threshold = self._score_thresholds.get(strictness, 0.5)

        # Analyze
        results: List[RecognizerResult] = self._analyzer.analyze(
            text=text,
            language=self.languages[0],
            score_threshold=threshold
        )

        # Convert to AVA entities
        entities = []
        for result in results:
            entity_type = self.ENTITY_MAP.get(
                result.entity_type, 
                result.entity_type
            )

            entities.append(DetectedEntity(
                type=entity_type,
                value=text[result.start:result.end],
                position=(result.start, result.end),
                confidence=result.score
            ))

        # Sort by position
        entities.sort(key=lambda e: e.position[0])
        return entities

    def anonymize(self, text: str, entities: List[DetectedEntity]) -> str:
        """Direct anonymization (utility method)."""
        from presidio_anonymizer.entities import OperatorConfig

        presidio_results = [
            {
                "entity_type": e.type,
                "start": e.position[0],
                "end": e.position[1],
                "score": e.confidence
            }
            for e in entities
        ]

        result = self._anonymizer.anonymize(
            text=text,
            analyzer_results=presidio_results,
            operators={
                "DEFAULT": OperatorConfig("replace", {"new_value": "<REDACTED>"})
            }
        )
        return result.text
