"""HTTP client for AVA Gateway"""
from typing import Optional, Dict, Any


class GatewaySession:
    """Session backed by remote AVA Gateway."""

    def __init__(self, client, policy: str, reversibility: bool = True):
        self.client = client
        self.policy = policy
        self.reversibility = reversibility
        self._manifest_id: Optional[str] = None
        self._closed = False

    def sanitize(self, text: str, context: Optional[str] = None) -> str:
        """Sanitize via gateway API."""
        if self._closed:
            raise RuntimeError("Session is closed")

        resp = self.client.post("/v1/sanitize", json={
            "text": text,
            "context": context,
            "reversibility_required": self.reversibility
        })
        resp.raise_for_status()

        data = resp.json()
        self._manifest_id = data.get("manifest", {}).get("manifest_id")
        return data["sanitized_text"]

    def restore(self, text: str, manifest_id: Optional[str] = None) -> str:
        """Restore via gateway API."""
        if self._closed:
            raise RuntimeError("Session is closed")

        resp = self.client.post("/v1/restore", json={
            "ai_response": text,
            "manifest_id": manifest_id or self._manifest_id
        })
        resp.raise_for_status()

        return resp.json()["restored_text"]

    def close(self):
        """Close session - no-op for stateless HTTP."""
        self._closed = True
