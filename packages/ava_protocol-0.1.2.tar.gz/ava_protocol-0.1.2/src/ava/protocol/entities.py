"""Entity definitions for detected PII"""
from dataclasses import dataclass
from typing import Tuple
import hashlib


@dataclass
class DetectedEntity:
    """A detected sensitive entity in text."""
    type: str                    # e.g., "PERSON_NAME", "EMAIL_ADDRESS"
    value: str                   # Original text
    position: Tuple[int, int]    # (start, end) character positions
    confidence: float            # 0.0-1.0 detection confidence

    def hash(self) -> str:
        """Hash the value for audit trails without storing original."""
        h = hashlib.sha256(self.value.encode()).hexdigest()[:16]
        return f"sha256:{h}"
