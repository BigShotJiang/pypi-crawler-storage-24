"""AVA Manifest - Audit and transformation tracking"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class EntityRecord:
    """Recorded entity in manifest."""
    type: str
    value_hash: str
    position: List[int]
    confidence: float
    action: str
    token: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "value_hash": self.value_hash,
            "position": self.position,
            "confidence": self.confidence,
            "action": self.action,
            "token": self.token
        }


@dataclass  
class AVAManifest:
    """AVA transformation manifest for audit and reversibility."""

    # Required fields
    manifest_id: str
    timestamp: str
    policy_domain: str = "general"
    policy_strictness: str = "moderate"
    reversibility: bool = True

    # Runtime state
    entities: List[EntityRecord] = field(default_factory=list)
    input_transform: str = "pseudonymize"
    output_transform: str = "restore"

    def add_entity(
        self,
        entity_type: str,
        value_hash: str,
        position: List[int],
        confidence: float,
        action: str,
        token: str
    ):
        """Add an entity record to this manifest."""
        self.entities.append(EntityRecord(
            type=entity_type,
            value_hash=value_hash,
            position=position,
            confidence=confidence,
            action=action,
            token=token
        ))

    def to_dict(self) -> Dict[str, Any]:
        """Serialize manifest to dictionary."""
        return {
            "ava_version": "1.0",
            "manifest_id": self.manifest_id,
            "timestamp": self.timestamp,
            "policy": {
                "domain": self.policy_domain,
                "strictness": self.policy_strictness,
                "reversibility": self.reversibility
            },
            "entities": [e.to_dict() for e in self.entities],
            "transformations": {
                "input_transform": self.input_transform,
                "output_transform": self.output_transform
            }
        }

    def get_tokens(self) -> List[str]:
        """Return all tokens in this manifest."""
        return [e.token for e in self.entities]
