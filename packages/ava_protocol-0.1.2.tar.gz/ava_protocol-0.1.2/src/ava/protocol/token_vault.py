"""Token vault implementations for secure storage of original values"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional, Dict, Tuple
import secrets
import threading
from datetime import datetime, timedelta, timezone


class TokenVault(ABC):
    """Abstract base for token storage backends."""

    TOKEN_PREFIX = "AVA"

    @abstractmethod
    def store(self, original: str, entity_type: str, session_id: str) -> str:
        """Store original value, return token."""
        pass

    @abstractmethod
    def retrieve(self, token: str, session_id: str) -> Optional[str]:
        """Retrieve original value by token."""
        pass

    @abstractmethod
    def expire_session(self, session_id: str):
        """Remove all tokens for a session."""
        pass

    @abstractmethod
    def close(self):
        """Cleanup resources."""
        pass

    def _generate_token(self, entity_type: str, suffix: str) -> str:
        """Generate standard AVA token format: AVA_TYPE_suffix"""
        short_type = entity_type.split("_")[0][:4].upper()
        return f"{self.TOKEN_PREFIX}_{short_type}_{suffix}"

    def _now(self) -> datetime:
        """Get current UTC time (timezone-aware)."""
        return datetime.now(timezone.utc)


class MemoryVault(TokenVault):
    """In-memory token vault with TTL support."""

    def __init__(self, ttl_seconds: int = 3600):
        self.ttl_seconds = ttl_seconds
        self._store: Dict[str, Tuple[str, datetime]] = {}
        self._session_tokens: Dict[str, set] = {}
        self._lock = threading.RLock()
        self._closed = False

    def store(self, original: str, entity_type: str, session_id: str) -> str:
        with self._lock:
            if self._closed:
                raise RuntimeError("Vault is closed")

            suffix = secrets.token_urlsafe(6)[:8]
            token = self._generate_token(entity_type, suffix)

            # Ensure uniqueness
            while token in self._store:
                suffix = secrets.token_urlsafe(6)[:8]
                token = self._generate_token(entity_type, suffix)

            expiry = self._now() + timedelta(seconds=self.ttl_seconds)
            self._store[token] = (original, expiry)

            if session_id not in self._session_tokens:
                self._session_tokens[session_id] = set()
            self._session_tokens[session_id].add(token)

            return token

    def retrieve(self, token: str, session_id: str) -> Optional[str]:
        with self._lock:
            if self._closed:
                return None

            entry = self._store.get(token)
            if not entry:
                return None

            original, expiry = entry
            if self._now() > expiry:
                self._store.pop(token, None)
                return None

            return original

    def expire_session(self, session_id: str):
        with self._lock:
            tokens = self._session_tokens.pop(session_id, set())
            for token in tokens:
                self._store.pop(token, None)

    def close(self):
        with self._lock:
            self._store.clear()
            self._session_tokens.clear()
            self._closed = True


class SqliteVault(TokenVault):
    """SQLite-backed token vault for persistence."""

    def __init__(self, db_path: str = ":memory:", ttl_seconds: int = 3600):
        import sqlite3
        self.db_path = db_path
        self.ttl_seconds = ttl_seconds
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._init_db()

    def _init_db(self):
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS tokens ("
            "token TEXT PRIMARY KEY, original TEXT NOT NULL, "
            "session_id TEXT NOT NULL, entity_type TEXT NOT NULL, "
            "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, expires_at TIMESTAMP)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_session ON tokens(session_id)"
        )
        self._conn.commit()

    def store(self, original: str, entity_type: str, session_id: str) -> str:
        import sqlite3
        suffix = secrets.token_urlsafe(6)[:8]
        token = self._generate_token(entity_type, suffix)

        expires = self._now() + timedelta(seconds=self.ttl_seconds)

        try:
            with self._conn:
                self._conn.execute(
                    "INSERT INTO tokens (token, original, session_id, entity_type, expires_at) VALUES (?, ?, ?, ?, ?)",
                    (token, original, session_id, entity_type, expires.isoformat())
                )
            return token
        except sqlite3.IntegrityError:
            # Collision, retry
            return self.store(original, entity_type, session_id)

    def retrieve(self, token: str, session_id: str) -> Optional[str]:
        cursor = self._conn.execute(
            "SELECT original, expires_at FROM tokens WHERE token = ?",
            (token,)
        )
        row = cursor.fetchone()
        if not row:
            return None

        original, expires_at = row
        if datetime.fromisoformat(expires_at) < self._now():
            self._conn.execute("DELETE FROM tokens WHERE token = ?", (token,))
            return None

        return original

    def expire_session(self, session_id: str):
        with self._conn:
            self._conn.execute("DELETE FROM tokens WHERE session_id = ?", (session_id,))

    def close(self):
        self._conn.close()
