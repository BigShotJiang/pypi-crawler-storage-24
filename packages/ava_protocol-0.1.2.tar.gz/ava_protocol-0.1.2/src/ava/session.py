"""AVA Session - Context manager for sanitize/restore operations"""
from __future__ import annotations
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ava.engines.base import DetectionEngine
    from ava.protocol.token_vault import TokenVault
    from ava.protocol.manifest import AVAManifest


class Session:
    """Transaction context for AVA operations."""

    def __init__(
        self,
        engine: DetectionEngine,
        vault: TokenVault,
        policy: str,
        reversibility: bool = True
    ):
        self.engine = engine
        self.vault = vault
        self.policy = policy
        self.reversibility = reversibility
        self.session_id = str(uuid.uuid4())[:8]
        self.manifests: List[AVAManifest] = []
        self._closed = False

    def sanitize(self, text: str, context: Optional[str] = None) -> str:
        """Sanitize text, return cleaned version."""
        if self._closed:
            raise RuntimeError("Session is closed")

        # Detect entities
        entities = self.engine.detect(text, policy=self.policy)

        # Build manifest
        from ava.protocol.manifest import AVAManifest
        manifest = AVAManifest(
            manifest_id=f"ava-{self.session_id}-{len(self.manifests)}",
            timestamp=datetime.utcnow().isoformat() + "Z",
            policy_domain=self.policy.split("_")[0] if "_" in self.policy else "general",
            policy_strictness=self.policy.split("_")[-1] if "_" in self.policy else "moderate",
            reversibility=self.reversibility
        )

        # Transform
        transformed_text = text
        offset = 0

        for entity in sorted(entities, key=lambda e: e.position[0]):
            token = self.vault.store(
                original=entity.value,
                entity_type=entity.type,
                session_id=self.session_id
            )

            manifest.add_entity(
                entity_type=entity.type,
                value_hash=entity.hash(),
                position=[entity.position[0] + offset, entity.position[1] + offset],
                confidence=entity.confidence,
                action="pseudonymize",
                token=token
            )

            # Replace in text
            start, end = entity.position[0] + offset, entity.position[1] + offset
            transformed_text = transformed_text[:start] + token + transformed_text[end:]
            offset += len(token) - (end - start)

        self.manifests.append(manifest)
        return transformed_text

    def restore(self, text: str, manifest_id: Optional[str] = None) -> str:
        """Restore sanitized text to original values."""
        if self._closed:
            raise RuntimeError("Session is closed")

        if not self.reversibility:
            raise RuntimeError("Session created without reversibility")

        result = text
        # Find manifest
        manifest = None
        if manifest_id:
            for m in self.manifests:
                if m.manifest_id == manifest_id:
                    manifest = m
                    break
        else:
            manifest = self.manifests[-1] if self.manifests else None

        if not manifest:
            raise ValueError("No manifest found for restoration")

        # Restore entities (reverse order to preserve positions)
        for entity in reversed(manifest.entities):
            original = self.vault.retrieve(entity.token, session_id=self.session_id)
            if original:
                result = result.replace(entity.token, original)

        return result

    def get_manifest(self, manifest_id: Optional[str] = None) -> Optional[AVAManifest]:
        """Retrieve manifest by ID or latest."""
        if manifest_id:
            for m in self.manifests:
                if m.manifest_id == manifest_id:
                    return m
            return None
        return self.manifests[-1] if self.manifests else None

    def close(self):
        """Cleanup session resources."""
        if self._closed:
            return
        self.vault.expire_session(self.session_id)
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
