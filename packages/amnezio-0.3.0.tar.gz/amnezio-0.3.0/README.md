# Amnezio Python SDK

Python SDK для работы с панелью Amnezio VPN.

## Установка

```bash
pip install amnezio
```

## Использование

### Аутентификация

SDK поддерживает два способа аутентификации:

#### 1. API токен (рекомендуется)

```python
from amnezio import AmnezioClient

async with AmnezioClient(
    base_url="https://panel.example.com",
    api_token="amz_xxxxxxxxxxxxxxxxxx"
) as client:
    # Работа с API
    users = await client.users.list()
```

#### 2. Логин и пароль

```python
async with AmnezioClient(
    base_url="https://panel.example.com",
    username="admin",
    password="secret"
) as client:
    # Работа с API
    users = await client.users.list()
```

**Рекомендуется использовать API токены** для ботов и интеграций:
- Токены можно отзывать отдельно
- Безопаснее, чем хранить пароль
- Можно задать срок действия
- Лучший аудит (видно какой токен что делает)

Создать токен можно в веб-панели: **API Токены → Создать токен**

### Основные операции

```python
from amnezio import AmnezioClient
from datetime import date, timedelta

async with AmnezioClient(
    base_url="https://panel.example.com",
    api_token="amz_xxxxxxxxxxxxxxxxxx"
) as client:
    # Генерация ключей
    keypair = await client.users.generate_keypair()
    
    # Создание пользователя
    user = await client.users.create(
        sub_id="user123",
        private_key=keypair.private_key,
        preshared_key=keypair.preshared_key,
        profile_id=1,
        paid_for=date.today() + timedelta(days=30)
    )
    
    # Получение конфига
    config = await client.users.get_config(user.id)
    
    # Продление подписки
    await client.users.renew_subscription(user.id, date(2027, 12, 31))
    
    # Отключение пользователя
    await client.users.disable(user.id)
```

## Методы

### Users

- `create()` — добавить пользователя
- `get(user_id)` — получить данные пользователя
- `list()` — получить список пользователей
- `update(user_id, **kwargs)` — обновить пользователя
- `delete(user_id)` — удалить пользователя
- `get_config(user_id)` — получить конфиг WireGuard
- `get_qrcode(user_id)` — получить QR-код с конфигом
- `enable(user_id)` — включить пользователя
- `disable(user_id)` — отключить пользователя
- `renew_subscription(user_id, paid_for)` — продлить подписку
- `generate_keypair()` — сгенерировать пару ключей WireGuard

### Profiles

- `create()` — создать профиль
- `get(profile_id)` — получить профиль
- `list()` — получить список профилей
- `update(profile_id, **kwargs)` — обновить профиль
- `delete(profile_id)` — удалить профиль

### Nodes

- `create(..., port=9999, node_type="awg"|"wg")` — добавить ноду (возвращает `NodeCreated` с `secret_key`, `docker_compose`)
- `get(node_id)` — получить ноду
- `list()` — получить список нод
- `update(node_id, **kwargs)` — обновить ноду
- `delete(node_id)` — удалить ноду
- `push_config(node_id)` — отправить конфиг на ноду (`POST /api/nodes/{id}/push`)
- `restart(node_id)` — перезапустить VPN-интерфейс на ноде
