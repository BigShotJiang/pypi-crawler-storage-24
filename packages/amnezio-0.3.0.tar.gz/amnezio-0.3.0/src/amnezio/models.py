"""Модели данных SDK."""

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class User(BaseModel):
    """Пользователь VPN."""

    id: int
    telegram_id: Optional[int] = None
    sub_id: str
    status: str
    public_key: str
    preshared_key: Optional[str] = None
    assigned_ip: Optional[str] = None
    paid_for: Optional[datetime] = None
    tag: Optional[str] = None
    description: Optional[str] = None
    profile_id: Optional[int] = None
    last_connected_at: Optional[datetime] = None
    last_connected_node_id: Optional[int] = None
    last_connected_node_name: Optional[str] = None
    rx_bytes: int = 0
    tx_bytes: int = 0


class Profile(BaseModel):
    """Профиль (шаблон конфига)."""

    id: int
    name: str
    subdomain: Optional[str] = None
    listen_port: int
    public_key: str
    private_key: str
    preshared_key: Optional[str] = None
    address: str
    dns: str
    mtu: int
    persistent_keepalive: int
    junk_packet_count: int
    junk_packet_min_size: int
    junk_packet_max_size: int
    init_packet_junk_size: int
    response_packet_junk_size: int
    underload_packet_junk_size: int
    transport_packet_junk_size: int
    init_packet_magic_header: int
    response_packet_magic_header: int
    underload_packet_magic_header: int
    transport_packet_magic_header: int
    created_at: datetime
    updated_at: datetime


class Node(BaseModel):
    """Нода (сервер VPN), ответ панели GET /api/nodes."""

    model_config = ConfigDict(extra="ignore")

    id: int
    name: str
    host: str
    port: int
    node_type: str = "awg"
    profile_id: Optional[int] = None
    status: str
    config_hash: Optional[str] = None
    expected_config_hash: Optional[str] = None
    config_applied: Optional[bool] = None
    last_poll_at: Optional[str] = None
    peers_online: int = 0
    node_version: Optional[str] = None
    awg_started_at: Optional[str] = None


class NodeCreated(Node):
    """Ответ POST /api/nodes (с SECRET_KEY и docker-compose)."""

    secret_key: str
    docker_compose: str


class KeyPair(BaseModel):
    """Пара ключей WireGuard."""

    private_key: str
    public_key: str
    preshared_key: str


class UserConfig(BaseModel):
    """Конфиг пользователя."""

    config: str


class PaginatedResponse(BaseModel):
    """Пагинированный ответ."""

    items: list
    total: int
    page: int
    per_page: int
    total_pages: int
