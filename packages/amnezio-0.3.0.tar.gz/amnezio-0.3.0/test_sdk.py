#!/usr/bin/env python3
"""CLI утилита для тестирования Amnezio SDK."""

import asyncio
import argparse
from datetime import date, timedelta
from amnezio import AmnezioClient
from amnezio.exceptions import NotFoundError, APIError


async def test_users(client: AmnezioClient):
    """Тест API пользователей."""
    print("\n=== Тест Users API ===")
    
    # Генерация ключей
    print("1. Генерация ключей...")
    keypair = await client.users.generate_keypair()
    print(f"   ✓ Private key: {keypair.private_key[:20]}...")
    
    # Создание пользователя
    print("2. Создание пользователя...")
    user = await client.users.create(
        sub_id=f"test_{int(date.today().timestamp())}",
        private_key=keypair.private_key,
        preshared_key=keypair.preshared_key,
        profile_id=1,
        paid_for=date.today() + timedelta(days=30),
        tag="test"
    )
    print(f"   ✓ Создан: ID={user.id}, IP={user.assigned_ip}")
    
    # Получение пользователя
    print("3. Получение пользователя...")
    user = await client.users.get(user.id)
    print(f"   ✓ Статус: {user.status}, подписка до: {user.paid_for}")
    
    # Список пользователей
    print("4. Список пользователей...")
    result = await client.users.list(page=1, per_page=5)
    print(f"   ✓ Всего: {result.total}, на странице: {len(result.items)}")
    
    # Получение конфига
    print("5. Получение конфига...")
    config = await client.users.get_config(user.id)
    print(f"   ✓ Конфиг получен ({len(config.config)} байт)")
    
    # Обновление пользователя
    print("6. Обновление пользователя...")
    user = await client.users.update(user.id, description="Test user from CLI")
    print(f"   ✓ Обновлен: {user.description}")
    
    # Отключение/включение
    print("7. Отключение пользователя...")
    user = await client.users.disable(user.id)
    print(f"   ✓ Статус: {user.status}")
    
    print("8. Включение пользователя...")
    user = await client.users.enable(user.id)
    print(f"   ✓ Статус: {user.status}")
    
    # Удаление
    print("9. Удаление пользователя...")
    result = await client.users.delete(user.id)
    print(f"   ✓ Удален: {result}")
    
    print("\n✅ Все тесты Users API пройдены!")


async def test_profiles(client: AmnezioClient):
    """Тест API профилей."""
    print("\n=== Тест Profiles API ===")
    
    # Список профилей
    print("1. Список профилей...")
    profiles = await client.profiles.list()
    print(f"   ✓ Найдено профилей: {len(profiles)}")
    
    for profile in profiles:
        print(f"   - {profile.id}: {profile.name} (порт {profile.listen_port})")
    
    if profiles:
        # Получение профиля
        print("2. Получение профиля...")
        profile = await client.profiles.get(profiles[0].id)
        print(f"   ✓ {profile.name}: {profile.address}")
    
    print("\n✅ Все тесты Profiles API пройдены!")


async def test_nodes(client: AmnezioClient):
    """Тест API нод."""
    print("\n=== Тест Nodes API ===")
    
    # Список нод
    print("1. Список нод...")
    nodes = await client.nodes.list()
    print(f"   ✓ Найдено нод: {len(nodes)}")
    
    for node in nodes:
        print(f"   - {node.id}: {node.name} ({node.host}:{node.port}) [{node.node_type}] - {node.status}")
        print(f"     Онлайн: {node.peers_online}, последний опрос: {node.last_poll_at}")
    
    if nodes:
        print("2. Push конфига на ноду...")
        try:
            result = await client.nodes.push_config(nodes[0].id)
            print(f"   ✓ {result}")
        except APIError as e:
            print(f"   ⚠ Ошибка push: {e.message}")
    
    print("\n✅ Все тесты Nodes API пройдены!")


async def main():
    parser = argparse.ArgumentParser(description="Тестирование Amnezio SDK")
    parser.add_argument("--url", required=True, help="URL панели")
    parser.add_argument("--username", required=True, help="Имя пользователя")
    parser.add_argument("--password", required=True, help="Пароль")
    parser.add_argument("--test", choices=["all", "users", "profiles", "nodes"], 
                        default="all", help="Какие тесты запустить")
    
    args = parser.parse_args()
    
    print(f"Подключение к {args.url}...")
    
    try:
        async with AmnezioClient(
            base_url=args.url,
            username=args.username,
            password=args.password
        ) as client:
            print("✓ Аутентификация успешна")
            
            if args.test in ["all", "users"]:
                await test_users(client)
            
            if args.test in ["all", "profiles"]:
                await test_profiles(client)
            
            if args.test in ["all", "nodes"]:
                await test_nodes(client)
            
            print("\n🎉 Все тесты успешно завершены!")
    
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(asyncio.run(main()))
