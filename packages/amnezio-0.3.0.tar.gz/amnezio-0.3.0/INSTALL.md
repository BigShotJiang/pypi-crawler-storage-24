# Установка и тестирование Amnezio SDK

## Установка

### Установка в режиме разработки

```bash
cd amnezio
pip install -e .
```

### Установка с зависимостями для разработки

```bash
pip install -e ".[dev]"
```

## Быстрый старт

```python
import asyncio
from datetime import date, timedelta
from amnezio import AmnezioClient

async def main():
    async with AmnezioClient(
        base_url="https://panel.example.com",
        username="admin",
        password="secret"
    ) as client:
        # Генерация ключей
        keypair = await client.users.generate_keypair()
        
        # Создание пользователя
        user = await client.users.create(
            sub_id="user123",
            private_key=keypair.private_key,
            preshared_key=keypair.preshared_key,
            profile_id=1,
            paid_for=date.today() + timedelta(days=30)
        )
        
        # Получение конфига
        config = await client.users.get_config(user.id)
        print(config.config)

asyncio.run(main())
```

## Примеры

Примеры находятся в папке `examples/`:

- `basic_usage.py` — базовое использование всех методов
- `telegram_bot.py` — создание пользователя через Telegram ID
- `subscription_management.py` — управление подписками

## Тестирование

Запуск тестов:

```bash
pytest
```

Запуск с покрытием:

```bash
pytest --cov=amnezio --cov-report=html
```

## API методы

### Users

```python
# Создание пользователя
user = await client.users.create(
    sub_id="user123",
    private_key="...",
    profile_id=1,
    paid_for="2026-12-31"
)

# Получение пользователя
user = await client.users.get(user_id=1)

# Список пользователей
result = await client.users.list(page=1, per_page=50)

# Обновление пользователя
user = await client.users.update(user_id=1, status="active")

# Удаление пользователя
await client.users.delete(user_id=1)

# Получение конфига
config = await client.users.get_config(user_id=1)

# Получение QR-кода
qrcode = await client.users.get_qrcode(user_id=1)

# Управление статусом
user = await client.users.enable(user_id=1)
user = await client.users.disable(user_id=1)

# Продление подписки
user = await client.users.renew_subscription(user_id=1, paid_for=date(2027, 12, 31))

# Генерация ключей
keypair = await client.users.generate_keypair()
```

### Profiles

```python
# Список профилей
profiles = await client.profiles.list()

# Создание профиля
profile = await client.profiles.create(
    name="US Server",
    subdomain="us",
    listen_port=51820
)

# Получение профиля
profile = await client.profiles.get(profile_id=1)

# Обновление профиля
profile = await client.profiles.update(profile_id=1, name="US East")

# Удаление профиля
await client.profiles.delete(profile_id=1)
```

### Nodes

```python
# Список нод
nodes = await client.nodes.list()

# Создание ноды
result = await client.nodes.create(
    name="Server 1",
    host="1.2.3.4",
    port=9999,
    node_type="awg",  # или "wg" для обычного WireGuard
    profile_id=1
)
# result содержит secret_key и docker_compose

# Получение ноды
node = await client.nodes.get(node_id=1)

# Обновление ноды
node = await client.nodes.update(node_id=1, name="Updated Server")

# Удаление ноды
await client.nodes.delete(node_id=1)

# Push конфига на ноду
result = await client.nodes.push_config(node_id=1)

# Перезапуск VPN-интерфейса на ноде
result = await client.nodes.restart(node_id=1)
```

## Обработка ошибок

```python
from amnezio import AmnezioClient
from amnezio.exceptions import (
    AmnezioError,
    AuthenticationError,
    NotFoundError,
    APIError
)

try:
    async with AmnezioClient(...) as client:
        user = await client.users.get(999)
except AuthenticationError:
    print("Неверные учетные данные")
except NotFoundError:
    print("Пользователь не найден")
except APIError as e:
    print(f"Ошибка API: {e.status_code} - {e.message}")
except AmnezioError as e:
    print(f"Общая ошибка: {e}")
```

## Публикация на PyPI

Для публикации на PyPI:

```bash
# Сборка пакета
python -m build

# Публикация (тестовый PyPI)
python -m twine upload --repository testpypi dist/*

# Публикация (production PyPI)
python -m twine upload dist/*
```
