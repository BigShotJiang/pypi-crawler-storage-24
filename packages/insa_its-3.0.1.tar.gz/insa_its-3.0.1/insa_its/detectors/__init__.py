"""
InsAIts SDK - Advanced Detectors
=================================
Algorithmic anomaly detectors for multi-agent communication.

- SemanticDriftDetector: EWMA-based cosine distance drift detection
- HallucinationChainDetector: Confidence propagation tracking
- JargonDriftDetector: TF-IDF weighted out-of-vocabulary detection
"""

from .semantic_drift import SemanticDriftDetector, DriftResult
from .hallucination_chain import HallucinationChainDetector
from .jargon_drift import JargonDriftDetector

__all__ = [
    "SemanticDriftDetector",
    "DriftResult",
    "HallucinationChainDetector",
    "JargonDriftDetector",
]
