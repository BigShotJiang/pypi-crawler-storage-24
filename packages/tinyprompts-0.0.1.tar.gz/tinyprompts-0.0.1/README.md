# tinyprompts

A dependency free prompts (not the LLM prompts) library built for CLI.



# Dependency
None, your only dependency is Python.


echo "# tinyprompts" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin git@github.com:noklam/tinyprompts.git
git push -u origin main