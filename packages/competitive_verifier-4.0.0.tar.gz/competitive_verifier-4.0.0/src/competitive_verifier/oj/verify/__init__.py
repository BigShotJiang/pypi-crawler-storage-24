"""Port of oj-verify."""
