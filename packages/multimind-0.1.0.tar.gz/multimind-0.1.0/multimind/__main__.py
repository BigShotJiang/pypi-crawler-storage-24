from thinking_wrapper.main import run


if __name__ == "__main__":
    run()