from __future__ import annotations

from collections.abc import AsyncIterator

from thinking_wrapper.config import PIPELINE_STEPS
from thinking_wrapper.llm_client import LocalLLMClient
from thinking_wrapper.markdown_render import render_markdown_to_html


STEP_LABELS = {
    "plan": "Planning",
    "execute": "Executing",
    "critique": "Critiquing",
}


def _system_prompt_for_plan() -> str:
    return (
        "You are the planning stage in a reasoning pipeline. "
        "Create a concise strategy for solving the user request. "
        "Do not give the final answer. Use short bullet points."
    )


def _system_prompt_for_execute(mode: str) -> str:
    if mode == "hard":
        return (
            "You are the execution stage in a reasoning pipeline. "
            "Use the plan to produce the strongest draft answer possible. "
            "Be detailed and explicit."
        )

    return (
        "You are the execution stage in a reasoning pipeline. "
        "Use the plan to produce the final user-facing answer."
    )


def _system_prompt_for_critique() -> str:
    return (
        "You are the critique stage in a reasoning pipeline. "
        "Review the draft answer for factual mistakes, weak logic, and omissions. "
        "Return an improved final answer directly, without meta commentary."
    )


def _build_messages_for_plan(user_message: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": _system_prompt_for_plan()},
        {"role": "user", "content": user_message},
    ]


def _build_messages_for_execute(user_message: str, plan: str, mode: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": _system_prompt_for_execute(mode)},
        {
            "role": "user",
            "content": (
                f"User request:\n{user_message}\n\n"
                f"Plan:\n{plan or 'No plan was generated.'}\n\n"
                "Write the best possible answer."
            ),
        },
    ]


def _build_messages_for_critique(user_message: str, plan: str, draft: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": _system_prompt_for_critique()},
        {
            "role": "user",
            "content": (
                f"User request:\n{user_message}\n\n"
                f"Plan:\n{plan or 'No plan was generated.'}\n\n"
                f"Draft answer:\n{draft or 'No draft answer was generated.'}\n\n"
                "Provide the corrected final answer."
            ),
        },
    ]


def _pipeline_for_mode(mode: str) -> tuple[str, ...]:
    if mode == "off":
        return ("execute",)
    if mode == "medium":
        return ("plan", "execute")
    return PIPELINE_STEPS


async def run_pipeline(
    *,
    client: LocalLLMClient,
    provider_kind: str,
    base_url: str,
    model_map: dict[str, str],
    user_message: str,
    mode: str,
) -> AsyncIterator[dict]:
    steps = _pipeline_for_mode(mode)
    outputs: dict[str, str] = {}

    yield {"type": "run-start", "mode": mode, "steps": list(steps)}

    for step in steps:
        model = model_map.get(step) or model_map.get("execute") or ""
        if not model:
            raise ValueError(f"No model configured for step '{step}'.")

        yield {
            "type": "step-start",
            "step": step,
            "label": STEP_LABELS[step],
            "model": model,
            "thought": step != "execute" or mode == "hard",
        }

        if step == "execute" and mode != "hard":
            yield {"type": "answer-start", "step": step, "label": STEP_LABELS[step], "model": model}
        if step == "critique":
            yield {"type": "answer-start", "step": step, "label": STEP_LABELS[step], "model": model}

        if step == "plan":
            messages = _build_messages_for_plan(user_message)
        elif step == "execute":
            messages = _build_messages_for_execute(user_message, outputs.get("plan", ""), mode)
        else:
            messages = _build_messages_for_critique(
                user_message,
                outputs.get("plan", ""),
                outputs.get("execute", ""),
            )

        buffer: list[str] = []
        partial_content = ""
        async for token in client.stream_chat(
            provider_kind=provider_kind,
            base_url=base_url,
            model=model,
            messages=messages,
        ):
            buffer.append(token)
            partial_content += token
            yield {
                "type": "step-delta",
                "step": step,
                "delta": token,
                "content": partial_content,
                "html": render_markdown_to_html(partial_content),
            }

            if (step == "execute" and mode != "hard") or step == "critique":
                yield {
                    "type": "answer-delta",
                    "step": step,
                    "delta": token,
                    "content": partial_content,
                    "html": render_markdown_to_html(partial_content),
                }

        outputs[step] = "".join(buffer).strip()
        yield {
            "type": "step-complete",
            "step": step,
            "content": outputs[step],
            "html": render_markdown_to_html(outputs[step]),
        }

        if (step == "execute" and mode != "hard") or step == "critique":
            yield {
                "type": "answer-complete",
                "step": step,
                "content": outputs[step],
                "html": render_markdown_to_html(outputs[step]),
            }

    if mode == "off":
        outputs["final"] = outputs.get("execute", "")
    elif mode == "medium":
        outputs["final"] = outputs.get("execute", "")
    else:
        outputs["final"] = outputs.get("critique", "")

    yield {"type": "run-complete", "outputs": outputs}