"""
Batch Fix Service

Handles batch processing of multiple vulnerability fixes.
Supports both individual and batch fix operations.

This service:
1. Runs a LIGHTWEIGHT baseline (build + existing tests + coverage — NO AI)
2. Fixes vulnerabilities using the 6-agent workflow
3. Verifies build success after fixes (with BuildMechanic auto-repair)
4. Runs FULL testing agent validation (AI test generation on fixed code)
5. Creates PRs (if auto_create_pr is enabled)
"""

import logging
import asyncio
import time
from typing import List, Dict, Any, Optional
from pathlib import Path

# Package-relative imports so this works from both source and installed package
from ..models.agent_models import VulnerabilityFixRequest, VulnerabilitySeverity
from .fix_orchestrator import FixOrchestrator
from .bedrock_service import BedrockService
from .batch_pr_service import BatchPRService
from .atlas_service import atlas_service

logger = logging.getLogger(__name__)


class BatchFixService:
    """Service for batch processing of vulnerability fixes"""
    
    def __init__(self, bedrock_service: BedrockService):
        """
        Initialize Batch Fix Service.
        
        Args:
            bedrock_service: BedrockService instance for AI operations
        """
        self.bedrock_service = bedrock_service
        self.orchestrator = FixOrchestrator(bedrock_service)
        logger.info("[BatchFixService] Initialized")
    
    async def _process_vulnerability_fix(
        self,
        current_idx: int,
        vuln_idx: int,
        vuln: Dict[str, Any],
        total: int,
        repo_path: str,
        repo_name: str,
        clone_url: Optional[str] = None,
        token: Optional[str] = None
    ) -> tuple:
        """
        Internal method to process a single vulnerability fix with logging.
        Returns: (current_idx, vuln_idx, success, error_str, fix_result)
        """
        vuln_type = vuln.get('vulnerability', 'Unknown')
        file_path = vuln.get('matched_file_path', vuln.get('file_path', 'N/A'))
        line_no = vuln.get('line_no', 'N/A')
        description = vuln.get('description', '')[:80] if vuln.get('description') else 'N/A'
        
        logger.info("")
        logger.info("=" * 80)
        logger.info(f"[BatchFixService] 🔧 FIXING VULNERABILITY {current_idx}/{total}")
        logger.info("=" * 80)
        logger.info(f"[BatchFixService] 📋 Vulnerability #{vuln_idx}: {vuln_type}")
        logger.info(f"[BatchFixService] 📁 File: {file_path}")
        logger.info(f"[BatchFixService] 📍 Line: {line_no}")
        logger.info(f"[BatchFixService] 📝 Description: {description}")
        logger.info(f"[BatchFixService] 🏷️  Repository: {repo_name}")
        logger.info("-" * 80)
        logger.info(f"[BatchFixService] 🤖 Starting 6-Agent Fix Pipeline...")
        logger.info(f"[BatchFixService]    Agent 1: Vulnerability Analyzer")
        logger.info(f"[BatchFixService]    Agent 2: Code Context Agent")
        logger.info(f"[BatchFixService]    Agent 3: Fix Strategy Agent")
        logger.info(f"[BatchFixService]    Agent 4: Code Fix Agent")
        logger.info(f"[BatchFixService]    Agent 5: Safety Validator Agent")
        logger.info(f"[BatchFixService]    Agent 6: Explanation Agent")
        logger.info("-" * 80)
        
        fix_start_time = time.time()
        fix_result = await self.fix_single_vulnerability(
            vulnerability=vuln,
            repo_path=repo_path,
            repo_name=repo_name,
            clone_url=clone_url,
            token=token
        )
        fix_duration = time.time() - fix_start_time
        
        if fix_result['success']:
            logger.info("-" * 80)
            logger.info(f"[BatchFixService] ✅ SUCCESS: Vulnerability #{vuln_idx} fixed successfully!")
            logger.info(f"[BatchFixService]    Type: {vuln_type}")
            logger.info(f"[BatchFixService]    File: {file_path}")
            logger.info(f"[BatchFixService]    Duration: {fix_duration:.2f}s")
            logger.info(f"[BatchFixService]    Progress: {current_idx}/{total} completed")
            logger.info("=" * 80)
            logger.info("")
            return (current_idx, vuln_idx, True, None, fix_result)
        else:
            error_msg = fix_result.get('errors', ['Unknown error'])
            error_str = error_msg[0] if error_msg else 'Unknown error'
            logger.error("-" * 80)
            logger.error(f"[BatchFixService] ❌ FAILED: Vulnerability #{vuln_idx} could not be fixed")
            logger.error(f"[BatchFixService]    Type: {vuln_type}")
            logger.error(f"[BatchFixService]    File: {file_path}")
            logger.error(f"[BatchFixService]    Error: {error_str}")
            logger.error(f"[BatchFixService]    Duration: {fix_duration:.2f}s")
            logger.error(f"[BatchFixService]    Progress: {current_idx}/{total} completed")
            logger.error("=" * 80)
            logger.error("")
            return (current_idx, vuln_idx, False, error_str, fix_result)
    
    
    async def _run_testing_agent(
        self,
        repo_path: str,
        repo_name: str,
        phase: str = "after_fix",  # "before_fix" or "after_fix"
        fixed_files: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Run testing agent on code (before or after fixes).
        
        Args:
            repo_path: Path to repository
            repo_name: Repository name
            phase: "before_fix" for baseline or "after_fix" for validation
            fixed_files: List of files that were fixed (optional, for context)
            
        Returns:
            Dictionary with test generation results
        """
        phase_label = "LIGHTWEIGHT BASELINE (BEFORE FIX)" if phase == "before_fix" else "VALIDATION (AFTER FIX)"
        phase_emoji = "📊" if phase == "before_fix" else "🧪"
        
        logger.info("="  * 80)
        logger.info(f"[BatchFixService] {phase_emoji} RUNNING TESTING AGENT - {phase_label}")
        logger.info("=" * 80)
        logger.info(f"[BatchFixService] Repository: {repo_name}")
        logger.info(f"[BatchFixService] Phase: {phase}")
        if fixed_files:
            logger.info(f"[BatchFixService] Fixed files: {len(fixed_files)}")
            logger.info(f"[BatchFixService] Files: {', '.join(fixed_files[:5])}{'...' if len(fixed_files) > 5 else ''}")
        logger.info("-" * 80)
        
        test_start_time = time.time()
        
        try:
            if phase == "before_fix":
                # OPTIMIZED: Use lightweight baseline (build + existing tests + coverage only)
                # Skips AI test generation, RAG, LLM calls — saves ~70-80% time
                logger.info(f"[BatchFixService] 📊 Using LIGHTWEIGHT baseline (no AI test generation)")
                test_result = await atlas_service.run_baseline_only(
                    repo_path=repo_path,
                    repo_url=repo_name,
                )
            else:
                # FULL VALIDATION: Run complete pipeline with AI test generation on fixed code
                test_result = await atlas_service.run_testing_pipeline_local(
                    repo_path=repo_path,
                    repo_url=repo_name,
                    fixed_files=fixed_files,
                    create_pr=False
                )
            
            test_duration = time.time() - test_start_time
            
            if test_result and test_result.get('success'):
                tests_generated = len(test_result.get('generated_files', []))
                logger.info("-" * 80)
                logger.info(f"[BatchFixService] ✅ Testing agent completed successfully!")
                logger.info(f"[BatchFixService]    Tests generated: {tests_generated}")
                logger.info(f"[BatchFixService]    Duration: {test_duration:.2f}s")
                logger.info("=" * 80)
                logger.info("")
                
                return {
                    'success': True,
                    'phase': phase,  # NEW: Include phase in results
                    'tests_generated': tests_generated,
                    'test_files': test_result.get('generated_files', []),
                    'coverage': test_result.get('coverage', {}).get('overall', 'N/A'),
                    'duration': test_duration,
                    'full_result': test_result
                }
            else:
                error_msg = test_result.get('error', 'Unknown error') if test_result else 'Testing agent returned None'
                logger.warning("-" * 80)
                logger.warning(f"[BatchFixService] ⚠️ Testing agent failed: {error_msg}")
                logger.warning(f"[BatchFixService]    Duration: {test_duration:.2f}s")
                logger.warning("=" * 80)
                logger.warning("")
                
                return {
                    'success': False,
                    'phase': phase,  # NEW: Include phase in results
                    'error': error_msg,
                    'duration': test_duration
                }
                
        except Exception as e:
            test_duration = time.time() - test_start_time
            logger.error("-" * 80)
            logger.error(f"[BatchFixService] ❌ Testing agent exception: {str(e)}")
            logger.error(f"[BatchFixService]    Duration: {test_duration:.2f}s")
            logger.error("=" * 80)
            logger.error("")
            
            return {
                'success': False,
                'phase': phase,  # NEW: Include phase in results
                'error': str(e),
                'duration': test_duration
            }
    
    async def fix_single_vulnerability(
        self,
        vulnerability: Dict[str, Any],
        repo_path: str,
        repo_name: str,
        clone_url: Optional[str] = None,
        token: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Fix a single vulnerability.
        
        Args:
            vulnerability: Vulnerability dictionary with:
                - vulnerability_type: str
                - description: str
                - severity: str
                - file_path: str
                - line_no: int or str
                - recommendation: Optional[str]
            repo_path: Path to repository (if already cloned)
            repo_name: Repository name
            clone_url: Clone URL (if repo needs to be cloned)
            token: GitHub token for private repos
            
        Returns:
            Dictionary with fix result
        """
        start_time = time.time()
        try:
            # Extract vulnerability details
            vuln_type = vulnerability.get('vulnerability', 'Unknown')
            description = vulnerability.get('description', '')
            severity_str = vulnerability.get('severity', 'high').lower()
            file_path = vulnerability.get('matched_file_path') or vulnerability.get('file_path', '')
            line_no = vulnerability.get('line_no', 0)
            recommendation = vulnerability.get('recommendation')
            
            # Convert line_no to int
            try:
                line_number = int(line_no) if line_no else 0
            except (ValueError, TypeError):
                line_number = 0
            
            # Validate severity
            try:
                severity = VulnerabilitySeverity(severity_str)
            except ValueError:
                severity = VulnerabilitySeverity.HIGH
                logger.warning(f"[BatchFixService] Invalid severity '{severity_str}', defaulting to HIGH")
            
            # Create fix request
            fix_request = VulnerabilityFixRequest(
                vulnerability_type=vuln_type,
                description=description,
                severity=severity,
                recommendation=recommendation,
                file_path=file_path,
                line_number=line_number,
                repo_path=repo_path,
                repo_name=repo_name
            )
            
            # Run orchestration with optimizations:
            # - Validation disabled (non-blocking)
            #   (build/test validation is handled separately in the batch flow)
            result = await self.orchestrator.orchestrate_fix(
                fix_request,
                stop_at_agent=None,
                validate_fix=False,  # Disabled by default - validation failures are non-blocking warnings
                max_validation_retries=1,  # Reduced retries to avoid excessive build attempts
            )
            
            # Convert to dict
            result_dict = result.model_dump(mode='json', exclude_none=True)
            
            duration = time.time() - start_time
            return {
                'success': result.overall_status == "success",
                'status': result.overall_status,
                'errors': result.errors,
                'result': result_dict,
                'vulnerability_type': vuln_type,
                'description': description,
                'file_path': file_path,
                'line_number': line_number,
                'duration': round(duration, 2)
            }
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"[BatchFixService] Error fixing vulnerability: {str(e)}")
            return {
                'success': False,
                'status': 'failed',
                'errors': [str(e)],
                'result': None,
                'vulnerability_type': vulnerability.get('vulnerability', 'Unknown'),
                'description': vulnerability.get('description', ''),
                'file_path': vulnerability.get('matched_file_path', ''),
                'line_number': vulnerability.get('line_no', 0),
                'duration': round(duration, 2)
            }
    
    async def fix_batch_vulnerabilities(
        self,
        vulnerabilities: List[Dict[str, Any]],
        repo_path: str,
        repo_name: str,
        clone_url: Optional[str] = None,
        token: Optional[str] = None,
        max_concurrent: int = 1,
        auto_create_pr: bool = False,
        repo_owner: Optional[str] = None,
        base_branch: str = "main",
        run_tests_after_fix: bool = True  # NEW: Run testing agent after fixes
    ) -> Dict[str, Any]:
        """
        Fix multiple vulnerabilities in batch.
        
        Args:
            vulnerabilities: List of vulnerability dictionaries
            repo_path: Path to repository
            repo_name: Repository name
            clone_url: Clone URL (if needed)
            token: GitHub token
            max_concurrent: Maximum concurrent fixes (default: 1 for sequential processing)
            auto_create_pr: If True, automatically create PR after each successful fix
            repo_owner: Repository owner (required if auto_create_pr is True)
            base_branch: Base branch for PRs (default: "main")
            
        Returns:
            Dictionary with batch results:
            {
                'total': int,
                'successful': int,
                'failed': int,
                'skipped': int,
                'results': List[Dict],
                'pr_results': List[Dict] (if auto_create_pr is True)
            }
        """
        batch_start_time = time.time()
        logger.info("=" * 70)
        logger.info(f"[BatchFixService] 🚀 STARTING BATCH FIX PROCESS")
        logger.info("=" * 70)
        logger.info(f"[BatchFixService] Repository: {repo_name}")
        logger.info(f"[BatchFixService] Total vulnerabilities: {len(vulnerabilities)}")
        logger.info(f"[BatchFixService] Processing mode: {'Sequential' if max_concurrent == 1 else f'Concurrent (max {max_concurrent})'}")
        if auto_create_pr:
            logger.info(f"[BatchFixService] ✅ Auto PR creation: ENABLED")
        else:
            logger.info(f"[BatchFixService] ⏸️  Auto PR creation: DISABLED")
        logger.info("=" * 70)
        
        # Initialize PR service if auto_create_pr is enabled
        pr_service = None
        if auto_create_pr:
            if not token:
                logger.warning("[BatchFixService] Auto PR creation requires token, disabling auto PR")
                auto_create_pr = False
            elif not repo_owner:
                logger.warning("[BatchFixService] Auto PR creation requires repo_owner, disabling auto PR")
                auto_create_pr = False
            else:
                pr_service = BatchPRService(token)
        
        results = {
            'total': len(vulnerabilities),
            'successful': 0,
            'failed': 0,
            'skipped': 0,
            'results': [],
            # For backward compatibility, keep pr_results but we will store
            # a single batch PR result replicated per successful vulnerability.
            'pr_results': [] if auto_create_pr else None,
            # New field: single batch PR result (one PR per repository)
            'batch_pr_result': None,
            'duration': 0.0
        }
        
        # Filter fixable vulnerabilities
        fixable_vulns = []
        for idx, vuln in enumerate(vulnerabilities, 1):
            file_found = vuln.get('file_found', False)
            matched_file_path = vuln.get('matched_file_path')
            
            if file_found and matched_file_path:
                fixable_vulns.append((idx, vuln))
            else:
                results['skipped'] += 1
                results['results'].append({
                    'vuln_idx': idx,
                    'status': 'skipped',
                    'error': 'File not found or no matched file path',
                    'result': None
                })
        
        if not fixable_vulns:
            logger.info("[BatchFixService] No fixable vulnerabilities found")
            return results
        
        # NEW: Run baseline testing BEFORE fixes (if enabled)
        baseline_test_results = None
        if run_tests_after_fix:  # Use same flag for both baseline and post-fix testing
            logger.info("")
            logger.info(f"[📊 BatchFixService] Running baseline testing on original code...")
            baseline_test_results = await self._run_testing_agent(
                repo_path=repo_path,
                repo_name=repo_name,
                phase="before_fix"
            )
            results['baseline_test_results'] = baseline_test_results
        
        # Track successful fixes for optional single batch PR creation
        successful_fixes_for_pr: List[Dict[str, Any]] = []

        # Process fixes with configurable concurrency
        # Use semaphore to limit concurrent operations
        semaphore = asyncio.Semaphore(max_concurrent) if max_concurrent > 1 else None
        
        async def process_single_fix(current_idx, vuln_idx, vuln):
            """Process a single vulnerability fix with optional concurrency control"""
            if semaphore:
                async with semaphore:
                    return await self._process_vulnerability_fix(
                        current_idx, vuln_idx, vuln, len(fixable_vulns), 
                        repo_path, repo_name, clone_url, token
                    )
            else:
                return await self._process_vulnerability_fix(
                    current_idx, vuln_idx, vuln, len(fixable_vulns),
                    repo_path, repo_name, clone_url, token
                )
        
        # Process fixes (sequentially or in parallel based on max_concurrent)
        if max_concurrent > 1:
            # Parallel processing
            tasks = [
                process_single_fix(current_idx, vuln_idx, vuln)
                for current_idx, (vuln_idx, vuln) in enumerate(fixable_vulns, 1)
            ]
            fix_results_list = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            for i, fix_result in enumerate(fix_results_list):
                if isinstance(fix_result, Exception):
                    # Handle exception
                    vuln_idx, vuln = fixable_vulns[i]
                    results['failed'] += 1
                    error_str = str(fix_result)
                    logger.error(f"[BatchFixService] ❌ Exception fixing vulnerability: {error_str}")
                    results['results'].append({
                        'vuln_idx': vuln_idx,
                        'status': 'failed',
                        'error': error_str,
                        'result': None
                    })
                else:
                    # Process normal result
                    current_idx, vuln_idx, success, error_str, fix_result_data = fix_result
                    if success:
                        results['successful'] += 1
                        result_entry = {
                            'vuln_idx': vuln_idx,
                            'status': 'success',
                            'error': None,
                            'result': fix_result_data
                        }
                        if auto_create_pr and pr_service:
                            successful_fixes_for_pr.append({
                                'vuln_idx': vuln_idx,
                                'result': fix_result_data
                            })
                        results['results'].append(result_entry)
                    else:
                        results['failed'] += 1
                        results['results'].append({
                            'vuln_idx': vuln_idx,
                            'status': 'failed',
                            'error': error_str,
                            'result': fix_result_data
                        })
        else:
            # Sequential processing (original logic)
            for current_idx, (vuln_idx, vuln) in enumerate(fixable_vulns, 1):
                # Use the refactored method
                _, _, success, error_str, fix_result_data = await self._process_vulnerability_fix(
                    current_idx, vuln_idx, vuln, len(fixable_vulns),
                    repo_path, repo_name, clone_url, token
                )
                
                if success:
                    results['successful'] += 1
                    result_entry = {
                        'vuln_idx': vuln_idx,
                        'status': 'success',
                        'error': None,
                        'result': fix_result_data
                    }
                    if auto_create_pr and pr_service:
                        successful_fixes_for_pr.append({
                            'vuln_idx': vuln_idx,
                            'result': fix_result_data
                        })
                    results['results'].append(result_entry)
                else:
                    results['failed'] += 1
                    results['results'].append({
                        'vuln_idx': vuln_idx,
                        'status': 'failed',
                        'error': error_str,
                        'result': fix_result_data
                    })
        
        # Final summary
        logger.info("=" * 70)
        logger.info(f"[BatchFixService] 📊 BATCH FIX SUMMARY")
        logger.info("=" * 70)
        logger.info(f"[BatchFixService] Total vulnerabilities: {results['total']}")
        logger.info(f"[BatchFixService] ✅ Successful: {results['successful']}")
        logger.info(f"[BatchFixService] ❌ Failed: {results['failed']}")
        logger.info(f"[BatchFixService] ⏭️  Skipped: {results['skipped']}")
        logger.info("=" * 70)
        
        # Phase 3: BUILD VERIFICATION — ensure fixes didn't break the build
        build_verification = None
        if run_tests_after_fix and results['successful'] > 0:
            logger.info("")
            logger.info("=" * 80)
            logger.info(f"[BatchFixService] 🔨 PHASE 3: VERIFYING BUILD AFTER FIXES")
            logger.info("=" * 80)
            try:
                from atlas.build.maven import mvn_clean_install
                build_res = mvn_clean_install(repo_path)
                build_verification = {
                    'build_ok': build_res.ok,
                    'retries': 0,
                    'auto_fixed': False,
                }
                
                # If build fails, use BuildMechanic to auto-repair (up to 3 retries)
                if not build_res.ok:
                    logger.warning(f"[BatchFixService] ⚠️ Build failed after fixes. Attempting auto-repair...")
                    try:
                        from atlas.core.config import load_config
                        from atlas.llm.bedrock import create_bedrock_client
                        from atlas.agents.build_mechanic import BuildMechanic
                        from atlas.analysis.java_maven import find_domain_models
                        from collections import defaultdict
                        
                        cfg = load_config()
                        llm = create_bedrock_client(cfg.aws_region, cfg.bedrock_model_id, cfg.bedrock_embed_model_id)
                        build_mechanic = BuildMechanic(llm=llm, logger=logger)
                        domain_models = find_domain_models(repo_path)
                        attempted_fix_counts = defaultdict(int)
                        
                        max_build_retries = 3
                        for retry in range(1, max_build_retries + 1):
                            if build_res.ok:
                                break
                            logger.info(f"[BatchFixService] 🔧 Build auto-fix attempt {retry}/{max_build_retries}")
                            diagnosis = build_mechanic.analyze(build_res.stdout or "", build_res.stderr or "")
                            blocked = {f for f, c in attempted_fix_counts.items() if c >= 10}
                            fix = build_mechanic.generate_fix(diagnosis, repo_path, blocked, domain_models)
                            if fix and fix.file_patches:
                                import os
                                for patch in fix.file_patches:
                                    try:
                                        os.makedirs(os.path.dirname(patch.path), exist_ok=True)
                                        with open(patch.path, "w", encoding="utf-8") as f:
                                            f.write(patch.content)
                                        attempted_fix_counts[patch.path] += 1
                                        logger.info(f"[BatchFixService]    Applied fix to {patch.path}")
                                    except Exception as e:
                                        logger.error(f"[BatchFixService]    Patch failed: {e}")
                                build_res = mvn_clean_install(repo_path)
                                build_verification['retries'] = retry
                            else:
                                logger.warning(f"[BatchFixService] No fix available, stopping retries")
                                break
                        
                        build_verification['build_ok'] = build_res.ok
                        build_verification['auto_fixed'] = build_res.ok and build_verification['retries'] > 0
                        
                    except Exception as mechanic_err:
                        logger.error(f"[BatchFixService] BuildMechanic auto-repair failed: {mechanic_err}")
                        build_verification['mechanic_error'] = str(mechanic_err)
                
                if build_verification['build_ok']:
                    if build_verification.get('auto_fixed'):
                        logger.info(f"[BatchFixService] ✅ Build PASSED after auto-repair ({build_verification['retries']} retries)")
                    else:
                        logger.info(f"[BatchFixService] ✅ Build PASSED after fixes")
                else:
                    logger.error(f"[BatchFixService] ❌ Build FAILED after fixes (even after auto-repair attempts)")
                    # Store build error details
                    combined = (build_res.stdout or "") + "\n" + (build_res.stderr or "")
                    error_lines = [l.strip() for l in combined.splitlines() if l.strip() and ("ERROR" in l or "FAILURE" in l)][:10]
                    build_verification['build_errors'] = error_lines
                
                results['build_verification'] = build_verification
                logger.info("=" * 80)
                
            except Exception as build_err:
                logger.error(f"[BatchFixService] Build verification failed: {build_err}")
                build_verification = {'build_ok': False, 'error': str(build_err)}
                results['build_verification'] = build_verification
        
        # Phase 4: FULL VALIDATION — AI test generation on fixed code
        test_results = None
        if run_tests_after_fix and results['successful'] > 0:
            # Only run validation testing if build is OK
            build_ok = build_verification.get('build_ok', True) if build_verification else True
            
            # Collect all fixed files from successful fixes
            fixed_files = []
            for result_entry in results['results']:
                if result_entry.get('status') == 'success':
                    fix_result = result_entry.get('result', {})
                    if fix_result and 'result' in fix_result:
                        code_fix = fix_result['result'].get('code_fix', {})
                        if isinstance(code_fix, dict):
                            fixed_files.extend(code_fix.get('files_modified', []))
            
            if fixed_files and build_ok:
                logger.info("")
                logger.info(f"[BatchFixService] 🧪 PHASE 4: Running FULL validation testing on fixed code ({len(fixed_files)} files)...")
                test_results = await self._run_testing_agent(
                    repo_path=repo_path,
                    repo_name=repo_name,
                    phase="after_fix",
                    fixed_files=fixed_files
                )
                
                # Add test results to response
                results['test_results'] = test_results
            elif not build_ok:
                logger.warning(f"[BatchFixService] ⏭️  Skipping validation testing — build failed after fixes")
                results['test_results'] = {'success': False, 'phase': 'after_fix', 'error': 'Build failed after fixes, skipping test validation'}
            else:
                logger.info(f"[BatchFixService] ⏭️  Skipping testing agent (no fixed files found)")
        elif not run_tests_after_fix:
            logger.info(f"[BatchFixService] ⏭️  Testing agent disabled (run_tests_after_fix=False)")
        
        # If auto PR is enabled, create a single aggregate PR for all successful fixes
        if auto_create_pr and pr_service and successful_fixes_for_pr:
            logger.info(
                f"[BatchFixService] 📝 Creating SINGLE batch PR for {len(successful_fixes_for_pr)} successful fixes..."
            )
            try:
                batch_pr = await pr_service.create_single_batch_pr(
                    successful_fixes=successful_fixes_for_pr,
                    repo_owner=repo_owner,
                    repo_name=repo_name,
                    repo_path=repo_path,
                    base_branch=base_branch,
                    test_results=test_results  # NEW: Pass test results to PR service
                )

                results['batch_pr_result'] = batch_pr

                if batch_pr and batch_pr.get('success'):
                    logger.info(
                        f"[BatchFixService] ✅ Batch PR created successfully: "
                        f"PR #{batch_pr.get('pr_number')} - {batch_pr.get('pr_url')}"
                    )
                    # For backward compatibility, replicate this PR result per successful vulnerability
                    if results['pr_results'] is not None:
                        results['pr_results'].clear()
                        for entry in results['results']:
                            if entry.get('status') == 'success':
                                entry['pr_result'] = batch_pr
                                results['pr_results'].append({
                                    'vuln_idx': entry.get('vuln_idx'),
                                    'status': 'success',
                                    'pr_result': batch_pr
                                })
                else:
                    error_msg = batch_pr.get('message', 'Unknown error') if batch_pr else 'Failed to create batch PR'
                    logger.warning(f"[BatchFixService] ⚠️ Failed to create batch PR: {error_msg}")
                    if results['pr_results'] is not None:
                        # Mark PR creation as failed for each successful vulnerability
                        for entry in results['results']:
                            if entry.get('status') == 'success':
                                results['pr_results'].append({
                                    'vuln_idx': entry.get('vuln_idx'),
                                    'status': 'failed',
                                    'error': error_msg,
                                    'pr_result': None
                                })
            except Exception as pr_error:
                logger.error(f"[BatchFixService] Exception creating batch PR: {str(pr_error)}")
                if results['pr_results'] is not None:
                    for entry in results['results']:
                        if entry.get('status') == 'success':
                            results['pr_results'].append({
                                'vuln_idx': entry.get('vuln_idx'),
                                'status': 'failed',
                                'error': str(pr_error),
                                'pr_result': None
                            })

        logger.info("=" * 70)
        logger.info(f"[BatchFixService] 🎉 BATCH FIX PROCESS COMPLETE")
        logger.info("=" * 70)
        logger.info(
            f"[BatchFixService] Repository: {repo_name}"
        )
        logger.info(
            f"[BatchFixService] ✅ Successful fixes: {results['successful']}"
        )
        logger.info(
            f"[BatchFixService] ❌ Failed fixes: {results['failed']}"
        )
        logger.info(
            f"[BatchFixService] ⏭️  Skipped: {results['skipped']}"
        )
        logger.info(
            f"[BatchFixService] 📊 Total processed: {results['total']}"
        )
        if auto_create_pr and results.get('batch_pr_result') and results['batch_pr_result'].get('success'):
            pr_url = results['batch_pr_result'].get('pr_url', 'N/A')
            pr_number = results['batch_pr_result'].get('pr_number', 'N/A')
            logger.info(
                f"[BatchFixService] 🔗 Batch PR created: PR #{pr_number} - {pr_url}"
            )
        results['duration'] = round(time.time() - batch_start_time, 2)
        logger.info(f"[BatchFixService] ⏱️  Total duration: {results['duration']}s")
        logger.info("=" * 70)

        return results

