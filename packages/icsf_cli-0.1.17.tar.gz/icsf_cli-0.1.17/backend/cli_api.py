"""
cli_api.py

Core Python API used by the ICSF CLI.

This module is intentionally **web-framework agnostic** – it reuses the same
services that the FastAPI backend uses (GitHubService, VulnerabilityService,
BatchFixService, Atlas testing service) but exposes them as simple functions
that can be called from a command-line entrypoint.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml
from dotenv import load_dotenv

# When installed as a package, all backend modules live under the
# `backend` package. Use package-relative imports so the CLI works both
# from a source checkout and from an installed wheel.
from .config import Config
from .services.github_service import GitHubService
from .services.vulnerability_service import VulnerabilityService
from .services.bedrock_service import BedrockService
from .services.batch_fix_service import BatchFixService

logger = logging.getLogger(__name__)

def _parse_credentials_file(raw: str) -> Dict[str, Any]:
    """
    Parse credentials file content.

    Supports:
    - Proper YAML (preferred)
    - YAML with accidental `.env`-style lines appended (KEY=VALUE)
    """
    try:
        return yaml.safe_load(raw) or {}
    except Exception:
        # Filter out lines like: BEDROCK_MODEL_ID=... that break YAML parsing.
        yaml_lines: List[str] = []
        extra_env: Dict[str, str] = {}
        for line in raw.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                yaml_lines.append(line)
                continue
            # If it looks like dotenv (has '=' but no ':' before it), treat as env var.
            if "=" in stripped and (":" not in stripped.split("=", 1)[0]):
                key, val = stripped.split("=", 1)
                extra_env[key.strip()] = val.strip()
                continue
            yaml_lines.append(line)

        data = yaml.safe_load("\n".join(yaml_lines)) or {}
        if extra_env:
            aws = (data.get("aws") or {}) if isinstance(data, dict) else {}
            # Map env style keys into aws section where relevant.
            if "BEDROCK_MODEL_ID" in extra_env:
                aws.setdefault("bedrock_model_id", extra_env["BEDROCK_MODEL_ID"])
            if "BEDROCK_EMBED_MODEL_ID" in extra_env:
                aws.setdefault("bedrock_embed_model_id", extra_env["BEDROCK_EMBED_MODEL_ID"])
            if aws and isinstance(data, dict):
                data["aws"] = aws
        return data if isinstance(data, dict) else {}


def load_github_credentials_from_file(
    credentials_path: Optional[Path],
) -> Tuple[str, Optional[str], Optional[str]]:
    """
    Load GitHub token/username/email for CLI usage.

    Precedence:
    1. Explicit credentials YAML path if provided
    2. Fallback to Config.get_github_credentials() (backend/credentials.yaml)
    """
    token: Optional[str]
    username: Optional[str]
    email: Optional[str]

    if credentials_path is not None:
        if not credentials_path.exists():
            raise FileNotFoundError(
                f"Credentials file not found: {credentials_path}"
            )
        raw = credentials_path.read_text(encoding="utf-8")
        data = _parse_credentials_file(raw)
        gh = data.get("github", {}) or {}
        token = gh.get("token")
        username = gh.get("username")
        email = gh.get("email")
        logger.info(
            "Loaded GitHub credentials from %s (username=%s, email=%s)",
            credentials_path,
            username or "N/A",
            email or "N/A",
        )
    else:
        creds = Config.get_github_credentials(force_reload=True)
        token = creds.get("token")
        username = creds.get("username")
        email = creds.get("email")
        logger.info(
            "Loaded GitHub credentials from default backend/credentials.yaml "
            "(username=%s, email=%s)",
            username or "N/A",
            email or "N/A",
        )

    if not token:
        raise RuntimeError(
            "GitHub token is required but was not found in credentials."
        )

    return token, username, email


async def fetch_repositories_for_cli(
    token: str,
    username: Optional[str],
    email: Optional[str],
) -> List[Dict[str, Any]]:
    """
    Fetch repositories the same way the FastAPI endpoint does, but for CLI use.
    """
    github_service = GitHubService(token)

    # Resolve which identifier to use.
    if username:
        final_username = username
        logger.info("Using GitHub username: %s", final_username)
    elif email:
        logger.info(
            "Username not provided; resolving from email via GitHub API: %s",
            email,
        )
        final_username = await github_service.get_username_from_email(email)
        if not final_username:
            raise RuntimeError(
                "Unable to resolve GitHub username from email; "
                "provide username in credentials.yaml or via CLI."
            )
        logger.info("Resolved username from email: %s", final_username)
    else:
        # As a fallback, rely on the authenticated user info.
        logger.info(
            "Neither username nor email provided; using authenticated user."
        )
        user_info = await github_service.verify_token_and_get_user(None)
        final_username = user_info.get("login")
        if not final_username:
            raise RuntimeError(
                "Authenticated GitHub user could not be determined."
            )

    logger.info("Verifying GitHub token and fetching user info for %s", final_username)
    user_info = await github_service.verify_token_and_get_user(final_username)
    authenticated_username = user_info.get("login") or final_username
    logger.info("Authenticated as: %s", authenticated_username)

    repos = await github_service.get_all_repositories(
        final_username,
        include_private=True,
        authenticated_username=authenticated_username,
        include_orgs=True,
    )
    logger.info("Fetched %d repositories from GitHub", len(repos))
    return repos


def map_vulnerabilities_from_csv_for_cli(
    csv_path: Path,
    repositories: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Parse a vulnerability CSV and map vulnerabilities to repositories/files.

    This reuses VulnerabilityService.parse_csv_file and
    VulnerabilityService.map_vulnerabilities_to_repos, mirroring the
    `/api/vulnerabilities/map` endpoint, but runs entirely in-process.
    """
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    file_bytes = csv_path.read_bytes()
    df, error = VulnerabilityService.parse_csv_file(file_bytes, csv_path.name)
    if error:
        raise RuntimeError(f"Error parsing CSV: {error}")
    if df is None or df.empty:
        raise RuntimeError("CSV file is empty or invalid")

    # For the initial CLI implementation we let VulnerabilityService clone
    # repositories on demand for accurate file-path matching.
    mapped_vulns, unmatched_vulns = VulnerabilityService.map_vulnerabilities_to_repos(
        vulnerabilities_df=df,
        repositories=repositories,
        repo_files_map=None,
        clone_repos=True,
    )

    # Normalize keys to strings for JSON-compatibility.
    mapped_response: Dict[str, Any] = {}
    for repo_id, data in mapped_vulns.items():
        mapped_response[str(repo_id)] = {
            "repo": data["repo"],
            "vulnerabilities": data["vulnerabilities"],
        }

    return {
        "mapped_vulnerabilities": mapped_response,
        "unmatched_vulnerabilities": unmatched_vulns,
        "total_mapped": len(mapped_response),
        "total_unmatched": len(unmatched_vulns),
    }


def _ensure_repo_cloned_for_cli(
    repo: Dict[str, Any],
    token: Optional[str],
    backend_root: Path,
) -> Path:
    """
    Ensure a repository is cloned locally and return the local path.

    This mirrors the cloning logic used in the FastAPI `/api/fixes/batch`
    endpoint, but is safe for CLI use.
    """
    from subprocess import run, CalledProcessError

    repo_name = repo.get("name") or "repo"
    full_name = repo.get("full_name") or repo_name
    clone_url = repo.get("clone_url") or repo.get("html_url", "")

    if not clone_url:
        raise RuntimeError(f"No clone URL available for repository: {full_name}")

    temp_clone_dir = backend_root / "temp_cloned_repos" / repo_name
    temp_clone_dir.parent.mkdir(parents=True, exist_ok=True)

    git_dir = temp_clone_dir / ".git"
    if temp_clone_dir.exists() and git_dir.exists():
        logger.info(
            "Reusing existing clone for %s at %s", full_name, temp_clone_dir
        )
        return temp_clone_dir

    # Normalize HTTPS clone URL and inject token if available.
    repo_clone_url = clone_url
    if "github.com" in repo_clone_url and not repo_clone_url.endswith(".git"):
        repo_clone_url = repo_clone_url + ".git"
    if token and repo_clone_url.startswith("https://") and "github.com" in repo_clone_url:
        # https://TOKEN@github.com/owner/repo.git
        repo_clone_url = repo_clone_url.replace("https://", f"https://{token}@")

    if temp_clone_dir.exists():
        # Stale/non-git directory – remove it before cloning.
        import shutil

        shutil.rmtree(temp_clone_dir, ignore_errors=True)

    logger.info("Cloning %s into %s ...", repo_clone_url, temp_clone_dir)
    try:
        completed = run(
            [
                "git",
                "clone",
                "--depth",
                "1",
                "--single-branch",
                "--filter=blob:none",
                "--quiet",
                repo_clone_url,
                str(temp_clone_dir),
            ],
            capture_output=True,
            text=True,
            timeout=120,
            shell=False,
        )
    except CalledProcessError as e:
        raise RuntimeError(f"Failed to clone repository: {e}") from e
    except Exception as e:  # pragma: no cover - defensive
        raise RuntimeError(f"Failed to clone repository: {e}") from e

    if completed.returncode != 0:
        raise RuntimeError(
            f"Failed to clone repository {full_name}: {completed.stderr or completed.stdout}"
        )

    logger.info("Clone complete for %s", full_name)
    return temp_clone_dir


async def run_end_to_end_for_repo(
    repo: Dict[str, Any],
    vulnerabilities: List[Dict[str, Any]],
    token: str,
    *,
    auto_create_pr: bool,
    run_tests: bool,
    base_branch: str = "main",
    credentials_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Run the full batch pipeline for a single repository:
    - clone (or reuse clone)
    - baseline testing (Atlas)
    - multi-agent fixes (BatchFixService)
    - validation testing
    - PR creation (single batch PR)
    """
    backend_root = Path(__file__).resolve().parent
    repo_path = _ensure_repo_cloned_for_cli(repo, token, backend_root)

    bedrock_cfg = Config.get_bedrock_config(credentials_path)
    bedrock_service = BedrockService(
        access_key=bedrock_cfg["access_key"],
        secret_key=bedrock_cfg["secret_key"],
        region=bedrock_cfg["region"],
    )
    batch_service = BatchFixService(bedrock_service)

    repo_name: str = repo.get("name", "")
    full_name: str = repo.get("full_name", repo_name)
    owner: Optional[str] = None
    if full_name and "/" in full_name:
        owner = full_name.split("/")[0]

    results = await batch_service.fix_batch_vulnerabilities(
        vulnerabilities=vulnerabilities,
        repo_path=str(repo_path),
        repo_name=repo_name,
        clone_url=repo.get("clone_url") or repo.get("html_url", ""),
        token=token,
        max_concurrent=2,
        auto_create_pr=auto_create_pr,
        repo_owner=owner,
        base_branch=base_branch,
        run_tests_after_fix=run_tests,
    )

    return {
        "repo": repo,
        "batch_results": results,
        "local_repo_path": str(repo_path),
    }


async def run_end_to_end_cli(
    credentials_path: Optional[Path],
    csv_path: Path,
    *,
    auto_create_pr: bool,
    run_tests: bool,
    repo_filter: Optional[str] = None,
    min_severity: Optional[str] = None,
    env_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    High-level orchestration used by `icsf run`:
    - load credentials
    - fetch repositories
    - map CSV vulnerabilities to repos/files
    - for each repo (optionally filtered), run batch fixes + tests + PR
    """
    # Load .env as fallback when AWS/model IDs are not in credentials.yaml.
    if env_path and env_path.exists():
        load_dotenv(dotenv_path=env_path, override=True)
    elif credentials_path and credentials_path.parent:
        default_env = credentials_path.parent / ".env"
        if default_env.exists():
            load_dotenv(dotenv_path=default_env, override=True)

    # If credentials file has aws section, set env so Atlas and other code see them.
    if credentials_path and credentials_path.exists():
        try:
            data = _parse_credentials_file(credentials_path.read_text(encoding="utf-8"))
            aws = data.get("aws") or {}
            if aws:
                if aws.get("access_key_id"):
                    os.environ["AWS_ACCESS_KEY_ID"] = str(aws["access_key_id"]).strip()
                if aws.get("secret_access_key"):
                    os.environ["AWS_SECRET_ACCESS_KEY"] = str(aws["secret_access_key"]).strip()
                if aws.get("region"):
                    os.environ["AWS_REGION"] = str(aws["region"]).strip()
                if aws.get("session_token"):
                    os.environ["AWS_SESSION_TOKEN"] = str(aws["session_token"]).strip()
                # Model IDs from YAML so .env is not required for Bedrock.
                if aws.get("bedrock_model_id"):
                    os.environ["BEDROCK_MODEL_ID"] = str(aws["bedrock_model_id"]).strip()
                if aws.get("bedrock_embed_model_id"):
                    os.environ["BEDROCK_EMBED_MODEL_ID"] = str(aws["bedrock_embed_model_id"]).strip()
        except Exception:
            pass

    token, username, email = load_github_credentials_from_file(credentials_path)

    repos = await fetch_repositories_for_cli(token, username, email)
    mapping = map_vulnerabilities_from_csv_for_cli(csv_path, repos)

    mapped = mapping.get("mapped_vulnerabilities", {})
    repo_id_to_repo: Dict[int, Dict[str, Any]] = {}
    for r in repos:
        if "id" in r:
            repo_id_to_repo[int(r["id"])] = r

    # Optionally filter by repo name / full_name substring.
    def _repo_matches_filter(repo_dict: Dict[str, Any]) -> bool:
        if not repo_filter:
            return True
        name = (repo_dict.get("name") or "").lower()
        full_name = (repo_dict.get("full_name") or "").lower()
        return repo_filter.lower() in name or repo_filter.lower() in full_name

    end_to_end_results: List[Dict[str, Any]] = []
    total_fixable_repos = 0

    # Iterate over mapped repos and run the full batch pipeline for each.
    for repo_id_str, payload in mapped.items():
        try:
            repo_id = int(repo_id_str)
        except ValueError:
            continue

        repo = repo_id_to_repo.get(repo_id) or payload.get("repo")
        if not repo:
            continue
        if not _repo_matches_filter(repo):
            continue

        vulnerabilities = payload.get("vulnerabilities", [])
        if not vulnerabilities:
            continue

        total_fixable_repos += 1
        logger.info(
            "Running end-to-end pipeline for repository %s with %d mapped vulnerabilities",
            repo.get("full_name") or repo.get("name"),
            len(vulnerabilities),
        )
        repo_result = await run_end_to_end_for_repo(
            repo=repo,
            vulnerabilities=vulnerabilities,
            token=token,
            auto_create_pr=auto_create_pr,
            run_tests=run_tests,
            credentials_path=credentials_path,
        )
        end_to_end_results.append(repo_result)

    summary = {
        "total_repos_with_vulns": len(mapped),
        "total_repos_processed": total_fixable_repos,
        "mapping": mapping,
        "repos": repos,
        "results": end_to_end_results,
    }
    return summary


def to_pretty_json(data: Any) -> str:
    """Helper for dumping CLI reports."""
    def _default(o: Any) -> Any:
        try:
            return asdict(o)  # dataclasses
        except Exception:
            return str(o)

    return json.dumps(data, indent=2, default=_default)

