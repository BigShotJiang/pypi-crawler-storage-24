from __future__ import annotations

import logging
import os
import re
import json
from collections import defaultdict
from atlas.agents.models import BuildDiagnosis, AgentFix, FilePatch
from atlas.analysis.contract_service import extract_class_contract, format_contracts_for_prompt, RepoContractRegistry
from atlas.llm.bedrock import BedrockClient
from atlas.core.logging import RunLogger

PREFIX = "BuildMechanic: "

JUNIT_FIX_SNIPPET = """        <!-- Fix for JUnit 5 NoSuchMethodError -->
        <dependency>
            <groupId>org.junit.platform</groupId>
            <artifactId>junit-platform-launcher</artifactId>
            <scope>test</scope>
        </dependency>
"""

COMMON_TEST_HINTS = {
    "Record": "import java.util.Record;",
    "MockMvc": "import org.springframework.test.web.servlet.MockMvc;",
    "Autowired": "import org.springframework.beans.factory.annotation.Autowired;",
    "MockBean": "import org.springframework.boot.test.mock.mockito.MockBean;",
    "Test": "import org.junit.jupiter.api.Test;",
    "BeforeEach": "import org.junit.jupiter.api.BeforeEach;",
    "BeforeAll": "import org.junit.jupiter.api.BeforeAll;",
    "AfterEach": "import org.junit.jupiter.api.AfterEach;",
    "AfterAll": "import org.junit.jupiter.api.AfterAll;",
    "DisplayName": "import org.junit.jupiter.api.DisplayName;",
    "ExtendWith": "import org.junit.jupiter.api.extension.ExtendWith;",
    "BigDecimal": "import java.math.BigDecimal;",
    "List": "import java.util.List;",
    "ArrayList": "import java.util.ArrayList;",
    "Map": "import java.util.Map;",
    "HashMap": "import java.util.HashMap;",
    "WebSecurityConfigurerAdapter": "import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter; // Note: Deprecated in Spring Security 5.7+",
    "EnableWebSecurity": "import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;",
    "HttpSecurity": "import org.springframework.security.config.annotation.web.builders.HttpSecurity;",
    "SecurityFilterChain": "import org.springframework.security.web.SecurityFilterChain;",
    "Bean": "import org.springframework.context.annotation.Bean;",
    "Configuration": "import org.springframework.context.annotation.Configuration;",
    "Account": "import com.banking.account.domain.Account; // NOTE: Account(customerId, type, initialBalance) exists. NO builder().",
    "AccountService": "// NOTE: Uses getAccount(id), createAccount(customerId, type, initialBalance).",
    "TransactionService": "// NOTE: deposit(accountId, Money amount, String desc), withdraw(accountId, Money, String), transfer(fromId, toId, Money, String).",
    "AccountCreateRequest": "// NOTE: Uses setInitialBalance(double), setAccountType(String). NOT Money/AccountType.",
    "AccountResponse": "// NOTE: Default constructor ONLY. Use setAccountId(String), setBalance(double), etc.",
    "TransactionRequest": "// NOTE: Uses setAmount(double), setFromAccountId(String), setToAccountId(String). NOT Money.",
    "TransactionResponse": "// NOTE: Default constructor ONLY. Uses setTransactionId(String), setAmount(double), etc.",
    "Money": "import com.banking.core.domain.Money; // NOTE: Use 'new Money(BigDecimal, \"USD\")' or 'new Money(double, \"USD\")'.",
    # ASSERTION HINTS
    "status().isCreated()": "// WARNING: If 201 fails, try status().isOk(). Some controllers return 200 for creation.",
    "jsonPath": "// WARNING: Use '$.balance' (double), NOT '$.balance.amount'. DTOs are flat.",
    "content().json": "// WARNING: Use strict=false when comparing JSON to ignore extra fields.",
    "status().isForbidden()": "// WARNING: 403 Forbidden? Check SecurityFilterChain. Use @WithMockUser or permitAll().",
    "status().isUnauthorized()": "// WARNING: 401 Unauthorized? Check SecurityFilterChain. Use @WithMockUser or permitAll().",
    "HttpSecurity": "import org.springframework.security.config.annotation.web.builders.HttpSecurity; // NOTE: Use lambda-based DSL for SS6.",
    "HeadersConfigurer": "// NOTE: .httpStrictTransportSecurity() is on HeadersConfigurer, NOT on nested configurers like permissionsPolicy().",
    # SPRING SECURITY 6 DSL MIGRATION HINTS
    "ReferrerPolicyConfig": "// SS6: Use lambda DSL: .headers(h -> h.referrerPolicy(rp -> rp.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN)))",
    "PermissionsPolicyConfig": "// SS6: Use lambda DSL: .headers(h -> h.permissionsPolicy(pp -> pp.policy(\"geolocation=self\")))",
    "ContentSecurityPolicyConfig": "// SS6: Use lambda DSL: .headers(h -> h.contentSecurityPolicy(csp -> csp.policyDirectives(\"script-src 'self'\")))",
    "FrameOptionsConfig": "// SS6: Use lambda DSL: .headers(h -> h.frameOptions(fo -> fo.deny()))",
    "XssProtectionConfig": "// SS6: Use lambda DSL: .headers(h -> h.xssProtection(xss -> xss.disable()))",
    "HstsConfig": "// SS6: Use lambda DSL: .headers(h -> h.httpStrictTransportSecurity(hsts -> hsts.includeSubDomains(true).maxAgeInSeconds(31536000)))",
    "CacheControlConfig": "// SS6: Use lambda DSL: .headers(h -> h.cacheControl(cc -> cc.disable()))",
}

# ── Deprecated Spring Security patterns that cannot be fixed by LLM ─────────
# When a compile error in a generated test references ANY of these, delete file.
DEPRECATED_SPRING_PATTERNS = [
    "WebSecurityConfigurerAdapter",
    "authorizeRequests(",
    "antMatchers(",
    "mvcMatchers(",
    "regexMatchers(",
    "AbstractSecurityWebApplicationInitializer",
]

def _count_unquoted_braces(code: str) -> tuple[int, int]:

    """Counts { and } while ignoring those within quotes or line comments."""
    open_count = 0
    close_count = 0
    in_string = False
    in_char = False
    in_line_comment = False
    in_block_comment = False
    string_char = None
    
    i = 0
    while i < len(code):
        char = code[i]
        next_char = code[i+1] if i + 1 < len(code) else ""
        
        # Handle block comments
        if in_block_comment:
            if char == '*' and next_char == '/':
                in_block_comment = False
                i += 2
                continue
        elif in_line_comment:
            if char == '\n':
                in_line_comment = False
        elif not in_string and not in_char:
            if char == '/' and next_char == '/':
                in_line_comment = True
                i += 2
                continue
            if char == '/' and next_char == '*':
                in_block_comment = True
                i += 2
                continue
        
        # Handle strings/chars if not in comments
        if not in_line_comment and not in_block_comment:
            if char == '\\': # Escape
                i += 2
                continue
            if char == '"' and not in_char:
                in_string = not in_string
            elif char == "'" and not in_string:
                in_char = not in_char
            
            # Count braces if not in any "escaped" block
            if not in_string and not in_char:
                if char == '{':
                    open_count += 1
                elif char == '}':
                    close_count += 1
        
        i += 1
    return open_count, close_count

# Senior QA Prompt Guidelines for First-Try Success
SENIOR_QA_INSTRUCTIONS = """
1. Fix ALL compilation errors in one shot. Analyze imports and types meticulously.
2. If a domain model or DTO is referenced, use the provided signatures precisely.
3. Maintain brace stability. Balanced { } are mandatory.
4. Avoid placeholders. Generate logic that reflects actual class behavior.
5. CRITICAL: Follow Spring Security 6 DSL and Logging rules provided in the context.
"""

MISSING_PACKAGE_DEPS = {
    "org.springframework.security": """
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
""",
    "jakarta.validation": """
        <dependency>
            <groupId>jakarta.validation</groupId>
            <artifactId>jakarta.validation-api</artifactId>
            <version>3.0.2</version>
        </dependency>
        <dependency>
            <groupId>org.hibernate.validator</groupId>
            <artifactId>hibernate-validator</artifactId>
            <version>8.0.1.Final</version>
        </dependency>
""",
    "org.apache.commons.text": """
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-text</artifactId>
            <version>1.10.0</version>
        </dependency>
""",
    "org.apache.commons.lang3": """
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-lang3</artifactId>
            <version>3.14.0</version>
        </dependency>
""",
    "org.owasp.encoder": """
        <dependency>
            <groupId>org.owasp.encoder</groupId>
            <artifactId>encoder</artifactId>
            <version>1.2.3</version>
        </dependency>
""",
}

class BuildMechanic:
    """
    Agent responsible for analyzing build failures and proposing fixes.
    Capable of fixing:
    - Missing config files (e.g. application.properties)
    - Simple compilation errors
    - Missing dependencies
    """

    def __init__(self, llm: BedrockClient, logger: RunLogger):
        self.llm = llm
        self.logger = logger

    def analyze(self, stdout: str, stderr: str) -> BuildDiagnosis:
        """Analyze Maven build output to find root cause."""
        self.logger.info(f"{PREFIX}Analyzing build failure...")
        
        # Heuristic check first (faster/cheaper)
        combined = (stdout or "") + "\n" + (stderr or "")
        
        # DEBUG: Log what we're analyzing
        self.logger.info(f"{PREFIX}Build output length: {len(combined)} chars")
        has_compilation = "COMPILATION ERROR" in combined or "compilation failure" in combined.lower()
        has_junit = "org.junit.platform.commons.util.ExceptionUtils.findNestedThrowables" in combined
        has_dependency = "DependencyResolutionException" in combined or "Could not resolve dependencies" in combined
        has_network = any(msg in combined for msg in [
            "Premature end of Content-Length",
            "Could not transfer artifact",
            "Checksum validation failed",
            "Transfer failed for"
        ])
        
        self.logger.info(f"{PREFIX}Patterns: compilation={has_compilation}, junit={has_junit}, dependency={has_dependency}, network={has_network}")
        self.logger.info(f"{PREFIX}Output preview: {combined[:1000]}...")

        # Spring Security 6 DSL migration errors (common after vulnerability fixes)
        # These occur when a vuln fix upgrades SS API but leaves deprecated non-lambda DSL
        ss6_dsl_patterns = [
            "HeadersConfigurer",
            "ReferrerPolicyConfig",
            "PermissionsPolicyConfig",
            "ContentSecurityPolicyConfig",
            "FrameOptionsConfig",
            "XssProtectionConfig",
            "HstsConfig",
            "CacheControlConfig",
            "CorsConfigurer",
            "CsrfConfigurer",
            "ExpressionUrlAuthorizationConfigurer",
            "httpBasic()",  # Non-lambda variant
        ]
        has_ss6_dsl_error = has_compilation and any(pat in combined for pat in ss6_dsl_patterns)

        if has_ss6_dsl_error:
            # Extract the specific failing file(s)
            failing_files = []
            for m in re.finditer(r"(?:\[ERROR\]\s+)?([a-zA-Z]?:?[^:\s]+\.java):\[(\d+)", combined):
                failing_files.append(m.group(1))
            failing_files = list(set(failing_files))[:5]
            # Identify which SS6 patterns were detected
            detected = [p for p in ss6_dsl_patterns if p in combined]
            return BuildDiagnosis(
                root_cause=f"Spring Security 6 DSL migration required. Deprecated non-lambda configurers detected: {', '.join(detected)}.",
                confidence=0.95,
                summary=f"Post-vulnerability-fix build failure: Spring Security DSL needs lambda migration ({', '.join(detected)}).",
                failure_type="spring_security_dsl",
                error_messages=[f"SS6 DSL error in {f}" for f in failing_files] if failing_files else [f"SS6 DSL pattern: {', '.join(detected)}"],
                missing_files=failing_files
            )

        # Common pattern: JUnit 5 version mismatch (NoSuchMethodError in various JUnit Platform utils)
        junit_errors = [
            "org.junit.platform.commons.util.ExceptionUtils.findNestedThrowables",
            "org.junit.platform.commons.util.CollectionUtils.forEachInReverseOrder",
            "org.junit.platform.commons.util.ReflectionUtils",
            "org.junit.platform.commons.PreconditionViolationException",
            "NoSuchMethodError.*org.junit.platform"
        ]
        
        has_junit_error = any(error in combined for error in junit_errors)
        
        if has_junit_error:
             return BuildDiagnosis(
                root_cause="JUnit 5 dependency version mismatch (Platform vs Engine).",
                confidence=0.9,
                summary="Detected conflicting versions of JUnit Platform. Needs dependency alignment.",
                failure_type="dependency_conflict",
                error_messages=["java.lang.NoSuchMethodError in JUnit Platform classes"]
            )

        if has_network:
            return BuildDiagnosis(
                root_cause="Transient network failure or corrupted local artifact repository.",
                confidence=0.95,
                summary="Maven failed to download or verify an artifact (Premature end of Content-Length).",
                failure_type="network_or_corrupted_artifact",
                error_messages=["Premature end of Content-Length delimited message body", "Could not transfer artifact"]
            )
        
        if "DependencyResolutionException" in combined or "Could not resolve dependencies" in combined:
            # Capture artifact info from: "dependency: groupId:artifactId:type:version"
            dep_match = re.search(r"dependency: ([\w.-]+):([\w.-]+):[\w.-]*:([\w.-]+)", combined)
            
            error_msgs = ["DependencyResolutionException"]
            diag_summary = "Dependency resolution failed."
            root_cause = "Cannot resolve dependencies (network issue or bad version)."
            missing_files = []
            
            if dep_match:
                g, a, v = dep_match.groups()
                diag_summary = f"Valid version not found for {g}:{a}:{v}"
                # Store as "groupId:artifactId:version" for the fixer
                missing_files = [f"{g}:{a}:{v}"] 
                error_msgs.append(f"Failed to download {g}:{a}:{v}")

            return BuildDiagnosis(
                root_cause=root_cause,
                confidence=0.85,
                summary=diag_summary,
                failure_type="missing_dependency",
                error_messages=error_msgs,
                missing_files=missing_files
            )
        
        if "COMPILATION ERROR" in combined or "compilation failure" in combined.lower():
            # Extract specific error details
            error_lines = []
            if "class, interface, or enum expected" in combined:
                error_lines.append("class, interface, or enum expected (likely missing brace or code outside class)")
            if "cannot find symbol" in combined:
                error_lines.append("cannot find symbol (likely missing import)")
            
            # Detect missing packages (symptom of missing dependency)
            missing_packages = set()
            pkg_matches = re.finditer(r"package ([\w\.]+) does not exist", combined)
            for m in pkg_matches:
                missing_packages.add(m.group(1))
            
            # IMPROVED: Parse Maven output line by line to group multi-line errors
            # Regex is now more relaxed about the path and prefix
            lines = combined.splitlines()
            error_messages = []
            current_error = []
            
            # Pattern: [ERROR] /path/to/File.java:[line,col] message
            # Or: [ERROR] path\to\File.java:[line,col] message (Windows)
            # Or just: /path/to/File.java:[line,col] message
            error_start_re = re.compile(r"(?:\[ERROR\]\s+)?([a-zA-Z]?:?[^:\s]+\.java):\[(\d+),[^\]]+\]\s+(.+)")
            
            for line in lines:
                match = error_start_re.search(line)
                if match:
                    if current_error:
                        error_messages.append("\n".join(current_error))
                    current_error = [f"{match.group(1)}:{match.group(2)} - {match.group(3)}"]
                elif line.strip().startswith("[ERROR]") and current_error:
                    # Append subsequent [ERROR] lines to current error context
                    cleaned = line.replace("[ERROR]", "").strip()
                    if cleaned:
                        current_error.append(cleaned)
                elif current_error and line.strip().startswith(("symbol:", "location:")):
                    # Sometimes symbol/location lines don't have [ERROR] prefix in some outputs
                    current_error.append(line.strip())
                elif not line.strip().startswith("[ERROR]") and current_error and not line.strip():
                    # Empty line or non-error line ends the block
                    error_messages.append("\n".join(current_error))
                    current_error = []
            
            if current_error:
                error_messages.append("\n".join(current_error))

            if error_messages:
                # Count unique files for the summary
                unique_files = set()
                for msg in error_messages:
                    if ":" in msg:
                        path_part = msg.split(":")[0].strip()
                        if path_part.endswith(".java"):
                            unique_files.add(path_part)
                
                self.logger.info(f"{PREFIX}Extracted {len(error_messages)} total error(s) across {len(unique_files)} unique file(s)")
                return BuildDiagnosis(
                    root_cause=f"Compilation errors in {len(unique_files)} file(s).",
                    confidence=0.95,
                    summary=f"Java compilation failed with syntax or structural errors.",
                    failure_type="compilation_error",
                    error_messages=error_messages,
                    missing_files=list(missing_packages) # Reuse missing_files for package names
                )
            if not error_messages:
                # Fallback: We detected COMPILATION ERROR but regex didn't match
                self.logger.warn(f"{PREFIX}Detected COMPILATION ERROR but couldn't extract file paths via regex, falling back to LLM")
                # Do not return here, let it fall through to LLM fallback below

        # Fallback to LLM for complex extraction
        prompt = f"""
        Analyze this Java Maven build failure. Return a JSON object with:
        - root_cause (string): What specifically failed?
        - failure_type (enum): compilation, missing_dependency, missing_file, unknown
        - error_messages (list[string]): Key error lines
        - missing_files (list[string]): Full paths of any files that seem missing

        LOGS:
        {combined[-6000:]} 
        """
        
        try:
            # Simple wrapper for now - in prod use structured output
            resp = self.llm.generate_text(system="You are a Java Build Expert. Output ONLY JSON.", user=prompt)
            # Basic parsing (improve with structured output parser later)
            
            # Extract JSON block
            match = re.search(r"\{.*\}", resp, re.DOTALL)
            if match:
                data = json.loads(match.group(0))
                return BuildDiagnosis(
                    root_cause=data.get("root_cause", "Unknown build failure"),
                    confidence=0.7,
                    summary=f"LLM diagnosed: {data.get('root_cause')}",
                    failure_type=data.get("failure_type", "unknown"),
                    missing_files=data.get("missing_files", [])
                )
        except Exception as e:
            self.logger.warn(f"{PREFIX}LLM analysis failed: {e}")

        return BuildDiagnosis(
            root_cause="Unknown failure (analysis failed)",
            confidence=0.0,
            summary="Could not diagnose build failure.",
            failure_type="unknown"
        )

    def generate_fix(
        self,
        diagnosis: BuildDiagnosis,
        workspace_path: str,
        attempted_files: set[str] | None = None,
        domain_models: list[str] | None = None,
        api_test_context: dict[str, str] | None = None,
        prior_failed_symbols: list[str] | None = None,
    ) -> AgentFix | None:
        """Generate a concrete fix for the diagnosis.

        Args:
            diagnosis: The build diagnosis
            workspace_path: Path to the workspace
            attempted_files: Set of file paths that have already been attempted (to avoid infinite loops)
            domain_models: Optional list of discovered domain models to provide context for missing symbols
            api_test_context: Optional map from absolute file path to controller/DTO context for *ControllerIT.java fixes
            prior_failed_symbols: List of symbol names that failed in prior attempts (DO NOT USE these)
        """
        
        if diagnosis.failure_type == "network_or_corrupted_artifact":
            return AgentFix(
                diagnosis=diagnosis,
                explanation="Detected transient network error or corrupted Maven artifact. Triggering force-update of dependencies.",
                shell_commands=["mvn -U clean compile"]
            )

        # Spring Security 6 DSL migration — auto-fix deprecated configurer patterns
        if diagnosis.failure_type == "spring_security_dsl":
            patches = []
            # SS6 DSL migration mappings: old chained-style → lambda-style
            DSL_MIGRATIONS = [
                # headers() sub-configurers
                (r'\.headers\(\)\s*\.referrerPolicy\(([^)]*?)\)', '.headers(h -> h.referrerPolicy(rp -> rp.policy(\\1)))'),
                (r'\.headers\(\)\s*\.permissionsPolicy\(\)\s*\.policy\(([^)]+)\)', '.headers(h -> h.permissionsPolicy(pp -> pp.policy(\\1)))'),
                (r'\.headers\(\)\s*\.contentSecurityPolicy\(([^)]+)\)', '.headers(h -> h.contentSecurityPolicy(csp -> csp.policyDirectives(\\1)))'),
                (r'\.headers\(\)\s*\.frameOptions\(\)\s*\.deny\(\)', '.headers(h -> h.frameOptions(fo -> fo.deny()))'),
                (r'\.headers\(\)\s*\.frameOptions\(\)\s*\.sameOrigin\(\)', '.headers(h -> h.frameOptions(fo -> fo.sameOrigin()))'),
                (r'\.headers\(\)\s*\.xssProtection\(\)\s*\.block\(false\)', '.headers(h -> h.xssProtection(xss -> xss.disable()))'),
                (r'\.headers\(\)\s*\.httpStrictTransportSecurity\(\)', '.headers(h -> h.httpStrictTransportSecurity(hsts -> hsts.includeSubDomains(true)))'),
                (r'\.headers\(\)\s*\.cacheControl\(\)', '.headers(h -> h.cacheControl(cc -> {}))'),
                # Top-level configurers
                (r'\.csrf\(\)\s*\.disable\(\)', '.csrf(csrf -> csrf.disable())'),
                (r'\.httpBasic\(\)', '.httpBasic(Customizer.withDefaults())'),
                (r'\.formLogin\(\)\s*\.disable\(\)', '.formLogin(form -> form.disable())'),
                (r'\.sessionManagement\(\)\s*\.sessionCreationPolicy\(([^)]+)\)',
                 '.sessionManagement(sm -> sm.sessionCreationPolicy(\\1))'),
                (r'\.cors\(\)\s*\.and\(\)', '.cors(Customizer.withDefaults())'),
                # Remove .and() chaining (SS6 lambda-style doesn't use .and())
                (r'\.and\(\)\s*\.', '.'),
            ]
            for file_path in (diagnosis.missing_files or []):
                if not os.path.exists(file_path):
                    continue
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                    original = content
                    for pattern, replacement in DSL_MIGRATIONS:
                        content = re.sub(pattern, replacement, content)
                    # Add Customizer import if httpBasic(Customizer.withDefaults()) was introduced
                    if 'Customizer.withDefaults()' in content and 'import org.springframework.security.config.Customizer' not in content:
                        content = content.replace(
                            'import org.springframework.security.config.annotation.web.builders.HttpSecurity;',
                            'import org.springframework.security.config.annotation.web.builders.HttpSecurity;\nimport org.springframework.security.config.Customizer;'
                        )
                    if content != original:
                        patches.append(FilePatch(path=file_path, content=content, mode="overwrite"))
                        self.logger.info(f"{PREFIX}Migrated Spring Security DSL in {os.path.basename(file_path)}")
                except Exception as e:
                    self.logger.error(f"{PREFIX}Failed to migrate DSL in {file_path}: {e}")

            if patches:
                return AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Migrated {len(patches)} file(s) from deprecated Spring Security chained DSL to lambda-style DSL (SS6 compatible).",
                    file_patches=patches
                )
            else:
                # If regex migration didn't work, fall through to LLM-based compilation fix
                self.logger.info(f"{PREFIX}Regex-based SS6 migration didn't apply. Falling through to LLM-based repair.")

        if diagnosis.failure_type == "missing_file":
            patches = []
            for missing in diagnosis.missing_files:
                if "application-test.properties" in missing:
                    self.logger.info(f"{PREFIX}Generating default application-test.properties")
                    # Generate a sane default for testing
                    content = """# Verification-friendly defaults generated by Atlas
spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=create-drop
server.port=-1
"""
                    full_path = f"{workspace_path}/{missing}" if not missing.startswith("/") else missing
                    patches.append(FilePatch(path=full_path, content=content, mode="create"))
            
            if patches:
                return AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Created missing configuration files: {', '.join(diagnosis.missing_files)}",
                    file_patches=patches
                )
        
        if diagnosis.failure_type == "dependency_conflict":
            # Strategies for dependency conflicts
            # Progressive version retry strategy based on what's already been attempted
            all_patches = []
            
            # Version strategy: Try stable versions from newest to oldest
            version_strategy = ["1.10.2", "1.9.3", "1.8.2", "1.7.2", "1.6.3"]
            
            for root, dirs, files in os.walk(workspace_path):
                    if "pom.xml" in files:
                        pom_path = os.path.join(root, "pom.xml")
                        try:
                            text = open(pom_path, "r", encoding="utf-8", errors="ignore").read()
                            
                            # Determine target version for THIS file based on what's already there
                            current_version = None
                            match = re.search(r"<artifactId>junit-platform-launcher</artifactId>\s*<version>(.*?)</version>", text)
                            if match:
                                current_version = match.group(1).strip()
                            
                            # Pick next version
                            target_version = version_strategy[0] # Default to first
                            if current_version in version_strategy:
                                idx = version_strategy.index(current_version)
                                if idx + 1 < len(version_strategy):
                                    target_version = version_strategy[idx + 1]
                                else:
                                    target_version = version_strategy[-1] # Stick to last if exhausted
                            
                            self.logger.info(f"{PREFIX}Determined target JUnit version {target_version} for {os.path.basename(pom_path)}")

                            # Check if this POM uses JUnit 5 (direct or transitive via Spring Boot)
                            # Look for: junit-jupiter, junit-platform, spring-boot-starter-test, or maven-surefire-plugin
                            is_junit5 = (
                                "junit-jupiter" in text or 
                                "junit-platform" in text or
                                "spring-boot-starter-test" in text or
                                "maven-surefire-plugin" in text
                            )
                            has_deps_block = "<dependencies>" in text and "</dependencies>" in text
                            
                            # Only inject if it's a JUnit 5 project and has dependencies block
                            if is_junit5 and has_deps_block:
                                # Try to detect version from existing junit dependencies
                                detected_version = None
                                
                                # Try 1: Explicit junit-jupiter version
                                v_match = re.search(r"<artifactId>junit-jupiter</artifactId>.*?<version>(.*?)</version>", text, re.DOTALL)
                                if v_match:
                                    major_ver = v_match.group(1).strip()  # e.g. 5.9.1
                                    # Convert 5.x.y to 1.x.y for platform
                                    if major_ver.startswith("5."):
                                        detected_version = "1." + major_ver[2:]
                                
                                # Try 2: Property-based version
                                if not detected_version:
                                    prop_match = re.search(r"<junit-jupiter.version>(.*?)</junit-jupiter.version>", text)
                                    if prop_match:
                                        major_ver = prop_match.group(1).strip()
                                        if major_ver.startswith("5."):
                                            detected_version = "1." + major_ver[2:]
                                
                                # Use detected version or fallback to strategy
                                version = detected_version if detected_version else target_version
                                
                                # Check if we need to update existing launcher or add new one
                                if "junit-platform-launcher" in text:
                                    # Already exists - update version if different
                                    current_version_match = re.search(
                                        r"<artifactId>junit-platform-launcher</artifactId>\s*<version>(.*?)</version>",
                                        text
                                    )
                                    if current_version_match:
                                        current_version = current_version_match.group(1).strip()
                                        if current_version != version:
                                            self.logger.info(f"{PREFIX}Updating junit-platform-launcher from {current_version} to {version} in {os.path.basename(pom_path)}")
                                            # Replace the version
                                            new_text = re.sub(
                                                r"(<artifactId>junit-platform-launcher</artifactId>\s*<version>).*?(</version>)",
                                                rf"\g<1>{version}\g<2>",
                                                text
                                            )
                                            all_patches.append(FilePatch(path=pom_path, content=new_text, mode="overwrite"))
                                else:
                                    # Doesn't exist - add it
                                    self.logger.info(f"{PREFIX}Adding junit-platform-launcher version {version} to {os.path.basename(pom_path)}")
                                    snippet = f"""
        <dependency>
            <groupId>org.junit.platform</groupId>
            <artifactId>junit-platform-launcher</artifactId>
            <version>{version}</version>
            <scope>test</scope>
        </dependency>
"""
                                    idx = text.find("</dependencies>")
                                    new_text = text[:idx] + snippet + text[idx:]
                                    all_patches.append(FilePatch(path=pom_path, content=new_text, mode="overwrite"))
                        except Exception as e:
                            self.logger.warn(f"{PREFIX}Error processing {pom_path}: {e}")
                            continue
            
            if all_patches:
                return AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Injecting/Updating junit-platform-launcher to compatible version into {len(all_patches)} module(s) to resolve JUnit 5 version mismatch.",
                    file_patches=all_patches
                )
        
        if diagnosis.failure_type == "missing_dependency":
             patches = []
             for missing in diagnosis.missing_files:
                 # missing format: groupId:artifactId:version
                 if ":" not in missing: continue
                 g, a, v = missing.split(":")[:3]
                 
                 self.logger.info(f"{PREFIX}Attempting to fix missing dependency {g}:{a}:{v}")
                 
                 # 1. Ask LLM for a stable version
                 prompt = f"""
You are a Maven dependency expert. The build failed because it cannot resolve this dependency:
{g}:{a}:{v}
It might be a wrong version, a network issue, or a non-existent version.
Suggest a STABLE, WIDELY USED version for this artifact that is likely to exist in Maven Central.
If {v} seems too new, suggest the previous stable release.
Return ONLY the version string (e.g. \"1.48.0\"). Do not return XML.
"""
                 suggestion = self.llm.generate_text(
                     system="You are a build expert. output only version number.",
                     user=prompt
                 ).strip()
                 
                 # Clean up suggestion
                 suggestion = suggestion.replace("Version:", "").strip()
                 
                 if suggestion and suggestion != v:
                     self.logger.info(f"{PREFIX}LLM suggested switching from {v} to {suggestion}")
                     
                     # 2. Patch POMs
                     for root, dirs, files in os.walk(workspace_path):
                        if "pom.xml" in files:
                            pom_path = os.path.join(root, "pom.xml")
                            try:
                                content = open(pom_path, "r", encoding="utf-8", errors="ignore").read()
                                # Try to find the version tag for this artifact
                                # Pattern: <artifactId>a</artifactId>...<version>v</version>
                                # This is tricky with regex, so strictly look for the artifact definition
                                if f"<artifactId>{a}</artifactId>" in content:
                                    # Simple replace if version is explicit
                                    # We replace <version>v</version> inside the dependency block for this artifact
                                    # This regex looks for artifactId followed by version within some distance
                                    pattern = re.compile(f"(<artifactId>{re.escape(a)}</artifactId>\\s*<version>){re.escape(v)}(</version>)")
                                    if pattern.search(content):
                                        new_content = pattern.sub(f"\\g<1>{suggestion}\\g<2>", content)
                                        patches.append(FilePatch(path=pom_path, content=new_content, mode="overwrite"))
                            except Exception as e:
                                self.logger.error(f"{PREFIX}Failed to process POM {pom_path}: {e}")

             if patches:
                return AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Updated dependencies to stable versions (e.g. {suggestion}) to fix resolution failures.",
                    file_patches=patches
                )

        if diagnosis.failure_type == "compilation_error":
            # Use LLM to fix compilation errors
            self.logger.info(f"{PREFIX}Attempting to repair {len(diagnosis.error_messages)} compilation error(s)...")
            patches = []
            
            # ── BLOCKLIST: Delete generated tests that use deprecated Spring patterns ──
            files_to_delete = set()
            for err in diagnosis.error_messages:
                for pattern in DEPRECATED_SPRING_PATTERNS:
                    if pattern in err:
                        # Extract the file path from error like "/path/File.java:[line]:"
                        if ":" in err:
                            err_file = err.split(":")[0].strip()
                            # Only auto-delete generated test files, not source files
                            if "src/test/" in err_file or "src\\test\\" in err_file:
                                files_to_delete.add(err_file)
                                self.logger.info(f"{PREFIX}🚫 Blocklisted: {os.path.basename(err_file)} uses deprecated '{pattern}'")
            
            if files_to_delete:
                delete_patches = []
                for fpath in files_to_delete:
                    if os.path.exists(fpath):
                        os.remove(fpath)
                        self.logger.info(f"{PREFIX}🗑️  Deleted blocklisted test: {os.path.basename(fpath)}")
                return AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Deleted {len(files_to_delete)} generated test(s) using deprecated Spring Security APIs (unfixable)",
                    file_patches=delete_patches
                )
            
            # CHECK FOR MISSING PACKAGES FIRST
            # If we have missing packages that we know how to fix, inject those dependencies
            if diagnosis.missing_files: # We stored package names here in analyze()
                for pkg in diagnosis.missing_files:
                    # Find a match in our hints
                    matching_dep = None
                    for known_pkg, dep_snippet in MISSING_PACKAGE_DEPS.items():
                        if pkg.startswith(known_pkg):
                            matching_dep = dep_snippet
                            break
                    
                    if matching_dep:
                        # Find the failing module to inject dependency
                        # Usually the module containing the failing Java files
                        failing_modules = set()
                        for err in diagnosis.error_messages:
                            if ":" in err:
                                path = err.split(":")[0]
                                # Map back to pom.xml - find nearest pom.xml in parent directories
                                current = os.path.dirname(path)
                                while current and len(current) >= len(workspace_path):
                                    if os.path.exists(os.path.join(current, "pom.xml")):
                                        failing_modules.add(os.path.join(current, "pom.xml"))
                                        break
                                    current = os.path.dirname(current)
                        
                        for pom_path in failing_modules:
                            try:
                                text = open(pom_path, "r", encoding="utf-8", errors="ignore").read()
                                if matching_dep.split("<artifactId>")[1].split("</artifactId>")[0] not in text:
                                    self.logger.info(f"{PREFIX}Injecting missing dependency for package {pkg} into {os.path.basename(pom_path)}")
                                    idx = text.find("</dependencies>")
                                    if idx != -1:
                                        new_text = text[:idx] + matching_dep + text[idx:]
                                        patches.append(FilePatch(path=pom_path, content=new_text, mode="overwrite"))
                            except Exception as e:
                                self.logger.error(f"{PREFIX}Failed to inject dependency into {pom_path}: {e}")

            
            # Initialize attempted_files tracking
            if attempted_files is None:
                attempted_files = set()
            
            # Process more error files per retry (up to 10 instead of 3)
            error_files = set()
            for error_msg in diagnosis.error_messages:
                # Extract file path from error message (format: "/path/file.java:line - error")
                if ":" in error_msg:
                    file_path = error_msg.split(":")[0]
                    # Only add if it's a Java file and hasn't been attempted yet
                    if file_path.endswith(".java") and file_path not in attempted_files:
                        error_files.add(file_path)
            
            # Limit to 3 files per attempt to keep each cycle under ~3 minutes
            # Unrepairable files will be deleted by the confidence gate (Phase 9)
            error_files = set(list(error_files)[:3])
            
            self.logger.info(f"{PREFIX}TRACE error_files final list: {error_files}")

            
            if not error_files:
                self.logger.warn(f"{PREFIX}All error files have been attempted already, cannot make progress")
                return None
            
            # Fallback: If we couldn't extract file paths, search workspace for .java files
            if not error_files: 
                self.logger.warn(f"{PREFIX}No file paths in error messages, searching workspace for Java files...")
                for root, dirs, files in os.walk(workspace_path):
                    if "src/main/java" in root:
                        for file in files:
                            if file.endswith(".java") and len(error_files) < 10:
                                error_files.add(os.path.join(root, file))

            # Proactive Context Gathering: If we have "cannot find symbol", 
            # try to find the source of the missing class and include its signatures in the prompt.
            symbol_context = ""
            peek_classes = set()
            for err in diagnosis.error_messages:
                if "cannot find symbol" in err.lower():
                    # Pattern 1: method/variable in a class location
                    # [ERROR] ... cannot find symbol symbol: method of(...) location: class com.banking.core.domain.Money
                    match_loc = re.search(r"location:\s+class\s+([\w\.]+)", err)
                    if match_loc:
                        peek_classes.add(match_loc.group(1))
                    
                    # Pattern 2: variable of type Y
                    # [ERROR] ... cannot find symbol symbol: method email() location: variable x of type com.webapp...OtpRequest
                    match_type = re.search(r"location:\s+variable\s+\w+\s+of\s+type\s+([\w\.]+)", err)
                    if match_type:
                        peek_classes.add(match_type.group(1))

                    # Pattern 3: class itself is missing
                    # [ERROR] ... cannot find symbol symbol: class Playwright
                    match_sym = re.search(r"symbol:\s+class\s+([\w\.]+)", err)
                    if match_sym:
                        peek_classes.add(match_sym.group(1))

                if "cannot be applied to given types" in err.lower():
                    # Pattern 4: constructor/method signature mismatch
                    # [ERROR] ... constructor ResetPasswordRequest in record com.webapp...ResetPasswordRequest cannot be applied to given types
                    match_sig = re.search(r"(?:constructor|method)\s+\w+\s+in\s+(?:class|record|interface|enum)\s+([\w\.]+)\s+cannot\s+be\s+applied", err)
                    if match_sig:
                        peek_classes.add(match_sig.group(1))
            
            if peek_classes:
                self.logger.info(f"{PREFIX}Attempting to peek at {len(peek_classes)} class(es) for context...")
                
                # Use contract service for accurate extraction (handles records, Lombok, etc.)
                try:
                    registry = RepoContractRegistry(workspace_path)
                except Exception:
                    registry = None
                
                for target_model in peek_classes:
                    # Strategy 1: Use contract service (most accurate — handles records, Lombok, builders)
                    if registry:
                        try:
                            source = registry.get_source(target_model)
                            if source:
                                contract = extract_class_contract(source)
                                if contract:
                                    contract_text = format_contracts_for_prompt({contract.class_name: contract})
                                    if contract_text:
                                        symbol_context += f"\n--- Contract for {target_model} ---\n{contract_text}\n"
                                        self.logger.info(f"{PREFIX}Extracted contract for {target_model} (record={contract.is_record}, constructors={len(contract.constructors)})")
                                        continue  # Successfully extracted, skip fallback
                        except Exception as e:
                            self.logger.warn(f"{PREFIX}Contract extraction failed for {target_model}: {e}")
                    
                    # Strategy 2: Fallback to regex-based extraction
                    actual_path = None
                    model_path = os.path.join(workspace_path, target_model.replace('.', '/') + ".java")
                    if os.path.exists(model_path):
                        actual_path = model_path
                    else:
                        # Deep search if standard path fails
                        model_filename = target_model.split('.')[-1] + ".java"
                        for root, _, files in os.walk(workspace_path):
                            if model_filename in files:
                                try:
                                    with open(os.path.join(root, model_filename), "r", encoding="utf-8", errors="ignore") as f:
                                        content = f.read()
                                        if f"package {'.'.join(target_model.split('.')[:-1])}" in content:
                                            actual_path = os.path.join(root, model_filename)
                                            break
                                except Exception:
                                    continue
                    
                    if actual_path:
                        try:
                            with open(actual_path, "r", encoding="utf-8", errors="ignore") as f:
                                content = f.read()
                            
                            # Try contract service on file content directly
                            contract = extract_class_contract(content)
                            if contract:
                                contract_text = format_contracts_for_prompt({contract.class_name: contract})
                                if contract_text:
                                    symbol_context += f"\n--- Contract for {target_model} ---\n{contract_text}\n"
                                    self.logger.info(f"{PREFIX}Extracted contract for {target_model} via file (record={contract.is_record})")
                                    continue
                            
                            # Final fallback: regex-based extraction
                            pkg_match = re.search(r"package\s+([\w\.]+);", content)
                            pkg = pkg_match.group(1) if pkg_match else ""
                            
                            signature_lines = []
                            # Match class/interface/enum/record declarations
                            class_matches = re.findall(r"(public|protected)\s+(?:abstract\s+)?(?:class|interface|enum|record)\s+\w+.*?(?=\{|\n)", content)
                            signature_lines.extend([m.strip() for m in class_matches])
                            
                            # Match constructors and methods
                            member_matches = re.finditer(r"(?:@\w+\s+)*(public|protected)\s+(?:[\w<>\[\]]+\s+)?\w+\s*\([^)]*\).*?(?=\{|\n|;)", content)
                            for m in member_matches:
                                sig = m.group(0).strip()
                                if "{" in sig: sig = sig.split("{")[0].strip()
                                signature_lines.append(sig)
                            
                            signature_lines = sorted(list(set(signature_lines)))
                            
                            if signature_lines:
                                symbol_context += f"\n--- Source Context for {target_model} ---\n"
                                symbol_context += f"Package: {pkg}\n"
                                symbol_context += "Signatures:\n" + "\n".join(signature_lines[:30]) + "\n"
                        except Exception:
                            continue
                
                # Add hints for common missing symbols
                missing_hints = []
                for peek_cls in peek_classes:
                    if peek_cls in COMMON_TEST_HINTS:
                        missing_hints.append(COMMON_TEST_HINTS[peek_cls])
                
                if missing_hints:
                    symbol_context += "\n--- Common Import Hints ---\n"
                    symbol_context += "\n".join(missing_hints) + "\n"

            for file_path in error_files:
                try:
                    if not os.path.exists(file_path):
                        continue
                    
                    # Read the broken file
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        broken_code = f.read()
                    
                    # CRITICAL FIX: Detect if file has multiple package declarations (corrupted file)
                    # This happens when multiple classes are concatenated into one file
                    package_matches = re.findall(r'^\s*package\s+[\w.]+;', broken_code, re.MULTILINE)
                    package_count = len(package_matches)
                    if package_count > 1:
                        self.logger.warn(f"{PREFIX}Detected {package_count} package declarations in {os.path.basename(file_path)} - file appears corrupted with concatenated classes")
                        self.logger.info(f"{PREFIX}Splitting concatenated classes into separate sections...")
                        
                        # Split by package declaration and keep only the FIRST class
                        lines = broken_code.split('\n')
                        first_package_start = 0
                        second_package_start = -1
                        
                        for i, line in enumerate(lines):
                            if line.strip().startswith("package ") and i > 0:
                                # Found second package declaration
                                second_package_start = i
                                break
                        
                        if second_package_start > 0:
                            # Keep only the first class (everything before second package)
                            fixed_code = '\n'.join(lines[:second_package_start]).rstrip()
                            self.logger.info(f"{PREFIX}Split file - keeping first class, discarding {package_count - 1} concatenated class(es)")
                            
                            # Validate the extracted class has proper structure
                            if "class " in fixed_code or "interface " in fixed_code:
                                patches.append(FilePatch(path=file_path, content=fixed_code, mode="overwrite"))
                                self.logger.info(f"{PREFIX}Successfully extracted first class from {os.path.basename(file_path)}")
                                continue
                    
                    # Extract relevant error messages for this file
                    file_errors = [msg for msg in diagnosis.error_messages if file_path in msg]
                    
                    # Inject controller/DTO context for *ControllerIT.java so fixes match real API
                    api_ctx = ""
                    if api_test_context:
                        norm_path = os.path.normpath(file_path)
                        for key, ctx in api_test_context.items():
                            if os.path.normpath(key) == norm_path or os.path.basename(key) == os.path.basename(file_path):
                                api_ctx = "\n\nAPI INTEGRATION TEST CONTEXT (use these exact types, request/response bodies, and controller endpoints):\n" + ctx + "\n"
                                break
                    
                    # Build fix strategies based on error patterns
                    strategies = []
                    if any("cannot find symbol" in err.lower() for err in file_errors):
                        strategies.append("- For 'cannot find symbol': Check if it's from a dependency module (e.g., banking-core, banking-account).")
                        strategies.append("- If it's a custom annotation without definition, comment it out rather than breaking the code.")
                        strategies.append("- Preserve existing imports - do NOT remove imports from dependency modules.")
                    
                    if any("cannot be applied to given types" in err.lower() for err in file_errors):
                        strategies.append("- CONSTRUCTOR/METHOD MISMATCH: The error shows 'required' vs 'found' argument types. You MUST match the 'required' signature EXACTLY.")
                        strategies.append("- For Java RECORDS: The canonical constructor takes ALL fields in declaration order. Check the 'Source Context' or 'Contract' section above for the exact parameters.")
                        strategies.append("- Count the arguments carefully. If required is (String, String, String) and found is (String, String), you are MISSING an argument.")
                        strategies.append("- Look at the error's 'required' line to see the exact types needed and pass ALL of them.")
                    
                    if any("class, interface, or enum expected" in err.lower() for err in file_errors):
                        strategies.append("- SYNTAX ERROR: Check for missing '}' or misplaced code outside class body.")
                        strategies.append("- Ensure all class/method/block braces are properly matched.")
                    
                    if any("does not exist" in err.lower() for err in file_errors):
                        strategies.append("- MISSING PACKAGE: If an import references a package that does not exist (e.g., org.apache.commons.text, org.owasp.encoder), REMOVE the import and replace the usage with standard Java alternatives.")
                        strategies.append("- Do NOT swap one missing external library for another (e.g., don't replace commons.text with commons.lang3 if neither exists).")
                        strategies.append("- For input sanitization, use standard Java: str.replaceAll(\"[^a-zA-Z0-9 ]\", \"\") or org.springframework.web.util.HtmlUtils.htmlEscape() if Spring is available.")
                    
                    if any("package" in err.lower() and "does not exist" not in err.lower() for err in file_errors):
                        strategies.append("- Keep the package declaration intact.")

                    if any("httpStrictTransportSecurity" in err for err in file_errors):
                        strategies.append(SPRING_SECURITY_DSL_RULES)
                    
                    if any("cannot be converted to java.lang.Throwable" in err for err in file_errors):
                        strategies.append(LOGGING_SIGNATURE_RULES)

                    fix_guidance = "\n".join(strategies)
                    if fix_guidance:
                        fix_guidance = "\nFix Strategies:\n" + fix_guidance + "\n"

                    # PRIOR FAILURE AWARENESS: If symbols were tried before and failed, tell LLM to NOT use them
                    prior_symbols_warning = ""
                    if prior_failed_symbols:
                        combined_toxic = set(prior_failed_symbols)
                        # Add common Spring Security hallucinations to toxic list proactively
                        combined_toxic.update(["contentTypeOptionsEnabled", "HeaderValue", "XXssProtection"])
                        
                        prior_symbols_warning = (
                            "\n⚠️ PRIOR ATTEMPT FAILED or TOXIC SYMBOLS: The following symbols/APIs do NOT exist in this project's dependencies or are known hallucinations. "
                            "Do NOT use them under any circumstances. REMOVE all references to them and use standard alternatives:\n"
                            + "\n".join(f"  - {s}" for s in sorted(list(combined_toxic)))
                            + "\nCRITICAL: You MUST take a COMPLETely DIFFERENT approach. If the broken symbol is from Spring Security "
                            "(e.g., HeaderValue, XXssProtection, contentTypeOptionsEnabled), REMOVE the entire failing header configuration method/block. "
                            "Spring Security headers are enabled by default; it is better to remove a redundant configuration that doesn't compile "
                            "than to leave compilation errors.\n"
                        )

                    # Extract Spring version from pom.xml for version-aware fixes
                    spring_version_ctx = ""
                    try:
                        for root_dir, _, fnames in os.walk(workspace_path):
                            if "pom.xml" in fnames:
                                pom_content = open(os.path.join(root_dir, "pom.xml"), "r", encoding="utf-8", errors="ignore").read()
                                sb_match = re.search(r"<spring-boot\.version>([^<]+)</spring-boot\.version>", pom_content)
                                if not sb_match:
                                    sb_match = re.search(r"<parent>[\s\S]*?<artifactId>spring-boot-starter-parent</artifactId>[\s\S]*?<version>([^<]+)</version>", pom_content)
                                if sb_match:
                                    spring_version_ctx = f"\nPROJECT SPRING BOOT VERSION: {sb_match.group(1)}. Use ONLY APIs available in this version.\n"
                                    break
                            if root_dir.count(os.sep) - workspace_path.count(os.sep) > 2:
                                break
                    except Exception:
                        pass
                    
                    # Prepare ALL error messages for this file (not just first 5)
                    all_errors_text = "\n".join(file_errors) if len(file_errors) <= 20 else "\n".join(file_errors[:20]) + f"\n... and {len(file_errors) - 20} more errors"
                    
                    # Use LLM to fix the code
                    prompt = f"""
You are a Java compilation error fixer for a multi-module Maven project.

CONTEXT: This is part of a banking system with modules: banking-core, banking-account, banking-transaction, banking-api
These modules depend on each other. DO NOT remove imports or references to these modules.
{spring_version_ctx}{prior_symbols_warning}{symbol_context}{api_ctx}
COMPILATION ERRORS IN THIS FILE:
{all_errors_text}
{fix_guidance}

BROKEN CODE:
```java
{broken_code}
```

INSTRUCTIONS:
1. Fix ALL compilation errors in the first attempt.
2. PRESERVE all imports and dependencies from other modules (com.banking.*).
3. If an annotation is undefined (e.g., @ValidateOrigin), comment it out: // @ValidateOrigin
4. Fix syntax errors (missing braces, misplaced code) aggressively.
5. Ensure all classes/methods are properly closed with matching braces.
6. DO NOT remove functionality - only fix compilation errors.
7. CRITICAL: If a package "does not exist" (e.g., org.apache.commons.text, org.owasp.encoder), REMOVE the import entirely and replace the usage with standard Java or Spring alternatives. Do NOT replace it with another external library that may also not exist.
   - For HTML/XSS escaping: use org.springframework.web.util.HtmlUtils.htmlEscape() (already available in Spring projects)
   - For general string escaping: use standard Java String methods like replaceAll()
8. ACCESSOR & SIGNATURE CONVENTIONS: 
   - If the error is 'cannot find symbol' for a method like 'email()', use the style in the "Source Context" or "Contract" section (Bean vs Record).
   - If the error is 'cannot be applied to given types' (constructor mismatch), look at the provided constructor signatures in "Source Context" or "Contract" section and use the CORRECT arguments.
   - For Java RECORDS: Records have an implicit canonical constructor that takes ALL declared fields in order. If the Contract says `Record constructor: Foo(String a, String b, String c)`, you MUST pass exactly 3 String arguments.
   - DO NOT GUESS! Read the provided signatures and contracts.
9. JAVA RECORDS:
   - Records use accessor methods named after the field (e.g., `record.email()` NOT `record.getEmail()`).
   - Records are immutable — no setters. Use the canonical constructor to create instances.
   - The canonical constructor parameters match the record components in declaration order.
{SENIOR_QA_INSTRUCTIONS}
10. Return ONLY the complete fixed Java code, NO markdown formatting, NO explanations.
"""
                    
                    self.logger.info(f"{PREFIX}Repairing {os.path.basename(file_path)} via LLM...")
                    fixed_code = self.llm.generate_text(
                        system="You are a Java code repair expert. Output only raw Java code, no explanations.",
                        user=prompt
                    )
                    
                    if "```java" in fixed_code:
                        match = re.search(r"```java\s*(.*?)\s*```", fixed_code, re.DOTALL | re.IGNORECASE)
                        if match:
                            fixed_code = match.group(1).strip()
                    elif "```" in fixed_code:
                        match = re.search(r"```\w*\s*(.*?)\s*```", fixed_code, re.DOTALL)
                        if match:
                            fixed_code = match.group(1).strip()
                    
                    # Final fallback for backtick noise
                    fixed_code = fixed_code.replace("```java", "").replace("```", "").strip()
                    
                    # Log summary of what we're fixing
                    self.logger.info(f"{PREFIX}Fixed {os.path.basename(file_path)} - addressed {len(file_errors)} error(s)")
                    
                    # VALIDATION: Check brace balance
                    open_braces, close_braces = _count_unquoted_braces(fixed_code)
                    
                    if open_braces != close_braces:
                        self.logger.warn(f"{PREFIX}Unbalanced braces detected in fix for {os.path.basename(file_path)} ({{={open_braces}, }}={close_braces})")
                        diff = open_braces - close_braces
                        if diff > 0:
                            self.logger.info(f"{PREFIX}Appending {diff} missing closing braces...")
                            fixed_code += "\n" + ("}\n" * diff)
                        elif diff < 0:
                            self.logger.warn(f"{PREFIX}Too many closing braces detected. LLM output might be truncated in the middle.")
                    
                    # Basic sanity check
                    is_java = any(kw in fixed_code for kw in ["class ", "interface ", "enum ", "record "])
                    if is_java and "package " in fixed_code:
                        patches.append(FilePatch(path=file_path, content=fixed_code, mode="overwrite"))
                        self.logger.info(f"{PREFIX}Successfully generated fix for {os.path.basename(file_path)}")
                    else:
                        self.logger.warn(f"{PREFIX}LLM output doesn't look like valid Java (missing class/package), skipping {os.path.basename(file_path)}")
                        
                except Exception as e:
                    self.logger.error(f"{PREFIX}Failed to repair {file_path}: {e}")
            
            if patches:
                return AgentFix(
                    diagnosis=diagnosis,
                    explanation=f"Repaired {len(patches)} Java file(s) with compilation errors using AI.",
                    file_patches=patches
                )

        return None
