"""
deployless CLI — build, validate, deploy, clean, secrets
"""
import sys
import subprocess
from pathlib import Path

import click

from deployless.compiler.main import compile_project
from deployless.compiler.validator import validate, ValidationError, check_existing_resources
from deployless.compiler.checker import run_checks
from deployless.compiler.env_file import parse_env_file, push_secrets, sync_secrets
from deployless.core.config import load_config
from deployless.core.discovery import discover_features
from deployless.core.metadata import reset_registry


@click.group()
@click.version_option(package_name="deployless", prog_name="deployless")
def cli():
    """deployless — compile your Python web app to AWS SAM serverless."""


@cli.command()
@click.option("-o", "--output", default="template.yaml", help="Output template file path.")
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--dry-run", is_flag=True, help="Validate and show plan without writing files.")
@click.option("-v", "--verbose", is_flag=True, help="Verbose output.")
def build(output, stage, dry_run, verbose):
    """Generate SAM template and build .dist/ Lambda packages."""
    try:
        compile_project(stage=stage, output=output, dry_run=dry_run, verbose=verbose)
    except ValidationError as e:
        click.echo(click.style("\n[deployless] Build failed — validation errors:\n", fg="red"))
        for error in e.errors:
            click.echo(click.style(f"  {error}", fg="red"))
        sys.exit(1)
    except Exception as e:
        click.echo(click.style(f"\n[deployless] Build failed: {e}", fg="red"))
        raise


@cli.command()
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--check-existing", is_flag=True, help="Verify existing=True resources exist in AWS.")
@click.option("-v", "--verbose", is_flag=True)
def validate_cmd(stage, check_existing, verbose):
    """Validate project configuration without generating files."""
    try:
        state = compile_project(stage=stage, dry_run=True, verbose=verbose)
        click.echo(click.style("[deployless] Validation passed.", fg="green"))
    except ValidationError as e:
        click.echo(click.style("[deployless] Validation failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    if check_existing:
        click.echo("[deployless] Checking existing resources in AWS...")
        errors = check_existing_resources(state)
        if errors:
            click.echo(click.style("[deployless] Check existing failed:\n", fg="red"))
            for err in errors:
                click.echo(click.style(f"  {err}", fg="red"))
            sys.exit(1)
        click.echo(click.style("[deployless] All existing resources verified.", fg="green"))


@cli.command()
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("-v", "--verbose", is_flag=True)
def check(stage, verbose):
    """Run pre-flight checks: env vars, SAM CLI, AWS credentials, existing resources."""
    # Compile (dry-run) to get state and run build-time validation
    try:
        state = compile_project(stage=stage, dry_run=True, verbose=verbose)
    except ValidationError as e:
        click.echo(click.style("[deployless] Build validation failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    config = load_config()
    if stage:
        config["stage"] = stage

    click.echo("[deployless] Running pre-flight checks...")
    errors = run_checks(state, config)

    if errors:
        click.echo(click.style("[deployless] Pre-flight checks failed:\n", fg="red"))
        for err in errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    click.echo(click.style("[deployless] All checks passed.", fg="green"))


@cli.command()
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--guided", is_flag=True, help="Force sam deploy --guided (wizard mode).")
@click.option("--push-secrets", is_flag=True, help="Push SECRET_ vars from .env to SSM before deploying.")
@click.option("-v", "--verbose", is_flag=True)
def deploy(stage, guided, push_secrets, verbose):
    """Build and deploy to AWS (runs: check → deployless build → sam build → sam deploy)."""
    # Auto-detect first deploy: samconfig.toml is created by SAM after the first --guided run.
    is_first_deploy = not Path("samconfig.toml").exists()
    if is_first_deploy and not guided:
        click.echo(click.style(
            "[deployless] No samconfig.toml found — running guided setup for the first time.",
            fg="yellow",
        ))

    # Step 1: pre-flight checks (dry-run compile + env vars + SAM + AWS creds + existing resources)
    click.echo("[deployless] Running pre-flight checks...")
    try:
        pre_state = compile_project(stage=stage, dry_run=True, verbose=False)
    except ValidationError as e:
        click.echo(click.style("[deployless] Build validation failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    pre_config = load_config()
    if stage:
        pre_config["stage"] = stage

    check_errors = run_checks(pre_state, pre_config)
    if check_errors:
        click.echo(click.style("[deployless] Pre-flight checks failed:\n", fg="red"))
        for err in check_errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)
    click.echo(click.style("[deployless] Pre-flight checks passed.", fg="green"))

    # Step 2: full build (with optional secret push)
    click.echo("[deployless] Building...")
    try:
        compile_project(stage=stage, verbose=verbose, push_secrets=push_secrets)
    except ValidationError as e:
        click.echo(click.style("[deployless] Build failed:\n", fg="red"))
        for err in e.errors:
            click.echo(click.style(f"  {err}", fg="red"))
        sys.exit(1)

    # Step 3: sam build
    click.echo("[deployless] Running sam build...")
    result = subprocess.run(["sam", "build"], check=False)
    if result.returncode != 0:
        click.echo(click.style("[deployless] sam build failed.", fg="red"))
        sys.exit(result.returncode)

    # Step 4: sam deploy (--guided auto-added on first deploy)
    sam_deploy_cmd = ["sam", "deploy"]
    if guided or is_first_deploy:
        sam_deploy_cmd.append("--guided")

    click.echo(f"[deployless] Running {' '.join(sam_deploy_cmd)}...")
    result = subprocess.run(sam_deploy_cmd, check=False)
    sys.exit(result.returncode)


@cli.command()
@click.option("-o", "--output", default="template.yaml", help="Template file to remove.")
def clean(output):
    """Remove generated files (.dist/ and template.yaml)."""
    import shutil
    root = Path.cwd()

    dist_dir = root / ".dist"
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
        click.echo(f"[deployless] Removed {dist_dir}")

    output_path = root / output
    if output_path.exists():
        output_path.unlink()
        click.echo(f"[deployless] Removed {output_path}")

    if not dist_dir.exists() and not output_path.exists():
        click.echo("[deployless] Nothing to clean.")


@cli.command()
def info():
    """Show detected project structure."""
    config = load_config()
    paths = config.get("paths", {})
    features = discover_features(Path.cwd(), paths.get("features", "app/features"))

    click.echo(f"\nProject  : {config['name']}")
    click.echo(f"Provider : {config['provider']}")
    click.echo(f"Stage    : {config['stage']}")
    click.echo(f"Runtime  : {config.get('globals', {}).get('runtime', 'python3.13')}")
    click.echo(f"\nFeatures ({len(features)}):")
    for f in features:
        click.echo(f"  - {f['name']}  ({f['routes_file']})")
    click.echo()


@cli.group()
def secrets():
    """Manage secrets in AWS SSM Parameter Store."""


@secrets.command(name="push")
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--env-file", default=None, help="Path to .env file (overrides deployless.yaml).")
@click.option("-v", "--verbose", is_flag=True)
def secrets_push(stage, env_file, verbose):
    """Push SECRET_ variables from .env file to SSM Parameter Store."""
    config = load_config()
    if stage:
        config["stage"] = stage

    env_file_path = env_file or config.get("env_file")
    if not env_file_path:
        click.echo(click.style("[deployless] No env_file configured. Set it in deployless.yaml or use --env-file.", fg="red"))
        sys.exit(1)

    env_path = Path.cwd() / env_file_path
    if not env_path.exists():
        click.echo(click.style(f"[deployless] File not found: {env_file_path}", fg="red"))
        sys.exit(1)

    _, secret_vars = parse_env_file(env_path)
    if not secret_vars:
        click.echo("[deployless] No SECRET_ variables found in .env file.")
        return

    app_name = config.get("name", "deployless-app")
    secrets_kms = config.get("secrets_kms")

    click.echo(f"[deployless] Pushing {len(secret_vars)} secret(s) for '{app_name}'...")
    results = push_secrets(app_name, secret_vars, secrets_kms)
    for path, action in results:
        click.echo(f"  {action}: {path}")
    click.echo(click.style("[deployless] Done.", fg="green"))


@secrets.command(name="sync")
@click.option("-s", "--stage", default=None, help="Override deployment stage.")
@click.option("--env-file", default=None, help="Path to .env file (overrides deployless.yaml).")
@click.option("-y", "--yes", is_flag=True, help="Auto-confirm orphan deletion.")
@click.option("-v", "--verbose", is_flag=True)
def secrets_sync(stage, env_file, yes, verbose):
    """Push secrets and delete orphaned parameters from SSM."""
    config = load_config()
    if stage:
        config["stage"] = stage

    env_file_path = env_file or config.get("env_file")
    if not env_file_path:
        click.echo(click.style("[deployless] No env_file configured. Set it in deployless.yaml or use --env-file.", fg="red"))
        sys.exit(1)

    env_path = Path.cwd() / env_file_path
    if not env_path.exists():
        click.echo(click.style(f"[deployless] File not found: {env_file_path}", fg="red"))
        sys.exit(1)

    _, secret_vars = parse_env_file(env_path)
    app_name = config.get("name", "deployless-app")
    secrets_kms = config.get("secrets_kms")

    if not yes:
        click.confirm(
            f"This will push {len(secret_vars)} secret(s) and delete orphaned params for '{app_name}'. Continue?",
            abort=True,
        )

    click.echo(f"[deployless] Syncing secrets for '{app_name}'...")
    pushed, deleted = sync_secrets(app_name, secret_vars, secrets_kms)
    for path, action in pushed:
        click.echo(f"  {action}: {path}")
    for path in deleted:
        click.echo(click.style(f"  deleted orphan: {path}", fg="yellow"))
    click.echo(click.style("[deployless] Done.", fg="green"))


# Register validate command with correct name
cli.add_command(validate_cmd, name="validate")


def main():
    """Entry point registered in pyproject.toml under ``[project.scripts]``."""
    cli()


if __name__ == "__main__":
    main()
