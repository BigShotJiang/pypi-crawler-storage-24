"""
deployless — compile your Python web app to AWS SAM serverless.

Public API surface: decorators, CloudFormation intrinsic helpers, and
AWS resource classes re-exported here so user code only needs to import
from ``deployless``.
"""
from deployless.core.metadata import (
    configure, route, cron, lambda_function, shared_resource,
    Ref, GetAtt,
)
from deployless.providers.aws.resources.dynamodb import DynamoDB
from deployless.providers.aws.resources.s3 import S3
from deployless.providers.aws.resources.sqs import SQS
from deployless.providers.aws.resources.kms import KMS
from deployless.providers.aws.resources.ssm import SSMParameter, SSMParam

__version__ = "0.1.2"

__all__ = [
    "configure",
    "route",
    "cron",
    "lambda_function",
    "shared_resource",
    "Ref",
    "GetAtt",
    "DynamoDB",
    "S3",
    "SQS",
    "KMS",
    "SSMParameter",
    "SSMParam",
]
