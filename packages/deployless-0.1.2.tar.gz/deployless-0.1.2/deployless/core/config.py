"""
Project configuration loader for deployless.

Reads ``deployless.yaml`` from the project root and deep-merges it with
built-in defaults so every config key always has a sensible value.
"""
from pathlib import Path
import yaml

DEFAULTS = {
    "name": "deployless-app",
    "provider": "aws",
    "stage": "dev",
    "paths": {
        "features": "app/features",
        "shared": "app/shared",
    },
    "globals": {
        "runtime": "python3.13",
        "memory": 256,
        "timeout": 30,
        "log_retention": 14,
    },
    "api": {
        "cors": {
            "allow_origin": "*",
            "allow_methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"],
        },
        "endpoint_type": "REGIONAL",
    },
    "env": {},
    "env_file": None,
}


def _deep_merge(base: dict, override: dict) -> dict:
    """
    Recursively merge *override* into *base*, returning a new dict.

    Nested dicts are merged rather than replaced, so a partial override only
    changes the keys it specifies while keeping all other base values intact.

    Args:
        base: The default configuration dict.
        override: User-supplied values that take precedence.

    Returns:
        A new dict containing the merged result.
    """
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(project_root=None) -> dict:
    """Load deployless.yaml and merge with defaults."""
    root = Path(project_root) if project_root else Path.cwd()
    config_path = root / "deployless.yaml"
    user_config = {}
    if config_path.exists():
        with open(config_path) as f:
            user_config = yaml.safe_load(f) or {}
    return _deep_merge(DEFAULTS, user_config)
