"""
Feature discovery and dynamic module import utilities.

Scans the project's features directory for valid feature modules and provides
a helper to import Python files at runtime from an arbitrary filesystem path.

Entry file resolution order (zero-config, convention-based):
  1. ``{feature}/routes.py``                  — classic flat structure
  2. ``{feature}/routes/{feature}_routes.py`` — screaming architecture
  3. Single ``.py`` file in ``{feature}/routes/`` — any other convention
"""
import importlib.util
import sys
from pathlib import Path


def _find_entry_file(feature_dir: Path, feature_name: str) -> Path | None:
    """
    Find the entry .py file for a feature, trying multiple conventions.

    Returns the first match or None if no entry point is found.
    """
    # 1. Classic flat structure: routes.py
    candidate = feature_dir / "routes.py"
    if candidate.exists():
        return candidate

    # 2. Screaming arch: routes/{feature_name}_routes.py
    candidate = feature_dir / "routes" / f"{feature_name}_routes.py"
    if candidate.exists():
        return candidate

    # 3. Any single .py file in routes/ (ignoring __init__.py and _-prefixed files)
    routes_dir = feature_dir / "routes"
    if routes_dir.is_dir():
        py_files = [
            f for f in routes_dir.iterdir()
            if f.suffix == ".py" and not f.name.startswith("_")
        ]
        if len(py_files) == 1:
            return py_files[0]

    return None


def discover_features(project_root: str, features_path: str) -> list:
    """
    Scan features directory for feature modules.
    Returns list of dicts: {name, dir, routes_file}
    """
    features_dir = Path(project_root) / features_path
    if not features_dir.exists():
        return []

    features = []
    for entry in sorted(features_dir.iterdir()):
        if entry.is_dir() and not entry.name.startswith("_"):
            entry_file = _find_entry_file(entry, entry.name)
            if entry_file:
                features.append({
                    "name": entry.name,
                    "dir": entry,
                    "routes_file": entry_file,
                })
    return features


def import_module_from_file(module_name: str, file_path, project_root=None):
    """Import a Python module from an absolute file path."""
    file_path = Path(file_path)
    if project_root:
        root = str(project_root)
        if root not in sys.path:
            sys.path.insert(0, root)

    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module
