"""
SSM Parameter Store resource definitions for deployless.

Provides two classes:

- ``SSMParameter`` — declares a managed ``AWS::SSM::Parameter`` resource that
  deployless creates in the CloudFormation stack.
- ``SSMParam`` — a lightweight reference to an *existing* SSM parameter that
  generates a CloudFormation dynamic reference (``{{resolve:ssm:…}}``).
"""
import re
from deployless.providers.aws.resources.base import Resource


VALID_SSM_TYPES = {"String", "StringList", "SecureString"}


def _to_pascal(name: str) -> str:
    """
    Convert an SSM path to a PascalCase logical ID.

    Each path segment is independently PascalCased and then concatenated,
    with ``"Parameter"`` appended.  Example: ``"/myapp/db/host"`` → ``"MyappDbHostParameter"``.
    """
    segments = [s for s in name.split("/") if s]
    return "".join(
        "".join(w.capitalize() for w in re.split(r"[-_]", seg))
        for seg in segments
    ) + "Parameter"


class SSMParameter(Resource):
    """
    Declares an SSM Parameter Store parameter (creates AWS::SSM::Parameter).

    Usage:
        pc.SSMParameter("/myapp/db/host", value="db.example.com")
        pc.SSMParameter("/myapp/api/key", value="secret", type="SecureString")
    """

    def __init__(
        self,
        name: str,
        value: str,
        type: str = "String",
        description: str = None,
        existing: bool = False,
    ):
        """
        Args:
            name: SSM parameter path, must start with ``"/"`` (e.g. ``"/myapp/db/host"``).
            value: Parameter value stored in SSM.
            type: SSM parameter type — ``"String"`` (default), ``"StringList"``, or ``"SecureString"``.
            description: Optional description stored on the parameter.
            existing: If ``True``, the parameter is assumed to already exist in SSM; no
                      CloudFormation resource is created and *name* is used as the env var value.
        """
        self.name = name
        self.value = value
        self.type = type
        self.description = description
        self.existing = existing

    def _logical_id(self) -> str:
        """Return the CloudFormation logical ID derived from the SSM parameter path."""
        return _to_pascal(self.name)

    def env_var_name(self) -> str:
        """Last path segment: /myapp/db/host → HOST."""
        last = self.name.rstrip("/").split("/")[-1]
        return last.replace("-", "_").upper()

    def env_var_value(self):
        """Return the parameter path directly if existing, otherwise a CloudFormation ``Ref``."""
        if self.existing:
            return self.name
        return {"Ref": self._logical_id()}

    def validate(self) -> list:
        """Return a list of validation error strings; empty list means valid."""
        errors = []
        if not self.name:
            errors.append("SSM parameter name vacío")
        elif not self.name.startswith("/"):
            errors.append(f"SSM parameter name '{self.name}' debe comenzar con '/'")
        elif not re.match(r"^/[a-zA-Z0-9_./-]+$", self.name):
            errors.append(f"SSM parameter name '{self.name}' contiene caracteres inválidos")
        if self.type not in VALID_SSM_TYPES:
            errors.append(
                f"SSM type='{self.type}' inválido. "
                f"Debe ser: {', '.join(sorted(VALID_SSM_TYPES))}"
            )
        if not self.value and self.type != "SecureString":
            errors.append(f"SSM parameter '{self.name}' value vacío")
        return errors

    def to_cfn(self) -> dict:
        """Return the CloudFormation resource dict, or an empty dict when ``existing=True``."""
        if self.existing:
            return {}

        props = {
            "Name": self.name,
            "Type": self.type,
            "Value": self.value,
        }
        if self.description:
            props["Description"] = self.description

        return {"Type": "AWS::SSM::Parameter", "Properties": props}


class SSMParam:
    """
    Reference to an existing SSM parameter for use in Lambda environment variables.

    Does not create a CloudFormation resource — produces a dynamic reference
    string (``{{resolve:ssm:…}}``) that API Gateway / Lambda resolves at deploy time.

    Usage:
        pc.configure(env={
            "DB_HOST": pc.SSMParam("/prod/db/host"),
            "API_KEY": pc.SSMParam("/prod/api/key", secure=True),
        })
    """

    def __init__(self, name: str, secure: bool = False, version: int = None):
        """
        Args:
            name: Full SSM parameter path (e.g. ``"/prod/db/host"``).
            secure: Use ``ssm-secure`` resolution (for ``SecureString`` parameters).
            version: Pin to a specific parameter version.  Omit to always use the latest.
        """
        self.name = name
        self.secure = secure
        self.version = version

    def to_reference(self) -> str:
        """Returns the CloudFormation dynamic reference string."""
        prefix = "ssm-secure" if self.secure else "ssm"
        ref = f"{{{{resolve:{prefix}:{self.name}"
        if self.version is not None:
            ref += f":{self.version}"
        ref += "}}"
        return ref
