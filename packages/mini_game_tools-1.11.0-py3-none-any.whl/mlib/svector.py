class vec2:
    """二维向量"""
    
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
    
    def __add__(self, other):
        return vec2(self.x + other.x, self.y + other.y)
    
    def __sub__(self, other):
        return vec2(self.x - other.x, self.y - other.y)
    
    def __mul__(self, scalar):
        return vec2(self.x * scalar, self.y * scalar)
    
    def __truediv__(self, scalar):
        return vec2(self.x / scalar, self.y / scalar)
    
    def dot(self, other):
        """点积"""
        return self.x * other.x + self.y * other.y
    
    def length(self):
        """模长"""
        return (self.x**2 + self.y**2) ** 0.5
    
    def normalize(self):
        """归一化"""
        l = self.length()
        if l == 0:
            return vec2(0, 0)
        return vec2(self.x / l, self.y / l)
    
    def __repr__(self):
        return f"vec2({self.x}, {self.y})"


class vec3:
    """三维向量"""
    
    def __init__(self, x=0, y=0, z=0):
        self.x = x
        self.y = y
        self.z = z
    
    def __add__(self, other):
        return vec3(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __sub__(self, other):
        return vec3(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def __mul__(self, scalar):
        return vec3(self.x * scalar, self.y * scalar, self.z * scalar)
    
    def dot(self, other):
        """点积"""
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def cross(self, other):
        """叉积"""
        return vec3(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )
    
    def length(self):
        return (self.x**2 + self.y**2 + self.z**2) ** 0.5
