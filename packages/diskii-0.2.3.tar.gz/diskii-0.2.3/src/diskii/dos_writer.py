"""DOS 3.3 and DOS 3.2 file writing functionality."""

import struct

from .dos32 import DOS32VTOC, DOS32Catalog
from .dos33 import DOSVTOC, DOSCatalog
from .exceptions import (
    FileNotFoundError,
    FilesystemError,
    InvalidFileError,
)


def _invalidate_image_cache(image):
    """Invalidate file list cache if image supports it."""
    if hasattr(image, "_file_list_cache"):
        image._file_list_cache = None


class DOSTrackSectorAllocator:
    """Manages track/sector allocation using the DOS VTOC."""

    def __init__(self, image, vtoc_class=DOSVTOC):
        self.image = image
        self.vtoc_class = vtoc_class
        self._vtoc = None

    @property
    def vtoc(self):
        """Get or create VTOC instance."""
        if self._vtoc is None:
            self._vtoc = self.vtoc_class(self.image)
        return self._vtoc

    def find_free_sectors(self, count: int) -> list[tuple[int, int]]:
        """Find free track/sector pairs.

        Args:
            count: Number of sectors needed

        Returns:
            List of (track, sector) tuples

        Raises:
            FilesystemError: If not enough free sectors
        """
        free_sectors = []

        # Skip track 17 (VTOC track) and tracks used for catalog
        total_tracks = (
            35 if isinstance(self.vtoc, DOSVTOC) else 35
        )  # DOS 3.2 also has 35 tracks
        sectors_per_track = self.vtoc.sectors_per_track

        for track in range(total_tracks):
            # Skip track 0 (boot sectors) and track 17 (VTOC/catalog track)
            if track == 0 or track == self.vtoc.catalog_track:
                continue

            # Get free sector bitmap for this track
            if (
                hasattr(self.vtoc, "_track_sector_maps")
                and self.vtoc._track_sector_maps
            ):
                track_bitmap = self.vtoc._track_sector_maps.get(track, 0)
            else:
                # Read VTOC to get track bitmap
                vtoc_data = self.image.read_sector(
                    17, 0
                )  # VTOC is always at track 17, sector 0
                track_bitmap = struct.unpack_from("<I", vtoc_data, 56 + track * 4)[
                    0
                ]  # Track allocation map

            # Check each sector in the track
            for sector in range(sectors_per_track):
                if track_bitmap & (1 << sector):  # Bit set = free
                    free_sectors.append((track, sector))
                    if len(free_sectors) >= count:
                        return free_sectors[:count]

        raise FilesystemError(
            f"Not enough free sectors: need {count}, found {len(free_sectors)}",
            str(self.image.file_path),
        )

    def allocate_sectors(self, sector_list: list[tuple[int, int]]) -> None:
        """Mark sectors as allocated in the VTOC."""
        # Read current VTOC
        vtoc_data = bytearray(self.image.read_sector(17, 0))

        # Update track allocation maps
        for track, sector in sector_list:
            # Each track has a 4-byte entry in the allocation table
            # starting at offset 56
            track_offset = 56 + track * 4

            # Read current bitmap for this track (4 bytes per track)
            track_bitmap = struct.unpack_from("<I", vtoc_data, track_offset)[0]

            # Clear the bit for this sector (0 = allocated, 1 = free)
            track_bitmap &= ~(1 << sector)

            # Write back the updated bitmap
            struct.pack_into("<I", vtoc_data, track_offset, track_bitmap)

        # Write updated VTOC
        self.image.write_sector(17, 0, bytes(vtoc_data))

    def deallocate_sectors(self, sector_list: list[tuple[int, int]]) -> None:
        """Mark sectors as free in the VTOC."""
        # Read current VTOC
        vtoc_data = bytearray(self.image.read_sector(17, 0))

        # Update track allocation maps
        for track, sector in sector_list:
            track_offset = 56 + track * 4

            # Read current bitmap for this track (4 bytes per track)
            track_bitmap = struct.unpack_from("<I", vtoc_data, track_offset)[0]

            # Set the bit for this sector (1 = free, 0 = allocated)
            track_bitmap |= 1 << sector

            # Write back the updated bitmap
            struct.pack_into("<I", vtoc_data, track_offset, track_bitmap)

        # Write updated VTOC
        self.image.write_sector(17, 0, bytes(vtoc_data))


def create_dos_file(
    image, filename: str, file_type: str, data: bytes, locked: bool = False
) -> None:
    """Create a new file on a DOS disk image.

    Args:
        image: UnifiedDiskImage instance
        filename: Name of the file to create (up to 30 chars)
        file_type: DOS file type ('T', 'I', 'A', 'B', 'S', 'R')
        data: File content bytes
        locked: Whether the file should be locked

    Raises:
        InvalidFileError: If filename already exists or is invalid
        FilesystemError: If not enough free space
    """
    # Validate filename
    if not filename or len(filename) > 30:
        raise InvalidFileError(f"Invalid filename: {filename}")

    if file_type not in ["T", "I", "A", "B", "S", "R"]:
        raise InvalidFileError(f"Invalid DOS file type: {file_type}")

    # Check if file already exists
    existing_files = image.get_file_list()
    for existing_file in existing_files:
        if existing_file.filename.upper() == filename.upper():
            raise InvalidFileError(f"File already exists: {filename}")

    # Determine VTOC class and catalog class based on image type
    from .image import FilesystemType

    vtoc_class = (
        DOS32VTOC
        if hasattr(image, "SECTORS_PER_TRACK") and image.SECTORS_PER_TRACK == 13
        else DOSVTOC
    )

    # Check catalog capacity
    if hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS33:
        from .dos33 import DOSCatalog

        catalog = DOSCatalog(image)
    elif hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS32:
        from .dos32 import DOS32Catalog

        catalog = DOS32Catalog(image)
    else:
        # Fall back to DOS33 catalog for images without format info
        from .dos33 import DOSCatalog

        catalog = DOSCatalog(image)

    if catalog.is_catalog_full():
        raise FilesystemError(
            "Catalog is full - cannot add more files (maximum 105 files)"
        )

    # For binary files, prepend exact file size to preserve cross-format integrity
    actual_data = data
    if file_type == "B":
        # Check if this looks like it already has a DOS binary header
        has_dos_header = False
        if len(data) >= 4:
            start_addr = struct.unpack("<H", data[0:2])[0]
            file_length = struct.unpack("<H", data[2:4])[0]

            # Validate DOS binary header format
            # Standard DOS binary: load_addr(2) + length(2) + data
            # Both address and length must be reasonable
            actual_data_size = len(data) - 4

            if (
                0x0800 <= start_addr <= 0xBFFF  # Valid Apple II address range
                and 0 < file_length <= actual_data_size  # Length must fit
                and file_length < 32768  # Reasonable maximum size
                # Additional validation: ensure this looks like a real header
                and file_length != start_addr  # Avoid false positives like 'XXXX'
                and file_length <= 16384  # More conservative size limit for headers
            ):
                has_dos_header = True

        if not has_dos_header:
            # Add our own size metadata for cross-format integrity
            # Format: 2 bytes = original file length (little-endian 16-bit)
            # to match what _calculate_dos_file_size expects
            file_length = min(len(data), 65535)  # Cap at 16-bit max
            size_header = struct.pack("<H", file_length)
            actual_data = size_header + data

    # Calculate sectors needed based on actual data (including any headers)
    sector_size = 256  # Bytes per sector
    sectors_needed = (len(actual_data) + sector_size - 1) // sector_size

    # Empty files don't need data sectors, only track/sector list
    # This matches CiderPress behavior where empty files have zero length

    # Add one extra sector for track/sector list if file is large
    ts_sectors_needed = 1
    if sectors_needed > 122:  # 122 entries fit in one T/S list sector
        ts_sectors_needed = (sectors_needed + 121) // 122  # Additional T/S list sectors

    total_sectors_needed = sectors_needed + ts_sectors_needed

    # Allocate sectors
    allocator = DOSTrackSectorAllocator(image, vtoc_class)
    allocated_sectors = allocator.find_free_sectors(total_sectors_needed)

    try:
        # First allocated sector is the track/sector list
        ts_track, ts_sector = allocated_sectors[0]
        data_sectors = allocated_sectors[1:]

        # Create track/sector lists (may be chained for large files)
        ts_sectors = allocated_sectors[:ts_sectors_needed]  # T/S list sectors
        data_sectors = allocated_sectors[ts_sectors_needed:]  # Data sectors

        _create_chained_track_sector_lists(image, ts_sectors, data_sectors)

        # Write data sectors
        for i, (track, sector) in enumerate(data_sectors):
            start_offset = i * 256
            end_offset = min(start_offset + 256, len(actual_data))

            if start_offset < len(actual_data):
                sector_data = actual_data[start_offset:end_offset]
                # Pad sector to 256 bytes
                sector_data = sector_data.ljust(256, b"\x00")
                image.write_sector(track, sector, sector_data)
            else:
                # Empty sector for padding
                image.write_sector(track, sector, b"\x00" * 256)

        # Mark sectors as allocated
        allocator.allocate_sectors(allocated_sectors)

        # Add catalog entry with original data length (not including headers)
        _add_catalog_entry(
            image,
            filename,
            file_type,
            ts_track,
            ts_sector,
            len(
                data
            ),  # Use original data length, not actual_data which may include headers
            locked,
            vtoc_class,
        )

    except Exception as e:
        # If anything fails, deallocate sectors that were allocated
        try:
            allocator.deallocate_sectors(allocated_sectors)
        except Exception:
            pass  # Best effort cleanup
        raise FilesystemError(f"Failed to create file {filename}: {e}") from e

    # Invalidate file list cache after successful creation
    _invalidate_image_cache(image)


def _create_chained_track_sector_lists(
    image, ts_sectors: list[tuple[int, int]], data_sectors: list[tuple[int, int]]
) -> None:
    """Create chained track/sector lists for large files."""
    sectors_per_ts_list = 122  # Maximum data sectors per T/S list

    for ts_index, (ts_track, ts_sector) in enumerate(ts_sectors):
        # Calculate which data sectors this T/S list handles
        start_sector = ts_index * sectors_per_ts_list
        end_sector = min(start_sector + sectors_per_ts_list, len(data_sectors))
        current_data_sectors = data_sectors[start_sector:end_sector]

        # Create T/S list data
        ts_data = bytearray(256)

        # Set next T/S list pointer
        if ts_index + 1 < len(ts_sectors):
            # Not the last T/S list
            next_ts_track, next_ts_sector = ts_sectors[ts_index + 1]
            ts_data[1] = next_ts_track
            ts_data[2] = next_ts_sector
        else:
            # Last T/S list
            ts_data[1] = 0
            ts_data[2] = 0

        # Set sector offset within file (not used by most DOS implementations)
        ts_data[5] = start_sector & 0xFF
        ts_data[6] = (start_sector >> 8) & 0xFF

        # Write track/sector pairs starting at offset 12
        for i, (track, sector) in enumerate(current_data_sectors):
            offset = 12 + (i * 2)
            if offset < 254:  # Ensure we don't overflow
                ts_data[offset] = track
                ts_data[offset + 1] = sector

        # Write the T/S list sector
        image.write_sector(ts_track, ts_sector, bytes(ts_data))


def _create_track_sector_list(
    data_sectors: list[tuple[int, int]], sector_count: int
) -> bytes:
    """Create a DOS track/sector list sector."""
    ts_data = bytearray(256)

    # Standard DOS 3.3 T/S list format:
    # Byte 0: not used (or next T/S track)
    # Byte 1: track of next T/S list (0 if last)
    # Byte 2: sector of next T/S list (0 if last)
    # Bytes 5-6: sector offset within file
    # Bytes 12+: track/sector pairs

    ts_data[1] = 0  # No next T/S list track
    ts_data[2] = 0  # No next T/S list sector

    # Track/sector pairs start at offset 12
    for i, (track, sector) in enumerate(data_sectors[:122]):  # Max 122 entries
        offset = 12 + (i * 2)
        if offset < 254:  # Make sure we don't overflow
            ts_data[offset] = track
            ts_data[offset + 1] = sector

    return bytes(ts_data)


def _add_catalog_entry(
    image,
    filename: str,
    file_type: str,
    ts_track: int,
    ts_sector: int,
    file_size: int,
    locked: bool,
    vtoc_class,
) -> None:
    """Add a catalog entry for a new DOS file."""

    # Get catalog location from VTOC
    vtoc = vtoc_class(image)
    catalog_track = vtoc.catalog_track
    catalog_sector = vtoc.catalog_sector

    # Search through catalog sectors for an empty slot
    while True:
        try:
            catalog_data = bytearray(image.read_sector(catalog_track, catalog_sector))
        except Exception as e:
            raise FilesystemError(
                "Cannot read catalog sector", str(image.file_path)
            ) from e

        # Check for empty catalog entry (track = 0xFF or track = 0x00)
        for i in range(7):  # 7 entries per catalog sector
            offset = 0x0B + i * 35  # File entries start at 0x0B, each entry is 35 bytes

            if offset + 35 > len(catalog_data):
                break

            entry_track = catalog_data[offset]

            # Check if entry is truly empty (track=0 AND sector=0) or deleted
            # (track=0xFF)
            entry_sector = (
                catalog_data[offset + 1] if offset + 1 < len(catalog_data) else 0
            )
            is_empty = (
                entry_track == 0x00 and entry_sector == 0x00
            ) or entry_track == 0xFF

            if is_empty:
                # Found empty entry
                _write_catalog_entry(
                    catalog_data,
                    offset,
                    filename,
                    file_type,
                    ts_track,
                    ts_sector,
                    file_size,
                    locked,
                )

                # Write updated catalog sector
                image.write_sector(catalog_track, catalog_sector, bytes(catalog_data))
                return

        # Check next catalog sector
        next_track = catalog_data[1]
        next_sector = catalog_data[2]

        if next_track == 0:
            # Allocate new catalog sector
            new_track, new_sector = _allocate_new_catalog_sector(image, vtoc)

            # Update current catalog sector to point to new one
            catalog_data[1] = new_track
            catalog_data[2] = new_sector
            image.write_sector(catalog_track, catalog_sector, bytes(catalog_data))

            # Initialize new catalog sector
            new_catalog_data = _create_empty_catalog_sector()
            image.write_sector(new_track, new_sector, new_catalog_data)

            # Continue with new catalog sector
            catalog_track = new_track
            catalog_sector = new_sector
            continue  # Loop back to check for empty slots in new sector

        catalog_track = next_track
        catalog_sector = next_sector


def _write_catalog_entry(
    catalog_data: bytearray,
    offset: int,
    filename: str,
    file_type: str,
    ts_track: int,
    ts_sector: int,
    file_size: int,
    locked: bool,
) -> None:
    """Write a DOS catalog entry at the specified offset."""

    # Byte 0: Track of first track/sector list
    catalog_data[offset] = ts_track

    # Byte 1: Sector of first track/sector list
    catalog_data[offset + 1] = ts_sector

    # Byte 2: File type and flags
    type_byte = 0x80  # Normal file
    if locked:
        type_byte |= 0x40

    type_mapping = {"T": 0x00, "I": 0x01, "A": 0x02, "B": 0x04, "S": 0x08, "R": 0x10}
    type_byte |= type_mapping.get(file_type, 0x00)

    catalog_data[offset + 2] = type_byte

    # Bytes 3-32: Filename (30 bytes, high ASCII, padded with spaces)
    name_bytes = filename.upper().encode("ascii")[:30]
    # Convert to high ASCII
    name_bytes = bytes(b | 0x80 for b in name_bytes)
    name_bytes = name_bytes.ljust(30, b"\xa0")  # Pad with high ASCII space

    catalog_data[offset + 3 : offset + 33] = name_bytes

    # Bytes 33-34: File size in sectors (little endian)
    sector_count = (file_size + 255) // 256
    struct.pack_into("<H", catalog_data, offset + 33, sector_count)


def delete_dos_file(image, filename: str) -> None:
    """Delete a file from a DOS disk image.

    Args:
        image: UnifiedDiskImage instance
        filename: Name of the file to delete

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    # Determine VTOC and catalog classes
    vtoc_class = (
        DOS32VTOC
        if hasattr(image, "SECTORS_PER_TRACK") and image.SECTORS_PER_TRACK == 13
        else DOSVTOC
    )
    catalog_class = DOS32Catalog if vtoc_class == DOS32VTOC else DOSCatalog

    # Find the file in catalog
    catalog = catalog_class(image)
    files = catalog.parse()

    target_file = None
    for file_entry in files:
        # Compare both display filename and cleaned filename
        display_name = file_entry.filename.strip().upper()
        clean_name = display_name.replace("[", "").replace("]", "")
        target_name = filename.strip().upper()

        if display_name == target_name or clean_name == target_name:
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(filename, str(image.file_path))

    # Collect sectors to deallocate
    sectors_to_free = []

    # Add track/sector list sector
    sectors_to_free.append((target_file.track, target_file.sector))

    # Read track/sector list to get data sector locations
    ts_data = image.read_sector(target_file.track, target_file.sector)

    # Parse track/sector list to find data sectors (starts at offset 12)
    for i in range(12, 256, 2):
        if i + 1 >= len(ts_data):
            break

        data_track = ts_data[i]
        data_sector = ts_data[i + 1]

        if data_track == 0:  # End of valid entries
            break

        sectors_to_free.append((data_track, data_sector))

    # Deallocate sectors
    allocator = DOSTrackSectorAllocator(image, vtoc_class)
    allocator.deallocate_sectors(sectors_to_free)

    # Remove catalog entry
    _remove_catalog_entry(image, filename, vtoc_class)

    # Invalidate file list cache after successful deletion
    _invalidate_image_cache(image)


def _remove_catalog_entry(image, filename: str, vtoc_class) -> None:
    """Remove a DOS catalog entry by marking it as deleted."""

    # Get catalog location from VTOC
    vtoc = vtoc_class(image)
    catalog_track = vtoc.catalog_track
    catalog_sector = vtoc.catalog_sector

    # Search through catalog sectors
    while True:
        try:
            catalog_data = bytearray(image.read_sector(catalog_track, catalog_sector))
        except Exception as e:
            raise FileNotFoundError(filename, str(image.file_path)) from e

        # Check each catalog entry
        for i in range(7):  # 7 entries per sector
            offset = 0x0B + i * 35  # File entries start at 0x0B

            if offset + 35 > len(catalog_data):
                break

            entry_track = catalog_data[offset]

            # Check if entry is a valid file (not empty: track=0 AND sector=0,
            # not deleted: track=0xFF)
            entry_sector = (
                catalog_data[offset + 1] if offset + 1 < len(catalog_data) else 0
            )
            is_valid_file = not (
                (entry_track == 0x00 and entry_sector == 0x00) or entry_track == 0xFF
            )

            if is_valid_file:
                # Read filename from entry
                name_bytes = catalog_data[offset + 3 : offset + 33]
                # Convert from high ASCII and strip padding
                entry_filename = (
                    bytes(b & 0x7F for b in name_bytes).decode("ascii").rstrip(" ")
                )

                if entry_filename.upper() == filename.upper():
                    # Found the entry, mark as deleted
                    catalog_data[offset] = 0xFF  # Mark as deleted

                    # Write updated catalog sector
                    image.write_sector(
                        catalog_track, catalog_sector, bytes(catalog_data)
                    )
                    return

        # Check next catalog sector
        next_track = catalog_data[1]
        next_sector = catalog_data[2]

        if next_track == 0:
            break

        catalog_track = next_track
        catalog_sector = next_sector

    # File not found in any catalog sector
    raise FileNotFoundError(filename, str(image.file_path))


def _create_empty_catalog_sector() -> bytes:
    """Create properly formatted empty catalog sector per DOS 3.3 spec."""
    catalog = bytearray(256)

    # Byte 0: Reserved (0x00)
    catalog[0] = 0x00

    # Bytes 1-2: Next catalog track/sector (0x00 = end of chain)
    catalog[1] = 0x00
    catalog[2] = 0x00

    # Bytes 3-10: Reserved (0x00)
    for i in range(3, 11):
        catalog[i] = 0x00

    # Bytes 11+: Initialize file entries as unused (track=0)
    for i in range(7):  # 7 file entries per catalog sector
        entry_offset = 11 + (i * 35)
        catalog[entry_offset] = 0x00  # Track=0 means unused

    return bytes(catalog)


def _allocate_new_catalog_sector(image, vtoc) -> tuple[int, int]:
    """Find and allocate a free sector for catalog expansion."""
    # First try to find a free sector on the catalog track (Track 17)
    catalog_track = vtoc.catalog_track

    for sector in range(vtoc.sectors_per_track):
        if vtoc.is_sector_free(catalog_track, sector):
            # Found free sector on catalog track
            _mark_catalog_sector_allocated(image, vtoc, catalog_track, sector)
            return catalog_track, sector

    # If catalog track is full, find any free sector
    free_sectors = vtoc.get_free_sector_list()
    if not free_sectors:
        raise FilesystemError(
            "Disk is full - no sectors available for catalog expansion",
            str(image.file_path),
        )

    # Use the first available free sector
    track, sector = free_sectors[0]
    _mark_catalog_sector_allocated(image, vtoc, track, sector)
    return track, sector


def _mark_catalog_sector_allocated(image, vtoc, track: int, sector: int) -> None:
    """Mark catalog sector as allocated in VTOC bitmap."""
    # Read current VTOC
    vtoc_data = bytearray(image.read_sector(17, 0))

    # Calculate bitmap offset for this track
    bitmap_offset = 56 + (track * 4)

    if bitmap_offset + 4 <= len(vtoc_data):
        # Read current 4-byte bitmap for this track
        current_bitmap = struct.unpack(
            "<I", vtoc_data[bitmap_offset : bitmap_offset + 4]
        )[0]

        # Clear the bit for this sector (mark as allocated)
        updated_bitmap = current_bitmap & ~(1 << sector)

        # Write updated bitmap back
        struct.pack_into("<I", vtoc_data, bitmap_offset, updated_bitmap)

        # Write updated VTOC back to disk
        image.write_sector(17, 0, bytes(vtoc_data))


def set_dos_file_attributes(image, filename: str, *, locked: bool = None) -> None:
    """Set DOS file attributes.

    Args:
        image: DOS disk image
        filename: Name of file to modify
        locked: True to lock file, False to unlock, None to leave unchanged

    Raises:
        FileNotFoundError: If file doesn't exist
        FilesystemError: If unable to update catalog
    """
    from .dos32 import DOS32Catalog
    from .dos33 import DOSCatalog
    from .image import FilesystemType

    # Determine DOS version and get appropriate catalog
    if image.format.filesystem == FilesystemType.DOS33:
        catalog = DOSCatalog(image)
        vtoc_class = DOSVTOC
    elif image.format.filesystem == FilesystemType.DOS32:
        catalog = DOS32Catalog(image)
        vtoc_class = DOS32VTOC
    else:
        raise FilesystemError("Image is not a DOS disk")

    # Find the file
    files = catalog.parse()
    target_file = None

    for file_entry in files:
        # Compare both display filename and padded filename
        display_name = file_entry.filename.strip().upper()
        # Also try removing the DOS filename decorations like [X]
        clean_name = display_name.replace("[", "").replace("]", "")
        target_name = filename.strip().upper()

        if display_name == target_name or clean_name == target_name:
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(filename)

    # Update attributes
    if locked is not None:
        target_file.set_locked(locked)

    # Find and update the catalog entry
    _update_catalog_entry(image, target_file, vtoc_class)

    # Invalidate file list cache after successful attribute update
    _invalidate_image_cache(image)


def _update_catalog_entry(image, file_entry, vtoc_class) -> None:
    """Update a catalog entry on disk.

    Args:
        image: DOS disk image
        file_entry: File entry to update
        vtoc_class: VTOC class (DOSVTOC or DOS32VTOC)
    """
    vtoc = vtoc_class(image)
    current_track = vtoc.catalog_track
    current_sector = vtoc.catalog_sector

    while current_track != 0:
        # Read catalog sector
        catalog_data = bytearray(image.read_sector(current_track, current_sector))

        # Parse entries in this sector
        for i in range(7):  # 7 entries per sector
            entry_offset = 11 + (i * 35)  # Skip 11-byte header
            if entry_offset + 35 > len(catalog_data):
                break

            entry_data = catalog_data[entry_offset : entry_offset + 35]

            # Check if this is our target file
            # Compare track/sector and filename
            ts_track = entry_data[0]
            ts_sector = entry_data[1]

            if ts_track == file_entry.track and ts_sector == file_entry.sector:
                # Found our file - update the catalog entry
                new_entry = file_entry.get_catalog_entry_bytes()
                catalog_data[entry_offset : entry_offset + 35] = new_entry

                # Write the updated catalog sector back
                image.write_sector(current_track, current_sector, bytes(catalog_data))
                return

        # Move to next catalog sector
        next_track = catalog_data[1] if len(catalog_data) > 1 else 0
        next_sector = catalog_data[2] if len(catalog_data) > 2 else 0

        if next_track == 0:
            break

        current_track = next_track
        current_sector = next_sector

    raise FilesystemError(
        f"Could not find catalog entry for file '{file_entry.filename}'"
    )


def rename_dos_file(image, old_filename: str, new_filename: str) -> None:
    """Rename a DOS file.

    Args:
        image: DOS disk image
        old_filename: Current name of file
        new_filename: New name for file

    Raises:
        FileNotFoundError: If file doesn't exist
        InvalidFileError: If new filename is invalid or already exists
        FilesystemError: If unable to update catalog
    """
    from .dos32 import DOS32Catalog
    from .dos33 import DOSCatalog
    from .dos_filename import validate_dos_filename
    from .image import FilesystemType

    # Validate new filename
    if not validate_dos_filename(new_filename):
        raise InvalidFileError(f"Invalid DOS filename: {new_filename}")

    # Check if new filename already exists
    existing_files = image.get_file_list()
    for existing_file in existing_files:
        clean_existing = (
            existing_file.filename.strip().replace("[", "").replace("]", "")
        )
        if clean_existing.upper() == new_filename.strip().upper():
            raise InvalidFileError(f"File already exists: {new_filename}")

    # Determine DOS version and get appropriate catalog
    if hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS33:
        catalog = DOSCatalog(image)
        vtoc_class = DOSVTOC
    elif hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS32:
        catalog = DOS32Catalog(image)
        vtoc_class = DOS32VTOC
    else:
        # Fall back to DOS33
        catalog = DOSCatalog(image)
        vtoc_class = DOSVTOC

    # Find the file
    files = catalog.parse()
    target_file = None

    for file_entry in files:
        # Compare both display filename and cleaned filename
        display_name = file_entry.filename.strip().upper()
        clean_name = display_name.replace("[", "").replace("]", "")
        target_name = old_filename.strip().upper()

        if display_name == target_name or clean_name == target_name:
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(old_filename)

    # Update the filename
    target_file.set_filename(new_filename)

    # Update the catalog entry on disk
    _update_catalog_entry(image, target_file, vtoc_class)

    # Invalidate file list cache after successful rename
    _invalidate_image_cache(image)
