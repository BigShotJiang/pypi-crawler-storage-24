"""DOS 3.3 filesystem parsing and manipulation."""

import struct

from .exceptions import CorruptedImageError
from .fileentry import DOSFileEntry
from .image import UnifiedDiskImage


class DOSTrackSectorList:
    """DOS 3.3 Track/Sector list parser."""

    def __init__(self, image: UnifiedDiskImage, track: int, sector: int):
        self.image = image
        self.track = track
        self.sector = sector

    def read_sectors(self) -> list[bytes]:
        """Read all data sectors for this track/sector list."""
        data_sectors = []
        current_track = self.track
        current_sector = self.sector

        while current_track != 0 or current_sector != 0:
            try:
                # Read the track/sector list sector
                ts_list = self.image.read_sector(current_track, current_sector)

                # Byte 1: track of next T/S list (0 if last)
                # Byte 2: sector of next T/S list (0 if last)
                next_track = ts_list[1]
                next_sector = ts_list[2]

                # Bytes 5-6: sector offset (which sector number in this T/S list)
                struct.unpack("<H", ts_list[5:7])[0]

                # Bytes 12-255: track/sector pairs (122 pairs max)
                for i in range(12, 256, 2):
                    if i + 1 >= len(ts_list):
                        break

                    data_track = ts_list[i]
                    data_sector = ts_list[i + 1]

                    if data_track == 0 and data_sector == 0:
                        # End of data sectors for this T/S list
                        break

                    if data_track != 0 or data_sector != 0:
                        # Read the actual data sector
                        try:
                            data = self.image.read_sector(data_track, data_sector)
                            data_sectors.append(data)
                        except Exception:
                            # Bad sector - add empty data
                            data_sectors.append(b"\x00" * 256)

                # Move to next T/S list
                current_track = next_track
                current_sector = next_sector

            except Exception:
                # If we can't read a T/S list, stop here
                break

        return data_sectors


class DOSVTOC:
    """DOS 3.3 Volume Table of Contents parser."""

    def __init__(self, image: UnifiedDiskImage):
        self.image = image
        self._vtoc_data: bytes | None = None
        self._dos_version: int | None = None
        self._catalog_track: int | None = None
        self._catalog_sector: int | None = None
        self._sectors_per_track: int | None = None
        self._last_allocated_track: int | None = None
        self._track_allocation_direction: int | None = None
        self._num_tracks: int | None = None
        self._free_sector_count: int | None = None
        self._volume_number: int | None = None

    def _parse_vtoc(self) -> None:
        """Parse the VTOC from track 17, sector 0."""
        try:
            self._vtoc_data = self.image.read_sector(17, 0)
        except Exception as e:
            raise CorruptedImageError(
                f"Cannot read VTOC at track 17, sector 0: {e}",
                str(self.image.file_path),
            ) from e

        if len(self._vtoc_data) < 256:
            raise CorruptedImageError(
                "VTOC sector too short", str(self.image.file_path)
            )

        # Parse VTOC structure according to DOS 3.3 documentation
        # Byte 1: Track number of first catalog sector (normally 17)
        self._catalog_track = self._vtoc_data[1]

        # Byte 2: Sector number of first catalog sector (normally 15)
        self._catalog_sector = self._vtoc_data[2]

        # Byte 3: Release number of DOS used to INIT this disk
        self._dos_version = self._vtoc_data[3]

        # Byte 6: Volume number (1-254, typically 254 as default)
        self._volume_number = self._vtoc_data[6]

        # Byte 48: Last track where sectors were allocated
        self._last_allocated_track = self._vtoc_data[48]

        # Byte 49: Direction of track allocation (+1 or -1)
        direction_byte = self._vtoc_data[49]
        self._track_allocation_direction = 1 if direction_byte >= 128 else -1

        # Byte 52: Number of tracks per disk (normally 35)
        self._num_tracks = self._vtoc_data[52]

        # Byte 53: Number of sectors per track (normally 16)
        self._sectors_per_track = self._vtoc_data[53]

        # Calculate free sectors
        self._calculate_free_sectors()

    def _calculate_free_sectors(self) -> None:
        """Calculate number of free sectors from bitmap."""
        if not self._vtoc_data:
            return

        free_count = 0

        # Track allocation bitmaps start at byte 56
        # Each track gets 4 bytes (32 bits) for its sectors
        for track in range(self._num_tracks or 35):
            bitmap_offset = 56 + (track * 4)
            if bitmap_offset + 4 > len(self._vtoc_data):
                break

            # Read 4-byte bitmap for this track
            bitmap = struct.unpack(
                "<I", self._vtoc_data[bitmap_offset : bitmap_offset + 4]
            )[0]

            # Count free sectors (bits set to 1)
            sectors_per_track = self._sectors_per_track or 16
            for sector in range(sectors_per_track):
                if bitmap & (1 << sector):
                    free_count += 1

        self._free_sector_count = free_count

    def is_sector_free(self, track: int, sector: int) -> bool:
        """Check if a specific sector is free."""
        if not self._vtoc_data:
            self._parse_vtoc()

        if track >= (self._num_tracks or 35):
            return False

        bitmap_offset = 56 + (track * 4)
        if bitmap_offset + 4 > len(self._vtoc_data):
            return False

        bitmap = struct.unpack(
            "<I", self._vtoc_data[bitmap_offset : bitmap_offset + 4]
        )[0]
        return bool(bitmap & (1 << sector))

    def get_free_sector_list(self) -> list[tuple[int, int]]:
        """Get list of all free sectors as (track, sector) tuples."""
        if not self._vtoc_data:
            self._parse_vtoc()

        free_sectors = []

        for track in range(self._num_tracks or 35):
            bitmap_offset = 56 + (track * 4)
            if bitmap_offset + 4 > len(self._vtoc_data):
                break

            bitmap = struct.unpack(
                "<I", self._vtoc_data[bitmap_offset : bitmap_offset + 4]
            )[0]

            sectors_per_track = self._sectors_per_track or 16
            for sector in range(sectors_per_track):
                if bitmap & (1 << sector):
                    free_sectors.append((track, sector))

        return free_sectors

    @property
    def catalog_track(self) -> int:
        """Get catalog starting track."""
        if self._catalog_track is None:
            self._parse_vtoc()
        return self._catalog_track or 17

    @property
    def catalog_sector(self) -> int:
        """Get catalog starting sector."""
        if self._catalog_sector is None:
            self._parse_vtoc()
        return self._catalog_sector or 15

    @property
    def dos_version(self) -> int:
        """Get DOS version number."""
        if self._dos_version is None:
            self._parse_vtoc()
        return self._dos_version or 3

    @property
    def sectors_per_track(self) -> int:
        """Get sectors per track."""
        if self._sectors_per_track is None:
            self._parse_vtoc()
        return self._sectors_per_track or 16

    @property
    def num_tracks(self) -> int:
        """Get number of tracks."""
        if self._num_tracks is None:
            self._parse_vtoc()
        return self._num_tracks or 35

    @property
    def free_sectors(self) -> int:
        """Get number of free sectors."""
        if self._free_sector_count is None:
            self._parse_vtoc()
        return self._free_sector_count or 0

    @property
    def volume_number(self) -> int:
        """Get volume number."""
        if self._volume_number is None:
            self._parse_vtoc()
        return self._volume_number or 254

    @property
    def volume_name(self) -> str:
        """Get DOS volume name in the format 'DISK VOLUME #X'."""
        return f"DISK VOLUME #{self.volume_number}"

    def set_volume_number(self, volume_num: int) -> None:
        """Set volume number (1-254).

        Args:
            volume_num: Volume number to set (1-254)

        Raises:
            ValueError: If volume number is out of range
        """
        if not (1 <= volume_num <= 254):
            raise ValueError("Volume number must be between 1 and 254")

        # Ensure VTOC is loaded
        if self._vtoc_data is None:
            self._parse_vtoc()

        # Update the volume number in VTOC data
        vtoc_data = bytearray(self._vtoc_data)
        vtoc_data[6] = volume_num
        self._vtoc_data = bytes(vtoc_data)
        self._volume_number = volume_num

        # Write the updated VTOC back to disk
        self.image.write_sector(17, 0, self._vtoc_data)


class DOSCatalog:
    """DOS 3.3 catalog parser."""

    def __init__(self, image: UnifiedDiskImage):
        self.image = image
        self.vtoc = DOSVTOC(image)
        self._entries: list[DOSFileEntry] | None = None

    def _parse_catalog_sector(
        self, track: int, sector: int
    ) -> tuple[list[DOSFileEntry], tuple[int, int] | None]:
        """Parse a single catalog sector and return entries plus next sector info."""
        try:
            catalog_data = self.image.read_sector(track, sector)
        except Exception as e:
            raise CorruptedImageError(
                f"Cannot read catalog sector {track},{sector}: {e}",
                str(self.image.file_path),
            ) from e

        entries = []

        # First byte: track of next catalog sector (0 if last)
        # Second byte: sector of next catalog sector (0 if last)
        next_track = catalog_data[1] if len(catalog_data) > 1 else 0
        next_sector = catalog_data[2] if len(catalog_data) > 2 else 0

        next_catalog = (next_track, next_sector) if next_track != 0 else None

        # Parse catalog entries (7 entries per sector, 35 bytes each)
        for i in range(7):
            entry_offset = 11 + (i * 35)  # Skip 11-byte header
            if entry_offset + 35 > len(catalog_data):
                break

            entry_data = catalog_data[entry_offset : entry_offset + 35]
            entry = self._parse_catalog_entry(entry_data)
            if entry:
                entries.append(entry)

        return entries, next_catalog

    def _parse_catalog_entry(self, entry_data: bytes) -> DOSFileEntry | None:
        """Parse a single DOS 3.3 catalog entry."""
        if len(entry_data) < 35:
            return None

        # First byte: track of first track/sector list sector
        ts_list_track = entry_data[0]

        # Skip deleted files (track = 255) only. Track 0 is valid for files.
        if ts_list_track == 255:
            return None

        # Second byte: sector of first track/sector list sector
        ts_list_sector = entry_data[1]

        # Third byte: file type and flags
        type_byte = entry_data[2]

        # Extract file type from lower bits (0x80 is the normal file flag)
        # Mask out the normal file flag (0x80) and lock flag (0x40) to get type bits
        file_type_bits = type_byte & 0x3F  # Keep only bits 0-5

        dos_type_map = {
            0x00: "T",  # Text
            0x01: "I",  # Integer BASIC
            0x02: "A",  # Applesoft BASIC
            0x04: "B",  # Binary
            0x08: "S",  # Special/Typeless
            0x10: "R",  # Relocatable
            0x20: "B",  # New B type (rare)
        }

        # Look up the file type directly
        dos_type = dos_type_map.get(
            file_type_bits, "B"
        )  # Default to binary if not found

        # Check if file is locked (bit 6, 0x40)
        locked = bool(type_byte & 0x40)

        # Bytes 3-32: filename (30 characters, high ASCII, space padded)
        filename_bytes = entry_data[3:33]

        # Convert raw filename bytes to display name using DOS filename utilities
        from .dos_filename import DOSFilename

        try:
            dos_filename = DOSFilename(filename_bytes)
            filename = dos_filename.padded_name
        except ValueError:
            # Fallback to old method for corrupted filenames
            filename = ""
            for b in filename_bytes:
                if b == 0xA0:  # High ASCII space
                    break
                elif b >= 0x80:  # High ASCII
                    filename += chr(b - 0x80)
                else:
                    filename += chr(b) if 32 <= b <= 126 else ""
            filename = filename.strip()

        if not filename:
            return None

        # Bytes 33-34: file length in sectors
        length_sectors = struct.unpack("<H", entry_data[33:35])[0]

        # Calculate file size using CiderPress 2 methodology
        # Different file types have different size calculation methods
        file_size = self._calculate_dos_file_size(
            ts_list_track, ts_list_sector, dos_type, length_sectors
        )

        entry = DOSFileEntry(
            filename=filename,
            file_type=dos_type,
            size=file_size,
            locked=locked,
            track=ts_list_track,
            sector=ts_list_sector,
            length_sectors=length_sectors,
            dos_type=dos_type,
            _raw_filename_bytes=filename_bytes,
        )

        # Add image reference for file reading
        entry._image = self.image
        return entry

    def _calculate_dos_file_size(
        self, ts_track: int, ts_sector: int, dos_type: str, length_sectors: int
    ) -> int:
        """Calculate DOS file size using CiderPress 2 methodology.

        Different file types use different size calculation methods:
        - T (Text): Scan sectors until zero byte found
        - I/A (Integer/Applesoft BASIC): Length in first 2 bytes
        - B (Binary): Length at offset 2-3 after load address
        - S/R (Special/Relocatable): Raw sector count * 256
        """
        try:
            # Read the track/sector list and data sectors
            ts_list = DOSTrackSectorList(self.image, ts_track, ts_sector)
            sectors = ts_list.read_sectors()

            if not sectors:
                return 0

            if dos_type == "T":  # Text files
                # Scan sectors until zero byte found
                for sector_idx, sector_data in enumerate(sectors):
                    for byte_idx, byte_val in enumerate(sector_data):
                        if byte_val == 0:
                            return sector_idx * 256 + byte_idx
                # If no zero found, use all data
                return len(sectors) * 256

            elif dos_type in ["I", "A"]:  # Integer/Applesoft BASIC
                # Length is in first 2 bytes of first sector
                if len(sectors[0]) >= 2:
                    stored_length = struct.unpack("<H", sectors[0][0:2])[0]
                    max_possible = len(sectors) * 256 - 2  # Subtract header bytes
                    return min(stored_length, max_possible)
                return 0

            elif dos_type == "B":  # Binary files
                # CiderPress approach: trust catalog entry size unless we have a
                # clearly valid header
                total_data_size = len(sectors) * 256

                if len(sectors[0]) >= 4:
                    # Try standard DOS format (length at offset 2-3 after load address)
                    stored_length = struct.unpack("<H", sectors[0][2:4])[0]
                    load_addr = struct.unpack("<H", sectors[0][0:2])[0]

                    # Only use header if it's clearly valid and reasonable
                    # (match DOS writer logic)
                    if (
                        0x0800 <= load_addr <= 0xFFFF  # Valid load address range (expanded for high memory)
                        and stored_length > 0  # Non-zero length
                        and stored_length <= total_data_size - 4  # Length fits in data
                        and stored_length < 32768  # Reasonable size
                        and stored_length != load_addr  # Avoid false positives
                        and stored_length <= 16384
                    ):  # More conservative size limit
                        return stored_length

                    # Try diskii format only if DOS format clearly invalid
                    if load_addr < 0x0800 or load_addr > 0xFFFF:
                        potential_length = struct.unpack("<H", sectors[0][0:2])[0]
                        if (
                            potential_length > 0
                            and potential_length <= total_data_size - 2
                            and potential_length < 32768
                            and abs(potential_length - (total_data_size - 2)) < 256
                        ):
                            return potential_length

                # When headers are ambiguous or invalid, trust catalog entry size
                # This matches CiderPress behavior for problematic files
                return length_sectors * 256

            else:  # S, R, and other types
                # Use raw sector count * 256
                return length_sectors * 256

        except Exception:
            # Fall back to sector-based calculation
            return length_sectors * 256

    def parse(self) -> list[DOSFileEntry]:
        """Parse the DOS 3.3 catalog and return list of file entries."""
        if self._entries is not None:
            return self._entries

        entries = []
        current_track = self.vtoc.catalog_track
        current_sector = self.vtoc.catalog_sector

        try:
            while current_track != 0:
                sector_entries, next_catalog = self._parse_catalog_sector(
                    current_track, current_sector
                )
                entries.extend(sector_entries)

                if next_catalog:
                    current_track, current_sector = next_catalog
                else:
                    break

        except Exception as e:
            raise CorruptedImageError(
                f"Error parsing DOS catalog: {e}", str(self.image.file_path)
            ) from e

        self._entries = entries
        return entries

    def refresh(self) -> None:
        """Refresh the catalog by clearing cached entries."""
        self._entries = None

    def get_catalog_capacity(self) -> tuple[int, int]:
        """Get catalog capacity information.

        Returns:
            Tuple of (current_entries, max_entries)
        """
        entries = self.parse()
        current_count = len(entries)

        # DOS 3.3 has a maximum of 15 catalog sectors (track 17, sectors 1-15)
        # Each sector holds 7 file entries
        max_entries = 15 * 7  # 105 files maximum

        return current_count, max_entries

    def is_catalog_full(self) -> bool:
        """Check if the catalog is at capacity.

        Returns:
            True if no more files can be added
        """
        current, maximum = self.get_catalog_capacity()
        return current >= maximum

    def get_available_catalog_slots(self) -> int:
        """Get number of available file slots in catalog.

        Returns:
            Number of files that can still be added
        """
        current, maximum = self.get_catalog_capacity()
        return max(0, maximum - current)

    def count_catalog_sectors(self) -> int:
        """Count the number of catalog sectors currently in use.

        Returns:
            Number of catalog sectors allocated
        """
        sector_count = 0
        current_track = self.vtoc.catalog_track
        current_sector = self.vtoc.catalog_sector

        while current_track != 0:
            sector_count += 1

            try:
                catalog_data = self.image.read_sector(current_track, current_sector)

                # Get next sector pointer
                next_track = catalog_data[1] if len(catalog_data) > 1 else 0
                next_sector = catalog_data[2] if len(catalog_data) > 2 else 0

                if next_track == 0:
                    break

                current_track = next_track
                current_sector = next_sector

            except Exception:
                break

        return sector_count


def parse_dos33_catalog(image: UnifiedDiskImage) -> DOSCatalog:
    """Parse a DOS 3.3 catalog from an image."""
    return DOSCatalog(image)
