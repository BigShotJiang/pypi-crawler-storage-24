"""ProDOS-ordered translator (sequential block layout)."""

from pathlib import Path
from typing import BinaryIO

from ..exceptions import CorruptedImageError
from ..exceptions import IOError as DiskiiIOError
from .interface import BlockTranslator, TranslationMode


class ProDOSOrderTranslator(BlockTranslator):
    """Translator for ProDOS-ordered images (.po files).

    ProDOS-ordered images store blocks sequentially in the file.
    This is the simplest translation - blocks are directly mapped
    to file offsets.
    """

    mode = TranslationMode.PRODOS_ORDER

    def _calculate_total_blocks(self) -> int:
        """Calculate total blocks from file size."""
        return self.file_path.stat().st_size // self.BLOCK_SIZE

    def read_block(self, block_num: int) -> bytes:
        """Read a ProDOS block directly from sequential layout."""
        if block_num < 0 or block_num >= self.total_blocks:
            raise ValueError(
                f"Block {block_num} out of range (0-{self.total_blocks - 1})"
            )

        try:
            offset = block_num * self.BLOCK_SIZE
            self.file_handle.seek(offset)
            data = self.file_handle.read(self.BLOCK_SIZE)

            if len(data) != self.BLOCK_SIZE:
                raise CorruptedImageError(
                    f"Block {block_num} incomplete: got {len(data)} bytes, "
                    f"expected {self.BLOCK_SIZE}",
                    str(self.file_path),
                )
            return data

        except OSError as e:
            raise DiskiiIOError(f"Error reading block {block_num}: {e}") from e

    def write_block(self, block_num: int, data: bytes) -> None:
        """Write a ProDOS block directly to sequential layout."""
        if len(data) != self.BLOCK_SIZE:
            raise ValueError(
                f"Block data must be exactly {self.BLOCK_SIZE} bytes, got {len(data)}"
            )

        if block_num < 0 or block_num >= self.total_blocks:
            raise ValueError(
                f"Block {block_num} out of range (0-{self.total_blocks - 1})"
            )

        try:
            offset = block_num * self.BLOCK_SIZE
            self.file_handle.seek(offset)
            self.file_handle.write(data)
            self.file_handle.flush()

        except OSError as e:
            raise DiskiiIOError(f"Error writing block {block_num}: {e}") from e
