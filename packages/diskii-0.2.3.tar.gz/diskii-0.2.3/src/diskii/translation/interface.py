"""Interfaces for sector/block translation layer."""

from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import BinaryIO


class TranslationMode(Enum):
    """Translation modes for different sector/block orderings."""

    DOS_ORDER = "dos_order"  # .dsk, .do files - DOS 3.3 sector interleaving
    PRODOS_ORDER = "prodos_order"  # .po files - ProDOS block ordering
    DOS32_ORDER = "dos32_order"  # .d13 files - DOS 3.2 13-sector format


class SectorTranslator(ABC):
    """Abstract interface for sector-level translation."""

    SECTOR_SIZE = 256

    def __init__(self, file_handle: BinaryIO, file_path: Path):
        self.file_handle = file_handle
        self.file_path = file_path
        self._total_sectors = None

    @property
    def total_sectors(self) -> int:
        """Get total number of sectors in the image."""
        if self._total_sectors is None:
            self._total_sectors = self._calculate_total_sectors()
        return self._total_sectors

    @abstractmethod
    def _calculate_total_sectors(self) -> int:
        """Calculate total sectors based on file size and format."""
        pass

    @abstractmethod
    def read_sector(self, track: int, sector: int) -> bytes:
        """Read a 256-byte sector.

        Args:
            track: Track number
            sector: Sector number within track

        Returns:
            256-byte sector data
        """
        pass

    @abstractmethod
    def write_sector(self, track: int, sector: int, data: bytes) -> None:
        """Write a 256-byte sector.

        Args:
            track: Track number
            sector: Sector number within track
            data: 256 bytes of sector data
        """
        pass


class BlockTranslator(ABC):
    """Abstract interface for block-level translation."""

    BLOCK_SIZE = 512

    def __init__(self, file_handle: BinaryIO, file_path: Path):
        self.file_handle = file_handle
        self.file_path = file_path
        self._total_blocks = None

    @property
    def total_blocks(self) -> int:
        """Get total number of blocks in the image."""
        if self._total_blocks is None:
            self._total_blocks = self._calculate_total_blocks()
        return self._total_blocks

    @property
    def total_sectors(self) -> int:
        """Get total number of sectors (2 per block)."""
        return self.total_blocks * 2

    @abstractmethod
    def _calculate_total_blocks(self) -> int:
        """Calculate total blocks based on file size and format."""
        pass

    @abstractmethod
    def read_block(self, block_num: int) -> bytes:
        """Read a 512-byte block.

        Args:
            block_num: Block number

        Returns:
            512-byte block data
        """
        pass

    @abstractmethod
    def write_block(self, block_num: int, data: bytes) -> None:
        """Write a 512-byte block.

        Args:
            block_num: Block number
            data: 512 bytes of block data
        """
        pass

    def read_sector(self, track: int, sector: int) -> bytes:
        """Read sector by converting to block address.

        Default implementation for block-based translators.
        """
        # Convert track/sector to block
        linear_sector = track * 16 + sector  # Assume 16 sectors per track
        block_num = linear_sector // 2
        sector_offset = linear_sector % 2

        block_data = self.read_block(block_num)

        if sector_offset == 0:
            return block_data[:256]
        else:
            return block_data[256:]

    def write_sector(self, track: int, sector: int, data: bytes) -> None:
        """Write sector by converting to block address.

        Default implementation for block-based translators.
        """
        if len(data) != 256:
            raise ValueError(f"Sector data must be exactly 256 bytes, got {len(data)}")

        # Convert track/sector to block
        linear_sector = track * 16 + sector  # Assume 16 sectors per track
        block_num = linear_sector // 2
        sector_offset = linear_sector % 2

        # Read current block, modify appropriate half, write back
        current_block = self.read_block(block_num)
        block_data = bytearray(current_block)

        if sector_offset == 0:
            block_data[:256] = data
        else:
            block_data[256:] = data

        self.write_block(block_num, bytes(block_data))
