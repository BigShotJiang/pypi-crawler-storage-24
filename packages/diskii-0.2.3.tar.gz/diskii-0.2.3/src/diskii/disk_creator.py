#!/usr/bin/env python3
"""Disk image creation utilities for diskii library."""

from datetime import datetime
from pathlib import Path

from .exceptions import DiskiiError


def create_blank_dos33_image(file_path: str | Path, volume_number: int = 254) -> None:
    """Create a blank DOS 3.3 disk image.

    Args:
        file_path: Path where the disk image will be created
        volume_number: DOS volume number (default 254)
    """
    file_path = Path(file_path)

    # DOS 3.3 specifications
    TRACKS = 35
    SECTORS_PER_TRACK = 16
    BYTES_PER_SECTOR = 256
    TOTAL_SIZE = TRACKS * SECTORS_PER_TRACK * BYTES_PER_SECTOR  # 143,360 bytes

    # Create blank disk image file
    with open(file_path, "wb") as f:
        f.write(b"\x00" * TOTAL_SIZE)

    # Use UnifiedDiskImage to write sectors with proper ordering
    from .image import UnifiedDiskImage
    from .types import ImageFormat, FilesystemType, SectorOrdering

    # Create format specification for DOS 3.3 in DOS ordering
    dos_format = ImageFormat(SectorOrdering.DOS_ORDER, FilesystemType.DOS33)

    with UnifiedDiskImage(file_path, dos_format, read_only=False) as img:
        # Create VTOC (Volume Table of Contents) at track 17, sector 0
        vtoc_data = _create_dos33_vtoc(volume_number)
        img.write_sector(17, 0, vtoc_data)

        # Create initial catalog at track 17, sector 15
        catalog_data = _create_dos33_catalog()
        img.write_sector(17, 15, catalog_data)


def create_blank_prodos_image(
    file_path: str | Path,
    volume_name: str = "BLANK.DISK",
    total_blocks: int = 280,
) -> None:
    """Create a blank ProDOS disk image.

    Args:
        file_path: Path where the disk image will be created
        volume_name: ProDOS volume name (15 chars max)
        total_blocks: Total blocks in the disk (default 280 for 140K disk)
                     Maximum 65535 blocks (32MB)
    """
    file_path = Path(file_path)

    # Validate parameters
    if len(volume_name) > 15:
        raise DiskiiError(f"Volume name too long: {volume_name} (max 15 chars)")
    if total_blocks > 65535:
        raise DiskiiError(f"Too many blocks: {total_blocks} (max 65535)")
    if total_blocks < 5:
        raise DiskiiError(f"Too few blocks: {total_blocks} (min 5)")

    # ProDOS specifications
    BYTES_PER_BLOCK = 512
    total_size = total_blocks * BYTES_PER_BLOCK

    # Create blank disk image
    with open(file_path, "wb") as f:
        # Initialize with zeros
        f.write(b"\x00" * total_size)

        # Create boot blocks (blocks 0-1) - minimal boot code
        f.seek(0)
        boot_block = _create_prodos_boot_blocks()
        f.write(boot_block)

        # Create volume directory (block 2)
        f.seek(2 * BYTES_PER_BLOCK)
        volume_dir = _create_prodos_volume_directory(volume_name, total_blocks)
        f.write(volume_dir)

        # Create directory continuation blocks (blocks 3, 4, 5)
        f.seek(3 * BYTES_PER_BLOCK)
        continuation_block3 = _create_prodos_directory_continuation(
            prev_block=2, next_block=4
        )
        f.write(continuation_block3)

        f.seek(4 * BYTES_PER_BLOCK)
        continuation_block4 = _create_prodos_directory_continuation(
            prev_block=3, next_block=5
        )
        f.write(continuation_block4)

        f.seek(5 * BYTES_PER_BLOCK)
        continuation_block5 = _create_prodos_directory_continuation(
            prev_block=4, next_block=0
        )  # 0 = end of chain
        f.write(continuation_block5)

        # Create volume bitmap (block 6 and following)
        bitmap_start_block = 6
        bitmap_blocks_needed = (
            total_blocks + 4095
        ) // 4096  # Each block covers 4096 blocks

        f.seek(bitmap_start_block * BYTES_PER_BLOCK)
        volume_bitmap = _create_prodos_volume_bitmap(
            total_blocks, bitmap_start_block, bitmap_blocks_needed
        )
        f.write(volume_bitmap)


def create_blank_dos_ordered_prodos_image(
    file_path: str | Path,
    volume_name: str = "BLANK.DISK",
    total_blocks: int = 280,
) -> None:
    """Create a blank ProDOS disk image with DOS sector ordering (.dsk format).

    Args:
        file_path: Path where the disk image will be created
        volume_name: ProDOS volume name (15 chars max)
        total_blocks: Total blocks in the disk (default 280 for 140K disk)
    """
    file_path = Path(file_path)

    # Validate parameters (same as regular ProDOS)
    if len(volume_name) > 15:
        raise DiskiiError(f"Volume name too long: {volume_name} (max 15 chars)")
    if total_blocks > 65535:
        raise DiskiiError(f"Too many blocks: {total_blocks} (max 65535)")
    if total_blocks < 5:
        raise DiskiiError(f"Too few blocks: {total_blocks} (min 5)")

    # Create the disk with DOS sector ordering
    # DOS 3.3 specifications for physical layout
    TRACKS = 35
    SECTORS_PER_TRACK = 16
    BYTES_PER_SECTOR = 256
    TOTAL_SIZE = TRACKS * SECTORS_PER_TRACK * BYTES_PER_SECTOR  # 143,360 bytes

    # Ensure we don't exceed DOS disk capacity
    max_dos_blocks = TOTAL_SIZE // 512  # 280 blocks max for standard DOS disk
    if total_blocks > max_dos_blocks:
        raise DiskiiError(
            f"Too many blocks for DOS-ordered disk: {total_blocks} "
            f"(max {max_dos_blocks})"
        )

    # Create blank disk image
    with open(file_path, "wb") as f:
        f.write(b"\x00" * TOTAL_SIZE)

    # Use UnifiedDiskImage to write ProDOS structures with DOS sector ordering
    from .image import UnifiedDiskImage
    from .types import FilesystemType, ImageFormat, SectorOrdering

    # Create image format descriptor for DOS-ordered ProDOS
    image_format = ImageFormat(SectorOrdering.DOS_ORDER, FilesystemType.PRODOS)

    with UnifiedDiskImage(file_path, image_format, read_only=False) as img:
        # Create boot blocks (blocks 0-1)
        img.write_block(0, b"\x00" * 512)  # Boot block 0
        img.write_block(1, b"\x00" * 512)  # Boot block 1

        # Create volume directory header block (block 2)
        volume_dir = _create_prodos_volume_directory(volume_name, total_blocks)
        img.write_block(2, volume_dir)

        # Create directory continuation block (block 3)
        continuation_block = _create_prodos_directory_continuation(
            2, 0
        )  # Prev=2 (volume dir), Next=0 (end)
        img.write_block(3, continuation_block)

        # Blocks 4-5 are typically unused but available
        img.write_block(4, b"\x00" * 512)
        img.write_block(5, b"\x00" * 512)

        # Create volume bitmap (block 6 and following)
        bitmap_start_block = 6
        bitmap_blocks_needed = (
            total_blocks + 4095
        ) // 4096  # Each block covers 4096 blocks

        volume_bitmap = _create_prodos_volume_bitmap(
            total_blocks, bitmap_start_block, bitmap_blocks_needed
        )
        img.write_block(bitmap_start_block, volume_bitmap)


def create_blank_dos32_image(file_path: str | Path, volume_number: int = 254) -> None:
    """Create a blank DOS 3.2 disk image (13-sector format).

    Args:
        file_path: Path where the disk image will be created
        volume_number: DOS volume number (default 254)
    """
    file_path = Path(file_path)

    # DOS 3.2 specifications
    TRACKS = 35
    SECTORS_PER_TRACK = 13
    BYTES_PER_SECTOR = 256
    TOTAL_SIZE = TRACKS * SECTORS_PER_TRACK * BYTES_PER_SECTOR  # 116,480 bytes

    # Create blank disk image file
    with open(file_path, "wb") as f:
        f.write(b"\x00" * TOTAL_SIZE)

    # Use UnifiedDiskImage to write sectors with proper ordering
    from .image import UnifiedDiskImage
    from .types import ImageFormat, SectorOrdering, FilesystemType

    # Create format specification for DOS 3.2 in DOS32 ordering (13-sector)
    dos32_format = ImageFormat(SectorOrdering.DOS32_ORDER, FilesystemType.DOS32)

    with UnifiedDiskImage(file_path, dos32_format, read_only=False) as img:
        # Create VTOC at track 17, sector 0
        vtoc_data = _create_dos32_vtoc(volume_number)
        img.write_sector(17, 0, vtoc_data)

        # Create initial catalog at track 17, sector 12 (different from DOS 3.3)
        catalog_data = _create_dos32_catalog()
        img.write_sector(17, 12, catalog_data)


def _get_dos_sector_offset(track: int, sector: int) -> int:
    """Get file offset for DOS 3.3 track/sector."""
    return (track * 16 + sector) * 256


def _get_dos32_sector_offset(track: int, sector: int) -> int:
    """Get file offset for DOS 3.2 track/sector."""
    return (track * 13 + sector) * 256


def _create_dos33_vtoc(volume_number: int) -> bytes:
    """Create DOS 3.3 VTOC (Volume Table of Contents)."""
    vtoc = bytearray(256)

    # VTOC header
    vtoc[0x01] = 17  # Catalog track
    vtoc[0x02] = 15  # Catalog sector (first catalog sector)
    vtoc[0x03] = 3  # Release number
    vtoc[0x06] = volume_number  # Volume number (byte 6)
    vtoc[0x27] = 122  # Maximum track/sector list sectors
    vtoc[0x30] = 1  # Last track where sectors were allocated
    vtoc[0x31] = 1  # Direction of track allocation (+1)
    vtoc[0x34] = 35  # Number of tracks per disk
    vtoc[0x35] = 16  # Number of sectors per track
    vtoc[0x36] = 0  # Number of bytes per sector (low byte)
    vtoc[0x37] = 1  # Number of bytes per sector (high byte) -> 256 bytes

    # Track allocation bitmap - mark most sectors as free
    # Each track has 2 bytes for sector allocation (16 bits for 16 sectors)
    for track in range(35):
        offset = 0x38 + track * 4  # Track allocation starts at 0x38

        if track == 0:
            # Boot track - mark sectors 0-2 as used, rest free
            vtoc[offset] = 0xF8  # Low byte: 11111000 (sectors 0-2 used)
            vtoc[offset + 1] = 0xFF  # High byte: all free
        elif track == 17:
            # VTOC/Catalog track - mark VTOC and catalog sectors as used
            vtoc[offset] = 0x00  # Sector 0 (VTOC) used
            vtoc[offset + 1] = 0x7F  # Sector 15 (catalog) used, others free
        else:
            # All other tracks - all sectors free
            vtoc[offset] = 0xFF
            vtoc[offset + 1] = 0xFF

    return bytes(vtoc)


def _create_dos32_vtoc(volume_number: int) -> bytes:
    """Create DOS 3.2 VTOC."""
    vtoc = bytearray(256)

    # VTOC header for DOS 3.2
    vtoc[0x01] = 17  # Catalog track
    vtoc[0x02] = 12  # Catalog sector (DOS 3.2 uses sector 12)
    vtoc[0x03] = 2  # Release number (DOS 3.2)
    vtoc[0x27] = 122  # Maximum track/sector list sectors
    vtoc[0x30] = 1  # Last track where sectors were allocated
    vtoc[0x31] = 1  # Direction of track allocation
    vtoc[0x34] = 35  # Number of tracks per disk
    vtoc[0x35] = 13  # Number of sectors per track (DOS 3.2 difference)
    vtoc[0x36] = 0  # Number of bytes per sector (low)
    vtoc[0x37] = 1  # Number of bytes per sector (high)

    # Track allocation bitmap for 13 sectors per track
    for track in range(35):
        offset = 0x38 + track * 4

        if track == 0:
            # Boot track
            vtoc[offset] = 0xF8  # Sectors 0-2 used
            vtoc[offset + 1] = 0x1F  # Only 13 sectors total (bits 0-12)
        elif track == 17:
            # VTOC/Catalog track
            vtoc[offset] = 0x00  # Sector 0 (VTOC) used
            vtoc[offset + 1] = 0x0F  # Sector 12 (catalog) used, others free
        else:
            # All other tracks - all 13 sectors free
            vtoc[offset] = 0xFF
            vtoc[offset + 1] = 0x1F  # Only 13 bits set (0-12)

    return bytes(vtoc)


def _create_dos33_catalog() -> bytes:
    """Create initial empty DOS 3.3 catalog sector."""
    catalog = bytearray(256)

    # Catalog header
    catalog[0x00] = 0x00  # Reserved/unused
    catalog[0x01] = 0x00  # Next catalog track (0 = no next sector)
    catalog[0x02] = 0x00  # Next catalog sector

    # Mark all file entries as deleted (0x00 in track field)
    for i in range(7):  # 7 file entries per catalog sector
        offset = 0x0B + i * 35  # File entries start at 0x0B
        catalog[offset] = 0x00  # Track = 0x00 (deleted entry)

    return bytes(catalog)


def _create_dos33_catalog_continuation() -> bytes:
    """Create DOS 3.3 catalog continuation sector."""
    catalog = bytearray(256)

    # Catalog header for continuation sector
    catalog[0x00] = 0x00  # Reserved/unused
    catalog[0x01] = 0x11  # Previous catalog track (17)
    catalog[0x02] = 0x0F  # Previous catalog sector (15) - link back

    # Mark all file entries as deleted (0x00 in track field)
    for i in range(7):  # 7 file entries per catalog sector
        offset = 0x0B + i * 35  # File entries start at 0x0B
        catalog[offset] = 0x00  # Track = 0x00 (deleted entry)

    return bytes(catalog)


def _create_dos32_catalog() -> bytes:
    """Create initial empty DOS 3.2 catalog sector."""
    # DOS 3.2 catalog structure is the same as DOS 3.3
    return _create_dos33_catalog()


def _create_prodos_boot_blocks() -> bytes:
    """Create standard ProDOS boot blocks (blocks 0-1)."""
    boot_data = bytearray(1024)  # 2 blocks = 1024 bytes

    # Use standard ProDOS boot block that can load ProDOS if present
    # This uses the functional boot code without AppleCommander-specific messaging
    standard_boot = bytes(
        [
            0x01,
            0x38,
            0xB0,
            0x03,
            0x4C,
            0x32,
            0xA1,
            0xBD,
            0x88,
            0xC0,
            0x20,
            0x2F,
            0xFB,
            0x20,
            0x58,
            0xFC,
            0x20,
            0x40,
            0xFB,
            0xA2,
            0x11,
            0xBD,
            0x75,
            0x08,
            0x4A,
            0x4A,
            0x4A,
            0x4A,
            0x20,
            0x64,
            0xF8,
            0xBD,
            0x86,
            0x08,
            0x4A,
            0x4A,
            0x4A,
            0x4A,
            0x85,
            0x2C,
            0xBD,
            0x75,
            0x08,
            0x29,
            0x0F,
            0xA8,
            0xBD,
            0x86,
            0x08,
            0x29,
            0x0F,
            0x18,
            0x69,
            0x0D,
            0x20,
            0x19,
            0xF8,
            0xCA,
            0xD0,
            0xD9,
            0xBD,
            0x98,
            0x08,
            0xF0,
            0x06,
            0x20,
            0xF0,
            0xFD,
            0xE8,
            0xD0,
            0xF5,
            0xAD,
            0x00,
            0xC0,
            0x10,
            0x06,
            0x8D,
            0x10,
            0xC0,
            0x4C,
            0xA6,
            0xFA,
            0xA2,
            0x13,
            0x8A,
            0x20,
            0x47,
            0xF8,
            0xA0,
            0x27,
            0xB1,
            0x26,
            0x48,
            0x88,
            0xB1,
            0x26,
            0xC8,
            0x91,
            0x26,
            0x88,
            0xD0,
            0xF7,
            0x68,
            0x91,
            0x26,
            0xCA,
            0x10,
            0xE8,
            0xA9,
            0x08,
            0x20,
            0xA8,
            0xFC,
            0xCA,
            0xD0,
            0xF8,
            0xF0,
            0xD1,
            0xC8,
            0xC7,
            0xC6,
            0xC3,
            0xC8,
            0xC2,
            0xD1,
            0xD1,
            0x90,
            0x90,
            0x10,
            0x10,
            0x31,
            0x31,
            0x62,
            0x63,
            0x68,
            0x90,
            0x81,
            0x72,
            0x53,
            0xB3,
            0xC4,
            0xC9,
            0xD3,
            0xCB,
            0xC9,
            0xC9,
            0xA0,
            0xC6,
            0xCF,
            0xD2,
            0xCD,
            0xC1,
            0xD4,
            0xD4,
            0xC5,
            0xC4,
            0xA0,
            0xC4,
            0xC9,
            0xD3,
            0xCB,
            0x8D,
            0x8D,
            0xC9,
            0xCE,
            0xD3,
            0xC5,
            0xD2,
            0xD4,
            0xA0,
            0xC1,
            0xA0,
            0xD0,
            0xD2,
            0xCF,
            0xC4,
            0xCF,
            0xD3,
            0xA0,
            0xC4,
            0xC9,
            0xD3,
            0xCB,
            0xA0,
            0xC1,
            0xCE,
            0xC4,
            0xA0,
            0xD0,
            0xD2,
            0xC5,
            0xD3,
            0xD3,
            0xA0,
            0xC1,
            0xCE,
            0xD9,
            0xA0,
            0xCB,
            0xC5,
            0xD9,
            0xA0,
            0xD4,
            0xCF,
            0xA0,
            0xC3,
            0xCF,
            0xCE,
            0xD4,
            0xC9,
            0xCE,
            0xD5,
            0xC5,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
            0x8D,
        ]
    )

    # Copy the standard boot code to block 0
    boot_data[: len(standard_boot)] = standard_boot

    return bytes(boot_data)


def _create_prodos_volume_directory(volume_name: str, total_blocks: int) -> bytes:
    """Create ProDOS volume directory (block 2)."""
    volume_dir = bytearray(512)

    # ProDOS directory block header (first 4 bytes)
    volume_dir[0x00] = 0x00  # Previous block pointer (low) - 0 for volume directory
    volume_dir[0x01] = 0x00  # Previous block pointer (high)
    volume_dir[0x02] = 0x03  # Next block pointer (low) - 3 for continuation block
    volume_dir[0x03] = 0x00  # Next block pointer (high)

    # Volume directory header entry starts at offset 4
    # Storage type (0xF in high nibble for volume directory header)
    # and name length (low nibble)
    volume_dir[0x04] = 0xF0 | len(volume_name)  # Storage type 0xF + name length
    volume_dir[0x05 : 0x05 + len(volume_name)] = volume_name.encode("ascii").upper()

    # Volume directory key block (adjusted offsets - add 4 to all)
    volume_dir[0x18] = 0x00  # Reserved (should be 0x00, not 0x75)
    volume_dir[0x19] = 0x00  # Reserved

    # Creation date/time (current time)
    now = datetime.now()
    date_time = _encode_prodos_datetime(now)
    volume_dir[0x1C:0x20] = date_time

    # Version info
    volume_dir[0x20] = 0x00  # Version
    volume_dir[0x21] = 0x00  # Min version
    volume_dir[0x22] = 0xE3  # Access permissions (read/write/rename/destroy)
    volume_dir[0x23] = 0x27  # Entry length (39 bytes)
    volume_dir[0x24] = 0x0D  # Entries per block (13)
    volume_dir[0x25] = 0x00  # File count (low) - start with 0 files
    volume_dir[0x26] = 0x00  # File count (high)

    # Volume bitmap pointer (block 6)
    volume_dir[0x27] = 0x06  # Bitmap pointer (low)
    volume_dir[0x28] = 0x00  # Bitmap pointer (high)

    # Total blocks
    volume_dir[0x29] = total_blocks & 0xFF  # Total blocks (low)
    volume_dir[0x2A] = (total_blocks >> 8) & 0xFF  # Total blocks (high)

    return bytes(volume_dir)


def _create_prodos_directory_continuation(prev_block: int, next_block: int) -> bytes:
    """Create ProDOS directory continuation block."""
    continuation_block = bytearray(512)

    # Directory block header (first 4 bytes)
    continuation_block[0x00] = prev_block & 0xFF  # Previous block pointer (low)
    continuation_block[0x01] = (prev_block >> 8) & 0xFF  # Previous block pointer (high)
    continuation_block[0x02] = next_block & 0xFF  # Next block pointer (low) - 0 if last
    continuation_block[0x03] = (next_block >> 8) & 0xFF  # Next block pointer (high)

    # Rest of block remains zeros (empty directory entries)
    return bytes(continuation_block)


def _create_prodos_volume_bitmap(
    total_blocks: int, start_block: int, bitmap_blocks: int
) -> bytes:
    """Create ProDOS volume bitmap."""
    bitmap_size = bitmap_blocks * 512
    bitmap = bytearray(bitmap_size)

    # Mark system blocks as used (blocks 0-5 including directory
    # continuation, and bitmap blocks)
    system_blocks = set(
        range(6)
    )  # Blocks 0-5 (includes boot blocks 0-1, volume dir 2, continuation 3, empty 4-5)
    system_blocks.update(
        range(start_block, start_block + bitmap_blocks)
    )  # Bitmap blocks

    # Set bits for all blocks (1 = free, 0 = used)
    for block in range(total_blocks):
        byte_offset = block // 8
        bit_offset = 7 - (block % 8)  # ProDOS uses big-endian bit ordering

        if byte_offset < len(bitmap):
            if block not in system_blocks:
                bitmap[byte_offset] |= 1 << bit_offset  # Mark as free
            # Used blocks remain 0 (already initialized)

    return bytes(bitmap)


def _encode_prodos_datetime(dt: datetime) -> bytes:
    """Encode datetime in ProDOS format."""
    # Use the same encoding as prodos_writer.py for consistency
    from .prodos_writer import datetime_to_prodos_date

    return datetime_to_prodos_date(dt)


# Convenience functions for common disk sizes
def create_140k_dos_disk(file_path: str | Path) -> None:
    """Create standard 140K DOS 3.3 disk."""
    create_blank_dos33_image(file_path)


def create_140k_prodos_disk(
    file_path: str | Path, volume_name: str = "BLANK.DISK"
) -> None:
    """Create standard 140K ProDOS disk."""
    create_blank_prodos_image(file_path, volume_name, 280)  # 280 blocks = 140K


def create_800k_prodos_disk(
    file_path: str | Path, volume_name: str = "BLANK.DISK"
) -> None:
    """Create 800K ProDOS disk."""
    create_blank_prodos_image(file_path, volume_name, 1600)  # 1600 blocks = 800K


def create_32mb_prodos_disk(
    file_path: str | Path, volume_name: str = "BLANK.DISK"
) -> None:
    """Create maximum 32MB ProDOS disk."""
    create_blank_prodos_image(file_path, volume_name, 65535)  # Maximum ProDOS blocks
