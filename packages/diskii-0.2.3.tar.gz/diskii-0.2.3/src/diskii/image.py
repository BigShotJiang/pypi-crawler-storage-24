"""Base classes for disk image handling."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import BinaryIO, Optional

from .exceptions import (
    CorruptedImageError,
    UnsupportedOperationError,
)
from .exceptions import (
    IOError as DiskiiIOError,
)
from .types import FilesystemType, ImageFormat, SectorOrdering
from .translation import TranslatorFactory


class DiskImage(ABC):
    """Abstract base class for disk image readers."""

    def __init__(
        self,
        file_path: str | Path,
        image_format: Optional["ImageFormat"] = None,
        read_only: bool = True,
    ):
        self.file_path = Path(file_path)
        self._file_handle: BinaryIO | None = None
        self._image_format = image_format
        self._read_only = read_only
        self._translator = None

    def __enter__(self):
        mode = "rb" if self._read_only else "r+b"
        self._file_handle = open(self.file_path, mode)

        # Initialize translator - auto-detect format if not provided
        if self._image_format is None:
            self._image_format = self.format  # Trigger format detection

        self._translator = TranslatorFactory.create_translator(
            self._image_format.filesystem,
            self._image_format.sector_ordering,
            self._file_handle,
            self.file_path,
        )

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._file_handle:
            self._file_handle.close()
            self._file_handle = None
        self._translator = None

    @property
    def is_open(self) -> bool:
        """Check if the image file is currently open."""
        return self._file_handle is not None and not self._file_handle.closed

    def read_block(self, block_num: int) -> bytes:
        """Read a logical block from the disk image."""
        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        # Check if translator supports block operations
        if hasattr(self._translator, "read_block"):
            return self._translator.read_block(block_num)
        else:
            # Fall back to sector-based operations (convert block to sectors)
            # Block size is always 512 bytes (2 sectors of 256 bytes each)
            # Convert block number to two consecutive linear sectors
            from .addressing import SectorAddress

            # Determine sectors per track based on filesystem
            if self._image_format.filesystem == FilesystemType.DOS32:
                sectors_per_track = 13
            else:  # DOS33 or ProDOS
                sectors_per_track = 16

            linear_sector_0 = block_num * 2
            linear_sector_1 = block_num * 2 + 1

            # Convert to track/sector addresses
            addr_0 = SectorAddress.from_linear_sector(
                linear_sector_0, sectors_per_track
            )
            addr_1 = SectorAddress.from_linear_sector(
                linear_sector_1, sectors_per_track
            )

            sector_0 = self._translator.read_sector(addr_0.track, addr_0.sector)
            sector_1 = self._translator.read_sector(addr_1.track, addr_1.sector)
            return sector_0 + sector_1

    def read_sector(self, track: int, sector: int) -> bytes:
        """Read a physical sector from the disk image."""
        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        return self._translator.read_sector(track, sector)

    def write_block(self, block_num: int, data: bytes) -> None:
        """Write a logical block to the disk image."""
        if self._read_only:
            raise UnsupportedOperationError("write", "read-only image")

        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        # Check if translator supports block operations
        if hasattr(self._translator, "write_block"):
            self._translator.write_block(block_num, data)
        else:
            # Fall back to sector-based operations (convert block to sectors)
            # Block size is always 512 bytes (2 sectors of 256 bytes each)
            from .addressing import SectorAddress

            # Determine sectors per track based on filesystem
            if self._image_format.filesystem == FilesystemType.DOS32:
                sectors_per_track = 13
            else:  # DOS33 or ProDOS
                sectors_per_track = 16

            linear_sector_0 = block_num * 2
            linear_sector_1 = block_num * 2 + 1

            # Convert to track/sector addresses
            addr_0 = SectorAddress.from_linear_sector(
                linear_sector_0, sectors_per_track
            )
            addr_1 = SectorAddress.from_linear_sector(
                linear_sector_1, sectors_per_track
            )

            sector_0 = data[:256]
            sector_1 = data[256:512] if len(data) > 256 else b"\x00" * 256

            self._translator.write_sector(addr_0.track, addr_0.sector, sector_0)
            self._translator.write_sector(addr_1.track, addr_1.sector, sector_1)

    def write_sector(self, track: int, sector: int, data: bytes) -> None:
        """Write a physical sector to the disk image."""
        if self._read_only:
            raise UnsupportedOperationError("write", "read-only image")

        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        self._translator.write_sector(track, sector, data)

    @abstractmethod
    def get_volume_name(self) -> str:
        """Get the volume name from the disk image."""
        pass

    @abstractmethod
    def get_file_list(self) -> list:
        """Get a list of files on the disk image."""
        pass

    @abstractmethod
    def get_free_space(self) -> int:
        """Get the amount of free space on the disk in bytes."""
        pass

    def create_file(
        self, filename: str, file_type: int | str, data: bytes, **kwargs
    ) -> None:
        """Create a new file on the disk image.

        Args:
            filename: Name of the file to create
            file_type: File type (int for ProDOS, int or str for DOS)
            data: File content bytes
            **kwargs: Additional arguments (aux_type, etc.)
        """
        if self._read_only:
            raise UnsupportedOperationError("create_file", "read-only image")
        self._create_file_impl(filename, file_type, data, **kwargs)

    def delete_file(self, filename: str) -> None:
        """Delete a file from the disk image."""
        if self._read_only:
            raise UnsupportedOperationError("delete_file", "read-only image")
        self._delete_file_impl(filename)

    def modify_file_attributes(self, filename: str, **attrs) -> None:
        """Modify file attributes (file type, aux type, etc.).

        Args:
            filename: Name of the file to modify
            **attrs: Attributes to modify (file_type, aux_type, access, etc.)
        """
        if self._read_only:
            raise UnsupportedOperationError("modify_file_attributes", "read-only image")
        self._modify_file_attributes_impl(filename, **attrs)

    def truncate_file(self, filename: str, new_size: int) -> None:
        """Truncate a file to a new size.

        Args:
            filename: Name of the file to truncate
            new_size: New size in bytes
        """
        if self._read_only:
            raise UnsupportedOperationError("truncate_file", "read-only image")
        if new_size < 0:
            raise ValueError("File size cannot be negative")
        self._truncate_file_impl(filename, new_size)

    def move_file(self, src_filename: str, dest_filename: str) -> None:
        """Move/rename a file on the disk image.

        Args:
            src_filename: Current name of the file
            dest_filename: New name/location for the file
        """
        if self._read_only:
            raise UnsupportedOperationError("move_file", "read-only image")
        self._move_file_impl(src_filename, dest_filename)

    def rename_file(self, old_filename: str, new_filename: str) -> None:
        """Rename a file on the disk image.

        Args:
            old_filename: Current name of the file
            new_filename: New name for the file
        """
        if self._read_only:
            raise UnsupportedOperationError("rename_file", "read-only image")
        self._move_file_impl(old_filename, new_filename)

    @abstractmethod
    def _create_file_impl(
        self, filename: str, file_type: int | str, data: bytes, **kwargs
    ) -> None:
        """Implementation-specific file creation."""
        pass

    @abstractmethod
    def _delete_file_impl(self, filename: str) -> None:
        """Implementation-specific file deletion."""
        pass

    @abstractmethod
    def _modify_file_attributes_impl(self, filename: str, **attrs) -> None:
        """Implementation-specific file attribute modification."""
        pass

    @abstractmethod
    def _truncate_file_impl(self, filename: str, new_size: int) -> None:
        """Implementation-specific file truncation."""
        pass

    @abstractmethod
    def _move_file_impl(self, src_filename: str, dest_filename: str) -> None:
        """Implementation-specific file move/rename."""
        pass

    @property
    def format(self) -> "ImageFormat":
        """Get the image format type."""
        if self._image_format is None:
            # Fallback: detect format if not provided
            from .detection import detect_format

            self._image_format = detect_format(self.file_path)
        return self._image_format

    @property
    def total_blocks(self) -> int:
        """Get the total number of blocks in the image."""
        if self._translator is None:
            # Fallback calculation
            return self.file_path.stat().st_size // 512

        return self._translator.total_blocks

    @property
    def total_sectors(self) -> int:
        """Get the total number of sectors in the image."""
        if self._translator is None:
            # Fallback calculation
            return self.file_path.stat().st_size // 256

        return self._translator.total_sectors


class UnifiedDiskImage(DiskImage):
    """Unified disk image handler that supports all filesystem/ordering combinations."""

    def __init__(
        self,
        file_path: str | Path,
        image_format: Optional["ImageFormat"] = None,
        read_only: bool = True,
    ):
        super().__init__(file_path, image_format, read_only)
        self._volume_name: str | None = None
        self._file_list_cache: list | None = None

    def get_volume_name(self) -> str:
        """Get the volume name from the appropriate filesystem."""
        if self._volume_name is None:
            if self._image_format is None:
                self._image_format = self.format  # Trigger format detection

            if self._image_format.filesystem == FilesystemType.PRODOS:
                from .prodos import parse_prodos_directory

                directory = parse_prodos_directory(self)
                self._volume_name = directory.volume_name
            elif self._image_format.filesystem == FilesystemType.DOS33:
                from .dos33 import DOSCatalog

                catalog = DOSCatalog(self)
                self._volume_name = catalog.vtoc.volume_name
            elif self._image_format.filesystem == FilesystemType.DOS32:
                from .dos32 import DOS32Catalog

                catalog = DOS32Catalog(self)
                self._volume_name = catalog.vtoc.volume_name
            else:
                self._volume_name = "Unknown"

        return self._volume_name

    def get_file_list(self) -> list:
        """Get a list of files using the appropriate filesystem parser."""
        if self._file_list_cache is not None:
            return self._file_list_cache

        if self._image_format is None:
            self._image_format = self.format  # Trigger format detection

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import parse_prodos_directory

            directory = parse_prodos_directory(self)
            self._file_list_cache = directory.parse()
        elif self._image_format.filesystem == FilesystemType.DOS33:
            from .dos33 import parse_dos33_catalog

            catalog = parse_dos33_catalog(self)
            self._file_list_cache = catalog.parse()
        elif self._image_format.filesystem == FilesystemType.DOS32:
            from .dos32 import parse_dos32_catalog

            catalog = parse_dos32_catalog(self)
            self._file_list_cache = catalog.parse()
        else:
            self._file_list_cache = []

        return self._file_list_cache

    def get_all_files(self, recursive: bool = True) -> list:
        """Get all files, with recursive support for ProDOS."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import parse_prodos_directory

            directory = parse_prodos_directory(self)
            return directory.get_all_files(recursive=recursive)
        else:
            # DOS doesn't support subdirectories
            return self.get_file_list()

    def get_free_space(self) -> int:
        """Get the amount of free space on the disk in bytes."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import parse_prodos_directory

            volume = parse_prodos_directory(self)
            free_space_info = volume.get_free_space_info()
            free_blocks = free_space_info.get("free_blocks", 0)
            return free_blocks * 512
        elif self._image_format.filesystem == FilesystemType.DOS33:
            from .dos33 import DOSVTOC

            vtoc = DOSVTOC(self)
            free_sectors = vtoc.free_sectors
            return free_sectors * 256
        elif self._image_format.filesystem == FilesystemType.DOS32:
            from .dos32 import DOS32VTOC

            vtoc = DOS32VTOC(self)
            free_sectors = vtoc.free_sectors
            return free_sectors * 256
        else:
            return 0

    def _create_file_impl(
        self, filename: str, file_type: int | str, data: bytes, **kwargs
    ) -> None:
        """Create a new file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .file_type_conversion import (
                get_prodos_aux_type_for_basic,
                normalize_prodos_file_type,
            )
            from .prodos_writer import create_prodos_file

            # Normalize file type to ProDOS integer format
            prodos_file_type = normalize_prodos_file_type(file_type)

            # Set default aux_type for BASIC programs if not specified
            if "aux_type" not in kwargs:
                aux_type = get_prodos_aux_type_for_basic(file_type)
                if aux_type != 0:
                    kwargs["aux_type"] = aux_type

            create_prodos_file(self, filename, prodos_file_type, data, **kwargs)

        elif self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            from .dos_writer import create_dos_file
            from .file_type_conversion import normalize_dos_file_type

            # Normalize file type to DOS string format
            dos_file_type = normalize_dos_file_type(file_type)
            create_dos_file(self, filename, dos_file_type, data, **kwargs)

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def _delete_file_impl(self, filename: str) -> None:
        """Delete a file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos_writer import delete_prodos_file

            delete_prodos_file(self, filename)
        elif self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            from .dos_writer import delete_dos_file

            delete_dos_file(self, filename)

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def _modify_file_attributes_impl(self, filename: str, **attrs) -> None:
        """Modify file attributes using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos_writer import modify_prodos_file_attributes

            modify_prodos_file_attributes(self, filename, **attrs)
        else:
            raise UnsupportedOperationError("modify_file_attributes", "DOS filesystem")

    def _truncate_file_impl(self, filename: str, new_size: int) -> None:
        """Truncate a file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos_writer import truncate_prodos_file

            truncate_prodos_file(self, filename, new_size)
        else:
            raise UnsupportedOperationError("truncate_file", "DOS filesystem")

    def _move_file_impl(self, src_filename: str, dest_filename: str) -> None:
        """Move/rename a file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos_writer import move_prodos_file

            move_prodos_file(self, src_filename, dest_filename)
        elif self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            from .dos_writer import rename_dos_file

            rename_dos_file(self, src_filename, dest_filename)

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def create_directory(self, directory_path: str) -> None:
        """Create a new directory (ProDOS only).

        Args:
            directory_path: Path of the directory to create (e.g., "SUBDIR")
        """
        if self._read_only:
            raise UnsupportedOperationError("create_directory", "read-only image")

        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos_writer import create_prodos_directory

            create_prodos_directory(self, directory_path)
        else:
            raise UnsupportedOperationError("create_directory", "DOS filesystem")

    def delete_directory(self, directory_path: str) -> None:
        """Delete a directory (ProDOS only).

        Args:
            directory_path: Path of the directory to delete (e.g., "SUBDIR")
        """
        if self._read_only:
            raise UnsupportedOperationError("delete_directory", "read-only image")

        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos_writer import delete_prodos_directory

            delete_prodos_directory(self, directory_path)
        else:
            raise UnsupportedOperationError("delete_directory", "DOS filesystem")

    def __str__(self) -> str:
        """String representation of the disk image."""
        if self._image_format is None:
            self._image_format = self.format  # Trigger format detection

        filesystem_name = self._image_format.filesystem.name
        return f"UnifiedDiskImage({self.file_path.name}, {filesystem_name})"
