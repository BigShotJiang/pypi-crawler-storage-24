"""DOS filename encoding and manipulation utilities.

This module handles the special character encoding used in DOS 3.3 and DOS 3.2
filesystems, including inverse text (high-bit ASCII) and filename validation.

Based on CiderPress 2 DOS filename handling for maximum compatibility.
"""

import re
from typing import Union


class DOSFilename:
    """DOS filename with raw and display representations."""

    def __init__(self, raw_bytes: bytes):
        """Initialize from raw DOS filename bytes.

        Args:
            raw_bytes: 30-character DOS filename as stored in catalog
        """
        if len(raw_bytes) != 30:
            raise ValueError("DOS filename must be exactly 30 bytes")

        self._raw_bytes = raw_bytes
        self._display_name = self._decode_display_name()

    @classmethod
    def from_display_name(cls, display_name: str) -> "DOSFilename":
        """Create DOSFilename from human-readable display name.

        Args:
            display_name: Human-readable filename

        Returns:
            DOSFilename instance

        Raises:
            ValueError: If display name is invalid
        """
        if not display_name:
            raise ValueError("Display name cannot be empty")

        if len(display_name) > 30:
            raise ValueError("Display name too long (max 30 characters)")

        # Convert display name to raw bytes
        raw_bytes = cls._encode_raw_bytes(display_name)
        return cls(raw_bytes)

    @property
    def raw_bytes(self) -> bytes:
        """Get raw DOS filename bytes as stored in catalog."""
        return self._raw_bytes

    @property
    def display_name(self) -> str:
        """Get human-readable display name."""
        return self._display_name

    @property
    def padded_name(self) -> str:
        """Get display name without trailing spaces."""
        return self._display_name.rstrip()

    def _decode_display_name(self) -> str:
        """Decode raw bytes to display name."""
        result = []

        for byte_val in self._raw_bytes:
            if byte_val == 0xA0:  # Space character in DOS
                result.append(" ")
            elif byte_val == 0x00:  # Null terminator
                break
            elif 0x20 <= byte_val <= 0x7F:  # Normal ASCII
                result.append(chr(byte_val))
            elif 0xA0 <= byte_val <= 0xFF:  # Inverse/high-bit ASCII
                # Convert high-bit ASCII to normal ASCII (standard DOS behavior)
                normal_char = chr(byte_val & 0x7F)
                if normal_char.isprintable():
                    result.append(normal_char)  # Convert to normal ASCII
                else:
                    result.append(f"[${byte_val:02X}]")
            else:
                # Non-printable characters
                result.append(f"[${byte_val:02X}]")

        return "".join(result)

    @staticmethod
    def _encode_raw_bytes(display_name: str) -> bytes:
        """Encode display name to raw DOS bytes."""
        result = bytearray(30)  # DOS filenames are always 30 bytes
        pos = 0
        i = 0

        while i < len(display_name) and pos < 30:
            char = display_name[i]

            # Handle inverse character markers [X]
            if char == "[" and i + 2 < len(display_name) and display_name[i + 2] == "]":
                inverse_char = display_name[i + 1]
                if inverse_char.isprintable():
                    # Convert to high-bit ASCII
                    result[pos] = ord(inverse_char) | 0x80
                    pos += 1
                    i += 3
                    continue

            # Handle hex markers [$ XX]
            if (
                char == "["
                and i + 4 < len(display_name)
                and display_name[i + 1] == "$"
                and display_name[i + 4] == "]"
            ):
                try:
                    hex_val = int(display_name[i + 2 : i + 4], 16)
                    result[pos] = hex_val
                    pos += 1
                    i += 5
                    continue
                except ValueError:
                    pass

            # Regular ASCII character - store as high-bit ASCII (historical DOS
            # behavior)
            if char.isprintable() and ord(char) <= 0x7F:
                result[pos] = ord(char) | 0x80  # Set high bit
                pos += 1
            else:
                # Invalid character, skip
                pass

            i += 1

        # Pad with spaces (0xA0 in DOS)
        while pos < 30:
            result[pos] = 0xA0
            pos += 1

        return bytes(result)

    def __str__(self) -> str:
        """String representation is the display name."""
        return self.display_name

    def __repr__(self) -> str:
        """Detailed representation showing both raw and display."""
        return f"DOSFilename(display='{self.display_name}', raw={self.raw_bytes.hex()})"

    def __eq__(self, other: Union["DOSFilename", str]) -> bool:
        """Compare filenames."""
        if isinstance(other, DOSFilename):
            return self.raw_bytes == other.raw_bytes
        elif isinstance(other, str):
            return self.display_name == other
        return False


def validate_dos_filename(filename: str) -> bool:
    """Validate a DOS filename for correctness.

    Args:
        filename: Filename to validate

    Returns:
        True if filename is valid for DOS
    """
    if not filename:
        return False

    if len(filename) > 30:
        return False

    # Check for invalid characters
    # DOS allows most printable ASCII except some special chars
    invalid_chars = r'[<>:"|?*\\/]'
    if re.search(invalid_chars, filename):
        return False

    return True


def normalize_dos_filename(filename: str) -> str:
    """Normalize a filename for DOS compatibility.

    Args:
        filename: Input filename

    Returns:
        Normalized filename safe for DOS
    """
    if not filename:
        return "UNNAMED"

    # Convert to uppercase (DOS convention)
    filename = filename.upper()

    # Replace invalid characters with underscores
    filename = re.sub(r'[<>:"|?*\\/]', "_", filename)

    # Truncate to 30 characters
    if len(filename) > 30:
        filename = filename[:30]

    # Remove leading/trailing spaces
    filename = filename.strip()

    if not filename:
        return "UNNAMED"

    return filename


def compare_dos_filenames(name1: str, name2: str) -> bool:
    """Compare two DOS filenames for equality.

    DOS filename comparison is case-insensitive and ignores trailing spaces.

    Args:
        name1: First filename
        name2: Second filename

    Returns:
        True if filenames are equivalent
    """
    # Normalize both names
    norm1 = name1.upper().rstrip()
    norm2 = name2.upper().rstrip()

    return norm1 == norm2


def extract_filename_from_catalog_entry(
    catalog_bytes: bytes, offset: int
) -> DOSFilename:
    """Extract filename from DOS catalog entry.

    Args:
        catalog_bytes: Raw catalog sector data
        offset: Offset to filename within catalog entry

    Returns:
        DOSFilename instance

    Raises:
        ValueError: If offset is invalid or data is corrupted
    """
    if offset + 30 > len(catalog_bytes):
        raise ValueError("Catalog entry extends beyond sector boundary")

    filename_bytes = catalog_bytes[offset : offset + 30]
    return DOSFilename(filename_bytes)


def create_catalog_filename_bytes(display_name: str) -> bytes:
    """Create 30-byte filename for DOS catalog entry.

    Args:
        display_name: Human-readable filename

    Returns:
        30-byte filename suitable for catalog entry

    Raises:
        ValueError: If display name is invalid
    """
    if not validate_dos_filename(display_name):
        raise ValueError(f"Invalid DOS filename: {display_name}")

    dos_filename = DOSFilename.from_display_name(display_name)
    return dos_filename.raw_bytes
