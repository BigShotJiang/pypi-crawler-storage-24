"""Common type definitions for diskii."""

from enum import Enum


class SectorOrdering(Enum):
    """Sector ordering schemes for disk images."""

    DOS_ORDER = "dos_order"  # .dsk, .do files - DOS 3.3 sector interleaving
    PRODOS_ORDER = "prodos_order"  # .po files - ProDOS block ordering
    DOS32_ORDER = "dos32_order"  # .d13 files - DOS 3.2 13-sector format


class FilesystemType(Enum):
    """Filesystem types found on disk images."""

    DOS33 = "dos33"  # DOS 3.3 filesystem
    PRODOS = "prodos"  # ProDOS filesystem
    DOS32 = "dos32"  # DOS 3.2 filesystem


class ImageFormat:
    """Complete disk image format combining sector ordering and filesystem type."""

    def __init__(
        self,
        sector_ordering: SectorOrdering,
        filesystem: FilesystemType,
        size_bytes: int | None = None,
    ):
        self.sector_ordering = sector_ordering
        self.filesystem = filesystem
        self.size_bytes = size_bytes

    def __eq__(self, other):
        if isinstance(other, ImageFormat):
            return (
                self.sector_ordering == other.sector_ordering
                and self.filesystem == other.filesystem
            )
        return False

    def __repr__(self):
        return f"ImageFormat({self.sector_ordering.value}, {self.filesystem.value})"
