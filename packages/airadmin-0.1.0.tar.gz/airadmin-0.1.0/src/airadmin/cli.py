"""Console script for airadmin."""

import typer
from rich.console import Console

from airadmin import utils

app = typer.Typer()
console = Console()


@app.command()
def main() -> None:
    """Console script for airadmin."""
    console.print("Replace this message by putting your code into airadmin.cli.main")
    console.print("See Typer documentation at https://typer.tiangolo.com/")
    utils.do_something_useful()


if __name__ == "__main__":
    app()
