# AirAdmin

Admin UI for Air web framework, inspired by the Django admin and its replacements

## Getting started

- [Installation](installation.md) - how to install AirAdmin
- [Usage](usage.md) - how to use AirAdmin
- [API Reference](api.md) - auto-generated API documentation
