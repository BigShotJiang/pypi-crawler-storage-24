# Usage

To use AirAdmin in a project:

```python
import airadmin
```
