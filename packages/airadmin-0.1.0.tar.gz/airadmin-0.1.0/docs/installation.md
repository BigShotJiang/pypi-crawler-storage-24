# Installation

## Stable release

To install AirAdmin, run this command in your terminal:

```sh
uv add AirAdmin
```

Or if you prefer to use `pip`:

```sh
pip install AirAdmin
```

## From source

The source files for AirAdmin can be downloaded from the [Github repo](https://github.com/feldroy/AirAdmin).

You can either clone the public repository:

```sh
git clone https://github.com/feldroy/AirAdmin
```

Or download the [tarball](https://github.com/feldroy/AirAdmin/tarball/main):

```sh
curl -OJL https://github.com/feldroy/AirAdmin/tarball/main
```

Once you have a copy of the source, you can install it with:

```sh
cd AirAdmin
uv sync
```
