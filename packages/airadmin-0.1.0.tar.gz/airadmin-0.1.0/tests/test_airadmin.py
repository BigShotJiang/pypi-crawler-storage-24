"""Tests for `airadmin` package."""

import airadmin


def test_import():
    """Verify the package can be imported."""
    assert airadmin
