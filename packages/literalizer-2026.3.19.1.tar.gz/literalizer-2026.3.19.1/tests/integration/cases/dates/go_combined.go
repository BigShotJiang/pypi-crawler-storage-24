package main

func main() {
my_data := map[string]any{
    "date": "2024-01-15",
    "datetime": "2024-01-15T12:30:00+00:00",
}
my_data = map[string]any{
    "date": "2024-01-15",
    "datetime": "2024-01-15T12:30:00+00:00",
}
_ = my_data
}
