"""Local dev server for the component showcase."""

import uvicorn

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components, component_router

settings = BluefoxSettings()
app = create_bluefox_app(settings)
setup_components(app)
app.include_router(component_router, prefix="/components", tags=["components"])

if __name__ == "__main__":
    uvicorn.run("serve_showcase:app", host="127.0.0.1", port=8080, reload=True)
