import httpx
from httpx import ASGITransport

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components, component_router


def _make_app(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    setup_components(app)
    app.include_router(component_router, prefix="/components", tags=["components"])
    return app


# --- showcase route ---


async def test_showcase__returns_200(monkeypatch):
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/components/")

    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]


async def test_showcase__contains_all_component_sections(monkeypatch):
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/components/")

    html = resp.text
    # All section IDs present
    assert 'id="button"' in html
    assert 'id="input"' in html
    assert 'id="select"' in html
    assert 'id="textarea"' in html
    assert 'id="form-group"' in html
    assert 'id="card"' in html
    assert 'id="nav"' in html
    assert 'id="alert"' in html


async def test_showcase__renders_live_components(monkeypatch):
    """Showcase renders actual macro output, not just code snippets."""
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/components/")

    html = resp.text
    # Buttons actually rendered
    assert ">Primary</button>" in html
    assert ">Secondary</button>" in html
    # Inputs rendered
    assert 'type="email"' in html
    assert 'placeholder="you@example.com"' in html
    # Alerts rendered
    assert "alert-info" in html
    assert "alert-success" in html
    assert "alert-warning" in html
    assert "alert-error" in html
    # Cards rendered
    assert "<article" in html
    assert "<header>User Profile</header>" in html


async def test_showcase__contains_source_previews(monkeypatch):
    """Each component section includes copy-paste code blocks."""
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/components/")

    html = resp.text
    assert "code-block" in html
    # Raw macro syntax visible in code blocks (not rendered)
    assert "{% from" in html or "{%" in html


async def test_showcase__has_toc_navigation(monkeypatch):
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/components/")

    html = resp.text
    assert "sc-toc" in html
    assert 'href="#button"' in html
    assert 'href="#alert"' in html


async def test_showcase__has_bluefox_theme(monkeypatch):
    """Showcase page uses the Bluefox theme tokens and layout."""
    app = _make_app(monkeypatch)
    transport = ASGITransport(app=app)

    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.get("/components/")

    html = resp.text
    assert "DM Sans" in html
    assert "#D4652A" in html
    assert "<footer" in html


# --- component_router export ---


def test_component_router__exported():
    """component_router is importable from the package."""
    from bluefox_components import component_router
    assert component_router is not None
    assert hasattr(component_router, "routes")
