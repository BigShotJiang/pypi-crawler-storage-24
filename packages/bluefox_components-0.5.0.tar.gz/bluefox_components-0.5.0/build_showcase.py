"""Render the component showcase to a static HTML file for production."""

import sys
from pathlib import Path

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings
from bluefox_components import setup_components


def main() -> None:
    outdir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("site/showcase")
    outdir.mkdir(parents=True, exist_ok=True)

    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    setup_components(app)

    templates = app.state.templates
    html = templates.get_template("bfx_preview/showcase.html").render(
        title="Component Showcase — Bluefox",
        base_url="/showcase/",
    )
    (outdir / "index.html").write_text(html)
    print(f"Showcase built → {outdir / 'index.html'}")


if __name__ == "__main__":
    main()
