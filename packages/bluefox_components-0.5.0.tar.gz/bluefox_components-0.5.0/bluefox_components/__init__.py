from bluefox_components.router import router as component_router
from bluefox_components.setup import setup_components

__all__ = [
    "setup_components",
    "component_router",
]
