"""Component showcase router — mounted at /components."""

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
async def showcase(request: Request) -> HTMLResponse:
    """Render the full component showcase page."""
    templates = request.app.state.templates
    html = templates.get_template("bfx_preview/showcase.html").render(
        title="Components — Bluefox",
        request=request,
    )
    return HTMLResponse(html)
