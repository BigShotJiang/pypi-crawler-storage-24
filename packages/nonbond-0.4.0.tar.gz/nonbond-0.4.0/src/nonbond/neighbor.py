import numpy as np


class NeighborList:
    """
    Cell-linked neighbor list builder (Cython-ready layout).

    - positions: (N, 3) float64 array
    - cutoff: scalar float
    - box: optional (3,) array for orthorhombic periodic box
    """

    def __init__(
        self,
        positions: np.ndarray,
        cutoff: float,
        box: np.ndarray | None = None,
    ):
        if positions.ndim != 2 or positions.shape[1] != 3:
            raise ValueError("positions must have shape (N, 3)")
        if positions.dtype != np.float64:
            positions = np.asarray(positions, dtype=np.float64)

        self._positions = np.ascontiguousarray(positions, dtype=np.float64)
        self._cutoff = float(cutoff)
        self._cutoff2 = self._cutoff * self._cutoff

        if box is not None:
            box = np.asarray(box, dtype=np.float64)
            if box.shape != (3,):
                raise ValueError("box must have shape (3,)")
            if np.any(box <= 0.0):
                raise ValueError("box lengths must be positive")
            self._box = np.ascontiguousarray(box, dtype=np.float64)
            self._inv_box = 1.0 / self._box
            self._periodic = True
            self._origin = np.zeros(3, dtype=np.float64)
        else:
            # non-periodic bounding box tightly around the points
            self._box = None
            self._inv_box = None
            self._periodic = False
            self._origin = np.min(self._positions, axis=0)

        self._neighbors = np.empty(0, dtype=np.int32)
        self._offsets = np.zeros(self._positions.shape[0] + 1, dtype=np.int64)

    # ------------------------------------------------------------------ #
    # public API                                                         #
    # ------------------------------------------------------------------ #
    def build(self) -> None:
        """Build neighbor list into flat adjacency layout."""
        positions = self._positions
        cutoff = self._cutoff
        cutoff2 = self._cutoff2
        n_atoms = positions.shape[0]

        # grid sizing
        cell_size = cutoff
        if self._periodic:
            box = self._box
            cell_counts = np.maximum(
                np.floor(box / cell_size).astype(np.int32), 1
            )
            origin = self._origin
        else:
            min_corner = self._origin
            max_corner = np.max(positions, axis=0)
            span = max_corner - min_corner + 1e-12
            cell_counts = np.maximum(
                np.floor(span / cell_size).astype(np.int32), 1
            )
            origin = min_corner

        nx, ny, nz = int(cell_counts[0]), int(cell_counts[1]), int(cell_counts[2])
        n_cells = nx * ny * nz
        if n_cells <= 0:
            raise RuntimeError("Invalid grid configuration for neighbor list.")

        # cell ids for each particle
        rel = (positions - origin) / cell_size
        grid = np.floor(rel).astype(np.int32)
        grid = np.clip(grid, 0, cell_counts - 1)
        lin_ids = grid[:, 0] + nx * (grid[:, 1] + ny * grid[:, 2])

        # sort particles by cell id
        counts_per_cell = np.zeros(n_cells, dtype=np.int32)
        np.add.at(counts_per_cell, lin_ids, 1)
        cell_start = np.empty(n_cells + 1, dtype=np.int64)
        cell_start[0] = 0
        np.cumsum(counts_per_cell, out=cell_start[1:])

        sorted_indices = np.empty(n_atoms, dtype=np.int32)
        write_ptr_cell = cell_start[:-1].copy()
        for idx in range(n_atoms):
            c = lin_ids[idx]
            pos_in_sorted = write_ptr_cell[c]
            sorted_indices[pos_in_sorted] = idx
            write_ptr_cell[c] = pos_in_sorted + 1

        # offsets for each cell in the sorted array
        neighbor_offsets = np.array(
            [
                [dx, dy, dz]
                for dz in (-1, 0, 1)
                for dy in (-1, 0, 1)
                for dx in (-1, 0, 1)
            ],
            dtype=np.int32,
        )

        neighbor_counts = np.zeros(n_atoms, dtype=np.int32)
        positions_view = positions
        periodic = self._periodic
        box = self._box
        inv_box = self._inv_box

        # first pass: count neighbors
        cell_id = 0
        for cz in range(nz):
            for cy in range(ny):
                for cx in range(nx):
                    start_i = cell_start[cell_id]
                    end_i = cell_start[cell_id + 1]
                    if end_i == start_i:
                        cell_id += 1
                        continue

                    for offset in neighbor_offsets:
                        nx_cell = cx + int(offset[0])
                        ny_cell = cy + int(offset[1])
                        nz_cell = cz + int(offset[2])

                        if periodic:
                            if nx_cell < 0:
                                nx_cell += nx
                            elif nx_cell >= nx:
                                nx_cell -= nx
                            if ny_cell < 0:
                                ny_cell += ny
                            elif ny_cell >= ny:
                                ny_cell -= ny
                            if nz_cell < 0:
                                nz_cell += nz
                            elif nz_cell >= nz:
                                nz_cell -= nz
                        else:
                            if (
                                nx_cell < 0
                                or ny_cell < 0
                                or nz_cell < 0
                                or nx_cell >= nx
                                or ny_cell >= ny
                                or nz_cell >= nz
                            ):
                                continue

                        neigh_id = nx_cell + nx * (ny_cell + ny * nz_cell)
                        if neigh_id < cell_id:
                            continue

                        start_j = cell_start[neigh_id]
                        end_j = cell_start[neigh_id + 1]
                        if end_j == start_j:
                            continue

                        for idx_i in range(start_i, end_i):
                            i = int(sorted_indices[idx_i])
                            pos_i = positions_view[i]

                            if neigh_id == cell_id:
                                idx_j_start = idx_i + 1
                            else:
                                idx_j_start = start_j

                            for idx_j in range(idx_j_start, end_j):
                                j = int(sorted_indices[idx_j])
                                pos_j = positions_view[j]

                                dx0 = pos_j[0] - pos_i[0]
                                dy0 = pos_j[1] - pos_i[1]
                                dz0 = pos_j[2] - pos_i[2]

                                if periodic:
                                    dx0 -= np.rint(dx0 * inv_box[0]) * box[0]
                                    dy0 -= np.rint(dy0 * inv_box[1]) * box[1]
                                    dz0 -= np.rint(dz0 * inv_box[2]) * box[2]

                                dist2 = dx0 * dx0 + dy0 * dy0 + dz0 * dz0
                                if dist2 < cutoff2:
                                    neighbor_counts[i] += 1
                                    neighbor_counts[j] += 1
                    cell_id += 1

        offsets = np.empty(n_atoms + 1, dtype=np.int64)
        offsets[0] = 0
        offsets[1:] = np.cumsum(neighbor_counts, dtype=np.int64)
        neighbors = np.empty(int(offsets[-1]), dtype=np.int32)

        # second pass: fill adjacency
        write_ptr = offsets[:-1].copy()
        cell_id = 0
        for cz in range(nz):
            for cy in range(ny):
                for cx in range(nx):
                    start_i = cell_start[cell_id]
                    end_i = cell_start[cell_id + 1]
                    if end_i == start_i:
                        cell_id += 1
                        continue

                    for offset in neighbor_offsets:
                        nx_cell = cx + int(offset[0])
                        ny_cell = cy + int(offset[1])
                        nz_cell = cz + int(offset[2])

                        if periodic:
                            if nx_cell < 0:
                                nx_cell += nx
                            elif nx_cell >= nx:
                                nx_cell -= nx
                            if ny_cell < 0:
                                ny_cell += ny
                            elif ny_cell >= ny:
                                ny_cell -= ny
                            if nz_cell < 0:
                                nz_cell += nz
                            elif nz_cell >= nz:
                                nz_cell -= nz
                        else:
                            if (
                                nx_cell < 0
                                or ny_cell < 0
                                or nz_cell < 0
                                or nx_cell >= nx
                                or ny_cell >= ny
                                or nz_cell >= nz
                            ):
                                continue

                        neigh_id = nx_cell + nx * (ny_cell + ny * nz_cell)
                        if neigh_id < cell_id:
                            continue

                        start_j = cell_start[neigh_id]
                        end_j = cell_start[neigh_id + 1]
                        if end_j == start_j:
                            continue

                        for idx_i in range(start_i, end_i):
                            i = int(sorted_indices[idx_i])
                            pos_i = positions_view[i]

                            if neigh_id == cell_id:
                                idx_j_start = idx_i + 1
                            else:
                                idx_j_start = start_j

                            for idx_j in range(idx_j_start, end_j):
                                j = int(sorted_indices[idx_j])
                                pos_j = positions_view[j]

                                dx0 = pos_j[0] - pos_i[0]
                                dy0 = pos_j[1] - pos_i[1]
                                dz0 = pos_j[2] - pos_i[2]

                                if periodic:
                                    dx0 -= np.rint(dx0 * inv_box[0]) * box[0]
                                    dy0 -= np.rint(dy0 * inv_box[1]) * box[1]
                                    dz0 -= np.rint(dz0 * inv_box[2]) * box[2]

                                dist2 = dx0 * dx0 + dy0 * dy0 + dz0 * dz0
                                if dist2 < cutoff2:
                                    ptr_i = write_ptr[i]
                                    ptr_j = write_ptr[j]
                                    neighbors[ptr_i] = j
                                    neighbors[ptr_j] = i
                                    write_ptr[i] = ptr_i + 1
                                    write_ptr[j] = ptr_j + 1
                    cell_id += 1

        self._neighbors = neighbors
        self._offsets = offsets

    def neighbors_of(self, i: int) -> np.ndarray:
        """Return neighbors of particle i as a 1D int array view."""
        if i < 0 or i >= self._positions.shape[0]:
            raise IndexError("particle index out of range")
        start = int(self._offsets[i])
        end = int(self._offsets[i + 1])
        return self._neighbors[start:end]


if __name__ == "__main__":
    import numpy as np
    from nonbond.neighbor import NeighborList

    pos = np.random.rand(1000, 3)
    nl = NeighborList(pos, cutoff=0.3)
    nl.build()

    print(nl.neighbors_of(0))
