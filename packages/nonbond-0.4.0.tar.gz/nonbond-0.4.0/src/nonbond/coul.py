from torchpme.tuning import tune_ewald, tune_pme, tune_p3m
import torchpme
import torch
from torchpme.prefactors import eV_A
import numpy as np


class CoulombCalculator:
    """
    Coulomb Calculator
    """

    def __init__(
        self,
        method: str,
        cutoff: float,
        accuracy: float,
        device: str,
        dtype: torch.dtype,
    ):
        
        if method is not None:
            self._method = method.lower()
        self._cutoff = cutoff
        self._accuracy = accuracy
        self._device = device
        self._dtype = dtype

        # 验证方法
        valid_methods = ['direct', 'ewald', 'pme', 'p3m']
        if self._method not in valid_methods:
            raise ValueError(
                f"Unsupported method: {self._method}. Valid methods: {valid_methods}"
            )

        # 通用参数
        self._neighbor_indices, self._neighbor_distances, self._neighbor_vectors = None, None, None
        self._positions = None
        self._cell = None
        self._charges = None

        #结果
        self._energy = None
        self._energies = None
        self._forces = None
        # self.forces = None

    def get_coul_energy_and_forces(
        self,
        neighbor_indices: torch.Tensor,
        neighbor_distances: torch.Tensor,
        neighbor_vectors: torch.Tensor,
        positions: torch.Tensor,
        cell: torch.Tensor,
        charges: torch.Tensor,
    ) -> float:

        self._positions = positions
        self._cell = cell
        self._charges = charges

        self._neighbor_indices, self._neighbor_distances, self._neighbor_vectors = neighbor_indices, neighbor_distances, neighbor_vectors

        if self._method == 'direct':
            self._direct_coulomb()
        else:
            self._long_range_coulomb()

        return self._energy, self._energies, self._forces

    def _optimize_params(self):
        if self._method == 'ewald':
            return tune_ewald(
                charges=self._charges,
                cell=self._cell,
                positions=self._positions,
                cutoff=self._cutoff,
                accuracy=self._accuracy,
                neighbor_indices=self._neighbor_indices,
                neighbor_distances=self._neighbor_distances,
            )
        elif self._method == 'pme':
            return tune_pme(
                charges=self._charges,
                cell=self._cell,
                positions=self._positions,
                cutoff=self._cutoff,
                accuracy=self._accuracy,
                neighbor_indices=self._neighbor_indices,
                neighbor_distances=self._neighbor_distances,
            )
        elif self._method == 'p3m':
            return tune_p3m(
                charges=self._charges,
                cell=self._cell,
                positions=self._positions,
                cutoff=self._cutoff,
                accuracy=self._accuracy,
                neighbor_indices=self._neighbor_indices,
                neighbor_distances=self._neighbor_distances,
            )

    def _long_range_coulomb(self) -> float:
        """长程库伦相互作用计算"""
        smearing, params, _ = self._optimize_params()
        prefactor = eV_A
        if self._method == 'ewald':
            base_calc = torchpme.EwaldCalculator(
                potential=torchpme.CoulombPotential(smearing,prefactor=prefactor),
                **params,
                )
        elif self._method == 'pme':
            base_calc = torchpme.PMECalculator(
                potential=torchpme.CoulombPotential(smearing,prefactor=prefactor),
                **params,
                )
        elif self._method == 'p3m':
            base_calc = torchpme.P3MCalculator(
                potential=torchpme.CoulombPotential(smearing,prefactor=prefactor),
                **params,
                )

        calculator = base_calc
        calculator.to(device=self._device, dtype=self._dtype)
        potentials = calculator.forward(self._charges, self._cell,
                                        self._positions,
                                        self._neighbor_indices,
                                        self._neighbor_distances)
        energies = self._charges * potentials
        energy = torch.sum(energies)

        energy.backward()
        forces = -self._positions.grad

        self._energy = energy.item()
        self._energies = energies
        self._forces = forces

    def _direct_coulomb(self):

        COULOMB_CONSTANT = 14.399644853  # eV·Å / e^2

        if self._neighbor_indices is None or self._neighbor_distances is None:
            raise RuntimeError("Neighbor list not initialized.")

        if self._neighbor_vectors is None:
            raise RuntimeError(
                "neighbor_vectors is required to compute Coulomb forces.")

        # -------------------------------------------------
        # indices
        # -------------------------------------------------
        i_idx = self._neighbor_indices[:, 0].to(self._device)
        j_idx = self._neighbor_indices[:, 1].to(self._device)

        # -------------------------------------------------
        # charges
        # -------------------------------------------------
        qi = self._charges[i_idx].to(self._device, dtype=self._dtype).flatten()
        qj = self._charges[j_idx].to(self._device, dtype=self._dtype).flatten()

        # -------------------------------------------------
        # geometry
        # -------------------------------------------------
        r = self._neighbor_distances.to(self._device, dtype=self._dtype)
        r_vec = self._neighbor_vectors.to(self._device, dtype=self._dtype)

        # avoid r = 0
        mask = r > 1e-12
        qi = qi[mask]
        qj = qj[mask]
        r = r[mask]
        r_vec = r_vec[mask]
        i_idx = i_idx[mask]
        j_idx = j_idx[mask]

        # -------------------------------------------------
        # energy (pair)
        # -------------------------------------------------
        pair_energy = COULOMB_CONSTANT * qi * qj / r

        n_atoms = self._charges.shape[0]
        energies = torch.zeros(n_atoms, device=self._device, dtype=self._dtype)
        energies.index_add_(0, i_idx, 0.5 * pair_energy)
        energies.index_add_(0, j_idx, 0.5 * pair_energy)

        energy = energies.sum().item()

        # -------------------------------------------------
        # forces
        # -------------------------------------------------
        inv_r3 = 1.0 / (r * r * r)
        force_scalar = COULOMB_CONSTANT * qi * qj * inv_r3
        force_vec = force_scalar[:, None] * r_vec  # (n_pair, 3)

        forces = torch.zeros((n_atoms, 3),
                             device=self._device,
                             dtype=self._dtype)
        forces.index_add_(0, i_idx, force_vec)
        forces.index_add_(0, j_idx, -force_vec)

        # -------------------------------------------------
        # save results
        # -------------------------------------------------
        self._energy = energy
        self._energies = energies
        self._forces = forces
