import torch


class LJCalculator:
    def __init__(self,
                 cutoff: float,
                 shift: bool,
                 device: str,
                 dtype: torch.dtype):
        self._cutoff = cutoff
        self._shift = shift
        self._device = device
        self._dtype = dtype

        # cache (pair-level, must be cleared when neighborlist changes)
        self._cached = False
        self._sigma_ij = None
        self._epsilon_ij = None
        self._inv_r6 = None
        self._inv_r12 = None
        self._i_idx = None
        self._j_idx = None
        self._n_atoms = None

    # ------------------------------------------------------------------
    # cache control
    # ------------------------------------------------------------------
    def clear_cache(self):
        self._cached = False
        self._sigma_ij = None
        self._epsilon_ij = None
        self._inv_r6 = None
        self._inv_r12 = None
        self._i_idx = None
        self._j_idx = None
        self._n_atoms = None

    # ------------------------------------------------------------------
    # parameter mixing
    # ------------------------------------------------------------------
    def _mix_lj_params(self, neighbor_indices, epsilon, sigma):
        sigma_t = torch.as_tensor(sigma, device=self._device, dtype=self._dtype)
        eps_t   = torch.as_tensor(epsilon, device=self._device, dtype=self._dtype)

        i_idx = neighbor_indices[:, 0].to(self._device)
        j_idx = neighbor_indices[:, 1].to(self._device)

        sigma_ij   = 0.5 * (sigma_t[i_idx] + sigma_t[j_idx])
        epsilon_ij = torch.sqrt(eps_t[i_idx] * eps_t[j_idx])

        self._sigma_ij = sigma_ij
        self._epsilon_ij = epsilon_ij
        self._i_idx = i_idx
        self._j_idx = j_idx
        self._n_atoms = sigma_t.shape[0]

        return sigma_ij, epsilon_ij

    # ------------------------------------------------------------------
    # LJ powers
    # ------------------------------------------------------------------
    def _lj_powers(self, sigma_ij, r):

        inv_r = sigma_ij / r
        inv_r2 = inv_r * inv_r
        inv_r6 = inv_r2 * inv_r2 * inv_r2
        inv_r12 = inv_r6 * inv_r6

        self._inv_r6 = inv_r6
        self._inv_r12 = inv_r12
        self._cached = True

        return inv_r6, inv_r12

    # energy
    def get_lj_energy(self, neighbor_indices, neighbor_distances, epsilon, sigma):

        if neighbor_indices.numel() == 0:
            return 0.0, None

        r = neighbor_distances.to(self._device, dtype=self._dtype)

        sigma_ij, epsilon_ij = self._mix_lj_params(
            neighbor_indices, epsilon, sigma
        )
        inv_r6, inv_r12 = self._lj_powers(sigma_ij, r)

        pair_energy = 4.0 * epsilon_ij * (inv_r12 - inv_r6)

        if self._shift:
            rc = torch.as_tensor(self._cutoff, device=self._device, dtype=self._dtype)
            inv_rc = sigma_ij / rc
            inv_rc2 = inv_rc * inv_rc
            inv_rc6 = inv_rc2 * inv_rc2 * inv_rc2
            inv_rc12 = inv_rc6 * inv_rc6
            pair_energy = pair_energy - 4.0 * epsilon_ij * (inv_rc12 - inv_rc6)

        energies = torch.zeros(
            self._n_atoms, device=self._device, dtype=self._dtype
        )
        energies.index_add_(0, self._i_idx, 0.5 * pair_energy)
        energies.index_add_(0, self._j_idx, 0.5 * pair_energy)

        return energies.sum().item(), energies


    # forces (NOTE: shift does NOT affect force)
    def get_lj_forces(self,
                      neighbor_indices,
                      neighbor_vectors,
                      neighbor_distances,
                      epsilon,
                      sigma):

        if neighbor_indices.numel() == 0:
            return None

        r = neighbor_distances.to(self._device, dtype=self._dtype)
        r_vec = -neighbor_vectors.to(self._device, dtype=self._dtype)

        sigma_ij, epsilon_ij = self._mix_lj_params(
            neighbor_indices, epsilon, sigma
        )
        inv_r6, inv_r12 = self._lj_powers(sigma_ij, r)

        force_scalar = (
            24.0 * epsilon_ij / r *
            (2.0 * inv_r12 - inv_r6)
        )

        force_vec = force_scalar[:, None] * (r_vec / r[:, None])

        forces = torch.zeros(
            (self._n_atoms, 3), device=self._device, dtype=self._dtype
        )
        forces.index_add_(0, self._i_idx,  force_vec)
        forces.index_add_(0, self._j_idx, -force_vec)

        return forces
