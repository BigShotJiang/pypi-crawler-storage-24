"""
llm-guard-kit: Real-time reliability monitoring, failure diagnosis,
and A2A trust management for LLM agents.

Validated performance on HotpotQA (within-domain) and NQ (cross-domain):
  Behavioral AUROC:    ~0.81 within / ~0.67 cross  (exp88 5-fold CV)
  + Sonnet judge:      ~0.78 within / ~0.74 cross  (exp89/91)
  Alert precision:     0.908 at FPR ≤ 10%          (exp92 conformal)
  Mid-chain step 2:    AUROC 0.683                  (exp107)

Note: earlier versions reported AUROC 0.966–0.993, measured in-sample on
calibration data. That figure does not generalise to unseen inputs. The numbers
above are from held-out evaluation (5-fold CV or separate test sets).

Quick start
-----------
    from llm_guard import AgentGuard, LLMGuard, SmartRouter

    # --- Chain scoring + A2A handoff ---
    guard  = AgentGuard()                         # behavioral only, $0
    result = guard.score_chain(question, steps, final_answer)
    trust  = guard.generate_trust_object(question, steps, final_answer)

    # --- Query diversification when Agent A has low confidence ---
    from llm_guard import QueryRewriter
    rewriter = QueryRewriter(api_key="sk-ant-...")
    variants = rewriter.rewrite_if_needed(question, trust)

    # --- Mid-chain monitoring (inside your agent loop) ---
    step = guard.monitor_step(question, steps_so_far, current_action)
    if step.risk == "high":
        pass  # intervene early

    # --- Cost-optimal model routing ---
    router = SmartRouter(LLMGuard(api_key="sk-ant-..."))
    result = router.route("What is 15% of 240?")
    print(result.model_used)  # Haiku for easy queries, Sonnet/Opus for hard ones
"""

from qppg.guard import QPPGLLMGuard as LLMGuard
from qppg.guard import GuardResult
from llm_guard.router import SmartRouter, RouterResult
from llm_guard.agent_guard import AgentGuard, AgentStepResult, ChainTrustResult
from llm_guard.trust_object import A2ATrustObject, TemporalValidity
from llm_guard.query_rewriter import QueryRewriter, RewriteResult

__version__ = "0.6.0"
__all__ = [
    # Core guard (KNN + repair)
    "LLMGuard",
    "GuardResult",
    # Cost-optimal routing
    "SmartRouter",
    "RouterResult",
    # Agent monitoring (SC_OLD + Sonnet judge)
    "AgentGuard",
    "AgentStepResult",
    "ChainTrustResult",
    # A2A trust object
    "A2ATrustObject",
    "TemporalValidity",
    # Query diversification
    "QueryRewriter",
    "RewriteResult",
]
