# llm-checker

A simple CLI tool to check system hardware for running local LLMs.

## Usage
```
llm-checker hw-detect
```
