import platform
import psutil

def hw_detect():
    print("LLM Hardware Check\n", flush=True)

    print(f"OS: {platform.system()} {platform.release()}", flush=True)
    print(f"CPU: {platform.processor()}", flush=True)
    
    try:
        count = psutil.cpu_count(logical=True)
        print(f"Cores: {count}", flush=True)
    except Exception as e:
        print(f"Cores: Error detecting cores ({e})", flush=True)

    try:
        ram = psutil.virtual_memory().total / (1024 ** 3)
        print(f"RAM: {ram:.2f} GB", flush=True)
    except Exception as e:
        print(f"RAM: Error detecting RAM ({e})", flush=True)

    try:
        import torch
        if torch.cuda.is_available():
            try:
                print(f"GPU: {torch.cuda.get_device_name(0)}", flush=True)
            except Exception as e:
                 print(f"GPU: Error getting device name ({e})", flush=True)
        else:
            print("GPU: Not available", flush=True)
    except ImportError:
        print("GPU: torch not installed", flush=True)
    except Exception as e:
        print(f"GPU: Unexpected error ({e})", flush=True)

def main():
    import sys

    if len(sys.argv) < 2:
        print("Usage: llm-checker hw-detect", flush=True)
        return

    command = sys.argv[1]

    if command == "hw-detect":
        hw_detect()
    else:
        print("Unknown command", flush=True)

if __name__ == "__main__":
    main()
