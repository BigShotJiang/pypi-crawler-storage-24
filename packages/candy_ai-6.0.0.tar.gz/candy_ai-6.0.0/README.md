# 🍬 candy-ai v6

Client Python pour **cedric-8EF** — moteur IA multi-personnalités.  
Zéro configuration · 50 personnalités · **Helper agent** · Profils · Conversations · Batch · Streaming

---

## Installation

```bash
pip install candy-ai
```

---

## Démarrage immédiat

```python
from candy import Coding
print(Coding.ask("Write a quicksort in Python"))
```

---

## 🆕 Helper — Agent générateur de code candy

Helper connaît toute la syntaxe candy v6 et génère du code prêt à être exécuté.

```python
from candy import Helper

# Générer du code candy
code = Helper.write("un livre de 20 pages sur la Révolution française")
print(code)

# Générer ET exécuter directement
Helper.run("un script qui traduit un texte en 5 langues différentes")

# Générer avec explication
code_expliqué = Helper.explain("un chatbot de maths en boucle")
print(code_expliqué)
```

---

## Profils

```python
from candy import cfg, Coding, Math

# Manuel
cfg.A.lang         = "FR"
cfg.A.max_tokens   = 2000
cfg.A.style        = "detailed"
cfg.A.tone         = "encouraging"
cfg.A.expertise    = "beginner"

# Presets rapides
cfg.A = cfg.preset("french_beginner")
cfg.B = cfg.preset("coder")
cfg.C = cfg.preset("quick")

# Profil default
cfg.default.lang  = "FR"

# Utilisation
print(Coding.ask("Hello"))              # → default
print(Math.use("A").ask("C'est quoi pi ?"))  # → profil A
```

**Presets disponibles :**
`french_beginner` `french_expert` `english_beginner` `english_expert`
`quick` `academic` `creative` `teacher` `coder` `journalist`
`storyteller` `analyst` `coach` `debug`

---

## Tous les paramètres

| Paramètre | Défaut | Valeurs |
|-----------|--------|---------|
| `lang` | `"EN"` | `FR EN ES DE IT PT ZH JA AR RU NL PL SV TR KO HI VI ID CS RO` |
| `max_tokens` | `1024` | `100` → `4096` |
| `temperature` | `0.7` | `0.0` → `1.5` |
| `style` | `"default"` | `default concise detailed bullet academic casual technical eli5` |
| `tone` | `"neutral"` | `neutral encouraging strict humorous empathetic socratic` |
| `output_format` | `"text"` | `text markdown json html` |
| `expertise` | `"intermediate"` | `beginner intermediate expert` |
| `include_examples` | `True` | `True / False` |
| `safe_mode` | `True` | `True / False` |
| `timeout` | `120` | secondes |
| `retry` | `1` | tentatives en cas d'échec |
| `verbose` | `False` | affiche les infos de requête |

---

## Conversations multi-tours

```python
from candy import Coding

session = Coding.chat(profile="A")
print(session.say("Explique les décorateurs"))
print(session.say("Donne un exemple"))   # se souvient du contexte
session.save("chat.json")
session.show_history()
```

---

## Batch

```python
questions = ["C'est quoi X ?", "C'est quoi Y ?", "C'est quoi Z ?"]
réponses = Coding.use("A").batch(questions)
```

---

## Streaming

```python
Writing.use("A").stream_print("Écris une histoire")
```

---

## Utilitaires

```python
Coding.is_online()      # True/False
Coding.ping()           # latence ms
Coding.quota()          # quota restant
cfg.A.reset()           # remet aux défauts
cfg.list_presets()      # liste les presets
```

---

## Les 50 personnalités

`Math` `Coding` `Reflexion` `Analytic` `Full` `Science` `Writing` `History`
`Law` `Medicine` `Finance` `Marketing` `Security` `Design` `Language`
`Psychology` `Education` `Research` `Business` `Productivity` `Cooking`
`Travel` `Music` `Film` `Sports` `Philosophy` `Environment` `Architecture`
`Automotive` `Astronomy` `Biology` `Chemistry` `Physics` `Engineering`
`Entrepreneur` `Ethics` `Geopolitics` `Crypto` `AI` `DevOps` `Database`
`GameDev` `Comic` `Storyteller` `Translator` `Summarizer` `Debugger`
`Reviewer` `Planner` `Tutor`

---

Propulsé par **cedric-8EF** · Quota 500 req/jour · MIT License
