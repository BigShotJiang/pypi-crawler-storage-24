"""Prompt template management for the organize command."""

from pathlib import Path

from notulist.config import _settings_home

PROMPT_DEFAULTS: dict[str, str] = {
    "daily_summary.txt": (
        "Summarize the following notes taken today into a cohesive daily summary.\n"
        "Focus on key themes, decisions, and action items.\n"
        "Write the summary in markdown format.\n"
        "\n"
        "## Notes\n"
        "\n"
        "{notes}"
    ),
    "monthly_summary.txt": (
        "Summarize the following notes taken during this month into a cohesive"
        " monthly summary.\n"
        "Identify recurring themes, major accomplishments, and ongoing threads.\n"
        "Write the summary in markdown format.\n"
        "\n"
        "## Notes\n"
        "\n"
        "{notes}"
    ),
    "classify_notes.txt": (
        "Classify each of the following notes into one of the available projects"
        " based on content relevance.\n"
        "If a note does not clearly belong to any project, set its project_slug"
        " to null.\n"
        "\n"
        "## Available Projects\n"
        "\n"
        "{projects}\n"
        "\n"
        "## Notes\n"
        "\n"
        "{notes}"
    ),
}


def prompts_dir() -> Path:
    """
    Return the prompts directory, creating it if necessary.

    Returns
    -------
    Path
        Path to the prompts directory under the settings home.
    """
    pdir = _settings_home() / "prompts"
    pdir.mkdir(parents=True, exist_ok=True)
    return pdir


def ensure_default_prompts(force: bool = False) -> list[str]:
    """
    Create default prompt template files if they don't exist.

    Parameters
    ----------
    force : bool
        If True, overwrite existing prompt files with defaults.

    Returns
    -------
    list[str]
        List of prompt filenames that were skipped (already existed).
    """
    pdir = prompts_dir()
    skipped: list[str] = []

    for filename, content in PROMPT_DEFAULTS.items():
        filepath = pdir / filename
        if filepath.exists() and not force:
            skipped.append(filename)
            continue
        filepath.write_text(content)

    return skipped


def load_prompt(name: str) -> str:
    """
    Load a prompt template by name.

    Parameters
    ----------
    name : str
        The prompt name without extension (e.g., ``"daily_summary"``).

    Returns
    -------
    str
        The prompt template content.

    Raises
    ------
    FileNotFoundError
        If the prompt file does not exist.
    """
    filepath = prompts_dir() / f"{name}.txt"
    return filepath.read_text()
