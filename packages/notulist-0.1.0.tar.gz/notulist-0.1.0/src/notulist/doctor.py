"""Health checks for the notulist environment."""

import shutil
from pathlib import Path


def check_claude_cli() -> bool:
    """
    Check whether the ``claude`` CLI is available on PATH.

    Returns
    -------
    bool
        ``True`` if ``claude`` is found, ``False`` otherwise.
    """
    return shutil.which("claude") is not None


def check_repository(repository: str) -> bool:
    """
    Check whether the notes repository has been initialized.

    Parameters
    ----------
    repository : str
        Path to the notes repository directory.

    Returns
    -------
    bool
        ``True`` if the directory exists and contains a ``today/`` subdirectory.
    """
    repo_path = Path(repository)
    return repo_path.is_dir() and (repo_path / "today").is_dir()


def check_editor(editor: str) -> bool:
    """
    Check whether the configured editor is available.

    If *editor* is an absolute path, checks that the file exists.
    Otherwise, checks that the executable is found on PATH.

    Parameters
    ----------
    editor : str
        Editor command or absolute path.

    Returns
    -------
    bool
        ``True`` if the editor is available, ``False`` otherwise.
    """
    if Path(editor).is_absolute():
        return Path(editor).is_file()
    return shutil.which(editor) is not None
