"""Unit tests for PaymentValidator."""

import unittest
from datetime import datetime
from payment_orchestrator.core.validator import PaymentValidator


class TestPaymentValidator(unittest.TestCase):
    """Test cases for PaymentValidator class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.validator = PaymentValidator()
    
    def test_valid_payment(self):
        """Test validation of valid payment data."""
        payment_data = {
            "amount": 1999,
            "card_number": "4532015112830366",
            "expiry_month": 12,
            "expiry_year": 2027,
            "cvv": "123",
            "email": "test@example.com",
            "cardholder_name": "John Doe"
        }
        
        is_valid, error = self.validator.validate(payment_data)
        self.assertTrue(is_valid)
        self.assertIsNone(error)
    
    def test_invalid_amount_zero(self):
        """Test validation fails for zero amount."""
        payment_data = {
            "amount": 0,
            "card_number": "4532015112830366",
            "expiry_month": 12,
            "expiry_year": 2027,
            "cvv": "123",
            "email": "test@example.com",
            "cardholder_name": "John Doe"
        }
        
        is_valid, error = self.validator.validate(payment_data)
        self.assertFalse(is_valid)
        self.assertIn("Amount", error)
    
    def test_invalid_card_number(self):
        """Test validation fails for invalid card number."""
        payment_data = {
            "amount": 1999,
            "card_number": "1234567890123456",  # Invalid Luhn check
            "expiry_month": 12,
            "expiry_year": 2027,
            "cvv": "123",
            "email": "test@example.com",
            "cardholder_name": "John Doe"
        }
        
        is_valid, error = self.validator.validate(payment_data)
        self.assertFalse(is_valid)
        self.assertIn("card number", error.lower())
    
    def test_expired_card(self):
        """Test validation fails for expired card."""
        payment_data = {
            "amount": 1999,
            "card_number": "4532015112830366",
            "expiry_month": 1,
            "expiry_year": 2020,  # Expired
            "cvv": "123",
            "email": "test@example.com",
            "cardholder_name": "John Doe"
        }
        
        is_valid, error = self.validator.validate(payment_data)
        self.assertFalse(is_valid)
        self.assertIn("expir", error.lower())
    
    def test_invalid_cvv(self):
        """Test validation fails for invalid CVV."""
        payment_data = {
            "amount": 1999,
            "card_number": "4532015112830366",
            "expiry_month": 12,
            "expiry_year": 2027,
            "cvv": "12",  # Too short
            "email": "test@example.com",
            "cardholder_name": "John Doe"
        }
        
        is_valid, error = self.validator.validate(payment_data)
        self.assertFalse(is_valid)
        self.assertIn("CVV", error)
    
    def test_invalid_email(self):
        """Test validation fails for invalid email."""
        payment_data = {
            "amount": 1999,
            "card_number": "4532015112830366",
            "expiry_month": 12,
            "expiry_year": 2027,
            "cvv": "123",
            "email": "invalid-email",
            "cardholder_name": "John Doe"
        }
        
        is_valid, error = self.validator.validate(payment_data)
        self.assertFalse(is_valid)
        self.assertIn("email", error.lower())


if __name__ == "__main__":
    unittest.main()
