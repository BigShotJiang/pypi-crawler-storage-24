"""Unit tests for FraudDetector."""

import unittest
from payment_orchestrator.core.fraud_detector import FraudDetector


class TestFraudDetector(unittest.TestCase):
    """Test cases for FraudDetector class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.detector = FraudDetector(high_amount_threshold=1000000)
    
    def test_normal_payment(self):
        """Test normal payment passes fraud check."""
        payment_data = {
            "amount": 5000,
            "email": "test@example.com",
            "card_number": "4532015112830366"
        }
        
        is_fraud, reason = self.detector.check_fraud(payment_data)
        self.assertFalse(is_fraud)
        self.assertIsNone(reason)
    
    def test_high_amount_fraud(self):
        """Test high amount triggers fraud detection."""
        payment_data = {
            "amount": 1500000,  # $15,000
            "email": "test@example.com",
            "card_number": "4532015112830366"
        }
        
        is_fraud, reason = self.detector.check_fraud(payment_data)
        self.assertTrue(is_fraud)
        self.assertIn("threshold", reason.lower())
    
    def test_suspicious_card_pattern(self):
        """Test suspicious card pattern detection."""
        payment_data = {
            "amount": 5000,
            "email": "test@example.com",
            "card_number": "1111111111111111"  # All same digits
        }
        
        is_fraud, reason = self.detector.check_fraud(payment_data)
        self.assertTrue(is_fraud)
        self.assertIn("pattern", reason.lower())
    
    def test_velocity_check(self):
        """Test velocity check for multiple transactions."""
        email = "velocity@example.com"
        
        # Simulate 6 transactions quickly
        for i in range(6):
            payment_data = {
                "amount": 1000,
                "email": email,
                "card_number": "4532015112830366"
            }
            is_fraud, reason = self.detector.check_fraud(payment_data)
            
            if i < 5:
                self.assertFalse(is_fraud)
            else:
                # 6th transaction should trigger velocity check
                self.assertTrue(is_fraud)
                self.assertIn("velocity", reason.lower())


if __name__ == "__main__":
    unittest.main()
