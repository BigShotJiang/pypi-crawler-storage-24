"""Mock payment processor."""

import logging
from typing import Tuple
import time

logger = logging.getLogger(__name__)


class PaymentProcessor:
    """
    Mock payment processor for simulating payment gateway interactions.
    
    This class simulates a real payment processor. In production, this would
    integrate with Stripe, PayPal, or other payment gateways.
    """
    
    def __init__(self, api_key: str):
        """
        Initialize the PaymentProcessor.
        
        Args:
            api_key: Payment processor API key
        """
        self.api_key = api_key
        logger.info("PaymentProcessor initialized")
    
    def process(self, card_number: str, cvv: str, amount: int, 
               currency: str, cardholder_name: str) -> Tuple[bool, str]:
        """
        Process payment transaction (mock implementation).
        
        Mock logic: Amounts ending in 0 fail, all others succeed.
        
        Args:
            card_number: Decrypted card number
            cvv: Decrypted CVV
            amount: Payment amount in cents
            currency: Currency code
            cardholder_name: Name on card
            
        Returns:
            Tuple of (success, message)
        """
        logger.info(f"Processing payment: {amount} {currency} for {cardholder_name}")
        
        # Simulate processing delay
        time.sleep(0.1)
        
        # Mock logic: amounts ending in 0 fail
        if amount % 10 == 0:
            error_msg = "Payment declined by processor (insufficient funds)"
            logger.warning(f"Payment failed: {error_msg}")
            return False, error_msg
        
        success_msg = f"Payment approved - Authorization code: AUTH{amount}{int(time.time())}"
        logger.info(f"Payment succeeded: {success_msg}")
        return True, success_msg
