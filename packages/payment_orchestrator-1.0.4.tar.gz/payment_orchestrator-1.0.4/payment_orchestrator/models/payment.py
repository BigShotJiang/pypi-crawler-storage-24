from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class Payment:
    cardholder_name: str
    card_number: str
    expiry_month: int
    expiry_year: int
    cvv: str
    amount: int
    currency: str
    email: str
    transaction_id: Optional[str] = None
    timestamp: Optional[str] = None
    
    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()
    
    def get_masked_card(self) -> str:
        if len(self.card_number) >= 4:
            return "*" * (len(self.card_number) - 4) + self.card_number[-4:]
        return "****"
    
    def to_dict(self) -> dict:
        return {
            "cardholder_name": self.cardholder_name,
            "card_number": self.card_number,
            "expiry_month": self.expiry_month,
            "expiry_year": self.expiry_year,
            "cvv": self.cvv,
            "amount": self.amount,
            "currency": self.currency,
            "email": self.email,
            "transaction_id": self.transaction_id,
            "timestamp": self.timestamp
        }
