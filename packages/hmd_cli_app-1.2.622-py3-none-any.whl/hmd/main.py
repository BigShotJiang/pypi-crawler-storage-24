from cement import App, TestApp, init_defaults
from cement.core.exc import CaughtSignal
from .core.exc import HmdAppError
from .controllers.base import Base
from .controllers.ai import AIController

import pkgutil
import importlib
import sys

# Use importlib.metadata for Python 3.10+, backport for earlier versions
if sys.version_info < (3, 10):
    from importlib_metadata import entry_points
else:
    from importlib.metadata import entry_points

HANDLER_ENTRY_POINT = "hmd_cli.controllers"

# configuration defaults
CONFIG = init_defaults("hmd", "github", "docker")


class HmdApp(App):
    """hmd Command-line Interface primary application."""

    class Meta:
        label = "hmd"

        # configuration defaults
        config_defaults = CONFIG

        # call sys.exit() on close
        exit_on_close = True

        # load additional framework extensions
        extensions = ["yaml", "colorlog", "jinja2"]

        # configuration handler
        config_handler = "yaml"

        # configuration file suffix
        config_file_suffix = ".yml"

        # set the log handler
        log_handler = "colorlog"

        # set the output handler
        output_handler = "jinja2"

        # handlers are registered in main()


class HmdAppTest(TestApp, HmdApp):
    """A sub-class of HmdApp that is better suited for testing."""

    class Meta:
        label = "hmd"
        handlers = [Base]


def _discover_entrypoint_handlers():
    """Discover handlers registered via entry points."""
    handlers = []
    eps = entry_points(group=HANDLER_ENTRY_POINT)
    for ep in eps:
        try:
            handler = ep.load()
            handlers.append(handler)
        except Exception:
            pass
    return handlers


def _discover_pkgutil_handlers():
    """Discover handlers from hmd_cli_* packages (legacy method)."""
    handlers = []
    for _, name, _ in pkgutil.iter_modules():
        if name.startswith("hmd_cli"):
            try:
                module = importlib.import_module(f"{name}.controller")
                module_controllers = filter(
                    lambda x: x != "Controller" and x.endswith("Controller"),
                    dir(module),
                )
                for module_controller in module_controllers:
                    handlers.append(getattr(module, module_controller))
            except ModuleNotFoundError:
                pass
    return handlers


def main():
    handlers = [Base, AIController]

    # Entry point-based discovery (preferred for new handlers)
    handlers.extend(_discover_entrypoint_handlers())

    # pkgutil-based discovery (backwards compatibility for hmd_cli_* packages)
    pkgutil_handlers = _discover_pkgutil_handlers()

    # Deduplicate - avoid adding handlers already discovered via entry points
    existing = set(handlers)
    for h in pkgutil_handlers:
        if h not in existing:
            handlers.append(h)

    with HmdApp(**{"handlers": handlers}) as app:
        try:
            app.run()

        except AssertionError as e:
            print("AssertionError > %s" % e.args[0])
            app.exit_code = 1

            if app.debug is True:
                import traceback

                traceback.print_exc()

        except HmdAppError as e:
            print("HmdAppError > %s" % e.args[0])
            app.exit_code = 1

            if app.debug is True:
                import traceback

                traceback.print_exc()

        except CaughtSignal as e:
            # Default Cement signals are SIGINT and SIGTERM, exit 0 (non-error)
            print("\n%s" % e)
            app.exit_code = 0

        except Exception as e:
            print(f"Error: {e.args[0]}")
            app.exit_code = 1

            if app.debug is True:
                import traceback

                traceback.print_exc()


if __name__ == "__main__":
    main()
