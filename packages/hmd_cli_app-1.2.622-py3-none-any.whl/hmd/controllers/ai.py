"""AI controller for managing AI components (commands, skills, agents) across all handlers."""

import importlib
import os
import pkgutil
import shutil
from pathlib import Path

from cement import Controller, ex

# Destination mappings by tool and component type
DESTINATIONS = {
    "claude": {
        "commands": "~/.claude/commands/",
        "skills": "~/.claude/commands/",
        "agents": "~/.claude/agents/",
    },
    "cursor": {
        "commands": ".cursor/rules/",
        "skills": ".cursor/rules/",
        "agents": ".cursor/rules/",
    },
    "continue": {
        "commands": "~/.continue/prompts/",
        "skills": "~/.continue/prompts/",
        "agents": "~/.continue/prompts/",
    },
    "aider": {
        "commands": "~/.aider/prompts/",
        "skills": "~/.aider/prompts/",
        "agents": "~/.aider/prompts/",
    },
}

COMPONENT_TYPES = ["commands", "skills", "agents"]
DESTINATION_CHOICES = ["claude", "cursor", "continue", "aider"]


class AIController(Controller):
    """Controller for managing AI components across installed hmd_cli handlers."""

    class Meta:
        label = "ai"

        stacked_type = "nested"
        stacked_on = "base"

        description = "Manage AI components (commands, skills, agents) for coding tools"

        arguments = ()

    def _default(self):
        """Default action if no sub-command is passed."""
        self.app.args.print_help()

    def _discover_ai_loaders(self):
        """Discover AILoader or SkillsLoader from all hmd_cli_* handlers.

        Returns:
            dict: Mapping of handler name to loader instance and type
        """
        loaders = {}
        for _, name, _ in pkgutil.iter_modules():
            if name.startswith("hmd_cli"):
                # Try new AILoader first
                try:
                    module = importlib.import_module(f"{name}.loaders.ai_loader")
                    if hasattr(module, "AILoader"):
                        loaders[name] = {"loader": module.AILoader(), "type": "ai"}
                        continue
                except ModuleNotFoundError:
                    pass

                # Fallback to legacy SkillsLoader
                try:
                    module = importlib.import_module(f"{name}.loaders.skills_loader")
                    if hasattr(module, "SkillsLoader"):
                        loaders[name] = {
                            "loader": module.SkillsLoader(),
                            "type": "skills",
                        }
                except ModuleNotFoundError:
                    pass
        return loaders

    def _get_components(self, loader_info, component_type):
        """Get components of a specific type from a loader.

        Args:
            loader_info: Dict with 'loader' and 'type' keys
            component_type: One of 'commands', 'skills', 'agents'

        Returns:
            list: List of component dicts
        """
        loader = loader_info["loader"]
        loader_type = loader_info["type"]

        if loader_type == "ai":
            # New AILoader with type-specific methods
            method_name = f"list_{component_type}"
            if hasattr(loader, method_name):
                method = getattr(loader, method_name)
                return method()
            return []
        else:
            # Legacy SkillsLoader - only supports skills
            if component_type == "skills" and hasattr(loader, "list_skills"):
                return loader.list_skills()
            return []

    def _resolve_destination(self, dest, component_type):
        """Resolve a named destination to a path.

        Args:
            dest: Destination name (claude, cursor, continue, aider)
            component_type: Component type (commands, skills, agents)

        Returns:
            Path: Resolved path
        """
        if dest not in DESTINATIONS:
            raise ValueError(f"Unknown destination: {dest}")

        path_str = DESTINATIONS[dest].get(component_type)
        if not path_str:
            raise ValueError(f"No path configured for {dest}/{component_type}")

        # Handle project-relative paths (cursor)
        if not path_str.startswith("~"):
            return Path.cwd() / path_str

        return Path(path_str).expanduser()

    @ex(
        help="list available AI components from all installed handlers",
        arguments=[
            (
                ["--type"],
                {
                    "action": "store",
                    "dest": "component_type",
                    "required": False,
                    "choices": COMPONENT_TYPES,
                    "help": "Filter by component type (commands, skills, agents)",
                },
            ),
            (
                ["--handler"],
                {
                    "action": "store",
                    "dest": "handler",
                    "required": False,
                    "help": "Filter to a specific handler (e.g., hmd_cli_repo)",
                },
            ),
            (
                ["--json"],
                {
                    "action": "store_true",
                    "dest": "json_output",
                    "required": False,
                    "help": "Output in JSON format",
                },
            ),
        ],
    )
    def list(self):
        """List available AI components from all installed handlers."""
        import json

        loaders = self._discover_ai_loaders()
        filter_handler = self.app.pargs.handler
        filter_type = self.app.pargs.component_type
        json_output = self.app.pargs.json_output

        # Determine which types to list
        types_to_list = [filter_type] if filter_type else COMPONENT_TYPES

        all_components = {}
        total_count = 0

        for handler_name, loader_info in sorted(loaders.items()):
            if filter_handler and handler_name != filter_handler:
                continue

            handler_components = {}

            for comp_type in types_to_list:
                try:
                    components = self._get_components(loader_info, comp_type)
                    if components:
                        handler_components[comp_type] = components
                        total_count += len(components)
                except Exception as e:
                    if not json_output:
                        print(f"Error listing {comp_type} from {handler_name}: {e}")

            if handler_components:
                all_components[handler_name] = handler_components

        if json_output:
            # Clean output - remove internal fields
            clean_output = {}
            for handler_name, type_components in all_components.items():
                clean_output[handler_name] = {}
                for comp_type, components in type_components.items():
                    clean_output[handler_name][comp_type] = [
                        {k: v for k, v in c.items() if not k.startswith("_")}
                        for c in components
                    ]
            print(json.dumps(clean_output, indent=2))
        else:
            if not all_components:
                print("No AI components found in installed handlers.")
                return

            for handler_name, type_components in all_components.items():
                print(f"\n{handler_name}:")
                print("-" * (len(handler_name) + 1))
                for comp_type, components in type_components.items():
                    print(f"  [{comp_type}]")
                    for component in components:
                        name = component.get("name", "unnamed")
                        desc = component.get("description", "No description")
                        version = component.get("version", "")
                        version_str = f" (v{version})" if version else ""
                        print(f"    - {name}{version_str}: {desc}")

            handler_count = len(all_components)
            print(
                f"\nTotal: {total_count} component(s) from {handler_count} handler(s)"
            )

    @ex(
        help="install AI components from handlers into a target directory",
        arguments=[
            (
                ["--type"],
                {
                    "action": "store",
                    "dest": "component_type",
                    "required": False,
                    "choices": COMPONENT_TYPES,
                    "help": "Component type to install (commands, skills, agents)",
                },
            ),
            (
                ["-d", "--directory"],
                {
                    "action": "store",
                    "dest": "directory",
                    "required": False,
                    "help": "Target directory to install components into",
                },
            ),
            (
                ["--dest"],
                {
                    "action": "store",
                    "dest": "destination",
                    "required": False,
                    "choices": DESTINATION_CHOICES,
                    "help": "Named destination (claude, cursor, continue, aider)",
                },
            ),
            (
                ["--handler"],
                {
                    "action": "store",
                    "dest": "handler",
                    "required": False,
                    "help": "Install components from a specific handler only",
                },
            ),
            (
                ["--name", "-n"],
                {
                    "action": "store",
                    "dest": "component_name",
                    "required": False,
                    "help": "Install a specific component by name",
                },
            ),
            (
                ["--force", "-f"],
                {
                    "action": "store_true",
                    "dest": "force",
                    "required": False,
                    "help": "Overwrite existing files",
                },
            ),
            (
                ["--list-destinations"],
                {
                    "action": "store_true",
                    "dest": "list_destinations",
                    "required": False,
                    "help": "Show available installation destinations",
                },
            ),
        ],
    )
    def install(self):
        """Install AI components from handlers into a target directory."""
        # Show destinations if requested
        if self.app.pargs.list_destinations:
            home = os.path.expanduser("~")
            print("Destinations for AI tools:\n")
            for tool, types in DESTINATIONS.items():
                print(f"  {tool}:")
                for comp_type, path in types.items():
                    display_path = (
                        path.replace("~", home)
                        if path.startswith("~")
                        else f"{path} (project-relative)"
                    )
                    print(f"    {comp_type:10} {display_path}")
                print()
            return

        directory = self.app.pargs.directory
        destination = self.app.pargs.destination
        component_type = self.app.pargs.component_type

        # Validate that we have a target
        if not directory and not destination:
            print("Error: destination required")
            print("Usage: hmd ai install --type TYPE (-d <directory> | --dest <tool>)")
            print("       hmd ai install --list-destinations")
            return

        # Can't use both -d and --dest
        if directory and destination:
            print("Error: cannot use both -d and --dest")
            return

        # Resolve the target path
        if destination:
            if not component_type:
                print("Error: --type is required when using --dest")
                return
            try:
                dest_path = self._resolve_destination(destination, component_type)
            except ValueError as e:
                print(f"Error: {e}")
                return
        else:
            dest_path = Path(directory).expanduser().resolve()

        # Determine which types to install
        types_to_install = [component_type] if component_type else COMPONENT_TYPES

        loaders = self._discover_ai_loaders()
        filter_handler = self.app.pargs.handler
        filter_name = self.app.pargs.component_name
        force = self.app.pargs.force

        # Create target directory if it doesn't exist
        if not dest_path.exists():
            dest_path.mkdir(parents=True, exist_ok=True)
            print(f"Created directory: {dest_path}")

        total_installed = 0
        total_skipped = 0

        for handler_name, loader_info in sorted(loaders.items()):
            if filter_handler and handler_name != filter_handler:
                continue

            for comp_type in types_to_install:
                try:
                    components = self._get_components(loader_info, comp_type)
                    if not components:
                        continue

                    for component in components:
                        comp_name = component.get("name", "")
                        comp_file = component.get("_file")

                        if not comp_file:
                            continue

                        # Filter by name if specified
                        if filter_name and comp_name != filter_name:
                            continue

                        comp_path = Path(comp_file)

                        # Handle directory-based components (e.g., skills/skill-name/SKILL.md)
                        # vs file-based components (e.g., skills/skill-name.md)
                        if comp_path.name.upper() in ("SKILL.MD", "AGENT.MD"):
                            # Directory-based: preserve subdirectory structure
                            subdir_name = comp_path.parent.name
                            dest_subdir = dest_path / subdir_name
                            dest_subdir.mkdir(parents=True, exist_ok=True)
                            dest_file = dest_subdir / comp_path.name
                            display_name = f"{subdir_name}/{comp_path.name}"
                        else:
                            # File-based: copy directly to dest_path
                            dest_file = dest_path / comp_path.name
                            display_name = comp_path.name

                        if dest_file.exists() and not force:
                            print(f"Skipped (exists): {display_name}")
                            total_skipped += 1
                            continue

                        shutil.copy2(comp_path, dest_file)
                        print(
                            f"Installed: {display_name} [{comp_type}] (from {handler_name})"
                        )
                        total_installed += 1

                except Exception as e:
                    print(f"Error installing {comp_type} from {handler_name}: {e}")

        print(f"\nInstalled {total_installed} component(s), skipped {total_skipped}")
        if total_skipped > 0:
            print("Use --force to overwrite existing files")
        if total_installed > 0:
            print(f"Components installed to: {dest_path}")
