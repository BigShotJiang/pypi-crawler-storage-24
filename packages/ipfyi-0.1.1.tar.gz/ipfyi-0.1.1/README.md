# ipfyi

[![PyPI version](https://agentgif.com/badge/pypi/ipfyi/version.svg)](https://pypi.org/project/ipfyi/)
[![Python](https://img.shields.io/pypi/pyversions/ipfyi)](https://pypi.org/project/ipfyi/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Zero Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)](https://pypi.org/project/ipfyi/)

Python API client for IP address and network data. Look up IP geolocation, query ASN (Autonomous System Number) ownership, explore CIDR ranges, and retrieve BGP routing information — all from [IPFYI](https://ipfyi.com/), an IP intelligence platform for network engineers and security analysts.

IPFYI provides structured access to IP geolocation databases, ASN-to-organization mappings, prefix announcements, and network relationships — covering both IPv4 and IPv6 address spaces used by network operators, cybersecurity teams, and compliance platforms.

> **Look up IP addresses at [ipfyi.com](https://ipfyi.com/)** — check [geolocation](https://ipfyi.com/lookup/), browse [ASNs](https://ipfyi.com/asns/), and explore network data.

<p align="center">
  <img src="https://raw.githubusercontent.com/fyipedia/ipfyi/main/demo.gif" alt="ipfyi demo — IP geolocation, ASN lookup, and CIDR range analysis in Python" width="800">
</p>

## Table of Contents

- [Install](#install)
- [Quick Start](#quick-start)
- [What You Can Do](#what-you-can-do)
  - [IPv4 and IPv6 Address Spaces](#ipv4-and-ipv6-address-spaces)
  - [ASN and BGP Routing](#asn-and-bgp-routing)
  - [IP Geolocation](#ip-geolocation)
  - [CIDR Notation and Subnetting](#cidr-notation-and-subnetting)
- [Command-Line Interface](#command-line-interface)
- [MCP Server (Claude, Cursor, Windsurf)](#mcp-server-claude-cursor-windsurf)
- [REST API Client](#rest-api-client)
- [API Reference](#api-reference)
- [Learn More About IP](#learn-more-about-ip)
- [Also Available](#also-available)
- [Network FYI Family](#network-fyi-family)
- [License](#license)

## Install

```bash
pip install ipfyi                # Core (zero deps)
pip install "ipfyi[cli]"         # + Command-line interface
pip install "ipfyi[mcp]"         # + MCP server for AI assistants
pip install "ipfyi[api]"         # + HTTP client for ipfyi.com API
pip install "ipfyi[all]"         # Everything
```

## Quick Start

```python
from ipfyi.api import IPFYI

with IPFYI() as api:
    # Look up an IP address
    info = api.lookup("8.8.8.8")
    print(info["ip"])              # 8.8.8.8
    print(info["asn"])             # AS15169
    print(info["organization"])    # Google LLC
    print(info["country"])         # United States

    # Get ASN details
    asn = api.get_asn("AS15169")
    print(asn["name"])             # GOOGLE
    print(asn["prefix_count"])     # Announced prefixes

    # Search network data
    results = api.search("cloudflare")
```

## What You Can Do

### IPv4 and IPv6 Address Spaces

The Internet Protocol uses two addressing schemes. IPv4 (32-bit, ~4.3 billion addresses) is nearly exhausted — IANA allocated the last /8 blocks in 2011. IPv6 (128-bit, 3.4 x 10^38 addresses) provides virtually unlimited address space but adoption varies by region.

| Protocol | Address Size | Format | Total Addresses |
|----------|-------------|--------|-----------------|
| IPv4 | 32 bits | 192.168.1.1 | 4.3 billion |
| IPv6 | 128 bits | 2001:db8::1 | 3.4 x 10^38 |

| IPv4 Class | Range | Default Mask | Purpose |
|-----------|-------|-------------|---------|
| A | 1.0.0.0 - 126.255.255.255 | /8 | Large networks |
| B | 128.0.0.0 - 191.255.255.255 | /16 | Medium networks |
| C | 192.0.0.0 - 223.255.255.255 | /24 | Small networks |
| Private | 10.0.0.0, 172.16.0.0, 192.168.0.0 | Various | Internal use (RFC 1918) |

```python
from ipfyi.api import IPFYI

with IPFYI() as api:
    # Look up any IPv4 or IPv6 address
    v4 = api.lookup("1.1.1.1")
    print(f"IPv4: {v4['organization']}")  # Cloudflare

    v6 = api.lookup("2606:4700:4700::1111")
    print(f"IPv6: {v6['organization']}")  # Cloudflare
```

Learn more: [IP Lookup](https://ipfyi.com/lookup/) · [Glossary](https://ipfyi.com/glossary/)

### ASN and BGP Routing

An Autonomous System (AS) is a network under a single administrative domain, identified by a unique ASN. The Border Gateway Protocol (BGP) connects these autonomous systems, forming the routing fabric of the internet. Each AS announces its IP prefixes to peers, creating the global routing table.

| AS Type | Purpose | Examples |
|---------|---------|---------|
| Stub | Single-homed end network | Small ISPs, enterprises |
| Multi-homed | Multiple upstream providers | Medium enterprises, CDNs |
| Transit | Carries traffic for other ASes | Tier 1/2 ISPs |
| Internet Exchange | Peering point | DE-CIX, AMS-IX, LINX |

```python
from ipfyi.api import IPFYI

with IPFYI() as api:
    # Look up ASN details
    asn = api.get_asn("AS13335")
    print(f"Name: {asn['name']}")              # CLOUDFLARENET
    print(f"Organization: {asn['organization']}") # Cloudflare, Inc.
    print(f"Prefixes: {asn.get('prefix_count')}")

    # List ASNs by country
    asns = api.list_asns(country="united-states")
```

Learn more: [ASN Directory](https://ipfyi.com/asns/) · [Guides](https://ipfyi.com/guides/)

### IP Geolocation

IP geolocation maps an IP address to a physical location using a combination of RIR (Regional Internet Registry) allocation data, BGP routing tables, and active measurement. Accuracy varies — city-level is typically 50-80% accurate, country-level exceeds 99%.

| Accuracy Level | Typical Accuracy | Use Case |
|---------------|-----------------|----------|
| Country | 99%+ | Compliance, content licensing |
| Region/State | 80-90% | Regional content delivery |
| City | 50-80% | Local advertising, analytics |
| Postal code | 20-50% | Approximate location only |

```python
from ipfyi.api import IPFYI

with IPFYI() as api:
    # Geolocation data for an IP
    info = api.lookup("8.8.8.8")
    print(f"Country: {info['country']}")
    print(f"Region: {info.get('region')}")
    print(f"City: {info.get('city')}")
    print(f"Latitude: {info.get('latitude')}")
    print(f"Longitude: {info.get('longitude')}")
```

Learn more: [IP Geolocation](https://ipfyi.com/lookup/) · [Glossary](https://ipfyi.com/glossary/)

### CIDR Notation and Subnetting

CIDR (Classless Inter-Domain Routing) replaced classful addressing, allowing variable-length subnet masks. The notation IP/prefix (e.g., 10.0.0.0/8) specifies a network range. Understanding CIDR is fundamental for network planning, firewall rules, and IP allocation.

| CIDR | Subnet Mask | Hosts | Common Use |
|------|------------|-------|-----------|
| /8 | 255.0.0.0 | 16.7M | Large ISP allocation |
| /16 | 255.255.0.0 | 65,534 | Enterprise network |
| /24 | 255.255.255.0 | 254 | Small office/home |
| /32 | 255.255.255.255 | 1 | Single host route |

```python
from ipfyi.api import IPFYI

with IPFYI() as api:
    # Search for prefixes
    results = api.search("10.0.0.0/8")
    for r in results:
        print(f"{r['prefix']}: {r.get('organization')}")
```

Learn more: [CIDR Calculator](https://ipfyi.com/guides/) · [API Documentation](https://ipfyi.com/developers/)

## Command-Line Interface

```bash
pip install "ipfyi[cli]"

ipfyi lookup 8.8.8.8                       # IP geolocation
ipfyi asn AS15169                          # ASN details
ipfyi search "amazon"                      # Search networks
ipfyi my-ip                                # Your public IP info
```

## MCP Server (Claude, Cursor, Windsurf)

```bash
pip install "ipfyi[mcp]"
```

```json
{
    "mcpServers": {
        "ipfyi": {
            "command": "uvx",
            "args": ["--from", "ipfyi[mcp]", "python", "-m", "ipfyi.mcp_server"]
        }
    }
}
```

## REST API Client

```python
from ipfyi.api import IPFYI

with IPFYI() as api:
    info = api.lookup("8.8.8.8")             # GET /api/v1/lookup/8.8.8.8/
    asn = api.get_asn("AS15169")             # GET /api/v1/asns/AS15169/
    asns = api.list_asns(country="us")        # GET /api/v1/asns/?country=us
    results = api.search("cloudflare")       # GET /api/v1/search/?q=cloudflare
```

### Example

```bash
curl -s "https://ipfyi.com/api/v1/lookup/8.8.8.8/"
```

```json
{
    "ip": "8.8.8.8",
    "asn": "AS15169",
    "organization": "Google LLC",
    "country": "United States",
    "city": "Mountain View"
}
```

Full API documentation at [ipfyi.com/developers/](https://ipfyi.com/developers/).

## API Reference

| Function | Description |
|----------|-------------|
| `api.lookup(ip)` | IP geolocation and ASN info |
| `api.get_asn(asn)` | ASN details (organization, prefixes) |
| `api.list_asns(country)` | List ASNs, optionally by country |
| `api.search(query)` | Search IPs, ASNs, and organizations |

## Learn More About IP

- **Browse**: [IP Lookup](https://ipfyi.com/lookup/) · [ASN Directory](https://ipfyi.com/asns/)
- **Guides**: [Networking Guides](https://ipfyi.com/guides/) · [Glossary](https://ipfyi.com/glossary/)
- **API**: [REST API Docs](https://ipfyi.com/developers/) · [OpenAPI Spec](https://ipfyi.com/api/openapi.json)

## Also Available

| Platform | Install | Link |
|----------|---------|------|
| **npm** | `npm install ipfyi` | [npm](https://www.npmjs.com/package/ipfyi) |
| **MCP** | `uvx --from "ipfyi[mcp]" python -m ipfyi.mcp_server` | [Config](#mcp-server-claude-cursor-windsurf) |

## Network FYI Family

Part of the [FYIPedia](https://fyipedia.com) open-source developer tools ecosystem — internet infrastructure, cables, domains, and protocols.

| Package | PyPI | npm | Description |
|---------|------|-----|-------------|
| cablefyi | [PyPI](https://pypi.org/project/cablefyi/) | [npm](https://www.npmjs.com/package/cablefyi) | Submarine cables, landing points, operators — [cablefyi.com](https://cablefyi.com/) |
| tldfyi | [PyPI](https://pypi.org/project/tldfyi/) | [npm](https://www.npmjs.com/package/tldfyi) | TLD registry, domain extensions, WHOIS — [tldfyi.com](https://tldfyi.com/) |
| **ipfyi** | [PyPI](https://pypi.org/project/ipfyi/) | [npm](https://www.npmjs.com/package/ipfyi) | **IP geolocation, ASN lookup, CIDR ranges — [ipfyi.com](https://ipfyi.com/)** |
| protocolcodes | [PyPI](https://pypi.org/project/protocolcodes/) | [npm](https://www.npmjs.com/package/protocolcodes) | HTTP status codes, protocol references — [statuscodefyi.com](https://statuscodefyi.com/) |

## License

MIT
