"""HTTP API client for ipfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install ipfyi[api]``

Usage::

    from ipfyi.api import IPFYI

    with IPFYI() as api:
        items = api.list_asns()
        detail = api.get_asn("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class IPFYI:
    """API client for the ipfyi.com REST API.

    Provides typed access to all ipfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://ipfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://ipfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_asns(self, **params: Any) -> dict[str, Any]:
        """List all asns."""
        return self._get("/api/v1/rest/asns/", **params)

    def get_asn(self, slug: str) -> dict[str, Any]:
        """Get asn by slug."""
        return self._get(f"/api/v1/rest/asns/" + slug + "/")

    def list_cities(self, **params: Any) -> dict[str, Any]:
        """List all cities."""
        return self._get("/api/v1/rest/cities/", **params)

    def get_city(self, slug: str) -> dict[str, Any]:
        """Get city by slug."""
        return self._get(f"/api/v1/rest/cities/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/rest/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/rest/faqs/" + slug + "/")

    def list_glossary_categories(self, **params: Any) -> dict[str, Any]:
        """List all glossary categories."""
        return self._get("/api/v1/rest/glossary-categories/", **params)

    def get_glossary_category(self, slug: str) -> dict[str, Any]:
        """Get glossary category by slug."""
        return self._get(f"/api/v1/rest/glossary-categories/" + slug + "/")

    def list_glossary_terms(self, **params: Any) -> dict[str, Any]:
        """List all glossary terms."""
        return self._get("/api/v1/rest/glossary-terms/", **params)

    def get_glossary_term(self, slug: str) -> dict[str, Any]:
        """Get glossary term by slug."""
        return self._get(f"/api/v1/rest/glossary-terms/" + slug + "/")

    def list_ip_ranges(self, **params: Any) -> dict[str, Any]:
        """List all ip ranges."""
        return self._get("/api/v1/rest/ip-ranges/", **params)

    def get_ip_range(self, slug: str) -> dict[str, Any]:
        """Get ip range by slug."""
        return self._get(f"/api/v1/rest/ip-ranges/" + slug + "/")

    def list_isps(self, **params: Any) -> dict[str, Any]:
        """List all isps."""
        return self._get("/api/v1/rest/isps/", **params)

    def get_isp(self, slug: str) -> dict[str, Any]:
        """Get isp by slug."""
        return self._get(f"/api/v1/rest/isps/" + slug + "/")

    def list_threats(self, **params: Any) -> dict[str, Any]:
        """List all threats."""
        return self._get("/api/v1/rest/threats/", **params)

    def get_threat(self, slug: str) -> dict[str, Any]:
        """Get threat by slug."""
        return self._get(f"/api/v1/rest/threats/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/rest/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> IPFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
