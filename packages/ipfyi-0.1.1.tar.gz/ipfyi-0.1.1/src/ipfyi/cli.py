"""Command-line interface for ipfyi."""

from __future__ import annotations

import json

import typer

from ipfyi.api import IPFYI

app = typer.Typer(help="IPFYI — IP geolocation and ASN lookup API client.")


@app.command()
def search(query: str) -> None:
    """Search ipfyi.com."""
    with IPFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
