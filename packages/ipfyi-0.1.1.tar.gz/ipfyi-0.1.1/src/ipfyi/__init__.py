"""Python API client for ipfyi.com."""

__version__ = "0.1.0"
