"""MCP server for ipfyi — AI assistant tools for ipfyi.com.

Run: uvx --from "ipfyi[mcp]" python -m ipfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("IPFYI")


@mcp.tool()
def list_asns(limit: int = 20, offset: int = 0) -> str:
    """List asns from ipfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from ipfyi.api import IPFYI

    with IPFYI() as api:
        data = api.list_asns(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No asns found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_asn(slug: str) -> str:
    """Get detailed information about a specific asn.

    Args:
        slug: URL slug identifier for the asn.
    """
    from ipfyi.api import IPFYI

    with IPFYI() as api:
        data = api.get_asn(slug)
        return str(data)


@mcp.tool()
def list_isps(limit: int = 20, offset: int = 0) -> str:
    """List isps from ipfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from ipfyi.api import IPFYI

    with IPFYI() as api:
        data = api.list_isps(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No isps found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_ip(query: str) -> str:
    """Search ipfyi.com for ASNs, IP ranges, ISPs, and geolocation.

    Args:
        query: Search query string.
    """
    from ipfyi.api import IPFYI

    with IPFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
