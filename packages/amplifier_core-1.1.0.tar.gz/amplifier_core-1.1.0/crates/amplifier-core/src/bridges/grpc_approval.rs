//! gRPC bridge for remote approval modules.
//!
//! [`GrpcApprovalBridge`] wraps an [`ApprovalServiceClient`] (gRPC) and
//! implements the native [`ApprovalProvider`] trait, making a remote approval
//! provider indistinguishable from a local one.
//!
//! # Usage
//!
//! ```rust,no_run
//! # async fn example() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
//! use amplifier_core::bridges::grpc_approval::GrpcApprovalBridge;
//! use amplifier_core::traits::ApprovalProvider;
//! use std::sync::Arc;
//!
//! let bridge = GrpcApprovalBridge::connect("http://localhost:50051").await?;
//! let approval: Arc<dyn ApprovalProvider> = Arc::new(bridge);
//! # Ok(())
//! # }
//! ```

use std::future::Future;
use std::pin::Pin;

use tonic::transport::Channel;

use crate::errors::{AmplifierError, SessionError};
use crate::generated::amplifier_module;
use crate::generated::amplifier_module::approval_service_client::ApprovalServiceClient;
use crate::models::{ApprovalRequest, ApprovalResponse};
use crate::traits::ApprovalProvider;

/// A bridge that wraps a remote gRPC `ApprovalService` as a native [`ApprovalProvider`].
///
/// The client is held behind a [`tokio::sync::Mutex`] because
/// `ApprovalServiceClient` methods take `&mut self` and we need to hold
/// the lock across `.await` points.
pub struct GrpcApprovalBridge {
    client: tokio::sync::Mutex<ApprovalServiceClient<Channel>>,
}

impl GrpcApprovalBridge {
    /// Connect to a remote approval service.
    pub async fn connect(endpoint: &str) -> Result<Self, Box<dyn std::error::Error + Send + Sync>> {
        let client = ApprovalServiceClient::connect(endpoint.to_string()).await?;

        Ok(Self {
            client: tokio::sync::Mutex::new(client),
        })
    }
}

impl ApprovalProvider for GrpcApprovalBridge {
    fn request_approval(
        &self,
        request: ApprovalRequest,
    ) -> Pin<Box<dyn Future<Output = Result<ApprovalResponse, AmplifierError>> + Send + '_>> {
        Box::pin(async move {
            let details_json = serde_json::to_string(&request.details).map_err(|e| {
                AmplifierError::Session(SessionError::Other {
                    message: format!("gRPC: {}", e),
                })
            })?;

            let proto_request = amplifier_module::ApprovalRequest {
                tool_name: request.tool_name,
                action: request.action,
                details_json,
                risk_level: request.risk_level,
                timeout: request.timeout,
            };

            let response = {
                let mut client = self.client.lock().await;
                client.request_approval(proto_request).await.map_err(|e| {
                    AmplifierError::Session(SessionError::Other {
                        message: format!("gRPC: {}", e),
                    })
                })?
            };

            let proto_resp = response.into_inner();

            let reason = if proto_resp.reason.is_empty() {
                None
            } else {
                Some(proto_resp.reason)
            };

            Ok(ApprovalResponse {
                approved: proto_resp.approved,
                reason,
                remember: proto_resp.remember,
            })
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    #[allow(dead_code)]
    fn assert_approval_trait_object(_: Arc<dyn crate::traits::ApprovalProvider>) {}

    /// Compile-time check: GrpcApprovalBridge can be wrapped in Arc<dyn ApprovalProvider>.
    #[allow(dead_code)]
    fn grpc_approval_bridge_is_approval_provider() {
        fn _check(bridge: GrpcApprovalBridge) {
            assert_approval_trait_object(Arc::new(bridge));
        }
    }

    #[test]
    fn none_timeout_maps_to_none_on_wire() {
        let proto = amplifier_module::ApprovalRequest {
            tool_name: String::new(),
            action: String::new(),
            details_json: String::new(),
            risk_level: String::new(),
            timeout: None,
        };
        assert_eq!(proto.timeout, None);
    }

    #[test]
    fn some_timeout_is_preserved_on_wire() {
        let proto = amplifier_module::ApprovalRequest {
            tool_name: String::new(),
            action: String::new(),
            details_json: String::new(),
            risk_level: String::new(),
            timeout: Some(30.0),
        };
        assert_eq!(proto.timeout, Some(30.0));
    }

    #[test]
    fn zero_timeout_is_distinguishable_from_none() {
        let proto = amplifier_module::ApprovalRequest {
            tool_name: String::new(),
            action: String::new(),
            details_json: String::new(),
            risk_level: String::new(),
            timeout: Some(0.0),
        };
        assert_eq!(proto.timeout, Some(0.0));
        // Verify None and Some(0.0) are different
        let proto_none = amplifier_module::ApprovalRequest {
            tool_name: String::new(),
            action: String::new(),
            details_json: String::new(),
            risk_level: String::new(),
            timeout: None,
        };
        assert_ne!(proto.timeout, proto_none.timeout);
    }
}
