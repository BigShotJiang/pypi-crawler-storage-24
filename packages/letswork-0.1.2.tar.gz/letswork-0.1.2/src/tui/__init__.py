"""LetsWork TUI dashboard."""
