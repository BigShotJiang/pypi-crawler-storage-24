"""
GPU Hardware State & Identification models.
"""

from typing import List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class GPUProcess:
    """A process using a GPU."""
    pid: int
    name: Optional[str] = None
    used_gpu_memory: Optional[str] = None


@dataclass
class GPUDevice:
    """Detailed information about a single GPU"""

    index: int
    name: str
    pci_bus_id: str
    driver_version: Optional[str] = None
    vbios_version: Optional[str] = None
    serial: Optional[str] = None
    uuid: Optional[str] = None
    memory_total: Optional[str] = None

    # Sysfs power management
    sysfs_power_control: Optional[str] = None
    sysfs_runtime_status: Optional[str] = None
    sysfs_runtime_usage: Optional[str] = None

    # Memory usage
    memory_used: Optional[str] = None
    memory_free: Optional[str] = None

    # Power
    power_draw: Optional[str] = None
    power_limit: Optional[str] = None
    power_limit_enforced: Optional[str] = None
    power_limit_max: Optional[str] = None
    power_limit_min: Optional[str] = None

    # Clocks
    clock_graphics: Optional[str] = None
    clock_sm: Optional[str] = None
    clock_memory: Optional[str] = None
    clock_max_graphics: Optional[str] = None
    clock_max_memory: Optional[str] = None

    # Modes
    persistence_mode: Optional[str] = None
    ecc_mode: Optional[str] = None

    compute_mode: Optional[str] = None

    # ECC Errors
    ecc_errors_corrected_volatile: Optional[str] = None
    ecc_errors_corrected_aggregate: Optional[str] = None
    ecc_errors_uncorrected_volatile: Optional[str] = None
    ecc_errors_uncorrected_aggregate: Optional[str] = None

    # Retired Pages
    retired_pages_single_bit_ecc: Optional[str] = None
    retired_pages_double_bit: Optional[str] = None
    retired_pages_pending: Optional[str] = None

    # Remapped Rows
    remapped_rows_correctable: Optional[int] = None
    remapped_rows_uncorrectable: Optional[int] = None
    remapped_rows_pending: Optional[bool] = None
    remapped_rows_failure: Optional[bool] = None

    # Temperature and Throttling
    temperature_gpu: Optional[str] = None
    temperature_memory: Optional[str] = None
    clocks_throttle_reasons_active: Optional[str] = None
    clocks_throttle_reasons_hw_slowdown: Optional[str] = None

    # PCIe Link Status
    pcie_link_gen_current: Optional[str] = None
    pcie_link_gen_max: Optional[str] = None
    pcie_link_width_current: Optional[str] = None
    pcie_link_width_max: Optional[str] = None

    # Running processes
    processes: List[GPUProcess] = field(default_factory=list)

    errors: List[str] = field(default_factory=list)

    def check_ecc_errors(self) -> Optional[str]:
        if self.ecc_errors_uncorrected_aggregate and self.ecc_errors_uncorrected_aggregate != "N/A":
            try:
                uncorrected_count = int(self.ecc_errors_uncorrected_aggregate)
                if uncorrected_count > 0:
                    return f"GPU {self.index}: {uncorrected_count} uncorrected ECC errors detected"
            except ValueError:
                return f"GPU {self.index}: {self.ecc_errors_uncorrected_aggregate} uncorrected ECC errors detected"
        return None

    def check_retired_pages(self) -> Optional[str]:
        if self.retired_pages_pending and self.retired_pages_pending not in ["N/A", "0", "None"]:
            return f"GPU {self.index}: Retired pages pending - {self.retired_pages_pending}"
        return None

    # Benign throttle reasons that don't indicate a problem
    BENIGN_THROTTLE_REASONS = {
        "N/A",
        "0x0", "0x0000000000000000",  # No throttling
        "0x1", "0x0000000000000001",  # GPU idle
        "0x2", "0x0000000000000002",  # Applications clocks setting
        "0x3", "0x0000000000000003",  # GPU idle + Applications clocks
    }

    def check_clocks_throttle(self) -> Optional[str]:
        if self.clocks_throttle_reasons_active and self.clocks_throttle_reasons_active not in self.BENIGN_THROTTLE_REASONS:
            return f"GPU {self.index}: Clock throttling active - {self.clocks_throttle_reasons_active}"
        return None

    def check_pcie_link(self) -> Optional[str]:
        if self.pcie_link_gen_current and self.pcie_link_gen_max:
            if self.pcie_link_gen_current != self.pcie_link_gen_max and self.pcie_link_gen_current not in [
                "N/A",
                "None",
            ]:
                return f"GPU {self.index}: PCIe link speed degraded - running at Gen{self.pcie_link_gen_current} (max: Gen{self.pcie_link_gen_max})"

    def check_pcie_link_width(self) -> Optional[str]:
        if self.pcie_link_width_current and self.pcie_link_width_max:
            if self.pcie_link_width_current != self.pcie_link_width_max and self.pcie_link_width_current not in [
                "N/A",
                "None",
            ]:
                return f"GPU {self.index}: PCIe link width degraded - running at x{self.pcie_link_width_current} (max: x{self.pcie_link_width_max})"
        return None

    def check_remapped_rows(self) -> Optional[str]:
        if self.remapped_rows_failure is True:
            return (
                f"GPU {self.index}: Row remapping FAILED - no spare rows remaining. "
                f"GPU needs RMA (correctable={self.remapped_rows_correctable}, "
                f"uncorrectable={self.remapped_rows_uncorrectable})"
            )
        if self.remapped_rows_uncorrectable and self.remapped_rows_uncorrectable > 0:
            return (
                f"GPU {self.index}: {self.remapped_rows_uncorrectable} uncorrectable "
                f"remapped rows (pending={self.remapped_rows_pending})"
            )
        return None

    def check_all_errors(self) -> List[Optional[str]]:
        return [
            self.check_ecc_errors(),
            self.check_retired_pages(),
            self.check_remapped_rows(),
            self.check_clocks_throttle(),
            self.check_pcie_link(),
            self.check_pcie_link_width(),
        ]


@dataclass
class GPUHardwareResult:
    """Results from GPU hardware diagnostics"""

    timestamp: datetime
    gpus: List[GPUDevice] = field(default_factory=list)
    total_gpus: int = 0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
