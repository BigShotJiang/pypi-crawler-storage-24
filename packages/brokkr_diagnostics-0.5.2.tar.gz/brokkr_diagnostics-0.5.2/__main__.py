"""
Entry point for brokkr-diagnostics binary
"""

import argparse
from brokkr_diagnostics.console import run_command, run_interactive
from brokkr_diagnostics.core.sender import send_diagnostics


def main():
    parser = argparse.ArgumentParser(description="NVIDIA GPU Diagnostics Toolkit")
    parser.add_argument("--run", "-r", metavar="COMMAND", help="Run a specific diagnostic")
    parser.add_argument("--interactive", "-i", action="store_true", default=False, help="Launch interactive console")
    parser.add_argument("--send", "-s", nargs="?", const="all", metavar="COMMAND",
                        help="Run diagnostics and send to Brokkr (optionally specify a single command)")

    args = parser.parse_args()

    if args.send:
        cmd = None if args.send == "all" else args.send
        exit(send_diagnostics(cmd))
    elif args.run:
        exit(run_command(args.run))
    elif args.interactive:
        run_interactive()
    else:
        print("No arguments provided, use --help for available options.")


if __name__ == "__main__":
    main()
