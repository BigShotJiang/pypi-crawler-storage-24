"""Configuration management for brokkr-diagnostics."""

import json
import os
import uuid
from pathlib import Path
from typing import Optional
from dataclasses import dataclass
import re

DEFAULT_API_URL = "https://brokkr.hydrahost.com/api/v1"
PHONE_HOME_CREDS_PATH = Path("/var/lib/brokkr/phone-home-creds.json")
PHONE_HOME_SCRIPT_PATH = Path("/var/lib/cloud/scripts/per-boot/90-phone-home.sh")


@dataclass
class BrokkrCreds:
    cipher: Optional[str] = None
    signature: Optional[str] = None
    job_id: Optional[str] = None


def _parse_creds_from_phone_home_script() -> tuple[Optional[str], Optional[str]]:
    """Fallback: parse cipher and signature from 90-phone-home.sh curl headers."""
   

    cipher = None
    signature = None
    try:
        content = PHONE_HOME_SCRIPT_PATH.read_text()
        cipher_match = re.search(r'x-brokkr-cipher:\s*(.+?)"', content)
        sig_match = re.search(r'x-brokkr-signature:\s*(.+?)"', content)
        if cipher_match:
            cipher = cipher_match.group(1).strip()
        if sig_match:
            signature = sig_match.group(1).strip()
    except (PermissionError, OSError) as e:
        
        print(f"Warning: Failed to read {PHONE_HOME_SCRIPT_PATH}: {e}")
    return cipher, signature


def load_creds() -> BrokkrCreds:
    """Load credentials from phone-home-creds.json, falling back to 90-phone-home.sh, with env var overrides."""
    creds = BrokkrCreds()

    if PHONE_HOME_CREDS_PATH.exists():
        try:
            raw = json.loads(PHONE_HOME_CREDS_PATH.read_text())
            creds.cipher = raw.get("cipher")
            creds.signature = raw.get("signature")
        except (json.JSONDecodeError, PermissionError, OSError) as e:
            print(f"Warning: Failed to read {PHONE_HOME_CREDS_PATH}: {e}")

    # Fallback to parsing 90-phone-home.sh if creds are still missing
    if (not creds.cipher or not creds.signature) and PHONE_HOME_SCRIPT_PATH.exists():
        script_cipher, script_signature = _parse_creds_from_phone_home_script()
        creds.cipher = creds.cipher or script_cipher
        creds.signature = creds.signature or script_signature

    creds.cipher = os.environ.get("BROKKR_AUTH_CIPHER") or creds.cipher
    creds.signature = os.environ.get("BROKKR_AUTH_SIGNATURE") or creds.signature

    creds.job_id = str(uuid.uuid4())

    return creds


def get_api_url() -> str:
    return os.environ.get("BROKKR_API_URL", DEFAULT_API_URL)


def get_timeout() -> int:
    return int(os.environ.get("BROKKR_TIMEOUT") or os.environ.get("HTTP_TIMEOUT") or "30")
