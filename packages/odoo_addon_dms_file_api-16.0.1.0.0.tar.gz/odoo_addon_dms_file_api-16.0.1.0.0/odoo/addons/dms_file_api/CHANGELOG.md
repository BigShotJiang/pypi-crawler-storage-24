# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.0] - 2026-02-18
### Migrated
- [#8](https://gitlab.com/somitcoop/erp-research/odoo-document-management/-/merge_requests/8) Migrate/dms modules 16.0

## [12.0.0.1.0] - 2024-03-11
### Added
- [#25](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/25) Add dms_file_api module
