# Sentinel-1
GRD_HD = 'GRD_HD'
GRD_MD = 'GRD_MD'
GRD_MS = 'GRD_MS'
GRD_HS = 'GRD_HS'
GRD_FD = 'GRD_FD'
SLC = 'SLC'
OCN = 'OCN'
RAW = 'RAW'
METADATA_GRD_HD = 'METADATA_GRD_HD'
METADATA_GRD_MD = 'METADATA_GRD_MD'
METADATA_GRD_MS = 'METADATA_GRD_MS'
METADATA_GRD_HS = 'METADATA_GRD_HS'
METADATA_SLC = 'METADATA_SLC'
METADATA_OCN = 'METADATA_OCN'
METADATA_RAW = 'METADATA_RAW'
BURST = 'BURST'

# ALOS PALSAR
L1_0 = 'L1.0'
L1_1 = 'L1.1'
L1_5 = 'L1.5'
L2_2 = 'L2.2'
RTC_LOW_RES = 'RTC_LOW_RES'
RTC_HIGH_RES = 'RTC_HI_RES'
KMZ = 'KMZ'

# ALOS AVNIR
# No PROCESSING_TYPE attribute in CMR

# SIR-C
# SLC and SLC metadata are both 'SLC', provided by Sentinel-1 constants

# Sentinel-1 InSAR
GUNW_STD = 'GUNW_STD'
GUNW_AMP = 'GUNW_AMP'
GUNW_CON = 'GUNW_CON'
GUN_COH = 'GUNW_COH'
GUNW_UNW = 'GUNW_UNW'

# SMAP
L1A_RADAR_RO_HDF5 = 'L1A_Radar_RO_HDF5'
L1A_RADAR_HDF5 = 'L1A_Radar_HDF5'
L1B_S0_LOW_RES_HDF5 = 'L1B_S0_LoRes_HDF5'
L1C_S0_HIGH_RES_HDF5 = 'L1C_S0_HiRes_HDF5'
L1A_RADAR_RO_QA = 'L1A_Radar_RO_QA'
L1A_RADAR_QA = 'L1A_Radar_QA'
L1B_S0_LOW_RES_QA = 'L1B_S0_LoRes_QA'
L1C_S0_HIGH_RES_QA = 'L1C_S0_HiRes_QA'
L1A_RADAR_RO_ISO_XML = 'L1A_Radar_RO_ISO_XML'
L1B_S0_LOW_RES_ISO_XML = 'L1B_S0_LoRes_ISO_XML'
L1C_S0_HIGH_RES_ISO_XML = 'L1C_S0_HiRes_ISO_XML'

# UAVSAR
AMPLITUDE = 'AMPLITUDE'
STOKES = 'STOKES'
AMPLITUDE_GRD = 'AMPLITUDE_GRD'
PROJECTED = 'PROJECTED'
PROJECTED_ML5X5 = 'PROJECTED_ML5X5'
PROJECTED_ML3X3 = 'PROJECTED_ML3X3'
INTERFEROMETRY_GRD = 'INTERFEROMETRY_GRD'
INTERFEROMETRY = 'INTERFEROMETRY'
COMPLEX = 'COMPLEX'
# KMZ provided by ALOS PALSAR
INC = 'INC'
SLOPE = 'SLOPE'
DEM_TIFF = 'DEM_TIFF'
PAULI = 'PAULI'
METADATA = 'METADATA'

# RADARSAT
L0 = 'L0'
L1 = 'L1'

# ERS
# L0 provided by RADARSAT
# L1 provided by RADARSAT

# JERS
# L0 provided by RADARSAT
# L1 provided by RADARSAT

# AIRSAR
CTIF = 'CTIF'
PTIF = 'PTIF'
LTIF = 'LTIF'
JPG = 'JPG'
LSTOKES = 'LSTOKES'
PSTOKES = 'PSTOKES'
CSTOKES = 'CSTOKES'
DEM = 'DEM'
THREEFP = '3FP'

# OPERA-S1
RTC = 'RTC'
CSLC = 'CSLC'
RTC_STATIC = 'RTC-STATIC'
CSLC_STATIC = 'CSLC-STATIC'
DISP_S1 = 'DISP-S1'
DISP_S1_STATIC = 'DISP-S1-STATIC'

# TROPO
TROPO_ZENITH = 'TROPO-ZENITH'
ECMWF_TROPO = 'ECMWF_TROPO'

### NISAR

### NISAR Science Products ###
L0B = 'L0B'
"""alias for RRSD Level 0B product types"""

RRSD = 'RRSD'
"""Level 0B Radar Raw Signal Data"""

RSLC = 'RSLC'
"""Level 1 Range-Doppler Single Look Complex"""
RIFG = 'RIFG'
"""Level 1 Range-Doppler Wrapped Interferrogram"""
RUNW = 'RUNW'
"""Level 1 Range-Doppler Unwrapped Interferrogram"""
ROFF = 'ROFF'
"""Level 1 Range-Doppler Pixel Offsets"""
GSLC = 'GSLC'
"""Level 2 Geocoded Single Look Complex"""
GCOV = 'GCOV'
"""Level 2 Geocoded Polarimetric Covariance"""
GUNW = 'GUNW'
""""Level 2 Geocoded Unwrapped Inteferrogram"""
GOFF = 'GOFF'
"""Level 2 Geocoded Pixel Offsets"""
SME2 = 'SME2'
"""Level 3 Soil Moisture EASE-Grid 2.0"""

### NISAR ANCILLARY PRODUCTS ###

CRSD = 'CRSD'
"""NISAR Radar Raw Signal Calibration Data"""

# NISAR Coordinated Observation Plan (NISAR_COP)
DCOP = 'DCOP'
"""NISAR Coordinates Observation Plan"""
# NISAR_OROST
OROST = 'OROST'
"""NISAR Radar Observation Sequence Table"""
# NISAR_STUF
STUF = "STUF"
"""	STUF - 1 week plan of orbit boundaries, convert UTC to Orbit"""

# NISAR Total Electron Content (NISAR_TEC)
TEC = "TEC"
"NISAR Total Electron Content"

# NISAR L-SAR Radar Clock to UTC Conversion File (NISAR_LRCLK_UTC)
LRCLK_UTC = "LRCLK_UTC"
"""L-SAR Radar clock to UTC Spacecraft Clock Spacecraft Event Time (SCLKSCET) conversion file"""


# NISAR Orbit Ephemeris (NISAR_OE)
# "The NASA-ISRO Synthetic Aperture Radar (NISAR) Orbit Ephemeris collection contains 
# the state vector files for the NISAR mission"
FOE = "FOE"
"""Forecast Orbit Ephemeris"""
MOE = "MOE"
"""	Medium Orbit Ephemeris"""
NOE = "NOE"
"""	Near-Realtime Orbit Ephemeris"""
POE = "POE"
"""	Precise Orbit Ephemeris"""

# NISAR Ancillary and Auxiliary Data (NISAR_ANC_AUX)
# "The NASA-ISRO Synthetic Aperture Radar (NISAR) Ancilliary and Auxiallry collection contains products 
# that are supplementary information for the NISAR mission and are created a limited number of times.""
TSR_STATIC = "TSR_STATIC"
"""Time Series Ratio (TSR_STATIC)"""
PMI_STATIC = "PMI_STATIC"
"""Physical Model Inversion (PMI_STATIC)"""
CORNER_REFL = "CORNER_REFL"
"""Corner Reflector locations (CORNER_REFL)"""
LSAR_INT_CAL = "LSAR_INT_CAL"
"""Combined ADT Flight Table (INT_CAL)"""
LSAR_EXT_CAL = "LSAR_EXT_CAL"
"""LSAR Calibration File (EXT_CAL)"""
FT_WAVEFORM = "FT_WAVEFORM"
"""Flight Table Waveform (FT_WAVEFORM)"""
FT_PARAM = "FT_PARAM"
"""Flight Table Parameters (FT_PARAM)"""
ANTPAT = "ANTPAT"
"""Antenna Pattern (ANTPAT)"""
BFPQ = "BFPQ"
"""Block Floating Point Quantization Look-up Table (BFPQ)"""
TFDB = "TFDB"
"""Track Frame Database (TFDB)"""
L_CHAN_DATA = "L_CHAN_DATA"
"""L-SAR Channel Data (L_CHAN_DATA)"""
SM_STATIC = "SM_STATIC"
"""Soil Moisture Static File (SM_STATIC)"""
DSG_STATIC = "DSG_STATIC"
"""Disaggregation File (DSG_STATIC)"""

# NISAR Pointing: (NISAR_RP)
# "The NASA-ISRO Synthetic Aperture Radar (NISAR) Radar Pointing collection contains the radar pointing files for the NISAR mission.
# The collection includes multiple accuracy levels"
FRP = "FRP"
"""	Forecast Radar Pointing"""
PRP = "PRP"
"""	Precise Radar Pointing"""
NRP = "NRP"
"""	Near-Realtime Radar Pointing"""

# ECMWF SMST Data (ASF_ECMWF_SMST)
ECMWF_SMST = "ECMWF_SMST"
"""	European Centre for Medium-Range Weather Forecasts (models)"""

# TODO: Verify/Add/Remove these product types as necessary
# COP = "COP"
# """Coordinated Observation Plan that contains a 7 day plan of observations"""
# DEM = "DEM"
# """	Digital Elevation Model"""

# LOCAL_INC_ANG = "LOCAL_INC_ANG" 
# """	Local Incidence Angles"""
# VWC = "VWC"
# """	Vegetation water content"""
# WATER_MASK = "WaterMask"
# """Water Mask"""
