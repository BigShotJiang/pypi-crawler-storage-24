# CodePilot CLI

AI Coding Agent Mobile Manager - manage your Claude Code / Codex agents from anywhere.

## Install

```bash
curl -fsSL https://songlegend.com/codepilot/install | sh
```

Alternative:

```bash
pip install codepilot
```

## Usage

```bash
codepilot auth login
codepilot wrap claude
codepilot openclaw --session main
codepilot status
```

## Local Development

```bash
cd apps/cli
source .venv/bin/activate
python3 -m codepilot.main auth status
python3 -m codepilot.main wrap claude
python3 -m codepilot.main openclaw --session main
```

## OpenClaw Bridge

Use the dedicated OpenClaw bridge when you want clean message sync instead of TUI screen output. If the desktop OpenClaw app is already using `main`, bridge a separate session key such as `codepilot-main`.

```bash
codepilot openclaw --session codepilot-main --name openclaw-mobile
```
