"""codepilot launch — one-command: QR code + agent start simultaneously.

Happy-style flow:
  codepilot claude   →  QR appears immediately, start coding, phone scans anytime
"""

import asyncio
import os
import threading
from typing import Optional

from rich.console import Console
from rich.panel import Panel

from .auth import ensure_valid_token
from .connect import get_provider_env
from .pairing import (
    RELAY_HTTP,
    display_qr,
    generate_token,
    poll_pairing_status,
    register_pairing,
)

console = Console()

# Map shorthand names to real commands + agent_type labels
AGENT_COMMANDS = {
    "claude": ("claude", "claude-code"),
    "codex": ("codex", "codex"),
    "opencode": ("opencode", "opencode"),
}


def _poll_phone_in_background(pair_token: str, user_token: str, connected_event: threading.Event) -> None:
    """Background thread: poll relay until phone scans QR, then signal."""
    import time

    timeout = 300  # 5 min
    elapsed = 0
    while elapsed < timeout and not connected_event.is_set():
        session_id = poll_pairing_status(pair_token, user_token)
        if session_id:
            connected_event.set()
            console.print("\n[bold green]📱 手机已连接！[/bold green]")
            return
        time.sleep(2)
        elapsed += 2


async def launch(agent: str = "claude", name: Optional[str] = None) -> None:
    """Start agent + show QR simultaneously. Phone can scan anytime."""
    from .wrapper import AgentWrapper

    user_token = ensure_valid_token()
    if not user_token:
        console.print("[red]未登录。请先运行: codepilot auth login[/red]")
        return

    agent = agent.lower()
    if agent not in AGENT_COMMANDS:
        console.print(f"[red]未知 agent: {agent}[/red]")
        console.print(f"可选: {', '.join(AGENT_COMMANDS.keys())}")
        return

    command, agent_type = AGENT_COMMANDS[agent]
    session_name = name or agent

    # Check if provider key is stored; if so, inject it
    env_extra = get_provider_env(agent_type)
    if env_extra:
        env_var = list(env_extra.keys())[0]
        console.print(f"[dim]使用已存储的 {env_var[:15]}***[/dim]")

    # Generate pairing token and register with relay (non-blocking)
    pair_token = generate_token()
    ok = register_pairing(pair_token, user_token, session_name, agent_type=agent_type)
    if not ok:
        console.print("[yellow]⚠️  无法注册配对 token，手机扫码功能暂不可用[/yellow]")
        console.print("[dim]继续启动 agent...[/dim]\n")
    else:
        # Show QR immediately — don't wait for phone
        display_qr(pair_token)
        console.print(
            "[dim]扫码后即可在手机上监控 · 可先开始编程，随时扫码连接[/dim]\n"
        )

        # Background thread watches for phone scan
        connected_event = threading.Event()
        watcher = threading.Thread(
            target=_poll_phone_in_background,
            args=(pair_token, user_token, connected_event),
            daemon=True,
        )
        watcher.start()

    # Start the agent immediately (this blocks until agent exits)
    console.print(f"[bold]▶ 启动 {agent}[/bold]  [dim]session: {session_name}[/dim]\n")

    wrapper = AgentWrapper(
        command=command,
        agent_type=agent_type,
        name=session_name,
    )
    await wrapper.start()
