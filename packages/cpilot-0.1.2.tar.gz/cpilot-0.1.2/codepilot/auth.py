"""Authentication helpers for CodePilot CLI (Supabase REST API)."""

import http.server
import json
import platform
import socket
import threading
import time
import urllib.parse
import urllib.request
import uuid
import webbrowser
from typing import Optional

from rich.console import Console
from rich.prompt import Prompt

from .config import (
    SUPABASE_ANON_KEY,
    SUPABASE_URL,
    WEB_URL,
    clear_token,
    get_auth,
    load_config,
    save_auth,
    save_config,
)

console = Console()

# ---------------------------------------------------------------------------
# Low-level Supabase Auth REST helpers
# ---------------------------------------------------------------------------


def _supabase_auth_post(path: str, payload: dict) -> dict:
    """POST to Supabase Auth endpoint; returns parsed JSON or raises."""
    url = f"{SUPABASE_URL}/auth/v1{path}"
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "apikey": SUPABASE_ANON_KEY,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            err = json.loads(body)
        except Exception:
            err = {"error": body}
        raise RuntimeError(err.get("error_description") or err.get("msg") or err.get("error") or body)


def _supabase_auth_get(path: str, token: str) -> dict:
    """GET from Supabase Auth endpoint with bearer token."""
    url = f"{SUPABASE_URL}/auth/v1{path}"
    req = urllib.request.Request(
        url,
        headers={
            "apikey": SUPABASE_ANON_KEY,
            "Authorization": f"Bearer {token}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            err = json.loads(body)
        except Exception:
            err = {"error": body}
        raise RuntimeError(err.get("error_description") or err.get("msg") or err.get("error") or body)


def _supabase_rest_post(path: str, token: str, payload: dict) -> dict:
    """POST to Supabase REST API with bearer token."""
    url = f"{SUPABASE_URL}/rest/v1{path}"
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "apikey": SUPABASE_ANON_KEY,
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        # Ignore duplicate device errors (23505 = unique_violation)
        if b"23505" in e.read() if hasattr(e, "read") else b"" in body.encode():
            return {}
        return {}


def _supabase_rest_get(path: str, token: str) -> list:
    """GET from Supabase REST API with bearer token."""
    url = f"{SUPABASE_URL}/rest/v1{path}"
    req = urllib.request.Request(
        url,
        headers={
            "apikey": SUPABASE_ANON_KEY,
            "Authorization": f"Bearer {token}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError:
        return []


# ---------------------------------------------------------------------------
# Token management
# ---------------------------------------------------------------------------


def refresh_auth_token() -> Optional[str]:
    """Use stored refresh_token to get a new access_token. Returns new token or None."""
    auth = get_auth()
    refresh_token = auth.get("refresh_token")
    if not refresh_token:
        return None
    try:
        result = _supabase_auth_post(
            "/token?grant_type=refresh_token",
            {"refresh_token": refresh_token},
        )
        access_token = result.get("access_token")
        new_refresh = result.get("refresh_token", refresh_token)
        expires_in = result.get("expires_in", 3600)
        if access_token:
            save_auth(
                access_token=access_token,
                refresh_token=new_refresh,
                expires_at=int(time.time()) + expires_in,
            )
            return access_token
    except Exception:
        pass
    return None


def ensure_valid_token() -> Optional[str]:
    """Return a valid access token, refreshing if within 5 minutes of expiry."""
    auth = get_auth()
    token = auth.get("access_token")
    if not token:
        return None
    expires_at = auth.get("expires_at", 0)
    # Refresh if expiring within 5 minutes
    if expires_at and time.time() > expires_at - 300:
        token = refresh_auth_token() or token
    return token


# ---------------------------------------------------------------------------
# User info
# ---------------------------------------------------------------------------


def get_user_info(token: str) -> Optional[dict]:
    """Fetch user profile from Supabase. Returns dict with id, email, etc."""
    try:
        return _supabase_auth_get("/user", token)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Device registration
# ---------------------------------------------------------------------------


def _get_device_name() -> str:
    """Generate a human-readable device name."""
    hostname = socket.gethostname().split(".")[0]
    system = platform.system()  # Darwin, Linux, Windows
    return f"{hostname} ({system})"


def register_device(token: str, user_id: str) -> Optional[str]:
    """Register this CLI device in Supabase. Returns device_id or None."""
    config = load_config()
    device_id = config.get("device_id") or str(uuid.uuid4())
    device_name = _get_device_name()

    try:
        _supabase_rest_post(
            "/devices",
            token,
            {
                "id": device_id,
                "user_id": user_id,
                "platform": "cli",
                "device_name": device_name,
                "last_seen_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            },
        )
        # Persist device_id
        config["device_id"] = device_id
        save_config(config)
        return device_id
    except Exception:
        return None


def list_devices(token: str) -> list:
    """Return list of registered devices for the current user."""
    return _supabase_rest_get("/devices?select=*&order=last_seen_at.desc", token)


# ---------------------------------------------------------------------------
# Login flows
# ---------------------------------------------------------------------------


def login_with_email(email: str, password: str) -> bool:
    """Authenticate with email + password via Supabase."""
    try:
        result = _supabase_auth_post(
            "/token?grant_type=password",
            {"email": email, "password": password},
        )
    except RuntimeError as e:
        console.print(f"[red]Login failed:[/red] {e}")
        return False

    access_token = result.get("access_token")
    refresh_token = result.get("refresh_token")
    expires_in = result.get("expires_in", 3600)
    user = result.get("user", {})

    if not access_token:
        console.print("[red]Login failed: no token returned.[/red]")
        return False

    user_id = user.get("id", "")
    email_addr = user.get("email", email)

    save_auth(
        access_token=access_token,
        refresh_token=refresh_token,
        user_id=user_id,
        email=email_addr,
        expires_at=int(time.time()) + expires_in,
    )

    # Register this device
    register_device(access_token, user_id)

    console.print(f"[bold green]Logged in as {email_addr}[/bold green]")
    return True


# OAuth browser flow

_auth_result: dict = {}


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """HTTP handler to receive OAuth callback with tokens."""

    def do_GET(self):
        global _auth_result
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        if "access_token" in params and "refresh_token" in params:
            _auth_result = {
                "access_token": params["access_token"][0],
                "refresh_token": params["refresh_token"][0],
            }
            html = (
                b"<html><body style='font-family:sans-serif;text-align:center;margin-top:80px'>"
                b"<h1 style='color:#22c55e'>Authenticated!</h1>"
                b"<p>You can close this window and return to the terminal.</p>"
                b"</body></html>"
            )
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)
        else:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"Authentication failed - missing tokens.")

    def log_message(self, format, *args):
        pass  # Suppress access logs


def login_with_browser() -> bool:
    """Open browser for OAuth login, wait for token callback."""
    global _auth_result
    _auth_result = {}

    port = 9876
    server = http.server.HTTPServer(("localhost", port), _CallbackHandler)

    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()

    auth_url = f"{WEB_URL}/auth/cli?callback=http://localhost:{port}/callback"
    console.print("[bold blue]Opening browser for authentication...[/bold blue]")
    console.print(f"[dim]If browser doesn't open, visit: {auth_url}[/dim]")
    webbrowser.open(auth_url)

    console.print("[dim]Waiting for authentication (120s timeout)...[/dim]")
    thread.join(timeout=120)
    server.server_close()

    if not _auth_result:
        console.print("[bold red]Authentication timed out or failed.[/bold red]")
        return False

    access_token = _auth_result["access_token"]
    refresh_token = _auth_result["refresh_token"]

    # Fetch user info
    user = get_user_info(access_token) or {}
    user_id = user.get("id", "")
    email = user.get("email", "")

    save_auth(
        access_token=access_token,
        refresh_token=refresh_token,
        user_id=user_id,
        email=email,
        expires_at=int(time.time()) + 3600,
    )

    if user_id:
        register_device(access_token, user_id)

    console.print(f"[bold green]Logged in as {email or 'unknown'}[/bold green]")
    return True


def login(email: Optional[str] = None) -> bool:
    """Main login entry point. Uses email/password if --email given, else browser OAuth."""
    if email:
        password = Prompt.ask("Password", password=True)
        return login_with_email(email, password)
    else:
        return login_with_browser()
