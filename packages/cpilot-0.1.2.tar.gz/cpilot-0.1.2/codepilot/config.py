"""Configuration management for CodePilot CLI."""

import json
import os
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".codepilot"
CONFIG_FILE = CONFIG_DIR / "config.json"

SUPABASE_URL = "https://cnswwzcirpiwopjbmzih.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNuc3d3emNpcnBpd29wamJtemloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM5NTAxMjcsImV4cCI6MjA4OTUyNjEyN30.mEMIH6NHnXN07BpceNq_w3u9MDS-QbJBgl2LcsExeMo"
WEB_URL = "https://web-peach-ten-57.vercel.app"
RELAY_WS = os.environ.get("CODEPILOT_RELAY_WS", "ws://129.204.224.145:4000")


def ensure_config_dir() -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def load_config() -> dict:
    ensure_config_dir()
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(config: dict) -> None:
    ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    CONFIG_FILE.chmod(0o600)  # Owner read/write only


def get_token() -> Optional[str]:
    """Return stored access token (does not auto-refresh; use auth.ensure_valid_token for that)."""
    config = load_config()
    return config.get("access_token")


def get_auth() -> dict:
    """Return full auth dict with access_token, refresh_token, user_id, email, expires_at."""
    return load_config()


def save_auth(access_token: str, refresh_token: str, user_id: str = None,
              email: str = None, expires_at: int = None) -> None:
    """Persist auth info to config file."""
    config = load_config()
    config["access_token"] = access_token
    config["refresh_token"] = refresh_token
    if user_id is not None:
        config["user_id"] = user_id
    if email is not None:
        config["email"] = email
    if expires_at is not None:
        config["expires_at"] = expires_at
    save_config(config)


def save_token(access_token: str, refresh_token: str) -> None:
    """Legacy compat: save tokens without user info."""
    save_auth(access_token, refresh_token)


def clear_token() -> None:
    config = load_config()
    for key in ("access_token", "refresh_token", "user_id", "email", "expires_at", "device_id"):
        config.pop(key, None)
    save_config(config)
