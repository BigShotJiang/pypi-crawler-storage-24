"""PTY wrapper for Claude Code / Codex - captures stdin/stdout."""

import asyncio
import os
import pty
import re
import select
import signal
import subprocess
import sys
import termios
import tty
from typing import Optional

from rich.console import Console

from .connect import get_provider_env
from .sync import RelaySync, SupabaseSync

console = Console()

ANSI_ESCAPE_RE = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
# Claude Code marks tool invocations with ● or ⏺ followed by ToolName(args)
TOOL_CALL_RE = re.compile(r'[●⏺]\s+(\w+)\(([^)]*)\)')
# ⎿ marks the start of a tool result block
TOOL_RESULT_START_RE = re.compile(r'^\s*[⎿└⊢]')


class ToolCallParser:
    """Detects Claude Code tool call/result lines in PTY output and emits events."""

    def __init__(self):
        self._line_buf = ""
        self._pending_tool: Optional[str] = None
        self._result_lines: list[str] = []
        self._collecting_result = False

    def feed(self, raw: str) -> list[dict]:
        """Feed raw PTY text; returns list of tool events to relay."""
        events: list[dict] = []
        self._line_buf += ANSI_ESCAPE_RE.sub('', raw)
        while '\n' in self._line_buf:
            line, self._line_buf = self._line_buf.split('\n', 1)
            events.extend(self._process_line(line))
        return events

    def _flush_result(self) -> list[dict]:
        if self._pending_tool and self._result_lines:
            event = {
                "type": "tool_result",
                "tool_name": self._pending_tool,
                "tool_output": {"result": '\n'.join(self._result_lines).strip()},
            }
            self._result_lines = []
            self._collecting_result = False
            self._pending_tool = None
            return [event]
        return []

    def _process_line(self, line: str) -> list[dict]:
        events: list[dict] = []
        m = TOOL_CALL_RE.search(line)
        if m:
            events.extend(self._flush_result())
            tool_name, tool_args = m.group(1), m.group(2).strip()
            self._pending_tool = tool_name
            self._collecting_result = False
            events.append({
                "type": "tool_call",
                "tool_name": tool_name,
                "tool_input": {"args": tool_args},
            })
            return events

        if self._pending_tool and TOOL_RESULT_START_RE.match(line):
            self._collecting_result = True
            content = TOOL_RESULT_START_RE.sub('', line).strip()
            if content:
                self._result_lines.append(content)
            return events

        if self._collecting_result:
            stripped = line.strip()
            if stripped:
                self._result_lines.append(stripped)
            else:
                events.extend(self._flush_result())
        return events


# Patterns that indicate the agent is waiting for user input
WAITING_PATTERNS = [
    r"Do you want to proceed\?",
    r"\[Y/n\]",
    r"\[y/N\]",
    r"Press Enter",
    r"waiting for input",
    r"please reply",
    r"reply.*continue",
    r"approve|deny|confirm",
    r">\s*$",  # Prompt ending with >
]


class AgentWrapper:
    """Wraps a CLI agent process (claude code, codex) with PTY to capture I/O."""

    def __init__(self, command: str, agent_type: str, name: str):
        self.command = command
        self.agent_type = agent_type
        self.name = name
        self.sync = SupabaseSync()
        self.relay: Optional[RelaySync] = None
        self.process: Optional[subprocess.Popen] = None
        self.master_fd: Optional[int] = None
        self.output_buffer = ""
        self._tool_parser = ToolCallParser()

    def _is_waiting_for_input(self, text: str) -> bool:
        """Check if output indicates agent is waiting for user input."""
        for pattern in WAITING_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        return False

    async def _handle_output(self, text: str) -> None:
        """Write output through to terminal and sync backends."""
        sys.stdout.write(text)
        sys.stdout.flush()

        self.output_buffer += text
        # Strip ANSI escape codes and normalize line endings for mobile display
        clean = ANSI_ESCAPE_RE.sub('', text)
        clean = clean.replace('\r\n', '\n').replace('\r', '\n')
        await self.sync.push_message("assistant", clean)
        if self.relay:
            await self.relay.send_output(clean)
            for event in self._tool_parser.feed(text):
                if event["type"] == "tool_call":
                    await self.relay.send_tool_call(event["tool_name"], event["tool_input"])
                elif event["type"] == "tool_result":
                    await self.relay.send_tool_result(event["tool_name"], event["tool_output"])

        if self._is_waiting_for_input(clean):
            await self.sync.update_status(
                "waiting_input",
                preview=clean[-200:],
            )
            if self.relay:
                await self.relay.send_status("waiting_input")

    async def _drain_remaining_output(self) -> None:
        """Flush any PTY bytes left after the child process exits."""
        if self.master_fd is None:
            return

        idle_polls = 0
        while idle_polls < 5:
            try:
                r, _, _ = select.select([self.master_fd], [], [], 0.05)
                if self.master_fd not in r:
                    idle_polls += 1
                    continue
                data = os.read(self.master_fd, 4096)
                if not data:
                    break
                idle_polls = 0
                await self._handle_output(data.decode("utf-8", errors="replace"))
            except OSError:
                break

    async def _capture_post_input_output(self, duration: float = 0.5) -> list[str]:
        """Capture output that arrives immediately after sending input."""
        if self.master_fd is None:
            return []

        chunks: list[str] = []
        deadline = asyncio.get_running_loop().time() + duration
        while asyncio.get_running_loop().time() < deadline:
            try:
                r, _, _ = select.select([self.master_fd], [], [], 0.05)
                if self.master_fd not in r:
                    await asyncio.sleep(0)
                    continue
                data = os.read(self.master_fd, 4096)
                if not data:
                    break
                chunks.append(data.decode("utf-8", errors="replace"))
            except OSError:
                break

        return chunks

    async def start(self) -> None:
        """Start the wrapped agent process."""
        session_id = await self.sync.create_session(self.name, self.agent_type)
        console.print(f"[bold green]Session created:[/bold green] {session_id}")
        console.print(f"[dim]Starting {self.command}...[/dim]")

        self.relay = RelaySync(session_id=session_id, name=self.name, agent_type=self.agent_type)
        await self.relay.connect()

        # Create PTY
        master_fd, slave_fd = pty.openpty()
        self.master_fd = master_fd
        slave_attrs = termios.tcgetattr(slave_fd)
        slave_attrs[3] &= ~termios.ECHO
        termios.tcsetattr(slave_fd, termios.TCSANOW, slave_attrs)

        # Merge stored provider API keys into the child's environment
        env = os.environ.copy()
        env.update(get_provider_env(self.agent_type))

        # Start process with PTY
        self.process = subprocess.Popen(
            self.command.split(),
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            preexec_fn=os.setsid,
            env=env,
        )
        os.close(slave_fd)

        console.print(f"[bold green]Agent running (PID: {self.process.pid})[/bold green]")
        console.print("[dim]Output is being synced to your mobile device.[/dim]\n")

        # Put host terminal in raw mode so interactive TUI apps (Claude Code)
        # receive keystrokes directly without local echo or line buffering.
        old_tty = None
        stdin_fd = sys.stdin.fileno()
        try:
            old_tty = termios.tcgetattr(stdin_fd)
            tty.setraw(stdin_fd)
        except (termios.error, IOError):
            pass  # stdin may not be a tty (e.g. piped input)

        try:
            await self._relay_loop()
        except KeyboardInterrupt:
            console.print("\n[yellow]Stopping agent...[/yellow]")
        finally:
            if old_tty is not None:
                try:
                    termios.tcsetattr(stdin_fd, termios.TCSADRAIN, old_tty)
                except termios.error:
                    pass
            preview = self.output_buffer[-200:] if self.output_buffer else None
            await self.sync.close_session(preview=preview)
            if self.relay:
                await self.relay.close()
            self._cleanup()

    async def _relay_loop(self) -> None:
        """Main loop: read from PTY, write to terminal + sync to Supabase."""
        process_exited = False
        exit_idle_polls = 0

        while True:
            fds = [self.master_fd]
            if not process_exited:
                fds.append(sys.stdin.fileno())

            # Check if there's data to read from PTY
            r, _, _ = select.select(fds, [], [], 0.1)
            saw_agent_output = False

            for fd in r:
                if fd == self.master_fd:
                    # Agent output
                    try:
                        data = os.read(self.master_fd, 4096)
                        if not data:
                            process_exited = True
                            continue
                        saw_agent_output = True
                        await self._handle_output(
                            data.decode("utf-8", errors="replace")
                        )

                    except OSError:
                        process_exited = True
                        continue

                elif fd == sys.stdin.fileno():
                    # User input from terminal
                    try:
                        data = os.read(sys.stdin.fileno(), 4096)
                        if data:
                            os.write(self.master_fd, data)
                            text = data.decode("utf-8", errors="replace")
                            post_input_chunks = await self._capture_post_input_output()
                            await self.sync.push_message("user", text)
                            await self.sync.update_status("running")
                            for chunk in post_input_chunks:
                                await self._handle_output(chunk)
                    except OSError:
                        break

            # Check for mobile user replies via relay
            if self.relay:
                reply = await self.relay.get_user_input()
                if reply:
                    if not reply.endswith("\n"):
                        reply += "\n"
                    os.write(self.master_fd, reply.encode())
                    post_input_chunks = await self._capture_post_input_output()
                    await self.sync.push_message("user", reply)
                    await self.sync.update_status("running")
                    await self.relay.send_status("running")
                    for chunk in post_input_chunks:
                        await self._handle_output(chunk)

                if await self.relay.should_stop():
                    os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
                    break

            # select.select is synchronous; yield so the relay receiver task can
            # enqueue mobile replies while the wrapped process is idle.
            if not process_exited and self.process.poll() is not None:
                process_exited = True

            if process_exited:
                if saw_agent_output:
                    exit_idle_polls = 0
                else:
                    exit_idle_polls += 1
                    if exit_idle_polls >= 5:
                        break

            await asyncio.sleep(0)

        await self._drain_remaining_output()

    def _cleanup(self) -> None:
        """Clean up process and file descriptors."""
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
        if self.process and self.process.poll() is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            except (OSError, ProcessLookupError):
                pass
