"""Bridge OpenClaw's structured agent API into CodePilot sessions."""

import asyncio
import contextlib
import json
import os
import shutil
import signal
from pathlib import Path
from typing import Optional

from rich.console import Console

from .sync import RelaySync, SupabaseSync

console = Console()
DEFAULT_AGENT_TIMEOUT_SECONDS = 20


def resolve_openclaw_bin(explicit_path: Optional[str] = None) -> str:
    """Resolve the OpenClaw executable path."""
    candidates = [
        explicit_path,
        os.environ.get("OPENCLAW_BIN"),
        shutil.which("openclaw"),
        str(Path.home() / ".openclaw" / "bin" / "openclaw"),
    ]

    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate))

    raise RuntimeError(
        "OpenClaw binary not found. Set OPENCLAW_BIN or pass --bin with the executable path."
    )


class OpenClawBridge:
    """Relay mobile user input into OpenClaw's structured CLI API."""

    def __init__(
        self,
        name: str,
        session_key: str = "main",
        agent_id: Optional[str] = None,
        openclaw_bin: Optional[str] = None,
    ):
        self.name = name
        self.session_key = session_key
        self.agent_id = agent_id
        self.openclaw_bin = resolve_openclaw_bin(openclaw_bin)
        self.sync = SupabaseSync()
        self.relay: Optional[RelaySync] = None
        self.preview = ""
        self.agent_timeout_seconds = DEFAULT_AGENT_TIMEOUT_SECONDS

    async def _run_command(self, *args: str, timeout_seconds: Optional[int] = None) -> str:
        """Run an OpenClaw command and return stdout or raise on failure."""
        process = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=True,
        )
        try:
            if timeout_seconds:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(), timeout=timeout_seconds
                )
            else:
                stdout, stderr = await process.communicate()
        except asyncio.TimeoutError as exc:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = await process.communicate()
            out = stdout.decode("utf-8", errors="replace").strip()
            err = stderr.decode("utf-8", errors="replace").strip()
            detail = err or out or "no output"
            raise RuntimeError(
                "OpenClaw did not return in time. "
                f"Timed out after {timeout_seconds}s. Last output: {detail[:240]}"
            ) from exc
        except asyncio.CancelledError:
            with contextlib.suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGKILL)
            raise
        out = stdout.decode("utf-8", errors="replace").strip()
        err = stderr.decode("utf-8", errors="replace").strip()

        if process.returncode != 0:
            detail = err or out or f"exit code {process.returncode}"
            raise RuntimeError(detail)

        return out

    async def _verify_health(self) -> dict:
        """Ensure OpenClaw's gateway is reachable before starting the bridge."""
        raw = await self._run_command(self.openclaw_bin, "health", "--json")
        try:
            health = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"failed to parse OpenClaw health JSON: {exc}") from exc

        if not health.get("ok"):
            raise RuntimeError("OpenClaw gateway reported unhealthy state")

        return health

    def _session_lock_path(self, agent_id: str) -> Path:
        """Return the lock file path for the bridged OpenClaw session."""
        return (
            Path.home()
            / ".openclaw"
            / "agents"
            / agent_id
            / "sessions"
            / f"{self.session_key}.jsonl.lock"
        )

    def _read_active_lock(self, agent_id: str) -> Optional[dict]:
        """Return active lock metadata when another OpenClaw process owns the session."""
        lock_path = self._session_lock_path(agent_id)
        if not lock_path.exists():
            return None

        try:
            payload = json.loads(lock_path.read_text(encoding="utf-8"))
        except Exception:
            return {"path": str(lock_path)}

        pid = payload.get("pid")
        if not pid:
            payload["path"] = str(lock_path)
            return payload

        try:
            os.kill(int(pid), 0)
        except OSError:
            return None

        payload["path"] = str(lock_path)
        return payload

    def _format_lock_error(self, lock: dict) -> str:
        """Explain that the current OpenClaw session is already in use."""
        pid = lock.get("pid", "unknown")
        created_at = lock.get("createdAt", "unknown time")
        suggestion = (
            f"codepilot openclaw --session codepilot-{self.session_key} "
            f'--name "{self.name}-mobile"'
        )
        return (
            f"OpenClaw session '{self.session_key}' is busy (pid {pid}, lock from {created_at}). "
            "This usually means the desktop OpenClaw app or gateway is already using the same session. "
            f"Use a dedicated bridge session instead, for example: `{suggestion}`"
        )

    async def _invoke_agent(self, message: str, agent_id: str) -> dict:
        """Send one message into the target OpenClaw session and parse JSON output."""
        active_lock = self._read_active_lock(agent_id)
        if active_lock:
            raise RuntimeError(self._format_lock_error(active_lock))

        args = [
            self.openclaw_bin,
            "agent",
            "--session-id",
            self.session_key,
            "--message",
            message,
            "--json",
            "--timeout",
            str(self.agent_timeout_seconds),
        ]
        if self.agent_id:
            args.extend(["--agent", self.agent_id])

        raw = await self._run_command(*args, timeout_seconds=self.agent_timeout_seconds + 5)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            excerpt = raw[:400].replace("\n", " ")
            raise RuntimeError(f"failed to parse OpenClaw response JSON: {excerpt}") from exc

    def _extract_text(self, payload: dict) -> str:
        """Return a clean assistant message from OpenClaw's JSON payload."""
        result = payload.get("result") or {}
        response_parts = []

        for item in result.get("payloads") or []:
            text = (item.get("text") or "").strip()
            media_url = item.get("mediaUrl")
            if text:
                response_parts.append(text)
            elif media_url:
                response_parts.append(f"[media] {media_url}")

        if response_parts:
            return "\n\n".join(response_parts)

        summary = payload.get("summary") or result.get("summary")
        if summary:
            return f"[OpenClaw {summary}]"

        return "[OpenClaw returned no text payload.]"

    async def _push_assistant_message(self, text: str, metadata: Optional[dict] = None) -> None:
        """Publish a clean assistant message to Supabase and relay."""
        self.preview = text[-200:]
        console.print(f"\n[bold cyan]OpenClaw[/bold cyan]: {text}\n")
        await self.sync.push_message("assistant", text, metadata=metadata or {})
        await self.sync.update_status("running", preview=self.preview)
        if self.relay:
            await self.relay.send_output(text)

    async def start(self) -> None:
        """Start the bridge and keep forwarding mobile user input into OpenClaw."""
        health = await self._verify_health()
        agent_id = self.agent_id or health.get("defaultAgentId") or "main"

        session_id = await self.sync.create_session(self.name, "openclaw")
        console.print(f"[bold green]Session created:[/bold green] {session_id}")
        console.print(
            f"[dim]Bridging OpenClaw agent '{agent_id}' session '{self.session_key}' via {self.openclaw_bin}[/dim]"
        )

        self.relay = RelaySync(session_id=session_id, name=self.name, agent_type="openclaw")
        await self.relay.connect()

        intro = (
            f"Connected to OpenClaw session '{self.session_key}'"
            f" (agent '{agent_id}'). Send a message from mobile to continue this conversation."
        )
        await self._push_assistant_message(
            intro,
            metadata={
                "bridge": "openclaw",
                "session_key": self.session_key,
                "agent_id": agent_id,
                "kind": "intro",
            },
        )

        try:
            await self._bridge_loop(agent_id)
        except KeyboardInterrupt:
            console.print("\n[yellow]Stopping OpenClaw bridge...[/yellow]")
        finally:
            await self.sync.close_session(preview=self.preview or intro)
            if self.relay:
                await self.relay.close()

    async def _bridge_loop(self, agent_id: str) -> None:
        """Process mobile user input one message at a time."""
        while True:
            if self.relay and await self.relay.should_stop():
                break

            reply = await self.relay.get_user_input() if self.relay else None
            if not reply:
                await asyncio.sleep(0.1)
                continue

            clean_reply = reply.rstrip("\n")
            await self.sync.push_message(
                "user",
                reply,
                metadata={
                    "bridge": "openclaw",
                    "session_key": self.session_key,
                    "agent_id": agent_id,
                },
            )
            await self.sync.update_status("running", preview=clean_reply[-200:])
            if self.relay:
                await self.relay.send_status("running")

            try:
                result = await asyncio.wait_for(
                    self._invoke_agent(clean_reply, agent_id),
                    timeout=self.agent_timeout_seconds + 10,
                )
                text = self._extract_text(result)
                metadata = {
                    "bridge": "openclaw",
                    "session_key": self.session_key,
                    "agent_id": agent_id,
                    "run_id": result.get("runId"),
                    "summary": result.get("summary"),
                }
            except Exception as exc:
                text = f"[OpenClaw bridge error] {exc}"
                metadata = {
                    "bridge": "openclaw",
                    "session_key": self.session_key,
                    "agent_id": agent_id,
                    "error": True,
                }

            await self._push_assistant_message(text, metadata=metadata)
