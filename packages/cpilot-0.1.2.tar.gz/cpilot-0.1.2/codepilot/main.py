"""CodePilot CLI - AI Coding Agent Mobile Manager."""

import asyncio
import time
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from . import __version__
from .auth import ensure_valid_token, list_devices, login
from .config import clear_token, get_auth, load_config
from .connect import connect_interactive, connect_provider, show_status as show_provider_status

app = typer.Typer(
    name="codepilot",
    help="AI Coding Agent Mobile Manager - manage your agents from anywhere.",
    no_args_is_help=True,
)
auth_app = typer.Typer(help="Authentication commands")
app.add_typer(auth_app, name="auth")

console = Console()


@app.command()
def version():
    """Show version."""
    console.print(f"codepilot v{__version__}")


# ---------------------------------------------------------------------------
# Auth commands
# ---------------------------------------------------------------------------


@auth_app.command("login")
def auth_login(
    email: Optional[str] = typer.Option(None, "--email", "-e", help="Email for direct login"),
):
    """Authenticate with CodePilot.

    Without --email: opens browser OAuth flow.
    With --email: prompts for password directly (no browser needed).
    """
    success = login(email=email)
    if not success:
        raise typer.Exit(1)


@auth_app.command("logout")
def auth_logout():
    """Clear stored credentials."""
    clear_token()
    console.print("[green]Logged out successfully.[/green]")


@auth_app.command("status")
def auth_status():
    """Show current authentication status and user info."""
    auth = get_auth()
    token = auth.get("access_token")

    if not token:
        console.print("[red]Not authenticated.[/red]")
        console.print("Run: [bold]codepilot auth login[/bold]")
        raise typer.Exit(1)

    email = auth.get("email", "unknown")
    user_id = auth.get("user_id", "")
    expires_at = auth.get("expires_at", 0)
    device_id = auth.get("device_id", "")

    # Determine token status
    if expires_at:
        remaining = expires_at - time.time()
        if remaining < 0:
            token_status = "[red]expired[/red]"
        elif remaining < 300:
            token_status = f"[yellow]expires in {int(remaining)}s[/yellow]"
        else:
            hours = int(remaining // 3600)
            mins = int((remaining % 3600) // 60)
            token_status = f"[green]valid ({hours}h {mins}m remaining)[/green]"
    else:
        token_status = "[green]valid[/green]"

    console.print()
    console.print("[bold]Authentication Status[/bold]")
    console.print(f"  Email:     {email}")
    if user_id:
        console.print(f"  User ID:   {user_id[:8]}...")
    if device_id:
        console.print(f"  Device ID: {device_id[:8]}...")
    console.print(f"  Token:     {token_status}")
    console.print()


@auth_app.command("devices")
def auth_devices():
    """List devices registered to your account."""
    token = ensure_valid_token()
    if not token:
        console.print("[red]Not authenticated. Run: codepilot auth login[/red]")
        raise typer.Exit(1)

    devices = list_devices(token)

    if not devices:
        console.print("[dim]No devices registered.[/dim]")
        return

    table = Table(title="Registered Devices")
    table.add_column("Platform", style="cyan")
    table.add_column("Name", style="white")
    table.add_column("Device ID", style="dim")
    table.add_column("Last Seen", style="green")

    for d in devices:
        platform = d.get("platform", "unknown")
        name = d.get("device_name") or "-"
        dev_id = (d.get("id") or "")[:8] + "..."
        last_seen = (d.get("last_seen_at") or d.get("created_at") or "")[:19].replace("T", " ")
        table.add_row(platform, name, dev_id, last_seen)

    console.print(table)


# ---------------------------------------------------------------------------
# Provider connect
# ---------------------------------------------------------------------------


@app.command()
def connect(
    provider: Optional[str] = typer.Argument(
        None,
        help="Provider to connect: claude, codex, opencode. Omit for interactive menu.",
    ),
    status: bool = typer.Option(False, "--status", "-s", help="Show connection status for all providers."),
):
    """Connect an AI provider by storing its API key locally.

    Keys are saved to ~/.codepilot/config.json and auto-injected when
    you run 'codepilot wrap'.

    Examples:
        codepilot connect            # interactive menu
        codepilot connect claude     # set up Anthropic key
        codepilot connect codex      # set up OpenAI key
        codepilot connect --status   # show all connected providers
    """
    if status:
        show_provider_status()
        return

    if provider:
        ok = connect_provider(provider)
    else:
        ok = connect_interactive()

    if not ok:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Agent commands
# ---------------------------------------------------------------------------


@app.command()
def launch(
    agent: str = typer.Argument(
        "claude",
        help="Agent to launch: claude, codex, opencode",
    ),
    name: Optional[str] = typer.Option(
        None, "--name", "-n", help="Session name"
    ),
):
    """Launch an AI agent and show QR code simultaneously.

    Happy-style one-command flow: QR appears immediately,
    start coding now, phone scans anytime.

    Examples:
        codepilot launch           # launch Claude Code (default)
        codepilot launch codex     # launch Codex
        codepilot launch claude --name my-project
    """
    from .launch import launch as _launch

    asyncio.run(_launch(agent=agent, name=name))


@app.command()
def wrap(
    command: str = typer.Argument(
        ...,
        help="Agent command to wrap (e.g., 'claude', 'codex', 'opencode')",
    ),
    name: Optional[str] = typer.Option(
        None, "--name", "-n", help="Session name (defaults to command name)"
    ),
):
    """Wrap an AI agent and sync its I/O to your mobile device.

    Examples:
        codepilot wrap claude
        codepilot wrap codex --name "my-project"
        codepilot wrap "python my_agent.py" --name "custom-agent"
    """
    from .wrapper import AgentWrapper

    token = ensure_valid_token()
    if not token:
        console.print("[red]Not authenticated. Run: codepilot auth login[/red]")
        raise typer.Exit(1)

    agent_type = "custom"
    if "claude" in command.lower():
        agent_type = "claude-code"
    elif "codex" in command.lower():
        agent_type = "codex"
    elif "opencode" in command.lower():
        agent_type = "opencode"
    elif "openclaw" in command.lower():
        agent_type = "openclaw"

    session_name = name or command.split()[0]

    wrapper = AgentWrapper(
        command=command,
        agent_type=agent_type,
        name=session_name,
    )

    console.print(f"[bold]Wrapping agent:[/bold] {command}")
    console.print(f"[bold]Session name:[/bold]  {session_name}")
    console.print(f"[bold]Agent type:[/bold]    {agent_type}")
    console.print()

    asyncio.run(wrapper.start())


@app.command("openclaw")
def openclaw_bridge(
    session: str = typer.Option(
        "main",
        "--session",
        "-s",
        help=(
            "OpenClaw session key to bridge. "
            "Use a dedicated key like 'codepilot-main' if the desktop OpenClaw app already owns 'main'."
        ),
    ),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="OpenClaw agent id (defaults to OpenClaw's default agent)"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="CodePilot session name"),
    bin_path: Optional[str] = typer.Option(None, "--bin", help="Path to the openclaw executable"),
):
    """Bridge an OpenClaw conversation into CodePilot using structured JSON replies."""
    from .openclaw_bridge import OpenClawBridge

    token = ensure_valid_token()
    if not token:
        console.print("[red]Not authenticated. Run: codepilot auth login[/red]")
        raise typer.Exit(1)

    session_name = name or f"openclaw-{session}"
    bridge = OpenClawBridge(
        name=session_name,
        session_key=session,
        agent_id=agent,
        openclaw_bin=bin_path,
    )
    asyncio.run(bridge.start())


@app.command()
def status():
    """Show status of all active agent sessions."""
    from rich.table import Table
    import httpx

    from .config import SUPABASE_ANON_KEY, SUPABASE_URL

    token = ensure_valid_token()
    if not token:
        console.print("[red]Not authenticated. Run: codepilot auth login[/red]")
        raise typer.Exit(1)

    try:
        import urllib.request

        url = f"{SUPABASE_URL}/rest/v1/sessions?status=in.(running,waiting_input)&order=updated_at.desc&limit=20"
        req = urllib.request.Request(
            url,
            headers={
                "apikey": SUPABASE_ANON_KEY,
                "Authorization": f"Bearer {token}",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            sessions = __import__("json").loads(resp.read())
    except Exception as e:
        console.print(f"[red]Failed to fetch sessions:[/red] {e}")
        raise typer.Exit(1)

    if not sessions:
        console.print("[dim]No active sessions.[/dim]")
        return

    table = Table(title="Active Sessions")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="magenta")
    table.add_column("Status", style="green")
    table.add_column("Last Update")
    table.add_column("Preview")

    for s in sessions:
        status_color = {
            "running": "green",
            "waiting_input": "yellow",
            "completed": "dim",
            "error": "red",
        }.get(s.get("status", ""), "white")

        table.add_row(
            s.get("name", ""),
            s.get("agent_type", ""),
            f"[{status_color}]{s.get('status', '')}[/{status_color}]",
            (s.get("updated_at") or "")[:19].replace("T", " "),
            (s.get("last_message_preview") or "")[:60],
        )

    console.print(table)


@app.command()
def start(
    name: Optional[str] = typer.Option(
        None, "--name", "-n", help="Session name (e.g. 'my-project')"
    ),
):
    """Pair your phone and start an AI agent session.

    Displays a QR code — open the Codepilot app and scan it.
    Your phone will automatically connect when the agent starts.

    Examples:
        codepilot start
        codepilot start --name "my-project"
    """
    from .pairing import generate_token, register_pairing, wait_for_pairing

    token = ensure_valid_token()
    if not token:
        console.print("[red]Not authenticated. Run: codepilot auth login[/red]")
        raise typer.Exit(1)

    session_name = name or "my-agent"
    pair_token = generate_token()

    console.print(f"\n[bold]CodePilot[/bold] — 氛围编程 🎶")
    console.print(f"[dim]Session: {session_name}[/dim]\n")

    # Register pairing token with relay
    if not register_pairing(pair_token, token, session_name):
        console.print("[red]Could not reach relay server. Check your connection.[/red]")
        raise typer.Exit(1)

    # Block until phone scans QR
    try:
        session_id = asyncio.run(wait_for_pairing(pair_token, token))
    except KeyboardInterrupt:
        console.print("\n[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    if not session_id:
        raise typer.Exit(1)

    console.print(f"\n[green]✅ Phone connected![/green]")
    console.print("\nNow start your agent:\n")
    console.print(f"  [bold]codepilot wrap claude --name {session_name}[/bold]      # Claude Code")
    console.print(f"  [bold]codepilot wrap codex --name {session_name}[/bold]       # Codex")
    console.print(f"  [bold]codepilot openclaw --name {session_name}[/bold]         # OpenClaw")
    console.print(f"  [bold]codepilot wrap 'python agent.py' --name {session_name}[/bold]  # Custom\n")


if __name__ == "__main__":
    app()
