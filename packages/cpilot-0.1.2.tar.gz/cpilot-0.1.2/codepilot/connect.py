"""codepilot connect — interactive AI provider setup wizard."""

import json
import os
import subprocess
import sys
import webbrowser
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from .config import load_config, save_config

console = Console()

# Provider metadata
PROVIDERS = {
    "claude": {
        "label": "Claude Code (Anthropic)",
        "env_var": "ANTHROPIC_API_KEY",
        "key_prefix": "sk-ant-",
        "key_url": "https://console.anthropic.com/account/keys",
        "validate_url": "https://api.anthropic.com/v1/models",
        "validate_headers": lambda key: {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
        },
        "hint": "Create a key at console.anthropic.com → Settings → API Keys",
    },
    "codex": {
        "label": "Codex / OpenAI",
        "env_var": "OPENAI_API_KEY",
        "key_prefix": "sk-",
        "key_url": "https://platform.openai.com/api-keys",
        "validate_url": "https://api.openai.com/v1/models",
        "validate_headers": lambda key: {"Authorization": f"Bearer {key}"},
        "hint": "Create a key at platform.openai.com → API Keys",
    },
    "opencode": {
        "label": "OpenCode",
        "env_var": "OPENAI_API_KEY",  # opencode uses OPENAI_API_KEY by default
        "key_prefix": "sk-",
        "key_url": "https://platform.openai.com/api-keys",
        "validate_url": "https://api.openai.com/v1/models",
        "validate_headers": lambda key: {"Authorization": f"Bearer {key}"},
        "hint": "OpenCode uses your OpenAI key. Create one at platform.openai.com → API Keys",
    },
}


def _validate_key(provider_id: str, api_key: str) -> bool:
    """Test the API key with a lightweight models list call."""
    import urllib.error
    import urllib.request

    p = PROVIDERS[provider_id]
    try:
        req = urllib.request.Request(
            p["validate_url"],
            headers=p["validate_headers"](api_key),
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            return resp.status == 200
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return False
        # Other HTTP errors (403, 429, etc.) don't mean the key is wrong
        return e.code not in (401,)
    except Exception:
        # Network error — assume key is valid, can't verify
        console.print("[yellow]Could not reach the server to validate. Key saved anyway.[/yellow]")
        return True


def _save_provider_key(provider_id: str, api_key: str) -> None:
    config = load_config()
    if "providers" not in config:
        config["providers"] = {}
    config["providers"][provider_id] = {"api_key": api_key}
    save_config(config)


def _get_provider_key(provider_id: str) -> Optional[str]:
    config = load_config()
    return config.get("providers", {}).get(provider_id, {}).get("api_key")


def connect_provider(provider_id: str) -> bool:
    """Interactive wizard to set up a single provider. Returns True on success."""
    if provider_id not in PROVIDERS:
        console.print(f"[red]Unknown provider: {provider_id}[/red]")
        console.print(f"Available: {', '.join(PROVIDERS.keys())}")
        return False

    p = PROVIDERS[provider_id]

    console.print()
    console.print(Panel(
        f"[bold]{p['label']}[/bold]\n\n{p['hint']}",
        title="[blue]Connect Provider[/blue]",
        border_style="blue",
    ))
    console.print()

    # Check if already connected
    existing = _get_provider_key(provider_id)
    if existing:
        masked = existing[:10] + "***"
        console.print(f"[dim]Already connected: {masked}[/dim]")
        overwrite = Prompt.ask("Replace existing key?", choices=["y", "n"], default="n")
        if overwrite.lower() != "y":
            console.print("[dim]Keeping existing key.[/dim]")
            return True

    # Open browser to API key page
    console.print(f"[dim]Opening browser → {p['key_url']}[/dim]")
    try:
        webbrowser.open(p["key_url"])
    except Exception:
        console.print(f"[dim]Couldn't open browser. Visit: {p['key_url']}[/dim]")

    console.print()
    api_key = Prompt.ask(f"Paste your {p['label']} API key", password=True)
    api_key = api_key.strip()

    if not api_key:
        console.print("[red]No key entered. Aborted.[/red]")
        return False

    # Basic format check
    if p["key_prefix"] and not api_key.startswith(p["key_prefix"]):
        console.print(f"[yellow]Warning: expected key starting with '{p['key_prefix']}'[/yellow]")

    # Validate
    console.print("[dim]Validating key...[/dim]")
    with console.status("Checking with provider API..."):
        valid = _validate_key(provider_id, api_key)

    if not valid:
        console.print("[red]Key validation failed — the key may be invalid or revoked.[/red]")
        retry = Prompt.ask("Save anyway?", choices=["y", "n"], default="n")
        if retry.lower() != "y":
            return False

    _save_provider_key(provider_id, api_key)
    console.print(f"[green]✅ {p['label']} connected![/green]")
    console.print(f"[dim]Stored in ~/.codepilot/config.json (mode 600)[/dim]")
    console.print()
    console.print(f"Now run your agent with:")
    console.print(f"  [bold]codepilot wrap {provider_id} --name my-project[/bold]")
    return True


def connect_interactive() -> bool:
    """Show a provider menu if no provider was specified."""
    console.print()
    console.print(Panel(
        "[bold]Connect an AI provider[/bold]\n\n"
        "Your API key will be stored locally in [dim]~/.codepilot/config.json[/dim]\n"
        "and injected automatically when you run [bold]codepilot wrap[/bold].",
        title="[blue]codepilot connect[/blue]",
        border_style="blue",
    ))
    console.print()

    config = load_config()
    connected = set(config.get("providers", {}).keys())

    choices = []
    for pid, meta in PROVIDERS.items():
        status = "[green]✓[/green]" if pid in connected else "[dim]○[/dim]"
        choices.append(f"  {status} [bold]{pid}[/bold] — {meta['label']}")

    for c in choices:
        console.print(c)

    console.print()
    provider_id = Prompt.ask(
        "Which provider to connect?",
        choices=list(PROVIDERS.keys()),
    )
    return connect_provider(provider_id)


def get_provider_env(agent_type: str) -> dict:
    """Return env vars dict for the given agent type, merging stored keys over os.environ."""
    # Map agent_type -> provider_id
    mapping = {
        "claude-code": "claude",
        "claude": "claude",
        "codex": "codex",
        "opencode": "opencode",
    }
    provider_id = mapping.get(agent_type)
    if not provider_id:
        return {}

    api_key = _get_provider_key(provider_id)
    if not api_key:
        return {}

    env_var = PROVIDERS[provider_id]["env_var"]
    return {env_var: api_key}


def show_status() -> None:
    """Print a table of connected providers."""
    from rich.table import Table

    config = load_config()
    providers_config = config.get("providers", {})

    table = Table(title="Connected Providers", show_header=True)
    table.add_column("Provider", style="cyan")
    table.add_column("Label")
    table.add_column("Status", style="green")
    table.add_column("Key (masked)")

    for pid, meta in PROVIDERS.items():
        entry = providers_config.get(pid, {})
        key = entry.get("api_key", "")
        if key:
            status = "[green]Connected[/green]"
            masked = key[:10] + "***"
        else:
            status = "[dim]Not set[/dim]"
            masked = "[dim]—[/dim]"
        table.add_row(pid, meta["label"], status, masked)

    console.print()
    console.print(table)
    console.print()
