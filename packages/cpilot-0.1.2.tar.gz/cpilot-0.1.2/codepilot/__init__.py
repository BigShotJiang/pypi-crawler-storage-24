"""CodePilot - AI Coding Agent Mobile Manager CLI"""

__version__ = "0.1.0"
