"""Supabase Realtime sync - push agent messages to cloud."""

import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Optional

import httpx
import websockets
from websockets.protocol import State

from .config import RELAY_WS, SUPABASE_ANON_KEY, SUPABASE_URL, get_token


class SupabaseSync:
    """Sync agent sessions and messages to Supabase."""

    def __init__(self):
        self.token = get_token()
        self.session_id: Optional[str] = None
        self.headers = {
            "apikey": SUPABASE_ANON_KEY,
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        }
        self.base_url = f"{SUPABASE_URL}/rest/v1"
        self._client_kwargs = {
            "trust_env": False,
            "timeout": httpx.Timeout(20.0),
        }

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Perform a Supabase REST request with a few retries for transient failures."""
        last_error = None
        for attempt in range(3):
            try:
                async with httpx.AsyncClient(**self._client_kwargs) as client:
                    resp = await client.request(
                        method,
                        f"{self.base_url}{path}",
                        headers=self.headers,
                        **kwargs,
                    )
                    resp.raise_for_status()
                    return resp
            except httpx.HTTPError as exc:
                last_error = exc
                await asyncio.sleep(0.5 * (attempt + 1))
        raise last_error

    async def create_session(self, name: str, agent_type: str) -> str:
        """Create a new agent session in Supabase."""
        self.session_id = str(uuid.uuid4())
        await self._request(
            "POST",
            "/sessions",
            json={
                "id": self.session_id,
                "name": name,
                "agent_type": agent_type,
                "status": "running",
                "started_at": datetime.now(timezone.utc).isoformat(),
            },
        )
        return self.session_id

    async def push_message(self, role: str, content: str, metadata: dict = None) -> None:
        """Push a message to Supabase."""
        if not self.session_id:
            return
        try:
            await self._request(
                "POST",
                "/messages",
                json={
                    "session_id": self.session_id,
                    "role": role,
                    "content": content,
                    "metadata": metadata or {},
                },
            )
        except httpx.HTTPError:
            return

    async def update_status(self, status: str, preview: str = None) -> None:
        """Update session status (running, waiting_input, completed, error)."""
        if not self.session_id:
            return
        data = {
            "status": status,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        if preview:
            data["last_message_preview"] = preview[:200]
        try:
            await self._request(
                "PATCH",
                f"/sessions?id=eq.{self.session_id}",
                json=data,
            )
        except httpx.HTTPError:
            return

    async def check_user_reply(self) -> Optional[str]:
        """Check if user sent a reply from mobile."""
        if not self.session_id:
            return None
        try:
            resp = await self._request(
                "GET",
                "/messages",
                params={
                    "session_id": f"eq.{self.session_id}",
                    "role": "eq.user",
                    "order": "created_at.desc",
                    "limit": "1",
                },
            )
            messages = resp.json()
            if messages:
                return messages[0]["content"]
        except httpx.HTTPError:
            return None
        return None

    async def close_session(self, preview: str = None) -> None:
        """Mark session as completed."""
        await self.update_status("completed", preview=preview)


class RelaySync:
    """Real-time relay over WebSocket for live agent streaming."""

    def __init__(self, session_id: str, name: str, agent_type: str):
        self.session_id = session_id
        self.name = name
        self.agent_type = agent_type
        from .auth import ensure_valid_token
        from urllib.parse import quote
        token = ensure_valid_token() or ""
        url_params = (
            f"role=cli&session={quote(session_id)}&name={quote(name)}"
            f"&agent={quote(agent_type)}&token={quote(token)}"
        )
        self._url = f"{RELAY_WS}?{url_params}"
        self._ws = None
        self._recv_queue: asyncio.Queue = asyncio.Queue()
        self._stop_queue: asyncio.Queue = asyncio.Queue()
        self._recv_task = None

    def _is_connected(self) -> bool:
        """Return True when the websocket is open."""
        return bool(self._ws and getattr(self._ws, "state", None) == State.OPEN)

    async def connect(self) -> None:
        """Connect to the relay server and start background receiver."""
        # Explicitly bypass host proxy settings; the relay is a direct LAN/WAN socket.
        last_error = None
        for attempt in range(3):
            try:
                self._ws = await websockets.connect(self._url, proxy=None)
                self._recv_task = asyncio.create_task(self._recv_loop())
                return
            except Exception as exc:
                last_error = exc
                await asyncio.sleep(0.5 * (attempt + 1))
        raise last_error

    async def _recv_loop(self) -> None:
        """Receive messages from relay and route to queues."""
        try:
            async for raw in self._ws:
                try:
                    msg = json.loads(raw)
                    if msg.get("type") == "user_input" and msg.get("content"):
                        await self._recv_queue.put(msg["content"])
                    elif msg.get("type") == "stop_agent":
                        await self._stop_queue.put(True)
                except (json.JSONDecodeError, KeyError):
                    pass
        except websockets.exceptions.ConnectionClosed:
            pass

    async def send_output(self, content: str, status: str = "running") -> None:
        """Send agent output to relay."""
        if self._is_connected():
            await self._ws.send(json.dumps({
                "type": "agent_output",
                "content": content,
                "status": status,
            }))

    async def send_status(self, status: str) -> None:
        """Send status update to relay."""
        if self._is_connected():
            await self._ws.send(json.dumps({
                "type": "status_update",
                "status": status,
            }))

    async def send_tool_call(self, tool_name: str, tool_input: dict) -> None:
        """Send a tool call event to relay so mobile can display it."""
        if self._is_connected():
            await self._ws.send(json.dumps({
                "type": "tool_call",
                "tool_name": tool_name,
                "tool_input": tool_input,
            }))

    async def send_tool_result(self, tool_name: str, tool_output: dict) -> None:
        """Send a tool result event to relay so mobile can display it."""
        if self._is_connected():
            await self._ws.send(json.dumps({
                "type": "tool_result",
                "tool_name": tool_name,
                "tool_output": tool_output,
            }))

    async def get_user_input(self) -> Optional[str]:
        """Non-blocking check for user input from relay."""
        try:
            return self._recv_queue.get_nowait()
        except asyncio.QueueEmpty:
            return None

    async def should_stop(self) -> bool:
        """Non-blocking check for stop signal from relay."""
        try:
            self._stop_queue.get_nowait()
            return True
        except asyncio.QueueEmpty:
            return False

    async def close(self) -> None:
        """Close WebSocket connection and cancel receiver task."""
        if self._recv_task:
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
        if self._ws:
            await self._ws.close()
