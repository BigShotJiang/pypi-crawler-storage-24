"""Pairing logic — generate a token, display QR code, poll for mobile scan."""

import asyncio
import json
import os
import secrets
import urllib.request
from typing import Optional

from rich.console import Console
from rich.panel import Panel

console = Console()

RELAY_HOST = os.environ.get("CODEPILOT_RELAY", "ws://129.204.224.145:4000")
RELAY_HTTP = RELAY_HOST.replace("ws://", "http://").replace("wss://", "https://")

PAIR_TIMEOUT_SECONDS = 300   # 5 minutes
POLL_INTERVAL_SECONDS = 2


def generate_token() -> str:
    """Generate a cryptographically random pairing token."""
    return secrets.token_urlsafe(24)


def register_pairing(token: str, user_token: str, session_name: str, agent_type: str = "claude-code") -> bool:
    """Register the pairing token with the relay server."""
    payload = json.dumps({
        "token": token,
        "session_name": session_name,
        "agent_type": agent_type,
    }).encode()

    try:
        req = urllib.request.Request(
            f"{RELAY_HTTP}/pair/register",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {user_token}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception as e:
        console.print(f"[red]Failed to register pairing with relay: {e}[/red]")
        return False


def poll_pairing_status(token: str, user_token: str) -> Optional[str]:
    """Poll the relay for pairing confirmation. Returns session_id if paired."""
    try:
        req = urllib.request.Request(
            f"{RELAY_HTTP}/pair/status?token={token}",
            headers={"Authorization": f"Bearer {user_token}"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            if data.get("paired"):
                return data.get("session_id")
    except Exception:
        pass
    return None


def display_qr(token: str) -> None:
    """Print QR code to terminal. Falls back to URL if qrcode not installed."""
    deep_link = f"codepilot://pair?token={token}&relay={RELAY_HTTP}"

    try:
        import qrcode  # type: ignore
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=1,
            border=2,
        )
        qr.add_data(deep_link)
        qr.make(fit=True)

        console.print()
        console.print(
            Panel(
                "[bold white]用手机 Codepilot 扫描下方二维码[/bold white]\n"
                "[dim]Open Codepilot app → tap Scan[/dim]",
                style="blue",
                padding=(0, 2),
            )
        )
        console.print()
        # Print QR to stdout directly (bypasses rich)
        qr.print_ascii(tty=False)
        console.print()

    except ImportError:
        # qrcode not installed — show URL as fallback
        console.print()
        console.print(Panel(
            f"[bold]Pairing URL[/bold]\n[dim]{deep_link}[/dim]\n\n"
            "[yellow]Tip: install qrcode for a scannable QR code: pip install qrcode[/yellow]",
            style="blue",
        ))
        console.print()


async def wait_for_pairing(token: str, user_token: str) -> Optional[str]:
    """Display QR and block until mobile pairs or timeout."""
    display_qr(token)
    console.print("[dim]⏳ Waiting for phone to scan... (Ctrl+C to cancel)[/dim]")

    elapsed = 0
    while elapsed < PAIR_TIMEOUT_SECONDS:
        session_id = poll_pairing_status(token, user_token)
        if session_id:
            return session_id
        await asyncio.sleep(POLL_INTERVAL_SECONDS)
        elapsed += POLL_INTERVAL_SECONDS

        # Show countdown at 1 minute remaining
        if PAIR_TIMEOUT_SECONDS - elapsed == 60:
            console.print("[yellow]⚠️  QR code expires in 1 minute[/yellow]")

    console.print("[red]❌ Pairing timed out. Run 'codepilot start' again.[/red]")
    return None
