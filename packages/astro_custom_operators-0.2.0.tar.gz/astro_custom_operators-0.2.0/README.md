# astro-custom-operators

Custom Apache Airflow operators for the Astro workflow builder.

## Operators

- **SlackChannelReadOperator** — Read messages from a Slack channel or thread with automatic channel name-to-ID resolution and pagination.
- **SlackChannelWriteOperator** — Post, reply to, or update messages in a Slack channel with automatic channel name-to-ID resolution.

## Installation

```bash
pip install astro-custom-operators
```

## Usage

```python
from custom_operators.slack_channel import SlackChannelReadOperator, SlackChannelWriteOperator

read_messages = SlackChannelReadOperator(
    task_id="read_slack",
    channel="general",
    limit=50,
)

post_message = SlackChannelWriteOperator(
    task_id="post_slack",
    channel="general",
    text="Hello from Airflow!",
)
```

Requires a Slack connection configured in Airflow (default conn id: `slack_default`).
