"""
QuarterBit AXIOM - Memory-Efficient Training
=============================================

Usage:
    from quarterbit import axiom

    results = axiom(
        model='gpt2-large',
        train_loader=train_loader,
        val_loader=val_loader,
        steps=1000,
    )

70% better validation improvement, 2x less memory than FP16+AdamW.

Free during beta - https://quarterbit.dev
"""

__version__ = "25.0.6"
__author__ = "Clouthier Simulation Labs"

# Check PyTorch
try:
    import torch as _torch
    _HAS_TORCH = True
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "QuarterBit: CUDA not available. GPU required for full performance.",
            RuntimeWarning
        )
except ImportError:
    _HAS_TORCH = False
    import warnings
    warnings.warn(
        "QuarterBit: PyTorch not found. Install from https://pytorch.org/get-started/locally/",
        ImportWarning
    )

# Main exports (requires PyTorch)
if _HAS_TORCH:
    from .axiom import axiom

    __all__ = [
        "axiom",
        "__version__",
    ]
else:
    __all__ = ["__version__"]
