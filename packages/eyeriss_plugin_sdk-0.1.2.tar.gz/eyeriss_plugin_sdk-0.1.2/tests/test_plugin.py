"""Tests for eyeriss_plugin_sdk.plugin — EyerissPlugin ABC."""

import pytest

from eyeriss_plugin_sdk import EyerissPlugin
from eyeriss_plugin_sdk.types import PluginContext, PluginResult, SerializedRequest


def _make_context():
    return PluginContext(
        request=SerializedRequest(
            method="GET", path="/test",
            headers={}, query_params={},
        ),
        application_id=1, endpoint_id=1,
        auth_result={}, request_id="test-id",
        client_ip="127.0.0.1",
    )


class _MinimalPlugin(EyerissPlugin):
    @property
    def plugin_id(self) -> str:
        return "test-minimal-plugin"


class TestEyerissPluginABC:

    def test_cannot_instantiate_directly(self):
        with pytest.raises(TypeError):
            EyerissPlugin()

    def test_must_implement_plugin_id(self):
        class Incomplete(EyerissPlugin):
            pass

        with pytest.raises(TypeError):
            Incomplete()

    def test_minimal_subclass_instantiates(self):
        plugin = _MinimalPlugin()
        assert plugin.plugin_id == "test-minimal-plugin"


class TestDefaultHooks:

    @pytest.mark.asyncio
    async def test_pre_request_returns_proceed(self):
        plugin = _MinimalPlugin()
        result = await plugin.pre_request(_make_context())
        assert isinstance(result, PluginResult)
        assert result.proceed is True

    @pytest.mark.asyncio
    async def test_post_response_returns_proceed(self):
        plugin = _MinimalPlugin()
        result = await plugin.post_response(_make_context())
        assert isinstance(result, PluginResult)
        assert result.proceed is True

    @pytest.mark.asyncio
    async def test_on_error_returns_none(self):
        plugin = _MinimalPlugin()
        result = await plugin.on_error(_make_context(), {"error": "timeout"})
        assert result is None

    @pytest.mark.asyncio
    async def test_initialize_returns_none(self):
        plugin = _MinimalPlugin()
        result = await plugin.initialize()
        assert result is None

    @pytest.mark.asyncio
    async def test_configure_returns_none(self):
        plugin = _MinimalPlugin()
        result = await plugin.configure({"key": "value"})
        assert result is None

    @pytest.mark.asyncio
    async def test_cleanup_returns_none(self):
        plugin = _MinimalPlugin()
        result = await plugin.cleanup()
        assert result is None
