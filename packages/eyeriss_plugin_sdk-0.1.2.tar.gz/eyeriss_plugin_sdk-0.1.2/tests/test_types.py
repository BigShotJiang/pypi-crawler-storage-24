"""Tests for eyeriss_plugin_sdk.types — serialization, deserialization, roundtrips."""

import base64

from eyeriss_plugin_sdk.types import (
    ErrorResponse,
    PluginContext,
    PluginResult,
    SerializedRequest,
)


# ---------------------------------------------------------------------------
# SerializedRequest
# ---------------------------------------------------------------------------

class TestSerializedRequest:

    def test_to_dict_with_body(self):
        req = SerializedRequest(
            method="POST", path="/api/v1/data",
            headers={"content-type": "application/json"},
            query_params={"page": "1"},
            content_type="application/json",
            body=b'{"key": "value"}',
        )
        d = req.to_dict()
        assert d["method"] == "POST"
        assert d["path"] == "/api/v1/data"
        assert d["headers"] == {"content-type": "application/json"}
        assert d["query_params"] == {"page": "1"}
        assert d["content_type"] == "application/json"
        assert d["body_encoding"] == "base64"
        assert base64.b64decode(d["body"]) == b'{"key": "value"}'

    def test_to_dict_without_body(self):
        req = SerializedRequest(
            method="GET", path="/healthz",
            headers={}, query_params={},
        )
        d = req.to_dict()
        assert d["body"] is None
        assert "body_encoding" not in d

    def test_from_dict_base64_body(self):
        encoded = base64.b64encode(b"hello").decode("ascii")
        d = {
            "method": "PUT", "path": "/items/1",
            "headers": {}, "query_params": {},
            "body": encoded, "body_encoding": "base64",
        }
        req = SerializedRequest.from_dict(d)
        assert req.body == b"hello"

    def test_from_dict_string_body(self):
        d = {
            "method": "POST", "path": "/data",
            "headers": {}, "query_params": {},
            "body": "plain text",
        }
        req = SerializedRequest.from_dict(d)
        assert req.body == b"plain text"

    def test_from_dict_bytes_body(self):
        d = {
            "method": "POST", "path": "/data",
            "headers": {}, "query_params": {},
            "body": b"raw bytes",
        }
        req = SerializedRequest.from_dict(d)
        assert req.body == b"raw bytes"

    def test_from_dict_none_body(self):
        d = {
            "method": "GET", "path": "/",
            "headers": {}, "query_params": {},
            "body": None,
        }
        req = SerializedRequest.from_dict(d)
        assert req.body is None

    def test_from_dict_missing_optional_fields(self):
        d = {"method": "GET", "path": "/test"}
        req = SerializedRequest.from_dict(d)
        assert req.headers == {}
        assert req.query_params == {}
        assert req.content_type == ""
        assert req.body is None

    def test_roundtrip(self):
        original = SerializedRequest(
            method="PATCH", path="/users/42",
            headers={"authorization": "Bearer tok"},
            query_params={"fields": "name,email"},
            content_type="application/json",
            body=b'{"name": "Alice"}',
        )
        restored = SerializedRequest.from_dict(original.to_dict())
        assert restored.method == original.method
        assert restored.path == original.path
        assert restored.headers == original.headers
        assert restored.query_params == original.query_params
        assert restored.content_type == original.content_type
        assert restored.body == original.body

    def test_roundtrip_no_body(self):
        original = SerializedRequest(
            method="DELETE", path="/items/7",
            headers={}, query_params={},
        )
        restored = SerializedRequest.from_dict(original.to_dict())
        assert restored.body is None

    def test_defaults(self):
        req = SerializedRequest(method="GET", path="/", headers={}, query_params={})
        assert req.content_type == ""
        assert req.body is None


# ---------------------------------------------------------------------------
# ErrorResponse
# ---------------------------------------------------------------------------

class TestErrorResponse:

    def test_to_dict_without_headers(self):
        err = ErrorResponse(status_code=403, body={"error": "forbidden"})
        d = err.to_dict()
        assert d == {"status_code": 403, "body": {"error": "forbidden"}}
        assert "headers" not in d

    def test_to_dict_with_headers(self):
        err = ErrorResponse(
            status_code=429, body={"error": "rate limited"},
            headers={"Retry-After": "60"},
        )
        d = err.to_dict()
        assert d["headers"] == {"Retry-After": "60"}

    def test_from_dict(self):
        d = {"status_code": 500, "body": {"error": "internal"}, "headers": {"X-Req-Id": "abc"}}
        err = ErrorResponse.from_dict(d)
        assert err.status_code == 500
        assert err.body == {"error": "internal"}
        assert err.headers == {"X-Req-Id": "abc"}

    def test_from_dict_no_headers(self):
        d = {"status_code": 401, "body": {"error": "unauthorized"}}
        err = ErrorResponse.from_dict(d)
        assert err.headers is None

    def test_roundtrip(self):
        original = ErrorResponse(status_code=422, body={"detail": "invalid"}, headers={"X-Error": "yes"})
        restored = ErrorResponse.from_dict(original.to_dict())
        assert restored.status_code == original.status_code
        assert restored.body == original.body
        assert restored.headers == original.headers


# ---------------------------------------------------------------------------
# PluginResult
# ---------------------------------------------------------------------------

class TestPluginResult:

    def test_defaults(self):
        result = PluginResult()
        assert result.proceed is True
        assert result.modified_headers is None
        assert result.modified_body is None
        assert result.error_response is None

    def test_to_dict_minimal(self):
        result = PluginResult()
        assert result.to_dict() == {"proceed": True}

    def test_to_dict_with_headers(self):
        result = PluginResult(modified_headers={"X-Custom": "val"})
        d = result.to_dict()
        assert d["modified_headers"] == {"X-Custom": "val"}

    def test_to_dict_with_body(self):
        result = PluginResult(modified_body=b"new body")
        d = result.to_dict()
        assert d["modified_body_encoding"] == "base64"
        assert base64.b64decode(d["modified_body"]) == b"new body"

    def test_to_dict_with_error_response(self):
        err = ErrorResponse(status_code=403, body={"msg": "blocked"})
        result = PluginResult(proceed=False, error_response=err)
        d = result.to_dict()
        assert d["proceed"] is False
        assert d["error_response"]["status_code"] == 403

    def test_from_dict_minimal(self):
        result = PluginResult.from_dict({"proceed": True})
        assert result.proceed is True
        assert result.modified_body is None
        assert result.error_response is None

    def test_from_dict_defaults_proceed_true(self):
        result = PluginResult.from_dict({})
        assert result.proceed is True

    def test_from_dict_with_body(self):
        encoded = base64.b64encode(b"modified").decode("ascii")
        result = PluginResult.from_dict({
            "proceed": True,
            "modified_body": encoded,
            "modified_body_encoding": "base64",
        })
        assert result.modified_body == b"modified"

    def test_from_dict_with_raw_bytes_body(self):
        result = PluginResult.from_dict({
            "proceed": True,
            "modified_body": b"raw",
        })
        assert result.modified_body == b"raw"

    def test_from_dict_with_error_response(self):
        result = PluginResult.from_dict({
            "proceed": False,
            "error_response": {"status_code": 429, "body": {"error": "throttled"}},
        })
        assert result.proceed is False
        assert result.error_response.status_code == 429

    def test_roundtrip_full(self):
        err = ErrorResponse(status_code=503, body={"error": "unavailable"}, headers={"Retry-After": "30"})
        original = PluginResult(
            proceed=False,
            modified_headers={"X-Plugin": "test"},
            modified_body=b"replacement",
            error_response=err,
        )
        restored = PluginResult.from_dict(original.to_dict())
        assert restored.proceed == original.proceed
        assert restored.modified_headers == original.modified_headers
        assert restored.modified_body == original.modified_body
        assert restored.error_response.status_code == original.error_response.status_code
        assert restored.error_response.body == original.error_response.body
        assert restored.error_response.headers == original.error_response.headers


# ---------------------------------------------------------------------------
# PluginContext
# ---------------------------------------------------------------------------

class TestPluginContext:

    def _make_request(self):
        return SerializedRequest(
            method="POST", path="/api/test",
            headers={"content-type": "application/json"},
            query_params={"q": "search"},
            content_type="application/json",
            body=b'{"data": 1}',
        )

    def test_to_dict(self):
        ctx = PluginContext(
            request=self._make_request(),
            application_id=10, endpoint_id=20,
            auth_result={"user_id": "u1", "role": "admin"},
            request_id="req-abc-123",
            client_ip="192.168.1.100",
        )
        d = ctx.to_dict()
        assert d["application_id"] == 10
        assert d["endpoint_id"] == 20
        assert d["auth_result"]["user_id"] == "u1"
        assert d["request_id"] == "req-abc-123"
        assert d["client_ip"] == "192.168.1.100"
        assert d["request"]["method"] == "POST"

    def test_from_dict(self):
        req_dict = self._make_request().to_dict()
        d = {
            "request": req_dict,
            "application_id": 5, "endpoint_id": 15,
            "auth_result": {"authenticated": True},
            "request_id": "req-xyz",
            "client_ip": "10.0.0.1",
        }
        ctx = PluginContext.from_dict(d)
        assert ctx.application_id == 5
        assert ctx.request.method == "POST"
        assert ctx.request.body == b'{"data": 1}'

    def test_from_dict_default_auth_result(self):
        req_dict = self._make_request().to_dict()
        d = {
            "request": req_dict,
            "application_id": 1, "endpoint_id": 2,
            "request_id": "r1", "client_ip": "0.0.0.0",
        }
        ctx = PluginContext.from_dict(d)
        assert ctx.auth_result == {}

    def test_roundtrip(self):
        original = PluginContext(
            request=self._make_request(),
            application_id=42, endpoint_id=99,
            auth_result={"scope": "read:all"},
            request_id="roundtrip-id",
            client_ip="203.0.113.50",
        )
        restored = PluginContext.from_dict(original.to_dict())
        assert restored.application_id == original.application_id
        assert restored.endpoint_id == original.endpoint_id
        assert restored.auth_result == original.auth_result
        assert restored.request_id == original.request_id
        assert restored.client_ip == original.client_ip
        assert restored.request.method == original.request.method
        assert restored.request.body == original.request.body
