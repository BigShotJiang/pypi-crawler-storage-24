"""
Eyeriss Plugin SDK for Python

Provides the base class and data types for building Python plugins
for the Eyeriss API Gateway.

Usage:
    from eyeriss_plugin_sdk import EyerissPlugin
    from eyeriss_plugin_sdk.types import PluginContext, PluginResult, ErrorResponse

    class Plugin(EyerissPlugin):
        @property
        def plugin_id(self) -> str:
            return "my-plugin"

        async def pre_request(self, context: PluginContext) -> PluginResult:
            return PluginResult(proceed=True)
"""

from eyeriss_plugin_sdk.plugin import EyerissPlugin
from eyeriss_plugin_sdk.types import (
    ErrorResponse,
    PluginContext,
    PluginResult,
    SerializedRequest,
)

__all__ = [
    "EyerissPlugin",
    "ErrorResponse",
    "PluginContext",
    "PluginResult",
    "SerializedRequest",
]

__version__ = "0.1.0"
