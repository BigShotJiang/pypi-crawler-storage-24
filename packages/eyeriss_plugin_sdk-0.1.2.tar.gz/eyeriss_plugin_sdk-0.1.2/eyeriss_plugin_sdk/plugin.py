"""
EyerissPlugin Abstract Base Class

Base class for all Python plugins in the Eyeriss Gateway. Plugin authors
subclass this and implement the hooks they need. Default implementations
return proceed=True so plugins only need to override hooks they care about.
"""

from abc import ABC, abstractmethod

from eyeriss_plugin_sdk.types import PluginContext, PluginResult


class EyerissPlugin(ABC):
    """
    Base class for all Python plugins in the Eyeriss Gateway.

    Plugin authors must:
    1. Subclass this class
    2. Implement the `plugin_id` property (must match manifest.json id)
    3. Override one or more hook methods

    Example:
        class Plugin(EyerissPlugin):
            @property
            def plugin_id(self) -> str:
                return "my-custom-plugin"

            async def pre_request(self, context: PluginContext) -> PluginResult:
                return PluginResult(
                    proceed=True,
                    modified_headers={"X-Plugin-Processed": "true"},
                )
    """

    @property
    @abstractmethod
    def plugin_id(self) -> str:
        """Unique plugin identifier (must match manifest.json 'id' field)."""
        ...

    async def pre_request(self, context: PluginContext) -> PluginResult:
        """
        Called after auth/RBAC pass, before proxying to backend.

        Return PluginResult with proceed=False to block the request.
        Return modified_headers to add/override outbound headers.
        Return modified_body to replace the request body.

        Default: proceed without modification.
        """
        return PluginResult(proceed=True)

    async def post_response(self, context: PluginContext) -> PluginResult:
        """
        Called after backend response, before returning to client.

        Return modified_headers to add/override response headers.
        Return modified_body to replace the response body.
        proceed=False is ignored for post_response (response already received).

        Default: pass-through without modification.
        """
        return PluginResult(proceed=True)

    async def on_error(self, context: PluginContext, error_info: dict) -> None:
        """
        Called on gateway error (auth failure, 5xx, timeout, etc.).

        Observational only — return value is ignored. Cannot modify the
        error response. Use for logging, alerting, or metrics.

        Default: no-op.
        """
        pass

    async def initialize(self) -> None:
        """
        Called once when the plugin is loaded at gateway startup.
        Override for setup tasks (initialize state, validate config, etc.).

        Default: no-op.
        """
        pass

    async def configure(self, config: dict) -> None:
        """
        Called after initialize() with the plugin's configuration.

        Override to apply settings from the admin UI / database config.
        Use this instead of reading environment variables directly so
        that configuration changes via the UI take effect immediately.

        Default: no-op.
        """
        pass

    async def cleanup(self) -> None:
        """
        Called when the plugin is unloaded (gateway shutdown or plugin removal).
        Override for cleanup tasks (close connections, flush buffers, etc.).

        Default: no-op.
        """
        pass
