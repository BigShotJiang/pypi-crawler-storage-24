"""
Eyeriss Plugin SDK — Data Types

Serializable data types for plugin hook arguments and return values.
All types are fully JSON-serializable for WASM compatibility.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class SerializedRequest:
    """
    Serialized representation of an HTTP request for plugin consumption.
    Body is size-limited to prevent memory issues with large uploads.
    """
    method: str
    path: str
    headers: dict  # {header_name: value} — lowercase keys
    query_params: dict  # {param_name: value}
    content_type: str = ""
    body: Optional[bytes] = None

    def to_dict(self) -> dict:
        """Serialize to a JSON-compatible dict (body as base64)."""
        import base64
        d = {
            "method": self.method,
            "path": self.path,
            "headers": self.headers,
            "query_params": self.query_params,
            "content_type": self.content_type,
        }
        if self.body is not None:
            d["body"] = base64.b64encode(self.body).decode("ascii")
            d["body_encoding"] = "base64"
        else:
            d["body"] = None
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "SerializedRequest":
        """Deserialize from a JSON-compatible dict."""
        import base64
        body = None
        if d.get("body") is not None:
            if d.get("body_encoding") == "base64":
                body = base64.b64decode(d["body"])
            elif isinstance(d["body"], bytes):
                body = d["body"]
            else:
                body = d["body"].encode("utf-8")
        return cls(
            method=d["method"],
            path=d["path"],
            headers=d.get("headers", {}),
            query_params=d.get("query_params", {}),
            content_type=d.get("content_type", ""),
            body=body,
        )


@dataclass
class ErrorResponse:
    """Error response returned by a plugin when blocking a request."""
    status_code: int
    body: dict
    headers: Optional[dict] = None

    def to_dict(self) -> dict:
        d = {"status_code": self.status_code, "body": self.body}
        if self.headers:
            d["headers"] = self.headers
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "ErrorResponse":
        return cls(
            status_code=d["status_code"],
            body=d["body"],
            headers=d.get("headers"),
        )


@dataclass
class PluginResult:
    """
    Result returned by a plugin hook execution.

    - proceed=True: request continues to next plugin or to backend
    - proceed=False: request is blocked; error_response is returned to client
    - modified_headers: headers to merge into outbound request (pre_request)
      or response (post_response)
    - modified_body: replacement body bytes, or None to keep original
    """
    proceed: bool = True
    modified_headers: Optional[dict] = None
    modified_body: Optional[bytes] = None
    error_response: Optional[ErrorResponse] = None

    def to_dict(self) -> dict:
        import base64
        d = {"proceed": self.proceed}
        if self.modified_headers is not None:
            d["modified_headers"] = self.modified_headers
        if self.modified_body is not None:
            d["modified_body"] = base64.b64encode(self.modified_body).decode("ascii")
            d["modified_body_encoding"] = "base64"
        if self.error_response is not None:
            d["error_response"] = self.error_response.to_dict()
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PluginResult":
        import base64
        modified_body = None
        if d.get("modified_body") is not None:
            if d.get("modified_body_encoding") == "base64":
                modified_body = base64.b64decode(d["modified_body"])
            elif isinstance(d["modified_body"], bytes):
                modified_body = d["modified_body"]
        error_response = None
        if d.get("error_response"):
            error_response = ErrorResponse.from_dict(d["error_response"])
        return cls(
            proceed=d.get("proceed", True),
            modified_headers=d.get("modified_headers"),
            modified_body=modified_body,
            error_response=error_response,
        )


@dataclass
class PluginContext:
    """
    Context passed to plugin hooks.

    Contains serialized request data and auth information. Must be fully
    JSON-serializable for WASM compatibility.
    """
    request: SerializedRequest
    application_id: int
    endpoint_id: int
    auth_result: dict
    request_id: str
    client_ip: str

    def to_dict(self) -> dict:
        return {
            "request": self.request.to_dict(),
            "application_id": self.application_id,
            "endpoint_id": self.endpoint_id,
            "auth_result": self.auth_result,
            "request_id": self.request_id,
            "client_ip": self.client_ip,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PluginContext":
        return cls(
            request=SerializedRequest.from_dict(d["request"]),
            application_id=d["application_id"],
            endpoint_id=d["endpoint_id"],
            auth_result=d.get("auth_result", {}),
            request_id=d["request_id"],
            client_ip=d["client_ip"],
        )
