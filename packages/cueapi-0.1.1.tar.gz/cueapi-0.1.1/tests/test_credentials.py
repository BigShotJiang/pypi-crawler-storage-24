"""Tests for credential storage and resolution."""
from __future__ import annotations

import os
import stat

import pytest

from cueapi.credentials import (
    load_credentials,
    remove_all_credentials,
    remove_credentials,
    resolve_api_key,
    save_credentials,
)


def test_save_and_load_credentials(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_test",
        "email": "test@example.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    loaded = load_credentials(creds_file)
    assert loaded["default"]["api_key"] == "cue_sk_test"
    assert loaded["default"]["email"] == "test@example.com"


def test_file_permissions(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_test",
        "email": "t@t.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    mode = oct(creds_file.stat().st_mode & 0o777)
    assert mode == "0o600"


def test_resolve_env_var_overrides_file(tmp_path, monkeypatch):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_file",
        "email": "t@t.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    monkeypatch.setenv("CUEAPI_API_KEY", "cue_sk_env")
    key = resolve_api_key(creds_file=creds_file)
    assert key == "cue_sk_env"


def test_resolve_api_key_flag_overrides_file(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_file",
        "email": "t@t.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    key = resolve_api_key(api_key="cue_sk_flag", creds_file=creds_file)
    assert key == "cue_sk_flag"


def test_resolve_profile(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "work", {
        "api_key": "cue_sk_work",
        "email": "w@w.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    key = resolve_api_key(creds_file=creds_file, profile="work")
    assert key == "cue_sk_work"


def test_no_credentials_raises(tmp_path):
    creds_file = tmp_path / "credentials.json"
    with pytest.raises(Exception):
        resolve_api_key(creds_file=creds_file)


def test_logout_removes_profile(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_test",
        "email": "t@t.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    email = remove_credentials(creds_file, "default")
    assert email == "t@t.com"
    loaded = load_credentials(creds_file)
    assert "default" not in loaded


def test_logout_all_removes_file(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_test",
        "email": "t@t.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    remove_all_credentials(creds_file)
    assert not creds_file.exists()


def test_load_nonexistent_returns_empty(tmp_path):
    creds_file = tmp_path / "nonexistent.json"
    loaded = load_credentials(creds_file)
    assert loaded == {}


def test_multiple_profiles(tmp_path):
    creds_file = tmp_path / "credentials.json"
    save_credentials(creds_file, "default", {
        "api_key": "cue_sk_default",
        "email": "default@t.com",
        "api_base": "https://api.cueapi.ai/v1",
    })
    save_credentials(creds_file, "staging", {
        "api_key": "cue_sk_staging",
        "email": "staging@t.com",
        "api_base": "https://staging.cueapi.ai/v1",
    })
    loaded = load_credentials(creds_file)
    assert loaded["default"]["api_key"] == "cue_sk_default"
    assert loaded["staging"]["api_key"] == "cue_sk_staging"
