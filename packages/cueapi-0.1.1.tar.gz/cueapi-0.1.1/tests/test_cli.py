"""Tests for CLI commands using click.testing.CliRunner."""
from __future__ import annotations

from unittest.mock import patch

from click.testing import CliRunner

from cueapi.cli import main


def test_version():
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.1.1" in result.output


def test_whoami_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr("cueapi.credentials.CREDS_PATH", tmp_path / "credentials.json")
    # Also clear any env var that might be set
    monkeypatch.delenv("CUEAPI_API_KEY", raising=False)
    runner = CliRunner()
    result = runner.invoke(main, ["whoami"])
    assert "not logged in" in result.output.lower() or "login" in result.output.lower()


def test_list_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr("cueapi.credentials.CREDS_PATH", tmp_path / "credentials.json")
    monkeypatch.delenv("CUEAPI_API_KEY", raising=False)
    runner = CliRunner()
    result = runner.invoke(main, ["list"])
    assert "not logged in" in result.output.lower() or "login" in result.output.lower()


def test_logout_no_credentials(tmp_path, monkeypatch):
    monkeypatch.setattr("cueapi.credentials.CREDS_PATH", tmp_path / "credentials.json")
    runner = CliRunner()
    result = runner.invoke(main, ["logout"])
    assert result.exit_code == 0
    assert "no credentials" in result.output.lower() or "not found" in result.output.lower()


def test_create_missing_flags():
    runner = CliRunner()
    result = runner.invoke(main, ["create", "--name", "test", "--url", "https://example.com"])
    assert result.exit_code != 0
    assert "cron" in result.output.lower() or "at" in result.output.lower()


def test_create_conflicting_flags():
    runner = CliRunner()
    result = runner.invoke(main, [
        "create", "--name", "test", "--url", "https://example.com",
        "--cron", "0 9 * * *", "--at", "2026-01-01T00:00:00Z",
    ])
    assert result.exit_code != 0


def test_help():
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "cueapi" in result.output.lower()
    assert "login" in result.output
    assert "create" in result.output
    assert "list" in result.output


def test_key_regenerate_help():
    runner = CliRunner()
    result = runner.invoke(main, ["key", "regenerate", "--help"])
    assert result.exit_code == 0
    assert "regenerate" in result.output.lower()
