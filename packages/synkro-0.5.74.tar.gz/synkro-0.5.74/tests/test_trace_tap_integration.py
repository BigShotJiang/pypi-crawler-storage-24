"""Integration test: prove synkro.trace_tap captures real Langfuse OTEL spans.

Creates a Langfuse client, creates a generation span, and verifies
that our tap intercepts the span data via LangfuseSpanProcessor.on_end.

Run:
    source .env && .venv/bin/python -m pytest tests/test_trace_tap_integration.py -v -s

Requires: LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY
"""

from __future__ import annotations

import os
import time
from unittest.mock import MagicMock

import pytest

requires_langfuse = pytest.mark.skipif(
    not os.getenv("LANGFUSE_SECRET_KEY") or not os.getenv("LANGFUSE_PUBLIC_KEY"),
    reason="LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY required",
)


def _reset_trace_tap():
    from synkro.enterprise.trace_tap._state import _state

    if _state.langfuse_tap:
        _state.langfuse_tap.uninstall()
    if _state.langsmith_tap:
        _state.langsmith_tap.uninstall()
    if _state.worker:
        try:
            _state.worker._stop.set()
            _state.worker._thread.join(timeout=2)
        except Exception:
            pass
    _state.initialized = False
    _state.enabled = True
    _state.worker = None
    _state.langsmith_tap = None
    _state.langfuse_tap = None


@requires_langfuse
class TestTraceTapLangfuseIntegration:
    """Prove that synkro.trace_tap captures real Langfuse spans."""

    def setup_method(self):
        _reset_trace_tap()

    def teardown_method(self):
        _reset_trace_tap()

    def test_captures_langfuse_generation_span(self):
        """Create a Langfuse generation, verify our tap captures the span."""
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap
        from synkro.enterprise.trace_tap._state import _state

        # Collect captured events
        captured_events: list[dict] = []
        mock_worker = MagicMock()
        mock_worker.enqueue = lambda event: captured_events.append(event)

        # Install our tap BEFORE creating the Langfuse client
        tap = LangfuseTap(worker=mock_worker, project="integration-test")
        tap.install()
        assert tap._installed, "LangfuseTap failed to install"
        _state.enabled = True

        print("\n--- Tap installed, creating Langfuse client ---")

        lf = None
        try:
            from langfuse import Langfuse

            lf = Langfuse()

            # Langfuse v3 API: start_generation creates a generation span
            gen = lf.start_generation(
                name="test-llm-call",
                model="gpt-4o-test",
                input=[{"role": "user", "content": "What is 2+2?"}],
                output={"role": "assistant", "content": "4"},
                usage_details={"input": 10, "output": 5},
            )
            gen.end()

            print("--- Created generation, flushing ---")

            # Flush sends spans through the processor
            lf.flush()
            time.sleep(3)

            print(f"--- Captured {len(captured_events)} events ---")
            for i, event in enumerate(captured_events):
                print(f"\nEvent {i}:")
                print(f"  source: {event.get('source')}")
                print(f"  project: {event.get('project')}")
                print(f"  trace_id: {event.get('trace_id', '')[:16]}...")
                print(f"  model: {event.get('model')}")
                print(f"  messages: {event.get('messages')[:2] if event.get('messages') else []}")
                print(f"  metadata.name: {event.get('metadata', {}).get('name')}")
                print(f"  metadata.run_type: {event.get('metadata', {}).get('run_type')}")
                print(f"  metadata.prompt_tokens: {event.get('metadata', {}).get('prompt_tokens')}")
                print(
                    f"  metadata.completion_tokens: "
                    f"{event.get('metadata', {}).get('completion_tokens')}"
                )
                print(f"  metadata.latency_ms: {event.get('metadata', {}).get('latency_ms')}")

            # ── Assertions ──
            assert len(captured_events) > 0, "No events were captured!"

            # Verify all events have the right structure
            for event in captured_events:
                assert event["source"] == "langfuse"
                assert event["project"] == "integration-test"
                assert "trace_id" in event
                assert "metadata" in event
                assert event["metadata"]["run_type"] in {"llm", "chain", "tool"}

            print("\n=== PASSED: Trace tap successfully captured Langfuse spans ===")

        finally:
            tap.uninstall()
            if lf:
                try:
                    lf.shutdown()
                except Exception:
                    pass

    def test_disable_suppresses_capture(self):
        """Verify that disable() prevents span capture while active."""
        from synkro.enterprise.trace_tap import disable
        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap
        from synkro.enterprise.trace_tap._state import _state

        captured_events: list[dict] = []
        mock_worker = MagicMock()
        mock_worker.enqueue = lambda event: captured_events.append(event)

        tap = LangfuseTap(worker=mock_worker, project="test-disabled")
        tap.install()
        _state.enabled = True

        lf = None
        try:
            from langfuse import Langfuse

            lf = Langfuse()

            # Create generation with tap disabled
            with disable():
                gen = lf.start_generation(
                    name="disabled-call",
                    model="gpt-4o-test",
                    input="test",
                    output="test",
                )
                gen.end()
                lf.flush()
                time.sleep(2)

            disabled_count = len(captured_events)
            print(f"\n--- Events captured while disabled: {disabled_count} ---")
            assert disabled_count == 0, f"Expected 0 events while disabled, got {disabled_count}"

            # Now create generation with tap re-enabled
            gen2 = lf.start_generation(
                name="enabled-call",
                model="gpt-4o-test",
                input="test2",
                output="test2",
            )
            gen2.end()
            lf.flush()
            time.sleep(3)

            enabled_count = len(captured_events)
            print(f"--- Events captured after re-enable: {enabled_count} ---")
            assert enabled_count > 0, "Expected events after re-enable"

            print("\n=== PASSED: disable() correctly suppresses capture ===")

        finally:
            tap.uninstall()
            if lf:
                try:
                    lf.shutdown()
                except Exception:
                    pass
