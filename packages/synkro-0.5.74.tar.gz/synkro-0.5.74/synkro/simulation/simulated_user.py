"""Simulated User - LLM-driven user for agent simulation.

Generates realistic user messages based on a scenario, adapting
to the agent's actual responses in a multi-turn conversation.
"""

from __future__ import annotations

from synkro.llm.client import LLM
from synkro.types.logic_map import GoldenScenario, LogicMap

SIMULATED_USER_PROMPT = """You are simulating a user interacting with a customer service agent.
You must stay in character and follow the scenario below.

## Scenario
- Description: {scenario_description}
- Context: {scenario_context}
- Type: {scenario_type}
- Expected outcome: {expected_outcome}

## Policy Rules Being Tested
{target_rules}

## Instructions
- Act as a realistic user who would be in this scenario
- Your messages should be natural and conversational
- Follow the scenario description closely — it tells you what the user wants
- React naturally to the agent's responses
- If the agent asks for information that fits the scenario, provide it
- If the scenario is a NEGATIVE type, you may be a user who doesn't meet the policy requirements
- If the scenario is an EDGE_CASE type, provide details that are at exact boundary conditions
- Do NOT reveal that you are a simulated user
- Do NOT mention the policy rules directly
- Keep messages concise (1-3 sentences typically)

## Conversation So Far
{conversation}

## Turn Info
This is turn {turn_number} of {max_turns}.
{turn_guidance}

Generate the next user message. Output ONLY the user's message text, nothing else.
If the conversation has reached a natural conclusion, output exactly: [DONE]"""


class SimulatedUser:
    """LLM-driven simulated user for agent testing.

    Generates realistic user messages that follow a scenario while
    adapting to the agent's actual responses.
    """

    def __init__(self, llm: LLM):
        self.llm = llm

    async def generate_message(
        self,
        scenario: GoldenScenario,
        logic_map: LogicMap,
        conversation: list[dict],
        turn_number: int,
        max_turns: int,
    ) -> str | None:
        """Generate the next user message, or None if conversation should end.

        Args:
            scenario: The scenario being simulated
            logic_map: The logic map for rule context
            conversation: Conversation so far (OpenAI-format dicts)
            turn_number: Current turn number (1-indexed)
            max_turns: Maximum turns allowed

        Returns:
            Next user message string, or None if conversation is done
        """
        # Format target rules
        target_rules_text = self._format_target_rules(scenario, logic_map)

        # Format conversation history
        conv_text = self._format_conversation(conversation)

        # Turn guidance
        if turn_number == 1:
            turn_guidance = "This is the OPENING message. Introduce your request/question."
        elif turn_number >= max_turns:
            turn_guidance = (
                "This is the FINAL turn. Wrap up the conversation naturally. "
                "If your issue is resolved or clearly unresolvable, output [DONE]."
            )
        else:
            turn_guidance = "Continue the conversation naturally based on the agent's response."

        prompt = SIMULATED_USER_PROMPT.format(
            scenario_description=scenario.description,
            scenario_context=scenario.context,
            scenario_type=scenario.scenario_type.value,
            expected_outcome=scenario.expected_outcome,
            target_rules=target_rules_text,
            conversation=conv_text if conv_text else "(No messages yet — you speak first)",
            turn_number=turn_number,
            max_turns=max_turns,
            turn_guidance=turn_guidance,
        )

        response = await self.llm.generate(prompt)
        text = response.strip()

        if "[DONE]" in text:
            return None

        return text

    def _format_target_rules(self, scenario: GoldenScenario, logic_map: LogicMap) -> str:
        """Format the target rules for the prompt."""
        lines = []
        for rule_id in scenario.target_rule_ids:
            rule = logic_map.get_rule(rule_id)
            if rule:
                lines.append(f"- {rule.rule_id}: {rule.text}")
                lines.append(f"  IF: {rule.condition}")
                lines.append(f"  THEN: {rule.action}")
        return "\n".join(lines) if lines else "No specific rules targeted."

    def _format_conversation(self, conversation: list[dict]) -> str:
        """Format conversation history for the prompt."""
        if not conversation:
            return ""
        lines = []
        for msg in conversation:
            role = msg["role"].upper()
            content = msg.get("content", "")
            lines.append(f"[{role}]: {content}")
        return "\n".join(lines)


__all__ = ["SimulatedUser"]
