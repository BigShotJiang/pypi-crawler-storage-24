"""Monkey-patch for the LangSmith SDK to forward trace data.

LangSmith >= 0.5 uses multipart ingest by default. The internal tracing
thread calls ``_create_run`` / ``_update_run`` directly and never goes
through the public ``batch_ingest_runs``. We only intercept ``_update_run``
(which has the complete inputs + outputs) to avoid duplicate grading.
``batch_ingest_runs`` is also patched for legacy/explicit callers.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("synkro.trace_tap")


class LangSmithTap:
    """Patches LangSmith Client to copy trace data to Synkro."""

    def __init__(self, worker: Any, project: str) -> None:
        self._worker = worker
        self._project = project
        self._original_batch: Any = None
        self._original_update: Any = None
        self._installed = False

    def install(self) -> None:
        if self._installed:
            return
        try:
            import langsmith

            tap = self

            # --- Patch batch_ingest_runs (legacy / explicit calls) ---
            self._original_batch = langsmith.Client.batch_ingest_runs

            def patched_batch_ingest_runs(client_self: Any, *args: Any, **kwargs: Any) -> Any:
                result = tap._original_batch(client_self, *args, **kwargs)
                try:
                    tap._process_batch_runs(args, kwargs)
                except Exception:
                    logger.debug(
                        "synkro.trace_tap: error processing LangSmith batch runs", exc_info=True
                    )
                return result

            langsmith.Client.batch_ingest_runs = patched_batch_ingest_runs  # type: ignore[assignment]

            # --- Patch _update_run (has complete inputs + outputs) ---
            self._original_update = getattr(langsmith.Client, "_update_run", None)
            if self._original_update is not None:

                def patched_update_run(client_self: Any, run_update: dict, **kwargs: Any) -> None:
                    # Snapshot before original call — serialize_run_dict may consume fields
                    run_snapshot = dict(run_update)
                    tap._original_update(client_self, run_update, **kwargs)
                    try:
                        tap._process_single_run(run_snapshot)
                    except Exception:
                        logger.debug(
                            "synkro.trace_tap: error processing LangSmith update run", exc_info=True
                        )

                langsmith.Client._update_run = patched_update_run  # type: ignore[assignment]

            self._installed = True
            logger.debug("synkro.trace_tap: LangSmith tap installed")
        except ImportError:
            logger.debug("synkro.trace_tap: langsmith not installed, skipping")
        except Exception:
            logger.debug("synkro.trace_tap: failed to install LangSmith tap", exc_info=True)

    def _process_single_run(self, run: dict) -> None:
        """Process a single run dict from _update_run."""
        from synkro.enterprise.trace_tap._normalizer import normalize_langsmith_run
        from synkro.enterprise.trace_tap._state import _state

        if not _state.enabled:
            return

        if not isinstance(run, dict):
            return

        event = normalize_langsmith_run(run, self._project)
        if event:
            self._worker.enqueue(event)

    def _process_batch_runs(self, args: tuple, kwargs: dict) -> None:
        """Process runs from batch_ingest_runs(create=[], update=[])."""
        from synkro.enterprise.trace_tap._normalizer import normalize_langsmith_run
        from synkro.enterprise.trace_tap._state import _state

        if not _state.enabled:
            return

        # Only process updates (complete runs), skip creates to avoid duplicates
        update = kwargs.get("update") or (args[1] if len(args) > 1 else []) or []

        for run in update:
            if not isinstance(run, dict):
                continue
            event = normalize_langsmith_run(run, self._project)
            if event:
                self._worker.enqueue(event)

    def uninstall(self) -> None:
        if not self._installed:
            return
        try:
            import langsmith

            if self._original_batch is not None:
                langsmith.Client.batch_ingest_runs = self._original_batch  # type: ignore[assignment]
            if self._original_update is not None:
                langsmith.Client._update_run = self._original_update  # type: ignore[assignment]
            self._installed = False
            logger.debug("synkro.trace_tap: LangSmith tap uninstalled")
        except Exception:
            pass
