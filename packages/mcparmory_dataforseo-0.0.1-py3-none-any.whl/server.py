"""MCP server for Dataforseo — placeholder, full version coming soon."""

def main() -> None:
    print("mcparmory-dataforseo: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
