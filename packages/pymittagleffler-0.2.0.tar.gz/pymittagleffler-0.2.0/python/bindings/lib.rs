// SPDX-FileCopyrightText: 2024 Alexandru Fikl <alexfikl@gmail.com>
// SPDX-License-Identifier: MIT

use num::complex::{c64, Complex32, Complex64};

use numpy::{IntoPyArray, PyReadonlyArrayDyn};
use pyo3::exceptions::PyTypeError;
use pyo3::prelude::*;
use pyo3::types::PyComplex;

use mittagleffler::{mittag_leffler_special, GarrappaMittagLeffler, MittagLefflerAlgorithm};

#[pyclass]
#[pyo3(name = "GarrappaMittagLeffler")]
pub struct PyGarrappaMittagLeffler {
    inner: GarrappaMittagLeffler,
}

#[pymethods]
impl PyGarrappaMittagLeffler {
    #[new]
    #[pyo3(signature = (*, eps=None))]
    pub fn new(eps: Option<f64>) -> Self {
        PyGarrappaMittagLeffler {
            inner: GarrappaMittagLeffler::new(eps),
        }
    }

    pub fn evaluate(&self, z: Complex64, alpha: f64, beta: f64) -> Option<Complex64> {
        mittag_leffler_special(z, alpha, beta).or_else(|| self.inner.evaluate(z, alpha, beta))
    }

    #[setter(eps)]
    pub fn set_eps(&mut self, eps: f64) {
        self.inner.eps = eps;
    }

    #[getter(eps)]
    pub fn get_eps(&self) -> f64 {
        self.inner.eps
    }
}

fn eval(ml: &GarrappaMittagLeffler, z: Complex64, alpha: f64, beta: f64) -> Complex64 {
    match mittag_leffler_special(z, alpha, beta).or_else(|| ml.evaluate(z, alpha, beta)) {
        Some(value) => value,
        None => Complex64 {
            re: f64::NAN,
            im: f64::NAN,
        },
    }
}

#[pyfunction]
pub fn mittag_leffler<'py>(
    py: Python<'py>,
    z: Bound<'py, PyAny>,
    alpha: f64,
    beta: f64,
) -> PyResult<Py<PyAny>> {
    let ml = GarrappaMittagLeffler::default();

    if let Ok(ary) = z.extract::<Complex64>() {
        let result = eval(&ml, ary, alpha, beta);
        return Ok(PyComplex::from_doubles(py, result.re, result.im).into());
    }

    if let Ok(ary) = z.extract::<PyReadonlyArrayDyn<f32>>() {
        let ary = ary
            .as_array()
            .map(|x| eval(&ml, c64(*x as f64, 0.0), alpha, beta));
        return Ok(ary.into_pyarray(py).into_pyobject(py)?.into_any().unbind());
    }

    if let Ok(ary) = z.extract::<PyReadonlyArrayDyn<f64>>() {
        let ary = ary.as_array().map(|x| eval(&ml, c64(*x, 0.0), alpha, beta));
        return Ok(ary.into_pyarray(py).into_pyobject(py)?.into_any().unbind());
    }

    if let Ok(ary) = z.extract::<PyReadonlyArrayDyn<Complex32>>() {
        let ary = ary
            .as_array()
            .map(|x| eval(&ml, c64(x.re as f64, x.im as f64), alpha, beta));
        return Ok(ary.into_pyarray(py).into_pyobject(py)?.into_any().unbind());
    }

    if let Ok(ary) = z.extract::<PyReadonlyArrayDyn<Complex64>>() {
        let ary = ary.as_array().map(|x| eval(&ml, *x, alpha, beta));
        return Ok(ary.into_pyarray(py).into_pyobject(py)?.into_any().unbind());
    }

    if let Ok(ary) = z.extract::<PyReadonlyArrayDyn<i32>>() {
        let ary = ary
            .as_array()
            .map(|x| eval(&ml, c64(*x as f64, 0.0), alpha, beta));
        return Ok(ary.into_pyarray(py).into_pyobject(py)?.into_any().unbind());
    }

    if let Ok(ary) = z.extract::<PyReadonlyArrayDyn<i64>>() {
        let ary = ary
            .as_array()
            .map(|x| eval(&ml, c64(*x as f64, 0.0), alpha, beta));
        return Ok(ary.into_pyarray(py).into_pyobject(py)?.into_any().unbind());
    }

    Err(PyTypeError::new_err(format!(
        "Input 'z' has unsupported type {}",
        z.get_type()
    )))
}

#[pymodule]
#[pyo3(name = "_bindings")]
fn _bindings(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyGarrappaMittagLeffler>()?;
    m.add_function(wrap_pyfunction!(mittag_leffler, m)?)?;

    Ok(())
}
