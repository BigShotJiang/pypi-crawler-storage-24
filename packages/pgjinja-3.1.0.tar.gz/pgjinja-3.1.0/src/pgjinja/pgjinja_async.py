import logging
from collections.abc import Sequence
from typing import LiteralString

from jinjasql import JinjaSql
from psycopg import InterfaceError, OperationalError
from psycopg_pool import AsyncConnectionPool
from psycopg_pool.pool_async import PoolTimeout

from .errors import PgJinjaQueryError
from .schemas.pgjinja_settings import PgJinjaSettings
from .shared.common import read_template
from .shared.execution import (
    prepare_query_from_template,
    sanitize_params,
    validate_model,
)

logger = logging.getLogger(__name__)


class PgJinjaAsync:
    """Async variant of PgJinja backed by psycopg's AsyncConnectionPool."""

    def __init__(self, db_settings: PgJinjaSettings):
        # Initialize settings but skip parent's __init__ to avoid creating a sync pool
        self.settings = db_settings

        self.pool = AsyncConnectionPool(
            conninfo=self.settings.coninfo,
            max_size=self.settings.max_size,
            min_size=self.settings.min_size,
            open=False,
        )

    @staticmethod
    def _sanitize_params(params: dict | Sequence) -> str:
        return sanitize_params(params)

    async def _open_pool(self):
        # noinspection PyProtectedMember
        if not self.pool._opened:
            await self.pool.open()
            logger.debug(f"Opened connection pool to {self.settings}")

    async def _run(
        self,
        query: LiteralString,
        params: dict | Sequence = (),
        model: type | None = None,
        max_retries: int = 2,
    ):
        if max_retries < 1:
            raise ValueError("max_retries must be at least 1")

        await self._open_pool()
        attempts = 0
        while attempts < max_retries:
            try:
                async with (
                    self.pool.connection() as connection,
                    connection.cursor() as cursor,
                ):
                    await cursor.execute(query, params)
                    if cursor.description:
                        if model is not None:
                            headers = [desc[0] for desc in cursor.description]
                            rows = await cursor.fetchall()
                            mapped_rows = [dict(zip(headers, r)) for r in rows]
                            return [model(**r) for r in mapped_rows]
                        else:
                            return await cursor.fetchall()

                    return cursor.rowcount
            except Exception as e:
                stats = self.pool.get_stats()
                retryable = isinstance(
                    e,
                    (
                        OperationalError,
                        InterfaceError,
                        PoolTimeout,
                        TimeoutError,
                        ConnectionError,
                    ),
                )
                logger.warning(
                    "PgJinja async query failed (retryable=%s) query=%s params=%s model=%s pool_stats=%s",
                    retryable,
                    query,
                    self._sanitize_params(params),
                    model,
                    stats,
                )

                attempts += 1
                if not retryable:
                    raise PgJinjaQueryError(
                        "Async query failed with non-retryable error"
                    ) from e
                if attempts >= max_retries:
                    raise PgJinjaQueryError(
                        "Async query failed after retries exhausted"
                    ) from e
                logger.warning("Retrying query (%s/%s)...", attempts, max_retries)

    async def close(self):
        if hasattr(self, "pool") and self.pool._opened:
            await self.pool.close()
            logger.debug("Closed async connection pool")

    def __del__(self):
        """Warn when the async pool is still open during object finalization."""
        if hasattr(self, "pool") and self.pool._opened:
            logger.warning(
                "PgJinjaAsync pool was not closed properly. "
                "Please use 'await client.close()' to properly release resources."
            )

    async def query(
        self, template: str, params: dict | None = None, model: type | None = None
    ):
        """Async version of `query` with the same return semantics as PgJinja."""
        if params is None:
            params = dict()

        validated_model = validate_model(model)
        query, bind_params = prepare_query_from_template(
            self.settings.template_dir,
            template,
            params,
            validated_model,
            read_template_fn=read_template,
            jinja_sql_cls=JinjaSql,
        )
        return await self._run(query, bind_params, validated_model)
