from collections.abc import Sequence
from typing import Any

from jinjasql import JinjaSql
from pydantic import BaseModel

from .common import get_model_fields, read_template


def sanitize_params(params: dict | Sequence) -> str:
    if isinstance(params, dict):
        return str({k: "***" for k in params})
    if isinstance(params, Sequence) and not isinstance(params, (str, bytes, bytearray)):
        return f"<sequence length={len(params)}>"
    return "<redacted>"


def validate_model(model: type | None) -> type[BaseModel] | None:
    if model is None:
        return None
    if not (isinstance(model, type) and issubclass(model, BaseModel)):
        raise TypeError("model must be a subclass of pydantic.BaseModel or None")
    return model


def prepare_query_from_template(
    template_path: Any,
    template: str,
    params: dict | None,
    model: type[BaseModel] | None,
    read_template_fn=read_template,
    jinja_sql_cls=JinjaSql,
):
    render_params = dict(params or {})
    if model is not None:
        render_params["_model_fields_"] = get_model_fields(model)

    statement = read_template_fn(template_path / template)
    return jinja_sql_cls(param_style="format").prepare_query(
        statement, render_params or ()
    )


def map_rows(cursor: Any, model: type[BaseModel] | None):
    if not cursor.description:
        return cursor.rowcount
    if model is None:
        return cursor.fetchall()

    headers = [desc[0] for desc in cursor.description]
    rows = cursor.fetchall()
    mapped_rows = [dict(zip(headers, r)) for r in rows]
    return [model(**r) for r in mapped_rows]
