import logging
from functools import cache
from pathlib import Path

from pydantic import BaseModel

logger = logging.getLogger(__name__)


@cache
def read_template(file: Path) -> str:
    """Read a SQL template as UTF-8 and cache by `Path`."""
    return file.read_text(encoding="utf8")


@cache
def get_model_fields(model: type(BaseModel)) -> str:
    """Return comma-separated model fields, preferring string validation aliases."""
    if not issubclass(model, BaseModel):
        raise TypeError(f"{model} is not a subclass of pydantic.BaseModel")

    fields = []
    for name, field_info in model.model_fields.items():
        alias = field_info.validation_alias
        fields.append(alias if isinstance(alias, str) else name)
    return ", ".join(fields)
