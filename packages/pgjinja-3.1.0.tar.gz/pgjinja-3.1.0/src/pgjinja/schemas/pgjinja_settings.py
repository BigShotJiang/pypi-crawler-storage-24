from pathlib import Path

from pydantic import BaseModel, SecretStr


class PgJinjaSettings(BaseModel):
    """Settings for PostgreSQL connectivity, pooling, and SQL template lookup."""

    host: str = "localhost"
    port: int = 5432
    dbname: str = "public"
    user: str
    password: SecretStr

    template_dir: Path = Path()

    min_size: int = 4
    max_size: int | None = None

    application_name: str = "pgjinja"

    def __repr__(self) -> str:
        return f"{self.host}:{self.port}/{self.dbname}"

    def __str__(self) -> str:
        return self.__repr__()

    @property
    def coninfo(self) -> str:
        """Return a psycopg-compatible connection string from the configured fields."""
        from psycopg.conninfo import make_conninfo

        return make_conninfo(
            # keyword reference: https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-PARAMKEYWORDS
            host=self.host,
            port=self.port,
            dbname=self.dbname,
            user=self.user,
            password=self.password.get_secret_value(),
            application_name=self.application_name,
        )
