"""PostgreSQL query helpers built around Jinja2 SQL templates."""

__version__ = "3.1.0"

from .errors import PgJinjaError, PgJinjaQueryError
from .pgjinja import PgJinja
from .pgjinja_async import PgJinjaAsync
from .schemas.pgjinja_settings import PgJinjaSettings
from .shared.common import get_model_fields, read_template

# Export common classes and functions
__all__ = [
    "PgJinja",
    "PgJinjaAsync",
    "PgJinjaError",
    "PgJinjaQueryError",
    "PgJinjaSettings",
    "read_template",
    "get_model_fields",
]
