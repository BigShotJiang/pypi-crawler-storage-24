class PgJinjaError(Exception):
    """Base exception for pgjinja."""


class PgJinjaQueryError(PgJinjaError):
    """Raised when query execution fails."""
