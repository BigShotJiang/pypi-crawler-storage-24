import logging
from collections.abc import Sequence
from typing import LiteralString

from jinjasql import JinjaSql
from psycopg import InterfaceError, OperationalError
from psycopg_pool import ConnectionPool
from psycopg_pool.pool import PoolTimeout

from .errors import PgJinjaQueryError
from .schemas.pgjinja_settings import PgJinjaSettings
from .shared.common import read_template
from .shared.execution import (
    map_rows,
    prepare_query_from_template,
    sanitize_params,
    validate_model,
)

logger = logging.getLogger(__name__)


class PgJinja:
    """Execute Jinja2 SQL templates against PostgreSQL using a lazy connection pool."""

    @staticmethod
    def _sanitize_params(params: dict | Sequence) -> str:
        return sanitize_params(params)

    @staticmethod
    def _is_retryable_error(error: Exception) -> bool:
        return isinstance(
            error,
            (
                OperationalError,
                InterfaceError,
                PoolTimeout,
                TimeoutError,
                ConnectionError,
            ),
        )

    def __init__(self, db_settings: PgJinjaSettings):
        self.settings = db_settings
        self.pool = ConnectionPool(
            # ref: https://www.psycopg.org/psycopg3/docs/advanced/pool.html#
            conninfo=self.settings.coninfo,
            max_size=self.settings.max_size,
            min_size=self.settings.min_size,
            open=False,
        )

    def close(self):
        if hasattr(self, "pool") and self.pool._opened:
            self.pool.close()
            logger.debug("Closed connection pool")

    def _open_pool(self):
        # noinspection PyProtectedMember
        if not self.pool._opened:
            self.pool.open()
            logger.debug(f"Opened connection pool to {self.settings}")

    def _run(
        self,
        query: LiteralString,
        params: dict | Sequence = (),
        model: type | None = None,
        max_retries: int = 2,
    ):
        if max_retries < 1:
            raise ValueError("max_retries must be at least 1")

        self._open_pool()
        attempts = 0
        while attempts < max_retries:
            try:
                with (
                    self.pool.connection() as connection,
                    connection.cursor() as cursor,
                ):
                    cursor.execute(query, params)
                    return map_rows(cursor, model)
            except Exception as e:
                stats = self.pool.get_stats()
                retryable = self._is_retryable_error(e)
                logger.warning(
                    "PgJinja query failed (retryable=%s) query=%s params=%s model=%s pool_stats=%s",
                    retryable,
                    query,
                    self._sanitize_params(params),
                    model,
                    stats,
                )

                attempts += 1
                if not retryable:
                    raise PgJinjaQueryError(
                        "Query failed with non-retryable error"
                    ) from e
                if attempts >= max_retries:
                    raise PgJinjaQueryError(
                        "Query failed after retries exhausted"
                    ) from e
                logger.warning("Retrying query (%s/%s)...", attempts, max_retries)

    def query(
        self, template: str, params: dict | None = None, model: type | None = None
    ):
        """Render and execute a SQL template, optionally mapping rows to a model.

        Returns model instances for SELECT queries when `model` is provided, raw
        row tuples for SELECT queries without a model, and an affected-row count
        for statements without a result set.
        """
        if params is None:
            params = dict()

        validated_model = validate_model(model)
        query, bind_params = prepare_query_from_template(
            self.settings.template_dir,
            template,
            params,
            validated_model,
            read_template_fn=read_template,
            jinja_sql_cls=JinjaSql,
        )
        return self._run(query, bind_params, validated_model)
