#!/usr/bin/env python3
"""Minimal sync mic listener. Prints detections and exits after the first one."""

from sonnetics import WakeWordDetector
from sonnetics.detector import WakeWordDetector


def main() -> None:

    print("Loading model...")

    # This is a "Hey Alfred" model. You can copy your own mode_id from the sonnetics dashboard.
    detector: WakeWordDetector = WakeWordDetector.create(
        model_id="efea8354-3f81-4c61-9d50-7452cb901620"
    )

    print("Listening for wake word...")
    for event in detector.listen():
        print(f"Detected: {event.phrase}")
        detector.stop()


if __name__ == "__main__":
    main()
