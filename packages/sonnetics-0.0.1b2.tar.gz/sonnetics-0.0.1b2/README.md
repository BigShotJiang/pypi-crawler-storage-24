# sonnetics-py

Wake-word inference for Python. High-level API over [sonnetics-core](https://github.com/sonnetics/sonnetics-core).

## Installation

### With uv

```bash
uv add sonnetics
```

### With pip

```bash
pip install sonnetics
```

### Ussage

See [examples](examples/)

## License

Apache-2.0
