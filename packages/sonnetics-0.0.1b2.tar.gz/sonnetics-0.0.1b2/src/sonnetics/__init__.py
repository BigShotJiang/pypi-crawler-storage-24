"""
sonnetics: Wake-word inference for Python.

High-level API over sonnetics-core.
"""

from sonnetics.detector import DetectEvent, WakeWordDetector

__all__ = [
    "DetectEvent",
    "WakeWordDetector",
]
