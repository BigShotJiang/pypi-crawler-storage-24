"""
Wake word detector. Supports mic capture (sounddevice), feed() for manual audio,
listen()/listen_async() for blocking loops, and start/stop for fire-and-forget.
"""

from __future__ import annotations

import asyncio
import threading
from collections.abc import AsyncIterator, Iterator
from dataclasses import dataclass
from queue import Empty, Queue
from typing import Any, Callable

from sonnetics.model_loader import _load_model_async, _load_model_sync

try:
    import sonnetics_core
except ImportError:
    sonnetics_core = None  # type: ignore[assignment]

CHUNK_SIZE = 2048
DEFAULT_THRESHOLD = 0.25
DEFAULT_CHUNK_DURATION = 0.5


@dataclass
class DetectEvent:
    """Emitted when a wake word is detected."""

    phrase: str
    audio: AudioStream


class AudioStream:
    """Iterator over post-detection audio chunks. Sync or async."""

    def __init__(
        self,
        queue: Queue[list[float] | None],
        sample_rate: int,
        channels: int,
        chunk_duration: float,
        stopped: Callable[[], bool],
        on_close: Callable[[], None] | None,
    ):
        self._queue = queue
        self._sample_rate = sample_rate
        self._channels = channels
        self._chunk_size = int(chunk_duration * sample_rate * channels)
        self._stopped = stopped
        self._on_close = on_close
        self._buffer: list[float] = []
        self._closed = False

    @property
    def sample_rate(self) -> int:
        return self._sample_rate

    @property
    def channels(self) -> int:
        return self._channels

    def __iter__(self) -> Iterator[list[float]]:
        try:
            while not self._stopped() and not self._closed:
                try:
                    chunk = self._queue.get(timeout=0.1)
                    if chunk is None:
                        break
                    self._buffer.extend(chunk)
                    while len(self._buffer) >= self._chunk_size:
                        out = self._buffer[: self._chunk_size]
                        del self._buffer[: self._chunk_size]
                        yield out
                except Empty:
                    continue
            while len(self._buffer) >= self._chunk_size:
                out = self._buffer[: self._chunk_size]
                del self._buffer[: self._chunk_size]
                yield out
        finally:
            self._closed = True
            if self._on_close:
                self._on_close()

    async def __aiter__(self) -> AsyncIterator[list[float]]:
        """Async iteration: run sync iterator in thread pool."""
        loop = asyncio.get_running_loop()
        q: asyncio.Queue[list[float] | None] = asyncio.Queue()

        def run():
            for chunk in self:
                loop.call_soon_threadsafe(q.put_nowait, chunk)
            loop.call_soon_threadsafe(q.put_nowait, None)

        t = threading.Thread(target=run, daemon=True)
        t.start()

        while True:
            c = await q.get()
            if c is None:
                break
            yield c


class WakeWordDetector:
    """Wake word detector. Use create/create_async, then feed(), listen(), listen_async(), or start/stop."""

    def __init__(
        self,
        files: dict[str, bytes],
        *,
        threshold: float = DEFAULT_THRESHOLD,
        chunk_duration: float = DEFAULT_CHUNK_DURATION,
    ):
        if sonnetics_core is None:
            raise ImportError(
                "sonnetics-core not installed. Build with: cd sonnetics-core && maturin develop"
            )
        if not (0 <= threshold <= 1):
            raise ValueError("threshold must be between 0 and 1")
        self._files = files
        self._threshold = threshold
        self._chunk_duration = chunk_duration
        self._engine: Any | None = None  # PyWakeEngine from sonnetics_core (no stubs)
        self._sample_rate = 16000
        self._channels = 1
        self._stopped = False
        self._chunk_queue: Queue[list[float] | None] | None = None
        self._active_session_closed: Callable[[], None] | None = None
        self._capture_thread: threading.Thread | None = None

    @classmethod
    def create(
        cls,
        *,
        path: str | None = None,
        model_id: str | None = None,
        threshold: float = DEFAULT_THRESHOLD,
        chunk_duration: float = DEFAULT_CHUNK_DURATION,
    ) -> WakeWordDetector:
        """Create detector from path or model_id. Exactly one required. Sync (blocks on CDN fetch for model_id)."""
        files = _load_model_sync(path=path, model_id=model_id)
        return cls(files, threshold=threshold, chunk_duration=chunk_duration)

    @classmethod
    async def create_async(
        cls,
        *,
        path: str | None = None,
        model_id: str | None = None,
        threshold: float = DEFAULT_THRESHOLD,
        chunk_duration: float = DEFAULT_CHUNK_DURATION,
    ) -> WakeWordDetector:
        """Create detector from path or model_id. Exactly one required. Async (non-blocking for model_id fetch)."""
        files = await _load_model_async(path=path, model_id=model_id)
        return cls(files, threshold=threshold, chunk_duration=chunk_duration)

    def _ensure_engine(self, sample_rate: int, channels: int) -> None:
        if self._engine is None:
            self._sample_rate = sample_rate
            self._channels = channels
            files_dict = {k: v for k, v in self._files.items()}
            self._engine = sonnetics_core.init(files_dict, sample_rate, channels)

    def feed(
        self,
        audio: list[float] | bytes,
        sample_rate: int,
        channels: int = 1,
    ) -> str | None:
        """Manually feed audio. Returns detected phrase or None."""
        self._ensure_engine(sample_rate, channels)
        if isinstance(audio, bytes):
            import array

            arr = array.array("f")
            arr.frombytes(audio)
            audio = list(arr)
        chunk_samples = CHUNK_SIZE * channels
        for i in range(0, len(audio) - chunk_samples + 1, chunk_samples):
            chunk = audio[i : i + chunk_samples]
            phrase = self._engine.detect(chunk, self._threshold)
            if phrase is not None:
                return phrase
        return None

    def listen(self) -> Iterator[DetectEvent]:
        """Sync iterator over detections. Blocks."""
        try:
            import sounddevice as sd
        except ImportError:
            raise ImportError(
                "sounddevice required for listen. pip install sounddevice"
            )

        sample_rate = sd.query_devices(None, "input")["default_samplerate"]
        channels = sd.query_devices(None, "input")["max_input_channels"]
        self._ensure_engine(int(sample_rate), channels)
        self._stopped = False
        detect_queue: Queue[DetectEvent | None] = Queue()
        current_session: list[Queue[list[float] | None] | None] = [None]

        def callback(indata: Any, frames: int, time_info: Any, status: Any) -> None:
            if status:
                print(status)
            if self._stopped:
                return
            # Interleaved: [L0,R0,L1,R1,...] for stereo
            chunk = indata.flatten(order="F").tolist()
            chunk_samples = CHUNK_SIZE * self._channels
            for i in range(0, len(chunk) - chunk_samples + 1, chunk_samples):
                c = chunk[i : i + chunk_samples]
                phrase = self._engine.detect(c, self._threshold)
                if phrase is not None:
                    old = current_session[0]
                    if old is not None:
                        old.put(None)
                    q: Queue[list[float] | None] = Queue()
                    current_session[0] = q
                    ev = self._make_event(q, phrase)
                    detect_queue.put(ev)
                else:
                    q = current_session[0]
                    if q is not None:
                        q.put(c)

        stream = sd.InputStream(
            samplerate=sample_rate,
            channels=channels,
            dtype="float32",
            blocksize=CHUNK_SIZE,
            callback=callback,
        )
        stream.start()
        try:
            while not self._stopped:
                try:
                    ev = detect_queue.get(timeout=0.1)
                    if ev is None:
                        break
                    yield ev
                except Empty:
                    pass
        finally:
            self._stopped = True
            stream.stop()
            stream.close()

    def _make_event(
        self, chunk_queue: Queue[list[float] | None], phrase: str
    ) -> DetectEvent:
        def stopped() -> bool:
            return self._stopped

        def on_close() -> None:
            pass

        stream = AudioStream(
            chunk_queue,
            self._sample_rate,
            self._channels,
            self._chunk_duration,
            stopped,
            on_close,
        )
        return DetectEvent(phrase=phrase, audio=stream)

    def stop(self) -> None:
        """Stop capture (for start() or listen)."""
        self._stopped = True

    async def listen_async(self) -> AsyncIterator[DetectEvent]:
        """Async iterator over detections."""
        loop = asyncio.get_running_loop()
        q: asyncio.Queue[DetectEvent | None] = asyncio.Queue()

        def run():
            for ev in self.listen():
                loop.call_soon_threadsafe(q.put_nowait, ev)
            loop.call_soon_threadsafe(q.put_nowait, None)

        t = threading.Thread(target=run, daemon=True)
        t.start()
        while True:
            ev = await q.get()
            if ev is None:
                break
            yield ev

    def start(self, callback: Callable[[DetectEvent], None]) -> None:
        """Fire-and-forget: start listening in background, call callback on detect."""

        def run():
            for ev in self.listen():
                callback(ev)

        self._capture_thread = threading.Thread(target=run, daemon=True)
        self._capture_thread.start()
