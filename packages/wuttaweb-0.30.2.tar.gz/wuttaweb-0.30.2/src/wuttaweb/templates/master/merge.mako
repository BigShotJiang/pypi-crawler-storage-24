## -*- coding: utf-8; -*-
<%inherit file="/page.mako" />

<%def name="title()">Merge 2 ${model_title_plural}</%def>

<%def name="page_content()">
  <div style="padding: 2rem 5rem;">

    <p class="block">
      You are about to <span class="has-text-weight-bold">merge</span>
      two ${model_title} records, possibly updating and/or deleting
      various other records.
    </p>

    <p class="block">
      This tool can show you some basics but is not able to give you
      the full picture of the implications of this merge.
    </p>

    <p class="block">
      <span class="has-text-weight-bold">You are urged to proceed with
      caution!</span>  Ideally try the merge on a test site first.
    </p>

    <div class="block">

      <b-field horizontal label="Removing ${model_title}:">
        ${h.link_to(str(removing) or "(no title)", master.get_action_url('view', removing))}
      </b-field>

      <b-field horizontal label="Keeping ${model_title}:">
        ${h.link_to(str(keeping) or "(no title)", master.get_action_url('view', keeping))}
      </b-field>

    </div>

    ${diff.render_html()}

    <b-field grouped style="margin: 2rem;">

      <div class="control">
        <wutta-button label="Whoops, nevermind"
                      tag="a"
                      href="${index_url}"
                      once />
      </div>

      <div class="control">
        ${h.form(request.current_route_url(), **{"@submit": "swapSubmitting = true"})}
        ${h.csrf_token(request)}
        ${h.hidden("uuids", value=f"{keeping.uuid},{removing.uuid}")}
        <b-button native-type="submit"
                  :disabled="swapSubmitting"
                  icon-pack="fas"
                  icon-left="retweet">
          {{ swapSubmitting ? "Working, please wait..." : "Swap which record is kept/removed" }}
        </b-button>
        ${h.end_form()}
      </div>

      <div class="control">
        ${h.form(request.current_route_url(), **{"@submit": "mergeSubmitting = true"})}
        ${h.csrf_token(request)}
        ${h.hidden("uuids", value=f"{removing.uuid},{keeping.uuid}")}
        ${h.hidden("execute-merge", value="true")}
        <b-button type="is-primary"
                  native-type="submit"
                  :disabled="mergeSubmitting"
                  icon-pack="fas"
                  icon-left="object-ungroup">
          {{ mergeSubmitting ? "Working, please wait..." : "Yes, perform this merge" }}
        </b-button>
        ${h.end_form()}
      </div>

    </b-field>
  </div>
</%def>

<%def name="modify_vue_vars()">
  ${parent.modify_vue_vars()}
  <script>

    ThisPageData.swapSubmitting = false
    ThisPageData.mergeSubmitting = false

  </script>
</%def>
