#!/bin/sh
# FereAI CLI Installer
# Usage: curl -fsSL https://api.fereai.xyz/install.sh | sh
#
# Installs the `fere` CLI tool via pipx (recommended) or pip.
# Supports macOS and Linux.

set -e

VERSION="0.1.0"
PACKAGE="fere-cli"

# Colors (disabled if not a TTY)
if [ -t 1 ]; then
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    DIM='\033[2m'
    RESET='\033[0m'
else
    RED=''
    GREEN=''
    YELLOW=''
    DIM=''
    RESET=''
fi

info() { printf "${DIM}%s${RESET}\n" "$1"; }
success() { printf "${GREEN}%s${RESET}\n" "$1"; }
warn() { printf "${YELLOW}%s${RESET}\n" "$1"; }
error() { printf "${RED}Error: %s${RESET}\n" "$1" >&2; exit 1; }

# Detect OS
OS="$(uname -s)"
case "$OS" in
    Darwin) OS_NAME="macOS" ;;
    Linux)  OS_NAME="Linux" ;;
    *)      error "Unsupported OS: $OS. Use pip install $PACKAGE instead." ;;
esac

info "Installing FereAI CLI v${VERSION} on ${OS_NAME}..."

# Check Python 3.10+
check_python() {
    for cmd in python3 python; do
        if command -v "$cmd" >/dev/null 2>&1; then
            ver=$("$cmd" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null)
            major=$(echo "$ver" | cut -d. -f1)
            minor=$(echo "$ver" | cut -d. -f2)
            if [ "$major" -ge 3 ] && [ "$minor" -ge 10 ]; then
                echo "$cmd"
                return 0
            fi
        fi
    done
    return 1
}

PYTHON=$(check_python) || error "Python 3.10+ is required. Install it from https://python.org"
info "Found Python: $($PYTHON --version)"

# Prefer pipx for isolated installs
install_with_pipx() {
    if command -v pipx >/dev/null 2>&1; then
        info "Installing with pipx..."
        pipx install "$PACKAGE" || pipx upgrade "$PACKAGE"
        return 0
    fi
    return 1
}

install_pipx() {
    info "Installing pipx..."
    if command -v brew >/dev/null 2>&1; then
        brew install pipx
    elif [ "$OS" = "Linux" ]; then
        $PYTHON -m pip install --user pipx 2>/dev/null || \
            $PYTHON -m ensurepip --default-pip 2>/dev/null && \
            $PYTHON -m pip install --user pipx
    else
        $PYTHON -m pip install --user pipx
    fi
    pipx ensurepath 2>/dev/null || true
}

install_with_pip() {
    info "Installing with pip..."
    $PYTHON -m pip install --user "$PACKAGE"
}

# Try pipx first, then install pipx, then fall back to pip
if install_with_pipx; then
    : # success
elif install_pipx && install_with_pipx; then
    : # success
else
    warn "pipx not available, falling back to pip..."
    install_with_pip
fi

# Verify installation
if command -v fere >/dev/null 2>&1; then
    success "FereAI CLI installed successfully!"
    echo ""
    info "Get started:"
    echo "  fere auth          # Set up your agent"
    echo "  fere chat \"hello\"  # Chat with the AI"
    echo "  fere --help        # See all commands"
else
    warn "Installation complete, but 'fere' is not in PATH."
    warn "You may need to restart your shell or add ~/.local/bin to PATH:"
    echo ""
    echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
fi
