"""CLI entry point — root Click group and command registration."""

from __future__ import annotations

import click

from . import __version__
from .commands.auth import auth, credits, whoami
from .commands.chat import chat, threads
from .commands.earn import earn
from .commands.hooks import hooks
from .commands.limit_order import limit_order
from .commands.portfolio import holdings, notifications, wallets
from .commands.swap import swap
from .commands.utility import chains, config, status


@click.group(invoke_without_command=True)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output as machine-readable JSON.",
)
@click.option(
    "--quiet",
    is_flag=True,
    default=False,
    help="Minimal output (key value only).",
)
@click.option(
    "--agent",
    envvar="FERE_AGENT_NAME",
    default=None,
    help="Agent name override.",
)
@click.option(
    "--base-url",
    envvar="FERE_BASE_URL",
    default=None,
    help="API base URL override.",
)
@click.version_option(version=__version__, prog_name="fere")
@click.pass_context
def cli(ctx, output_json, quiet, agent, base_url):
    """FereAI CLI — crypto trading and research from your terminal."""
    ctx.ensure_object(dict)
    ctx.obj["output_json"] = output_json
    ctx.obj["quiet"] = quiet
    if agent:
        ctx.obj["agent_override"] = agent
    if base_url:
        ctx.obj["base_url_override"] = base_url

    # Show banner when no subcommand is given
    if ctx.invoked_subcommand is None and not output_json and not quiet:
        from rich.console import Console

        from .banner import get_banner

        console = Console(highlight=False)
        console.print(f"[bold]{get_banner()}[/bold]")
        click.echo(ctx.get_help())


# Auth & Identity
cli.add_command(auth)
cli.add_command(whoami)
cli.add_command(credits)

# Chat
cli.add_command(chat)
cli.add_command(threads)

# Trading
cli.add_command(swap)
cli.add_command(limit_order, name="limit-order")
cli.add_command(hooks)

# Portfolio
cli.add_command(wallets)
cli.add_command(holdings)
cli.add_command(notifications)

# Earn
cli.add_command(earn)

# Utility
cli.add_command(chains)
cli.add_command(status)
cli.add_command(config)
