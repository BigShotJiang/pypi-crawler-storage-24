"""FereAI CLI — terminal interface for crypto trading and research."""

__version__ = "0.1.0"
