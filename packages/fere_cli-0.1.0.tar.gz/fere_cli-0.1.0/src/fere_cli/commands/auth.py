"""Auth commands: fere auth, fere whoami, fere credits."""

from __future__ import annotations

import click
from fere_sdk import FereClient
from rich.console import Console

from ..async_util import async_command, get_client, is_tty, run_async
from ..config import load_config, save_config
from ..output import print_error, print_success

console = Console()


@click.command()
@click.option("--name", prompt=False, default=None, help="Agent name.")
@click.pass_context
@async_command
async def auth(ctx, name: str | None):
    """Authenticate and register a new agent (first-run setup)."""
    cfg = load_config()

    agent_name = (
        ctx.obj.get("agent_override")
        or name
        or cfg.get("agent_name")
    )
    if not agent_name:
        if is_tty():
            agent_name = click.prompt("Agent name")
        else:
            raise click.ClickException(
                "Agent name required. Pass --name or --agent."
            )

    base_url = ctx.obj.get("base_url_override") or cfg.get("base_url")
    key_path = cfg.get("key_path")

    try:
        client = await FereClient.create(
            agent_name=agent_name,
            base_url=base_url,
            key_path=key_path,
        )

        # Persist agent name to config
        cfg["agent_name"] = agent_name
        save_config(cfg)

        user = await client.get_user()
        await client.close()

        print_success(
            {
                "status": "authenticated",
                "agent_name": agent_name,
                "user": user,
            },
            quiet_value=agent_name,
        )
    except Exception as e:
        print_error(f"Authentication failed: {e}")
        raise SystemExit(1)


@click.command()
@click.pass_context
@async_command
async def whoami(ctx):
    """Show current agent identity and wallet addresses."""
    try:
        client = await get_client(ctx)
        user = await client.get_user()
        wallets_data = await client.get_wallets()
        await client.close()

        result = {**user}
        if wallets_data:
            result["wallets"] = wallets_data

        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@click.command()
@click.pass_context
@async_command
async def credits(ctx):
    """Show available credit balance."""
    try:
        client = await get_client(ctx)
        balance = await client.get_credits()
        await client.close()

        print_success(
            {"credits_available": balance},
            quiet_value=str(balance),
        )
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
