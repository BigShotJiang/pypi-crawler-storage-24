"""Chat commands: fere chat, fere threads."""

from __future__ import annotations

import json
import sys

import click
from rich.console import Console

from ..async_util import async_command, get_client, is_tty
from ..output import (
    is_json_mode,
    print_error,
    print_streaming_text,
    print_success,
    print_table_from_dicts,
)

console = Console()


@click.command()
@click.argument("query", required=False, default=None)
@click.option(
    "--stream",
    "stream_mode",
    is_flag=True,
    default=False,
    help="Stream response events as they arrive.",
)
@click.option(
    "--thread",
    "thread_id",
    default=None,
    help="Continue an existing chat thread.",
)
@click.option(
    "--agent",
    "agent_type",
    default="ProAgent",
    help="Agent type to use (default: ProAgent).",
)
@click.pass_context
@async_command
async def chat(ctx, query, stream_mode, thread_id, agent_type):
    """Chat with FereAI's crypto AI agent.

    Pass a query as an argument for one-shot mode, or run without
    arguments to enter interactive REPL mode.
    """
    try:
        client = await get_client(ctx)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)

    try:
        if query:
            # One-shot mode
            if stream_mode:
                await _stream_chat(
                    client, query, thread_id, agent_type
                )
            else:
                await _oneshot_chat(
                    client, query, thread_id, agent_type
                )
        elif is_tty():
            # Interactive REPL
            await _repl_chat(client, thread_id, agent_type)
        else:
            raise click.ClickException(
                "Query required in non-interactive mode. "
                "Usage: fere chat \"your question\""
            )
    except click.ClickException:
        raise
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
    finally:
        await client.close()


async def _oneshot_chat(client, query, thread_id, agent_type):
    """Send a query and print the final answer."""
    result = await client.chat(
        query, thread_id=thread_id, agent=agent_type
    )
    print_success(
        result,
        quiet_value=result.get("answer", ""),
    )


async def _stream_chat(client, query, thread_id, agent_type):
    """Stream chat events, printing each as it arrives."""
    json_mode = is_json_mode()

    async for event in client.chat_stream(
        query, thread_id=thread_id, agent=agent_type
    ):
        if json_mode:
            # NDJSON: one JSON object per line
            click.echo(
                json.dumps(
                    {"event": event.event, "data": event.data},
                    default=str,
                )
            )
        else:
            if event.event == "chunk":
                text = event.data.get("text", "")
                print_streaming_text(text)
            elif event.event == "answer":
                text = event.data.get("text", "")
                if text:
                    click.echo()  # newline after chunks
                    console.print(
                        f"\n[bold]Answer:[/bold] {text}"
                    )
            elif event.event == "tool_response":
                console.print(
                    f"[dim]Tool: {json.dumps(event.data, default=str)}[/dim]"
                )
            elif event.event == "error":
                msg = event.data.get("message", str(event.data))
                print_error(msg)
            elif event.event == "meta":
                chat_id = event.data.get("chat_id", "")
                console.print(f"[dim]Chat: {chat_id}[/dim]")

    if not json_mode:
        click.echo()  # final newline


async def _repl_chat(client, thread_id, agent_type):
    """Interactive REPL loop."""
    console.print(
        "[bold]FereAI Chat[/bold] "
        "[dim](type /exit or Ctrl+D to quit)[/dim]\n"
    )

    current_thread = thread_id

    while True:
        try:
            query = input(">>> ")
        except EOFError:
            click.echo()
            break

        query = query.strip()
        if not query:
            continue
        if query in ("/exit", "/quit"):
            break

        result = await client.chat(
            query, thread_id=current_thread, agent=agent_type
        )

        # Track thread for continuity
        if "chat_id" in result and not current_thread:
            current_thread = result["chat_id"]

        answer = result.get("answer", "")
        if answer:
            console.print(f"\n{answer}\n")


@click.command()
@click.option(
    "--limit",
    default=10,
    help="Number of threads to show.",
)
@click.option("--skip", default=0, help="Offset.")
@click.pass_context
@async_command
async def threads(ctx, limit, skip):
    """List recent chat threads."""
    try:
        client = await get_client(ctx)
        data = await client.get_threads(skip=skip, limit=limit)
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
