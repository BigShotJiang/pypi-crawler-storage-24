"""Limit order commands: fere limit-order (create, list, cancel)."""

from __future__ import annotations

import click
from rich.console import Console

from ..async_util import async_command, get_client, is_tty
from ..output import print_error, print_success

console = Console()


@click.group()
def limit_order():
    """Manage limit orders."""
    pass


@limit_order.command()
@click.option("--chain-in", required=True, type=int, help="Source chain ID.")
@click.option(
    "--chain-out", required=True, type=int, help="Destination chain ID."
)
@click.option(
    "--token-in", required=True, help="Source token contract address."
)
@click.option(
    "--token-out", required=True, help="Destination token contract address."
)
@click.option(
    "--amount", required=True, help="Amount in smallest unit."
)
@click.option(
    "--price",
    "price_usd_trigger",
    required=True,
    type=float,
    help="Trigger price in USD.",
)
@click.option(
    "--trigger-token",
    required=True,
    help="Token address to monitor for price trigger.",
)
@click.option(
    "--trigger-chain",
    required=True,
    help="Chain of the trigger token.",
)
@click.option(
    "--condition",
    required=True,
    type=click.Choice(["above", "below"]),
    help="Trigger when price goes above or below target.",
)
@click.option("--slippage-bps", default=50, type=int, help="Slippage (bps).")
@click.option(
    "--timeout", default=120, type=int, help="Wait timeout (seconds)."
)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@async_command
async def create(
    ctx,
    chain_in,
    chain_out,
    token_in,
    token_out,
    amount,
    price_usd_trigger,
    trigger_token,
    trigger_chain,
    condition,
    slippage_bps,
    timeout,
    yes,
):
    """Create a new limit order."""
    if not yes and is_tty():
        click.echo(
            f"Limit Order: {condition} ${price_usd_trigger}\n"
            f"  Swap {amount} units {token_in} -> {token_out}\n"
            f"  Chains: {chain_in} -> {chain_out}"
        )
        if not click.confirm("Proceed?"):
            raise SystemExit(0)

    try:
        client = await get_client(ctx)

        with console.status("Creating limit order..."):
            result = await client.limit_order(
                chain_id_in=chain_in,
                chain_id_out=chain_out,
                token_in=token_in,
                token_out=token_out,
                amount=amount,
                price_usd_trigger=price_usd_trigger,
                trigger_token_address=trigger_token,
                trigger_token_chain=trigger_chain,
                condition=condition,
                timeout=timeout,
            )

        await client.close()
        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@limit_order.command(name="list")
@click.option(
    "--status",
    default=None,
    help="Filter by status (e.g. active, completed).",
)
@click.pass_context
@async_command
async def list_orders(ctx, status):
    """List limit orders."""
    try:
        client = await get_client(ctx)
        data = await client.get_limit_orders(status=status)
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@limit_order.command()
@click.argument("order_id")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@async_command
async def cancel(ctx, order_id, yes):
    """Cancel a limit order by ID."""
    if not yes and is_tty():
        if not click.confirm(f"Cancel order {order_id}?"):
            raise SystemExit(0)

    try:
        client = await get_client(ctx)
        # Use the low-level API for cancel
        result = await client._api.cancel_limit_order(order_id)
        await client.close()

        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
