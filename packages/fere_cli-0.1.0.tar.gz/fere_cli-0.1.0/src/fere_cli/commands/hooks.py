"""Hooks commands: fere hooks set."""

from __future__ import annotations

import json

import click

from ..async_util import async_command, get_client
from ..output import print_error, print_success


@click.group()
def hooks():
    """Manage stop-loss and take-profit hooks."""
    pass


@hooks.command()
@click.option(
    "--chain-id", required=True, type=int, help="Chain ID."
)
@click.option(
    "--token", required=True, help="Token contract address."
)
@click.option(
    "--stop-loss",
    default=None,
    help="Stop-loss config as JSON (e.g. '{\"price\": 1.5}').",
)
@click.option(
    "--take-profit",
    default=None,
    help="Take-profit config as JSON (e.g. '{\"price\": 3.0}').",
)
@click.pass_context
@async_command
async def set(ctx, chain_id, token, stop_loss, take_profit):
    """Set stop-loss and/or take-profit hooks on a token."""
    try:
        sl = json.loads(stop_loss) if stop_loss else None
    except json.JSONDecodeError as exc:
        raise click.BadParameter(
            f"Invalid JSON for --stop-loss: {exc}", param_hint="'--stop-loss'"
        )
    try:
        tp = json.loads(take_profit) if take_profit else None
    except json.JSONDecodeError as exc:
        raise click.BadParameter(
            f"Invalid JSON for --take-profit: {exc}",
            param_hint="'--take-profit'",
        )

    if not sl and not tp:
        raise click.ClickException(
            "At least one of --stop-loss or --take-profit is required."
        )

    try:
        client = await get_client(ctx)
        result = await client.set_hooks(
            chain_id=chain_id,
            token_address=token,
            stop_loss=sl,
            take_profit=tp,
        )
        await client.close()

        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
