import csv
import json
import os


class JsonCSV:
    """A class to interact between a JSON and CSV file."""

    def convert_json_to_csv(self, json_path: str, csv_path: str, key: str | None = None):
        """Converts a json file from path to a csv file.

        Args:
            json_path (str): The path to the JSON file
            csv_path (str): The path that we are storing the CSV file
            key (str | None): The key in the json object with te data we are storing in the CSV
        """
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"{json_path} not found")

        with open(json_path, "r", encoding="utf-8") as json_file:
            with open(csv_path, "w", encoding="utf-8", newline="") as csv_file:
                try:
                    json_obj = json.load(json_file)
                    if key and key != "":
                        json_obj = json_obj[key]
                except json.JSONDecodeError as e:
                    doc = e.doc
                    pos = e.pos
                    raise json.JSONDecodeError("Failed to decode provided JSON File to JSON Object", doc, pos)
                except KeyError:
                    raise KeyError(f"{key} is not a valid key inside the JSON File")
                headers = json_obj[0].keys()
                writer = csv.DictWriter(csv_file, fieldnames=headers, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(json_obj)

    def convert_csv_to_json(self, csv_path: str, json_path: str | None = None):
        """Convert a CSV file to a JSON File.

        Args:
            csv_path (str): The path to the CSV file
            json_path (str): The path to where the JSON file is to be stored
        """
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"{csv_path} not found.")

        json_data: list[dict] = []
        with open(csv_path, "r") as csv_file:
            reader = csv.DictReader(csv_file)
            for row in reader:
                json_data.append(row)

            if json_path:
                with open(json_path, "w", encoding="utf-8") as json_file:
                    json.dump(json_data, json_file)
            else:
                print(json_data)
