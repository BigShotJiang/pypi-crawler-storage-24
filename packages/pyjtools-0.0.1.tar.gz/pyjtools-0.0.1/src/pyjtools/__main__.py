if __name__ == "__main__":
    from json_tools.cli import app

    app()
