from typing import Annotated

import typer

from .json_csv import JsonCSV

app = typer.Typer(no_args_is_help=True)


@app.command()
def json2csv(
    json_path: Annotated[str, typer.Option(help="The JSON file to turn to CSV")],
    csv_path: Annotated[str, typer.Option(help="The path where to output the CSV file")] = "",
    key: Annotated[str | None, typer.Option(help="The key in the JSON object with the data to post to the CSV")] = None,
):
    """Converts a JSON to a CSV.

    Args:
        json_path: The json file to turn to a CSV
        csv_path: The path where to output the CSV file
        key: The key in the JSON object with the data to post to the CSV
    """
    json_csv = JsonCSV()
    if csv_path == "":
        csv_path = json_path.replace(".json", ".csv")
    json_csv.convert_json_to_csv(json_path, csv_path, key)


@app.command()
def csv2json(
    csv_path: Annotated[str, typer.Option(help="The path where to output the CSV file")],
    json_path: Annotated[str | None, typer.Option(help="The JSON file to turn to CSV")] = None,
):
    """Converts a JSON to a CSV.

    Args:
        json_path: The json file to turn to a CSV
        csv_path: The path where to output the CSV file
    """
    json_csv = JsonCSV()
    json_csv.convert_csv_to_json(csv_path, json_path)


if __name__ == "__main__":
    app()
