# SPDX-License-Identifier: Apache-2.0
#
# SPDX-FileCopyrightText: © 2025 Tenstorrent AI ULC

import dataclasses
import sqlite3
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Union

from ttnn_visualizer.exceptions import DatabaseFileNotFoundException
from ttnn_visualizer.models import (
    Buffer,
    BufferPage,
    Device,
    DeviceOperation,
    ErrorRecord,
    InputTensor,
    Instance,
    Operation,
    OperationArgument,
    OutputTensor,
    ProducersConsumers,
    StackTrace,
    Tensor,
    TensorComparisonRecord,
)


class LocalQueryRunner:
    def __init__(self, instance: Optional[Instance] = None, connection=None):

        if connection:
            self.connection = connection
        else:
            if not instance or not instance.profiler_path:
                raise ValueError("Report path must be provided for local queries")
            db_path = str(instance.profiler_path)
            if not Path(db_path).exists():
                raise DatabaseFileNotFoundException(
                    f"Database not found at path: {db_path}"
                )
            self.connection = sqlite3.connect(
                instance.profiler_path, isolation_level=None, timeout=30
            )

    def execute_query(self, query: str, params: Optional[List] = None) -> List:
        """
        Executes a query locally using SQLite.
        """
        cursor = self.connection.cursor()
        try:
            cursor.execute(query, params or [])
            return cursor.fetchall()
        finally:
            cursor.close()

    def close(self):
        if self.connection:
            self.connection.close()


class DatabaseQueries:

    instance: Optional[Instance] = None
    query_runner: LocalQueryRunner

    def __init__(self, instance: Optional[Instance] = None, connection=None):
        self.instance = instance

        if connection:
            self.query_runner = LocalQueryRunner(connection=connection)
        else:
            if not instance:
                raise ValueError(
                    "Must provide either an existing connection or instance"
                )
            self.query_runner = LocalQueryRunner(instance=instance)

    def _check_table_exists(self, table_name: str) -> bool:
        """
        Checks if a table exists in the database.
        This method works for both local and remote databases.
        """
        # Properly format the table name into the query string with single quotes
        query = "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?"

        # Use the execute_query method to handle both local and remote cases.
        rows = self.query_runner.execute_query(query, [table_name])

        return bool(rows)

    def _get_table_columns(self, table_name: str) -> List[str]:
        """
        Gets the list of column names for a table.
        """
        query = f"PRAGMA table_info({table_name})"
        rows = self.query_runner.execute_query(query)
        return [row[1] for row in rows]  # row[1] is the column name

    def _query_table(
        self,
        table_name: str,
        filters: Optional[Dict[str, Union[Any, List[Any]]]] = None,
        additional_conditions: Optional[str] = None,
        additional_params: Optional[List[Any]] = None,
        columns: Optional[List[str]] = None,
    ) -> List[Any]:
        columns_str = ", ".join(columns) if columns else "*"
        query = f"SELECT {columns_str} FROM {table_name} WHERE 1=1"
        params = []

        if filters:
            for column, value in filters.items():
                if value is None:  # Skip filters with None values
                    continue

                if isinstance(value, list):  # Handle list-based filters
                    if len(value) == 0:  # Skip empty lists
                        continue
                    placeholders = ", ".join(["?"] * len(value))
                    query += f" AND {column} IN ({placeholders})"
                    params.extend(value)
                else:
                    query += f" AND {column} = ?"
                    params.append(value)

        if additional_conditions:
            query += f" {additional_conditions}"
            if additional_params:
                params.extend(additional_params)

        return self.query_runner.execute_query(query, params)

    def query_device_operations(
        self, filters: Optional[Dict[str, Union[Any, List[Any]]]] = None
    ) -> List[DeviceOperation]:
        if not self._check_table_exists("captured_graph"):
            return []
        rows = self._query_table("captured_graph", filters)
        return [DeviceOperation(*row) for row in rows]

    def query_operation_arguments(
        self, filters: Optional[Dict[str, Union[Any, List[Any]]]] = None
    ) -> Generator[OperationArgument, None, None]:
        rows = self._query_table("operation_arguments", filters)
        for row in rows:
            yield OperationArgument(*row)

    def query_operations(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[Operation, None, None]:
        rows = self._query_table("operations", filters)
        for row in rows:
            yield Operation(*row)

    def query_buffers(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[Buffer, None, None]:
        rows = self._query_table("buffers", filters)
        for row in rows:
            yield Buffer(*row[:6])

    def query_stack_traces(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[StackTrace, None, None]:
        rows = self._query_table("stack_traces", filters)
        for row in rows:
            operation_id, stack_trace = row
            yield StackTrace(operation_id, stack_trace=stack_trace)

    def query_error_records(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[ErrorRecord, None, None]:
        rows = self._query_table("errors", filters)
        for row in rows:
            yield ErrorRecord(*row)

    def query_tensor_comparisons(
        self, local: bool = True, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[TensorComparisonRecord, None, None]:
        if local:
            table_name = "local_tensor_comparison_records"
        else:
            table_name = "global_tensor_comparison_records"
        rows = self._query_table(table_name, filters)
        for row in rows:
            yield TensorComparisonRecord(*row)

    def query_buffer_pages(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[BufferPage, None, None]:
        rows = self._query_table("buffer_pages", filters)
        for row in rows:
            yield BufferPage(*row)

    def query_tensors(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[Tensor, None, None]:
        # Check if tensors table has a size column (new schema) or we need to infer from joins
        tensor_columns = self._get_table_columns("tensors")
        size_on_tensors = "size" in tensor_columns

        device_tensors_exists = self._check_table_exists("device_tensors")

        if size_on_tensors:
            # New schema: size is on tensors table — simple select without buffer/op joins
            if device_tensors_exists:
                query = """
                    SELECT
                        t.tensor_id, t.shape, t.dtype, t.layout, t.memory_config,
                        t.device_id, t.address, t.buffer_type,
                        t.size,
                        GROUP_CONCAT(dt.device_id || ':' || dt.address, ',') as device_tensors_data
                    FROM tensors t
                    LEFT JOIN device_tensors dt ON dt.tensor_id = t.tensor_id
                    WHERE 1=1
                """
            else:
                query = """
                    SELECT
                        t.tensor_id, t.shape, t.dtype, t.layout, t.memory_config,
                        t.device_id, t.address, t.buffer_type,
                        t.size,
                        NULL as device_tensors_data
                    FROM tensors t
                    WHERE 1=1
                """
        else:
            # Old schema: infer size from buffers via input_tensors/output_tensors joins
            if device_tensors_exists:
                query = """
                    SELECT
                        t.tensor_id, t.shape, t.dtype, t.layout, t.memory_config,
                        t.device_id, t.address, t.buffer_type,
                        b.max_size_per_bank as size,
                        GROUP_CONCAT(dt.device_id || ':' || dt.address, ',') as device_tensors_data
                    FROM tensors t
                    LEFT JOIN input_tensors it ON it.tensor_id = t.tensor_id
                    LEFT JOIN output_tensors ot ON ot.tensor_id = t.tensor_id
                    LEFT JOIN buffers b ON b.operation_id = COALESCE(it.operation_id, ot.operation_id)
                        AND t.address = b.address
                        AND t.device_id = b.device_id
                    LEFT JOIN device_tensors dt ON dt.tensor_id = t.tensor_id
                    WHERE 1=1
                """
            else:
                query = """
                    SELECT
                        t.tensor_id, t.shape, t.dtype, t.layout, t.memory_config,
                        t.device_id, t.address, t.buffer_type,
                        b.max_size_per_bank as size,
                        NULL as device_tensors_data
                    FROM tensors t
                    LEFT JOIN input_tensors it ON it.tensor_id = t.tensor_id
                    LEFT JOIN output_tensors ot ON ot.tensor_id = t.tensor_id
                    LEFT JOIN buffers b ON b.operation_id = COALESCE(it.operation_id, ot.operation_id)
                        AND t.address = b.address
                        AND t.device_id = b.device_id
                    WHERE 1=1
                """
        params = []

        # Apply filters to tensors table
        if filters:
            for column, value in filters.items():
                if value is None:
                    continue

                if isinstance(value, list):
                    if len(value) == 0:
                        continue
                    placeholders = ", ".join(["?"] * len(value))
                    query += f" AND t.{column} IN ({placeholders})"
                    params.extend(value)
                else:
                    query += f" AND t.{column} = ?"
                    params.append(value)

        query += " GROUP BY t.tensor_id"

        rows = self.query_runner.execute_query(query, params)
        for row in rows:
            tensor_row = row[:8]
            size = row[8]
            device_tensors_data = row[9]

            device_addresses = []

            if device_tensors_data:
                # Parse the concatenated device_id:address pairs
                pairs = device_tensors_data.split(",")
                device_tensor_list = []
                for pair in pairs:
                    if pair:
                        device_id_str, address_str = pair.split(":")
                        device_id = int(device_id_str)
                        address = int(address_str)
                        device_tensor_list.append((device_id, address))

                # Sort by device_id and build the list with proper indexing
                for device_id, address in sorted(
                    device_tensor_list, key=lambda x: x[0]
                ):
                    while len(device_addresses) < device_id:
                        device_addresses.append(None)
                    device_addresses.append(address)

            yield Tensor(*tensor_row, device_addresses, size=size)

    def query_input_tensors(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[InputTensor, None, None]:
        rows = self._query_table("input_tensors", filters)
        for row in rows:
            yield InputTensor(*row)

    def query_output_tensors(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[OutputTensor, None, None]:
        rows = self._query_table("output_tensors", filters)
        for row in rows:
            yield OutputTensor(*row)

    def query_devices(
        self, filters: Optional[Dict[str, Any]] = None
    ) -> Generator[Device, None, None]:
        # Get the expected Device model field names in order
        device_fields = [field.name for field in dataclasses.fields(Device)]

        # Get all columns from the devices table
        all_columns = self._get_table_columns("devices")

        # Filter out num_storage_cores if it exists (for backwards compatibility)
        # and ensure columns are in the order expected by the Device model
        available_columns = set(all_columns) - {"num_storage_cores"}
        columns = [col for col in device_fields if col in available_columns]

        rows = self._query_table("devices", filters, columns=columns)

        for row in rows:
            yield Device(*row)

    def query_producers_consumers(self) -> Generator[ProducersConsumers, None, None]:
        query = """
            SELECT
                t.tensor_id,
                GROUP_CONCAT(ot.operation_id, ', ') AS consumers,
                GROUP_CONCAT(it.operation_id, ', ') AS producers
            FROM
                tensors t
            LEFT JOIN
                input_tensors it ON t.tensor_id = it.tensor_id
            LEFT JOIN
                output_tensors ot on t.tensor_id = ot.tensor_id
            GROUP BY
                t.tensor_id
        """
        rows = self.query_runner.execute_query(query)
        for row in rows:
            tensor_id, producers_data, consumers_data = row
            producers = sorted(
                set(map(int, producers_data.strip('"').split(",")))
                if producers_data
                else []
            )
            consumers = sorted(
                set(map(int, consumers_data.strip('"').split(",")))
                if consumers_data
                else []
            )
            yield ProducersConsumers(tensor_id, producers, consumers)

    def query_report_metadata(
        self,
    ) -> list[tuple[str, str | None]]:
        """
        Returns all rows from report_metadata (key, value).
        Caller must ensure the table exists (e.g. via _check_table_exists).
        """
        rows = self._query_table("report_metadata", columns=["key", "value"])
        return rows

    def query_next_buffer(self, operation_id: int, address: str) -> Optional[Buffer]:
        query = """
            SELECT
                buffers.operation_id,
                buffers.device_id,
                buffers.address,
                buffers.max_size_per_bank,
                buffers.buffer_type
            FROM
                buffers
            WHERE
                buffers.address = ?
                AND buffers.operation_id > ?
            ORDER BY buffers.operation_id
        """
        rows = self.query_runner.execute_query(query, [address, operation_id])
        return Buffer(*rows[0]) if rows else None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if isinstance(self.query_runner, LocalQueryRunner):
            self.query_runner.close()
