import karrio.schemas.fedex.shipping_request as fedex
import karrio.schemas.fedex.shipping_responses as shipping
import typing
import datetime
import karrio.lib as lib
import karrio.core.units as units
import karrio.core.models as models
import karrio.providers.fedex.error as provider_error
import karrio.providers.fedex.utils as provider_utils
import karrio.providers.fedex.units as provider_units


def parse_shipment_response(
    _response: lib.Deserializable[typing.List[dict]],
    settings: provider_utils.Settings,
) -> typing.Tuple[typing.List[models.RateDetails], typing.List[models.Message]]:
    response = _response.deserialize()

    messages = provider_error.parse_error_response(response, settings)
    shipment = lib.identity(
        _extract_details(
            response["output"]["transactionShipments"][0],
            settings,
            ctx=_response.ctx,
        )
        if response.get("errors") is None
        and response.get("output") is not None
        and response.get("output").get("transactionShipments") is not None
        else None
    )

    return shipment, messages


def _get_doc_content(doc: shipping.DocumentType) -> typing.Optional[str]:
    return doc.encodedLabel or (lib.request(url=doc.url, decoder=lib.encode_base64) if doc.url else None)


def _get_doc_category(content_type: str) -> str:
    category_map = {
        "RETURN": "return_label",
        "CUSTOMS": "customs_document",
        "CERTIFICATE_OF_ORIGIN": "customs_document",
        "DANGEROUS": "dangerous_goods_document",
        "PACKING": "packing_list",
        "RECEIPT": "shipping_receipt",
    }
    return next((cat for key, cat in category_map.items() if key in content_type), "other")


def _extract_details(
    data: dict,
    settings: provider_utils.Settings,
    ctx: dict = {},
) -> models.ShipmentDetails:
    shipment = lib.to_object(shipping.TransactionShipmentType, data)
    service = provider_units.ShippingService.map(shipment.serviceType)
    piece_documents = sum([_.packageDocuments or [] for _ in shipment.pieceResponses], start=[])
    tracking_number = shipment.masterTrackingNumber
    return_service = ctx.get("return_service")

    invoices = [d for d in (shipment.shipmentDocuments or []) if d.contentType and "INVOICE" in d.contentType]
    labels = [d for d in piece_documents if d.contentType and "LABEL" in d.contentType]

    invoice_type = invoices[0].docType if invoices else "PDF"
    invoice = lib.bundle_base64(
        [_get_doc_content(d) for d in invoices], invoice_type
    ) if invoices else None

    label_type = labels[0].docType if labels else "PDF"
    label = lib.bundle_base64(
        [_get_doc_content(d) for d in labels], label_type
    ) if labels else None

    # Collect extra documents (excluding primary labels and invoices)
    is_primary_doc = lambda ct: ct and ("LABEL" in ct or "INVOICE" in ct)
    shipment_docs = [
        (d, d.contentType or "")
        for d in (shipment.shipmentDocuments or [])
        if not is_primary_doc(d.contentType) and _get_doc_content(d)
    ]
    package_docs = [
        (d, d.contentType or "")
        for d in piece_documents
        if d not in labels and _get_doc_content(d)
    ]

    return models.ShipmentDetails(
        carrier_id=settings.carrier_id,
        carrier_name=settings.carrier_name,
        tracking_number=tracking_number,
        shipment_identifier=tracking_number,
        label_type=label_type,
        docs=models.Documents(
            label=label,
            invoice=invoice,
            extra_documents=[
                models.ShippingDocument(
                    category=_get_doc_category(content_type),
                    format=doc.docType or "PDF",
                    base64=_get_doc_content(doc),
                )
                for doc, content_type in (shipment_docs + package_docs)
            ],
        ),
        return_shipment=lib.identity(
            models.ReturnShipment(
                tracking_number=tracking_number,
                shipment_identifier=tracking_number,
                tracking_url=settings.tracking_url.format(tracking_number),
                service=return_service,
            )
            if return_service
            else None
        ),
        meta=dict(
            service_name=service.name_or_key,
            carrier_tracking_link=settings.tracking_url.format(tracking_number),
            trackingIdType=shipment.pieceResponses[0].trackingIdType,
            serviceCategory=shipment.pieceResponses[0].serviceCategory,
            fedex_carrier_code=lib.failsafe(
                lambda: shipment.completedShipmentDetail.carrierCode
            ),
        ),
    )


def shipment_request(
    payload: models.ShipmentRequest,
    settings: provider_utils.Settings,
) -> lib.Serializable:
    shipper = lib.to_address(payload.shipper)
    recipient = lib.to_address(payload.recipient)
    service = provider_units.ShippingService.map(payload.service).value_or_key
    options = lib.to_shipping_options(
        payload.options,
        initializer=provider_units.shipping_options_initializer,
    )
    packages = lib.to_packages(
        payload.parcels,
        required=["weight"],
        options=options,
        presets=provider_units.PackagePresets,
        shipping_options_initializer=provider_units.shipping_options_initializer,
    )

    default_currency = lib.identity(
        options.currency.state
        or settings.default_currency
        or units.CountryCurrency.map(payload.shipper.country_code).value
        or "USD"
    )
    weight_unit, dim_unit = lib.identity(
        provider_units.COUNTRY_PREFERED_UNITS.get(payload.shipper.country_code)
        or packages.compatible_units
    )
    customs = lib.to_customs_info(
        payload.customs,
        shipper=payload.shipper,
        recipient=payload.recipient,
        weight_unit=weight_unit.value,
    )
    is_intl = lib.identity(
        shipper.country_code != recipient.country_code
        or (shipper.country_code == "IN" and recipient.country_code == "IN")
    )
    shipment_date = lib.to_date(options.shipment_date.state or datetime.datetime.now())
    label_type, label_format = lib.identity(
        provider_units.LabelType.map(payload.label_type or "PDF_4x6").value
    )
    return_address = lib.to_address(payload.return_address)
    billing_address = lib.to_address(
        payload.billing_address
        or dict(
            sender=payload.shipper,
            recipient=payload.recipient,
            third_party=payload.billing_address,
        )[payload.payment.paid_by]
    )
    duty_billing_address = lib.to_address(
        customs.duty_billing_address
        or dict(
            sender=payload.shipper,
            recipient=payload.recipient,
            third_party=customs.duty_billing_address or billing_address or shipper,
        ).get(customs.duty.paid_by)
    )
    duty_payment_type = lib.identity(
        provider_units.PaymentType.map(customs.duty.paid_by).value
    )
    payment_account_number = lib.identity(
        payload.payment.account_number
        if payload.payment and payload.payment.paid_by != "sender"
        else settings.account_number
    )
    duty_payment_account_number = lib.identity(
        customs.duty.account_number
        if customs.duty and customs.duty.paid_by != "sender"
        else payment_account_number
    )
    package_options = lambda _options: [
        option
        for _, option in _options.items()
        if option.state is not False and option.code in provider_units.PACKAGE_OPTIONS
    ]
    shipment_options = lambda _options: [
        option
        for _, option in _options.items()
        if option.state is not False and option.code in provider_units.SHIPMENT_OPTIONS
    ]
    hub_id = lib.identity(
        lib.text(options.fedex_smart_post_hub_id.state)
        or lib.text(settings.connection_config.smart_post_hub_id.state)
    )
    request_types = lib.identity(
        settings.connection_config.rate_request_types.state
        if any(settings.connection_config.rate_request_types.state or [])
        else ["LIST", "ACCOUNT", *([] if "currency" not in options else ["PREFERRED"])]
    )

    requests = fedex.ShippingRequestType(
        mergeLabelDocOption=None,
        requestedShipment=fedex.RequestedShipmentType(
            shipDatestamp=lib.fdate(shipment_date, "%Y-%m-%d"),
            totalDeclaredValue=lib.identity(
                fedex.TotalDeclaredValueType(
                    amount=lib.to_money(options.declared_value.state),
                    currency=options.currency.state or default_currency,
                )
                if options.declared_value.state
                else None
            ),
            shipper=fedex.ShipperType(
                address=fedex.AddressType(
                    streetLines=shipper.address_lines,
                    city=shipper.city,
                    stateOrProvinceCode=provider_utils.state_code(shipper),
                    postalCode=shipper.postal_code,
                    countryCode=shipper.country_code,
                    residential=shipper.residential,
                ),
                contact=fedex.ContactType(
                    personName=lib.text(shipper.contact, max=35),
                    emailAddress=shipper.email,
                    phoneNumber=lib.text(
                        shipper.phone_number or "000-000-0000",
                        max=15,
                        trim=True,
                    ),
                    phoneExtension=None,
                    companyName=lib.text(shipper.company_name, max=35),
                    faxNumber=None,
                ),
                tins=lib.identity(
                    fedex.TinType(number=shipper.tax_id) if shipper.has_tax_info else []
                ),
                deliveryInstructions=options.shipper_instructions.state,
            ),
            soldTo=None,
            recipients=[
                fedex.ShipperType(
                    address=fedex.AddressType(
                        streetLines=recipient.address_lines,
                        city=recipient.city,
                        stateOrProvinceCode=provider_utils.state_code(recipient),
                        postalCode=recipient.postal_code,
                        countryCode=recipient.country_code,
                        residential=recipient.residential,
                    ),
                    contact=fedex.ContactType(
                        personName=lib.text(recipient.person_name, max=35),
                        emailAddress=recipient.email,
                        phoneNumber=lib.text(
                            recipient.phone_number
                            or shipper.phone_number
                            or "000-000-0000",
                            max=15,
                            trim=True,
                        ),
                        phoneExtension=None,
                        companyName=lib.text(recipient.company_name, max=35),
                        faxNumber=None,
                    ),
                    tins=(
                        fedex.TinType(number=recipient.tax_id)
                        if recipient.has_tax_info
                        else []
                    ),
                    deliveryInstructions=options.recipient_instructions.state,
                )
            ],
            recipientLocationNumber=None,
            pickupType="DROPOFF_AT_FEDEX_LOCATION",
            serviceType=service,
            packagingType=lib.identity(
                provider_units.PackagingType.map(
                    packages.package_type or "your_packaging"
                ).value
            ),
            totalWeight=packages.weight.LB,
            origin=lib.identity(
                fedex.OriginType(
                    address=fedex.AddressType(
                        streetLines=return_address.address_lines,
                        city=return_address.city,
                        stateOrProvinceCode=provider_utils.state_code(return_address),
                        postalCode=return_address.postal_code,
                        countryCode=return_address.country_code,
                        residential=return_address.residential,
                    ),
                    contact=fedex.ContactType(
                        personName=lib.text(return_address.contact, max=35),
                        emailAddress=return_address.email,
                        phoneNumber=lib.text(
                            return_address.phone_number or "000-000-0000",
                            max=15,
                            trim=True,
                        ),
                        phoneExtension=None,
                        companyName=lib.text(return_address.company_name, max=35),
                        faxNumber=None,
                    ),
                )
                if payload.return_address is not None
                else None
            ),
            shippingChargesPayment=fedex.ShippingChargesPaymentType(
                paymentType=provider_units.PaymentType.map(
                    payload.payment.paid_by
                ).value_or_key,
                payor=fedex.PayorType(
                    responsibleParty=fedex.ShipperType(
                        address=lib.identity(
                            fedex.AddressType(
                                streetLines=billing_address.address_lines,
                                city=billing_address.city,
                                stateOrProvinceCode=provider_utils.state_code(
                                    billing_address
                                ),
                                postalCode=billing_address.postal_code,
                                countryCode=billing_address.country_code,
                                residential=billing_address.residential,
                            )
                            if billing_address.address is not None
                            else None
                        ),
                        contact=lib.identity(
                            fedex.ContactType(
                                personName=lib.text(billing_address.contact, max=35),
                                emailAddress=billing_address.email,
                                phoneNumber=lib.text(
                                    billing_address.phone_number
                                    or shipper.phone_number
                                    or "000-000-0000",
                                    max=15,
                                    trim=True,
                                ),
                                phoneExtension=None,
                                companyName=lib.text(
                                    billing_address.company_name, max=35
                                ),
                                faxNumber=None,
                            )
                            if billing_address.address is not None
                            else None
                        ),
                        accountNumber=fedex.AccountNumberType(
                            value=payment_account_number
                        ),
                        tins=lib.identity(
                            fedex.TinType(number=billing_address.tax_id)
                            if billing_address.has_tax_info
                            else []
                        ),
                    )
                ),
            ),
            shipmentSpecialServices=lib.identity(
                fedex.ShipmentSpecialServicesType(
                    specialServiceTypes=lib.identity(
                        [option.code for option in shipment_options(packages.options)]
                        if shipment_options(packages.options)
                        else None
                    ),
                    etdDetail=lib.identity(
                        fedex.EtdDetailType(
                            attributes=lib.identity(
                                None
                                if options.doc_files.state
                                or options.doc_references.state
                                else ["POST_SHIPMENT_UPLOAD_REQUESTED"]
                            ),
                            attachedDocuments=lib.identity(
                                [
                                    fedex.AttachedDocumentType(
                                        documentType=(
                                            provider_units.UploadDocumentType.map(
                                                doc["doc_type"]
                                            ).value
                                            or "COMMERCIAL_INVOICE"
                                        ),
                                        documentReference=(
                                            payload.reference
                                            or packages[0].reference_number
                                            or getattr(payload, "id", None)
                                        ),
                                        description=None,
                                        documentId=None,
                                    )
                                    for doc in options.doc_files.state
                                ]
                                if (options.doc_files.state or [])
                                else []
                            ),
                            requestedDocumentTypes=["COMMERCIAL_INVOICE"],
                        )
                        if options.fedex_electronic_trade_documents.state
                        else None
                    ),
                    returnShipmentDetail=lib.identity(
                        fedex.ReturnShipmentDetailType(
                            returnType="PRINT_RETURN_LABEL",
                        )
                        if options.fedex_return_shipment.state
                        else None
                    ),
                    deliveryOnInvoiceAcceptanceDetail=None,
                    internationalTrafficInArmsRegulationsDetail=None,
                    pendingShipmentDetail=None,
                    holdAtLocationDetail=None,
                    shipmentCODDetail=lib.identity(
                        fedex.ShipmentCODDetailType(
                            addTransportationChargesDetail=None,
                            codRecipient=None,
                            remitToName=None,
                            codCollectionType="CASH",
                            financialInstitutionContactAndAddress=None,
                            codCollectionAmount=fedex.TotalDeclaredValueType(
                                amount=lib.to_money(options.cash_on_delivery.state),
                                currency=lib.identity(
                                    options.currency.state or default_currency
                                ),
                            ),
                            returnReferenceIndicatorType=None,
                            shipmentCodAmount=None,
                        )
                        if options.cash_on_delivery.state
                        else None
                    ),
                    shipmentDryIceDetail=None,
                    internationalControlledExportDetail=None,
                    homeDeliveryPremiumDetail=None,
                )
                if any(shipment_options(packages.options))
                else None
            ),
            emailNotificationDetail=lib.identity(
                fedex.RequestedShipmentEmailNotificationDetailType(
                    aggregationType="PER_SHIPMENT",
                    emailNotificationRecipients=[
                        fedex.EmailNotificationRecipientType(
                            name=recipient.person_name,
                            emailNotificationRecipientType="RECIPIENT",
                            emailAddress=lib.identity(
                                options.email_notification_to.state or recipient.email
                            ),
                            notificationFormatType="HTML",
                            notificationType="EMAIL",
                            notificationEventType=[
                                "ON_DELIVERY",
                                "ON_EXCEPTION",
                                "ON_SHIPMENT",
                            ],
                        )
                    ],
                    personalMessage=None,
                )
                if (payload.options or {}).get("email_notification") is True
                or options.email_notification_to.state
                else None
            ),
            expressFreightDetail=None,
            variableHandlingChargeDetail=None,
            customsClearanceDetail=lib.identity(
                fedex.CustomsClearanceDetailType(
                    regulatoryControls=None,
                    brokers=[],
                    commercialInvoice=fedex.CommercialInvoiceType(
                        originatorName=lib.text(
                            shipper.company_name or shipper.contact, max=35
                        ),
                        comments=None,
                        customerReferences=(
                            [
                                fedex.CustomerReferenceType(
                                    customerReferenceType="INVOICE_NUMBER",
                                    value=customs.invoice,
                                )
                            ]
                            if customs.invoice
                            else []
                        ),
                        taxesOrMiscellaneousCharge=None,
                        taxesOrMiscellaneousChargeType=None,
                        freightCharge=None,
                        packingCosts=None,
                        handlingCosts=None,
                        declarationStatement=None,
                        termsOfSale=provider_units.Incoterm.map(
                            customs.incoterm or "DDU"
                        ).value,
                        specialInstructions=None,
                        shipmentPurpose=provider_units.PurposeType.map(
                            customs.content_type or "other"
                        ).value,
                        emailNotificationDetail=None,
                    ),
                    freightOnValue=None,
                    dutiesPayment=fedex.DutiesPaymentType(
                        paymentType=duty_payment_type,
                        payor=lib.identity(
                            fedex.PayorType(
                                responsibleParty=fedex.ShipperType(
                                    address=lib.identity(
                                        fedex.AddressType(
                                            streetLines=duty_billing_address.address_lines,
                                            city=duty_billing_address.city,
                                            stateOrProvinceCode=provider_utils.state_code(
                                                duty_billing_address
                                            ),
                                            postalCode=duty_billing_address.postal_code,
                                            countryCode=duty_billing_address.country_code,
                                            residential=duty_billing_address.residential,
                                        )
                                        if duty_billing_address.address
                                        else None
                                    ),
                                    contact=lib.identity(
                                        fedex.ContactType(
                                            personName=lib.text(
                                                duty_billing_address.contact, max=35
                                            ),
                                            emailAddress=duty_billing_address.email,
                                            phoneNumber=lib.text(
                                                duty_billing_address.phone_number
                                                or shipper.phone_number
                                                or "000-000-0000",
                                                max=15,
                                                trim=True,
                                            ),
                                            phoneExtension=None,
                                            companyName=lib.text(
                                                duty_billing_address.company_name,
                                                max=35,
                                            ),
                                            faxNumber=None,
                                        )
                                        if duty_billing_address.address
                                        else None
                                    ),
                                    accountNumber=lib.identity(
                                        fedex.AccountNumberType(
                                            value=duty_payment_account_number
                                        )
                                        if duty_payment_account_number
                                        else None
                                    ),
                                    tins=lib.identity(
                                        fedex.TinType(
                                            number=duty_billing_address.tax_id,
                                            tinType="FEDERAL",
                                        )
                                        if duty_billing_address.has_tax_info
                                        else []
                                    ),
                                )
                            )
                            if duty_billing_address.address
                            else None
                        ),
                    ),
                    commodities=[
                        fedex.CommodityType(
                            unitPrice=lib.identity(
                                fedex.TotalDeclaredValueType(
                                    amount=lib.to_money(item.value_amount),
                                    currency=lib.identity(
                                        item.value_currency
                                        or packages.options.currency.state
                                        or default_currency
                                    ),
                                )
                                if item.value_amount
                                else None
                            ),
                            additionalMeasures=[],
                            numberOfPieces=item.quantity,
                            quantity=item.quantity,
                            quantityUnits="PCS",
                            customsValue=fedex.CustomsValueType(
                                amount=lib.identity(
                                    lib.to_money(item.value_amount * item.quantity)
                                    if item.value_amount is not None
                                    else 0.0
                                ),
                                currency=lib.identity(
                                    item.value_currency
                                    or packages.options.currency.state
                                    or default_currency
                                ),
                            ),
                            countryOfManufacture=(
                                item.origin_country or shipper.country_code
                            ),
                            cIMarksAndNumbers=None,
                            harmonizedCode=item.hs_code,
                            description=lib.text(
                                item.description or item.title or "N/A", max=35
                            ),
                            name=lib.text(item.title, max=35),
                            weight=fedex.WeightType(
                                units=weight_unit.value,
                                value=item.weight,
                            ),
                            exportLicenseNumber=None,
                            exportLicenseExpirationDate=None,
                            partNumber=item.sku,
                            purpose=None,
                            usmcaDetail=None,
                        )
                        for item in customs.commodities
                    ],
                    isDocumentOnly=packages.is_document,
                    recipientCustomsId=None,
                    customsOption=None,
                    importerOfRecord=None,
                    generatedDocumentLocale=None,
                    exportDetail=None,
                    totalCustomsValue=lib.identity(
                        fedex.TotalDeclaredValueType(
                            amount=lib.to_money(packages.options.declared_value.state),
                            currency=lib.identity(
                                packages.options.currency.state or default_currency
                            ),
                        )
                        if lib.to_money(packages.options.declared_value.state)
                        is not None
                        else None
                    ),
                    partiesToTransactionAreRelated=None,
                    declarationStatementDetail=None,
                    insuranceCharge=fedex.TotalDeclaredValueType(
                        amount=packages.options.insurance.state or 0.0,
                        currency=lib.identity(
                            packages.options.currency.state or default_currency
                        ),
                    ),
                )
                if payload.customs is not None and is_intl
                else None
            ),
            smartPostInfoDetail=lib.identity(
                fedex.SmartPostInfoDetailType(
                    ancillaryEndorsement=None,
                    hubId=hub_id,
                    indicia=(
                        lib.text(options.fedex_smart_post_allowed_indicia.state)
                        or "PARCEL_SELECT"
                    ),
                    specialServices=None,
                )
                if hub_id and service == "SMART_POST"
                else None
            ),
            blockInsightVisibility=False,
            labelSpecification=fedex.LabelSpecificationType(
                labelFormatType="COMMON2D",
                labelOrder="SHIPPING_LABEL_FIRST",
                customerSpecifiedDetail=None,
                printedLabelOrigin=None,
                labelStockType=label_format,
                labelRotation=None,
                imageType=label_type,
                labelPrintingOrientation=None,
                returnedDispositionDetail=None,
            ),
            shippingDocumentSpecification=lib.identity(
                fedex.ShippingDocumentSpecificationType(
                    generalAgencyAgreementDetail=None,
                    returnInstructionsDetail=None,
                    op900Detail=None,
                    usmcaCertificationOfOriginDetail=None,
                    usmcaCommercialInvoiceCertificationOfOriginDetail=None,
                    shippingDocumentTypes=["COMMERCIAL_INVOICE"],
                    certificateOfOrigin=None,
                    commercialInvoiceDetail=fedex.CertificateOfOriginType(
                        customerImageUsages=[],
                        documentFormat=fedex.DocumentFormatType(
                            provideInstructions=None,
                            optionsRequested=None,
                            stockType="PAPER_LETTER",
                            dispositions=[],
                            locale=None,
                            docType="PDF",
                        ),
                    ),
                )
            ),
            rateRequestType=request_types,
            preferredCurrency=packages.options.currency.state,
            totalPackageCount=len(packages),
            masterTrackingId=None,
            requestedPackageLineItems=[
                fedex.RequestedPackageLineItemType(
                    sequenceNumber=None,
                    subPackagingType="OTHER",
                    customerReferences=[],
                    declaredValue=fedex.TotalDeclaredValueType(
                        amount=lib.identity(
                            lib.to_money(package.total_value)
                            or lib.to_money(package.options.declared_value.state)
                            or 0.0
                        ),
                        currency=lib.identity(
                            packages.options.currency.state or default_currency
                        ),
                    ),
                    weight=fedex.WeightType(
                        units=package.weight.unit,
                        value=package.weight.value,
                    ),
                    dimensions=lib.identity(
                        fedex.DimensionsType(
                            length=package.length.map(
                                provider_units.MeasurementOptions
                            ).value,
                            width=package.width.map(
                                provider_units.MeasurementOptions
                            ).value,
                            height=package.height.map(
                                provider_units.MeasurementOptions
                            ).value,
                            units=dim_unit.value,
                        )
                        if (
                            # only set dimensions if the packaging type is set to your_packaging
                            package.has_dimensions
                            and provider_units.PackagingType.map(
                                package.packaging_type or "your_packaging"
                            ).value
                            == provider_units.PackagingType.your_packaging.value
                        )
                        else None
                    ),
                    groupPackageCount=1,
                    itemDescriptionForClearance=None,
                    contentRecord=[],
                    itemDescription=package.parcel.description,
                    variableHandlingChargeDetail=None,
                    packageSpecialServices=fedex.PackageSpecialServicesType(
                        specialServiceTypes=[
                            option.code for option in package_options(package.options)
                        ],
                        priorityAlertDetail=None,
                        signatureOptionType=lib.identity(
                            provider_units.SignatureOptionType.map(
                                package.options.fedex_signature_option.state
                            ).value
                            or (
                                "DIRECT"
                                if package.options.fedex_signature_option.state
                                else None
                            )
                        ),
                        signatureOptionDetail=None,
                        alcoholDetail=None,
                        dangerousGoodsDetail=None,
                        packageCODDetail=None,
                        pieceCountVerificationBoxCount=None,
                        batteryDetails=[],
                        dryIceWeight=None,
                    ),
                    trackingNumber=None,
                )
                for package in packages
            ],
        ),
        labelResponseOptions="LABEL",
        accountNumber=fedex.AccountNumberType(value=settings.account_number),
        shipAction="CONFIRM",
        processingOptionType=None,
        oneLabelAtATime=False,
    )

    return lib.Serializable(
        requests,
        lib.to_dict,
        dict(
            shipment_date=shipment_date,
            label_type=label_type,
            label_format=label_format,
            return_service=lib.identity(
                "fedex_return_shipment" if options.fedex_return_shipment.state else None
            ),
        ),
    )
