import os
import json
import uuid
from .utils import print_error

LOCAL_CONFIG_FILE = ".appforge.json"
HISTORY_FILE = os.path.expanduser("~/.appforge_history.json")

def load_history():
    """Loads the global build history from the user's home directory."""
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def save_history(history_data):
    """Saves the global build history."""
    with open(HISTORY_FILE, "w") as f:
        json.dump(history_data, f, indent=2)

def add_to_history(new_build_entry):
    """Adds a new build record to the history."""
    history = load_history()
    # Prepend the new entry to the top of the list
    history.insert(0, new_build_entry)
    # Keep the history from getting too long (e.g., max 50 entries)
    if len(history) > 50:
        history = history[:50]
    save_history(history)

def load_local_config():
    if not os.path.exists(LOCAL_CONFIG_FILE):
        return {}
    with open(LOCAL_CONFIG_FILE, "r") as f:
        return json.load(f)

def save_local_config(data):
    config = load_local_config()
    config.update(data)
    with open(LOCAL_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

def get_app_id():
    config = load_local_config()
    if "app_id" not in config:
        new_id = str(uuid.uuid4())[:8] # Generate a short 8-character unique ID
        save_local_config({"app_id": new_id})
        return new_id
    return config["app_id"]
