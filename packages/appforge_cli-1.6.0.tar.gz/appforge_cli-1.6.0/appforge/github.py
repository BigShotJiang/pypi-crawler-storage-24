import os
import zipfile
import requests
import sys
import threading
import shutil
import time
import base64
from .config import get_app_id, load_local_config, add_to_history
from .utils import print_success, print_info, print_error, run_with_spinner, GRAY, RESET, GREEN, RED, CYAN, YELLOW, BOLD, print_progress_bar
from .injector import inject_metadata_locally

GITHUB_API_URL = "https://api.github.com"
BUILD_REPO_OWNER = "juniorsir" 
BUILD_REPO_NAME = "appforge-build"
MASTER_SYSTEM_TOKEN = "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" # <-- PUT YOUR TOKEN HERE

def get_headers():
    return {
        "Authorization": f"Bearer {MASTER_SYSTEM_TOKEN}",
        "Accept": "application/vnd.github.v3+json",
        "X-GitHub-Api-Version": "2022-11-28"
    }

# --- Inside github.py ---

def zip_project(category, sub_path=".", zip_name="app_source.zip"):
    """Zips the project, ensuring the icon is ready for @capacitor/assets."""
    config = load_local_config()
    
    # --- UPDATED PRE-ZIP ASSET COPIER ---
    icon_path = config.get("iconPath")
    copied_icons = []
    
    if icon_path and os.path.exists(icon_path):
        try:
            import shutil
            # @capacitor/assets expects the icon to be in an 'assets' folder at the root
            os.makedirs("assets", exist_ok=True)
            
            # It looks specifically for 'icon.png' and 'splash.png'
            target_icon = os.path.join("assets", "icon.png")
            shutil.copy2(icon_path, target_icon)
            copied_icons.append(target_icon)
            
            # Optional: If you want to use the same image for the splash screen
            splash_path = config.get("splashImg")
            if splash_path and os.path.exists(splash_path):
                target_splash = os.path.join("assets", "splash.png")
                shutil.copy2(splash_path, target_splash)
                copied_icons.append(target_splash)
            elif not os.path.exists(os.path.join("assets", "splash.png")):
                # Fallback to using the icon as the splash if none provided
                target_splash = os.path.join("assets", "splash.png")
                shutil.copy2(icon_path, target_splash)
                copied_icons.append(target_splash)

        except Exception as e:
            print_error(f"Failed to prepare app assets for upload: {e}")
    # ------------------------------------

    def do_zip():
        original_dir = os.getcwd()
        
        if sub_path != ".":
            depth = len(sub_path.split(os.sep))
            up_path = os.path.join(*(['..'] * depth))
            os.chdir(up_path)

        if category == 'web':
            # WARNING: We must NOT ignore the 'assets' folder anymore!
            ignore_list = ['node_modules', '.git', 'android', 'ios', '.next', '.nuxt', 'build', 'dist']
        else:
            ignore_list = ['node_modules', '.git', '.dart_tool', 'build', '.gradle', 'android', 'ios']

        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk('.'):
                dirs[:] = [d for d in dirs if d not in ignore_list]
                for file in files:
                    if file == zip_name:
                        continue
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, file_path)
                    
        if sub_path != ".":
            shutil.move(zip_name, os.path.join(original_dir, zip_name))
            os.chdir(original_dir) 
            
    run_with_spinner(do_zip, "Zipping project files")
    
    # Clean up the temporary assets folder after zipping so we don't clutter the user's project
    if copied_icons:
        try:
            shutil.rmtree("assets")
        except:
            pass
        
    return zip_name


def push_and_build(config):
    """Pushes the zipped project and triggers the cloud build."""
    # Extract needed info from the config
    category = config.get("category", "web")
    platform = config.get("platform", "android")
    app_id = get_app_id()
    sub_path = config.get("sub_path", ".")

    try:
        inject_metadata_locally(config)
    except Exception as e:
        print_error(f"Failed to inject local metadata: {e}")

    # Pass the category to the zipping function
    zip_path = zip_project(category, sub_path)

    zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    if zip_size_mb > 50:
        os.remove(zip_path)
        print_error(f"Project too large ({zip_size_mb:.1f}MB). GitHub limits API uploads to ~50MB.\n"
                    f"Please remove heavy assets (videos, large images, pre-compiled binaries) and try again.")

    headers = get_headers()
    
    print_info(f"Uploading app (ID: {app_id})...")
    
    upload_result = {"success": False, "error": None}
    
    def actual_upload_task():
        try:
            with open(zip_path, "rb") as f:
                content_b64 = base64.b64encode(f.read()).decode("utf-8")
            
            url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/contents/apps/{app_id}/source.zip"
            sha = None
            res = requests.get(url, headers=headers)
            if res.status_code == 200: sha = res.json().get("sha")

            data = {"message": f"Upload for {app_id}", "content": content_b64, "branch": "main"}
            if sha: data["sha"] = sha
            
            put_res = requests.put(url, headers=headers, json=data)
            if put_res.status_code not in [200, 201]:
                raise Exception(f"API Error: {put_res.json().get('message')}")
            
            upload_result["success"] = True
        except Exception as e:
            upload_result["error"] = e

    # Start the real upload in a background thread
    upload_thread = threading.Thread(target=actual_upload_task)
    upload_thread.start()

    # While the thread is running, draw a simulated progress bar
    progress = 0
    while upload_thread.is_alive():
        # This makes the bar fill up nicely over a few seconds
        progress = min(progress + 5, 99.0)
        print_progress_bar(progress, "Uploading")
        time.sleep(0.1)
    
    # Check the result from the thread
    if upload_result["success"]:
        print_progress_bar(100.0, "Uploading")
        print_success("Upload complete.")
    else:
        print("") # Newline after the failed bar
        print_error(f"Upload failed: {upload_result['error']}")

    os.remove(zip_path)

    def do_trigger():
        # Load the full config again just to be safe
        full_config = load_local_config()
        proj_category = full_config.get("category", "web")
        proj_type = full_config.get("project_type", "unknown")

        build_type = full_config.get("buildMode", "debug")

        app_name = full_config.get("appName", "AppForge App")
        package_id = full_config.get("packageId", "com.appforge.app")

        dispatch_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/workflows/build.yml/dispatches"
        
        dispatch_data = {
            "ref": "main", 
            "inputs": {
                "app_id": app_id, 
                "platform": platform,
                "project_category": proj_category,
                "project_type": proj_type,
                "app_version": full_config.get("version", "1.0.0"),
                "sub_path": sub_path,
                "app_name": app_name,         # <-- THESE NOW SEND "Vdl"
                "package_id": package_id,      # <-- AND "com.appforge.vdl"
                "build_type": build_type
            }
        }
        res = requests.post(dispatch_url, headers=headers, json=dispatch_data)
        if res.status_code != 204:
            raise Exception(f"Failed to trigger build. Status {res.status_code}: {res.text}")
        time.sleep(5) # Wait a few seconds for the run to appear in the API
        runs_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/runs?per_page=1"
        run_res = requests.get(runs_url, headers=headers)
        if run_res.status_code == 200 and run_res.json().get("workflow_runs"):
            return run_res.json()["workflow_runs"][0]["id"]
        return None
    run_id = run_with_spinner(do_trigger, "Triggering cloud build")
    from datetime import datetime
    project_name = os.path.basename(os.getcwd())

    # Create the history entry
    new_entry = {
        "app_id": app_id,
        "run_id": run_id,
        "project_name": project_name,
        "platform": config.get("platform", "android"),
        "triggered_at": datetime.utcnow().isoformat() + "Z",
        "status": "triggered" # We can update this later
    }
    add_to_history(new_entry)
def check_status():
    """Streams live build logs from GitHub Actions with step-by-step animations."""
    headers = get_headers()
    url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/runs?per_page=1"
    res = requests.get(url, headers=headers)
    
    if res.status_code != 200:
        print_error("Could not fetch build status from cloud.")
        return

    runs = res.json().get("workflow_runs", [])
    if not runs:
        print_info("No builds found in the cloud yet.")
        return
    
    latest_run = runs[0]
    run_id = latest_run["id"]
    status = latest_run["status"]
    
    if status == "completed":
        conclusion = latest_run.get("conclusion")
        if conclusion == "success":
            print_success(f"Build #{run_id} is already completed! Run 'appforge download'")
        else:
            print_error(f"Build #{run_id} failed with conclusion: {conclusion}")
        return

    print_info(f"Connected to Cloud Build #{run_id}. Streaming live logs...\n")
    
    jobs_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/runs/{run_id}/jobs"
    
    completed_steps = set()
    current_running_step = None
    spinner_chars = "|/-\\"
    spinner_idx = 0
    
    try:
        while True:
            # Animate the currently running step while we wait for the API ping
            for _ in range(20): # Loop fast for smooth animation (20 * 0.15s = 3 seconds)
                if current_running_step:
                    char = spinner_chars[spinner_idx % len(spinner_chars)]
                    # Highlight custom steps in Cyan, normal steps in Gray
                    color = CYAN if "Permission" in current_running_step else GRAY
                    sys.stdout.write(f"\r{color}{char}{RESET}  [Cloud] {current_running_step}...")
                    sys.stdout.flush()
                    spinner_idx += 1
                time.sleep(0.15)

            # Ping the GitHub API
            jobs_res = requests.get(jobs_url, headers=headers)
            if jobs_res.status_code != 200:
                continue
                
            jobs = jobs_res.json().get("jobs", [])
            if not jobs:
                continue
                
            active_job = jobs[0]
            steps = active_job.get("steps", [])
            
            new_running_step = None
            for step in steps:
                step_name = step["name"]
                step_status = step["status"]
                
                if step_status == "completed" and step_name not in completed_steps:
                    completed_steps.add(step_name)
                    
                    sys.stdout.write(f"\r{GREEN}✔{RESET}  [Cloud] {step_name}... {GREEN}done!{RESET}       \n")
                    sys.stdout.flush()

                    if step.get("conclusion") == "failure":
                        print_error(f"\n❌ Cloud Build Failed at step: {step_name}")
                        
                        try:
                            log_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/jobs/{active_job['id']}/logs"
                            log_res = requests.get(log_url, headers=headers)
                            if log_res.status_code == 200:
                                friendly_msg = get_friendly_error(log_res.text)
                                print(f"\n{YELLOW}💡 AppForge Diagnosis:{RESET}\n{friendly_msg}\n")
                        except:
                            pass
                        return
                    if step.get("conclusion") == "failure":
                        print_error(f"\n❌ Cloud Build Failed at step: {step_name}")
                        return
                        
                if step_status == "in_progress":
                    new_running_step = step_name
            
            # Update the current step for the animation loop
            current_running_step = new_running_step

            # Check if the entire cloud job is done
            if active_job["status"] == "completed":
                print("-" * 40)
                
                if active_job["conclusion"] == "success":
                    # 1. JOB SUCCESSFUL? Check if the APK actually exists!
                    artifacts_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/runs/{run_id}/artifacts"
                    art_res = requests.get(artifacts_url, headers=headers)
                    
                    if art_res.status_code == 200 and art_res.json().get("total_count", 0) > 0:
                        # EVERYTHING IS PERFECT
                        print_success(f"{BOLD}✨ Cloud Build Finished Successfully!{RESET}")
                        print_info("Run 'appforge download' to get your app.")
                    else:
                        # SOFT FAILURE: Success but no file!
                        print_warning(f"\n⚠ Build finished, but NO ARTIFACT (APK) was produced.")
                        # Fetch logs to find out why
                        try:
                            log_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/jobs/{active_job['id']}/logs"
                            log_res = requests.get(log_url, headers=headers)
                            friendly_msg = get_friendly_error(log_res.text)
                            print(f"\n{YELLOW}💡 AppForge Diagnosis:{RESET}\n{friendly_msg}\n")
                        except:
                            print_error("Could not retrieve cloud logs for diagnosis.")
                else:
                    # HARD FAILURE: Job crashed
                    print_error("\n❌ Cloud Build Crashed.")
                    # Fetch logs for hard failure
                    try:
                        log_url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/jobs/{active_job['id']}/logs"
                        log_res = requests.get(log_url, headers=headers)
                        friendly_msg = get_friendly_error(log_res.text)
                        print(f"\n{YELLOW}💡 AppForge Diagnosis:{RESET}\n{friendly_msg}\n")
                    except: pass
                break
                
    except KeyboardInterrupt:
        # Clear the spinner line if user hits Ctrl+C
        sys.stdout.write("\r                                                    \r") 
        print(f"\n{YELLOW}⚠ Stopped watching logs. The build is still running in the cloud.{RESET}")
        print_info("You can run 'appforge status' again later to reconnect.")

def get_build_status_by_id(run_id):
    headers = get_headers()
    url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/runs/{run_id}"
    try:
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            data = res.json()
            return (data.get("status"), data.get("conclusion"))
        else:
            return ("unknown", "error")
    except requests.exceptions.RequestException:
        return ("unknown", "network_error")
    
# --- Replace the download_apk function in github.py ---

def download_apk(run_id=None):
    """
    Finds and downloads ALL artifacts (Android, iOS, Windows, Linux) for a build.
    """
    headers = get_headers()
    app_id = get_app_id()

    if run_id:
        url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/runs/{run_id}/artifacts"
    else:
        print_info(f"Searching for latest artifacts for App ID: {app_id}")
        url = f"{GITHUB_API_URL}/repos/{BUILD_REPO_OWNER}/{BUILD_REPO_NAME}/actions/artifacts?per_page=100"

    res = requests.get(url, headers=headers)

    if res.status_code == 200:
        artifacts = res.json().get("artifacts", [])
        if not artifacts:
            print_error("No artifacts found. The build may have failed or is still in progress.")
            return

        # --- NEW: FIND ALL MATCHING ARTIFACTS ---
        # Filter artifacts that belong to this specific App ID
        target_artifacts = [a for a in artifacts if app_id in a.get("name", "")]

        if not target_artifacts:
            print_error(f"Could not find any recent artifacts for App ID: {app_id}")
            return

        print_info(f"Found {len(target_artifacts)} artifact(s) for this build. Starting downloads...\n")

        # --- MULTI-DOWNLOAD LOOP ---
        for target_artifact in target_artifacts:
            artifact_name = target_artifact['name']
            print_info(f"Preparing download for: {CYAN}{artifact_name}{RESET}")
            
            secure_api_url = target_artifact.get('archive_download_url')
            redirect_res = requests.get(secure_api_url, headers=headers, allow_redirects=False)

            if redirect_res.status_code == 302:
                public_download_url = redirect_res.headers['Location']
                filename = f"{artifact_name}.zip"
                
                try:
                    # Start a streaming download
                    with requests.get(public_download_url, stream=True) as r:
                        r.raise_for_status()
                        total_size = int(r.headers.get('content-length', 0))
                        downloaded = 0

                        with open(filename, 'wb') as f:
                            # Download in 8KB chunks
                            for chunk in r.iter_content(chunk_size=8192):
                                if chunk: # filter out keep-alive new chunks
                                    f.write(chunk)
                                    downloaded += len(chunk)
                                    percentage = (downloaded / total_size * 100) if total_size > 0 else 0
                                    print_progress_bar(percentage, f"Downloading {artifact_name}")

                    print_progress_bar(100.0, f"Downloading {artifact_name}")
                    print_success(f"Saved: {os.path.join(os.getcwd(), filename)}\n")

                except Exception as e:
                    print_error(f"Download failed for {artifact_name}: {e}")
            else:
                print_error(f"Could not generate a temporary download link for {artifact_name}.")
                
    else:
         print_error(f"Failed to fetch artifacts. Status Code: {res.status_code}")
