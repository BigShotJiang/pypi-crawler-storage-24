import os
import shutil
import subprocess
import re
from .utils import print_success, print_info, print_error, prompt, print_progress_bar, CYAN, RESET, BOLD

TEMPLATES = {
    "vite": {
        "cmd": "npm create vite@latest {name} -- --template react-ts",
        "desc": "React + TypeScript + Vite (Fast Web App)"
    },
    "flutter": {
        "cmd": "git clone --progress https://github.com/flutter/samples.git _temp_samples && mv _temp_samples/provider_counter {name} && rm -rf _temp_samples",
        "desc": "Official Flutter Starter App (Native)"
    },
    "kotlin": {
        "cmd": "git clone --progress https://github.com/android/architecture-samples.git _temp_kt && mv _temp_kt {name} && rm -rf _temp_kt",
        "desc": "Native Android Kotlin (Jetpack Compose)"
    },
    "html": {
        "cmd": None,
        "desc": "Plain HTML/CSS/JS (Simple Web App)"
    },
    "win": {
        "cmd": "git clone --progress https://github.com/flutter/samples.git _temp_samples",
        "desc": "Flutter Windows Desktop App (.exe)",
        "base_framework": "flutter" # It uses Flutter under the hood!
    },
    "linux": {
        "cmd": "git clone --progress https://github.com/flutter/samples.git _temp_samples",
        "desc": "Flutter Linux Desktop App",
        "base_framework": "flutter" # It uses Flutter under the hood!
    }
}

def generate_html_template(project_name):
    # This function stays exactly the same
    os.makedirs(project_name, exist_ok=True)
    os.makedirs(os.path.join(project_name, "www"), exist_ok=True)
    html_content = f"""...""" # Keep your HTML content
    with open(os.path.join(project_name, "www", "index.html"), "w") as f:
        f.write(html_content)

def create_project(framework, project_name):
    """Generates a new project with a real progress bar for git clone."""
    if framework not in TEMPLATES:
        print_error(f"Unknown framework: {framework}.")

    if os.path.exists(project_name):
        print_error(f"Directory '{project_name}' already exists.")

    template = TEMPLATES[framework]
    print_info(f"Creating a new {BOLD}{template['desc']}{RESET} project in {CYAN}./{project_name}{RESET}...")
    
    if framework == "html":
        generate_html_template(project_name)
    else:
        # --- NEW REAL-TIME PROGRESS BAR LOGIC ---
        cmd = template["cmd"].format(name=project_name)
        
        try:
            # We open a subprocess and read its stderr line by line
            process = subprocess.Popen(
                cmd,
                shell=True,
                stderr=subprocess.PIPE,
                stdout=subprocess.DEVNULL, # Hide normal git output
                text=True,
                bufsize=1 # Line-buffered
            )

            # Regex to find the percentage in git's output
            # It looks for "Receiving objects:  25%"
            progress_regex = re.compile(r"(\d+)%")
            
            # Read each line of output from the running git command
            for line in iter(process.stderr.readline, ''):
                match = progress_regex.search(line)
                if match:
                    percentage = float(match.group(1))
                    print_progress_bar(percentage, f"Downloading {framework} template")
            
            process.wait() # Wait for the command to finish
            if process.returncode != 0:
                raise Exception("Git clone failed.")

            print_progress_bar(100.0, f"Downloading {framework} template")
            
            # Post-clone cleanup for Flutter
            if framework == "flutter":
                shutil.move("_temp_samples/provider_counter", project_name)
                shutil.rmtree("_temp_samples", ignore_errors=True)
                shutil.rmtree(os.path.join(project_name, ".git"), ignore_errors=True)

        except Exception as e:
            # Clean up partial downloads on failure
            if os.path.exists("_temp_samples"):
                shutil.rmtree("_temp_samples", ignore_errors=True)
            print_error(f"Project creation failed: {e}")
        # --- END OF NEW LOGIC ---

    print_success(f"Project '{project_name}' created successfully!")
    print("\nNext steps:")
    print(f"  {CYAN}cd {project_name}{RESET}")
    print(f"  {CYAN}appforge init{RESET}")
    print("")
