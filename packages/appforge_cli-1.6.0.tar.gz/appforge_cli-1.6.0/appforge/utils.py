import sys
import threading
import time
import requests
from packaging.version import parse as parse_version

# ANSI Color Codes
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[32m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
RED = "\033[31m"
GRAY = "\033[90m"
BLUE = "\033[34m"

CLI_VERSION = "1.6.0"

def check_for_cli_updates():
    try:
        res = requests.get("https://pypi.org/pypi/appforge-cli/json", timeout=2)
        if res.status_code == 200:
            latest_version = res.json()["info"]["version"]
            
            if parse_version(latest_version) > parse_version(CLI_VERSION):
                return latest_version
    except:
        pass
    return None

def print_header():
    print(f"\n{BOLD}▲ AppForge{RESET} {GRAY}v{CLI_VERSION}{RESET}\n")
    latest = check_for_cli_updates()
    if latest:
        print(f"{YELLOW}⭐ A new version of AppForge is available! (v{latest}){RESET}")
        print(f"{GRAY}Run: pip install --upgrade appforge-cli{RESET}\n")

def print_footer():
    print(f"\n{GRAY}AppForge CLI")
    print(f"Built by AppForge Team [Maintainer - JuniorSir]{RESET}\n")

def print_success(msg):
    print(f"{GREEN}✔{RESET} {msg}")

def print_info(msg):
    print(f"{CYAN}?{RESET} {msg}")

def print_warning(msg):
    print(f"{YELLOW}⚠{RESET} {msg}")

def print_error(msg):
    print(f"{RED}✖{RESET} {msg}")
    sys.exit(1)

def cursor_up(lines):
    sys.stdout.write(f"\033[{lines}A")

def get_friendly_error(raw_log):
    """Translates complex cloud errors into user-friendly advice."""
    log_lower = raw_log.lower()
    
    if "namespace not specified" in log_lower or "app_plugin_loader" in log_lower:
        return "Flutter Plugin Mismatch: A third-party package is too old for this SDK. Check your pubspec.yaml."
    if "permission denied" in log_lower:
        return "Security Block: The cloud server could not access a required file. Ensure your project structure is standard."
    if "unresolved reference" in log_lower or "script compilation errors" in log_lower:
        return "Native Code Error: There is a syntax error in your build.gradle or Kotlin files."
    if "no files were found with the provided path" in log_lower:
        return ("Build Mode Mismatch: The cloud successfully created your app, but the uploader "
                "was looking in the 'debug' folder while you built a 'release' app (or vice versa).\n"
                "💡 SOLUTION: Ensure your build.yml upload path uses ${{ inputs.build_type }}")
    if "exit code 66" in log_lower or "could not find package" in log_lower:
        return "Monorepo Structure Error: A local path dependency is missing from the uploaded zip file."
    if "timeout" in log_lower or "rule was unable to be completed" in log_lower:
        return "Upload Too Large: Your project exceeds the GitHub API limits. Remove heavy assets (videos/binaries) before building."
    if "not found" in log_lower and "404" in log_lower:
        return "Dependency Missing: An npm or pub package listed in your config could not be downloaded."
    
    return "Unknown Compilation Error. Run the build locally (e.g., flutter build apk) to see detailed logs."


def _spinner_animation(stop_event, message, anim_type="spinner"):
    """
    Handles different animation types.
    - 'spinner': | / - \
    - 'dots': . .. ...
    """
    if anim_type == "dots":
        while not stop_event.is_set():
            for i in range(4):
                if stop_event.is_set(): break
                dots = "." * i
                # Extra spaces at the end clear the previous, longer line
                sys.stdout.write(f"\r{CYAN}●{RESET} {message}{dots}    ")
                sys.stdout.flush()
                time.sleep(0.4)
    else: # Default is spinner
        # Phase 1: Letter typewriter
        displayed_text = ""
        for char in message:
            if stop_event.is_set(): break
            displayed_text += char
            sys.stdout.write(f"\r{CYAN}●{RESET} {displayed_text}")
            sys.stdout.flush()
            time.sleep(0.03)

        # Phase 2: Spinner
        spinner_chars = "|/-\\"
        idx = 0
        while not stop_event.is_set():
            char = spinner_chars[idx % len(spinner_chars)]
            sys.stdout.write(f"\r{CYAN}{char}{RESET} {displayed_text}")
            sys.stdout.flush()
            idx += 1
            time.sleep(0.1)

def run_with_spinner(target_func, message, anim_type="spinner"):
    """
    Runs a target function while displaying an animation.
    'anim_type' can be 'spinner' or 'dots'.
    """
    stop_event = threading.Event()
    spinner_thread = threading.Thread(target=_spinner_animation, args=(stop_event, message, anim_type))
    
    spinner_thread.start()
    
    try:
        result = target_func()
    except Exception as e:
        stop_event.set()
        spinner_thread.join()
        sys.stdout.write(f"\r{RED}✖{RESET} {message.strip()}... {RED}failed!{RESET}       \n")
        sys.stdout.flush()
        print_error(str(e))
        return None

    stop_event.set()
    spinner_thread.join()
    
    sys.stdout.write(f"\r{GREEN}✔{RESET} {message.strip()}... {GREEN}done!{RESET}       \n")
    sys.stdout.flush()
    
    return result

# ANSI escape code to clear from the cursor to the end of the screen
def clear_from_cursor():
    sys.stdout.write("\033[J")

def prompt(question, default=""):
    prompt_text = f"{CYAN}?{RESET} {question}"
    if default:
        prompt_text += f" {GRAY}({default}){RESET}"
    prompt_text += ": "
    
    try:
        response = input(prompt_text).strip()
        return response if response else default
    except KeyboardInterrupt:
        print_error("\nOperation cancelled.")

# --- In utils.py ---

def print_progress_bar(percentage, message=""):
    """Prints a simple, elegant progress bar."""
    bar_length = 40
    filled_length = int(bar_length * percentage // 100)
    # Use a simple block character for the bar
    bar = "█" * filled_length + '-' * (bar_length - filled_length)
    # \r moves the cursor to the beginning of the line to create the animation
    sys.stdout.write(f"\r{GREEN}▶{RESET} {message} [{bar}] {percentage:.1f}%")
    sys.stdout.flush()

    if percentage >= 100:
        sys.stdout.write("\n")
