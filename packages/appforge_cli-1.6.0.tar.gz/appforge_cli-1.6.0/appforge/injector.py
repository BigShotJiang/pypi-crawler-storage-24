import os
import shutil
import re
from .utils import print_info, print_success, print_warning

def inject_metadata_locally(config):
    """Injects App Name, Package ID, Version, and Icons locally before zipping."""
    
    app_name = config.get("appName", "AppForge App")
    package_id = config.get("packageId", "com.appforge.app")
    app_version = config.get("version", "1.0.0")
    icon_path = config.get("iconPath")
    web_dir = config.get("webDir", "dist")
    project_category = config.get("category", "web")
    
    try:
        parts = app_version.split('.')
        build_number = int(f"{parts[0]}{parts[1].zfill(2)}{parts[2].zfill(2)}")
    except:
        build_number = 1

    print_info("Injecting metadata locally before upload...")

    # --- PATH DETECTION ---
    manifest_path = "app/src/main/AndroidManifest.xml" if os.path.exists("app/src/main/AndroidManifest.xml") else "android/app/src/main/AndroidManifest.xml"
    gradle_groovy = "app/build.gradle" if os.path.exists("app/build.gradle") else "android/app/build.gradle"
    gradle_kts = gradle_groovy + ".kts"

    # --- 1. INJECT APP NAME (AndroidManifest.xml) ---
    if os.path.exists(manifest_path):
        with open(manifest_path, 'r', encoding='utf-8') as f:
            manifest = f.read()
        
        manifest = re.sub(r'android:label="[^"]+"', f'android:label="{app_name}"', manifest)
        if 'xmlns:tools=' not in manifest:
            manifest = manifest.replace('<manifest', '<manifest xmlns:tools="http://schemas.android.com/tools"')
        if 'tools:replace="android:label"' not in manifest:
            manifest = manifest.replace('<application', '<application tools:replace="android:label"')
        if 'package=' in manifest:
            manifest = re.sub(r'package="[^"]+"', f'package="{package_id}"', manifest)

        with open(manifest_path, 'w', encoding='utf-8') as f:
            f.write(manifest)
        print_success(f"Injected App Name: {app_name}")

    # --- 2. INJECT PACKAGE ID & VERSION (build.gradle) ---
    target_gradle = gradle_kts if os.path.exists(gradle_kts) else (gradle_groovy if os.path.exists(gradle_groovy) else None)
    
    if target_gradle:
        with open(target_gradle, 'r', encoding='utf-8') as f:
            gradle = f.read()

        gradle = re.sub(r'applicationId\s*=?\s*["\'][^"\']+["\']', f'applicationId = "{package_id}"', gradle)
        gradle = re.sub(r'applicationId\s+["\'][^"\']+["\']', f'applicationId "{package_id}"', gradle)
        gradle = re.sub(r'namespace\s*=?\s*["\'][^"\']+["\']', f'namespace = "{package_id}"', gradle)
        gradle = re.sub(r'namespace\s+["\'][^"\']+["\']', f'namespace "{package_id}"', gradle)
        gradle = re.sub(r'versionName\s*=?\s*["\'][^"\']+["\']', f'versionName = "{app_version}"', gradle)
        gradle = re.sub(r'versionName\s+["\'][^"\']+["\']', f'versionName "{app_version}"', gradle)
        gradle = re.sub(r'versionCode\s*=?\s*\d+', f'versionCode = {build_number}', gradle)
        gradle = re.sub(r'versionCode\s+\d+', f'versionCode {build_number}', gradle)

        with open(target_gradle, 'w', encoding='utf-8') as f:
            f.write(gradle)
        print_success(f"Injected Package ID: {package_id} & Version: {app_version}")

    # --- 3. INJECT PUBSPEC.YAML (Flutter Specifics) ---
    if os.path.exists("pubspec.yaml"):
        with open("pubspec.yaml", 'r', encoding='utf-8') as f:
            pubspec = f.read()
        
        # 3a. Update Version
        if re.search(r'^version:\s*.*$', pubspec, re.MULTILINE):
            pubspec = re.sub(r'^version:\s*.*$', f'version: {app_version}+{build_number}', pubspec, flags=re.MULTILINE)
        
        # 3b. Update Project Name (Must be snake_case for Dart!)
        # e.g. "Vault Downloader" -> "vault_downloader"
        snake_case_name = re.sub(r'[^a-zA-Z0-9]', '_', app_name).lower()
        if re.search(r'^name:\s*.*$', pubspec, re.MULTILINE):
            pubspec = re.sub(r'^name:\s*.*$', f'name: {snake_case_name}', pubspec, flags=re.MULTILINE)

        with open("pubspec.yaml", 'w', encoding='utf-8') as f:
            f.write(pubspec)
        print_success(f"Updated pubspec.yaml (name: {snake_case_name}, version: {app_version})")

    # --- 4. INJECT APP ICONS (Universal) ---
    if icon_path and os.path.exists(icon_path):
        injected_icons = False

        # 4a. Android Mipmaps
        if os.path.exists(manifest_path):
            res_dir = os.path.join(os.path.dirname(manifest_path), 'res')
            mipmaps = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi']
            for m in mipmaps:
                target_dir = os.path.join(res_dir, m)
                if os.path.exists(target_dir):
                    shutil.copyfile(icon_path, os.path.join(target_dir, 'ic_launcher.png'))
                    round_icon = os.path.join(target_dir, 'ic_launcher_round.png')
                    if os.path.exists(round_icon):
                        shutil.copyfile(icon_path, round_icon)
                    injected_icons = True

        # 4b. Web / Flutter Web Icons (PWA Support)
        # Check standard web directories
        web_targets = ["web", "public", web_dir]
        for w_dir in web_targets:
            if os.path.exists(w_dir):
                # Replace Favicon
                shutil.copyfile(icon_path, os.path.join(w_dir, 'favicon.png'))
                if os.path.exists(os.path.join(w_dir, 'favicon.ico')):
                    shutil.copyfile(icon_path, os.path.join(w_dir, 'favicon.ico'))
                
                # Replace PWA Icons
                icons_dir = os.path.join(w_dir, 'icons')
                if os.path.exists(icons_dir):
                    pwa_icons = ['Icon-192.png', 'Icon-512.png', 'Icon-maskable-192.png', 'Icon-maskable-512.png']
                    for p_icon in pwa_icons:
                        shutil.copyfile(icon_path, os.path.join(icons_dir, p_icon))
                injected_icons = True
                
        if injected_icons:
            print_success("Injected custom App Icons across Native and Web directories.")
        else:
            print_warning("Icon path found, but no valid target directories (res/mipmap or web/icons) exist yet.")

    print_success("Local Metadata Injection Complete. Project is ready for upload.")
