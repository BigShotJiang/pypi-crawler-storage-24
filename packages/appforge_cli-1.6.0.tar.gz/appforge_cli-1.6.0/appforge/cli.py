import os
import sys
import argparse
import shutil
from .utils import (print_header, print_footer, print_info, print_success, prompt, print_error, print_warning,
                    GRAY, RESET, BOLD, CYAN, YELLOW, GREEN, RED, CLI_VERSION, BLUE,
                    cursor_up, clear_from_cursor)
from .detector import detect_project
from .capacitor import setup_capacitor, apply_configuration
from .config import save_local_config, load_local_config, load_history, get_app_id
from .github import push_and_build, check_status as check_by_id, download_apk as download_by_id, check_status, download_apk, get_build_status_by_id
import time
from .ai import scan_codebase_for_permissions
from .capacitor import install_plugins
from .create import create_project

def init_project():
    project_info = detect_project()
    category = project_info.get("category", "web")
    proj_type = project_info.get("type", "unknown")
    default_icon_dest = os.path.join(os.getcwd(), "appforge_icon.png")

    current_config = load_local_config()
    if not current_config.get("iconPath") or not os.path.exists(current_config.get("iconPath")):
        try:
            cli_dir = os.path.dirname(os.path.abspath(__file__))
            bundled_icon = os.path.join(cli_dir, "default_icon.png")

            if os.path.exists(bundled_icon):
                shutil.copy2(bundled_icon, default_icon_dest)
                save_local_config({"iconPath": default_icon_dest})
                print_info("Installed default AppForge app icon.")
        except Exception as e:
            pass

    save_local_config({"category": category, "project_type": proj_type})

    if category == "web":
        web_dir = prompt("Confirm web build directory", project_info["webDir"])
        platform_choice = prompt("Select platforms (android, ios, both)", "android").lower()
        if platform_choice == "both" or platform_choice == "all": 
            platforms = ["android", "ios"]
            platform_choice = "android,ios"
        elif "ios" in platform_choice: 
            platforms = ["ios"]
            platform_choice = "ios"
        else: 
            platforms = ["android"]
            platform_choice = "android"

        save_local_config({"webDir": web_dir, "platform": platform_choice})
        setup_capacitor(web_dir, platforms)
    else:
        print_info(f"Native {proj_type} project detected. Bypassing Capacitor setup.")
        
        if proj_type == "flutter":
            platform_choice = prompt("Select platforms (e.g., android, ios, windows, linux, or 'all')", "android").lower()
            if platform_choice == "all" or platform_choice == "both":
                platform_choice = "android,ios,windows,linux"
        else:
            platform_choice = prompt("Select platform to build in cloud (android)", "android").lower()
            platform_choice = "android"
        
        save_local_config({"platform": platform_choice})

    print("")
    detected_features = scan_codebase_for_permissions()

    if detected_features:
        print_success(f"AI detected {len(detected_features)} native features required by your app:")

        for data in detected_features.values():
            print(f"  {CYAN}●{RESET} {data['feature']} {GRAY}({data['desc']}){RESET}")

        print_info("The AppForge Cloud Server will automatically inject these permissions during the build process.")
    else:
        print_info("AI scan complete. No special native permissions detected.")
    
    try:
        import subprocess
        git_root = subprocess.check_output(
            ['git', 'rev-parse', '--show-toplevel'],
            text=True,
            stderr=subprocess.DEVNULL
        ).strip()

        sub_path = os.path.relpath(os.getcwd(), git_root)

        if sub_path and sub_path != '.':
            print_info(f"Detected sub-project path: {GRAY}{sub_path}{RESET}")
            save_local_config({"sub_path": sub_path})

    except (subprocess.CalledProcessError, FileNotFoundError):
        save_local_config({"sub_path": "."})
        
    print_success("Ready to send to the AppForge Cloud Builder.")

def configure_project():
    config = load_local_config()
    print_info("Interactive Configuration")
    app_name = prompt("App name", config.get("appName", "My App"))
    package_id = prompt("Package ID", config.get("packageId", "com.example.app"))
    build_mode = prompt("Default Build Mode (debug/release)", config.get("buildMode", "debug")).lower()
    if build_mode not in ['debug', 'release']: build_mode = 'debug'
    current_icon = config.get("iconPath", "")
    icon_prompt = prompt("Icon path (local PNG)", current_icon)
    
    # If they typed a new path, use it. Otherwise, keep the old one.
    final_icon_path = icon_prompt if icon_prompt else current_icon

    splash_img = prompt("Splash image (local PNG)", config.get("splashImg", ""))
    splash_bg = prompt("Splash background color (HEX)", config.get("splashBg", "#ffffff"))

    new_config = {
        "appName": app_name,
        "packageId": package_id,
        "buildMode": build_mode, 
        "iconPath": final_icon_path,
        "iconPath": icon_path,
        "splashImg": splash_img,
        "splashBg": splash_bg
    }
    save_local_config(new_config)

    web_dir = config.get("webDir", "dist")
    if config.get("category") == "web":
        apply_configuration(app_name, package_id, final_icon_path, splash_img, splash_bg, web_dir)
    return new_config

def display_app_details(config):
    print(f"{BOLD}App Configuration:{RESET}")
    print(f"  {GRAY}Name:{RESET}          {config.get('appName', 'Not set')}")
    print(f"  {GRAY}Package ID:{RESET}    {config.get('packageId', 'Not set')}")
    print(f"  {GRAY}Default Mode:{RESET}  {config.get('buildMode', 'debug').upper()}")
    print(f"  {GRAY}Web Directory:{RESET} {config.get('webDir', 'Not set')}")
    print(f"  {GRAY}Icon:{RESET}          {config.get('iconPath', 'Not set')}")
    print(f"  {GRAY}Splash Image:{RESET}  {config.get('splashImg', 'Not set')}")
    print(f"  {GRAY}Splash Color:{RESET}  {config.get('splashBg', 'Not set')}")
    print("-" * 30)

def build_app():
    config = load_local_config()
    if not config:
        print_error("Project not initialized. Run 'appforge init' first.")

    app_name = config.get("appName")
    package_id = config.get("packageId")
    platform = config.get("platform", "android")
    config_was_updated = False

    if not app_name or not package_id:
        print_info("Some required app details are missing. Let's set them up.")
        new_app_name = prompt("App name", app_name or "My App")
        new_package_id = prompt("Package ID", package_id or "com.example.app")
        new_platform = prompt("Platform (android, ios, both)", platform)

        config['appName'] = new_app_name
        config['packageId'] = new_package_id
        config['platform'] = new_platform.lower()
        config_was_updated = True

    current_version_str = config.get("version", "1.0.0")
    try:
        parts = current_version_str.split('.')
        parts[-1] = str(int(parts[-1]) + 1)
        new_version_str = '.'.join(parts)
    except:
        new_version_str = "1.0.1"

    print_info(f"Preparing build for version: {CYAN}{new_version_str}{RESET}")
    build_type = config.get("buildMode")
    
    if not build_type:
        choice = prompt("Build for Production Release? (Y/n - 'n' builds Debug)", default="y").lower()
        build_type = "release" if choice in ['y', 'yes', ''] else "debug"
        # Save this choice so we don't have to ask again next time
        save_local_config({"buildMode": build_type})
    
    # Update the working config object
    config['build_type'] = build_type
    config['version'] = new_version_str

    if config_was_updated:
        save_local_config(config)
        print_success("App details updated.\n")

    print_info("Ready to build with the following configuration:")
    display_app_details(config)
    print(f"  {GRAY}Target Platform:{RESET} {config.get('platform', 'android')}")
    print(f"  {GRAY}Next Version:{RESET}      {new_version_str}")
    color = GREEN if build_type == "release" else YELLOW
    print(f"  {GRAY}Build Mode:{RESET}        {color}{build_type.upper()}{RESET}\n")

    action = prompt("Proceed with build? (Y/n)", default="y").lower()

    if action in ['y', 'yes', '']:
        save_local_config({"version": new_version_str})
        
        if config.get("category") == "web":
            apply_configuration(
                config.get('appName', 'My App'), 
                config.get('packageId', 'com.example.app'), 
                config.get('iconPath'),
                config.get('splashImg'), 
                config.get('splashBg'), 
                config.get('webDir', 'dist')
            )

        push_and_build(config)
        print_success("Your app is now building in the cloud!")
        
        watch = prompt("Watch live build logs? (Y/n)", default="y").lower()
        if watch in ['y', 'yes', '']:
            status_check() 
        else:
            print_info("Run 'appforge status' later to check its progress.")
            
    else:
        print(f"\n{GREEN}Run 'appforge configure' to edit App configuration{RESET}")
        print("\n")
        print_info("Build cancelled.")

def show_history():
    history = load_history()
    if not history:
        print_info("No build history found. Run 'appforge build' to create your first app!")
        return

    print(f"\n{BOLD}Your Recent AppForge Builds:{RESET}")
    print(f"  {GRAY}{'ID':<10} {'PROJECT':<20} {'PLATFORM':<10} {'TRIGGERED (UTC)':<22} {'STATUS'}{RESET}")
    print("-" * 80)

    entries_to_display = history[:10]
    
    print_info("Fetching latest statuses from the cloud...\n")

    for entry in entries_to_display:
        from datetime import datetime
        
        dt_obj = datetime.fromisoformat(entry['triggered_at'].replace('Z', '+00:00'))
        formatted_time = dt_obj.strftime('%Y-%m-%d %H:%M:%S')

        run_id = entry.get("run_id")
        if run_id:
            status, conclusion = get_build_status_by_id(run_id)
        else:
            status, conclusion = entry.get("status", "unknown"), entry.get("conclusion", None)
        status_text = ""
        if status in ["in_progress", "queued"]:
            # Static yellow text instead of animation
            status_text = f"{YELLOW}▶ Building...{RESET}"
        elif status == "completed":
            if conclusion == "success":
                status_text = f"{GREEN}✔ Success{RESET}"
            else:
                status_text = f"{RED}✖ Failed{RESET}"
        else:
            status_text = f"{GRAY}{(status or 'Unknown').capitalize()}{RESET}"
        
        # Print the row
        print(f"  {CYAN}{entry['app_id']:<9}{RESET} {entry['project_name']:<20} {entry['platform']:<10} {formatted_time:<22} {status_text}")

    print("-" * 80)
    
    choice = prompt("Enter a number or App ID to re-download, or press Enter to exit").strip().lower()

    selected_entry = None

    if choice.isdigit() and 0 < int(choice) <= len(entries_to_display):
        selected_index = int(choice) - 1
        selected_entry = entries_to_display[selected_index]

    elif choice:
        selected_entry = next((entry for entry in history if entry['app_id'].lower().startswith(choice)), None)

    if selected_entry:
        run_id_to_download = selected_entry.get("run_id")
        
        if run_id_to_download:
            print_info(f"Fetching artifact for Build Run ID: {run_id_to_download} (App ID: {selected_entry['app_id']})")
            download_apk(run_id=run_id_to_download)
        else:
            print_warning("This is a legacy build entry without a unique Run ID. Cannot guarantee the correct artifact.")
    
    elif choice:
        print_warning("Invalid input. Please enter a number from the list or a valid App ID.")

def status_check():
    check_status()

def download_app():
    download_apk()

def show_info():
    print(f"\n{BOLD}▲ AppForge CLI Information{RESET}")
    print("=" * 55)
    
    print(f"\n{CYAN}SYSTEM STATUS{RESET}")
    print(f"  {GRAY}Current Version:{RESET} v{CLI_VERSION}")
    print(f"  {GRAY}Cloud Target:{RESET}    Private GitHub Actions Runner")
    print(f"  {GRAY}Connection:{RESET}      Authenticated & Active")
    print(f"\n{CYAN}UNIVERSAL ARCHITECTURE{RESET}")
    print(f"  {GREEN}✔{RESET} {BOLD}Web to Native{RESET} (React, Vite, Next.js, HTML)")
    print(f"  {GREEN}✔{RESET} {BOLD}Flutter{RESET} (Full Native Compilation)")
    print(f"  {GREEN}✔{RESET} {BOLD}Kotlin/Java{RESET} (Standard Android Studio Projects)")
    print(f"  {GREEN}✔{RESET} {BOLD}Monorepo Support{RESET} (Sub-directory execution)")

    print(f"\n{CYAN}ADVANCED FEATURES{RESET}")
    print(f"  {YELLOW}✦{RESET} {BOLD}AI Permission Scanner:{RESET} Automatically detects required")
    print(f"    hardware (Camera, GPS, Bluetooth) from source code.")
    print(f"  {YELLOW}✦{RESET} {BOLD}Cloud Injector Engine:{RESET} Dynamically writes strict")
    print(f"    Android 13+ permissions and Java 8 Desugaring rules.")
    print(f"  {YELLOW}✦{RESET} {BOLD}Permanent Keystore:{RESET} Signs Release APKs securely via")
    print(f"    cloud secrets to enable seamless OTA updates.")
    print(f"  {YELLOW}✦{RESET} {BOLD}Live Telemetry:{RESET} Streams real-time GitHub Actions")
    print(f"    build logs directly to your local terminal.")

    print(f"\n{CYAN}LATEST RELEASE NOTES (v{CLI_VERSION}){RESET}")
    print("  • Added Native App Icon & Splash Screen generation.")
    print("  • Added intelligent 'history' command with live statuses.")
    print("  • Fixed Flutter 'app_plugin_loader' compatibility bugs.")
    print("  • Upgraded to robust Node.js Cloud Injection script.")
    print("  • Added 'create' command for instant project scaffolding.")
    
    print("\n" + "=" * 55)
    print(f"  {GRAY}Run 'appforge help' to see available commands.{RESET}\n")

def show_argu():
    print("Commands:")
    print("  appforge init       - Initialize an AppForge project")
    print("  appforge configure  - Open interactive settings")
    print(f"  {CYAN}info{RESET}  - View CLI version and release notes")
    print(f"  {CYAN}create <framework> <name>{RESET} Scaffold a new app (vite, flutter, html, kotlin, win, linux), {BLUE}Ex - appforge create flutter myapp{RESET}")
    print("  appforge build      - Package project and send to build repo")
    print("  appforge status     - Check build status")
    print("  appforge download   - Download the built APK")
    print(f"  {CYAN}history{RESET}     View a list of your past builds")
    print("  appforge help       - Show this help message")

def show_help():
    """The animated welcome sequence for the very first run."""
    welcome_message = f"{BOLD}▲ AppForge{RESET} - The Universal App Builder"
    
    for char in welcome_message:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.05)
    print("\n")
    time.sleep(0.5)
    
    print_success("Installation complete!")
    print_info("Welcome to the AppForge ecosystem.")
    
    print("\nGetting Started:")
    print("  1. `cd` into your project directory")
    print("  2. Run `appforge init` to begin\n")
    
    show_argu()
    sys.exit(0)

def main():
    
    print_header()
    
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("command", nargs="?", default="help", help="Command to run")
    parser.add_argument("args", nargs=argparse.REMAINDER, help="Additional arguments")
    
    args, unknown = parser.parse_known_args()
    
    if unknown:
        args.args.extend(unknown)

    try:
        if args.command == "create":
            if not args.args or len(args.args) < 2:
                print_error("Usage: appforge create <framework> <project-name>\nExample: appforge create flutter my_new_app")
            
            framework = args.args[0].lower()
            project_name = args.args[1]
            create_project(framework, project_name)
            
        elif args.command == "init": init_project()
        elif args.command == "build": build_app()
        elif args.command == "configure": configure_project()
        elif args.command == "history": show_history()
        elif args.command == "info": show_info()
        elif args.command == "status": status_check()
        elif args.command == "download": download_apk()
        else: show_help()
    finally:
        print_footer()

if __name__ == "__main__":
    main()
