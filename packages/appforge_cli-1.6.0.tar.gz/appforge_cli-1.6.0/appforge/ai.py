import os
import json
import re
from .utils import print_info, print_success, print_error, CYAN, RESET, GRAY

def load_knowledge_base():
    """Loads the AI keyword-to-plugin mappings from the JSON file."""
    try:
        # __file__ gives the path to the current python script (ai.py)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        json_path = os.path.join(current_dir, 'knowledge_base.json')
        with open(json_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        # Note: print_error must be imported from utils
        print_error(f"Critical Error: Could not load AI knowledge base: {e}")
        return {}

def scan_codebase_for_permissions():
    """
    Universally scans project files. It now uses regex to robustly parse
    Flutter pubspec.yaml files and scans web directories like 'www'.
    """
    ai_knowledge_base = load_knowledge_base()

    print_info(f"{CYAN}🤖 AI Agent scanning codebase for native features...{RESET}")

    found_plugins = {}
    pubspec_already_scanned = False

    for root, dirs, files in os.walk('.'):
        # FIXED: Removed 'www' from the ignore list so your HTML files are scanned!
        dirs[:] = [d for d in dirs if d not in ['node_modules', '.git', 'android', 'ios', 'dist', 'build', '.next', '.nuxt', '.dart_tool']]

        for file in files:
            file_path = os.path.join(root, file)

            # --- FLUTTER SCANNER ---
            if file == 'pubspec.yaml' and not pubspec_already_scanned:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()

                        if 'workspace:' in content:
                            print_info(f"Ignoring Flutter workspace file: {GRAY}{file_path}{RESET}")
                            continue

                        print_info(f"Analyzing dependencies in {GRAY}{file_path}{RESET}")
                        for keyword, data in ai_knowledge_base.items():
                            if keyword.startswith("pubspec:"):
                                package_name = keyword.split(":")[1]

                                # FIXED: Using fr"" (Raw F-String) to stop the SyntaxWarning
                                pattern = re.compile(fr"^\s*{re.escape(package_name)}:", re.MULTILINE)

                                if pattern.search(content):
                                    found_plugins[data["plugin"]] = data

                    pubspec_already_scanned = True
                except Exception:
                    pass

            # --- WEB SCANNER (index.html, etc.) ---
            elif file.endswith(('.js', '.ts', '.jsx', '.tsx', '.vue', '.svelte', '.html')):
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        for keyword, data in ai_knowledge_base.items():
                            if not keyword.startswith("pubspec:"):
                                if keyword in content and data["plugin"] not in found_plugins:
                                    found_plugins[data["plugin"]] = data
                except Exception:
                    pass

    return found_plugins
