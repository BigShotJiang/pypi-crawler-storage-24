from setuptools import setup

setup(
    name="appforge",
    version="1.6.0",
    description="Convert web apps into Android apps automatically using Capacitor and GitHub cloud builds.",
    author="AppForge Team",
    packages=["appforge"],
    package_data={
        "appforge": ["knowledge_base.json", "default_icon.png"],
    },
    include_package_data=True,
    install_requires=[
        "requests",
        "packaging"
    ],
    entry_points={
        "console_scripts": [
            "appforge=appforge.cli:main",
        ],
    },
)
