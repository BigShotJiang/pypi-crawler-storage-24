from importlib.metadata import PackageNotFoundError, version

from packaging.version import Version

try:
    OVERFLASK_VERSION = Version(version('overflask'))
except PackageNotFoundError:
    OVERFLASK_VERSION = Version('0.0.0')
