"""Flask config accessors for overflask projects."""

import os
import warnings
from functools import partial
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from flask import Flask
from packaging.version import Version

from .config_value import ConfigValue
from .overflask_version import OVERFLASK_VERSION

_CHANGELOG_URL = 'https://gitlab.com/overflask/overflask/-/blob/master/CHANGELOG.md'

load_dotenv()


class Config:
    """Typed accessors for Flask config keys."""

    TASKS_REDIS_DB: int = 15
    TEMPLATES_DIR: Path = Path(__file__).parent.parent / 'templates'
    COMPONENT_TEMPLATES_DIR: Path = TEMPLATES_DIR / 'component'

    PROJECT_NAME: ConfigValue[str] = ConfigValue()
    COMPONENTS: ConfigValue[list[str]] = ConfigValue()
    IS_DEBUG: ConfigValue[bool] = ConfigValue()
    IS_TESTING: ConfigValue[bool] = ConfigValue()
    SECRET_KEY: ConfigValue[str] = ConfigValue()
    OVERFLASK_VERSION: Version = OVERFLASK_VERSION
    VERIFIED_OVERFLASK_VERSION: Version = Version('0.0.0')
    POSTGRES_HOST: ConfigValue[str] = ConfigValue()
    POSTGRES_PORT: ConfigValue[str] = ConfigValue()
    POSTGRES_USER: ConfigValue[str] = ConfigValue()
    POSTGRES_PASSWORD: ConfigValue[str] = ConfigValue()
    POSTGRES_DB: ConfigValue[str] = ConfigValue()
    SQLALCHEMY_DATABASE_URI: ConfigValue[str] = ConfigValue()
    REDIS_URL: ConfigValue[str] = ConfigValue()
    ELASTICSEARCH_URL: ConfigValue[str] = ConfigValue()
    ELASTICSEARCH_USERNAME: ConfigValue[str] = ConfigValue()
    ELASTICSEARCH_PASSWORD: ConfigValue[str] = ConfigValue()
    KIBANA_URL: ConfigValue[str] = ConfigValue()
    KIBANA_USERNAME: ConfigValue[str] = ConfigValue()
    KIBANA_PASSWORD: ConfigValue[str] = ConfigValue()
    TASKS_REGISTERED_RETENTION_DAYS: ConfigValue[int] = ConfigValue()
    TASKS_DISPATCHED_RETENTION_DAYS: ConfigValue[int] = ConfigValue()
    TASKS_COMPLETED_RETENTION_DAYS: ConfigValue[int] = ConfigValue()
    TASKS_METRICS_RETENTION_DAYS: ConfigValue[int] = ConfigValue()
    ANALYTICS_ENVIRONMENT: ConfigValue[str] = ConfigValue()
    ANALYTICS_FLUSH_INTERVAL_SECONDS: ConfigValue[int] = ConfigValue()
    ANALYTICS_FLUSH_BATCH_SIZE: ConfigValue[int] = ConfigValue()
    ANALYTICS_RETENTION_DAYS: ConfigValue[int] = ConfigValue()

    @classmethod
    def load(cls, app: Flask) -> None:
        require = partial(_require, app)
        optional = partial(_optional, app)

        cls.PROJECT_NAME = require('PROJECT_NAME')
        cls.COMPONENTS = cls._load_components(app.project_root)
        cls.IS_DEBUG = optional('IS_DEBUG', default=not Path('/.dockerenv').exists())
        cls.IS_TESTING = optional('OVERFLASK_TESTING', default=False)
        cls.SECRET_KEY = require('SECRET_KEY', testing_default='test-secret-key')
        cls.VERIFIED_OVERFLASK_VERSION = Version(require('VERIFIED_OVERFLASK_VERSION'))

        cls.REDIS_URL = require('REDIS_URL', testing_default='redis://localhost:6379')
        cls.ELASTICSEARCH_URL = require('ELASTICSEARCH_URL', testing_default='http://localhost:9200')
        cls.KIBANA_URL = require('KIBANA_URL', testing_default='http://localhost:5601')

        cls.POSTGRES_HOST = require('POSTGRES_HOST')
        cls.POSTGRES_PORT = optional('POSTGRES_PORT', '5432')
        cls.POSTGRES_USER = require('POSTGRES_USER')
        cls.POSTGRES_PASSWORD = require('POSTGRES_PASSWORD')
        cls.POSTGRES_DB = require('POSTGRES_DB')
        cls.SQLALCHEMY_DATABASE_URI = cls._determine_postgres_url()

        cls.ELASTICSEARCH_USERNAME = optional('ELASTICSEARCH_USERNAME', '')
        cls.ELASTICSEARCH_PASSWORD = optional('ELASTICSEARCH_PASSWORD', '')
        cls.KIBANA_USERNAME = optional('KIBANA_USERNAME', '')
        cls.KIBANA_PASSWORD = optional('KIBANA_PASSWORD', '')

        cls.TASKS_REGISTERED_RETENTION_DAYS = optional('TASKS_REGISTERED_RETENTION_DAYS', 7)
        cls.TASKS_DISPATCHED_RETENTION_DAYS = optional('TASKS_DISPATCHED_RETENTION_DAYS', 7)
        cls.TASKS_COMPLETED_RETENTION_DAYS = optional('TASKS_COMPLETED_RETENTION_DAYS', 7)
        cls.TASKS_METRICS_RETENTION_DAYS = optional('TASKS_METRICS_RETENTION_DAYS', 365)

        cls.ANALYTICS_ENVIRONMENT = optional('ANALYTICS_ENVIRONMENT', 'production')
        cls.ANALYTICS_FLUSH_INTERVAL_SECONDS = optional('ANALYTICS_FLUSH_INTERVAL_SECONDS', 5)
        cls.ANALYTICS_FLUSH_BATCH_SIZE = optional('ANALYTICS_FLUSH_BATCH_SIZE', 500)
        cls.ANALYTICS_RETENTION_DAYS = optional('ANALYTICS_RETENTION_DAYS', 365)

        cls._update_flask_config(app)
        cls._check_verified_version()

    @classmethod
    def _load_components(cls, root: Path) -> list[str]:
        """Populate COMPONENTS by scanning the components/ directory under root."""
        components_dir = root / 'components'
        return sorted(
            p.name for p in components_dir.iterdir()
            if p.is_dir() and not p.name.startswith('_')
        ) if components_dir.exists() else []

    @classmethod
    def _determine_postgres_url(cls) -> str:
        return f'postgresql+psycopg://{cls.POSTGRES_USER}:{cls.POSTGRES_PASSWORD}@{cls.POSTGRES_HOST}:{cls.POSTGRES_PORT}/{cls.POSTGRES_DB}'

    @classmethod
    def _check_verified_version(cls):
        if Config.IS_DEBUG and not Config.IS_TESTING and cls.OVERFLASK_VERSION > cls.VERIFIED_OVERFLASK_VERSION:
            warnings.warn(
                f'overflask {cls.OVERFLASK_VERSION} is newer than '
                f'VERIFIED_OVERFLASK_VERSION={cls.VERIFIED_OVERFLASK_VERSION!r} in settings.py. '
                f'Review the changelog and update VERIFIED_OVERFLASK_VERSION when done: {_CHANGELOG_URL}',
                stacklevel=3,
            )

    @classmethod
    def _update_flask_config(cls, app):
        app.config['TESTING'] = cls.IS_TESTING
        app.config['SQLALCHEMY_DATABASE_URI'] = cls.SQLALCHEMY_DATABASE_URI
        app.config['SECRET_KEY'] = cls.SECRET_KEY


def _get(app: Flask, key: str) -> str | None:
    val = app.config.get(key)
    return val if val is not None else os.getenv(key)


def _require(app: Flask, key: str, testing_default: str | None = None) -> str:
    val = _get(app, key)
    if val not in (None, ''):
        return val  # type: ignore[return-value]
    if Config.IS_TESTING and testing_default is not None:
        return testing_default
    raise RuntimeError(f'Required config key {key!r} is not set in settings.py or environment.')


def _optional(app: Flask, key: str, default: Any):
    val = _get(app, key)
    if val in (None, ''):
        val = default

    value_type = type(default)
    return type(default)(val) \
        if value_type is not bool \
        else str(val).lower() in ('true', '1', 'yes')
