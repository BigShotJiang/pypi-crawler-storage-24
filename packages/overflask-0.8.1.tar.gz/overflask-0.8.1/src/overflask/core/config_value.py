class ConfigValue[T]:
    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name

    def __get__(self, obj: object, objtype: type | None = None) -> T:
        raise RuntimeError(f'Config.{self.name} not yet loaded — call Config.load(app) first')

    def __set__(self, instance: object, value: T | ConfigValue[T]) -> None:
        raise AttributeError(f'Config.{self.name} cannot be set on an instance')
