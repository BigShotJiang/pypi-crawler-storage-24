"""OverFlask application class."""

from pathlib import Path

from flask import Blueprint, Flask

from overflask.core.config import Config
from overflask.core.discovery import DiscoveredModules, discover


class OverFlask(Flask):
    """Flask application configured for overflask projects.

    Args:
        settings: The project settings module.
        manage_path: Absolute path to the project's manage.py script.
    """

    registry: DiscoveredModules
    project_root: Path
    migrations_dir: Path

    def __init__(self, settings, manage_path: str):
        super().__init__(settings.__name__)
        self.project_root = Path(manage_path).parent
        self.migrations_dir = self.project_root / "ops" / "migrations"

        self.config.from_object(settings)
        Config.load(self)

        self.registry = discover()

        for views_module in self.registry.views:
            for name in dir(views_module):
                obj = getattr(views_module, name)
                if isinstance(obj, Blueprint):
                    self.register_blueprint(obj)

        from overflask.commands.builtin_commands import BuiltinCommands
        self.builtin_commands = BuiltinCommands(self)
