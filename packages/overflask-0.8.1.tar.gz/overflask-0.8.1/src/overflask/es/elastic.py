"""Elasticsearch client singleton for the tasks system."""

from elasticsearch import Elasticsearch

from overflask.core.config import Config

_es_client: Elasticsearch | None = None


def get_es_client() -> Elasticsearch:
    """Return a cached Elasticsearch client built from Flask config."""
    global _es_client
    if _es_client is None:
        kwargs = {"hosts": [Config.ELASTICSEARCH_URL]}
        if Config.ELASTICSEARCH_USERNAME:
            kwargs["basic_auth"] = [
                Config.ELASTICSEARCH_USERNAME,
                Config.ELASTICSEARCH_PASSWORD,
            ]
        _es_client = Elasticsearch(**kwargs)
    return _es_client
