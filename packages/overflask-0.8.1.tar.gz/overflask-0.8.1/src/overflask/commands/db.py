"""Database migration command implementations."""

import re
from pathlib import Path

import click
from alembic import command
from alembic.config import Config as AlembicConfig

from overflask.core.app import OverFlask


def _alembic_cfg(app: OverFlask) -> AlembicConfig:
    cfg = AlembicConfig(str(app.migrations_dir / 'alembic.ini'))
    cfg.set_main_option('script_location', str(app.migrations_dir))
    return cfg


def get_next_revision_id(migrations_dir: Path) -> str:
    """Get the next auto-incremented revision ID."""
    versions_dir = migrations_dir / 'versions'
    existing = list(versions_dir.glob('*.py'))
    if not existing:
        return '001'

    max_num = 0
    for f in existing:
        match = re.match(r'(\d+)_', f.name)
        if match:
            max_num = max(max_num, int(match.group(1)))

    return f'{max_num + 1:03d}'


def db_migrate(app: OverFlask, message: str) -> None:
    rev_id = get_next_revision_id(app.migrations_dir)
    command.revision(_alembic_cfg(app), message=message, autogenerate=True, rev_id=rev_id)
    click.echo(f'Created migration {rev_id}')


def db_upgrade(app: OverFlask, revision: str) -> None:
    command.upgrade(_alembic_cfg(app), revision)
    click.echo(f'Upgraded to {revision}')


def db_downgrade(app: OverFlask, revision: str) -> None:
    command.downgrade(_alembic_cfg(app), revision)
    click.echo(f'Downgraded to {revision}')
