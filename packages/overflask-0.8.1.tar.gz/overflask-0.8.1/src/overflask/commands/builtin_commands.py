"""Command implementations for overflask projects."""

import os

import click

from overflask.commands.component import add_component
from overflask.commands.db import db_downgrade, db_migrate, db_upgrade
from overflask.commands.overflask import overwrite
from overflask.commands.tasks import tasks_kibana, tasks_scheduler, tasks_worker
from overflask.core.app import OverFlask
from overflask.core.config import Config


class BuiltinCommands:
    """Assembled Click command group for generated project management."""

    def __init__(self, app: OverFlask) -> None:
        @click.group()
        def cli():
            pass

        cli.help = f'{app.config["PROJECT_NAME"]} management commands.'

        # --- server ---

        @cli.command()
        @click.argument('host', default='0.0.0.0')
        @click.argument('port', default=5000, type=int)
        def run(host: str, port: int):
            """Run the development server."""
            is_debug = Config.IS_DEBUG
            os.environ.setdefault('FLASK_DEBUG', '1' if is_debug else '0')
            app.run(host=host, port=port, debug=is_debug)

        # --- component ---

        @cli.group()
        def component():
            """Manage project components."""
            pass

        @component.command('add')
        @click.argument('name')
        def component_add(name: str):
            """Add a new component to the project."""
            add_component(app, name)

        # --- db ---

        @cli.group()
        def db():
            """Database migration commands."""
            pass

        @db.command('migrate')
        @click.option('-m', '--message', default='migration', help='Migration message')
        def migrate(message: str):
            """Create a new migration based on model changes."""
            db_migrate(app, message)

        @db.command('upgrade')
        @click.argument('revision', default='head')
        def upgrade(revision: str):
            """Upgrade database to REVISION (default: head)."""
            db_upgrade(app, revision)

        @db.command('downgrade')
        @click.argument('revision')
        def downgrade(revision: str):
            """Downgrade database to REVISION."""
            db_downgrade(app, revision)

        # --- tasks ---

        @cli.group()
        def tasks():
            """Task management commands."""
            pass

        @tasks.command('scheduler')
        def tasks_scheduler_cmd():
            """Run the task scheduler (polls ES and dispatches due tasks to Redis)."""
            tasks_scheduler(app)

        @tasks.command('worker')
        def tasks_worker_cmd():
            """Run a task worker (pops from Redis and executes tasks). Scale via compose replicas."""
            tasks_worker(app)

        @tasks.command('kibana')
        def tasks_kibana_cmd():
            """Overwrite Kibana data view, visualizations, and dashboard with current definitions."""
            tasks_kibana(app)

        # --- overflask ---

        @cli.command('overwrite')
        def overflask_overwrite():
            """Upgrade and overwrite framework-generated files in this project."""
            overwrite(app)

        # --- component commands from registry ---

        for cli_module in app.registry.cli:
            for name in dir(cli_module):
                obj = getattr(cli_module, name)
                if isinstance(obj, click.Command) and obj.name != 'cli':
                    cli.add_command(obj)

        self.cli = cli
