"""Overflask framework upgrade command."""

import shutil
from pathlib import Path

import click

from overflask.cli.scaffold import get_overflask_pypi_source, render_template, write_root_files
from overflask.core.app import OverFlask
from overflask.core.config import Config

_MARKER = '### IMPORTANT: Anything beyond this line is overflask configuration'


def overwrite(app: OverFlask) -> None:
    context = {
        'project_name': Config.PROJECT_NAME,
        'overflask_version': str(Config.OVERFLASK_VERSION),
        'overflask_source': get_overflask_pypi_source(),
    }
    _overwrite_root_files(app, context)
    _overwrite_alembic_files(app, context)
    _overwrite_docs(app)
    _overwrite_with_marker(Config.TEMPLATES_DIR / 'ops' / 'env.template', app.project_root / 'ops' / 'env.template')
    _overwrite_env(Config.TEMPLATES_DIR / 'ops' / 'env.template', app.project_root / '.env')
    _overwrite_with_marker(Config.TEMPLATES_DIR / 'gitignore', app.project_root / '.gitignore')
    _overwrite_static(Config.TEMPLATES_DIR / 'ops' / 'setup-traefik.sh', app.project_root / 'ops' / 'setup-traefik.sh')


def _overwrite_root_files(app: OverFlask, context: dict) -> None:
    root = app.project_root
    for path in write_root_files(root, context):
        click.echo(f'Updated {path.relative_to(root)}')


def _overwrite_alembic_files(app: OverFlask, context: dict) -> None:
    templates_dir = Config.TEMPLATES_DIR
    root = app.project_root

    rendered = [
        ('ops/migrations/alembic.ini.jinja', root / 'ops' / 'migrations' / 'alembic.ini'),
        ('ops/migrations/env.py.jinja', root / 'ops' / 'migrations' / 'env.py'),
    ]
    for template_name, dest in rendered:
        dest.write_text(render_template(templates_dir / template_name, context))
        click.echo(f'Updated {dest.relative_to(root)}')

    static = root / 'ops' / 'migrations' / 'script.py.mako'
    shutil.copy2(templates_dir / 'ops' / 'migrations' / 'script.py.mako', static)
    click.echo(f'Updated {static.relative_to(root)}')


def _overwrite_docs(app: OverFlask) -> None:
    source_dir = Config.TEMPLATES_DIR / 'overflask-docs'
    dest_dir = app.project_root / 'overflask-docs'

    if dest_dir.exists():
        shutil.rmtree(dest_dir)
        click.echo(f'Removed {dest_dir}')

    shutil.copytree(source_dir, dest_dir)
    click.echo(f'Written {dest_dir}')


def _overwrite_static(source: Path, dest: Path) -> None:
    shutil.copy2(source, dest)
    click.echo(f'Updated {dest.name}')


def _split_at_marker(source: Path, dest: Path) -> tuple[str, str, str, int]:
    """Read source and dest, split both at _MARKER.

    Returns (source_tail, dest_head, dest_text, dest_marker_pos).
    """
    source_text = source.read_text()
    source_marker_pos = source_text.find(_MARKER)
    if source_marker_pos == -1:
        raise click.ClickException(f'Marker {_MARKER!r} not found in {source.name}.')

    if not dest.exists():
        raise click.ClickException(f'{dest} does not exist.')

    dest_text = dest.read_text()
    dest_marker_pos = dest_text.find(_MARKER)
    dest_head = dest_text[:dest_marker_pos] if dest_marker_pos != -1 else dest_text.rstrip('\n') + '\n\n'

    return source_text[source_marker_pos:], dest_head, dest_text, dest_marker_pos


def _overwrite_env(source: Path, dest: Path) -> None:
    source_tail, dest_head, dest_text, dest_marker_pos = _split_at_marker(source, dest)

    # Parse existing values from dest's overflask section
    existing_values = {}
    if dest_marker_pos != -1:
        for line in dest_text[dest_marker_pos:].splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#') and '=' in stripped:
                key, _, value = stripped.partition('=')
                if value:
                    existing_values[key] = value

    # Rebuild using template ordering, restoring existing values for known keys
    merged_lines = []
    for line in source_tail.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#') and '=' in stripped:
            key = stripped.partition('=')[0]
            if key in existing_values:
                merged_lines.append(f'{key}={existing_values[key]}')
                continue
        merged_lines.append(line)

    dest.write_text(dest_head + '\n'.join(merged_lines) + '\n')
    click.echo(f'Updated {dest.name}')


def _overwrite_with_marker(source: Path, dest: Path) -> None:
    source_tail, dest_head, _, _ = _split_at_marker(source, dest)
    dest.write_text(dest_head + source_tail)
    click.echo(f'Updated {dest.name}')
