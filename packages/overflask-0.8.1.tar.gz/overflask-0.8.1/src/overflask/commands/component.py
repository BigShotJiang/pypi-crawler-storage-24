"""Component management command implementations."""

import shutil
from pathlib import Path

import click
from jinja2 import Environment, FileSystemLoader

from overflask.core.app import OverFlask
from overflask.core.config import Config


def _get_jinja_env(template_dir: Path) -> Environment:
    """Create Jinja2 environment for template rendering."""
    return Environment(
        loader=FileSystemLoader(str(template_dir)),
        keep_trailing_newline=True,
    )


def add_component(app: OverFlask, name: str) -> None:
    component_dir = app.project_root / 'components' / name

    if component_dir.exists():
        raise click.ClickException(f"Component '{name}' already exists.")

    component_templates_dir = Config.COMPONENT_TEMPLATES_DIR

    if not component_templates_dir.exists():
        raise click.ClickException('Component templates not found. Is overflask installed?')

    component_dir.mkdir(parents=True)

    env = _get_jinja_env(component_templates_dir)

    for template_file in component_templates_dir.rglob('*'):
        if template_file.is_dir():
            continue

        rel_path = template_file.relative_to(component_templates_dir)
        dest_path = component_dir / rel_path
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        if template_file.suffix == '.jinja':
            dest_path = dest_path.with_suffix('')
            template = env.get_template(str(rel_path))
            content = template.render(component_name=name)
            dest_path.write_text(content)
        else:
            shutil.copy2(template_file, dest_path)

    click.echo(f"Component '{name}' created successfully!")
