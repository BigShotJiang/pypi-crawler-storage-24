"""Task management command implementations."""

from overflask.core.app import OverFlask


def tasks_scheduler(app: OverFlask) -> None:
    """Run the task scheduler (polls ES and dispatches due tasks to Redis)."""
    from overflask.tasks import scheduler
    with app.app_context():
        scheduler.run()


def tasks_worker(app: OverFlask) -> None:
    """Run a task worker (pops from Redis and executes tasks). Scale via compose replicas."""
    from overflask.tasks import worker
    with app.app_context():
        worker.run()


def tasks_kibana(app: OverFlask) -> None:
    """Overwrite Kibana data view, visualizations, and dashboard with current definitions."""
    from overflask.tasks.kibana import provision_kibana
    with app.app_context():
        provision_kibana()
