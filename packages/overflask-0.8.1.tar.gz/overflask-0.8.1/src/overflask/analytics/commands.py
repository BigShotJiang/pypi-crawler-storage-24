"""Click commands for the analytics system."""

import click
from flask import Flask

from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates
from overflask.analytics.purge import AnalyticsPurge


@click.group()
def analytics():
    """Analytics management commands."""


@analytics.command("provision")
@click.pass_obj
def provision_cmd(app: Flask) -> None:
    """Create or update the Elasticsearch index template for analytics indices."""
    with app.app_context():
        AnalyticsEsIndexTemplates.ensure()
        click.echo("Analytics ES index template provisioned.")


@analytics.command("purge")
@click.pass_obj
def purge_cmd(app: Flask) -> None:
    """Delete analytics indices older than the configured retention period."""
    with app.app_context():
        AnalyticsPurge.purge_old()
        click.echo("Analytics purge complete.")
