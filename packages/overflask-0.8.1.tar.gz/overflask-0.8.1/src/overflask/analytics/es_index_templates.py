"""Elasticsearch index templates and naming helpers for the analytics system."""

from datetime import datetime

from overflask.core.config import Config
from overflask.es.elastic import get_es_client


class AnalyticsEsIndexTemplates:
    """Manages ES index templates and index naming for the analytics system."""

    @staticmethod
    def analytics_index(project: str, area: str, dt: datetime) -> str:
        """Return the monthly analytics index name for the given project, area, and datetime."""
        return f"{project}_analytics_{area}-{dt:%Y.%m}"

    @staticmethod
    def ensure() -> None:
        """Create or update the ES index template for all analytics index patterns.

        Idempotent — safe to call on every scheduler and worker startup.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME

        properties = {
            "event": {"type": "keyword"},
            "timestamp": {"type": "date"},
            "project": {"type": "keyword"},
            "environment": {"type": "keyword"},
            "area": {"type": "keyword"},
            "context": {
                "type": "object",
                "properties": {
                    "request_id": {"type": "keyword"},
                    "http_method": {"type": "keyword"},
                    "http_path": {"type": "keyword"},
                    "user_id": {"type": "keyword"},
                },
            },
            "data": {
                "type": "object",
                "dynamic": True,
            },
        }

        es.indices.put_index_template(
            name=f"{project}-analytics",
            index_patterns=[f"{project}_analytics_*-*"],
            template={"mappings": {"properties": properties}},
        )
