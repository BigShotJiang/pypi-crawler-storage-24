"""Analytics index retention: purge indices older than the configured retention period."""

import logging
from datetime import UTC, datetime, timedelta

from overflask.core.config import Config
from overflask.es.elastic import get_es_client

logger = logging.getLogger(__name__)


class AnalyticsPurge:
    """Analytics index retention management."""

    @staticmethod
    def purge_old() -> None:
        """Delete analytics indices older than the configured retention period.

        Reads ANALYTICS_RETENTION_DAYS from Flask config.
        Runs once daily from the scheduler.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME
        retention_days = Config.ANALYTICS_RETENTION_DAYS
        prefix = f"{project}_analytics_"

        now = datetime.now(tz=UTC)
        cutoff = now - timedelta(days=retention_days)

        try:
            indices = es.indices.get(index=f"{prefix}*-*", ignore_unavailable=True)
        except Exception:
            logger.exception("Failed to list analytics indices for purge")
            return

        for index_name in indices:
            # Index format: {project}_analytics_{area}-YYYY.MM
            # Extract the date suffix after the last "-"
            try:
                suffix = index_name.rsplit("-", 1)[-1]  # "YYYY.MM"
                parts = [int(p) for p in suffix.split(".")]
                if len(parts) == 2:
                    index_dt = datetime(parts[0], parts[1], 1, tzinfo=UTC)
                else:
                    continue
                if index_dt < cutoff:
                    es.indices.delete(index=index_name)
            except (ValueError, IndexError):
                continue
