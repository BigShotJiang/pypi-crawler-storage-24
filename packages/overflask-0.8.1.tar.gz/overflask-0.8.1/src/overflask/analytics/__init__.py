"""Analytics package for overflask."""
