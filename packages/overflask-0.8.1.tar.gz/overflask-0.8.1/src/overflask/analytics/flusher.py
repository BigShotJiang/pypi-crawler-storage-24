"""Background daemon thread that bulk-flushes analytics events to Elasticsearch."""

import atexit
import logging
import threading
import time
from datetime import UTC, datetime

from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates
from overflask.analytics.events import AnalyticsEvents
from overflask.core.config import Config
from overflask.es.elastic import get_es_client

logger = logging.getLogger(__name__)


class AnalyticsFlusher:
    """Manages the background flusher thread and bulk-write logic."""

    _flusher_started: bool = False
    _start_lock: threading.Lock = threading.Lock()

    @staticmethod
    def ensure() -> None:
        """Start the background flusher daemon thread on first call (lazy, post-fork safe)."""
        if AnalyticsFlusher._flusher_started or Config.IS_TESTING:
            return

        with AnalyticsFlusher._start_lock:
            if AnalyticsFlusher._flusher_started:
                return
            from flask import current_app
            app = current_app._get_current_object()
            atexit.register(AnalyticsFlusher.flush_now)
            t = threading.Thread(
                target=AnalyticsFlusher._run, args=(app,), daemon=True, name="analytics-flusher"
            )
            t.start()
            AnalyticsFlusher._flusher_started = True

    @staticmethod
    def _run(app) -> None:
        """Loop: sleep N seconds, flush buffer. Runs until process exits."""
        with app.app_context():
            while True:
                time.sleep(Config.ANALYTICS_FLUSH_INTERVAL_SECONDS)
                AnalyticsFlusher.flush_now()

    @staticmethod
    def flush_now() -> int:
        """Drain the buffer and bulk-write to ES immediately.

        Returns the number of events flushed. Safe to call from shutdown hooks or tests.
        """
        batch = AnalyticsEvents.get_batch()
        if not batch:
            return 0

        try:
            es = get_es_client()
            now = datetime.now(tz=UTC)
            operations = []
            for doc in batch:
                index = AnalyticsEsIndexTemplates.analytics_index(
                    doc["project"], doc["area"], now
                )
                operations.append({"index": {"_index": index}})
                operations.append(doc)

            es.bulk(operations=operations)
            return len(batch)
        except Exception:
            logger.exception("Failed to flush %d analytics events to ES", len(batch))
            AnalyticsEvents.put_back_batch(batch)
            return 0
