"""Gunicorn configuration for production deployment."""

import os

# Worker count: configured via environment variable
# Default: 10 (see gunicorn.md for reasoning)
workers = int(os.getenv('WORKER_COUNT', '10'))

# Bind to all interfaces on port 8000
bind = '0.0.0.0:8000'

# Worker class
worker_class = 'sync'

# Timeout for worker processes (seconds)
timeout = 30

# Keep-alive connections
keepalive = 2

# Logging
accesslog = '-'
errorlog = '-'
loglevel = 'info'

# Include worker PID in logs
access_log_format = '[%(p)s] %(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# Graceful timeout
graceful_timeout = 30

# Preload application for memory efficiency
preload_app = True
