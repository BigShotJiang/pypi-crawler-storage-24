"""Cache decorator for caching function results in Redis with stampede prevention.

Usage:
    from overflask import cached, CachePopulationTimeoutError

    @cached(ttl=timedelta(minutes=5))
    def get_profile(user_id, include_details=False):
        # If another caller is already computing this value,
        # we wait. Raises CachePopulationTimeoutError if the
        # other caller takes too long (>10s).
        ...

    # Clear all cached results for this function
    get_profile.clear_all_caches()

    # Clear cache for exact parameter combination
    get_profile.clear_cache(user_id=1, include_details=False)

    # Clear all caches for a key
    cached.clear("get_profile")
"""

import functools
import json
import random
import time
from collections.abc import Callable
from datetime import timedelta
from typing import Any, TypeVar

from overflask.redis.redis import get_redis

# Type variable for decorated functions
F = TypeVar("F", bound=Callable[..., Any])

# Cache uses Redis db 15 to separate from application data
CACHE_DB = 15


class CachePopulationTimeoutError(Exception):
    """Raised when waiting for another caller to populate the cache times out.

    This happens during stampede prevention: when multiple callers request
    the same uncached value simultaneously, only one computes it while others
    wait. If the computing caller takes too long (>10s), waiters raise this.
    """

    pass


class cached:  # noqa: N801
    """Decorator for caching function results in Redis.

    Args:
        ttl: Cache duration as timedelta.
        key: Optional cache key. Defaults to function name.
    """

    def __init__(
        self,
        ttl: timedelta,
        key: str | None = None,
    ):
        """Initialize the cache decorator."""
        self.ttl = ttl
        self.key = key

    def _build_cache_key(self, **kwargs: Any) -> str:
        """Build the cache key from function key and sorted arguments."""
        if not kwargs:
            return self.key  # type: ignore
        sorted_args = ":".join(f"{k}={v}" for k, v in sorted(kwargs.items()))
        return f"{self.key}:{sorted_args}"

    def _build_lock_key(self, cache_key: str) -> str:
        """Build the lock key for a cache key."""
        return f"_lock:{cache_key}"

    def __call__(self, func: F) -> F:
        """Decorate the function with caching behavior."""
        if self.key is None:
            self.key = func.__name__

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Convert positional args to kwargs using function signature
            import inspect

            sig = inspect.signature(func)
            params = list(sig.parameters.keys())
            all_kwargs = dict(zip(params, args, strict=False))
            all_kwargs.update(kwargs)

            r = get_redis(CACHE_DB)
            cache_key = self._build_cache_key(**all_kwargs)
            lock_key = self._build_lock_key(cache_key)
            ttl_seconds = int(self.ttl.total_seconds())

            # Try to get cached value
            cached_value = r.get(cache_key)
            if cached_value is not None:
                return json.loads(cached_value)

            # Cache miss - try to acquire lock
            lock_value = random.randint(0, 9999)
            lock_acquired = r.set(lock_key, lock_value, nx=True, ex=10)

            if lock_acquired:
                # We have the lock - compute the value
                result = func(*args, **kwargs)

                # Verify we still own the lock before caching
                current_lock = r.get(lock_key)
                if current_lock is not None and int(current_lock) == lock_value:
                    r.set(cache_key, json.dumps(result), ex=ttl_seconds)
                    r.delete(lock_key)

                return result
            else:
                # Lock not acquired - poll for cached value
                for _ in range(10):
                    time.sleep(1)
                    cached_value = r.get(cache_key)
                    if cached_value is not None:
                        return json.loads(cached_value)

                raise CachePopulationTimeoutError(
                    f"Timed out waiting for another caller to populate cache: {cache_key}"
                )

        # Attach cache management methods to the wrapper
        wrapper.clear_cache = lambda **kw: self._clear_cache(**kw)  # type: ignore
        wrapper.clear_all_caches = lambda: self._clear_all_caches()  # type: ignore

        return wrapper  # type: ignore

    def _clear_cache(self, **kwargs: Any) -> None:
        """Clear cache for exact parameter combination."""
        r = get_redis(CACHE_DB)
        cache_key = self._build_cache_key(**kwargs)
        r.delete(cache_key)

    def _clear_all_caches(self) -> None:
        """Clear all cached results for this function."""
        r = get_redis(CACHE_DB)
        pattern = f"{self.key}:*"
        cursor = 0
        while True:
            cursor, keys = r.scan(cursor, match=pattern)
            if keys:
                r.delete(*keys)
            if cursor == 0:
                break
        # Also delete the base key (no args case)
        r.delete(self.key)  # type: ignore

    @staticmethod
    def clear(key: str) -> None:
        """Clear all caches for a given key.

        Args:
            key: The cache key (usually function name).
        """
        r = get_redis(CACHE_DB)
        pattern = f"{key}:*"
        cursor = 0
        while True:
            cursor, keys = r.scan(cursor, match=pattern)
            if keys:
                r.delete(*keys)
            if cursor == 0:
                break
        # Also delete the base key
        r.delete(key)
