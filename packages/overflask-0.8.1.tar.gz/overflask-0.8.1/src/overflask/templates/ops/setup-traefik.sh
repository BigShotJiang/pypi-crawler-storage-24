#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# setup-traefik.sh
# Sets up Traefik on the host and/or configures this project's .env.
# Run from the project root directory.
# Requires: bash, docker (with compose plugin)
# =============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

TRAEFIK_CONTAINER=""
COMPOSE=""
INSTALL_DIR=""
ACME_EMAIL=""
USE_STAGING=""
ENV_FILE="./.env"

info()    { echo -e "${CYAN}${BOLD}[info]${RESET}  $*"; }
success() { echo -e "${GREEN}${BOLD}[ok]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}${BOLD}[warn]${RESET}  $*"; }
error()   { echo -e "${RED}${BOLD}[error]${RESET} $*" >&2; }
die()     { error "$*"; exit 1; }

# =============================================================================
# Preflight
# =============================================================================

check_dependencies() {
    command -v docker >/dev/null 2>&1 || die "Docker is not installed or not in PATH."

    if docker compose version >/dev/null 2>&1; then
        COMPOSE="docker compose"
    elif command -v docker-compose >/dev/null 2>&1; then
        COMPOSE="docker-compose"
    else
        die "Docker Compose is not available. Install the Docker Compose plugin."
    fi

    docker info >/dev/null 2>&1 || die "Docker daemon is not running or current user lacks permission."
}

detect_running_traefik() {
    local name image
    while IFS=' ' read -r name image; do
        if [[ "$image" == traefik:* || "$image" == "traefik" ]]; then
            TRAEFIK_CONTAINER="$name"
            return
        fi
    done < <(docker ps --format "{{.Names}} {{.Image}}")
}

# =============================================================================
# Server installation helpers
# =============================================================================

prompt_install_dir() {
    echo
    echo -e "${BOLD}Where should Traefik be installed?${RESET}"
    echo    "  Configuration files and certificates will be stored here."
    echo    "  Suggested: /opt/traefik"
    echo
    read -rp "Installation directory [/opt/traefik]: " INSTALL_DIR
    INSTALL_DIR="${INSTALL_DIR:-/opt/traefik}"
    INSTALL_DIR="${INSTALL_DIR/#\~/$HOME}"

    if [[ -d "$INSTALL_DIR" ]]; then
        warn "Directory '$INSTALL_DIR' already exists."
        read -rp "Continue and overwrite existing config files? [y/N]: " OVERWRITE
        [[ "${OVERWRITE,,}" == "y" ]] || die "Aborted by user."
    fi
}

prompt_email() {
    echo
    echo -e "${BOLD}Let's Encrypt requires a contact email for certificate notifications.${RESET}"
    echo
    while true; do
        read -rp "Email address: " ACME_EMAIL
        [[ "$ACME_EMAIL" =~ ^[^@]+@[^@]+\.[^@]+$ ]] && break
        warn "Please enter a valid email address."
    done
}

prompt_staging() {
    echo
    echo -e "${BOLD}Use Let's Encrypt staging server?${RESET}"
    echo    "  Staging avoids rate limits during testing but issues untrusted certificates."
    echo
    read -rp "Use staging server? [y/N]: " USE_STAGING
    USE_STAGING="${USE_STAGING,,}"
}

write_compose() {
    cat > "$INSTALL_DIR/compose.yaml" <<'YAML'
services:
  traefik:
    image: traefik:v3.6.9
    container_name: traefik
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
      - ./traefik.yml:/etc/traefik/traefik.yml:ro
      - ./acme.json:/etc/traefik/acme.json
    networks:
      - traefik-internal-net

networks:
  traefik-internal-net:
    external: true
YAML
}

write_traefik_yml() {
    local ca_server_line=""
    if [[ "$USE_STAGING" == "y" ]]; then
        ca_server_line="      caServer: https://acme-staging-v02.api.letsencrypt.org/directory"
    fi

    cat > "$INSTALL_DIR/traefik.yml" <<YAML
api:
  dashboard: false

entryPoints:
  web:
    address: ":80"
    http:
      redirections:
        entryPoint:
          to: websecure
          scheme: https
          permanent: true

  websecure:
    address: ":443"
    http:
      tls:
        certResolver: letsencrypt

certificatesResolvers:
  letsencrypt:
    acme:
      email: ${ACME_EMAIL}
      storage: /etc/traefik/acme.json
      httpChallenge:
        entryPoint: web
${ca_server_line}

providers:
  docker:
    endpoint: "unix:///var/run/docker.sock"
    exposedByDefault: false
    network: traefik-internal-net

log:
  level: INFO
YAML
}

ensure_network() {
    if docker network inspect traefik-internal-net >/dev/null 2>&1; then
        info "Docker network 'traefik-internal-net' already exists, skipping."
    else
        docker network create traefik-internal-net >/dev/null
        success "Created Docker network 'traefik-internal-net'."
    fi
}

setup_server() {
    detect_running_traefik

    if [[ -n "$TRAEFIK_CONTAINER" ]]; then
        warn "Traefik is already running as container '$TRAEFIK_CONTAINER'."
        warn "Config files will be overwritten and the container will be restarted to apply changes."
        echo
    fi

    prompt_install_dir
    prompt_email
    prompt_staging

    echo
    info "Installing into: $INSTALL_DIR"
    info "ACME email:       $ACME_EMAIL"
    info "Staging mode:     ${USE_STAGING:-n}"
    echo

    mkdir -p "$INSTALL_DIR" || die "Failed to create directory '$INSTALL_DIR'. Try running with sudo."
    touch "$INSTALL_DIR/acme.json" || die "Failed to create acme.json."
    chmod 600 "$INSTALL_DIR/acme.json"
    ensure_network
    write_compose
    write_traefik_yml

    success "Configuration written to '$INSTALL_DIR'."
    echo
    echo -e "  ${CYAN}compose.yaml${RESET}  — Traefik Docker Compose service"
    echo -e "  ${CYAN}traefik.yml${RESET}   — Traefik static configuration"
    echo -e "  ${CYAN}acme.json${RESET}     — Certificate storage (chmod 600)"
    echo

    if [[ -n "$TRAEFIK_CONTAINER" ]]; then
        read -rp "Restart container '$TRAEFIK_CONTAINER' to apply new config? [Y/n]: " DO_RESTART
        DO_RESTART="${DO_RESTART,,}"
        if [[ -z "$DO_RESTART" || "$DO_RESTART" == "y" ]]; then
            echo
            info "Restarting '$TRAEFIK_CONTAINER'..."
            docker restart "$TRAEFIK_CONTAINER" >/dev/null \
                || die "Failed to restart container '$TRAEFIK_CONTAINER'."
            echo
            success "Traefik restarted with new configuration."
            echo    "  View logs:     docker logs -f $TRAEFIK_CONTAINER"
        else
            echo
            warn "Config updated but container not restarted — changes are not yet active."
        fi
    else
        read -rp "Start Traefik now? [Y/n]: " START_NOW
        START_NOW="${START_NOW,,}"
        if [[ -z "$START_NOW" || "$START_NOW" == "y" ]]; then
            echo
            info "Starting Traefik..."
            $COMPOSE -f "$INSTALL_DIR/compose.yaml" up -d \
                || die "Failed to start Traefik. Check the logs: docker logs traefik"
            echo
            success "Traefik is running."
            echo    "  Check status:  docker ps --filter name=traefik"
            echo    "  View logs:     docker logs -f traefik"
        else
            echo
            info "To start Traefik manually:"
            echo    "  $COMPOSE -f $INSTALL_DIR/compose.yaml up -d"
        fi
    fi
}

# =============================================================================
# Project configuration helpers
# =============================================================================

env_set() {
    local key="$1" value="$2"
    if grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
        local escaped_value="${value//\//\\/}"
        sed -i "s/^${key}=.*/${key}=${escaped_value}/" "$ENV_FILE"
    else
        echo "${key}=${value}" >> "$ENV_FILE"
    fi
}

env_get() {
    local key="$1"
    grep "^${key}=" "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- || true
}

configure_project() {
    [[ -f "$ENV_FILE" ]] || die "No .env file found in current directory. Are you in the project root?"

    local current_domain
    current_domain="$(env_get TRAEFIK_DOMAIN)"
    if [[ -n "$current_domain" ]]; then
        warn "Traefik domain already set to: $current_domain"
        echo
    fi

    echo
    echo -e "${BOLD}Enter the domain this project will be served on.${RESET}"
    echo    "  Example: myapp.example.com"
    echo
    local traefik_domain
    while true; do
        read -rp "Domain${current_domain:+ [${current_domain}]}: " traefik_domain
        traefik_domain="${traefik_domain:-$current_domain}"
        if [[ "$traefik_domain" =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)+$ ]]; then
            break
        fi
        warn "Invalid domain. Enter a plain domain without http:// or trailing slashes."
    done

    env_set "TRAEFIK_DOMAIN" "$traefik_domain"

    echo
    success "Written to $ENV_FILE"
    echo -e "  ${CYAN}TRAEFIK_DOMAIN${RESET} = $traefik_domain"
    echo
    info "Restart the web service to apply: docker compose up -d web"
}

# =============================================================================
# Main
# =============================================================================

main() {
    echo
    echo -e "${BOLD}========================================${RESET}"
    echo -e "${BOLD}  Traefik Setup${RESET}"
    echo -e "${BOLD}========================================${RESET}"
    echo

    check_dependencies

    local did_something=false

    read -rp "Set up / update the Traefik server on this host? [y/N]: " DO_SERVER
    if [[ "${DO_SERVER,,}" == "y" ]]; then
        echo
        setup_server
        did_something=true
    fi

    echo
    read -rp "Configure Traefik integration for this project? [y/N]: " DO_PROJECT
    if [[ "${DO_PROJECT,,}" == "y" ]]; then
        echo
        configure_project
        did_something=true
    fi

    if [[ "$did_something" == false ]]; then
        info "Nothing to do."
    else
        echo
        success "Done."
    fi

    echo
}

main "$@"
