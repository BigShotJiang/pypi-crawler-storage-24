A Flask application built with [overflask](overflask-docs/README-overflask.md).

## Quick Start

```bash
# Install dependencies
pip install -e ".[dev]"

# Configure environment
cp ops/env.template .env
vim .env  # Set your database credentials

# Start PostgreSQL
docker compose up -d db

# Run migrations
python manage.py db upgrade

# Start development server
python manage.py run
```

## Development

### Add a Component

```bash
python manage.py component add auth
```

Components are created in `components/<name>/` with models, views, services, and CLI modules.

### Database Migrations

```bash
# Create migration after changing models
python manage.py db migrate -m "add users table"

# Apply migrations
python manage.py db upgrade

# Rollback
python manage.py db downgrade 001
```

## Deployment

```bash
# Build and start
docker compose build
docker compose up -d

# Run migrations (with web stopped for breaking changes)
docker compose stop web
docker compose run --rm manage db upgrade
docker compose start web
```

Set `WORKER_COUNT` in `.env` based on available CPUs (recommended: `2 × cores + 1`).

## Documentation

See [overflask-docs/README-overflask.md](overflask-docs/README-overflask.md) for detailed documentation on project structure, components, migrations, and deployment.