# Why Gunicorn

This document explains the decision to use Gunicorn for production deployment.

## Final Decision

- **Production**: Gunicorn under Docker
- **Development**: `flask run` via `python manage.py run`

## Questions and Answers

### What deployment options exist for Flask in production?

**WSGI servers (synchronous):**
- Gunicorn - most popular, Unix only
- uWSGI - feature-rich, complex config
- Waitress - pure Python, Windows support
- mod_wsgi - Apache integration

**ASGI servers (async):**
- Uvicorn - fast, needs ASGI wrapper for Flask
- Hypercorn - HTTP/2 support

### Performance comparison

| Server | Requests/sec | Best for |
|--------|--------------|----------|
| Gunicorn | ~3,000-5,000 | General purpose, simplicity |
| uWSGI | ~4,000-6,000 | Max performance, complex needs |
| Waitress | ~2,000-3,500 | Windows, simple deploys |
| mod_wsgi | ~2,500-4,000 | Apache integration |
| Uvicorn | ~5,000-8,000* | Async apps (not Flask) |
| Hypercorn | ~4,000-6,000* | HTTP/2, async apps |

*Uvicorn/Hypercorn numbers are for native async frameworks. Flask through ASGI wrapper loses this advantage.

For Flask specifically, Gunicorn and uWSGI are essentially tied. The database queries and application code dominate performance, not the server choice.

### Gunicorn vs uWSGI (excluding simplicity)

| Aspect | Gunicorn | uWSGI |
|--------|----------|-------|
| Worker types | sync, gthread, gevent, eventlet | sync, threads, gevent, asyncio, coroutines |
| Process management | Basic (relies on systemd/supervisor) | Built-in emperor, vassals, auto-restart |
| Memory | ~20-30MB per worker | ~30-50MB per worker |
| Static files | No | Yes, with caching and gzip |
| Websockets | Limited (needs gevent) | Native support |
| HTTP/2 | No | Yes |
| Rate limiting | No | Built-in |
| Hot reload | SIGHUP, graceful | Chain reloading, zerodowntime |
| Language support | Python only | Python, Ruby, PHP, Go, etc. |

**Where uWSGI wins:** Zero-downtime deploys without nginx, built-in emperor for multi-app management, websocket-heavy applications.

**Where Gunicorn wins:** Lower baseline memory, faster startup, predictable behavior.

### What is the ideal number of processes?

**Formula:** `(2 × CPU cores) + 1`

- `1× cores`: CPU might idle between requests
- `2× cores`: Overlap I/O waits, keep CPU busy
- `3× cores+`: Diminishing returns, context switch overhead grows

**Constraints:**
- Memory: ~30-50MB per worker
- DB connections: pool size × workers
- CPU: Context switching overhead past ~2× cores

### Does this hold under Docker?

No - Docker adds complications:

**Problem:** Gunicorn sees host CPU count, not container limit.
```bash
# Host: 16 cores, container limited to 2 CPUs
python -c "import os; print(os.cpu_count())"
# Output: 16 (wrong!)
```

**Solution:** Always hardcode worker count or use `WORKER_COUNT` environment variable. Never rely on auto-detection in containers.

## Configuration

Worker count is configured via `WORKER_COUNT` environment variable (default: 10).

See `overflask.deploy.gunicorn` module for full configuration including custom log format.
