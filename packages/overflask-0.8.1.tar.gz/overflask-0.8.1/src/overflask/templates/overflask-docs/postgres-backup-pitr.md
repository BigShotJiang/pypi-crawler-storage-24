# PostgreSQL Backup & Point-in-Time Recovery with WAL-G

This guide covers installing and configuring WAL-G for continuous PostgreSQL backups and restoring to either a specific timestamp or a named restore point.

## Prerequisites

- PostgreSQL 13+ (running as the `postgres` OS user)
- A storage backend (S3, GCS, Azure Blob, or local filesystem)
- `sudo` access on the database host

---

## 1. Install WAL-G

Download the latest release binary for your platform:

```bash
curl -L https://github.com/wal-g/wal-g/releases/latest/download/wal-g-pg-ubuntu-20.04-amd64.tar.gz \
  | tar xz -C /usr/local/bin/
chmod +x /usr/local/bin/wal-g
```

Verify:
```bash
wal-g --version
```

---

## 2. Configure Storage

Create `/etc/wal-g.env` with your storage credentials. Only one backend section is needed.

```bash
# Compression (choose one: lz4, zstd, brotli)
WALG_COMPRESSION_METHOD=zstd

# How many incremental deltas before forcing a full backup
WALG_DELTA_MAX_STEPS=6

# Number of full backups to retain (used with: wal-g delete retain FULL N)
WALG_RETAIN_COUNT=7
```

### S3 or S3-compatible (MinIO, Backblaze, etc.)

```bash
WALG_S3_PREFIX=s3://your-bucket/your-cluster
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-key-id
AWS_SECRET_ACCESS_KEY=your-secret-key

# Uncomment for MinIO or other S3-compatible endpoints:
# AWS_ENDPOINT=http://minio:9000
# AWS_S3_FORCE_PATH_STYLE=true
```

### Google Cloud Storage

```bash
WALG_GS_PREFIX=gs://your-bucket/your-cluster
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

### Azure Blob Storage

```bash
WALG_AZ_PREFIX=azure://your-container/your-cluster
AZURE_STORAGE_ACCOUNT=your-account-name
AZURE_STORAGE_KEY=your-key
```

### Local filesystem (dev / testing only)

```bash
WALG_FILE_PREFIX=/mnt/backups/postgres
```

Restrict access to the file:
```bash
chown postgres:postgres /etc/wal-g.env
chmod 600 /etc/wal-g.env
```

---

## 3. Configure PostgreSQL

Edit `postgresql.conf`:

```ini
# Minimum required for WAL archiving
wal_level = replica

# Enable archiving
archive_mode = on

# Push each completed WAL segment to storage
archive_command = 'wal-g wal-push %p --config /etc/wal-g.env'

# Force a WAL segment every 60 seconds even if not full.
# Reduces RPO: without this, a quiet database may not archive for minutes.
archive_timeout = 60
```

Restart PostgreSQL to apply:
```bash
systemctl restart postgresql
```

---

## 4. Take the First Base Backup

Run as the `postgres` user:

```bash
su -c "wal-g backup-push $PGDATA --config /etc/wal-g.env" postgres
```

This uploads a full physical snapshot of the data directory plus a backup manifest. Subsequent backups will be incremental (delta) up to `WALG_DELTA_MAX_STEPS`, then a new full is taken automatically.

Verify it was uploaded:
```bash
wal-g backup-list --detail --config /etc/wal-g.env
```

---

## 5. Schedule Regular Backups

Add a cron job for nightly base backups and weekly pruning:

```
# /etc/cron.d/wal-g

# Nightly base backup at 02:00
0 2 * * * postgres wal-g backup-push /var/lib/postgresql/data --config /etc/wal-g.env >> /var/log/wal-g-backup.log 2>&1

# Weekly: keep only the last 7 full backups (runs Sunday at 03:00)
0 3 * * 0 postgres wal-g delete retain FULL 7 --confirm --config /etc/wal-g.env >> /var/log/wal-g-backup.log 2>&1
```

> **Important:** Never delete WAL segments that are newer than your oldest retained base backup. The `delete retain FULL N` command handles this automatically — it removes base backups beyond N and also removes WAL segments that are no longer needed by any retained backup.

---

## 6. Monitor Archiving Health

WAL archiving failures are silent by default. Monitor `pg_stat_archiver`:

```sql
SELECT
  archived_count,
  last_archived_wal,
  last_archived_time,
  failed_count,
  last_failed_wal,
  last_failed_time
FROM pg_stat_archiver;
```

Alert if `last_failed_time` is recent or `failed_count` is increasing.

---

## 7. Creating Named Restore Points

Before any significant operation (schema migration, bulk import, major release), plant a named marker in the WAL:

```sql
SELECT pg_create_restore_point('before_schema_migration_002');
SELECT pg_create_restore_point('before_v2_data_import');
SELECT pg_create_restore_point('release_2026_03_08');
```

Named restore points are more reliable than guessing a timestamp — they point to an exact WAL position.

> Named restore points exist only in the WAL stream. They require no extra storage and are available as long as the corresponding WAL segments have been archived.

---

## 8. Restoring

### Prepare the target host

1. Stop PostgreSQL:
   ```bash
   systemctl stop postgresql
   ```

2. Clear the data directory:
   ```bash
   rm -rf $PGDATA/*
   ```

3. Fetch the base backup:
   ```bash
   su -c "wal-g backup-fetch $PGDATA LATEST --config /etc/wal-g.env" postgres
   ```
   To restore from a specific backup instead of the latest:
   ```bash
   wal-g backup-list --config /etc/wal-g.env   # find the backup name
   wal-g backup-fetch $PGDATA base_000000010000000000000005 --config /etc/wal-g.env
   ```

### Option A — Restore to a specific timestamp

Add to `postgresql.conf`:

```ini
restore_command = 'wal-g wal-fetch %f %p --config /etc/wal-g.env'
recovery_target_time = '2026-03-07 14:32:00 UTC'
recovery_target_action = 'promote'
```

PostgreSQL will replay WAL up to (but not past) the given timestamp, then promote to read-write.

### Option B — Restore to a named restore point

Add to `postgresql.conf`:

```ini
restore_command = 'wal-g wal-fetch %f %p --config /etc/wal-g.env'
recovery_target_name = 'before_schema_migration_002'
recovery_target_action = 'promote'
```

PostgreSQL replays WAL up to the exact position where `pg_create_restore_point()` was called.

### Start recovery

Create the recovery signal file and start PostgreSQL:

```bash
touch $PGDATA/recovery.signal
chown postgres:postgres $PGDATA/recovery.signal
systemctl start postgresql
```

PostgreSQL will replay WAL automatically. Follow progress in the logs:

```bash
journalctl -u postgresql -f
# look for: "recovery stopping before commit" or "database system is ready"
```

When recovery completes and `recovery_target_action = 'promote'` is set, the instance becomes read-write automatically and the `recovery.signal` file is removed.

### Pausing for inspection before promoting

If you want to inspect data before committing to the recovery point, use `pause` instead of `promote`:

```ini
recovery_target_action = 'pause'
```

The instance starts in read-only mode. Inspect, then promote manually:

```sql
SELECT pg_wal_replay_resume();
```

---

## 9. Test Your Backups

A backup that has never been tested is not a backup. Run a recovery drill periodically:

1. Spin up a separate PostgreSQL instance (a VM, a Docker container, or a spare host)
2. Restore from the latest base backup
3. Replay WAL to a known restore point
4. Run a query to verify expected data is present

Automate this and alert on failure.

---

## Quick Reference

```bash
# Take a base backup
wal-g backup-push $PGDATA --config /etc/wal-g.env

# List backups
wal-g backup-list --detail --config /etc/wal-g.env

# Fetch latest backup (restore step 1)
wal-g backup-fetch $PGDATA LATEST --config /etc/wal-g.env

# Delete old backups, keep last 7 full
wal-g delete retain FULL 7 --confirm --config /etc/wal-g.env

# Plant a named restore point (run in psql)
SELECT pg_create_restore_point('my-label');

# Check archiving health (run in psql)
SELECT * FROM pg_stat_archiver;
```
