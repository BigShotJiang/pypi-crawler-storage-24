# How to Use overflask

This guide explains the project structure and workflows for overflask projects.

## Project Structure

```
myproject/
├── manage.py           # CLI entry point
├── settings.py         # All configuration
├── pyproject.toml      # Python dependencies
├── compose.yaml        # Docker Compose config
├── conftest.py         # pytest configuration and fixtures
├── pytest.ini          # pytest settings
├── .env                # Environment variables (not in git)
├── .gitignore
├── .dockerignore
├── docs/               # Documentation
├── ops/                # Deployment and operations
│   ├── env.template    # Environment template
│   └── migrations/     # Alembic migrations
│       ├── alembic.ini
│       ├── env.py
│       ├── script.py.mako
│       └── versions/
└── components/         # Application components
    └── myproject/      # Initial component (named after project)
        ├── __init__.py
        ├── models.py   # Database models
        ├── views.py    # Flask Blueprints
        ├── services.py # Business logic
        ├── cli.py      # CLI commands
        └── tests.py    # Component tests
```

## Components

Components are self-contained modules with their own models, views, services, and CLI commands.

### Creating a Component

```bash
python manage.py component add auth
```

This creates:
```
components/auth/
├── __init__.py
├── models.py
├── views.py
├── services.py
├── cli.py
└── tests.py
```

The new component is automatically discovered — no registration needed.

### Component Guidelines

1. **models.py**: Define SQLAlchemy models inheriting from `ModelBase` (imported from `overflask`).
2. **views.py**: Define Flask Blueprints. They're auto-discovered and registered.
3. **services.py**: Business logic that can be reused across views and CLI.
4. **cli.py**: Click commands for management tasks.

## Database Migrations

Migrations are stored in `ops/migrations/` and apply to all models across all components.

### Create a Migration

```bash
python manage.py db migrate -m "add users table"
```

### Apply Migrations

```bash
# Upgrade to latest
python manage.py db upgrade

# Upgrade to specific revision
python manage.py db upgrade 003
```

### Rollback Migrations

```bash
python manage.py db downgrade 001
```

## Views and Blueprints

Blueprints in `views.py` are auto-discovered:

```python
# components/myproject/views.py
from flask import Blueprint

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/users")
def list_users():
    return {"users": []}
```

The app factory auto-discovers all subdirectories under `components/` and registers any Blueprint objects found in their `views.py` files.

## Models

Models inherit from `ModelBase`. The table name is derived automatically from the component name and model class — no `__tablename__` needed:

```python
# components/auth/models.py
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from overflask import ModelBase


class User(ModelBase):
    # __tablename__ auto-set to "auth_users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)


class UserRole(ModelBase):
    # __tablename__ auto-set to "auth_user_roles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
```

The naming rule is `{component}_{plural_snake_case_model_name}`. Set `__tablename__` explicitly to override it.

All models share a single database and migration history.

## Testing

Each component ships with a `tests.py` file. Run all tests with:

```bash
pytest
# or in parallel:
pytest -n auto
```

Tests are discovered from `components/` automatically via `pytest.ini`.

### Unit vs Integration Tests

Mark tests explicitly to control database access:

```python
import pytest

class TestAuthUnit:
    @pytest.mark.unit
    def test_login_validates_input(self, client):
        # Database access is blocked — use client for HTTP or mock the DB.
        response = client.get("/auth/health")
        assert response.status_code == 200

class TestAuthIntegration:
    @pytest.mark.integration
    def test_creates_user(self, db_session):
        # Real PostgreSQL, isolated per test via cloned template DB.
        from components.auth.models import User
        user = User(email="alice@example.com")
        db_session.add(user)
        db_session.commit()
        assert user.id is not None
```

Unmarked tests are treated as unit tests (DB blocked).

### Fixtures from Files

Use `@fixture_file` to load JSON data into `db_session` for a test:

```python
from overflask.testing.testing import fixture_file

@fixture_file("fixtures/roles.json")
@pytest.mark.integration
def test_list_roles(db_session, fixture_data):
    # fixture_data: list of model instances loaded from JSON
    assert len(fixture_data) == 2
    assert fixture_data[0].name == "admin"
```

Fixture file format (`components/auth/tests/fixtures/roles.json`):

```json
[
  {
    "model": "auth.Role",
    "records": [
      {"name": "admin"},
      {"name": "user"}
    ]
  }
]
```

The `model` key uses `{component}.{ModelName}` shorthand. Multiple files and cross-component references are supported — SQLAlchemy handles FK ordering.

### Creating Fixture Files from Code

Serialize in-memory instances to a fixture file with `create_data_fixture()`. Call it from inside a `components/` test file — it writes relative to the caller:

```python
from overflask.testing.testing import create_data_fixture
from components.auth.models import Role

# Called from components/auth/tests/test_views.py
# Writes to components/auth/tests/fixtures/roles.json
create_data_fixture(
    [Role(name="admin"), Role(name="user")],
    "fixtures/roles.json",
)
```

### Database Details

- Tests run against a real PostgreSQL instance (same credentials as `.env`).
- A template DB is created once per model-change and cloned per test — fast isolation with no `create_all()` overhead per test.
- The template is rebuilt automatically when any `models.py` file changes (tracked via SHA256 hash in `.pytest_template_hash`).
- **Simultaneous parallel pytest runs are not supported.** Run one invocation at a time.

### Available Fixtures

| Fixture | Scope | Description |
|---------|-------|-------------|
| `app` | session | The Flask application |
| `client` | function | Flask test client |
| `db_session` | function | Isolated SQLAlchemy session (integration only) |
| `fixture_data` | function | Instances loaded via `@fixture_file` |
| `redis` | function | fakeredis instance (DB 0) |
| `tasks_queue` | function | `TaskStore.queued` list, cleared before and after each test |

Redis is always mocked with fakeredis — no real Redis needed for tests.

## Settings

`settings.py` contains only the project identity. All other configuration (database, Redis, Elasticsearch, etc.) is read from environment variables automatically by overflask:

```python
PROJECT_NAME = 'myproject'
VERIFIED_OVERFLASK_VERSION = '1.2.3'
```

Components are auto-discovered from the `components/` directory — no list to maintain. Environment variables are loaded from `.env` via `python-dotenv`. See `ops/env.template` for the full list of supported variables.

## Deployment

### Environment Configuration

Production settings in `.env`:

```bash
# Required
POSTGRES_HOST=your-db-host
POSTGRES_PORT=5432
POSTGRES_USER=your-user
POSTGRES_PASSWORD=your-password
POSTGRES_DB=your-database
SECRET_KEY=your-64-char-hex-key

# Optional
IS_DEBUG=false
WORKER_COUNT=5  # Recommended: (2 × CPU cores) + 1
```

### Docker Deployment

```bash
# Build images
docker compose build

# Start all services
docker compose up -d

# View logs
docker compose logs -f web

# Apply migrations
docker compose exec web python manage.py db upgrade
```

### Production Checklist

1. **Worker count**: Set `WORKER_COUNT` based on available CPUs. Formula: `(2 × CPU cores) + 1`. See `docs/why-gunicorn.md` for details.

2. **Secret key**: Generate a secure key:
   ```bash
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

3. **Database**: Use a managed PostgreSQL service or properly secured container.

4. **Reverse proxy**: Traefik is pre-configured for this project. Run `bash ops/setup-traefik.sh` to set it up. See `docs/traefik.md` for details.

5. **Migrations**: Always run migrations before deploying new code:
   ```bash
   docker compose exec web python manage.py db upgrade
   ```

### Manual Deployment (without Docker)

```bash
# Install dependencies
pip install -e ".[dev]"

# Set environment variables
export POSTGRES_HOST=...
export SECRET_KEY=...
# ... etc

# Run with Gunicorn
gunicorn -c python:overflask.deploy.gunicorn "manage:app"
```

## Tasks

overflask includes a task system backed by Elasticsearch and Redis. Tasks are defined in a component's `tasks.py` and run by separate scheduler and worker processes.

### Async tasks

Decorate a function with `@async_task` to enqueue it on demand. All parameters must be type-annotated and JSON-serializable (str, int, float, bool, list, dict, None).

```python
# components/auth/tasks.py
from overflask import async_task

@async_task
def send_welcome_email(user_id: int, email: str) -> None:
    """Send a welcome email to a newly registered user."""
    ...
```

Enqueue the task from anywhere in your application:

```python
from components.auth.tasks import send_welcome_email
from datetime import timedelta

# Run immediately
send_welcome_email.queue(user_id=42, email="alice@example.com")

# Run after a delay
send_welcome_email.queue(timedelta(minutes=5), user_id=42, email="alice@example.com")

# Run at a specific time
from datetime import datetime, timezone
send_welcome_email.queue(datetime(2026, 6, 1, 9, 0, tzinfo=timezone.utc), user_id=42, email="alice@example.com")
```

Use `key` to tag a task for later cancellation:

```python
send_welcome_email.queue(user_id=42, email="alice@example.com", key="welcome-42")

# Cancel before it runs
from overflask import delete
delete(key="welcome-42")
```

### Recurring tasks

Decorate a function with `@recurring_task(cron)` to schedule it on a cron expression. The scheduler automatically reschedules each occurrence after dispatch.

```python
# components/reports/tasks.py
from overflask import recurring_task

@recurring_task("0 9 * * MON-FRI")
def daily_report() -> None:
    """Generate and email the daily report on weekday mornings."""
    ...
```

Cron expressions follow standard five-field format: `minute hour day-of-month month day-of-week`.

### Testing tasks

In tests (`TESTING=True`), tasks are not sent to ES or Redis. Use the `tasks_queue` fixture to capture enqueued tasks, and call the decorated function directly to test its logic.

```python
def test_sends_welcome_email(tasks_queue):
    send_welcome_email.queue(user_id=1, email="a@b.com")
    assert len(tasks_queue) == 1
    assert tasks_queue[0]["kwargs"]["user_id"] == 1

def test_email_logic_directly():
    send_welcome_email(user_id=1, email="a@b.com")  # calls underlying function
```

### Running the task processes

```bash
# Polls ES for due tasks and dispatches them to Redis
python manage.py tasks scheduler

# Pops tasks from Redis and executes them (scale with compose replicas)
python manage.py tasks worker

# Provision Kibana dashboard for task monitoring
python manage.py tasks kibana
```

### Infrastructure requirements

The tasks system requires Elasticsearch and Redis. Add the following to your `.env`:

```bash
ELASTICSEARCH_URL=http://localhost:9200

# Optional retention (days)
TASKS_REGISTERED_RETENTION_DAYS=7
TASKS_DISPATCHED_RETENTION_DAYS=7
TASKS_COMPLETED_RETENTION_DAYS=30
TASKS_METRICS_RETENTION_DAYS=365
```

## Analytics

overflask includes a lightweight analytics event system. Call `Analytics.record()` from anywhere in your application — the event is buffered in memory and flushed to Elasticsearch in the background without blocking the request.

Both technical metrics (request timing, error rates) and business metrics (signups, purchases) are in scope.

### Recording events

```python
from overflask.analytics import Analytics

Analytics.record("user.registered", area="auth", plan="free", source="organic")
Analytics.record("purchase.completed", area="billing", amount=99, currency="usd")
Analytics.record("report.generated", area="reports")
```

`area` is required and determines which Elasticsearch index the event is written to. Use it to group related events by component or domain (e.g. `"auth"`, `"billing"`, `"api"`).

All remaining keyword arguments are stored as-is under `data` in the event envelope and dynamically indexed by Elasticsearch.

### Event envelope

Every event is stored with a consistent structure:

```json
{
  "event":       "user.registered",
  "timestamp":   "2026-03-02T14:32:01.123456+00:00",
  "project":     "myapp",
  "environment": "production",
  "area":        "auth",
  "context": {
    "request_id":  "a3f1c2d9",
    "http_method": "POST",
    "http_path":   "/api/register",
    "user_id":     "123"
  },
  "data": {
    "plan":   "free",
    "source": "organic"
  }
}
```

`context` is populated automatically when `Analytics.record()` is called inside a Flask request context. It is omitted entirely when called outside one (e.g. from a scheduled task). `context.request_id` comes from `g.request_id` or the `X-Request-ID` header if set. `context.user_id` comes from `g.user_id` if set.

### Index strategy

Events are written to monthly, per-area indices:

```
{project}_analytics_{area}-YYYY.MM
```

For example, `myapp_analytics_auth-2026.03`. This gives each domain its own index with independent retention, mappings, and Kibana data views. Query across all areas with the wildcard `myapp_analytics_*-*`.

`area` is normalised before use: lowercased and non-alphanumeric characters replaced with underscores.

### How flushing works

`Analytics.record()` appends to an in-memory buffer and returns immediately. A daemon thread started on the first `record()` call wakes every `ANALYTICS_FLUSH_INTERVAL_SECONDS` seconds and bulk-writes up to `ANALYTICS_FLUSH_BATCH_SIZE` events to Elasticsearch. On process exit, buffered events are flushed synchronously via `atexit`.

Events in the buffer at the time of a hard kill (`SIGKILL`) are lost — this is acceptable for an analytics buffer. Use the Tasks system if you need delivery guarantees.

### Testing analytics

In tests (`TESTING=True`), the flusher thread is never started. Events accumulate in `AnalyticsEvents.buffer` for inspection. Use the `analytics_recorded` fixture to get a clean buffer:

```python
def test_records_signup_event(client, analytics_recorded):
    client.post("/register", json={"email": "alice@example.com"})

    assert len(analytics_recorded) == 1
    event = analytics_recorded[0]
    assert event["event"] == "user.registered"
    assert event["area"] == "auth"
    assert event["data"]["plan"] == "free"
```

The fixture clears the buffer before and after each test automatically.

### Running the analytics processes

The analytics system requires no extra processes — flushing happens inside each gunicorn worker. The scheduler provisions the Elasticsearch index template and purges old indices as part of its normal startup and daily maintenance cycle.

If you need to provision or purge manually:

```bash
# Create or update the Elasticsearch index template
python manage.py analytics provision

# Delete indices older than ANALYTICS_RETENTION_DAYS
python manage.py analytics purge
```

### Infrastructure requirements

The analytics system uses the same Elasticsearch instance as the tasks system. Add the following to your `.env` if you want to override the defaults:

```bash
# Optional — all have sensible defaults
ANALYTICS_ENVIRONMENT=production        # tag written to every event
ANALYTICS_RETENTION_DAYS=365           # how long to keep monthly indices
ANALYTICS_FLUSH_INTERVAL_SECONDS=5     # how often the background thread flushes
ANALYTICS_FLUSH_BATCH_SIZE=500         # max events per bulk write
```

### Available fixtures

| Fixture | Scope | Description |
|---------|-------|-------------|
| `analytics_recorded` | function | `AnalyticsEvents.buffer`, cleared before and after each test |

## Command Reference

```bash
# Development server
python manage.py run
python manage.py run 0.0.0.0 8000

# Components
python manage.py component add <name>

# Database
python manage.py db migrate -m "message"
python manage.py db upgrade [revision]
python manage.py db downgrade <revision>

# Tests
pytest                    # all tests, sequential
pytest -n auto            # all tests, parallel
pytest -m unit            # unit tests only (no DB needed)
pytest -m integration     # integration tests only
pytest components/auth/   # one component

# Tasks
python manage.py tasks scheduler   # run scheduler process
python manage.py tasks worker      # run worker process
python manage.py tasks kibana      # provision Kibana dashboard

# Analytics
python manage.py analytics provision   # create/update ES index template
python manage.py analytics purge       # delete indices older than retention period
```