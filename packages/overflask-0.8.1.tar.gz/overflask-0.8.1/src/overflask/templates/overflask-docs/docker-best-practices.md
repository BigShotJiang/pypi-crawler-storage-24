# Docker Best Practices

## 1. Pruning Dangling Images

### What are dangling images?

Every time you rebuild a Docker image using an existing tag, Docker creates a new image ID and moves the tag to it. The old image loses its tag and becomes dangling — shown as `<none>:<none>` in `docker images`. It still occupies disk space but is no longer reachable by name.

This happens routinely with every `docker compose up --build` or `docker compose build`.

Check what's currently dangling:
```bash
docker images -f dangling=true
```

### Pruning

Remove only dangling images (safe — nothing running references them):
```bash
docker image prune -f
```

Remove all images not referenced by any container (more aggressive — do not run while containers are stopped temporarily):
```bash
docker image prune -a -f
```

`docker system prune` goes further and removes dangling images, stopped containers, unused networks, and build cache in one shot:
```bash
docker system prune
```

Add `--volumes` to also remove unused volumes (use with care).

### Automate with cron

Add a weekly cleanup job on your Docker host:

```
# /etc/cron.d/docker-prune
0 4 * * 0 root docker image prune -f >> /var/log/docker-prune.log 2>&1
```

Or more aggressively, remove all images unused in the last 48 hours:
```
0 4 * * * root docker image prune -a -f --filter "until=48h" >> /var/log/docker-prune.log 2>&1
```

> **Note:** `docker system prune` and `docker image prune -a` only affect images not currently referenced by a container, running or stopped. They will not remove images in active use.

---

## 2. Container Log Management

### The problem

Docker's default logging driver is `json-file`. It writes all container output to:
```
/var/lib/docker/containers/<container-id>/<container-id>-json.log
```

There is no rotation by default. A long-running or verbose container will grow this file unboundedly until it fills the disk.

`docker logs --since` and `--until` do not use an index — they perform a full linear scan of this file from the beginning. On a large log file this is slow regardless of the time range requested.

### Configure log rotation globally

Edit `/etc/docker/daemon.json` (create it if it doesn't exist):

```json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

Restart the Docker daemon to apply:
```bash
systemctl restart docker
```

`max-file` sets how many log files to keep per container. When the active log file reaches `max-size`, Docker renames it to a numbered backup (`.1`, `.2`, …) and starts a fresh file. Once the count reaches `max-file`, the oldest backup is deleted. With `max-size: "10m"` and `max-file: "3"` each container keeps at most 3 × 10 MB = 30 MB of logs at any time.

> **Important:** This only applies to containers created after the daemon restart. Recreate existing containers (`docker compose down && docker compose up -d`) to pick up the new config.

### Configure log rotation per service

Set it directly in `compose.yaml` for fine-grained control per service:

```yaml
services:
  web:
    logging:
      driver: json-file
      options:
        max-size: "10m"
        max-file: "3"

  tasks-worker:
    logging:
      driver: json-file
      options:
        max-size: "20m"
        max-file: "5"
```

Per-service config takes precedence over the daemon default.

### Alternative: use the `local` log driver

The `local` driver is a drop-in replacement for `json-file` with rotation enabled by default (100 MB, 5 files) and a more efficient binary storage format:

```yaml
services:
  web:
    logging:
      driver: local
```

Or globally in `daemon.json`:
```json
{
  "log-driver": "local"
}
```

The trade-off: `docker logs` still works, but the log files are not human-readable on disk (they are binary, not JSON).

### Check current log file sizes

```bash
du -sh /var/lib/docker/containers/*/*-json.log | sort -h
```
