# Traefik & HTTPS

This project is pre-configured to run behind [Traefik](https://traefik.io/) as a reverse proxy with automatic HTTPS via Let's Encrypt.

Run the setup script from the project root to get everything in place:

```bash
bash ops/setup-traefik.sh
```

The script has two independent sections — answer yes to either, both, or neither.

---

## 1. Set up the Traefik server

Installs and starts Traefik on the host. You only need to do this once per server, not once per project.

What it does:

- Prompts for an installation directory (default: `/opt/traefik`)
- Prompts for a Let's Encrypt contact email
- Asks whether to use the Let's Encrypt staging server (safe for testing, issues untrusted certs)
- Writes `compose.yaml` and `traefik.yml` to the installation directory
- Creates `acme.json` with the required `600` permissions (certificate storage)
- Creates the shared Docker network `traefik-internal-net` if it does not exist
- Starts Traefik via `docker compose up -d`, or restarts it if already running

If Traefik is already running when you run the script, it detects the container and offers a restart instead of a fresh start — existing certificates in `acme.json` are preserved.

### Requirements

- Docker with the Compose plugin (or `docker-compose` standalone)
- Ports 80 and 443 open and reachable from the internet
- A domain with its DNS A record pointing to this server

### Staging vs production

Use the staging server during initial setup to avoid hitting Let's Encrypt rate limits. Once everything works, re-run the script without staging to get a trusted certificate.

---

## 2. Configure this project

Writes the domain into the project's `.env` file so Traefik knows where to route traffic.

What it sets in `.env`:

| Variable | Description |
|---|---|
| `TRAEFIK_DOMAIN` | The domain this project will be served on, e.g. `myapp.example.com` |

The `web` service in `compose.yaml` reads this value and exposes itself to Traefik with the correct routing rule. No other changes are needed.

If `TRAEFIK_DOMAIN` is already set, the current value is shown and you can update it or keep it by pressing Enter.

After configuring, apply the change:

```bash
docker compose up -d web
```

---

## How it works

Traefik runs as a standalone container on the host and watches Docker for containers that have `traefik.enable=true` on the shared `traefik-internal-net` network. When it finds one, it reads the labels to determine routing rules and automatically provisions a certificate.

```
Internet → :80/:443 (Traefik) → traefik-internal-net → web container
```

All HTTP traffic is permanently redirected to HTTPS. Certificates renew automatically 30 days before expiry — no cron jobs needed.

---

## Multiple projects on the same server

Traefik is shared across all projects. Run the server setup once, then run only the project configuration step for each additional project with its own domain.

Each project gets its own router inside Traefik, identified by the project name set at generation time.
