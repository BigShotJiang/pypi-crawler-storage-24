"""Shared scaffolding helpers used by both project creation and the overwrite command."""

import shutil
from pathlib import Path

from overflask.core.config import Config

_ROOT_RENDERED_TEMPLATES = [
    'manage.py.jinja',
    'settings.py.jinja',
    'compose.yaml.jinja',
    'pyproject.toml.jinja',
    'conftest.py.jinja',
]

_ROOT_STATIC_FILES = [
    ('README.md', 'README.md'),
    ('gitignore', '.gitignore'),
    ('dockerignore', '.dockerignore'),
    ('pytest.ini', 'pytest.ini'),
]



def render_template(template_path: Path, context: dict) -> str:
    """Render a template file by replacing {{ key }} placeholders."""
    content = template_path.read_text()
    for key, value in context.items():
        content = content.replace('{{ ' + key + ' }}', str(value))
    return content


def get_overflask_pypi_source() -> str:
    """Get the overflask dependency string for pyproject.toml."""
    import overflask

    package_path = Path(overflask.__file__).parent
    if 'site-packages' in str(package_path):
        return f'overflask=={Config.OVERFLASK_VERSION}'
    else:
        source_dir = package_path.parent.parent
        return f'overflask @ file://{source_dir}'


def write_root_files(project_dir: Path, context: dict) -> list[Path]:
    """Write rendered and static root-level project files. Returns list of written paths."""
    templates_dir = Config.TEMPLATES_DIR
    written = []

    for template_name in _ROOT_RENDERED_TEMPLATES:
        dest = project_dir / Path(template_name).stem  # strips .jinja
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(render_template(templates_dir / template_name, context))
        written.append(dest)

    for src_name, dest_name in _ROOT_STATIC_FILES:
        dest = project_dir / dest_name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(templates_dir / src_name, dest)
        written.append(dest)

    return written
