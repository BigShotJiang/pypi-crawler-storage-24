"""overflask CLI - Create Flask projects with component-based architecture."""

import re
import secrets
import shutil
import subprocess
from pathlib import Path

import click

from overflask.cli.scaffold import get_overflask_pypi_source, render_template, write_root_files
from overflask.core.config import Config


def generate_secret_key() -> str:
    """Generate a secure secret key."""
    return secrets.token_hex(32)


def prompt_config(
    keys: list[str],
    defaults: dict[str, str] | None = None,
    required: list[str] | None = None,
    secret: list[str] | None = None,
    hints: dict[str, str] | None = None,
) -> tuple[dict[str, str], list[str]]:
    """Prompt for configuration values.

    Args:
        keys: List of environment variable names to prompt for.
        defaults: Optional dict of default values for specific keys.
        required: List of keys that are required (missing values will be tracked).
        secret: List of keys whose input should be hidden and whose defaults shown as '[generated]'.
        hints: Display hints shown in brackets for specific keys, overriding default display.

    Returns:
        Tuple of (values dict, list of missing required keys).
    """
    defaults = defaults or {}
    required = required or []
    secret = secret or []
    hints = hints or {}
    values = {}
    missing = []

    for key in keys:
        default = defaults.get(key)
        is_secret = key in secret
        prompt = f'  {key}'
        if key in hints:
            prompt += f' [{hints[key]}]'
        elif default:
            prompt += ' [random generated]' if is_secret else f' [{default}]'

        value = click.prompt(prompt, default=default or '', show_default=False, hide_input=is_secret).strip()
        values[key] = value
        if not value and key in required:
            missing.append(key)

    return values, missing


def _get_container_ip(project_dir: Path, service: str) -> str | None:
    """Start a compose service and return its container IP address."""
    try:
        subprocess.run(['docker', 'compose', 'up', '-d', service], cwd=project_dir, check=True, capture_output=True)
        result = subprocess.run(
            ['docker', 'compose', 'ps', '-q', service], cwd=project_dir, check=True, capture_output=True, text=True
        )
        container_id = result.stdout.strip()
        if not container_id:
            return None
        inspect = subprocess.run(
            ['docker', 'inspect', container_id, '--format', '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}'],
            check=True, capture_output=True, text=True,
        )
        return inspect.stdout.strip() or None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def populate_env_content(content: str, *value_dicts: dict[str, str]) -> str:
    """Replace placeholder values in env template content.

    Args:
        content: The env template content.
        value_dicts: One or more dicts of key-value pairs to substitute.

    Returns:
        The content with values substituted.
    """
    for values in value_dicts:
        for key, value in values.items():
            if value:
                content = content.replace(f'{key}=', f'{key}={value}')
    return content


def create_component(project_dir: Path, component_name: str):
    """Create a component using the package's component templates."""
    component_dir = project_dir / 'components' / component_name
    context = {'component_name': component_name}

    templates = [
        ('__init__.py.jinja', component_dir / '__init__.py'),
        ('models.py.jinja', component_dir / 'models.py'),
        ('views.py.jinja', component_dir / 'views.py'),
        ('services.py.jinja', component_dir / 'services.py'),
        ('cli.py.jinja', component_dir / 'cli.py'),
        ('tasks.py.jinja', component_dir / 'tasks.py'),
        ('tests.py.jinja', component_dir / 'tests.py'),
    ]

    for template_name, dest in templates:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(render_template(Config.COMPONENT_TEMPLATES_DIR / template_name, context))


def _validate_project(name: str, project_dir: Path) -> None:
    if not re.match(r'^[a-z][a-z0-9_]*$', name):
        raise click.ClickException(
            f"Invalid project name '{name}'. "
            "Use lowercase letters, digits, and underscores only, starting with a letter."
        )
    if project_dir.exists():
        raise click.ClickException(f"Directory '{name}' already exists.")


def _prompt_project_config(name: str) -> tuple[str, dict[str, str], dict[str, str], list[str]]:
    component_name = click.prompt('\nInitial component name', default=name, show_default=True).strip()

    click.echo('\nPostgres configuration (press Enter for defaults):')
    postgres_values, missing_values = prompt_config(
        ['POSTGRES_HOST', 'POSTGRES_PORT', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'POSTGRES_DB'],
        defaults={
            'POSTGRES_PORT': '5432',
            'POSTGRES_USER': 'admin',
            'POSTGRES_PASSWORD': secrets.token_urlsafe(16),
            'POSTGRES_DB': name
        },
        required=['POSTGRES_HOST', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'POSTGRES_DB'],
        secret=['POSTGRES_PASSWORD'],
        hints={'POSTGRES_HOST': 'auto from docker'},
    )

    click.echo('\nRedis configuration (press Enter for defaults):')
    redis_values, redis_missing = prompt_config(
        ['REDIS_URL'],
        required=['REDIS_URL'],
        hints={'REDIS_URL': 'auto from docker'},
    )
    missing_values.extend(redis_missing)

    return component_name, postgres_values, redis_values, missing_values


def _scaffold_project(project_dir: Path, context: dict) -> str:
    """Create all project files and return the generated .env content."""
    templates_dir = Config.TEMPLATES_DIR

    project_dir.mkdir(parents=True)
    write_root_files(project_dir, context)

    for template_name, dest in [
        ('ops/migrations/alembic.ini.jinja', project_dir / 'ops' / 'migrations' / 'alembic.ini'),
        ('ops/migrations/env.py.jinja', project_dir / 'ops' / 'migrations' / 'env.py'),
    ]:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(render_template(templates_dir / template_name, context))

    for src_name, dest in [
        ('ops/env.template', project_dir / 'ops' / 'env.template'),
        ('ops/setup-traefik.sh', project_dir / 'ops' / 'setup-traefik.sh'),
        ('ops/migrations/script.py.mako', project_dir / 'ops' / 'migrations' / 'script.py.mako'),
    ]:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(templates_dir / src_name, dest)

    shutil.copytree(templates_dir / 'overflask-docs', project_dir / 'overflask-docs')
    (project_dir / 'ops' / 'migrations' / 'versions').mkdir(parents=True, exist_ok=True)

    env_content = populate_env_content(
        (templates_dir / 'ops' / 'env.template').read_text(),
        context['postgres'],
        context['redis'],
        {'SECRET_KEY': context['secret_key']},
    )
    (project_dir / '.env').write_text(env_content)

    create_component(project_dir, context['initial_component'])

    return env_content


def _detect_service_ips(project_dir: Path, missing_values: list[str], env_content: str) -> list[str]:
    """Start Docker services for any missing IPs, update .env, and return remaining missing keys."""
    auto_detect_services = [
        ('POSTGRES_HOST', 'db', lambda ip: ip),
        ('REDIS_URL', 'redis', lambda ip: f'redis://{ip}:6379'),
    ]
    auto_detected_values = {}
    for env_key, service, fmt in auto_detect_services:
        if env_key in missing_values:
            click.echo(f'\nDetecting {env_key} from docker... ', nl=False)
            service_ip = _get_container_ip(project_dir, service)
            if service_ip:
                auto_detected_values[env_key] = fmt(service_ip)
                missing_values.remove(env_key)
                click.echo(service_ip)
            else:
                click.echo('could not detect IP')

    if auto_detected_values:
        env_content = populate_env_content(env_content, auto_detected_values)
        (project_dir / '.env').write_text(env_content)

    return missing_values


@click.group()
@click.version_option()
def main():
    """overflask - Scaffold Flask projects with component-based architecture."""
    pass


@main.command()
@click.argument('name')
def create(name: str):
    """Create a new Flask project with the given NAME."""
    project_dir = Path.cwd() / name
    _validate_project(name, project_dir)

    component_name, postgres_values, redis_values, missing_values = _prompt_project_config(name)

    click.echo(f"\nCreating project '{name}'...")

    context = {
        'project_name': name,
        'secret_key': generate_secret_key(),
        'initial_component': component_name,
        'overflask_source': get_overflask_pypi_source(),
        'overflask_version': Config.OVERFLASK_VERSION,
        'postgres': postgres_values,
        'redis': redis_values,
    }
    env_content = _scaffold_project(project_dir, context)

    click.echo(f"\nProject '{name}' created successfully!")
    click.echo(f"Initial component '{component_name}' created.")

    missing_values = _detect_service_ips(project_dir, missing_values, env_content)

    if missing_values:
        click.echo('\nNote: The following values were not provided and need to be configured in .env:')
        for key in missing_values:
            click.echo(f'  - {key}')

    click.echo('\nNext steps:')
    click.echo(f'  cd {name}')
    click.echo('  python -m venv .venv && source .venv/bin/activate')
    click.echo('  pip install -e ".[dev]"')
    click.echo('  python manage.py run')


if __name__ == '__main__':
    main()
