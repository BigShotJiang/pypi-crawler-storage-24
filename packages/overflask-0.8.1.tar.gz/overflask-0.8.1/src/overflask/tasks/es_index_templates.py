"""Elasticsearch index templates and naming helpers for the tasks system."""

from datetime import datetime

from overflask.core.config import Config
from overflask.es.elastic import get_es_client


class EsIndexTemplates:
    """Manages ES index templates and index naming for the tasks system."""

    @staticmethod
    def registered_index(project: str, dt: datetime) -> str:
        """Return the monthly registered-tasks index name for the given datetime."""
        return f"{project}_tasks_registered-{dt:%Y.%m}"

    @staticmethod
    def dispatched_index(project: str, dt: datetime) -> str:
        """Return the monthly dispatched-tasks index name for the given datetime."""
        return f"{project}_tasks_dispatched-{dt:%Y.%m}"

    @staticmethod
    def completed_index(project: str, dt: datetime) -> str:
        """Return the monthly completed-tasks index name for the given datetime."""
        return f"{project}_tasks_completed-{dt:%Y.%m}"

    @staticmethod
    def metrics_index(project: str, dt: datetime) -> str:
        """Return the daily metrics index name for the given datetime."""
        return f"{project}_tasks_metrics-{dt:%Y.%m.%d}"

    @staticmethod
    def ensure() -> None:
        """Create or update ES index templates for all task index patterns.

        Idempotent — safe to call on every scheduler and worker startup.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME

        _common = {
            "id": {"type": "long"},
            "key": {"type": "keyword"},
            "type": {"type": "keyword"},
            "function": {"type": "keyword"},
            "args": {"type": "object", "enabled": False},
            "kwargs": {"type": "object", "enabled": False},
            "created_at": {"type": "date"},
            "run_at": {"type": "date"},
            "cron": {"type": "keyword"},
        }

        templates = [
            (
                f"{project}-tasks-registered",
                f"{project}_tasks_registered-*",
                {**_common, "batch_id": {"type": "long"}},
            ),
            (
                f"{project}-tasks-dispatched",
                f"{project}_tasks_dispatched-*",
                {
                    **_common,
                    "dispatched_at": {"type": "date"},
                    "failed_at": {"type": "date"},
                    "error": {"type": "text"},
                    "error_traceback": {"type": "text"},
                },
            ),
            (
                f"{project}-tasks-completed",
                f"{project}_tasks_completed-*",
                {
                    **_common,
                    "dispatched_at": {"type": "date"},
                    "completed_at": {"type": "date"},
                },
            ),
            (
                f"{project}-tasks-metrics",
                f"{project}_tasks_metrics-*",
                {
                    "timestamp": {"type": "date"},
                    "registered_count": {"type": "long"},
                    "dispatched_count": {"type": "long"},
                    "completed_count": {"type": "long"},
                },
            ),
        ]

        for name, pattern, properties in templates:
            es.indices.put_index_template(
                name=name,
                index_patterns=[pattern],
                template={"mappings": {"properties": properties}},
            )
