"""CallableWrapper: wraps a task function and exposes .queue()."""

import functools
import secrets
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any

from overflask.tasks.callable_data import CallableData
from overflask.tasks.task_store import TaskStore
from overflask.tasks.validator import validate_queue_call


class CallableWrapper(CallableData):
    """Wraps a task function with functools metadata and exposes .queue() for enqueuing."""

    def __init__(self, fn: Callable, cron: str):
        super().__init__(fn, cron)
        functools.update_wrapper(self, self.fn)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Call the underlying function directly (e.g. in tests)."""
        return self.fn(*args, **kwargs)

    def queue(
            self,
            when: datetime | timedelta | None = None,
            *args: Any,
            key: str | None = None,
            **kwargs: Any,
    ) -> int:
        """Enqueue this task.

        Args:
            when: None for immediate, timedelta for relative delay, datetime for exact time.
            key: Optional deletion key to identify this task instance.
            *args: Positional arguments passed to the task function.
            **kwargs: Keyword arguments passed to the task function.

        Returns:
            The task ID (long int).

        Raises:
            ValueError: On invalid `when` type, missing/unexpected params, or non-serializable args.
            TypeError: On argument type mismatch against annotations.
        """
        run_at, all_kwargs = validate_queue_call(self.signature, when, args, kwargs)
        now = datetime.now(tz=UTC)
        if self.cron:
            task_type = "recurring"
        elif when is None:
            task_type = "async"
        else:
            task_type = "run_at"
        task_doc = {
            "id": secrets.randbits(63),
            "key": key,
            "type": task_type,
            "function": self.function_path,
            "args": [],
            "kwargs": all_kwargs,
            "created_at": now.isoformat(),
            "run_at": run_at.isoformat(),
            "cron": self.cron or None,
        }

        TaskStore.persist(task_doc)
        return task_doc["id"]
