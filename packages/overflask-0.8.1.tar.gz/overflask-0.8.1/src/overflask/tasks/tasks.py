"""Public task decorator and management API."""

from collections.abc import Callable

from overflask.core.config import Config
from overflask.tasks.callable_registry import CallableRegistry
from overflask.tasks.callable_wrapper import CallableWrapper
from overflask.tasks.task_store import TaskStore
from overflask.tasks.validator import validate_annotations


def _register_callable(fn: Callable, cron: str) -> CallableWrapper:
    """Validate and register fn, returning its CallableWrapper. Deduplicates by identity."""
    validate_annotations(fn)

    existing_wrapper = next((w for w in CallableRegistry.registry if w.fn is fn), None)
    if existing_wrapper:
        wrapper = existing_wrapper
    else:
        wrapper = CallableWrapper(fn, cron)
        CallableRegistry.registry.append(wrapper)

    return wrapper


def async_task(fn: Callable) -> CallableWrapper:
    """Decorator to register an async task function."""
    return _register_callable(fn, '')


def recurring_task(cron: str) -> Callable[[Callable], CallableWrapper]:
    """Decorator factory to register a recurring task with a cron expression."""
    def decorator(fn: Callable) -> CallableWrapper:
        return _register_callable(fn, cron)
    return decorator


def delete(key: str) -> None:
    """Delete all tasks with the given key.

    In testing mode, removes matching entries from TaskStore.queued.
    """
    if Config.IS_TESTING:
        TaskStore.queued[:] = [t for t in TaskStore.queued if t.get("key") != key]
        return
    TaskStore.delete_by_key(key)
