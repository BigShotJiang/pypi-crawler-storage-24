"""TaskStore: task lifecycle operations against Elasticsearch."""

import secrets
import traceback
from datetime import UTC, datetime

from croniter import croniter

from overflask.core.config import Config
from overflask.es.elastic import get_es_client
from overflask.tasks.callable_registry import CallableRegistry
from overflask.tasks.es_index_templates import EsIndexTemplates


class TaskStore:
    """Task lifecycle operations: register, claim, dispatch, complete, fail, delete."""

    queued: list[dict] = []

    @staticmethod
    def persist(task_doc: dict) -> None:
        """Insert a task document into the current registered index."""
        if Config.IS_TESTING:
            TaskStore.queued.append(task_doc)
            return

        es = get_es_client()
        project = Config.PROJECT_NAME
        now = datetime.now(tz=UTC)
        es.index(
            index=EsIndexTemplates.registered_index(project, now),
            id=task_doc["id"],
            document=task_doc,
        )

    @staticmethod
    def sync_recurring() -> None:
        """Rebuild all recurring task instances in Registered from the in-memory registry.

        Deletes every existing recurring instance then re-inserts one per registry
        entry, computing run_at from the cron expression. Called on every scheduler
        startup so cron changes in code are always reflected.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME
        es.delete_by_query(
            index=f"{project}_tasks_registered-*",
            query={"term": {"type": "recurring"}},
            ignore_unavailable=True,
            refresh=True,
        )
        now = datetime.now(tz=UTC)
        for callable_wrapper in CallableRegistry.registry:
            if not callable_wrapper.cron:
                continue

            run_at = croniter(callable_wrapper.cron, now).get_next(datetime)
            TaskStore.persist({
                "id": secrets.randbits(63),
                "key": None,
                "type": "recurring",
                "function": callable_wrapper.function_path,
                "args": [],
                "kwargs": {},
                "created_at": now.isoformat(),
                "run_at": run_at.replace(tzinfo=UTC).isoformat(),
                "cron": callable_wrapper.cron,
            })

    @staticmethod
    def claim_batch(
        now: datetime, batch_id: int, batch_size: int = 50
    ) -> list[tuple[int, dict]]:
        """Claim a batch of due tasks from Registered for dispatch.

        Marks all due tasks (run_at <= now, no batch_id yet) with the given
        batch_id in a single update_by_query, then fetches them by batch_id
        sorted oldest-first.

        Returns a list of (task_id, task_doc) pairs in run_at ASC order.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME
        es.update_by_query(
            index=f"{project}_tasks_registered-*",
            ignore_unavailable=True,
            max_docs=batch_size,
            refresh=True,
            query={
                "bool": {
                    "filter": [{"range": {"run_at": {"lte": now.isoformat()}}}],
                    "must_not": [{"exists": {"field": "batch_id"}}],
                }
            },
            script={
                "source": "ctx._source.batch_id = params.batch_id",
                "params": {"batch_id": batch_id},
            },
        )
        resp = es.search(
            index=f"{project}_tasks_registered-*",
            ignore_unavailable=True,
            size=batch_size,
            sort=[{"run_at": "asc"}],
            query={"term": {"batch_id": batch_id}},
        )
        return [(hit["_source"]["id"], hit["_source"]) for hit in resp["hits"]["hits"]]

    @staticmethod
    def move_to_dispatched(task_id: int, task_doc: dict) -> None:
        """Move a task from Registered to Dispatched.

        Inserts into the dispatched index first (doc always exists somewhere),
        then removes from registered.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME
        now = datetime.now(tz=UTC)
        es.index(
            index=EsIndexTemplates.dispatched_index(project, now),
            id=task_id,
            document={**task_doc, "dispatched_at": now.isoformat()},
            refresh=True,
        )
        es.delete_by_query(
            index=f"{project}_tasks_registered-*",
            query={"term": {"id": task_id}},
            ignore_unavailable=True,
            conflicts="proceed",
            refresh=True,
        )

    @staticmethod
    def mark_completed(task_id: int) -> None:
        """Move a task from Dispatched to Completed."""
        es = get_es_client()
        project = Config.PROJECT_NAME
        resp = es.search(
            index=f"{project}_tasks_dispatched-*",
            query={"term": {"id": task_id}},
            ignore_unavailable=True,
            size=1,
        )
        hits = resp["hits"]["hits"]
        if not hits:
            return
        hit = hits[0]
        now = datetime.now(tz=UTC)
        es.index(
            index=EsIndexTemplates.completed_index(project, now),
            id=task_id,
            document={**hit["_source"], "completed_at": now.isoformat()},
        )
        es.delete(index=hit["_index"], id=hit["_id"])

    @staticmethod
    def record_failure(task_id: int, exc: BaseException) -> None:
        """Write failure details onto the Dispatched document for a failed task.

        The task remains in Dispatched (at-most-once — no retry).
        Must be called from within an except block so traceback.format_exc()
        captures the active exception.
        """
        es = get_es_client()
        project = Config.PROJECT_NAME
        resp = es.search(
            index=f"{project}_tasks_dispatched-*",
            query={"term": {"id": task_id}},
            ignore_unavailable=True,
            size=1,
        )
        hits = resp["hits"]["hits"]
        if not hits:
            return
        hit = hits[0]
        es.update(
            index=hit["_index"],
            id=hit["_id"],
            doc={
                "failed_at": datetime.now(tz=UTC).isoformat(),
                "error": str(exc),
                "error_traceback": traceback.format_exc(),
            },
        )

    @staticmethod
    def delete_by_key(key: str) -> None:
        """Delete all tasks with the given key from all three lifecycle indices."""
        es = get_es_client()
        project = Config.PROJECT_NAME
        for pattern in (
            f"{project}_tasks_registered-*",
            f"{project}_tasks_dispatched-*",
            f"{project}_tasks_completed-*",
        ):
            es.delete_by_query(
                index=pattern,
                query={"term": {"key": key}},
                ignore_unavailable=True,
            )

    @staticmethod
    def get_dispatched(task_id: int) -> dict | None:
        """Fetch a task document from the Dispatched index by task ID."""
        es = get_es_client()
        project = Config.PROJECT_NAME
        resp = es.search(
            index=f"{project}_tasks_dispatched-*",
            query={"term": {"id": task_id}},
            ignore_unavailable=True,
            size=1,
        )
        hits = resp["hits"]["hits"]
        return hits[0]["_source"] if hits else None
