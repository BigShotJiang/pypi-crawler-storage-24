"""Tests for component discovery."""

import importlib
import pkgutil
import types
from unittest.mock import MagicMock, patch

import pytest

from overflask.core.config import Config
from overflask.core.discovery import DiscoveredModules, _import_module_or_package, discover


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def components(request):
    """Set Config.COMPONENTS for a test and restore the original afterwards."""
    value = getattr(request, 'param', [])
    # Access the raw class dict to save the original (bypasses descriptor __get__)
    original = Config.__dict__.get('COMPONENTS')
    Config.COMPONENTS = value
    yield value
    Config.COMPONENTS = original


# ---------------------------------------------------------------------------
# TestDiscoveredModules
# ---------------------------------------------------------------------------

class TestDiscoveredModules:
    def test_default_fields_are_empty_lists(self):
        dm = DiscoveredModules()
        assert dm.models == []
        assert dm.views == []
        assert dm.tasks == []
        assert dm.cli == []

    def test_fields_are_independent_lists(self):
        dm = DiscoveredModules()
        dm.models.append(types.ModuleType('m'))
        assert dm.views == []

    def test_accepts_module_list_in_constructor(self):
        m = types.ModuleType('mymod')
        dm = DiscoveredModules(models=[m])
        assert dm.models == [m]


# ---------------------------------------------------------------------------
# TestImportModuleOrPackage
# ---------------------------------------------------------------------------

class TestImportModuleOrPackage:
    def test_imports_simple_module(self):
        fake = types.ModuleType('fake_module')
        target = []
        with patch('importlib.import_module', return_value=fake) as mock_import:
            _import_module_or_package('fake_module', target)
        assert fake in target
        mock_import.assert_called_once_with('fake_module')

    def test_appends_to_target_list(self):
        existing = types.ModuleType('existing')
        new_mod = types.ModuleType('new_mod')
        target = [existing]
        with patch('importlib.import_module', return_value=new_mod):
            _import_module_or_package('new_mod', target)
        assert existing in target
        assert new_mod in target
        assert len(target) == 2

    def test_silently_ignores_missing_module(self):
        target = []
        with patch('importlib.import_module', side_effect=ModuleNotFoundError):
            _import_module_or_package('does.not.exist', target)
        assert target == []

    def test_imports_package_and_submodules(self):
        pkg = types.ModuleType('mypkg')
        pkg.__path__ = ['/fake/path']
        submod = types.ModuleType('mypkg.sub')

        def fake_import(name):
            if name == 'mypkg':
                return pkg
            if name == 'mypkg.sub':
                return submod
            raise ModuleNotFoundError(name)

        # Patch pkgutil.iter_modules before import_module to avoid interception
        target = []
        with patch.object(pkgutil, 'iter_modules', return_value=[(None, 'sub', False)]):
            with patch('importlib.import_module', side_effect=fake_import):
                _import_module_or_package('mypkg', target)

        assert pkg in target
        assert submod in target

    def test_skips_private_submodules(self):
        pkg = types.ModuleType('mypkg')
        pkg.__path__ = ['/fake/path']
        target = []

        with patch.object(pkgutil, 'iter_modules', return_value=[(None, '_private', False)]):
            with patch('importlib.import_module', return_value=pkg):
                _import_module_or_package('mypkg', target)

        assert len(target) == 1  # only pkg, not _private
        assert target[0] is pkg

    def test_simple_module_not_treated_as_package(self):
        mod = types.ModuleType('simple')
        # No __path__ attribute — not a package
        target = []
        mock_iter = MagicMock()
        with patch.object(pkgutil, 'iter_modules', mock_iter):
            with patch('importlib.import_module', return_value=mod):
                _import_module_or_package('simple', target)
        mock_iter.assert_not_called()
        assert target == [mod]


# ---------------------------------------------------------------------------
# TestDiscover
# ---------------------------------------------------------------------------

class TestDiscover:
    @pytest.mark.usefixtures('components')
    def test_empty_components_returns_empty_modules(self):
        result = discover()
        assert result.models == []
        assert result.views == []
        assert result.tasks == []
        assert result.cli == []

    def test_imports_all_module_types_for_component(self):
        modules = {
            'components.myapp.models': types.ModuleType('components.myapp.models'),
            'components.myapp.views': types.ModuleType('components.myapp.views'),
            'components.myapp.tasks': types.ModuleType('components.myapp.tasks'),
            'components.myapp.cli': types.ModuleType('components.myapp.cli'),
        }

        def fake_import(name):
            if name in modules:
                return modules[name]
            raise ModuleNotFoundError(name)

        original = Config.__dict__.get('COMPONENTS')
        Config.COMPONENTS = ['myapp']
        try:
            with patch('importlib.import_module', side_effect=fake_import):
                result = discover()
        finally:
            Config.COMPONENTS = original

        assert modules['components.myapp.models'] in result.models
        assert modules['components.myapp.views'] in result.views
        assert modules['components.myapp.tasks'] in result.tasks
        assert modules['components.myapp.cli'] in result.cli

    def test_missing_modules_are_silently_skipped(self):
        original = Config.__dict__.get('COMPONENTS')
        Config.COMPONENTS = ['nocomp']
        try:
            with patch('importlib.import_module', side_effect=ModuleNotFoundError):
                result = discover()
        finally:
            Config.COMPONENTS = original

        assert result.models == []
        assert result.views == []

    def test_multiple_components_aggregated(self):
        mod_a = types.ModuleType('components.alpha.views')
        mod_b = types.ModuleType('components.beta.views')

        def fake_import(name):
            mapping = {
                'components.alpha.views': mod_a,
                'components.beta.views': mod_b,
            }
            if name in mapping:
                return mapping[name]
            raise ModuleNotFoundError(name)

        original = Config.__dict__.get('COMPONENTS')
        Config.COMPONENTS = ['alpha', 'beta']
        try:
            with patch('importlib.import_module', side_effect=fake_import):
                result = discover()
        finally:
            Config.COMPONENTS = original

        assert mod_a in result.views
        assert mod_b in result.views
