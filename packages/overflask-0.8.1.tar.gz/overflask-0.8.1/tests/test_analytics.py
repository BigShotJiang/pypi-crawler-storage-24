"""Tests for the overflask analytics system."""

from datetime import UTC, datetime, timezone
from unittest.mock import MagicMock, patch

import pytest
from flask import Flask

from overflask.analytics.events import AnalyticsEvents

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def app():
    """Flask app in testing mode."""
    flask_app = Flask(__name__)
    flask_app.config.update({
        "TESTING": True,
        "PROJECT_NAME": "testproject",
        "ELASTICSEARCH_URL": "http://localhost:9200",
        "ELASTICSEARCH_USERNAME": "",
        "ELASTICSEARCH_PASSWORD": "",
        "ANALYTICS_ENVIRONMENT": "test",
        "ANALYTICS_RETENTION_DAYS": 365,
        "ANALYTICS_FLUSH_INTERVAL_SECONDS": 5,
        "ANALYTICS_FLUSH_BATCH_SIZE": 500,
    })
    return flask_app


@pytest.fixture
def app_ctx(app):
    """Active Flask application context (TESTING=True)."""
    with app.app_context():
        yield app


@pytest.fixture
def prod_app():
    """Flask app with TESTING=False."""
    flask_app = Flask(__name__)
    flask_app.config.update({
        "TESTING": False,
        "PROJECT_NAME": "testproject",
        "ELASTICSEARCH_URL": "http://localhost:9200",
        "ELASTICSEARCH_USERNAME": "",
        "ELASTICSEARCH_PASSWORD": "",
        "ANALYTICS_ENVIRONMENT": "production",
        "ANALYTICS_RETENTION_DAYS": 365,
        "ANALYTICS_FLUSH_INTERVAL_SECONDS": 5,
        "ANALYTICS_FLUSH_BATCH_SIZE": 500,
    })
    return flask_app


@pytest.fixture
def prod_ctx(prod_app):
    """Active Flask application context (TESTING=False)."""
    with prod_app.app_context():
        yield prod_app


@pytest.fixture
def mock_es():
    """Mock ES client patched into analytics modules."""
    es = MagicMock()
    with (
        patch("overflask.analytics.es_index_templates.get_es_client", return_value=es),
        patch("overflask.analytics.flusher.get_es_client", return_value=es),
        patch("overflask.analytics.purge.get_es_client", return_value=es),
    ):
        yield es


@pytest.fixture(autouse=True)
def _reset_analytics():
    """Isolate analytics state across tests."""
    from overflask.analytics.events import AnalyticsEvents
    from overflask.analytics.flusher import AnalyticsFlusher
    AnalyticsEvents.buffer.clear()
    AnalyticsFlusher._flusher_started = False
    yield
    AnalyticsEvents.buffer.clear()
    AnalyticsFlusher._flusher_started = False


@pytest.fixture(autouse=True)
def _set_config():
    """Set Config class attributes required by analytics modules and restore after each test."""
    from overflask.core.config import Config

    saved = {k: Config.__dict__[k] for k in (
        'PROJECT_NAME', 'ANALYTICS_ENVIRONMENT', 'IS_TESTING',
        'ANALYTICS_FLUSH_INTERVAL_SECONDS', 'ANALYTICS_FLUSH_BATCH_SIZE',
        'ANALYTICS_RETENTION_DAYS', 'ELASTICSEARCH_URL',
        'ELASTICSEARCH_USERNAME', 'ELASTICSEARCH_PASSWORD',
    )}

    Config.PROJECT_NAME = 'testproject'
    Config.ANALYTICS_ENVIRONMENT = 'test'
    Config.IS_TESTING = True
    Config.ANALYTICS_FLUSH_INTERVAL_SECONDS = 5
    Config.ANALYTICS_FLUSH_BATCH_SIZE = 500
    Config.ANALYTICS_RETENTION_DAYS = 365
    Config.ELASTICSEARCH_URL = 'http://localhost:9200'
    Config.ELASTICSEARCH_USERNAME = ''
    Config.ELASTICSEARCH_PASSWORD = ''

    yield

    for k, v in saved.items():
        setattr(Config, k, v)


# ---------------------------------------------------------------------------
# TestAnalyticsTestingMode
# ---------------------------------------------------------------------------

class TestAnalyticsTestingMode:

    def test_record_appends_to_recorded_in_test_mode(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("user.registered", area="auth", plan="free")

        assert len(AnalyticsEvents.buffer) == 1

    def test_record_does_not_start_flusher_in_test_mode(self, app_ctx):
        from overflask.analytics.analytics import Analytics
        from overflask.analytics.flusher import AnalyticsFlusher

        Analytics.record("user.registered", area="auth")

        assert not AnalyticsFlusher._flusher_started

    def test_multiple_events_accumulate_in_recorded(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("user.registered", area="auth")
        Analytics.record("user.login", area="auth")
        Analytics.record("purchase.completed", area="billing", amount=99)

        assert len(AnalyticsEvents.buffer) == 3

    def test_recorded_list_cleared_between_tests(self, app_ctx):
        """Relies on autouse _reset_analytics fixture."""
        from overflask.analytics.analytics import Analytics

        assert len(AnalyticsEvents.buffer) == 0


# ---------------------------------------------------------------------------
# TestAnalyticsEnvelope
# ---------------------------------------------------------------------------

class TestAnalyticsEnvelope:

    def test_envelope_has_required_fields(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("user.registered", area="auth", plan="free")

        doc = AnalyticsEvents.buffer[0]
        assert doc["event"] == "user.registered"
        assert doc["project"] == "testproject"
        assert doc["environment"] == "test"
        assert doc["area"] == "auth"
        assert "timestamp" in doc
        assert "data" in doc

    def test_data_contains_kwargs(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("user.registered", area="auth", plan="free", source="organic")

        doc = AnalyticsEvents.buffer[0]
        assert doc["data"] == {"plan": "free", "source": "organic"}

    def test_data_is_empty_dict_when_no_kwargs(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("page.viewed", area="web")

        doc = AnalyticsEvents.buffer[0]
        assert doc["data"] == {}

    def test_timestamp_is_iso_format_with_timezone(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        dt = datetime.fromisoformat(doc["timestamp"])
        assert dt.tzinfo is not None

    def test_no_context_outside_request(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("batch.processed", area="jobs")

        doc = AnalyticsEvents.buffer[0]
        assert "context" not in doc

    def test_context_enriched_inside_request(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        with app_ctx.test_request_context("/api/register", method="POST"):
            Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        assert "context" in doc
        assert doc["context"]["http_method"] == "POST"
        assert doc["context"]["http_path"] == "/api/register"

    def test_context_request_id_from_header(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        with app_ctx.test_request_context(
            "/api/register", headers={"X-Request-ID": "abc123"}
        ):
            Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        assert doc["context"]["request_id"] == "abc123"

    def test_context_request_id_from_g(self, app_ctx):
        from flask import g

        from overflask.analytics.analytics import Analytics

        with app_ctx.test_request_context("/api/register"):
            g.request_id = "g-id-xyz"
            Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        assert doc["context"]["request_id"] == "g-id-xyz"

    def test_context_user_id_from_g(self, app_ctx):
        from flask import g

        from overflask.analytics.analytics import Analytics

        with app_ctx.test_request_context("/api/register"):
            g.user_id = 42
            Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        assert doc["context"]["user_id"] == "42"

    def test_context_user_id_omitted_when_not_set(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        with app_ctx.test_request_context("/api/register"):
            Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        assert "user_id" not in doc.get("context", {})

    def test_context_request_id_omitted_when_not_set(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        with app_ctx.test_request_context("/api/register"):
            Analytics.record("user.registered", area="auth")

        doc = AnalyticsEvents.buffer[0]
        assert "request_id" not in doc.get("context", {})


# ---------------------------------------------------------------------------
# TestAreaNormalization
# ---------------------------------------------------------------------------

class TestAreaNormalization:

    def test_area_is_lowercased(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("event", area="Auth")

        assert AnalyticsEvents.buffer[0]["area"] == "auth"

    def test_area_spaces_replaced_with_underscores(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("event", area="user auth")

        assert AnalyticsEvents.buffer[0]["area"] == "user_auth"

    def test_area_hyphens_replaced_with_underscores(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("event", area="user-auth")

        assert AnalyticsEvents.buffer[0]["area"] == "user_auth"

    def test_area_multiple_special_chars_collapsed(self, app_ctx):
        from overflask.analytics.analytics import Analytics

        Analytics.record("event", area="user--auth!!!")

        assert AnalyticsEvents.buffer[0]["area"] == "user_auth"


# ---------------------------------------------------------------------------
# TestAnalyticsBuffering
# ---------------------------------------------------------------------------

class TestAnalyticsBuffering:

    def test_record_appends_to_buffer_in_prod_mode(self, prod_ctx):
        from overflask.analytics.analytics import Analytics
        from overflask.analytics.events import AnalyticsEvents

        with patch("overflask.analytics.analytics.AnalyticsFlusher.ensure"):
            Analytics.record("user.registered", area="auth")

        assert len(AnalyticsEvents.buffer) == 1

    def test_record_starts_flusher_in_prod_mode(self, prod_ctx):
        from overflask.analytics.analytics import Analytics
        from overflask.analytics.flusher import AnalyticsFlusher

        with patch.object(AnalyticsFlusher, "ensure") as mock_ensure:
            Analytics.record("user.registered", area="auth")

        mock_ensure.assert_called_once()


# ---------------------------------------------------------------------------
# TestAnalyticsFlusher
# ---------------------------------------------------------------------------

class TestAnalyticsFlusher:

    def test_flush_now_writes_buffered_events(self, prod_ctx, mock_es):
        from overflask.analytics.events import AnalyticsEvents
        from overflask.analytics.flusher import AnalyticsFlusher

        AnalyticsEvents.buffer.append({
            "event": "test.event",
            "project": "testproject",
            "area": "auth",
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "data": {},
        })

        count = AnalyticsFlusher.flush_now()

        assert count == 1
        mock_es.bulk.assert_called_once()

    def test_flush_drains_buffer(self, prod_ctx, mock_es):
        from overflask.analytics.events import AnalyticsEvents
        from overflask.analytics.flusher import AnalyticsFlusher

        for i in range(3):
            AnalyticsEvents.buffer.append({
                "event": f"event.{i}",
                "project": "testproject",
                "area": "auth",
                "timestamp": datetime.now(tz=UTC).isoformat(),
                "data": {},
            })

        AnalyticsFlusher.flush_now()

        assert len(AnalyticsEvents.buffer) == 0

    def test_flush_returns_zero_when_buffer_empty(self, prod_ctx, mock_es):
        from overflask.analytics.flusher import AnalyticsFlusher

        count = AnalyticsFlusher.flush_now()

        assert count == 0
        mock_es.bulk.assert_not_called()

    def test_flush_respects_batch_size(self, prod_ctx, mock_es):
        from overflask.analytics.events import AnalyticsEvents
        from overflask.analytics.flusher import AnalyticsFlusher
        from overflask.core.config import Config

        Config.ANALYTICS_FLUSH_BATCH_SIZE = 2

        for i in range(5):
            AnalyticsEvents.buffer.append({
                "event": f"event.{i}",
                "project": "testproject",
                "area": "auth",
                "timestamp": datetime.now(tz=UTC).isoformat(),
                "data": {},
            })

        count = AnalyticsFlusher.flush_now()

        assert count == 2
        assert len(AnalyticsEvents.buffer) == 3

    def test_flush_requeues_on_es_error(self, prod_ctx, mock_es):
        from overflask.analytics.events import AnalyticsEvents
        from overflask.analytics.flusher import AnalyticsFlusher

        mock_es.bulk.side_effect = Exception("ES unavailable")

        AnalyticsEvents.buffer.append({
            "event": "test.event",
            "project": "testproject",
            "area": "auth",
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "data": {},
        })

        count = AnalyticsFlusher.flush_now()

        assert count == 0
        assert len(AnalyticsEvents.buffer) == 1

    def test_flush_bulk_payload_has_correct_index_and_doc(self, prod_ctx, mock_es):
        from overflask.analytics.events import AnalyticsEvents
        from overflask.analytics.flusher import AnalyticsFlusher

        doc = {
            "event": "user.registered",
            "project": "testproject",
            "area": "auth",
            "timestamp": "2026-03-02T14:00:00+00:00",
            "data": {"plan": "free"},
        }
        AnalyticsEvents.buffer.append(doc)

        with patch("overflask.analytics.flusher.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 3, 2, tzinfo=UTC)
            AnalyticsFlusher.flush_now()

        ops = mock_es.bulk.call_args.kwargs["operations"]
        assert ops[0] == {"index": {"_index": "testproject_analytics_auth-2026.03"}}
        assert ops[1] == doc


# ---------------------------------------------------------------------------
# TestAnalyticsEsIndexTemplates
# ---------------------------------------------------------------------------

class TestAnalyticsEsIndexTemplates:

    def test_analytics_index_name_format(self, prod_ctx, mock_es):
        from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates

        dt = datetime(2026, 3, 15, tzinfo=UTC)
        name = AnalyticsEsIndexTemplates.analytics_index("myapp", "auth", dt)

        assert name == "myapp_analytics_auth-2026.03"

    def test_ensure_puts_one_index_template(self, prod_ctx, mock_es):
        from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates

        AnalyticsEsIndexTemplates.ensure()

        mock_es.indices.put_index_template.assert_called_once()

    def test_ensure_uses_wildcard_pattern(self, prod_ctx, mock_es):
        from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates

        AnalyticsEsIndexTemplates.ensure()

        call_kwargs = mock_es.indices.put_index_template.call_args.kwargs
        assert call_kwargs["index_patterns"] == ["testproject_analytics_*-*"]

    def test_ensure_template_has_explicit_envelope_mappings(self, prod_ctx, mock_es):
        from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates

        AnalyticsEsIndexTemplates.ensure()

        props = mock_es.indices.put_index_template.call_args.kwargs["template"]["mappings"]["properties"]
        assert props["event"] == {"type": "keyword"}
        assert props["timestamp"] == {"type": "date"}
        assert props["area"] == {"type": "keyword"}
        assert props["environment"] == {"type": "keyword"}

    def test_ensure_data_field_is_dynamic(self, prod_ctx, mock_es):
        from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates

        AnalyticsEsIndexTemplates.ensure()

        props = mock_es.indices.put_index_template.call_args.kwargs["template"]["mappings"]["properties"]
        assert props["data"]["type"] == "object"
        assert props["data"]["dynamic"] is True

    def test_ensure_context_has_keyword_subfields(self, prod_ctx, mock_es):
        from overflask.analytics.es_index_templates import AnalyticsEsIndexTemplates

        AnalyticsEsIndexTemplates.ensure()

        props = mock_es.indices.put_index_template.call_args.kwargs["template"]["mappings"]["properties"]
        ctx = props["context"]["properties"]
        assert ctx["request_id"] == {"type": "keyword"}
        assert ctx["http_method"] == {"type": "keyword"}
        assert ctx["http_path"] == {"type": "keyword"}
        assert ctx["user_id"] == {"type": "keyword"}


# ---------------------------------------------------------------------------
# TestAnalyticsPurge
# ---------------------------------------------------------------------------

class TestAnalyticsPurge:

    def test_purge_deletes_old_indices_leaves_recent(self, prod_ctx, mock_es):
        from overflask.analytics.purge import AnalyticsPurge

        # ANALYTICS_RETENTION_DAYS=365; today≈2026-03-02 → cutoff≈2025-03-02.
        # Jan 2025 and Jan 2020 are before the cutoff; Apr 2025 is after.
        mock_es.indices.get.return_value = {
            "testproject_analytics_auth-2020.01": {},
            "testproject_analytics_auth-2025.01": {},
            "testproject_analytics_auth-2025.04": {},
            "testproject_analytics_auth-2026.03": {},
        }

        AnalyticsPurge.purge_old()

        deleted = [c.kwargs["index"] for c in mock_es.indices.delete.call_args_list]
        assert "testproject_analytics_auth-2020.01" in deleted
        assert "testproject_analytics_auth-2025.01" in deleted
        assert "testproject_analytics_auth-2025.04" not in deleted
        assert "testproject_analytics_auth-2026.03" not in deleted

    def test_purge_skips_malformed_index_names(self, prod_ctx, mock_es):
        from overflask.analytics.purge import AnalyticsPurge

        mock_es.indices.get.return_value = {
            "testproject_analytics_auth-notadate": {},
        }

        AnalyticsPurge.purge_old()

        mock_es.indices.delete.assert_not_called()

    def test_purge_handles_es_list_error_gracefully(self, prod_ctx, mock_es):
        from overflask.analytics.purge import AnalyticsPurge

        mock_es.indices.get.side_effect = Exception("ES down")

        # Should not raise
        AnalyticsPurge.purge_old()

        mock_es.indices.delete.assert_not_called()

    def test_purge_queries_correct_index_pattern(self, prod_ctx, mock_es):
        from overflask.analytics.purge import AnalyticsPurge

        mock_es.indices.get.return_value = {}

        AnalyticsPurge.purge_old()

        call_kwargs = mock_es.indices.get.call_args.kwargs
        assert call_kwargs["index"] == "testproject_analytics_*-*"


# ---------------------------------------------------------------------------
# TestSchedulerWiring
# ---------------------------------------------------------------------------

class TestSchedulerWiring:

    def test_startup_calls_analytics_ensure(self, app_ctx):
        from overflask.tasks import scheduler

        with (
            patch("overflask.tasks.scheduler.EsIndexTemplates.ensure"),
            patch("overflask.tasks.scheduler.AnalyticsEsIndexTemplates.ensure") as mock_ensure,
            patch("overflask.tasks.scheduler.TaskStore.sync_recurring"),
            patch("overflask.tasks.scheduler.is_provisioned", return_value=True),
        ):
            scheduler._startup()

        mock_ensure.assert_called_once()

    def test_purge_block_calls_analytics_purge(self, app_ctx):
        from overflask.tasks import scheduler

        mock_redis = MagicMock()

        with (
            patch("overflask.tasks.scheduler.TaskStore.claim_batch", return_value=[]),
            patch("overflask.tasks.scheduler.get_redis", return_value=mock_redis),
            patch("overflask.tasks.scheduler.Metrics.record"),
            patch("overflask.tasks.scheduler.Metrics.purge_old"),
            patch("overflask.tasks.scheduler.AnalyticsPurge.purge_old") as mock_purge,
            patch("overflask.tasks.scheduler.time.monotonic", side_effect=[0, 0, 86401]),
            patch("overflask.tasks.scheduler.time.sleep", side_effect=KeyboardInterrupt),
        ):
            with pytest.raises(KeyboardInterrupt):
                scheduler._loop()

        mock_purge.assert_called_once()
