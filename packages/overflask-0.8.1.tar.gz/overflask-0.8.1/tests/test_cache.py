"""Tests for the cached decorator and cache key helpers."""

import json
from datetime import timedelta
from unittest.mock import MagicMock, call, patch

import pytest

from overflask.redis.cache import CachePopulationTimeoutError, cached


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_redis(cached_value=None, lock_acquired=True):
    """Return a mock Redis client pre-configured for a cache-miss scenario."""
    r = MagicMock()
    r.get.return_value = cached_value
    r.set.return_value = lock_acquired
    r.scan.return_value = (0, [])
    return r


# ---------------------------------------------------------------------------
# TestBuildCacheKey
# ---------------------------------------------------------------------------

class TestBuildCacheKey:
    def test_no_args_returns_base_key(self):
        c = cached(ttl=timedelta(minutes=1), key='mykey')
        assert c._build_cache_key() == 'mykey'

    def test_single_arg_appended(self):
        c = cached(ttl=timedelta(minutes=1), key='fn')
        assert c._build_cache_key(x=5) == 'fn:x=5'

    def test_args_are_sorted(self):
        c = cached(ttl=timedelta(minutes=1), key='fn')
        assert c._build_cache_key(b=2, a=1) == 'fn:a=1:b=2'

    def test_multiple_args_joined_by_colon(self):
        c = cached(ttl=timedelta(minutes=1), key='fn')
        key = c._build_cache_key(user_id=1, include_details=False)
        assert key.startswith('fn:')
        assert 'user_id=1' in key
        assert 'include_details=False' in key


# ---------------------------------------------------------------------------
# TestBuildLockKey
# ---------------------------------------------------------------------------

class TestBuildLockKey:
    def test_prepends_lock_prefix(self):
        c = cached(ttl=timedelta(minutes=1), key='mykey')
        assert c._build_lock_key('mykey:x=1') == '_lock:mykey:x=1'

    def test_base_key_gets_lock_prefix(self):
        c = cached(ttl=timedelta(minutes=1), key='mykey')
        assert c._build_lock_key('mykey') == '_lock:mykey'


# ---------------------------------------------------------------------------
# TestCachedDecorator
# ---------------------------------------------------------------------------

class TestCachedDecorator:
    def test_returns_function_result_on_cache_miss(self):
        r = make_redis(cached_value=None, lock_acquired=True)
        r.get.side_effect = [None, '9999']  # cache miss, then lock check succeeds

        with patch('overflask.redis.cache.get_redis', return_value=r):
            with patch('overflask.redis.cache.random.randint', return_value=9999):
                @cached(ttl=timedelta(minutes=5))
                def double(x):
                    return x * 2

                result = double(5)

        assert result == 10

    def test_returns_cached_value_on_cache_hit(self):
        r = make_redis(cached_value=json.dumps(42))

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=5))
            def double(x):
                raise AssertionError('should not be called on cache hit')

            result = double(5)

        assert result == 42

    def test_stores_result_in_cache_after_computation(self):
        r = MagicMock()
        r.get.side_effect = [None, '1234']  # cache miss, then lock owned
        r.set.return_value = True           # lock acquired
        r.scan.return_value = (0, [])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            with patch('overflask.redis.cache.random.randint', return_value=1234):
                @cached(ttl=timedelta(minutes=5))
                def triple(x):
                    return x * 3

                result = triple(4)

        assert result == 12
        # Verify we stored the result: r.set called with json-encoded value and ex kwarg
        store_calls = [c for c in r.set.call_args_list if c.kwargs.get('ex') and not c.kwargs.get('nx')]
        assert len(store_calls) == 1
        assert json.loads(store_calls[0].args[1]) == 12

    def test_function_name_used_as_default_key(self):
        r = make_redis(cached_value=None, lock_acquired=True)
        r.get.side_effect = [None, '0']

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=1))
            def my_function():
                return 'result'

            my_function()

        first_get_key = r.get.call_args_list[0].args[0]
        assert first_get_key == 'my_function'

    def test_custom_key_overrides_function_name(self):
        r = make_redis(cached_value=None, lock_acquired=True)
        r.get.side_effect = [None, '0']

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=1), key='custom_key')
            def my_function():
                return 'result'

            my_function()

        first_get_key = r.get.call_args_list[0].args[0]
        assert first_get_key == 'custom_key'

    def test_positional_args_mapped_to_kwargs_for_cache_key(self):
        r = make_redis(cached_value=None, lock_acquired=True)
        r.get.side_effect = [None, '0']

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=1), key='fn')
            def get_profile(user_id, include_details):
                return {'id': user_id}

            get_profile(42, False)

        # Cache key should include user_id and include_details
        first_get_key = r.get.call_args_list[0].args[0]
        assert 'user_id=42' in first_get_key
        assert 'include_details=False' in first_get_key

    def test_preserves_wrapped_function_metadata(self):
        @cached(ttl=timedelta(minutes=1))
        def documented_function():
            """My docstring."""
            return 'result'

        assert documented_function.__name__ == 'documented_function'
        assert documented_function.__doc__ == 'My docstring.'

    def test_raises_cache_population_timeout_when_lock_held(self):
        r = MagicMock()
        r.get.return_value = None   # always cache miss
        r.set.return_value = False  # lock never acquired
        r.scan.return_value = (0, [])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            with patch('overflask.redis.cache.time.sleep'):
                @cached(ttl=timedelta(minutes=5))
                def slow_fn(x):
                    return x

                with pytest.raises(CachePopulationTimeoutError, match='slow_fn'):
                    slow_fn(1)

    def test_ttl_applied_to_cached_value(self):
        r = MagicMock()
        r.get.side_effect = [None, '42']  # cache miss, then lock owned (matches randint mock)
        r.set.return_value = True
        r.scan.return_value = (0, [])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            with patch('overflask.redis.cache.random.randint', return_value=42):
                @cached(ttl=timedelta(minutes=2))
                def fn():
                    return 'val'

                fn()

        store_calls = [c for c in r.set.call_args_list if c.kwargs.get('ex') and not c.kwargs.get('nx')]
        assert len(store_calls) == 1
        assert store_calls[0].kwargs['ex'] == 120  # 2 minutes in seconds


# ---------------------------------------------------------------------------
# TestClearCache
# ---------------------------------------------------------------------------

class TestClearCache:
    def test_clear_cache_deletes_specific_key(self):
        r = MagicMock()

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=5))
            def get_data(user_id):
                return user_id

            get_data.clear_cache(user_id=1)

        r.delete.assert_called_once()
        deleted_key = r.delete.call_args.args[0]
        assert 'user_id=1' in deleted_key

    def test_clear_all_caches_deletes_all_keys(self):
        r = MagicMock()
        r.scan.return_value = (0, [b'get_data:user_id=1', b'get_data:user_id=2'])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=5))
            def get_data(user_id):
                return user_id

            get_data.clear_all_caches()

        r.delete.assert_called()

    def test_clear_all_caches_also_deletes_base_key(self):
        r = MagicMock()
        r.scan.return_value = (0, [])  # no pattern matches

        with patch('overflask.redis.cache.get_redis', return_value=r):
            @cached(ttl=timedelta(minutes=5), key='mykey')
            def fn():
                return 'val'

            fn.clear_all_caches()

        # Should delete the base key even when scan finds nothing
        deleted_args = [c.args[0] for c in r.delete.call_args_list]
        assert 'mykey' in deleted_args


# ---------------------------------------------------------------------------
# TestCachedClearStatic
# ---------------------------------------------------------------------------

class TestCachedClearStatic:
    def test_clear_static_deletes_all_matching_keys(self):
        r = MagicMock()
        r.scan.return_value = (0, [b'mykey:a=1', b'mykey:b=2'])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            cached.clear('mykey')

        r.delete.assert_called()

    def test_clear_static_also_deletes_base_key(self):
        r = MagicMock()
        r.scan.return_value = (0, [])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            cached.clear('somekey')

        deleted_args = [c.args[0] for c in r.delete.call_args_list]
        assert 'somekey' in deleted_args

    def test_clear_static_scans_with_wildcard_pattern(self):
        r = MagicMock()
        r.scan.return_value = (0, [])

        with patch('overflask.redis.cache.get_redis', return_value=r):
            cached.clear('mykey')

        scan_pattern = r.scan.call_args.kwargs.get('match') or r.scan.call_args.args[1]
        assert 'mykey' in scan_pattern
        assert '*' in scan_pattern
