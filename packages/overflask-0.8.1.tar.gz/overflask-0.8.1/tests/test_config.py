"""Tests for Config internals — _get, _require, _optional, and Config classmethods."""

import warnings
from contextlib import contextmanager
from pathlib import Path

import pytest
from flask import Flask
from packaging.version import Version

from overflask.core.config import Config, _get, _optional, _require
from overflask.core.config_value import ConfigValue


@contextmanager
def config_attrs(**kwargs):
    """Temporarily set Config class attributes, safely bypassing ConfigValue descriptors."""
    originals = {k: Config.__dict__.get(k) for k in kwargs}
    for k, v in kwargs.items():
        Config.__dict__  # noqa: B018 — referenced just to confirm access
        type.__setattr__(Config, k, v)
    try:
        yield
    finally:
        for k, v in originals.items():
            type.__setattr__(Config, k, v)


# ---------------------------------------------------------------------------
# TestConfigValue
# ---------------------------------------------------------------------------

class TestConfigValue:
    def test_get_raises_before_load(self):
        class Holder:
            VALUE: ConfigValue[str] = ConfigValue()

        with pytest.raises(RuntimeError, match='not yet loaded'):
            _ = Holder.VALUE

    def test_set_on_instance_raises(self):
        class Holder:
            VALUE: ConfigValue[str] = ConfigValue()

        with pytest.raises(AttributeError, match='cannot be set on an instance'):
            Holder().VALUE = 'foo'

    def test_error_message_includes_attribute_name(self):
        class Holder:
            MY_KEY: ConfigValue[str] = ConfigValue()

        with pytest.raises(RuntimeError, match='Config.MY_KEY'):
            _ = Holder.MY_KEY

    def test_set_name_is_recorded(self):
        class Holder:
            MY_KEY: ConfigValue[str] = ConfigValue()

        assert Holder.__dict__['MY_KEY'].name == 'MY_KEY'


# ---------------------------------------------------------------------------
# TestGet
# ---------------------------------------------------------------------------

class TestGet:
    def test_reads_from_flask_config(self):
        app = Flask('test')
        app.config['MYKEY'] = 'from_flask'
        assert _get(app, 'MYKEY') == 'from_flask'

    def test_falls_back_to_env(self, monkeypatch):
        app = Flask('test')
        monkeypatch.setenv('OVERFLASK_TEST_ENV_KEY', 'from_env')
        assert _get(app, 'OVERFLASK_TEST_ENV_KEY') == 'from_env'

    def test_returns_none_when_missing(self, monkeypatch):
        app = Flask('test')
        monkeypatch.delenv('OVERFLASK_ABSENT_KEY', raising=False)
        assert _get(app, 'OVERFLASK_ABSENT_KEY') is None

    def test_flask_config_takes_priority_over_env(self, monkeypatch):
        app = Flask('test')
        app.config['OVERFLASK_TEST_ENV_KEY'] = 'from_flask'
        monkeypatch.setenv('OVERFLASK_TEST_ENV_KEY', 'from_env')
        assert _get(app, 'OVERFLASK_TEST_ENV_KEY') == 'from_flask'


# ---------------------------------------------------------------------------
# TestRequire
# ---------------------------------------------------------------------------

class TestRequire:
    @pytest.fixture(autouse=True)
    def reset_is_testing(self):
        with config_attrs(IS_TESTING=False):
            yield

    def test_returns_value_when_present(self):
        app = Flask('test')
        app.config['MYKEY'] = 'value'
        assert _require(app, 'MYKEY') == 'value'

    def test_raises_when_missing(self, monkeypatch):
        monkeypatch.delenv('OVERFLASK_ABSENT_KEY', raising=False)
        app = Flask('test')
        with pytest.raises(RuntimeError, match="Required config key 'OVERFLASK_ABSENT_KEY'"):
            _require(app, 'OVERFLASK_ABSENT_KEY')

    def test_raises_when_empty_string(self, monkeypatch):
        monkeypatch.delenv('MYKEY', raising=False)
        app = Flask('test')
        app.config['MYKEY'] = ''
        with pytest.raises(RuntimeError):
            _require(app, 'MYKEY')

    def test_uses_testing_default_when_testing(self, monkeypatch):
        type.__setattr__(Config, 'IS_TESTING', True)
        monkeypatch.delenv('OVERFLASK_ABSENT_KEY', raising=False)
        app = Flask('test')
        result = _require(app, 'OVERFLASK_ABSENT_KEY', testing_default='default_val')
        assert result == 'default_val'

    def test_raises_without_testing_default_even_when_testing(self, monkeypatch):
        type.__setattr__(Config, 'IS_TESTING', True)
        monkeypatch.delenv('OVERFLASK_ABSENT_KEY', raising=False)
        app = Flask('test')
        with pytest.raises(RuntimeError):
            _require(app, 'OVERFLASK_ABSENT_KEY')

    def test_returns_env_var_value(self, monkeypatch):
        monkeypatch.setenv('OVERFLASK_TEST_ENV_KEY', 'env_value')
        app = Flask('test')
        assert _require(app, 'OVERFLASK_TEST_ENV_KEY') == 'env_value'


# ---------------------------------------------------------------------------
# TestOptional
# ---------------------------------------------------------------------------

class TestOptional:
    def test_returns_value_cast_to_int(self):
        app = Flask('test')
        app.config['MY_INT'] = '42'
        assert _optional(app, 'MY_INT', default=0) == 42

    def test_returns_value_cast_to_str(self):
        app = Flask('test')
        app.config['MY_STR'] = 'hello'
        assert _optional(app, 'MY_STR', default='') == 'hello'

    def test_returns_default_when_missing(self, monkeypatch):
        monkeypatch.delenv('OVERFLASK_ABSENT_KEY', raising=False)
        app = Flask('test')
        assert _optional(app, 'OVERFLASK_ABSENT_KEY', default=99) == 99

    def test_returns_default_when_empty_string(self):
        app = Flask('test')
        app.config['MYKEY'] = ''
        assert _optional(app, 'MYKEY', default='fallback') == 'fallback'

    @pytest.mark.parametrize('val', ['true', 'True', '1', 'yes', 'Yes'])
    def test_bool_truthy_strings(self, val):
        app = Flask('test')
        app.config['MY_BOOL'] = val
        assert _optional(app, 'MY_BOOL', default=False) is True

    @pytest.mark.parametrize('val', ['false', 'False', '0', 'no'])
    def test_bool_falsy_strings(self, val):
        app = Flask('test')
        app.config['MY_BOOL'] = val
        assert _optional(app, 'MY_BOOL', default=True) is False

    def test_bool_default_returned_as_bool(self, monkeypatch):
        monkeypatch.delenv('OVERFLASK_ABSENT_KEY', raising=False)
        app = Flask('test')
        assert _optional(app, 'OVERFLASK_ABSENT_KEY', default=True) is True


# ---------------------------------------------------------------------------
# TestLoadComponents
# ---------------------------------------------------------------------------

class TestLoadComponents:
    def test_returns_sorted_component_names(self, tmp_path):
        comp = tmp_path / 'components'
        for name in ('zebra', 'alpha', 'beta'):
            (comp / name).mkdir(parents=True)
        assert Config._load_components(tmp_path) == ['alpha', 'beta', 'zebra']

    def test_excludes_underscore_dirs(self, tmp_path):
        comp = tmp_path / 'components'
        (comp / '_private').mkdir(parents=True)
        (comp / 'public').mkdir(parents=True)
        assert Config._load_components(tmp_path) == ['public']

    def test_excludes_files(self, tmp_path):
        comp = tmp_path / 'components'
        comp.mkdir()
        (comp / 'mycomp').mkdir()
        (comp / 'readme.txt').write_text('not a component')
        assert Config._load_components(tmp_path) == ['mycomp']

    def test_empty_when_no_components_dir(self, tmp_path):
        assert Config._load_components(tmp_path) == []

    def test_empty_when_components_dir_is_empty(self, tmp_path):
        (tmp_path / 'components').mkdir()
        assert Config._load_components(tmp_path) == []


# ---------------------------------------------------------------------------
# TestDeterminePostgresUrl
# ---------------------------------------------------------------------------

class TestDeterminePostgresUrl:
    @pytest.fixture(autouse=True)
    def pg_config(self):
        with config_attrs(
            POSTGRES_USER='myuser',
            POSTGRES_PASSWORD='mypass',
            POSTGRES_HOST='dbhost',
            POSTGRES_PORT='5432',
            POSTGRES_DB='mydb',
        ):
            yield

    def test_builds_correct_url(self):
        url = Config._determine_postgres_url()
        assert url == 'postgresql+psycopg://myuser:mypass@dbhost:5432/mydb'

    def test_custom_port_included(self):
        with config_attrs(POSTGRES_PORT='5433'):
            assert ':5433/' in Config._determine_postgres_url()

    def test_uses_psycopg_driver(self):
        assert Config._determine_postgres_url().startswith('postgresql+psycopg://')


# ---------------------------------------------------------------------------
# TestCheckVerifiedVersion
# ---------------------------------------------------------------------------

class TestCheckVerifiedVersion:
    @pytest.fixture(autouse=True)
    def config_state(self):
        with config_attrs(
            OVERFLASK_VERSION=Version('1.0.0'),
            VERIFIED_OVERFLASK_VERSION=Version('0.9.0'),
        ):
            yield

    def test_warns_when_debug_and_version_newer(self):
        with config_attrs(IS_DEBUG=True, IS_TESTING=False):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                Config._check_verified_version()
        assert len(w) == 1
        assert 'VERIFIED_OVERFLASK_VERSION' in str(w[0].message)

    def test_no_warning_when_not_debug(self):
        with config_attrs(IS_DEBUG=False, IS_TESTING=False):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                Config._check_verified_version()
        assert len(w) == 0

    def test_no_warning_when_testing(self):
        with config_attrs(IS_DEBUG=True, IS_TESTING=True):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                Config._check_verified_version()
        assert len(w) == 0

    def test_no_warning_when_versions_equal(self):
        with config_attrs(IS_DEBUG=True, IS_TESTING=False, VERIFIED_OVERFLASK_VERSION=Version('1.0.0')):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                Config._check_verified_version()
        assert len(w) == 0

    def test_warning_mentions_changelog_url(self):
        with config_attrs(IS_DEBUG=True, IS_TESTING=False):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                Config._check_verified_version()
        assert 'CHANGELOG' in str(w[0].message)
