"""Tests for the overflask CLI."""

import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import pytest
from click.testing import CliRunner

import overflask
from overflask.cli.cli import main
from overflask.commands.overflask import _MARKER, _overwrite_env, _overwrite_with_marker, _split_at_marker

# Env passed to subprocesses that start a generated project locally (non-Docker).
# Provides required overflask env vars not present in the generated .env.
_LOCAL_ENV = {
    **os.environ,
    'ELASTICSEARCH_URL': 'http://localhost:9200',
    'KIBANA_URL': 'http://localhost:5601',
    'SECRET_KEY': 'a' * 64,
    'REDIS_URL': 'redis://localhost:6379',
    'POSTGRES_HOST': 'localhost',
    'POSTGRES_PORT': '5432',
    'POSTGRES_USER': 'testuser',
    'POSTGRES_PASSWORD': 'testpass',
    'POSTGRES_DB': 'testdb',
}


def setup_overflask_for_docker(project_dir: Path) -> None:
    """Build overflask wheel and configure project to install it in Docker.

    Building a wheel on the host avoids needing setuptools in the Docker image.
    """
    overflask_project = Path(overflask.__file__).parent.parent.parent  # repo root
    wheels_dir = project_dir / 'overflask-wheels'
    wheels_dir.mkdir()

    # Build wheel on host where setuptools is available
    subprocess.run(
        [sys.executable, '-m', 'pip', 'wheel', '--no-deps', '-w', str(wheels_dir), str(overflask_project)],
        check=True, capture_output=True,
    )
    wheel_file = next(wheels_dir.glob('overflask-*.whl'))

    # Update pyproject.toml to install from local wheel
    pyproject_file = project_dir / 'pyproject.toml'
    content = pyproject_file.read_text()
    content = '\n'.join(
        f'    "overflask @ file:./overflask-wheels/{wheel_file.name}",' if 'overflask @' in line else line
        for line in content.splitlines()
    )
    pyproject_file.write_text(content)

    # Update compose.yaml to copy wheels dir in dependencies stage
    compose_file = project_dir / 'compose.yaml'
    compose_content = compose_file.read_text()
    compose_content = compose_content.replace(
        'COPY pyproject.toml .',
        'COPY pyproject.toml .\n        COPY overflask-wheels ./overflask-wheels'
    )
    compose_file.write_text(compose_content)


@pytest.fixture
def runner():
    """Create a CLI test runner."""
    return CliRunner()


@pytest.fixture
def isolated_dir(tmp_path, monkeypatch):
    """Change to a temporary directory for testing."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


# Input for create command: component_name + 5 postgres prompts + 1 redis prompt + docker confirm
# Format: component_name\npg_host\npg_port\npg_user\npg_pass\npg_db\nredis_url\ndocker_confirm
# All required values are provided
DEFAULT_CREATE_INPUT = '\nlocalhost\n5432\ntestuser\ntestpass\ntestdb\nredis://localhost:6379\nn\n'


class TestCreateCommand:
    """Tests for the 'overflask create' command."""

    def test_create_project_structure(self, runner, isolated_dir):
        """Test that create command creates the correct directory structure."""
        # Input: default component name, skip postgres values, no docker
        result = runner.invoke(main, ['create', 'testproject'], input=DEFAULT_CREATE_INPUT)

        assert result.exit_code == 0
        assert "Creating project 'testproject'" in result.output

        project_dir = isolated_dir / 'testproject'
        assert project_dir.exists()

        # Check root files
        assert (project_dir / 'README.md').exists()
        assert (project_dir / 'manage.py').exists()
        assert (project_dir / 'settings.py').exists()
        assert (project_dir / 'pyproject.toml').exists()
        assert (project_dir / 'compose.yaml').exists()
        assert (project_dir / '.gitignore').exists()
        assert (project_dir / '.dockerignore').exists()
        assert (project_dir / '.env').exists()

        # Check directories
        assert (project_dir / 'overflask-docs').is_dir()
        assert (project_dir / 'ops').is_dir()
        assert (project_dir / 'components').is_dir()

        # Check docs
        assert (project_dir / 'overflask-docs' / 'gunicorn.md').exists()
        assert (project_dir / 'overflask-docs' / 'README-overflask.md').exists()

        # Check ops
        assert (project_dir / 'ops' / 'env.template').exists()

        # Check components folder
        assert (project_dir / 'components').is_dir()

        # Check test infrastructure files
        assert (project_dir / 'conftest.py').exists()
        assert (project_dir / 'pytest.ini').exists()

        # Check initial component (named after project by default)
        component_dir = project_dir / 'components' / 'testproject'
        assert component_dir.exists()
        assert (component_dir / '__init__.py').exists()
        assert (component_dir / 'models.py').exists()
        assert (component_dir / 'views.py').exists()
        assert (component_dir / 'services.py').exists()
        assert (component_dir / 'cli.py').exists()
        assert (component_dir / 'tests.py').exists()

        # Check migrations folder in ops
        assert (project_dir / 'ops' / 'migrations').is_dir()
        assert (project_dir / 'ops' / 'migrations' / 'alembic.ini').exists()
        assert (project_dir / 'ops' / 'migrations' / 'env.py').exists()
        assert (project_dir / 'ops' / 'migrations' / 'versions').is_dir()

    def test_create_project_with_postgres_values(self, runner, isolated_dir):
        """Test that postgres values are written to .env."""
        # Input: default component, then postgres values, no docker
        result = runner.invoke(main, ['create', 'testproject'], input='\nlocalhost\n5432\nmyuser\nmypass\nmydb\nredis://localhost:6379\nn\n')

        assert result.exit_code == 0

        env_content = (isolated_dir / 'testproject' / '.env').read_text()
        assert 'POSTGRES_HOST=localhost' in env_content
        assert 'POSTGRES_PORT=5432' in env_content
        assert 'POSTGRES_USER=myuser' in env_content
        assert 'POSTGRES_PASSWORD=mypass' in env_content
        assert 'POSTGRES_DB=mydb' in env_content
        assert 'SECRET_KEY=' in env_content
        # Secret key should be generated (64 hex chars)
        for line in env_content.split('\n'):
            if line.startswith('SECRET_KEY='):
                key = line.split('=', 1)[1].split('  #')[0]
                assert len(key) == 64

    def test_create_project_already_exists(self, runner, isolated_dir):
        """Test that create fails if directory already exists."""
        (isolated_dir / 'testproject').mkdir()

        result = runner.invoke(main, ['create', 'testproject'])

        assert result.exit_code != 0
        assert 'already exists' in result.output

    def test_create_renders_project_name(self, runner, isolated_dir):
        """Test that project name is rendered in templates."""
        result = runner.invoke(main, ['create', 'myapp'], input=DEFAULT_CREATE_INPUT)

        assert result.exit_code == 0

        # Check manage.py has project name in docstring
        manage_content = (isolated_dir / 'myapp' / 'manage.py').read_text()
        assert 'myapp' in manage_content

        # Check compose.yaml has project name as default
        compose_content = (isolated_dir / 'myapp' / 'compose.yaml').read_text()
        assert 'myapp' in compose_content

    def test_create_with_custom_component_name(self, runner, isolated_dir):
        """Test that a custom initial component name can be specified."""
        # Input: custom component name "core", skip postgres, no docker
        result = runner.invoke(main, ['create', 'myapp'], input='core\n\n\n\n\n\n\nn\n')

        assert result.exit_code == 0
        assert "Initial component 'core' created" in result.output

        project_dir = isolated_dir / 'myapp'
        # Check component is created with custom name
        assert (project_dir / 'components' / 'core').is_dir()
        assert (project_dir / 'components' / 'core' / 'views.py').exists()

        # Components are auto-discovered from filesystem, not listed in settings.py

    def test_pyproject_uses_local_overflask_in_dev(self, runner, isolated_dir):
        """Test that overflask uses file:// URL when running from source."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        pyproject = (isolated_dir / 'testapp' / 'pyproject.toml').read_text()
        # When running from source (development), overflask should use file:// URL
        assert 'overflask @ file://' in pyproject
        # Other dependencies should be there
        assert 'flask>=3.0' in pyproject
        assert 'sqlalchemy>=2.0' in pyproject

    def test_secret_key_is_unique(self, runner, isolated_dir):
        """Test that each project gets a unique secret key."""
        runner.invoke(main, ['create', 'project1'], input=DEFAULT_CREATE_INPUT)
        runner.invoke(main, ['create', 'project2'], input=DEFAULT_CREATE_INPUT)

        env1 = (isolated_dir / 'project1' / '.env').read_text()
        env2 = (isolated_dir / 'project2' / '.env').read_text()

        key1 = None
        key2 = None
        for line in env1.split('\n'):
            if line.startswith('SECRET_KEY='):
                key1 = line.split('=', 1)[1]
        for line in env2.split('\n'):
            if line.startswith('SECRET_KEY='):
                key2 = line.split('=', 1)[1]

        assert key1 is not None
        assert key2 is not None
        assert key1 != key2


class TestVersionOption:
    """Tests for the version option."""

    def test_version_option(self, runner):
        """Test that --version shows version info."""
        result = runner.invoke(main, ['--version'])

        assert result.exit_code == 0
        assert '0.8.1' in result.output


def find_free_port() -> int:
    """Find a free port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def wait_for_server(host: str, port: int, timeout: float = 10.0) -> bool:
    """Wait for server to be ready, return True if successful."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            with socket.create_connection((host, port), timeout=1.0):
                return True
        except OSError:
            time.sleep(0.1)
    return False


class TestComponentAdd:
    """Tests for the 'manage.py component add' command."""

    def test_component_add_creates_structure(self, runner, isolated_dir):
        """Test that component add creates the correct directory structure."""
        # Create project first
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        # Run component add
        add_result = subprocess.run(
            [sys.executable, 'manage.py', 'component', 'add', 'auth'],
            cwd=project_dir,
            capture_output=True,
            text=True,
            env=_LOCAL_ENV,
        )
        assert add_result.returncode == 0
        assert "Component 'auth' created successfully" in add_result.stdout

        # Check component directory structure
        component_dir = project_dir / 'components' / 'auth'
        assert component_dir.exists()
        assert (component_dir / '__init__.py').exists()
        assert (component_dir / 'models.py').exists()
        assert (component_dir / 'views.py').exists()
        assert (component_dir / 'services.py').exists()
        assert (component_dir / 'cli.py').exists()
        assert (component_dir / 'tests.py').exists()

        # Check component name is rendered in templates
        views_content = (component_dir / 'views.py').read_text()
        assert 'auth_bp' in views_content
        assert 'Blueprint("auth"' in views_content
        assert 'url_prefix="/auth"' in views_content

        # Components are auto-discovered from filesystem, not listed in settings.py

    def test_component_add_already_exists(self, runner, isolated_dir):
        """Test that component add fails if component already exists."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        # Add component first time
        subprocess.run(
            [sys.executable, 'manage.py', 'component', 'add', 'auth'],
            cwd=project_dir,
            capture_output=True,
            env=_LOCAL_ENV,
        )

        # Try to add again
        add_result = subprocess.run(
            [sys.executable, 'manage.py', 'component', 'add', 'auth'],
            cwd=project_dir,
            capture_output=True,
            text=True,
            env=_LOCAL_ENV,
        )
        assert add_result.returncode != 0
        assert 'already exists' in add_result.stderr


class TestDiscovery:
    """Tests for the component discovery system."""

    def test_discovery_with_models_package(self, runner, isolated_dir):
        """Test that discovery works when models.py is converted to a models/ package."""
        # Create project
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'
        component_dir = project_dir / 'components' / 'testapp'

        # Convert models.py to models/ package
        models_file = component_dir / 'models.py'
        models_file.unlink()

        models_dir = component_dir / 'models'
        models_dir.mkdir()

        # Create __init__.py (can be empty)
        (models_dir / '__init__.py').write_text('')

        # Create a model in a submodule
        (models_dir / 'user.py').write_text('''
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column
from overflask import ModelBase

class User(ModelBase):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255))
''')

        # Run a Python script in the project to verify discovery
        verify_script = project_dir / '_verify_discovery.py'
        verify_script.write_text('''
import sys
sys.path.insert(0, ".")
import settings
from overflask import ModelBase, OverFlask

app = OverFlask(settings, manage_path='manage.py')

# Check that the User model's table was discovered
assert "users" in ModelBase.metadata.tables, f"users table not found. Tables: {list(ModelBase.metadata.tables.keys())}"
print("Discovery OK: users table found")
''')
        verify_result = subprocess.run(
            [sys.executable, str(verify_script)],
            cwd=project_dir,
            capture_output=True,
            text=True,
            env=_LOCAL_ENV,
        )
        assert verify_result.returncode == 0, f"Discovery failed: {verify_result.stderr}"
        assert "Discovery OK" in verify_result.stdout

    def test_discovery_with_views_package(self, runner, isolated_dir):
        """Test that discovery works when views.py is converted to a views/ package."""
        # Create project
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'
        component_dir = project_dir / 'components' / 'testapp'

        # Convert views.py to views/ package
        views_file = component_dir / 'views.py'
        views_file.unlink()

        views_dir = component_dir / 'views'
        views_dir.mkdir()

        # Create __init__.py (can be empty)
        (views_dir / '__init__.py').write_text('')

        # Create a blueprint in a submodule
        (views_dir / 'api.py').write_text('''
from flask import Blueprint

api_bp = Blueprint("api", __name__, url_prefix="/api")

@api_bp.route("/status")
def status():
    return {"status": "ok"}
''')

        # Start server and verify the blueprint is registered
        port = find_free_port()
        server_process = subprocess.Popen(
            [sys.executable, 'manage.py', 'run', '127.0.0.1', str(port)],
            cwd=project_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=_LOCAL_ENV,
        )

        try:
            if not wait_for_server('127.0.0.1', port):
                server_process.terminate()
                output, _ = server_process.communicate(timeout=5)
                pytest.fail(f'Server did not start. Output:\n{output.decode()}')

            # Request the endpoint from the submodule blueprint
            url = f'http://127.0.0.1:{port}/api/status'
            with urllib.request.urlopen(url, timeout=5) as response:
                assert response.status == 200
                body = response.read().decode()
                assert 'ok' in body

        finally:
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()

    def test_discovery_with_cli_package(self, runner, isolated_dir):
        """Test that discovery works when cli.py is converted to a cli/ package."""
        # Create project
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'
        component_dir = project_dir / 'components' / 'testapp'

        # Convert cli.py to cli/ package
        cli_file = component_dir / 'cli.py'
        cli_file.unlink()

        cli_dir = component_dir / 'cli'
        cli_dir.mkdir()

        # Create __init__.py (can be empty)
        (cli_dir / '__init__.py').write_text('')

        # Create a command in a submodule
        (cli_dir / 'greet.py').write_text('''
import click

@click.command()
def hello():
    """Say hello."""
    click.echo("Hello from submodule!")
''')

        # Run the command from the submodule
        cmd_result = subprocess.run(
            [sys.executable, 'manage.py', 'hello'],
            cwd=project_dir,
            capture_output=True,
            text=True,
            env=_LOCAL_ENV,
        )
        assert cmd_result.returncode == 0, f"Command failed: {cmd_result.stderr}"
        assert "Hello from submodule!" in cmd_result.stdout


class TestProjectRun:
    """Integration tests for running a generated project."""

    def test_health_endpoint_responds(self, runner, isolated_dir):
        """Test that a generated project runs and the health endpoint responds."""
        # Create project
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'
        port = find_free_port()

        # Start the Flask server
        server_process = subprocess.Popen(
            [sys.executable, 'manage.py', 'run', '127.0.0.1', str(port)],
            cwd=project_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=_LOCAL_ENV,
        )

        try:
            # Wait for server to start
            if not wait_for_server('127.0.0.1', port):
                # Server didn't start - get output for debugging
                server_process.terminate()
                output, _ = server_process.communicate(timeout=5)
                pytest.fail(f'Server did not start in time. Output:\n{output.decode()}')

            # Make request to the health endpoint
            url = f'http://127.0.0.1:{port}/testapp/health'
            with urllib.request.urlopen(url, timeout=5) as response:
                assert response.status == 200
                body = response.read().decode()
                assert 'ok' in body

        finally:
            # Clean up: terminate the server
            server_process.terminate()
            try:
                server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                server_process.kill()

    def test_redis_integration(self, runner, isolated_dir):
        """Test that Redis integration works in generated projects."""
        # Create project
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        # Modify views.py to set a Redis key
        views_file = project_dir / 'components' / 'testapp' / 'views.py'
        views_file.write_text('''
from flask import Blueprint
from overflask import get_redis

testapp_bp = Blueprint("testapp", __name__, url_prefix="/testapp")

@testapp_bp.route("/health")
def health():
    redis = get_redis(0)
    redis.set("test_key", "hello_from_view")
    return {"status": "ok"}
''')

        try:
            setup_overflask_for_docker(project_dir)

            # Build dependencies first, then project, then start Redis
            subprocess.run(
                ['docker', 'compose', 'build', 'dependencies'],
                cwd=project_dir,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'build', 'project'],
                cwd=project_dir,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'up', '-d', 'redis'],
                cwd=project_dir,
                check=True,
                capture_output=True,
            )

            # Run a one-off container to make a request using Flask's test client
            # This runs inside Docker so it can access Redis via the internal network
            test_script = '''
import settings
from overflask import OverFlask
app = OverFlask(settings, manage_path='manage.py')
with app.test_client() as client:
    response = client.get("/testapp/health")
    assert response.status_code == 200
print("REQUEST_OK")
'''
            run_result = subprocess.run(
                [
                    'docker', 'compose', 'run', '--rm',
                    '-e', 'POSTGRES_HOST=localhost',
                    '-e', 'POSTGRES_PORT=5432',
                    '-e', 'POSTGRES_USER=testuser',
                    '-e', 'POSTGRES_PASSWORD=testpass',
                    '-e', 'POSTGRES_DB=testdb',
                    '-e', 'REDIS_URL=redis://redis:6379',
                    '-e', 'SECRET_KEY=testsecret',
                    '-e', 'ELASTICSEARCH_URL=http://localhost:9200',
                    '-e', 'KIBANA_URL=http://localhost:5601',
                    '--entrypoint', 'python',
                    'project', '-c', test_script,
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert run_result.returncode == 0, f"Test script failed: {run_result.stderr}"
            assert "REQUEST_OK" in run_result.stdout

            # Verify value was set in Redis using redis-cli
            redis_result = subprocess.run(
                ['docker', 'compose', 'exec', 'redis', 'redis-cli', 'GET', 'test_key'],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert redis_result.returncode == 0
            assert 'hello_from_view' in redis_result.stdout

        finally:
            # Clean up docker
            subprocess.run(
                ['docker', 'compose', 'down'],
                cwd=project_dir,
                capture_output=True,
            )


class TestCacheDecorator:
    """Tests for the @cached decorator."""

    def test_cache_basic_functionality(self, runner, isolated_dir):
        """Test that cached decorator caches function results."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        setup_overflask_for_docker(project_dir)

        try:
            # Build and start Redis
            subprocess.run(
                ['docker', 'compose', 'build', 'dependencies'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'build', 'project'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'up', '-d', 'redis'],
                cwd=project_dir, check=True, capture_output=True,
            )

            # Test script that verifies caching works
            test_script = '''
import settings
from datetime import timedelta
from overflask import OverFlask, cached

# Initialize app (configures cache)
app = OverFlask(settings, manage_path='manage.py')

call_count = 0

@cached(ttl=timedelta(minutes=5))
def expensive_function(x, y):
    global call_count
    call_count += 1
    return x + y

with app.app_context():
    # First call - should execute function
    result1 = expensive_function(1, 2)
    assert result1 == 3
    assert call_count == 1

    # Second call with same args - should return cached
    result2 = expensive_function(1, 2)
    assert result2 == 3
    assert call_count == 1, f"Function was called again, count={call_count}"

    # Call with different args - should execute function
    result3 = expensive_function(3, 4)
    assert result3 == 7
    assert call_count == 2

print("CACHE_TEST_OK")
'''
            run_result = subprocess.run(
                [
                    'docker', 'compose', 'run', '--rm',
                    '-e', 'POSTGRES_HOST=localhost',
                    '-e', 'POSTGRES_PORT=5432',
                    '-e', 'POSTGRES_USER=testuser',
                    '-e', 'POSTGRES_PASSWORD=testpass',
                    '-e', 'POSTGRES_DB=testdb',
                    '-e', 'REDIS_URL=redis://redis:6379',
                    '-e', 'SECRET_KEY=testsecret',
                    '-e', 'ELASTICSEARCH_URL=http://localhost:9200',
                    '-e', 'KIBANA_URL=http://localhost:5601',
                    '--entrypoint', 'python',
                    'project', '-c', test_script,
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert run_result.returncode == 0, f"Test failed: {run_result.stderr}"
            assert "CACHE_TEST_OK" in run_result.stdout

        finally:
            subprocess.run(
                ['docker', 'compose', 'down'],
                cwd=project_dir, capture_output=True,
            )

    def test_cache_clear_specific(self, runner, isolated_dir):
        """Test that clear_cache() clears specific cache entries."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        setup_overflask_for_docker(project_dir)

        try:
            subprocess.run(
                ['docker', 'compose', 'build', 'dependencies'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'build', 'project'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'up', '-d', 'redis'],
                cwd=project_dir, check=True, capture_output=True,
            )

            test_script = '''
import settings
from datetime import timedelta
from overflask import OverFlask, cached

# Initialize app (configures cache)
app = OverFlask(settings, manage_path='manage.py')

call_count = 0

@cached(ttl=timedelta(minutes=5))
def get_data(key):
    global call_count
    call_count += 1
    return f"value_{key}"

with app.app_context():
    # Cache two different keys
    get_data("a")
    get_data("b")
    assert call_count == 2

    # Both should be cached
    get_data("a")
    get_data("b")
    assert call_count == 2

    # Clear only key "a"
    get_data.clear_cache(key="a")

    # "a" should be re-computed, "b" should still be cached
    get_data("a")
    assert call_count == 3
    get_data("b")
    assert call_count == 3

print("CLEAR_SPECIFIC_OK")
'''
            run_result = subprocess.run(
                [
                    'docker', 'compose', 'run', '--rm',
                    '-e', 'POSTGRES_HOST=localhost',
                    '-e', 'POSTGRES_PORT=5432',
                    '-e', 'POSTGRES_USER=testuser',
                    '-e', 'POSTGRES_PASSWORD=testpass',
                    '-e', 'POSTGRES_DB=testdb',
                    '-e', 'REDIS_URL=redis://redis:6379',
                    '-e', 'SECRET_KEY=testsecret',
                    '-e', 'ELASTICSEARCH_URL=http://localhost:9200',
                    '-e', 'KIBANA_URL=http://localhost:5601',
                    '--entrypoint', 'python',
                    'project', '-c', test_script,
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert run_result.returncode == 0, f"Test failed: {run_result.stderr}"
            assert "CLEAR_SPECIFIC_OK" in run_result.stdout

        finally:
            subprocess.run(
                ['docker', 'compose', 'down'],
                cwd=project_dir, capture_output=True,
            )

    def test_cache_clear_all(self, runner, isolated_dir):
        """Test that clear_all_caches() clears all entries for a function."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        setup_overflask_for_docker(project_dir)

        try:
            subprocess.run(
                ['docker', 'compose', 'build', 'dependencies'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'build', 'project'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'up', '-d', 'redis'],
                cwd=project_dir, check=True, capture_output=True,
            )

            test_script = '''
import settings
from datetime import timedelta
from overflask import OverFlask, cached

# Initialize app (configures cache)
app = OverFlask(settings, manage_path='manage.py')

call_count = 0

@cached(ttl=timedelta(minutes=5))
def get_data(key):
    global call_count
    call_count += 1
    return f"value_{key}"

with app.app_context():
    # Cache multiple keys
    get_data("a")
    get_data("b")
    get_data("c")
    assert call_count == 3

    # All should be cached
    get_data("a")
    get_data("b")
    get_data("c")
    assert call_count == 3

    # Clear all caches for this function
    get_data.clear_all_caches()

    # All should be re-computed
    get_data("a")
    get_data("b")
    get_data("c")
    assert call_count == 6

print("CLEAR_ALL_OK")
'''
            run_result = subprocess.run(
                [
                    'docker', 'compose', 'run', '--rm',
                    '-e', 'POSTGRES_HOST=localhost',
                    '-e', 'POSTGRES_PORT=5432',
                    '-e', 'POSTGRES_USER=testuser',
                    '-e', 'POSTGRES_PASSWORD=testpass',
                    '-e', 'POSTGRES_DB=testdb',
                    '-e', 'REDIS_URL=redis://redis:6379',
                    '-e', 'SECRET_KEY=testsecret',
                    '-e', 'ELASTICSEARCH_URL=http://localhost:9200',
                    '-e', 'KIBANA_URL=http://localhost:5601',
                    '--entrypoint', 'python',
                    'project', '-c', test_script,
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert run_result.returncode == 0, f"Test failed: {run_result.stderr}"
            assert "CLEAR_ALL_OK" in run_result.stdout

        finally:
            subprocess.run(
                ['docker', 'compose', 'down'],
                cwd=project_dir, capture_output=True,
            )

    def test_cache_static_clear(self, runner, isolated_dir):
        """Test that cached.clear(key) static method works."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        setup_overflask_for_docker(project_dir)

        try:
            subprocess.run(
                ['docker', 'compose', 'build', 'dependencies'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'build', 'project'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'up', '-d', 'redis'],
                cwd=project_dir, check=True, capture_output=True,
            )

            test_script = '''
import settings
from datetime import timedelta
from overflask import OverFlask, cached

# Initialize app (configures cache)
app = OverFlask(settings, manage_path='manage.py')

call_count = 0

@cached(ttl=timedelta(minutes=5), key="my_data")
def get_data(key):
    global call_count
    call_count += 1
    return f"value_{key}"

with app.app_context():
    # Cache values
    get_data("a")
    get_data("b")
    assert call_count == 2

    # Use static clear method
    cached.clear("my_data")

    # All should be re-computed
    get_data("a")
    get_data("b")
    assert call_count == 4

print("STATIC_CLEAR_OK")
'''
            run_result = subprocess.run(
                [
                    'docker', 'compose', 'run', '--rm',
                    '-e', 'POSTGRES_HOST=localhost',
                    '-e', 'POSTGRES_PORT=5432',
                    '-e', 'POSTGRES_USER=testuser',
                    '-e', 'POSTGRES_PASSWORD=testpass',
                    '-e', 'POSTGRES_DB=testdb',
                    '-e', 'REDIS_URL=redis://redis:6379',
                    '-e', 'SECRET_KEY=testsecret',
                    '-e', 'ELASTICSEARCH_URL=http://localhost:9200',
                    '-e', 'KIBANA_URL=http://localhost:5601',
                    '--entrypoint', 'python',
                    'project', '-c', test_script,
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert run_result.returncode == 0, f"Test failed: {run_result.stderr}"
            assert "STATIC_CLEAR_OK" in run_result.stdout

        finally:
            subprocess.run(
                ['docker', 'compose', 'down'],
                cwd=project_dir, capture_output=True,
            )

    def test_cache_custom_key(self, runner, isolated_dir):
        """Test that custom cache key works."""
        result = runner.invoke(main, ['create', 'testapp'], input=DEFAULT_CREATE_INPUT)
        assert result.exit_code == 0

        project_dir = isolated_dir / 'testapp'

        setup_overflask_for_docker(project_dir)

        try:
            subprocess.run(
                ['docker', 'compose', 'build', 'dependencies'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'build', 'project'],
                cwd=project_dir, check=True, capture_output=True,
            )
            subprocess.run(
                ['docker', 'compose', 'up', '-d', 'redis'],
                cwd=project_dir, check=True, capture_output=True,
            )

            test_script = '''
import settings
from datetime import timedelta
from overflask import OverFlask, cached
from overflask.core.config import Config
from redis import Redis

# Initialize app (configures cache)
app = OverFlask(settings, manage_path='manage.py')

# Two functions with same name but different custom keys
@cached(ttl=timedelta(minutes=5), key="func_v1")
def get_value():
    return "v1"

@cached(ttl=timedelta(minutes=5), key="func_v2")
def get_value():
    return "v2"

with app.app_context():
    # Call both - they should cache separately
    result1 = get_value()
    assert result1 == "v2"  # Second definition wins

    # Check Redis directly to verify key naming
    r = Redis.from_url(Config.REDIS_URL, db=15)
    keys = list(r.scan_iter("func_*"))
    # Should have func_v2 key (the one we called)
    assert any(b"func_v2" in k for k in keys), f"Expected func_v2 key, got {keys}"

print("CUSTOM_KEY_OK")
'''
            run_result = subprocess.run(
                [
                    'docker', 'compose', 'run', '--rm',
                    '-e', 'POSTGRES_HOST=localhost',
                    '-e', 'POSTGRES_PORT=5432',
                    '-e', 'POSTGRES_USER=testuser',
                    '-e', 'POSTGRES_PASSWORD=testpass',
                    '-e', 'POSTGRES_DB=testdb',
                    '-e', 'REDIS_URL=redis://redis:6379',
                    '-e', 'SECRET_KEY=testsecret',
                    '-e', 'ELASTICSEARCH_URL=http://localhost:9200',
                    '-e', 'KIBANA_URL=http://localhost:5601',
                    '--entrypoint', 'python',
                    'project', '-c', test_script,
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
            )
            assert run_result.returncode == 0, f"Test failed: {run_result.stderr}"
            assert "CUSTOM_KEY_OK" in run_result.stdout

        finally:
            subprocess.run(
                ['docker', 'compose', 'down'],
                cwd=project_dir, capture_output=True,
            )


_RULER = '### ============================================================'


def _make_env_template(keys: list[str]) -> str:
    """Build a minimal env.template with a marker section containing the given keys."""
    lines = [
        _MARKER,
        _RULER,
        '### They will be overwritten when running "manage.py overflask overwrite"',
        '',
    ]
    for key in keys:
        lines.append(f'{key}=')
    return '\n'.join(lines) + '\n'


class TestOverwriteEnv:
    def test_preserves_existing_values(self, tmp_path):
        source = tmp_path / 'env.template'
        dest = tmp_path / '.env'
        source.write_text(_make_env_template(['POSTGRES_HOST', 'POSTGRES_PORT', 'SECRET_KEY']))
        dest.write_text(
            f'# user section\n\n'
            f'{_MARKER}\n{_RULER}\n\n'
            f'POSTGRES_HOST=myhost\n'
            f'POSTGRES_PORT=5432\n'
            f'SECRET_KEY=abc123\n'
        )

        _overwrite_env(source, dest)

        result = dest.read_text()
        assert 'POSTGRES_HOST=myhost' in result
        assert 'POSTGRES_PORT=5432' in result
        assert 'SECRET_KEY=abc123' in result

    def test_adds_new_keys_with_empty_value(self, tmp_path):
        source = tmp_path / 'env.template'
        dest = tmp_path / '.env'
        source.write_text(_make_env_template(['EXISTING_KEY', 'NEW_KEY']))
        dest.write_text(
            f'{_MARKER}\n{_RULER}\n\n'
            f'EXISTING_KEY=somevalue\n'
        )

        _overwrite_env(source, dest)

        result = dest.read_text()
        assert 'EXISTING_KEY=somevalue' in result
        assert 'NEW_KEY=' in result

    def test_drops_removed_keys(self, tmp_path):
        source = tmp_path / 'env.template'
        dest = tmp_path / '.env'
        source.write_text(_make_env_template(['KEPT_KEY']))
        dest.write_text(
            f'{_MARKER}\n{_RULER}\n\n'
            f'KEPT_KEY=val\n'
            f'REMOVED_KEY=old\n'
        )

        _overwrite_env(source, dest)

        result = dest.read_text()
        assert 'KEPT_KEY=val' in result
        assert 'REMOVED_KEY' not in result

    def test_follows_template_ordering(self, tmp_path):
        source = tmp_path / 'env.template'
        dest = tmp_path / '.env'
        source.write_text(_make_env_template(['FIRST', 'SECOND', 'THIRD']))
        dest.write_text(
            f'{_MARKER}\n{_RULER}\n\n'
            f'THIRD=c\n'
            f'FIRST=a\n'
            f'SECOND=b\n'
        )

        _overwrite_env(source, dest)

        result = dest.read_text()
        assert result.index('FIRST=a') < result.index('SECOND=b') < result.index('THIRD=c')

    def test_preserves_user_section_above_marker(self, tmp_path):
        source = tmp_path / 'env.template'
        dest = tmp_path / '.env'
        source.write_text(_make_env_template(['KEY']))
        dest.write_text(
            f'MY_CUSTOM_VAR=hello\n'
            f'ANOTHER_VAR=world\n\n'
            f'{_MARKER}\n{_RULER}\n\n'
            f'KEY=val\n'
        )

        _overwrite_env(source, dest)

        result = dest.read_text()
        assert result.startswith('MY_CUSTOM_VAR=hello\nANOTHER_VAR=world\n')
        assert 'KEY=val' in result
