from __future__ import annotations

import json
import unittest

import httpx

from runrobot import Runrobot, RunrobotApiError


class RunrobotClientTests(unittest.TestCase):
    def test_simulations_create_and_wait_uses_poll_url(self) -> None:
        calls: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(str(request.url))
            if request.url.path == "/v1/simulations":
                self.assertEqual(json.loads(request.content.decode("utf-8")), {"simulator": "nvidia/sonic"})
                return httpx.Response(
                    202,
                    json={
                        "simulation": {
                            "id": "sim_123",
                            "status": "starting",
                            "simulator": "nvidia/sonic",
                            "robot": "unitree/g1",
                            "assets": "parkour-v1",
                            "target": "browser",
                            "browser_url": None,
                            "debug_url": None,
                            "poll_url": "/v1/simulations/sim_123",
                            "expires_at": None,
                        }
                    },
                )
            return httpx.Response(
                200,
                json={
                    "simulation": {
                        "id": "sim_123",
                        "status": "ready",
                        "simulator": "nvidia/sonic",
                        "robot": "unitree/g1",
                        "assets": "parkour-v1",
                        "target": "browser",
                        "browser_url": "https://runrobot.sh/sonic/session_123",
                        "debug_url": "https://runrobot.sh/sonic/session_123",
                        "poll_url": "/v1/simulations/sim_123",
                        "expires_at": None,
                    }
                },
            )

        client = Runrobot(auth="token", client=httpx.Client(transport=httpx.MockTransport(handler)))
        simulation = client.simulations.create_and_wait({"simulator": "nvidia/sonic"}, poll_interval_ms=0, timeout_ms=1000)
        self.assertEqual(simulation["browser_url"], "https://runrobot.sh/sonic/session_123")
        self.assertEqual(calls[0], "https://runrobot.sh/v1/simulations")
        self.assertEqual(calls[1], "https://runrobot.sh/v1/simulations/sim_123")

    def test_matchups_create_and_wait_uses_assets(self) -> None:
        calls: list[str] = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(str(request.url))
            if request.url.path == "/v1/matchups":
                self.assertEqual(json.loads(request.content.decode("utf-8")), {"assets": "parkour-v1"})
                return httpx.Response(
                    202,
                    json={
                        "matchup": {
                            "id": "matchup_123",
                            "status": "starting",
                            "assets": "parkour-v1",
                            "robot": "unitree/g1",
                            "startup": "ready",
                            "vote_unlock_at": None,
                            "expires_at": None,
                            "poll_url": "/v1/matchups/matchup_123",
                            "left": {"side": "left", "simulator": "amazon/php-parkour", "simulation_id": "sim_left", "browser_url": None, "supported_actions": []},
                            "right": {"side": "right", "simulator": "nvidia/sonic", "simulation_id": "sim_right", "browser_url": None, "supported_actions": []},
                        }
                    },
                )
            return httpx.Response(
                200,
                json={
                    "matchup": {
                        "id": "matchup_123",
                        "status": "ready",
                        "assets": "parkour-v1",
                        "robot": "unitree/g1",
                        "startup": "ready",
                        "vote_unlock_at": None,
                        "expires_at": None,
                        "poll_url": "/v1/matchups/matchup_123",
                        "left": {"side": "left", "simulator": "amazon/php-parkour", "simulation_id": "sim_left", "browser_url": "https://left", "supported_actions": []},
                        "right": {"side": "right", "simulator": "nvidia/sonic", "simulation_id": "sim_right", "browser_url": "https://right", "supported_actions": []},
                    }
                },
            )

        client = Runrobot(auth="token", client=httpx.Client(transport=httpx.MockTransport(handler)))
        matchup = client.matchups.create_and_wait({"assets": "parkour-v1"}, poll_interval_ms=0, timeout_ms=1000)
        self.assertEqual(matchup["left"]["browser_url"], "https://left")
        self.assertEqual(matchup["right"]["browser_url"], "https://right")
        self.assertEqual(calls[0], "https://runrobot.sh/v1/matchups")
        self.assertEqual(calls[1], "https://runrobot.sh/v1/matchups/matchup_123")

    def test_leaderboard_uses_assets_query_parameter(self) -> None:
        requested_url = ""

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal requested_url
            requested_url = str(request.url)
            return httpx.Response(
                200,
                json={
                    "leaderboard": {
                        "assets": "parkour-v1",
                        "updated_at": None,
                        "winner": None,
                        "methodology_version": "arena-bt-v1",
                        "entries": [],
                    }
                },
            )

        client = Runrobot(auth="token", client=httpx.Client(transport=httpx.MockTransport(handler)))
        leaderboard = client.leaderboard.get("parkour-v1")
        self.assertEqual(leaderboard["assets"], "parkour-v1")
        self.assertEqual(requested_url, "https://runrobot.sh/v1/leaderboard?assets=parkour-v1")

    def test_api_errors_expose_status_and_code(self) -> None:
        def handler(_: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"error": {"code": "unauthorized", "message": "Bad token"}})

        client = Runrobot(auth="token", client=httpx.Client(transport=httpx.MockTransport(handler)))
        with self.assertRaises(RunrobotApiError) as context:
            client.simulations.create({"simulator": "nvidia/sonic"})

        self.assertEqual(context.exception.status, 401)
        self.assertEqual(context.exception.code, "unauthorized")
        self.assertEqual(str(context.exception), "Bad token")

    def test_plain_text_api_errors_are_surfaced_cleanly(self) -> None:
        def handler(_: httpx.Request) -> httpx.Response:
            return httpx.Response(503, text="An error occurred upstream")

        client = Runrobot(auth="token", client=httpx.Client(transport=httpx.MockTransport(handler)))
        with self.assertRaises(RunrobotApiError) as context:
            client.simulations.create({"simulator": "nvidia/sonic"})

        self.assertEqual(context.exception.status, 503)
        self.assertEqual(str(context.exception), "An error occurred upstream")

    def test_simulation_timeouts_expose_request_timeout(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ReadTimeout("timed out", request=request)

        client = Runrobot(auth="token", client=httpx.Client(transport=httpx.MockTransport(handler)))
        with self.assertRaises(RunrobotApiError) as context:
            client.simulations.create_and_wait({"simulator": "nvidia/sonic"}, request_timeout_ms=10)

        self.assertEqual(context.exception.status, 408)
        self.assertEqual(context.exception.code, "request_timeout")


if __name__ == "__main__":
    unittest.main()
