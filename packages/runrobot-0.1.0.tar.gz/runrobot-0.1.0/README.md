# runrobot

Official Python client for the RunRobot API.

## Install

```bash
python -m pip install runrobot
```

## Quickstart

```python
from runrobot import Runrobot

client = Runrobot(auth="YOUR_RUNROBOT_API_TOKEN")
simulation = client.simulations.create_and_wait({
    "simulator": "nvidia/sonic",
})

print(simulation["browser_url"])
```

## Matchups

```python
matchup = client.matchups.create_and_wait({
    "assets": "parkour-v1",
})

print(matchup["left"]["browser_url"])
print(matchup["right"]["browser_url"])
```
