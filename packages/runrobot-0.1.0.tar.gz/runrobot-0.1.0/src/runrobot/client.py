from __future__ import annotations

import time
from typing import Any
from urllib.parse import urljoin

import httpx

JsonDict = dict[str, Any]


class RunrobotApiError(Exception):
    def __init__(self, message: str, *, status: int, code: str | None = None, details: Any = None) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details


class _CatalogOperations:
    def __init__(self, client: "Runrobot") -> None:
        self._client = client

    def get(self) -> JsonDict:
        return self._client._request("/catalog")


class _SimulationOperations:
    def __init__(self, client: "Runrobot") -> None:
        self._client = client

    def create(self, input: JsonDict) -> JsonDict:
        return self._client._request("/simulations", method="POST", json_body=input)["simulation"]

    def get(self, simulation_id_or_poll_url: str) -> JsonDict:
        path = simulation_id_or_poll_url if "/" in simulation_id_or_poll_url else f"/simulations/{simulation_id_or_poll_url}"
        return self._client._request(path)["simulation"]

    def create_and_wait(
        self,
        input: JsonDict,
        *,
        wait_seconds: int | None = None,
        poll_interval_ms: int | None = None,
        timeout_ms: int | None = None,
        request_timeout_ms: int | None = None,
    ) -> JsonDict:
        wait_seconds = _clamp_wait_seconds(wait_seconds)
        total_timeout_ms = max((timeout_ms or wait_seconds * 1000), wait_seconds * 1000)
        request_timeout_seconds = max(
            0.001,
            (request_timeout_ms / 1000) if request_timeout_ms is not None else self._client._request_timeout,
        )
        simulation = self._client._request(
            "/simulations",
            method="POST",
            json_body=input,
            headers={"Prefer": f"wait={wait_seconds}"},
            timeout=min(
                request_timeout_seconds if request_timeout_ms is not None else max(request_timeout_seconds, wait_seconds + 5),
                total_timeout_ms / 1000,
            ),
        )["simulation"]
        if simulation.get("browser_url") or simulation.get("status") == "failed":
            return simulation

        deadline = time.time() + total_timeout_ms / 1000
        poll_interval = max(0.25, (poll_interval_ms or 3000) / 1000)
        while not simulation.get("browser_url") and simulation.get("status") != "failed" and time.time() < deadline:
            time.sleep(min(poll_interval, max(deadline - time.time(), 0)))
            simulation = self._client._request(
                simulation.get("poll_url") or simulation["id"],
                timeout=max(0.001, min(request_timeout_seconds, deadline - time.time())),
            )["simulation"]

        if not simulation.get("browser_url") and simulation.get("status") != "failed":
            raise RunrobotApiError(
                f"Simulation {simulation['id']} did not become ready in time.",
                status=408,
                code="simulation_timeout",
                details=simulation,
            )
        return simulation


class _MatchupOperations:
    def __init__(self, client: "Runrobot") -> None:
        self._client = client

    def create(self, input: JsonDict) -> JsonDict:
        return self._client._request("/matchups", method="POST", json_body=input)["matchup"]

    def get(self, matchup_id_or_poll_url: str) -> JsonDict:
        path = matchup_id_or_poll_url if "/" in matchup_id_or_poll_url else f"/matchups/{matchup_id_or_poll_url}"
        return self._client._request(path)["matchup"]

    def control(self, matchup_id: str, input: JsonDict) -> JsonDict:
        return self._client._request(f"/matchups/{matchup_id}/control", method="POST", json_body=input)

    def create_and_wait(
        self,
        input: JsonDict,
        *,
        wait_seconds: int | None = None,
        poll_interval_ms: int | None = None,
        timeout_ms: int | None = None,
        request_timeout_ms: int | None = None,
    ) -> JsonDict:
        wait_seconds = _clamp_wait_seconds(wait_seconds)
        total_timeout_ms = max((timeout_ms or wait_seconds * 1000), wait_seconds * 1000)
        request_timeout_seconds = max(
            0.001,
            (request_timeout_ms / 1000) if request_timeout_ms is not None else self._client._request_timeout,
        )
        matchup = self._client._request(
            "/matchups",
            method="POST",
            json_body=input,
            headers={"Prefer": f"wait={wait_seconds}"},
            timeout=min(
                request_timeout_seconds if request_timeout_ms is not None else max(request_timeout_seconds, wait_seconds + 5),
                total_timeout_ms / 1000,
            ),
        )["matchup"]
        if (matchup["left"].get("browser_url") and matchup["right"].get("browser_url")) or matchup.get("status") == "failed":
            return matchup

        deadline = time.time() + total_timeout_ms / 1000
        poll_interval = max(0.25, (poll_interval_ms or 3000) / 1000)
        while (not matchup["left"].get("browser_url") or not matchup["right"].get("browser_url")) and matchup.get("status") != "failed" and time.time() < deadline:
            time.sleep(min(poll_interval, max(deadline - time.time(), 0)))
            matchup = self._client._request(
                matchup.get("poll_url") or matchup["id"],
                timeout=max(0.001, min(request_timeout_seconds, deadline - time.time())),
            )["matchup"]

        if (not matchup["left"].get("browser_url") or not matchup["right"].get("browser_url")) and matchup.get("status") != "failed":
            raise RunrobotApiError(
                f"Matchup {matchup['id']} did not become ready in time.",
                status=408,
                code="matchup_timeout",
                details=matchup,
            )
        return matchup


class _LeaderboardOperations:
    def __init__(self, client: "Runrobot") -> None:
        self._client = client

    def get(self, assets: str) -> JsonDict:
        return self._client._request(f"/leaderboard?assets={assets}")["leaderboard"]


class _VoteOperations:
    def __init__(self, client: "Runrobot") -> None:
        self._client = client

    def create(self, input: JsonDict) -> JsonDict:
        return self._client._request("/votes", method="POST", json_body=input)["leaderboard"]


class Runrobot:
    def __init__(
        self,
        *,
        auth: str,
        base_url: str = "https://runrobot.sh/v1",
        client: httpx.Client | None = None,
        request_timeout: float = 30.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.auth = auth
        self._client = client or httpx.Client()
        self._request_timeout = max(0.001, request_timeout)
        self._owns_client = client is None

        self.catalog = _CatalogOperations(self)
        self.simulations = _SimulationOperations(self)
        self.matchups = _MatchupOperations(self)
        self.leaderboard = _LeaderboardOperations(self)
        self.votes = _VoteOperations(self)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "Runrobot":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _request(
        self,
        path_or_url: str,
        *,
        method: str = "GET",
        json_body: JsonDict | None = None,
        headers: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> JsonDict:
        try:
            response = self._client.request(
                method,
                self._to_request_url(path_or_url),
                json=json_body,
                headers={
                    "Authorization": f"Bearer {self.auth}",
                    **(headers or {}),
                },
                timeout=timeout if timeout is not None else self._request_timeout,
            )
        except httpx.TimeoutException as error:
            effective_timeout = timeout if timeout is not None else self._request_timeout
            raise RunrobotApiError(
                f"RunRobot request timed out after {effective_timeout:.3f}s.",
                status=408,
                code="request_timeout",
                details={"path": self._to_request_url(path_or_url)},
            ) from error
        except httpx.RequestError as error:
            raise RunrobotApiError(
                str(error),
                status=599,
                code="request_failed",
                details={"path": self._to_request_url(path_or_url)},
            ) from error
        payload: Any = None
        if response.content:
            try:
                payload = response.json()
            except ValueError:
                payload = None
        if response.is_error:
            error_payload = payload.get("error") if isinstance(payload, dict) else None
            message = error_payload.get("message") if isinstance(error_payload, dict) else (response.text or f"RunRobot request failed with status {response.status_code}")
            code = error_payload.get("code") if isinstance(error_payload, dict) else None
            raise RunrobotApiError(
                str(message),
                status=response.status_code,
                code=None if code is None else str(code),
                details=payload if payload is not None else response.text,
            )
        if response.content and not isinstance(payload, dict):
            raise RunrobotApiError(
                f"RunRobot returned invalid JSON from {self._to_request_url(path_or_url)}.",
                status=502,
                code="invalid_response",
                details={"path": self._to_request_url(path_or_url), "body": response.text},
            )
        return payload if isinstance(payload, dict) else {}

    def _to_request_url(self, path_or_url: str) -> str:
        if path_or_url.startswith("http://") or path_or_url.startswith("https://"):
            return path_or_url
        if path_or_url.startswith("/v1/"):
            return urljoin(f"{self.base_url}/", path_or_url)
        if path_or_url.startswith("/"):
            return f"{self.base_url}{path_or_url}"
        return f"{self.base_url}/{path_or_url}"


def _clamp_wait_seconds(value: int | None) -> int:
    if value is None:
        return 25
    return max(1, min(25, int(value)))
