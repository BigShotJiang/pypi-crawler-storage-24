# Pipedrive MCP Server

A Python-based MCP (Model Context Protocol) server that connects Claude to the Pipedrive CRM API. It runs locally via stdio and provides **57 tools** for managing the full Pipedrive data model through natural language.

## Installation

```bash
pip install pipedrive-mcp
```

Or run directly without installing (recommended for Claude Desktop):

```bash
uvx pipedrive-mcp
```

## Project Structure

```
pipedrive_mcp/
├── __init__.py    ← Package version
├── pipedrive.py   ← Pipedrive API Connector (11 resource classes)
└── server.py      ← MCP Server (57 tools)
```

---

## Available Tools

**57 tools** across 12 categories:

| Category | Tools | Operations |
|---|---|---|
| Deals | 7 | list, get, search, create, update, delete, list_deal_fields |
| Persons | 6 | list, get, search, create, update, delete |
| Organizations | 6 | list, get, search, create, update, delete |
| Activities | 6 | list, get, create, update, delete, list_activity_types |
| Notes | 5 | list, get, create, update, delete |
| Leads | 7 | list, get, search, create, update, delete, convert_to_deal |
| Pipelines & Stages | 4 | list_pipelines, get_pipeline, list_stages, get_stage |
| Products | 6 | list, get, search, create, update, delete |
| Deal Products | 4 | list, add, update, remove |
| Deal Participants | 3 | list, add, remove |
| Users / Team | 2 | list, get |
| Search | 1 | item_search (universal cross-entity search) |

### Key Features

- **Owner assignment**: `create_deal` and `update_deal` support `owner_id` to assign deals to team members
- **Custom fields**: `create_deal` supports `custom_fields` parameter for setting custom field values
- **Search with data extraction**: All search handlers extract structured data (id, name, org, score) from Pipedrive's nested response format
- **Activity owner support**: Activities use the v1 API to properly support `user_id` for owner assignment
- **Timezone handling**: API expects times in UTC — convert from your local timezone before passing `due_time`

---

## Setup

### Claude Desktop Configuration

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "pipedrive": {
      "command": "uvx",
      "args": ["pipedrive-mcp"],
      "env": {
        "PIPEDRIVE_API_KEY": "YOUR_PIPEDRIVE_API_TOKEN"
      }
    }
  }
}
```

After changing the config: fully quit Claude Desktop (Cmd+Q) and restart.

### Project Instructions (optional but recommended)

For best results, create a markdown file with your Pipedrive-specific context and add it to your Claude project instructions. Useful things to include:
- Your team's user/owner IDs (run `list_users` to find them)
- Your pipeline & stage IDs (run `list_pipelines` and `list_stages`)
- Your custom field hash keys (run `list_deal_fields`)
- Your timezone (API expects UTC — e.g. CET = UTC+1 in winter)
- Any activity type key_strings used in your workspace (`list_activity_types`)

---

## Troubleshooting

- **MCP not visible?** → Fully quit Claude Desktop (Cmd+Q) and restart
- **API errors?** → Check your API key in the config
- **Module not found?** → `pip install pipedrive-mcp`

---

## Planned Enhancements

- [ ] Webhook endpoint in MCP server for automatic triggers on Pipedrive stage changes
- [ ] Troi time tracking integration
- [x] PyPI package for one-line installation via `uvx pipedrive-mcp`
