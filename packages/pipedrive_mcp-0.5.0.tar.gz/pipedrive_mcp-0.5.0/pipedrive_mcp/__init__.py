"""Pipedrive MCP Server - connects Claude Desktop to Pipedrive CRM."""

__version__ = "0.5.0"
