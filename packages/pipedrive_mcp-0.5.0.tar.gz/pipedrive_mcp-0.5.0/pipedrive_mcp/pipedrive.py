"""
Pipedrive API v2 Connector
Base URL: https://api.pipedrive.com/api/v2
Auth: API key (passed as query param `api_token`)

Covers:
  - Deals      : list, get, create, update, delete, search
  - Persons    : list, get, create, update, delete, search
  - Organizations: list, get, create, update, delete, search
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, Iterator, List, Optional
from urllib.parse import urlencode

import requests

logger = logging.getLogger("pipedrive-mcp")

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class PipedriveError(Exception):
    """Raised when the Pipedrive API returns a non-success response."""

    def __init__(self, status_code: int, message: str, raw: dict | None = None):
        super().__init__(f"[{status_code}] {message}")
        self.status_code = status_code
        self.raw = raw


# ---------------------------------------------------------------------------
# Base client
# ---------------------------------------------------------------------------

class PipedriveClient:
    """
    Thin HTTP client that handles authentication, pagination, and error
    handling for the Pipedrive API v2 (and v1 for legacy endpoints).

    Usage:
        client = PipedriveClient(api_key="YOUR_KEY")
        # or set env var PIPEDRIVE_API_KEY and call PipedriveClient()
    """

    BASE_URL = "https://api.pipedrive.com/api/v2"
    V1_BASE_URL = "https://api.pipedrive.com/v1"

    MAX_RETRIES = 5
    BASE_DELAY = 1.0        # seconds – exponential backoff base
    THROTTLE_DELAY = 0.15   # 150 ms pause between paginated pages

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.environ.get("PIPEDRIVE_API_KEY")
        if not self.api_key:
            raise ValueError(
                "No API key provided. Pass `api_key=` or set the "
                "PIPEDRIVE_API_KEY environment variable."
            )
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self.BASE_URL}{path}"

    def _v1_url(self, path: str) -> str:
        return f"{self.V1_BASE_URL}{path}"

    def _params(self, extra: dict | None = None) -> dict:
        """Merge extra query params with the mandatory api_token."""
        p = {"api_token": self.api_key}
        if extra:
            p.update({k: v for k, v in extra.items() if v is not None})
        return p

    def _do_request(
        self,
        method: str,
        url: str,
        *,
        params: dict,
        json: dict | None = None,
    ) -> requests.Response:
        """
        Execute an HTTP request with automatic retry on 429 (rate limit).

        Uses the ``Retry-After`` header when present; falls back to
        exponential back-off (1 s, 2 s, 4 s, 8 s, 16 s).
        """
        for attempt in range(self.MAX_RETRIES + 1):
            resp = self.session.request(method, url, params=params, json=json)

            if resp.status_code != 429:
                return resp

            if attempt == self.MAX_RETRIES:
                raise PipedriveError(
                    429,
                    f"Rate limit exceeded after {self.MAX_RETRIES} retries. "
                    "Bitte in 30-60 Sekunden erneut versuchen.",
                    raw={"error": "RATE_LIMIT_EXCEEDED", "retryAfterSeconds": 30},
                )

            retry_after = resp.headers.get("Retry-After")
            wait = (
                float(retry_after)
                if retry_after
                else self.BASE_DELAY * (2 ** attempt)
            )
            logger.warning(
                "[Pipedrive MCP] 429 rate limit hit on %s %s. "
                "Retry in %.1fs (attempt %d/%d)",
                method, url, wait, attempt + 1, self.MAX_RETRIES,
            )
            time.sleep(wait)

        # Should never be reached, but keeps type checkers happy.
        raise PipedriveError(429, "Rate limit exceeded")  # pragma: no cover

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: dict | None = None,
    ) -> dict:
        resp = self._do_request(
            method,
            self._url(path),
            params=self._params(params),
            json=json,
        )
        try:
            data = resp.json()
        except Exception:
            resp.raise_for_status()
            return {}

        if not data.get("success", False):
            raise PipedriveError(
                resp.status_code,
                data.get("error", "Unknown error"),
                raw=data,
            )
        return data

    def _v1_request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: dict | None = None,
    ) -> dict:
        """Like _request but targets the v1 API base URL."""
        resp = self._do_request(
            method,
            self._v1_url(path),
            params=self._params(params),
            json=json,
        )
        try:
            data = resp.json()
        except Exception:
            resp.raise_for_status()
            return {}

        if not data.get("success", False):
            raise PipedriveError(
                resp.status_code,
                data.get("error", "Unknown error"),
                raw=data,
            )
        return data

    def _paginate(
        self,
        path: str,
        params: dict | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """
        Cursor-based pagination helper (v2).
        Yields every item from every page until exhausted.
        """
        params = dict(params or {})
        params["limit"] = limit

        while True:
            data = self._request("GET", path, params=params)
            raw = data.get("data") or []
            # Search endpoints return {"data": {"items": [...]}} instead of {"data": [...]}
            if isinstance(raw, dict):
                items = raw.get("items") or []
            else:
                items = raw
            yield from items

            next_cursor = (data.get("additional_data") or {}).get("next_cursor")
            if not next_cursor:
                break
            params["cursor"] = next_cursor
            time.sleep(self.THROTTLE_DELAY)  # throttle between pages

    def _v1_paginate(
        self,
        path: str,
        params: dict | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """
        Offset-based pagination helper (v1).
        Yields every item from every page until exhausted.
        """
        params = dict(params or {})
        params["limit"] = limit
        params["start"] = 0

        while True:
            data = self._v1_request("GET", path, params=params)
            raw = data.get("data") or []
            # Search endpoints return {"data": {"items": [...]}} instead of {"data": [...]}
            if isinstance(raw, dict):
                items = raw.get("items") or []
            else:
                items = raw
            yield from items

            pagination = (data.get("additional_data") or {}).get("pagination", {})
            if not pagination.get("more_items_in_collection", False):
                break
            params["start"] = pagination.get("next_start", params["start"] + limit)
            time.sleep(self.THROTTLE_DELAY)  # throttle between pages

    # ------------------------------------------------------------------
    # Public helpers (v2)
    # ------------------------------------------------------------------

    def get(self, path: str, params: dict | None = None) -> dict:
        return self._request("GET", path, params=params)

    def post(self, path: str, json: dict) -> dict:
        return self._request("POST", path, json=json)

    def patch(self, path: str, json: dict) -> dict:
        return self._request("PATCH", path, json=json)

    def delete(self, path: str) -> dict:
        return self._request("DELETE", path)

    def paginate(
        self,
        path: str,
        params: dict | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        return self._paginate(path, params=params, limit=limit)

    # ------------------------------------------------------------------
    # Public helpers (v1)
    # ------------------------------------------------------------------

    def v1_get(self, path: str, params: dict | None = None) -> dict:
        return self._v1_request("GET", path, params=params)

    def v1_post(self, path: str, json: dict) -> dict:
        return self._v1_request("POST", path, json=json)

    def v1_put(self, path: str, json: dict) -> dict:
        """v1 uses PUT for updates (not PATCH)."""
        return self._v1_request("PUT", path, json=json)

    def v1_delete(self, path: str) -> dict:
        return self._v1_request("DELETE", path)

    def v1_paginate(
        self,
        path: str,
        params: dict | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        return self._v1_paginate(path, params=params, limit=limit)


# ---------------------------------------------------------------------------
# Deals
# ---------------------------------------------------------------------------

class DealsResource:
    """
    CRUD + search for Pipedrive Deals.

    deal_status values: "open" | "won" | "lost" | "deleted"
    sort_by values:     "id" | "update_time" | "add_time"
    sort_direction:     "asc" | "desc"
    """

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        owner_id: int | None = None,
        person_id: int | None = None,
        org_id: int | None = None,
        pipeline_id: int | None = None,
        stage_id: int | None = None,
        status: str | None = None,          # open | won | lost | deleted
        updated_since: str | None = None,   # RFC3339
        updated_until: str | None = None,
        filter_id: int | None = None,
        include_fields: str | None = None,
        custom_fields: str | None = None,
        sort_by: str = "id",
        sort_direction: str = "asc",
        limit: int = 100,
    ) -> Iterator[dict]:
        """
        Iterate over all matching deals (handles pagination automatically).

        Example:
            for deal in client.deals.list(status="open", pipeline_id=1):
                print(deal["id"], deal["title"])
        """
        params = {
            "owner_id": owner_id,
            "person_id": person_id,
            "org_id": org_id,
            "pipeline_id": pipeline_id,
            "stage_id": stage_id,
            "status": status,
            "updated_since": updated_since,
            "updated_until": updated_until,
            "filter_id": filter_id,
            "include_fields": include_fields,
            "custom_fields": custom_fields,
            "sort_by": sort_by,
            "sort_direction": sort_direction,
        }
        yield from self._c.paginate("/deals", params=params, limit=limit)

    def get(
        self,
        deal_id: int,
        *,
        include_fields: str | None = None,
        custom_fields: str | None = None,
    ) -> dict:
        """Fetch a single deal by ID."""
        resp = self._c.get(
            f"/deals/{deal_id}",
            params={"include_fields": include_fields, "custom_fields": custom_fields},
        )
        return resp["data"]

    def search(
        self,
        term: str,
        *,
        fields: str | None = None,
        exact_match: bool = False,
        person_id: int | None = None,
        org_id: int | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """
        Full-text search across deals.

        fields: comma-separated subset of "custom_fields,notes,title"
        """
        params = {
            "term": term,
            "fields": fields,
            "exact_match": exact_match,
            "person_id": person_id,
            "org_id": org_id,
            "status": status,
        }
        yield from self._c.paginate("/deals/search", params=params, limit=limit)

    # --- Write --------------------------------------------------------------

    def create(
        self,
        title: str,
        *,
        owner_id: int | None = None,
        person_id: int | None = None,
        org_id: int | None = None,
        pipeline_id: int | None = None,
        stage_id: int | None = None,
        value: float | None = None,
        currency: str | None = None,
        status: str | None = None,
        expected_close_date: str | None = None,   # YYYY-MM-DD
        probability: float | None = None,
        lost_reason: str | None = None,
        visible_to: int | None = None,
        label_ids: list[int] | None = None,
        custom_fields: dict | None = None,
        **extra,
    ) -> dict:
        """
        Create a new deal. `title` is the only required field.

        Returns the created deal object.
        """
        body = {"title": title}
        for key, val in {
            "owner_id": owner_id,
            "person_id": person_id,
            "org_id": org_id,
            "pipeline_id": pipeline_id,
            "stage_id": stage_id,
            "value": value,
            "currency": currency,
            "status": status,
            "expected_close_date": expected_close_date,
            "probability": probability,
            "lost_reason": lost_reason,
            "visible_to": visible_to,
            "label_ids": label_ids,
            "custom_fields": custom_fields,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.post("/deals", json=body)["data"]

    def update(self, deal_id: int, **fields) -> dict:
        """
        Update any fields on a deal.

        Example:
            client.deals.update(42, title="New Title", status="won")

        Custom fields can be passed inside a `custom_fields` dict key.
        """
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.patch(f"/deals/{deal_id}", json=fields)["data"]

    def delete(self, deal_id: int) -> dict:
        """
        Soft-delete a deal (recoverable for 30 days).
        Returns {"id": <deleted_id>}.
        """
        return self._c.delete(f"/deals/{deal_id}")["data"]

    # --- Summary & Timeline (v1) -------------------------------------------

    def summary(
        self,
        *,
        status: str | None = None,
        filter_id: int | None = None,
        user_id: int | None = None,
        stage_id: int | None = None,
        pipeline_id: int | None = None,
    ) -> dict:
        """
        Get deal summary (total values and counts by currency, weighted values).
        Uses v1 endpoint: GET /v1/deals/summary
        """
        params = {
            "status": status,
            "filter_id": filter_id,
            "user_id": user_id,
            "stage_id": stage_id,
            "pipeline_id": pipeline_id,
        }
        return self._c.v1_get("/deals/summary", params=params)["data"]

    def timeline(
        self,
        start_date: str,
        interval: str = "month",
        amount: int = 3,
        field_key: str = "add_time",
        *,
        user_id: int | None = None,
        pipeline_id: int | None = None,
        filter_id: int | None = None,
        exclude_deals: bool = False,
        totals_convert_currency: str | None = None,
    ) -> dict:
        """
        Get deals timeline (deals grouped by time intervals).
        Uses v1 endpoint: GET /v1/deals/timeline

        start_date: YYYY-MM-DD
        interval: day | week | month | quarter
        amount: number of intervals (1-12)
        field_key: date field to use (add_time, update_time, won_time, etc.)
        """
        params = {
            "start_date": start_date,
            "interval": interval,
            "amount": amount,
            "field_key": field_key,
            "user_id": user_id,
            "pipeline_id": pipeline_id,
            "filter_id": filter_id,
            "exclude_deals": 1 if exclude_deals else 0,
            "totals_convert_currency": totals_convert_currency,
        }
        return self._c.v1_get("/deals/timeline", params=params)["data"]

    # --- Revenue by billing date (custom aggregation) ----------------------

    BILLING_DATE_FIELD = "f691421dded49b1c3c21614c939303925b67b2a2"

    def revenue_by_billing_date(
        self,
        billing_date_from: str,
        billing_date_to: str,
        *,
        pipeline_id: int | None = None,
        status: str = "won",
    ) -> dict:
        """
        Aggregate deal revenue filtered by the custom field
        "Datum der vsl. Rechnungsstellung" (expected billing date).

        Returns compact summary + deal list for liquidity planning.
        """
        matching_deals: list[dict] = []
        total_value = 0.0

        for deal in self.list(
            status=status,
            pipeline_id=pipeline_id,
            custom_fields=self.BILLING_DATE_FIELD,
        ):
            # v2 nests custom fields under deal["custom_fields"][key]
            cf = deal.get("custom_fields") or {}
            billing_date = cf.get(self.BILLING_DATE_FIELD)
            if not billing_date:
                continue

            billing_date_str = str(billing_date)[:10]  # normalize to YYYY-MM-DD

            if billing_date_from <= billing_date_str <= billing_date_to:
                value = float(deal.get("value") or 0)
                total_value += value
                matching_deals.append({
                    "id": deal["id"],
                    "title": deal.get("title", ""),
                    "value": value,
                    "billing_date": billing_date_str,
                    "owner_id": deal.get("owner_id"),
                })

        return {
            "total_value": round(total_value, 2),
            "count": len(matching_deals),
            "currency": "EUR",
            "deals": matching_deals,
        }


# ---------------------------------------------------------------------------
# Persons  (contacts / customers)
# ---------------------------------------------------------------------------

class PersonsResource:
    """CRUD + search for Pipedrive Persons (contacts)."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        owner_id: int | None = None,
        org_id: int | None = None,
        deal_id: int | None = None,
        filter_id: int | None = None,
        updated_since: str | None = None,
        updated_until: str | None = None,
        include_fields: str | None = None,
        custom_fields: str | None = None,
        sort_by: str = "id",
        sort_direction: str = "asc",
        limit: int = 100,
    ) -> Iterator[dict]:
        """Iterate over all matching persons (handles pagination automatically)."""
        params = {
            "owner_id": owner_id,
            "org_id": org_id,
            "deal_id": deal_id,
            "filter_id": filter_id,
            "updated_since": updated_since,
            "updated_until": updated_until,
            "include_fields": include_fields,
            "custom_fields": custom_fields,
            "sort_by": sort_by,
            "sort_direction": sort_direction,
        }
        yield from self._c.paginate("/persons", params=params, limit=limit)

    def get(
        self,
        person_id: int,
        *,
        include_fields: str | None = None,
        custom_fields: str | None = None,
    ) -> dict:
        """Fetch a single person by ID."""
        resp = self._c.get(
            f"/persons/{person_id}",
            params={"include_fields": include_fields, "custom_fields": custom_fields},
        )
        return resp["data"]

    def search(
        self,
        term: str,
        *,
        fields: str | None = None,
        exact_match: bool = False,
        org_id: int | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Full-text search across persons."""
        params = {
            "term": term,
            "fields": fields,
            "exact_match": exact_match,
            "org_id": org_id,
        }
        yield from self._c.paginate("/persons/search", params=params, limit=limit)

    # --- Write --------------------------------------------------------------

    def create(
        self,
        name: str,
        *,
        owner_id: int | None = None,
        org_id: int | None = None,
        emails: list[dict] | None = None,
        phones: list[dict] | None = None,
        visible_to: int | None = None,
        label_ids: list[int] | None = None,
        custom_fields: dict | None = None,
        **extra,
    ) -> dict:
        """
        Create a new person. `name` is required.

        emails / phones format:
            [{"value": "user@example.com", "primary": True, "label": "work"}]
        """
        body = {"name": name}
        for key, val in {
            "owner_id": owner_id,
            "org_id": org_id,
            "emails": emails,
            "phones": phones,
            "visible_to": visible_to,
            "label_ids": label_ids,
            "custom_fields": custom_fields,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.post("/persons", json=body)["data"]

    def update(self, person_id: int, **fields) -> dict:
        """
        Update any fields on a person.

        Example:
            client.persons.update(7, name="Jane Doe",
                                  emails=[{"value": "jane@acme.com", "primary": True}])
        """
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.patch(f"/persons/{person_id}", json=fields)["data"]

    def delete(self, person_id: int) -> dict:
        """Soft-delete a person. Returns {"id": <deleted_id>}."""
        return self._c.delete(f"/persons/{person_id}")["data"]


# ---------------------------------------------------------------------------
# Organizations
# ---------------------------------------------------------------------------

class OrganizationsResource:
    """CRUD + search for Pipedrive Organizations."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        owner_id: int | None = None,
        filter_id: int | None = None,
        updated_since: str | None = None,
        updated_until: str | None = None,
        include_fields: str | None = None,
        custom_fields: str | None = None,
        sort_by: str = "id",
        sort_direction: str = "asc",
        limit: int = 100,
    ) -> Iterator[dict]:
        """Iterate over all organizations (handles pagination automatically)."""
        params = {
            "owner_id": owner_id,
            "filter_id": filter_id,
            "updated_since": updated_since,
            "updated_until": updated_until,
            "include_fields": include_fields,
            "custom_fields": custom_fields,
            "sort_by": sort_by,
            "sort_direction": sort_direction,
        }
        yield from self._c.paginate("/organizations", params=params, limit=limit)

    def get(
        self,
        org_id: int,
        *,
        include_fields: str | None = None,
        custom_fields: str | None = None,
    ) -> dict:
        """Fetch a single organization by ID."""
        resp = self._c.get(
            f"/organizations/{org_id}",
            params={"include_fields": include_fields, "custom_fields": custom_fields},
        )
        return resp["data"]

    def search(
        self,
        term: str,
        *,
        fields: str | None = None,
        exact_match: bool = False,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Full-text search across organizations."""
        params = {"term": term, "fields": fields, "exact_match": exact_match}
        yield from self._c.paginate("/organizations/search", params=params, limit=limit)

    # --- Write --------------------------------------------------------------

    def create(
        self,
        name: str,
        *,
        owner_id: int | None = None,
        visible_to: int | None = None,
        label_ids: list[int] | None = None,
        custom_fields: dict | None = None,
        **extra,
    ) -> dict:
        """Create a new organization. `name` is required."""
        body = {"name": name}
        for key, val in {
            "owner_id": owner_id,
            "visible_to": visible_to,
            "label_ids": label_ids,
            "custom_fields": custom_fields,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.post("/organizations", json=body)["data"]

    def update(self, org_id: int, **fields) -> dict:
        """
        Update any fields on an organization.

        Example:
            client.organizations.update(3, name="ACME Corp")
        """
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.patch(f"/organizations/{org_id}", json=fields)["data"]

    def delete(self, org_id: int) -> dict:
        """Soft-delete an organization. Returns {"id": <deleted_id>}."""
        return self._c.delete(f"/organizations/{org_id}")["data"]


# ---------------------------------------------------------------------------
# Item Search  (v2 API — universal search)
# ---------------------------------------------------------------------------

class ItemSearchResource:
    """Universal search across deals, leads, persons, organizations, products."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def search(
        self,
        term: str,
        *,
        item_types: str | None = None,
        fields: str | None = None,
        exact_match: bool = False,
        include_fields: str | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """
        Search across all entity types.

        item_types: comma-separated, e.g. "deal,person,organization,product,lead"
        fields: restrict search to specific fields
        """
        params = {
            "term": term,
            "item_types": item_types,
            "fields": fields,
            "exact_match": exact_match,
            "include_fields": include_fields,
        }
        yield from self._c.paginate("/itemSearch", params=params, limit=limit)


# ---------------------------------------------------------------------------
# Deal Participants  (v1 API)
# ---------------------------------------------------------------------------

class DealParticipantsResource:
    """Manage person contacts linked to deals (v1 API)."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self, deal_id: int, *, limit: int = 100) -> Iterator[dict]:
        """List all participants (persons) on a deal."""
        yield from self._c.v1_paginate(f"/deals/{deal_id}/participants", limit=limit)

    def add(self, deal_id: int, person_id: int) -> dict:
        """Add a person as participant to a deal."""
        return self._c.v1_post(
            f"/deals/{deal_id}/participants", json={"person_id": person_id}
        )["data"]

    def remove(self, deal_id: int, deal_participant_id: int) -> dict:
        """Remove a participant from a deal by deal_participant_id (association ID)."""
        return self._c.v1_delete(
            f"/deals/{deal_id}/participants/{deal_participant_id}"
        )["data"]


# ---------------------------------------------------------------------------
# Products  (v2 API)
# ---------------------------------------------------------------------------

class ProductsResource:
    """CRUD + search for Pipedrive Products."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        owner_id: int | None = None,
        filter_id: int | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Iterate over all products."""
        params = {"owner_id": owner_id, "filter_id": filter_id}
        yield from self._c.paginate("/products", params=params, limit=limit)

    def get(self, product_id: int) -> dict:
        """Fetch a single product by ID."""
        return self._c.get(f"/products/{product_id}")["data"]

    def search(
        self,
        term: str,
        *,
        fields: str | None = None,
        exact_match: bool = False,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Full-text search across products."""
        params = {"term": term, "fields": fields, "exact_match": exact_match}
        yield from self._c.paginate("/products/search", params=params, limit=limit)

    # --- Write --------------------------------------------------------------

    def create(
        self,
        name: str,
        *,
        code: str | None = None,
        description: str | None = None,
        unit: str | None = None,
        tax: float | None = None,
        owner_id: int | None = None,
        prices: list[dict] | None = None,
        visible_to: int | None = None,
        **extra,
    ) -> dict:
        """
        Create a new product. `name` is required.

        prices format: [{"price": 100, "currency": "EUR", "cost": 50}]
        """
        body: Dict[str, Any] = {"name": name}
        for key, val in {
            "code": code,
            "description": description,
            "unit": unit,
            "tax": tax,
            "owner_id": owner_id,
            "prices": prices,
            "visible_to": visible_to,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.post("/products", json=body)["data"]

    def update(self, product_id: int, **fields) -> dict:
        """Update any fields on a product."""
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.patch(f"/products/{product_id}", json=fields)["data"]

    def delete(self, product_id: int) -> dict:
        """Delete a product."""
        return self._c.delete(f"/products/{product_id}")["data"]


# ---------------------------------------------------------------------------
# Deal-Products  (v2 API — sub-resource of deals)
# ---------------------------------------------------------------------------

class DealProductsResource:
    """Manage products attached to deals."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self, deal_id: int, *, limit: int = 100) -> Iterator[dict]:
        """List all products attached to a deal."""
        yield from self._c.paginate(f"/deals/{deal_id}/products", limit=limit)

    def add(
        self,
        deal_id: int,
        product_id: int,
        item_price: float,
        quantity: int = 1,
        *,
        discount: float | None = None,
        discount_type: str | None = None,
        tax: float | None = None,
        comments: str | None = None,
        **extra,
    ) -> dict:
        """Attach a product to a deal."""
        body: Dict[str, Any] = {
            "product_id": product_id,
            "item_price": item_price,
            "quantity": quantity,
        }
        for key, val in {
            "discount": discount,
            "discount_type": discount_type,
            "tax": tax,
            "comments": comments,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.post(f"/deals/{deal_id}/products", json=body)["data"]

    def update(self, deal_id: int, product_attachment_id: int, **fields) -> dict:
        """Update a product attachment on a deal."""
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.patch(
            f"/deals/{deal_id}/products/{product_attachment_id}", json=fields
        )["data"]

    def remove(self, deal_id: int, product_attachment_id: int) -> dict:
        """Remove a product from a deal."""
        return self._c.delete(
            f"/deals/{deal_id}/products/{product_attachment_id}"
        )["data"]


# ---------------------------------------------------------------------------
# Leads  (v1 for CRUD, v2 for search + convert)
# ---------------------------------------------------------------------------

class LeadsResource:
    """
    CRUD + search + convert for Pipedrive Leads.

    IMPORTANT: Lead IDs are UUIDs (strings), not integers!
    """

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        owner_id: int | None = None,
        person_id: int | None = None,
        organization_id: int | None = None,
        filter_id: int | None = None,
        sort: str | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Iterate over all leads (v1, offset pagination)."""
        params = {
            "owner_id": owner_id,
            "person_id": person_id,
            "organization_id": organization_id,
            "filter_id": filter_id,
            "sort": sort,
        }
        yield from self._c.v1_paginate("/leads", params=params, limit=limit)

    def get(self, lead_id: str) -> dict:
        """Fetch a single lead by UUID."""
        return self._c.v1_get(f"/leads/{lead_id}")["data"]

    def search(
        self,
        term: str,
        *,
        fields: str | None = None,
        exact_match: bool = False,
        person_id: int | None = None,
        organization_id: int | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Full-text search across leads (v2)."""
        params = {
            "term": term,
            "fields": fields,
            "exact_match": exact_match,
            "person_id": person_id,
            "organization_id": organization_id,
        }
        yield from self._c.paginate("/leads/search", params=params, limit=limit)

    # --- Write --------------------------------------------------------------

    def create(
        self,
        title: str,
        *,
        owner_id: int | None = None,
        person_id: int | None = None,
        organization_id: int | None = None,
        label_ids: list[str] | None = None,
        value: dict | None = None,
        expected_close_date: str | None = None,
        visible_to: int | None = None,
        **extra,
    ) -> dict:
        """
        Create a new lead. `title` is required.

        value format: {"amount": 1000, "currency": "EUR"}
        """
        body: Dict[str, Any] = {"title": title}
        for key, val in {
            "owner_id": owner_id,
            "person_id": person_id,
            "organization_id": organization_id,
            "label_ids": label_ids,
            "value": value,
            "expected_close_date": expected_close_date,
            "visible_to": visible_to,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.v1_post("/leads", json=body)["data"]

    def update(self, lead_id: str, **fields) -> dict:
        """Update any fields on a lead. Uses PATCH (v1 leads support PATCH)."""
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c._v1_request("PATCH", f"/leads/{lead_id}", json=fields)["data"]

    def delete(self, lead_id: str) -> dict:
        """Delete a lead by UUID."""
        return self._c.v1_delete(f"/leads/{lead_id}")["data"]

    def convert_to_deal(
        self,
        lead_id: str,
        *,
        pipeline_id: int | None = None,
        stage_id: int | None = None,
    ) -> dict:
        """
        Convert a lead into a deal (v2 endpoint).
        Returns conversion info with the new deal ID.
        """
        body: Dict[str, Any] = {}
        if pipeline_id is not None:
            body["pipeline_id"] = pipeline_id
        if stage_id is not None:
            body["stage_id"] = stage_id
        return self._c.post(f"/leads/{lead_id}/convert/deal", json=body)["data"]


# ---------------------------------------------------------------------------
# Pipelines & Stages  (v2 API)
# ---------------------------------------------------------------------------

class PipelinesResource:
    """Read-only access to Pipedrive Pipelines."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self, *, limit: int = 100) -> Iterator[dict]:
        """Iterate over all pipelines."""
        yield from self._c.paginate("/pipelines", limit=limit)

    def get(self, pipeline_id: int) -> dict:
        """Fetch a single pipeline by ID."""
        return self._c.get(f"/pipelines/{pipeline_id}")["data"]

    # --- Statistics (v1) ---------------------------------------------------

    def conversion_statistics(
        self,
        pipeline_id: int,
        start_date: str,
        end_date: str,
        *,
        user_id: int | None = None,
    ) -> dict:
        """
        Get stage-to-stage conversion rates and pipeline-to-close rate.
        Uses v1 endpoint: GET /v1/pipelines/{id}/conversion_statistics

        start_date / end_date: YYYY-MM-DD
        """
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "user_id": user_id,
        }
        return self._c.v1_get(
            f"/pipelines/{pipeline_id}/conversion_statistics", params=params
        )["data"]

    def movement_statistics(
        self,
        pipeline_id: int,
        start_date: str,
        end_date: str,
        *,
        user_id: int | None = None,
    ) -> dict:
        """
        Get deal movement statistics (new, won, lost, moved between stages).
        Uses v1 endpoint: GET /v1/pipelines/{id}/movement_statistics

        start_date / end_date: YYYY-MM-DD
        """
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "user_id": user_id,
        }
        return self._c.v1_get(
            f"/pipelines/{pipeline_id}/movement_statistics", params=params
        )["data"]


class StagesResource:
    """Read-only access to Pipedrive Stages."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self, *, pipeline_id: int | None = None, limit: int = 100) -> Iterator[dict]:
        """Iterate over stages, optionally filtered by pipeline."""
        params = {"pipeline_id": pipeline_id}
        yield from self._c.paginate("/stages", params=params, limit=limit)

    def get(self, stage_id: int) -> dict:
        """Fetch a single stage by ID."""
        return self._c.get(f"/stages/{stage_id}")["data"]


# ---------------------------------------------------------------------------
# Notes  (v1 API)
# ---------------------------------------------------------------------------

class NotesResource:
    """CRUD for Pipedrive Notes (attached to deals, persons, or organizations). Uses v1 API."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        deal_id: int | None = None,
        person_id: int | None = None,
        org_id: int | None = None,
        lead_id: str | None = None,
        pinned_to_deal_flag: bool | None = None,
        pinned_to_person_flag: bool | None = None,
        pinned_to_organization_flag: bool | None = None,
        sort: str | None = None,
        limit: int = 100,
    ) -> Iterator[dict]:
        """Iterate over notes, optionally filtered by linked entity."""
        params = {
            "deal_id": deal_id,
            "person_id": person_id,
            "org_id": org_id,
            "lead_id": lead_id,
            "pinned_to_deal_flag": 1 if pinned_to_deal_flag else None,
            "pinned_to_person_flag": 1 if pinned_to_person_flag else None,
            "pinned_to_organization_flag": 1 if pinned_to_organization_flag else None,
            "sort": sort,
        }
        yield from self._c.v1_paginate("/notes", params=params, limit=limit)

    def get(self, note_id: int) -> dict:
        """Fetch a single note by ID."""
        return self._c.v1_get(f"/notes/{note_id}")["data"]

    # --- Write --------------------------------------------------------------

    def create(
        self,
        content: str,
        *,
        deal_id: int | None = None,
        person_id: int | None = None,
        org_id: int | None = None,
        lead_id: str | None = None,
        pinned_to_deal_flag: bool = False,
        pinned_to_person_flag: bool = False,
        pinned_to_organization_flag: bool = False,
        **extra,
    ) -> dict:
        """
        Create a note. `content` is required, plus at least one of
        deal_id, person_id, org_id, or lead_id.
        """
        body: Dict[str, Any] = {"content": content}
        for key, val in {
            "deal_id": deal_id,
            "person_id": person_id,
            "org_id": org_id,
            "lead_id": lead_id,
            "pinned_to_deal_flag": 1 if pinned_to_deal_flag else None,
            "pinned_to_person_flag": 1 if pinned_to_person_flag else None,
            "pinned_to_organization_flag": 1 if pinned_to_organization_flag else None,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c.v1_post("/notes", json=body)["data"]

    def update(self, note_id: int, **fields) -> dict:
        """Update a note. Common fields: content, pinned flags."""
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.v1_put(f"/notes/{note_id}", json=fields)["data"]

    def delete(self, note_id: int) -> dict:
        """Delete a note by ID."""
        return self._c.v1_delete(f"/notes/{note_id}")["data"]


# ---------------------------------------------------------------------------
# Activities  (calls, meetings, tasks, etc.)
# ---------------------------------------------------------------------------

class ActivitiesResource:
    """CRUD for Pipedrive Activities (calls, meetings, tasks, emails, etc.)."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    # --- Read ---------------------------------------------------------------

    def list(
        self,
        *,
        owner_id: int | None = None,
        deal_id: int | None = None,
        lead_id: str | None = None,
        person_id: int | None = None,
        org_id: int | None = None,
        done: bool | None = None,
        type: str | None = None,
        updated_since: str | None = None,
        sort_by: str = "due_date",
        sort_direction: str = "asc",
        limit: int = 100,
    ) -> Iterator[dict]:
        """Iterate over all matching activities (handles pagination automatically)."""
        params = {
            "owner_id": owner_id,
            "deal_id": deal_id,
            "lead_id": lead_id,
            "person_id": person_id,
            "org_id": org_id,
            "done": done,
            "type": type,
            "updated_since": updated_since,
            "sort_by": sort_by,
            "sort_direction": sort_direction,
        }
        yield from self._c.paginate("/activities", params=params, limit=limit)

    def get(self, activity_id: int) -> dict:
        """Fetch a single activity by ID."""
        return self._c.get(f"/activities/{activity_id}")["data"]

    # --- Write --------------------------------------------------------------

    def create(
        self,
        subject: str,
        type: str = "call",
        *,
        owner_id: int | None = None,
        deal_id: int | None = None,
        lead_id: str | None = None,
        person_id: int | None = None,
        org_id: int | None = None,
        due_date: str | None = None,
        due_time: str | None = None,
        duration: str | None = None,
        note: str | None = None,
        done: bool | None = None,
        busy: bool | None = None,
        location: str | None = None,
        **extra,
    ) -> dict:
        """
        Create a new activity. `subject` is the title.

        type: call | meeting | task | deadline | email | lunch (or custom)
        due_date: YYYY-MM-DD
        due_time: HH:MM
        duration: HH:MM
        """
        body = {"subject": subject, "type": type}
        for key, val in {
            "user_id": owner_id,
            "deal_id": deal_id,
            "lead_id": lead_id,
            "person_id": person_id,
            "org_id": org_id,
            "due_date": due_date,
            "due_time": due_time,
            "duration": duration,
            "note": note,
            "done": done,
            "busy_flag": busy,
            "location": location,
            **extra,
        }.items():
            if val is not None:
                body[key] = val
        return self._c._v1_request("POST", "/activities", json=body)["data"]

    def update(self, activity_id: int, **fields) -> dict:
        """Update any fields on an activity."""
        if not fields:
            raise ValueError("At least one field must be provided to update.")
        return self._c.patch(f"/activities/{activity_id}", json=fields)["data"]

    def delete(self, activity_id: int) -> dict:
        """Delete an activity."""
        return self._c.delete(f"/activities/{activity_id}")["data"]


class ActivityTypesResource:
    """Read-only access to Pipedrive activity types."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self) -> list[dict]:
        """Return all activity types configured in this Pipedrive instance."""
        return self._c._v1_request("GET", "/activityTypes")["data"]


class UsersResource:
    """Read-only access to Pipedrive users (team members)."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self) -> list[dict]:
        """Return all users in the Pipedrive account."""
        return self._c._v1_request("GET", "/users")["data"]

    def get(self, user_id: int) -> dict:
        """Fetch a single user by ID."""
        return self._c._v1_request("GET", f"/users/{user_id}")["data"]


# ---------------------------------------------------------------------------
# Deal Fields  (v2 API — metadata about custom fields)
# ---------------------------------------------------------------------------

class DealFieldsResource:
    """Read-only access to deal field definitions."""

    def __init__(self, client: PipedriveClient):
        self._c = client

    def list(self, *, limit: int = 500) -> Iterator[dict]:
        """Return all deal field definitions (including custom fields)."""
        yield from self._c.paginate("/dealFields", limit=limit)

    def get(self, field_code: str) -> dict:
        """Fetch a single deal field by its hash code."""
        return self._c.get(f"/dealFields/{field_code}")["data"]


# ---------------------------------------------------------------------------
# Top-level connector  (the main entry point)
# ---------------------------------------------------------------------------

class Pipedrive:
    """
    Pipedrive API v2 connector.

    Usage
    -----
        from pipedrive import Pipedrive

        pd = Pipedrive(api_key="YOUR_KEY")
        # or: pd = Pipedrive()  # reads PIPEDRIVE_API_KEY env var

        # --- Deals ---
        for deal in pd.deals.list(status="open"):
            print(deal["id"], deal["title"], deal["value"])

        new_deal = pd.deals.create("Big Opportunity", value=50000, currency="EUR")
        pd.deals.update(new_deal["id"], stage_id=3, probability=75)
        pd.deals.delete(new_deal["id"])

        # --- Persons ---
        for person in pd.persons.list(org_id=5):
            print(person["name"])

        new_person = pd.persons.create(
            "Jane Doe",
            emails=[{"value": "jane@acme.com", "primary": True, "label": "work"}],
            phones=[{"value": "+49123456789", "primary": True}],
        )
        pd.persons.update(new_person["id"], org_id=5)

        # --- Organizations ---
        org = pd.organizations.create("ACME Corp")
        results = list(pd.organizations.search("ACME"))
    """

    def __init__(self, api_key: str | None = None):
        self._client = PipedriveClient(api_key=api_key)
        self.deals = DealsResource(self._client)
        self.persons = PersonsResource(self._client)
        self.organizations = OrganizationsResource(self._client)
        self.activities = ActivitiesResource(self._client)
        self.notes = NotesResource(self._client)
        self.pipelines = PipelinesResource(self._client)
        self.stages = StagesResource(self._client)
        self.leads = LeadsResource(self._client)
        self.products = ProductsResource(self._client)
        self.deal_products = DealProductsResource(self._client)
        self.deal_participants = DealParticipantsResource(self._client)
        self.item_search = ItemSearchResource(self._client)
        self.activity_types = ActivityTypesResource(self._client)
        self.users = UsersResource(self._client)
        self.deal_fields = DealFieldsResource(self._client)
