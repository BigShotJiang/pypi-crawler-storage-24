from enum import StrEnum


"""Зоны действия пропуска (русские подписи).

Раньше использовался ``class PassAllowedZone(str, Enum)`` с кастомным
``__get_pydantic_core_schema__`` и ``serialization=to_string_ser_schema()``:
для такого типа в Python ``str(member)`` даёт ``"PassAllowedZone.MKAD"``, не
значение ``"МКАД"``, и в JSON уходила некорректная строка.

Наследование от ``StrEnum`` даёт нормальное ``str(member) == member.value`` и
стандартную схему Pydantic без ручного ``pydantic_core`` — сериализация в API
совпадает с человекочитаемым значением enum.
"""
class PassAllowedZone(StrEnum):
    MKAD = "МКАД"
    SK = "СК"
    TTK = "ТТК"
    MO = "МО"

    @classmethod
    def _missing_(cls, value: object) -> "PassAllowedZone | None":
        if not isinstance(value, str):
            return None
        v = value.lower()
        if v == "московская область":
            return cls.MO
        if v == "садовое кольцо":
            return cls.SK
        return None


class PassAllowedZoneEn(StrEnum):
    MO = "MO"
    MKAD = "MKAD"
    TTK = "TTK"
    SK = "SK"
    NoZone = "NoZone"
