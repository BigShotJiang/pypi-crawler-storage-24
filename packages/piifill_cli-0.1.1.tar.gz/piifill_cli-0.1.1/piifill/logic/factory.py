from .parsers import IParser, TextParser, JSONParser, CSVParser, SQLParser, PDFParser, DocxParser, XLSXParser, JSONLParser
from .vision import ImageParser

class FileProcessor:
    """Factory to create the correct parser based on file extension."""
    _parsers = {
        'txt': TextParser(),
        'json': JSONParser(),
        'jsonl': JSONLParser(),
        'csv': CSVParser(),
        'sql': SQLParser(),
        'pdf': PDFParser(),
        'docx': DocxParser(),
        'png': ImageParser(),
        'jpg': ImageParser(),
        'jpeg': ImageParser(),
        'xlsx': XLSXParser()
    }
    
    @staticmethod
    def get_parser(extension: str) -> IParser:
        """
        Returns a parser instance for the given extension.
        Falls back to TextParser.
        """
        return FileProcessor._parsers.get(extension.lower().replace('.', ''), TextParser())
