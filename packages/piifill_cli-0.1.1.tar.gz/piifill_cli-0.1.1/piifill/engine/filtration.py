import re
from typing import Dict, List, Pattern, Optional, Set
from pydantic import BaseModel

class PIIEntity(BaseModel):
    value: str
    entity_type: str
    start: int
    end: int

class PatternRegistry:
    """
    Registry for managing PII patterns across different categories and countries.
    Optimized for memory and lookup speed.
    """
    def __init__(self):
        self._patterns: Dict[str, Dict[str, Pattern]] = {
            "GLOBAL": {},    # Multi-country patterns (Email, IP, etc.)
            "AMERICAS": {},  # North/South America
            "EMEA": {},      # Europe, Middle East, Africa
            "APAC": {},      # Asia Pacific
        }
        self._compiled_cache: Optional[Dict[str, Pattern]] = None

    def register(self, category: str, type_name: str, pattern: str, flags: int = 0):
        """Registers a new PII pattern in a specific category."""
        if category not in self._patterns:
            self._patterns[category] = {}
        # Ensure we don't accidentally use re.IGNORECASE for critical identifiers
        self._patterns[category][type_name] = re.compile(pattern, flags)
        self._compiled_cache = None # Invalidate cache

    def get_all_patterns(self) -> Dict[str, Pattern]:
        """Returns a flattened dictionary of all registered patterns."""
        if self._compiled_cache is not None:
            return self._compiled_cache
        
        all_pats = {}
        for cat_pats in self._patterns.values():
            all_pats.update(cat_pats)
        self._compiled_cache = all_pats
        return all_pats

class PIIDetector:
    """
    Professional-grade PII detection engine using a modular PatternRegistry.
    Adheres to PIIFILL high-performance and type-safety standards.
    """
    
    # Mapping of common language codes to their primary regions
    _LANG_REGION_MAP = {
        "en": ["GLOBAL", "AMERICAS", "EMEA", "APAC"], # English is global
        "de": ["GLOBAL", "EMEA"],
        "es": ["GLOBAL", "EMEA", "AMERICAS"],
        "fr": ["GLOBAL", "EMEA", "AMERICAS"],
        "hi": ["GLOBAL", "APAC"],
        "pt": ["GLOBAL", "AMERICAS", "EMEA"],
        "zh": ["GLOBAL", "APAC"],
        "ja": ["GLOBAL", "APAC"],
    }
    
    def __init__(self):
        self.registry = PatternRegistry()
        self._initialize_core_patterns()

    def _initialize_core_patterns(self):
        # --- CATEGORY: CONTACT & INTERNET (GLOBAL) ---
        g = "GLOBAL"
        ign = re.IGNORECASE
        self.registry.register(g, "EMAIL", r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', ign)
        self.registry.register(g, "PHONE_GLOBAL", r'(?<!\d)\+(?:[0-9] ?){6,14}[0-9](?!\d)')
        self.registry.register(g, "IPV4", r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b')
        self.registry.register(g, "IPV6", r'\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b', ign)
        self.registry.register(g, "MAC_ADDRESS", r'\b([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})\b', ign)
        
        # --- CATEGORY: FINANCIAL (GLOBAL) ---
        self.registry.register(g, "CREDIT_CARD", r'\b(?:\d{4}[-\s]?){3}\d{4}\b')
        self.registry.register(g, "IBAN", r'\b[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}\b') # Critical: case-sensitive
        self.registry.register(g, "SWIFT_BIC", r'\b[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?\b') # Critical: case-sensitive
        self.registry.register(g, "CRYPTO_BTC", r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b')
        self.registry.register(g, "CRYPTO_ETH", r'\b0x[a-fA-F0-9]{40}\b', ign)

        # --- REGION: AMERICAS ---
        am = "AMERICAS"
        self.registry.register(am, "SSN_US", r'\b\d{3}-\d{2}-\d{4}\b')
        self.registry.register(am, "PASSPORT_US", r'\b[0-9]{9}\b')
        self.registry.register(am, "SIN_CA", r'\b\d{3} \d{3} \d{3}\b')
        self.registry.register(am, "CPF_BR", r'\b\d{3}\.\d{3}\.\d{3}-\d{2}\b')
        self.registry.register(am, "CURP_MX", r'\b[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d\b')
        
        # --- REGION: APAC (Asia Pacific) ---
        ap = "APAC"
        self.registry.register(ap, "AADHAAR_IN", r'\b[2-9][0-9]{3}\s?[0-9]{4}\s?[0-9]{4}\b')
        self.registry.register(ap, "PAN_IN", r'\b[A-Z]{5}[0-9]{4}[A-Z]\b')
        self.registry.register(ap, "PASSPORT_IN", r'\b[A-Z][0-9]{7}\b')
        self.registry.register(ap, "TFN_AU", r'\b\d{3} \d{3} \d{3}\b')
        self.registry.register(ap, "HKID_HK", r'\b[A-Z]{1,2}[0-9]{6}\([0-9A]\)\b')
        self.registry.register(ap, "NRIC_SG", r'\b[STFG][0-9]{7}[A-Z]\b')
        self.registry.register(ap, "RESIDENT_ID_CN", r'\b[1-9]\d{5}(?:18|19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[1-2]\d|3[0-1])\d{3}[\dXx]\b')
        self.registry.register(ap, "MYKAD_MY", r'\b\d{6}-\d{2}-\d{4}\b')
        self.registry.register(ap, "ARC_TW", r'\b[A-Z][A-D0-9][0-9]{8}\b')
        self.registry.register(ap, "PASSPORT_JP", r'\b[A-Z]{2}[0-9]{7}\b')

        # --- REGION: EMEA (Europe, Middle East, Africa) ---
        em = "EMEA"
        self.registry.register(em, "NINO_UK", r'\b[A-CEGHJ-PR-TW-Z]{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b')
        self.registry.register(em, "PPSN_IE", r'\b\d{7}[A-W][A-Z]?\b')
        self.registry.register(em, "NIE_ES", r'\b[XYZ][0-9]{7}[A-Z]\b')
        self.registry.register(em, "DNI_ES", r'\b[0-9]{8}[A-Z]\b')
        self.registry.register(em, "NIR_FR", r'\b[12]\s?\d{2}\s?(?:0[1-9]|1[0-2])\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}\b')
        self.registry.register(em, "STEUERID_DE", r'\b\d{11}\b')
        self.registry.register(em, "PESEL_PL", r'\b\d{11}\b')
        self.registry.register(em, "CODICE_FISCALE_IT", r'\b[A-Z]{6}\d{2}[A-EHLMPR-T]\d{2}[A-Z]\d{3}[A-Z]\b')
        self.registry.register(em, "CNP_RO", r'\b[1-9]\d{12}\b')
        self.registry.register(em, "BSN_NL", r'\b\d{8,9}\b')
        self.registry.register(em, "EMIRATES_ID_UAE", r'\b784-\d{4}-\d{7}-\d\b')
        self.registry.register(em, "ID_SA", r'\b1\d{9}\b')
        self.registry.register(em, "ID_ZA", r'\b\d{13}\b')

    def detect(self, text: str, lang: Optional[str] = None) -> List[PIIEntity]:
        """Scans text and returns isolated PII entities, handling overlaps."""
        entities = []
        
        # Determine which categories to scan based on language
        active_categories = self._LANG_REGION_MAP.get(lang, ["GLOBAL", "AMERICAS", "EMEA", "APAC"])
        if "GLOBAL" not in active_categories:
            active_categories.append("GLOBAL")

        for cat in active_categories:
            cat_patterns = self.registry._patterns.get(cat, {})
            for entity_type, pattern in cat_patterns.items():
                for match in pattern.finditer(text):
                    entities.append(PIIEntity(
                        value=match.group(),
                        entity_type=entity_type,
                        start=match.start(),
                        end=match.end()
                    ))
                
        if not entities:
            return []

        # Hande Overlaps: Prioritize longer matches
        entities.sort(key=lambda x: x.start)
        filtered = []
        
        current = entities[0]
        for next_ent in entities[1:]:
            if next_ent.start < current.end:
                # Overlap detected
                if (next_ent.end - next_ent.start) > (current.end - current.start):
                    current = next_ent # Keep the longer one
            else:
                filtered.append(current)
                current = next_ent
        filtered.append(current)
        
        return filtered
