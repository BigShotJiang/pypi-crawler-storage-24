from typing import List, Optional
from .filtration import PIIDetector, PIIEntity
from .vault import PIIMasker
from ..logic.linguistics import language_service

class FiltrationManager:
    """Service facade that combines detecting and masking."""
    
    def __init__(self):
        self.detector = PIIDetector()
        self.masker = PIIMasker()
        self.last_detection_count = 0
        self.last_detection_breakdown = {}
        self.last_processed_chars = 0

    def detect(self, text: str, lang: Optional[str] = None) -> List[PIIEntity]:
        """Proxy to detector with optional language hints."""
        # Auto-detect language if not provided
        if not lang:
            lang = language_service.detect_language(text)
        return self.detector.detect(text, lang=lang)

    def reset_session(self):
        """Reset token mapping session in masker."""
        self.masker.reset_session()
        self.last_detection_count = 0
        self.last_detection_breakdown = {}
        self.last_processed_chars = 0

    def sanitize(self, text: str, mode: str = "redact", lang: Optional[str] = None) -> str:
        """Sanitize text by detecting and then replacing entities."""
        # Detect language if not provided to adjust context
        if not lang:
            lang = language_service.detect_language(text)
            
        entities = self.detect(text, lang=lang)
        self.last_processed_chars += len(text)
        
        # Calculate breakdown
        for ent in entities:
            self.last_detection_count += 1
            self.last_detection_breakdown[ent.entity_type] = self.last_detection_breakdown.get(ent.entity_type, 0) + 1
        
        # Sort in reverse to replace from end to front
        entities.sort(key=lambda x: x.start, reverse=True)

        mode = mode.upper()
        sanitized_text = text
        
        for ent in entities:
            replacement = ""
            if mode == "REDACT":
                replacement = "[REDACTED]"
            elif mode == "TOKENIZE":
                replacement = self.masker.get_token(ent.value, ent.entity_type)
            elif mode == "MASK":
                replacement = self.masker.apply_masking(ent.value, ent.entity_type)
            else:
                replacement = "[REDACTED]"

            sanitized_text = sanitized_text[:ent.start] + replacement + sanitized_text[ent.end:]

        return sanitized_text

    def mask_entities(self, text: str, entities: List[PIIEntity], mode: str = "redact") -> str:
        """Apply masking to a specific list of entities in text."""
        self.last_processed_chars += len(text)
        # Sort in reverse to replace from end to front
        sorted_entities = sorted(entities, key=lambda x: x.start, reverse=True)
        mode = mode.upper()
        sanitized_text = text
        
        for ent in sorted_entities:
            replacement = ""
            if mode == "REDACT":
                replacement = "[REDACTED]"
            elif mode == "TOKENIZE":
                replacement = self.masker.get_token(ent.value, ent.entity_type)
            elif mode == "MASK":
                replacement = self.masker.apply_masking(ent.value, ent.entity_type)
            else:
                replacement = "[REDACTED]"

            sanitized_text = sanitized_text[:ent.start] + replacement + sanitized_text[ent.end:]
            
            # Update metrics
            self.last_detection_count += 1
            self.last_detection_breakdown[ent.entity_type] = self.last_detection_breakdown.get(ent.entity_type, 0) + 1

        return sanitized_text

    def fast_sanitize(self, text: str, entity_type: str, mode: str = "redact") -> str:
        """Sanitize text directly for a known entity type without full detection."""
        mode = mode.upper()
        if mode == "REDACT":
            return "[REDACTED]"
        elif mode == "TOKENIZE":
            return self.masker.get_token(text, entity_type)
        elif mode == "MASK":
            return self.masker.apply_masking(text, entity_type)
        return "[REDACTED]"

    def get_session_report(self) -> dict:
        """Generate a PIIFILL-grade security report locally."""
        weighted_sum = 0
        weights = {
            # Critical (10)
            "SSN_US": 10, "AADHAAR_IN": 10, "PRIVATE_KEY": 10, "PASSWORD": 10, 
            "CREDIT_CARD": 10, "CPF_BR": 10, "RESIDENT_ID_CN": 10, "NRIC_SG": 10,
            "PPSN_IE": 10, "STEUERID_DE": 10, "PESEL_PL": 10, "ID_ZA": 10,
            
            # High (8-9)
            "PAN_IN": 9, "PASSPORT_US": 9, "PASSPORT_IN": 9, "IBAN": 9, "CRYPTO_BTC": 9,
            "SIN_CA": 9, "CURP_MX": 8, "DNI_ES": 9, "NIE_ES": 9, "NIR_FR": 9,
            
            # Moderate (5-7)
            "PHONE_GLOBAL": 5, "SWIFT_BIC": 6, "BANK_ACCOUNT": 7, "VIN": 5,
            
            # Low (2-4)
            "EMAIL": 3, "IPV4": 2, "IPV6": 2, "MAC_ADDRESS": 2
        }
        for ptype, count in self.last_detection_breakdown.items():
            weighted_sum += weights.get(ptype, 5) * count
            
        total = self.last_processed_chars if self.last_processed_chars > 0 else 1
        # Normalize score based on text density and PII types
        score = min(100, int((weighted_sum / (total / 100)) * 20))
        
        if score < 15: grade, risk = "A", "Minimal"
        elif score < 40: grade, risk = "B", "Low"
        elif score < 70: grade, risk = "C", "Moderate"
        else: grade, risk = "F", "Critical"
        
        return {
            "pii_count": self.last_detection_count,
            "pii_breakdown": self.last_detection_breakdown,
            "risk_score": score,
            "risk_grade": grade,
            "risk_level": risk
        }

# Global service instance for efficiency
filtration_manager = FiltrationManager()
