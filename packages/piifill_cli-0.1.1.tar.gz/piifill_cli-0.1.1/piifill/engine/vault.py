import re
import hashlib
from typing import Dict, List
from pydantic import BaseModel

class PIIMasker:
    """Handles logic for masking, redacting, and tokenizing PII values."""
    
    def __init__(self):
        self._token_map: Dict[str, str] = {}
        
    def reset_session(self):
        self._token_map = {}

    def get_token(self, value: str, entity_type: str = "PII") -> str:
        if value not in self._token_map:
            hash_int = int(hashlib.md5(value.encode()).hexdigest(), 16)
            token_num = str(hash_int)[-5:]
            self._token_map[value] = f"<{entity_type}_{token_num}>"
        return self._token_map[value]

    def apply_masking(self, value: str, entity_type: str) -> str:
        entity_type_upper = entity_type.upper()

        if "PHONE" in entity_type_upper or "FAX" in entity_type_upper:
            numeric_only = re.sub(r'\D', '', value)
            if len(numeric_only) <= 2: return 'X' * len(value)
            
            masked = ""
            digits_found = 0
            for char in reversed(value):
                if char.isdigit():
                    if digits_found < 2:
                        masked = char + masked
                    else:
                        masked = 'X' + masked
                    digits_found += 1
                else:
                    masked = char + masked
            return masked

        elif "EMAIL" in entity_type_upper:
            if "@" not in value: return "*" * len(value)
            parts = value.split("@", 1)
            user = parts[0]
            domain = parts[1]
            if not user: return f"*@{domain}"
            return f"{user[0]}{'*' * (len(user)-1)}@{domain}"

        elif "CARD" in entity_type_upper and ("CREDIT" in entity_type_upper or "DEBIT" in entity_type_upper):
            clean_val = re.sub(r'\D', '', value)
            last_4 = clean_val[-4:] if len(clean_val) >= 4 else clean_val
            masked = ""
            digits_rev_found = 0
            for char in reversed(value):
                if char.isdigit():
                    if digits_rev_found < 4:
                        masked = char + masked
                    else:
                        masked = 'X' + masked
                    digits_rev_found += 1
                else:
                    masked = char + masked
            return masked

        elif "BANK" in entity_type_upper or "ACCOUNT" in entity_type_upper or next((x for x in ["IBAN", "SWIFT_BIC", "ROUTING"] if x in entity_type_upper), None):
            if len(value) <= 3: return 'X' * len(value)
            return 'X' * (len(value) - 3) + value[-3:]

        elif "IPV4" in entity_type_upper or "IP_ADDRESS" in entity_type_upper:
            parts = value.split('.')
            if len(parts) == 4:
                return f"XXX.XXX.XXX.{parts[3]}"
            return "XXX.XXX.XXX.XXX"
            
        elif "IPV6" in entity_type_upper or "MAC_ADDRESS" in entity_type_upper:
            return "***:***:***:***"

        elif "ADDRESS" in entity_type_upper and not any(x in entity_type_upper for x in ["IP", "MAC", "BITCOIN", "ETHEREUM"]):
            return "*" * len(value)

        elif "AADHAAR" in entity_type_upper:
            clean_val = re.sub(r'\s', '', value)
            return "XXXX-XXXX-" + clean_val[-4:]

        elif any(x in entity_type_upper for x in ["PASSPORT", "VOTER_ID", "LICENSE", "PAN_CARD", "SSN", "NATIONAL_ID", "SIN", "TFN"]):
            if len(value) <= 2: return 'X' * len(value)
            return 'X' * (len(value) - 2) + value[-2:]

        if len(value) <= 2: return '*' * len(value)
        return '*' * (len(value) - 2) + value[-2:]
