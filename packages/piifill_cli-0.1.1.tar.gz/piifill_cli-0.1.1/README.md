# PIIFILL CLI
**Automated Enterprise-Grade Local PII Sanitization CLI.**

PIIFILL is a high-performance terminal utility for detecting and masking sensitive data locally and securely.

## ⚡ Quick Start

### 1. Installation
Install the CLI from PyPI:
```bash
pip install piifill-cli
```

Or install in editable mode for local development:
```bash
cd piifill
pip install -e .
```

### 2. Basic Usage
Scan and mask PII in a file:
```bash
piifill mask path/to/file.json
```

## 🛠 Command Reference

### `piifill mask`
Securely mask sensitive data in assets.
- `piifill mask <path>`: Direct masking of a file.
- `piifill mask -o <output_path>`: Specify custom output path.
- `--mode`: Sanitization strategy (`mask`, `redact`, `tokenize`).
- `--local`: Rapid local directory protection (scans current directory by default).

### `piifill scan`
Detect PII in a file or directory without modifying it.
- `piifill scan <path>`: Scan an asset.
- `--recursive`: Scan entire directories.

### `piifill config`
Manage PIIFILL configuration.

### `piifill version`
Show PIIFILL version information.

## 📊 Security Analysis
Every sanitization run performs high-fidelity risk analysis:
- **Security Grading**: A-F scale based on PII density.
- **Risk Scoring**: 0-100 technical protection score.
- **Entity Breakdown**: Categorical distribution (emails, SSNs, credit cards, etc.).

## 🧪 Verification
Run the CLI against sample data to verify detection:
```bash
piifill scan ./test_data/
```

## 📜 License
See LICENSE for details.
