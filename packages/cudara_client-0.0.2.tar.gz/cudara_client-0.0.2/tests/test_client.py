import base64
import json
from pathlib import Path
from typing import Any

import httpx

from cudara_client import CudaraClient, Message


def test_generate_payload(respx_mock: Any) -> None:
    """Test that the generate method sends the correct JSON payload."""
    client = CudaraClient("http://localhost:8000")
    route = respx_mock.post("http://localhost:8000/api/generate").mock(
        return_value=httpx.Response(200, json={"model": "test-model", "response": "Sky is blue", "done": True})
    )

    client.generate("test-model", "Why is the sky blue?", think=True, format="json")

    assert route.called
    payload = json.loads(route.calls.last.request.content)
    assert payload["think"] is True
    assert payload["format"] == "json"


def test_chat_with_images(respx_mock: Any) -> None:
    """Test that chat messages correctly include base64 image strings."""
    client = CudaraClient()
    route = respx_mock.post("http://localhost:8000/api/chat").mock(
        return_value=httpx.Response(200, json={"model": "vlm", "message": {"content": "A cat"}, "done": True})
    )

    client.chat("vlm", [Message(role="user", content="What is this?", images=["base64-string"])])

    payload = json.loads(route.calls.last.request.content)
    assert payload["messages"][0]["images"] == ["base64-string"]


def test_embed_rerank(respx_mock: Any) -> None:
    """Test that embedding options are correctly passed for reranking tasks."""
    client = CudaraClient()
    route = respx_mock.post("http://localhost:8000/api/embed").mock(
        return_value=httpx.Response(200, json={"model": "reranker", "scores": [0.9, 0.1]})
    )

    client.embed("reranker", ["query", "doc1", "doc2"], options={"is_rerank": True})

    payload = json.loads(route.calls.last.request.content)
    assert payload["options"]["is_rerank"] is True


def test_transcribe_helper(respx_mock: Any, tmp_path: Path) -> None:
    """Test the transcription helper encodes files and sets is_audio option."""
    audio_file = tmp_path / "test.opus"
    audio_file.write_bytes(b"dummy-audio-data")

    client = CudaraClient()
    route = respx_mock.post("http://localhost:8000/api/generate").mock(
        return_value=httpx.Response(200, json={"model": "whisper", "response": "Hello world", "done": True})
    )

    client.transcribe("whisper", audio_file)

    payload = json.loads(route.calls.last.request.content)
    assert payload["options"]["is_audio"] is True
    assert len(payload["images"]) == 1
    assert payload["images"][0] == base64.b64encode(b"dummy-audio-data").decode()
