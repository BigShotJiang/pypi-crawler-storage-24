"""
cudara_client: The definitive Python client for the Cudara API.
"""

from __future__ import annotations

import base64
import json
import threading
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Literal, Union, cast

import httpx


@dataclass
class Message:
    """Represents a single message in a conversation thread."""

    role: Literal["system", "user", "assistant", "tool"]
    content: str
    images: list[str] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert the Message instance to a dictionary for API payloads."""
        d: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.images:
            d["images"] = self.images
        return d


@dataclass
class Response:
    """Standardized response object for Cudara generation and chat endpoints."""

    content: str
    model: str
    thinking: str | None = None
    done: bool = True
    done_reason: str | None = None
    total_duration_ns: int = 0
    eval_count: int = 0
    raw: dict[str, Any] | None = None

    @property
    def duration_ms(self) -> float:
        """The total duration of the request in milliseconds."""
        return self.total_duration_ns / 1_000_000


class CudaraClient:
    """Synchronous client for interacting with the Cudara inference server."""

    def __init__(self, base_url: str = "http://localhost:8000", timeout: float = 300.0):
        """Initialize the client with a base URL and default timeout."""
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)
        self._lock = threading.Lock()

    def _encode_file(self, file_path: Union[str, Path]) -> str:
        """Helper to convert a file to a base64 string without newlines."""
        with open(file_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8").replace("\n", "").replace("\r", "")

    def _request(self, method: str, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Internal helper to handle HTTP requests and error reporting."""
        url = f"{self.base_url}{endpoint}"
        resp = self._client.request(method, url, **kwargs)
        resp.raise_for_status()
        return cast(dict[str, Any], resp.json())

    def generate(
        self,
        model: str,
        prompt: str,
        *,
        system: str | None = None,
        images: list[str] | None = None,
        format: Union[str, dict[str, Any]] | None = None,
        stream: bool = False,
        think: bool | str | None = None,
        keep_alive: Union[str, int] | None = None,
        options: dict[str, Any] | None = None,
    ) -> Union[Response, Iterator[Response]]:
        """Generate a response for a single prompt."""
        payload: dict[str, Any] = {"model": model, "prompt": prompt, "stream": stream}
        if system:
            payload["system"] = system
        if images:
            payload["images"] = images
        if format:
            payload["format"] = format
        if think is not None:
            payload["think"] = think
        if keep_alive is not None:
            payload["keep_alive"] = keep_alive
        if options:
            payload["options"] = options

        if stream:

            def stream_gen() -> Iterator[Response]:
                with self._lock, self._client.stream("POST", f"{self.base_url}/api/generate", json=payload) as r:
                    for line in r.iter_lines():
                        if not line:
                            continue
                        data = json.loads(line)
                        yield Response(
                            content=data.get("response", ""),
                            model=data.get("model", model),
                            thinking=data.get("thinking"),
                            done=data.get("done", False),
                            done_reason=data.get("done_reason"),
                            raw=data,
                        )

            return stream_gen()

        data = self._request("POST", "/api/generate", json=payload)
        return Response(
            content=data.get("response", ""),
            model=data.get("model", model),
            thinking=data.get("thinking"),
            done=data.get("done", True),
            total_duration_ns=data.get("total_duration", 0),
            raw=data,
        )

    def chat(
        self,
        model: str,
        messages: Union[str, Sequence[Message], Sequence[dict[str, Any]]],
        *,
        format: Union[str, dict[str, Any]] | None = None,
        stream: bool = False,
        think: bool | str | None = None,
        keep_alive: Union[str, int] | None = None,
        options: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> Union[Response, Iterator[Response]]:
        """Initiate or continue a chat conversation."""
        if isinstance(messages, str):
            msgs = [{"role": "user", "content": messages}]
        else:
            msgs = [m.to_dict() if isinstance(m, Message) else m for m in messages]

        payload: dict[str, Any] = {"model": model, "messages": msgs, "stream": stream}
        if format:
            payload["format"] = format
        if think is not None:
            payload["think"] = think
        if keep_alive is not None:
            payload["keep_alive"] = keep_alive
        if options:
            payload["options"] = options
        if tools:
            payload["tools"] = tools

        if stream:

            def stream_gen() -> Iterator[Response]:
                with self._lock, self._client.stream("POST", f"{self.base_url}/api/chat", json=payload) as r:
                    for line in r.iter_lines():
                        if not line:
                            continue
                        data = json.loads(line)
                        yield Response(
                            content=data.get("message", {}).get("content", ""),
                            model=data.get("model", model),
                            thinking=data.get("thinking"),
                            done=data.get("done", False),
                            raw=data,
                        )

            return stream_gen()

        data = self._request("POST", "/api/chat", json=payload)
        return Response(
            content=data.get("message", {}).get("content", ""),
            model=data.get("model", model),
            thinking=data.get("thinking"),
            done=data.get("done", True),
            raw=data,
        )

    def embed(
        self,
        model: str,
        input: Union[str, list[str]],
        dimensions: int | None = None,
        keep_alive: Union[str, int] | None = None,
        options: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Generate vector embeddings for the given input."""
        payload: dict[str, Any] = {"model": model, "input": input}
        if dimensions:
            payload["dimensions"] = dimensions
        if keep_alive is not None:
            payload["keep_alive"] = keep_alive
        if options:
            payload["options"] = options
        return self._request("POST", "/api/embed", json=payload)

    def transcribe(self, model: str, audio_path: Union[str, Path], prompt: str = "Transcribe this audio.") -> Response:
        """Transcribe an audio file using a specified model."""
        b64_audio = self._encode_file(audio_path)
        return cast(
            Response,
            self.generate(model=model, prompt=prompt, images=[b64_audio], options={"is_audio": True}, stream=False),
        )

    def tags(self) -> dict[str, Any]:
        """Get a list of all available models."""
        return self._request("GET", "/api/tags")

    def ps(self) -> dict[str, Any]:
        """Get the current status of loaded models in memory."""
        return self._request("GET", "/api/ps")

    def pull(self, model: str, stream: bool = True) -> Union[dict[str, Any], Iterator[dict[str, Any]]]:
        """Download a model to the server registry."""
        if not stream:
            return self._request("POST", "/api/pull", json={"model": model, "stream": False})

        def stream_gen() -> Iterator[dict[str, Any]]:
            with self._client.stream("POST", f"{self.base_url}/api/pull", json={"model": model}) as r:
                for line in r.iter_lines():
                    if line:
                        yield cast(dict[str, Any], json.loads(line))

        return stream_gen()

    def delete(self, model: str) -> dict[str, Any]:
        """Delete a model from the server registry."""
        return self._request("DELETE", "/api/delete", json={"model": model})

    def close(self) -> None:
        """Close the underlying HTTPX client."""
        self._client.close()
