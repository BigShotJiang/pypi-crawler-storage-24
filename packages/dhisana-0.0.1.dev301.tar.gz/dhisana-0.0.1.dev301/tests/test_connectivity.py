import asyncio
import unittest
from unittest.mock import AsyncMock, patch

from src.dhisana.utils.test_connect import test_connectivity as run_test_connectivity, test_twilio


class FakeResponse:
    def __init__(self, status, payload):
        self.status = status
        self._payload = payload

    async def json(self):
        return self._payload


class FakeRequestContext:
    def __init__(self, response):
        self.response = response

    async def __aenter__(self):
        return self.response

    async def __aexit__(self, exc_type, exc, tb):
        return False


class FakeSession:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    def get(self, url):
        self.calls.append(url)
        if not self.responses:
            raise AssertionError(f"No fake response configured for {url}")
        return FakeRequestContext(self.responses.pop(0))


class FakeClientSessionFactory:
    def __init__(self, sessions):
        self.sessions = list(sessions)
        self.auths = []

    def __call__(self, *args, **kwargs):
        if not self.sessions:
            raise AssertionError("No fake aiohttp session configured")
        self.auths.append(kwargs.get("auth"))
        return self.sessions.pop(0)


class TestConnectivity(unittest.TestCase):
    def test_jinaai_dispatch(self):
        async def runner():
            with patch('src.dhisana.utils.test_connect.test_jinaai', new=AsyncMock(return_value={'success': True, 'status_code': 200, 'error_message': None})):
                tool_config = [
                    {
                        'name': 'jinaai',
                        'configuration': [
                            {'name': 'apiKey', 'value': 'dummy'}
                        ]
                    }
                ]
                result = await run_test_connectivity(tool_config)
                self.assertIn('jinaai', result)
                self.assertTrue(result['jinaai']['success'])
        asyncio.run(runner())

    def test_firecrawl_dispatch(self):
        async def runner():
            with patch('src.dhisana.utils.test_connect.test_firecrawl', new=AsyncMock(return_value={'success': True, 'status_code': 200, 'error_message': None})):
                tool_config = [
                    {
                        'name': 'firecrawl',
                        'configuration': [
                            {'name': 'apiKey', 'value': 'dummy'}
                        ]
                    }
                ]
                result = await run_test_connectivity(tool_config)
                self.assertIn('firecrawl', result)
                self.assertTrue(result['firecrawl']['success'])
        asyncio.run(runner())

    def test_firefliesai_dispatch(self):
        async def runner():
            with patch('src.dhisana.utils.test_connect.test_firefliesai', new=AsyncMock(return_value={'success': True, 'status_code': 200, 'error_message': None})):
                tool_config = [
                    {
                        'name': 'firefliesai',
                        'configuration': [
                            {'name': 'apiKey', 'value': 'dummy'}
                        ]
                    }
                ]
                result = await run_test_connectivity(tool_config)
                self.assertIn('firefliesai', result)
                self.assertTrue(result['firefliesai']['success'])
        asyncio.run(runner())

    def test_theorg_dispatch(self):
        async def runner():
            with patch('src.dhisana.utils.test_connect.test_theorg', new=AsyncMock(return_value={'success': True, 'status_code': 200, 'error_message': None})):
                tool_config = [
                    {
                        'name': 'theorg',
                        'configuration': [
                            {'name': 'apiKey', 'value': 'dummy'}
                        ]
                    }
                ]
                result = await run_test_connectivity(tool_config)
                self.assertIn('theorg', result)
                self.assertTrue(result['theorg']['success'])
        asyncio.run(runner())

    def test_salesforce_dispatch(self):
        async def runner():
            with patch(
                'src.dhisana.utils.test_connect.test_salesforce',
                new=AsyncMock(return_value={'success': True, 'status_code': 200, 'error_message': None})
            ):
                tool_config = [
                    {
                        'name': 'salesforce',
                        'configuration': [
                            {'name': 'username', 'value': 'dummy'},
                            {'name': 'password', 'value': 'dummy'},
                            {'name': 'security_token', 'value': 'dummy'},
                            {'name': 'domain', 'value': 'login'},
                            {'name': 'client_id', 'value': 'dummy'},
                            {'name': 'client_secret', 'value': 'dummy'},
                        ]
                    }
                ]
                result = await run_test_connectivity(tool_config)
                self.assertIn('salesforce', result)
                self.assertTrue(result['salesforce']['success'])
        asyncio.run(runner())

    def test_samgov_dispatch(self):
        async def runner():
            with patch(
                'src.dhisana.utils.test_connect.test_samgov',
                new=AsyncMock(return_value={'success': True, 'status_code': 200, 'error_message': None})
            ):
                tool_config = [
                    {
                        'name': 'samgov',
                        'configuration': [
                            {'name': 'apiKey', 'value': 'dummy'}
                        ]
                    }
                ]
                result = await run_test_connectivity(tool_config)
                self.assertIn('samgov', result)
                self.assertTrue(result['samgov']['success'])
        asyncio.run(runner())

    def test_twilio_requires_api_secret_when_api_key_is_set(self):
        async def runner():
            account_session = FakeSession([
                FakeResponse(200, {'sid': 'AC123'}),
            ])
            session_factory = FakeClientSessionFactory([account_session])

            with patch('src.dhisana.utils.test_connect.aiohttp.ClientSession', new=session_factory):
                result = await test_twilio('AC123', 'auth-token', api_key='SK123', api_secret='')

            self.assertFalse(result['success'])
            self.assertEqual(result['status_code'], 0)
            self.assertIn('Missing api_secret', result['error_message'])
            self.assertEqual(len(session_factory.auths), 1)
            self.assertEqual(session_factory.auths[0].login, 'AC123')
            self.assertEqual(session_factory.auths[0].password, 'auth-token')

        asyncio.run(runner())

    def test_twilio_fails_when_api_key_secret_auth_is_rejected(self):
        async def runner():
            account_session = FakeSession([
                FakeResponse(200, {'sid': 'AC123'}),
                FakeResponse(200, {'sid': 'SK123'}),
            ])
            api_key_session = FakeSession([
                FakeResponse(401, {'message': 'Authenticate'}),
            ])
            session_factory = FakeClientSessionFactory([account_session, api_key_session])

            with patch('src.dhisana.utils.test_connect.aiohttp.ClientSession', new=session_factory):
                result = await test_twilio('AC123', 'auth-token', api_key='SK123', api_secret='secret')

            self.assertFalse(result['success'])
            self.assertEqual(result['status_code'], 401)
            self.assertEqual(result['error_message'], 'Authenticate')
            self.assertEqual(len(session_factory.auths), 2)
            self.assertEqual(session_factory.auths[0].login, 'AC123')
            self.assertEqual(session_factory.auths[0].password, 'auth-token')
            self.assertEqual(session_factory.auths[1].login, 'SK123')
            self.assertEqual(session_factory.auths[1].password, 'secret')
            self.assertIn('/Messages.json?PageSize=1', api_key_session.calls[0])

        asyncio.run(runner())


if __name__ == '__main__':
    unittest.main()
