"""
Integration test for the single-step generate_personalized_email function.
Requires OPENAI_API_KEY environment variable to be set.
"""
import asyncio
import os
import re
import unittest
from unittest.mock import AsyncMock, patch

from dhisana.schemas.sales import (
    CampaignContext,
    ContentGenerationContext,
    ConversationContext,
    Lead,
    MessageGenerationInstructions,
    SenderInfo,
)
from dhisana.utils.generate_email import generate_personalized_email
from dhisana.utils.generate_email import EmailCopy, generate_personalized_email_copy


def _build_tool_config():
    """Build tool_config from environment variables."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return None
    return [
        {
            "name": "openai",
            "configuration": [
                {"name": "apiKey", "value": key},
            ],
        }
    ]


def _build_context() -> ContentGenerationContext:
    lead = Lead(
        full_name="Jane Smith",
        first_name="Jane",
        last_name="Smith",
        email="jane.smith@acmecorp.com",
        job_title="VP of Engineering",
        organization_name="Acme Corp",
        organization_website="https://acmecorp.com",
        industry="Software",
        company_size="500-1000",
        phone="404-555-1234",
        research_summary="Jane Smith is VP of Eng at Acme Corp. Phone: 404-555-1234.",
    )
    sender = SenderInfo(
        sender_full_name="John Doe",
        sender_first_name="John",
        sender_last_name="Doe",
        sender_email="john@dhisana.ai",
        sender_bio="Co-founder at Dhisana, helping sales teams automate outreach.",
        sender_appointment_booking_url="https://cal.com/johndoe/30min",
    )
    campaign = CampaignContext(
        product_name="Dhisana AI",
        value_prop="AI-powered sales outreach that writes personalized emails at scale",
        call_to_action="Book a 15-minute demo call",
        pain_points=["Manual email writing is slow", "Low response rates on generic templates"],
        proof_points=["3x response rate improvement", "Used by 500+ sales teams"],
    )
    instructions = MessageGenerationInstructions(
        use_cache=False,
        allow_html=False,
    )
    return ContentGenerationContext(
        lead_info=lead,
        sender_info=sender,
        campaign_context=campaign,
        current_conversation_context=ConversationContext(),
        message_instructions=instructions,
    )


class TestGenerateEmail(unittest.TestCase):
    def test_prompt_prevents_invented_sender_details(self):
        """The prompt should explicitly forbid invented sender contact details."""
        context = _build_context()
        instructions = context.message_instructions
        captured = {}

        async def _fake_get_structured_output_internal(**kwargs):
            captured.update(kwargs)
            return EmailCopy(subject="Hello", body="Hi Jane\n\nBest,\nJohn"), "SUCCESS"

        with patch(
            "dhisana.utils.generate_email.get_structured_output_internal",
            new=AsyncMock(side_effect=_fake_get_structured_output_internal),
        ):
            result = asyncio.run(
                generate_personalized_email_copy(
                    email_context=context,
                    message_instructions=instructions,
                    variation_text="Use a concise problem-solution-action framework.",
                    tool_config=None,
                )
            )

        self.assertEqual(result["subject"], "Hello")
        prompt = captured["prompt"]
        # Anti-hallucination constraints
        self.assertIn("closed set", prompt)
        self.assertIn("Never invent", prompt)
        self.assertIn("phone numbers", prompt)
        self.assertIn("Do NOT add phone numbers", prompt)
        self.assertIn("Email:", prompt)
        # Lead identity appears early, additional lead context at end
        self.assertIn("## Lead", prompt)
        self.assertIn("## Additional Lead Context", prompt)
        lead_pos = prompt.index("## Lead")
        context_pos = prompt.index("## Additional Lead Context")
        sender_pos = prompt.index("## Sender")
        self.assertLess(lead_pos, sender_pos, "Lead section should appear before sender section")
        self.assertGreater(context_pos, sender_pos, "Additional lead context should appear after sender section")
        # Lead context must be serialised as JSON, not Python repr
        self.assertNotIn("UUID(", prompt, "Lead context should be JSON, not Python repr")
        # Anti-JSON-in-body instruction
        self.assertIn('must contain ONLY the email text', prompt)
        # Phone numbers from lead must be redacted
        self.assertIn('[redacted]', prompt)

    def test_generate_email_uses_gpt54_medium_effort(self):
        """The email generator should call GPT-5.4 with medium effort."""
        context = _build_context()
        instructions = context.message_instructions
        captured = {}

        async def _fake_get_structured_output_internal(**kwargs):
            captured.update(kwargs)
            return EmailCopy(subject="Hello", body="Hi Jane\n\nBest,\nJohn"), "SUCCESS"

        with patch(
            "dhisana.utils.generate_email.get_structured_output_internal",
            new=AsyncMock(side_effect=_fake_get_structured_output_internal),
        ):
            asyncio.run(
                generate_personalized_email_copy(
                    email_context=context,
                    message_instructions=instructions,
                    variation_text="Use a concise problem-solution-action framework.",
                    tool_config=None,
                )
            )

        self.assertEqual(captured["model"], "gpt-5.4")
        self.assertEqual(captured["effort"], "medium")

    def test_single_variation(self):
        """Generate 1 email variation and validate the output structure."""
        tool_config = _build_tool_config()
        if not tool_config:
            self.skipTest("OPENAI_API_KEY not set")

        context = _build_context()
        results = asyncio.run(
            generate_personalized_email(
                generation_context=context,
                number_of_variations=1,
                tool_config=tool_config,
            )
        )

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 1)

        email = results[0]
        self.assertIn("subject", email)
        self.assertIn("body", email)
        self.assertTrue(len(email["subject"]) > 0, "Subject should not be empty")
        self.assertTrue(len(email["body"]) > 0, "Body should not be empty")

        print(f"\n--- Generated Email ---")
        print(f"Subject: {email['subject']}")
        print(f"Body:\n{email['body']}")

    # ------------------------------------------------------------------
    # Integration: no hallucinated phone numbers
    # ------------------------------------------------------------------
    def test_no_hallucinated_phone_number(self):
        """The generated email must not contain a phone number since
        SenderInfo has no phone field and no phone is in the context."""
        tool_config = _build_tool_config()
        if not tool_config:
            self.skipTest("OPENAI_API_KEY not set")

        context = _build_context()
        results = asyncio.run(
            generate_personalized_email(
                generation_context=context,
                number_of_variations=1,
                tool_config=tool_config,
            )
        )
        body = results[0]["body"]
        subject = results[0]["subject"]
        combined = subject + "\n" + body

        # Match common US/intl phone patterns: (xxx) xxx-xxxx, xxx-xxx-xxxx, +1..., etc.
        phone_pattern = re.compile(
            r"(\+?\d[\d\-.\s()]{7,}\d)"  # 8+ digit sequences with separators
        )
        matches = phone_pattern.findall(combined)
        self.assertEqual(
            matches, [],
            f"Email contains hallucinated phone number(s): {matches}\n\nFull body:\n{body}",
        )
        print(f"\n--- No-Phone Test PASSED ---")
        print(f"Body:\n{body}")

    # ------------------------------------------------------------------
    # Integration: no hallucinated sender details
    # ------------------------------------------------------------------
    def test_no_fabricated_sender_details(self):
        """The generated email must not fabricate a job title, company name,
        or address for the sender that were not in SenderInfo or Bio."""
        tool_config = _build_tool_config()
        if not tool_config:
            self.skipTest("OPENAI_API_KEY not set")

        # Build a minimal sender with NO bio
        lead = Lead(
            full_name="Sarah Chen",
            first_name="Sarah",
            last_name="Chen",
            email="sarah@bigcorp.com",
            job_title="Head of Operations",
            organization_name="BigCorp",
            industry="Manufacturing",
        )
        sender = SenderInfo(
            sender_full_name="Alex Test",
            sender_first_name="Alex",
            sender_last_name="Test",
            sender_email="alex@example.com",
            # No bio, no booking URL — everything else should be omitted
        )
        campaign = CampaignContext(
            product_name="WidgetPro",
            value_prop="Streamlines manufacturing QA with automated visual inspection",
            call_to_action="Would a brief call make sense?",
        )
        instructions = MessageGenerationInstructions(use_cache=False, allow_html=False)
        context = ContentGenerationContext(
            lead_info=lead,
            sender_info=sender,
            campaign_context=campaign,
            current_conversation_context=ConversationContext(),
            message_instructions=instructions,
        )

        results = asyncio.run(
            generate_personalized_email(
                generation_context=context,
                number_of_variations=1,
                tool_config=tool_config,
            )
        )
        body = results[0]["body"]

        # Phone numbers must not appear
        phone_pattern = re.compile(r"(\+?\d[\d\-.\s()]{7,}\d)")
        phones = phone_pattern.findall(body)
        self.assertEqual(phones, [], f"Hallucinated phone: {phones}\n\n{body}")

        # Sender title/company must not be invented (these were never provided)
        body_lower = body.lower()
        self.assertNotIn("ceo", body_lower, f"Invented title 'CEO' in:\n{body}")
        self.assertNotIn("founder", body_lower, f"Invented title 'founder' in:\n{body}")
        self.assertNotIn("director", body_lower, f"Invented 'director' for sender in:\n{body}")

        # Signature should only contain sender first name
        self.assertIn("Alex", body, f"Sender first name missing from body:\n{body}")

        print(f"\n--- No-Fabrication Test PASSED ---")
        print(f"Body:\n{body}")

    # ------------------------------------------------------------------
    # Integration: sparse sender (only email, no names)
    # ------------------------------------------------------------------
    def test_sparse_sender_no_invented_name(self):
        """When only sender_email is provided, the model should not invent
        a name for the signature."""
        tool_config = _build_tool_config()
        if not tool_config:
            self.skipTest("OPENAI_API_KEY not set")

        lead = Lead(
            full_name="Jamie Rivera",
            first_name="Jamie",
            email="jamie@someco.com",
            organization_name="SomeCo",
        )
        sender = SenderInfo(
            sender_email="bot@outreach.io",
            # No names, no bio, no booking URL
        )
        campaign = CampaignContext(
            product_name="OutreachBot",
            value_prop="Automates follow-up emails so reps focus on selling",
            call_to_action="Interested in a quick demo?",
        )
        instructions = MessageGenerationInstructions(use_cache=False, allow_html=False)
        context = ContentGenerationContext(
            lead_info=lead,
            sender_info=sender,
            campaign_context=campaign,
            current_conversation_context=ConversationContext(),
            message_instructions=instructions,
        )

        results = asyncio.run(
            generate_personalized_email(
                generation_context=context,
                number_of_variations=1,
                tool_config=tool_config,
            )
        )
        body = results[0]["body"]

        # No phone numbers
        phone_pattern = re.compile(r"(\+?\d[\d\-.\s()]{7,}\d)")
        phones = phone_pattern.findall(body)
        self.assertEqual(phones, [], f"Hallucinated phone: {phones}\n\n{body}")

        print(f"\n--- Sparse-Sender Test PASSED ---")
        print(f"Body:\n{body}")


if __name__ == "__main__":
    unittest.main()
