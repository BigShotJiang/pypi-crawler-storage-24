"""Comprehensive tests for AgenticComm Python SDK.

This file tests CommStore, cli_bridge, models, and error classes.
Does NOT replace test_imports.py -- this is an additional test file.
"""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path, PurePosixPath
from unittest.mock import patch, MagicMock

import pytest

from agentic_comm import (
    CommStore,
    Channel,
    Message,
    Subscription,
    StoreInfo,
    AcommError,
    AcommNotFoundError,
    CLIError,
    StoreNotFoundError,
    ChannelNotFoundError,
    ValidationError,
    __version__,
)
from agentic_comm.cli_bridge import find_acomm_binary, run_cli, run_cli_json


# ---------------------------------------------------------------------------
# 1. Package Metadata
# ---------------------------------------------------------------------------


class TestPackageMetadata:
    def test_version_exists(self) -> None:
        assert __version__ is not None
        assert isinstance(__version__, str)
        assert len(__version__) > 0

    def test_version_semver(self) -> None:
        parts = __version__.split(".")
        assert len(parts) == 3
        assert all(p.isdigit() for p in parts)

    def test_version_is_010(self) -> None:
        assert __version__ == "0.1.0"

    def test_import_main_class(self) -> None:
        assert CommStore is not None

    def test_import_error_classes(self) -> None:
        assert issubclass(AcommError, Exception)
        assert issubclass(AcommNotFoundError, AcommError)
        assert issubclass(CLIError, AcommError)
        assert issubclass(StoreNotFoundError, AcommError)
        assert issubclass(ChannelNotFoundError, AcommError)
        assert issubclass(ValidationError, AcommError)

    def test_main_class_has_docstring(self) -> None:
        assert CommStore.__doc__ is not None
        assert len(CommStore.__doc__) > 10

    def test_all_exports_defined(self) -> None:
        import agentic_comm
        assert hasattr(agentic_comm, "__all__")
        assert "CommStore" in agentic_comm.__all__
        assert "AcommError" in agentic_comm.__all__


# ---------------------------------------------------------------------------
# 2. CommStore Initialization
# ---------------------------------------------------------------------------


class TestInit:
    def test_create_with_string_path(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(str(tmp_path / "test.acomm"))
            assert str(obj.path) == str(tmp_path / "test.acomm")

    def test_create_with_path_object(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            path = tmp_path / "test.acomm"
            obj = CommStore(path)
            assert obj.path == path

    def test_create_with_pure_posix_path(self) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(PurePosixPath("/tmp/test.acomm"))
            assert "test.acomm" in str(obj.path)

    def test_path_converted_to_path_object(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            path = str(tmp_path / "test.acomm")
            obj = CommStore(path)
            assert isinstance(obj.path, Path)

    def test_custom_binary_path(self, tmp_path: Path) -> None:
        fake_bin = tmp_path / "acomm"
        fake_bin.touch()
        fake_bin.chmod(0o755)
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=fake_bin):
            obj = CommStore(str(tmp_path / "test.acomm"), binary=fake_bin)
            assert obj._binary == fake_bin

    def test_custom_timeout(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(str(tmp_path / "test.acomm"), timeout=60)
            assert obj._timeout == 60

    def test_default_timeout_is_30(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(str(tmp_path / "test.acomm"))
            assert obj._timeout == 30

    def test_repr_does_not_crash(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(str(tmp_path / "test.acomm"))
            r = repr(obj)
            assert isinstance(r, str)
            assert "CommStore" in r

    def test_repr_contains_path(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(str(tmp_path / "test.acomm"))
            assert "test.acomm" in repr(obj)


# ---------------------------------------------------------------------------
# 3. Binary Resolution (find_acomm_binary)
# ---------------------------------------------------------------------------


class TestBinaryResolution:
    def test_missing_binary_raises(self) -> None:
        with patch("agentic_comm.cli_bridge.shutil.which", return_value=None), \
             patch.dict(os.environ, {}, clear=True), \
             patch("pathlib.Path.is_file", return_value=False):
            with pytest.raises(AcommNotFoundError):
                find_acomm_binary()

    def test_error_is_acomm_subclass(self) -> None:
        assert issubclass(AcommNotFoundError, AcommError)

    def test_error_contains_install_hint(self) -> None:
        with patch("agentic_comm.cli_bridge.shutil.which", return_value=None), \
             patch.dict(os.environ, {}, clear=True), \
             patch("pathlib.Path.is_file", return_value=False):
            with pytest.raises(AcommNotFoundError, match="Install"):
                find_acomm_binary()

    def test_override_nonexistent_raises(self, tmp_path: Path) -> None:
        fake = tmp_path / "nonexistent_binary"
        with pytest.raises(AcommNotFoundError):
            find_acomm_binary(fake)

    def test_override_existing_executable(self, tmp_path: Path) -> None:
        fake = tmp_path / "acomm"
        fake.touch()
        fake.chmod(0o755)
        result = find_acomm_binary(fake)
        assert result == fake

    def test_which_found(self) -> None:
        with patch("shutil.which", return_value="/usr/local/bin/acomm"), \
             patch.dict(os.environ, {}, clear=True):
            result = find_acomm_binary()
            assert result == Path("/usr/local/bin/acomm")

    def test_env_var_takes_priority(self, tmp_path: Path) -> None:
        fake = tmp_path / "acomm"
        fake.touch()
        fake.chmod(0o755)
        with patch.dict(os.environ, {"ACOMM_BINARY": str(fake)}):
            result = find_acomm_binary()
            assert result == fake


# ---------------------------------------------------------------------------
# 4. Subprocess Execution (run_cli / run_cli_json)
# ---------------------------------------------------------------------------


class TestSubprocessExecution:
    def test_run_cli_calls_subprocess(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="ok\n", stderr=""
            )
            result = run_cli(Path("/usr/bin/echo"), ["arg1", "arg2"])
            assert mock_run.called
            cmd = mock_run.call_args[0][0]
            assert cmd[0] == "/usr/bin/echo"

    def test_run_cli_includes_store_flag_in_commstore(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore(str(tmp_path / "t.acomm"))
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="ok\n", stderr=""
            )
            obj._run(["test"])
            cmd = mock_run.call_args[0][0]
            assert "--store" in cmd
            assert str(tmp_path / "t.acomm") in cmd

    def test_run_cli_raises_on_nonzero_exit(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1, stdout="", stderr="error happened"
            )
            with pytest.raises(CLIError, match="error happened"):
                run_cli(Path("/bin/false"), ["fail"])

    def test_cli_error_stores_returncode(self) -> None:
        err = CLIError(42, "bad stuff")
        assert err.returncode == 42
        assert err.stderr == "bad stuff"

    def test_run_cli_json_parses_output(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout='{"key": "value"}\n', stderr=""
            )
            result = run_cli_json(Path("/usr/bin/echo"), ["test"])
            assert result == {"key": "value"}

    def test_run_cli_json_appends_json_flag(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout='{"k": 1}\n', stderr=""
            )
            run_cli_json(Path("/usr/bin/echo"), ["test"])
            cmd = mock_run.call_args[0][0]
            assert "--json" in cmd

    def test_run_cli_json_does_not_duplicate_json_flag(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout='{"k": 1}\n', stderr=""
            )
            run_cli_json(Path("/usr/bin/echo"), ["test", "--json"])
            cmd = mock_run.call_args[0][0]
            assert cmd.count("--json") == 1

    def test_run_cli_json_raises_on_invalid_json(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="not json at all", stderr=""
            )
            with pytest.raises(json.JSONDecodeError):
                run_cli_json(Path("/usr/bin/echo"), ["test"])


# ---------------------------------------------------------------------------
# 5. Data Models
# ---------------------------------------------------------------------------


class TestModels:
    def test_channel_creation(self) -> None:
        ch = Channel(id="ch1", name="general", channel_type="broadcast", created_at="2026-01-01")
        assert ch.id == "ch1"
        assert ch.name == "general"
        assert ch.metadata == {}

    def test_message_creation(self) -> None:
        msg = Message(id="m1", channel_id="ch1", sender="agent-1", content="hello", timestamp="now")
        assert msg.id == "m1"
        assert msg.content == "hello"
        assert msg.metadata == {}

    def test_subscription_creation(self) -> None:
        sub = Subscription(id="s1", channel_id="ch1", subscriber="agent-2")
        assert sub.id == "s1"
        assert sub.pattern is None
        assert sub.created_at == ""

    def test_store_info_creation(self) -> None:
        info = StoreInfo(path="/tmp/test.acomm", channels=3, messages=10, subscriptions=2)
        assert info.channels == 3
        assert info.file_size == 0

    def test_channel_with_metadata(self) -> None:
        ch = Channel(id="ch1", name="ops", channel_type="topic", created_at="now", metadata={"key": "val"})
        assert ch.metadata["key"] == "val"

    def test_message_with_metadata(self) -> None:
        msg = Message(id="m1", channel_id="ch1", sender="a", content="b", timestamp="t", metadata={"x": 1})
        assert msg.metadata["x"] == 1


# ---------------------------------------------------------------------------
# 6. Edge Cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_path(self) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            obj = CommStore("")
            assert isinstance(obj.path, Path)

    def test_path_with_spaces(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            path = tmp_path / "path with spaces" / "test.acomm"
            obj = CommStore(str(path))
            assert "spaces" in str(obj.path)

    def test_path_with_unicode(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            path = tmp_path / "donnees" / "test.acomm"
            obj = CommStore(str(path))
            assert "donnees" in str(obj.path)

    def test_very_long_path(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            long_name = "a" * 200
            path = tmp_path / long_name / "test.acomm"
            obj = CommStore(str(path))
            assert len(str(obj.path)) > 200

    def test_multiple_instances_independent(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            a = CommStore(str(tmp_path / "a.acomm"))
            b = CommStore(str(tmp_path / "b.acomm"))
            assert a.path != b.path

    def test_dot_in_directory_name(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            path = tmp_path / "v1.0.0" / "test.acomm"
            obj = CommStore(str(path))
            assert "v1.0.0" in str(obj.path)


# ---------------------------------------------------------------------------
# 7. Error Handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_acomm_error_is_exception(self) -> None:
        assert issubclass(AcommError, Exception)

    def test_acomm_error_stores_message(self) -> None:
        err = AcommError("test message")
        assert "test message" in str(err)

    def test_acomm_not_found_stores_searched(self) -> None:
        err = AcommNotFoundError(["/path/1", "/path/2"])
        assert err.searched == ["/path/1", "/path/2"]
        assert "/path/1" in str(err)

    def test_acomm_not_found_empty_searched(self) -> None:
        err = AcommNotFoundError()
        assert err.searched == []
        assert "(none)" in str(err)

    def test_cli_error_stores_fields(self) -> None:
        err = CLIError(1, "stderr text")
        assert err.returncode == 1
        assert err.stderr == "stderr text"
        assert "1" in str(err)

    def test_store_not_found_stores_path(self) -> None:
        err = StoreNotFoundError("/missing.acomm")
        assert err.path == "/missing.acomm"

    def test_channel_not_found_stores_id(self) -> None:
        err = ChannelNotFoundError("ch-xyz")
        assert err.channel_id == "ch-xyz"

    def test_validation_error_basic(self) -> None:
        err = ValidationError("bad input")
        assert "bad input" in str(err)

    def test_error_hierarchy(self) -> None:
        with pytest.raises(AcommError):
            raise CLIError(1, "x")
        with pytest.raises(AcommError):
            raise AcommNotFoundError()
        with pytest.raises(AcommError):
            raise StoreNotFoundError("/x")
        with pytest.raises(AcommError):
            raise ChannelNotFoundError("x")
        with pytest.raises(AcommError):
            raise ValidationError("x")


# ---------------------------------------------------------------------------
# 8. Stress Tests
# ---------------------------------------------------------------------------


class TestStress:
    def test_create_1000_instances(self, tmp_path: Path) -> None:
        with patch("agentic_comm.cli_bridge.find_acomm_binary", return_value=Path("/fake/acomm")):
            instances = [
                CommStore(str(tmp_path / f"test_{i}.acomm"))
                for i in range(1000)
            ]
            assert len(instances) == 1000
            assert instances[0].path != instances[999].path

    def test_find_binary_1000_times_cached(self, tmp_path: Path) -> None:
        fake = tmp_path / "acomm"
        fake.touch()
        fake.chmod(0o755)
        for _ in range(1000):
            result = find_acomm_binary(fake)
            assert result == fake

    def test_create_1000_error_instances(self) -> None:
        errors = [CLIError(i, f"err_{i}") for i in range(1000)]
        assert len(errors) == 1000
        assert errors[999].returncode == 999
