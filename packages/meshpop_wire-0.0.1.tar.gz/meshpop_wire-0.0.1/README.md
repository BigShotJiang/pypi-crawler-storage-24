# meshpop-wire

MeshPOP Wire — WireGuard mesh VPN manager.

> This package is a placeholder. Full release coming soon.

See [github.com/meshpop/wire](https://github.com/meshpop/wire) for source.
