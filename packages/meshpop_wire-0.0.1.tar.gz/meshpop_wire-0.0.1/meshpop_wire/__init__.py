"""MeshPOP Wire — WireGuard mesh VPN manager"""
