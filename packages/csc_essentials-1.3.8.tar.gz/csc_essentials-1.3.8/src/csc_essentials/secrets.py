"""Helpers para acessar o Google Secret Manager.

Fornece uma função utilitária simples para recuperar o payload de uma
versão de segredo como string (geralmente JSON).
"""

from google.cloud import secretmanager



def get_secrets(secret_name):
    """Recupera o valor de um segredo do Secret Manager.

    Args:
        secret_name (str): recurso completo da versão do segredo
            (ex.: "projects/<proj>/secrets/<name>/versions/latest").

    Returns:
        str | None: valor do segredo decodificado ou `None` em caso de falha.
    """
    try:
        sm_client = secretmanager.SecretManagerServiceClient()
        response = sm_client.access_secret_version(request={"name": secret_name})
        secret_value = response.payload.data.decode("UTF-8")
        return secret_value
    except Exception:
        # Em caso de erro retornamos None para que chamadores possam tratar
        return None
