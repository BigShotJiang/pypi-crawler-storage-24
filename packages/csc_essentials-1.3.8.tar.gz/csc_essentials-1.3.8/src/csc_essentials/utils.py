"""Funções utilitárias: normalização, conversão e execução com timeout.

Contém helpers usados em pipelines para preparar dados antes do envio
ao BigQuery e para executar tarefas com timeout/fallback.
"""

import json
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from unidecode import unidecode
import re
import math


def ajusta_nome_coluna(nome_coluna):
    """Normaliza um nome de coluna para formato compatível com BigQuery.

    - substitui `/` por `_`
    - converte para minúsculas
    - substitui espaços por `_`
    - remove acentos e caracteres especiais
    """
    nome_coluna = nome_coluna.replace('/', '_')
    normalized = unidecode(nome_coluna.lower().replace(' ', '_'))
    return re.sub(r'[^a-zA-Z0-9_]', '', normalized)


def converter_valor(row, schema_map, gerador_log):
    """Converte e sanitiza os valores de uma linha segundo o `schema_map`.

    - Recebe `row` (dict coluna->valor) e `schema_map` (coluna->TIPO BigQuery).
    - Converte tipos básicos (STRING, INTEGER, FLOAT, BOOLEAN, DATE, DATETIME).
    - Sanitiza NaN/Inf, strings nulas do Pandas e formata datas no padrão aceito pelo BigQuery.
    - Trata formatos de moeda BR/US, datas BR (DD/MM/YYYY), datetime BR e padrão MMM-AA.
    - Em falhas de conversão registra avisos e armazena `None` no campo.
    """

    if not schema_map:
        return row

    nova_linha = {}

    regex_data_br = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
    regex_iso_tz = re.compile(
        r"^(\d{4}-\d{2}-\d{2})[T ]"
        r"(\d{2}:\d{2}:\d{2}(?:\.\d+)?)"
        r"(?:Z|[+-]\d{2}:?\d{2})?$"
    )

    for col, val in row.items():
        # Captura "nan" vindo do Pandas e demais strings que representam nulo
        val_str_check = str(val).strip().lower() if val is not None else ""
        if val is None or val_str_check in ("", "nan", "none", "null", "undefined"):
            nova_linha[col] = None
            continue

        if col == "data_import":
            nova_linha[col] = val
            continue

        # Serializa estruturas complexas para JSON
        if isinstance(val, (dict, list)):
            try:
                nova_linha[col] = json.dumps(val, ensure_ascii=False)
            except Exception:
                nova_linha[col] = str(val)
            continue

        tipo_bq = schema_map.get(col, "STRING")

        try:
            if tipo_bq == "STRING":
                # Remove quebras de linha e caracteres de controle que corrompem o JSONL
                val_str = str(val).replace("\n", " ").replace("\r", "").replace("\t", " ").strip()
                # Remove caracteres não-imprimíveis (ASCII < 32) exceto espaço
                val_str = "".join(ch for ch in val_str if ord(ch) >= 32)
                nova_linha[col] = val_str

            elif tipo_bq in ("INTEGER", "INT64"):
                # Garante conversão segura string -> float -> int (ex: "10.0" vira 10)
                nova_linha[col] = int(float(str(val)))

            elif tipo_bq in ("FLOAT", "FLOAT64", "NUMERIC"):
                # Limpeza inicial de moeda e espaços
                val_str = str(val).replace("R$", "").replace(" ", "").strip()

                # Trata traço como zero (comum em planilhas)
                if val_str in ("-", ""):
                    nova_linha[col] = 0.0
                else:
                    # Lógica inteligente para vírgulas e pontos
                    if "," in val_str and "." in val_str:
                        # Se a vírgula vem antes do ponto (ex: 1,510,000.00) -> padrão US
                        if val_str.find(",") < val_str.rfind("."):
                            val_str = val_str.replace(",", "")
                        else:
                            # Padrão BR: 1.000,00
                            val_str = val_str.replace(".", "").replace(",", ".")
                    elif "," in val_str:
                        # Só vírgula: se parte decimal tem <= 2 dígitos trata como decimal
                        partes = val_str.split(",")
                        if len(partes[-1]) <= 2:
                            val_str = val_str.replace(".", "").replace(",", ".")
                        else:
                            val_str = val_str.replace(",", "")

                    try:
                        valor_float = float(val_str)
                        if math.isnan(valor_float) or math.isinf(valor_float):
                            nova_linha[col] = None
                        else:
                            nova_linha[col] = valor_float
                    except ValueError:
                        gerador_log.add(
                            f"AVISO: Não foi possível converter '{val}' para FLOAT. Coluna: {col}. Enviando NULL.",
                            severity="WARNING",
                        )
                        nova_linha[col] = None

            elif tipo_bq in ("BOOLEAN", "BOOL"):
                nova_linha[col] = str(val).lower() in ("true", "1", "t", "yes")

            elif tipo_bq == "DATE":
                val_str = str(val).strip().upper()

                meses = {
                    'JAN': '01', 'FEB': '02', 'MAR': '03', 'APR': '04', 'MAY': '05', 'JUN': '06',
                    'JUL': '07', 'AUG': '08', 'SEP': '09', 'OCT': '10', 'NOV': '11', 'DEC': '12'
                }

                # Trata formato DD/MMM/YY (ex: 19/MAR/26) ou DD-MMM-YY (ex: 22-JAN-26)
                regex_dd_mmm_yy = re.compile(r"^(\d{2})[/-]([A-Z]{3})[/-](\d{2})$")
                match_dmy = regex_dd_mmm_yy.match(val_str)
                if match_dmy:
                    mes = meses.get(match_dmy.group(2), '01')
                    ano = f"20{match_dmy.group(3)}"
                    nova_linha[col] = f"{ano}-{mes}-{match_dmy.group(1)}"
                    continue

                # Trata formato MMM-AA (ex: FEB-26)
                regex_mes_ano = re.compile(r"^([A-Z]{3})-(\d{2})$")
                match_ma = regex_mes_ano.match(val_str)

                if match_ma:
                    mes = meses.get(match_ma.group(1), '01')
                    ano = f"20{match_ma.group(2)}"
                    nova_linha[col] = f"{ano}-{mes}-01"
                else:
                    # Corrige concatenações de ano comuns em planilhas
                    val_str = val_str.replace('0224', '2024').replace('0202', '2022').replace('0204', '2024')
                    match_br = regex_data_br.match(val_str)
                    if match_br:
                        nova_linha[col] = f"{match_br.group(3)}-{match_br.group(2)}-{match_br.group(1)}"
                    else:
                        nova_linha[col] = val_str[:10] if len(val_str) >= 10 else None

            elif tipo_bq == "DATETIME":
                val_str = str(val).strip()

                # Tenta formato brasileiro DD/MM/YYYY HH:MM:SS
                regex_dt_br = re.compile(
                    r"^(\d{2})/(\d{2})/(\d{4})\s+(\d{2}:\d{2}:\d{2})(?:\.\d+)?$"
                )
                match_dt_br = regex_dt_br.match(val_str)
                if match_dt_br:
                    nova_linha[col] = (
                        f"{match_dt_br.group(3)}-{match_dt_br.group(2)}-{match_dt_br.group(1)}"
                        f" {match_dt_br.group(4)}"
                    )
                else:
                    match_iso = regex_iso_tz.match(val_str)
                    if match_iso:
                        nova_linha[col] = f"{match_iso.group(1)} {match_iso.group(2)}"
                    else:
                        # Limpeza robusta de timezone para evitar erro de formato
                        limpo = val_str.replace("T", " ").replace("Z", "")
                        if "+" in limpo:
                            limpo = limpo.split("+")[0]
                        if "-" in limpo and len(limpo.split("-")[-1]) == 5:
                            limpo = limpo.rsplit("-", 1)[0]
                        nova_linha[col] = limpo.strip()[:23]

            else:
                # Tipo não tratado: devolve o valor como veio
                nova_linha[col] = val

        except Exception:
            # Se falhar a conversão, envia NULL para evitar Type Mismatch no BigQuery
            gerador_log.add(
                f"AVISO: Falha conversão coluna '{col}' valor '{val}'. Enviando NULL."
            )
            nova_linha[col] = None

    return nova_linha


def executar_com_fallback(func, bq_client, timeout, project, dataset, tabela, gerador_log):
    """Executa `func` em um executor com timeout e captura falhas.

    Retorna uma string entre: `"sucesso"`, `"timeout"`, `"falha"`.
    """
    with ThreadPoolExecutor(max_workers=1) as executor:
        try:
            executor.submit(func, bq_client, project, dataset, tabela, gerador_log).result(timeout=timeout)
            return "sucesso"
        except TimeoutError:
            return "timeout"
        except Exception as e:
            gerador_log.add(f"❌ Erro {func.__name__}: {e}")
            return "falha"
