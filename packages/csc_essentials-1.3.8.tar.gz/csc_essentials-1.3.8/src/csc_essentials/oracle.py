
from google.cloud import  storage, bigquery
import time
from ftplib import FTP_TLS, error_perm
import ssl
from google.cloud import storage
from .utils import ajusta_nome_coluna
from datetime import datetime, timedelta, date
import socket
import pandas as pd
import io
import csv
from openpyxl import load_workbook
import xlrd
import gzip
import shutil
import time
import ssl
from ftplib import error_perm

def conexao_ftp_oracle(conexao, gerador_log):
    try:
        host, host_ip, port, user, pwd = conexao
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

        ftp = FTP_TLS(context=context)
        try:
            ftp.connect(host, int(port), timeout=60)  # timeout da conexão inicial
            gerador_log.add('Conectado via host.')
        except Exception:
            ftp.connect(host_ip, int(port), timeout=60)  # timeout da conexão inicial
            gerador_log.add('Conectado via IP.')
        ftp.login(user, pwd)
        ftp.prot_p()
        ftp.sock.settimeout(60)
        ftp.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)  
        return ftp

    except error_perm as e:
        raise Exception(f"Erro de permissão durante a conexão ou login: {e}")
    except Exception as e:
        raise Exception(f'Erro geral durante a conexão com o FTP: {e}')
    


def baixar_arquivo_em_blocos(conexao, dir_arquivo, nome_arquivo_ftp, caminho_local, gerador_log, blocksize=64*1024, tamanho_bloco=50*1024*1024):
    parte_inicio = 0
    max_tentativas = 5

    try:
        ftp = conexao_ftp_oracle(conexao,gerador_log)
        ftp.cwd(dir_arquivo)
        tamanho_total = ftp.size(nome_arquivo_ftp)
        ftp.quit()
    except Exception as e:
        gerador_log.add(f"Falha ao obter tamanho do arquivo: {e}", severity="ERROR")
        raise

    with open(caminho_local, 'wb') as f_out:
        while parte_inicio < tamanho_total:
            tentativas = 0
            bytes_restantes = min(tamanho_bloco, tamanho_total - parte_inicio)

            while tentativas < max_tentativas:
                try:
                    ftp = conexao_ftp_oracle(conexao,gerador_log)
                    ftp.set_pasv(True)
                    ftp.voidcmd('TYPE I')
                    ftp.cwd(dir_arquivo)

                    ftp.sendcmd(f'REST {parte_inicio}')
                    baixado_bloco = 0
                    ultimo_log = parte_inicio

                    def escrever_bloco(data):
                        nonlocal parte_inicio, baixado_bloco, ultimo_log
                        f_out.write(data)
                        parte_inicio += len(data)
                        baixado_bloco += len(data)

                        if parte_inicio - ultimo_log >= 10 * 1024 * 1024:
                            progresso = (
                                f"{parte_inicio / (1024**2):.2f} MB / "
                                f"{tamanho_total / (1024**2):.2f} MB "
                                f"({(parte_inicio / tamanho_total) * 100:.2f}%)"
                            )
                            print(f"\r⏬ {progresso}", end='', flush=True)
                            ultimo_log = parte_inicio

                        if baixado_bloco >= bytes_restantes:
                            gerador_log.add(f"Bloco de {bytes_restantes} bytes baixado com sucesso.")
                            raise StopIteration()

                    try:
                        ftp.retrbinary(f'RETR {nome_arquivo_ftp}', escrever_bloco, blocksize=blocksize)
                    except StopIteration:
                        pass

                    try:
                        ftp.quit()
                    except Exception:
                        ftp.close()
                    break

                except ssl.SSLError as e:
                    if "UNEXPECTED_EOF_WHILE_READING" in str(e):
                        gerador_log.add("Conexão encerrada abruptamente (EOF). Tentando novamente...")
                    else:
                        raise
                except Exception as e:
                    tentativas += 1
                    gerador_log.add(f"Tentativa {tentativas} falhou em {parte_inicio / (1024**2):.2f} MB: {e}")
                    time.sleep(5)
                    try:
                        ftp.close()
                    except:
                        pass
        gerador_log.add("Download finalizado com sucesso.")
        

def detectar_separador(caminho_arquivo, encoding, gerador_log):
    try:
        with open(caminho_arquivo, 'r', encoding=encoding) as f:
            primeira_linha = f.readline()
            if primeira_linha.count(';') > primeira_linha.count(','):
                gerador_log.add("Separador detectado: ';'")
                return ';'
            else:
                gerador_log.add("Separador detectado: ','")
                return ','
    except Exception as e:
        gerador_log.add(f"Erro ao detectar separador: {e}", severity="ERROR")
        raise


def envia_outbound(conexao, dir_in, ftp_files, gerador_log):
    try:
        gerador_log.add("Iniciando transferência de arquivos para a pasta outbound.")
        gerador_log.add(f"Arquivos a serem transferidos: {ftp_files}")
        dir_out = dir_in.replace('inbound', 'outbound')

        ftp = conexao_ftp_oracle(conexao,gerador_log)
        ftp.cwd(dir_in)

        for file in ftp_files:
            try:
                ftp.rename(file, f"{dir_out}/{file}")
            except Exception as e:
                gerador_log.add(f"Erro ao mover o arquivo {file}: {e}", severity="ERROR")

        gerador_log.add("Arquivos transferidos com sucesso para a pasta outbound.")
        ftp.quit()
    except Exception as e:
        gerador_log.add(f"Erro na transferência dos arquivos para a pasta outbound: {e}", severity="ERROR")



def salvar_csv_gzip(df, caminho_csv, caminho_gzip, gerador_log):
    try:
        df.to_csv(caminho_csv, index=False, encoding='utf-8')
        with open(caminho_csv, 'rb') as f_in:
            with gzip.open(caminho_gzip, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        gerador_log.add(f"Arquivo CSV compactado com sucesso: {caminho_gzip}")
    except Exception as e:
        gerador_log.add(f"Erro ao salvar arquivo CSV GZIP: {e}", severity="ERROR")

    

def upload_para_gcs(bucket_name, caminho_gzip, destino_blob, gerador_log):
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destino_blob)
        blob.upload_from_filename(caminho_gzip)
        gerador_log.add(f"Upload concluído: {destino_blob}")
        return blob
    except Exception as e:
        gerador_log.add(f"Erro ao enviar arquivo para GCS: {e}", severity="ERROR")
      

def carregar_csv_no_bigquery(bucket_name, blob_path, dataset, tabela_nome, gerador_log,client,clientdtptfrm):
    try:
        gerador_log.add(f"Enviando CSV para o BigQuery...")
        client = client
        uri = f"gs://{bucket_name}/{blob_path}"
        table_ref = clientdtptfrm.dataset(dataset).table(tabela_nome)
        table = clientdtptfrm.get_table(table_ref)

        schema = []
        for field in table.schema:
            if field.name == "data_import":
                schema.append(bigquery.SchemaField("data_import", "DATETIME"))
            else:
                schema.append(bigquery.SchemaField(field.name, "STRING"))

        job_config = bigquery.LoadJobConfig(
            schema=schema,
            source_format=bigquery.SourceFormat.CSV,
            skip_leading_rows=1,
            write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
            field_delimiter=","
        )

        job = client.load_table_from_uri(uri, table_ref, job_config=job_config)
        job.result()

        gerador_log.add(f"CSV carregado com sucesso no BigQuery: {tabela_nome}")
    except Exception as e:
        gerador_log.add(f"Erro ao inserir no BigQuery: {e}", severity="ERROR")


def deleta_arquivos_outbound(conexao,diretorio, gerador_log):    
    try:
        ftp = conexao_ftp_oracle(conexao,gerador_log)

        diretorio = diretorio.replace('inbound', 'outbound')
        ftp.cwd(diretorio)
        ftp_files = [file for file in ftp.nlst() if file.endswith('.csv')]
        data_atual = date.today() - timedelta(days=90)
        for arquivo in ftp_files:
            # Obter data de modificação do arquivo
            data_modificacao_str = ftp.sendcmd('MDTM ' + arquivo)
            data_modificacao = datetime.strptime(data_modificacao_str[4:], "%Y%m%d%H%M%S").date()
            #print(f'{arquivo} - dt: {data_modificacao}')

            # Comparar com a data atual
            if data_modificacao < data_atual:
                # Remover o arquivo
                ftp.delete(arquivo)
                #print(f"Arquivo {arquivo} removido com sucesso!")
        gerador_log.add(f"Remoção de arquivos antigos concluída.")
    except Exception as e:
        gerador_log.add(f'Erro na remoção de arquivos antigos. ERRO: {e}')  
    


def ler_arquivos_bucket(
    pasta: str,
    nome_arquivo: str,
    coluna_vazia: str,
    data_import,
    bucket_name: str,
    fatia_nome: slice,
    gerador_log,
    pasta_destino: str,      
) -> tuple[list, str]:
    try:
        pasta_lower = pasta.lower()
        nome_arquivo_lower = nome_arquivo.lower()

        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)

        blobs = bucket.list_blobs()
    except Exception as e:
        raise RuntimeError(f"Erro ao acessar o bucket ou listar os blobs: {e}")

    todos_dados = []
    nome_arquivo_final_curto = ''

    for blob in blobs:
        try:
            nome_blob = blob.name.lower()
            if 'outbound/' in nome_blob:
                continue
            if not nome_blob.startswith(f'{pasta_lower}') or nome_arquivo_lower not in nome_blob:
                continue
            if blob.name.endswith('/'):
                continue

            # Process CSV and TXT files
            if nome_blob.endswith('.csv') or nome_blob.endswith('.txt'):
                nome_arquivo_final = blob.name

                nome_arquivo_final_curto = nome_arquivo_final.split('/')[-1][fatia_nome]
                gerador_log.add(f'Lendo arquivo: {nome_arquivo_final} | periodo: {nome_arquivo_final_curto}')
                try:
                    conteudo = blob.download_as_text(encoding='utf-8')
                except UnicodeDecodeError:
                    conteudo = blob.download_as_text(encoding='latin1')

                reader = csv.DictReader(io.StringIO(conteudo), delimiter=';', quotechar='"')

                for row in reader:
                    mapped_row = {(ajusta_nome_coluna(k) or coluna_vazia): (v.strip() if v else None) for k, v in row.items()}
                    mapped_row['data_import'] = data_import

                    mapped_row['periodo'] = nome_arquivo_final_curto
                    todos_dados.append(mapped_row)

                if pasta_destino:
                    nome_arquivo_arquivado = blob.name.split('/')[-1]
                    novo_caminho = f'{pasta_destino.rstrip("/")}/{nome_arquivo_arquivado}'
                    bucket.copy_blob(blob, bucket, new_name=novo_caminho)
                    blob.delete()
                    gerador_log.add(f'Movido: {blob.name} -> {novo_caminho}')


            # Process XLSX files
            elif nome_blob.endswith('.xlsx'):
                nome_arquivo_final = blob.name

                nome_arquivo_final_curto = nome_arquivo_final.split('/')[-1][fatia_nome]
                gerador_log.add(f'Lendo arquivo: {nome_arquivo_final} | periodo: {nome_arquivo_final_curto}')

                conteudo = blob.download_as_bytes()
                workbook = load_workbook(filename=io.BytesIO(conteudo), data_only=True)

                for sheet_name in workbook.sheetnames:
                    sheet = workbook[sheet_name]
                    if sheet.sheet_state != "visible":
                        continue

                    visible_data = []
                    for row in sheet.iter_rows():
                        row_idx = row[0].row
                        if sheet.row_dimensions[row_idx].hidden:
                            continue

                        row_data = []
                        for cell in row:
                            col_letter = cell.column_letter
                            if sheet.column_dimensions[col_letter].hidden:
                                continue
                            row_data.append(cell.value)

                        if row_data:
                            visible_data.append(row_data)

                    if not visible_data:
                        continue

                    header = [(ajusta_nome_coluna(str(col).strip()) if col is not None else '') or coluna_vazia for col in visible_data[0]]
                    df = pd.DataFrame(visible_data[1:], columns=header)
                    df = df.fillna('').astype(str).apply(lambda col: col.map(lambda x: x.strip()))
                    df["data_import"] = data_import

                    df["periodo"] = nome_arquivo_final_curto
                    todos_dados.extend(df.to_dict(orient="records"))

                    nome_arquivo_arquivado = blob.name.split('/')[-1]
                    novo_caminho = f'{pasta_destino.rstrip("/")}/{nome_arquivo_arquivado}'
                    bucket.copy_blob(blob, bucket, new_name=novo_caminho)
                    blob.delete()
                    gerador_log.add(f'Movido: {blob.name} -> {novo_caminho}')

            # Process XLS files (real XLS or HTML table disguised as .xls)
            elif nome_blob.endswith('.xls'):
                nome_arquivo_final = blob.name
                nome_arquivo_final_curto = nome_arquivo_final.split('/')[-1][fatia_nome]
                gerador_log.add(f'Lendo arquivo: {nome_arquivo_final} | periodo: {nome_arquivo_final_curto}')

                conteudo = blob.download_as_bytes()
                is_html = conteudo[:200].strip().lower().startswith((b'<!doctype', b'<html'))

                if is_html:
                    try:
                        conteudo_str = conteudo.decode('utf-8')
                    except UnicodeDecodeError:
                        conteudo_str = conteudo.decode('latin1')

                    tabelas = pd.read_html(io.StringIO(conteudo_str))
                    for df in tabelas:
                        df.columns = [(ajusta_nome_coluna(str(col).strip()) if col is not None else '') or coluna_vazia for col in df.columns]
                        df = df.fillna('').astype(str).apply(lambda col: col.map(lambda x: x.strip()))
                        df["data_import"] = data_import
                        df["periodo"] = nome_arquivo_final_curto
                        todos_dados.extend(df.to_dict(orient="records"))
                else:
                    workbook = xlrd.open_workbook(file_contents=conteudo)

                    for sheet_idx in range(workbook.nsheets):
                        if workbook.sheet_visibility(sheet_idx) != 0:
                            continue
                        sheet = workbook.sheet_by_index(sheet_idx)

                        visible_data = []
                        for row_idx in range(sheet.nrows):
                            rowinfo = sheet.rowinfo_map.get(row_idx)
                            if rowinfo and rowinfo.hidden:
                                continue

                            row_data = []
                            for col_idx in range(sheet.ncols):
                                colinfo = sheet.colinfo_map.get(col_idx)
                                if colinfo and colinfo.hidden:
                                    continue
                                row_data.append(sheet.cell(row_idx, col_idx).value)

                            if row_data:
                                visible_data.append(row_data)

                        if not visible_data:
                            continue

                        header = [(ajusta_nome_coluna(str(col).strip()) if col is not None else '') or coluna_vazia for col in visible_data[0]]
                        df = pd.DataFrame(visible_data[1:], columns=header)
                        df = df.fillna('').astype(str).apply(lambda col: col.map(lambda x: x.strip()))
                        df["data_import"] = data_import
                        df["periodo"] = nome_arquivo_final_curto
                        todos_dados.extend(df.to_dict(orient="records"))

                if pasta_destino:
                    nome_arquivo_arquivado = blob.name.split('/')[-1]
                    novo_caminho = f'{pasta_destino.rstrip("/")}/{nome_arquivo_arquivado}'
                    bucket.copy_blob(blob, bucket, new_name=novo_caminho)
                    blob.delete()
                    gerador_log.add(f'Movido: {blob.name} -> {novo_caminho}')

        except Exception as e:
            raise RuntimeError(f"Erro ao processar o blob '{blob.name}': {e}")

    return todos_dados, nome_arquivo_final_curto
