"""Helpers para interação com BigQuery.

Fornece funções para obter o schema de tabelas, carregar arquivos NDJSON
e executar rotinas de atualização de tabelas (ex.: recriar a tabela a partir
de uma view `_vw`).
"""

from .utils import executar_com_fallback, converter_valor
import json
from google.api_core import exceptions
from google.cloud import bigquery


def obter_schema_map(bq_client, projeto, dataset, tabela, gerador_log):
    """
    Busca o schema da tabela no BigQuery e retorna um dicionário {coluna: TIPO}.
    Ex: {'data_emissao': 'DATE', 'valor': 'FLOAT', 'criado_em': 'DATETIME'}
    Se a tabela não existir, retorna um dict vazio (fallback).
    """
    tabela_completa = f"{projeto}.{dataset}.{tabela}"
    schema_map = {}

    try:
        table = bq_client.get_table(tabela_completa)
        for field in table.schema:
            schema_map[field.name] = field.field_type
    except exceptions.NotFound:
        gerador_log.add(
            f"Tabela {tabela} ainda não existe no BQ. Conversão inteligente desativada para este fluxo.",
            severity="WARNING",
        )
    except Exception as e:
        gerador_log.add(f"Erro ao buscar schema de {tabela}: {e}", severity="ERROR")

    return schema_map


def inserir_banco_dados(dados=None, arquivo_path=None, projeto=None, dataset=None, tabela=None, tabela_silver="", gerador_log=None, client=None, wait_job=False):
    """Inserção universal no BigQuery.

    Pode receber `dados` (lista/NDJSON/JSON) ou um `arquivo_path` (NDJSON) para upload.
    - `client` deve ser um `google.cloud.bigquery.Client`.
    - Se `arquivo_path` for fornecido, usa `load_table_from_file`.
    - Se `dados` for fornecido, normaliza e usa `insert_rows_json`.
    Retorna True em sucesso.
    """
    endpoint_name = f"BigQuery-Insert ({tabela})"

    # Preferência pelo arquivo: se arquivo_path é fornecido, faz upload em massa
    if arquivo_path:
        if client is None:
            gerador_log.add("client do BigQuery não fornecido para upload de arquivo.", severity="ERROR")
            raise ValueError("client obrigatório para upload de arquivo")

        tabela_completa = f"{projeto}.{dataset}.{tabela}"
        schema_destino = None
        autodetect_config = True

        try:
            table_ref = client.get_table(tabela_completa)
            schema_destino = table_ref.schema
            autodetect_config = False
        except exceptions.NotFound:
            # Tabela ainda não existe; manter autodetect_config=True para o BigQuery
            # inferir automaticamente o schema durante o carregamento.
            pass

        job_config = bigquery.LoadJobConfig(
            source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
            write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
            ignore_unknown_values=True,
            autodetect=autodetect_config,
        )

        with open(arquivo_path, "rb") as f:
            job = client.load_table_from_file(f, f"{projeto}.{dataset}.{tabela}", job_config=job_config)

        if wait_job:
            job.result()
            gerador_log.add(f"Upload finalizado para {tabela}", severity="DEBUG")

        return True

    # Caso contrário, usa `dados` em memória
    if dados is None:
        gerador_log.add("AVISO: Nenhum dado ou arquivo fornecido para inserção.", severity="WARNING")
        return

    # Normalize incoming `dados` into a list of dicts.
    try:
        if isinstance(dados, str):
            raw = dados.strip()
            if "\n" in raw:
                lines = [ln for ln in raw.splitlines() if ln.strip()]
                dados = [json.loads(ln) for ln in lines]
            else:
                parsed = json.loads(raw)
                dados = parsed if isinstance(parsed, list) else [parsed]

        elif isinstance(dados, (list, tuple)):
            normalized = []
            for idx, el in enumerate(dados):
                if isinstance(el, str):
                    try:
                        normalized.append(json.loads(el))
                    except Exception as e:
                        gerador_log.add(f"Ignorando elemento {idx} que não é JSON válido: {e}", severity="WARNING")
                elif isinstance(el, dict):
                    normalized.append(el)
                else:
                    gerador_log.add(f"Ignorando elemento {idx} de tipo {type(el).__name__}", severity="WARNING")
            dados = normalized
        else:
            gerador_log.add(f"Tipo de 'dados' inválido: {type(dados).__name__}", severity="ERROR")
            raise TypeError("'dados' deve ser uma lista/tupla, dict ou string JSON/NDJSON")

        if not dados:
            gerador_log.add("AVISO: Após normalização, não há dados válidos para inserção.", severity="WARNING")
            return
    except Exception:
        gerador_log.add("Erro ao parsear/normalizar 'dados' para inserção.", severity="ERROR")
        raise

    try:
        if client is None:
            raise ValueError("Para inserção via 'dados', é necessário fornecer um cliente BigQuery válido.")
        tabela_completa = f"{projeto}.{dataset}.{tabela}"
        table_ref = client.get_table(tabela_completa)
        schema = table_ref.schema

        tamanho_bloco = 1000
        total_registros = len(dados)

        gerador_log.add(f"Iniciando inserção de {total_registros} registros em blocos de {tamanho_bloco}...")

        inserted = 0
        for i in range(0, total_registros, tamanho_bloco):
            bloco = dados[i:i+tamanho_bloco]
            bloco_ajustado = []
            for item_idx, item in enumerate(bloco):
                if not isinstance(item, dict):
                    gerador_log.add(f"Ignorando registro no bloco (indice {i + item_idx}) pois não é um dict.", severity="WARNING")
                    continue

                novo_item = {}
                for campo in schema:
                    nome_coluna = campo.name
                    if nome_coluna in item:
                        # `converter_valor` expects a mapping (row->tipo). Wrap the
                        # single column value into a dict and pass a single-column
                        # schema so converter_valor can safely iterate `.items()`.
                        single_row = {nome_coluna: item.get(nome_coluna)}
                        single_schema = {nome_coluna: campo.field_type}
                        converted = converter_valor(single_row, single_schema, gerador_log)
                        novo_item[nome_coluna] = converted.get(nome_coluna)
                    else:
                        novo_item[nome_coluna] = None
                bloco_ajustado.append(novo_item)

            if not bloco_ajustado:
                continue

            errors = client.insert_rows_json(table_ref, bloco_ajustado)
            if errors:
                error_details = f"A API do BigQuery retornou erros ao inserir dados: {errors}"
                gerador_log.add(error_details, severity="ERROR")
                raise Exception(error_details)

            inserted += len(bloco_ajustado)

        gerador_log.add(f"{inserted} registros inseridos com sucesso!")

        if tabela_silver:
            att = atualiza_tabela(client, projeto, dataset, tabela_silver, gerador_log)
            gerador_log.add(f'Tabela silver: {att}')
            return True

        gerador_log.add('Sem Tabela Silver')
        return True

    except Exception as e:
        gerador_log.add(f"Erro crítico ao tentar inserir dados no BigQuery: {e}", severity="CRITICAL")
        raise
    
def atualiza_tabela(client, projeto, dataset, tabela, gerador_log):
    """Recria a tabela destino a partir da view correspondente (`<tabela>_vw`).

    Este helper executa um `CREATE OR REPLACE TABLE <tabela> AS SELECT * FROM <tabela>_vw`.
    """
    tabela_completa = f"{projeto}.{dataset}.{tabela}"
    insert_sql = f"create or replace table `{tabela_completa}` as SELECT * FROM `{tabela_completa}_vw`;"
    try:
        client.query(insert_sql).result()
        gerador_log.add(f"Tabela {tabela_completa} atualizada.")
    except Exception as e:
        # Log de erro e re-raise para que chamadores possam detectar falha
        gerador_log.add(f"Erro query {tabela_completa}: {e}", severity="ERROR")
        raise


def atualiza_tabelas_silvers(client_t1, client_t2, project, dataset, tabelas_silvers, gerador_log, timeout_minutos=5):
    """Atualiza múltiplas "silvers" com fallback entre dois clientes.

    A ideia é tentar atualizar cada tabela usando `client_t1`. Se houver falha
    no primeiro cliente (timeout/falha), ativa `secundario` e passa a usar
    `client_t2` para as próximas tabelas.
    """
    gerador_log.add("Iniciando Silvers...")
    timeout = timeout_minutos * 60
    secundario = False
    for tb in tabelas_silvers:
        if not secundario:
            # Tenta no client principal com timeout/fallback
            res = executar_com_fallback(atualiza_tabela, client_t1, timeout, project, dataset, tb, gerador_log)
            if res != "sucesso":
                # Marca para usar o secundário a partir de agora
                secundario = True
                executar_com_fallback(atualiza_tabela, client_t2, timeout, project, dataset, tb, gerador_log)
        else:
            # Já está no secundário: executa diretamente
            executar_com_fallback(atualiza_tabela, client_t2, timeout, project, dataset, tb, gerador_log)
    gerador_log.add("Fim Silvers.")
