import os
import threading
import json
from datetime import datetime
import pytz
from google.cloud import logging as cloud_logging
from google.cloud import secretmanager
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from .secrets import get_secrets


"""Integração de logging e alertas (Slack / Cloud Logging).

Contém a classe `GeradorLog` usada para imprimir logs no console,
enviar entradas estruturadas ao Cloud Logging e acumular erros para
relatório no Slack via `AlertaSlack`.
"""


class GeradorLog:
    """Gerador de logs usado por fluxos de dados.

    - Imprime mensagens no console imediatamente.
    - Se `GCP_LOGGING_ATIVO` estiver habilitado envia logs ao Cloud Logging.
    - Erros podem ser acumulados e posteriormente enviados ao Slack.
    """

    def __init__(self, nome_do_log: str):
        # Lock para operações thread-safe sobre a lista de erros acumulados
        self.lock = threading.Lock()
        self.gcp_logging_ativo = os.environ.get("GCP_LOGGING_ATIVO", "true").lower() == "true"
        self.erros_acumulados = []

        if self.gcp_logging_ativo:
            try:
                self.logging_client = cloud_logging.Client()
                self.gcp_logger = self.logging_client.logger(nome_do_log)
                print("INFO: Logging para o Google Cloud ATIVADO.")
            except Exception as e:
                print(f"CRÍTICO: Falha ao inicializar o cliente do Cloud Logging. Erro: {e}")
                self.logging_client = None
                self.gcp_logger = None
        else:
            self.logging_client = None
            self.gcp_logger = None
            print("INFO: Logging para o Google Cloud DESATIVADO localmente.")

        # Inicializa o alerta Slack (usa SLACK_SECRET_PATH por padrão)
        self.alertador = AlertaSlack(os.environ.get("SLACK_SECRET_PATH", ""), self)

    def add(self, message, severity="INFO", notify_now=False, **extra_data):
        """Adiciona uma entrada de log.

        Args:
            message (str): mensagem do log.
            severity (str): nível (INFO, DEBUG, ERROR, etc.).
            notify_now (bool): se True, em caso de ERROR dispara alerta imediato ao Slack.
            **extra_data: dados extras enviados ao Cloud Logging e/ou usados no alerta.
        """
        with self.lock:
            log_console_message = f"[{severity.upper()}] {message}"
            if extra_data:
                log_console_message += f" | Dados: {extra_data}"

            # Impressão local (sempre)
            print(log_console_message)

            # Envia para Cloud Logging se configurado
            if self.gcp_logger:
                payload = {"message": message, **extra_data}
                self.gcp_logger.log_struct(payload, severity=severity)

            # Acumula ou envia alertas imediatos para severidades altas
            if severity.upper() in ["ERROR", "CRITICAL", "ALERT"]:
                timestamp = datetime.now(pytz.timezone("America/Sao_Paulo")).strftime("%H:%M:%S")
                if notify_now:
                    self.alertador.envia_alerta(
                        consumo=extra_data.get("endpoint", "Processo Principal"),
                        data_execucao=datetime.now(pytz.timezone("America/Sao_Paulo")).strftime("%d/%m/%Y %H:%M:%S"),
                        exception_msg=message,
                    )
                else:
                    erro_formatado = f"[{timestamp}] {extra_data.get('endpoint', '')}: {message}"
                    self.erros_acumulados.append(erro_formatado)

    def reportar_erros_acumulados(self):
        """Envia relatório consolidado dos erros acumulados para o Slack."""
        with self.lock:
            if not self.erros_acumulados:
                print("INFO: Nenhum erro acumulado para reportar.")
                return

            qtd_erros = len(self.erros_acumulados)
            detalhes = "\n".join(self.erros_acumulados[:20])
            if qtd_erros > 20:
                detalhes += f"\n... e mais {qtd_erros - 20} erros."

            msg_final = (
                "Houve "
                f"{qtd_erros} falhas de requisição/página durante a execução.\n\n{detalhes}"
            )

            print("INFO: Enviando relatório consolidado de erros para o Slack.")
            self.alertador.envia_alerta(
                consumo="Relatório de Erros em Lote",
                data_execucao=datetime.now(pytz.timezone("America/Sao_Paulo")).strftime("%d/%m/%Y %H:%M:%S"),
                exception_msg=msg_final,
            )
            # Limpa a lista após envio
            self.erros_acumulados = []


class AlertaSlack:
    """Cliente simples para envio de alertas ao Slack usando token em Secret Manager.

    A classe busca um segredo (JSON) que deve conter a chave `token` e opcionalmente
    `users` com menções.
    """

    def __init__(self, secret_path, gerador_log):
        self.gerador_log = gerador_log
        self.secret_path = secret_path
        self.slack_client = None
        self.channel_id = "dados_csc_tecnico"
        self.users_to_mention = ""
        self.alertas_ativos = os.environ.get("ALERTAS_SLACK_ATIVOS", "true").lower() == "true"
        if self.alertas_ativos:
            self._inicializar_cliente()

    def _inicializar_cliente(self):
        """Inicializa o `WebClient` do Slack lendo o segredo do Secret Manager."""
        try:
            response = get_secrets(self.secret_path)
            if not response:
                print("CRÍTICO: Segredo do Slack não encontrado ou vazio.")
                return
            config = json.loads(response)
            self.slack_client = WebClient(token=config.get("token"))
            self.users_to_mention = config.get("users", "")
            print("INFO: Cliente do Slack inicializado.")
        except Exception as e:
            print(f"CRÍTICO: Erro Slack: {e}")

    def envia_alerta(self, consumo, data_execucao, exception_msg):
        """Envia mensagem formatada para o canal do Slack configurado."""
        if not self.alertas_ativos or not self.slack_client:
            return
        msg = (
            "*:red_circle: Falha!*\n"
            f"*Consumo:* `{consumo}`\n"
            f"*Data:* `{data_execucao}`\n"
            f"```{exception_msg}``` {self.users_to_mention}"
        )
        try:
            self.slack_client.chat_postMessage(channel=self.channel_id, text=msg)
        except SlackApiError:
            # Falha no envio do Slack é silenciosa (não queremos quebrar o fluxo)
            pass
