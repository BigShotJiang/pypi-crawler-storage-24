"""Operações relacionadas a armazenamento/infra (Compute).

Este módulo contém helpers pequenos para operações em Google Compute.
"""
from google.cloud import compute_v1


def parar_vm(instance_name, _project, _zona, gerador_log):
    """Para uma instância do Compute Engine.

    Args:
        instance_name (str): nome da VM a ser parada.
        _project (str): projeto GCP onde a VM está localizada.
        _zona (str): zona da VM.
        gerador_log (GeradorLog): instância de `GeradorLog` para registrar mensagens.

    Observação: a função registra eventos no `gerador_log` e tenta parar a VM
    usando o cliente `compute_v1.InstancesClient().stop`.
    """
    # Log local de início da operação
    gerador_log.add(f"Parando {instance_name}...")
    try:
        # Chamada ao client do Compute para parar a instância
        compute_v1.InstancesClient().stop(
            project=_project,
            zone=_zona,
            instance=instance_name,
        )
        print("VM Parada.")
    except Exception as e:
        # Registra erro sem levantar, para não interromper fluxos que chamam esta util
        gerador_log.add(f"Erro parar VM: {e}", severity="ERROR")
