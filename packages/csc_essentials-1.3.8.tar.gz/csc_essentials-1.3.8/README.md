
# csc-essentials

Pequeno utilitário para integração com Google Cloud (BigQuery, Secret Manager, Cloud Logging, Compute).

## Instalação

```bash
pip install csc-essentials
```

## Quickstart (exemplo rápido)

```python
from google.cloud import bigquery
from csc_essentials.logging import GeradorLog
from csc_essentials.secrets import get_secrets
from csc_essentials.database import inserir_banco_dados

log = GeradorLog("exemplo")
# Ler segredo do Secret Manager (ex.: token Slack)
raw = get_secrets("projects/MEU_PROJ/secrets/SLACK_SECRET/versions/latest")

# Preparar cliente BigQuery
client = bigquery.Client()

# Carregar arquivo NDJSON para uma tabela
inserir_banco_dados(
    arquivo_path="/tmp/dados.ndjson",
    projeto="meu-projeto",
    dataset="meu_dataset",
    tabela="minha_tabela",
    log=log,
    client=client,
    wait_job=True,
)

print("Upload iniciado")
```

## Documentação

- Documentação por módulo em `docs/` (veja `docs/overview.md`).
- Principais módulos: `logging`, `secrets`, `utils`, `database`, `oracle`.

## Contribuindo

- Abra uma issue descrevendo o problema ou feature.
- Envie um Pull Request com testes e descrição clara das mudanças.
- Formato de código: siga o estilo existing do projeto e execute os testes (`pytest`).

## Licença

Este repositório está licenciado conforme o arquivo `LICENSE` na raiz.

## Notas rápidas

- Verifique permissões GCP ao usar `bigquery.Client()` e `secretmanager.SecretManagerServiceClient`.
- Em desenvolvimento local, você pode desativar o envio para Cloud Logging configurando `GCP_LOGGING_ATIVO=false`.
