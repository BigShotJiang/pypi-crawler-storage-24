"""Example: hitting every major endpoint."""

from botindex import BotIndex
import os

bot = BotIndex(api_key=os.environ.get("BOTINDEX_API_KEY"))

print("=== FREE ENDPOINTS ===")

# Discovery — see all available endpoints
catalog = bot.v1.discover()
print(f"Available endpoints: {len(catalog.get('endpoints', []))}")

# Whale alerts summary (free)
whales = bot.hyperliquid.whale_alerts()
print(f"Whales tracked: {whales.summary.whalesTracked}")
print(f"Total value: ${whales.summary.totalTrackedValue:,.0f}")

print("\n=== PAID ENDPOINTS ($0.03-$0.10) ===")

# Zora trending coins
zora = bot.zora.trending_coins(limit=5)
print(f"Zora coins: {len(zora.get('coins', []))}")

# Doppler launches
doppler = bot.doppler.launches(limit=5)
print(f"Doppler launches: {len(doppler.get('launches', []))}")

# Signals (premium)
try:
    signals = bot.v1.signals()
    print(f"Active signals: {len(signals.get('signals', []))}")
except Exception as e:
    print(f"Signals (paid): {e}")
