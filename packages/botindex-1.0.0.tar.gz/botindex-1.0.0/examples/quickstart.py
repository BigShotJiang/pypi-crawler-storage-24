"""Quickstart example — get whale alerts in 3 lines."""

from botindex import BotIndex

# Get free API key: https://api.botindex.dev/api/botindex/keys/register?plan=free
bot = BotIndex()  # Or: BotIndex(api_key="botindex_sk_...")

# Free tier — whale alert summary
whales = bot.hyperliquid.whale_alerts()
print(f"Tracking ${whales.summary.totalTrackedValue:,.0f} in whale positions")
print(f"Top whale: {whales.summary.top_positions[0]['coin']} {whales.summary.top_positions[0]['side']}")

# Paid tier ($0.05) — full data with entry prices, leverage, PnL
# full = bot.hyperliquid.whale_alerts_full()
# print(full.top_positions[0])
