from setuptools import setup, find_packages

setup(
    name="botindex",
    version="1.0.0",
    description="Official Python SDK for BotIndex — whale tracking, prediction markets, crypto signals",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="BotIndex",
    author_email="support@botindex.dev",
    url="https://botindex.dev",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=["httpx>=0.24.0", "pydantic>=2.0.0"],
    python_requires=">=3.9",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Financial",
    ],
    keywords="crypto whale-tracking prediction-markets trading api signals",
)
