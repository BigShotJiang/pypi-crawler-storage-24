"""BotIndex Python SDK — Official SDK for crypto intelligence, compliance, and agent discovery."""

__version__ = "1.0.0"

from botindex.client import BotIndex
from botindex.models import (
    WhaleAlertResponse,
    WhalePosition,
    WhaleTrade,
    SignalResponse,
    ZoraCoin,
    DopplerLaunch,
    HyperliquidFundingArb,
    ApiError,
)

__version__ = "1.0.0"
__all__ = [
    "BotIndex",
    "WhaleAlertResponse",
    "WhalePosition", 
    "WhaleTrade",
    "SignalResponse",
    "ZoraCoin",
    "DopplerLaunch",
    "HyperliquidFundingArb",
    "ApiError",
]
