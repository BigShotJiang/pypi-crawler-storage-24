"""Pydantic models for BotIndex API responses."""

from typing import List, Optional, Any
from pydantic import BaseModel
from datetime import datetime


class ApiError(Exception):
    """Raised when BotIndex API returns an error."""
    pass


class WhalePosition(BaseModel):
    address: str
    coin: str
    szi: str
    entryPx: str
    positionValue: float
    unrealizedPnl: float
    leverage: float
    liquidationPx: Optional[str]
    side: str
    marginUsed: str
    returnOnEquity: float


class WhaleTrade(BaseModel):
    address: str
    coin: str
    px: str
    sz: str
    side: str
    time: int
    dir: str
    closedPnl: str
    hash: str
    usdValue: float


class WhaleAlertSummary(BaseModel):
    totalTrackedValue: float
    whalesTracked: int
    topPositions: List[dict]
    recentTradeCount: int


class WhaleAlertResponse(BaseModel):
    summary: Optional[WhaleAlertSummary] = None
    topPositions: Optional[List[WhalePosition]] = None
    recentLargeTrades: Optional[List[WhaleTrade]] = None
    totalTrackedValue: Optional[float] = None
    whalesTracked: Optional[int] = None
    timestamp: str
    metadata: dict


class SignalResponse(BaseModel):
    signals: List[dict]
    timestamp: str
    metadata: dict


class ZoraCoin(BaseModel):
    name: str
    symbol: str
    address: str
    marketCap: float
    volume24h: float
    price: float


class DopplerLaunch(BaseModel):
    tokenAddress: str
    name: str
    symbol: str
    launchTime: str
    liquidityUsd: float


class HyperliquidFundingArb(BaseModel):
    coin: str
    hyperliquidFunding: float
    binanceFunding: float
    spread: float
    annualizedReturn: float
