# BotIndex Python SDK

Official Python SDK for BotIndex — whale tracking, prediction markets, crypto signals.

## Install

```bash
pip install botindex
```

## Quick Start

```python
from botindex import BotIndex

bot = BotIndex(api_key="botindex_sk_...")

# Whale alerts (free)
whales = bot.hyperliquid.whale_alerts()
print(whales.summary.top_positions)

# Full data ($0.05)
full = bot.hyperliquid.whale_alerts_full()
print(full.top_positions)

# All endpoints
signals = bot.v1.signals()
zora = bot.zora.trending_coins()
```

## Get API Key

Free tier: 100 requests/day
```bash
curl https://api.botindex.dev/api/botindex/keys/register?plan=free
```

## Links

- Docs: https://botindex.dev
- API Reference: https://api.botindex.dev/docs
