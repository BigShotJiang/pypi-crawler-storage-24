﻿from sklearn.base import BaseEstimator, TransformerMixin

from ... import helper_functions


class FeatureNameCleanerTransformer(BaseEstimator, TransformerMixin):
    """
    Normalize/clean DataFrame column names inside an sklearn pipeline.

    Uses :func:`EDA_Utils.HelperFunctions.clean_feature_names` to apply common naming
    conventions such as trimming whitespace, replacing spaces with underscores, and
    converting camelCase/PascalCase to snake_case.

    Notes
    -----
    This transformer only changes column names; it does not modify values.
    """
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()
        X.columns = helper_functions.clean_feature_names(X.columns)
        return X
