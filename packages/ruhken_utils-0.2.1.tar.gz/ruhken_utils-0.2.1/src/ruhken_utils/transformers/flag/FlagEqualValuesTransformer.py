﻿from sklearn.base import BaseEstimator, TransformerMixin


class FlagEqualValuesTransformer(BaseEstimator, TransformerMixin):
    """
    Create a binary flag indicating whether two feature columns have identical values.

    Parameters
    ----------
    column_a : str
        Name of the first column.
    column_b : str
        Name of the second column.
    new_column : str
        Name of the output flag column.
    """

    def __init__(self, column_a, column_b, new_column, invert_output=False):
        self.column_a = column_a
        self.column_b = column_b
        self.new_column = new_column
        self.invert_output = invert_output

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()

        if self.column_a not in X.columns or self.column_b not in X.columns:
            raise ValueError("One or both columns not found in DataFrame")

        X[self.new_column] = X[self.column_a].eq(X[self.column_b]).fillna(False)

        if self.invert_output:
            X[self.new_column] = ~X[self.new_column]

        return X
