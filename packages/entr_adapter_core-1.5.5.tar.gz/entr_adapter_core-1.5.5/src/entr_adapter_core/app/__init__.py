"""ENTR Adapter Core application components.

Provides the app factory, router, and dispatcher for building adapter apps.
"""

from .dispatcher import Dispatcher
from .factory import create_adapter_app
from .router import create_adapter_router

__all__ = [
    "Dispatcher",
    "create_adapter_app",
    "create_adapter_router",
]
