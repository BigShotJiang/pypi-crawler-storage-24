"""Fuzzy matching engine for entity resolution.

Provides a configurable, data-source-agnostic matching engine that uses
rapidfuzz for weighted fuzzy scoring. Designed for matching extracted
document data (e.g., product descriptions, customer names) against known
entities in a tenant's system.

Requires the ``[matching]`` extra::

    uv add entr-adapter-core[matching]

Public API:
    - ``MatchingEngine``: Main engine class — accepts config and entity data.
    - ``MatchConfig``: Pydantic model for matching configuration.
    - ``MatchResult``: Pydantic model for match results.
    - ``normalize_text``: Text normalization utility.

Usage::

    from entr_adapter_core.utils.matching import MatchingEngine, MatchConfig

    config = MatchConfig(
        id_field="ItemCode",
        description_field="Description",
        score_threshold=90.0,
        synonym_map={"bubble": "bubbel"},
        stopwords={"de", "het"},
    )
    engine = MatchingEngine(config)

    entities = [
        {"ItemCode": "A001", "Description": "Blue bubble wrap 50x60"},
        {"ItemCode": "A002", "Description": "Brown cardboard box"},
    ]

    result = engine.match("bubbel folie blauw", entities)
    if result:
        print(f"Matched: {result.entity_id} (score: {result.score})")
"""

from entr_adapter_core.utils.matching.config import MatchConfig
from entr_adapter_core.utils.matching.normalizer import normalize_text

# Lazy import for engine and result — they require rapidfuzz
try:
    from entr_adapter_core.utils.matching.engine import MatchingEngine, MatchResult
except ImportError:
    MatchingEngine = None  # type: ignore[assignment,misc]
    MatchResult = None  # type: ignore[assignment,misc]

__all__ = [
    "MatchConfig",
    "MatchingEngine",
    "MatchResult",
    "normalize_text",
]
