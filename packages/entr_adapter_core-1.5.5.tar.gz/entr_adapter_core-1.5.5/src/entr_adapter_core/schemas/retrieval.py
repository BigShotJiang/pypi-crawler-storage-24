"""Retrieval schemas for the document retrieval contract.

These models define the structure of data exchanged between ENTR Core
and tenant adapters for document listing and downloading operations.
"""

from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from entr_adapter_core.schemas.response import StatusEnum


class RetrievalPayload(BaseModel):
    """Payload sent from Core to adapter for listing available documents.

    Core sends this to the adapter's /list_documents endpoint to discover
    new documents from an external source (email, FTP, API, etc.).
    """

    source_identifier: str = Field(
        ..., description="Identifier for the adapter process/source to query"
    )
    date_from: date = Field(
        ..., description="Date to filter documents from (inclusive)"
    )
    params: Optional[Dict[str, Any]] = Field(
        None, description="Optional parameters for the retrieval process"
    )


class DocumentIdentifier(BaseModel):
    """Represents a document available for download from an external source."""

    document_identifier: str = Field(
        ..., description="Unique identifier to use when requesting a document download"
    )
    filename: str = Field(
        ..., description="Original filename, used for display or deduplication"
    )


class RetrievalResponse(BaseModel):
    """Response from adapter after listing available documents."""

    status: StatusEnum = Field(
        ..., description="Status of the retrieval operation"
    )
    message: str | None = Field(
        None, description="Optional message describing the result or error"
    )
    documents: List[DocumentIdentifier] = Field(
        default_factory=list, description="List of documents available for download"
    )


class DocumentDownloadPayload(BaseModel):
    """Payload to request the download of a specific document."""

    source_identifier: str = Field(
        ..., description="Identifier for the document source"
    )
    document_identifier: str = Field(
        ..., description="Unique identifier for the document to download"
    )


class DocumentDownloadResponse(BaseModel):
    """Response containing the content of a downloaded document."""

    document_identifier: str = Field(
        ..., description="Filename for the document"
    )
    adapter_document_id: str = Field(
        ..., description="Unique document ID from source system, used for deduplication (e.g., email UID, file ID)"
    )
    content_b64: str = Field(
        ..., description="Base64-encoded content of the document"
    )
