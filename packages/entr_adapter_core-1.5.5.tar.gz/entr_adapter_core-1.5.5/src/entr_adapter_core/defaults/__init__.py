"""Deployment defaults and override resolution for ENTR Adapter."""

from entr_adapter_core.defaults.resolve import (
    DEFAULT_OVERRIDE_DIR,
    ResolvedFile,
    log_resolution_summary,
    resolve_all_files,
    resolve_compose_files,
    resolve_file,
)

__all__ = [
    "DEFAULT_OVERRIDE_DIR",
    "ResolvedFile",
    "log_resolution_summary",
    "resolve_all_files",
    "resolve_compose_files",
    "resolve_file",
]
