"""Smoke tests for create_adapter_router()."""

import pytest
from fastapi import APIRouter, FastAPI

from entr_adapter_core.app import create_adapter_router

from tests.mock_handler import MockProcessHandler


class TestRouterSmoke:

    def test_create_adapter_router_returns_router(self):
        router = create_adapter_router(
            handlers={"mock": MockProcessHandler()}
        )
        assert isinstance(router, APIRouter)

    def test_router_includes_standard_routes(self):
        router = create_adapter_router(
            handlers={"mock": MockProcessHandler()}
        )
        route_paths = [r.path for r in router.routes]
        assert "/process" in route_paths
        assert "/list_documents" in route_paths
        assert "/download_document" in route_paths
        assert "/health" in route_paths

    @pytest.mark.asyncio
    async def test_router_can_be_included_in_custom_app(self):
        app = FastAPI()
        router = create_adapter_router(
            handlers={"mock": MockProcessHandler()}
        )
        app.include_router(router)

        from httpx import ASGITransport, AsyncClient

        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            response = await client.get("/health")

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_router_with_custom_routes_coexist(self):
        app = FastAPI()

        @app.get("/custom")
        async def custom_route():
            return {"custom": True}

        router = create_adapter_router(
            handlers={"mock": MockProcessHandler()}
        )
        app.include_router(router)

        from httpx import ASGITransport, AsyncClient

        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as client:
            custom_resp = await client.get("/custom")
            health_resp = await client.get("/health")

        assert custom_resp.status_code == 200
        assert custom_resp.json() == {"custom": True}
        assert health_resp.status_code == 200
