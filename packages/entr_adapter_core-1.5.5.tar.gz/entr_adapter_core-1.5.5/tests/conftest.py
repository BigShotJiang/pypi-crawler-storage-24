"""Shared test fixtures for ENTR Adapter Core tests."""

import logging

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from entr_adapter_core.app import create_adapter_app, create_adapter_router
from entr_adapter_core.schemas import (
    AppliedMapping,
    DocumentPayload,
)

from tests.mock_handler import (
    MockFailingHandler,
    MockProcessHandler,
    MockRetrievalHandler,
    MockReviewHandler,
    MockStatefulHandler,
)


@pytest.fixture(autouse=True)
def _ensure_root_logger_debug():
    """Ensure root logger captures DEBUG+ so flight recorder tests work."""
    root = logging.getLogger()
    original_level = root.level
    root.setLevel(logging.DEBUG)
    yield
    root.setLevel(original_level)


@pytest.fixture
def sample_payload() -> DocumentPayload:
    """A representative DocumentPayload for testing."""
    return DocumentPayload(
        adapter_identifier="mock",
        document_id=1,
        data={
            "invoice_number": "INV-001",
            "amount": 100.0,
            "vendor": "Test Corp",
        },
    )


@pytest.fixture
def sample_payload_with_mappings() -> DocumentPayload:
    """A DocumentPayload with applied_mappings and original_data populated."""
    return DocumentPayload(
        adapter_identifier="mock",
        document_id=2,
        data={
            "invoice_number": "INV-002",
            "amount": 200.0,
            "vendor": "Mapped Corp",
        },
        original_data={
            "invoice_number": "INV-002",
            "amount": 200.0,
            "vendor": "Original Corp",
        },
        applied_mappings=[
            AppliedMapping(
                field_path="vendor",
                mapping_field="vendor",
                original_value="Original Corp",
                mapped_value="Mapped Corp",
            ),
        ],
    )


@pytest.fixture
def mock_handlers() -> dict:
    """Handler dict with process, review, and failing handlers."""
    return {
        "mock": MockProcessHandler(),
        "review": MockReviewHandler(),
        "failing": MockFailingHandler(),
    }


@pytest.fixture
def mock_handlers_with_retrieval() -> dict:
    """Handler dict including a handler with a retrieval handler attached."""
    return {
        "mock": MockProcessHandler(retrieval_handler=MockRetrievalHandler()),
        "review": MockReviewHandler(),
        "failing": MockFailingHandler(),
    }


@pytest.fixture
def mock_handlers_with_stateful() -> dict:
    """Handler dict including the stateful handler for concurrency tests."""
    return {
        "mock": MockProcessHandler(),
        "stateful": MockStatefulHandler(),
    }


@pytest_asyncio.fixture
async def app_client(mock_handlers_with_retrieval):
    """AsyncClient against a factory-created app for contract tests."""
    app = create_adapter_app(handlers=mock_handlers_with_retrieval)
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client


@pytest_asyncio.fixture
async def router_client(mock_handlers_with_retrieval):
    """AsyncClient against a minimal app using create_adapter_router."""
    from fastapi import FastAPI

    app = FastAPI()
    router = create_adapter_router(handlers=mock_handlers_with_retrieval)
    app.include_router(router)

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client
