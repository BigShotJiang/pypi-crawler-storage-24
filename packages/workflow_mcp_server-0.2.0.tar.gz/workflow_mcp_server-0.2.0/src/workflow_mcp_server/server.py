from mcp.server.fastmcp import FastMCP
from pathlib import Path
import re

# Initialize the MCP server
mcp = FastMCP("Workflow Manager")

# -----------------------------------------------------------------------------
# 1. PROMPT: Injects the rules at the start of the conversation
# -----------------------------------------------------------------------------


@mcp.prompt()
def workflow_instructions() -> str:
    """
    Loads the core workflow and task instructions into the model's context.
    Use this prompt at the beginning of a session to set the behavior.
    """
    return """
# Workflow Instructions

For every new task, you must begin by collecting a task ID from the user with the `ask_user` tool.

## Planning Workflow

Always stay in a planning stage until the user confirms the plan.

1. Use `ask_user` to request the task ID from the user.
2. Call `resolve_task_plan_file` with that task ID and use the returned filename.
3. Use that exact filename to create the task's plan markdown file.
4. After creating or updating the plan file, use the `ask_user` tool in options mode with these choices:
   - `Review plan`
   - `Confirm task`
5. If the user chooses `Review plan`, call `read_task_plan` with the current task ID. It means the user has already modified that specific task's resolved plan file. Re-read only that ID-specific plan file, account for the user's edits in that file, and then ask again with the same two options.
6. Repeat this review loop until the user chooses `Confirm task`.

Only use the filename returned by `resolve_task_plan_file` for the current task ID. Do not use plan files from other task IDs or other sessions.

You must not begin executing the task until the user has confirmed the current task's ID-specific plan.

## Task Completion Workflow

After finishing a task, always ask the user if there are any remaining tasks to complete.
If there is another task, start the workflow again by collecting a new task ID with `ask_user`.

## Enforcement Mechanism

To help you follow these rules, you have access to the tool `confirm_task_completion`.
- You must call this tool when you believe a task is done.
- The tool will remind you to ask the user for the next task.
- You must not end your response without asking for the next task.
"""


# -----------------------------------------------------------------------------
# 2. TOOLS: Active enforcement during the conversation
# -----------------------------------------------------------------------------


@mcp.tool()
def resolve_task_plan_file(task_id: str) -> str:
    """
    Validate a task ID and return the exact plan filename for that task.
    Use this before creating or reviewing a plan so each task stays scoped
    to its own plan file.
    """
    normalized_task_id = task_id.strip()
    if not normalized_task_id:
        raise ValueError("Task ID cannot be empty.")

    if not re.fullmatch(r"[A-Za-z0-9_-]+", normalized_task_id):
        raise ValueError(
            "Task ID may only contain letters, numbers, underscores, and hyphens."
        )

    return f"{normalized_task_id}_plan.md"


def _plan_path_for_task(task_id: str) -> Path:
    return Path.cwd() / resolve_task_plan_file(task_id)


@mcp.tool()
def read_task_plan(task_id: str) -> str:
    """
    Read the exact plan file for a validated task ID.
    Use this during review so the workflow only reads the current task's plan file.
    """
    plan_path = _plan_path_for_task(task_id)
    if not plan_path.exists():
        raise FileNotFoundError(f"Plan file not found: {plan_path.name}")

    return plan_path.read_text(encoding="utf-8")


@mcp.tool()
def confirm_task_completion(task_name: str) -> str:
    """
    Call this tool when you have finished executing a specific task.
    This tool records the completion and enforces the workflow rule
    to ask the user for the next task.
    """
    # In a real app, you might save this to a database.
    # Here we just return the enforcement reminder.
    return (
        f"Task '{task_name}' has been marked as complete.\n\n"
        "⚠️ WORKFLOW REMINDER: Per your instructions, you must now ask the user "
        "if there are any remaining tasks before ending your turn. If the user gives "
        "you another task, restart the workflow by collecting a new task ID with "
        "`ask_user` and creating a new `<task_id>_plan.md` file."
    )


@mcp.tool()
def start_planning_phase(topic: str) -> str:
    """
    Call this tool when you are beginning a new task to enter the 'Planning Stage'.
    This reminds you to ask clarifying questions before executing.
    """
    return (
        f"Planning phase started for: '{topic}'.\n\n"
        "⚠️ TASK REMINDER: You are now in the planning stage. First collect a task ID "
        "with `ask_user`, call `resolve_task_plan_file` to get the exact plan filename, "
        "create that file, and then use "
        "`ask_user` options `Review plan` and `Confirm task` in a loop until the user "
        "confirms the plan. If the user selects `Review plan`, treat that as a signal "
        "that they already edited that exact resolved plan file, call `read_task_plan` "
        "with the current task ID, and only review that ID-specific file for the "
        "current task. Do not execute the task before that confirmation."
    )


def main():
    mcp.run()


if __name__ == "__main__":
    # Run the server using stdio transport (default for most clients)
    main()
