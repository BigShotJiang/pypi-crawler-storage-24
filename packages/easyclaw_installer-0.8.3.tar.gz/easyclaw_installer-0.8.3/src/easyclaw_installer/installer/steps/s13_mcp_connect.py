"""Step 13: Connect OpenClaw to the MCP knowledge base server."""

from ..base_step import BaseStep


class MCPConnectStep(BaseStep):
    name = "MCP Connect"
    description = "Connect OpenClaw instance to the MCP knowledge base"
    timeout = 60
    allow_retry = True
    max_retries = 2

    def validate_preconditions(self) -> tuple[bool, str]:
        import shutil

        if not shutil.which("openclaw"):
            return False, "OpenClaw CLI not found"
        return True, ""

    def command(self) -> str:
        return (
            "set -e\n"
            "echo 'Connecting to MCP knowledge base...'\n"
            "openclaw mcp connect 2>&1\n"
            "echo ''\n"
            "echo 'Verifying MCP connection...'\n"
            "openclaw mcp status 2>&1\n"
            "echo ''\n"
            "echo 'MCP connection established.'"
        )
