# UniArticles MCP Server

A unified Model Context Protocol (MCP) server for retrieving academic literature from multiple sources.

## 🌟 Features

- **Unified Interface**: Consistent return structure across all data sources.
- **Multi-Source Support**:
  - **Scopus**: Extensive abstract and citation database.
  - **Semantic Scholar**: AI-driven research tool.
  - **ArXiv**: Open access archive for scholarly articles.
  - **ChemRxiv**: Open access preprint archive for chemistry.
- **MCP Standard**: Built on the FastMCP framework for easy integration with Claude and other MCP clients.

## 🚀 Installation

### Prerequisites
- Python 3.10 or higher
- `uv` (recommended) or `pip`

### Using uv (Recommended)

```bash
# Clone the repository
git clone <repository-url>
cd UniArticles_MCPserver

# Install dependencies
uv sync
```

### Using pip

```bash
pip install -e .
```

## ⚙️ Configuration

Create a `.env` file in the project root or set environment variables:

```env
# Required for Scopus
SCOPUS_API_KEY=your_scopus_api_key

# Optional (Recommended for higher limits)
SEMANTICSCHOLAR_API_KEY=your_semanticscholar_api_key
```

### ⚠️ Important Notes
- **API Key Handling**: If you do not have an API key for a service (e.g., Semantic Scholar), **you must delete the corresponding line** from the configuration. Do not leave it as `your_key_here`, otherwise the service will try to authenticate with that invalid string and fail (e.g., returning 403 Forbidden).
- **Scopus**: If `SCOPUS_API_KEY` is missing, Scopus search will return errors, but other tools will work.
- **Semantic Scholar**: If `SEMANTICSCHOLAR_API_KEY` is missing (i.e., the line is deleted), the service will automatically fallback to the public API (lower rate limits but functional).

## 🏃 Usage

### Running Locally

```bash
# Using uv
uv run uniarticles-mcp

# Using python directly
python -m uniarticles
```

### With Claude Desktop

#### Option 1: Via PyPI (Recommended if published)
If you have published the package to PyPI (or are installing from a git URL), use `uvx`:

> **Note**: In the example below, `SEMANTICSCHOLAR_API_KEY` is omitted. Remove it if you don't have a key.

```json
{
  "mcpServers": {
    "uniarticles": {
      "command": "uvx",
      "args": [
        "uniarticles-mcp"
      ],
      "env": {
        "SCOPUS_API_KEY": "your_scopus_key_here"
      }
    }
  }
}
```

#### Option 2: Full Configuration (With all keys)
```json
{
  "mcpServers": {
    "uniarticles": {
      "command": "uvx",
      "args": [
        "uniarticles-mcp"
      ],
      "env": {
        "SCOPUS_API_KEY": "your_scopus_key_here",
        "SEMANTICSCHOLAR_API_KEY": "your_semanticscholar_key_here"
      }
    }
  }
}
```

#### Option 3: Local Development
If you are running from source code locally:

```json
{
  "mcpServers": {
    "uniarticles": {
      "command": "uv",
      "args": [
        "--directory",
        "C:/absolute/path/to/UniArticles_MCPserver/UniArticles_MCPserver",
        "run",
        "uniarticles-mcp"
      ],
      "env": {
        "SCOPUS_API_KEY": "your_scopus_key_here",
        "SEMANTICSCHOLAR_API_KEY": "your_semanticscholar_key_here"
      }
    }
  }
}
```

## 🛠️ Development

### Running Tests

```bash
# Run integration tests
python -m unittest tests/test_integration.py
```

### Project Structure

```text
src/uniarticles/
├── sources/           # Individual data source modules
│   ├── arxiv.py
│   ├── scopus.py
│   ├── ...
├── server.py          # Main server entry point
└── config.py          # Configuration management
```

## 📄 License

[MIT License](LICENSE)
