import os
from dataclasses import dataclass

from dotenv import load_dotenv


load_dotenv()


@dataclass(frozen=True)
class Settings:
    scopus_api_key: str | None = os.getenv("SCOPUS_API_KEY")
    semanticscholar_api_key: str | None = os.getenv("SEMANTICSCHOLAR_API_KEY")


settings = Settings()
