import asyncio

import arxiv
from mcp.server.fastmcp import FastMCP


def _ok(query: str, items: list[dict]) -> dict:
    return {
        "ok": True,
        "source": "arxiv",
        "query": query,
        "count": len(items),
        "items": items,
        "error": None,
    }


def _err(query: str, message: str) -> dict:
    return {
        "ok": False,
        "source": "arxiv",
        "query": query,
        "count": 0,
        "items": [],
        "error": message,
    }


def _run_arxiv_search(query: str, max_results: int) -> dict:
    client = arxiv.Client()
    search = arxiv.Search(
        query=query,
        max_results=max_results,
        sort_by=arxiv.SortCriterion.SubmittedDate,
    )
    papers = []
    for paper in client.results(search):
        papers.append(
            {
                "id": paper.get_short_id(),
                "title": paper.title,
                "authors": [author.name for author in paper.authors],
                "abstract": paper.summary,
                "published": paper.published.isoformat(),
                "categories": paper.categories,
                "pdf_url": paper.pdf_url,
            }
        )
    return _ok(query=query, items=papers)


def register(server: FastMCP) -> None:
    @server.tool()
    async def search_arxiv(query: str, max_results: int = 10) -> dict:
        normalized_query = query.strip()
        bounded = max(1, min(max_results, 25))
        if not normalized_query:
            return _err(query=query, message="query must not be empty")
        try:
            return await asyncio.to_thread(_run_arxiv_search, normalized_query, bounded)
        except Exception as exc:
            return _err(query=normalized_query, message=str(exc))
