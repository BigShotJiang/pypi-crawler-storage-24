import httpx
from mcp.server.fastmcp import FastMCP


BASE_URL = "https://chemrxiv.org/engage/chemrxiv/public-api/v1"


def _ok(term: str, items: list[dict]) -> dict:
    return {
        "ok": True,
        "source": "chemrxiv",
        "query": term,
        "count": len(items),
        "items": items,
        "error": None,
    }


def _err(term: str, message: str) -> dict:
    return {
        "ok": False,
        "source": "chemrxiv",
        "query": term,
        "count": 0,
        "items": [],
        "error": message,
    }


def _normalize_item(item: dict) -> dict:
    return {
        "itemId": item.get("itemId") or item.get("id"),
        "doi": item.get("doi"),
        "title": item.get("title"),
        "abstract": item.get("abstract"),
        "authors": item.get("authors"),
        "publishedDate": item.get("publishedDate") or item.get("published"),
        "url": item.get("url"),
        "license": item.get("license"),
    }


async def _search_items(term: str, limit: int, page: int | None, sort: str | None) -> dict:
    params = {"term": term, "limit": limit}
    if page is not None:
        params["page"] = page
    if sort:
        params["sort"] = sort
    async with httpx.AsyncClient(timeout=20.0) as client:
        response = await client.get(f"{BASE_URL}/items", params=params)
        response.raise_for_status()
        payload = response.json()
    items = payload.get("items") or payload.get("results") or []
    normalized = [_normalize_item(item) for item in items]
    return _ok(term=term, items=normalized)


def register(server: FastMCP) -> None:
    @server.tool()
    async def search_chemrxiv(
        term: str,
        limit: int = 10,
        page: int | None = None,
        sort: str | None = None,
    ) -> dict:
        normalized_term = term.strip()
        bounded = max(1, min(limit, 50))
        if not normalized_term:
            return _err(term=term, message="term must not be empty")
        try:
            return await _search_items(term=normalized_term, limit=bounded, page=page, sort=sort)
        except Exception as exc:
            return _err(term=normalized_term, message=str(exc))
