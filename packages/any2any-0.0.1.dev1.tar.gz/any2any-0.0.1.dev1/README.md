# any2any – Universal File Converter

Convert any file to any other file using pure Python libraries. No external binaries required (except optional ones for some formats). Uses a graph of 386 formats to find a conversion path via BFS.

## Features

- **PDF to video slideshow** – renders each page to an image, then creates a video.
- **Image to video** – loop a single image for a few seconds.
- **Document conversion** – uses pandoc (via pypandoc) for markdown, docx, etc.
- **Text to speech** – uses pyttsx3 (native OS) or espeak‑ng.
- **Many image formats** – via Pillow.
- **Specialized formats** (optional) – MIDI, Minecraft NBT, BSON, JSON5, and more.

## Installation

```bash
pip install any2any
```

For optional game formats:

```bash
pip install any2any[game]
```

## Requirements

- Python 3.8 or later
- No system‑wide dependencies needed for basic operation – the package bundles or automatically downloads all required libraries (e.g., pypandoc will download pandoc on first use).

## Usage

```bash
any2any input.pdf output.mp4
```

First run will build the conversion graph from the included `cache.json`. Subsequent runs load it instantly.

## How it works

1. The graph (derived from the original [convert.to.it](https://convert.to.it/) project) defines which formats can be directly converted by which tools.
2. BFS finds the shortest path from input format to output format.
3. Each step uses a pure Python library (or subprocess fallback) to perform the conversion, possibly creating intermediate files in a temporary directory.

## Examples

- Convert a multi‑page PDF to a slideshow video (1 second per page):

```bash
any2any document.pdf slideshow.mp4
```

- Convert a single JPEG to a 5‑second MP4 loop:

```bash
any2any photo.jpg video.mp4
```

- Convert a Markdown file to DOCX:

```bash
any2any readme.md report.docx
```

## Limitations

- Some conversions (e.g., complex video filters) may not be supported by the pure Python libraries.
- The package relies on `pypandoc` to handle document conversions; it may take a few seconds to download pandoc on first use.
- For text‑to‑speech, the script attempts to use `espeak-ng` via subprocess; if not found, it falls back to `pyttsx3` (which uses native OS speech).

## License

GPL‑2.0‑or‑later (to match the original project). See [LICENSE](LICENSE).

## Acknowledgements

Based on the format graph from [convert.to.it](https://github.com/p2r3/convert) and the original TypeScript handlers.
