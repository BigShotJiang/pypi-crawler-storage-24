#!/usr/bin/env python3
"""
Any‑to‑Any Converter using pure Python libraries.
"""

import os
import sys
import json
import tempfile
import shutil
import subprocess
from collections import deque
import tqdm

# Attempt to import libraries; if missing, we'll raise an error.
try:
    import pypdfium2 as pdfium
except ImportError:
    pdfium = None

try:
    from moviepy.editor import ImageSequenceClip
except ImportError:
    ImageSequenceClip = None

try:
    from PIL import Image
except ImportError:
    Image = None

try:
    import pypandoc
except ImportError:
    pypandoc = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

try:
    import vtracer
except ImportError:
    vtracer = None

# Other optional libraries (not used in core, but imported if available)
try:
    import mido
except ImportError:
    mido = None

try:
    import nbtlib
except ImportError:
    nbtlib = None

try:
    import bson
except ImportError:
    bson = None

try:
    import json5
except ImportError:
    json5 = None

CACHE_FILE = "cache.json"  # will be overridden by user cache dir

# ----------------------------------------------------------------------
# Graph building (if cache missing)
# ----------------------------------------------------------------------

def get_ffmpeg_formats():
    """Return (input_formats, output_formats) as sets (via subprocess)."""
    if not shutil.which("ffmpeg"):
        return set(), set()
    out = subprocess.run(["ffmpeg", "-formats"], capture_output=True, text=True).stdout
    inputs, outputs = set(), set()
    for line in out.splitlines():
        if line.startswith((" D", " DE", " DEd")):
            parts = line.split()
            if len(parts) < 2:
                continue
            fmt = parts[1]
            for name in fmt.split(","):
                inputs.add(name.strip())
        if line.startswith((" E", " DE", " DEd")):
            parts = line.split()
            if len(parts) < 2:
                continue
            fmt = parts[1]
            for name in fmt.split(","):
                outputs.add(name.strip())
    return inputs, outputs

def get_pandoc_formats():
    if not shutil.which("pandoc"):
        return set(), set()
    inp = subprocess.run(["pandoc", "--list-input-formats"], capture_output=True, text=True).stdout
    out = subprocess.run(["pandoc", "--list-output-formats"], capture_output=True, text=True).stdout
    inputs = {f.strip() for f in inp.splitlines() if f.strip()}
    outputs = {f.strip() for f in out.splitlines() if f.strip()}
    return inputs, outputs

def get_imagemagick_formats():
    tool = None
    if shutil.which("magick"):
        tool = "magick"
    elif shutil.which("convert"):
        tool = "convert"
    else:
        return set(), set()
    out = subprocess.run([tool, "-list", "format"], capture_output=True, text=True).stdout
    inputs, outputs = set(), set()
    for line in out.splitlines():
        if not line.strip() or line.startswith(" "):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        fmt = parts[0].lower().rstrip('*')
        flags = parts[1] if len(parts) > 1 else ""
        if "r" in flags:
            inputs.add(fmt)
        if "w" in flags:
            outputs.add(fmt)
    return inputs, outputs

def build_conversion_graph():
    adjacency = {}
    edge_tool = {}

    # Auto‑detected capabilities
    for inp, out in [(get_ffmpeg_formats(), "ffmpeg"),
                     (get_pandoc_formats(), "pandoc"),
                     (get_imagemagick_formats(), "magick")]:
        inputs, outputs = inp
        for i in inputs:
            for o in outputs:
                if i == o:
                    continue
                adjacency.setdefault(i, set()).add(o)
                edge_tool[(i, o)] = out

    # Manual bridges (cross‑media)
    if shutil.which("magick") or shutil.which("convert"):
        for img in ["png", "jpg", "jpeg", "bmp", "tiff"]:
            adjacency.setdefault("pdf", set()).add(img)
            edge_tool[("pdf", img)] = "magick"

    if shutil.which("ffmpeg"):
        for img in ["png", "jpg", "jpeg", "bmp", "tiff"]:
            for vid in ["mp4", "mkv", "avi", "webm", "gif"]:
                adjacency.setdefault(img, set()).add(vid)
                edge_tool[(img, vid)] = "ffmpeg"

    if shutil.which("espeak-ng"):
        adjacency.setdefault("txt", set()).add("wav")
        edge_tool[("txt", "wav")] = "espeak"
        adjacency.setdefault("txt", set()).add("mp3")
        edge_tool[("txt", "mp3")] = "espeak"

    # Convert sets to lists for JSON
    adjacency = {k: list(v) for k, v in adjacency.items()}
    edge_tool_json = {f"{k[0]}|{k[1]}": v for k, v in edge_tool.items()}
    return adjacency, edge_tool, edge_tool_json

def load_or_build_cache(force_rebuild=False):
    """Load cache from disk if exists and not forced to rebuild, else build."""
    if not force_rebuild and os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE) as f:
                data = json.load(f)
            adjacency = data["adjacency"]
            edge_tool_json = data["edge_tool"]
            edge_tool = {tuple(k.split("|")): v for k, v in edge_tool_json.items()}
            return adjacency, edge_tool
        except Exception:
            pass
    print("Building conversion graph... (this may take a few seconds)")
    adjacency, edge_tool, edge_tool_json = build_conversion_graph()
    with open(CACHE_FILE, "w") as f:
        json.dump({"adjacency": adjacency, "edge_tool": edge_tool_json}, f, indent=2)
    print("Graph built and cached.")
    return adjacency, edge_tool

# ----------------------------------------------------------------------
# BFS path finder
# ----------------------------------------------------------------------

def find_path(adjacency, start, end):
    if start == end:
        return [start]
    queue = deque([(start, [start])])
    visited = {start}
    while queue:
        current, path = queue.popleft()
        for nxt in adjacency.get(current, []):
            if nxt == end:
                return path + [end]
            if nxt not in visited:
                visited.add(nxt)
                queue.append((nxt, path + [nxt]))
    return None

# ----------------------------------------------------------------------
# Conversion execution
# ----------------------------------------------------------------------

def convert_with_tool(tool, input_data, output_path, input_fmt, output_fmt):
    """Perform conversion using pure Python libraries, falling back to subprocess if needed."""
    if tool == "magick" or tool == "pdf2image":
        # PDF to image sequence using pypdfium2
        if input_fmt == "pdf" and output_fmt in ["jpg", "jpeg", "png"]:
            if pdfium is None:
                raise ImportError("pypdfium2 is required for PDF conversion")
            pdf = pdfium.PdfDocument(input_data)
            temp_dir = tempfile.mkdtemp(prefix="any2any_")
            image_paths = []
            for i in range(len(pdf)):
                bitmap = pdf[i].render(scale=150/72)  # 150 DPI
                img = bitmap.to_pil()
                path = os.path.join(temp_dir, f"page_{i:04d}.jpg")
                img.save(path, "JPEG", quality=85)
                image_paths.append(path)
                # optional progress
                # if tqdm: tqdm.tqdm.write(f"Rendered page {i+1}/{len(pdf)}")
            pattern = os.path.join(temp_dir, "page_%04d.jpg")
            return ("sequence", pattern, temp_dir, image_paths)

    elif tool == "ffmpeg" or tool == "moviepy":
        # Image sequence to video
        if isinstance(input_data, tuple) and input_data[0] == "sequence":
            _, pattern, temp_dir, image_paths = input_data
            if ImageSequenceClip is None:
                raise ImportError("moviepy is required for video creation")
            clip = ImageSequenceClip(image_paths, fps=1)  # 1 second per image
            clip.write_videofile(output_path, codec="libx264", verbose=False, logger=None)
            shutil.rmtree(temp_dir, ignore_errors=True)
            return output_path
        else:
            # Single image to video loop
            if ImageSequenceClip is None:
                raise ImportError("moviepy is required for video creation")
            # Create a short video by looping the image
            clip = ImageSequenceClip([input_data], fps=0.2)  # 5 seconds
            clip.write_videofile(output_path, codec="libx264", verbose=False, logger=None)
            return output_path

    elif tool == "pandoc":
        if pypandoc is None:
            raise ImportError("pypandoc is required for document conversion")
        try:
            pypandoc.convert_file(input_data, output_fmt, outputfile=output_path)
        except Exception as e:
            # Fallback to subprocess
            subprocess.run(["pandoc", input_data, "-o", output_path], check=True)
        return output_path

    elif tool == "espeak":
        # Text to speech
        if pyttsx3 is not None:
            engine = pyttsx3.init()
            # pyttsx3 doesn't directly save to file; we can use a temporary approach
            # but easier: fallback to subprocess
            pass
        if shutil.which("espeak-ng"):
            subprocess.run(["espeak-ng", "-f", input_data, "-w", output_path], check=True)
            return output_path
        else:
            raise RuntimeError("No text-to-speech tool available (install espeak-ng or pyttsx3)")

    else:
        raise ValueError(f"Unknown tool: {tool}")

def any_to_any(input_file, output_file, adjacency, edge_tool):
    in_fmt = os.path.splitext(input_file)[1][1:].lower()
    out_fmt = os.path.splitext(output_file)[1][1:].lower()

    path = find_path(adjacency, in_fmt, out_fmt)
    if not path:
        raise ValueError(f"No conversion path found from {in_fmt} to {out_fmt}")

    print(f"Conversion path: {' -> '.join(path)}")

    current = input_file
    temp_dirs = []

    for i in range(len(path) - 1):
        src_fmt = path[i]
        dst_fmt = path[i+1]
        tool = edge_tool.get((src_fmt, dst_fmt))

        with tempfile.NamedTemporaryFile(suffix=f".{dst_fmt}", delete=False) as tmp:
            tmp_path = tmp.name

        print(f"Step {i+1}: {src_fmt} -> {dst_fmt} using {tool}")

        if isinstance(current, tuple) and current[0] == "sequence":
            _, pattern, td, _ = current
            result = convert_with_tool(tool, current, tmp_path, src_fmt, dst_fmt)
            if td not in temp_dirs:
                temp_dirs.append(td)
        else:
            result = convert_with_tool(tool, current, tmp_path, src_fmt, dst_fmt)

        # Clean up previous single file (but not the original input)
        if isinstance(current, str) and current != input_file:
            os.unlink(current)
        current = result

    # Final move to output
    if isinstance(current, tuple) and current[0] == "sequence":
        raise RuntimeError("Unexpected: final result is a sequence, not a single file.")
    else:
        shutil.move(current, output_file)

    for td in temp_dirs:
        shutil.rmtree(td, ignore_errors=True)

    print(f"Done! Output: {output_file}")

# ----------------------------------------------------------------------
# Command‑line interface
# ----------------------------------------------------------------------

def main():
    # Check if we have the essentials
    try:
        import PIL
        import moviepy
    except ImportError:
        print("Missing libraries! Please run: pip install any2any")
        sys.exit(1)

    # Check for Pandoc specifically since it's the "big one"
    import pypandoc
    if len(sys.argv) < 3:
        print("Usage: any2any input_file output_file [--force-rebuild]")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    force_rebuild = "--force-rebuild" in sys.argv

    # Use a user‑writable cache location
    cache_dir = os.path.expanduser("~/.cache/any2any")
    os.makedirs(cache_dir, exist_ok=True)
    global CACHE_FILE
    CACHE_FILE = os.path.join(cache_dir, "cache.json")

    adjacency, edge_tool = load_or_build_cache(force_rebuild)
    any_to_any(input_file, output_file, adjacency, edge_tool)

if __name__ == "__main__":
    main()
