"""any2any – Universal file converter"""

from .converter import any_to_any, main

__version__ = "0.0.1dev1"

__all__ = ["any_to_any", "main"]

def _check_essentials():
    """Internal check for the bare minimum to run the CLI."""
    import importlib.util
    essentials = ["PIL", "moviepy", "pypdfium2"]
    missing = [lib for lib in essentials if importlib.util.find_spec(lib) is None]
    if missing:
        # We don't raise an error here so the user can still
        # run 'any2any --help' or similar, but it's a good place for a warning.
        pass
