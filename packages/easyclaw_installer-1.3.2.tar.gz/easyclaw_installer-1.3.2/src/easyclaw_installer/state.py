"""Global mutable state shared across UI, install runner, and agent.

Created once in the App and passed by reference to both the
deterministic install runner and the conversational AgentBrain.

v1.1: Deterministic runner + conversational agent. Error context
fields bridge the runner and agent (the agent's system prompt
reads error details from state to help the user troubleshoot).
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class InstallState:
    """Shared mutable state for the installer lifecycle."""

    # -- Install progress --
    install_active: bool = False
    install_complete: bool = False
    has_error: bool = False
    current_step: int = 0
    total_steps: int = 9
    completed_steps: list[str] = field(default_factory=list)

    # -- Error context (populated by install_runner on failure) --
    error_step: int = 0
    error_message: str = ""
    error_stdout: str = ""
    error_stderr: str = ""

    # -- Install log (one entry per step: "Step N (Title): OK/FAILED") --
    install_log: list[str] = field(default_factory=list)

    # -- Main event loop reference (for agent thread -> main loop calls) --
    main_loop: Optional[asyncio.AbstractEventLoop] = None
