"""Activity-centric resource management for rpacli.

Provides activity resource generation with package relationships,
container hierarchies, and URI resolution for navigation.
"""

from .activity_resource_manager import ActivityResourceManager
from .uri_resolver import ResourceUriResolver, UriBuilder

__all__ = [
    "ActivityResourceManager",
    "ResourceUriResolver",
    "UriBuilder",
]
