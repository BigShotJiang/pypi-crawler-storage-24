"""V0 schema generators for MCP-optimized artifacts."""

from rpacli.output.v0.generator import V0LakeGenerator

__all__ = ["V0LakeGenerator"]
