"""Output generators for rpax artifacts."""

from rpacli.output.warehouse_index import WarehouseIndexGenerator
from rpacli.output.lake_index import LakeIndexGenerator  # legacy

__all__ = ["WarehouseIndexGenerator", "LakeIndexGenerator"]
