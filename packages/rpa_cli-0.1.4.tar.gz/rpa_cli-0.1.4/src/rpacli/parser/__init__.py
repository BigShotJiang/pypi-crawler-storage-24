"""Parser modules for UiPath project analysis."""

from rpacli.parser.project import ProjectParser

__all__ = [
    "ProjectParser",
]
