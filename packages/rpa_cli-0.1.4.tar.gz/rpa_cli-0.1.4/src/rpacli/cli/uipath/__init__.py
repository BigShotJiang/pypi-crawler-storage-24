"""UiPath CLI sub-application."""
from rpacli.cli.uipath._app import beta, command, experimental, plumbing, uipath_app

from rpacli.cli.uipath import commands as _commands  # noqa: F401 — registers commands

# Attach or_tools plugin as sub-app under uipath
from rpacli.plugins.or_tools.cli import or_app as _or_app

uipath_app.add_typer(_or_app, name="or")

__all__ = ["uipath_app", "command", "experimental", "plumbing", "beta"]
