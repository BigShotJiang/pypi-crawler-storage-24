"""Plugin registry — auto-discovers plugins in sub-packages."""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from types import ModuleType

_plugins: list[ModuleType] = []
_loaded = False


def _load_all() -> None:
    global _loaded
    seen_names: set[str] = set()
    seen_aliases: set[str] = set()
    pkg_dir = Path(__file__).parent

    for _, mod_name, is_pkg in pkgutil.iter_modules([str(pkg_dir)]):
        if not is_pkg:
            continue
        mod = importlib.import_module(f"rpacli.plugins.{mod_name}")
        if not hasattr(mod, "cli_app"):
            continue
        name: str = getattr(mod, "name", mod_name)
        if name in seen_names:
            raise RuntimeError(f"Plugin name clash: {name!r}")
        for alias in getattr(mod, "root_aliases", []):
            if alias in seen_aliases:
                raise RuntimeError(f"CLI alias clash: {alias!r} (plugin {name!r})")
            seen_aliases.add(alias)
        seen_names.add(name)
        _plugins.append(mod)

    _loaded = True


def get_plugins() -> list[ModuleType]:
    if not _loaded:
        _load_all()
    return list(_plugins)
