"""OR-tools plugin — UiPath Object Repository inventory, audit, and replace.

Registered under ``rpa-cli uipath or`` (not via root plugin auto-discovery).
"""
