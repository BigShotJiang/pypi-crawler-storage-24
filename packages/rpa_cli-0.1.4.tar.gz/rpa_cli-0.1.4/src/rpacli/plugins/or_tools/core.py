"""OR-tools plugin core — delegates to cpmf-uips-or discovery/audit/rules APIs."""

from __future__ import annotations

from pathlib import Path


def resolve_project(path: Path) -> Path:
    """Resolve a path to project.json.

    Accepts either a directory or a direct project.json path.
    """
    resolved = path.resolve()
    if resolved.is_dir():
        return resolved / "project.json"
    return resolved
