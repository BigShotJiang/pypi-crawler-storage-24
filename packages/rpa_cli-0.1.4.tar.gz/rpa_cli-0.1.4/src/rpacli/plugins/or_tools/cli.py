"""OR-tools plugin CLI — ``rpa-cli or`` sub-app."""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpacli.plugins.or_tools.core import resolve_project

or_app = typer.Typer(
    name="or",
    help="UiPath Object Repository tools (inventory, audit, replace)",
    no_args_is_help=True,
)
console = Console(legacy_windows=False)


class TypeFilter(StrEnum):
    all = "all"
    screen = "screen"
    element = "element"


class OutputFormat(StrEnum):
    text = "text"
    json = "json"
    tree = "tree"
    json_tree = "json-tree"
    markdown = "markdown"
    html = "html"
    zip = "zip"


@or_app.command("inventory")
def inventory_cmd(
    path: Annotated[
        Path,
        typer.Argument(help="Path to project.json or project directory"),
    ] = Path("."),
    type_filter: Annotated[
        TypeFilter,
        typer.Option("--type", help="Filter by type: screen, element, or all"),
    ] = TypeFilter.all,
    output_format: Annotated[
        OutputFormat,
        typer.Option("--format", "-f", help="Output format: text, json, tree, json-tree, markdown, html, zip"),
    ] = OutputFormat.text,
) -> None:
    """List all objects in the Object Repository."""
    from cpmf_uips_or.cli import TypeFilter as UpstreamTypeFilter
    from cpmf_uips_or.cli import inventory as upstream_inventory

    project_json = resolve_project(path)
    if not project_json.exists():
        console.print(f"[red]Error:[/red] project.json not found at {project_json}")
        raise typer.Exit(1)

    # Delegate to upstream — map enums by value
    upstream_inventory(
        project=project_json,
        type_filter=UpstreamTypeFilter(type_filter.value),
        output_format=_map_output_format(output_format),
        json_output=False,
    )


@or_app.command("audit")
def audit_cmd(
    path: Annotated[
        Path,
        typer.Argument(help="Path to project.json or project directory"),
    ] = Path("."),
    type_filter: Annotated[
        TypeFilter,
        typer.Option("--type", help="Filter by type: screen, element, or all"),
    ] = TypeFilter.all,
    exit_code: Annotated[
        bool,
        typer.Option("--exit-code", help="Exit 1 if issues found"),
    ] = False,
) -> None:
    """Audit Object Repository and show statistics."""
    from cpmf_uips_or.cli import TypeFilter as UpstreamTypeFilter
    from cpmf_uips_or.cli import audit as upstream_audit

    project_json = resolve_project(path)
    if not project_json.exists():
        console.print(f"[red]Error:[/red] project.json not found at {project_json}")
        raise typer.Exit(1)

    upstream_audit(
        project=project_json,
        type_filter=UpstreamTypeFilter(type_filter.value),
        exit_code=exit_code,
    )


@or_app.command("replace")
def replace_cmd(
    path: Annotated[
        Path,
        typer.Argument(help="Path to project.json or project directory"),
    ] = Path("."),
    config: Annotated[
        Path | None,
        typer.Option("--config", help="Path to rules TOML file"),
    ] = None,
    type_filter: Annotated[
        TypeFilter,
        typer.Option("--type", help="Filter by type: screen, element, or all"),
    ] = TypeFilter.all,
    apply: Annotated[
        bool,
        typer.Option("--apply", help="Apply changes (default: dry-run)"),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", help="Allow mutations on unsupported versions"),
    ] = False,
) -> None:
    """Replace values using rules from a TOML config file.

    \b
    Dry-run by default — pass --apply to mutate files.

    \b
    Examples:
      rpa-cli or replace . --config rules.toml          # preview
      rpa-cli or replace . --config rules.toml --apply   # apply
    """
    from cpmf_uips_or.cli import TypeFilter as UpstreamTypeFilter
    from cpmf_uips_or.cli import replace as upstream_replace

    project_json = resolve_project(path)
    if not project_json.exists():
        console.print(f"[red]Error:[/red] project.json not found at {project_json}")
        raise typer.Exit(1)

    if config is None:
        console.print("[red]Error:[/red] --config is required (interactive mode not supported)")
        raise typer.Exit(1)

    upstream_replace(
        project=project_json,
        config=config,
        type_filter=UpstreamTypeFilter(type_filter.value),
        apply=apply,
        force=force,
        interactive=False,
    )


def _map_output_format(fmt: OutputFormat) -> object:
    """Map local OutputFormat to upstream OutputFormat."""
    from cpmf_uips_or.cli import OutputFormat as UpstreamOutputFormat

    return UpstreamOutputFormat(fmt.value)
