"""Bumper plugin CLI — ``rpa-cli bump`` command."""

from __future__ import annotations

import json as jsonlib
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpacli.versioning import BumpType

bumper_app = typer.Typer(name="bumper", help="Semantic versioning for UiPath projects")
console = Console(legacy_windows=False)


@bumper_app.command("bump")
def bump_cmd(
    bump_type: Annotated[
        BumpType,
        typer.Argument(help="Version component to bump (major/minor/patch/pre*/release)"),
    ] = BumpType.PATCH,
    path: Annotated[
        Path,
        typer.Option("--path", help="Path to project.json or project directory"),
    ] = Path("."),
    pre_tag: Annotated[
        str,
        typer.Option("--pre-tag", help="Pre-release tag identifier for pre* bump types"),
    ] = "rc",
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show new version without writing project.json"),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", help="Print only the new version string (for scripting)"),
    ] = False,
) -> None:
    """Bump the projectVersion in project.json using semantic versioning.

    \b
    BUMP_TYPE choices: major | minor | patch | premajor | preminor | prepatch | prerelease | release

    \b
    Examples:
      rpa-cli bump                             # 1.2.3 → 1.2.4
      rpa-cli bump minor                       # 1.2.3 → 1.3.0
      rpa-cli bump premajor --pre-tag alpha    # 1.2.3 → 2.0.0-alpha
      rpa-cli bump --dry-run                   # preview only
      rpa-cli bump --quiet                     # prints version string only
    """
    from rpacli.versioning import (
        bump,
        find_project_json,
        read_project_version,
        write_project_version,
    )

    try:
        project_json = find_project_json(path.resolve())
        old_version = read_project_version(project_json)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
    except KeyError:
        console.print(f"[red]Error:[/red] 'projectVersion' field not found in {project_json}")
        raise typer.Exit(1)

    new_version = bump(old_version, bump_type, pre_tag)

    if quiet:
        typer.echo(new_version)
        return

    project_name = jsonlib.loads(project_json.read_text(encoding="utf-8")).get("name", project_json.parent.name)
    typer.echo(f"  Project: {project_name}")
    suffix = "  [dry run — not written]" if dry_run else ""
    typer.echo(f"  Version: {old_version} → {new_version}{suffix}")

    if not dry_run:
        write_project_version(project_json, new_version)
