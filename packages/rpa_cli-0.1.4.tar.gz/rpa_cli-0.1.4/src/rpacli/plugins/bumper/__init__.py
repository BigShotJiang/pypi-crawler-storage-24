"""Bumper plugin — semantic versioning for UiPath project.json."""

from rpacli.plugins.bumper.cli import bumper_app

name = "bumper"
cli_app = bumper_app
root_aliases = ["bump"]
