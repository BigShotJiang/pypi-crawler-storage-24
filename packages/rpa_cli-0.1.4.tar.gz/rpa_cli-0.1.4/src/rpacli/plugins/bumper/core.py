"""Semantic versioning core logic — re-exported from rpacli.versioning."""

# All versioning logic lives in rpacli.versioning (the canonical location).
# This module re-exports it so plugin consumers can import from the plugin.
from rpacli.versioning import (
    SEMVER_RE,
    BumpType,
    SemVer,
    bump,
    find_project_json,
    parse,
    read_project_version,
    write_project_version,
)

__all__ = [
    "SEMVER_RE",
    "BumpType",
    "SemVer",
    "bump",
    "find_project_json",
    "parse",
    "read_project_version",
    "write_project_version",
]
