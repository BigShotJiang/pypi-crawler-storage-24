"""CI-gate plugin core — orchestrates validate + diff into a single CI step."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Exit codes (machine-readable)
EXIT_CLEAN = 0
EXIT_WARNINGS = 1
EXIT_ERRORS = 2
EXIT_REGRESSIONS = 3


class CiGateConfig(BaseModel):
    """Plugin configuration for CI gate."""

    fail_on_warnings: bool = Field(default=False, alias="failOnWarnings")

    class Config:
        populate_by_name = True


@dataclass
class GateResult:
    """Result of a CI gate run."""

    status: str = "pass"
    exit_code: int = EXIT_CLEAN
    violations: list[dict] = field(default_factory=list)
    regressions: list[dict] = field(default_factory=list)
    baseline: str | None = None

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "exitCode": self.exit_code,
            "violations": self.violations,
            "regressions": self.regressions,
            "baseline": self.baseline,
        }


def _collect_violations(artifacts_dir: Path) -> tuple[list[dict], list[dict]]:
    """Scan artifacts for validation violations.

    Returns (errors, warnings).
    """
    errors: list[dict] = []
    warnings: list[dict] = []

    # Check for error collection index
    error_index = artifacts_dir / "errors.index.json"
    if error_index.exists():
        try:
            data = json.loads(error_index.read_text(encoding="utf-8"))
            for entry in data.get("errors", []):
                severity = entry.get("severity", "error")
                record = {
                    "type": entry.get("type", "unknown"),
                    "message": entry.get("message", ""),
                    "workflow": entry.get("workflow", ""),
                    "severity": severity,
                }
                if severity == "warning":
                    warnings.append(record)
                else:
                    errors.append(record)
        except (json.JSONDecodeError, OSError):
            pass

    # Check manifest for missing references
    manifest_path = artifacts_dir / "manifest.json"
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            missing = manifest.get("missingReferences", [])
            for ref in missing:
                errors.append({
                    "type": "missing_reference",
                    "message": f"Missing workflow reference: {ref}",
                    "workflow": ref,
                    "severity": "error",
                })
        except (json.JSONDecodeError, OSError):
            pass

    return errors, warnings


def _collect_regressions(
    artifacts_dir: Path, baseline_dir: Path
) -> list[dict]:
    """Compare current scan against baseline to detect regressions."""
    regressions: list[dict] = []

    if not baseline_dir.exists():
        return regressions

    # Compare error counts
    current_errors, _ = _collect_violations(artifacts_dir)
    baseline_errors, _ = _collect_violations(baseline_dir)

    current_types = {e["message"] for e in current_errors}
    baseline_types = {e["message"] for e in baseline_errors}

    new_errors = current_types - baseline_types
    for msg in new_errors:
        regressions.append({
            "type": "new_error",
            "message": msg,
            "severity": "regression",
        })

    return regressions


def run_gate(
    artifacts_dir: Path,
    *,
    baseline_dir: Path | None = None,
    config: CiGateConfig | None = None,
) -> GateResult:
    """Run the CI gate check against parsed artifacts.

    Returns a GateResult with status, exit code, violations, and regressions.
    """
    if config is None:
        config = CiGateConfig()

    result = GateResult()

    if not artifacts_dir.exists():
        result.status = "fail"
        result.exit_code = EXIT_ERRORS
        result.violations.append({
            "type": "missing_artifacts",
            "message": f"Artifacts directory not found: {artifacts_dir}",
            "severity": "error",
        })
        return result

    # Collect violations
    errors, warnings = _collect_violations(artifacts_dir)
    result.violations.extend(errors)
    result.violations.extend(warnings)

    # Collect regressions
    if baseline_dir:
        result.baseline = str(baseline_dir)
        regressions = _collect_regressions(artifacts_dir, baseline_dir)
        result.regressions.extend(regressions)

    # Determine exit code
    if result.regressions:
        result.status = "fail"
        result.exit_code = EXIT_REGRESSIONS
    elif errors:
        result.status = "fail"
        result.exit_code = EXIT_ERRORS
    elif warnings and config.fail_on_warnings:
        result.status = "fail"
        result.exit_code = EXIT_WARNINGS
    elif warnings:
        result.status = "warn"
        result.exit_code = EXIT_WARNINGS
    else:
        result.status = "pass"
        result.exit_code = EXIT_CLEAN

    return result
