"""CI-gate plugin — single-command CI validation + diff."""

from rpacli.plugins.ci_gate.cli import ci_gate_app

name = "ci_gate"
cli_app = ci_gate_app
root_aliases = ["ci-check"]
