"""CI-gate plugin CLI — ``rpa-cli ci-check`` command."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpacli.plugins.ci_gate.core import CiGateConfig, run_gate

ci_gate_app = typer.Typer(name="ci-gate", help="CI validation gate")
console = Console(legacy_windows=False)


@ci_gate_app.command("ci-check")
def ci_check_cmd(
    path: Annotated[
        Path,
        typer.Argument(help="Path to artifacts directory or project directory"),
    ] = Path(".rpacli-warehouse"),
    baseline: Annotated[
        Path | None,
        typer.Option("--baseline", help="Baseline artifacts directory for regression detection"),
    ] = None,
    format_: Annotated[
        str,
        typer.Option("--format", help="Output format: json or text"),
    ] = "text",
    fail_on_warnings: Annotated[
        bool,
        typer.Option("--fail-on-warnings", help="Exit non-zero on warnings"),
    ] = False,
    out: Annotated[
        Path | None,
        typer.Option("--out", help="Write JSON report to file"),
    ] = None,
) -> None:
    """Run CI validation gate: validate artifacts and optionally diff against baseline.

    \b
    Exit codes:
      0  Clean — no violations
      1  Warnings only (pass unless --fail-on-warnings)
      2  Errors — hard failures (missing refs, cycles)
      3  Regressions — diff vs baseline shows new failures

    \b
    Examples:
      rpa-cli ci-check                                  # check default warehouse
      rpa-cli ci-check .rpacli-warehouse --format json  # JSON output
      rpa-cli ci-check --baseline /prev/.rpacli-cache   # detect regressions
      rpa-cli ci-check --fail-on-warnings               # strict mode
      rpa-cli ci-check --out report.json                # write report file
    """
    from rpacli.config import load_config

    # Build config
    try:
        rpacli_config = load_config()
        plugin_conf = rpacli_config.plugins.get("ci_gate", {})
    except Exception:
        plugin_conf = {}

    if fail_on_warnings:
        plugin_conf["failOnWarnings"] = True

    config = CiGateConfig(**plugin_conf)

    # Resolve artifacts directory
    artifacts_dir = path.resolve()

    # Run gate
    result = run_gate(artifacts_dir, baseline_dir=baseline, config=config)

    # Output
    if format_ == "json" or out:
        report = json.dumps(result.to_dict(), indent=2)
        if format_ == "json":
            typer.echo(report)
        if out:
            out.write_text(report, encoding="utf-8")
            console.print(f"[dim]Report written to {out}[/dim]")
    else:
        # Text output
        status_color = {"pass": "green", "warn": "yellow", "fail": "red"}.get(result.status, "white")
        console.print(f"[{status_color}]Status: {result.status.upper()}[/{status_color}]")

        if result.violations:
            console.print(f"\n[bold]Violations ({len(result.violations)}):[/bold]")
            for v in result.violations:
                icon = "[red]E[/red]" if v["severity"] == "error" else "[yellow]W[/yellow]"
                console.print(f"  {icon} {v['type']}: {v['message']}")

        if result.regressions:
            console.print(f"\n[bold red]Regressions ({len(result.regressions)}):[/bold red]")
            for r in result.regressions:
                console.print(f"  [red]R[/red] {r['message']}")

        if result.status == "pass":
            console.print("[green]All checks passed.[/green]")

    raise typer.Exit(result.exit_code)
