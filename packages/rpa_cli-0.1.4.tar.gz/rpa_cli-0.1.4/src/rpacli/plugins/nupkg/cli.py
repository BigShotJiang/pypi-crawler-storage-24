"""Nupkg plugin CLI — ``rpa-cli pack`` command."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpacli.plugins.nupkg.core import NupkgConfig, pack

nupkg_app = typer.Typer(name="nupkg", help="Pack UiPath projects into .nupkg packages")
console = Console(legacy_windows=False)
logger = logging.getLogger(__name__)


@nupkg_app.command("pack")
def pack_cmd(
    path: Annotated[
        Path,
        typer.Argument(help="Path to project.json or project directory"),
    ] = Path("."),
    output: Annotated[
        str,
        typer.Option("--output", "-o", help="Output directory for .nupkg"),
    ] = ".",
    version: Annotated[
        str | None,
        typer.Option("--version", help="Version override (default: from project.json)"),
    ] = None,
    use_net6: Annotated[
        bool,
        typer.Option("--use-net6", help="Pack with net6 uipcli (23.x) instead of net8 (25.x)"),
    ] = False,
    multi_tfm: Annotated[
        bool,
        typer.Option("--multi-tfm", help="Library projects: merge net8 + net6 lib/ folders"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be done without packing"),
    ] = False,
) -> None:
    """Pack a UiPath project into a .nupkg with post-pack fixups.

    \b
    Steps:
      1. Locate/install uipcli (cached under ~/.rpacli/uipcli-tools/)
      2. Run uipcli package pack
      3. Post-pack fixup: remove .cpmf/ bloat, patch nuspec, optionally merge TFMs
      4. Output .nupkg to --output directory

    \b
    Examples:
      rpa-cli pack .                            # pack current directory
      rpa-cli pack /path/to/project.json        # pack specific project
      rpa-cli pack . --multi-tfm                # library: net8 + net6
      rpa-cli pack . --version 1.2.3            # override version
      rpa-cli pack . --dry-run                  # preview only
    """
    from rpacli.config import load_config

    # Resolve project.json
    project_path = path.resolve()
    if project_path.is_dir():
        project_json = project_path / "project.json"
    else:
        project_json = project_path

    if not project_json.exists():
        console.print(f"[red]Error:[/red] project.json not found at {project_json}")
        raise typer.Exit(1)

    # Build config from file + plugin overrides
    try:
        rpacli_config = load_config()
        plugin_conf = rpacli_config.plugins.get("nupkg", {})
    except Exception:
        plugin_conf = {}

    # CLI flags override config file
    if use_net6:
        plugin_conf["useNet6"] = True
    if multi_tfm:
        plugin_conf["multiTfm"] = True
    plugin_conf["outputFolder"] = output

    config = NupkgConfig(**plugin_conf)

    if dry_run:
        # Enable logging for dry-run info
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    try:
        result = pack(project_json, config=config, version_override=version, dry_run=dry_run)
        if result and result.exists():
            size_kb = result.stat().st_size / 1024
            console.print(f"[green]Packed:[/green] {result.name} ({size_kb:.1f} KB)")
        elif dry_run:
            console.print("[yellow]Dry run complete — no files written[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
