"""Nupkg plugin — pack UiPath projects into .nupkg packages."""

from rpacli.plugins.nupkg.cli import nupkg_app

name = "nupkg"
cli_app = nupkg_app
root_aliases = ["pack"]
