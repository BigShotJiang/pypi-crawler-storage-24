"""Nupkg plugin core — uipcli install, pack, post-pack fixup."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

UIPATH_NUGET_FEED = (
    "https://uipath.pkgs.visualstudio.com"
    "/Public.Feeds/_packaging/UiPath-Official/nuget/v3/index.json"
)
UIPATH_FLAT_FEED = (
    "https://uipath.pkgs.visualstudio.com"
    "/Public.Feeds/_packaging/UiPath-Official/nuget/v3/flat2"
    "/uipath.cli.windows"
)


class NupkgConfig(BaseModel):
    """Plugin configuration for nupkg packing."""

    cli_version_net8: str = Field(default="25.10.11", alias="cliVersionNet8")
    cli_version_net6: str = Field(default="23.10.2.6", alias="cliVersionNet6")
    use_net6: bool = Field(default=False, alias="useNet6")
    multi_tfm: bool = Field(default=False, alias="multiTfm")
    trace_level: str = Field(default="Information", alias="traceLevel")
    output_folder: str = Field(default=".", alias="outputFolder")

    class Config:
        populate_by_name = True


# ── uipcli install ──────────────────────────────────────────────────────────


def _uipcli_tool_base() -> Path:
    """Return the base directory for uipcli tool installations."""
    local = os.environ.get("LOCALAPPDATA")
    if local:
        return Path(local) / "uipcli-tools"
    return Path.home() / ".rpacli" / "uipcli-tools"


def _find_or_install_uipcli(version: str, *, dry_run: bool = False) -> Path:
    """Locate or install a specific version of uipcli.

    25.x+: installed via ``dotnet tool install``
    23.x:  downloaded as nupkg and extracted
    """
    base = _uipcli_tool_base()
    tool_dir = base / version

    if version.startswith("23."):
        exe = tool_dir / "extracted" / "tools" / "uipcli.exe"
        if exe.exists():
            logger.info("uipcli %s already installed at %s", version, exe)
            return exe
        if dry_run:
            return exe
        # Download classic nupkg
        import urllib.request

        tool_dir.mkdir(parents=True, exist_ok=True)
        nupkg_url = f"{UIPATH_FLAT_FEED}/{version}/uipath.cli.windows.{version}.nupkg"
        nupkg_path = tool_dir / "uipcli.nupkg"
        logger.info("Downloading uipcli %s (classic nupkg)...", version)
        urllib.request.urlretrieve(nupkg_url, str(nupkg_path))
        extract_dir = tool_dir / "extracted"
        with zipfile.ZipFile(nupkg_path) as zf:
            zf.extractall(extract_dir)
        nupkg_path.unlink(missing_ok=True)
        if not exe.exists():
            raise FileNotFoundError(f"Failed to extract uipcli {version} — expected at {exe}")
        return exe

    # 25.x+ via dotnet tool install
    if sys.platform == "win32":
        exe = tool_dir / "uipcli.exe"
    else:
        exe = tool_dir / "uipcli"
    if exe.exists():
        logger.info("uipcli %s already installed at %s", version, exe)
        return exe
    if dry_run:
        return exe

    if not shutil.which("dotnet"):
        raise RuntimeError(
            "dotnet CLI not found on PATH. Install the .NET SDK or add dotnet to PATH."
        )

    tool_dir.mkdir(parents=True, exist_ok=True)
    logger.info("Installing uipcli %s (dotnet tool)...", version)
    result = subprocess.run(
        [
            "dotnet", "tool", "install", "UiPath.CLI.Windows",
            "--tool-path", str(tool_dir),
            "--version", version,
            "--add-source", UIPATH_NUGET_FEED,
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"dotnet tool install failed (exit {result.returncode}): {result.stderr}"
        )
    if not exe.exists():
        raise FileNotFoundError(
            f"Installation succeeded but uipcli not found at {exe}"
        )
    return exe


# ── pack ────────────────────────────────────────────────────────────────────


def _read_project_metadata(project_json: Path) -> dict:
    """Read name, version, type, description from project.json."""
    data = json.loads(project_json.read_text(encoding="utf-8"))
    output_type = (data.get("designOptions") or {}).get("outputType", "Process")
    return {
        "name": data.get("name", project_json.parent.name),
        "version": data.get("projectVersion", "1.0.0"),
        "type": output_type,
        "description": data.get("description", ""),
    }


def pack(
    project_json: Path,
    *,
    config: NupkgConfig,
    version_override: str | None = None,
    dry_run: bool = False,
) -> Path | None:
    """Pack a UiPath project into a .nupkg with post-pack fixups.

    Returns the path to the produced .nupkg, or None in dry-run mode.
    """
    metadata = _read_project_metadata(project_json)
    project_name = metadata["name"]
    project_type = metadata["type"]
    effective_version = version_override or metadata["version"]

    # Guard multi-TFM for Library projects only
    multi_tfm = config.multi_tfm and project_type == "Library"
    use_net6 = config.use_net6

    output_folder = Path(config.output_folder).resolve()

    logger.info("Project: %s (%s) v%s", project_name, project_type, effective_version)
    logger.info("Output:  %s", output_folder)

    # Resolve uipcli
    uipcli_net8 = _find_or_install_uipcli(config.cli_version_net8, dry_run=dry_run)
    uipcli_net6 = _find_or_install_uipcli(config.cli_version_net6, dry_run=dry_run)

    if dry_run:
        nupkg_name = f"{project_name}.{effective_version}.nupkg"
        logger.info("[dry-run] Would pack %s → %s", project_json, output_folder / nupkg_name)
        logger.info("[dry-run] uipcli (net8): %s", uipcli_net8)
        logger.info("[dry-run] uipcli (net6): %s", uipcli_net6)
        if multi_tfm:
            logger.info("[dry-run] Multi-TFM merge enabled")
        return None

    output_folder.mkdir(parents=True, exist_ok=True)

    # Build argument list
    uipcli = uipcli_net6 if use_net6 else uipcli_net8
    pack_args = [
        str(uipcli), "package", "pack",
        str(project_json.resolve()),
        "--output", str(output_folder),
        "--traceLevel", config.trace_level,
        "--disableTelemetry",
    ]
    if version_override:
        pack_args.extend(["-v", version_override])

    logger.info("Running uipcli package pack (%s)...", "net6" if use_net6 else "net8")
    result = subprocess.run(pack_args, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(
            f"uipcli package pack failed (exit {result.returncode}):\n{result.stderr}"
        )

    # Post-pack fixup
    nupkg_name = f"{project_name}.{effective_version}.nupkg"
    nupkg_path = output_folder / nupkg_name

    if nupkg_path.exists():
        _post_pack_fixup(
            nupkg_path,
            project_json=project_json,
            metadata=metadata,
            multi_tfm=multi_tfm,
            uipcli_net6=uipcli_net6,
            config=config,
            version_override=version_override,
        )
    else:
        logger.warning("Expected nupkg not found at %s — skipping post-pack fixup", nupkg_path)

    return nupkg_path


# ── post-pack fixup ─────────────────────────────────────────────────────────


def _post_pack_fixup(
    nupkg_path: Path,
    *,
    project_json: Path,
    metadata: dict,
    multi_tfm: bool,
    uipcli_net6: Path,
    config: NupkgConfig,
    version_override: str | None,
) -> None:
    """Apply post-pack fixups: remove bloat, multi-TFM merge, nuspec patching."""
    logger.info("Post-pack fixup: %s", nupkg_path.name)

    temp_dir = Path(tempfile.mkdtemp(prefix="rpacli-pack-"))
    try:
        # Extract
        with zipfile.ZipFile(nupkg_path) as zf:
            zf.extractall(temp_dir)

        # 6a. Remove .cpmf/ bloat from content/
        cpmf_dir = temp_dir / "content" / ".cpmf"
        if cpmf_dir.exists():
            shutil.rmtree(cpmf_dir)
            logger.info("  Removed content/.cpmf/ bloat")

        # 6b. Library-only: multi-TFM merge
        if multi_tfm:
            _multi_tfm_merge(
                temp_dir, project_json, metadata, uipcli_net6, config, version_override
            )

        # 6c. Patch nuspec
        _patch_nuspec(temp_dir, project_json, metadata)

        # 6d. Re-pack
        nupkg_path.unlink()
        _repack_nupkg(temp_dir, nupkg_path)
        size_kb = nupkg_path.stat().st_size / 1024
        logger.info("  Repacked: %s (%.1f KB)", nupkg_path.name, size_kb)

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def _multi_tfm_merge(
    temp_dir: Path,
    project_json: Path,
    metadata: dict,
    uipcli_net6: Path,
    config: NupkgConfig,
    version_override: str | None,
) -> None:
    """Pack with net6 uipcli and merge lib/ folders into the extracted nupkg."""
    logger.info("  Multi-TFM: packing net6.0 build...")

    net6_out = Path(tempfile.mkdtemp(prefix="rpacli-net6-"))
    try:
        net6_args = [
            str(uipcli_net6), "package", "pack",
            str(project_json.resolve()),
            "--output", str(net6_out),
            "--traceLevel", "Warning",
            "--disableTelemetry",
        ]
        if version_override:
            net6_args.extend(["-v", version_override])

        result = subprocess.run(net6_args, capture_output=True, text=True)
        if result.returncode != 0:
            logger.warning("  net6.0 pack failed (exit %d) — continuing with net8.0 only", result.returncode)
            return

        effective_version = version_override or metadata["version"]
        net6_nupkg = net6_out / f"{metadata['name']}.{effective_version}.nupkg"
        if not net6_nupkg.exists():
            logger.warning("  net6.0 nupkg not found — skipping merge")
            return

        # Extract net6 lib/ entries
        count = 0
        with zipfile.ZipFile(net6_nupkg) as zf:
            for entry in zf.namelist():
                if entry.startswith("lib/net6") and not entry.endswith("/"):
                    dest = temp_dir / entry
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(entry) as src, open(dest, "wb") as dst:
                        dst.write(src.read())
                    count += 1

        if count:
            logger.info("  Merged %d net6.0 lib/ files", count)
        else:
            logger.warning("  net6.0 nupkg had no net6 lib/ entries")

    finally:
        shutil.rmtree(net6_out, ignore_errors=True)


def _patch_nuspec(temp_dir: Path, project_json: Path, metadata: dict) -> None:
    """Patch nuspec with description, authors, repository tag."""
    nuspec_files = list(temp_dir.glob("*.nuspec"))
    if not nuspec_files:
        return

    nuspec_path = nuspec_files[0]
    tree = ET.parse(nuspec_path)
    root = tree.getroot()
    ns = root.tag.split("}")[0] + "}" if "}" in root.tag else ""

    meta = root.find(f"{ns}metadata")
    if meta is None:
        return

    changed = False

    # Description from project.json
    if metadata.get("description"):
        desc_elem = meta.find(f"{ns}description")
        if desc_elem is not None and desc_elem.text != metadata["description"]:
            desc_elem.text = metadata["description"]
            changed = True
            logger.info("  Patched description from project.json")

    # Authors from git config
    project_dir = project_json.parent
    try:
        git_author = subprocess.run(
            ["git", "-C", str(project_dir), "config", "user.name"],
            capture_output=True, text=True,
        ).stdout.strip()
    except FileNotFoundError:
        git_author = ""

    if git_author:
        authors_elem = meta.find(f"{ns}authors")
        if authors_elem is not None and authors_elem.text != git_author:
            authors_elem.text = git_author
            changed = True
            logger.info("  Patched authors from git: %s", git_author)

    # Repository tag
    repo_elem = meta.find(f"{ns}repository")
    if repo_elem is None:
        try:
            branch = subprocess.run(
                ["git", "-C", str(project_dir), "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True,
            ).stdout.strip()
            commit = subprocess.run(
                ["git", "-C", str(project_dir), "rev-parse", "HEAD"],
                capture_output=True, text=True,
            ).stdout.strip()
        except FileNotFoundError:
            branch = commit = ""

        if branch and commit:
            repo_elem = ET.SubElement(meta, f"{ns}repository" if ns else "repository")
            repo_elem.set("type", "git")
            repo_elem.set("branch", branch)
            repo_elem.set("commit", commit)
            changed = True
            logger.info("  Added repository tag: %s @ %s", branch, commit[:12])

    # Multi-TFM: add net6 dependency group if net6 lib/ was merged
    net6_lib = temp_dir / "lib" / "net6.0-windows7.0"
    if net6_lib.exists():
        deps_elem = meta.find(f"{ns}dependencies")
        if deps_elem is not None:
            existing_net6 = None
            for group in deps_elem.findall(f"{ns}group"):
                if group.get("targetFramework") == "net6.0-windows7.0":
                    existing_net6 = group
                    break
            if existing_net6 is None:
                # Find net8 group to clone
                for group in deps_elem.findall(f"{ns}group"):
                    if group.get("targetFramework") == "net8.0-windows7.0":
                        import copy
                        net6_group = copy.deepcopy(group)
                        net6_group.set("targetFramework", "net6.0-windows7.0")
                        # Remove net8-only deps
                        for dep in net6_group.findall(f"{ns}dependency"):
                            if dep.get("id") == "System.Activities.ViewModels":
                                net6_group.remove(dep)
                        deps_elem.append(net6_group)
                        changed = True
                        logger.info("  Added net6.0-windows7.0 dependency group")
                        break

    if changed:
        tree.write(str(nuspec_path), encoding="utf-8", xml_declaration=True)


def _repack_nupkg(extracted_dir: Path, output_path: Path) -> None:
    """Re-create a .nupkg from an extracted directory."""
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(extracted_dir.rglob("*")):
            if file_path.is_file():
                arcname = file_path.relative_to(extracted_dir).as_posix()
                zf.write(file_path, arcname)
