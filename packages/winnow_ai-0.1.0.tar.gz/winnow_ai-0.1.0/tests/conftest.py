"""Shared test fixtures for winnow tests."""
