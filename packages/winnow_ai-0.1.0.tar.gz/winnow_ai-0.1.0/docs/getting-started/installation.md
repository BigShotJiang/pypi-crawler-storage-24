# Installation

## Base install

```bash
pip install winnow-ai
```

This gives you heuristic filters, exact deduplication, the CLI, and JSONL/Parquet/CSV I/O. No heavy dependencies.

## Extras

Install only what you need:

```bash
pip install "winnow-ai[embeddings]"   # sentence-transformers, FAISS search, semantic dedup
pip install "winnow-ai[dedup]"        # MinHash-LSH fuzzy deduplication
pip install "winnow-ai[nlp]"          # language detection (lingua)
pip install "winnow-ai[io]"           # HuggingFace datasets, Pandas
pip install "winnow-ai[attribution]"  # TRAK-based data attribution (torch, transformers)
pip install "winnow-ai[explore]"      # web UI (FastAPI)
```

Or everything at once:

```bash
pip install "winnow-ai[all]"
```

## Development

```bash
git clone https://github.com/winnow-ai/winnow.git
cd winnow
pip install -e ".[dev]"
pre-commit install
```

## Requirements

- Python 3.10+
- No GPU required (but recommended for embeddings and attribution)
