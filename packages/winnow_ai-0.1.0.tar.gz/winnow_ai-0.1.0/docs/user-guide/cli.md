# CLI Reference

All commands are available via the `winnow` command after installation.

## winnow version

Print the installed version.

```bash
winnow version
```

## winnow curate

Run a curation pipeline on a dataset.

```bash
# With flags
winnow curate input.jsonl output.parquet \
  --min-length 50 --max-length 100000 \
  --max-whitespace 0.4 --max-repetition 0.3 --max-special 0.3 \
  --dedup --fuzzy-dedup 0.8

# With YAML config
winnow curate input.jsonl output.parquet --config pipeline.yaml
```

| Flag | Description |
|---|---|
| `--config`, `-c` | Path to YAML pipeline config |
| `--min-length` | Minimum document length (chars) |
| `--max-length` | Maximum document length (chars) |
| `--max-whitespace` | Max whitespace ratio (0-1) |
| `--max-repetition` | Max n-gram repetition ratio (0-1) |
| `--max-special` | Max special character ratio (0-1) |
| `--dedup` | Enable exact deduplication |
| `--fuzzy-dedup` | MinHash dedup threshold (0-1) |

## winnow stats

Show basic statistics about a dataset.

```bash
winnow stats data/raw.jsonl
```

Outputs document count, total characters, average/min/max length.

## winnow embed

Compute embeddings and save as `.npy`. Requires `winnow-ai[embeddings]`.

```bash
winnow embed data/curated.jsonl embeddings.npy \
  --model all-MiniLM-L6-v2 --batch-size 64 --device cuda
```

## winnow search

Semantic search over a dataset. Requires `winnow-ai[embeddings]`.

```bash
winnow search data/curated.jsonl "your query here" -k 10

# With precomputed embeddings (faster)
winnow search data/curated.jsonl "your query" -e embeddings.npy
```

## winnow outliers

Find anomalous documents via k-NN distance. Requires `winnow-ai[embeddings]`.

```bash
winnow outliers data/curated.jsonl --top 20 -k 10

# With precomputed embeddings
winnow outliers data/curated.jsonl -e embeddings.npy --top 20
```

## winnow attribute

Score training data influence on model performance. Requires `winnow-ai[attribution]`.

```bash
winnow attribute train.jsonl eval.jsonl \
  --model gpt2 --top 20 --save-dir ./results
```

## winnow explore

Launch an interactive web UI. Requires `winnow-ai[explore]`.

```bash
winnow explore data/curated.jsonl --port 8765 -e embeddings.npy
```
