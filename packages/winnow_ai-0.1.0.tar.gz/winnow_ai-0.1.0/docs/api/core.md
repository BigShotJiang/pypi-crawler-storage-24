# winnow.core

## Filters

::: winnow.core.filters

## Pipeline

::: winnow.core.pipeline

## Registry

::: winnow.core.registry
