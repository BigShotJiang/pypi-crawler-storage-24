# winnow.embeddings

## Compute

::: winnow.embeddings.compute

## Search

::: winnow.embeddings.search

## Dedup

::: winnow.embeddings.dedup
