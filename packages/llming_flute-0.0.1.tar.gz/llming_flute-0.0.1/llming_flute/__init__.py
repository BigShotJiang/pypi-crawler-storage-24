"""Isolated Python code execution with resource limits"""

__version__ = "0.0.1"
