# near-transfer-py

A Python client for managing NEAR Protocol token transfers. Track, query, and manage NEAR token transfers with simple CRUD operations.

## Installation

pip install near-transfer-py

## Requirements

- **Python 3.9+**
- requests

## Quick Start

from near_transfer_py import NEARTransferManager

# Initialize the manager
manager = NEARTransferManager(network="mainnet")

# Create a transfer record
transfer = manager.create_transfer_record(
    sender="alice.near",
    receiver="bob.near",
    amount_near=5.0,
    note="Payment for services"
)

# Get transfer details
transfer_info = manager.get_transfer(transfer["id"])

# List all transfers
transfers = manager.list_transfers()

# Update transfer status
manager.update_transfer_status(transfer["id"], "completed")

# Check account balance
balance = manager.get_account_balance("alice.near")

# Get transaction status
status = manager.get_transaction_status("tx_hash_here")

# Get recent transfers
recent = manager.get_recent_transfers(limit=10)

# Delete a transfer record
manager.delete_transfer(transfer["id"])

## Features

- **Create** transfer records with sender, receiver, amount, and notes
- **Read** transfer details and account information
- **Update** transfer status tracking
- **Delete** transfer records
- Query recent transfers and transaction status
- Support for both mainnet and testnet

## Network Support

- `mainnet` (default)
- `testnet`

## Notes

This client tracks and queries transfers. For signing and sending actual transactions, use the NEAR SDK directly.

## License

MIT