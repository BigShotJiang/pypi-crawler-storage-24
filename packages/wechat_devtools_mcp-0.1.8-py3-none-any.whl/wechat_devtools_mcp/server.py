#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信开发者工�?CLI MCP Server (增强�?v4)

将微信开发者工�?CLI 封装�?MCP 服务，使 AI 能够直接调用 CLI 命令�?
实现小程序的打开、预览、上传、自动化测试等开发流程的自动化�?

新增能力�?
- 项目上下文感知：自动解析 project.config.json / app.json
- 源码管理：读�?列出小程序页面文�?
- 自动化测试：开启自动化端口、回放测试用�?
- 文件监听重建：代码修改后刷新项目
- 预览增强：支持自定义编译条件(指定页面)
- 云函数管理：列表/信息/上传/下载
- 实时日志监听：通过 miniprogram-automator 捕获 console/exception 事件
- 调试事件监听：页面跳转捕获、自动化脚本执行、系统信息获�?
"""

import asyncio
import glob
import json
import os
import re
import sys
import tempfile
from enum import Enum
from pathlib import Path
from typing import Optional, List, Any, Dict

from pydantic import BaseModel, Field, ConfigDict
from mcp.server.fastmcp import FastMCP

# ============================================================
# 常量配置
# ============================================================

# CLI 路径，优先从环境变量读取
CLI_PATH = os.environ.get(
    "WECHAT_DEVTOOLS_CLI",
    r"D:\Tencent\微信web开发者工具\cli.bat",
)

# CLI 执行超时时间（秒�?
CLI_TIMEOUT = int(os.environ.get("WECHAT_CLI_TIMEOUT", "30"))

DEFAULT_PROJECT_PATH = os.environ.get("WECHAT_PROJECT_PATH")

# 新增：MCP 根目录，用于定位截图等资�?
MCP_ROOT = os.environ.get(
    "WECHAT_MCP_ROOT",
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)

# 初始�?MCP Server
mcp = FastMCP("wechat_devtools_mcp")

# ============================================================
# 工具预设控制
# ============================================================

# 通过环境变量 WECHAT_TOOLS_PRESET 控制开放的工具集：
#   core  （默认）：SOP 流程 + 实时调试核心工具，约 15 �?
#   full  ：开放全部工�?
_PRESET = os.environ.get("WECHAT_TOOLS_PRESET", "core").strip().lower()

# core 预设白名单：覆盖 SOP 两个流程所需的全部工�?
_CORE_TOOLS = {
    # 初始�?& 系统
    "wechat_setup_sop",
    "wechat_open",
    "wechat_is_login",
    "wechat_get_status",
    "wechat_list_tools",
    # 项目上下�?
    "wechat_project_info",
    "wechat_list_pages",
    "wechat_read_page",
    "wechat_read_file",
    # 编译 & 预览
    "wechat_compile_check",
    "wechat_preview_page",
    # 自动化基础
    "wechat_auto",
    # 调试 & 日志
    "wechat_get_cdp_logs",
    "wechat_navigate_and_capture",
    "wechat_capture_screenshot",
    "wechat_get_console_logs",
    "wechat_get_exceptions",
}


def _tool(**kwargs):
    """条件注册装饰器：core 预设下只注册白名单内的工具�?""
    tool_name = kwargs.get("name", "")
    if _PRESET == "full" or tool_name in _CORE_TOOLS:
        return mcp.tool(**kwargs)
    # 不在白名单：返回透传装饰器，函数仍存在但不注册为 MCP 工具
    def _passthrough(fn):
        return fn
    return _passthrough




class ErrorCode(str, Enum):
    """机器可读的错误码枚举，继�?str 以便 JSON 序列化�?""
    CLI_TIMEOUT          = "CLI_TIMEOUT"
    CLI_NOT_FOUND        = "CLI_NOT_FOUND"
    NODE_NOT_FOUND       = "NODE_NOT_FOUND"
    NPM_DEPS_MISSING     = "NPM_DEPS_MISSING"
    PROJECT_PATH_MISSING = "PROJECT_PATH_MISSING"
    PILLOW_NOT_INSTALLED = "PILLOW_NOT_INSTALLED"
    UNKNOWN_ERROR        = "UNKNOWN_ERROR"


def _make_error(error_code: ErrorCode, message: str, hint: str = "") -> str:
    """生成结构化错误响应（JSON 字符串）�?

    Args:
        error_code: ErrorCode 枚举值，机器可读的错误标识符�?
        message: 人类可读的错误描述（中文）�?
        hint: 可选的修复建议或操作指引�?

    Returns:
        JSON 字符串，包含 success=false、error_code、message，以及可选的 hint�?
    """
    payload: Dict[str, Any] = {
        "success": False,
        "error_code": error_code.value,
        "message": message,
    }
    if hint:
        payload["hint"] = hint
    return json.dumps(payload, ensure_ascii=False, indent=2)

# ============================================================
# 核心工具函数
# ============================================================


async def _run_cli(*args: str, timeout: int = CLI_TIMEOUT) -> dict:
    """
    执行微信开发者工�?CLI 命令并返回结果�?
    使用临时文件捕获输出，避免与 MCP stdio 冲突�?

    Args:
        *args: CLI 子命令及参数列表
        timeout: 超时时间（秒�?

    Returns:
        dict: 包含 success, stdout, stderr, return_code 的字�?
    """
    cmd = [CLI_PATH] + list(args)

    # Windows 兼容性修复：执行 .bat 文件需通过 cmd /c
    if sys.platform == "win32" and CLI_PATH.lower().endswith(".bat"):
        cmd = ["cmd", "/c"] + cmd

    cmd_display = " ".join(cmd)

    # 创建临时文件来捕获输�?
    stdout_file = tempfile.NamedTemporaryFile(mode='w+', delete=False, encoding='utf-8')
    stderr_file = tempfile.NamedTemporaryFile(mode='w+', delete=False, encoding='utf-8')
    
    try:
        stdout_file.close()
        stderr_file.close()
        
        # Windows 使用 shell 模式，重定向到临时文�?
        if sys.platform == "win32":
            import subprocess
            cmd_str = " ".join(f'"{c}"' if " " in str(c) else str(c) for c in cmd)
            cmd_str = f'{cmd_str} > "{stdout_file.name}" 2> "{stderr_file.name}"'
            
            process = await asyncio.create_subprocess_shell(
                cmd_str,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
        else:
            with open(stdout_file.name, 'w') as out, open(stderr_file.name, 'w') as err:
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=out,
                    stderr=err,
                )
        
        # 等待进程完成
        try:
            await asyncio.wait_for(process.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            return {
                "success": False,
                "stdout": "",
                "stderr": f"命令执行超时（{timeout}秒）：{cmd_display}",
                "return_code": -1,
                "command": cmd_display,
            }
        
        # 读取输出文件
        with open(stdout_file.name, 'r', encoding='utf-8', errors='replace') as f:
            stdout_text = f.read().strip()
        with open(stderr_file.name, 'r', encoding='utf-8', errors='replace') as f:
            stderr_text = f.read().strip()
        
        return_code = process.returncode
        
        return {
            "success": return_code == 0,
            "stdout": stdout_text,
            "stderr": stderr_text,
            "return_code": return_code,
            "command": cmd_display,
        }

    except FileNotFoundError:
        return {
            "success": False,
            "stdout": "",
            "stderr": (
                f"找不�?CLI 文件：{CLI_PATH}\n"
                "请确认微信开发者工具已安装，或设置 WECHAT_DEVTOOLS_CLI 环境变量�?
            ),
            "return_code": -1,
            "command": cmd_display,
        }
    except Exception as e:
        return {
            "success": False,
            "stdout": "",
            "stderr": f"执行失败：{type(e).__name__}: {str(e)}",
            "return_code": -1,
            "command": cmd_display,
        }
    finally:
        # 清理临时文件
        try:
            os.unlink(stdout_file.name)
            os.unlink(stderr_file.name)
        except:
            pass


def _format_result(result: dict) -> str:
    """�?CLI 执行结果格式化为可读字符串�?""
    parts = []
    if result["success"]:
        parts.append("�?命令执行成功")
    else:
        parts.append("�?命令执行失败")

    parts.append(f"命令: {result['command']}")
    parts.append(f"返回�? {result['return_code']}")

    if result["stdout"]:
        parts.append(f"输出:\n{result['stdout']}")
    if result["stderr"]:
        parts.append(f"错误:\n{result['stderr']}")

    return "\n".join(parts)


def _build_global_args(
    project_path: Optional[str] = None,
    appid: Optional[str] = None,
    port: Optional[int] = None,
    lang: Optional[str] = None,
) -> list[str]:
    """构建全局选项参数列表�?""
    args: list[str] = []
    if project_path:
        args.extend(["--project", project_path])
    if appid:
        args.extend(["--appid", appid])
    if port is not None:
        args.extend(["--port", str(port)])
    if lang:
        args.extend(["--lang", lang])
    return args


def _resolve_project_path(project_path: Optional[str]) -> str:
    """解析项目路径，如果未提供则使用默认路径。如果为占位符环境则抛出错误�?""
    path = project_path or DEFAULT_PROJECT_PATH
    if not path:
        raise ValueError(
            "�?错误：未提供有效的小程序项目路径！\n"
            "请通过以下任一种方式设置：\n"
            "1. 配置环境变量 `WECHAT_PROJECT_PATH`\n"
            "2. 在工具参数中显式提供 `project_path`"
        )
    return path


# ============================================================
# Pydantic 输入模型 �?系统与元工具
# ============================================================



# ============================================================
# Pydantic 输入模型 �?基础操作
# ============================================================


class OpenInput(BaseModel):
    """打开开发者工具或项目的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(
        default=None,
        description="小程序项目路径。若不提供则仅打开开发者工�?IDE�?,
    )
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?en' �?'zh'�?)
    cdp_enabled: Optional[bool] = Field(
        default=False,
        description="是否开�?Chromium 调试端口 (9222)。开启后可捕获完�?WXML 警告�?
    )


class LoginInput(BaseModel):
    """登录开发者工具的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    qr_format: Optional[str] = Field(
        default="terminal",
        description="二维码格式：'terminal'�?image'�?base64'�?,
    )
    qr_output: Optional[str] = Field(
        default=None,
        description="二维码输出文件路径�?,
    )
    result_output: Optional[str] = Field(
        default=None,
        description="登录结果输出文件路径（JSON 格式）�?,
    )
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?)


class IsLoginInput(BaseModel):
    """检查登录状态的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class PreviewInput(BaseModel):
    """预览小程序的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(
        default=None,
        description="小程序项目路径。不填则使用默认项目路径�?,
    )
    qr_format: Optional[str] = Field(
        default="base64",
        description="二维码格式：'terminal'�?image'�?base64'。默�?'base64'�?,
    )
    qr_output: Optional[str] = Field(
        default=None,
        description="二维码输出文件路径�?,
    )
    info_output: Optional[str] = Field(
        default=None,
        description="编译信息输出 JSON 文件路径�?,
    )
    compile_condition: Optional[str] = Field(
        default=None,
        description=(
            "自定义编译条件（JSON 字符串），可指定预览的页面和参数�?
            "例如: '{\"pathName\":\"pages/index/index\",\"query\":\"x=1&y=2\"}'"
        ),
    )
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?)


class AutoPreviewInput(BaseModel):
    """自动预览小程序的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    info_output: Optional[str] = Field(default=None, description="预览信息输出文件路径�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?)


class UploadInput(BaseModel):
    """上传小程序的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    version: str = Field(..., description="版本号（必填），例如 '1.0.0'�?, min_length=1)
    desc: Optional[str] = Field(default=None, description="版本描述信息�?)
    info_output: Optional[str] = Field(default=None, description="上传信息输出 JSON 文件路径�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?)


class BuildNpmInput(BaseModel):
    """构建 NPM 的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    compile_type: Optional[str] = Field(
        default=None,
        description="编译类型�?miniprogram' �?'plugin'�?,
    )
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CompileCheckInput(BaseModel):
    """编译检查的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    info_output: Optional[str] = Field(default=None, description="编译信息输出 JSON 文件路径�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CacheCleanInput(BaseModel):
    """清除缓存的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    clean_type: str = Field(
        default="compile",
        description=(
            "缓存类型�?storage'（数据）�?file'（文件）�?
            "'compile'（编译）�?auth'（授权）�?network'（网络）�?
            "'session'（登录）�?all'（所有）�?
        ),
    )
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CloseProjectInput(BaseModel):
    """关闭项目的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="要关闭的小程序项目路径�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class QuitIdeInput(BaseModel):
    """退�?IDE 的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


# ============================================================
# Pydantic 输入模型 �?新增：自动化 & 文件 & 云函�?
# ============================================================


class AutomationInput(BaseModel):
    """开启自动化测试的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    auto_port: Optional[int] = Field(
        default=9420,
        description="自动化监听端口，默认 9420�?,
        ge=1,
        le=65535,
    )
    auto_account: Optional[str] = Field(
        default=None,
        description="指定使用�?openid�?,
    )


class AutoReplayInput(BaseModel):
    """打开自动化测试窗�?& 回放的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    replay_all: bool = Field(
        default=False,
        description="是否回放全部测试用例�?,
    )


class ResetFileUtilsInput(BaseModel):
    """重建文件监听的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)


class ProjectInfoInput(BaseModel):
    """获取项目信息的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)


class ListPagesInput(BaseModel):
    """列出项目页面的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)


class ReadPageFilesInput(BaseModel):
    """读取指定页面文件的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    page_path: str = Field(
        ...,
        description=(
            "页面路径（相对于项目根目录），例�?'pages/index/index'�?
            "将自动读取该页面�?.wxml, .wxss, .js, .json 四个文件�?
        ),
    )


class ReadFileInput(BaseModel):
    """读取项目中任意文件的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    file_path: str = Field(
        ...,
        description="相对于项目根目录的文件路径，例如 'app.json' �?'pages/index/index.wxml'�?,
    )


class CloudFuncListInput(BaseModel):
    """查看云函数列表的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    env: str = Field(..., description="云环�?ID（必填）�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CloudFuncInfoInput(BaseModel):
    """查看云函数信息的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    env: str = Field(..., description="云环�?ID（必填）�?)
    names: list[str] = Field(..., description="云函数名称列表�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CloudFuncDeployInput(BaseModel):
    """上传云函数的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    env: str = Field(..., description="云环�?ID（必填）�?)
    names: Optional[list[str]] = Field(default=None, description="云函数名称列表（使用 --project 时）�?)
    paths: Optional[list[str]] = Field(default=None, description="云函数目录绝对路径列表�?)
    remote_npm_install: bool = Field(default=False, description="是否云端安装依赖�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CloudFuncDownloadInput(BaseModel):
    """下载云函数的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    env: str = Field(..., description="云环�?ID（必填）�?)
    name: str = Field(..., description="云函数名称�?)
    download_path: str = Field(..., description="下载后的存放位置路径�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


class CloudEnvListInput(BaseModel):
    """列出云开发环境的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?)


class PreviewPageInput(BaseModel):
    """预览指定页面的输入参数（快捷工具）�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    page_path: str = Field(
        ...,
        description="要预览的页面路径，例�?'pages/index/index'�?,
    )
    query: Optional[str] = Field(
        default=None,
        description="页面参数，例�?'id=123&type=detail'�?,
    )
    qr_format: Optional[str] = Field(default="base64", description="二维码格式�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)


# ============================================================
# Pydantic 输入模型 �?实时日志 & 调试事件监听
# ============================================================


class ConsoleLogsInput(BaseModel):
    """实时获取控制台日志的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径（仅用于提示，连接时使�?auto_port）�?)
    auto_port: int = Field(
        default=9420,
        description="自动化监听端口（需先调�?wechat_auto 开启），默�?9420�?,
        ge=1,
        le=65535,
    )
    duration: int = Field(
        default=10,
        description="采集持续时间（秒），范围 1~120，默�?10 秒�?,
        ge=1,
        le=120,
    )
    log_type: str = Field(
        default="all",
        description="监听类型�?all'（日�?异常）�?console'（仅日志）�?exception'（仅异常）�?,
    )
    tap_selector: Optional[str] = Field(
        default=None,
        description="可选：在采集期间自动点击的 CSS 选择器，例如 '.btn' �?'#submit'。用于触发操作后捕获日志�?,
    )
    tap_delay: int = Field(
        default=500,
        description="点击延迟（毫秒），在开始采集后等待多久再触发点击，默认 500ms�?,
        ge=0,
    )


class CDPLogsInput(BaseModel):
    """通过 CDP 端口获取高清日志的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    duration: int = Field(
        default=10,
        description="采集持续时间（秒），默认 10 秒�?,
        ge=1,
        le=120,
    )
    port: int = Field(
        default=9222,
        description="CDP 端口，默�?9222�?,
        ge=1,
        le=65535,
    )
    verbose: bool = Field(
        default=False,
        description="True 时返回全量日志，不过滤系统日志�?,
    )


class ExceptionsInput(BaseModel):
    """实时获取运行时异常的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径（仅用于提示）�?)
    auto_port: int = Field(
        default=9420,
        description="自动化监听端口，默认 9420�?,
        ge=1,
        le=65535,
    )
    duration: int = Field(
        default=10,
        description="采集持续时间（秒），范围 1~120，默�?10 秒�?,
        ge=1,
        le=120,
    )


class RunScriptInput(BaseModel):
    """执行自动化测试脚本的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    script_content: str = Field(
        ...,
        description=(
            "自动化测试脚本的 JS 代码内容。脚本必须导出一个接�?miniProgram 参数�?async function。\n"
            "示例:\n"
            "module.exports = async function(miniProgram) {\n"
            "  const page = await miniProgram.navigateTo('/pages/index/index');\n"
            "  await page.waitFor(1000);\n"
            "  return { success: true };\n"
            "};"
        ),
    )
    auto_port: int = Field(
        default=9420,
        description="自动化监听端口，默认 9420�?,
        ge=1,
        le=65535,
    )
    timeout: int = Field(
        default=30,
        description="脚本执行超时时间（秒），范围 5~300，默�?30 秒�?,
        ge=5,
        le=300,
    )
    project_path: Optional[str] = Field(default=None, description="小程序项目路径（仅用于提示）�?)


class NavigateCaptureInput(BaseModel):
    """跳转页面并捕获日志的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    page_path: str = Field(
        ...,
        description="要跳转的页面路径，例�?'pages/index/index' �?'/pages/index/index'�?,
    )
    wait_ms: int = Field(
        default=2000,
        description="跳转后等待时间（毫秒），范围 100~30000，默�?2000ms�?,
        ge=100,
        le=30000,
    )
    auto_port: int = Field(
        default=9420,
        description="自动化监听端口，默认 9420�?,
        ge=1,
        le=65535,
    )
    project_path: Optional[str] = Field(default=None, description="小程序项目路径（仅用于提示）�?)


class SystemInfoInput(BaseModel):
    """获取小程序运行时系统信息的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    auto_port: int = Field(
        default=9420,
        description="自动化监听端口，默认 9420�?,
        ge=1,
        le=65535,
    )
    project_path: Optional[str] = Field(default=None, description="小程序项目路径（仅用于提示）�?)


class ScreenshotInput(BaseModel):
    """截屏工具输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    output_path: str = Field(..., description="截图保存路径（绝对路径）。必须明确指定�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)
    overlap: int = Field(default=50, description="分段重叠像素数，防止内容截断（默�?0）�?)


class PageDataInput(BaseModel):
    """获取页面数据输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class StorageInput(BaseModel):
    """Storage 输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    key: Optional[str] = Field(default=None, description="要读取的 Storage key。若为空，则列出所�?key 列表�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class EvaluateInput(BaseModel):
    """代码执行输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    expression: str = Field(..., description="要执行的 JS 表达式�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


# ── v4.0 输入模型 ─────────────────────────────────────────────

class SetPageDataInput(BaseModel):
    """设置页面 Data 的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    data_json: str = Field(..., description="要设置的数据（JSON 字符串），例�?'{\"message\": \"hello\"}'�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class CallPageMethodInput(BaseModel):
    """调用页面方法的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    method: str = Field(..., description="要调用的页面方法名，例如 'onPullDownRefresh'�?)
    args_json: Optional[str] = Field(default=None, description="方法参数（JSON 数组字符串）�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class TapElementInput(BaseModel):
    """点击元素的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    selector: str = Field(..., description="CSS 选择器，例如 '.submit-btn' �?'#login'�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class ElementInfoInput(BaseModel):
    """获取元素信息的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    selector: str = Field(..., description="CSS 选择器�?)
    style_prop: Optional[str] = Field(default=None, description="要查询的具体 CSS 属性名，例�?'color'�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class InputElementInput(BaseModel):
    """输入表单内容的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    selector: str = Field(..., description="input/textarea �?CSS 选择器�?)
    value: str = Field(..., description="要输入的文本内容�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class MockWxMethodInput(BaseModel):
    """Mock wx API 的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    method: str = Field(..., description="�?mock �?wx 方法，例�?'showModal'�?chooseLocation'�?)
    result_json: str = Field(..., description="Mock 返回值（JSON 字符串），例�?'{\"confirm\": true}'�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class CallWxMethodInput(BaseModel):
    """调用 wx API 的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    method: str = Field(..., description="wx 方法名，例如 'getStorageSync'�?setNavigationBarTitle'�?)
    args_json: Optional[str] = Field(default=None, description="参数（JSON 数组字符串）�?)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class PageStackInput(BaseModel):
    """获取页面栈的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    auto_port: int = Field(default=9420, description="自动化端口�?)


class SetupSopInput(BaseModel):
    """一键初始化 SOP 聚合工具的输入参数�?""
    model_config = ConfigDict(str_strip_whitespace=True)
    project_path: Optional[str] = Field(default=None, description="小程序项目路径�?)
    auto_port: int = Field(default=9420, description="自动化端口�?, ge=1, le=65535)
    appid: Optional[str] = Field(default=None, description="小程�?AppID�?)
    port: Optional[int] = Field(default=None, description="IDE HTTP 服务端口号�?, ge=1, le=65535)
    lang: Optional[str] = Field(default=None, description="界面语言�?)
    cdp_enabled: bool = Field(default=False, description="是否开�?CDP 调试端口�?)


# ============================================================
# CDP 日志过滤辅助函数
# ============================================================

SYSTEM_LOG_PATTERNS = [
    r"\[system\]",
    r"WAService\.js",
    r"WAWebview\.js",
    r"__dev__",
]


def _filter_cdp_logs(logs: list, verbose: bool) -> list:
    """verbose=False 时过滤系统日志和框架内部堆栈�?""
    if verbose:
        return logs
    filtered = []
    for log in logs:
        text = json.dumps(log, ensure_ascii=False) if isinstance(log, dict) else str(log)
        if not any(re.search(p, text) for p in SYSTEM_LOG_PATTERNS):
            filtered.append(log)
    return filtered


# ============================================================
# 工具分层常量（需�?10�?
# ============================================================

CORE_TOOLS = {
    "wechat_setup_sop", "wechat_open", "wechat_is_login",
    "wechat_auto", "wechat_project_info", "wechat_compile_check",
    "wechat_get_console_logs", "wechat_navigate_and_capture",
    "wechat_capture_screenshot", "wechat_tap_element",
    "wechat_get_element_info", "wechat_mock_wx_method",
    "wechat_get_status", "wechat_list_tools", "wechat_get_cdp_logs",
}

ADVANCED_TOOLS = {
    "wechat_login", "wechat_preview", "wechat_preview_page",
    "wechat_upload", "wechat_build_npm", "wechat_cache_clean",
    "wechat_cloud_env_list", "wechat_cloud_func_list",
    "wechat_cloud_func_info", "wechat_cloud_func_deploy",
    "wechat_cloud_func_download", "wechat_run_automation_script",
    "wechat_set_page_data", "wechat_call_page_method",
    "wechat_evaluate_expression", "wechat_get_page_stack",
    "wechat_get_storage", "wechat_get_page_data",
    "wechat_call_wx_method", "wechat_input_element",
    "wechat_get_exceptions", "wechat_get_system_info",
    "wechat_auto_preview", "wechat_auto_replay",
    "wechat_reset_fileutils", "wechat_close_project", "wechat_quit_ide",
    "wechat_list_pages", "wechat_read_page", "wechat_read_file",
}


# ============================================================
# MCP 工具 �?核心操作（原�?+ 增强�?
# ============================================================


@_tool(
    name="wechat_setup_sop",
    annotations={
        "title": "一键初始化（SOP 聚合工具�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_setup_sop(params: SetupSopInput) -> str:
    """一键完成初始化：is_login �?auto �?open �?project_info（尽力模式）�?

    依次执行四个初始化步骤，任一步骤失败后仍继续执行后续步骤�?
    返回包含所有步骤状态的结构�?JSON�?
    """
    import subprocess as _sp

    result: dict = {
        "login": {},
        "auto": {},
        "open": {},
        "info": {},
    }

    # ── 步骤 1：is_login ──────────────────────────────────────
    try:
        login_args = ["islogin"]
        login_args.extend(
            _build_global_args(
                project_path=params.project_path,
                appid=params.appid,
                port=params.port,
            )
        )
        login_result = await _run_cli(*login_args)
        result["login"] = {
            "status": "ok" if login_result["success"] else "failed",
        }
        if not login_result["success"]:
            result["login"]["error_code"] = ErrorCode.UNKNOWN_ERROR.value
            result["login"]["message"] = login_result.get("stderr") or login_result.get("stdout") or "登录状态检查失�?
    except Exception as e:
        result["login"] = {
            "status": "failed",
            "error_code": ErrorCode.UNKNOWN_ERROR.value,
            "message": str(e),
        }

    # ── 步骤 2：auto（开启自动化端口）────────────────────────
    try:
        proj_for_auto = params.project_path or DEFAULT_PROJECT_PATH
        if not proj_for_auto:
            result["auto"] = {
                "status": "failed",
                "error_code": ErrorCode.PROJECT_PATH_MISSING.value,
                "message": "未提供小程序项目路径，无法开启自动化端口�?,
            }
        else:
            cli = os.environ.get("WECHAT_DEVTOOLS_CLI", CLI_PATH)
            auto_cmd = [cli, "auto", "--project", proj_for_auto, "--auto-port", str(params.auto_port)]
            if sys.platform == "win32" and cli.lower().endswith(".bat"):
                auto_cmd = ["cmd", "/c"] + auto_cmd
            _sp.Popen(
                auto_cmd,
                stdout=_sp.DEVNULL,
                stderr=_sp.DEVNULL,
                creationflags=_sp.CREATE_NO_WINDOW if hasattr(_sp, "CREATE_NO_WINDOW") else 0,
            )
            await asyncio.sleep(2)
            result["auto"] = {
                "status": "ok",
                "port": params.auto_port,
            }
    except FileNotFoundError:
        result["auto"] = {
            "status": "failed",
            "error_code": ErrorCode.CLI_NOT_FOUND.value,
            "message": f"找不到微信开发者工�?CLI：{CLI_PATH}",
        }
    except Exception as e:
        result["auto"] = {
            "status": "failed",
            "error_code": ErrorCode.UNKNOWN_ERROR.value,
            "message": str(e),
        }

    # ── 步骤 3：open（打开项目）──────────────────────────────
    try:
        if params.cdp_enabled:
            exe_path = CLI_PATH.replace("cli.bat", "微信开发者工�?exe")
            open_cmd = [exe_path, "--remote-debugging-port=9222"]
            if params.project_path:
                open_cmd.extend(["--project", params.project_path])
        else:
            open_cli_args = ["open"]
            open_cli_args.extend(
                _build_global_args(
                    project_path=params.project_path,
                    appid=params.appid,
                    port=params.port,
                    lang=params.lang,
                )
            )
            if sys.platform == "win32" and CLI_PATH.lower().endswith(".bat"):
                open_cmd = ["cmd", "/c", CLI_PATH] + open_cli_args
            else:
                open_cmd = [CLI_PATH] + open_cli_args

        kwargs: dict = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = _sp.CREATE_NO_WINDOW

        proc = _sp.Popen(
            open_cmd,
            stdout=_sp.DEVNULL,
            stderr=_sp.DEVNULL,
            **kwargs,
        )
        try:
            await asyncio.wait_for(asyncio.to_thread(proc.wait), timeout=15)
        except asyncio.TimeoutError:
            pass  # 超时 = IDE 仍在运行，视为成�?

        result["open"] = {"status": "ok"}
    except FileNotFoundError:
        result["open"] = {
            "status": "failed",
            "error_code": ErrorCode.CLI_NOT_FOUND.value,
            "message": f"找不到微信开发者工具文件：{CLI_PATH}",
        }
    except Exception as e:
        result["open"] = {
            "status": "failed",
            "error_code": ErrorCode.UNKNOWN_ERROR.value,
            "message": str(e),
        }

    # ── 步骤 4：project_info（获取项目信息）──────────────────
    try:
        proj = params.project_path or DEFAULT_PROJECT_PATH
        if not proj:
            result["info"] = {
                "status": "failed",
                "error_code": ErrorCode.PROJECT_PATH_MISSING.value,
                "message": "未提供小程序项目路径，无法获取项目信息�?,
            }
        else:
            info: dict = {"status": "ok"}
            config_path = os.path.join(proj, "project.config.json")
            if os.path.exists(config_path):
                try:
                    with open(config_path, "r", encoding="utf-8") as f:
                        config = json.load(f)
                    info["appid"] = config.get("appid")
                    info["name"] = config.get("projectname")
                except Exception:
                    pass
            result["info"] = info
    except Exception as e:
        result["info"] = {
            "status": "failed",
            "error_code": ErrorCode.UNKNOWN_ERROR.value,
            "message": str(e),
        }

    return json.dumps(result, ensure_ascii=False, indent=2)


@_tool(
    name="wechat_open",
    annotations={
        "title": "打开微信开发者工�?/ 项目",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_open(params: OpenInput) -> str:
    """打开微信开发者工�?IDE，或打开指定的小程序项目�?

    若提�?project_path，则�?IDE 中打开该项目（每次执行都会自动编译刷新）；
    若不提供，则仅启�?IDE�?
    """
    import subprocess

    # CDP 模式：直接启�?EXE 并附�?--remote-debugging-port
    # �?CDP 模式：通过 CLI 'open' 子命令启�?
    # 两种模式统一使用 subprocess.Popen 异步启动，不等待进程退�?
    if params.cdp_enabled:
        exe_path = CLI_PATH.replace("cli.bat", "微信开发者工�?exe")
        cmd_args = [exe_path, "--remote-debugging-port=9222"]
        if params.project_path:
            cmd_args.extend(["--project", params.project_path])
        launch_desc = "微信开发者工具（CDP 模式，端�?9222�?

        # 已有实例运行�?--remote-debugging-port 会被忽略，需�?kill 再重�?
        if sys.platform == "win32":
            import subprocess as _sp
            _sp.run(
                ["taskkill", "/F", "/IM", "wechatdevtools.exe"],
                stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
                creationflags=_sp.CREATE_NO_WINDOW,
            )
            await asyncio.sleep(2)  # 等进程完全退�?
    else:
        # 构建 CLI open 命令
        cli_args = ["open"]
        cli_args.extend(
            _build_global_args(
                project_path=params.project_path,
                appid=params.appid,
                port=params.port,
                lang=params.lang,
            )
        )
        if sys.platform == "win32" and CLI_PATH.lower().endswith(".bat"):
            cmd_args = ["cmd", "/c", CLI_PATH] + cli_args[:]
        else:
            cmd_args = [CLI_PATH] + cli_args[:]
        launch_desc = "微信开发者工�?IDE"

    try:
        # Windows 使用 CREATE_NO_WINDOW 避免弹出命令行窗�?
        kwargs: dict = {}
        if sys.platform == "win32":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW

        proc = subprocess.Popen(
            cmd_args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            **kwargs,
        )

        # 等待最�?15 秒；超时视为"启动成功"（IDE 正在后台运行�?
        try:
            await asyncio.wait_for(asyncio.to_thread(proc.wait), timeout=15)
        except asyncio.TimeoutError:
            pass  # 超时 = IDE 仍在运行，视为成�?

        cdp_note = "，CDP 调试端口已开启（9222�? if params.cdp_enabled else ""
        return json.dumps(
            {
                "success": True,
                "message": f"�?{launch_desc} 已在后台启动{cdp_note}",
            },
            ensure_ascii=False,
            indent=2,
        )

    except FileNotFoundError:
        return _make_error(
            ErrorCode.CLI_NOT_FOUND,
            f"找不到微信开发者工具文件：{cmd_args[0]}",
            hint=(
                "请确认微信开发者工具已安装，或通过环境变量 WECHAT_DEVTOOLS_CLI "
                "指定正确�?cli.bat 路径�?
            ),
        )
    except Exception as e:
        return _make_error(
            ErrorCode.UNKNOWN_ERROR,
            f"启动微信开发者工具失败：{type(e).__name__}: {str(e)}",
        )


@_tool(
    name="wechat_login",
    annotations={
        "title": "登录微信开发者工�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_login(params: LoginInput) -> str:
    """登录微信开发者工具，生成二维码供扫码登录�?

    支持 qr_output 将二维码保存到文件，result_output 将登录结果写�?JSON 文件�?
    """
    args = ["login"]
    if params.qr_format:
        args.extend(["--qr-format", params.qr_format])
    if params.qr_output:
        args.extend(["--qr-output", params.qr_output])
    if params.result_output:
        args.extend(["--result-output", params.result_output])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


@_tool(
    name="wechat_is_login",
    annotations={
        "title": "检查微信开发者工具登录状�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_is_login(params: IsLoginInput) -> str:
    """检查微信开发者工具当前是否已登录�?""
    args = ["islogin"]
    args.extend(
        _build_global_args(
            project_path=params.project_path,
            appid=params.appid,
            port=params.port,
        )
    )
    result = await _run_cli(*args)
    return _format_result(result)


@_tool(
    name="wechat_preview",
    annotations={
        "title": "预览小程�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_preview(params: PreviewInput) -> str:
    """预览小程序，生成预览二维码�?

    增强功能�?
    - 支持 compile_condition 指定预览页面和参�?
    - 支持 qr_output 将二维码保存到文�?
    - 支持 info_output 获取包大小等信息
    """
    proj = _resolve_project_path(params.project_path)
    args = ["preview", "--project", proj]
    if params.qr_format:
        args.extend(["--qr-format", params.qr_format])
    if params.qr_output:
        args.extend(["--qr-output", params.qr_output])
    if params.info_output:
        args.extend(["--info-output", params.info_output])
    if params.compile_condition:
        args.extend(["--compile-condition", params.compile_condition])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


@_tool(
    name="wechat_preview_page",
    annotations={
        "title": "预览指定页面（快捷）",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_preview_page(params: PreviewPageInput) -> str:
    """快捷工具：直接预览小程序的指定页面�?

    自动构建 compile_condition 参数，无需手动�?JSON�?

    示例：预�?pages/index/index 页面，附带参�?id=123
    """
    proj = _resolve_project_path(params.project_path)
    condition: dict = {"pathName": params.page_path}
    if params.query:
        condition["query"] = params.query
    condition_json = json.dumps(condition, ensure_ascii=False)

    args = [
        "preview",
        "--project", proj,
        "--compile-condition", condition_json,
    ]
    if params.qr_format:
        args.extend(["--qr-format", params.qr_format])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


@_tool(
    name="wechat_auto_preview",
    annotations={
        "title": "自动预览小程�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_auto_preview(params: AutoPreviewInput) -> str:
    """自动预览：文件变化时自动刷新预览�?""
    proj = _resolve_project_path(params.project_path)
    args = ["auto-preview", "--project", proj]
    if params.info_output:
        args.extend(["--info-output", params.info_output])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


@_tool(
    name="wechat_upload",
    annotations={
        "title": "上传小程序代�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_upload(params: UploadInput) -> str:
    """上传小程序代码到微信后台�?

    ⚠️ 上传操作会覆盖相同版本号的已有代码，请谨慎使用�?
    支持 info_output 将包大小等信息输出到 JSON 文件�?
    """
    proj = _resolve_project_path(params.project_path)
    args = ["upload", "--project", proj, "--version", params.version]
    if params.desc:
        args.extend(["--desc", params.desc])
    if params.info_output:
        args.extend(["--info-output", params.info_output])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    if params.lang:
        args.extend(["--lang", params.lang])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


# ============================================================
# MCP 工具 �?构建 & 调试
# ============================================================


@_tool(
    name="wechat_build_npm",
    annotations={
        "title": "构建 NPM",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_build_npm(params: BuildNpmInput) -> str:
    """构建小程序项目中�?NPM 依赖�?""
    proj = _resolve_project_path(params.project_path)
    args = ["build-npm", "--project", proj]
    if params.compile_type:
        args.extend(["--compile-type", params.compile_type])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


@_tool(
    name="wechat_compile_check",
    annotations={
        "title": "编译检�?/ 查看报错",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_compile_check(params: CompileCheckInput) -> str:
    """编译检查：触发编译并捕获所有错误和警告信息�?

    这是 AI 开发小程序时最常用的调试工具：
    1. 修改代码后调用此工具检查是否有编译错误
    2. 如果有错误，根据错误信息修复代码
    3. 再次调用确认修复成功
    """
    proj = _resolve_project_path(params.project_path)
    info_path = params.info_output
    if not info_path:
        info_path = os.path.join(tempfile.gettempdir(), "wechat_compile_info.json")

    args = ["preview", "--project", proj, "--info-output", info_path]
    if params.port is not None:
        args.extend(["--port", str(params.port)])

    result = await _run_cli(*args, timeout=120)

    # 构建输出
    parts = []
    if result["success"]:
        parts.append("�?编译成功，未发现错误")
    else:
        parts.append("�?编译失败，发现以下错�?)

    parts.append(f"项目: {proj}")

    # 解析 stderr 中的错误信息
    stderr = result.get("stderr", "")
    if stderr:
        error_lines = []
        warning_lines = []
        for line in stderr.split("\n"):
            line_stripped = line.strip()
            if not line_stripped:
                continue
            if line_stripped.startswith(("- initialize", "�?", "- preparing",
                                         "- Fetching", "- Preview")):
                continue
            if any(kw in line_stripped.lower() for kw in
                   ["error", "错误", "fail", "异常", "[error]"]):
                error_lines.append(line_stripped)
            elif any(kw in line_stripped.lower() for kw in
                     ["warning", "warn", "警告"]):
                warning_lines.append(line_stripped)
            else:
                error_lines.append(line_stripped)

        if error_lines:
            parts.append("\n🔴 错误:")
            for line in error_lines:
                parts.append(f"  �?{line}")

        if warning_lines:
            parts.append("\n🟡 警告:")
            for line in warning_lines:
                parts.append(f"  �?{line}")

    # 读取编译输出�?JSON 信息
    if os.path.exists(info_path):
        try:
            with open(info_path, "r", encoding="utf-8") as f:
                compile_info = json.load(f)
            parts.append(f"\n📦 编译信息:\n{json.dumps(compile_info, indent=2, ensure_ascii=False)}")
        except Exception:
            pass

    if result.get("stdout"):
        parts.append(f"\n📊 输出:\n{result['stdout']}")

    return "\n".join(parts)


@_tool(
    name="wechat_cache_clean",
    annotations={
        "title": "清除工具缓存",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_cache_clean(params: CacheCleanInput) -> str:
    """清除微信开发者工具的缓存�?

    类型: storage(数据), file(文件), compile(编译), auth(授权),
    network(网络), session(登录), all(所�?
    """
    proj = _resolve_project_path(params.project_path)
    args = ["cache", "--clean", params.clean_type, "--project", proj]
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    return _format_result(result)


# ============================================================
# MCP 工具 �?自动化测试（新增�?
# ============================================================


@_tool(
    name="wechat_auto",
    annotations={
        "title": "开启自动化测试端口",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_auto(params: AutomationInput) -> str:
    """开启小程序自动化功能�?

    开启后，可通过 miniprogram-automator SDK 连接到指定端口，
    实现自动化测试：控制页面跳转、获取元素、触发事件、注入代码等�?

    典型用法�?
    1. 调用此工具开启自动化（默认端�?9420�?
    2. 通过 automator SDK 连接并执行测试脚�?
    """
    proj = _resolve_project_path(params.project_path)
    # 使用环境变量中的 CLI 路径
    cli = os.environ.get("WECHAT_DEVTOOLS_CLI", CLI_PATH)
    
    cmd_args = [cli, "auto", "--project", proj]
    if params.auto_port is not None:
        cmd_args.extend(["--auto-port", str(params.auto_port)])
    if params.auto_account:
        cmd_args.extend(["--auto-account", params.auto_account])
    
    # Windows 兼容性：确保 .bat 文件能正确执�?
    if sys.platform == "win32" and cli.lower().endswith(".bat"):
        cmd_args = ["cmd", "/c"] + cmd_args

    import subprocess as _sp
    _sp.Popen(
        cmd_args,
        stdout=_sp.DEVNULL,
        stderr=_sp.DEVNULL,
        # creationflags 仅在 Windows 上有效，防止弹出黑色窗口
        creationflags=_sp.CREATE_NO_WINDOW if hasattr(_sp, "CREATE_NO_WINDOW") else 0,
    )
    
    await asyncio.sleep(3)
    return f"�?自动化端口已在后台启动，监听端口 {params.auto_port or 9420}"


@_tool(
    name="wechat_auto_replay",
    annotations={
        "title": "打开自动化测试窗�?/ 回放测试",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_auto_replay(params: AutoReplayInput) -> str:
    """打开自动化测试窗口，可回放之前录制的测试用例�?

    设置 replay_all=True 可自动回放全部测试用例�?
    """
    proj = _resolve_project_path(params.project_path)
    args = ["auto-replay", "--project", proj]
    if params.replay_all:
        args.append("--replay-all")
    result = await _run_cli(*args, timeout=60)
    return _format_result(result)


@_tool(
    name="wechat_reset_fileutils",
    annotations={
        "title": "重建文件监听",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_reset_fileutils(params: ResetFileUtilsInput) -> str:
    """重建文件监听：重置工具内部文件缓存，重新监听项目文件�?

    �?AI 修改了大量文件后，调用此工具可确保开发者工具检测到所有变更，
    自动重新编译刷新�?

    ⚠️ 需要确保先�?wechat_open 打开了项目�?
    """
    proj = _resolve_project_path(params.project_path)
    args = ["reset-fileutils", "--project", proj]
    result = await _run_cli(*args)
    return _format_result(result)


# ============================================================
# MCP 工具 �?项目上下文感知（新增�?
# ============================================================


@_tool(
    name="wechat_project_info",
    annotations={
        "title": "获取小程序项目信�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_project_info(params: ProjectInfoInput) -> str:
    """获取小程序项目的完整信息，包括：

    - project.config.json 配置（AppID、编译选项等）
    - app.json 配置（页面列表、窗口设置、TabBar 等）
    - app.wxss 全局样式（前 100 行）
    - app.js 入口逻辑（前 50 行）
    - 项目目录结构概览

    这是 AI 开始开发小程序前最应该先调用的工具，可以全面了解项目上下文�?
    """
    proj = _resolve_project_path(params.project_path)
    parts = [f"📁 项目路径: {proj}\n"]

    # 读取 project.config.json，同时解�?miniprogramRoot
    miniprogram_root = proj
    config_path = os.path.join(proj, "project.config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            parts.append(f"📋 project.config.json:\n{json.dumps(config, indent=2, ensure_ascii=False)}\n")
            mp_root = config.get("miniprogramRoot", "")
            if mp_root:
                miniprogram_root = os.path.join(proj, mp_root.rstrip("/\\"))
        except Exception as e:
            parts.append(f"⚠️ 读取 project.config.json 失败: {e}\n")
    else:
        parts.append("⚠️ 未找�?project.config.json\n")

    # 读取 app.json（支�?miniprogramRoot�?
    app_json_path = os.path.join(miniprogram_root, "app.json")
    if os.path.exists(app_json_path):
        try:
            with open(app_json_path, "r", encoding="utf-8") as f:
                app_config = json.load(f)
            parts.append(f"📱 app.json:\n{json.dumps(app_config, indent=2, ensure_ascii=False)}\n")
        except Exception as e:
            parts.append(f"⚠️ 读取 app.json 失败: {e}\n")

    # 读取 app.wxss 的前 100 行（支持 miniprogramRoot�?
    app_wxss_path = os.path.join(miniprogram_root, "app.wxss")
    if os.path.exists(app_wxss_path):
        try:
            with open(app_wxss_path, "r", encoding="utf-8") as f:
                lines = f.readlines()[:100]
            wxss_content = "".join(lines)
            parts.append(f"🎨 app.wxss (�?{len(lines)} �?:\n{wxss_content}\n")
        except Exception as e:
            parts.append(f"⚠️ 读取 app.wxss 失败: {e}\n")

    # 读取 app.js 的前 50 行（支持 miniprogramRoot�?
    app_js_path = os.path.join(miniprogram_root, "app.js")
    if os.path.exists(app_js_path):
        try:
            with open(app_js_path, "r", encoding="utf-8") as f:
                lines = f.readlines()[:50]
            js_content = "".join(lines)
            parts.append(f"⚙️ app.js (�?{len(lines)} �?:\n{js_content}\n")
        except Exception as e:
            parts.append(f"⚠️ 读取 app.js 失败: {e}\n")

    # 项目目录结构
    parts.append("📂 项目目录结构:")
    try:
        for item in sorted(os.listdir(proj)):
            full = os.path.join(proj, item)
            if item.startswith(".") or item in ("node_modules", "miniprogram_npm", "__pycache__"):
                continue
            if os.path.isdir(full):
                children = os.listdir(full)
                parts.append(f"  📁 {item}/ ({len(children)} �?")
            else:
                size = os.path.getsize(full)
                parts.append(f"  📄 {item} ({size} bytes)")
    except Exception as e:
        parts.append(f"  ⚠️ 读取目录失败: {e}")

    return "\n".join(parts)


@_tool(
    name="wechat_list_pages",
    annotations={
        "title": "列出所有页面及其文�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_list_pages(params: ListPagesInput) -> str:
    """列出小程序中所有注册的页面，以及每个页面包含的文件�?

    �?app.json �?pages 数组读取页面列表，并检查每个页面的
    .wxml / .wxss / .js / .json / .ts 文件是否存在�?
    """
    proj = _resolve_project_path(params.project_path)

    # 支持 miniprogramRoot（云开发项目结构）
    miniprogram_root = proj
    project_config_path = os.path.join(proj, "project.config.json")
    if os.path.exists(project_config_path):
        try:
            with open(project_config_path, "r", encoding="utf-8") as f:
                pc = json.load(f)
            mp_root = pc.get("miniprogramRoot", "")
            if mp_root:
                miniprogram_root = os.path.join(proj, mp_root.rstrip("/\\"))
        except Exception:
            pass

    app_json_path = os.path.join(miniprogram_root, "app.json")

    if not os.path.exists(app_json_path):
        return f"�?未找�?app.json: {app_json_path}"

    try:
        with open(app_json_path, "r", encoding="utf-8") as f:
            app_config = json.load(f)
    except Exception as e:
        return f"�?读取 app.json 失败: {e}"

    pages = app_config.get("pages", [])
    if not pages:
        return "⚠️ app.json 中未定义任何页面�?

    parts = [f"📱 小程序共�?{len(pages)} 个页�?\n"]
    exts = [".wxml", ".wxss", ".js", ".json", ".ts"]

    for page in pages:
        page_dir = os.path.join(miniprogram_root, page)
        existing = []
        missing = []
        for ext in exts:
            if os.path.exists(page_dir + ext):
                size = os.path.getsize(page_dir + ext)
                existing.append(f"{ext}({size}B)")
            else:
                if ext == ".ts":
                    continue  # .ts 是可选的
                missing.append(ext)

        status = "�? if not missing else "⚠️"
        parts.append(f"  {status} {page}")
        parts.append(f"     存在: {', '.join(existing)}")
        if missing:
            parts.append(f"     缺失: {', '.join(missing)}")

    return "\n".join(parts)


@_tool(
    name="wechat_read_page",
    annotations={
        "title": "读取页面的全部源码文�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_read_page(params: ReadPageFilesInput) -> str:
    """读取指定小程序页面的全部源码文件�?wxml, .wxss, .js, .json）�?

    AI 在修改页面代码前应先调用此工具了解现有代码�?
    返回每个文件的完整内容（每个文件最�?500 行）�?
    """
    proj = _resolve_project_path(params.project_path)
    page_base = os.path.join(proj, params.page_path)
    exts = [".wxml", ".wxss", ".js", ".json", ".ts"]

    parts = [f"📄 页面: {params.page_path}\n"]
    found_any = False

    for ext in exts:
        fpath = page_base + ext
        if os.path.exists(fpath):
            found_any = True
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                content = "".join(lines[:500])
                truncated = " (截断，共 {} �?".format(len(lines)) if len(lines) > 500 else ""
                parts.append(f"--- {os.path.basename(fpath)}{truncated} ---")
                parts.append(content)
                parts.append("")
            except Exception as e:
                parts.append(f"--- {os.path.basename(fpath)} ---")
                parts.append(f"⚠️ 读取失败: {e}\n")

    if not found_any:
        parts.append(f"�?未找到该页面的任何文件。路�? {page_base}.*")

    return "\n".join(parts)


@_tool(
    name="wechat_read_file",
    annotations={
        "title": "读取项目中的单个文件",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_read_file(params: ReadFileInput) -> str:
    """读取小程序项目中的任意单个文件�?

    路径相对于项目根目录，例�?'app.json'�?utils/util.js' 等�?
    返回文件内容（最�?800 行）�?
    """
    proj = _resolve_project_path(params.project_path)
    fpath = os.path.join(proj, params.file_path)

    if not os.path.exists(fpath):
        return f"�?文件不存�? {fpath}"

    try:
        with open(fpath, "r", encoding="utf-8") as f:
            lines = f.readlines()
        content = "".join(lines[:800])
        total = len(lines)
        header = f"📄 {params.file_path} ({total} �?"
        if total > 800:
            header += " [仅显示前 800 行]"
        return f"{header}\n\n{content}"
    except Exception as e:
        return f"�?读取文件失败: {e}"


# ============================================================
# MCP 工具 �?云函数管理（新增�?
# ============================================================


@_tool(
    name="wechat_cloud_env_list",
    annotations={
        "title": "列出云开发环�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_cloud_env_list(params: CloudEnvListInput) -> str:
    """列出小程序关联的所有云开发环境�?""
    args = ["cloud", "env", "list"]
    proj = _resolve_project_path(params.project_path)
    args.extend(
        _build_global_args(
            project_path=proj,
            appid=params.appid,
            port=params.port,
            lang=params.lang,
        )
    )
    result = await _run_cli(*args)
    return _format_result(result)


@_tool(
    name="wechat_cloud_func_list",
    annotations={
        "title": "查看云函数列�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_cloud_func_list(params: CloudFuncListInput) -> str:
    """查看指定云环境下的线上云函数列表�?""
    args = ["cloud", "functions", "list", "--env", params.env]
    proj = params.project_path
    if proj:
        args.extend(["--project", proj])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    return _format_result(result)


@_tool(
    name="wechat_cloud_func_info",
    annotations={
        "title": "查看云函数信�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_cloud_func_info(params: CloudFuncInfoInput) -> str:
    """查看指定云函数的详细信息�?""
    args = ["cloud", "functions", "info", "--env", params.env, "--names"] + params.names
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    return _format_result(result)


@_tool(
    name="wechat_cloud_func_deploy",
    annotations={
        "title": "上传云函�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_cloud_func_deploy(params: CloudFuncDeployInput) -> str:
    """上传云函数到指定的云环境�?

    可通过 names（函数名，需配合 --project）或 paths（绝对路径）指定�?
    remote_npm_install=True 时云端安装依赖，不上�?node_modules�?
    """
    args = ["cloud", "functions", "deploy", "--env", params.env]
    if params.remote_npm_install:
        args.append("-r")
    if params.names:
        args.extend(["--names"] + params.names)
    if params.paths:
        args.extend(["--paths"] + params.paths)
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


@_tool(
    name="wechat_cloud_func_download",
    annotations={
        "title": "下载云函�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_cloud_func_download(params: CloudFuncDownloadInput) -> str:
    """从云环境下载指定云函数到本地目录�?""
    args = [
        "cloud", "functions", "download",
        "--env", params.env,
        "--name", params.name,
        "--path", params.download_path,
    ]
    if params.project_path:
        args.extend(["--project", params.project_path])
    if params.appid:
        args.extend(["--appid", params.appid])
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args, timeout=120)
    return _format_result(result)


# ============================================================
# MCP 工具 �?IDE 管理
# ============================================================


@_tool(
    name="wechat_close_project",
    annotations={
        "title": "关闭项目窗口",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_close_project(params: CloseProjectInput) -> str:
    """关闭微信开发者工具中指定的项目窗口�?

    注意：关闭时 IDE 会弹窗确认，3秒后自动关闭�?
    """
    proj = _resolve_project_path(params.project_path)
    args = ["close", "--project", proj]
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    return _format_result(result)


@_tool(
    name="wechat_quit_ide",
    annotations={
        "title": "退出微信开发者工�?,
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_quit_ide(params: QuitIdeInput) -> str:
    """关闭整个微信开发者工具�?

    ⚠️ 注意：这将关�?IDE 及所有打开的项目�?
    """
    args = ["quit"]
    if params.port is not None:
        args.extend(["--port", str(params.port)])
    result = await _run_cli(*args)
    return _format_result(result)


# ============================================================
# MCP 工具 �?系统诊断与发�?
# ============================================================


@_tool(
    name="wechat_get_status",
    annotations={
        "title": "环境诊断",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_status() -> str:
    """返回微信开发者工�?MCP 服务的运行状态和当前项目配置信息�?""
    project_path = DEFAULT_PROJECT_PATH or "未配�?
    cli_path = CLI_PATH

    project_exists = os.path.isdir(project_path) if project_path != "未配�? else False
    cli_exists = os.path.exists(cli_path)

    # 检�?Node.js 可用性（使用缓存�?
    node_ok, node_path = await _check_node_available()

    parts = [
        "🌐 WeChat DevTools MCP 服务状�?,
        f"  - 状�? 运行�?,
        f"  - CLI 路径: {cli_path} ({'�?存在' if cli_exists else '�?不存�?})",
        f"  - 项目路径: {project_path} ({'�?存在' if project_exists else '�?不存�?})",
    ]

    if node_ok:
        parts.append(f"  - Node.js: �?可用 ({node_path})")
    else:
        parts.append(f"  - Node.js: �?未检测到")
        parts.append(f"    error_code: {ErrorCode.NODE_NOT_FOUND.value}")
        parts.append(f"    请安�?Node.js 并配�?PATH 环境变量。下载地址：https://nodejs.org/zh-cn/download/")

    if project_exists:
        config_path = os.path.join(project_path, "project.config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    config = json.load(f)
                parts.append(f"  - 项目�? {config.get('projectname', '未知')}")
                parts.append(f"  - AppID: {config.get('appid', '未知')}")
                parts.append(f"  - 基础�? {config.get('libVersion', '未知')}")
            except Exception:
                pass
    
    return "\n".join(parts)


@_tool(
    name="wechat_list_tools",
    annotations={
        "title": "工具发现",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_list_tools() -> str:
    """列出所有已注册�?MCP 工具及其分类�?""
    # 所有已知工具的描述映射
    tool_descriptions: dict[str, str] = {
        "wechat_setup_sop": "一键完成初始化：is_login �?auto �?open �?project_info（尽力模式）",
        "wechat_open": "打开微信开发者工�?IDE，或打开指定的小程序项目",
        "wechat_is_login": "检查微信开发者工具当前是否已登录",
        "wechat_auto": "开启小程序自动化功�?,
        "wechat_project_info": "获取小程序项目的完整信息",
        "wechat_compile_check": "编译检查：触发编译并捕获所有错误和警告信息",
        "wechat_get_console_logs": "实时采集小程序运行时�?console 日志�?JS 异常",
        "wechat_navigate_and_capture": "跳转到指定页面，等待指定时间，捕获该时间窗口内的所有日志和异常",
        "wechat_capture_screenshot": "实时捕获当前小程序模拟器的界面截�?,
        "wechat_tap_element": "通过 CSS 选择器定位页面上的元素并模拟点击",
        "wechat_get_element_info": "获取页面元素的详细信息（文本、WXML 结构、尺寸、位置、样式）",
        "wechat_mock_wx_method": "覆盖 wx 对象上指定方法的调用结果（Mock�?,
        "wechat_get_status": "返回微信开发者工�?MCP 服务的运行状态和当前项目配置信息",
        "wechat_list_tools": "列出所有已注册�?MCP 工具及其分类",
        "wechat_get_cdp_logs": "通过 Chromium DevTools Protocol (CDP) 采集高清日志",
        "wechat_login": "登录微信开发者工具，生成二维码供扫码登录",
        "wechat_preview": "预览小程序，生成预览二维�?,
        "wechat_preview_page": "快捷工具：直接预览小程序的指定页�?,
        "wechat_upload": "上传小程序代码到微信后台",
        "wechat_build_npm": "构建小程序项目中�?NPM 依赖",
        "wechat_cache_clean": "清除微信开发者工具的缓存",
        "wechat_cloud_env_list": "列出小程序关联的所有云开发环�?,
        "wechat_cloud_func_list": "查看指定云环境下的线上云函数列表",
        "wechat_cloud_func_info": "查看指定云函数的详细信息",
        "wechat_cloud_func_deploy": "上传云函数到指定的云环境",
        "wechat_cloud_func_download": "从云环境下载指定云函数到本地目录",
        "wechat_run_automation_script": "执行自定�?JS 自动化测试脚本，并捕获执行期间的所有日志和异常",
        "wechat_set_page_data": "动态设置当前页面的 data（响应式数据），无需重新编译即可热更�?UI",
        "wechat_call_page_method": "调用当前页面中的指定方法",
        "wechat_evaluate_expression": "在小程序逻辑层运行环境中直接执行一�?JS 表达式，并返回结�?,
        "wechat_get_page_stack": "获取当前小程序的页面栈信�?,
        "wechat_get_storage": "获取小程序的本地缓存数据",
        "wechat_get_page_data": "读取小程序当前活跃页面的 data 模型状�?,
        "wechat_call_wx_method": "直接调用 wx 对象上的指定方法",
        "wechat_input_element": "�?input �?textarea 元素输入文本内容",
        "wechat_get_exceptions": "专门监听小程序运行时 JS 异常",
        "wechat_get_system_info": "通过自动化接口获取小程序运行时的系统信息",
        "wechat_auto_preview": "自动预览：文件变化时自动刷新预览",
        "wechat_auto_replay": "打开自动化测试窗口，可回放之前录制的测试用例",
        "wechat_reset_fileutils": "重建文件监听：重置工具内部文件缓存，重新监听项目文件",
        "wechat_close_project": "关闭微信开发者工具中指定的项目窗�?,
        "wechat_quit_ide": "关闭整个微信开发者工�?,
        "wechat_list_pages": "列出小程序中所有注册的页面，以及每个页面包含的文件",
        "wechat_read_page": "读取指定小程序页面的全部源码文件",
        "wechat_read_file": "读取小程序项目中的任意单个文�?,
    }

    all_tool_names = sorted(CORE_TOOLS | ADVANCED_TOOLS)
    tools_list = []
    for name in all_tool_names:
        tier = "core" if name in CORE_TOOLS else "advanced"
        tools_list.append({
            "name": name,
            "description": tool_descriptions.get(name, ""),
            "tier": tier,
        })

    payload = {
        "total": len(tools_list),
        "core_count": len(CORE_TOOLS),
        "advanced_count": len(ADVANCED_TOOLS),
        "tools": tools_list,
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


# ============================================================
# 辅助函数 �?Node.js 脚本调用
# ============================================================

# Node.js 脚本所在目录（�?server.py 同级�?scripts/ 子目录）
# Node.js 脚本所在目�?
_SCRIPTS_DIR = os.environ.get(
    "WECHAT_SCRIPTS_DIR",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "scripts")
)

# 检�?Node.js 可执行文件路�?
_NODE_PATH = os.environ.get("NODE_PATH", "node")

# ============================================================
# Node.js 可用性检测与缓存
# ============================================================

_node_available: Optional[bool] = None
_node_path_cache: Optional[str] = None

# 防止并发 npm install 的模块级�?
_npm_install_lock = asyncio.Lock()


async def _check_node_available() -> tuple[bool, str]:
    """检�?Node.js 是否可用，结果缓存到模块级变量，避免重复检测�?

    Returns:
        tuple[bool, str]: (是否可用, node路径或空字符�?
    """
    global _node_available, _node_path_cache
    if _node_available is not None:
        return _node_available, _node_path_cache or ""

    global _NODE_PATH

    # 候选路径列表：先用环境变量/PATH，再 fallback �?Windows 常见安装位置
    candidates = [_NODE_PATH]
    if sys.platform == "win32":
        candidates += [
            r"C:\Program Files\nodejs\node.exe",
            r"C:\Program Files (x86)\nodejs\node.exe",
            os.path.expandvars(r"%APPDATA%\nvm\current\node.exe"),
            os.path.expandvars(r"%ProgramFiles%\nodejs\node.exe"),
        ]

    for candidate in candidates:
        try:
            process = await asyncio.create_subprocess_exec(
                candidate, "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout=10)
            if process.returncode == 0:
                version = stdout.decode("utf-8", errors="replace").strip()
                node_path = candidate if os.path.isabs(candidate) else f"node ({version})"
                _node_available = True
                _node_path_cache = node_path
                # 如果找到的是绝对路径，更新全局 _NODE_PATH 供后续调用使�?
                if os.path.isabs(candidate) and os.path.exists(candidate):
                    _NODE_PATH = candidate
                return True, node_path
        except Exception:
            continue

    _node_available = False
    _node_path_cache = ""
    return False, ""


async def _run_node_script(
    script_name: str,
    *extra_args: str,
    timeout: int = 120,
) -> dict:
    """
    调用 scripts/ 目录下的 Node.js 脚本，返回解析后�?JSON 结果�?

    优先使用 Bundle 文件（scripts/dist/<name>.bundle.js），若不存在则检�?
    node_modules，若 node_modules 也不存在则自动执�?npm install --production�?

    Args:
        script_name: 脚本文件名（不含路径），例如 'console_listener.js'
        *extra_args: 传递给脚本的额外命令行参数
        timeout: 执行超时时间（秒�?

    Returns:
        dict: 脚本输出�?JSON 对象，或包含 error 字段的错误信�?
    """
    script_path = os.path.join(_SCRIPTS_DIR, script_name)
    if not os.path.exists(script_path):
        return {
            "success": False,
            "error": (
                f"找不�?Node.js 脚本: {script_path}\n"
                "请确�?scripts/ 目录存在，并已运�?npm install（在 scripts/ 目录下执行）�?
            ),
        }

    # 检�?Node.js 可用性（使用缓存�?
    node_ok, node_path = await _check_node_available()
    if not node_ok:
        return json.loads(_make_error(
            ErrorCode.NODE_NOT_FOUND,
            "未检测到 Node.js，无法执行自动化脚本�?,
            hint="请安�?Node.js�?= 8.0）并配置 PATH 环境变量。下载地址：https://nodejs.org/zh-cn/download/",
        ))

    # ── Bundle 优先逻辑 ──────────────────────────────────────
    # Bundle 路径约定：scripts/dist/<name>.bundle.js
    script_stem = os.path.splitext(script_name)[0]  # 去掉 .js 后缀
    bundle_path = os.path.join(_SCRIPTS_DIR, "dist", f"{script_stem}.bundle.js")

    if os.path.exists(bundle_path):
        # 使用 Bundle，无需 node_modules
        run_script_path = bundle_path
    else:
        # Bundle 不存在，检�?node_modules
        node_modules_dir = os.path.join(_SCRIPTS_DIR, "node_modules")
        if not os.path.exists(node_modules_dir):
            # 自动执行 npm install --production（使用锁防止并发�?
            async with _npm_install_lock:
                # 双重检查：可能在等待锁期间已被其他协程安装完毕
                if not os.path.exists(node_modules_dir):
                    try:
                        npm_proc = await asyncio.create_subprocess_exec(
                            "npm", "install", "--production",
                            cwd=_SCRIPTS_DIR,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE,
                        )
                        npm_stdout, npm_stderr = await asyncio.wait_for(
                            npm_proc.communicate(), timeout=120
                        )
                        if npm_proc.returncode != 0:
                            npm_err = npm_stderr.decode("utf-8", errors="replace").strip()
                            return json.loads(_make_error(
                                ErrorCode.NPM_DEPS_MISSING,
                                f"自动安装 Node.js 依赖失败：{npm_err}",
                                hint=(
                                    f"请手动执行：cd \"{_SCRIPTS_DIR}\" && npm install --production"
                                ),
                            ))
                    except asyncio.TimeoutError:
                        return json.loads(_make_error(
                            ErrorCode.NPM_DEPS_MISSING,
                            "npm install 执行超时�?20秒）�?,
                            hint=(
                                f"请手动执行：cd \"{_SCRIPTS_DIR}\" && npm install --production"
                            ),
                        ))
                    except FileNotFoundError:
                        return json.loads(_make_error(
                            ErrorCode.NPM_DEPS_MISSING,
                            "未找�?npm 命令，无法自动安�?Node.js 依赖�?,
                            hint=(
                                f"请安�?Node.js（含 npm），然后手动执行：cd \"{_SCRIPTS_DIR}\" && npm install --production"
                            ),
                        ))
        run_script_path = script_path

    cmd = [_NODE_PATH, run_script_path] + list(extra_args)
    cmd_display = " ".join(cmd)

    process = None
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=_SCRIPTS_DIR,  # 确保�?scripts/ 目录下执行，�?require 能找�?node_modules
        )
        stdout, stderr = await asyncio.wait_for(
            process.communicate(), timeout=timeout
        )
        stdout_text = stdout.decode("utf-8", errors="replace").strip()
        stderr_text = stderr.decode("utf-8", errors="replace").strip()

        # 优先尝试解析 JSON 输出
        if stdout_text:
            try:
                return json.loads(stdout_text)
            except json.JSONDecodeError:
                pass

        # 如果 JSON 解析失败，返回原始文�?
        return {
            "success": process.returncode == 0,
            "stdout": stdout_text,
            "stderr": stderr_text,
            "return_code": process.returncode,
            "command": cmd_display,
        }

    except asyncio.TimeoutError:
        return {
            "success": False,
            "error": f"Node.js 脚本执行超时（{timeout}秒）: {cmd_display}",
        }
    except FileNotFoundError:
        return {
            "success": False,
            "error": (
                f"找不�?Node.js 可执行文�? {_NODE_PATH}\n"
                "请确认已安装 Node.js�?= 8.0），或设�?NODE_PATH 环境变量指向 node 可执行文件�?
            ),
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"执行 Node.js 脚本失败: {type(e).__name__}: {e}",
        }
    finally:
        if process is not None and process.returncode is None:
            try:
                process.kill()
                await process.wait()
            except Exception:
                pass


def _format_console_result(result: dict) -> str:
    """将日志采集结果格式化为可读字符串�?""
    if not result.get("success") and "error" in result:
        return f"�?连接失败: {result['error']}\n\n💡 提示:\n  1. 确认已调�?wechat_auto 工具开启了自动化端口\n  2. 确认已在 scripts/ 目录运行: npm install"

    parts = []
    port = result.get("port", "?")
    duration = result.get("duration", "?")
    summary = result.get("summary", {})

    if result.get("success"):
        parts.append(f"�?日志采集完成 | 端口: {port} | 持续: {duration}�?)
    else:
        parts.append(f"⚠️ 采集时发生错�?| 端口: {port}")
        if result.get("error"):
            parts.append(f"错误: {result['error']}")

    # 摘要
    if summary:
        parts.append(
            f"\n📊 摘要: �?{summary.get('total_logs', 0)} 条日�?
            f" | 错误 {summary.get('errors', 0)} �?
            f" | 警告 {summary.get('warnings', 0)} �?
            f" | 异常 {summary.get('exceptions', 0)} �?
        )

    # Console 日志
    console_logs = result.get("console_logs", [])
    if console_logs:
        parts.append("\n📋 Console 日志:")
        for entry in console_logs:
            t = entry.get("type", "log").upper()
            icon = {"LOG": "📝", "WARN": "🟡", "ERROR": "🔴", "INFO": "ℹ️", "DEBUG": "🔍"}.get(t, "📝")
            args_str = ", ".join(str(a) for a in entry.get("args", []))
            parts.append(f"  {icon} [{entry.get('time', '')}] [{t}] {args_str}")
    else:
        parts.append("\n📋 Console 日志: �?)

    # 异常
    exceptions = result.get("exceptions", [])
    if exceptions:
        parts.append("\n🚨 运行时异�?")
        for i, exc in enumerate(exceptions, 1):
            parts.append(f"  [{exc.get('time', '')}] 异常 #{i}: {exc.get('message', '')}")
            stack = exc.get("stack", "")
            if stack:
                # 只显示前 5 行调用栈
                stack_lines = stack.strip().split("\n")[:5]
                for line in stack_lines:
                    parts.append(f"    {line.strip()}")
    else:
        parts.append("\n🚨 运行时异�? �?)

    # 自动点击结果
    tap_result = result.get("tap_result")
    if tap_result:
        if tap_result.get("success"):
            parts.append(f"\n👆 自动点击: �?成功 ({tap_result.get('selector', '')})")
        else:
            parts.append(f"\n👆 自动点击: �?失败 ({tap_result.get('error', '')})")

    return "\n".join(parts)


# ============================================================
# MCP 工具 �?实时日志 & 调试事件监听（新增）
# ============================================================


@_tool(
    name="wechat_get_console_logs",
    annotations={
        "title": "实时获取小程序控制台日志",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_console_logs(params: ConsoleLogsInput) -> str:
    """实时采集小程序运行时�?console 日志�?JS 异常�?

    通过 miniprogram-automator SDK 连接到自动化端口，监听：
    - console.log / warn / error / info / debug 的输�?
    - 页面 JS 运行时异常（exception 事件�?

    ⚠️ 局限性及建议�?
    本工具仅能采集页面代码中主动使用 console 打印的内容�?
    它无法获取微信开发者工具底层的监控日志（如 WXML 警告、渲染层报错等）�?
    👉 强烈推荐：在调试分析问题时，优先使用 `wechat_get_cdp_logs` 获取更全面、高清的日志�?

    ⚠️ 使用前提�?
    1. 先调�?wechat_auto 工具开启自动化端口（默�?9420�?
    2. �?scripts/ 目录下已运行 npm install

    高级用法 �?采集同时触发操作�?
    - 设置 tap_selector='.btn' 可在采集期间自动点击按钮
    - 设置 tap_delay=1000 控制延迟点击时机（毫秒）
    - 这样能同时捕获操作前后的日志和异�?
    """
    script_args = [
        "--port", str(params.auto_port),
        "--duration", str(params.duration),
        "--type", params.log_type,
    ]

    # 如果指定了自动点�?
    if params.tap_selector:
        script_args.extend(["--tap", params.tap_selector])
        script_args.extend(["--tap-delay", str(params.tap_delay)])

    result = await _run_node_script(
        "console_listener.js",
        *script_args,
        timeout=params.duration + 15,
    )
    return _format_console_result(result)


@_tool(
    name="wechat_get_cdp_logs",
    annotations={
        "title": "通过 CDP 获取小程序高清日�?(含WXML警告)",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_cdp_logs(params: CDPLogsInput) -> str:
    """通过 Chromium DevTools Protocol (CDP) 采集高清日志（强烈推荐）�?

    这是调试和分析小程序问题的首选日志采集工具！能够捕获 standard SDK 无法获取的底层核心信息：
    - WXML 语法警告（如标签未闭合、弃用属性等�?
    - 渲染层网络请求报错（如图片、接�?404/500�?
    - 微信环境系统级日志及更完整的运行时错误堆�?

    相比 `wechat_get_console_logs`，本工具能提供最全面真实的调试上下文�?

    ⚠️ 使用前提�?
    1. 调用 wechat_open 时设�?cdp_enabled=True
    2. 确保端口 9222 未被占用
    """
    script_args = [
        str(params.duration),
    ]

    result = await _run_node_script(
        "cdp_listener.js",
        *script_args,
        timeout=params.duration + 10,
    )
    
    # 如果返回的是列表，说�?JSON 解析成功且是日志数组
    if isinstance(result, list):
        if not result:
            return "ℹ️ 采集结束，未发现新日志�?
        
        # 根据 verbose 参数过滤系统日志
        result = _filter_cdp_logs(result, params.verbose)
        
        if not result:
            return "ℹ️ 采集结束，未发现业务相关日志（系统日志已过滤，可设置 verbose=True 查看全量日志）�?
        
        processed_logs = []
        seen_messages = set() # 用于去重
        
        for log in result:
            log_type = log.get('type', 'UNKNOWN')
            url = log.get('url', 'N/A')
            content = log.get('content', {})
            
            # 基础数据提取
            text = ""
            level = "log"
            source = ""
            
            if log_type == "RUNTIME_CONSOLE" or log_type == "Runtime.consoleAPICalled":
                if 'args' in content:
                    text = " ".join(str(a.get('value') if isinstance(a, dict) else a) for a in content['args'])
                    level = content.get('type', 'log')
            elif log_type == "CONSOLE" or log_type == "Console.messageAdded":
                # Console message 包含更丰富的元数�?
                msg_body = content if isinstance(content, dict) else {}
                text = msg_body.get('text', '')
                level = msg_body.get('level', 'log')
                source = msg_body.get('url', '')
            elif log_type == "EXCEPTION":
                text = content.get('exception', {}).get('description', 'Unknown Exception')
                level = "error"
            
            if not text: continue
            
            # 1. 清理 %c �?CSS 格式占位�?
            if text.startswith('%c'):
                text = text.replace('%c', '', 1)
                # 微信特定的警告通常在第二个参数或后面，简单处�?
                if ' font-weight: bold;' in text:
                    text = text.replace(' font-weight: bold;', '')

            # 2. 去重逻辑 (根据内容和级�?
            msg_key = f"{level}:{text}"
            if msg_key in seen_messages:
                continue
            seen_messages.add(msg_key)

            # 3. 设置美化的图�?
            icon = "📝"
            if level in ["warning", "warn"]:
                icon = "🟡 [警告]"
            elif level in ["error", "exception"]:
                icon = "🔴 [错误]"
            elif "[system]" in text.lower():
                icon = "⚙️ [系统]"
            elif level == "info":
                icon = "ℹ️"
            
            # 4. 来源过滤：仅显示�?IDE 内部的业务路�?
            origin = ""
            if source or url:
                path = source or url
                if not path.startswith('ide://') and not path.startswith('devtools://'):
                    # 尝试保留 miniprogram 后的路径
                    if 'appservice/' in path:
                        origin = f" 🔗 {path.split('appservice/')[-1].split('?')[0]}"
                    else:
                        origin = f" 🔗 {path.split('/')[-1].split('?')[0]}"

            processed_logs.append(f"{icon} {text}{origin}")
        
        if not processed_logs:
            return "ℹ️ 采集结束，未发现业务相关日志�?
            
        return "\n".join(processed_logs)
    
    # 否则说明返回的是统一的脚本执行状态字�?
    if not result.get("success"):
        return f"�?CDP 日志采集失败: {result.get('error', result.get('stderr', 'Unknown error'))}"
    
    return "ℹ️ 采集结束，未发现新日志（或脚本输出格式不正确）�?


@_tool(
    name="wechat_get_exceptions",
    annotations={
        "title": "实时获取运行�?JS 异常",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_exceptions(params: ExceptionsInput) -> str:
    """专门监听小程序运行时 JS 异常（exception 事件）�?

    当小程序页面 JS 代码出错时，会捕获到异常信息，包含：
    - 错误消息（message�?
    - 完整调用栈（stack�?
    - 出错时间�?

    相比 wechat_get_console_logs，本工具仅关注异常，输出更清晰�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "console_listener.js",
        "--port", str(params.auto_port),
        "--duration", str(params.duration),
        "--type", "exception",
        timeout=params.duration + 15,
    )

    if not result.get("success") and "error" in result:
        return f"�?连接失败: {result['error']}\n\n💡 提示: 先调�?wechat_auto 开启自动化端口，并确保 scripts/ 目录下已安装依赖�?

    exceptions = result.get("exceptions", [])
    parts = [
        f"🚨 运行时异常监听结�?
        f" | 端口: {result.get('port', params.auto_port)}"
        f" | 持续: {result.get('duration', params.duration)}�?,
    ]

    if not exceptions:
        parts.append("\n�?未检测到运行时异�?)
    else:
        parts.append(f"\n共发�?{len(exceptions)} 个异�?\n")
        for i, exc in enumerate(exceptions, 1):
            parts.append(f"━━�?异常 #{i} [{exc.get('time', '')}] ━━�?)
            parts.append(f"�?消息: {exc.get('message', '（无消息�?)}")
            stack = exc.get("stack", "")
            if stack:
                parts.append("📍 调用�?")
                for line in stack.strip().split("\n"):
                    parts.append(f"   {line.strip()}")
            parts.append("")

    return "\n".join(parts)


@_tool(
    name="wechat_navigate_and_capture",
    annotations={
        "title": "跳转页面并捕获日�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_navigate_and_capture(params: NavigateCaptureInput) -> str:
    """跳转到指定页面，等待指定时间，捕获该时间窗口内的所�?console 日志�?JS 异常�?

    特别适用于：
    - 页面初始化时的日志检查（onLoad、onShow 生命周期�?
    - 验证某个页面是否有运行时错误
    - 自动化测试中的页面级别验�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    # 确保页面路径�?/ 开�?
    page = params.page_path
    if not page.startswith("/"):
        page = "/" + page

    wait_seconds = params.wait_ms / 1000
    total_timeout = int(wait_seconds) + 20

    result = await _run_node_script(
        "navigate_capture.js",
        "--port", str(params.auto_port),
        "--page", page,
        "--wait", str(params.wait_ms),
        timeout=total_timeout,
    )

    if not result.get("success") and "error" in result and not result.get("console_logs") and not result.get("exceptions"):
        return f"�?连接失败: {result['error']}\n\n💡 提示: 先调�?wechat_auto 开启自动化端口�?

    parts = [f"🔀 页面跳转捕获 | 目标页面: {page} | 等待: {params.wait_ms}ms"]

    # 当前页面信息
    current_page = result.get("current_page")
    if current_page:
        parts.append(f"\n📍 当前页面: {current_page.get('path', '未知')}")
        q = current_page.get("query", {})
        if q:
            parts.append(f"   参数: {json.dumps(q, ensure_ascii=False)}")
    else:
        parts.append("\n📍 页面信息: 无法获取")

    if not result.get("success"):
        parts.append(f"\n⚠️ 跳转时出现错�? {result.get('error', '未知错误')}")

    # 日志和异�?
    _append_logs_and_exceptions(parts, result)

    return "\n".join(parts)


@_tool(
    name="wechat_run_automation_script",
    annotations={
        "title": "执行自动化测试脚�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_run_automation_script(params: RunScriptInput) -> str:
    """执行自定�?JS 自动化测试脚本，并捕获执行期间的所有日志和异常�?

    脚本格式（Node.js CommonJS 模块）：
    ```js
    module.exports = async function(miniProgram) {
      // miniProgram �?miniprogram-automator SDK �?MiniProgram 实例
      const page = await miniProgram.navigateTo('/pages/index/index');
      await page.waitFor(1000);
      const el = await page.$('.my-button');
      if (el) await el.tap();
      return { tapped: true };
    };
    ```

    可用 API�?
    - miniProgram.navigateTo(path) / reLaunch(path) / currentPage()
    - page.$('.selector') / page.$$('.selector')
    - element.tap() / element.input('text') / element.attribute('name')
    - page.waitFor(ms �?selector字符�?
    - miniProgram.systemInfo() �?获取系统信息

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    # 将脚本内容写入临时文�?
    tmp_dir = tempfile.gettempdir()
    tmp_script_path = os.path.join(tmp_dir, "wechat_mcp_auto_script.js")
    try:
        with open(tmp_script_path, "w", encoding="utf-8") as f:
            f.write(params.script_content)
    except Exception as e:
        return f"�?写入临时脚本文件失败: {e}"

    result = await _run_node_script(
        "run_test_script.js",
        "--port", str(params.auto_port),
        "--script", tmp_script_path,
        "--timeout", str(params.timeout),
        timeout=params.timeout + 20,
    )

    parts = [f"🤖 自动化脚本执�?| 端口: {params.auto_port} | 超时: {params.timeout}�?]

    if not result.get("success") and "error" in result and not result.get("console_logs"):
        return f"�?执行失败: {result['error']}\n\n💡 提示: 先调�?wechat_auto 开启自动化端口，并确保 scripts/ 目录下已安装依赖�?

    # 脚本执行结果
    if result.get("success"):
        parts.append("\n�?脚本执行成功")
        if result.get("script_result") is not None:
            parts.append(f"📤 返回�? {json.dumps(result['script_result'], indent=2, ensure_ascii=False)}")
    else:
        parts.append("\n�?脚本执行失败")
        script_error = result.get("script_error")
        if script_error:
            parts.append(f"🔴 错误: {script_error.get('message', '')}")
            stack = script_error.get("stack", "")
            if stack:
                parts.append("📍 调用�?")
                for line in stack.strip().split("\n")[:8]:
                    parts.append(f"   {line.strip()}")

    # 日志和异�?
    _append_logs_and_exceptions(parts, result)

    # 清理临时文件
    try:
        os.remove(tmp_script_path)
    except Exception:
        pass

    return "\n".join(parts)


@_tool(
    name="wechat_get_system_info",
    annotations={
        "title": "获取小程序运行时系统信息",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_system_info(params: SystemInfoInput) -> str:
    """通过自动化接口获取小程序运行时的系统信息�?

    返回信息包括�?
    - 基础库版本（SDKVersion�?
    - 运行平台（platform�?
    - 系统版本（system�?
    - 品牌和型号（brand / model�?
    - 屏幕尺寸（screenWidth / screenHeight�?
    - 语言和字体大小等

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    # 生成一个内联脚本来获取 systemInfo
    system_info_script = """module.exports = async function(miniProgram) {
  const info = await miniProgram.systemInfo();
  return info;
};"""
    tmp_dir = tempfile.gettempdir()
    tmp_script_path = os.path.join(tmp_dir, "wechat_mcp_sysinfo.js")
    try:
        with open(tmp_script_path, "w", encoding="utf-8") as f:
            f.write(system_info_script)
    except Exception as e:
        return f"�?写入临时脚本失败: {e}"

    result = await _run_node_script(
        "run_test_script.js",
        "--port", str(params.auto_port),
        "--script", tmp_script_path,
        "--timeout", "15",
        timeout=30,
    )

    try:
        os.remove(tmp_script_path)
    except Exception:
        pass

    if not result.get("success") and "error" in result:
        return f"�?获取系统信息失败: {result['error']}\n\n💡 提示: 先调�?wechat_auto 开启自动化端口�?

    sys_info = result.get("script_result")
    if sys_info and isinstance(sys_info, dict):
        lines = ["📱 小程序运行时系统信息\n"]
        field_map = [
            ("brand",          "品牌"),
            ("model",          "型号"),
            ("platform",       "平台"),
            ("system",         "系统版本"),
            ("version",        "微信版本"),
            ("SDKVersion",     "基础库版�?),
            ("language",       "语言"),
            ("screenWidth",    "屏幕宽度"),
            ("screenHeight",   "屏幕高度"),
            ("windowWidth",    "窗口宽度"),
            ("windowHeight",   "窗口高度"),
            ("pixelRatio",     "设备像素�?),
            ("fontSizeSetting", "字体大小设置"),
            ("benchmarkLevel", "设备性能等级"),
        ]
        for key, label in field_map:
            if key in sys_info:
                lines.append(f"  {label}: {sys_info[key]}")
        # 输出完整原始数据
        lines.append(f"\n完整数据:\n{json.dumps(sys_info, indent=2, ensure_ascii=False)}")
        return "\n".join(lines)
    else:
        return (
            f"⚠️ 系统信息返回为空\n"
            f"原始结果: {json.dumps(result, indent=2, ensure_ascii=False)}"
        )


@_tool(
    name="wechat_capture_screenshot",
    annotations={
        "title": "捕获小程序界面截�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_capture_screenshot(params: ScreenshotInput) -> str:
    """实时捕获当前小程序模拟器的界面截图�?

    默认支持截取长图。将会自动滚动并拼接长页面截图�?
    必须明确指定 output_path 参数以保�?PNG 文件�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "screenshot.js",
        "--port", str(params.auto_port),
        "--output", params.output_path,
        "--overlap", str(params.overlap),
        timeout=CLI_TIMEOUT + 60,
    )

    if not result.get("success"):
        error_msg = result.get("error") or result.get("message") or "未知错误"
        # 若是结构化错误（来自 _make_error），直接透传
        if "error_code" in result:
            return json.dumps(result, ensure_ascii=False, indent=2)
        return _make_error(
            ErrorCode.UNKNOWN_ERROR,
            f"截图失败：{error_msg}",
        )

    abs_path = result.get("path", params.output_path)
    width = result.get("width", 0)
    height = result.get("height", 0)
    segments = result.get("segments", 1)
    file_size = 0
    try:
        file_size = os.path.getsize(abs_path)
    except OSError:
        pass

    return json.dumps(
        {
            "success": True,
            "path": abs_path,
            "width": width,
            "height": height,
            "segments": segments,
            "file_size": file_size,
            "message": f"�?截图成功，共 {segments} 段，已保存至 {abs_path}",
        },
        ensure_ascii=False,
        indent=2,
    )


@_tool(
    name="wechat_get_page_data",
    annotations={
        "title": "获取当前页面 Data 数据",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_page_data(params: PageDataInput) -> str:
    """读取小程序当前活跃页面的 data 模型状态（响应式数据）�?

    这对�?AI 诊断「数据绑定不生效」或「状态未更新」等问题非常有用�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "ui_debug.js",
        "--port", str(params.auto_port),
        "--action", "data"
    )

    if result.get("success"):
        page_path = result.get("path", "未知页面")
        data_json = json.dumps(result.get("data", {}), indent=2, ensure_ascii=False)
        return f"📱 当前页面: {page_path}\n📋 数据模型:\n{data_json}"
    else:
        return f"�?获取页面数据失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_get_storage",
    annotations={
        "title": "获取本地缓存 Storage",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_storage(params: StorageInput) -> str:
    """获取小程序的本地缓存数据�?

    - 如果提供 key: 返回�?key 对应的具体数据内容�?
    - 如果不提�?key: 返回当前所有已占用的缓�?key 列表及其使用空间统计�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    args = ["--port", str(params.auto_port), "--action", "storage"]
    if params.key:
        args.extend(["--key", params.key])

    result = await _run_node_script("ui_debug.js", *args)

    if result.get("success"):
        if params.key:
            val = result.get("value")
            return f"🔑 Key: {params.key}\n📄 数据内容: {json.dumps(val, indent=2, ensure_ascii=False)}"
        else:
            keys = ", ".join(result.get("keys", []))
            return (
                f"📋 Storage 信息:\n"
                f"  所�?Key: {keys or '（无�?}\n"
                f"  当前占用: {result.get('currentSize')} KB\n"
                f"  剩余上限: {result.get('limitSize')} KB"
            )
    else:
        return f"�?获取 Storage 失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_evaluate_expression",
    annotations={
        "title": "在小程序中执�?JS 表达�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_evaluate_expression(params: EvaluateInput) -> str:
    """在小程序逻辑层运行环境中直接执行一�?JS 表达式，并返回结果�?

    示例表达�?
    - 'wx.getSystemInfoSync()'
    - 'getApp().globalData'
    - '1 + 1'

    ⚠️ 请注意安全，不要执行恶意代码�?
    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "ui_debug.js",
        "--port", str(params.auto_port),
        "--action", "evaluate",
        "--code", params.expression
    )

    if result.get("success"):
        res_val = result.get("result")
        return f"�?执行成功\n📥 结果: {json.dumps(res_val, indent=2, ensure_ascii=False)}"
    else:
        return f"�?执行报错: {result.get('error', '未知错误')}"


# ============================================================
# MCP 工具 �?v4.0 自动化交�?
# ============================================================


@_tool(
    name="wechat_set_page_data",
    annotations={
        "title": "设置当前页面 Data",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_set_page_data(params: SetPageDataInput) -> str:
    """动态设置当前页面的 data（响应式数据），无需重新编译即可热更�?UI�?

    示例 data_json: '{"message": "hello", "count": 42}'

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "automation.js",
        "--port", str(params.auto_port),
        "--action", "setData",
        "--data", params.data_json
    )
    if result.get("success"):
        keys = ", ".join(result.get("updatedKeys", []))
        return f"�?页面数据已更新\n📱 页面: {result.get('path')}\n🔑 更新字段: {keys}"
    else:
        return f"�?设置失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_call_page_method",
    annotations={
        "title": "调用页面方法",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_call_page_method(params: CallPageMethodInput) -> str:
    """调用当前页面中的指定方法（如 onPullDownRefresh、自定义业务方法等）�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    args = ["--port", str(params.auto_port), "--action", "callMethod", "--method", params.method]
    if params.args_json:
        args.extend(["--args", params.args_json])
    result = await _run_node_script("automation.js", *args)
    if result.get("success"):
        ret = json.dumps(result.get("returnValue"), indent=2, ensure_ascii=False) if result.get("returnValue") is not None else "(无返回�?"
        return f"�?方法已调用\n📱 页面: {result.get('path')}\n🔧 方法: {params.method}\n📥 返回: {ret}"
    else:
        return f"�?调用失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_tap_element",
    annotations={
        "title": "点击 UI 元素",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_tap_element(params: TapElementInput) -> str:
    """通过 CSS 选择器定位页面上的元素并模拟点击（tap）�?

    示例选择�? '.submit-btn', '#login', 'button'

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "automation.js",
        "--port", str(params.auto_port),
        "--action", "tap",
        "--selector", params.selector
    )
    if result.get("success"):
        return f"�?已点击元�? {params.selector}"
    else:
        return f"�?点击失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_get_element_info",
    annotations={
        "title": "获取 UI 元素详情",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_element_info(params: ElementInfoInput) -> str:
    """获取页面元素的详细信息（文本、WXML 结构、尺寸、位置、样式）�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    args = ["--port", str(params.auto_port), "--action", "elementInfo", "--selector", params.selector]
    if params.style_prop:
        args.extend(["--prop", params.style_prop])
    result = await _run_node_script("automation.js", *args)
    if result.get("success"):
        el = result.get("element", {})
        parts = [
            f"🏷�?标签: {el.get('tagName')}",
            f"📝 文本: {el.get('text')}",
            f"📐 尺寸: {json.dumps(el.get('size'))}",
            f"📍 位置: {json.dumps(el.get('offset'))}",
        ]
        if el.get("style"):
            parts.append(f"🎨 样式: {json.dumps(el.get('style'))}")
        parts.append(f"📄 WXML:\n{el.get('wxml', '')}")
        return "\n".join(parts)
    else:
        return f"�?获取失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_input_element",
    annotations={
        "title": "输入表单内容",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_input_element(params: InputElementInput) -> str:
    """�?input �?textarea 元素输入文本内容�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "automation.js",
        "--port", str(params.auto_port),
        "--action", "input",
        "--selector", params.selector,
        "--value", params.value
    )
    if result.get("success"):
        return f"�?已输入内容\n📝 选择�? {params.selector}\n📄 输入�? {params.value}"
    else:
        return f"�?输入失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_mock_wx_method",
    annotations={
        "title": "Mock wx API 返回�?,
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_mock_wx_method(params: MockWxMethodInput) -> str:
    """覆盖 wx 对象上指定方法的调用结果（Mock）�?

    �?mock 定位、支付、弹窗等系统组件行为，无需真实调用�?
    示例: method='showModal', result_json='{"confirm": true, "cancel": false}'

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "automation.js",
        "--port", str(params.auto_port),
        "--action", "mockWx",
        "--method", params.method,
        "--result", params.result_json
    )
    if result.get("success"):
        return f"�?�?Mock: wx.{params.method}\n📦 返回�? {params.result_json}"
    else:
        return f"�?Mock 失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_call_wx_method",
    annotations={
        "title": "调用 wx API",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def wechat_call_wx_method(params: CallWxMethodInput) -> str:
    """直接调用 wx 对象上的指定方法�?

    示例: method='setNavigationBarTitle', args_json='[{"title": "新标�?}]'

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    args = ["--port", str(params.auto_port), "--action", "callWx", "--method", params.method]
    if params.args_json:
        args.extend(["--args", params.args_json])
    result = await _run_node_script("automation.js", *args)
    if result.get("success"):
        ret = json.dumps(result.get("returnValue"), indent=2, ensure_ascii=False) if result.get("returnValue") is not None else "(无返回�?"
        return f"�?wx.{params.method} 调用成功\n📥 返回: {ret}"
    else:
        return f"�?调用失败: {result.get('error', '未知错误')}"


@_tool(
    name="wechat_get_page_stack",
    annotations={
        "title": "获取页面导航�?,
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def wechat_get_page_stack(params: PageStackInput) -> str:
    """获取当前小程序的页面栈信息，包括每个页面的路径和查询参数�?

    ⚠️ 使用前提：先调用 wechat_auto 开启自动化端口�?
    """
    result = await _run_node_script(
        "automation.js",
        "--port", str(params.auto_port),
        "--action", "pageStack"
    )
    if result.get("success"):
        pages = result.get("pages", [])
        lines = [f"📚 页面栈深�? {result.get('depth', 0)}"]
        for i, p in enumerate(pages):
            query = json.dumps(p.get('query', {}), ensure_ascii=False)
            lines.append(f"  [{i}] {p.get('path')} {query if query != '{}' else ''}")
        return "\n".join(lines)
    else:
        return f"�?获取失败: {result.get('error', '未知错误')}"


# ── 私有辅助 ──────────────────────────────────────────────────────────────────

def _append_logs_and_exceptions(parts: list, result: dict) -> None:
    """�?console_logs �?exceptions 格式化后追加�?parts 列表�?""
    summary = result.get("summary", {})
    console_logs = result.get("console_logs", [])
    exceptions = result.get("exceptions", [])

    if summary:
        parts.append(
            f"\n📊 摘要: {summary.get('total_logs', 0)} 条日�?
            f" | 错误 {summary.get('errors', 0)} �?
            f" | 警告 {summary.get('warnings', 0)} �?
            f" | 异常 {summary.get('exceptions', 0)} �?
        )

    if console_logs:
        parts.append("\n📋 Console 日志:")
        for entry in console_logs:
            t = (entry.get("type") or "log").upper()
            icon = {"LOG": "📝", "WARN": "🟡", "ERROR": "🔴", "INFO": "ℹ️", "DEBUG": "🔍"}.get(t, "📝")
            args_str = ", ".join(str(a) for a in entry.get("args", []))
            parts.append(f"  {icon} [{entry.get('time', '')}] [{t}] {args_str}")
    else:
        parts.append("\n📋 Console 日志: �?)

    if exceptions:
        parts.append("\n🚨 运行时异�?")
        for i, exc in enumerate(exceptions, 1):
            parts.append(f"  ━━ 异常 #{i} [{exc.get('time', '')}] ━━")
            parts.append(f"  �?{exc.get('message', '')}")
            stack = exc.get("stack", "")
            if stack:
                for line in stack.strip().split("\n")[:6]:
                    parts.append(f"     {line.strip()}")
    else:
        parts.append("\n🚨 运行时异�? �?)


# ============================================================
# 入口
# ============================================================

def main():
    """MCP Server 启动入口"""
    # Windows 下强制 stdio 使用 UTF-8，避免 uvx 启动时 GBK 编码导致 UnicodeDecodeError
    if sys.platform == "win32":
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
        os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    # 启动前强制校验环境变�?
    missing_envs = []
    
    if "WECHAT_DEVTOOLS_CLI" not in os.environ:
        missing_envs.append("WECHAT_DEVTOOLS_CLI (例如: D:\\Tencent\\微信web开发者工具\\cli.bat)")
        
    if "WECHAT_PROJECT_PATH" not in os.environ:
        missing_envs.append("WECHAT_PROJECT_PATH (例如: D:\\Projects\\WeChat-App)")
        
    if missing_envs:
        print("�?启动失败：缺少必需的环境变量！", file=sys.stderr)
        print("在运行该 MCP Server 之前，您必须配置以下环境变量：\n", file=sys.stderr)
        for env in missing_envs:
            print(f"  - {env}", file=sys.stderr)
        print("\n请在 MCP 客户端配�?(�?cursor/mcp.json) 或系统环境变量中添加它们�?, file=sys.stderr)
        sys.exit(1)
        
    mcp.run()

if __name__ == "__main__":
    main()
