#!/usr/bin/env bash
# build_bundle.sh — 使用 @vercel/ncc 将各 Node.js 脚本打包为单文件 Bundle
# 输出目录：scripts/dist/
# 用法：cd scripts && npm install && bash build_bundle.sh

set -e

SCRIPTS=(
    "automation"
    "cdp_listener"
    "console_listener"
    "navigate_capture"
    "screenshot"
    "run_test_script"
    "ui_debug"
)

DIST_DIR="$(dirname "$0")/dist"
mkdir -p "$DIST_DIR"

NCC="$(dirname "$0")/node_modules/.bin/ncc"

for name in "${SCRIPTS[@]}"; do
    echo "📦 Bundling ${name}.js ..."
    TMP_DIR="${DIST_DIR}/${name}_tmp"
    "$NCC" build "$(dirname "$0")/${name}.js" -o "$TMP_DIR"
    mv "$TMP_DIR/index.js" "${DIST_DIR}/${name}.bundle.js"
    rm -rf "$TMP_DIR"
    echo "   ✅ ${DIST_DIR}/${name}.bundle.js"
done

echo ""
echo "🎉 All bundles built successfully in: $DIST_DIR"
