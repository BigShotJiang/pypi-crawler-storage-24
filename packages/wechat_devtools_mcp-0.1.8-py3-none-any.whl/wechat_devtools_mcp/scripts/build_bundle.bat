@echo off
REM build_bundle.bat — 使用 @vercel/ncc 将各 Node.js 脚本打包为单文件 Bundle
REM 输出目录：scripts\dist\
REM 用法：cd scripts && npm install && build_bundle.bat

setlocal enabledelayedexpansion

set SCRIPT_DIR=%~dp0
set DIST_DIR=%SCRIPT_DIR%dist
set NCC=%SCRIPT_DIR%node_modules\.bin\ncc.cmd

if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"

set SCRIPTS=automation cdp_listener console_listener navigate_capture screenshot run_test_script ui_debug

for %%s in (%SCRIPTS%) do (
    echo 📦 Bundling %%s.js ...
    set TMP_DIR=%DIST_DIR%\%%s_tmp
    call "%NCC%" build "%SCRIPT_DIR%%%s.js" -o "!TMP_DIR!"
    if errorlevel 1 (
        echo ❌ Failed to bundle %%s.js
        exit /b 1
    )
    move /y "!TMP_DIR!\index.js" "%DIST_DIR%\%%s.bundle.js"
    rmdir /s /q "!TMP_DIR!"
    echo    ✅ %DIST_DIR%\%%s.bundle.js
)

echo.
echo 🎉 All bundles built successfully in: %DIST_DIR%
endlocal
