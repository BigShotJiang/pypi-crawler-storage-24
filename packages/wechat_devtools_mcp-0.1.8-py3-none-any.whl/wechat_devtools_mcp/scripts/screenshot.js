#!/usr/bin/env node
/**
 * screenshot.js
 * 小程序截图脚本，支持多屏滚动拼接（使用 sharp 库）。
 * 若 sharp 不可用，降级为单屏截图。
 *
 * 滚动策略：
 *   1. 用 page.size().height 获取内容高度
 *   2. 若内容高度 > 窗口高度，通过模拟触摸滑动滚动页面
 *   3. 连续两张截图文件大小相同时停止（已到底部）
 *
 * 用法：
 *   node screenshot.js --port <port> --output <path> [--overlap <px>]
 *
 * 输出 JSON：
 *   {"success": true, "path": "...", "width": N, "height": N, "segments": N}
 */

'use strict';

const automator = require('miniprogram-automator');
const fs = require('fs');
const path = require('path');
const os = require('os');

function parseArgs(argv) {
    const args = { port: 9420, output: '', overlap: 50 };
    for (let i = 2; i < argv.length; i++) {
        switch (argv[i]) {
            case '--port':    args.port    = parseInt(argv[++i], 10); break;
            case '--output':  args.output  = argv[++i]; break;
            case '--overlap': args.overlap = parseInt(argv[++i], 10); break;
        }
    }
    return args;
}

function tryLoadSharp() {
    try { return require('sharp'); } catch (e) { return null; }
}

/**
 * 使用 sharp 垂直拼接多张 PNG 图片
 */
async function stitchImages(imagePaths, outputPath, overlap, sharp) {
    if (imagePaths.length === 1) {
        fs.copyFileSync(imagePaths[0], outputPath);
        try {
            const meta = await sharp(imagePaths[0]).metadata();
            return { width: meta.width || 0, height: meta.height || 0 };
        } catch (e) {
            return { width: 0, height: 0 };
        }
    }

    const metas = await Promise.all(imagePaths.map(p => sharp(p).metadata()));
    const width = metas[0].width || 375;

    let totalHeight = metas[0].height || 0;
    for (let i = 1; i < metas.length; i++) {
        const h = metas[i].height || 0;
        const cropTop = Math.min(overlap, h - 1);
        const cropHeight = h - cropTop;
        if (cropHeight > 0) totalHeight += cropHeight;
    }

    const compositeOps = [{ input: imagePaths[0], top: 0, left: 0 }];
    let yOffset = metas[0].height || 0;

    for (let i = 1; i < imagePaths.length; i++) {
        const h = metas[i].height || 0;
        const cropTop = Math.min(overlap, h - 1);
        const cropHeight = h - cropTop;
        if (cropHeight <= 0) continue;

        const cropped = await sharp(imagePaths[i])
            .extract({ left: 0, top: cropTop, width: metas[i].width || width, height: cropHeight })
            .toBuffer();

        compositeOps.push({ input: cropped, top: yOffset, left: 0 });
        yOffset += cropHeight;
    }

    await sharp({
        create: { width, height: totalHeight, channels: 3, background: { r: 255, g: 255, b: 255 } }
    })
        .composite(compositeOps)
        .png()
        .toFile(outputPath);

    return { width, height: totalHeight };
}

async function main() {
    const args = parseArgs(process.argv);
    const { port, output, overlap } = args;

    if (!output) {
        process.stdout.write(JSON.stringify({ success: false, error: '缺失 --output 参数' }));
        process.exit(0);
    }

    const outputDir = path.dirname(path.resolve(output));
    if (!fs.existsSync(outputDir)) {
        try { fs.mkdirSync(outputDir, { recursive: true }); } catch (e) { /* ignore */ }
    }

    const sharp = tryLoadSharp();
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wechat_screenshot_'));
    let miniProgram = null;

    try {
        miniProgram = await automator.connect({ wsEndpoint: `ws://localhost:${port}` });

        // 获取系统信息（窗口高度）
        let windowHeight = 667;
        let windowWidth = 375;
        try {
            const sysInfo = await miniProgram.systemInfo();
            windowHeight = sysInfo.windowHeight || 667;
            windowWidth = sysInfo.windowWidth || 375;
        } catch (e) { /* ignore */ }

        const page = await miniProgram.currentPage();

        // 获取页面内容高度（page.size() 返回实际渲染高度）
        let contentHeight = windowHeight;
        try {
            const sz = await page.size();
            if (sz && sz.height > 0) contentHeight = sz.height;
        } catch (e) { /* ignore */ }

        const absOutput = path.resolve(output);
        const segmentPaths = [];

        // 截第一屏
        const seg0Path = path.join(tmpDir, 'seg_0.png');
        await miniProgram.screenshot({ path: seg0Path });
        if (fs.existsSync(seg0Path)) segmentPaths.push(seg0Path);

        const needsScroll = sharp && contentHeight > windowHeight * 1.05;

        if (needsScroll) {
            // 多屏滚动：使用 miniProgram.pageScrollTo(scrollTop) 精确滚动
            const effectiveStep = Math.max(1, windowHeight - overlap);
            const estimatedSegments = Math.ceil(contentHeight / effectiveStep);
            const maxSegments = Math.min(estimatedSegments, 20);

            for (let i = 1; i < maxSegments; i++) {
                const scrollY = i * effectiveStep;

                try {
                    await miniProgram.pageScrollTo(scrollY);
                    await new Promise(r => setTimeout(r, 300));
                } catch (e) {
                    break; // 滚动失败，停止
                }

                const segPath = path.join(tmpDir, `seg_${i}.png`);
                await miniProgram.screenshot({ path: segPath });
                if (!fs.existsSync(segPath)) break;

                // 检测是否已到底部（截图与上一张完全相同）
                const prevSize = fs.statSync(segmentPaths[segmentPaths.length - 1]).size;
                const currSize = fs.statSync(segPath).size;
                if (currSize === prevSize) {
                    fs.unlinkSync(segPath);
                    break;
                }

                segmentPaths.push(segPath);
            }

            // 滚动回顶部
            try {
                await miniProgram.pageScrollTo(0);
                await new Promise(r => setTimeout(r, 200));
            } catch (e) { /* ignore */ }
        }

        if (segmentPaths.length === 0) {
            throw new Error('截图失败：未获取到任何分段图片');
        }

        let finalWidth = 0, finalHeight = 0;

        if (sharp && segmentPaths.length > 1) {
            const dims = await stitchImages(segmentPaths, absOutput, overlap, sharp);
            finalWidth = dims.width;
            finalHeight = dims.height;
        } else {
            fs.copyFileSync(segmentPaths[0], absOutput);
            if (sharp) {
                try {
                    const meta = await sharp(absOutput).metadata();
                    finalWidth = meta.width || 0;
                    finalHeight = meta.height || 0;
                } catch (e) { /* ignore */ }
            }
        }

        process.stdout.write(JSON.stringify({
            success: true,
            path: absOutput,
            width: finalWidth,
            height: finalHeight,
            segments: segmentPaths.length,
        }));
        process.exit(0);

    } catch (err) {
        process.stdout.write(JSON.stringify({ success: false, error: err.message || String(err) }));
        process.exit(0);
    } finally {
        try {
            const files = fs.readdirSync(tmpDir);
            for (const f of files) fs.unlinkSync(path.join(tmpDir, f));
            fs.rmdirSync(tmpDir);
        } catch (e) { /* ignore */ }
    }
}

main();
