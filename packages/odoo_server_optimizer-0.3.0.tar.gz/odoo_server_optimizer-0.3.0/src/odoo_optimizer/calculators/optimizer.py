"""Optimizer-Calculator: Optimale Konfigurationswerte berechnen."""

from ..config.defaults import (
    DEFAULT_LIMIT_MEMORY_HARD,
    DEFAULT_LIMIT_MEMORY_SOFT,
    DEFAULT_LIMIT_TIME_CPU,
    DEFAULT_LIMIT_TIME_REAL,
    DEFAULT_LIMIT_TIME_REAL_CRON,
    DEFAULT_MAX_CRON_THREADS,
)
from .base import HardwareInfo, OptimizationPlan, PostgresInfo


class OptimizerCalculator:
    """Kombiniert Hardware- und PostgreSQL-Infos zu einem optimalen Config-Set.

    Nimmt keine Connection entgegen — arbeitet nur mit bereits
    berechneten HardwareInfo und PostgresInfo Objekten.
    """

    calculator_id = "optimizer"
    title = "Gesamtoptimierung"

    def __init__(
        self, hardware: HardwareInfo, postgres: PostgresInfo
    ) -> None:
        self.hardware = hardware
        self.postgres = postgres

    def calculate(self) -> OptimizationPlan:
        """Optimale Konfigurationswerte berechnen."""
        memory_soft, memory_hard = self._calculate_memory_limits()

        changes: dict[str, dict[str, object]] = {
            "workers": {
                "soll": self.hardware.calculated_workers,
                "grund": (
                    f"{self.hardware.cpu_cores} CPU-Kerne × 2 + 1 = "
                    f"{self.hardware.calculated_workers}"
                ),
            },
            "max_cron_threads": {
                "soll": DEFAULT_MAX_CRON_THREADS,
                "grund": "1 Cron-Thread für Einzelunternehmen",
            },
            "db_maxconn": {
                "soll": self.postgres.safe_db_maxconn,
                "grund": (
                    f"{self.postgres.max_connections} max_connections / "
                    f"{self.hardware.total_processes} Prozesse"
                ),
            },
            "limit_time_cpu": {
                "soll": DEFAULT_LIMIT_TIME_CPU,
                "grund": "10 Min — Standard für Odoo Enterprise",
            },
            "limit_time_real": {
                "soll": DEFAULT_LIMIT_TIME_REAL,
                "grund": "20 Min — 2× CPU-Limit",
            },
            "limit_memory_soft": {
                "soll": memory_soft,
                "grund": (
                    f"80% von {self.hardware.ram_gb} GB / "
                    f"{self.hardware.total_processes} Prozesse"
                ),
            },
            "limit_memory_hard": {
                "soll": memory_hard,
                "grund": "120% des Soft-Limits",
            },
            "http_interface": {
                "soll": "127.0.0.1",
                "grund": "Nginx-Proxy — Odoo nur auf localhost",
            },
        }

        return OptimizationPlan(
            workers=self.hardware.calculated_workers,
            max_cron_threads=DEFAULT_MAX_CRON_THREADS,
            db_maxconn=self.postgres.safe_db_maxconn,
            limit_time_cpu=DEFAULT_LIMIT_TIME_CPU,
            limit_time_real=DEFAULT_LIMIT_TIME_REAL,
            limit_time_real_cron=DEFAULT_LIMIT_TIME_REAL_CRON,
            limit_memory_soft=memory_soft,
            limit_memory_hard=memory_hard,
            http_interface="127.0.0.1",
            changes=changes,
            needs_restart=True,
        )

    def _calculate_memory_limits(self) -> tuple[int, int]:
        """Memory-Limits basierend auf RAM und Prozessanzahl berechnen."""
        if self.hardware.ram_bytes == 0:
            return DEFAULT_LIMIT_MEMORY_SOFT, DEFAULT_LIMIT_MEMORY_HARD

        # 80% des fairen RAM-Anteils pro Prozess
        fair_share = self.hardware.ram_bytes // self.hardware.total_processes
        soft = int(fair_share * 0.8)
        hard = int(soft * 1.2)

        return soft, hard
