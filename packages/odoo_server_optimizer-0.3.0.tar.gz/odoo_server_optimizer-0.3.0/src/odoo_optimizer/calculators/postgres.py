"""PostgreSQL-Calculator: Verbindungslimits auslesen."""

from ..config.defaults import DEFAULT_DB_MAXCONN, DEFAULT_PG_MAX_CONNECTIONS
from ..connection.base import AbstractConnection
from .base import BaseCalculator, PostgresInfo


class PostgresCalculator(BaseCalculator):
    """Liest PostgreSQL max_connections und Version, berechnet sicheren db_maxconn.

    Formel: safe_db_maxconn = min(DEFAULT_DB_MAXCONN, max_connections // total_processes)
    """

    calculator_id = "postgres"
    title = "PostgreSQL-Verbindungslimits"

    def __init__(self, conn: AbstractConnection, total_processes: int) -> None:
        super().__init__(conn)
        self.total_processes = total_processes

    def calculate(self) -> PostgresInfo:
        """PostgreSQL-Werte auslesen und sicheren db_maxconn berechnen."""
        max_connections = self._get_max_connections()
        version = self._get_version()

        # Sicherer db_maxconn: max_connections / Gesamtprozesse, min 2
        calculated = max_connections // self.total_processes if self.total_processes > 0 else 8
        safe_db_maxconn = min(DEFAULT_DB_MAXCONN, max(2, calculated))

        return PostgresInfo(
            max_connections=max_connections,
            version=version,
            safe_db_maxconn=safe_db_maxconn,
        )

    def _get_max_connections(self) -> int:
        """PostgreSQL max_connections auslesen."""
        result = self.conn.run(
            "sudo -u postgres psql -t -c 'SHOW max_connections'"
        )
        if result.success and result.stdout.strip().isdigit():
            return int(result.stdout.strip())
        return DEFAULT_PG_MAX_CONNECTIONS

    def _get_version(self) -> str:
        """PostgreSQL-Version auslesen."""
        result = self.conn.run(
            "sudo -u postgres psql -t -c 'SELECT version()'"
        )
        if result.success and result.stdout.strip():
            # "PostgreSQL 16.2 on x86_64..." → "16.2"
            parts = result.stdout.strip().split()
            if len(parts) >= 2:
                return parts[1]
        return "unbekannt"
