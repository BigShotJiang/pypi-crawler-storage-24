"""Hardware-Calculator: CPU und RAM des Ziel-Servers auslesen."""

from ..config.defaults import (
    DEFAULT_MAX_CRON_THREADS,
    WORKER_FORMULA_MULTIPLIER,
    WORKER_FORMULA_OFFSET,
)
from .base import BaseCalculator, HardwareInfo


class HardwareCalculator(BaseCalculator):
    """Liest CPU-Cores und RAM aus, berechnet optimale Worker-Anzahl.

    Formel: HTTP-Workers = (CPU_Cores × 2) + 1
    Gesamtprozesse = Workers + Cron + Gevent + Master
    """

    calculator_id = "hardware"
    title = "Hardware-Erkennung (CPU/RAM)"

    def calculate(self) -> HardwareInfo:
        """CPU-Cores und RAM auslesen, Worker-Anzahl berechnen."""
        cpu_cores = self._get_cpu_cores()
        ram_bytes = self._get_ram_bytes()

        calculated_workers = (
            cpu_cores * WORKER_FORMULA_MULTIPLIER + WORKER_FORMULA_OFFSET
        )

        # Master + HTTP-Workers + Cron + Gevent
        total_processes = 1 + calculated_workers + DEFAULT_MAX_CRON_THREADS + 1

        return HardwareInfo(
            cpu_cores=cpu_cores,
            ram_bytes=ram_bytes,
            calculated_workers=calculated_workers,
            total_processes=total_processes,
        )

    def _get_cpu_cores(self) -> int:
        """CPU-Kerne über nproc auslesen."""
        result = self.conn.run("nproc")
        if result.success and result.stdout.strip().isdigit():
            return int(result.stdout.strip())
        # Fallback: /proc/cpuinfo
        result = self.conn.run("grep -c '^processor' /proc/cpuinfo")
        if result.success and result.stdout.strip().isdigit():
            return int(result.stdout.strip())
        return 1  # Minimaler Fallback

    def _get_ram_bytes(self) -> int:
        """RAM in Bytes über free auslesen."""
        result = self.conn.run("free -b | grep Mem | awk '{print $2}'")
        if result.success and result.stdout.strip().isdigit():
            return int(result.stdout.strip())
        return 0
