"""Basis-Klassen und Dataclasses für alle Calculators."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from ..connection.base import AbstractConnection


@dataclass
class HardwareInfo:
    """Hardware-Informationen des Ziel-Servers.

    Attributes:
        cpu_cores: Anzahl der CPU-Kerne (z.B. 4 für CCX23)
        ram_bytes: Gesamter RAM in Bytes
        calculated_workers: Optimale HTTP-Worker-Anzahl (CPU × 2 + 1)
        total_processes: Gesamtprozesse (Workers + Cron + Gevent + Master)
    """

    cpu_cores: int
    ram_bytes: int
    calculated_workers: int
    total_processes: int

    @property
    def ram_gb(self) -> float:
        """RAM in GB (gerundet auf 1 Dezimalstelle)."""
        return round(self.ram_bytes / (1024**3), 1)


@dataclass
class PostgresInfo:
    """PostgreSQL-Verbindungsinformationen.

    Attributes:
        max_connections: PostgreSQL max_connections Einstellung
        version: PostgreSQL-Version (z.B. "16.2")
        safe_db_maxconn: Sicherer db_maxconn-Wert für Odoo
    """

    max_connections: int
    version: str
    safe_db_maxconn: int


@dataclass
class OptimizationPlan:
    """Optimale Konfigurationswerte für odoo.conf.

    Enthält alle berechneten Werte und Begründungen.
    Wird vom plan-Command angezeigt und vom apply-Command umgesetzt.
    """

    workers: int
    max_cron_threads: int
    db_maxconn: int
    limit_time_cpu: int
    limit_time_real: int
    limit_time_real_cron: int
    limit_memory_soft: int
    limit_memory_hard: int
    http_interface: str
    changes: dict[str, dict[str, Any]] = field(default_factory=dict)
    needs_restart: bool = True


class BaseCalculator(ABC):
    """Abstrakte Basisklasse für alle Calculators.

    Calculators berechnen optimale Werte basierend auf
    Server-Hardware und aktueller Konfiguration.
    """

    calculator_id: str
    title: str

    def __init__(self, conn: AbstractConnection) -> None:
        self.conn = conn

    @abstractmethod
    def calculate(self) -> HardwareInfo | PostgresInfo:
        """Berechnung durchführen und Ergebnis zurückgeben."""
        ...
