"""Console-Reporter – Rich-formatierte Terminal-Ausgabe."""

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from ..checks.base import CheckResult, Severity, Status

console = Console()


def display_results(results: list[CheckResult], server_name: str = "lokal") -> None:
    """Alle Check-Ergebnisse als formatierte Tabelle anzeigen."""
    console.print()
    console.print(Panel(
        f"[bold]Odoo Server Diagnose[/bold] · Server: [cyan]{server_name}[/cyan]",
        box=box.DOUBLE_EDGE,
    ))
    console.print()

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold")
    table.add_column("#", style="dim", width=4)
    table.add_column("Check", min_width=35)
    table.add_column("Status", width=8, justify="center")
    table.add_column("Schwere", width=10, justify="center")
    table.add_column("Meldung", min_width=30)

    for i, result in enumerate(results, 1):
        status_text = _status_display(result.status)
        severity_text = _severity_display(result.severity, result.status)
        table.add_row(
            str(i),
            result.title,
            status_text,
            severity_text,
            result.message,
        )

    console.print(table)
    _print_summary(results)


def _status_display(status: Status) -> Text:
    colors = {
        Status.PASS: ("✅ OK", "green"),
        Status.FAIL: ("❌ FAIL", "red"),
        Status.SKIP: ("⏭ SKIP", "yellow"),
        Status.ERROR: ("💥 ERR", "magenta"),
    }
    text, color = colors[status]
    return Text(text, style=color)


def _severity_display(severity: Severity, status: Status) -> Text:
    if status == Status.PASS:
        return Text("–", style="dim")
    colors = {
        Severity.CRITICAL: ("🔴 Krit.", "red bold"),
        Severity.WARNING: ("🟡 Warn.", "yellow"),
        Severity.INFO: ("ℹ Info", "blue"),
    }
    text, color = colors[severity]
    return Text(text, style=color)


def _print_summary(results: list[CheckResult]) -> None:
    fails = [r for r in results if r.status == Status.FAIL]
    critical = [r for r in fails if r.severity == Severity.CRITICAL]
    warnings = [r for r in fails if r.severity == Severity.WARNING]
    passed = [r for r in results if r.status == Status.PASS]

    console.print()
    console.print(f"  Gesamt: {len(results)} Checks · "
                  f"[green]{len(passed)} OK[/green] · "
                  f"[red]{len(critical)} Kritisch[/red] · "
                  f"[yellow]{len(warnings)} Warnung[/yellow]")

    if fails:
        fixable = [r for r in fails if r.fix_available]
        console.print(f"\n  [bold]→ {len(fixable)} Fixes verfügbar.[/bold] "
                      f"Führe [cyan]odoo-optimizer plan[/cyan] aus für Details.\n")
