"""Markdown-Reporter – generiert strukturierte Diagnose-Berichte als Markdown."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from ..checks.base import CheckResult, Severity, Status

# Icon-Mappings
_STATUS_ICONS: dict[Status, str] = {
    Status.PASS: "✅",
    Status.FAIL: "❌",
    Status.SKIP: "⏭️",
    Status.ERROR: "💥",
}

_SEVERITY_ICONS: dict[Severity, str] = {
    Severity.CRITICAL: "🔴",
    Severity.WARNING: "🟡",
    Severity.INFO: "🔵",
}


def generate_markdown(
    results: list[CheckResult],
    server_name: str = "lokal",
    title: str = "Odoo Server Diagnose",
) -> str:
    """Markdown-Bericht aus CheckResults generieren.

    Args:
        results: Liste der Check-Ergebnisse
        server_name: Name/Hostname des analysierten Servers
        title: Überschrift des Berichts

    Returns:
        Vollständiger Markdown-Bericht als String
    """
    now = datetime.now(ZoneInfo("Europe/Vienna")).strftime("%Y-%m-%d %H:%M Uhr (Vienna)")

    sections: list[str] = []

    # Header
    sections.append(f"# {title}")
    sections.append("")
    sections.append(f"**Server:** {server_name}  ")
    sections.append(f"**Erstellt:** {now}  ")
    sections.append("")

    # Zusammenfassung
    sections.append(_build_summary(results))
    sections.append("")

    # Detail-Tabelle
    sections.append("## Ergebnisse")
    sections.append("")
    sections.append("| # | Status | Schwere | Check | Meldung |")
    sections.append("|---|--------|---------|-------|---------|")
    for i, result in enumerate(results, 1):
        status_icon = _STATUS_ICONS.get(result.status, "❓")
        severity_icon = _SEVERITY_ICONS.get(result.severity, "")
        severity_col = severity_icon if result.status == Status.FAIL else "–"
        # Pipe-Zeichen in Meldungen escapen
        message = result.message.replace("|", "\\|")
        sections.append(
            f"| {i} | {status_icon} | {severity_col} | {result.title} | {message} |"
        )
    sections.append("")

    # Details zu fehlgeschlagenen Checks
    fails = [r for r in results if r.status == Status.FAIL]
    if fails:
        sections.append("## Details zu Befunden")
        sections.append("")
        for result in fails:
            severity_icon = _SEVERITY_ICONS.get(result.severity, "")
            sections.append(f"### {severity_icon} {result.title}")
            sections.append("")
            sections.append(f"**Meldung:** {result.message}  ")
            if result.details:
                for key, value in result.details.items():
                    sections.append(f"**{key}:** {value}  ")
            if result.fix_available:
                sections.append("**Fix verfügbar:** Ja  ")
            sections.append("")

    # Footer
    sections.append("---")
    sections.append(f"*Generiert mit odoo-optimizer · {now}*")
    sections.append("")

    return "\n".join(sections)


def _build_summary(results: list[CheckResult]) -> str:
    """Zusammenfassungs-Abschnitt generieren."""
    total = len(results)
    passed = sum(1 for r in results if r.status == Status.PASS)
    failed = sum(1 for r in results if r.status == Status.FAIL)
    skipped = sum(1 for r in results if r.status == Status.SKIP)
    errors = sum(1 for r in results if r.status == Status.ERROR)

    critical = sum(
        1 for r in results if r.status == Status.FAIL and r.severity == Severity.CRITICAL
    )
    warnings = sum(
        1 for r in results if r.status == Status.FAIL and r.severity == Severity.WARNING
    )

    lines = [
        "## Zusammenfassung",
        "",
        "| Gesamt | ✅ Bestanden | ❌ Fehlgeschlagen | 🔴 Kritisch | 🟡 Warnung |",
        "|--------|-------------|-------------------|-------------|------------|",
        f"| {total} | {passed} | {failed} | {critical} | {warnings} |",
    ]

    if skipped:
        lines.append(f"\n⏭️ {skipped} Check(s) übersprungen")
    if errors:
        lines.append(f"\n💥 {errors} Check(s) mit Fehler")

    if failed and any(r.fix_available for r in results if r.status == Status.FAIL):
        fixable = sum(1 for r in results if r.needs_fix)
        lines.append(
            f"\n**→ {fixable} Fix(es) verfügbar.** "
            "Führe `odoo-optimizer plan` aus für Details."
        )

    return "\n".join(lines)


def save_markdown(
    results: list[CheckResult],
    output_path: str | Path,
    server_name: str = "lokal",
    title: str = "Odoo Server Diagnose",
) -> Path:
    """Markdown-Bericht generieren und als Datei speichern.

    Args:
        results: Liste der Check-Ergebnisse
        output_path: Zielpfad für die Markdown-Datei
        server_name: Name/Hostname des Servers
        title: Überschrift des Berichts

    Returns:
        Pfad zur gespeicherten Datei
    """
    path = Path(output_path)
    content = generate_markdown(results, server_name=server_name, title=title)
    path.write_text(content, encoding="utf-8")
    return path
