"""Plan-Reporter – Rich-formatierte Plan-Anzeige."""

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ..calculators.base import HardwareInfo, OptimizationPlan, PostgresInfo
from ..fixers.base import FixPlan

console = Console()


def display_plan(
    hardware: HardwareInfo,
    postgres: PostgresInfo,
    optimization: OptimizationPlan,
    fix_plans: list[FixPlan],
    server_name: str = "lokal",
) -> None:
    """Gesamten Optimierungsplan anzeigen."""
    console.print()
    console.print(Panel(
        f"[bold]Optimierungsplan[/bold] · Server: [cyan]{server_name}[/cyan]",
        box=box.DOUBLE_EDGE,
    ))

    _display_hardware(hardware)
    _display_postgres(postgres)
    _display_changes(optimization)
    _display_fix_plans(fix_plans)
    _display_summary(optimization, fix_plans)


def _display_hardware(hw: HardwareInfo) -> None:
    """Hardware-Infos als Panel anzeigen."""
    info = (
        f"CPU-Kerne: [bold]{hw.cpu_cores}[/bold]\n"
        f"RAM: [bold]{hw.ram_gb} GB[/bold]\n"
        f"Berechnete HTTP-Workers: [bold]{hw.calculated_workers}[/bold] "
        f"({hw.cpu_cores} × 2 + 1)\n"
        f"Gesamtprozesse: [bold]{hw.total_processes}[/bold] "
        f"(Master + Workers + Cron + Gevent)"
    )
    console.print()
    console.print(Panel(info, title="Hardware", border_style="cyan"))


def _display_postgres(pg: PostgresInfo) -> None:
    """PostgreSQL-Infos als Panel anzeigen."""
    info = (
        f"Version: [bold]{pg.version}[/bold]\n"
        f"max_connections: [bold]{pg.max_connections}[/bold]\n"
        f"Sicherer db_maxconn: [bold]{pg.safe_db_maxconn}[/bold]"
    )
    console.print(Panel(info, title="PostgreSQL", border_style="green"))


def _display_changes(plan: OptimizationPlan) -> None:
    """Änderungen-Tabelle anzeigen."""
    table = Table(
        title="Geplante Konfigurationsänderungen",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold",
    )
    table.add_column("Parameter", min_width=22)
    table.add_column("Soll-Wert", min_width=15, justify="right")
    table.add_column("Begründung", min_width=35)

    for param, info in plan.changes.items():
        table.add_row(
            param,
            str(info["soll"]),
            str(info["grund"]),
        )

    console.print()
    console.print(table)


def _display_fix_plans(fix_plans: list[FixPlan]) -> None:
    """Fixer-Pläne anzeigen."""
    active_plans = [p for p in fix_plans if p.steps]
    if not active_plans:
        return

    console.print()
    console.print("[bold]Zusätzliche Fixes:[/bold]")

    for plan in active_plans:
        console.print(f"\n  [cyan]{plan.title}[/cyan]")
        for step in plan.steps:
            console.print(f"    Datei: {step.file_path}")
            if step.backup_path:
                console.print(f"    Backup: {step.backup_path}")
            for change in step.changes:
                console.print(f"    → {change}")


def _display_summary(
    optimization: OptimizationPlan,
    fix_plans: list[FixPlan],
) -> None:
    """Zusammenfassung mit Hinweisen anzeigen."""
    needs_sudo = any(p.requires_sudo for p in fix_plans if p.steps)
    needs_restart = optimization.needs_restart or any(
        p.requires_restart for p in fix_plans if p.steps
    )
    active_fixes = sum(1 for p in fix_plans if p.steps)
    total_changes = len(optimization.changes) + active_fixes

    console.print()
    summary = f"  [bold]{total_changes} Änderungen[/bold] geplant"
    if needs_restart:
        summary += " · [yellow]Odoo-Neustart erforderlich[/yellow]"
    if needs_sudo:
        summary += " · [yellow]sudo-Rechte nötig[/yellow]"

    console.print(summary)
    console.print(
        "\n  Ausführen mit: [cyan]odoo-optimizer apply[/cyan]\n"
    )
