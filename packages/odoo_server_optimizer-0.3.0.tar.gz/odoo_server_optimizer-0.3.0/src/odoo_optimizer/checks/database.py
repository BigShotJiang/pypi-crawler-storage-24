"""Check für Befund 3: db_maxconn vs. PostgreSQL max_connections.

Befund 3: db_maxconn × Gesamtprozesse darf max_connections nicht überschreiten.
Beispiel CCX23: db_maxconn=64 × 11 Prozesse = 704 > 100 → Verbindungsfehler!
"""

from ..config.defaults import DEFAULT_DB_MAXCONN, DEFAULT_PG_MAX_CONNECTIONS, ODOO_CONF_PATH
from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class DatabaseConnectionCheck(BaseCheck):
    """Befund 3: Prüft ob db_maxconn × Prozesse < PostgreSQL max_connections.

    Problem: Odoo-Standard db_maxconn=64 ist viel zu hoch für Worker-Modus.
    Bei 11 Prozessen: 64 × 11 = 704 Verbindungen → PostgreSQL hat nur 100.
    """

    check_id = "database_connections"
    title = "Datenbank-Verbindungslimit (db_maxconn)"
    severity = Severity.CRITICAL

    def run(self, conn: AbstractConnection) -> CheckResult:
        """db_maxconn aus odoo.conf und max_connections aus PostgreSQL prüfen."""
        # db_maxconn aus odoo.conf lesen
        maxconn_result = conn.run(f"grep -E '^db_maxconn' {ODOO_CONF_PATH}")
        if not maxconn_result.success or not maxconn_result.stdout.strip():
            return self._skip("db_maxconn nicht in odoo.conf gefunden")

        db_maxconn = self._parse_config_value(maxconn_result.stdout)

        # PostgreSQL max_connections auslesen
        pg_result = conn.run("sudo -u postgres psql -t -c 'SHOW max_connections'")
        if pg_result.success and pg_result.stdout.strip():
            pg_max = int(pg_result.stdout.strip())
        else:
            pg_max = DEFAULT_PG_MAX_CONNECTIONS

        # Odoo-Prozesse zählen
        ps_result = conn.run("ps aux | grep '[o]doo' | wc -l")
        process_count = int(ps_result.stdout.strip()) if ps_result.success else 11

        total_connections = db_maxconn * process_count

        if total_connections >= pg_max:
            return self._fail(
                message=(
                    f"db_maxconn={db_maxconn} × {process_count} Prozesse = "
                    f"{total_connections} ≥ {pg_max} (max_connections)"
                ),
                details={
                    "ist": f"db_maxconn={db_maxconn} (total: {total_connections})",
                    "soll": (
                        f"db_maxconn={DEFAULT_DB_MAXCONN} "
                        f"(total: {DEFAULT_DB_MAXCONN * process_count})"
                    ),
                    "befund": "Befund 3 aus Worker-Analyse v1.0.0",
                    "pg_max_connections": pg_max,
                    "fix": f"db_maxconn = {DEFAULT_DB_MAXCONN} in {ODOO_CONF_PATH}",
                },
            )

        return self._pass(
            message=f"db_maxconn={db_maxconn} OK ({total_connections} < {pg_max})",
            details={
                "db_maxconn": db_maxconn,
                "prozesse": process_count,
                "total": total_connections,
                "pg_max_connections": pg_max,
            },
        )

    def _parse_config_value(self, line: str) -> int:
        """Wert aus 'parameter = value' extrahieren."""
        return int(line.split("=")[1].strip())
