"""Check für Befund 5: max_cron_threads prüfen.

Befund 5: max_cron_threads sollte 1 sein (für Einzelunternehmen).
Zu viel → verschwendet Worker-Slots.
0 → Cron-Jobs werden nicht ausgeführt.
"""

from ..config.defaults import DEFAULT_MAX_CRON_THREADS, ODOO_CONF_PATH
from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class CronThreadsCheck(BaseCheck):
    """Befund 5: Prüft ob max_cron_threads korrekt konfiguriert ist.

    Für Einzelunternehmen reicht 1 Cron-Thread.
    Mehr als 2 verschwendet Worker-Slots.
    0 bedeutet: keine Cron-Jobs werden ausgeführt.
    """

    check_id = "cron_threads"
    title = "Cron-Threads (max_cron_threads)"
    severity = Severity.WARNING

    def run(self, conn: AbstractConnection) -> CheckResult:
        """max_cron_threads aus odoo.conf prüfen."""
        result = conn.run(f"grep -E '^max_cron_threads' {ODOO_CONF_PATH}")

        if not result.stdout.strip():
            return self._skip("max_cron_threads nicht in odoo.conf gefunden")

        cron_threads = int(result.stdout.split("=")[1].strip())

        if cron_threads == 0:
            return self._fail(
                message="max_cron_threads=0 – Cron-Jobs werden nicht ausgeführt!",
                details={
                    "ist": cron_threads,
                    "soll": DEFAULT_MAX_CRON_THREADS,
                    "befund": "Befund 5 aus Worker-Analyse v1.0.0",
                    "auswirkung": "Geplante Aktionen (E-Mails, Berichte) laufen nicht",
                    "fix": f"max_cron_threads = {DEFAULT_MAX_CRON_THREADS}",
                },
            )

        if cron_threads > DEFAULT_MAX_CRON_THREADS:
            return self._fail(
                message=f"max_cron_threads={cron_threads} – verschwendet Worker-Slots",
                details={
                    "ist": cron_threads,
                    "soll": DEFAULT_MAX_CRON_THREADS,
                    "befund": "Befund 5 aus Worker-Analyse v1.0.0",
                    "auswirkung": (
                        f"{cron_threads - DEFAULT_MAX_CRON_THREADS} "
                        "Worker-Slot(s) für Cron statt HTTP"
                    ),
                    "fix": f"max_cron_threads = {DEFAULT_MAX_CRON_THREADS}",
                },
            )

        return self._pass(
            message=f"max_cron_threads={cron_threads} – optimal",
            details={"max_cron_threads": cron_threads},
        )
