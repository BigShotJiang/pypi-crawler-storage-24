"""Check-Registry – alle Checks zentral registriert."""

from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult
from .config_values import ConfigValuesCheck
from .cron import CronThreadsCheck
from .database import DatabaseConnectionCheck
from .deprecated import DeprecatedParamsCheck
from .system import HttpInterfaceCheck, SystemDependenciesCheck
from .timeouts import TimeoutCheck
from .workers import ConfigFileCheck, WorkersModeCheck

# Alle Checks in Ausführungs-Reihenfolge (kritische zuerst)
ALL_CHECKS: list[type[BaseCheck]] = [
    WorkersModeCheck,          # Befund 1: Workers aktiv?
    ConfigFileCheck,           # Befund 2: Richtige Config-Datei?
    DatabaseConnectionCheck,   # Befund 3: db_maxconn × Prozesse < max_connections?
    TimeoutCheck,              # Befund 4: Timeout-Werte sinnvoll?
    CronThreadsCheck,          # Befund 5: max_cron_threads = 1?
    DeprecatedParamsCheck,     # Befund 6: Veraltete Parameter?
    ConfigValuesCheck,         # Befund 7+8: db_host, addons_path korrekt?
    SystemDependenciesCheck,   # Befund 9: pdfminer.six installiert?
    HttpInterfaceCheck,        # Befund 10: http_interface = 127.0.0.1?
]


def run_all_checks(conn: AbstractConnection) -> list[CheckResult]:
    """Alle registrierten Checks ausführen.

    Args:
        conn: Verbindung zum Ziel-Server

    Returns:
        Liste aller CheckResults, sortiert nach Schweregrad
    """
    results = []
    for check_class in ALL_CHECKS:
        check = check_class()
        try:
            result = check.run(conn)
            results.append(result)
        except Exception as e:
            from .base import CheckResult, Status
            results.append(CheckResult(
                check_id=check.check_id,
                title=check.title,
                severity=check.severity,
                status=Status.ERROR,
                message=f"Check-Fehler: {e}",
            ))
    return results
