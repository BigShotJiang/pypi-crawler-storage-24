"""Checks für Befund 7+8: Fehlkonfigurierte Werte erkennen.

Befund 7: db_host = False → sollte Unix-Socket oder IP sein
Befund 8: addons_path fehlt oder ungültig
"""

from ..config.defaults import ODOO_CONF_PATH
from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class ConfigValuesCheck(BaseCheck):
    """Befund 7+8: Prüft ob Konfigurations-Werte korrekt gesetzt sind.

    - db_host = False → problematisch, sollte /var/run/postgresql oder IP sein
    - addons_path muss gesetzt sein und auf existierende Verzeichnisse zeigen
    """

    check_id = "config_values"
    title = "Konfigurationswerte (db_host, addons_path)"
    severity = Severity.WARNING

    def run(self, conn: AbstractConnection) -> CheckResult:
        """Kritische Konfigurationswerte prüfen."""
        problems = []
        details: dict[str, object] = {}

        # Befund 7: db_host prüfen
        db_host_result = conn.run(f"grep -E '^db_host' {ODOO_CONF_PATH}")
        if db_host_result.stdout.strip():
            db_host_value = db_host_result.stdout.split("=")[1].strip()
            details["db_host_ist"] = db_host_value

            if db_host_value.lower() == "false":
                problems.append("db_host = False (sollte /var/run/postgresql sein)")
                details["db_host_soll"] = "/var/run/postgresql"

        # Befund 8: addons_path prüfen
        addons_result = conn.run(f"grep -E '^addons_path' {ODOO_CONF_PATH}")
        if not addons_result.stdout.strip():
            problems.append("addons_path nicht gesetzt")
            details["addons_path_ist"] = "nicht gesetzt"
        else:
            addons_value = addons_result.stdout.split("=", 1)[1].strip()
            details["addons_path_ist"] = addons_value

        if problems:
            details["befund"] = "Befund 7+8 aus Worker-Analyse v1.0.0"
            details["fix"] = "db_host = /var/run/postgresql"
            return self._fail(
                message="; ".join(problems),
                details=details,
            )

        return self._pass(
            message="Konfigurationswerte OK",
            details=details,
        )
