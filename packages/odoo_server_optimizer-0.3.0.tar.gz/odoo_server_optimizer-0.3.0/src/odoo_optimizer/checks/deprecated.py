"""Check für Befund 6: Veraltete Parameter erkennen.

Befund 6: longpolling_port und andere veraltete Parameter sollten
entfernt werden (seit Odoo 17+ durch gevent ersetzt).
"""

from ..config.defaults import DEPRECATED_PARAMS, ODOO_CONF_PATH
from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class DeprecatedParamsCheck(BaseCheck):
    """Befund 6: Prüft ob veraltete Parameter in odoo.conf stehen.

    Seit Odoo 17+ ist longpolling_port durch den integrierten
    Gevent-Service ersetzt (Standard-Port 8072).
    """

    check_id = "deprecated_params"
    title = "Veraltete Parameter (longpolling_port etc.)"
    severity = Severity.WARNING

    def run(self, conn: AbstractConnection) -> CheckResult:
        """Config-Datei auf veraltete Parameter prüfen."""
        found_deprecated = []

        for param in DEPRECATED_PARAMS:
            result = conn.run(f"grep -E '^{param}' {ODOO_CONF_PATH}")
            if result.stdout.strip():
                found_deprecated.append(param)

        if found_deprecated:
            return self._fail(
                message=f"Veraltete Parameter gefunden: {', '.join(found_deprecated)}",
                details={
                    "ist": found_deprecated,
                    "soll": "Parameter entfernen",
                    "befund": "Befund 6 aus Worker-Analyse v1.0.0",
                    "fix": f"Folgende Zeilen aus {ODOO_CONF_PATH} entfernen: "
                           + ", ".join(found_deprecated),
                },
            )

        return self._pass(
            message="Keine veralteten Parameter gefunden",
            details={"geprüft": DEPRECATED_PARAMS},
        )
