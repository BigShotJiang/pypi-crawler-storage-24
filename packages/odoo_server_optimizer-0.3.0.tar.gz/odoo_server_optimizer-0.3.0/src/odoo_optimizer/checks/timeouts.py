"""Check für Befund 4: Timeout-Werte prüfen.

Befund 4: limit_time_cpu und limit_time_real sollten sinnvolle Werte haben.
Zu hoch → Server blockiert bei Endlosschleifen.
Zu niedrig → Legitime Requests werden abgebrochen.
"""

from ..config.defaults import DEFAULT_LIMIT_TIME_CPU, DEFAULT_LIMIT_TIME_REAL, ODOO_CONF_PATH
from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class TimeoutCheck(BaseCheck):
    """Befund 4: Prüft ob Timeout-Werte sinnvoll konfiguriert sind.

    Empfohlene Werte für Odoo 19 Enterprise:
    - limit_time_cpu = 600 (10 Min)
    - limit_time_real = 1200 (20 Min)
    """

    check_id = "timeouts"
    title = "Timeout-Werte (limit_time_cpu/real)"
    severity = Severity.WARNING

    MAX_CPU = 1800    # Über 30 Min ist definitiv zu viel
    MAX_REAL = 3600   # Über 1 Stunde ist definitiv zu viel
    MIN_CPU = 60      # Unter 1 Min ist zu wenig
    MIN_REAL = 120    # Unter 2 Min ist zu wenig

    def run(self, conn: AbstractConnection) -> CheckResult:
        """Timeout-Werte aus odoo.conf prüfen."""
        cpu_result = conn.run(f"grep -E '^limit_time_cpu' {ODOO_CONF_PATH}")
        real_result = conn.run(f"grep -E '^limit_time_real\\b' {ODOO_CONF_PATH}")

        if not cpu_result.stdout.strip() and not real_result.stdout.strip():
            return self._skip("Timeout-Werte nicht in odoo.conf gefunden")

        problems = []
        details: dict[str, object] = {
            "befund": "Befund 4 aus Worker-Analyse v1.0.0",
        }

        if cpu_result.stdout.strip():
            cpu_val = self._parse_value(cpu_result.stdout)
            details["limit_time_cpu_ist"] = cpu_val
            details["limit_time_cpu_soll"] = DEFAULT_LIMIT_TIME_CPU

            if cpu_val > self.MAX_CPU:
                problems.append(f"limit_time_cpu={cpu_val}s zu hoch (max {self.MAX_CPU}s)")
            elif cpu_val < self.MIN_CPU:
                problems.append(f"limit_time_cpu={cpu_val}s zu niedrig (min {self.MIN_CPU}s)")
            elif cpu_val != DEFAULT_LIMIT_TIME_CPU:
                problems.append(
                    f"limit_time_cpu={cpu_val}s weicht vom Optimum ab "
                    f"(empfohlen: {DEFAULT_LIMIT_TIME_CPU}s)"
                )

        if real_result.stdout.strip():
            real_val = self._parse_value(real_result.stdout)
            details["limit_time_real_ist"] = real_val
            details["limit_time_real_soll"] = DEFAULT_LIMIT_TIME_REAL

            if real_val > self.MAX_REAL:
                problems.append(f"limit_time_real={real_val}s zu hoch (max {self.MAX_REAL}s)")
            elif real_val < self.MIN_REAL:
                problems.append(f"limit_time_real={real_val}s zu niedrig (min {self.MIN_REAL}s)")
            elif real_val != DEFAULT_LIMIT_TIME_REAL:
                problems.append(
                    f"limit_time_real={real_val}s weicht vom Optimum ab "
                    f"(empfohlen: {DEFAULT_LIMIT_TIME_REAL}s)"
                )

        if problems:
            details["fix"] = (
                f"limit_time_cpu = {DEFAULT_LIMIT_TIME_CPU}\n"
                f"limit_time_real = {DEFAULT_LIMIT_TIME_REAL}"
            )
            return self._fail(
                message="; ".join(problems),
                details=details,
            )

        return self._pass(
            message="Timeout-Werte im empfohlenen Bereich",
            details=details,
        )

    def _parse_value(self, line: str) -> int:
        """Wert aus 'parameter = value' extrahieren."""
        return int(line.split("=")[1].strip())
