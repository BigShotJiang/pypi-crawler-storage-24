"""Checks für Befund 1+2: Workers aktiv und korrekte Config-Datei.

Befund 1: Odoo läuft im Single-Threaded-Modus (workers=0)
Befund 2: Falsche Config-Datei wird geladen (.odoorc statt odoo.conf)
"""

from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class WorkersModeCheck(BaseCheck):
    """Befund 1: Prüft ob Odoo im Multi-Worker-Modus läuft.

    Im Worker-Modus: Gevent-Service läuft, mehrere Prozesse sichtbar.
    Im Threaded-Modus (Fehler): nur 1 Prozess, werkzeug HTTP-Service.
    """

    check_id = "workers_mode"
    title = "Workers aktiv (Multi-Worker-Modus)"
    severity = Severity.CRITICAL

    def run(self, conn: AbstractConnection) -> CheckResult:
        """Worker-Modus anhand laufender Prozesse prüfen."""
        result = conn.run("ps aux | grep '[o]doo' | wc -l")
        if not result.success:
            return self._skip("ps-Kommando nicht ausführbar")

        process_count = int(result.stdout.strip())

        # Im Worker-Modus: Master + HTTP-Worker + Cron + Gevent = min. 4
        # Im Threaded-Modus: nur 1 Prozess
        if process_count <= 1:
            return self._fail(
                message=f"Odoo läuft im Single-Threaded-Modus ({process_count} Prozess)",
                details={
                    "ist": f"{process_count} Prozess(e)",
                    "soll": "≥4 Prozesse (1 Master + Worker + Cron + Gevent)",
                    "befund": "Befund 1 aus Worker-Analyse v1.0.0",
                    "auswirkung": "Nur 1 CPU-Kern genutzt, sequentielle Request-Verarbeitung",
                },
            )

        # Zusatz-Check: Gevent-Port 8072 aktiv?
        gevent_check = conn.run("ss -tlnp | grep 8072")
        gevent_active = gevent_check.success and "8072" in gevent_check.stdout

        return self._pass(
            message=f"Worker-Modus aktiv ({process_count} Prozesse)",
            details={
                "prozesse": process_count,
                "gevent_port_8072": gevent_active,
            },
        )


class ConfigFileCheck(BaseCheck):
    """Befund 2: Prüft welche Config-Datei Odoo lädt.

    Problem: Odoo sucht Config in dieser Reihenfolge:
      1. ~/.odoorc (Home des Service-Users)
      2. ~/.openerp_serverrc
      3. /etc/odoo/odoo.conf (Fallback)

    Wenn /opt/odoo/.odoorc existiert, wird /etc/odoo/odoo.conf ignoriert.
    """

    check_id = "config_file"
    title = "Korrekte Config-Datei wird geladen"
    severity = Severity.CRITICAL

    EXPECTED_CONFIG = "/etc/odoo/odoo.conf"
    PROBLEMATIC_ODOORC = "/opt/odoo/.odoorc"

    def run(self, conn: AbstractConnection) -> CheckResult:
        """Config-Datei anhand des Odoo-Logs prüfen."""
        # Log auf verwendete Config-Datei durchsuchen
        log_result = conn.run(
            "sudo journalctl -u odoo --since '1 hour ago' "
            "| grep 'Using configuration file' | tail -1"
        )

        if log_result.success and "Using configuration file" in log_result.stdout:
            used_config = self._extract_config_path(log_result.stdout)

            if used_config == self.EXPECTED_CONFIG:
                return self._pass(
                    message=f"Korrekte Config wird geladen: {self.EXPECTED_CONFIG}",
                    details={"config_datei": used_config},
                )
            else:
                return self._fail(
                    message=f"Falsche Config wird geladen: {used_config}",
                    details={
                        "ist": used_config,
                        "soll": self.EXPECTED_CONFIG,
                        "befund": "Befund 2 aus Worker-Analyse v1.0.0",
                        "ursache": f"{self.PROBLEMATIC_ODOORC} hat Priorität über odoo.conf",
                        "fix": f"ExecStart=/usr/bin/odoo -c {self.EXPECTED_CONFIG}",
                    },
                )

        # Fallback: .odoorc Existenz prüfen
        odoorc_exists = conn.file_exists(self.PROBLEMATIC_ODOORC)
        if odoorc_exists:
            return self._fail(
                message=f"{self.PROBLEMATIC_ODOORC} existiert und überschreibt odoo.conf",
                details={
                    "ist": self.PROBLEMATIC_ODOORC,
                    "soll": self.EXPECTED_CONFIG,
                    "befund": "Befund 2 aus Worker-Analyse v1.0.0",
                },
            )

        return self._skip("Odoo-Log nicht auswertbar, .odoorc nicht gefunden")

    def _extract_config_path(self, log_line: str) -> str:
        """Config-Pfad aus Log-Zeile extrahieren."""
        # Format: "... Using configuration file at /path/to/config"
        parts = log_line.split("Using configuration file at ")
        if len(parts) > 1:
            return parts[1].strip()
        return ""
