"""Checks für Befund 9+10: System-Abhängigkeiten und Sicherheit.

Befund 9: pdfminer.six muss installiert sein (PDF-Reports)
Befund 10: http_interface sollte auf 127.0.0.1 stehen (Nginx-Proxy)
"""

from ..config.defaults import ODOO_CONF_PATH
from ..connection.base import AbstractConnection
from .base import BaseCheck, CheckResult, Severity


class SystemDependenciesCheck(BaseCheck):
    """Befund 9: Prüft ob pdfminer.six installiert ist.

    Ohne pdfminer.six können PDF-Reports nicht korrekt generiert werden.
    """

    check_id = "system_dependencies"
    title = "System-Abhängigkeiten (pdfminer.six)"
    severity = Severity.WARNING

    def run(self, conn: AbstractConnection) -> CheckResult:
        """pdfminer.six Installation prüfen."""
        result = conn.run("pip3 show pdfminer.six")

        if not result.success or "Name: pdfminer.six" not in result.stdout:
            return self._fail(
                message="pdfminer.six ist nicht installiert",
                details={
                    "ist": "nicht installiert",
                    "soll": "pip3 install pdfminer.six",
                    "befund": "Befund 9 aus Worker-Analyse v1.0.0",
                    "auswirkung": "PDF-Reports können fehlerhaft sein",
                    "fix": "pip3 install pdfminer.six",
                },
            )

        return self._pass(
            message="pdfminer.six ist installiert",
            details={"pdfminer": "installiert"},
        )


class HttpInterfaceCheck(BaseCheck):
    """Befund 10: Prüft ob http_interface auf 127.0.0.1 steht.

    Bei Nginx-Proxy-Setup sollte Odoo nur auf localhost lauschen.
    Ohne http_interface lauscht Odoo auf 0.0.0.0 → öffentlich erreichbar.
    """

    check_id = "http_interface"
    title = "HTTP-Interface Sicherheit (http_interface)"
    severity = Severity.CRITICAL

    def run(self, conn: AbstractConnection) -> CheckResult:
        """http_interface aus odoo.conf prüfen."""
        result = conn.run(f"grep -E '^http_interface' {ODOO_CONF_PATH}")

        if not result.stdout.strip():
            return self._fail(
                message="http_interface nicht gesetzt – Odoo lauscht auf 0.0.0.0 (öffentlich!)",
                details={
                    "ist": "nicht gesetzt (0.0.0.0)",
                    "soll": "127.0.0.1",
                    "befund": "Befund 10 aus Worker-Analyse v1.0.0",
                    "auswirkung": "Odoo direkt aus dem Internet erreichbar, umgeht Nginx",
                    "fix": f"http_interface = 127.0.0.1 in {ODOO_CONF_PATH}",
                },
            )

        interface_value = result.stdout.split("=")[1].strip()

        if interface_value != "127.0.0.1":
            return self._fail(
                message=f"http_interface={interface_value} – sollte 127.0.0.1 sein",
                details={
                    "ist": interface_value,
                    "soll": "127.0.0.1",
                    "befund": "Befund 10 aus Worker-Analyse v1.0.0",
                    "fix": f"http_interface = 127.0.0.1 in {ODOO_CONF_PATH}",
                },
            )

        return self._pass(
            message="http_interface=127.0.0.1 – Odoo nur über Nginx erreichbar",
            details={"http_interface": interface_value},
        )
