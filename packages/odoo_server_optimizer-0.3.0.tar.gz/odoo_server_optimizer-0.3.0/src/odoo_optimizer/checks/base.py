"""Basis-Klassen für alle Checks."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from ..connection.base import AbstractConnection


class Severity(StrEnum):
    """Schweregrad eines Befunds (wie in der Worker-Analyse)."""

    CRITICAL = "critical"   # 🔴 Sofortiger Handlungsbedarf
    WARNING = "warning"     # 🟡 Empfehlung / Wichtig
    INFO = "info"           # ℹ️  Hinweis


class Status(StrEnum):
    """Status nach Ausführung eines Checks."""

    PASS = "pass"    # ✅ Kein Problem
    FAIL = "fail"    # ❌ Problem gefunden
    SKIP = "skip"    # ⏭️  Übersprungen (z.B. Datei nicht gefunden)
    ERROR = "error"  # 💥 Check konnte nicht ausgeführt werden


@dataclass
class CheckResult:
    """Ergebnis eines einzelnen Checks.

    Attributes:
        check_id: Eindeutige ID (z.B. "workers_active")
        title: Lesbarer Titel (z.B. "Workers aktiv?")
        severity: Schweregrad wenn FAIL
        status: Ergebnis des Checks
        message: Kurzbeschreibung des Ergebnisses
        details: Strukturierte Details (ist/soll/befund-nr)
        fix_available: Ob ein Fixer für diesen Check existiert
    """

    check_id: str
    title: str
    severity: Severity
    status: Status
    message: str
    details: dict[str, Any] = field(default_factory=dict)
    fix_available: bool = False

    @property
    def needs_fix(self) -> bool:
        """True wenn der Check fehlgeschlagen ist und ein Fix verfügbar ist."""
        return self.status == Status.FAIL and self.fix_available

    @property
    def emoji(self) -> str:
        """Status-Emoji für Terminal-Ausgabe."""
        return {
            Status.PASS: "✅",
            Status.FAIL: "❌",
            Status.SKIP: "⏭️",
            Status.ERROR: "💥",
        }[self.status]

    @property
    def severity_emoji(self) -> str:
        """Severity-Emoji (nur relevant bei FAIL)."""
        return {
            Severity.CRITICAL: "🔴",
            Severity.WARNING: "🟡",
            Severity.INFO: "ℹ️",
        }[self.severity]


class BaseCheck(ABC):
    """Abstrakte Basisklasse für alle Checks.

    Jeder Check implementiert genau einen Befund aus der Worker-Analyse.
    Checks sind zustandslos – run() kann mehrfach aufgerufen werden.

    Beispiel:
        class WorkerCheck(BaseCheck):
            check_id = "workers_active"
            title = "Workers aktiv?"
            severity = Severity.CRITICAL

            def run(self, conn: AbstractConnection) -> CheckResult:
                ...
    """

    check_id: str
    title: str
    severity: Severity

    @abstractmethod
    def run(self, conn: AbstractConnection) -> CheckResult:
        """Check ausführen und Ergebnis zurückgeben.

        Args:
            conn: Verbindung zum Ziel-Server (lokal oder SSH)

        Returns:
            CheckResult mit Status und Details
        """
        ...

    def _pass(self, message: str = "OK", details: dict[str, Any] | None = None) -> CheckResult:
        """Hilfs-Methode: Erfolgs-Ergebnis erstellen."""
        return CheckResult(
            check_id=self.check_id,
            title=self.title,
            severity=self.severity,
            status=Status.PASS,
            message=message,
            details=details or {},
        )

    def _fail(
        self,
        message: str,
        details: dict[str, Any] | None = None,
        fix_available: bool = True,
    ) -> CheckResult:
        """Hilfs-Methode: Fehler-Ergebnis erstellen."""
        return CheckResult(
            check_id=self.check_id,
            title=self.title,
            severity=self.severity,
            status=Status.FAIL,
            message=message,
            details=details or {},
            fix_available=fix_available,
        )

    def _skip(self, reason: str) -> CheckResult:
        """Hilfs-Methode: Übersprungen-Ergebnis erstellen."""
        return CheckResult(
            check_id=self.check_id,
            title=self.title,
            severity=self.severity,
            status=Status.SKIP,
            message=reason,
        )
