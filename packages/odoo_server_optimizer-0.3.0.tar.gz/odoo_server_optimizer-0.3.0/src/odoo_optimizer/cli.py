"""CLI-Einstiegspunkt – odoo-optimizer Commands."""

from __future__ import annotations

from enum import StrEnum

import typer
from rich import print as rprint
from rich.console import Console

from . import __version__
from .calculators.base import HardwareInfo, OptimizationPlan, PostgresInfo
from .checks.registry import run_all_checks
from .connection.base import AbstractConnection
from .fixers.base import BaseFixer, FixPlan
from .reporters.console import display_results

app = typer.Typer(
    name="odoo-optimizer",
    help="Odoo 19 Enterprise – Server Diagnose & Automatische Optimierung",
    add_completion=False,
)
console = Console()


class OutputFormat(StrEnum):
    console = "console"
    markdown = "md"


def _get_connection(server: str | None) -> AbstractConnection:
    """Connection-Objekt für lokalen oder SSH-Zugriff erstellen."""
    if server is None:
        from .connection.local import LocalConnection
        return LocalConnection()
    else:
        # Server-Profil aus servers.yml laden
        from .config.servers import load_server_config
        from .connection.ssh import SSHConnection
        cfg = load_server_config(server)
        return SSHConnection(
            host=cfg["host"],
            user=cfg.get("user", "root"),
            key_path=cfg.get("ssh_key", "~/.ssh/id_ed25519"),
        )


@app.command()
def analyze(
    server: str | None = typer.Option(None, "--server", "-s",
        help="Server-Profil aus config/servers.yml (leer = lokal)"),
    output: OutputFormat = typer.Option(OutputFormat.console, "--output", "-o",
        help="Ausgabeformat"),
) -> None:
    """Server analysieren – alle Checks ausführen und Befunde anzeigen."""
    rprint(f"\n[bold cyan]odoo-optimizer v{__version__}[/bold cyan] · analyze\n")

    with _get_connection(server) as conn:
        results = run_all_checks(conn)

    if output == OutputFormat.console:
        display_results(results, server_name=server or "lokal")
    else:
        from .reporters.markdown import generate_markdown
        md = generate_markdown(results, server_name=server or "lokal")
        console.print(md)


def _run_calculators(
    conn: AbstractConnection,
) -> tuple[HardwareInfo, PostgresInfo, OptimizationPlan]:
    """Calculators ausführen und Ergebnisse zurückgeben."""
    from .calculators.hardware import HardwareCalculator
    from .calculators.optimizer import OptimizerCalculator
    from .calculators.postgres import PostgresCalculator

    hw = HardwareCalculator(conn).calculate()
    pg = PostgresCalculator(conn, hw.total_processes).calculate()
    optimization = OptimizerCalculator(hw, pg).calculate()
    return hw, pg, optimization


def _create_fix_plans(
    conn: AbstractConnection, optimization: OptimizationPlan,
) -> list[tuple[BaseFixer, FixPlan]]:
    """Fixer-Pläne erstellen."""
    from .fixers.config import ConfigFixer
    from .fixers.odoorc import OdooRcFixer
    from .fixers.systemd import SystemdFixer

    fixers: list[BaseFixer] = [
        OdooRcFixer(),
        ConfigFixer(optimization.changes),
        SystemdFixer(),
    ]
    return [(f, f.plan(conn)) for f in fixers]


@app.command()
def plan(
    server: str | None = typer.Option(None, "--server", "-s",
        help="Server-Profil aus config/servers.yml"),
) -> None:
    """Fix-Plan berechnen – zeigt was geändert wird (KEINE Änderungen)."""
    from .reporters.plan import display_plan

    rprint(f"\n[bold cyan]odoo-optimizer v{__version__}[/bold cyan] · plan\n")

    with _get_connection(server) as conn:
        hw, pg, optimization = _run_calculators(conn)
        fixer_plans = _create_fix_plans(conn, optimization)
        fix_plans = [fp for _, fp in fixer_plans]

    display_plan(hw, pg, optimization, fix_plans, server or "lokal")


@app.command()
def apply(
    server: str | None = typer.Option(None, "--server", "-s",
        help="Server-Profil aus config/servers.yml"),
    dry_run: bool = typer.Option(False, "--dry-run",
        help="Zeigt alle Schritte ohne anzuwenden"),
) -> None:
    """Fixes halbautomatisch anwenden – Bestätigung pro Schritt."""
    from .reporters.plan import display_plan

    rprint(f"\n[bold cyan]odoo-optimizer v{__version__}[/bold cyan] · apply\n")

    with _get_connection(server) as conn:
        hw, pg, optimization = _run_calculators(conn)
        fixer_plans = _create_fix_plans(conn, optimization)
        fix_plans = [fp for _, fp in fixer_plans]

        display_plan(hw, pg, optimization, fix_plans, server or "lokal")

        if dry_run:
            rprint("[dim]Modus: --dry-run — keine Änderungen.[/dim]\n")
            return

        active = [(f, p) for f, p in fixer_plans if p.steps]
        if not active:
            rprint("[green]Keine Änderungen nötig.[/green]\n")
            return

        for fixer, fix_plan in active:
            rprint(f"\n[bold]→ {fix_plan.title}[/bold]")
            for step in fix_plan.steps:
                for change in step.changes:
                    rprint(f"  {change}")

            if not typer.confirm("  Anwenden?", default=False):
                rprint("  [yellow]Übersprungen.[/yellow]")
                continue

            # Backup → Apply → Verify
            backup_path = fixer.backup(conn)
            rprint(f"  Backup: {backup_path}")

            if fixer.apply(conn):
                if fixer.verify(conn):
                    rprint("  [green]Erfolgreich angewendet.[/green]")
                else:
                    rprint("  [red]Verifikation fehlgeschlagen "
                           "— Rollback...[/red]")
                    fixer.rollback(conn, backup_path)
                    rprint("  [yellow]Rollback durchgeführt.[/yellow]")
            else:
                rprint("  [red]Anwendung fehlgeschlagen.[/red]")

    rprint("\n[bold green]Fertig.[/bold green]")
    if optimization.needs_restart:
        rprint("[yellow]Odoo-Neustart erforderlich: "
               "systemctl restart odoo[/yellow]\n")


@app.command()
def report(
    server: str | None = typer.Option(None, "--server", "-s",
        help="Server-Profil aus config/servers.yml"),
    format: OutputFormat = typer.Option(OutputFormat.markdown, "--format", "-f",
        help="Ausgabeformat (md oder console)"),
    output_file: str | None = typer.Option(None, "--out",
        help="In Datei speichern (z.B. analyse.md)"),
) -> None:
    """Diagnose-Bericht generieren (Markdown oder Konsole)."""
    rprint(f"\n[bold cyan]odoo-optimizer v{__version__}[/bold cyan] · report\n")

    with _get_connection(server) as conn:
        results = run_all_checks(conn)

    if format == OutputFormat.markdown:
        from .reporters.markdown import generate_markdown
        md = generate_markdown(results, server_name=server or "lokal")
        if output_file:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(md)
            rprint(f"[green]✅ Bericht gespeichert: {output_file}[/green]")
        else:
            console.print(md)
    else:
        display_results(results, server_name=server or "lokal")


@app.callback(invoke_without_command=True)
def version_callback(
    version: bool = typer.Option(False, "--version", "-v", help="Version anzeigen"),
) -> None:
    """odoo-optimizer – Odoo 19 Enterprise Server Diagnose & Optimierung."""
    if version:
        rprint(f"odoo-optimizer v{__version__}")
        raise typer.Exit()


if __name__ == "__main__":
    app()
