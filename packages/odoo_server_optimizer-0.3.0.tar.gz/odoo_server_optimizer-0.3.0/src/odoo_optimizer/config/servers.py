"""Server-Profile aus servers.yml laden."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_server_config(server_name: str) -> dict[str, Any]:
    """Server-Profil aus servers.yml laden.

    Args:
        server_name: Name des Servers (z.B. "prod")

    Returns:
        Dict mit host, user, ssh_key, etc.

    Raises:
        KeyError: Wenn Server-Profil nicht gefunden
    """
    config_path = Path(__file__).parent / "servers.yml"
    with open(config_path, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    servers = config.get("servers", {})
    if server_name not in servers:
        available = ", ".join(servers.keys())
        raise KeyError(
            f"Server '{server_name}' nicht in servers.yml gefunden. "
            f"Verfügbar: {available}"
        )

    result: dict[str, Any] = servers[server_name]
    return result
