"""Standard-Werte und Formeln für Odoo-Konfiguration."""

# ==========================================
# WORKER-FORMEL: (CPU_Cores × 2) + 1
# CCX23 (4 vCPU): (4 × 2) + 1 = 9 HTTP-Worker
# ==========================================
WORKER_FORMULA_MULTIPLIER = 2
WORKER_FORMULA_OFFSET = 1

# ==========================================
# DATENBANK-VERBINDUNGEN
# db_maxconn × Gesamtprozesse < PG max_connections
# ==========================================
DEFAULT_DB_MAXCONN = 8
DEFAULT_PG_MAX_CONNECTIONS = 100

# ==========================================
# TIMEOUT-WERTE (Sekunden)
# ==========================================
DEFAULT_LIMIT_TIME_CPU = 600         # 10 Minuten
DEFAULT_LIMIT_TIME_REAL = 1200       # 20 Minuten
DEFAULT_LIMIT_TIME_REAL_CRON = 3600  # 1 Stunde (für KI-Cron-Jobs)

# ==========================================
# MEMORY-LIMITS PRO WORKER (Bytes)
# ==========================================
DEFAULT_LIMIT_MEMORY_SOFT = 1_342_177_280  # 1.25 GB
DEFAULT_LIMIT_MEMORY_HARD = 1_610_612_736  # 1.5 GB

# ==========================================
# CRON-THREADS
# ==========================================
DEFAULT_MAX_CRON_THREADS = 1  # Für Einzelunternehmen ausreichend

# ==========================================
# STANDARD-PFADE (Odoo auf Ubuntu)
# ==========================================
ODOO_CONF_PATH = "/etc/odoo/odoo.conf"
ODOO_RC_PATH_TEMPLATE = "/opt/odoo/.odoorc"
ODOO_SERVICE_PATH = "/etc/systemd/system/odoo.service"
ODOO_LOG_PATH = "/var/log/odoo/odoo.log"
ODOO_ADDONS_PATH = "/usr/lib/python3/dist-packages/odoo/addons"

# ==========================================
# NGINX PROXY TIMEOUTS (Sekunden)
# Müssen >= limit_time_real sein, sonst
# bricht Nginx die Verbindung vor Odoo ab.
# ==========================================
NGINX_PROXY_READ_TIMEOUT = 1200     # = limit_time_real
NGINX_PROXY_CONNECT_TIMEOUT = 600   # = limit_time_cpu
NGINX_PROXY_SEND_TIMEOUT = 600      # = limit_time_cpu
NGINX_SITE_CONFIG_PATH = "/etc/nginx/sites-available/odoo"

# ==========================================
# SWAP-KONFIGURATION
# Empfehlung: Swap = RAM für OOM-Schutz
# ==========================================
SWAP_FILE_PATH = "/swapfile"
MIN_SWAP_GB = 1            # Minimum: 1 GB Swap
SWAP_SWAPPINESS = 10       # Niedrig halten für Datenbank-Server

# ==========================================
# VERALTETE PARAMETER (Odoo 17+)
# ==========================================
DEPRECATED_PARAMS = [
    "longpolling_port",  # Ersetzt durch gevent-port (Standard: 8072)
]

# ==========================================
# SCHWELLWERTE FÜR WARNUNGEN
# ==========================================
MIN_PROCESSES_FOR_WORKER_MODE = 4   # Master + ≥1 HTTP + Cron + Gevent
GEVENT_PORT = 8072
HTTP_PORT = 8069
