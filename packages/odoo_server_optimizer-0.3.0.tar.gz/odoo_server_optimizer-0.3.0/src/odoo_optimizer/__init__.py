"""odoo-server-optimizer – Odoo 19 Enterprise Server Diagnose & Optimierung."""

__version__ = "0.3.0"
__author__ = "Bernhard Krenn"
