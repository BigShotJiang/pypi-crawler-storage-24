"""Lokale Connection – führt Kommandos via subprocess aus."""

import shutil
import subprocess
from pathlib import Path

from .base import AbstractConnection, CommandResult


class LocalConnection(AbstractConnection):
    """Verbindung zum lokalen System (direkt auf dem Odoo-Server).

    Verwendet subprocess für Shell-Kommandos.
    Geeignet wenn das Tool direkt auf dem Server ausgeführt wird.
    """

    def run(self, cmd: str) -> CommandResult:
        """Shell-Kommando lokal ausführen."""
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        return CommandResult(
            stdout=result.stdout.strip(),
            stderr=result.stderr.strip(),
            returncode=result.returncode,
        )

    def read_file(self, path: str) -> str:
        """Dateiinhalt lesen."""
        return Path(path).read_text(encoding="utf-8")

    def write_file(self, path: str, content: str) -> None:
        """Dateiinhalt schreiben."""
        Path(path).write_text(content, encoding="utf-8")

    def file_exists(self, path: str) -> bool:
        """Prüfen ob Datei/Verzeichnis existiert."""
        return Path(path).exists()

    def copy_file(self, src: str, dst: str) -> None:
        """Datei kopieren."""
        shutil.copy2(src, dst)

    def close(self) -> None:
        """Keine Verbindung zu schließen."""
        pass
