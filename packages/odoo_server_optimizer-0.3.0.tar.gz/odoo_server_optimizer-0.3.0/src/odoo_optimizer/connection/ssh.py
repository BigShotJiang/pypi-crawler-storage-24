"""SSH Connection – Remote-Zugriff via paramiko."""

from __future__ import annotations

import paramiko

from .base import AbstractConnection, CommandResult


class SSHConnection(AbstractConnection):
    """Verbindung zu einem Remote-Server via SSH (Key-Auth).

    Geeignet wenn das Tool vom Mac aus auf den Hetzner-Server zugreift.

    Beispiel:
        conn = SSHConnection(
            host="bernhardkrenn.cc",
            user="adminbk",
            key_path="~/.ssh/id_ed25519",
        )
    """

    def __init__(
        self,
        host: str,
        user: str = "root",
        key_path: str = "~/.ssh/id_ed25519",
        port: int = 22,
        timeout: int = 10,
    ) -> None:
        self.host = host
        self.user = user
        self.key_path = key_path
        self.port = port
        self.timeout = timeout
        self._client: paramiko.SSHClient | None = None
        self._connect()

    def _connect(self) -> None:
        """SSH-Verbindung aufbauen (nur Key-Auth)."""
        self._client = paramiko.SSHClient()
        self._client.load_system_host_keys()
        self._client.set_missing_host_key_policy(paramiko.RejectPolicy())
        self._client.connect(
            hostname=self.host,
            port=self.port,
            username=self.user,
            key_filename=self.key_path,
            timeout=self.timeout,
            look_for_keys=False,
            allow_agent=False,
        )

    def run(self, cmd: str) -> CommandResult:
        """Kommando auf Remote-Server ausführen."""
        assert self._client is not None
        _, stdout, stderr = self._client.exec_command(cmd, timeout=30)
        return CommandResult(
            stdout=stdout.read().decode().strip(),
            stderr=stderr.read().decode().strip(),
            returncode=stdout.channel.recv_exit_status(),
        )

    def read_file(self, path: str) -> str:
        """Dateiinhalt via SSH lesen."""
        result = self.run(f"cat {path}")
        if not result.success:
            raise FileNotFoundError(f"Datei nicht gefunden: {path}")
        return result.stdout

    def write_file(self, path: str, content: str) -> None:
        """Dateiinhalt via SSH schreiben (via sudo tee)."""
        # Sicherer Weg: via echo + sudo tee
        escaped = content.replace("'", "'\"'\"'")
        self.run(f"echo '{escaped}' | sudo tee {path} > /dev/null")

    def file_exists(self, path: str) -> bool:
        """Prüfen ob Datei existiert."""
        return self.run(f"test -e {path}").success

    def copy_file(self, src: str, dst: str) -> None:
        """Datei auf Remote-Server kopieren."""
        self.run(f"sudo cp {src} {dst}")

    def close(self) -> None:
        """SSH-Verbindung schließen."""
        if self._client:
            self._client.close()
            self._client = None
