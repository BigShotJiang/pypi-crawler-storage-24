"""Abstrakte Connection-Schicht – lokal oder SSH."""

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class CommandResult:
    """Ergebnis eines ausgeführten Shell-Kommandos."""

    stdout: str
    stderr: str
    returncode: int

    @property
    def success(self) -> bool:
        """True wenn Returncode 0."""
        return self.returncode == 0


class AbstractConnection(ABC):
    """Interface für alle Connection-Typen (lokal, SSH).

    Alle Checks und Fixer arbeiten ausschließlich mit diesem Interface.
    Sie wissen nicht ob lokal oder remote ausgeführt wird.
    """

    @abstractmethod
    def run(self, cmd: str) -> CommandResult:
        """Shell-Kommando ausführen und Ergebnis zurückgeben."""
        ...

    @abstractmethod
    def read_file(self, path: str) -> str:
        """Dateiinhalt lesen."""
        ...

    @abstractmethod
    def write_file(self, path: str, content: str) -> None:
        """Dateiinhalt schreiben (erfordert sudo-Rechte je nach Pfad)."""
        ...

    @abstractmethod
    def file_exists(self, path: str) -> bool:
        """Prüfen ob eine Datei oder Verzeichnis existiert."""
        ...

    @abstractmethod
    def copy_file(self, src: str, dst: str) -> None:
        """Datei kopieren (für Backups)."""
        ...

    @abstractmethod
    def close(self) -> None:
        """Verbindung schließen."""
        ...

    def __enter__(self) -> "AbstractConnection":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
