"""Config-Fixer: odoo.conf Parameter optimieren."""

import re

from ..config.defaults import (
    DEPRECATED_PARAMS,
    ODOO_CONF_PATH,
)
from ..connection.base import AbstractConnection
from .base import BaseFixer, FixPlan, FixStep


class ConfigFixer(BaseFixer):
    """Optimiert odoo.conf basierend auf dem OptimizationPlan.

    Ändert: workers, max_cron_threads, db_maxconn, Timeouts,
    Memory-Limits, http_interface.
    Entfernt: deprecated Parameter (longpolling_port).
    """

    fixer_id = "config"
    title = "odoo.conf Konfiguration optimieren"
    check_ids = [
        "worker_mode",
        "database_conn",
        "timeouts",
        "cron_threads",
        "deprecated_params",
        "config_values",
        "http_interface",
    ]

    def __init__(self, changes: dict[str, dict[str, object]]) -> None:
        """Args:
            changes: Dict mit Parameter → {soll, grund} aus OptimizationPlan.
        """
        self.changes = changes
        self._conf_path = ODOO_CONF_PATH
        self._backup_path: str | None = None

    def plan(self, conn: AbstractConnection) -> FixPlan:
        """Ist-/Soll-Vergleich der odoo.conf Parameter erstellen."""
        current_config = self._read_config_safe(conn)
        change_descriptions: list[str] = []

        for param, info in self.changes.items():
            soll = info["soll"]
            ist = self._get_param_value(current_config, param)
            if str(ist) != str(soll):
                change_descriptions.append(
                    f"{param}: {ist!r} → {soll!r} ({info['grund']})"
                )

        # Deprecated Parameter entfernen
        for param in DEPRECATED_PARAMS:
            if self._param_exists(current_config, param):
                change_descriptions.append(
                    f"{param}: ENTFERNEN (deprecated seit Odoo 17)"
                )

        if not change_descriptions:
            return FixPlan(
                fixer_id=self.fixer_id,
                title=self.title,
                steps=[],
                check_ids=self.check_ids,
            )

        backup_path = self._make_backup_path(self._conf_path, conn)
        step = FixStep(
            description="odoo.conf Parameter anpassen",
            file_path=self._conf_path,
            backup_path=backup_path,
            changes=change_descriptions,
        )
        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=[step],
            check_ids=self.check_ids,
            requires_restart=True,
            requires_sudo=True,
        )

    def backup(self, conn: AbstractConnection) -> str:
        """Backup der aktuellen odoo.conf erstellen."""
        self._backup_path = self._make_backup_path(self._conf_path, conn)
        conn.copy_file(self._conf_path, self._backup_path)
        return self._backup_path

    def apply(self, conn: AbstractConnection) -> bool:
        """Parameter in odoo.conf setzen/ändern."""
        content = self._read_config_safe(conn)
        if not content:
            return False

        for param, info in self.changes.items():
            content = self._set_param(content, param, info["soll"])

        # Deprecated Parameter entfernen
        for param in DEPRECATED_PARAMS:
            content = self._remove_param(content, param)

        conn.write_file(self._conf_path, content)
        return True

    def verify(self, conn: AbstractConnection) -> bool:
        """Prüfen ob alle Parameter korrekt gesetzt wurden."""
        content = self._read_config_safe(conn)
        if not content:
            return False

        for param, info in self.changes.items():
            actual = self._get_param_value(content, param)
            if str(actual) != str(info["soll"]):
                return False

        # Deprecated Parameter dürfen nicht mehr existieren
        for param in DEPRECATED_PARAMS:
            if self._param_exists(content, param):
                return False

        return True

    def rollback(self, conn: AbstractConnection, backup_path: str) -> bool:
        """Backup der odoo.conf wiederherstellen."""
        if not conn.file_exists(backup_path):
            return False
        conn.copy_file(backup_path, self._conf_path)
        return True

    # --- Hilfsmethoden ---

    def _read_config_safe(self, conn: AbstractConnection) -> str:
        """Config lesen, leerer String bei Fehler."""
        try:
            return conn.read_file(self._conf_path)
        except (FileNotFoundError, OSError):
            return ""

    @staticmethod
    def _get_param_value(content: str, param: str) -> str | None:
        """Wert eines Parameters aus der Config-Datei lesen."""
        pattern = rf"^\s*{re.escape(param)}\s*=\s*(.+)$"
        match = re.search(pattern, content, re.MULTILINE)
        if match:
            return match.group(1).strip()
        return None

    @staticmethod
    def _param_exists(content: str, param: str) -> bool:
        """Prüfen ob ein Parameter (auch auskommentiert) in der Config steht."""
        pattern = rf"^\s*{re.escape(param)}\s*="
        return bool(re.search(pattern, content, re.MULTILINE))

    @staticmethod
    def _set_param(content: str, param: str, value: object) -> str:
        """Parameter setzen oder hinzufügen."""
        pattern = rf"^(\s*#?\s*{re.escape(param)}\s*=.*)$"
        replacement = f"{param} = {value}"

        if re.search(pattern, content, re.MULTILINE):
            return re.sub(pattern, replacement, content, flags=re.MULTILINE)

        # Parameter existiert nicht → unter [options] hinzufügen
        if "[options]" in content:
            return content.replace(
                "[options]", f"[options]\n{replacement}", 1
            )
        return content + f"\n{replacement}\n"

    @staticmethod
    def _remove_param(content: str, param: str) -> str:
        """Parameter (und zugehörigen Kommentar) entfernen."""
        pattern = rf"^\s*{re.escape(param)}\s*=.*\n?"
        return re.sub(pattern, "", content, flags=re.MULTILINE)
