"""Nginx-Fixer: Proxy-Timeouts an Odoo-Werte anpassen."""

import re

from ..config.defaults import (
    NGINX_PROXY_CONNECT_TIMEOUT,
    NGINX_PROXY_READ_TIMEOUT,
    NGINX_PROXY_SEND_TIMEOUT,
    NGINX_SITE_CONFIG_PATH,
)
from ..connection.base import AbstractConnection
from .base import BaseFixer, FixPlan, FixStep

# Timeout-Direktiven die geprüft/gesetzt werden
TIMEOUT_DIRECTIVES: dict[str, int] = {
    "proxy_read_timeout": NGINX_PROXY_READ_TIMEOUT,
    "proxy_connect_timeout": NGINX_PROXY_CONNECT_TIMEOUT,
    "proxy_send_timeout": NGINX_PROXY_SEND_TIMEOUT,
}


class NginxFixer(BaseFixer):
    """Passt Nginx-Proxy-Timeouts an Odoo limit_time_real/cpu an.

    Ohne passende Timeouts bricht Nginx die Verbindung ab bevor
    Odoo mit der Verarbeitung fertig ist (z.B. bei langen Reports).

    Prüft/setzt:
    - proxy_read_timeout (>= limit_time_real)
    - proxy_connect_timeout (>= limit_time_cpu)
    - proxy_send_timeout (>= limit_time_cpu)
    """

    fixer_id = "nginx"
    title = "Nginx Proxy-Timeouts optimieren"
    check_ids = ["timeouts"]

    def __init__(self) -> None:
        self._config_path = NGINX_SITE_CONFIG_PATH
        self._backup_path: str | None = None

    def plan(self, conn: AbstractConnection) -> FixPlan:
        """Prüfen welche Timeout-Direktiven angepasst werden müssen."""
        content = self._read_config_safe(conn)
        if not content:
            return self._empty_plan()

        changes = self._find_needed_changes(content)
        if not changes:
            return self._empty_plan()

        backup_path = self._make_backup_path(self._config_path, conn)
        step = FixStep(
            description="Nginx Proxy-Timeouts anpassen",
            file_path=self._config_path,
            backup_path=backup_path,
            changes=changes,
        )
        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=[step],
            check_ids=self.check_ids,
            requires_restart=True,
            requires_sudo=True,
        )

    def backup(self, conn: AbstractConnection) -> str:
        """Backup der Nginx-Config erstellen."""
        self._backup_path = self._make_backup_path(self._config_path, conn)
        conn.copy_file(self._config_path, self._backup_path)
        return self._backup_path

    def apply(self, conn: AbstractConnection) -> bool:
        """Timeout-Direktiven setzen/aktualisieren."""
        content = self._read_config_safe(conn)
        if not content:
            return False

        new_content = content
        for directive, target_value in TIMEOUT_DIRECTIVES.items():
            new_content = self._set_directive(
                new_content, directive, target_value
            )

        if new_content == content:
            return True  # Nichts zu ändern

        conn.write_file(self._config_path, new_content)
        conn.run("nginx -t")
        conn.run("systemctl reload nginx")
        return True

    def verify(self, conn: AbstractConnection) -> bool:
        """Prüfen ob alle Timeouts korrekt gesetzt sind."""
        content = self._read_config_safe(conn)
        if not content:
            return False

        for directive, target_value in TIMEOUT_DIRECTIVES.items():
            current = self._get_directive_value(content, directive)
            if current != target_value:
                return False
        return True

    def rollback(self, conn: AbstractConnection, backup_path: str) -> bool:
        """Backup der Nginx-Config wiederherstellen + reload."""
        if not conn.file_exists(backup_path):
            return False
        conn.copy_file(backup_path, self._config_path)
        conn.run("nginx -t")
        conn.run("systemctl reload nginx")
        return True

    def _empty_plan(self) -> FixPlan:
        """Leeren Plan zurückgeben (keine Änderungen nötig)."""
        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=[],
            check_ids=self.check_ids,
        )

    def _find_needed_changes(self, content: str) -> list[str]:
        """Ermitteln welche Direktiven geändert werden müssen."""
        changes: list[str] = []
        for directive, target_value in TIMEOUT_DIRECTIVES.items():
            current = self._get_directive_value(content, directive)
            if current is None:
                changes.append(
                    f"{directive} {target_value}s hinzufügen"
                )
            elif current != target_value:
                changes.append(
                    f"{directive}: {current}s → {target_value}s"
                )
        return changes

    def _get_directive_value(self, content: str, directive: str) -> int | None:
        """Aktuellen Wert einer Timeout-Direktive auslesen (in Sekunden)."""
        pattern = rf"^\s*{re.escape(directive)}\s+(\d+)s?\s*;"
        match = re.search(pattern, content, re.MULTILINE)
        if match:
            return int(match.group(1))
        return None

    def _set_directive(
        self, content: str, directive: str, value: int
    ) -> str:
        """Timeout-Direktive setzen oder aktualisieren.

        Wenn die Direktive existiert → Wert ersetzen.
        Wenn nicht → vor der ersten proxy_pass-Zeile einfügen.
        """
        pattern = rf"(^\s*){re.escape(directive)}\s+\d+s?\s*;"
        replacement = rf"\g<1>{directive} {value}s;"
        new_content, count = re.subn(
            pattern, replacement, content, count=1, flags=re.MULTILINE
        )
        if count > 0:
            return new_content

        # Direktive fehlt → vor proxy_pass einfügen
        proxy_pass_pattern = r"(^\s*)(proxy_pass\s+)"
        match = re.search(proxy_pass_pattern, content, re.MULTILINE)
        if match:
            indent = match.group(1)
            insert_line = f"{indent}{directive} {value}s;\n"
            return content[: match.start()] + insert_line + content[match.start() :]

        # Kein proxy_pass gefunden → am Ende des letzten location-Blocks
        return content

    def _read_config_safe(self, conn: AbstractConnection) -> str:
        """Nginx-Config lesen, leerer String bei Fehler."""
        try:
            return conn.read_file(self._config_path)
        except (FileNotFoundError, OSError):
            return ""
