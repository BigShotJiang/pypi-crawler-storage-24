"""OdooRc-Fixer: .odoorc deaktivieren (umbenennen)."""

from ..config.defaults import ODOO_RC_PATH_TEMPLATE
from ..connection.base import AbstractConnection
from .base import BaseFixer, FixPlan, FixStep


class OdooRcFixer(BaseFixer):
    """Benennt /opt/odoo/.odoorc → .odoorc.disabled.YYYYMMDD_HHMM um.

    Verhindert, dass Odoo die falsche Config lädt, wenn sowohl
    .odoorc als auch /etc/odoo/odoo.conf existieren.
    """

    fixer_id = "odoorc"
    title = ".odoorc deaktivieren"
    check_ids = ["config_source"]

    def __init__(self) -> None:
        self._rc_path = ODOO_RC_PATH_TEMPLATE
        self._disabled_path: str | None = None

    def plan(self, conn: AbstractConnection) -> FixPlan:
        """Prüfen ob .odoorc existiert und Plan erstellen."""
        if not conn.file_exists(self._rc_path):
            return FixPlan(
                fixer_id=self.fixer_id,
                title=self.title,
                steps=[],
                check_ids=self.check_ids,
            )

        disabled_path = self._make_disabled_path(conn)
        step = FixStep(
            description=f"{self._rc_path} deaktivieren",
            file_path=self._rc_path,
            backup_path=disabled_path,
            changes=[
                f"Umbenennen: {self._rc_path} → {disabled_path}",
            ],
        )
        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=[step],
            check_ids=self.check_ids,
            requires_restart=True,
            requires_sudo=True,
        )

    def backup(self, conn: AbstractConnection) -> str:
        """Kein separates Backup nötig — Umbenennung IST das Backup."""
        self._disabled_path = self._make_disabled_path(conn)
        return self._disabled_path

    def apply(self, conn: AbstractConnection) -> bool:
        """odoorc umbenennen."""
        if not conn.file_exists(self._rc_path):
            return True  # Schon weg → OK

        self._disabled_path = self._make_disabled_path(conn)
        result = conn.run(
            f"mv {self._rc_path} {self._disabled_path}"
        )
        return result.success

    def verify(self, conn: AbstractConnection) -> bool:
        """.odoorc darf nicht mehr existieren."""
        return not conn.file_exists(self._rc_path)

    def rollback(self, conn: AbstractConnection, backup_path: str) -> bool:
        """Umbenennung rückgängig machen."""
        result = conn.run(f"mv {backup_path} {self._rc_path}")
        return result.success

    def _make_disabled_path(self, conn: AbstractConnection) -> str:
        """Pfad für die deaktivierte .odoorc generieren."""
        date_result = conn.run("TZ='Europe/Vienna' date '+%Y%m%d_%H%M'")
        date_str = (
            date_result.stdout.strip() if date_result.success else "disabled"
        )
        return f"{self._rc_path}.disabled.{date_str}"
