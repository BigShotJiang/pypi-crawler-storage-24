"""Basis-Klassen für alle Fixer – Plan-Apply-Pattern."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ..connection.base import AbstractConnection


@dataclass
class FixStep:
    """Ein einzelner Schritt im Fix-Plan."""

    description: str          # Was wird geändert?
    file_path: str | None     # Welche Datei wird bearbeitet?
    backup_path: str | None   # Wohin wird das Backup gespeichert?
    changes: list[str] = field(default_factory=list)  # Konkrete Änderungen


@dataclass
class FixPlan:
    """Plan für einen Fixer – zeigt was passieren wird OHNE anzuwenden."""

    fixer_id: str
    title: str
    steps: list[FixStep]
    check_ids: list[str]       # Welche Check-Probleme werden behoben?
    requires_restart: bool = False
    requires_sudo: bool = True


class BaseFixer(ABC):
    """Abstrakte Basisklasse für alle Fixer.

    Pattern (halbautomatisch):
      1. plan()    → Zeigt was passieren wird (keine Änderungen)
      2. backup()  → Sicherungskopie erstellen
      3. apply()   → Änderung durchführen
      4. verify()  → Prüfen ob erfolgreich
      5. rollback()→ Bei Fehler: Backup wiederherstellen

    Jeder Schritt wird dem User angezeigt und muss bestätigt werden.
    """

    fixer_id: str
    title: str
    check_ids: list[str]  # Welche Check-IDs behebt dieser Fixer?

    @abstractmethod
    def plan(self, conn: AbstractConnection) -> FixPlan:
        """Fix-Plan erstellen (KEINE Änderungen).

        Zeigt dem User genau was passieren wird, welche Dateien
        geändert werden und wo Backups gespeichert werden.
        """
        ...

    @abstractmethod
    def backup(self, conn: AbstractConnection) -> str:
        """Sicherungskopie erstellen.

        Returns:
            Pfad zur Backup-Datei (mit Datum-Suffix)
        """
        ...

    @abstractmethod
    def apply(self, conn: AbstractConnection) -> bool:
        """Fix anwenden.

        Returns:
            True wenn erfolgreich
        """
        ...

    @abstractmethod
    def verify(self, conn: AbstractConnection) -> bool:
        """Prüfen ob Fix erfolgreich war.

        Returns:
            True wenn Problem behoben
        """
        ...

    @abstractmethod
    def rollback(self, conn: AbstractConnection, backup_path: str) -> bool:
        """Backup wiederherstellen (bei Fehler).

        Args:
            backup_path: Pfad zur Backup-Datei

        Returns:
            True wenn Rollback erfolgreich
        """
        ...

    def _make_backup_path(self, original_path: str, conn: AbstractConnection) -> str:
        """Backup-Pfad mit aktuellem Datum-Suffix generieren."""
        date_result = conn.run("TZ='Europe/Vienna' date '+%Y%m%d_%H%M'")
        date_str = date_result.stdout.strip() if date_result.success else "backup"
        return f"{original_path}.bak.{date_str}"
