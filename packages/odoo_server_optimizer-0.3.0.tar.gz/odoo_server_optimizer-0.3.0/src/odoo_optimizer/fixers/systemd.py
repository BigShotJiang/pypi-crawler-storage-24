"""Systemd-Fixer: Odoo Service-Datei patchen."""

from ..config.defaults import ODOO_CONF_PATH, ODOO_SERVICE_PATH
from ..connection.base import AbstractConnection
from .base import BaseFixer, FixPlan, FixStep


class SystemdFixer(BaseFixer):
    """Patcht die Odoo systemd-Service-Datei.

    Stellt sicher, dass ExecStart den expliziten Config-Pfad enthält:
        ExecStart=... -c /etc/odoo/odoo.conf
    """

    fixer_id = "systemd"
    title = "systemd Service-Datei patchen"
    check_ids = ["config_source"]

    def __init__(self) -> None:
        self._service_path = ODOO_SERVICE_PATH
        self._conf_flag = f" -c {ODOO_CONF_PATH}"
        self._backup_path: str | None = None

    def plan(self, conn: AbstractConnection) -> FixPlan:
        """Prüfen ob die Service-Datei angepasst werden muss."""
        content = self._read_service_safe(conn)
        if not content:
            return FixPlan(
                fixer_id=self.fixer_id,
                title=self.title,
                steps=[],
                check_ids=self.check_ids,
            )

        if self._has_config_ref(content):
            # Config-Pfad schon gesetzt (-c oder --config)
            return FixPlan(
                fixer_id=self.fixer_id,
                title=self.title,
                steps=[],
                check_ids=self.check_ids,
            )

        backup_path = self._make_backup_path(self._service_path, conn)
        step = FixStep(
            description="ExecStart um Config-Pfad ergänzen",
            file_path=self._service_path,
            backup_path=backup_path,
            changes=[
                f"ExecStart: -c {ODOO_CONF_PATH} hinzufügen",
                "systemctl daemon-reload ausführen",
            ],
        )
        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=[step],
            check_ids=self.check_ids,
            requires_restart=True,
            requires_sudo=True,
        )

    def backup(self, conn: AbstractConnection) -> str:
        """Backup der Service-Datei erstellen."""
        self._backup_path = self._make_backup_path(
            self._service_path, conn
        )
        conn.copy_file(self._service_path, self._backup_path)
        return self._backup_path

    def apply(self, conn: AbstractConnection) -> bool:
        """ExecStart um -c /etc/odoo/odoo.conf ergänzen."""
        content = self._read_service_safe(conn)
        if not content:
            return False

        # ExecStart-Zeile finden und Config-Flag anhängen
        lines = content.splitlines()
        patched = False
        for i, line in enumerate(lines):
            if line.strip().startswith("ExecStart="):
                if not self._has_config_ref(line):
                    lines[i] = line.rstrip() + self._conf_flag
                    patched = True
                break

        if not patched:
            return False

        conn.write_file(self._service_path, "\n".join(lines) + "\n")

        # daemon-reload damit systemd die neue Datei liest
        conn.run("systemctl daemon-reload")
        return True

    def verify(self, conn: AbstractConnection) -> bool:
        """Prüfen ob Config-Pfad in ExecStart steht."""
        content = self._read_service_safe(conn)
        if not content:
            return False
        return self._has_config_ref(content)

    def rollback(self, conn: AbstractConnection, backup_path: str) -> bool:
        """Backup der Service-Datei wiederherstellen + daemon-reload."""
        if not conn.file_exists(backup_path):
            return False
        conn.copy_file(backup_path, self._service_path)
        conn.run("systemctl daemon-reload")
        return True

    def _has_config_ref(self, content: str) -> bool:
        """Prüfen ob -c oder --config ODOO_CONF_PATH im Text vorkommt."""
        return (
            f"-c {ODOO_CONF_PATH}" in content
            or f"--config {ODOO_CONF_PATH}" in content
        )

    def _read_service_safe(self, conn: AbstractConnection) -> str:
        """Service-Datei lesen, leerer String bei Fehler."""
        try:
            return conn.read_file(self._service_path)
        except (FileNotFoundError, OSError):
            return ""
