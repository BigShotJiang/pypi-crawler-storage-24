"""Fixer-Registry – alle verfügbaren Fixer in korrekter Reihenfolge."""

from .config import ConfigFixer
from .nginx import NginxFixer
from .odoorc import OdooRcFixer
from .swap import SwapFixer
from .systemd import SystemdFixer

__all__ = [
    "ALL_FIXER_CLASSES",
    "ConfigFixer",
    "NginxFixer",
    "OdooRcFixer",
    "SwapFixer",
    "SystemdFixer",
]

# Reihenfolge ist wichtig:
# 1. .odoorc deaktivieren (sonst lädt Odoo falsche Config)
# 2. odoo.conf optimieren
# 3. systemd Service patchen (damit neue Config geladen wird)
# 4. Nginx Proxy-Timeouts anpassen
# 5. Swap einrichten (OOM-Schutz)
ALL_FIXER_CLASSES = [OdooRcFixer, SystemdFixer, NginxFixer, SwapFixer]

# ConfigFixer wird separat instanziiert, da er changes-Dict benötigt
