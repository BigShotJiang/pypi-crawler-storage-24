"""Swap-Fixer: Swap-Datei einrichten für OOM-Schutz."""

from ..config.defaults import MIN_SWAP_GB, SWAP_FILE_PATH, SWAP_SWAPPINESS
from ..connection.base import AbstractConnection
from .base import BaseFixer, FixPlan, FixStep


class SwapFixer(BaseFixer):
    """Richtet eine Swap-Datei ein oder vergrößert bestehenden Swap.

    Odoo-Worker können bei großen Reports oder KI-Cron-Jobs viel RAM
    verbrauchen. Ohne Swap wird der Prozess vom OOM-Killer beendet.

    Empfehlung: Swap >= RAM-Größe (z.B. 16 GB bei CCX23).
    Swappiness = 10 (Server soll RAM bevorzugen, Swap nur als Notfall).
    """

    fixer_id = "swap"
    title = "Swap-Datei einrichten"
    check_ids: list[str] = []  # Kein zugehöriger Check (präventiv)

    def __init__(self, target_swap_gb: int | None = None) -> None:
        """SwapFixer initialisieren.

        Args:
            target_swap_gb: Gewünschte Swap-Größe in GB.
                            None = automatisch (= RAM-Größe).
        """
        self._target_swap_gb = target_swap_gb
        self._swap_path = SWAP_FILE_PATH

    def plan(self, conn: AbstractConnection) -> FixPlan:
        """Prüfen ob Swap eingerichtet/vergrößert werden muss."""
        current_swap_mb = self._get_swap_total_mb(conn)
        target_gb = self._resolve_target_gb(conn)

        if target_gb <= 0:
            return self._empty_plan()

        current_gb = current_swap_mb / 1024
        if current_gb >= target_gb:
            return self._empty_plan()

        steps = []

        if current_swap_mb == 0:
            # Kein Swap vorhanden → neue Swap-Datei erstellen
            steps.append(FixStep(
                description=f"Swap-Datei {self._swap_path} mit {target_gb} GB erstellen",
                file_path=self._swap_path,
                backup_path=None,
                changes=[
                    f"fallocate -l {target_gb}G {self._swap_path}",
                    f"chmod 600 {self._swap_path}",
                    f"mkswap {self._swap_path}",
                    f"swapon {self._swap_path}",
                    "Eintrag in /etc/fstab hinzufügen",
                    f"vm.swappiness = {SWAP_SWAPPINESS} setzen",
                ],
            ))
        else:
            # Swap vorhanden aber zu klein → vergrößern
            steps.append(FixStep(
                description=(
                    f"Swap von {current_gb:.1f} GB auf {target_gb} GB vergrößern"
                ),
                file_path=self._swap_path,
                backup_path=None,
                changes=[
                    f"swapoff {self._swap_path}",
                    f"fallocate -l {target_gb}G {self._swap_path}",
                    f"mkswap {self._swap_path}",
                    f"swapon {self._swap_path}",
                    f"vm.swappiness = {SWAP_SWAPPINESS} prüfen",
                ],
            ))

        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=steps,
            check_ids=self.check_ids,
            requires_restart=False,
            requires_sudo=True,
        )

    def backup(self, conn: AbstractConnection) -> str:
        """Backup der fstab erstellen (Swap-Datei selbst wird nicht gesichert)."""
        backup_path = self._make_backup_path("/etc/fstab", conn)
        conn.copy_file("/etc/fstab", backup_path)
        return backup_path

    def apply(self, conn: AbstractConnection) -> bool:
        """Swap-Datei erstellen/vergrößern und aktivieren."""
        target_gb = self._resolve_target_gb(conn)
        if target_gb <= 0:
            return False

        current_swap_mb = self._get_swap_total_mb(conn)

        # Bestehenden Swap auf der Datei deaktivieren
        if current_swap_mb > 0 and conn.file_exists(self._swap_path):
            conn.run(f"swapoff {self._swap_path}")

        # Swap-Datei erstellen
        conn.run(f"fallocate -l {target_gb}G {self._swap_path}")
        conn.run(f"chmod 600 {self._swap_path}")
        conn.run(f"mkswap {self._swap_path}")
        conn.run(f"swapon {self._swap_path}")

        # fstab-Eintrag sicherstellen (idempotent)
        fstab = conn.read_file("/etc/fstab")
        if self._swap_path not in fstab:
            fstab_line = f"\n{self._swap_path} none swap sw 0 0\n"
            conn.write_file("/etc/fstab", fstab + fstab_line)

        # Swappiness setzen
        conn.run(f"sysctl vm.swappiness={SWAP_SWAPPINESS}")

        # Swappiness persistent machen
        sysctl_conf = "/etc/sysctl.d/99-swappiness.conf"
        conn.write_file(sysctl_conf, f"vm.swappiness = {SWAP_SWAPPINESS}\n")

        return True

    def verify(self, conn: AbstractConnection) -> bool:
        """Prüfen ob Swap aktiv und ausreichend groß ist."""
        target_gb = self._resolve_target_gb(conn)
        current_swap_mb = self._get_swap_total_mb(conn)
        current_gb = current_swap_mb / 1024

        if current_gb < target_gb * 0.9:  # 10% Toleranz
            return False

        # Swappiness prüfen
        result = conn.run("sysctl -n vm.swappiness")
        if result.stdout.strip() != str(SWAP_SWAPPINESS):
            return False

        return True

    def rollback(self, conn: AbstractConnection, backup_path: str) -> bool:
        """Swap deaktivieren und fstab wiederherstellen."""
        # Swap deaktivieren
        if conn.file_exists(self._swap_path):
            conn.run(f"swapoff {self._swap_path}")
            conn.run(f"rm {self._swap_path}")

        # fstab wiederherstellen
        if not conn.file_exists(backup_path):
            return False
        conn.copy_file(backup_path, "/etc/fstab")

        # Swappiness-Config entfernen
        sysctl_conf = "/etc/sysctl.d/99-swappiness.conf"
        if conn.file_exists(sysctl_conf):
            conn.run(f"rm {sysctl_conf}")

        return True

    def _empty_plan(self) -> FixPlan:
        """Leeren Plan zurückgeben."""
        return FixPlan(
            fixer_id=self.fixer_id,
            title=self.title,
            steps=[],
            check_ids=self.check_ids,
        )

    def _get_swap_total_mb(self, conn: AbstractConnection) -> int:
        """Aktuelle Swap-Größe in MB auslesen."""
        result = conn.run("free -m | grep -i swap")
        if not result.stdout.strip():
            return 0
        parts = result.stdout.split()
        if len(parts) >= 2:
            try:
                return int(parts[1])
            except ValueError:
                return 0
        return 0

    def _get_ram_gb(self, conn: AbstractConnection) -> int:
        """RAM-Größe in GB auslesen (aufgerundet)."""
        result = conn.run("free -g | grep -i mem")
        if not result.stdout.strip():
            return 0
        parts = result.stdout.split()
        if len(parts) >= 2:
            try:
                return max(int(parts[1]), MIN_SWAP_GB)
            except ValueError:
                return MIN_SWAP_GB
        return MIN_SWAP_GB

    def _resolve_target_gb(self, conn: AbstractConnection) -> int:
        """Ziel-Swap-Größe ermitteln (explizit oder automatisch = RAM)."""
        if self._target_swap_gb is not None:
            return self._target_swap_gb
        return self._get_ram_gb(conn)
