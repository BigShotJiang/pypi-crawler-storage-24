"""FastAPI Web-Dashboard für odoo-optimizer."""

from .app import app

__all__ = ["app"]
