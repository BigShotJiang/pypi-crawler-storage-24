"""FastAPI Web-Dashboard – Server Diagnose & Optimierung."""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import Depends, FastAPI, HTTPException, Security
from fastapi.responses import HTMLResponse
from fastapi.security import APIKeyHeader
from pydantic import BaseModel

from .. import __version__
from ..checks.base import Severity, Status
from ..checks.registry import ALL_CHECKS
from ..connection.base import AbstractConnection

app = FastAPI(
    title="odoo-optimizer Dashboard",
    version=__version__,
    description="Web-Dashboard für Odoo Server Diagnose & Optimierung",
)

# --- Konfiguration (zur Laufzeit aus os.environ gelesen) ---


def _get_api_key() -> str:
    """API-Key aus Umgebungsvariable lesen (zur Laufzeit)."""
    return os.environ.get("ODOO_OPTIMIZER_API_KEY", "")


def _get_data_dir() -> Path:
    """Datenverzeichnis aus Umgebungsvariable lesen (zur Laufzeit)."""
    return Path(os.environ.get("ODOO_OPTIMIZER_DATA_DIR", "/tmp/odoo-optimizer"))


# --- Auth ---

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def _check_api_key(api_key: str | None = Security(_api_key_header)) -> str | None:
    """API-Key prüfen (nur wenn ODOO_OPTIMIZER_API_KEY gesetzt ist)."""
    key = _get_api_key()
    if not key:
        return None  # Kein Key konfiguriert → kein Auth
    if api_key != key:
        raise HTTPException(status_code=403, detail="Ungültiger API-Key")
    return api_key


# --- Persistenz ---

def _history_path() -> Path:
    """Pfad zur Analyse-Historie."""
    data_dir = _get_data_dir()
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "analysis_history.json"


def _load_history() -> list[dict[str, Any]]:
    """Analyse-Historie aus JSON laden."""
    path = _history_path()
    if not path.exists():
        return []
    result: list[dict[str, Any]] = json.loads(path.read_text(encoding="utf-8"))
    return result


def _save_analysis(analysis: dict[str, Any]) -> None:
    """Analyse-Ergebnis zur Historie hinzufügen (max. 50 Einträge)."""
    history = _load_history()
    history.insert(0, analysis)
    history = history[:50]  # Nur die letzten 50 behalten
    _history_path().write_text(
        json.dumps(history, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


# --- Pydantic-Modelle ---

class AnalyzeRequest(BaseModel):
    """Request-Body für /api/analyze."""
    connection_type: str = "local"
    host: str | None = None
    user: str = "root"


class CheckResultResponse(BaseModel):
    """Einzelnes Check-Ergebnis als JSON."""
    check_id: str
    title: str
    severity: str
    status: str
    message: str
    details: dict[str, Any] = {}
    fix_available: bool = False


class AnalyzeResponse(BaseModel):
    """Antwort von /api/analyze."""
    server: str
    timestamp: str
    total: int
    passed: int
    failed: int
    results: list[CheckResultResponse]


# --- Endpoints ---

@app.get("/api/health")
def health_check() -> dict[str, str]:
    """Health-Check Endpoint."""
    return {
        "status": "ok",
        "version": __version__,
        "auth_required": str(bool(_get_api_key())),
        "timestamp": datetime.now(ZoneInfo("Europe/Vienna")).isoformat(),
    }


@app.get("/api/status")
def get_status() -> dict[str, Any]:
    """Letztes Analyse-Ergebnis abrufen."""
    history = _load_history()
    if not history:
        return {"status": "no_analysis", "message": "Noch keine Analyse durchgeführt"}
    return history[0]


@app.get("/api/history")
def get_history() -> list[dict[str, Any]]:
    """Analyse-Historie abrufen (max. 50 Einträge)."""
    return _load_history()


@app.post("/api/analyze", response_model=AnalyzeResponse)
def analyze_server(
    request: AnalyzeRequest,
    _key: str | None = Depends(_check_api_key),
) -> AnalyzeResponse:
    """Server analysieren und Ergebnisse als JSON zurückgeben."""
    conn: AbstractConnection
    if request.connection_type == "local":
        from ..connection.local import LocalConnection
        conn = LocalConnection()
    else:
        from ..connection.ssh import SSHConnection
        conn = SSHConnection(
            host=request.host or "localhost",
            user=request.user,
        )

    server_name = request.host or "lokal"

    with conn:
        from ..checks.registry import run_all_checks
        results = run_all_checks(conn)

    now = datetime.now(ZoneInfo("Europe/Vienna")).strftime("%Y-%m-%d %H:%M Uhr (Vienna)")
    passed = sum(1 for r in results if r.status == Status.PASS)
    failed = sum(1 for r in results if r.status == Status.FAIL)

    response = AnalyzeResponse(
        server=server_name,
        timestamp=now,
        total=len(results),
        passed=passed,
        failed=failed,
        results=[
            CheckResultResponse(
                check_id=r.check_id,
                title=r.title,
                severity=r.severity.value,
                status=r.status.value,
                message=r.message,
                details=r.details,
                fix_available=r.fix_available,
            )
            for r in results
        ],
    )

    _save_analysis(response.model_dump())
    return response


@app.get("/", response_class=HTMLResponse)
def dashboard() -> str:
    """Dashboard-HTML mit Übersicht und Analyse-Ergebnissen."""
    check_rows = ""
    for check_cls in ALL_CHECKS:
        severity_icon = {
            Severity.CRITICAL: "🔴",
            Severity.WARNING: "🟡",
            Severity.INFO: "🔵",
        }.get(check_cls.severity, "")
        check_rows += f"""
            <tr>
                <td>{check_cls.check_id}</td>
                <td>{check_cls.title}</td>
                <td>{severity_icon} {check_cls.severity.value}</td>
            </tr>"""

    # Letzte Analyse visuell darstellen
    history = _load_history()
    analysis_html = ""
    if history:
        a = history[0]
        result_rows = ""
        for r in a.get("results", []):
            status_icons = {
                "pass": "✅", "fail": "❌", "skip": "⏭️", "error": "⚠️",
            }
            status_icon = status_icons.get(r["status"], "❓")
            sev_icon = {"critical": "🔴", "warning": "🟡", "info": "🔵"}.get(r["severity"], "")
            sev_display = f"{sev_icon}" if r["status"] != "pass" else "–"
            row_class = "result-fail" if r["status"] == "fail" else ""
            fix_hint = " 🔧" if r.get("fix_available") else ""
            result_rows += f"""
                <tr class="{row_class}">
                    <td>{status_icon}</td>
                    <td>{sev_display}</td>
                    <td>{r['title']}</td>
                    <td>{r['message']}{fix_hint}</td>
                </tr>"""

        analysis_html = f"""
        <div class="card">
            <h2>Letzte Analyse</h2>
            <div class="analysis-meta">
                <span><strong>Server:</strong> {a['server']}</span>
                <span><strong>Zeitpunkt:</strong> {a['timestamp']}</span>
                <span class="score">✅ {a['passed']} · ❌ {a['failed']} · \
Gesamt: {a['total']}</span>
            </div>
            <table>
                <thead>
                    <tr><th>Status</th><th>Schwere</th><th>Check</th><th>Meldung</th></tr>
                </thead>
                <tbody>{result_rows}
                </tbody>
            </table>
        </div>"""

    # Historie
    history_html = ""
    if len(history) > 1:
        history_items = ""
        for h in history[1:10]:  # Max. 9 ältere Einträge
            history_items += (
                f'<li>{h["timestamp"]} — {h["server"]} — '
                f'✅ {h["passed"]} · ❌ {h["failed"]}</li>'
            )
        history_html = f"""
        <div class="card">
            <h2>Ältere Analysen</h2>
            <ul class="history">{history_items}</ul>
        </div>"""

    auth_hint = ' <span class="auth-badge">🔒 Auth aktiv</span>' if _get_api_key() else ""

    return f"""<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>odoo-optimizer Dashboard</title>
    <style>
        * {{ margin:0; padding:0; box-sizing:border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               background: #f5f5f5; color: #333; padding: 2rem; }}
        .container {{ max-width: 960px; margin: 0 auto; }}
        h1 {{ color: #2c3e50; margin-bottom: 0.5rem; display: inline; }}
        .subtitle {{ color: #7f8c8d; margin-bottom: 2rem; }}
        .header {{ margin-bottom: 2rem; }}
        .auth-badge {{ font-size: 0.75rem; background: #27ae60; color: #fff;
                      padding: 2px 8px; border-radius: 4px; vertical-align: middle; }}
        .card {{ background: #fff; border-radius: 8px; padding: 1.5rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1.5rem; }}
        .analysis-meta {{ display: flex; gap: 2rem; flex-wrap: wrap;
                         margin: 0.75rem 0 1rem; color: #555; }}
        .score {{ font-weight: 600; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ text-align: left; padding: 0.6rem 0.75rem; border-bottom: 1px solid #eee; }}
        th {{ background: #f8f9fa; font-weight: 600; font-size: 0.9rem; }}
        tr:hover {{ background: #f8f9fa; }}
        .result-fail {{ background: #fff5f5; }}
        .result-fail:hover {{ background: #ffecec; }}
        .actions {{ margin-top: 1rem; }}
        .btn {{ display: inline-block; padding: 0.75rem 1.5rem; background: #3498db;
               color: #fff; border: none; border-radius: 4px; cursor: pointer;
               font-size: 1rem; text-decoration: none; }}
        .btn:hover {{ background: #2980b9; }}
        .btn:disabled {{ background: #bdc3c7; cursor: not-allowed; }}
        .btn-secondary {{ background: #95a5a6; margin-left: 0.5rem; }}
        .btn-secondary:hover {{ background: #7f8c8d; }}
        .history {{ list-style: none; }}
        .history li {{ padding: 0.4rem 0; border-bottom: 1px solid #f0f0f0;
                      font-size: 0.9rem; color: #666; }}
        #result-container {{ margin-top: 1rem; display: none; }}
        .result-card {{ background: #f8f9fa; border-radius: 4px; padding: 1rem;
                       overflow: auto; max-height: 400px; }}
        .footer {{ margin-top: 2rem; color: #95a5a6; font-size: 0.85rem; text-align: center; }}
        @media (max-width: 600px) {{
            body {{ padding: 1rem; }}
            .analysis-meta {{ flex-direction: column; gap: 0.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>odoo-optimizer v{__version__}</h1>{auth_hint}
            <p class="subtitle">Odoo 19 Enterprise – Server Diagnose & Optimierung</p>
        </div>

        {analysis_html}

        <div class="card">
            <h2>Verfügbare Checks ({len(ALL_CHECKS)})</h2>
            <table>
                <thead>
                    <tr><th>ID</th><th>Check</th><th>Schwere</th></tr>
                </thead>
                <tbody>{check_rows}
                </tbody>
            </table>
        </div>

        <div class="card actions">
            <h2>Analyse starten</h2>
            <p style="margin: 0.75rem 0">Server analysieren:</p>
            <button class="btn" id="btnLocal" onclick="runAnalysis('local')">
                Lokale Analyse
            </button>
            <div id="result-container">
                <div class="result-card" id="result"></div>
            </div>
        </div>

        {history_html}

        <p class="footer">odoo-optimizer v{__version__} · Web-Dashboard</p>
    </div>
    <script>
        async function runAnalysis(type) {{
            const btn = document.getElementById('btnLocal');
            const container = document.getElementById('result-container');
            const result = document.getElementById('result');
            btn.textContent = 'Analyse läuft...';
            btn.disabled = true;
            container.style.display = 'block';
            result.innerHTML = '<p>Bitte warten...</p>';
            try {{
                const headers = {{'Content-Type': 'application/json'}};
                const apiKey = localStorage.getItem('odoo_optimizer_api_key');
                if (apiKey) headers['X-API-Key'] = apiKey;
                const res = await fetch('/api/analyze', {{
                    method: 'POST',
                    headers,
                    body: JSON.stringify({{connection_type: type}})
                }});
                if (res.status === 403) {{
                    result.innerHTML = '<p style="color:#e74c3c">' +
                        'Zugriff verweigert. API-Key erforderlich.</p>';
                    btn.textContent = 'Lokale Analyse';
                    btn.disabled = false;
                    return;
                }}
                const data = await res.json();
                let html = `<p><strong>Server:</strong> ${{data.server}} · ` +
                    `✅ ${{data.passed}} · ❌ ${{data.failed}}</p><table>` +
                    `<tr><th>Status</th><th>Check</th><th>Meldung</th></tr>`;
                data.results.forEach(r => {{
                    const icon = r.status === 'pass' ? '✅' : r.status === 'fail' ? '❌' : '⏭️';
                    const cls = r.status === 'fail' ? 'style="background:#fff5f5"' : '';
                    html += `<tr ${{cls}}><td>${{icon}}</td>` +
                        `<td>${{r.title}}</td><td>${{r.message}}</td></tr>`;
                }});
                html += '</table><p style="margin-top:0.5rem;color:#95a5a6;font-size:0.85rem">' +
                    'Seite neu laden für aktualisiertes Dashboard.</p>';
                result.innerHTML = html;
            }} catch (e) {{
                result.innerHTML = `<p style="color:#e74c3c">Fehler: ${{e.message}}</p>`;
            }}
            btn.textContent = 'Lokale Analyse';
            btn.disabled = false;
        }}
    </script>
</body>
</html>"""
