# Session Handoff – odoo-server-optimizer

> **Zweck:** Dieses Dokument ermöglicht die nahtlose Fortsetzung der Arbeit
> in einer neuen Claude-Session. Am Anfang jeder neuen Session zuerst diese
> Datei lesen!

---

## Projekt-Kontext

**Projekt:** `odoo-server-optimizer`
**Repository:** `https://github.com/BERNHARD-KRENN-R-D/odoo-server-optimizer`
**Lokal (Mac):** `/Users/bernhardkrenn/GitHub/odoo-server-optimizer`

**Hintergrund:**
Basierend auf der Analyse `odoo19_worker_analyse_v1_0_0.md` wurde festgestellt,
dass Odoo 19 Enterprise auf dem Hetzner CCX23 im Single-Threaded-Modus läuft,
obwohl Workers konfiguriert sind. Dieses Tool automatisiert die Diagnose und
Behebung solcher Probleme – für diese und zukünftige Odoo-Installationen.

**Ziel (langfristig):** Branchenlösung als SaaS-Tool für Odoo-Partner und KMU.

---

## Server-Infrastruktur

| Komponente | Details |
|-----------|---------|
| Server | Hetzner CCX23 · 4 vCPU · 16 GB RAM |
| OS | Ubuntu 24.04 |
| Odoo | 19 Enterprise (19.0+e-20260225) |
| PostgreSQL | 16 |
| Nginx | Reverse Proxy mit SSL |
| Domain | bernhardkrenn.cc |
| SSH-User | adminbk |

---

## Aktueller Status

**Version:** 0.3.0
**Branch:** `feat/v0.3.0-release`
**Phase:** v0.3.0 Release — alle Tests bestanden, Version hochgezogen
**Tests:** 120/120 bestanden

### Nächste Schritte

1. **PR erstellen** für `feat/v0.3.0-release` → `main` mergen
2. **Git-Tag `v0.3.0` setzen** nach dem Merge
3. **Packaging** (PyPI oder privates Repo) — noch offen
4. **Multi-Server-Verwaltung** über `servers.yml` — geplant für v0.4.0
5. **Integration-Test** gegen echten Server — geplant für v0.4.0

### Was ist fertig ✅

- [x] Verzeichnisstruktur (src-Layout)
- [x] pyproject.toml mit allen Dependencies
- [x] BaseCheck / BaseConnection / BaseFixer (Fundament)
- [x] LocalConnection + SSHConnection
- [x] GitHub Actions CI-Pipeline
- [x] Alle 10 Checks (Befund 1–10): workers, database, timeouts, cron, deprecated, config_values, system
- [x] 3 Calculators: hardware, postgres, optimizer
- [x] 5 Fixer: config, odoorc, systemd, nginx (Proxy-Timeouts), swap (OOM-Schutz)
- [x] CLI: analyze, plan, apply, report — alle funktional
- [x] Reporter: console (Rich-Tabellen), plan (Rich-Panels), markdown (vollständig)
- [x] FastAPI Web-Dashboard mit Auth + Persistenz (API-Key, JSON-Historie, visuelles Dashboard)
- [x] 120 Tests bestanden (Checks: 22, Calculators: 8, Fixer: 53, Reporter: 16, API: 14, Workers: 7)
- [x] Dokumentation: README, CHANGELOG, CLAUDE.md, architecture.md, SKILLS.md

### Was fehlt noch ⏳ (v0.4.0+)

- [ ] Packaging (PyPI oder privates Repo)
- [ ] Multi-Server-Verwaltung über servers.yml
- [ ] Integration-Test gegen echten Server

---

## Wichtige Design-Entscheidungen

### Plan-Apply-Pattern (wie Terraform)
```
analyze() → CheckResult[]
plan()    → FixPlan (zeigt was passiert, keine Änderungen)
apply()   → pro Fixer: Bestätigung → Backup → Apply → Verify
```

### Connection-Abstraktion
Alle Checks/Fixer arbeiten nur mit `conn.run()` und `conn.read_file()`.
Das Tool merkt nicht ob lokal oder SSH.

### Halbautomatischer Modus
Standard: Bestätigung pro Schritt (kein `--yes` Flag ohne explizite Warnung).
`--dry-run` zeigt alles ohne anzuwenden.

### Sprache & Commits
- Dokumentation: Deutsch
- Code/Variablen: Englisch
- Commit-Messages: Deutsch
- Timestamps: Vienna/Austria (`TZ='Europe/Vienna' date '+%Y-%m-%d %H:%M Uhr (Vienna)'`)

---

## Architektur-Kurzreferenz

```
src/odoo_optimizer/
├── cli.py                    # Typer – 4 Commands: analyze|plan|apply|report
├── connection/               # base.py, local.py, ssh.py
├── checks/                   # base.py, registry.py, workers.py, database.py, ...
├── calculators/              # base.py, hardware.py, postgres.py, optimizer.py
├── fixers/                   # base.py, registry.py, config.py, odoorc.py, systemd.py, nginx.py, swap.py
├── reporters/                # console.py, plan.py, markdown.py (vollständig)
├── api/                      # FastAPI Dashboard (app.py, 4 Endpoints)
└── config/                   # defaults.py, servers.yml
```

---

## Referenz-Dokumente

| Datei | Beschreibung |
|-------|-------------|
| `docs/references/odoo19_worker_analyse_v1_0_0.md` | Ursprüngliche Analyse (10 Befunde) |
| `docs/architecture.md` | Architektur-Entscheidungen |
| `docs/adr/` | Architecture Decision Records |
| `QUALITY.md` | Qualitätsstandards & Checkliste |

---

## Bekannte Probleme / Offene Fragen

- Packaging/Distribution (PyPI vs. privates Repo) noch offen

---

*Letzte Aktualisierung: 2026-03-09 02:45 Uhr (Vienna)*
*Nächste Session: dieses Dokument zuerst lesen, dann `git log --oneline -10` ausführen*
