---
name: odoo-server-optimizer
description: >
  Skill für die Entwicklung und Weiterentwicklung des odoo-server-optimizer Tools.
  Verwende diesen Skill wenn es um Odoo 19 Enterprise Server-Diagnose, Worker-Konfiguration,
  Performance-Optimierung, oder die Implementierung neuer Checks/Fixer/Calculator geht.
  Auch verwenden wenn: neue Check-Klassen erstellt werden, SSH-Verbindungen konfiguriert
  werden, der Plan-Apply-Workflow erweitert wird, oder Markdown-Reports generiert werden.
---

# Skill: odoo-server-optimizer

## Projekt-Kontext

Python CLI-Tool zur automatisierten Diagnose und Optimierung von Odoo 19 Enterprise Servern.
Basiert auf der Analyse `odoo19_worker_analyse_v1_0_0.md` (10 Befunde, 3 kritisch).

**Repository:** `https://github.com/bernhardkrenn/odoo-server-optimizer`
**Lokal:** `/Users/bernhardkrenn/GitHub/odoo-server-optimizer`

## Sofort lesen bei Session-Start

1. `SESSION_HANDOFF.md` – aktueller Status, offene Punkte
2. `QUALITY.md` – Coding-Standards und Checklisten
3. `git log --oneline -10` – letzte Commits

## Architektur (Kurzreferenz)

```
cli.py → checks/ → connection/ → Odoo Server
              ↓
         calculators/ → optimale Werte
              ↓
         fixers/ → Backup → Apply → Verify
              ↓
         reporters/ → Console | Markdown
```

**Wichtigste Regel:** Business Logic (checks/calculators/fixers) kennt NIEMALS CLI oder Reporter.

## Implementierungs-Patterns

### Neuer Check
```python
class MyCheck(BaseCheck):
    check_id = "my_check"
    title = "Beschreibung des Checks"
    severity = Severity.CRITICAL

    def run(self, conn: AbstractConnection) -> CheckResult:
        output = conn.run("some command").stdout
        if problem_detected(output):
            return CheckResult(
                check_id=self.check_id,
                status=Status.FAIL,
                message="Problem gefunden",
                details={"ist": output, "soll": "..."},
                fix_available=True,
            )
        return CheckResult(check_id=self.check_id, status=Status.PASS, ...)
```

### Neuer Fixer
```python
class MyFixer(BaseFixer):
    fixer_id = "my_fixer"
    check_ids = ["my_check"]  # Welche Checks dieser Fixer behebt

    def backup(self, conn): ...    # Datei sichern mit Datum-Suffix
    def plan(self, conn): ...      # Änderung beschreiben (kein Apply)
    def apply(self, conn): ...     # Änderung durchführen
    def verify(self, conn): ...    # Prüfen ob erfolgreich
    def rollback(self, conn): ...  # Backup wiederherstellen
```

## Odoo-spezifisches Wissen

### Worker-Formel (CCX23: 4 vCPU, 16 GB RAM)
```
HTTP Workers = (CPU_Cores × 2) + 1 = 9
Cron Workers = 1 (Einzelunternehmen)
Gevent Worker = 1 (automatisch)
Gesamt = 11 Prozesse
```

### db_maxconn Formel
```
db_maxconn × Gesamtprozesse < PostgreSQL max_connections
8 × 11 = 88 < 100 ✅
```

### Config-Datei Priorität (Odoo)
```
1. ~/.odoorc          ← Problem! Wird zuerst gefunden
2. ~/.openerp_serverrc
3. /etc/odoo/odoo.conf ← Gewünschte Config
```
**Fix:** ExecStart=/usr/bin/odoo -c /etc/odoo/odoo.conf

### Kritische Parameter (Zielwerte CCX23)
```ini
workers = 9
max_cron_threads = 1
db_maxconn = 8
limit_time_cpu = 600
limit_time_real = 1200
limit_time_real_cron = 3600
http_interface = 127.0.0.1
```

## Timestamps (WICHTIG)

IMMER vor Datei-Änderungen die aktuelle Zeit ermitteln:
```bash
TZ='Europe/Vienna' date '+%Y-%m-%d %H:%M Uhr (Vienna)'
```
Niemals schätzen oder raten!

## Qualitäts-Kurzcheckliste

Vor jedem Commit:
- [ ] Type Hints vorhanden
- [ ] Docstring vorhanden
- [ ] Unit-Test geschrieben
- [ ] In registry.py registriert
- [ ] SESSION_HANDOFF.md aktualisiert
- [ ] CHANGELOG.md aktualisiert
- [ ] Timestamp korrekt (Vienna)

## Referenz-Dokumente

| Datei | Inhalt |
|-------|--------|
| `docs/references/odoo19_worker_analyse_v1_0_0.md` | 10 Befunde, Lösungen |
| `docs/architecture.md` | Schichten, Patterns, ADRs |
| `QUALITY.md` | Vollständige Checklisten |
| `SESSION_HANDOFF.md` | Aktueller Status |
