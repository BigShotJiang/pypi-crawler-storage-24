# Security Policy

## Unterstützte Versionen

| Version | Sicherheits-Updates |
|---------|---------------------|
| 0.2.x   | ✅ Aktiv            |
| 0.1.x   | ❌ Nicht unterstützt |
| < 0.1   | ❌ Nicht unterstützt |

---

## Sicherheitslücke melden

**Bitte melde Sicherheitslücken NICHT als öffentliches GitHub Issue.**

Sicherheitslücken werden vertraulich behandelt. Bitte sende eine E-Mail an:

📧 **office@bernhardkrenn.cc**

Betreff: `[SECURITY] odoo-server-optimizer – <kurze Beschreibung>`

### Was in die Meldung gehört

- Beschreibung der Sicherheitslücke
- Schritte zur Reproduktion
- Mögliche Auswirkungen (z.B. Datenverlust, unbefugter Zugriff)
- Betroffene Version(en)
- Optional: Vorschlag für einen Fix

### Was danach passiert

1. Bestätigung des Eingangs innerhalb von **48 Stunden**
2. Einschätzung der Schwere innerhalb von **7 Tagen**
3. Fix und Release innerhalb von **30 Tagen** (je nach Schwere früher)
4. Erwähnung im CHANGELOG (auf Wunsch mit oder ohne Namen)

---

## Sicherheitsrelevante Bereiche dieses Projekts

Dieses Tool hat weitreichende Rechte auf dem Zielsystem. Folgende Bereiche
sind besonders sicherheitskritisch:

### SSH-Verbindungen (`connection/ssh.py`)
- Nur Key-basierte Authentifizierung (niemals Passwörter)
- Host-Fingerprint-Validierung aktiv (kein `AutoAddPolicy`)
- Timeout konfiguriert

### Sudo-Operationen (`fixers/`)
- Jede schreibende Operation erfordert `sudo`
- Backup wird **vor** jeder Änderung erstellt
- Rollback ist immer möglich

### Konfigurationsdateien
- `servers.yml` enthält SSH-Key-Pfade – **niemals** Passwörter oder Hashes
- `odoo.conf` enthält `admin_passwd` Hash – darf niemals geloggt oder ausgegeben werden
- `.gitignore` schließt alle `*.key`, `*.pem`, `.env` Dateien aus

### Bekannte Einschränkungen
- Das Tool führt Shell-Kommandos via SSH aus – nur auf vertrauenswürdigen Servern verwenden
- `servers.yml` sollte Dateisystem-Berechtigungen `600` haben (`chmod 600 servers.yml`)
- SSH-Keys sollten eine Passphrase haben

---

## Sicherheits-Checkliste für Entwickler

Vor jedem Commit prüfen:

- [ ] Keine Passwörter, Hashes oder SSH-Keys im Code oder in Testdateien
- [ ] Keine echten Hostnamen oder IPs (Fixtures verwenden Platzhalter)
- [ ] `admin_passwd` wird in keinem Log oder Output ausgegeben
- [ ] Neue Shell-Kommandos auf Injection-Sicherheit geprüft
- [ ] Neue Fixer erstellen immer ein Backup vor dem Apply

---

## Responsible Disclosure

Wir folgen dem Prinzip des **Responsible Disclosure**. Sicherheitsforscher,
die Lücken verantwortungsvoll melden, werden im CHANGELOG namentlich erwähnt
(sofern gewünscht).

---

*Erstellt: 2026-03-03 23:15 Uhr (Vienna)*
*Aktualisiert: 2026-03-04 01:26 Uhr (Vienna)*
