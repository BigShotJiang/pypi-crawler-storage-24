# Architektur – odoo-server-optimizer

**Version:** 0.2.0
**Erstellt:** 2026-03-03 10:35 Uhr (Vienna)
**Aktualisiert:** 2026-03-04 01:26 Uhr (Vienna)

---

## Überblick

Das Tool folgt einem **Plan-Apply-Pattern** (inspiriert von Terraform):

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   analyze   │───▶│    plan     │───▶│    apply    │───▶│   report    │
│             │    │             │    │             │    │             │
│ Alle Checks │    │ Optimale    │    │ Halbautom.  │    │ MD / Konsole│
│ ausführen   │    │ Werte ber.  │    │ m. Bestät.  │    │ ausgeben    │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
```

---

## Schichtenmodell

```
┌──────────────────────────────────────────────────────┐
│                    CLI / API Layer                    │
│              cli.py  |  api/routes.py                │
├──────────────────────────────────────────────────────┤
│                  Reporters Layer                      │
│      console.py  |  plan.py  |  markdown.py          │
├──────────────────────────────────────────────────────┤
│                Business Logic Layer                   │
│    checks/  |  calculators/  |  fixers/              │
├──────────────────────────────────────────────────────┤
│               Connection Abstraction                  │
│         LocalConnection  |  SSHConnection            │
├──────────────────────────────────────────────────────┤
│                  Target System                        │
│        Odoo Server (lokal oder remote via SSH)       │
└──────────────────────────────────────────────────────┘
```

**Wichtigste Regel:** Jede Schicht kennt nur die darunter liegende.
Business Logic kennt NIEMALS CLI oder Reporter.

---

## Connection-Abstraktion

```python
class AbstractConnection:
    def run(self, cmd: str) -> CommandResult: ...
    def read_file(self, path: str) -> str: ...
    def write_file(self, path: str, content: str) -> None: ...
    def file_exists(self, path: str) -> bool: ...
    def copy_file(self, src: str, dst: str) -> None: ...
```

`LocalConnection` → verwendet `subprocess.run()`
`SSHConnection`   → verwendet `paramiko` (SSH-Key-Auth)

Alle Checks und Fixer empfangen nur `AbstractConnection` –
sie wissen nicht, ob lokal oder remote.

---

## Check-System

```python
@dataclass
class CheckResult:
    check_id: str
    title: str
    severity: Severity       # CRITICAL | WARNING | INFO | OK
    status: Status           # FAIL | PASS | SKIP
    message: str
    details: dict            # Ist-Zustand, Soll-Zustand, Befund-Nr.
    fix_available: bool

class BaseCheck(ABC):
    check_id: str
    title: str
    severity: Severity

    @abstractmethod
    def run(self, conn: AbstractConnection) -> CheckResult: ...
```

Checks werden in `checks/registry.py` registriert und
können einzeln oder als Gruppe ausgeführt werden.

---

## Plan-Apply-Pattern

```
FixPlan:
  ┌────────────────────────────────────────────┐
  │ Fixer 1: odoo.conf aktualisieren           │
  │   Backup: /etc/odoo/odoo.conf.bak.20260303 │
  │   Änderungen: db_maxconn: 64 → 8           │
  │               workers: 0 → 9               │
  │   [Bestätigen? J/N]                        │
  ├────────────────────────────────────────────┤
  │ Fixer 2: systemd service korrigieren       │
  │   Backup: /etc/systemd/...service.bak      │
  │   Änderung: ExecStart += -c /etc/odoo/...  │
  │   [Bestätigen? J/N]                        │
  └────────────────────────────────────────────┘
```

Jeder Fixer ist atomar: Backup → Apply → Verify → (Rollback bei Fehler).

---

## Erweiterbarkeit: Web-Dashboard

Die `api/routes.py` ruft dieselbe Business Logic auf:

```python
# CLI
results = CheckRegistry().run_all(LocalConnection())
ConsoleReporter().display(results)

# API (zukünftig)
@app.get("/api/analyze")
async def analyze(server_id: str):
    conn = get_connection(server_id)
    results = CheckRegistry().run_all(conn)
    return [r.dict() for r in results]
```

---

## Datenfluss: Multi-Server

```
servers.yml
    │
    ▼
┌──────────┐   SSH    ┌──────────────┐
│  Mac CLI │ ───────▶ │ Hetzner CCX23│
│          │          │ Odoo 19 Ent. │
│ analyze  │ ◀─────── │              │
│ plan     │  Results │              │
│ apply    │ ───────▶ │  Files edit  │
└──────────┘          └──────────────┘
```

---

## ADR (Architecture Decision Records)

Entscheidungen werden in `docs/adr/` dokumentiert:

| ADR                                       | Entscheidung              |
|-------------------------------------------|---------------------------|
| [ADR-001](adr/ADR-001-typer-vs-click.md)  | Typer statt Click für CLI |

---

*Letzte Aktualisierung: 2026-03-04 01:26 Uhr (Vienna)*
