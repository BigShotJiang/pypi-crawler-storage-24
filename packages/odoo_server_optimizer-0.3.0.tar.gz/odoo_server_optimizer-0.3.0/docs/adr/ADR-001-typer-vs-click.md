# ADR-001: Typer statt Click für CLI

**Datum:** 2026-03-03
**Status:** Akzeptiert

## Kontext
Wir brauchen ein CLI-Framework für 4 Commands mit Sub-Options.

## Entscheidung
Typer (basiert auf Click) statt reinem Click.

## Begründung
- Type Hints werden automatisch zu CLI-Parametern
- Weniger Boilerplate
- Rich-Integration eingebaut
- Einfacher für zukünftige Entwickler verständlich

## Konsequenzen
- Python 3.9+ Pflicht (bereits erfüllt: 3.11+)
- Typer-spezifische Patterns lernen
