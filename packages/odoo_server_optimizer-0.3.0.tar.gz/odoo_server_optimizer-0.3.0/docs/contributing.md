# Entwicklung – odoo-server-optimizer

**Version:** 0.2.0
**Erstellt:** 2026-03-04 01:26 Uhr (Vienna)

---

## Voraussetzungen

- Python 3.11+
- Git

---

## Setup

```bash
# Repository klonen
git clone https://github.com/BERNHARD-KRENN-R-D/odoo-server-optimizer.git
cd odoo-server-optimizer

# Virtual Environment erstellen
python3 -m venv .venv
source .venv/bin/activate

# Entwicklungs-Dependencies installieren
pip install -e ".[dev]"
```

---

## Tests ausführen

```bash
# Alle Tests
pytest tests/ -v

# Einzelne Test-Datei
pytest tests/test_checks/test_workers.py -v

# Mit Coverage
pytest tests/ --cov=odoo_optimizer
```

---

## Linter

```bash
# Ruff prüfen
ruff check src/ tests/

# Ruff auto-fix
ruff check --fix src/ tests/
```

---

## Neuen Check hinzufügen

1. Neue Datei: `src/odoo_optimizer/checks/mein_check.py`
2. `BaseCheck` ableiten, `check_id`, `title`, `severity` setzen
3. `run(self, conn)` implementieren → `CheckResult` zurückgeben
4. In `checks/registry.py` → `ALL_CHECKS` Liste eintragen
5. Test schreiben: `tests/test_checks/test_mein_check.py`
6. `CHANGELOG.md` unter `[Unreleased]` eintragen

---

## Neuen Fixer hinzufügen

1. Neue Datei: `src/odoo_optimizer/fixers/mein_fixer.py`
2. `BaseFixer` ableiten, `fixer_id`, `check_ids` setzen
3. 5 Methoden implementieren: `plan()`, `backup()`, `apply()`, `verify()`, `rollback()`
4. In `fixers/registry.py` registrieren
5. Test schreiben: `tests/test_fixers/test_mein_fixer.py`
6. `CHANGELOG.md` unter `[Unreleased]` eintragen

---

## Commit-Konventionen

- **Typ-Präfix** auf Englisch: `feat:`, `fix:`, `docs:`, `test:`, `refactor:`, `chore:`
- **Beschreibung** auf Deutsch
- Beispiel: `feat: Nginx-Timeout-Fixer implementiert`

---

## Wichtige Regeln

- Business Logic (`checks/`, `calculators/`, `fixers/`) kennt NIEMALS `cli.py` oder `reporters/`
- Tests verwenden immer `MockConnection` — niemals echte Server-Verbindungen
- Keine Secrets im Code (Passwörter, SSH-Keys, API-Keys)
- Type Hints überall verwenden

---

*Erstellt: 2026-03-04 01:26 Uhr (Vienna)*
