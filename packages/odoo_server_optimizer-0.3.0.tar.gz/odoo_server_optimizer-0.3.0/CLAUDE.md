# CLAUDE.md – Anleitung für Claude AI

> Diese Datei ist die erste Anlaufstelle für Claude in jeder neuen Session.
> Sie enthält alles was Claude wissen muss um effektiv an diesem Projekt
> weiterzuarbeiten – ohne Kontextverlust.

---

## Sofort-Orientierung (30 Sekunden)

```bash
# 1. Wo bin ich?
cat SESSION_HANDOFF.md          # Aktueller Status + offene Punkte

# 2. Was wurde zuletzt gemacht?
git log --oneline -10

# 3. Aktuelle Zeit (IMMER vor Datei-Änderungen!)
TZ='Europe/Vienna' date '+%Y-%m-%d %H:%M Uhr (Vienna)'

# 4. Tests laufen noch?
cd /Users/bernhardkrenn/GitHub/odoo-server-optimizer
pip install -e ".[dev]" && pytest tests/ -v
```

---

## Projekt in einem Satz

Python CLI-Tool (`odoo-optimizer`) das Odoo 19 Enterprise Server automatisch
auf Konfigurationsprobleme prüft und halbautomatisch optimiert –
lokal oder remote via SSH, mit Bestätigung pro Schritt.

---

## Kontext: Warum dieses Projekt?

Bernhards Odoo-Server lief trotz konfigurierter Workers im Single-Threaded-Modus
(nur 1 CPU von 4 genutzt). Ursache: `.odoorc` überschrieb `odoo.conf`.
Dieses Tool verhindert solche Probleme automatisch – für diesen und
alle zukünftigen Odoo-Server (geplante Branchenlösung).

Basis: `docs/references/odoo19_worker_analyse_v1_0_0.md` (10 Befunde, 3 kritisch)

---

## Architektur (muss Claude kennen)

```
cli.py                      ← Einstiegspunkt (Typer, 4 Commands)
    │
    ├── checks/             ← NUR LESEN (Diagnose)
    │   ├── base.py         ← BaseCheck, CheckResult, Severity, Status
    │   ├── registry.py     ← Alle Checks registrieren + ausführen
    │   ├── workers.py      ← Befund 1+2 (Worker-Modus, Config-Datei)
    │   ├── database.py     ← Befund 3 (db_maxconn)
    │   ├── timeouts.py     ← Befund 4 (Timeout-Werte)
    │   ├── cron.py         ← Befund 5 (max_cron_threads)
    │   ├── deprecated.py   ← Befund 6 (longpolling_port)
    │   ├── config_values.py← Befund 7+8 (db_host, addons_path)
    │   └── system.py       ← Befund 9+10 (pdfminer, http_interface)
    │
    ├── calculators/        ← BERECHNEN (optimale Werte)
    │   ├── base.py         ← HardwareInfo, PostgresInfo, OptimizationPlan
    │   ├── hardware.py     ← CPU/RAM → Worker-Anzahl
    │   ├── postgres.py     ← max_connections → db_maxconn
    │   └── optimizer.py    ← Gesamtplan berechnen
    │
    ├── fixers/             ← SCHREIBEN (Änderungen anwenden)
    │   ├── base.py         ← BaseFixer mit Plan-Apply-Pattern
    │   ├── config.py       ← odoo.conf Parameter optimieren
    │   ├── odoorc.py       ← .odoorc deaktivieren
    │   ├── systemd.py      ← Service-Datei patchen
    │   ├── nginx.py        ← Nginx Proxy-Timeouts anpassen
    │   ├── swap.py         ← Swap-Datei einrichten (OOM-Schutz)
    │   └── registry.py     ← Fixer-Registry
    │
    ├── reporters/          ← AUSGEBEN (Console/Markdown)
    │   ├── console.py      ← Rich-Tabellen (analyze)
    │   ├── plan.py         ← Rich-Tabellen (plan/apply)
    │   └── markdown.py     ← Markdown-Report
    │
    ├── connection/         ← ABSTRAKTION (lokal/SSH)
    │   ├── base.py         ← AbstractConnection Interface
    │   ├── local.py        ← subprocess
    │   └── ssh.py          ← paramiko
    │
    └── config/
        ├── defaults.py     ← Odoo-Formeln, Schwellwerte
        └── servers.yml     ← Server-Profile
```

**Wichtigste Regel:** `checks/`, `calculators/`, `fixers/` kennen NIEMALS
`cli.py` oder `reporters/`. Business Logic ist vollständig entkoppelt.

---

## Implementierungs-Patterns

### Neuen Check hinzufügen

```python
# 1. Neue Datei: src/odoo_optimizer/checks/mein_check.py
class MeinCheck(BaseCheck):
    check_id = "mein_check"          # eindeutig, snake_case
    title = "Was wird geprüft"
    severity = Severity.CRITICAL     # oder WARNING / INFO

    def run(self, conn: AbstractConnection) -> CheckResult:
        output = conn.run("shell kommando").stdout
        if problem:
            return self._fail(
                message="Kurzbeschreibung",
                details={"ist": ..., "soll": ..., "befund": "Befund X"},
            )
        return self._pass(message="OK")

# 2. In checks/registry.py registrieren:
ALL_CHECKS = [..., MeinCheck]

# 3. Test schreiben: tests/test_checks/test_mein_check.py
# 4. SESSION_HANDOFF.md aktualisieren
# 5. CHANGELOG.md unter [Unreleased] eintragen
```

### Neuen Fixer hinzufügen

```python
class MeinFixer(BaseFixer):
    fixer_id = "mein_fixer"
    check_ids = ["mein_check"]   # Welche Checks werden behoben?

    def backup(self, conn): ...   # Datei sichern (Datum-Suffix!)
    def plan(self, conn): ...     # Änderung beschreiben
    def apply(self, conn): ...    # Änderung durchführen
    def verify(self, conn): ...   # Erfolg prüfen
    def rollback(self, conn, backup_path): ...  # Rückgängig machen
```

---

## Odoo-Wissen (kritisch für korrekte Implementierung)

### Worker-Formel (CCX23: 4 vCPU)
```
HTTP Workers = (CPU_Cores × 2) + 1 = 9
Cron Workers = 1
Gevent       = 1 (automatisch)
─────────────────────────────────
Gesamt       = 11 Prozesse
```

### db_maxconn Formel
```
db_maxconn × Gesamtprozesse < PostgreSQL max_connections
8          × 11              = 88 < 100  ✅
```

### Config-Datei Priorität (das Kernproblem!)
```
Odoo sucht in dieser Reihenfolge:
  1. ~/.odoorc          ← /opt/odoo/.odoorc ÜBERSCHREIBT alles!
  2. ~/.openerp_serverrc
  3. /etc/odoo/odoo.conf ← Gewünschte Datei (wird ignoriert!)

Fix: ExecStart=/usr/bin/odoo -c /etc/odoo/odoo.conf
```

### Ziel-Konfiguration (CCX23)
```ini
workers = 9
max_cron_threads = 1
db_maxconn = 8
limit_time_cpu = 600
limit_time_real = 1200
limit_time_real_cron = 3600
http_interface = 127.0.0.1
```

### Nginx Proxy-Timeouts (müssen zu Odoo passen!)

```ini
proxy_read_timeout    >= limit_time_real (1200s)
proxy_connect_timeout >= limit_time_cpu  (600s)
proxy_send_timeout    >= limit_time_cpu  (600s)

# Ohne: Nginx bricht Verbindung ab bevor Odoo fertig ist (z.B. lange Reports)
# Config: /etc/nginx/sites-available/odoo
# Nach Änderung: nginx -t && systemctl reload nginx
```

### Prozessanzahl im Worker-Modus
```bash
ps aux | grep '[o]doo' | wc -l
# Erwartung: 12 (1 Master + 9 HTTP + 1 Cron + 1 Gevent)
# Single-Threaded: 1 Prozess → Problem!
```

---

## Coding-Standards (Kurzfassung)

| Was | Wie |
|-----|-----|
| Sprache Dokumentation | Deutsch |
| Sprache Code/Variablen | Englisch |
| Sprache Commits | Deutsch |
| Timestamps | `TZ='Europe/Vienna' date '+%Y-%m-%d %H:%M Uhr (Vienna)'` |
| Versionierung | Major.Minor.Patch |
| Type Hints | Überall, mypy strict |
| Tests | Immer mit MockConnection, niemals echter Server |
| Commit-Format | `typ: kurze Beschreibung` (feat/fix/docs/test/refactor) |

---

## Pflicht-Updates nach jeder Änderung

Nach jeder substantiellen Änderung diese Dateien aktualisieren:

1. **`SESSION_HANDOFF.md`** – Status-Checkboxen, nächste Schritte
2. **`CHANGELOG.md`** – Unter `[Unreleased]` eintragen
3. **Timestamp** – Immer aktuelle Wiener Zeit verwenden

---

## Server-Infrastruktur (Referenz)

| Komponente | Wert |
|-----------|------|
| Server | Hetzner CCX23 · 4 vCPU · 16 GB RAM |
| OS | Ubuntu 24.04 |
| Odoo | 19 Enterprise (19.0+e-20260225) |
| PostgreSQL | 16 · max_connections = 100 |
| Nginx | Reverse Proxy · SSL via Let's Encrypt |
| Domain | bernhardkrenn.cc |
| SSH-User | adminbk |
| Odoo-User | odoo · Home: /opt/odoo |

---

## Häufige Fehler vermeiden

❌ **Nicht tun:**
```python
# Timestamps schätzen
"Erstellt: 2026-03-03"   # Woher weißt du die Zeit?

# Secrets im Code
ssh_key = "-----BEGIN OPENSSH..."

# Business Logic im CLI
@app.command()
def analyze():
    if "workers" not in config:   # FALSCH – gehört in checks/
        ...

# Echter Server in Tests
conn = SSHConnection("bernhardkrenn.cc", ...)  # NIEMALS in Tests!
```

✅ **So machen:**
```python
# Zeit immer ermitteln
conn.run("TZ='Europe/Vienna' date '+%Y-%m-%d %H:%M Uhr (Vienna)'")

# Tests immer mocken
conn = MockConnection(responses={"ps aux ...": "1"})

# CLI ruft nur Business Logic auf
results = run_all_checks(conn)
display_results(results)
```

---

## Referenz-Dokumente

| Datei | Wann lesen |
|-------|-----------|
| `SESSION_HANDOFF.md` | Jeder Session-Start |
| `QUALITY.md` | Vor jedem Commit |
| `docs/architecture.md` | Bei Architektur-Fragen |
| `docs/references/odoo19_worker_analyse_v1_0_0.md` | Bei Check-Implementierung |
| `tests/fixtures/odoo.conf.problematic` | Als Referenz für Testdaten |

---

*Erstellt: 2026-03-03 23:15 Uhr (Vienna)*
*Aktualisiert: 2026-03-09 02:03 Uhr (Vienna) — v0.2.0 + NginxFixer + SwapFixer*
*Dieses Dokument bei jeder Major/Minor-Version aktualisieren*
