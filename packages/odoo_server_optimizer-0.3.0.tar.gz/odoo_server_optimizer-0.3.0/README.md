# odoo-server-optimizer

**Odoo 19 Enterprise – Server Diagnose & Automatische Optimierung**

Ein Python-basiertes CLI-Tool, das Odoo-Installationen auf Konfigurationsprobleme prüft
und die Optimierung halbautomatisch (mit Bestätigung pro Schritt) durchführt.

[![Python](https://img.shields.io/badge/Python-3.11+-blue)](https://python.org)
[![Odoo](https://img.shields.io/badge/Odoo-19%20Enterprise-purple)](https://odoo.com)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)
[![Tests](https://img.shields.io/badge/Tests-112%2F112-brightgreen)]()

---

## Funktionsumfang

| Command | Beschreibung |
|---------|--------------|
| `analyze` | Server prüfen – alle Befunde anzeigen |
| `plan` | Optimalen Zielzustand berechnen (ohne Änderungen) |
| `apply` | Fixes halbautomatisch anwenden (Bestätigung pro Schritt) |
| `report` | Diagnose-Bericht als Markdown oder Konsole ausgeben |

## Unterstützte Checks (alle 10 Befunde)

| # | Check | Schwere |
|---|-------|---------|
| 1 | Workers aktiv? (Single-Threaded vs. Multi-Worker) | Kritisch |
| 2 | Config-Datei korrekt? (`.odoorc` vs. `odoo.conf`) | Kritisch |
| 3 | `db_maxconn` vs. PostgreSQL `max_connections` | Kritisch |
| 4 | Timeout-Werte (`limit_time_cpu`, `limit_time_real`) | Warnung |
| 5 | `max_cron_threads` Optimierung | Warnung |
| 6 | Veraltete Parameter (`longpolling_port`) | Warnung |
| 7 | `db_host = False` erkennen | Warnung |
| 8 | `addons_path` gesetzt? | Warnung |
| 9 | `pdfminer.six` installiert? | Warnung |
| 10 | `http_interface = 127.0.0.1`? | Kritisch |

## Fixer (Plan-Apply-Pattern)

| Fixer | Beschreibung |
|-------|-------------|
| `ConfigFixer` | odoo.conf Parameter optimieren (workers, timeouts, memory, ...) |
| `OdooRcFixer` | `.odoorc` deaktivieren (umbenennen) |
| `SystemdFixer` | Service-Datei um `-c /etc/odoo/odoo.conf` ergänzen |
| `NginxFixer` | Nginx Proxy-Timeouts an Odoo-Werte anpassen |
| `SwapFixer` | Swap-Datei einrichten/vergrößern für OOM-Schutz |

Jeder Fixer folgt dem 5-Schritte-Lifecycle: **plan → backup → apply → verify → rollback**

## Schnellstart

```bash
# Installation
pip install odoo-server-optimizer

# Lokale Analyse
odoo-optimizer analyze

# Remote-Analyse (via SSH)
odoo-optimizer analyze --server=prod

# Plan anzeigen (keine Änderungen)
odoo-optimizer plan --server=prod

# Halbautomatisch anwenden
odoo-optimizer apply --server=prod

# Markdown-Bericht erstellen
odoo-optimizer report --server=prod --format=md
```

## Server-Profile

Server werden in `config/servers.yml` konfiguriert:

```yaml
servers:
  prod:
    host: bernhardkrenn.cc
    user: adminbk
    ssh_key: ~/.ssh/id_ed25519
    odoo_conf: /etc/odoo/odoo.conf
    service_name: odoo
```

## Architektur

Siehe [`docs/architecture.md`](docs/architecture.md)

## Entwicklung

Siehe [`docs/contributing.md`](docs/contributing.md)

---

*Entwickelt für BERNHARD KRENN, Hairstyling & Barbershop*
*Odoo 19 Enterprise · Hetzner CCX23 · Ubuntu 24.04*
