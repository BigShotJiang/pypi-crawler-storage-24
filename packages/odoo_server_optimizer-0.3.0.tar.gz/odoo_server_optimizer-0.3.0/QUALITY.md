# Qualitätsstandards – odoo-server-optimizer

> Vor jedem Commit und vor jeder neuen Feature-Implementierung diese
> Checkliste durchgehen.

---

## Code-Standards

### Python
- Python 3.11+ (kein Legacy-Code)
- Type Hints überall (mypy strict mode)
- Docstrings für alle öffentlichen Klassen und Methoden (Google-Style)
- Zeilenlänge: max. 100 Zeichen (ruff konfiguriert)
- Keine `print()` Statements – immer `rich.console` oder Logging

### Namenskonventionen
| Bereich | Konvention | Beispiel |
|---------|-----------|---------|
| Klassen | PascalCase | `WorkerCheck`, `LocalConnection` |
| Funktionen | snake_case | `check_workers()`, `apply_fix()` |
| Konstanten | UPPER_SNAKE | `DEFAULT_WORKERS`, `MAX_DB_CONN` |
| Dateien | snake_case | `workers.py`, `base_check.py` |
| Variablen | snake_case | `check_result`, `server_config` |

### Commits
- Sprache: **Deutsch**
- Format: `typ: kurze Beschreibung` (max. 72 Zeichen)
- Typen: `feat`, `fix`, `docs`, `test`, `refactor`, `chore`
- Beispiel: `feat: Worker-Check für Befund 1+2 implementiert`
- Timestamps in Commit-Messages: `TZ='Europe/Vienna' date`

---

## Sicherheitsstandards

### Kritisch – NIEMALS im Code
- [ ] Keine Passwörter, Hashes oder SSH-Keys im Code
- [ ] Keine echten Server-IPs oder Hostnamen (Beispieldaten verwenden)
- [ ] Keine PostgreSQL-Credentials hardcoded
- [ ] `admin_passwd` Hash niemals in Logs ausgeben

### Vor jedem Apply-Schritt
- [ ] Backup der zu ändernden Datei erstellt
- [ ] Backup-Pfad dem User angezeigt
- [ ] Rollback-Möglichkeit vorhanden
- [ ] Bestätigung des Users eingeholt (außer `--dry-run`)

### SSH-Verbindungen
- [ ] Nur Key-Auth, niemals Passwort
- [ ] Host-Fingerprint beim ersten Connect bestätigen
- [ ] Timeout konfiguriert (kein endloser Connect-Versuch)

---

## Test-Standards

### Abdeckung
- Ziel: **>80% Coverage** für alle `checks/` und `calculators/`
- Fixers: **>70% Coverage** (schwieriger zu mocken)

### Test-Typen
```
tests/
├── test_checks/      # Unit-Tests mit Mock-Connection
├── test_calculators/ # Pure-Function Tests (keine Mocks nötig)
├── test_fixers/      # Integration-Tests mit Filesystem-Fixtures
└── fixtures/         # Beispiel-Configs (mit und ohne Probleme)
```

### Mock-Prinzip
Alle Checks werden mit `MockConnection` getestet:
```python
# RICHTIG – immer mocken
conn = MockConnection(responses={"cat /etc/odoo/odoo.conf": SAMPLE_CONFIG})
result = WorkerCheck(conn).run()

# FALSCH – niemals echten Server in Tests ansprechen
conn = SSHConnection(host="bernhardkrenn.cc", ...)
```

---

## Dokumentations-Standards

### Pflicht-Dateien (immer aktuell halten)
- [ ] `README.md` – Quickstart und Feature-Übersicht
- [ ] `SESSION_HANDOFF.md` – Status und nächste Schritte
- [ ] `CHANGELOG.md` – Jede Version dokumentiert
- [ ] `docs/architecture.md` – Architektur-Entscheidungen

### Timestamps
**IMMER** die aktuelle Wiener Zeit verwenden:
```bash
TZ='Europe/Vienna' date '+%Y-%m-%d %H:%M Uhr (Vienna)'
```
Niemals Uhrzeiten schätzen oder aus dem Gedächtnis eintragen!

### Versionierung
Format: `Major.Minor.Patch`
- **Major:** Grundlegende Umstrukturierung (Breaking Changes)
- **Minor:** Neue Checks, Commands oder Features
- **Patch:** Bugfixes, kleine Korrekturen

---

## Check-Implementierungs-Checkliste

Für jeden neuen Check:

- [ ] Klasse erbt von `BaseCheck`
- [ ] `check_id`, `title`, `severity` definiert
- [ ] `run(conn)` Methode implementiert
- [ ] `CheckResult` mit `status`, `message`, `details` zurückgegeben
- [ ] Entsprechender Fixer in `fixers/` vorhanden
- [ ] Unit-Test mit MockConnection geschrieben
- [ ] Fixture-Config (mit Problem) in `tests/fixtures/` vorhanden
- [ ] In `checks/registry.py` registriert
- [ ] In `SESSION_HANDOFF.md` als ✅ markiert

---

## Fixer-Implementierungs-Checkliste

Für jeden neuen Fixer:

- [ ] Klasse erbt von `BaseFixer`
- [ ] `backup()` erstellt datierte Sicherungskopie
- [ ] `plan()` beschreibt Änderung ohne anzuwenden
- [ ] `apply()` führt Änderung durch
- [ ] `verify()` prüft ob Änderung erfolgreich war
- [ ] `rollback()` stellt Backup wieder her
- [ ] In `fixers/registry.py` registriert

---

## Release-Checkliste

Vor einem neuen Release:

- [ ] `CHANGELOG.md` aktualisiert
- [ ] `pyproject.toml` Version erhöht
- [ ] `SESSION_HANDOFF.md` Status aktualisiert
- [ ] Alle Tests grün (`pytest`)
- [ ] Kein Linting-Fehler (`ruff check .`)
- [ ] Type-Checks ok (`mypy src/`)
- [ ] `git tag v0.x.x` gesetzt
- [ ] `git push --tags`

---

*Erstellt: 2026-03-03 10:35 Uhr (Vienna)*
