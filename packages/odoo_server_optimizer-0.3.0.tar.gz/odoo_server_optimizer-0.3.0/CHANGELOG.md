# Changelog

Alle wichtigen Änderungen an diesem Projekt werden in dieser Datei dokumentiert.

Format: [Keep a Changelog](https://keepachangelog.com/de/1.0.0/)
Versionierung: **Major.Minor.Patch**

| Typ | Bedeutung |
|-----|-----------|
| **Major** | Grundlegende Umstrukturierung, Breaking Changes |
| **Minor** | Neue Checks, Commands, Features |
| **Patch** | Bugfixes, kleine Korrekturen, Dokumentation |

---

## [Unreleased]

*Keine Änderungen*

---

## [0.3.0] – 2026-03-09

### Hinzugefügt

#### Fixer

- `fixers/nginx.py` – `NginxFixer`: Nginx Proxy-Timeouts (proxy_read_timeout, proxy_connect_timeout, proxy_send_timeout) an Odoo-Werte anpassen
- `fixers/swap.py` – `SwapFixer`: Swap-Datei einrichten/vergrößern für OOM-Schutz (Swap = RAM, swappiness = 10)
- `config/defaults.py` – Nginx- und Swap-Konstanten

#### FastAPI Web-Dashboard

- `api/app.py` – Vollständiges Web-Dashboard mit 4 Endpoints: `/api/health`, `/api/status`, `/api/history`, `/api/analyze`
- API-Key-Authentifizierung via `ODOO_OPTIMIZER_API_KEY` Umgebungsvariable
- JSON-Persistenz der Analyse-Historie (max. 50 Einträge) via `ODOO_OPTIMIZER_DATA_DIR`
- Visuelles HTML-Dashboard mit Ergebnisanzeige, Check-Übersicht und Analyse-Button

#### Reporter

- `reporters/markdown.py` – Markdown-Reporter vollständig implementiert (Header, Ergebnis-Tabelle, Detail-Sektion, Footer)

#### Tests

- 14 neue Tests für SwapFixer + 13 für NginxFixer
- 14 Tests für FastAPI-Dashboard (Health, Status, History, Auth, Dashboard)
- 16 Tests für Markdown-Reporter — **Gesamt: 120 Tests**

### Geändert

- `api/app.py` – Konfiguration (API_KEY, DATA_DIR) wird zur Laufzeit aus `os.environ` gelesen statt als Module-Level-Variable (behebt Test-Isolation)
- `cli.py` – Type-Hint-Verbesserungen (Rückgabetypen für `_get_connection`, `_run_calculators`, `_create_fix_plans`)
- `config/servers.py` – Type-Hint-Verbesserungen (`dict[str, Any]` statt `dict`)
- `pyproject.toml` – `httpx` zu api-Dependencies hinzugefügt

### Behoben

- 6 fehlschlagende API-Tests durch Umstellung auf Laufzeit-Umgebungsvariablen behoben

---

## [0.2.0] – 2026-03-04

### Hinzugefügt

#### Checks (Befund 3–10)
- `checks/database.py` – `DatabaseConnectionCheck`: db_maxconn vs. PostgreSQL max_connections (Befund 3)
- `checks/timeouts.py` – `TimeoutCheck`: limit_time_cpu/real Werte prüfen (Befund 4)
- `checks/cron.py` – `CronThreadsCheck`: max_cron_threads Optimierung (Befund 5)
- `checks/deprecated.py` – `DeprecatedParamsCheck`: veraltete Parameter wie longpolling_port (Befund 6)
- `checks/config_values.py` – `ConfigValuesCheck`: False-Werte, fehlende addons_path (Befund 7+8)
- `checks/system.py` – `SystemDependenciesCheck`, `HttpInterfaceCheck`: pdfminer.six, http_interface (Befund 9+10)

#### Calculators
- `calculators/base.py` – Dataclasses: `HardwareInfo`, `PostgresInfo`, `OptimizationPlan`
- `calculators/hardware.py` – CPU/RAM auslesen, Worker-Anzahl berechnen (CPU × 2 + 1)
- `calculators/postgres.py` – PostgreSQL max_connections + Version auslesen, sicheren db_maxconn berechnen
- `calculators/optimizer.py` – Gesamtplan aus Hardware- und PostgreSQL-Daten berechnen

#### Fixer (Plan-Apply-Pattern)
- `fixers/config.py` – `ConfigFixer`: odoo.conf Parameter setzen/ändern/entfernen (deprecated)
- `fixers/odoorc.py` – `OdooRcFixer`: .odoorc → .odoorc.disabled.DATUM umbenennen
- `fixers/systemd.py` – `SystemdFixer`: ExecStart um -c /etc/odoo/odoo.conf ergänzen + daemon-reload
- `fixers/registry.py` – Fixer-Registry mit Ausführungsreihenfolge

#### CLI
- `plan` Command vollständig implementiert (Calculators + Fixer-Plans + Rich-Anzeige)
- `apply` Command vollständig implementiert (Bestätigung pro Fixer, Backup/Apply/Verify/Rollback)

#### Reporter
- `reporters/plan.py` – Rich-formatierte Plan-Anzeige (Hardware-Panel, PostgreSQL-Panel, Änderungen-Tabelle)

#### Tests
- 26 neue Tests für Fixer (config: 10, odoorc: 7, systemd: 9)
- 22 neue Tests für Checks (Befund 3–10)
- 8 neue Tests für Calculators (hardware: 4, postgres: 4, optimizer: 4) — **Gesamt: 63 Tests**

### Geändert
- `checks/base.py` – `str, Enum` → `StrEnum` (Lint-Fix)
- `cli.py` – `Optional[str]` → `str | None`, Import-Sortierung (Lint-Fix)

### Geplant für v0.3.0
- ~~Fixer: `nginx.py`~~ — erledigt (siehe Unreleased)
- ~~Fixer: `swap.py`~~ — erledigt (siehe Unreleased)
- FastAPI Web-Dashboard Grundgerüst
- Markdown-Reporter vollständig implementieren
- Multi-Server-Verwaltung über `servers.yml`

---

## [0.1.0] – 2026-03-03

### Hinzugefügt

#### Projektstruktur
- Initiale Verzeichnisstruktur nach `src`-Layout
- `pyproject.toml` mit allen Dependencies (Typer, Rich, Paramiko, PyYAML)
- GitHub Actions CI-Pipeline (Lint + Test, Python 3.11 + 3.12)
- `.gitignore` mit Python-, macOS- und Odoo-spezifischen Einträgen

#### Fundament-Klassen
- `connection/base.py` – `AbstractConnection` Interface mit `CommandResult`
- `connection/local.py` – `LocalConnection` via subprocess
- `connection/ssh.py` – `SSHConnection` via paramiko (nur Key-Auth)
- `checks/base.py` – `BaseCheck`, `CheckResult`, `Severity`, `Status` Enums
- `fixers/base.py` – `BaseFixer` mit Plan-Apply-Pattern (backup/apply/verify/rollback)

#### Checks (implementiert)
- `checks/workers.py` – `WorkersModeCheck` (Befund 1: Single-Threaded-Modus)
- `checks/workers.py` – `ConfigFileCheck` (Befund 2: Falsche Config-Datei)
- `checks/registry.py` – Check-Registry für zentralen Aufruf

#### CLI
- `cli.py` – Typer-Grundgerüst mit 4 Commands: `analyze`, `plan`, `apply`, `report`
- `analyze` – vollständig funktionsfähig
- `plan`, `apply` – Skeleton, Implementierung folgt in v0.2.0

#### Reporter
- `reporters/console.py` – Rich-formatierte Tabellen mit Farben und Status-Emojis
- `reporters/markdown.py` – Markdown-Stub (vollständig in v0.2.0)

#### Konfiguration
- `config/defaults.py` – Odoo-Standardwerte, Worker-Formel, Timeout-Werte
- `config/servers.yml` – Server-Profile (lokal + SSH)
- `config/servers.py` – YAML-Loader für Server-Profile

#### Tests
- `tests/conftest.py` – `MockConnection`, Fixtures für beide Modi
- `tests/test_checks/test_workers.py` – 5 Unit-Tests für Worker-Checks
- `tests/fixtures/odoo.conf.problematic` – Beispiel-Config mit allen 10 Problemen
- `tests/fixtures/odoo.conf.optimal` – Ziel-Config nach Optimierung

#### Dokumentation
- `README.md`, `CHANGELOG.md`, `LICENSE`, `SECURITY.md`, `CLAUDE.md`
- `SESSION_HANDOFF.md`, `QUALITY.md`, `SKILL.md`
- `docs/architecture.md`, `docs/adr/ADR-001-typer-vs-click.md`
- `docs/references/odoo19_worker_analyse_v1_0_0.md`

---

## Versionshistorie auf einen Blick

| Version | Datum | Highlights |
|---------|-------|------------|
| 0.1.0 | 2026-03-03 | Projektfundament, 2 Checks, CLI-Grundgerüst |
| 0.2.0 | 2026-03-04 | Alle 10 Checks + Calculators + 3 Fixer + plan/apply |
| 0.3.0 | 2026-03-09 | Nginx/Swap-Fixer, FastAPI Web-Dashboard, Markdown-Reporter, 120 Tests |
| 1.0.0 | geplant | Erster stabiler Release, vollständige Dokumentation |

---

*Erstellt: 2026-03-03 23:15 Uhr (Vienna)*
*Aktualisiert: 2026-03-09 02:43 Uhr (Vienna)*
*Format: [Keep a Changelog](https://keepachangelog.com/de/1.0.0/) · [Semantic Versioning](https://semver.org/lang/de/)*
