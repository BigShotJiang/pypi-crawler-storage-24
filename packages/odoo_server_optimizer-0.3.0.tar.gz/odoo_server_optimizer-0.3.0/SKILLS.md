# SKILLS.md – Wiederverwendbare Patterns & Technologien

> **Version:** 1.1.0
> **Erstellt:** 2026-03-09 01:42 Uhr (Vienna)
> **Aktualisiert:** 2026-03-09 02:18 Uhr (Vienna)

Bewährte Patterns und Technologien aus diesem Projekt, übertragbar auf andere.

---

## Tech-Stack

| Komponente | Version | Rolle |
|-----------|---------|-------|
| Python | 3.11+ | Kernsprache |
| Typer | 0.x | CLI-Framework (Click-Basis, Type Hints) |
| Rich | 13.x | Terminal-Tabellen, Panels, Fortschrittsbalken |
| Paramiko | 3.x | SSH-Verbindungen (nur Key-Auth) |
| PyYAML | 6.x | Server-Profile laden |
| pytest | 9.x | Unit-Tests mit MockConnection |
| ruff | 0.x | Linter + Formatter (ersetzt flake8/isort/black) |
| GitHub Actions | CI | Lint + Test (Python 3.11 + 3.12) |

---

## Pattern 1: Plan-Apply mit Rollback

**Wann:** Konfigurationsdateien auf Remote-Servern ändern
**Problem:** Änderungen können fehlschlagen und System in inkonsistentem Zustand hinterlassen
**Lösung:** 5-Schritt-Lifecycle mit Bestätigung pro Schritt

```python
class BaseFixer(ABC):
    def plan(self, conn) -> FixPlan:    # 1. Zeigen was passiert (read-only)
    def backup(self, conn) -> str:      # 2. Sicherungskopie mit Datum-Suffix
    def apply(self, conn) -> bool:      # 3. Änderung durchführen
    def verify(self, conn) -> bool:     # 4. Erfolg prüfen
    def rollback(self, conn, path):     # 5. Bei Fehler: Backup wiederherstellen
```

**Klassenattribute:** Jeder Fixer definiert `fixer_id`, `title`, `check_ids` als Klassen-Level-Attribute.

**Datenmodell:**

```python
@dataclass
class FixStep:
    description: str          # Was wird geändert?
    file_path: str | None     # Welche Datei?
    backup_path: str | None   # Backup-Pfad
    changes: list[str]        # Konkrete Änderungsschritte

@dataclass
class FixPlan:
    fixer_id: str
    title: str
    steps: list[FixStep]
    check_ids: list[str]
    requires_restart: bool = False
    requires_sudo: bool = True
```

**Hilfsmethoden in BaseFixer:**

- `_make_backup_path(path, conn)` → generiert `pfad.bak.YYYYMMDD_HHMM`
- `_empty_plan()` → leerer FixPlan (Convention für "nichts zu tun")

**Bewährt:** Terraform-inspiriert, User behält Kontrolle, Rollback immer möglich.

---

## Pattern 2: Connection-Abstraktion (lokal/SSH)

**Wann:** Tool soll lokal und remote identisch funktionieren
**Problem:** Business Logic darf nicht wissen, ob lokal oder SSH
**Lösung:** AbstractConnection mit run/read_file/write_file/copy_file/file_exists

```python
class AbstractConnection(ABC):
    def run(self, cmd: str) -> CommandResult: ...
    def read_file(self, path: str) -> str: ...
    def write_file(self, path: str, content: str) -> None: ...
    def file_exists(self, path: str) -> bool: ...
    def copy_file(self, src: str, dst: str) -> None: ...
```

**Context-Manager:** `close()` + `__enter__`/`__exit__` implementiert → `with conn:` Pattern.

**CommandResult:** Dataclass mit `stdout`, `stderr`, `returncode` + `success`-Property.

**Test-Vorteil:** `MockConnection` mit `responses`-Dict → kein echter Server nötig.

---

## Pattern 3: MockConnection für Tests

**Wann:** Server-Interaktionen testen ohne echten Server
**Problem:** Tests dürfen nicht von externen Systemen abhängen
**Lösung:** Dict-basierte Mock-Antworten

```python
class MockConnection(AbstractConnection):
    def __init__(self, responses: dict[str, str] | None = None):
        self.responses = responses or {}
        self.executed_commands: list[str] = []
        self.written_files: dict[str, str] = {}

    def run(self, cmd):
        self.executed_commands.append(cmd)
        return CommandResult(stdout=self.responses.get(cmd, ""), ...)

    def read_file(self, path):
        if path in self.responses:
            return self.responses[path]
        raise FileNotFoundError(...)
```

**Test-Assertions über Seiteneffekte:**

```python
# Prüfen welche Kommandos ausgeführt wurden
assert "nginx -t" in conn.executed_commands
assert "systemctl reload nginx" in conn.executed_commands

# Reihenfolge prüfen
assert conn.executed_commands.index("nginx -t") < conn.executed_commands.index("systemctl reload nginx")

# Geschriebene Dateien prüfen
written = conn.written_files["/etc/odoo/odoo.conf"]
assert "workers = 9" in written
```

**Hilfs-Factory in Tests:**

```python
def _make_conn(**extra_responses):
    """MockConnection mit Standard-Responses + Extras."""
    responses = {"TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500"}
    responses.update(extra_responses)
    return MockConnection(responses=responses)
```

**Bewährt:** Gleicher Dict für Kommando-Antworten und Dateiinhalte → einfach zu verwenden.

---

## Pattern 4: Regex-basierte Config-Manipulation

**Wann:** Konfigurationsdateien (INI, Nginx, systemd) programmatisch ändern
**Problem:** Werte setzen, aktualisieren oder entfernen ohne Parser-Bibliothek
**Lösung:** `re.subn` mit `re.MULTILINE` + Fallback-Insert

```python
def _set_directive(self, content, directive, value):
    pattern = rf"(^\s*){re.escape(directive)}\s+\d+s?\s*;"
    replacement = rf"\g<1>{directive} {value}s;"
    new_content, count = re.subn(pattern, replacement, content, count=1, flags=re.MULTILINE)
    if count > 0:
        return new_content
    # Fallback: vor proxy_pass einfügen
    ...
```

**Wichtig:** `re.subn` gibt `(neuer_text, anzahl_ersetzungen)` zurück — `count > 0` prüft ob etwas geändert wurde. Immer `count=1` setzen um nur das erste Vorkommen zu ersetzen.

**Bewährt:** Funktioniert für Nginx, odoo.conf, systemd-Units. `\g<1>` bewahrt Einrückung.

---

## Pattern 5: Registry-Pattern für Plugin-Architektur

**Wann:** Erweiterbare Liste von Checks/Fixern/Plugins
**Problem:** Neue Module hinzufügen ohne bestehenden Code zu ändern
**Lösung:** Zentrale Liste + Import in registry.py

```python
# checks/registry.py
ALL_CHECKS = [WorkersModeCheck, ConfigFileCheck, DatabaseCheck, ...]

# fixers/registry.py
ALL_FIXER_CLASSES = [OdooRcFixer, SystemdFixer, NginxFixer, SwapFixer]
# ConfigFixer separat (benötigt Parameter)
```

**Bewährt:** Reihenfolge in der Liste = Ausführungsreihenfolge. Einfach erweiterbar.

---

## Pattern 6: Schichten-Trennung (checks → calculators → fixers → reporters)

**Wann:** Diagnose-/Optimierungs-Tools mit mehreren Phasen
**Problem:** Business Logic und Darstellung vermischen sich
**Lösung:** Strikte Abhängigkeitsrichtung: checks/calculators/fixers kennen NIEMALS cli/reporters

```
cli.py  →  checks/      (nur lesen)
        →  calculators/  (berechnen)
        →  fixers/       (schreiben)
        →  reporters/    (darstellen)
```

**Bewährt:** Jede Schicht einzeln testbar, CLI austauschbar (FastAPI Web-Dashboard implementiert).

---

## Pattern 7: Idempotente Operationen

**Wann:** Fixer/Skripte die mehrfach ausgeführt werden können
**Problem:** Doppelte Einträge, Fehler bei erneuter Ausführung
**Lösung:** Vor jeder Änderung prüfen ob sie schon angewendet wurde

```python
# SwapFixer: fstab-Eintrag nur hinzufügen wenn nicht vorhanden
fstab = conn.read_file("/etc/fstab")
if self._swap_path not in fstab:
    conn.write_file("/etc/fstab", fstab + fstab_line)

# NginxFixer: Content-Vergleich vor Schreibvorgang
current = conn.read_file(config_path)
if "proxy_read_timeout 1200s" in current:
    return self._empty_plan()  # Schon optimal → nichts tun
```

**Bewährt:** `plan()` gibt leeren Plan zurück wenn nichts zu tun ist → CLI überspringt den Fixer automatisch.

---

## Pattern 8: Parametrisierte Fixer mit Auto-Detection

**Wann:** Fixer deren Zielwerte von der Hardware abhängen
**Problem:** Hardcodierte Werte passen nicht auf alle Server
**Lösung:** `None` als Default → automatische Erkennung via Connection

```python
class SwapFixer(BaseFixer):
    def __init__(self, target_swap_gb: int | None = None):
        self._target_swap_gb = target_swap_gb  # None = auto

    def _resolve_target_gb(self, conn) -> int:
        if self._target_swap_gb is not None:
            return self._target_swap_gb  # Explizit gesetzt
        return self._get_ram_gb(conn)    # Auto: Swap = RAM-Größe
```

**Bewährt:** Explizite Werte für Tests (`SwapFixer(target_swap_gb=16)`), automatische Erkennung in Produktion.

---

## Pattern 9: Fehlertolerante Registry

**Wann:** Mehrere unabhängige Checks/Operationen nacheinander ausführen
**Problem:** Ein fehlerhafter Check darf nicht die gesamte Analyse abbrechen
**Lösung:** Exception pro Check fangen, als `Status.ERROR` weitermelden

```python
def run_all_checks(conn):
    results = []
    for check_class in ALL_CHECKS:
        try:
            result = check_class().run(conn)
            results.append(result)
        except Exception as e:
            results.append(CheckResult(
                check_id=check.check_id,
                status=Status.ERROR,
                message=f"Check-Fehler: {e}",
            ))
    return results
```

**Bewährt:** Benutzer sieht alle Ergebnisse + welche Checks fehlgeschlagen sind, statt nur eine Traceback.

---

## Anti-Patterns (aus Erfahrung)

### Dual-Flag-Erkennung nicht vergessen
Wenn ein Parameter sowohl als Kurz- (`-c`) als auch als Langform (`--config`) existiert,
müssen BEIDE Varianten geprüft werden. Sonst schlagen Tests fehl.

### Backup-Pfad mit Datum-Suffix
Immer `datei.bak.YYYYMMDD_HHMM` statt `datei.bak` — mehrere Backups möglich, keine Überschreibung.

### Nach Config-Änderung immer Service reloaden
- systemd: `systemctl daemon-reload`
- Nginx: `nginx -t && systemctl reload nginx`
- Odoo: Service-Restart (nicht reload)

### Leere MockConnection-Responses
Wenn `MockConnection()` ohne `responses` erstellt wird, gibt `run()` immer leere Strings zurück und `read_file()` wirft `FileNotFoundError`. Das ist gewollt für Fehlerfall-Tests, aber ein häufiger Stolperstein wenn man vergisst Response-Daten mitzugeben.

---

*Erstellt: 2026-03-09 01:42 Uhr (Vienna)*
*Aktualisiert: 2026-03-09 02:18 Uhr (Vienna)*
