"""Unit-Tests für den Markdown-Reporter."""


from odoo_optimizer.checks.base import CheckResult, Severity, Status
from odoo_optimizer.reporters.markdown import generate_markdown, save_markdown


def _make_results() -> list[CheckResult]:
    """Beispiel-CheckResults für Tests erstellen."""
    return [
        CheckResult(
            check_id="workers_active",
            title="Workers aktiv?",
            severity=Severity.CRITICAL,
            status=Status.FAIL,
            message="Server läuft im Single-Threaded-Modus",
            details={"ist": 1, "soll": 12, "befund": "Befund 1"},
            fix_available=True,
        ),
        CheckResult(
            check_id="config_file",
            title="Richtige Config-Datei?",
            severity=Severity.CRITICAL,
            status=Status.PASS,
            message="Config-Datei korrekt: /etc/odoo/odoo.conf",
        ),
        CheckResult(
            check_id="db_maxconn",
            title="db_maxconn korrekt?",
            severity=Severity.WARNING,
            status=Status.FAIL,
            message="db_maxconn zu hoch (64 statt 8)",
            details={"ist": 64, "soll": 8},
            fix_available=True,
        ),
        CheckResult(
            check_id="pdfminer",
            title="pdfminer.six installiert?",
            severity=Severity.INFO,
            status=Status.SKIP,
            message="Check übersprungen",
        ),
    ]


class TestGenerateMarkdown:
    """Tests für generate_markdown()."""

    def test_enthaelt_header(self):
        """Bericht enthält Titel und Server-Name."""
        results = _make_results()
        md = generate_markdown(results, server_name="test-server")

        assert "# Odoo Server Diagnose" in md
        assert "**Server:** test-server" in md

    def test_enthaelt_zusammenfassung(self):
        """Zusammenfassung zeigt korrekte Zahlen."""
        results = _make_results()
        md = generate_markdown(results)

        assert "## Zusammenfassung" in md
        assert "| 4 | 1 | 2 | 1 | 1 |" in md

    def test_enthaelt_ergebnis_tabelle(self):
        """Detail-Tabelle enthält alle Checks."""
        results = _make_results()
        md = generate_markdown(results)

        assert "## Ergebnisse" in md
        assert "Workers aktiv?" in md
        assert "Richtige Config-Datei?" in md
        assert "db_maxconn korrekt?" in md
        assert "pdfminer.six installiert?" in md

    def test_status_icons_korrekt(self):
        """Richtige Status-Icons werden verwendet."""
        results = _make_results()
        md = generate_markdown(results)

        assert "✅" in md  # PASS
        assert "❌" in md  # FAIL
        assert "⏭️" in md  # SKIP

    def test_severity_icons_nur_bei_fail(self):
        """Severity-Icons nur bei fehlgeschlagenen Checks."""
        results = [
            CheckResult(
                check_id="test_pass",
                title="Test OK",
                severity=Severity.CRITICAL,
                status=Status.PASS,
                message="Alles gut",
            ),
        ]
        md = generate_markdown(results)
        # Bei PASS soll "–" statt Severity-Icon stehen
        assert "| – |" in md

    def test_severity_icons_bei_fail(self):
        """Severity-Icons bei fehlgeschlagenen Checks korrekt."""
        results = _make_results()
        md = generate_markdown(results)

        assert "🔴" in md  # CRITICAL
        assert "🟡" in md  # WARNING

    def test_details_section_fuer_fails(self):
        """Detail-Abschnitt wird für fehlgeschlagene Checks erstellt."""
        results = _make_results()
        md = generate_markdown(results)

        assert "## Details zu Befunden" in md
        assert "### 🔴 Workers aktiv?" in md
        assert "### 🟡 db_maxconn korrekt?" in md
        assert "**Fix verfügbar:** Ja" in md

    def test_keine_details_ohne_fails(self):
        """Kein Detail-Abschnitt wenn alle Checks bestanden."""
        results = [
            CheckResult(
                check_id="test",
                title="Test",
                severity=Severity.INFO,
                status=Status.PASS,
                message="OK",
            ),
        ]
        md = generate_markdown(results)
        assert "## Details zu Befunden" not in md

    def test_fix_hinweis_bei_verfuegbaren_fixes(self):
        """Hinweis auf verfügbare Fixes wird angezeigt."""
        results = _make_results()
        md = generate_markdown(results)

        assert "Fix(es) verfügbar" in md
        assert "odoo-optimizer plan" in md

    def test_custom_title(self):
        """Benutzerdefinierter Titel wird übernommen."""
        results = _make_results()
        md = generate_markdown(results, title="Mein Report")

        assert "# Mein Report" in md

    def test_skip_zaehler(self):
        """Übersprungene Checks werden in Zusammenfassung gezählt."""
        results = _make_results()
        md = generate_markdown(results)

        assert "1 Check(s) übersprungen" in md

    def test_footer_enthalten(self):
        """Footer mit Zeitstempel vorhanden."""
        results = _make_results()
        md = generate_markdown(results)

        assert "Generiert mit odoo-optimizer" in md

    def test_pipe_in_message_escaped(self):
        """Pipe-Zeichen in Meldungen werden escaped."""
        results = [
            CheckResult(
                check_id="test",
                title="Test",
                severity=Severity.INFO,
                status=Status.PASS,
                message="Wert A | Wert B",
            ),
        ]
        md = generate_markdown(results)
        assert "Wert A \\| Wert B" in md

    def test_leere_ergebnisliste(self):
        """Leere Ergebnisliste erzeugt trotzdem gültigen Report."""
        md = generate_markdown([])

        assert "# Odoo Server Diagnose" in md
        assert "| 0 | 0 | 0 | 0 | 0 |" in md


class TestSaveMarkdown:
    """Tests für save_markdown()."""

    def test_speichert_datei(self, tmp_path):
        """Markdown wird als Datei gespeichert."""
        results = _make_results()
        output = tmp_path / "report.md"

        path = save_markdown(results, output, server_name="test")

        assert path.exists()
        content = path.read_text(encoding="utf-8")
        assert "# Odoo Server Diagnose" in content
        assert "**Server:** test" in content

    def test_gibt_pfad_zurueck(self, tmp_path):
        """Rückgabewert ist der Pfad zur gespeicherten Datei."""
        output = tmp_path / "report.md"
        path = save_markdown([], output)

        assert path == output
