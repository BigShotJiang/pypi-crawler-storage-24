"""Unit-Tests für SwapFixer."""

from odoo_optimizer.fixers.swap import SwapFixer
from tests.conftest import MockConnection

SWAP_PATH = "/swapfile"
FSTAB_PATH = "/etc/fstab"
SYSCTL_CONF = "/etc/sysctl.d/99-swappiness.conf"

FSTAB_OHNE_SWAP = """\
UUID=abc123 / ext4 defaults 0 1
UUID=def456 /boot ext4 defaults 0 2
"""

FSTAB_MIT_SWAP = """\
UUID=abc123 / ext4 defaults 0 1
UUID=def456 /boot ext4 defaults 0 2
/swapfile none swap sw 0 0
"""


def _make_conn(
    swap_mb: int = 0,
    ram_gb: int = 16,
    swappiness: int = 60,
    fstab: str = FSTAB_OHNE_SWAP,
    swap_file_exists: bool = False,
) -> MockConnection:
    """Hilfs-Funktion für konsistente MockConnections."""
    responses: dict[str, str] = {
        "free -m | grep -i swap": f"Swap:          {swap_mb}       0       {swap_mb}",
        "free -g | grep -i mem": f"Mem:           {ram_gb}       8       8       0       1      10",
        "sysctl -n vm.swappiness": str(swappiness),
        FSTAB_PATH: fstab,
        "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260309_0200",
    }
    if swap_file_exists:
        responses[SWAP_PATH] = "swap data"
    return MockConnection(responses=responses)


class TestSwapFixer:
    """Tests für SwapFixer — Swap-Datei einrichten."""

    def test_plan_erstellt_schritte_ohne_swap(self):
        """Plan erstellt Schritte wenn kein Swap vorhanden."""
        conn = _make_conn(swap_mb=0, ram_gb=16)
        fixer = SwapFixer()
        plan = fixer.plan(conn)

        assert plan.fixer_id == "swap"
        assert len(plan.steps) == 1
        assert "16 GB" in plan.steps[0].description
        assert plan.requires_sudo is True

    def test_plan_erstellt_schritte_bei_zu_wenig_swap(self):
        """Plan erstellt Schritte wenn Swap zu klein."""
        conn = _make_conn(swap_mb=1024, ram_gb=16)  # 1 GB statt 16 GB
        fixer = SwapFixer()
        plan = fixer.plan(conn)

        assert len(plan.steps) == 1
        assert "vergrößern" in plan.steps[0].description

    def test_plan_leer_wenn_genug_swap(self):
        """Kein Schritt wenn Swap >= RAM."""
        conn = _make_conn(swap_mb=16384, ram_gb=16)  # 16 GB Swap = 16 GB RAM
        fixer = SwapFixer()
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_plan_mit_expliziter_groesse(self):
        """Plan respektiert explizite Ziel-Größe."""
        conn = _make_conn(swap_mb=0, ram_gb=16)
        fixer = SwapFixer(target_swap_gb=4)
        plan = fixer.plan(conn)

        assert len(plan.steps) == 1
        assert "4 GB" in plan.steps[0].description

    def test_plan_leer_bei_expliziter_groesse_erfuellt(self):
        """Kein Schritt wenn explizite Ziel-Größe bereits erreicht."""
        conn = _make_conn(swap_mb=4096, ram_gb=16)
        fixer = SwapFixer(target_swap_gb=4)
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_apply_erstellt_swap_datei(self):
        """Apply erstellt Swap-Datei und aktiviert sie."""
        conn = _make_conn(swap_mb=0, ram_gb=16)
        fixer = SwapFixer(target_swap_gb=4)
        assert fixer.apply(conn) is True

        # Alle erwarteten Kommandos prüfen
        assert "fallocate -l 4G /swapfile" in conn.executed_commands
        assert "chmod 600 /swapfile" in conn.executed_commands
        assert "mkswap /swapfile" in conn.executed_commands
        assert "swapon /swapfile" in conn.executed_commands
        assert "sysctl vm.swappiness=10" in conn.executed_commands

        # fstab muss Swap-Eintrag enthalten
        assert SWAP_PATH in conn.written_files[FSTAB_PATH]

        # Swappiness-Config muss geschrieben sein
        assert "vm.swappiness = 10" in conn.written_files[SYSCTL_CONF]

    def test_apply_deaktiviert_alten_swap(self):
        """Apply deaktiviert bestehenden Swap vor Neuerstellen."""
        conn = _make_conn(swap_mb=1024, ram_gb=16, swap_file_exists=True)
        fixer = SwapFixer(target_swap_gb=4)
        assert fixer.apply(conn) is True

        # swapoff muss VOR fallocate kommen
        swapoff_idx = conn.executed_commands.index(f"swapoff {SWAP_PATH}")
        fallocate_idx = conn.executed_commands.index("fallocate -l 4G /swapfile")
        assert swapoff_idx < fallocate_idx

    def test_apply_fstab_idempotent(self):
        """Apply fügt keinen doppelten fstab-Eintrag hinzu."""
        conn = _make_conn(swap_mb=0, ram_gb=16, fstab=FSTAB_MIT_SWAP)
        fixer = SwapFixer(target_swap_gb=4)
        assert fixer.apply(conn) is True

        # fstab darf NICHT nochmal geschrieben werden (Eintrag existiert schon)
        assert FSTAB_PATH not in conn.written_files

    def test_verify_erkennt_ausreichend_swap(self):
        """Verify gibt True wenn Swap ausreichend + Swappiness korrekt."""
        conn = _make_conn(swap_mb=4096, ram_gb=16, swappiness=10)
        fixer = SwapFixer(target_swap_gb=4)
        assert fixer.verify(conn) is True

    def test_verify_erkennt_zu_wenig_swap(self):
        """Verify gibt False wenn Swap zu klein."""
        conn = _make_conn(swap_mb=1024, ram_gb=16, swappiness=10)
        fixer = SwapFixer(target_swap_gb=4)
        assert fixer.verify(conn) is False

    def test_verify_erkennt_falsche_swappiness(self):
        """Verify gibt False wenn Swappiness nicht 10."""
        conn = _make_conn(swap_mb=4096, ram_gb=16, swappiness=60)
        fixer = SwapFixer(target_swap_gb=4)
        assert fixer.verify(conn) is False

    def test_backup_sichert_fstab(self):
        """Backup sichert /etc/fstab (nicht die Swap-Datei selbst)."""
        conn = _make_conn()
        fixer = SwapFixer()
        backup_path = fixer.backup(conn)
        assert backup_path == "/etc/fstab.bak.20260309_0200"

    def test_rollback_entfernt_swap(self):
        """Rollback deaktiviert Swap und stellt fstab wieder her."""
        backup_path = "/etc/fstab.bak.20260309_0200"
        conn = _make_conn(swap_file_exists=True)
        conn.responses[backup_path] = FSTAB_OHNE_SWAP
        conn.responses[SYSCTL_CONF] = "vm.swappiness = 10"

        fixer = SwapFixer()
        assert fixer.rollback(conn, backup_path) is True

        assert f"swapoff {SWAP_PATH}" in conn.executed_commands
        assert f"rm {SWAP_PATH}" in conn.executed_commands
        assert f"rm {SYSCTL_CONF}" in conn.executed_commands

    def test_rollback_fehlschlag_ohne_backup(self):
        """Rollback gibt False wenn fstab-Backup nicht existiert."""
        conn = MockConnection()
        fixer = SwapFixer()
        assert fixer.rollback(conn, "/nicht/vorhanden") is False
