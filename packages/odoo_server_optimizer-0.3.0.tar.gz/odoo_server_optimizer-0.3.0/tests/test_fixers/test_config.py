"""Unit-Tests für ConfigFixer."""

from odoo_optimizer.fixers.config import ConfigFixer
from tests.conftest import MockConnection

SAMPLE_CONFIG = """[options]
admin_passwd = secret
workers = 0
max_cron_threads = 2
db_maxconn = 64
limit_time_cpu = 3600
limit_time_real = 7200
longpolling_port = 8072
http_interface =
"""

CHANGES = {
    "workers": {"soll": 9, "grund": "4 CPU × 2 + 1"},
    "max_cron_threads": {"soll": 1, "grund": "1 Cron-Thread"},
    "db_maxconn": {"soll": 8, "grund": "100 / 12 Prozesse"},
    "limit_time_cpu": {"soll": 600, "grund": "10 Min"},
    "limit_time_real": {"soll": 1200, "grund": "20 Min"},
    "http_interface": {"soll": "127.0.0.1", "grund": "Nginx-Proxy"},
}

CONF_PATH = "/etc/odoo/odoo.conf"


class TestConfigFixer:
    """Tests für ConfigFixer — odoo.conf Parameter."""

    def test_plan_erkennt_aenderungen(self):
        """Plan zeigt alle Parameter-Unterschiede."""
        conn = MockConnection(responses={
            CONF_PATH: SAMPLE_CONFIG,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = ConfigFixer(CHANGES)
        plan = fixer.plan(conn)

        assert plan.fixer_id == "config"
        assert len(plan.steps) == 1
        assert plan.requires_restart is True
        # workers, max_cron_threads, db_maxconn, cpu, real,
        # http_interface + longpolling_port ENTFERNEN = 7
        assert len(plan.steps[0].changes) == 7

    def test_plan_leer_wenn_alles_passt(self):
        """Keine Schritte wenn Config schon optimal."""
        optimal = """[options]
workers = 9
max_cron_threads = 1
db_maxconn = 8
limit_time_cpu = 600
limit_time_real = 1200
http_interface = 127.0.0.1
"""
        conn = MockConnection(responses={CONF_PATH: optimal})
        fixer = ConfigFixer(CHANGES)
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_apply_setzt_parameter(self):
        """Apply ändert alle Parameter in der Config."""
        conn = MockConnection(responses={CONF_PATH: SAMPLE_CONFIG})
        fixer = ConfigFixer(CHANGES)

        assert fixer.apply(conn) is True
        written = conn.written_files[CONF_PATH]

        assert "workers = 9" in written
        assert "max_cron_threads = 1" in written
        assert "db_maxconn = 8" in written
        assert "limit_time_cpu = 600" in written
        assert "limit_time_real = 1200" in written
        assert "http_interface = 127.0.0.1" in written
        assert "longpolling_port" not in written

    def test_apply_fuegt_fehlende_parameter_hinzu(self):
        """Parameter die nicht existieren werden unter [options] eingefügt."""
        minimal = "[options]\nadmin_passwd = secret\n"
        conn = MockConnection(responses={CONF_PATH: minimal})
        fixer = ConfigFixer({"workers": {"soll": 9, "grund": "test"}})

        assert fixer.apply(conn) is True
        written = conn.written_files[CONF_PATH]
        assert "workers = 9" in written

    def test_verify_prueft_alle_parameter(self):
        """Verify gibt True wenn alle Parameter stimmen."""
        correct = """[options]
workers = 9
max_cron_threads = 1
db_maxconn = 8
limit_time_cpu = 600
limit_time_real = 1200
http_interface = 127.0.0.1
"""
        conn = MockConnection(responses={CONF_PATH: correct})
        fixer = ConfigFixer(CHANGES)
        assert fixer.verify(conn) is True

    def test_verify_erkennt_falsche_werte(self):
        """Verify gibt False wenn ein Parameter nicht stimmt."""
        wrong = """[options]
workers = 0
max_cron_threads = 1
"""
        conn = MockConnection(responses={CONF_PATH: wrong})
        fixer = ConfigFixer(CHANGES)
        assert fixer.verify(conn) is False

    def test_backup_erstellt_kopie(self):
        """Backup kopiert die Config mit Datum-Suffix."""
        conn = MockConnection(responses={
            CONF_PATH: SAMPLE_CONFIG,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = ConfigFixer(CHANGES)
        backup_path = fixer.backup(conn)

        assert backup_path == f"{CONF_PATH}.bak.20260304_1500"
        assert backup_path in conn.responses

    def test_rollback_stellt_backup_wieder_her(self):
        """Rollback kopiert Backup zurück."""
        backup_path = f"{CONF_PATH}.bak.20260304_1500"
        conn = MockConnection(responses={
            backup_path: SAMPLE_CONFIG,
        })
        fixer = ConfigFixer(CHANGES)
        assert fixer.rollback(conn, backup_path) is True

    def test_rollback_fehlschlag_ohne_backup(self):
        """Rollback gibt False wenn Backup nicht existiert."""
        conn = MockConnection()
        fixer = ConfigFixer(CHANGES)
        assert fixer.rollback(conn, "/nicht/vorhanden") is False

    def test_entfernt_deprecated_params(self):
        """Deprecated Parameter werden bei apply entfernt."""
        config = "[options]\nlongpolling_port = 8072\nworkers = 9\n"
        conn = MockConnection(responses={CONF_PATH: config})
        fixer = ConfigFixer({})

        assert fixer.apply(conn) is True
        written = conn.written_files[CONF_PATH]
        assert "longpolling_port" not in written
        assert "workers = 9" in written
