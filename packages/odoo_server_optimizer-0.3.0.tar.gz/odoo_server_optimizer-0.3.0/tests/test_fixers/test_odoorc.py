"""Unit-Tests für OdooRcFixer."""

from odoo_optimizer.fixers.odoorc import OdooRcFixer
from tests.conftest import MockConnection

RC_PATH = "/opt/odoo/.odoorc"


class TestOdooRcFixer:
    """Tests für OdooRcFixer — .odoorc deaktivieren."""

    def test_plan_wenn_odoorc_existiert(self):
        """Plan erstellt Umbennungs-Schritt wenn .odoorc vorhanden."""
        conn = MockConnection(responses={
            RC_PATH: "[options]\nadmin_passwd = ...",
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = OdooRcFixer()
        plan = fixer.plan(conn)

        assert plan.fixer_id == "odoorc"
        assert len(plan.steps) == 1
        assert "deaktivieren" in plan.steps[0].description
        assert plan.requires_restart is True

    def test_plan_leer_wenn_keine_odoorc(self):
        """Kein Schritt wenn .odoorc nicht existiert."""
        conn = MockConnection()
        fixer = OdooRcFixer()
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_apply_benennt_um(self):
        """Apply führt mv-Kommando aus."""
        conn = MockConnection(responses={
            RC_PATH: "[options]",
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = OdooRcFixer()
        assert fixer.apply(conn) is True

        # mv-Kommando muss ausgeführt worden sein
        mv_cmds = [c for c in conn.executed_commands if c.startswith("mv ")]
        assert len(mv_cmds) == 1
        assert RC_PATH in mv_cmds[0]
        assert ".disabled." in mv_cmds[0]

    def test_apply_ok_wenn_schon_weg(self):
        """Apply gibt True wenn .odoorc schon nicht mehr da."""
        conn = MockConnection()
        fixer = OdooRcFixer()
        assert fixer.apply(conn) is True

    def test_verify_prueft_abwesenheit(self):
        """Verify gibt True wenn .odoorc nicht mehr existiert."""
        conn = MockConnection()  # file_exists → False
        fixer = OdooRcFixer()
        assert fixer.verify(conn) is True

    def test_verify_fehlschlag_wenn_noch_da(self):
        """Verify gibt False wenn .odoorc noch existiert."""
        conn = MockConnection(responses={RC_PATH: "[options]"})
        fixer = OdooRcFixer()
        assert fixer.verify(conn) is False

    def test_rollback_benennt_zurueck(self):
        """Rollback macht die Umbenennung rückgängig."""
        disabled = f"{RC_PATH}.disabled.20260304_1500"
        conn = MockConnection(responses={disabled: "[options]"})
        fixer = OdooRcFixer()
        assert fixer.rollback(conn, disabled) is True

        mv_cmds = [c for c in conn.executed_commands if c.startswith("mv ")]
        assert len(mv_cmds) == 1
        assert RC_PATH in mv_cmds[0]
