"""Unit-Tests für SystemdFixer."""

from odoo_optimizer.fixers.systemd import SystemdFixer
from tests.conftest import MockConnection

SERVICE_PATH = "/etc/systemd/system/odoo.service"

SAMPLE_SERVICE = """[Unit]
Description=Odoo 19
After=postgresql.service

[Service]
Type=simple
User=odoo
ExecStart=/usr/bin/odoo --config /etc/odoo/odoo.conf
Restart=on-failure

[Install]
WantedBy=multi-user.target
"""

SERVICE_WITHOUT_CONFIG = """[Unit]
Description=Odoo 19

[Service]
Type=simple
User=odoo
ExecStart=/usr/bin/odoo
Restart=on-failure

[Install]
WantedBy=multi-user.target
"""


class TestSystemdFixer:
    """Tests für SystemdFixer — Service-Datei patchen."""

    def test_plan_wenn_config_fehlt(self):
        """Plan erstellt Schritt wenn -c fehlt."""
        conn = MockConnection(responses={
            SERVICE_PATH: SERVICE_WITHOUT_CONFIG,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = SystemdFixer()
        plan = fixer.plan(conn)

        assert plan.fixer_id == "systemd"
        assert len(plan.steps) == 1
        assert plan.requires_restart is True

    def test_plan_leer_wenn_config_gesetzt(self):
        """Kein Schritt wenn -c schon in ExecStart."""
        conn = MockConnection(responses={SERVICE_PATH: SAMPLE_SERVICE})
        fixer = SystemdFixer()
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_plan_leer_wenn_service_fehlt(self):
        """Kein Schritt wenn Service-Datei nicht existiert."""
        conn = MockConnection()
        fixer = SystemdFixer()
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_apply_fuegt_config_flag_hinzu(self):
        """Apply ergänzt -c /etc/odoo/odoo.conf in ExecStart."""
        conn = MockConnection(responses={
            SERVICE_PATH: SERVICE_WITHOUT_CONFIG,
        })
        fixer = SystemdFixer()
        assert fixer.apply(conn) is True

        written = conn.written_files[SERVICE_PATH]
        assert "-c /etc/odoo/odoo.conf" in written
        assert "ExecStart=/usr/bin/odoo -c /etc/odoo/odoo.conf" in written

        # daemon-reload muss aufgerufen worden sein
        assert "systemctl daemon-reload" in conn.executed_commands

    def test_apply_fehlschlag_ohne_service(self):
        """Apply gibt False wenn Service-Datei nicht lesbar."""
        conn = MockConnection()
        fixer = SystemdFixer()
        assert fixer.apply(conn) is False

    def test_verify_erkennt_config_flag(self):
        """Verify gibt True wenn -c gesetzt."""
        conn = MockConnection(responses={SERVICE_PATH: SAMPLE_SERVICE})
        fixer = SystemdFixer()
        assert fixer.verify(conn) is True

    def test_verify_fehlschlag_ohne_config(self):
        """Verify gibt False wenn -c fehlt."""
        conn = MockConnection(responses={
            SERVICE_PATH: SERVICE_WITHOUT_CONFIG,
        })
        fixer = SystemdFixer()
        assert fixer.verify(conn) is False

    def test_backup_erstellt_kopie(self):
        """Backup kopiert die Service-Datei."""
        conn = MockConnection(responses={
            SERVICE_PATH: SAMPLE_SERVICE,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = SystemdFixer()
        backup_path = fixer.backup(conn)

        assert backup_path == f"{SERVICE_PATH}.bak.20260304_1500"

    def test_rollback_stellt_wieder_her(self):
        """Rollback kopiert Backup zurück + daemon-reload."""
        backup_path = f"{SERVICE_PATH}.bak.20260304_1500"
        conn = MockConnection(responses={
            backup_path: SAMPLE_SERVICE,
        })
        fixer = SystemdFixer()
        assert fixer.rollback(conn, backup_path) is True
        assert "systemctl daemon-reload" in conn.executed_commands
