"""Unit-Tests für NginxFixer."""

from odoo_optimizer.fixers.nginx import NginxFixer
from tests.conftest import MockConnection

CONFIG_PATH = "/etc/nginx/sites-available/odoo"

SAMPLE_NGINX_CONFIG = """\
server {
    listen 80;
    server_name example.com;

    location / {
        proxy_pass http://127.0.0.1:8069;
        proxy_read_timeout 60s;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
    }
}
"""

NGINX_CONFIG_OPTIMAL = """\
server {
    listen 80;
    server_name example.com;

    location / {
        proxy_pass http://127.0.0.1:8069;
        proxy_read_timeout 1200s;
        proxy_connect_timeout 600s;
        proxy_send_timeout 600s;
    }
}
"""

NGINX_CONFIG_OHNE_TIMEOUTS = """\
server {
    listen 80;
    server_name example.com;

    location / {
        proxy_pass http://127.0.0.1:8069;
    }
}
"""


class TestNginxFixer:
    """Tests für NginxFixer — Nginx Proxy-Timeouts anpassen."""

    def test_plan_erstellt_schritte_bei_falschen_werten(self):
        """Plan erstellt Schritte wenn Timeouts zu niedrig."""
        conn = MockConnection(responses={
            CONFIG_PATH: SAMPLE_NGINX_CONFIG,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = NginxFixer()
        plan = fixer.plan(conn)

        assert plan.fixer_id == "nginx"
        assert len(plan.steps) == 1
        assert plan.requires_restart is True
        assert len(plan.steps[0].changes) == 3

    def test_plan_leer_wenn_optimal(self):
        """Kein Schritt wenn alle Timeouts optimal."""
        conn = MockConnection(responses={CONFIG_PATH: NGINX_CONFIG_OPTIMAL})
        fixer = NginxFixer()
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_plan_leer_wenn_config_fehlt(self):
        """Kein Schritt wenn Nginx-Config nicht existiert."""
        conn = MockConnection()
        fixer = NginxFixer()
        plan = fixer.plan(conn)
        assert plan.steps == []

    def test_plan_bei_fehlenden_direktiven(self):
        """Plan erkennt fehlende Timeout-Direktiven."""
        conn = MockConnection(responses={
            CONFIG_PATH: NGINX_CONFIG_OHNE_TIMEOUTS,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = NginxFixer()
        plan = fixer.plan(conn)

        assert len(plan.steps) == 1
        # Alle 3 Direktiven müssen hinzugefügt werden
        changes_text = " ".join(plan.steps[0].changes)
        assert "proxy_read_timeout" in changes_text
        assert "proxy_connect_timeout" in changes_text
        assert "proxy_send_timeout" in changes_text

    def test_apply_aktualisiert_vorhandene_werte(self):
        """Apply ändert vorhandene Timeout-Werte."""
        conn = MockConnection(responses={CONFIG_PATH: SAMPLE_NGINX_CONFIG})
        fixer = NginxFixer()
        assert fixer.apply(conn) is True

        written = conn.written_files[CONFIG_PATH]
        assert "proxy_read_timeout 1200s;" in written
        assert "proxy_connect_timeout 600s;" in written
        assert "proxy_send_timeout 600s;" in written

        # nginx -t und reload müssen aufgerufen worden sein
        assert "nginx -t" in conn.executed_commands
        assert "systemctl reload nginx" in conn.executed_commands

    def test_apply_fuegt_fehlende_direktiven_ein(self):
        """Apply fügt fehlende Timeout-Direktiven vor proxy_pass ein."""
        conn = MockConnection(responses={
            CONFIG_PATH: NGINX_CONFIG_OHNE_TIMEOUTS,
        })
        fixer = NginxFixer()
        assert fixer.apply(conn) is True

        written = conn.written_files[CONFIG_PATH]
        assert "proxy_read_timeout 1200s;" in written
        assert "proxy_connect_timeout 600s;" in written
        assert "proxy_send_timeout 600s;" in written

    def test_apply_fehlschlag_ohne_config(self):
        """Apply gibt False wenn Config nicht lesbar."""
        conn = MockConnection()
        fixer = NginxFixer()
        assert fixer.apply(conn) is False

    def test_verify_erkennt_korrekte_werte(self):
        """Verify gibt True wenn alle Timeouts optimal."""
        conn = MockConnection(responses={CONFIG_PATH: NGINX_CONFIG_OPTIMAL})
        fixer = NginxFixer()
        assert fixer.verify(conn) is True

    def test_verify_erkennt_falsche_werte(self):
        """Verify gibt False wenn Timeouts zu niedrig."""
        conn = MockConnection(responses={CONFIG_PATH: SAMPLE_NGINX_CONFIG})
        fixer = NginxFixer()
        assert fixer.verify(conn) is False

    def test_verify_fehlschlag_ohne_config(self):
        """Verify gibt False wenn Config nicht lesbar."""
        conn = MockConnection()
        fixer = NginxFixer()
        assert fixer.verify(conn) is False

    def test_backup_erstellt_kopie(self):
        """Backup kopiert die Nginx-Config."""
        conn = MockConnection(responses={
            CONFIG_PATH: SAMPLE_NGINX_CONFIG,
            "TZ='Europe/Vienna' date '+%Y%m%d_%H%M'": "20260304_1500",
        })
        fixer = NginxFixer()
        backup_path = fixer.backup(conn)
        assert backup_path == f"{CONFIG_PATH}.bak.20260304_1500"

    def test_rollback_stellt_wieder_her(self):
        """Rollback kopiert Backup zurück + nginx reload."""
        backup_path = f"{CONFIG_PATH}.bak.20260304_1500"
        conn = MockConnection(responses={
            backup_path: SAMPLE_NGINX_CONFIG,
        })
        fixer = NginxFixer()
        assert fixer.rollback(conn, backup_path) is True
        assert "nginx -t" in conn.executed_commands
        assert "systemctl reload nginx" in conn.executed_commands

    def test_rollback_fehlschlag_ohne_backup(self):
        """Rollback gibt False wenn Backup nicht existiert."""
        conn = MockConnection()
        fixer = NginxFixer()
        assert fixer.rollback(conn, "/nicht/vorhanden") is False
