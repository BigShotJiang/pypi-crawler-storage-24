"""Unit-Tests für das FastAPI Web-Dashboard."""

import json

import pytest
from fastapi.testclient import TestClient

from odoo_optimizer.api.app import app


@pytest.fixture
def client(tmp_path, monkeypatch):
    """TestClient mit temporärem Datenverzeichnis."""
    monkeypatch.setenv("ODOO_OPTIMIZER_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("ODOO_OPTIMIZER_API_KEY", "")
    return TestClient(app)


@pytest.fixture
def client_with_auth(tmp_path, monkeypatch):
    """TestClient mit aktiviertem API-Key."""
    monkeypatch.setenv("ODOO_OPTIMIZER_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("ODOO_OPTIMIZER_API_KEY", "test-secret-key")
    return TestClient(app)


class TestHealthEndpoint:
    """Tests für GET /api/health."""

    def test_health_returns_ok(self, client):
        """Health-Check gibt Status ok zurück."""
        response = client.get("/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert "timestamp" in data
        assert "auth_required" in data


class TestStatusEndpoint:
    """Tests für GET /api/status."""

    def test_status_ohne_analyse(self, client):
        """Status zeigt 'no_analysis' ohne vorherige Analyse."""
        response = client.get("/api/status")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "no_analysis"


class TestHistoryEndpoint:
    """Tests für GET /api/history."""

    def test_history_leer(self, client):
        """Leere Historie bei frischem Start."""
        response = client.get("/api/history")
        assert response.status_code == 200
        assert response.json() == []

    def test_history_nach_analyse(self, tmp_path, monkeypatch):
        """Historie enthält Einträge nach Analyse."""
        monkeypatch.setenv("ODOO_OPTIMIZER_API_KEY", "")
        monkeypatch.setenv("ODOO_OPTIMIZER_DATA_DIR", str(tmp_path))
        client = TestClient(app)

        history_file = tmp_path / "analysis_history.json"
        history_file.write_text(json.dumps([{
            "server": "test",
            "timestamp": "2026-03-09 02:00",
            "total": 3, "passed": 2, "failed": 1,
            "results": [],
        }]), encoding="utf-8")

        response = client.get("/api/history")
        data = response.json()
        assert len(data) == 1
        assert data[0]["server"] == "test"


class TestAuthEndpoint:
    """Tests für API-Key-Authentifizierung."""

    def test_analyze_ohne_key_wenn_nicht_konfiguriert(self, client):
        """Analyse ohne Key funktioniert wenn kein Key konfiguriert."""
        response = client.post(
            "/api/analyze",
            json={"connection_type": "local"},
        )
        # Entweder 200 oder 500, aber NICHT 403
        assert response.status_code != 403

    def test_analyze_ohne_key_bei_auth(self, client_with_auth):
        """Analyse ohne Key gibt 403 wenn Auth aktiv."""
        response = client_with_auth.post(
            "/api/analyze",
            json={"connection_type": "local"},
        )
        assert response.status_code == 403

    def test_analyze_mit_falschem_key(self, client_with_auth):
        """Analyse mit falschem Key gibt 403."""
        response = client_with_auth.post(
            "/api/analyze",
            json={"connection_type": "local"},
            headers={"X-API-Key": "wrong-key"},
        )
        assert response.status_code == 403

    def test_analyze_mit_korrektem_key(self, client_with_auth):
        """Analyse mit korrektem Key funktioniert (kein 403)."""
        response = client_with_auth.post(
            "/api/analyze",
            json={"connection_type": "local"},
            headers={"X-API-Key": "test-secret-key"},
        )
        assert response.status_code != 403


class TestDashboardEndpoint:
    """Tests für GET / (HTML-Dashboard)."""

    def test_dashboard_returns_html(self, client):
        """Dashboard gibt HTML zurück."""
        response = client.get("/")
        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

    def test_dashboard_enthaelt_titel(self, client):
        """Dashboard enthält den Projekt-Titel."""
        response = client.get("/")
        assert "odoo-optimizer" in response.text

    def test_dashboard_enthaelt_checks(self, client):
        """Dashboard listet die verfügbaren Checks auf."""
        response = client.get("/")
        assert "Verfügbare Checks" in response.text
        assert "workers_mode" in response.text

    def test_dashboard_enthaelt_analyse_button(self, client):
        """Dashboard hat einen Button zum Starten der Analyse."""
        response = client.get("/")
        assert "Analyse starten" in response.text
        assert "runAnalysis" in response.text

    def test_dashboard_responsive(self, client):
        """Dashboard hat responsive CSS."""
        response = client.get("/")
        assert "@media" in response.text

    def test_dashboard_zeigt_ergebnisse(self, tmp_path, monkeypatch):
        """Dashboard zeigt Analyse-Ergebnisse wenn vorhanden."""
        monkeypatch.setenv("ODOO_OPTIMIZER_API_KEY", "")
        monkeypatch.setenv("ODOO_OPTIMIZER_DATA_DIR", str(tmp_path))
        client = TestClient(app)

        history_file = tmp_path / "analysis_history.json"
        history_file.write_text(json.dumps([{
            "server": "prod-server",
            "timestamp": "2026-03-09 02:00",
            "total": 10, "passed": 8, "failed": 2,
            "results": [
                {"check_id": "test", "title": "Test Check", "severity": "critical",
                 "status": "fail", "message": "Fehler", "details": {}, "fix_available": True},
            ],
        }]), encoding="utf-8")

        response = client.get("/")
        assert "Letzte Analyse" in response.text
        assert "prod-server" in response.text
        assert "Test Check" in response.text
