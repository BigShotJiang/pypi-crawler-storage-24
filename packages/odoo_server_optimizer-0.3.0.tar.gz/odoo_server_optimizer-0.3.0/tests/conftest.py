"""Test-Fixtures und MockConnection."""

from pathlib import Path

import pytest

from odoo_optimizer.connection.base import AbstractConnection, CommandResult

FIXTURES_DIR = Path(__file__).parent / "fixtures"


class MockConnection(AbstractConnection):
    """Mock-Connection für Tests – kein echter Server nötig."""

    def __init__(self, responses: dict[str, str] | None = None) -> None:
        """
        Args:
            responses: Mapping von Kommando → stdout-Antwort
        """
        self.responses = responses or {}
        self.executed_commands: list[str] = []
        self.written_files: dict[str, str] = {}

    def run(self, cmd: str) -> CommandResult:
        self.executed_commands.append(cmd)
        stdout = self.responses.get(cmd, "")
        return CommandResult(stdout=stdout, stderr="", returncode=0)

    def read_file(self, path: str) -> str:
        if path in self.responses:
            return self.responses[path]
        raise FileNotFoundError(f"Mock: Datei nicht gefunden: {path}")

    def write_file(self, path: str, content: str) -> None:
        self.written_files[path] = content

    def file_exists(self, path: str) -> bool:
        return path in self.responses

    def copy_file(self, src: str, dst: str) -> None:
        if src in self.responses:
            self.responses[dst] = self.responses[src]

    def close(self) -> None:
        pass


@pytest.fixture
def mock_conn_single_threaded():
    """Server im Single-Threaded-Modus (Ist-Zustand mit Problemen)."""
    return MockConnection(responses={
        "ps aux | grep '[o]doo' | wc -l": "1",
        "ss -tlnp | grep 8072": "",
        "sudo journalctl -u odoo --since '1 hour ago' "
        "| grep 'Using configuration file' | tail -1":
            "INFO ? odoo: Using configuration file at /opt/odoo/.odoorc",
        "/opt/odoo/.odoorc": "[options]\nadmin_passwd = ...",
    })


@pytest.fixture
def mock_conn_worker_mode():
    """Server im Worker-Modus (Zielzustand)."""
    return MockConnection(responses={
        "ps aux | grep '[o]doo' | wc -l": "12",
        "ss -tlnp | grep 8072": "LISTEN 8072",
        "sudo journalctl -u odoo --since '1 hour ago' "
        "| grep 'Using configuration file' | tail -1":
            "INFO ? odoo: Using configuration file at /etc/odoo/odoo.conf",
    })


@pytest.fixture
def problematic_config() -> str:
    """Lädt die problematische Beispiel-Config."""
    return (FIXTURES_DIR / "odoo.conf.problematic").read_text()


@pytest.fixture
def optimal_config() -> str:
    """Lädt die optimale Ziel-Config."""
    return (FIXTURES_DIR / "odoo.conf.optimal").read_text()
