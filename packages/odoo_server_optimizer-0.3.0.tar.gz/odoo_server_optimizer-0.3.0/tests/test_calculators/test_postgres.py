"""Unit-Tests für PostgresCalculator."""

from odoo_optimizer.calculators.postgres import PostgresCalculator
from tests.conftest import MockConnection


class TestPostgresCalculator:
    """Tests für PostgresCalculator — PostgreSQL-Verbindungslimits."""

    def test_ccx23_standard(self):
        """max_connections=100, 12 Prozesse → db_maxconn=8."""
        conn = MockConnection(responses={
            "sudo -u postgres psql -t -c 'SHOW max_connections'": "100",
            "sudo -u postgres psql -t -c 'SELECT version()'":
                "PostgreSQL 16.2 on x86_64-pc-linux-gnu",
        })
        result = PostgresCalculator(conn, total_processes=12).calculate()
        assert result.max_connections == 100
        assert result.version == "16.2"
        assert result.safe_db_maxconn == 8  # min(8, 100//12=8)

    def test_hohe_max_connections(self):
        """max_connections=200, 12 Prozesse → db_maxconn=8 (Default-Cap)."""
        conn = MockConnection(responses={
            "sudo -u postgres psql -t -c 'SHOW max_connections'": "200",
            "sudo -u postgres psql -t -c 'SELECT version()'":
                "PostgreSQL 16.2",
        })
        result = PostgresCalculator(conn, total_processes=12).calculate()
        assert result.safe_db_maxconn == 8  # min(8, 200//12=16) → 8

    def test_niedrige_max_connections(self):
        """max_connections=20, 12 Prozesse → db_maxconn=2 (Minimum)."""
        conn = MockConnection(responses={
            "sudo -u postgres psql -t -c 'SHOW max_connections'": "20",
            "sudo -u postgres psql -t -c 'SELECT version()'":
                "PostgreSQL 16.2",
        })
        result = PostgresCalculator(conn, total_processes=12).calculate()
        assert result.safe_db_maxconn == 2  # max(2, 20//12=1) → 2

    def test_fallback_bei_fehler(self):
        """Kein PostgreSQL-Zugriff → Default-Werte."""
        conn = MockConnection(responses={})
        result = PostgresCalculator(conn, total_processes=12).calculate()
        assert result.max_connections == 100  # DEFAULT_PG_MAX_CONNECTIONS
        assert result.version == "unbekannt"
