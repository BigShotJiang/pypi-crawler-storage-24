"""Unit-Tests für OptimizerCalculator."""

from odoo_optimizer.calculators.base import HardwareInfo, PostgresInfo
from odoo_optimizer.calculators.optimizer import OptimizerCalculator


class TestOptimizerCalculator:
    """Tests für OptimizerCalculator — Gesamtoptimierung."""

    def _ccx23_hardware(self) -> HardwareInfo:
        """CCX23 Standard-Hardware: 4 vCPU, 16 GB RAM."""
        return HardwareInfo(
            cpu_cores=4,
            ram_bytes=17179869184,  # 16 GB
            calculated_workers=9,
            total_processes=12,
        )

    def _standard_postgres(self) -> PostgresInfo:
        """Standard PostgreSQL-Konfiguration."""
        return PostgresInfo(
            max_connections=100,
            version="16.2",
            safe_db_maxconn=8,
        )

    def test_ccx23_optimierung(self):
        """CCX23 Szenario: Alle Werte korrekt berechnet."""
        plan = OptimizerCalculator(
            self._ccx23_hardware(), self._standard_postgres()
        ).calculate()

        assert plan.workers == 9
        assert plan.max_cron_threads == 1
        assert plan.db_maxconn == 8
        assert plan.limit_time_cpu == 600
        assert plan.limit_time_real == 1200
        assert plan.limit_time_real_cron == 3600
        assert plan.http_interface == "127.0.0.1"
        assert plan.needs_restart is True

    def test_memory_limits_berechnet(self):
        """Memory-Limits basieren auf RAM / Prozesse."""
        plan = OptimizerCalculator(
            self._ccx23_hardware(), self._standard_postgres()
        ).calculate()

        # 16 GB / 12 Prozesse × 0.8 ≈ 1.07 GB Soft
        assert plan.limit_memory_soft > 0
        assert plan.limit_memory_hard > plan.limit_memory_soft
        # Hard = Soft × 1.2
        assert plan.limit_memory_hard == int(plan.limit_memory_soft * 1.2)

    def test_changes_enthalten_begruendungen(self):
        """Jede \u00c4nderung hat eine Begr\u00fcndung."""
        plan = OptimizerCalculator(
            self._ccx23_hardware(), self._standard_postgres()
        ).calculate()

        assert "workers" in plan.changes
        assert "grund" in plan.changes["workers"]
        assert "db_maxconn" in plan.changes
        assert "grund" in plan.changes["db_maxconn"]

    def test_kleiner_server(self):
        """1 CPU, 2 GB RAM → 3 Workers."""
        hardware = HardwareInfo(
            cpu_cores=1,
            ram_bytes=2147483648,  # 2 GB
            calculated_workers=3,
            total_processes=6,
        )
        postgres = PostgresInfo(
            max_connections=100, version="16.2", safe_db_maxconn=8
        )
        plan = OptimizerCalculator(hardware, postgres).calculate()
        assert plan.workers == 3
        assert plan.limit_memory_soft > 0
