"""Unit-Tests für HardwareCalculator."""

from odoo_optimizer.calculators.hardware import HardwareCalculator
from tests.conftest import MockConnection


class TestHardwareCalculator:
    """Tests für HardwareCalculator — CPU/RAM Erkennung."""

    def test_ccx23_szenario(self):
        """CCX23: 4 vCPU, 16 GB RAM → 9 Workers, 12 Prozesse."""
        conn = MockConnection(responses={
            "nproc": "4",
            "free -b | grep Mem | awk '{print $2}'": "17179869184",
        })
        result = HardwareCalculator(conn).calculate()
        assert result.cpu_cores == 4
        assert result.ram_bytes == 17179869184
        assert result.calculated_workers == 9  # (4 × 2) + 1
        assert result.total_processes == 12  # 1 + 9 + 1 + 1

    def test_ram_gb_property(self):
        """RAM in GB korrekt berechnet."""
        conn = MockConnection(responses={
            "nproc": "4",
            "free -b | grep Mem | awk '{print $2}'": "17179869184",
        })
        result = HardwareCalculator(conn).calculate()
        assert result.ram_gb == 16.0

    def test_single_cpu_fallback(self):
        """1 CPU → 3 Workers, 6 Prozesse."""
        conn = MockConnection(responses={
            "nproc": "1",
            "free -b | grep Mem | awk '{print $2}'": "4294967296",
        })
        result = HardwareCalculator(conn).calculate()
        assert result.cpu_cores == 1
        assert result.calculated_workers == 3  # (1 × 2) + 1
        assert result.total_processes == 6  # 1 + 3 + 1 + 1

    def test_eight_cpu_server(self):
        """8 CPU → 17 Workers, 20 Prozesse."""
        conn = MockConnection(responses={
            "nproc": "8",
            "free -b | grep Mem | awk '{print $2}'": "34359738368",
        })
        result = HardwareCalculator(conn).calculate()
        assert result.cpu_cores == 8
        assert result.calculated_workers == 17  # (8 × 2) + 1
        assert result.total_processes == 20  # 1 + 17 + 1 + 1
