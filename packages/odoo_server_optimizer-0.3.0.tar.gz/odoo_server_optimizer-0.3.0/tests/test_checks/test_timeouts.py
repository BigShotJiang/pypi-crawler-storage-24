"""Unit-Tests für timeouts.py Check."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.timeouts import TimeoutCheck
from tests.conftest import MockConnection


class TestTimeoutCheck:
    """Tests für TimeoutCheck (Befund 4)."""

    def test_timeout_zu_hoch_erkannt(self):
        """limit_time_cpu=3600, limit_time_real=7200 → FAIL."""
        conn = MockConnection(responses={
            "grep -E '^limit_time_cpu' /etc/odoo/odoo.conf": "limit_time_cpu = 3600",
            "grep -E '^limit_time_real\\b' /etc/odoo/odoo.conf": "limit_time_real = 7200",
        })
        result = TimeoutCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.WARNING
        assert result.fix_available is True

    def test_timeout_optimal(self):
        """limit_time_cpu=600, limit_time_real=1200 → PASS."""
        conn = MockConnection(responses={
            "grep -E '^limit_time_cpu' /etc/odoo/odoo.conf": "limit_time_cpu = 600",
            "grep -E '^limit_time_real\\b' /etc/odoo/odoo.conf": "limit_time_real = 1200",
        })
        result = TimeoutCheck().run(conn)
        assert result.status == Status.PASS

    def test_befund_referenz_vorhanden(self):
        """Details enthalten Befund-Referenz."""
        conn = MockConnection(responses={
            "grep -E '^limit_time_cpu' /etc/odoo/odoo.conf": "limit_time_cpu = 3600",
            "grep -E '^limit_time_real\\b' /etc/odoo/odoo.conf": "limit_time_real = 7200",
        })
        result = TimeoutCheck().run(conn)
        assert "befund" in result.details
