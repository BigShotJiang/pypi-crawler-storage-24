"""Unit-Tests für config_values.py Check."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.config_values import ConfigValuesCheck
from tests.conftest import MockConnection


class TestConfigValuesCheck:
    """Tests für ConfigValuesCheck (Befund 7+8)."""

    def test_db_host_false_erkannt(self):
        """db_host = False → FAIL."""
        conn = MockConnection(responses={
            "grep -E '^db_host' /etc/odoo/odoo.conf": "db_host = False",
            "grep -E '^addons_path' /etc/odoo/odoo.conf":
                "addons_path = /usr/lib/python3/dist-packages/odoo",
        })
        result = ConfigValuesCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.WARNING
        assert result.fix_available is True
        assert "befund" in result.details

    def test_korrekte_werte(self):
        """db_host = /var/run/postgresql, addons_path gesetzt → PASS."""
        conn = MockConnection(responses={
            "grep -E '^db_host' /etc/odoo/odoo.conf": "db_host = /var/run/postgresql",
            "grep -E '^addons_path' /etc/odoo/odoo.conf":
                "addons_path = /usr/lib/python3/dist-packages/odoo",
        })
        result = ConfigValuesCheck().run(conn)
        assert result.status == Status.PASS

    def test_addons_path_fehlt(self):
        """addons_path nicht gesetzt → FAIL."""
        conn = MockConnection(responses={
            "grep -E '^db_host' /etc/odoo/odoo.conf": "db_host = /var/run/postgresql",
            "grep -E '^addons_path' /etc/odoo/odoo.conf": "",
        })
        result = ConfigValuesCheck().run(conn)
        assert result.status == Status.FAIL
