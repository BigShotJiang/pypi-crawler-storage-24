"""Unit-Tests für deprecated.py Check."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.deprecated import DeprecatedParamsCheck
from tests.conftest import MockConnection


class TestDeprecatedParamsCheck:
    """Tests für DeprecatedParamsCheck (Befund 6)."""

    def test_longpolling_port_erkannt(self):
        """longpolling_port in Config → FAIL."""
        conn = MockConnection(responses={
            "grep -E '^longpolling_port' /etc/odoo/odoo.conf": "longpolling_port = 8072",
        })
        result = DeprecatedParamsCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.WARNING
        assert result.fix_available is True
        assert "befund" in result.details

    def test_keine_veralteten_parameter(self):
        """Keine veralteten Parameter → PASS."""
        conn = MockConnection(responses={
            "grep -E '^longpolling_port' /etc/odoo/odoo.conf": "",
        })
        result = DeprecatedParamsCheck().run(conn)
        assert result.status == Status.PASS
