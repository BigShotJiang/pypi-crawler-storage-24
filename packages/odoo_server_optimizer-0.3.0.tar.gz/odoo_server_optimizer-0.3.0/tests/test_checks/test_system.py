"""Unit-Tests für system.py Checks."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.system import HttpInterfaceCheck, SystemDependenciesCheck
from tests.conftest import MockConnection


class TestSystemDependenciesCheck:
    """Tests für SystemDependenciesCheck (Befund 9)."""

    def test_pdfminer_fehlt(self):
        """pdfminer.six nicht installiert → FAIL."""
        conn = MockConnection(responses={
            "pip3 show pdfminer.six": "",
        })
        result = SystemDependenciesCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.WARNING
        assert result.fix_available is True
        assert "befund" in result.details

    def test_pdfminer_installiert(self):
        """pdfminer.six installiert → PASS."""
        conn = MockConnection(responses={
            "pip3 show pdfminer.six": "Name: pdfminer.six\nVersion: 20231228",
        })
        result = SystemDependenciesCheck().run(conn)
        assert result.status == Status.PASS


class TestHttpInterfaceCheck:
    """Tests für HttpInterfaceCheck (Befund 10)."""

    def test_http_interface_fehlt(self):
        """http_interface nicht gesetzt → FAIL (öffentlich erreichbar)."""
        conn = MockConnection(responses={
            "grep -E '^http_interface' /etc/odoo/odoo.conf": "",
        })
        result = HttpInterfaceCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.CRITICAL
        assert result.fix_available is True
        assert "befund" in result.details

    def test_http_interface_korrekt(self):
        """http_interface = 127.0.0.1 → PASS."""
        conn = MockConnection(responses={
            "grep -E '^http_interface' /etc/odoo/odoo.conf": "http_interface = 127.0.0.1",
        })
        result = HttpInterfaceCheck().run(conn)
        assert result.status == Status.PASS

    def test_http_interface_falsch(self):
        """http_interface = 0.0.0.0 → FAIL."""
        conn = MockConnection(responses={
            "grep -E '^http_interface' /etc/odoo/odoo.conf": "http_interface = 0.0.0.0",
        })
        result = HttpInterfaceCheck().run(conn)
        assert result.status == Status.FAIL
