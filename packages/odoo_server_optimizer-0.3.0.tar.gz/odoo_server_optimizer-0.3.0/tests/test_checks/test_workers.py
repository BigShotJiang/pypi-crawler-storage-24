"""Unit-Tests für workers.py Checks."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.workers import ConfigFileCheck, WorkersModeCheck


class TestWorkersModeCheck:
    """Tests für WorkersModeCheck (Befund 1)."""

    def test_single_threaded_mode_erkannt(self, mock_conn_single_threaded):
        """Single-Threaded-Modus wird als FAIL erkannt."""
        result = WorkersModeCheck().run(mock_conn_single_threaded)
        assert result.status == Status.FAIL
        assert result.severity == Severity.CRITICAL
        assert result.fix_available is True

    def test_worker_mode_erkannt(self, mock_conn_worker_mode):
        """Worker-Modus wird als PASS erkannt."""
        result = WorkersModeCheck().run(mock_conn_worker_mode)
        assert result.status == Status.PASS

    def test_details_enthalten_befund_nummer(self, mock_conn_single_threaded):
        """Details enthalten Befund-Referenz für Rückverfolgung."""
        result = WorkersModeCheck().run(mock_conn_single_threaded)
        assert "befund" in result.details


class TestConfigFileCheck:
    """Tests für ConfigFileCheck (Befund 2)."""

    def test_falsche_config_erkannt(self, mock_conn_single_threaded):
        """Falsche Config-Datei (.odoorc) wird als FAIL erkannt."""
        result = ConfigFileCheck().run(mock_conn_single_threaded)
        assert result.status == Status.FAIL
        assert result.severity == Severity.CRITICAL

    def test_korrekte_config_erkannt(self, mock_conn_worker_mode):
        """Korrekte Config (/etc/odoo/odoo.conf) wird als PASS erkannt."""
        result = ConfigFileCheck().run(mock_conn_worker_mode)
        assert result.status == Status.PASS

    def test_fix_vorschlag_in_details(self, mock_conn_single_threaded):
        """Details enthalten konkreten Fix-Vorschlag."""
        result = ConfigFileCheck().run(mock_conn_single_threaded)
        assert "fix" in result.details
        assert "-c /etc/odoo/odoo.conf" in result.details["fix"]
