"""Unit-Tests für database.py Check."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.database import DatabaseConnectionCheck
from tests.conftest import MockConnection


class TestDatabaseConnectionCheck:
    """Tests für DatabaseConnectionCheck (Befund 3)."""

    def test_maxconn_zu_hoch_erkannt(self):
        """db_maxconn=64 × 12 Prozesse = 768 > 100 → FAIL."""
        conn = MockConnection(responses={
            "grep -E '^db_maxconn' /etc/odoo/odoo.conf": "db_maxconn = 64",
            "sudo -u postgres psql -t -c 'SHOW max_connections'": "100",
            "ps aux | grep '[o]doo' | wc -l": "12",
        })
        result = DatabaseConnectionCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.CRITICAL
        assert result.fix_available is True
        assert "befund" in result.details

    def test_maxconn_korrekt(self):
        """db_maxconn=8 × 12 Prozesse = 96 < 100 → PASS."""
        conn = MockConnection(responses={
            "grep -E '^db_maxconn' /etc/odoo/odoo.conf": "db_maxconn = 8",
            "sudo -u postgres psql -t -c 'SHOW max_connections'": "100",
            "ps aux | grep '[o]doo' | wc -l": "12",
        })
        result = DatabaseConnectionCheck().run(conn)
        assert result.status == Status.PASS

    def test_fix_vorschlag_in_details(self):
        """Details enthalten konkreten Fix-Vorschlag."""
        conn = MockConnection(responses={
            "grep -E '^db_maxconn' /etc/odoo/odoo.conf": "db_maxconn = 64",
            "sudo -u postgres psql -t -c 'SHOW max_connections'": "100",
            "ps aux | grep '[o]doo' | wc -l": "12",
        })
        result = DatabaseConnectionCheck().run(conn)
        assert "fix" in result.details
        assert "db_maxconn = 8" in result.details["fix"]
