"""Unit-Tests für cron.py Check."""

from odoo_optimizer.checks.base import Severity, Status
from odoo_optimizer.checks.cron import CronThreadsCheck
from tests.conftest import MockConnection


class TestCronThreadsCheck:
    """Tests für CronThreadsCheck (Befund 5)."""

    def test_cron_zu_viel_erkannt(self):
        """max_cron_threads=2 → FAIL (verschwendet Worker-Slots)."""
        conn = MockConnection(responses={
            "grep -E '^max_cron_threads' /etc/odoo/odoo.conf": "max_cron_threads = 2",
        })
        result = CronThreadsCheck().run(conn)
        assert result.status == Status.FAIL
        assert result.severity == Severity.WARNING
        assert result.fix_available is True
        assert "befund" in result.details

    def test_cron_null_erkannt(self):
        """max_cron_threads=0 → FAIL (kein Cron)."""
        conn = MockConnection(responses={
            "grep -E '^max_cron_threads' /etc/odoo/odoo.conf": "max_cron_threads = 0",
        })
        result = CronThreadsCheck().run(conn)
        assert result.status == Status.FAIL

    def test_cron_optimal(self):
        """max_cron_threads=1 → PASS."""
        conn = MockConnection(responses={
            "grep -E '^max_cron_threads' /etc/odoo/odoo.conf": "max_cron_threads = 1",
        })
        result = CronThreadsCheck().run(conn)
        assert result.status == Status.PASS
