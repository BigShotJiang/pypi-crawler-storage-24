"""Pydantic model flattening and target resolution utilities.

Extracted from flask-apcore's registry_writer.py. Provides the
framework-agnostic core for converting Pydantic model parameters into
flat keyword arguments suitable for MCP tool invocation.
"""

from __future__ import annotations

import functools
import importlib
import inspect
import typing
from typing import Annotated, Any

from pydantic import BaseModel, Field


def resolve_target(target: str) -> Any:
    """Resolve a ``module.path:qualname`` target string to a callable.

    Args:
        target: Target string in ``module.path:qualname`` format.

    Returns:
        The resolved callable.

    Raises:
        ImportError: If the module cannot be imported.
        AttributeError: If the qualified name cannot be resolved.
        ValueError: If the target format is invalid.
    """
    if ":" not in target:
        raise ValueError(f"Invalid target format: {target!r}. Expected 'module.path:qualname'.")
    module_path, _, qualname = target.partition(":")
    mod = importlib.import_module(module_path)
    return getattr(mod, qualname)


def flatten_pydantic_params(func: Any) -> Any:
    """Wrap a function so Pydantic model params are flattened to scalar kwargs.

    View functions like ``create_task(body: TaskCreate)`` expect a Pydantic
    model instance. MCP tools should expose flat fields instead (``title``,
    ``description``, ...). This wrapper bridges the gap:

    1. Inspects the function signature for Pydantic BaseModel parameters.
    2. Creates a wrapper accepting the model's fields as flat kwargs.
    3. Reconstructs the Pydantic model(s) internally before calling
       the original function.

    If the function has no Pydantic model parameters, it is returned as-is.
    """
    try:
        hints = typing.get_type_hints(func, include_extras=True)
    except Exception:
        return func

    sig = inspect.signature(func)

    pydantic_params: dict[str, type[BaseModel]] = {}
    simple_params: list[tuple[str, inspect.Parameter]] = []

    for name, param in sig.parameters.items():
        hint = hints.get(name)
        if hint is not None and isinstance(hint, type) and issubclass(hint, BaseModel):
            pydantic_params[name] = hint
        else:
            simple_params.append((name, param))

    if not pydantic_params:
        return func

    # Build flat signature and annotations for the wrapper
    flat_params: list[inspect.Parameter] = []
    flat_annotations: dict[str, Any] = {}

    for name, param in simple_params:
        flat_params.append(param)
        if name in hints:
            flat_annotations[name] = hints[name]

    for model_cls in pydantic_params.values():
        for field_name, field_info in model_cls.model_fields.items():
            default = field_info.default if not field_info.is_required() else inspect.Parameter.empty

            annotation: Any = field_info.annotation
            field_kwargs: dict[str, Any] = {}
            if field_info.description is not None:
                field_kwargs["description"] = field_info.description
            if field_info.examples is not None:
                field_kwargs["examples"] = field_info.examples
            if field_info.json_schema_extra is not None:
                field_kwargs["json_schema_extra"] = field_info.json_schema_extra
            if field_kwargs:
                annotation = Annotated[annotation, Field(**field_kwargs)]

            flat_params.append(
                inspect.Parameter(
                    field_name,
                    kind=inspect.Parameter.KEYWORD_ONLY,
                    default=default,
                    annotation=annotation,
                )
            )
            flat_annotations[field_name] = annotation

    if "return" in hints:
        flat_annotations["return"] = hints["return"]

    simple_param_names = {name for name, _ in simple_params}

    @functools.wraps(func)
    def wrapper(**kwargs: Any) -> Any:
        call_kwargs: dict[str, Any] = {}
        remaining = dict(kwargs)

        for name in list(remaining):
            if name in simple_param_names:
                call_kwargs[name] = remaining.pop(name)

        for param_name, model_cls in pydantic_params.items():
            model_field_names = set(model_cls.model_fields.keys())
            model_data = {k: remaining.pop(k) for k in list(remaining) if k in model_field_names}
            call_kwargs[param_name] = model_cls(**model_data)

        return func(**call_kwargs)

    wrapper.__signature__ = inspect.Signature(flat_params)  # type: ignore[attr-defined]
    wrapper.__annotations__ = flat_annotations
    return wrapper
