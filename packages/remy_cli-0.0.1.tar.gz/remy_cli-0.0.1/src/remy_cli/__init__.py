"""Remy — Remy cooks while you sleep. Autonomous AI development CLI."""
__version__ = "0.0.1"
