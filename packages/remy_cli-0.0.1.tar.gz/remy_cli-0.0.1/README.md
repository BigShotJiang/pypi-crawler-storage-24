# Remy

**Remy cooks while you sleep.**

Autonomous AI development CLI that turns ideas into shipped code — overnight, in parallel, with multi-model review.

Coming soon. Visit [letremycook.com](https://letremycook.com) for more.
