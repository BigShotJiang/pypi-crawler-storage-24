"""Ferramentas MCP do Jira para criação e gestão de tickets.

Registra as ferramentas jira_get_issue, jira_create_issue, jira_search,
jira_update_issue e jira_add_comment no MCP server, delegando ao JiraClient.
"""

import json
import logging

from mcp.server import Server
from mcp.types import TextContent, Tool

from mcp_jira.jira_client import (
    JiraAuthError,
    JiraClient,
    JiraConnectionError,
    JiraError,
    JiraValidationError,
)

logger = logging.getLogger(__name__)

TOOLS = [
    Tool(
        name="jira_get_issue",
        description="Busca detalhes completos de uma issue pelo key (ex: PROJ-123)",
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
            },
            "required": ["issueKey"],
        },
    ),
    Tool(
        name="jira_create_issue",
        description="Cria um ticket de incidente no Jira",
        inputSchema={
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Chave do projeto (ex: PROJ)",
                },
                "summary": {
                    "type": "string",
                    "description": "Título do ticket",
                },
                "description": {
                    "type": "string",
                    "description": "Descrição do ticket",
                },
                "issueType": {
                    "type": "string",
                    "description": "Tipo da issue (default: Bug)",
                },
                "priority": {
                    "type": "string",
                    "description": "Prioridade do ticket",
                },
                "labels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Labels do ticket",
                },
                "components": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Componentes do ticket",
                },
            },
            "required": ["projectKey", "summary", "description"],
        },
    ),
    Tool(
        name="jira_search",
        description="Consulta tickets no Jira via JQL",
        inputSchema={
            "type": "object",
            "properties": {
                "jql": {
                    "type": "string",
                    "description": "Query JQL para busca",
                },
                "maxResults": {
                    "type": "integer",
                    "description": "Número máximo de resultados (default: 50)",
                },
                "fields": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Campos a retornar",
                },
            },
            "required": ["jql"],
        },
    ),
    Tool(
        name="jira_update_issue",
        description="Atualiza campos de um ticket existente no Jira",
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
                "fields": {
                    "type": "object",
                    "description": "Campos a atualizar",
                },
            },
            "required": ["issueKey", "fields"],
        },
    ),
    Tool(
        name="jira_add_comment",
        description="Adiciona comentário a um ticket no Jira",
        inputSchema={
            "type": "object",
            "properties": {
                "issueKey": {
                    "type": "string",
                    "description": "Chave da issue (ex: PROJ-123)",
                },
                "body": {
                    "type": "string",
                    "description": "Texto do comentário",
                },
            },
            "required": ["issueKey", "body"],
        },
    ),
]


def _error_content(message: str) -> list[TextContent]:
    """Cria resposta de erro MCP com isError=True."""
    return [TextContent(type="text", text=message)]


def _success_content(data: dict | list | str) -> list[TextContent]:
    """Cria resposta de sucesso MCP."""
    if isinstance(data, str):
        text = data
    else:
        text = json.dumps(data, ensure_ascii=False, indent=2)
    return [TextContent(type="text", text=text)]


def register_tools(app: Server, client: JiraClient) -> None:
    """Registra as ferramentas MCP do Jira no server."""

    @app.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    @app.call_tool()
    async def call_tool(
        name: str, arguments: dict
    ) -> list[TextContent]:
        """Dispatcher de ferramentas MCP do Jira."""
        try:
            if name == "jira_get_issue":
                return _handle_get_issue(client, arguments)
            elif name == "jira_create_issue":
                return _handle_create_issue(client, arguments)
            elif name == "jira_search":
                return _handle_search(client, arguments)
            elif name == "jira_update_issue":
                return _handle_update_issue(client, arguments)
            elif name == "jira_add_comment":
                return _handle_add_comment(client, arguments)
            else:
                raise ValueError(f"Ferramenta desconhecida: {name}")
        except JiraValidationError:
            raise
        except JiraAuthError as exc:
            raise JiraError(
                f"Erro de autenticação no Jira: {exc}"
            ) from exc
        except JiraConnectionError:
            raise
        except JiraError:
            raise
        except ValueError:
            raise
        except Exception as exc:
            logger.exception("Erro inesperado na ferramenta %s", name)
            raise RuntimeError(f"Erro inesperado: {exc}") from exc


def _handle_get_issue(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_get_issue."""
    issue_key = arguments.get("issueKey", "")
    if not issue_key:
        raise JiraValidationError("Campo obrigatório ausente: issueKey")
    result = client.get_issue(issue_key=issue_key)
    return _success_content(result)


def _handle_create_issue(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_create_issue."""
    required = ["projectKey", "summary", "description"]
    missing = [f for f in required if not arguments.get(f)]
    if missing:
        raise JiraValidationError(
            f"Campos obrigatórios ausentes: {', '.join(missing)}"
        )

    result = client.create_issue(
        project_key=arguments["projectKey"],
        summary=arguments["summary"],
        description=arguments["description"],
        issue_type=arguments.get("issueType", "Bug"),
        priority=arguments.get("priority"),
        labels=arguments.get("labels"),
        components=arguments.get("components"),
    )
    return _success_content(result)


def _handle_search(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_search."""
    issues = client.search_issues(
        jql=arguments["jql"],
        max_results=arguments.get("maxResults", 50),
        fields=arguments.get("fields"),
    )

    results = []
    for issue in issues:
        fields = issue.get("fields", {})
        status_obj = fields.get("status", {})
        results.append(
            {
                "key": issue.get("key", ""),
                "summary": fields.get("summary", ""),
                "status": status_obj.get("name", "")
                if isinstance(status_obj, dict)
                else str(status_obj),
            }
        )
    return _success_content(results)


def _handle_update_issue(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_update_issue."""
    client.update_issue(
        issue_key=arguments["issueKey"],
        fields=arguments["fields"],
    )
    return _success_content(
        {"message": f"Issue {arguments['issueKey']} atualizada com sucesso"}
    )


def _handle_add_comment(
    client: JiraClient, arguments: dict
) -> list[TextContent]:
    """Handler para jira_add_comment."""
    result = client.add_comment(
        issue_key=arguments["issueKey"],
        body=arguments["body"],
    )
    return _success_content(
        {
            "message": f"Comentário adicionado à issue {arguments['issueKey']}",
            "id": result.get("id", ""),
        }
    )
