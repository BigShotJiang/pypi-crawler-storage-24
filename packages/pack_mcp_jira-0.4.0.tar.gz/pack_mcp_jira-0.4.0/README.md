# pack-mcp-jira

MCP Server para criação e gestão de tickets no Jira via Basic Auth (REST API v2).

## Variáveis de ambiente

| Variável | Descrição |
|---|---|
| `JIRA_URL` | URL base do Jira (ex: `https://jira.sua-empresa.com`) |
| `JIRA_TOKEN` | Token Basic Auth em base64 (`usuario:senha` encodado) |

Para gerar o token:

```bash
echo -n "usuario:senha" | base64
```

## Ferramentas disponíveis

| Ferramenta | Descrição |
|---|---|
| `jira_get_issue` | Busca detalhes de uma issue pelo key |
| `jira_create_issue` | Cria um novo ticket |
| `jira_search` | Consulta tickets via JQL |
| `jira_update_issue` | Atualiza campos de um ticket |
| `jira_add_comment` | Adiciona comentário a um ticket |

## Instalação

```bash
pip install pack-mcp-jira
```

## Configuração MCP

```json
{
  "mcpServers": {
    "jira": {
      "command": "pack-mcp-jira",
      "env": {
        "JIRA_URL": "https://jira.sua-empresa.com",
        "JIRA_TOKEN": "seu_token_base64"
      }
    }
  }
}
```
