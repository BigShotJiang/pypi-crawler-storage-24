"""Build a module-level dependency graph from scanner output."""

from pathlib import Path

import networkx as nx

from dep_analyzer.scanner.models import FileAnalysis


def file_to_module(file_path: str, repo_root: str) -> str:
    """Convert an absolute file path to a dotted module name relative to repo_root."""
    try:
        rel = Path(file_path).relative_to(repo_root)
    except ValueError:
        return Path(file_path).stem

    parts = list(rel.with_suffix("").parts)
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts) if parts else Path(file_path).stem


def build_module_graph(
    analyses: list[FileAnalysis],
    repo_root: str,
    internal_only: bool = False,
) -> nx.DiGraph:
    """
    Build directed graph where edge A -> B means module A imports module B.

    Args:
        analyses: Parsed file analyses from the scanner.
        repo_root: Absolute path to the repository root.
        internal_only: If True, only include edges to modules within the repo.
    """
    G = nx.DiGraph()

    # Build set of known internal modules
    internal_modules: set[str] = set()
    file_to_mod: dict[str, str] = {}
    for analysis in analyses:
        mod = file_to_module(analysis.file_path, repo_root)
        internal_modules.add(mod)
        file_to_mod[analysis.file_path] = mod
        G.add_node(mod, file=analysis.file_path, internal=True)

    for analysis in analyses:
        src_mod = file_to_mod[analysis.file_path]

        for imp in analysis.imports:
            target = imp.module
            if not target:
                continue

            is_internal = target in internal_modules or any(
                target.startswith(m + ".") for m in internal_modules
            )

            if internal_only and not is_internal:
                continue

            if not G.has_node(target):
                G.add_node(target, internal=is_internal)

            if G.has_edge(src_mod, target):
                # Accumulate multiple imports on the same edge
                G[src_mod][target]["lines"].append(imp.line)
                G[src_mod][target]["names"].extend(imp.names)
            else:
                G.add_edge(
                    src_mod,
                    target,
                    lines=[imp.line],
                    names=imp.names[:],
                    internal=is_internal,
                )

    return G
