"""Build a package-level dependency graph."""

import networkx as nx

from dep_analyzer.deps.models import PackageDep, DependencySet
from dep_analyzer.scanner.models import FileAnalysis


def build_package_graph(dep_set: DependencySet) -> nx.DiGraph:
    """Build a directed graph of package dependencies (declared + transitive)."""
    G = nx.DiGraph()

    for dep in dep_set.direct:
        G.add_node(dep.normalized_name, version=dep.version_spec, direct=True, extras=dep.extras)

    for dep in dep_set.transitive:
        name = dep.normalized_name
        if not G.has_node(name):
            G.add_node(name, version=dep.version_spec, direct=False, extras=[])
        G.add_edge("(project)", name, weight=1)

    for dep in dep_set.direct:
        G.add_edge("(project)", dep.normalized_name, weight=1)

    return G


def build_usage_graph(
    analyses: list[FileAnalysis],
    dep_set: DependencySet,
) -> nx.DiGraph:
    """
    Build a bipartite graph: module -> package.
    Edge means the module imports something from that package.
    """
    G = nx.DiGraph()

    # Map top-level package names to known deps
    pkg_map: dict[str, str] = {}
    for dep in dep_set.all_packages:
        pkg_map[dep.normalized_name] = dep.normalized_name
        # Also map common aliases: PIL -> pillow, cv2 -> opencv-python, etc.

    for analysis in analyses:
        file_node = f"file:{analysis.file_path}"
        G.add_node(file_node, kind="file", path=analysis.file_path)

        for imp in analysis.imports:
            top = imp.top_level_package()
            norm = top.lower().replace("-", "_")
            if norm and norm in pkg_map:
                pkg_node = f"pkg:{pkg_map[norm]}"
                G.add_node(pkg_node, kind="package")
                G.add_edge(file_node, pkg_node, names=imp.names, line=imp.line)

    return G
