"""Build a function/class call graph from scanner output."""

import networkx as nx

from dep_analyzer.scanner.models import FileAnalysis
from dep_analyzer.graph.module_graph import file_to_module


def build_call_graph(analyses: list[FileAnalysis], repo_root: str) -> nx.DiGraph:
    """
    Build a directed graph where edge A -> B means A calls/uses B.
    Nodes are fully-qualified names like myapp.views.MyView.get.
    """
    G = nx.DiGraph()

    for analysis in analyses:
        module = file_to_module(analysis.file_path, repo_root)

        # Add class definitions as nodes
        for cls in analysis.class_usages:
            fqn = f"{module}.{cls.class_name}" if module else cls.class_name
            G.add_node(fqn, kind="class", file=analysis.file_path, line=cls.line)

            for base in cls.base_classes:
                G.add_node(base, kind="class")
                G.add_edge(fqn, base, relation="inherits")

        # Add function calls as edges
        for call in analysis.function_calls:
            caller_scope = f"{module}.{call.module_context}" if call.module_context else module
            callee = call.name

            if not G.has_node(caller_scope):
                G.add_node(caller_scope, kind="scope", file=analysis.file_path)
            if not G.has_node(callee):
                G.add_node(callee, kind="unknown")

            if not G.has_edge(caller_scope, callee):
                G.add_edge(caller_scope, callee, relation="calls", lines=[call.line])
            else:
                G[caller_scope][callee]["lines"].append(call.line)

    return G
