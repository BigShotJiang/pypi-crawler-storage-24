"""Global configuration and defaults."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Config:
    repo_path: Path = Path(".")
    cache_enabled: bool = True
    verbose: bool = False
    output_format: str = "table"  # table | json | dot
    ai_enabled: bool = False
    ai_provider: str = "anthropic"
    ai_api_key: str = ""
    workers: int = 0  # 0 = auto (cpu count)

    @classmethod
    def from_env(cls) -> "Config":
        return cls(
            ai_api_key=os.environ.get("DEP_ANALYZER_API_KEY", ""),
            ai_provider=os.environ.get("DEP_ANALYZER_PROVIDER", "anthropic"),
        )


# Global config instance - set by CLI before any command runs
_config: Config = Config()


def get_config() -> Config:
    return _config


def set_config(cfg: Config):
    global _config
    _config = cfg
