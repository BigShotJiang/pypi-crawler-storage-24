"""
Generate a PDF dependency health report using fpdf2.
Install: pip install dep-analyzer[pdf]
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable


def generate_pdf(
    repo_path: str,
    analyses: list,
    dep_set,
    risk_report,
    coupling_report,
    health_score: int,
    output_path: Path,
    ai_summary: str = "",
    on_step: Callable[[str], None] | None = None,
):
    """
    Write a full dependency health report as a PDF.

    on_step: optional callback called with a status message at each build stage.
             Used by the CLI to show a live progress bar.
    """
    def step(msg: str):
        if on_step:
            on_step(msg)

    try:
        from fpdf import FPDF
    except ImportError:
        raise RuntimeError(
            "fpdf2 not installed.\n"
            "Run: pip install dep-analyzer[pdf]"
        )

    step("Initialising PDF...")
    pdf = _DepReport(repo_path, health_score)
    pdf.add_page()

    # ── Cover info ────────────────────────────────────────────────────────────
    step("Writing header & repo info...")
    pdf.section("Repository")
    pdf.info_row("Path",        repo_path)
    pdf.info_row("Generated",   datetime.now().strftime("%Y-%m-%d %H:%M"))
    pdf.info_row("Files",       str(len(analyses)))
    pdf.info_row("Packages",    str(len(dep_set.direct)))
    pdf.info_row("Health Score", f"{health_score} / 100")
    pdf.ln(4)

    # ── Packages ──────────────────────────────────────────────────────────────
    step(f"Writing {len(dep_set.direct)} direct dependencies...")
    pdf.section("Direct Dependencies")
    pdf.table(
        headers=["Package", "Version", "Source"],
        rows=[
            [d.name, d.version_spec or "any", Path(d.source_file).name]
            for d in dep_set.direct[:50]
        ],
        col_widths=[60, 50, 70],
    )
    if len(dep_set.direct) > 50:
        pdf.note(f"... and {len(dep_set.direct) - 50} more packages not shown")
    pdf.ln(4)

    # ── Risks ─────────────────────────────────────────────────────────────────
    step(f"Writing {len(risk_report.items)} risk item(s)...")
    pdf.section("Dependency Risks")
    if risk_report.items:
        pdf.table(
            headers=["Package", "Type", "Severity", "Message"],
            rows=[
                [i.package, i.risk_type, i.severity, i.message[:65]]
                for i in risk_report.items
            ],
            col_widths=[40, 35, 25, 80],
        )
    else:
        pdf.note("No risks detected.")
    pdf.ln(4)

    # ── Circular dependencies ─────────────────────────────────────────────────
    step(f"Writing {len(coupling_report.circular_deps)} circular dependency cycle(s)...")
    pdf.section("Circular Dependencies")
    if coupling_report.circular_deps:
        for cycle in coupling_report.circular_deps:
            pdf.bullet(" -> ".join(cycle) + " -> " + cycle[0])
    else:
        pdf.note("No circular dependencies detected.")
    pdf.ln(4)

    # ── Coupling metrics ──────────────────────────────────────────────────────
    shown = min(20, len(coupling_report.metrics))
    step(f"Writing coupling metrics ({shown} modules)...")
    pdf.section("Module Coupling (top 20 by instability)")
    pdf.table(
        headers=["Module", "Ca", "Ce", "Instability", "Distance"],
        rows=[
            [
                m.module[-40:],
                str(m.afferent_coupling),
                str(m.efferent_coupling),
                f"{m.instability:.2f}",
                f"{m.distance:.2f}",
            ]
            for m in coupling_report.metrics[:20]
        ],
        col_widths=[75, 15, 15, 30, 25],
    )
    pdf.ln(4)

    # ── AI Summary ────────────────────────────────────────────────────────────
    if ai_summary:
        step("Writing AI summary...")
        pdf.section("AI Analysis Summary")
        pdf.multi_text(ai_summary)
        pdf.ln(4)

    # ── Write file ────────────────────────────────────────────────────────────
    step(f"Saving to {output_path}...")
    pdf.output(str(output_path))
    step("Done.")


# ── PDF helper class ──────────────────────────────────────────────────────────

class _DepReport:
    BRAND_COLOR = (30, 144, 255)
    RED         = (220, 50, 50)
    YELLOW      = (200, 150, 0)
    GREEN       = (34, 139, 34)
    GREY        = (100, 100, 100)
    LIGHT_GREY  = (240, 240, 240)

    def __init__(self, repo_path: str, health_score: int):
        from fpdf import FPDF
        self._pdf = FPDF()
        self._pdf.set_margins(15, 15, 15)
        self._pdf.set_auto_page_break(auto=True, margin=15)
        self._repo = repo_path
        self._score = health_score

    def add_page(self):
        self._pdf.add_page()
        self._draw_header()

    def output(self, path: str):
        self._pdf.output(path)

    def ln(self, h: int = 5):
        self._pdf.ln(h)

    def _draw_header(self):
        pdf = self._pdf
        r, g, b = self.BRAND_COLOR
        pdf.set_fill_color(r, g, b)
        pdf.rect(0, 0, 210, 28, "F")
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Helvetica", "B", 16)
        pdf.set_xy(15, 7)
        pdf.cell(0, 10, "Dependency Hell Analyzer - Health Report")

        score_color = (
            self.GREEN  if self._score >= 70 else
            self.YELLOW if self._score >= 40 else
            self.RED
        )
        r2, g2, b2 = score_color
        pdf.set_fill_color(r2, g2, b2)
        pdf.set_xy(160, 5)
        pdf.set_font("Helvetica", "B", 18)
        pdf.cell(35, 18, f"{self._score}/100", align="C", fill=True)
        pdf.set_text_color(0, 0, 0)
        pdf.set_xy(15, 30)

    def section(self, title: str):
        pdf = self._pdf
        r, g, b = self.BRAND_COLOR
        pdf.set_fill_color(r, g, b)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Helvetica", "B", 11)
        pdf.cell(0, 8, f"  {title}", fill=True, new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(0, 0, 0)
        pdf.set_font("Helvetica", size=9)
        pdf.ln(2)

    def info_row(self, label: str, value: str):
        pdf = self._pdf
        pdf.set_font("Helvetica", "B", 9)
        pdf.cell(40, 6, label + ":")
        pdf.set_font("Helvetica", size=9)
        pdf.cell(0, 6, value, new_x="LMARGIN", new_y="NEXT")

    def table(self, headers: list[str], rows: list[list[str]], col_widths: list[int]):
        pdf = self._pdf
        r, g, b = self.BRAND_COLOR
        pdf.set_fill_color(r, g, b)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font("Helvetica", "B", 8)
        for h, w in zip(headers, col_widths):
            pdf.cell(w, 6, h, border=1, fill=True)
        pdf.ln()

        pdf.set_text_color(0, 0, 0)
        for i, row in enumerate(rows):
            r2, g2, b2 = self.LIGHT_GREY if i % 2 == 0 else (255, 255, 255)
            pdf.set_fill_color(r2, g2, b2)
            pdf.set_font("Helvetica", size=8)
            for cell, w in zip(row, col_widths):
                pdf.cell(w, 5, str(cell)[:42], border=1, fill=True)
            pdf.ln()
        pdf.set_fill_color(255, 255, 255)

    def bullet(self, text: str):
        pdf = self._pdf
        pdf.set_font("Helvetica", size=9)
        pdf.cell(5, 5, "-")
        pdf.multi_cell(0, 5, text)

    def note(self, text: str):
        pdf = self._pdf
        r, g, b = self.GREY
        pdf.set_text_color(r, g, b)
        pdf.set_font("Helvetica", "I", 9)
        pdf.cell(0, 5, text, new_x="LMARGIN", new_y="NEXT")
        pdf.set_text_color(0, 0, 0)

    def multi_text(self, text: str):
        pdf = self._pdf
        pdf.set_font("Helvetica", size=9)
        clean = text.replace("**", "").replace("*", "").replace("`", "")
        pdf.multi_cell(0, 5, clean)
