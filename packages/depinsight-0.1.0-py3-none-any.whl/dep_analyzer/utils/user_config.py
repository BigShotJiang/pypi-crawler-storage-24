"""
User configuration store — saves API keys and provider settings to
~/.dep-analyzer/config.json so users set it once and it works everywhere.

Directory: ~/.dep-analyzer/
  config.json   — provider + API key + preferences
"""

from __future__ import annotations

import json
import os
from pathlib import Path

_CONFIG_DIR  = Path.home() / ".dep-analyzer"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


# ── Read / Write ──────────────────────────────────────────────────────────────

def load_user_config() -> dict:
    """Load saved config. Returns empty dict if not set up yet."""
    if not _CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_user_config(data: dict):
    """Persist config to ~/.dep-analyzer/config.json."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    # Restrict file permissions on Unix (chmod 600)
    try:
        _CONFIG_FILE.chmod(0o600)
    except Exception:
        pass  # Windows doesn't support chmod — silently skip


def get_config_path() -> Path:
    return _CONFIG_FILE


# ── Convenience getters (env var always wins over saved config) ───────────────

def get_api_key() -> str:
    return (
        os.environ.get("DEP_ANALYZER_API_KEY")
        or load_user_config().get("api_key", "")
    )


def get_provider() -> str:
    return (
        os.environ.get("DEP_ANALYZER_PROVIDER")
        or load_user_config().get("provider", "anthropic")
    )


def get_model() -> str | None:
    return (
        os.environ.get("DEP_ANALYZER_MODEL")
        or load_user_config().get("model")
        or None
    )


def is_configured() -> bool:
    """Return True if we have enough config to attempt an AI call."""
    cfg = load_user_config()
    has_key = bool(os.environ.get("DEP_ANALYZER_API_KEY") or cfg.get("api_key"))
    provider = get_provider()
    # Bedrock uses AWS creds, not an API key
    if provider == "bedrock":
        return True
    return has_key
