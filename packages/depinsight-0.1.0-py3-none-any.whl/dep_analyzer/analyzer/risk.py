"""Risk analysis - identify risky or problematic dependencies."""

from __future__ import annotations

from dataclasses import dataclass, field

from dep_analyzer.deps.models import DependencySet, PackageDep

# Packages known to be risky, unmaintained, or commonly problematic
_RISKY_PACKAGES: dict[str, str] = {
    "pycrypto": "Unmaintained; use 'pycryptodome' instead",
    "distribute": "Obsolete; merged into setuptools",
    "nose": "Unmaintained; use pytest",
    "mock": "Stdlib since Python 3.3; use unittest.mock",
    "simplejson": "Consider stdlib json unless you need the performance",
    "pyopenssl": "Can be tricky with OpenSSL versions; ensure pinned",
    "urllib3": "Often needs careful version pinning with requests/boto",
    "cryptography": "Frequent breaking changes; ensure explicit pinning",
}

_DEPRECATED_PACKAGES: set[str] = {
    "distutils",
    "imp",
    "asynchat",
    "asyncore",
    "pipes",
    "cgi",
    "cgitb",
    "telnetlib",
}


@dataclass
class RiskItem:
    package: str
    version_spec: str
    risk_type: str     # UNMAINTAINED | DEPRECATED | UNPINNED | KNOWN_RISK | DUPLICATE
    message: str
    severity: str      # LOW | MEDIUM | HIGH


@dataclass
class RiskReport:
    items: list[RiskItem] = field(default_factory=list)
    unpinned_count: int = 0
    high_risk_count: int = 0

    @property
    def has_issues(self) -> bool:
        return bool(self.items)


class RiskAnalyzer:
    def __init__(self, dep_set: DependencySet):
        self.dep_set = dep_set

    def analyze(self) -> RiskReport:
        items: list[RiskItem] = []

        for dep in self.dep_set.direct:
            items.extend(self._check_dep(dep))

        report = RiskReport(
            items=sorted(items, key=lambda i: {"HIGH": 0, "MEDIUM": 1, "LOW": 2}[i.severity]),
            unpinned_count=sum(1 for i in items if i.risk_type == "UNPINNED"),
            high_risk_count=sum(1 for i in items if i.severity == "HIGH"),
        )
        return report

    def _check_dep(self, dep: PackageDep) -> list[RiskItem]:
        items: list[RiskItem] = []
        name = dep.normalized_name

        # Check known risky packages
        if name in _RISKY_PACKAGES:
            items.append(RiskItem(
                package=dep.name,
                version_spec=dep.version_spec,
                risk_type="KNOWN_RISK",
                message=_RISKY_PACKAGES[name],
                severity="HIGH",
            ))

        # Check deprecated stdlib replacements
        if name in _DEPRECATED_PACKAGES:
            items.append(RiskItem(
                package=dep.name,
                version_spec=dep.version_spec,
                risk_type="DEPRECATED",
                message=f"'{dep.name}' is deprecated or removed in newer Python versions",
                severity="MEDIUM",
            ))

        # Warn about unpinned dependencies
        spec = dep.version_spec.strip()
        if not spec or spec in ("*", ""):
            items.append(RiskItem(
                package=dep.name,
                version_spec=dep.version_spec,
                risk_type="UNPINNED",
                message="No version constraint - any version can be installed",
                severity="MEDIUM",
            ))
        elif spec.startswith(">=") and "," not in spec and "<" not in spec:
            items.append(RiskItem(
                package=dep.name,
                version_spec=dep.version_spec,
                risk_type="UNPINNED",
                message="Open-ended upper bound - breaking changes from future major versions",
                severity="LOW",
            ))

        return items
