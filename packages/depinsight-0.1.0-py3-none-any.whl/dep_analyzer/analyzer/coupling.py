"""Coupling analysis - measure afferent/efferent coupling, instability, cycles."""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path

import networkx as nx

from dep_analyzer.scanner.models import FileAnalysis


@dataclass
class CouplingMetrics:
    module: str
    afferent_coupling: int    # Ca: # of modules that depend ON this one
    efferent_coupling: int    # Ce: # of modules this one depends ON
    instability: float        # I = Ce / (Ca + Ce)
    abstractness: float       # A = abstract_classes / total_classes
    distance: float           # D = |A + I - 1| (distance from main sequence)


@dataclass
class CouplingReport:
    metrics: list[CouplingMetrics] = field(default_factory=list)
    circular_deps: list[list[str]] = field(default_factory=list)
    highly_unstable: list[CouplingMetrics] = field(default_factory=list)
    highly_stable: list[CouplingMetrics] = field(default_factory=list)
    god_modules: list[str] = field(default_factory=list)  # Ce >> average


def analyze_coupling(
    module_graph: nx.DiGraph,
    analyses: list[FileAnalysis] | None = None,
    instability_threshold: float = 0.8,
    max_cycle_length: int = 6,
) -> CouplingReport:
    """Compute coupling metrics for all internal modules in the graph."""

    internal_nodes = {
        n for n, d in module_graph.nodes(data=True)
        if d.get("internal", False)
    }

    # Restrict to internal subgraph for coupling metrics
    internal_graph = module_graph.subgraph(internal_nodes).copy()

    # Build abstractness map if analyses provided
    abstractness_map = _compute_abstractness(analyses) if analyses else {}

    metrics: list[CouplingMetrics] = []
    for node in internal_graph.nodes():
        ca = internal_graph.in_degree(node)
        ce = internal_graph.out_degree(node)
        instability = ce / (ca + ce) if (ca + ce) > 0 else 0.0
        abstractness = abstractness_map.get(node, 0.0)
        distance = abs(abstractness + instability - 1.0)
        metrics.append(CouplingMetrics(
            module=node,
            afferent_coupling=ca,
            efferent_coupling=ce,
            instability=round(instability, 3),
            abstractness=round(abstractness, 3),
            distance=round(distance, 3),
        ))

    metrics.sort(key=lambda m: m.instability, reverse=True)

    # Detect cycles (Johnson's algorithm, limit length to avoid explosion)
    cycles = _find_cycles(internal_graph, max_length=max_cycle_length)

    # Identify problematic modules
    highly_unstable = [m for m in metrics if m.instability >= instability_threshold]
    highly_stable = [m for m in metrics if m.instability <= 0.1 and m.efferent_coupling == 0]

    avg_ce = sum(m.efferent_coupling for m in metrics) / max(len(metrics), 1)
    god_modules = [m.module for m in metrics if m.efferent_coupling > avg_ce * 3]

    return CouplingReport(
        metrics=metrics,
        circular_deps=cycles,
        highly_unstable=highly_unstable,
        highly_stable=highly_stable,
        god_modules=god_modules,
    )


def _find_cycles(G: nx.DiGraph, max_length: int) -> list[list[str]]:
    """Find simple cycles up to max_length. Returns deduplicated list."""
    try:
        all_cycles = nx.simple_cycles(G)
        seen: set[frozenset] = set()
        result: list[list[str]] = []
        for cycle in all_cycles:
            if len(cycle) > max_length:
                continue
            key = frozenset(cycle)
            if key not in seen:
                seen.add(key)
                result.append(cycle)
        return result
    except Exception:
        return []


def _compute_abstractness(analyses: list[FileAnalysis]) -> dict[str, float]:
    """
    Compute abstractness (A) per module.
    A = number of abstract/Protocol classes / total classes.
    Uses ABC and Protocol patterns as heuristics.
    """
    from dep_analyzer.graph.module_graph import file_to_module

    result: dict[str, float] = {}
    abstract_bases = {"ABC", "ABCMeta", "Protocol", "abc.ABC", "abc.ABCMeta"}

    for analysis in analyses:
        if not analysis.class_usages:
            continue
        total = len(analysis.class_usages)
        abstract = sum(
            1 for cls in analysis.class_usages
            if any(b in abstract_bases for b in cls.base_classes)
        )
        abstractness = abstract / total if total > 0 else 0.0
        mod_name = analysis.module_name
        if mod_name:
            result[mod_name] = abstractness

    return result
