"""Impact analysis engine - what breaks when you upgrade a package?"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from dep_analyzer.deps.models import DependencySet
from dep_analyzer.scanner.models import FileAnalysis, FunctionCallInfo, ImportInfo

# Path to curated breaking changes knowledge base
_DATA_DIR = Path(__file__).parent.parent.parent.parent / "data" / "breaking_changes"

# ── Call-level validation rules ───────────────────────────────────────────────
# Maps "api_name" -> callable(call: FunctionCallInfo) -> (safe: bool, note: str, fix: str)
# Return safe=True to downgrade severity to SAFE; False to keep original risk.

def _requests_http_rule(method: str):
    def _rule(c):
        if "timeout" in c.kwargs:
            return (True, "timeout explicitly provided - safe", "")
        return (
            False,
            "missing timeout kwarg — requests 3.0 changed default timeout behaviour",
            f"Before: {method}(url)\nAfter:  {method}(url, timeout=10)",
        )
    return _rule


def _requests_session_rule(c):
    return (
        False,
        "Session connection pooling behaviour changed in 3.0",
        "Check Session mount adapters and retry logic after upgrading.",
    )


_CALL_RULES: dict[str, object] = {
    "requests.get":     _requests_http_rule("requests.get"),
    "requests.post":    _requests_http_rule("requests.post"),
    "requests.put":     _requests_http_rule("requests.put"),
    "requests.delete":  _requests_http_rule("requests.delete"),
    "requests.patch":   _requests_http_rule("requests.patch"),
    "requests.head":    _requests_http_rule("requests.head"),
    "requests.Session": _requests_session_rule,
}


@dataclass
class BreakingAPI:
    old_api: str
    new_api: str | None
    change_type: str   # REMOVED | MOVED | SIGNATURE_CHANGED | DEPRECATED
    detail: str = ""


@dataclass
class AffectedFile:
    file_path: str
    line: int
    import_str: str     # what was imported
    risk: str           # REMOVED | CHANGED | DEPRECATED | UNKNOWN | SAFE
    breaking_api: BreakingAPI | None = None
    call_line: int | None = None        # line where the API is actually called
    confidence: str = "LOW"             # HIGH | MEDIUM | LOW
    note: str = ""                      # human-readable reason for risk/safe verdict
    fix_suggestion: str = ""            # before/after fix hint


@dataclass
class ImpactResult:
    package: str
    current_version: str
    target_version: str
    affected_files: list[AffectedFile] = field(default_factory=list)
    breaking_apis: list[BreakingAPI] = field(default_factory=list)
    severity: str = "LOW"
    summary: str = ""
    dynamic_import_warning: bool = False


class ImpactAnalyzer:
    """Analyze the impact of upgrading a specific package."""

    def __init__(self, analyses: list[FileAnalysis], dep_set: DependencySet):
        self.analyses = analyses
        self.dep_set = dep_set
        self._breaking_db: dict = {}
        self._load_breaking_db()

    # ── Public API ────────────────────────────────────────────────────────────

    def analyze(self, package_spec: str) -> ImpactResult:
        """
        Analyze upgrade impact for 'package==version' or 'package>=version'.
        Examples: 'django==4.0', 'flask>=2.0', 'requests'
        """
        package, target_version = self._parse_spec(package_spec)

        current_dep = self.dep_set.find(package)
        current_version = current_dep.version_spec if current_dep else "unknown"

        # Layer 1: Find all files that import this package
        usages = self._find_usages(package)

        # Layer 2: Check breaking changes database
        breaking_apis = self._get_breaking_apis(package, target_version)

        # Layer 3: Classify affected files
        affected_files = self._classify_affected(usages, breaking_apis)

        # Layer 4: Check for dynamic imports
        dynamic_warning = any(a.has_dynamic_imports for a in self.analyses)

        severity = self._compute_severity(affected_files)
        summary = self._build_summary(package, target_version, affected_files, breaking_apis)

        return ImpactResult(
            package=package,
            current_version=current_version,
            target_version=target_version,
            affected_files=affected_files,
            breaking_apis=breaking_apis,
            severity=severity,
            summary=summary,
            dynamic_import_warning=dynamic_warning,
        )

    # ── Internals ─────────────────────────────────────────────────────────────

    def _parse_spec(self, spec: str) -> tuple[str, str]:
        """Parse 'django==4.0' -> ('django', '4.0')."""
        for sep in ("==", ">=", "<=", "~=", "!="):
            if sep in spec:
                parts = spec.split(sep, 1)
                return parts[0].strip().lower(), parts[1].strip()
        return spec.strip().lower(), "latest"

    def _find_usages(self, package: str) -> list[tuple[FileAnalysis, ImportInfo]]:
        """Find all (file, import) pairs that use the given package."""
        results = []
        norm = package.lower().replace("-", "_")
        for analysis in self.analyses:
            for imp in analysis.imports:
                top = imp.top_level_package().lower().replace("-", "_")
                if top == norm:
                    results.append((analysis, imp))
        return results

    def _calls_in_file(self, analysis: FileAnalysis, api_prefix: str) -> list[FunctionCallInfo]:
        """Return all function calls in a file whose name starts with api_prefix."""
        return [c for c in analysis.function_calls if c.name.startswith(api_prefix)]

    def _from_import_calls(self, analysis: FileAnalysis, imp: ImportInfo) -> list[FunctionCallInfo]:
        """
        For 'from X import url, force_text' find calls to 'url(...)' or 'force_text(...)'.
        Handles aliases: 'from X import url as u' → look for 'u(...)'.
        """
        if not imp.is_from_import:
            return []
        # Build set of names that the import makes available in the local scope
        local_names: set[str] = set()
        for name in imp.names:
            local_names.add(imp.alias or name)
        return [c for c in analysis.function_calls if c.name in local_names]

    def _get_breaking_apis(self, package: str, version: str) -> list[BreakingAPI]:
        """Look up known breaking changes for this package + version."""
        pkg_data = self._breaking_db.get(package, {})
        if not pkg_data:
            # Try common aliases
            aliases = {"pillow": "pil", "opencv-python": "cv2"}
            pkg_data = self._breaking_db.get(aliases.get(package, ""), {})

        if not pkg_data:
            return []

        apis: list[BreakingAPI] = []

        # Collect all breaking changes up to and including the target version
        for ver, changes in pkg_data.items():
            if not self._version_lte(ver, version):
                continue
            for api_info in changes.get("removed", []):
                apis.append(BreakingAPI(
                    old_api=api_info["api"],
                    new_api=api_info.get("replacement"),
                    change_type="REMOVED",
                    detail=api_info.get("detail", ""),
                ))
            for api_info in changes.get("changed", []):
                apis.append(BreakingAPI(
                    old_api=api_info["api"],
                    new_api=api_info.get("replacement"),
                    change_type="SIGNATURE_CHANGED",
                    detail=api_info.get("detail", ""),
                ))
            for api_info in changes.get("deprecated", []):
                apis.append(BreakingAPI(
                    old_api=api_info["api"],
                    new_api=api_info.get("replacement"),
                    change_type="DEPRECATED",
                    detail=api_info.get("detail", ""),
                ))
        return apis

    def _classify_affected(
        self,
        usages: list[tuple[FileAnalysis, ImportInfo]],
        breaking_apis: list[BreakingAPI],
    ) -> list[AffectedFile]:
        """Cross-reference file imports with known breaking APIs, refined by call-level analysis."""
        results: list[AffectedFile] = []
        breaking_map = {b.old_api: b for b in breaking_apis}

        for analysis, imp in usages:
            import_str = self._format_import(imp)
            matched_api: BreakingAPI | None = None
            risk = "UNKNOWN"
            note = ""
            fix = ""
            confidence = "LOW"
            call_line: int | None = None

            # ── Match import against breaking APIs ────────────────────────────
            for api_name, api in breaking_map.items():
                if imp.module == api_name or any(
                    f"{imp.module}.{name}" == api_name for name in imp.names
                ):
                    matched_api = api
                    risk = api.change_type
                    break
                if api_name.startswith(imp.module + "."):
                    matched_api = api
                    risk = api.change_type
                    break

            if not matched_api and breaking_apis:
                risk = "UNKNOWN"

            # ── Refine with actual call-site analysis ─────────────────────────
            pkg = imp.top_level_package()
            # Qualified calls: requests.get(...) — matches pkg prefix
            qualified_calls = self._calls_in_file(analysis, pkg + ".")
            # From-import calls: from django.x import url → url(...)
            from_calls = self._from_import_calls(analysis, imp)
            actual_calls = qualified_calls + from_calls

            if matched_api and actual_calls:
                # For qualified calls check exact match; for from-import check imported name
                api_short = matched_api.old_api.split(".")[-1]  # e.g. "url" from "django.conf.urls.url"
                api_calls = [
                    c for c in actual_calls
                    if c.name == matched_api.old_api or c.name == api_short
                ]
                if not api_calls:
                    # Package called but not the specific breaking API
                    risk = "UNKNOWN"
                    note = f"{matched_api.old_api} not called directly"
                    confidence = "MEDIUM"
                else:
                    call_line = api_calls[0].line
                    confidence = "HIGH"
                    # Apply call-level rules if available
                    rule = _CALL_RULES.get(matched_api.old_api)
                    if rule:
                        safe, rule_note, fix = rule(api_calls[0])
                        note = rule_note
                        if safe:
                            risk = "SAFE"
                            confidence = "HIGH"
                    elif not note:
                        note = f"{matched_api.old_api} used — verify compatibility"
            elif matched_api and not actual_calls:
                # Import matched a breaking API but no calls found at all — cannot confirm usage
                risk = "UNKNOWN"
                note = "No calls detected — import-level match only"
                confidence = "LOW"
            elif not actual_calls and breaking_apis:
                note = "Package imported but no calls detected"
                confidence = "LOW"

            results.append(AffectedFile(
                file_path=analysis.file_path,
                line=imp.line,
                import_str=import_str,
                risk=risk,
                breaking_api=matched_api,
                call_line=call_line,
                confidence=confidence,
                note=note,
                fix_suggestion=fix,
            ))

        return results

    def _format_import(self, imp: ImportInfo) -> str:
        if imp.is_from_import:
            return f"from {imp.module} import {', '.join(imp.names)}"
        alias = f" as {imp.alias}" if imp.alias else ""
        return f"import {imp.module}{alias}"

    def _compute_severity(self, affected: list[AffectedFile]) -> str:
        if not affected:
            return "NONE"
        # Only count confirmed usages (MEDIUM+ confidence) for severity
        confirmed = [f for f in affected if f.confidence in ("HIGH", "MEDIUM") and f.risk not in ("SAFE", "NONE", "UNKNOWN")]
        if not confirmed:
            # Check if anything was actually called at all
            if all(f.risk in ("SAFE", "NONE", "UNKNOWN") for f in affected):
                return "LOW" if any(f.risk == "UNKNOWN" for f in affected) else "NONE"
        removed = sum(1 for f in confirmed if f.risk == "REMOVED")
        changed = sum(1 for f in confirmed if f.risk == "SIGNATURE_CHANGED")
        if removed >= 5 or changed >= 10:
            return "CRITICAL"
        if removed > 0 or changed > 0:
            return "HIGH"
        if len(affected) > 10:
            return "MEDIUM"
        return "LOW"

    def _build_summary(
        self,
        package: str,
        version: str,
        affected: list[AffectedFile],
        breaking_apis: list[BreakingAPI],
    ) -> str:
        lines = [f"Upgrading {package} -> {version}"]
        if not affected:
            lines.append("No affected files detected.")
            return "\n".join(lines)

        lines.append(f"{len(affected)} file(s) import this package.")

        if breaking_apis:
            matched = {af.breaking_api.old_api for af in affected if af.breaking_api}
            relevant = [a for a in breaking_apis if a.old_api in matched]
            ignored  = [a for a in breaking_apis if a.old_api not in matched]
            lines.append(f"Breaking changes: {len(relevant)} relevant, {len(ignored)} ignored (not used in codebase).")
            for af in affected:
                if af.breaking_api:
                    lines.append(f"  * {af.breaking_api.old_api} -> {af.risk} ({af.note})" if af.note
                                 else f"  * {af.breaking_api.old_api} -> {af.risk}")
        else:
            lines.append("No breaking changes found in database (manual review recommended).")
        return "\n".join(lines)

    def _load_breaking_db(self):
        """Load all YAML files from data/breaking_changes/."""
        if not _DATA_DIR.exists():
            return
        for yaml_file in _DATA_DIR.glob("*.yml"):
            try:
                data = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self._breaking_db.update(data)
            except Exception:
                pass

    @staticmethod
    def _version_lte(ver_a: str, ver_b: str) -> bool:
        """Return True if version a <= version b (simple numeric comparison)."""
        if ver_b in ("latest", ""):
            return True
        try:
            from packaging.version import Version
            return Version(ver_a) <= Version(ver_b)
        except Exception:
            return ver_a <= ver_b
