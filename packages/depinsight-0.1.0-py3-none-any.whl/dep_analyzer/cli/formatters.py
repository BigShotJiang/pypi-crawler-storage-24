"""Rich-based output formatters for all commands."""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

console = Console()
err_console = Console(stderr=True)

# ── Severity colors ───────────────────────────────────────────────────────────

SEVERITY_STYLE: dict[str, str] = {
    "CRITICAL": "bold red",
    "HIGH": "red",
    "MEDIUM": "yellow",
    "LOW": "green",
    "NONE": "dim",
    "SAFE": "bold green",
    "UNKNOWN": "cyan",
    "REMOVED": "bold red",
    "SIGNATURE_CHANGED": "yellow",
    "DEPRECATED": "dim yellow",
}


def severity_text(s: str) -> Text:
    return Text(s, style=SEVERITY_STYLE.get(s, "white"))


# ── Impact formatters ─────────────────────────────────────────────────────────

def render_impact(result, output_format: str = "table"):
    from dep_analyzer.analyzer.impact import ImpactResult
    if output_format == "json":
        _render_json(_impact_to_dict(result))
        return

    # Header
    sev = severity_text(result.severity)
    console.print()
    console.print(Panel(
        f"[bold]{result.package}[/] {result.current_version} -> [bold]{result.target_version}[/]\n"
        f"Severity: {sev}",
        title="Impact Analysis",
        border_style="cyan",
    ))

    if result.dynamic_import_warning:
        dynamic_files = [a for a in getattr(result, "_analyses", []) if getattr(a, "has_dynamic_imports", False)]
        count_hint = f" in {len(dynamic_files)} file(s)" if dynamic_files else ""
        console.print(
            f"[yellow]!! Dynamic imports detected{count_hint} - "
            f"confidence reduced for those modules[/]"
        )

    if result.breaking_apis:
        # Split into used vs unused based on what was matched to actual files
        matched_apis = {
            af.breaking_api.old_api
            for af in result.affected_files
            if af.breaking_api is not None
        }
        relevant = [a for a in result.breaking_apis if a.old_api in matched_apis]
        ignored  = [a for a in result.breaking_apis if a.old_api not in matched_apis]

        if relevant:
            table = Table(title="Relevant Breaking Changes (detected in codebase)", show_header=True)
            table.add_column("Type", style="bold")
            table.add_column("API", style="red")
            table.add_column("New API / Replacement", style="green")
            table.add_column("Detail")
            table.add_column("Status")
            for api in relevant:
                # Find the verdict for this API
                verdict = next(
                    (af for af in result.affected_files if af.breaking_api and af.breaking_api.old_api == api.old_api),
                    None,
                )
                status = severity_text(verdict.risk) if verdict else Text("UNKNOWN")
                table.add_row(
                    api.change_type,
                    api.old_api,
                    api.new_api or "[dim]-[/]",
                    api.detail or "",
                    status,
                )
            console.print(table)
        else:
            console.print("[dim]No relevant breaking changes found for APIs used in this codebase.[/]")

        if ignored:
            ignored_names = ", ".join(f"[dim]{a.old_api}[/]" for a in ignored)
            console.print(f"[dim]Ignored (not used in codebase): {ignored_names}[/]")
    else:
        console.print("[dim]No breaking changes found in database.[/]")

    if result.affected_files:
        table = Table(title=f"Affected Files ({len(result.affected_files)})", show_header=True)
        table.add_column("File (click to open)", style="cyan")
        table.add_column("Line", justify="right")
        table.add_column("Import")
        table.add_column("Risk")
        table.add_column("Confidence")
        table.add_column("Note", style="dim")

        for af in result.affected_files:
            abs_path = str(Path(af.file_path).resolve())
            uri = "file:///" + abs_path.replace("\\", "/").lstrip("/")
            display_line = af.call_line or af.line
            link_text = Text(_short_path(af.file_path), style=f"cyan link {uri}")
            confidence_label = _confidence_label(af)
            table.add_row(
                link_text,
                str(display_line),
                af.import_str,
                severity_text(af.risk),
                confidence_label,
                af.note or "",
            )
        console.print(table)

    console.print()
    console.print(Panel(result.summary, title="Summary", border_style="dim"))

    # ── Upgrade Safety verdict ─────────────────────────────────────────────────
    _render_upgrade_safety(result)


def _render_upgrade_safety(result):
    af = result.affected_files
    risky    = [f for f in af if f.risk not in ("SAFE", "NONE", "UNKNOWN")]
    safe     = [f for f in af if f.risk == "SAFE"]
    unknown  = [f for f in af if f.risk == "UNKNOWN"]
    dynamic  = result.dynamic_import_warning

    # Upgrade safety level
    if risky:
        safety = "UNSAFE"
        safety_color = "red"
        testing = "HIGH - run full test suite before deploying"
    elif unknown:
        safety = "REVIEW NEEDED"
        safety_color = "yellow"
        testing = "MEDIUM - test modules with dynamic imports"
    elif safe:
        safety = "SAFE TO UPGRADE"
        safety_color = "green"
        testing = "LOW - spot-check affected modules"
    else:
        safety = "SAFE TO UPGRADE"
        safety_color = "green"
        testing = "LOW - no usage detected"

    # Why safe reasons
    reasons: list[str] = []
    if safe:
        for f in safe:
            reasons.append(f"[green]OK[/] {f.note or 'usage verified safe'}")
    if not risky and not unknown:
        reasons.append("[green]OK[/] No deprecated APIs used")
    if not dynamic:
        reasons.append("[green]OK[/] No dynamic imports detected")
    if risky:
        for f in risky:
            reasons.append(f"[red]!![/] {f.breaking_api.old_api if f.breaking_api else f.import_str} -> {f.risk}")

    # Scan coverage
    total_imports = sum(len(getattr(a, "imports", [])) for a in getattr(result, "_analyses", []))
    total_files   = len(getattr(result, "_analyses", []))

    body = (
        f"[bold {safety_color}]Upgrade Safety: {safety}[/]\n"
        f"[dim]Recommended Testing: {testing}[/]\n\n"
    )
    if reasons:
        body += "\n".join(f"  {r}" for r in reasons)

    if total_files:
        body += (
            f"\n\n[dim]Scan Coverage: {total_files} file(s) | "
            f"{len(af)} usage(s) detected | "
            f"{len(safe)} safe | {len(risky)} risky[/]"
        )

    console.print(Panel(body, title="Upgrade Decision", border_style=safety_color))


def _impact_to_dict(result) -> dict:
    return {
        "package": result.package,
        "current_version": result.current_version,
        "target_version": result.target_version,
        "severity": result.severity,
        "summary": result.summary,
        "breaking_apis": [
            {"old_api": a.old_api, "new_api": a.new_api, "change_type": a.change_type, "detail": a.detail}
            for a in result.breaking_apis
        ],
        "affected_files": [
            {"file": af.file_path, "line": af.line, "import": af.import_str, "risk": af.risk}
            for af in result.affected_files
        ],
    }


# ── Coupling formatters ───────────────────────────────────────────────────────

def render_coupling(report, output_format: str = "table"):
    if output_format == "json":
        _render_json(_coupling_to_dict(report))
        return

    console.print()

    if report.circular_deps:
        console.print(Panel(
            "\n".join(
                f"  [red]{' -> '.join(c)} -> {c[0]}[/]"
                for c in report.circular_deps
            ),
            title=f"[bold red]Circular Dependencies ({len(report.circular_deps)})[/]",
            border_style="red",
        ))
    else:
        console.print("[green]OK No circular dependencies detected[/]")

    if report.god_modules:
        console.print(f"\n[yellow]God modules (high Ce):[/] {', '.join(report.god_modules)}")

    table = Table(title="Module Coupling Metrics", show_header=True)
    table.add_column("Module", style="cyan")
    table.add_column("Ca (in)", justify="right")
    table.add_column("Ce (out)", justify="right")
    table.add_column("Instability", justify="right")
    table.add_column("Abstractness", justify="right")
    table.add_column("Distance", justify="right")

    for m in report.metrics[:25]:
        inst_style = "red" if m.instability >= 0.8 else ("yellow" if m.instability >= 0.5 else "green")
        table.add_row(
            m.module,
            str(m.afferent_coupling),
            str(m.efferent_coupling),
            Text(f"{m.instability:.2f}", style=inst_style),
            f"{m.abstractness:.2f}",
            f"{m.distance:.2f}",
        )

    console.print(table)


def _coupling_to_dict(report) -> dict:
    return {
        "circular_deps": report.circular_deps,
        "god_modules": report.god_modules,
        "metrics": [
            {
                "module": m.module,
                "Ca": m.afferent_coupling,
                "Ce": m.efferent_coupling,
                "instability": m.instability,
                "abstractness": m.abstractness,
                "distance": m.distance,
            }
            for m in report.metrics
        ],
    }


# ── Scan formatters ───────────────────────────────────────────────────────────

def render_scan_summary(analyses, dep_set, elapsed: float, output_format: str = "table"):
    if output_format == "json":
        _render_json({
            "files_scanned": len(analyses),
            "packages": len(dep_set.direct),
            "elapsed_seconds": round(elapsed, 2),
        })
        return

    console.print()
    console.print(Panel(
        f"[green]OK[/] Scanned [bold]{len(analyses)}[/] Python files\n"
        f"[green]OK[/] Found [bold]{len(dep_set.direct)}[/] direct dependencies\n"
        f"[dim]Completed in {elapsed:.2f}s[/]",
        title="Scan Complete",
        border_style="green",
    ))

    if dep_set.direct:
        table = Table(title="Direct Dependencies", show_header=True)
        table.add_column("Package", style="cyan")
        table.add_column("Version Spec")
        table.add_column("Source")
        for dep in dep_set.direct[:30]:
            table.add_row(dep.name, dep.version_spec or "[dim]any[/]", Path(dep.source_file).name)
        if len(dep_set.direct) > 30:
            console.print(f"[dim]... and {len(dep_set.direct) - 30} more[/]")
        console.print(table)


# ── Risk formatters ───────────────────────────────────────────────────────────

def render_risk(report, output_format: str = "table"):
    if output_format == "json":
        _render_json({
            "items": [
                {"package": i.package, "risk_type": i.risk_type,
                 "severity": i.severity, "message": i.message}
                for i in report.items
            ]
        })
        return

    if not report.has_issues:
        console.print("[green]OK  No dependency risks detected[/]")
        return

    table = Table(title=f"Dependency Risks ({len(report.items)} found)")
    table.add_column("Package", style="cyan")
    table.add_column("Version")
    table.add_column("Risk Type")
    table.add_column("Severity")
    table.add_column("Message")

    for item in report.items:
        table.add_row(
            item.package,
            item.version_spec or "any",
            item.risk_type,
            severity_text(item.severity),
            item.message,
        )
    console.print(table)


# ── Trace formatters ──────────────────────────────────────────────────────────

def render_trace(package: str, affected_files, output_format: str = "table"):
    if output_format == "json":
        _render_json({
            "package": package,
            "usages": [
                {"file": af.file_path, "line": af.line, "import": af.import_str}
                for af in affected_files
            ]
        })
        return

    if not affected_files:
        console.print(f"[dim]No imports of '{package}' found.[/]")
        return

    tree = Tree(f"[bold cyan]{package}[/] - {len(affected_files)} usage(s)")
    for af in affected_files:
        branch = tree.add(f"[cyan]{_short_path(af.file_path)}[/]:{af.line}")
        branch.add(f"[dim]{af.import_str}[/]")
    console.print(tree)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _render_json(data: dict):
    console.print_json(json.dumps(data, indent=2, default=str))


def _confidence_label(af) -> str:
    reason = (
        "argument-level analysis" if af.call_line else
        "import-level analysis"
    )
    return f"{af.confidence} ({reason})"


def _short_path(path: str, max_parts: int = 4) -> str:
    parts = Path(path).parts
    if len(parts) <= max_parts:
        return str(Path(path))
    return ".../" + "/".join(parts[-max_parts:])
