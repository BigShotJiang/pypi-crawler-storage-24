"""dep-analyzer report - generate a full analysis report (terminal + optional PDF)."""

from __future__ import annotations

import time
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

from dep_analyzer.analyzer.coupling import analyze_coupling
from dep_analyzer.analyzer.risk import RiskAnalyzer
from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.cli.formatters import render_coupling, render_risk, render_scan_summary
from dep_analyzer.graph.module_graph import build_module_graph

console = Console()


def report_command(
    repo_path: Path = typer.Option(
        Path("."), "--repo", "-r", exists=True, file_okay=False,
        help="Repository path.",
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    output: str = typer.Option("table", "--format", "-f", help="table | json"),
    pdf: bool = typer.Option(
        False, "--pdf",
        help="Also export a PDF report.",
    ),
    pdf_out: Path = typer.Option(
        None, "--pdf-out",
        help="PDF output path (default: <repo>/dep-report.pdf).",
    ),
    ai: bool = typer.Option(False, "--ai", help="Add AI summary to the report."),
    ai_provider: str = typer.Option(None, "--provider"),
    ai_model: str = typer.Option(None, "--model"),
):
    """
    Generate a full dependency health report.

    Shows: scan summary, dependency risks, coupling metrics, health score.
    Optionally exports as a PDF.

    Examples:

      dep-analyzer report

      dep-analyzer report --pdf

      dep-analyzer report --pdf --pdf-out /tmp/myreport.pdf

      dep-analyzer report --pdf --ai
    """
    start = time.monotonic()
    repo_path = repo_path.resolve()
    console.print(f"\n[bold]Full Report:[/] [cyan]{repo_path}[/]\n")

    # ── Scan ──────────────────────────────────────────────────────────────────
    engine = ScanEngine(repo_path, use_cache=not no_cache)
    analyses, dep_set = engine.run()
    elapsed = time.monotonic() - start

    # ── Terminal output ───────────────────────────────────────────────────────
    console.print(Rule("[bold]Scan Summary[/]"))
    render_scan_summary(analyses, dep_set, elapsed, output_format=output)

    console.print()
    console.print(Rule("[bold]Dependency Risks[/]"))
    risk_report = RiskAnalyzer(dep_set).analyze()
    render_risk(risk_report, output_format=output)

    console.print()
    console.print(Rule("[bold]Module Coupling[/]"))
    G = build_module_graph(analyses, str(repo_path), internal_only=True)
    coupling_report = analyze_coupling(G, analyses=analyses)
    render_coupling(coupling_report, output_format=output)

    score = _health_score(risk_report, coupling_report, analyses)
    color = "green" if score >= 70 else ("yellow" if score >= 40 else "red")
    console.print()
    console.print(Panel(
        f"[bold {color}]Health Score: {score}/100[/]\n"
        f"[dim]Risks: {risk_report.high_risk_count} high  |  "
        f"Cycles: {len(coupling_report.circular_deps)}  |  "
        f"Parse errors: {sum(1 for a in analyses if a.parse_error)}[/]",
        title="Overall Health",
        border_style=color,
    ))

    # ── AI summary (optional) ─────────────────────────────────────────────────
    ai_summary = ""
    if ai:
        ai_summary = _get_ai_summary(coupling_report, ai_provider, ai_model)

    # ── PDF export (optional) ─────────────────────────────────────────────────
    if pdf:
        out = pdf_out or (repo_path / "dep-report.pdf")
        _export_pdf(
            repo_path=str(repo_path),
            analyses=analyses,
            dep_set=dep_set,
            risk_report=risk_report,
            coupling_report=coupling_report,
            health_score=score,
            output_path=out,
            ai_summary=ai_summary,
        )


def _get_ai_summary(coupling_report, ai_provider, ai_model) -> str:
    from dep_analyzer.ai.llm import LLMAnalyzer
    from dep_analyzer.cli.setup_cmd import run_setup_if_needed
    from dep_analyzer.utils.user_config import get_api_key, get_provider, get_model

    run_setup_if_needed()

    try:
        llm = LLMAnalyzer(
            provider=ai_provider or get_provider(),
            model=ai_model or get_model(),
            api_key=get_api_key(),
        )
    except ValueError as e:
        console.print(f"[red]{e}[/]")
        return ""

    if not llm.is_available():
        console.print(f"[yellow]AI not available: {llm.unavailable_reason()}[/]")
        return ""

    console.print(f"\n[bold]AI Summary[/] [dim]via {llm.provider_name} / {llm.model_name}[/]...")
    summary = llm.analyze_coupling(coupling_report)
    if summary:
        console.print(Panel(summary, title="AI Summary", border_style="magenta"))
    return summary


def _export_pdf(repo_path, analyses, dep_set, risk_report, coupling_report,
                health_score, output_path, ai_summary):
    from rich.progress import Progress, SpinnerColumn, TextColumn

    try:
        from dep_analyzer.utils.pdf_report import generate_pdf
    except RuntimeError as e:
        console.print(Panel(str(e), title="[red]PDF Error[/]", border_style="red"))
        return

    console.print()

    errors: list[str] = []

    with Progress(
        SpinnerColumn(spinner_name="line"),   # ASCII: - \ | /
        TextColumn("[cyan]{task.description}"),
        console=console,
        transient=False,
    ) as progress:
        task = progress.add_task("Preparing PDF...", total=None)

        def on_step(msg: str):
            progress.update(task, description=msg)

        try:
            generate_pdf(
                repo_path=repo_path,
                analyses=analyses,
                dep_set=dep_set,
                risk_report=risk_report,
                coupling_report=coupling_report,
                health_score=health_score,
                output_path=output_path,
                ai_summary=ai_summary,
                on_step=on_step,
            )
            progress.update(task, description="[green]PDF complete.")
        except RuntimeError as e:
            errors.append(str(e))
            progress.update(task, description="[red]PDF failed.")
        except Exception as e:
            errors.append(f"Unexpected error: {e}")
            progress.update(task, description="[red]PDF failed.")

    if errors:
        console.print(Panel(
            "\n".join(errors),
            title="[red]PDF Generation Failed[/]",
            border_style="red",
        ))
        return

    size_kb = output_path.stat().st_size // 1024
    console.print(Panel(
        f"[green]Saved:[/]  {output_path}\n"
        f"[green]Size:[/]   {size_kb} KB",
        title="[green]PDF Report Ready[/]",
        border_style="green",
    ))


def _health_score(risk_report, coupling_report, analyses) -> int:
    score = 100
    score -= min(risk_report.high_risk_count * 10, 30)
    score -= min(risk_report.unpinned_count * 3, 20)
    score -= min(len(coupling_report.circular_deps) * 5, 25)
    score -= min(sum(1 for a in analyses if a.parse_error) * 2, 10)
    score -= min(sum(1 for m in coupling_report.metrics if m.instability >= 0.8) * 2, 15)
    return max(0, score)
