"""dep-analyzer scan - scan a repository and cache results."""

from __future__ import annotations

import time
from pathlib import Path

import typer
from rich.console import Console

from dep_analyzer.analyzer.risk import RiskAnalyzer
from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.cli.formatters import render_scan_summary, render_risk

console = Console()


def scan_command(
    repo_path: Path = typer.Argument(
        default=Path("."),
        help="Path to the Python repository to scan.",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    no_cache: bool = typer.Option(False, "--no-cache", help="Force a fresh scan, ignoring cache."),
    workers: int = typer.Option(0, "--workers", "-w", help="Parallel workers (0=auto)."),
    output: str = typer.Option("table", "--format", "-f", help="Output format: table | json"),
    show_risks: bool = typer.Option(True, "--risks/--no-risks", help="Show dependency risks."),
):
    """
    Scan a Python repository, extract imports, build dependency graphs, and cache results.

    Results are cached in [cyan].dep-analyzer/cache.json[/] within the repo.
    """
    start = time.monotonic()
    console.print(f"\n[bold]Scanning[/] [cyan]{repo_path}[/]...\n")

    engine = ScanEngine(repo_path, use_cache=not no_cache, workers=workers)
    analyses, dep_set = engine.run()

    elapsed = time.monotonic() - start
    render_scan_summary(analyses, dep_set, elapsed, output_format=output)

    if show_risks and dep_set.direct:
        console.print()
        risk_report = RiskAnalyzer(dep_set).analyze()
        if risk_report.has_issues:
            console.print(f"[yellow]!!  {risk_report.high_risk_count} high-risk, "
                          f"{risk_report.unpinned_count} unpinned dependencies[/]")
            render_risk(risk_report, output_format=output)
        else:
            console.print("[green]OK  No dependency risks detected[/]")

    # Parse errors
    errors = [a for a in analyses if a.parse_error]
    if errors:
        console.print(f"\n[yellow]!!  {len(errors)} file(s) could not be parsed "
                      f"(syntax errors or encoding issues)[/]")

    dynamic = [a for a in analyses if a.has_dynamic_imports]
    if dynamic:
        console.print(f"[yellow]!!  {len(dynamic)} file(s) use dynamic imports "
                      f"- analysis may be incomplete[/]")
