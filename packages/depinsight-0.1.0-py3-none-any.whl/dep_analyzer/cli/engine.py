"""
Shared scanning engine used by all CLI commands.
Handles discovery, AST parsing (parallel), dep parsing, graph construction, and caching.
"""

from __future__ import annotations

import dataclasses
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from dep_analyzer.cache.store import CacheStore
from dep_analyzer.deps.models import DependencySet, PackageDep
from dep_analyzer.deps.pyproject_parser import parse_pyproject, parse_setup_cfg
from dep_analyzer.deps.requirements_parser import parse_requirements
from dep_analyzer.graph.module_graph import build_module_graph, file_to_module
from dep_analyzer.scanner.ast_parser import analyze_file
from dep_analyzer.scanner.file_discovery import discover_dep_files, discover_python_files
from dep_analyzer.scanner.models import FileAnalysis


def _analyze_file_worker(file_path: Path) -> FileAnalysis:
    """Top-level function for multiprocessing (must be picklable)."""
    return analyze_file(file_path)


class ScanEngine:
    """Orchestrates a full repository scan."""

    def __init__(self, repo_path: Path, use_cache: bool = True, workers: int = 0):
        self.repo_path = repo_path.resolve()
        self.use_cache = use_cache
        self.workers = workers or None  # None = os.cpu_count()
        self.cache = CacheStore(self.repo_path)

    def run(self) -> tuple[list[FileAnalysis], DependencySet]:
        """
        Run the full scan. Returns (analyses, dep_set).
        Uses cache if available and files haven't changed.
        """
        start = time.monotonic()

        if self.use_cache and self.cache.load() and not self.cache.is_stale():
            cached = self._load_from_cache()
            if cached:
                return cached

        analyses, dep_set = self._full_scan()

        if self.use_cache:
            self._save_to_cache(analyses, dep_set)

        elapsed = time.monotonic() - start
        return analyses, dep_set

    # ── Internal ──────────────────────────────────────────────────────────────

    def _full_scan(self) -> tuple[list[FileAnalysis], DependencySet]:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            transient=True,
        ) as progress:
            # Discover files
            task = progress.add_task("Discovering Python files...", total=None)
            py_files = discover_python_files(self.repo_path)
            dep_files = discover_dep_files(self.repo_path)
            progress.update(task, completed=1, total=1)

            # Parse Python files (parallel)
            task2 = progress.add_task(f"Parsing {len(py_files)} files...", total=len(py_files))
            analyses = self._parse_files_parallel(py_files, progress, task2)

            # Annotate module names
            for a in analyses:
                a.module_name = file_to_module(a.file_path, str(self.repo_path))

            # Parse dependency files
            task3 = progress.add_task("Parsing dependency files...", total=None)
            dep_set = self._parse_dep_files(dep_files)
            progress.update(task3, completed=1, total=1)

        return analyses, dep_set

    def _parse_files_parallel(
        self,
        files: list[Path],
        progress,
        task_id,
    ) -> list[FileAnalysis]:
        results: list[FileAnalysis] = []

        # Use multiprocessing for large repos, sequential for small ones
        if len(files) < 20:
            for f in files:
                results.append(analyze_file(f))
                progress.advance(task_id)
        else:
            with ProcessPoolExecutor(max_workers=self.workers) as pool:
                futures = {pool.submit(_analyze_file_worker, f): f for f in files}
                for future in as_completed(futures):
                    try:
                        results.append(future.result())
                    except Exception:
                        pass
                    progress.advance(task_id)

        return [r for r in results if r is not None]

    def _parse_dep_files(self, dep_files: dict[str, list[Path]]) -> DependencySet:
        dep_set = DependencySet()

        for req_file in dep_files["requirements"]:
            deps = parse_requirements(req_file)
            dep_set.direct.extend(deps)
            dep_set.source_files.append(str(req_file))

        for pyproject_file in dep_files["pyproject"]:
            deps = parse_pyproject(pyproject_file)
            dep_set.direct.extend(deps)
            dep_set.source_files.append(str(pyproject_file))

        for setup_cfg in dep_files["setup_cfg"]:
            deps = parse_setup_cfg(setup_cfg)
            dep_set.direct.extend(deps)

        # Deduplicate by normalized name (keep first occurrence)
        seen: set[str] = set()
        deduped: list[PackageDep] = []
        for dep in dep_set.direct:
            if dep.normalized_name not in seen:
                seen.add(dep.normalized_name)
                deduped.append(dep)
        dep_set.direct = deduped

        return dep_set

    # ── Cache helpers ─────────────────────────────────────────────────────────

    def _save_to_cache(self, analyses: list[FileAnalysis], dep_set: DependencySet):
        self.cache.set_analyses([dataclasses.asdict(a) for a in analyses])
        self.cache.set_dep_set({
            "direct": [dataclasses.asdict(d) for d in dep_set.direct],
            "transitive": [dataclasses.asdict(d) for d in dep_set.transitive],
            "source_files": dep_set.source_files,
        })
        self.cache.set_meta("repo_root", str(self.repo_path))
        self.cache.save()

    def _load_from_cache(self) -> tuple[list[FileAnalysis], DependencySet] | None:
        raw_analyses = self.cache.get_analyses()
        raw_dep_set = self.cache.get_dep_set()
        if not raw_analyses or not raw_dep_set:
            return None

        try:
            from dep_analyzer.scanner.models import ImportInfo, FunctionCallInfo, ClassUsageInfo

            def _rebuild_analysis(a: dict) -> FileAnalysis:
                return FileAnalysis(
                    file_path=a["file_path"],
                    module_name=a.get("module_name", ""),
                    imports=[ImportInfo(**i) for i in a.get("imports", [])],
                    function_calls=[FunctionCallInfo(**f) for f in a.get("function_calls", [])],
                    class_usages=[ClassUsageInfo(**c) for c in a.get("class_usages", [])],
                    has_dynamic_imports=a.get("has_dynamic_imports", False),
                    has_star_imports=a.get("has_star_imports", False),
                    parse_error=a.get("parse_error"),
                )

            analyses = [_rebuild_analysis(a) for a in raw_analyses]
            dep_set = DependencySet(
                direct=[PackageDep(**d) for d in raw_dep_set.get("direct", [])],
                transitive=[PackageDep(**d) for d in raw_dep_set.get("transitive", [])],
                source_files=raw_dep_set.get("source_files", []),
            )
            return analyses, dep_set
        except Exception:
            return None
