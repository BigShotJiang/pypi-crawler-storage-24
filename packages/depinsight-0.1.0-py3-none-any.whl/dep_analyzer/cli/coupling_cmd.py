"""dep-analyzer coupling - analyze module coupling metrics."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel

from dep_analyzer.analyzer.coupling import analyze_coupling
from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.cli.formatters import render_coupling
from dep_analyzer.graph.module_graph import build_module_graph

console = Console()


def coupling_command(
    repo_path: Path = typer.Option(
        Path("."), "--repo", "-r", exists=True, file_okay=False,
        help="Repository path.",
    ),
    threshold: float = typer.Option(
        0.8, "--threshold", "-t",
        help="Instability threshold for 'highly unstable' flag (0.0-1.0).",
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    output: str = typer.Option("table", "--format", "-f", help="table | json"),
    ai: bool = typer.Option(False, "--ai", help="Use LLM to summarize coupling issues."),
    ai_provider: str = typer.Option(
        None, "--provider",
        help="anthropic | openai | azure | bedrock",
    ),
    ai_model: str = typer.Option(
        None, "--model",
        help="Model name (auto-detects provider). e.g. gpt-4o, claude-sonnet-4-6",
    ),
    top: int = typer.Option(25, "--top", help="Show top N modules by instability."),
):
    """
    Analyze module-level coupling: instability, afferent/efferent coupling, cycles.

    Metrics:

      Ca (afferent)  - how many modules depend on this one (stability indicator)

      Ce (efferent)  - how many modules this one depends on

      Instability    - Ce / (Ca + Ce). 0=stable, 1=unstable

      Distance       - |Abstractness + Instability - 1| (closeness to main sequence)
    """
    console.print(f"\n[bold]Analyzing coupling in[/] [cyan]{repo_path}[/]...\n")

    engine = ScanEngine(repo_path.resolve(), use_cache=not no_cache)
    analyses, dep_set = engine.run()

    G = build_module_graph(analyses, str(repo_path.resolve()), internal_only=True)
    report = analyze_coupling(G, analyses=analyses, instability_threshold=threshold)

    original_metrics = report.metrics
    report.metrics = report.metrics[:top]
    render_coupling(report, output_format=output)
    report.metrics = original_metrics

    if ai:
        from dep_analyzer.ai.llm import LLMAnalyzer
        from dep_analyzer.cli.setup_cmd import run_setup_if_needed
        from dep_analyzer.utils.user_config import get_api_key, get_provider, get_model

        run_setup_if_needed()

        try:
            llm = LLMAnalyzer(
                provider=ai_provider or get_provider(),
                model=ai_model or get_model(),
                api_key=get_api_key(),
            )
        except ValueError as e:
            console.print(Panel(str(e), title="[red]Invalid provider[/]", border_style="red"))
            raise typer.Exit(1)

        if not llm.is_available():
            reason = llm.unavailable_reason() or "Unknown reason"
            console.print(Panel(
                f"[yellow]Provider:[/]  {llm.provider_name}\n"
                f"[yellow]Model:[/]     {llm.model_name}\n\n"
                f"{reason}",
                title="[red]AI not available[/]",
                border_style="red",
            ))
            raise typer.Exit(1)

        console.print(
            f"\n[bold]AI Analysis[/] [dim]via {llm.provider_name} / {llm.model_name}[/]..."
        )
        ai_summary = llm.analyze_coupling(report)
        if ai_summary:
            console.print(Panel(ai_summary, title="AI Coupling Analysis", border_style="magenta"))
