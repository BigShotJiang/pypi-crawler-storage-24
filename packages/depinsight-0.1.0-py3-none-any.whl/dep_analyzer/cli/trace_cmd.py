"""dep-analyzer trace - show where a package is used across the codebase."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from dep_analyzer.analyzer.impact import ImpactAnalyzer
from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.cli.formatters import render_trace

console = Console()


def trace_command(
    package: str = typer.Argument(..., help="Package name to trace, e.g. 'django'"),
    repo_path: Path = typer.Option(
        Path("."),
        "--repo", "-r",
        exists=True,
        file_okay=False,
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    output: str = typer.Option("table", "--format", "-f", help="table | json"),
):
    """
    Show every file that imports a specific package.

    Example:

      dep-analyzer trace django

      dep-analyzer trace celery --format json
    """
    console.print(f"\n[bold]Tracing usages of[/] [cyan]{package}[/]...\n")

    engine = ScanEngine(repo_path.resolve(), use_cache=not no_cache)
    analyses, dep_set = engine.run()

    analyzer = ImpactAnalyzer(analyses, dep_set)
    usages = analyzer._find_usages(package.lower())

    # Convert to AffectedFile for formatter
    from dep_analyzer.analyzer.impact import AffectedFile
    affected = [
        AffectedFile(
            file_path=analysis.file_path,
            line=imp.line,
            import_str=analyzer._format_import(imp),
            risk="UNKNOWN",
        )
        for analysis, imp in usages
    ]

    render_trace(package, affected, output_format=output)

    if not affected:
        console.print(f"[dim]'{package}' is not imported anywhere in this repository.[/]")
    else:
        console.print(f"\n[dim]Found {len(affected)} import(s) across {len({a.file_path for a in affected})} file(s)[/]")
