"""dep-analyzer impact - analyze upgrade impact for a package."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel

from dep_analyzer.analyzer.impact import ImpactAnalyzer
from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.cli.formatters import render_impact

console = Console()


def impact_command(
    package_spec: str = typer.Argument(
        ...,
        help="Package spec to analyze, e.g. 'django==4.0', 'flask>=2.3'",
    ),
    repo_path: Path = typer.Option(
        Path("."), "--repo", "-r", exists=True, file_okay=False,
        help="Repository path (defaults to cwd).",
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    output: str = typer.Option("table", "--format", "-f", help="table | json"),
    ai: bool = typer.Option(False, "--ai", help="Use LLM for enhanced analysis."),
    ai_provider: str = typer.Option(
        None, "--provider",
        help="anthropic | openai | azure | bedrock  (default: DEP_ANALYZER_PROVIDER or anthropic)",
    ),
    ai_model: str = typer.Option(
        None, "--model",
        help="Model name — auto-detects provider if omitted. "
             "e.g. claude-sonnet-4-6, gpt-4o, claude-3-5-sonnet (bedrock alias)",
    ),
):
    """
    Analyze what breaks when you upgrade a Python package.

    Examples:

      dep-analyzer impact django==4.0

      dep-analyzer impact sqlalchemy==2.0 --ai

      dep-analyzer impact flask==3.0 --ai --provider openai --model gpt-4o

      dep-analyzer impact celery==5.0 --ai --provider bedrock --model claude-3-5-sonnet

      dep-analyzer impact requests==3.0 --ai --model claude-sonnet-4-6
    """
    console.print(f"\n[bold]Analyzing impact of[/] [cyan]{package_spec}[/]...\n")

    engine = ScanEngine(repo_path.resolve(), use_cache=not no_cache)
    analyses, dep_set = engine.run()

    analyzer = ImpactAnalyzer(analyses, dep_set)
    result = analyzer.analyze(package_spec)
    render_impact(result, output_format=output)

    if ai:
        _run_ai(ai_provider, ai_model, result)


def _run_ai(ai_provider, ai_model, result):
    from dep_analyzer.ai.changelog import fetch_changelog
    from dep_analyzer.ai.llm import LLMAnalyzer
    from dep_analyzer.cli.setup_cmd import run_setup_if_needed
    from dep_analyzer.utils.user_config import get_api_key, get_provider, get_model

    run_setup_if_needed()

    try:
        llm = LLMAnalyzer(
            provider=ai_provider or get_provider(),
            model=ai_model or get_model(),
            api_key=get_api_key(),
        )
    except ValueError as e:
        console.print(Panel(str(e), title="[red]Invalid provider[/]", border_style="red"))
        raise typer.Exit(1)

    if not llm.is_available():
        reason = llm.unavailable_reason() or "Unknown reason"
        console.print(Panel(
            f"[yellow]Provider:[/]  {llm.provider_name}\n"
            f"[yellow]Model:[/]     {llm.model_name}\n\n"
            f"{reason}",
            title="[red]AI not available[/]",
            border_style="red",
        ))
        raise typer.Exit(1)

    console.print(
        f"\n[bold]AI Analysis[/] [dim]via {llm.provider_name} / {llm.model_name}[/] "
        f"— fetching changelog..."
    )
    changelog = fetch_changelog(result.package, result.target_version)
    ai_summary = llm.analyze_impact(result, changelog)
    if ai_summary:
        console.print(Panel(ai_summary, title="AI Summary", border_style="magenta"))

    # ── Action Required: clickable file:line list (exclude SAFE) ─────────────
    actionable = [af for af in result.affected_files if af.risk not in ("SAFE", "NONE")]
    if actionable:
        from pathlib import Path
        from rich.text import Text

        lines = Text()
        for af in actionable:
            abs_path = str(Path(af.file_path).resolve())
            uri = "file:///" + abs_path.replace("\\", "/").lstrip("/")
            display_line = af.call_line or af.line
            file_link = Text(f"{abs_path}:{display_line}", style=f"cyan link {uri}")
            risk_style = "red" if af.risk in ("REMOVED", "CRITICAL") else "yellow"
            lines.append_text(file_link)
            note = f"  {af.note}" if af.note else ""
            lines.append(f"  [{af.risk}]{note}\n", style=risk_style)
            if af.fix_suggestion:
                for fix_line in af.fix_suggestion.splitlines():
                    lines.append(f"    {fix_line}\n", style="dim")

        console.print(Panel(
            lines,
            title="[bold]Action Required - Files to Update (click to open)[/]",
            border_style="yellow",
        ))
    elif result.affected_files:
        console.print(Panel(
            "[green]All detected usages appear safe based on call-level analysis.[/]",
            title="[green]No Action Required[/]",
            border_style="green",
        ))
