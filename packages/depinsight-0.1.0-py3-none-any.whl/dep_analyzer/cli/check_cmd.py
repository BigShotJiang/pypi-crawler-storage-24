"""dep-analyzer check - scan all dependencies for breaking changes at once."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from dep_analyzer.analyzer.impact import ImpactAnalyzer
from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.cli.formatters import SEVERITY_STYLE

console = Console()

# Exit codes for CI/CD
# 0 = clean (NONE/LOW/SAFE)
# 1 = warning (MEDIUM)
# 2 = failure (HIGH/CRITICAL)
_EXIT_CLEAN   = 0
_EXIT_WARNING = 1
_EXIT_FAILURE = 2


def check_command(
    repo_path: Path = typer.Option(
        Path("."), "--repo", "-r", exists=True, file_okay=False,
        help="Repository path.",
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    output: str = typer.Option("table", "--format", "-f", help="table | json"),
    fail_on: str = typer.Option(
        "HIGH", "--fail-on",
        help="Exit with non-zero code if any package reaches this severity: "
             "CRITICAL | HIGH | MEDIUM | LOW",
    ),
    target: str = typer.Option(
        None, "--target", "-t",
        help="Only check upgrades to this version spec, e.g. '>=3.0'. "
             "Default: use pinned versions from requirement files.",
    ),
):
    """
    Scan ALL dependencies for breaking changes at once.

    Useful in CI/CD — exits non-zero if high-risk upgrades are detected.

    Examples:

      dep-analyzer check

      dep-analyzer check --fail-on MEDIUM

      dep-analyzer check --format json
    """
    engine = ScanEngine(repo_path.resolve(), use_cache=not no_cache)
    analyses, dep_set = engine.run()

    if not dep_set.direct:
        console.print("[yellow]No dependencies found.[/]")
        raise typer.Exit(0)

    analyzer = ImpactAnalyzer(analyses, dep_set)

    rows: list[dict] = []
    fail_severities = _severities_at_or_above(fail_on)

    console.print(f"\n[bold]Checking {len(dep_set.direct)} dependencies...[/]\n")

    for dep in dep_set.direct:
        spec = f"{dep.name}=={dep.version_spec.lstrip('>=<~!').split(',')[0]}" \
               if dep.version_spec else dep.name
        try:
            result = analyzer.analyze(target or spec)
        except Exception:
            continue

        # Only count APIs with confirmed call-level evidence
        confirmed = [af for af in result.affected_files if af.breaking_api and af.call_line]
        risky     = [af for af in confirmed if af.risk not in ("SAFE", "NONE")]
        safe_list = [af for af in confirmed if af.risk == "SAFE"]

        if risky:
            severity = result.severity
        elif confirmed:
            severity = "SAFE"
        else:
            severity = "NONE"

        rows.append({
            "package":  dep.name,
            "version":  dep.version_spec or "any",
            "severity": severity,
            "used":     len(confirmed),
            "safe":     len(safe_list),
            "risky":    len(risky),
            "notes":    "; ".join({af.note for af in risky if af.note}),
        })

    if output == "json":
        import json
        console.print_json(json.dumps(rows, indent=2))
        _exit_by_severity(rows, fail_severities)
        return

    # ── Table output ──────────────────────────────────────────────────────────
    table = Table(title="Dependency Check Results", show_header=True)
    table.add_column("Package", style="cyan")
    table.add_column("Version")
    table.add_column("Status")
    table.add_column("Used / Safe / Risky")
    table.add_column("Notes", style="dim")

    high_count = 0
    for row in rows:
        sev = row["severity"]
        style = SEVERITY_STYLE.get(sev, "white")
        status = Text(sev, style=style)
        if row["used"]:
            api_info = f"Used:{row['used']}  Safe:{row['safe']}  Risky:{row['risky']}"
        else:
            api_info = "-"
        table.add_row(row["package"], row["version"], status, api_info, row["notes"] or "")
        if sev in fail_severities:
            high_count += 1

    console.print(table)

    medium_count = sum(1 for r in rows if r["severity"] == "MEDIUM")
    high_count   = sum(1 for r in rows if r["severity"] in ("HIGH", "CRITICAL"))

    if high_count:
        console.print(Panel(
            f"[red]{high_count} package(s) have HIGH/CRITICAL issues.[/]\n"
            f"Run [cyan]dep-analyzer impact <package>==<version>[/] for details.\n"
            f"[dim]Exit code: 2[/]",
            title="[red]Check Failed[/]",
            border_style="red",
        ))
        raise typer.Exit(_EXIT_FAILURE)
    elif medium_count and "MEDIUM" in _severities_at_or_above(fail_on):
        console.print(Panel(
            f"[yellow]{medium_count} package(s) have MEDIUM severity issues.[/]\n"
            f"Run [cyan]dep-analyzer impact <package>==<version>[/] for details.\n"
            f"[dim]Exit code: 1[/]",
            title="[yellow]Check Warning[/]",
            border_style="yellow",
        ))
        raise typer.Exit(_EXIT_WARNING)
    else:
        safe_count = sum(1 for r in rows if r["severity"] == "SAFE")
        console.print(Panel(
            f"[green]All dependencies passed.[/]\n"
            f"[dim]{safe_count} package(s) verified safe | Exit code: 0[/]",
            title="[green]Check Passed[/]",
            border_style="green",
        ))
        raise typer.Exit(_EXIT_CLEAN)


def _severities_at_or_above(level: str) -> set[str]:
    order = ["NONE", "SAFE", "LOW", "MEDIUM", "HIGH", "CRITICAL"]
    try:
        idx = order.index(level.upper())
    except ValueError:
        idx = order.index("HIGH")
    return set(order[idx:])


def _exit_by_severity(rows: list[dict], fail_severities: set[str]):
    if any(r["severity"] in fail_severities for r in rows):
        raise typer.Exit(_EXIT_FAILURE)
    raise typer.Exit(_EXIT_CLEAN)
