"""Main Typer application - registers all sub-commands."""

import os
from pathlib import Path

import typer
from rich.console import Console


def _load_dotenv():
    """Load .env from cwd or project root (no external dependency required)."""
    for candidate in [Path.cwd() / ".env", Path(__file__).parent.parent.parent.parent / ".env"]:
        if candidate.exists():
            for line in candidate.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value
            break


_load_dotenv()

_ENV_EXAMPLE_CONTENT = """\
# ============================================================
# Dependency Hell Analyzer - Environment Configuration
# Copy this file to .env and fill in your values.
# ============================================================

# --- Provider (anthropic | openai | azure | bedrock) ---
DEP_ANALYZER_PROVIDER=anthropic

# --- API Key (not needed for bedrock) ---
DEP_ANALYZER_API_KEY=your-api-key-here

# --- Model (optional, uses provider default if omitted) ---
# DEP_ANALYZER_MODEL=claude-sonnet-4-6      # Anthropic
# DEP_ANALYZER_MODEL=gpt-4o-mini            # OpenAI
# DEP_ANALYZER_MODEL=gpt-5-mini             # Azure deployment name

# --- Azure OpenAI (only if PROVIDER=azure) ---
# DEP_ANALYZER_AZURE_ENDPOINT=https://<resource>.cognitiveservices.azure.com/
# DEP_ANALYZER_AZURE_DEPLOYMENT=gpt-4o
# DEP_ANALYZER_AZURE_API_VERSION=2024-02-01

# --- AWS Bedrock (only if PROVIDER=bedrock, no API key needed) ---
# DEP_ANALYZER_BEDROCK_REGION=us-east-1

# --- Scan settings (optional) ---
# DEP_ANALYZER_WORKERS=0       # 0 = auto (cpu count)
# DEP_ANALYZER_NO_CACHE=false
# DEP_ANALYZER_HTTP_TIMEOUT=10
"""


def _ensure_env_example():
    """Create .env.example in cwd on first run if it doesn't exist."""
    target = Path.cwd() / ".env.example"
    if not target.exists():
        try:
            target.write_text(_ENV_EXAMPLE_CONTENT, encoding="utf-8")
            Console().print(
                f"[dim]Created [cyan].env.example[/] in {Path.cwd()} "
                f"- copy it to [cyan].env[/] and add your keys.[/]"
            )
        except OSError:
            pass  # read-only fs or no permission - silently skip


_ensure_env_example()

from dep_analyzer import __version__

app = typer.Typer(
    name="dep-analyzer",
    help="[bold]Dependency Hell Analyzer[/] - AI-powered Python dependency analysis",
    rich_markup_mode="rich",
    no_args_is_help=True,
    pretty_exceptions_show_locals=False,
)

console = Console()


def version_callback(value: bool):
    if value:
        console.print(f"dep-analyzer [bold]{__version__}[/]")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None, "--version", "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
):
    """Dependency Hell Analyzer - understand, visualize and fix your Python dependencies."""


# Register sub-commands
from dep_analyzer.cli.scan_cmd import scan_command  # noqa: E402
from dep_analyzer.cli.graph_cmd import graph_command  # noqa: E402
from dep_analyzer.cli.impact_cmd import impact_command  # noqa: E402
from dep_analyzer.cli.coupling_cmd import coupling_command  # noqa: E402
from dep_analyzer.cli.trace_cmd import trace_command  # noqa: E402
from dep_analyzer.cli.report_cmd import report_command  # noqa: E402
from dep_analyzer.cli.setup_cmd import setup_command  # noqa: E402
from dep_analyzer.cli.check_cmd import check_command  # noqa: E402
from dep_analyzer.cli.fix_cmd import fix_command  # noqa: E402

app.command("scan")(scan_command)
app.command("graph")(graph_command)
app.command("impact")(impact_command)
app.command("coupling")(coupling_command)
app.command("trace")(trace_command)
app.command("report")(report_command)
app.command("setup")(setup_command)
app.command("check")(check_command)
app.command("fix")(fix_command)
