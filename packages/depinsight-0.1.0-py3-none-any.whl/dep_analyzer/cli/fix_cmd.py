"""dep-analyzer fix - auto-fix known breaking API usages."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.syntax import Syntax
from rich.table import Table

console = Console()


def fix_command(
    repo_path: Path = typer.Option(
        Path("."), "--repo", "-r", exists=True, file_okay=False,
        help="Repository path.",
    ),
    package: str = typer.Option(
        None, "--package", "-p",
        help="Only fix issues from this package (e.g. django). Default: all.",
    ),
    target_version: str = typer.Option(
        None, "--version", "-v",
        help="Target upgrade version (e.g. 4.0). Default: latest known rules.",
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Show diff without writing any files.",
    ),
    no_backup: bool = typer.Option(
        False, "--no-backup",
        help="Skip creating .bak files before overwriting.",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Apply all fixes without prompting.",
    ),
):
    """
    Auto-fix known breaking API changes in your codebase.

    Shows a diff preview before applying. Creates .bak backups by default.

    Examples:

      dep-analyzer fix

      dep-analyzer fix --package django --version 4.0

      dep-analyzer fix --dry-run

      dep-analyzer fix --yes --no-backup
    """
    from dep_analyzer.analyzer.impact import ImpactAnalyzer, BreakingAPI
    from dep_analyzer.cli.engine import ScanEngine
    from dep_analyzer.fixer import build_rules, fix_file, write_fix
    from dep_analyzer.scanner.file_discovery import discover_python_files

    engine = ScanEngine(repo_path.resolve(), use_cache=not no_cache)
    analyses, dep_set = engine.run()

    analyzer = ImpactAnalyzer(analyses, dep_set)

    # ── Gather all fixable rules across packages ───────────────────────────────
    packages = [package] if package else [d.name for d in dep_set.direct]
    all_rules = {}

    for pkg in packages:
        spec = f"{pkg}=={target_version}" if target_version else pkg
        try:
            result = analyzer.analyze(spec)
        except Exception:
            continue
        rules = build_rules(result.breaking_apis)
        all_rules.update(rules)

    if not all_rules:
        console.print("[green]No fixable breaking changes found.[/]")
        raise typer.Exit(0)

    console.print(f"\n[bold]{len(all_rules)} rule(s) available[/] [dim](will show applicable count after scanning)[/]")
    rule_table = Table(show_header=True, box=None)
    rule_table.add_column("Old API", style="red")
    rule_table.add_column("->")
    rule_table.add_column("New API", style="green")
    rule_table.add_column("Detail", style="dim")
    for rule in all_rules.values():
        new_full = f"{rule.new_module}.{rule.new_name}" if rule.new_module else rule.new_name
        rule_table.add_row(rule.old_api, "->", new_full, rule.detail or "")
    console.print(rule_table)

    # ── Scan python files ─────────────────────────────────────────────────────
    py_files = discover_python_files(repo_path.resolve())
    results = []

    for f in py_files:
        r = fix_file(f, all_rules, backup=False)
        if r.changed:
            results.append(r)

    if not results:
        console.print("\n[green]No files need fixing.[/]")
        raise typer.Exit(0)

    # ── Show diffs ────────────────────────────────────────────────────────────
    total_applicable = sum(len(r.fixes) for r in results)
    console.print(
        f"\n[bold]{total_applicable} applicable fix(es)[/] in [bold]{len(results)} file(s)[/] "
        f"[dim]({len(all_rules)} rules checked)[/]\n"
    )

    for r in results:
        console.print(Panel(
            Syntax(r.diff(), "diff", theme="monokai", line_numbers=False),
            title=f"[cyan]{r.file_path}[/]",
            border_style="cyan",
        ))
        for fix in r.fixes:
            console.print(
                f"  Line {fix.line}: [red]{fix.old_code.strip()}[/] -> [green]{fix.new_code.strip()}[/]"
            )
        console.print()

    if dry_run:
        console.print("[dim]Dry run — no files written.[/]")
        raise typer.Exit(0)

    # ── Confirm ───────────────────────────────────────────────────────────────
    if not yes:
        confirmed = Confirm.ask(
            f"Apply {sum(len(r.fixes) for r in results)} fix(es) to {len(results)} file(s)?",
            default=False,
        )
        if not confirmed:
            console.print("[yellow]Aborted.[/]")
            raise typer.Exit(0)

    # ── Apply ─────────────────────────────────────────────────────────────────
    written = 0
    backed_up = 0

    for r in results:
        if not no_backup:
            import shutil
            bak = Path(r.file_path + ".bak")
            shutil.copy2(r.file_path, bak)
            r.backup_path = str(bak)
            backed_up += 1
        write_fix(r)
        written += 1

    # ── Summary breakdown ─────────────────────────────────────────────────────
    from collections import Counter
    pkg_counts: Counter = Counter()
    total_fixes = 0
    for r in results:
        for fix in r.fixes:
            pkg = fix.rule.old_api.split(".")[0]
            pkg_counts[pkg] += 1
            total_fixes += 1

    breakdown = "\n".join(
        f"  [cyan]{pkg}[/]: {count} fix(es)"
        for pkg, count in pkg_counts.most_common()
    )
    summary = (
        f"[green]Fixed {written} file(s), {total_fixes} change(s)[/]\n\n"
        f"{breakdown}"
    )
    if backed_up:
        summary += f"\n\n[dim]Backups: {backed_up} .bak file(s) created alongside originals[/]"

    console.print(Panel(summary, title="[green]Fix Complete[/]", border_style="green"))
