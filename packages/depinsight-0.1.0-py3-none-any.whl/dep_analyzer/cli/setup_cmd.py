"""
dep-analyzer setup  —  interactive first-run configuration wizard.

Runs automatically the first time a user needs an API key.
Can also be triggered manually: dep-analyzer setup
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from dep_analyzer.ai.providers.factory import PROVIDER_REGISTRY
from dep_analyzer.utils.user_config import (
    get_config_path,
    is_configured,
    load_user_config,
    save_user_config,
)

console = Console()

# Provider-specific key hints shown during setup
_KEY_HINTS: dict[str, str] = {
    "anthropic": "Get your key at https://console.anthropic.com  (starts with sk-ant-...)",
    "openai":    "Get your key at https://platform.openai.com/api-keys  (starts with sk-...)",
    "azure":     "Find your key in Azure Portal -> Azure OpenAI resource -> Keys and Endpoint",
    "bedrock":   "No API key needed. Uses your AWS credentials (AWS_ACCESS_KEY_ID / IAM role).",
}

_PROVIDER_CHOICES = list(PROVIDER_REGISTRY.keys())


def setup_command(
    reset: bool = typer.Option(False, "--reset", help="Clear existing config and start over."),
    show: bool  = typer.Option(False, "--show",  help="Show current saved configuration."),
):
    """
    Interactive setup wizard — configure your AI provider and API key.

    Saves settings to ~/.dep-analyzer/config.json.
    Environment variables (DEP_ANALYZER_*) always override saved settings.
    """
    if show:
        _show_current_config()
        return

    if reset:
        save_user_config({})
        console.print("[yellow]Config cleared.[/]")

    console.print()
    console.print(Panel(
        "[bold]Welcome to Dependency Hell Analyzer[/]\n\n"
        "This wizard will save your AI provider settings so you\n"
        "don't have to enter them every time.\n\n"
        "[dim]Settings are stored in: ~/.dep-analyzer/config.json[/]",
        title="Setup Wizard",
        border_style="cyan",
    ))

    # ── Step 1: choose provider ───────────────────────────────────────────────
    console.print("\n[bold]Step 1 of 3 — Choose your AI provider[/]\n")

    table = Table(show_header=False, box=None, padding=(0, 2))
    for i, (name, desc) in enumerate(PROVIDER_REGISTRY.items(), 1):
        install = f"pip install dep-analyzer[{name}]" if name != "azure" else "pip install dep-analyzer[openai]"
        table.add_row(f"[cyan]{i}[/]", f"[bold]{name}[/]", desc.split("|")[0].strip(), f"[dim]{install}[/]")
    console.print(table)
    console.print()

    existing = load_user_config()
    default_provider = existing.get("provider", "anthropic")

    choice_str = Prompt.ask(
        "Enter provider name or number",
        default=default_provider,
    )

    # Accept number or name
    if choice_str.strip().isdigit():
        idx = int(choice_str.strip()) - 1
        if 0 <= idx < len(_PROVIDER_CHOICES):
            provider = _PROVIDER_CHOICES[idx]
        else:
            console.print("[red]Invalid choice. Using anthropic.[/]")
            provider = "anthropic"
    else:
        provider = choice_str.strip().lower()
        if provider not in _PROVIDER_CHOICES:
            console.print(f"[red]Unknown provider '{provider}'. Using anthropic.[/]")
            provider = "anthropic"

    # ── Step 2: API key ───────────────────────────────────────────────────────
    console.print(f"\n[bold]Step 2 of 3 — API Key for [cyan]{provider}[/][/]\n")
    console.print(f"[dim]{_KEY_HINTS[provider]}[/]\n")

    config: dict = {"provider": provider}

    if provider == "bedrock":
        console.print("[dim]Skipping API key - Bedrock uses AWS credentials.[/]")
        aws_region = Prompt.ask(
            "AWS region for Bedrock",
            default=existing.get("bedrock_region", "us-east-1"),
        )
        config["bedrock_region"] = aws_region

    else:
        masked_existing = ""
        if existing.get("api_key"):
            k = existing["api_key"]
            masked_existing = k[:8] + "..." + k[-4:] if len(k) > 12 else "****"

        prompt_text = "API key"
        if masked_existing:
            prompt_text += f" [dim](current: {masked_existing})[/]"

        api_key = Prompt.ask(prompt_text, password=True, default=existing.get("api_key", ""))

        if not api_key:
            console.print("[yellow]No key entered. You can set DEP_ANALYZER_API_KEY env var instead.[/]")
        else:
            config["api_key"] = api_key

        # Azure extras
        if provider == "azure":
            console.print()
            config["azure_endpoint"]   = Prompt.ask(
                "Azure endpoint",
                default=existing.get("azure_endpoint", "https://<resource>.openai.azure.com/"),
            )
            config["azure_deployment"] = Prompt.ask(
                "Deployment name",
                default=existing.get("azure_deployment", ""),
            )
            config["azure_api_version"] = Prompt.ask(
                "API version",
                default=existing.get("azure_api_version", "2024-02-01"),
            )

    # ── Step 3: model (optional) ──────────────────────────────────────────────
    _DEFAULTS = {
        "anthropic": "claude-sonnet-4-6",
        "openai":    "gpt-4o-mini",
        "azure":     "(your deployment name)",
        "bedrock":   "claude-3-5-sonnet",
    }

    console.print(f"\n[bold]Step 3 of 3 — Model[/] [dim](press Enter for default)[/]\n")
    model = Prompt.ask(
        f"Model name",
        default=existing.get("model", _DEFAULTS[provider]),
    )
    if model and model != _DEFAULTS[provider]:
        config["model"] = model

    # ── Save ──────────────────────────────────────────────────────────────────
    save_user_config(config)

    console.print()
    console.print(Panel(
        f"[green]Config saved to:[/] {get_config_path()}\n\n"
        f"  Provider : [cyan]{provider}[/]\n"
        f"  Model    : [cyan]{config.get('model', _DEFAULTS[provider])}[/]\n"
        f"  API key  : [dim]{'(set)' if config.get('api_key') else '(not set - use env var)'}[/]",
        title="[green]Setup Complete[/]",
        border_style="green",
    ))
    console.print(
        "\n[dim]Tip: env vars always override saved config. "
        "Run [bold]dep-analyzer setup --show[/] to view current settings.[/]\n"
    )


def _show_current_config():
    """Print current effective configuration."""
    from dep_analyzer.utils.user_config import get_api_key, get_provider, get_model
    import os

    cfg = load_user_config()

    table = Table(title="Current Configuration", show_header=True)
    table.add_column("Setting", style="cyan")
    table.add_column("Value")
    table.add_column("Source", style="dim")

    def _source(env_var: str, cfg_key: str) -> str:
        if os.environ.get(env_var):
            return f"env: {env_var}"
        if cfg.get(cfg_key):
            return f"~/.dep-analyzer/config.json"
        return "default"

    provider = get_provider()
    model    = get_model() or "(provider default)"
    api_key  = get_api_key()
    masked   = (api_key[:8] + "..." + api_key[-4:]) if len(api_key) > 12 else ("(set)" if api_key else "(not set)")

    table.add_row("Provider", provider,  _source("DEP_ANALYZER_PROVIDER", "provider"))
    table.add_row("Model",    model,     _source("DEP_ANALYZER_MODEL", "model"))
    table.add_row("API Key",  masked,    _source("DEP_ANALYZER_API_KEY", "api_key"))
    table.add_row("Config file", str(get_config_path()), "")

    console.print()
    console.print(table)


def run_setup_if_needed():
    """
    Called automatically before any --ai command.
    If no config exists at all, prompt the user to run setup.
    """
    if is_configured():
        return

    console.print()
    from pathlib import Path
    env_example = Path.cwd() / ".env.example"
    env_hint = (
        "\nOr fill in [cyan].env.example[/] -> rename it to [cyan].env[/]"
        if env_example.exists() else
        "\nOr set [cyan]DEP_ANALYZER_API_KEY[/] in your environment."
    )
    console.print(Panel(
        "[bold]No AI configuration found.[/]\n\n"
        "To use [cyan]--ai[/] features, run the setup wizard:\n\n"
        "  [bold cyan]dep-analyzer setup[/]\n" + env_hint,
        title="[yellow]Setup Required[/]",
        border_style="yellow",
    ))
    console.print()

    run_now = Confirm.ask("Run setup wizard now?", default=True)
    if run_now:
        setup_command(reset=False, show=False)
    else:
        raise typer.Exit(1)
