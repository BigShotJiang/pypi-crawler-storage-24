"""dep-analyzer graph - display or export the dependency graph."""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.tree import Tree

from dep_analyzer.cli.engine import ScanEngine
from dep_analyzer.graph.module_graph import build_module_graph
from dep_analyzer.graph.package_graph import build_package_graph

console = Console()


def graph_command(
    repo_path: Path = typer.Option(
        Path("."),
        "--repo", "-r",
        exists=True,
        file_okay=False,
    ),
    graph_type: str = typer.Option(
        "module",
        "--type", "-t",
        help="Graph type: module | package",
    ),
    output: str = typer.Option(
        "table",
        "--format", "-f",
        help="Output format: table | json | dot",
    ),
    internal_only: bool = typer.Option(
        True, "--internal/--all",
        help="Show only internal modules (default) or all including stdlib/third-party.",
    ),
    no_cache: bool = typer.Option(False, "--no-cache"),
    out_file: Path = typer.Option(
        None, "--out", "-o",
        help="Write output to file instead of stdout.",
    ),
):
    """
    Display or export the dependency graph.

    Examples:

      dep-analyzer graph --type module

      dep-analyzer graph --type package --format json

      dep-analyzer graph --format dot --out graph.dot
    """
    console.print(f"\n[bold]Building {graph_type} graph for[/] [cyan]{repo_path}[/]...\n")

    engine = ScanEngine(repo_path.resolve(), use_cache=not no_cache)
    analyses, dep_set = engine.run()

    repo_str = str(repo_path.resolve())

    if graph_type == "module":
        G = build_module_graph(analyses, repo_str, internal_only=internal_only)
    elif graph_type == "package":
        G = build_package_graph(dep_set)
    else:
        console.print(f"[red]Unknown graph type: {graph_type}[/]")
        raise typer.Exit(1)

    if output == "dot":
        dot_content = _to_dot(G, graph_type)
        if out_file:
            out_file.write_text(dot_content)
            console.print(f"[green]Written to {out_file}[/]")
        else:
            console.print(dot_content)

    elif output == "json":
        import networkx as nx
        data = nx.node_link_data(G)
        content = json.dumps(data, indent=2, default=str)
        if out_file:
            out_file.write_text(content)
            console.print(f"[green]Written to {out_file}[/]")
        else:
            console.print_json(content)

    else:  # table / rich tree
        _render_graph_tree(G, graph_type, internal_only)


def _render_graph_tree(G, graph_type: str, internal_only: bool):
    import networkx as nx

    console.print(
        f"Nodes: [bold]{G.number_of_nodes()}[/]   "
        f"Edges: [bold]{G.number_of_edges()}[/]\n"
    )

    # Show top nodes by out-degree
    sorted_nodes = sorted(G.nodes(), key=lambda n: G.out_degree(n), reverse=True)
    tree = Tree(f"[bold]{graph_type.capitalize()} Dependency Graph[/]")

    for node in sorted_nodes[:20]:
        out_deg = G.out_degree(node)
        in_deg = G.in_degree(node)
        branch = tree.add(
            f"[cyan]{node}[/] [dim](in={in_deg}, out={out_deg})[/]"
        )
        for _, neighbor in list(G.out_edges(node))[:5]:
            branch.add(f"[dim]-> {neighbor}[/]")
        if out_deg > 5:
            branch.add(f"[dim]... and {out_deg - 5} more[/]")

    if G.number_of_nodes() > 20:
        tree.add(f"[dim]... and {G.number_of_nodes() - 20} more nodes[/]")

    console.print(tree)

    # Highlight any cycles
    try:
        import networkx as nx
        cycles = list(nx.simple_cycles(G))
        short_cycles = [c for c in cycles if len(c) <= 4]
        if short_cycles:
            console.print(f"\n[red]!!  {len(short_cycles)} circular dependency cycle(s) detected[/]")
    except Exception:
        pass


def _to_dot(G, label: str) -> str:
    lines = [f'digraph "{label}" {{', '  rankdir=LR;', '  node [shape=box];']
    for node in G.nodes():
        attrs = G.nodes[node]
        color = "lightblue" if attrs.get("internal") else "lightyellow"
        lines.append(f'  "{node}" [style=filled, fillcolor="{color}"];')
    for u, v in G.edges():
        lines.append(f'  "{u}" -> "{v}";')
    lines.append("}")
    return "\n".join(lines)
