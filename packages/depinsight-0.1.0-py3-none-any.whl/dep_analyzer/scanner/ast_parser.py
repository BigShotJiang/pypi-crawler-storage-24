"""AST-based Python file analyzer - extracts imports, function calls, and class usage."""

import ast
from pathlib import Path

from .models import ClassUsageInfo, FileAnalysis, FunctionCallInfo, ImportInfo


class PythonFileAnalyzer(ast.NodeVisitor):
    """Walk a Python AST and extract dependency-relevant information."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.imports: list[ImportInfo] = []
        self.function_calls: list[FunctionCallInfo] = []
        self.class_usages: list[ClassUsageInfo] = []
        self.has_dynamic_imports: bool = False
        self.has_star_imports: bool = False
        self._scope_stack: list[str] = []

    # ── Scope tracking ────────────────────────────────────────────────────────

    @property
    def _current_scope(self) -> str:
        return ".".join(self._scope_stack)

    def _push_scope(self, name: str):
        self._scope_stack.append(name)

    def _pop_scope(self):
        if self._scope_stack:
            self._scope_stack.pop()

    # ── Visitors ──────────────────────────────────────────────────────────────

    def visit_Import(self, node: ast.Import):
        for alias in node.names:
            self.imports.append(ImportInfo(
                module=alias.name,
                names=[alias.asname or alias.name.split(".")[-1]],
                alias=alias.asname,
                line=node.lineno,
                file=self.file_path,
                is_from_import=False,
            ))
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        module = node.module or ""
        names = [a.name for a in node.names] if node.names else []

        if "*" in names:
            self.has_star_imports = True

        self.imports.append(ImportInfo(
            module=module,
            names=names,
            alias=None,
            line=node.lineno,
            file=self.file_path,
            is_from_import=True,
        ))
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        name = self._resolve_expr(node.func)
        if name:
            # Detect dynamic imports
            if name in ("importlib.import_module", "__import__", "importlib.util.spec_from_file_location"):
                self.has_dynamic_imports = True

            kwarg_names = [kw.arg for kw in node.keywords if kw.arg is not None]
            self.function_calls.append(FunctionCallInfo(
                name=name,
                module_context=self._current_scope,
                line=node.lineno,
                file=self.file_path,
                kwargs=kwarg_names,
            ))
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef):
        bases = [self._resolve_expr(b) for b in node.bases]
        self.class_usages.append(ClassUsageInfo(
            class_name=node.name,
            base_classes=[b for b in bases if b],
            module_context=self._current_scope,
            line=node.lineno,
            file=self.file_path,
        ))
        self._push_scope(node.name)
        self.generic_visit(node)
        self._pop_scope()

    def visit_FunctionDef(self, node: ast.FunctionDef):
        self._push_scope(node.name)
        self.generic_visit(node)
        self._pop_scope()

    visit_AsyncFunctionDef = visit_FunctionDef

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _resolve_expr(self, node: ast.expr) -> str | None:
        """Resolve a.b.c() style call targets to a dotted string."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            parent = self._resolve_expr(node.value)
            return f"{parent}.{node.attr}" if parent else node.attr
        if isinstance(node, ast.Subscript):
            return self._resolve_expr(node.value)
        return None


def analyze_file(file_path: Path) -> FileAnalysis:
    """Parse a Python source file and return extracted dependency information."""
    try:
        source = file_path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError as e:
        return FileAnalysis(file_path=str(file_path), parse_error=str(e))
    except OSError as e:
        return FileAnalysis(file_path=str(file_path), parse_error=str(e))

    visitor = PythonFileAnalyzer(str(file_path))
    visitor.visit(tree)

    return FileAnalysis(
        file_path=str(file_path),
        imports=visitor.imports,
        function_calls=visitor.function_calls,
        class_usages=visitor.class_usages,
        has_dynamic_imports=visitor.has_dynamic_imports,
        has_star_imports=visitor.has_star_imports,
    )
