"""Data models for scanner output."""

from dataclasses import dataclass, field


@dataclass
class ImportInfo:
    module: str
    names: list[str]
    alias: str | None
    line: int
    file: str
    is_from_import: bool

    def top_level_package(self) -> str:
        """Return the top-level package name (e.g. 'django' from 'django.db.models')."""
        return self.module.split(".")[0] if self.module else ""


@dataclass
class FunctionCallInfo:
    name: str
    module_context: str
    line: int
    file: str
    kwargs: list[str] = field(default_factory=list)  # keyword argument names present in the call


@dataclass
class ClassUsageInfo:
    class_name: str
    base_classes: list[str]
    module_context: str
    line: int
    file: str


@dataclass
class FileAnalysis:
    file_path: str
    module_name: str = ""
    imports: list[ImportInfo] = field(default_factory=list)
    function_calls: list[FunctionCallInfo] = field(default_factory=list)
    class_usages: list[ClassUsageInfo] = field(default_factory=list)
    has_dynamic_imports: bool = False
    has_star_imports: bool = False
    parse_error: str | None = None
