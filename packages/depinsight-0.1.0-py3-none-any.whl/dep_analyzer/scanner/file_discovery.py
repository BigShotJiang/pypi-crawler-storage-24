"""Discover Python files in a repository, skipping irrelevant directories."""

from pathlib import Path

SKIP_DIRS: frozenset[str] = frozenset({
    ".git", ".hg", ".svn",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "node_modules",
    ".tox", ".nox",
    "venv", ".venv", "env", ".env", "virtualenv",
    "build", "dist", ".build",
    ".dep-analyzer",
})


def discover_python_files(repo_path: Path) -> list[Path]:
    """Walk repo_path and return all .py files, skipping virtual envs and build dirs."""
    files: list[Path] = []

    for path in repo_path.rglob("*.py"):
        rel = path.relative_to(repo_path)
        # Skip if any path component matches skip list or is an egg-info dir
        if any(
            part in SKIP_DIRS or part.endswith(".egg-info") or part.endswith(".dist-info")
            for part in rel.parts
        ):
            continue
        files.append(path)

    return sorted(files)


def discover_dep_files(repo_path: Path) -> dict[str, list[Path]]:
    """Find all dependency specification files in the repo."""
    result: dict[str, list[Path]] = {
        "requirements": [],
        "pyproject": [],
        "setup_cfg": [],
        "setup_py": [],
        "pipfile": [],
    }

    for path in repo_path.rglob("requirements*.txt"):
        rel = path.relative_to(repo_path)
        if not any(part in SKIP_DIRS for part in rel.parts):
            result["requirements"].append(path)

    for name, key in [
        ("pyproject.toml", "pyproject"),
        ("setup.cfg", "setup_cfg"),
        ("setup.py", "setup_py"),
        ("Pipfile", "pipfile"),
    ]:
        found = repo_path.rglob(name)
        for path in found:
            rel = path.relative_to(repo_path)
            if not any(part in SKIP_DIRS for part in rel.parts):
                result[key].append(path)

    return result
