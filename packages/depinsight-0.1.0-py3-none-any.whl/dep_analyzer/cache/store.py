"""File-based cache for scan results, stored in .dep-analyzer/cache.json."""

import hashlib
import json
import time
from pathlib import Path
from typing import Any

CACHE_DIR = ".dep-analyzer"
CACHE_FILE = "cache.json"


class CacheStore:
    """Manages persisted scan cache for a repository."""

    def __init__(self, repo_path: Path):
        self.repo_path = repo_path
        self.cache_dir = repo_path / CACHE_DIR
        self.cache_file = self.cache_dir / CACHE_FILE
        self._data: dict[str, Any] = {}

    def load(self) -> bool:
        """Load cache from disk. Returns True if cache exists and was loaded."""
        if not self.cache_file.exists():
            return False
        try:
            self._data = json.loads(self.cache_file.read_text(encoding="utf-8"))
            return True
        except (json.JSONDecodeError, OSError):
            self._data = {}
            return False

    def save(self):
        """Persist cache to disk."""
        self.cache_dir.mkdir(exist_ok=True)
        self._data["_saved_at"] = time.time()
        self.cache_file.write_text(json.dumps(self._data, default=str, indent=2), encoding="utf-8")

    # ── File hash tracking ────────────────────────────────────────────────────

    def get_file_hash(self, path: Path) -> str | None:
        return self._data.get("file_hashes", {}).get(str(path))

    def set_file_hash(self, path: Path, hash_val: str):
        if "file_hashes" not in self._data:
            self._data["file_hashes"] = {}
        self._data["file_hashes"][str(path)] = hash_val

    @staticmethod
    def compute_hash(path: Path) -> str:
        return hashlib.md5(path.read_bytes()).hexdigest()

    # ── Scan results ──────────────────────────────────────────────────────────

    def get_analyses(self) -> list[dict] | None:
        return self._data.get("analyses")

    def set_analyses(self, analyses: list[dict]):
        self._data["analyses"] = analyses

    def get_dep_set(self) -> dict | None:
        return self._data.get("dep_set")

    def set_dep_set(self, dep_set: dict):
        self._data["dep_set"] = dep_set

    # ── Metadata ──────────────────────────────────────────────────────────────

    def get_meta(self, key: str) -> Any:
        return self._data.get("meta", {}).get(key)

    def set_meta(self, key: str, value: Any):
        if "meta" not in self._data:
            self._data["meta"] = {}
        self._data["meta"][key] = value

    def is_stale(self, max_age_seconds: int = 3600) -> bool:
        saved_at = self._data.get("_saved_at", 0)
        return (time.time() - saved_at) > max_age_seconds

    def clear(self):
        self._data = {}
        if self.cache_file.exists():
            self.cache_file.unlink()
