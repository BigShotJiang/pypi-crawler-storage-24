"""Dependency Hell Analyzer - AI-powered Python dependency analysis CLI."""

__version__ = "0.1.0"
