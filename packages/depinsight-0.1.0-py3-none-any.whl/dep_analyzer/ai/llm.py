"""LLM integration — supports Anthropic, OpenAI, Azure OpenAI, AWS Bedrock."""

from __future__ import annotations

from dep_analyzer.analyzer.coupling import CouplingReport
from dep_analyzer.analyzer.impact import ImpactResult
from dep_analyzer.ai.providers import BaseProvider, LLMResponse, create_provider, list_providers
from dep_analyzer.ai.prompts import IMPACT_ANALYSIS_PROMPT, COUPLING_SUMMARY_PROMPT


class LLMAnalyzer:
    """
    Single entry point for all LLM providers.

    Provider is selected via (first one wins):
      1. provider= argument  (e.g. "anthropic", "openai", "azure", "bedrock")
      2. DEP_ANALYZER_PROVIDER env var
      3. Auto-detected from model name  (e.g. "claude-*" -> anthropic)
      4. Default: anthropic

    Model is selected via (first one wins):
      1. model= argument
      2. DEP_ANALYZER_MODEL env var
      3. Provider default (claude-sonnet-4-6 / gpt-4o-mini / etc.)
    """

    def __init__(
        self,
        provider: str | None = None,
        model: str | None = None,
        api_key: str | None = None,
    ):
        self._provider: BaseProvider = create_provider(
            provider=provider,
            model=model,
            api_key=api_key,
        )

    # ── Status ────────────────────────────────────────────────────────────────

    def is_available(self) -> bool:
        return self._provider.is_available()

    def unavailable_reason(self) -> str | None:
        return self._provider.unavailable_reason()

    @property
    def provider_name(self) -> str:
        return self._provider.name

    @property
    def model_name(self) -> str:
        return self._provider.model

    @property
    def install_command(self) -> str:
        return f"pip install dep-analyzer[{self._provider.install_extra}]"

    @staticmethod
    def available_providers() -> list[str]:
        return list_providers()

    # ── Analysis methods ──────────────────────────────────────────────────────

    def analyze_impact(self, result: ImpactResult, changelog: str) -> str:
        imports_list = "\n".join(
            f"  - {af.import_str} (in {af.file_path}:{af.line})"
            for af in result.affected_files[:30]
        )
        prompt = IMPACT_ANALYSIS_PROMPT.format(
            package=result.package,
            version=result.target_version,
            imports_list=imports_list or "  (none detected)",
            changelog=changelog[:1500] if changelog else "(no changelog available)",
        )
        return self._complete(prompt)

    def analyze_coupling(self, report: CouplingReport) -> str:
        unstable = "\n".join(
            f"  - {m.module} (instability={m.instability}, Ce={m.efferent_coupling})"
            for m in report.highly_unstable[:10]
        )
        cycles = "\n".join(
            f"  - {' -> '.join(c)} -> {c[0]}"
            for c in report.circular_deps[:5]
        )
        prompt = COUPLING_SUMMARY_PROMPT.format(
            unstable_modules=unstable or "  None",
            circular_deps=cycles or "  None detected",
        )
        return self._complete(prompt)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _complete(self, prompt: str) -> str:
        response: LLMResponse = self._provider.complete(prompt)
        if not response.ok:
            return f"[AI error ({response.provider}/{response.model}): {response.error}]"
        return response.text
