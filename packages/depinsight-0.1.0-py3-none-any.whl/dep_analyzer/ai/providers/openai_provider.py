"""OpenAI provider (GPT-4o, GPT-4o-mini, o1, o3, etc.)."""

from __future__ import annotations

from .base import BaseProvider, LLMResponse


class OpenAIProvider(BaseProvider):
    name            = "openai"
    default_model   = "gpt-4o-mini"
    install_extra   = "openai"
    requires_api_key = True

    def complete(self, prompt: str, max_tokens: int = 1024) -> LLMResponse:
        try:
            import openai
            client = openai.OpenAI(api_key=self.api_key)
            response = client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
            )
            return LLMResponse(
                text=response.choices[0].message.content or "",
                provider=self.name,
                model=self.model,
            )
        except ImportError:
            return LLMResponse(text="", provider=self.name, model=self.model,
                               error=self.unavailable_reason())
        except Exception as e:
            return LLMResponse(text="", provider=self.name, model=self.model, error=str(e))

    def _sdk_installed(self) -> bool:
        try:
            import openai  # noqa: F401
            return True
        except ImportError:
            return False
