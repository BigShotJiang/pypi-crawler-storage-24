"""
Provider factory.

Two ways to select a provider — whichever is set wins (priority top to bottom):

  1. Explicit --provider flag on the CLI
  2. DEP_ANALYZER_PROVIDER env var
  3. Auto-detect from DEP_ANALYZER_MODEL / --model (model name prefix)
  4. Default: anthropic

Auto-detection rules (model name → provider):
  claude-*         → anthropic
  gpt-*, o1-*, o3* → openai
  azure/*          → azure
  bedrock/*        → bedrock
  llama*, mistral* → bedrock  (these only exist on Bedrock/Ollama)
  titan*           → bedrock

Install groups match provider names exactly:
  pip install dep-analyzer[anthropic]
  pip install dep-analyzer[openai]       # also covers azure
  pip install dep-analyzer[bedrock]
  pip install dep-analyzer[all-ai]       # everything
"""

from __future__ import annotations

import os

from .base import BaseProvider

# Canonical provider name -> human description
PROVIDER_REGISTRY: dict[str, str] = {
    "anthropic": "Anthropic Claude  |  pip install dep-analyzer[anthropic]",
    "openai":    "OpenAI GPT/o-series  |  pip install dep-analyzer[openai]",
    "azure":     "Azure OpenAI  |  pip install dep-analyzer[openai]",
    "bedrock":   "AWS Bedrock  |  pip install dep-analyzer[bedrock]",
}

# Provider aliases (all lowercase) → canonical name
_ALIASES: dict[str, str] = {
    "anthropic": "anthropic",
    "claude":    "anthropic",
    "openai":    "openai",
    "gpt":       "openai",
    "chatgpt":   "openai",
    "azure":     "azure",
    "azure_openai": "azure",
    "azure-openai": "azure",
    "azureopenai":  "azure",
    "bedrock":   "bedrock",
    "aws":       "bedrock",
    "aws_bedrock": "bedrock",
    "awsbedrock":  "bedrock",
}

# Model name prefix → provider (for auto-detection)
_MODEL_PREFIXES: list[tuple[str, str]] = [
    ("claude-",   "anthropic"),
    ("gpt-",      "openai"),
    ("gpt4",      "openai"),
    ("o1-",       "openai"),
    ("o1",        "openai"),
    ("o3",        "openai"),
    ("azure/",    "azure"),
    ("bedrock/",  "bedrock"),
    ("llama",     "bedrock"),
    ("mistral",   "bedrock"),
    ("titan",     "bedrock"),
    ("nova",      "bedrock"),
]


def list_providers() -> list[str]:
    return list(PROVIDER_REGISTRY.keys())


def detect_provider_from_model(model: str) -> str | None:
    """Guess provider from model name. Returns canonical name or None."""
    lower = model.lower()
    for prefix, provider in _MODEL_PREFIXES:
        if lower.startswith(prefix):
            return provider
    return None


def resolve_provider_name(raw: str) -> str:
    """Normalize a provider alias to its canonical name. Raises ValueError if unknown."""
    canonical = _ALIASES.get(raw.lower().strip())
    if not canonical:
        options = ", ".join(list_providers())
        raise ValueError(
            f"Unknown provider '{raw}'.\n"
            f"Available: {options}\n"
            f"Or set DEP_ANALYZER_MODEL to auto-detect (e.g. claude-sonnet-4-6 -> anthropic)"
        )
    return canonical


def create_provider(
    provider: str | None = None,
    model: str | None = None,
    api_key: str | None = None,
) -> BaseProvider:
    """
    Resolve and instantiate the correct provider.

    Resolution order:
      1. provider argument
      2. DEP_ANALYZER_PROVIDER env var
      3. Auto-detect from model name (argument or DEP_ANALYZER_MODEL env var)
      4. Default: anthropic
    """
    resolved_key   = api_key or os.environ.get("DEP_ANALYZER_API_KEY", "")
    resolved_model = model or os.environ.get("DEP_ANALYZER_MODEL") or None

    # Resolve provider name
    raw_provider = (
        provider
        or os.environ.get("DEP_ANALYZER_PROVIDER")
        or (detect_provider_from_model(resolved_model) if resolved_model else None)
        or "anthropic"
    )

    canonical = resolve_provider_name(raw_provider)

    # --- Anthropic ---
    if canonical == "anthropic":
        from .anthropic_provider import AnthropicProvider
        return AnthropicProvider(api_key=resolved_key, model=resolved_model)

    # --- OpenAI ---
    if canonical == "openai":
        from .openai_provider import OpenAIProvider
        return OpenAIProvider(api_key=resolved_key, model=resolved_model)

    # --- Azure OpenAI ---
    if canonical == "azure":
        from .azure_openai_provider import AzureOpenAIProvider
        return AzureOpenAIProvider(
            api_key=resolved_key,
            model=resolved_model or os.environ.get("DEP_ANALYZER_AZURE_DEPLOYMENT"),
            azure_endpoint=os.environ.get("DEP_ANALYZER_AZURE_ENDPOINT", ""),
            azure_deployment=os.environ.get("DEP_ANALYZER_AZURE_DEPLOYMENT", ""),
            azure_api_version=os.environ.get("DEP_ANALYZER_AZURE_API_VERSION", "2024-02-01"),
        )

    # --- AWS Bedrock ---
    if canonical == "bedrock":
        from .bedrock_provider import BedrockProvider
        return BedrockProvider(
            api_key=resolved_key,
            model=resolved_model,
            bedrock_region=os.environ.get(
                "DEP_ANALYZER_BEDROCK_REGION",
                os.environ.get("AWS_DEFAULT_REGION", ""),
            ),
        )

    # Should never reach here — resolve_provider_name already validated
    raise ValueError(f"Unhandled provider '{canonical}'")
