"""Anthropic Claude provider."""

from __future__ import annotations

from .base import BaseProvider, LLMResponse


class AnthropicProvider(BaseProvider):
    name            = "anthropic"
    default_model   = "claude-sonnet-4-6"
    install_extra   = "anthropic"
    requires_api_key = True

    def complete(self, prompt: str, max_tokens: int = 1024) -> LLMResponse:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=self.api_key)
            message = client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                messages=[{"role": "user", "content": prompt}],
            )
            return LLMResponse(text=message.content[0].text, provider=self.name, model=self.model)
        except ImportError:
            return LLMResponse(text="", provider=self.name, model=self.model,
                               error=self.unavailable_reason())
        except Exception as e:
            return LLMResponse(text="", provider=self.name, model=self.model, error=str(e))

    def _sdk_installed(self) -> bool:
        try:
            import anthropic  # noqa: F401
            return True
        except ImportError:
            return False
