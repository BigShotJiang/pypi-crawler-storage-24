"""Azure OpenAI provider (uses the openai SDK, AzureOpenAI client)."""

from __future__ import annotations

from .base import BaseProvider, LLMResponse


class AzureOpenAIProvider(BaseProvider):
    name            = "azure"
    default_model   = "gpt-4o"        # treated as deployment name
    install_extra   = "openai"        # same SDK as regular OpenAI
    requires_api_key = True

    def __init__(self, api_key: str, model: str | None = None, **kwargs):
        super().__init__(api_key, model, **kwargs)
        self.endpoint: str   = kwargs.get("azure_endpoint", "")
        self.deployment: str = model or kwargs.get("azure_deployment", self.default_model)
        self.api_version: str = kwargs.get("azure_api_version", "2024-02-01")
        # model attr should reflect the deployment name
        self.model = self.deployment

    def complete(self, prompt: str, max_tokens: int = 2048) -> LLMResponse:
        if not self.endpoint:
            return LLMResponse(
                text="", provider=self.name, model=self.deployment,
                error="DEP_ANALYZER_AZURE_ENDPOINT is not set.",
            )
        try:
            from openai import AzureOpenAI
            client = AzureOpenAI(
                api_key=self.api_key,
                azure_endpoint=self.endpoint,
                api_version=self.api_version,
            )
            response = client.chat.completions.create(
                model=self.deployment,
                messages=[{"role": "user", "content": prompt}],
                max_completion_tokens=max_tokens,
            )
            text = (response.choices[0].message.content or "").strip()
            return LLMResponse(text=text, provider=self.name, model=self.deployment)
        except ImportError:
            return LLMResponse(text="", provider=self.name, model=self.deployment,
                               error=self.unavailable_reason())
        except Exception as e:
            err = str(e) or repr(e)
            return LLMResponse(text="", provider=self.name, model=self.deployment, error=err)

    def _sdk_installed(self) -> bool:
        try:
            from openai import AzureOpenAI  # noqa: F401
            return True
        except ImportError:
            return False
