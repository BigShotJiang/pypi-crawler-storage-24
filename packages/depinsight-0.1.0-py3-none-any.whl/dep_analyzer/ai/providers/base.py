"""Abstract base class for all LLM providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class LLMResponse:
    text: str
    provider: str
    model: str
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and bool(self.text)


class BaseProvider(ABC):
    """Common interface every LLM provider must implement."""

    name: str = ""             # canonical name, matches pip extra: e.g. "anthropic"
    default_model: str = ""    # used when user doesn't specify a model
    install_extra: str = ""    # pip install dep-analyzer[<this>]
    requires_api_key: bool = True  # Bedrock uses AWS creds, not an API key

    def __init__(self, api_key: str, model: str | None = None, **kwargs):
        self.api_key = api_key
        self.model = model or self.default_model
        self._extra = kwargs

    @abstractmethod
    def complete(self, prompt: str, max_tokens: int = 1024) -> LLMResponse:
        """Send a prompt and return the completion."""

    @abstractmethod
    def _sdk_installed(self) -> bool:
        """Return True if the required SDK package is importable."""

    def is_available(self) -> bool:
        if not self._sdk_installed():
            return False
        if self.requires_api_key and not self.api_key:
            return False
        return True

    def unavailable_reason(self) -> str | None:
        """Return a human-readable reason if not available, else None."""
        if not self._sdk_installed():
            return (
                f"SDK not installed.\n"
                f"Run:  pip install dep-analyzer[{self.install_extra}]"
            )
        if self.requires_api_key and not self.api_key:
            return (
                f"No API key found.\n"
                f"Set:  DEP_ANALYZER_API_KEY=<your-key>"
            )
        return None
