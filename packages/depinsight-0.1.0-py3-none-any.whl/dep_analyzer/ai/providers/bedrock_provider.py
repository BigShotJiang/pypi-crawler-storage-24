"""AWS Bedrock provider (Claude, Llama3, Mistral, Titan via boto3)."""

from __future__ import annotations

import json

from .base import BaseProvider, LLMResponse

# Short alias -> full Bedrock model ID
MODEL_ALIASES: dict[str, str] = {
    "claude-3-5-sonnet": "us.anthropic.claude-3-5-sonnet-20241022-v2:0",
    "claude-3-5-haiku":  "us.anthropic.claude-3-5-haiku-20241022-v1:0",
    "claude-3-opus":     "us.anthropic.claude-3-opus-20240229-v1:0",
    "claude-3-sonnet":   "us.anthropic.claude-3-sonnet-20240229-v1:0",
    "claude-3-haiku":    "us.anthropic.claude-3-haiku-20240307-v1:0",
    "llama3-70b":        "meta.llama3-70b-instruct-v1:0",
    "llama3-8b":         "meta.llama3-8b-instruct-v1:0",
    "mistral-large":     "mistral.mistral-large-2402-v1:0",
    "mistral-7b":        "mistral.mistral-7b-instruct-v0:2",
    "titan-express":     "amazon.titan-text-express-v1",
    "titan-lite":        "amazon.titan-text-lite-v1",
}

_DEFAULT_ALIAS = "claude-3-5-sonnet"


class BedrockProvider(BaseProvider):
    name             = "bedrock"
    default_model    = _DEFAULT_ALIAS
    install_extra    = "bedrock"
    requires_api_key = False   # uses AWS credential chain, not DEP_ANALYZER_API_KEY

    def __init__(self, api_key: str, model: str | None = None, **kwargs):
        super().__init__(api_key, model, **kwargs)
        alias = model or _DEFAULT_ALIAS
        self.model_id: str = MODEL_ALIASES.get(alias, alias)  # accept full ID too
        self.model = alias   # keep human-readable alias as .model
        self.region: str = kwargs.get("bedrock_region", "")

    def complete(self, prompt: str, max_tokens: int = 1024) -> LLMResponse:
        try:
            import boto3
            kwargs = {}
            if self.region:
                kwargs["region_name"] = self.region
            client = boto3.client("bedrock-runtime", **kwargs)

            body = self._build_request(prompt, max_tokens)
            resp = client.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body),
            )
            text = self._parse_response(json.loads(resp["body"].read()))
            return LLMResponse(text=text, provider=self.name, model=self.model_id)
        except ImportError:
            return LLMResponse(text="", provider=self.name, model=self.model_id,
                               error=self.unavailable_reason())
        except Exception as e:
            return LLMResponse(text="", provider=self.name, model=self.model_id, error=str(e))

    def is_available(self) -> bool:
        return self._sdk_installed() and self._aws_creds_available()

    def unavailable_reason(self) -> str | None:
        if not self._sdk_installed():
            return (
                "boto3 not installed.\n"
                "Run:  pip install dep-analyzer[bedrock]"
            )
        if not self._aws_creds_available():
            return (
                "No AWS credentials found.\n"
                "Set:  AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_DEFAULT_REGION\n"
                "  or: configure an IAM role / aws configure"
            )
        return None

    def _sdk_installed(self) -> bool:
        try:
            import boto3  # noqa: F401
            return True
        except ImportError:
            return False

    def _aws_creds_available(self) -> bool:
        try:
            import boto3
            return boto3.Session().get_credentials() is not None
        except Exception:
            return False

    def _build_request(self, prompt: str, max_tokens: int) -> dict:
        mid = self.model_id.lower()
        if "anthropic" in mid or "claude" in mid:
            return {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}],
            }
        if "meta.llama" in mid:
            return {
                "prompt": (
                    "<|begin_of_text|><|start_header_id|>user<|end_header_id|>"
                    f"\n\n{prompt}<|eot_id|>"
                    "<|start_header_id|>assistant<|end_header_id|>\n\n"
                ),
                "max_gen_len": max_tokens,
                "temperature": 0.1,
            }
        if "mistral" in mid:
            return {"prompt": f"<s>[INST] {prompt} [/INST]", "max_tokens": max_tokens}
        if "amazon.titan" in mid:
            return {
                "inputText": prompt,
                "textGenerationConfig": {"maxTokenCount": max_tokens, "temperature": 0.1},
            }
        # fallback: Claude-style
        return {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }

    def _parse_response(self, body: dict) -> str:
        mid = self.model_id.lower()
        if "anthropic" in mid or "claude" in mid:
            return body.get("content", [{}])[0].get("text", "")
        if "meta.llama" in mid:
            return body.get("generation", "")
        if "mistral" in mid:
            outputs = body.get("outputs", [{}])
            return outputs[0].get("text", "") if outputs else ""
        if "amazon.titan" in mid:
            results = body.get("results", [{}])
            return results[0].get("outputText", "") if results else ""
        return str(body)
