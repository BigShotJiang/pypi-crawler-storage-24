"""Prompt templates for LLM-powered analysis."""

IMPACT_ANALYSIS_PROMPT = """\
You are a Python dependency analysis expert.

Package: {package}
Upgrading to version: {version}

The following imports from this package are used in the codebase:
{imports_list}

Here is the changelog / release notes for version {version}:
---
{changelog}
---

Task:
1. Identify which of the used imports are likely affected by breaking changes.
2. For each affected import, explain:
   - What changed
   - The severity (HIGH/MEDIUM/LOW)
   - How to fix it
3. If no breaking changes are detected for the specific imports used, say so clearly.

Be specific and concise. Format your response as a structured list.
"""

COUPLING_SUMMARY_PROMPT = """\
You are a Python software architect.

The following modules have high instability scores (they depend on many things
but nothing depends on them):

{unstable_modules}

Circular dependencies detected:
{circular_deps}

Provide:
1. A brief assessment of the coupling health of this codebase
2. The top 3 specific refactoring suggestions to reduce coupling
3. Any patterns you notice that are causing tight coupling

Keep the response concise and actionable.
"""

RISK_SUMMARY_PROMPT = """\
You are a Python security and maintenance expert.

The following dependency risks were detected in a Python project:

{risk_items}

Provide:
1. A prioritized list of which risks to address first
2. Specific upgrade paths or alternative packages where applicable
3. Any security implications

Be practical and specific.
"""
