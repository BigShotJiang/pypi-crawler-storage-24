"""Fetch and parse changelogs from PyPI and GitHub."""

from __future__ import annotations

import json
import re
import urllib.request
from functools import lru_cache


@lru_cache(maxsize=64)
def fetch_changelog(package: str, version: str = "") -> str:
    """
    Try to fetch changelog / release notes for a package.
    Order of attempts:
      1. PyPI project description (often includes changelog)
      2. GitHub releases API (if project_urls has a GitHub link)
    Returns the text or empty string.
    """
    pypi_data = _fetch_pypi_data(package, version)
    if not pypi_data:
        return ""

    info = pypi_data.get("info", {})

    # Try changelog-like sections in description
    description = info.get("description", "")
    changelog_section = _extract_changelog_section(description, version)
    if changelog_section:
        return changelog_section

    # Try GitHub releases
    github_url = _find_github_url(info.get("project_urls") or {})
    if github_url:
        release_notes = _fetch_github_release(github_url, version)
        if release_notes:
            return release_notes

    return description[:3000] if description else ""


def _fetch_pypi_data(package: str, version: str) -> dict | None:
    url = f"https://pypi.org/pypi/{package}"
    if version and version != "latest":
        url += f"/{version}"
    url += "/json"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


def _extract_changelog_section(text: str, version: str) -> str:
    """Extract the section of text relevant to a specific version."""
    if not text or not version:
        return ""

    # Look for version headings: ## 4.0, # Version 4.0, [4.0], etc.
    patterns = [
        rf"#+\s*[Vv]?{re.escape(version)}",
        rf"\[{re.escape(version)}\]",
        rf"^{re.escape(version)}\s*$",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.MULTILINE)
        if match:
            start = match.start()
            # Find the next version heading or end
            next_match = re.search(r"^#+\s|\n\[", text[start + 1:], re.MULTILINE)
            end = start + 1 + next_match.start() if next_match else start + 3000
            return text[start:end].strip()

    return ""


def _find_github_url(project_urls: dict) -> str | None:
    for key, url in project_urls.items():
        if url and "github.com" in url:
            # Normalize to repo root
            match = re.match(r"https://github\.com/([^/]+/[^/]+)", url)
            if match:
                return f"https://github.com/{match.group(1)}"
    return None


def _fetch_github_release(repo_url: str, version: str) -> str:
    """Fetch GitHub release notes for a version tag."""
    # Extract owner/repo
    match = re.search(r"github\.com/(.+)", repo_url)
    if not match:
        return ""

    repo_path = match.group(1).rstrip("/")
    api_url = f"https://api.github.com/repos/{repo_path}/releases/tags/v{version}"

    try:
        req = urllib.request.Request(api_url, headers={"Accept": "application/vnd.github.v3+json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            return data.get("body", "")
    except Exception:
        return ""
