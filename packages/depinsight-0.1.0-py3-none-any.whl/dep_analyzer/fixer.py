"""
AST-based auto-fix engine — line-level targeted replacement.

Detects breaking import/call patterns via AST, then applies fixes
by replacing only the affected source lines — preserving all other
formatting, comments, and string quote styles.
"""

from __future__ import annotations

import ast
import difflib
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class FixRule:
    old_api: str            # full dotted path: "django.utils.encoding.force_text"
    new_name: str           # new symbol name:  "force_str"
    new_module: str = ""    # new module if moved; empty = same module
    detail: str = ""
    confidence: str = "HIGH"  # HIGH | MEDIUM


@dataclass
class AppliedFix:
    file_path: str
    line: int               # 1-indexed
    old_line: str
    new_line: str
    rule: FixRule


@dataclass
class FixResult:
    file_path: str
    original: str
    fixed: str
    fixes: list[AppliedFix] = field(default_factory=list)
    backup_path: str = ""

    @property
    def changed(self) -> bool:
        return self.original != self.fixed

    def diff(self) -> str:
        return "".join(difflib.unified_diff(
            self.original.splitlines(keepends=True),
            self.fixed.splitlines(keepends=True),
            fromfile=f"{self.file_path} (before)",
            tofile=f"{self.file_path} (after)",
        ))


def build_rules(breaking_apis: list) -> dict[str, FixRule]:
    """Convert BreakingAPI objects into FixRule dict keyed by old_api."""
    rules: dict[str, FixRule] = {}
    for api in breaking_apis:
        if not api.new_api:
            continue
        new_parts = api.new_api.rsplit(".", 1)
        new_name   = new_parts[-1]
        new_module = new_parts[0] if len(new_parts) == 2 else ""
        rules[api.old_api] = FixRule(
            old_api=api.old_api,
            new_name=new_name,
            new_module=new_module,
            detail=api.detail or "",
        )
    return rules


def apply_fixes_to_source(source: str, rules: dict[str, FixRule]) -> tuple[str, list[AppliedFix]]:
    """
    Find breaking imports via AST, then patch only those lines in the raw source.
    Preserves all formatting, comments, and quote styles in unaffected lines.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source, []

    lines = source.splitlines(keepends=True)
    patches: dict[int, tuple[str, FixRule]] = {}    # lineno(1-idx) -> (new_line, rule)
    alias_map: dict[str, FixRule] = {}               # local_name -> rule (for call renaming)

    # ── Pass 1: find imports that need changing ────────────────────────────────
    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        module = node.module or ""
        for alias in node.names:
            full = f"{module}.{alias.name}"
            rule = rules.get(full)
            if not rule:
                continue

            local = alias.asname or alias.name
            alias_map[local] = rule

            lineno = node.lineno  # 1-indexed
            old_line = lines[lineno - 1]

            # Build new line by targeted string substitution
            new_line = _patch_import_line(old_line, module, alias.name,
                                           rule.new_module or module, rule.new_name)

            # Deduplicate: skip if this exact new line already exists anywhere
            new_stripped = new_line.strip()
            if any(l.strip() == new_stripped for l in lines):
                continue

            patches[lineno] = (new_line, rule)

    if not patches and not alias_map:
        return source, []

    # ── Pass 2: rename call sites that used from-imported names ───────────────
    call_patches: dict[int, tuple[str, FixRule]] = {}
    if alias_map:
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            name = None
            if isinstance(func, ast.Name):
                name = func.id
            elif isinstance(func, ast.Attribute):
                # only handle simple obj.method if obj matches an alias
                pass

            if name and name in alias_map:
                rule = alias_map[name]
                lineno = node.lineno
                if lineno in patches or lineno in call_patches:
                    continue  # already patching this line
                old_line = lines[lineno - 1]
                new_line = _rename_identifier(old_line, name, rule.new_name)
                if new_line != old_line:
                    call_patches[lineno] = (new_line, rule)

    all_patches = {**patches, **call_patches}

    # ── Apply patches: replace only patched lines ──────────────────────────────
    new_lines = list(lines)
    for lineno, (new_line, _) in all_patches.items():
        new_lines[lineno - 1] = new_line

    new_source = "".join(new_lines)

    applied: list[AppliedFix] = []
    for lineno, (new_line, rule) in sorted(all_patches.items()):
        applied.append(AppliedFix(
            file_path="",
            line=lineno,
            old_line=lines[lineno - 1].rstrip(),
            new_line=new_line.rstrip(),
            rule=rule,
        ))

    return new_source, applied


def fix_file(file_path: Path, rules: dict[str, FixRule], backup: bool = True) -> FixResult:
    source = file_path.read_text(encoding="utf-8", errors="replace")
    new_source, fixes = apply_fixes_to_source(source, rules)

    result = FixResult(
        file_path=str(file_path),
        original=source,
        fixed=new_source,
        fixes=fixes,
    )

    if result.changed and backup:
        bak = Path(str(file_path) + ".bak")
        shutil.copy2(file_path, bak)
        result.backup_path = str(bak)

    return result


def write_fix(result: FixResult):
    Path(result.file_path).write_text(result.fixed, encoding="utf-8")


# ── Line-level helpers ─────────────────────────────────────────────────────────

def _patch_import_line(line: str, old_module: str, old_name: str,
                        new_module: str, new_name: str) -> str:
    """
    Patch a single 'from X import ...' line.
    Handles: aliases, multi-name imports, parenthesised imports.
    Preserves surrounding whitespace and comments.
    """
    result = line

    # Replace module if changed
    if new_module != old_module:
        result = result.replace(old_module, new_module, 1)

    # Replace the imported name (word-boundary safe)
    result = re.sub(r'\b' + re.escape(old_name) + r'\b', new_name, result)

    return result


def _rename_identifier(line: str, old_name: str, new_name: str) -> str:
    """Replace a bare identifier in a line, word-boundary safe."""
    return re.sub(r'\b' + re.escape(old_name) + r'\b', new_name, line)
