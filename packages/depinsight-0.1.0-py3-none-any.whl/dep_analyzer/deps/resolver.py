"""Resolve transitive dependencies using pipdeptree or PyPI API."""

import json
import subprocess
import urllib.request
from functools import lru_cache

from .models import PackageDep


def get_transitive_deps_pipdeptree(package_name: str) -> list[PackageDep]:
    """Use pipdeptree (if installed) to resolve transitive deps for a package."""
    try:
        result = subprocess.run(
            ["pipdeptree", "--json-tree", "-p", package_name],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return []
        tree = json.loads(result.stdout)
        return _flatten_tree(tree, source="pipdeptree")
    except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
        return []


@lru_cache(maxsize=128)
def get_package_deps_pypi(package_name: str, version: str = "") -> list[PackageDep]:
    """Fetch dependencies for a package from PyPI JSON API."""
    try:
        url = f"https://pypi.org/pypi/{package_name}"
        if version:
            url += f"/{version}"
        url += "/json"

        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())

        requires = data.get("info", {}).get("requires_dist") or []
        deps: list[PackageDep] = []
        for req_str in requires:
            # Skip extras and optional deps
            if "extra ==" in req_str:
                continue
            dep = _parse_simple_req(req_str, source=f"pypi:{package_name}")
            if dep:
                dep.is_direct = False
                deps.append(dep)
        return deps
    except Exception:
        return []


def _parse_simple_req(req_str: str, source: str) -> PackageDep | None:
    """Minimal parser for a requires_dist string."""
    import re
    match = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(\[.*?\])?\s*(.*?)(?:\s*;.*)?$", req_str)
    if not match:
        return None
    name = match.group(1).strip()
    version = (match.group(3) or "").strip()
    return PackageDep(name=name.lower(), version_spec=version, extras=[], source_file=source)


def _flatten_tree(tree: list, source: str) -> list[PackageDep]:
    """Recursively flatten pipdeptree JSON output."""
    result: list[PackageDep] = []
    for pkg in tree:
        result.append(PackageDep(
            name=pkg.get("package_name", "").lower(),
            version_spec=pkg.get("installed_version", ""),
            extras=[],
            source_file=source,
            is_direct=False,
        ))
        result.extend(_flatten_tree(pkg.get("dependencies", []), source))
    return result
