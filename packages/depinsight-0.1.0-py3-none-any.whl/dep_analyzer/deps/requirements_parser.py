"""Parse requirements.txt style dependency files."""

import re
from pathlib import Path

from .models import PackageDep

# PEP 508 simplified: name[extras]version_spec
_REQ_RE = re.compile(
    r"^\s*"
    r"(?P<name>[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)"  # package name
    r"(?:\[(?P<extras>[^\]]+)\])?"                            # optional extras
    r"\s*(?P<version>[^;#\n]*?)"                              # version spec
    r"\s*(?:;[^#]*)?"                                         # optional env marker
    r"\s*(?:#.*)?"                                            # optional comment
    r"\s*$"
)


def parse_requirements(file_path: Path) -> list[PackageDep]:
    """Parse a requirements.txt file into a list of PackageDep objects."""
    deps: list[PackageDep] = []

    try:
        lines = file_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return deps

    for raw_line in lines:
        line = raw_line.strip()

        # Skip comments, empty lines, flags (-r, -c, -i, --index-url, etc.)
        if not line or line.startswith("#") or line.startswith("-"):
            continue

        # Skip editable installs and VCS URLs for now
        if line.startswith("git+") or line.startswith("http"):
            continue

        match = _REQ_RE.match(line)
        if not match:
            continue

        name = match.group("name").strip()
        extras_str = match.group("extras") or ""
        version = (match.group("version") or "").strip()

        extras = [e.strip() for e in extras_str.split(",") if e.strip()]

        deps.append(PackageDep(
            name=name.lower(),
            version_spec=version,
            extras=extras,
            source_file=str(file_path),
        ))

    return deps
