"""Parse pyproject.toml and setup.cfg dependency files."""

import re
import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            tomllib = None  # type: ignore[assignment]

from .models import PackageDep

_PEP508_RE = re.compile(
    r"^\s*(?P<name>[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)"
    r"(?:\[(?P<extras>[^\]]+)\])?"
    r"\s*(?P<version>[^;#\n]*?)\s*$"
)


def _parse_pep508(dep_str: str, source_file: str) -> PackageDep | None:
    match = _PEP508_RE.match(dep_str.split(";")[0].strip())
    if not match:
        return None
    name = match.group("name").strip()
    extras_str = match.group("extras") or ""
    version = (match.group("version") or "").strip()
    extras = [e.strip() for e in extras_str.split(",") if e.strip()]
    return PackageDep(name=name.lower(), version_spec=version, extras=extras, source_file=source_file)


def parse_pyproject(file_path: Path) -> list[PackageDep]:
    """Parse pyproject.toml (PEP 621 and Poetry) into PackageDep list."""
    if tomllib is None:
        return []

    try:
        data = tomllib.loads(file_path.read_text(encoding="utf-8"))
    except Exception:
        return []

    deps: list[PackageDep] = []
    src = str(file_path)

    # PEP 621: [project.dependencies]
    for dep_str in data.get("project", {}).get("dependencies", []):
        dep = _parse_pep508(dep_str, src)
        if dep:
            deps.append(dep)

    # PEP 621: [project.optional-dependencies]
    for group_deps in data.get("project", {}).get("optional-dependencies", {}).values():
        for dep_str in group_deps:
            dep = _parse_pep508(dep_str, src)
            if dep:
                dep.is_direct = False
                deps.append(dep)

    # Poetry: [tool.poetry.dependencies]
    poetry_deps = data.get("tool", {}).get("poetry", {}).get("dependencies", {})
    for name, spec in poetry_deps.items():
        if name.lower() == "python":
            continue
        if isinstance(spec, str):
            version = spec
        elif isinstance(spec, dict):
            version = spec.get("version", "")
        else:
            version = ""
        deps.append(PackageDep(name=name.lower(), version_spec=version, extras=[], source_file=src))

    return deps


def parse_setup_cfg(file_path: Path) -> list[PackageDep]:
    """Parse setup.cfg install_requires into PackageDep list."""
    try:
        import configparser
        cfg = configparser.ConfigParser()
        cfg.read(str(file_path))
    except Exception:
        return []

    deps: list[PackageDep] = []
    src = str(file_path)

    raw = cfg.get("options", "install_requires", fallback="")
    for line in raw.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        dep = _parse_pep508(line, src)
        if dep:
            deps.append(dep)

    return deps
