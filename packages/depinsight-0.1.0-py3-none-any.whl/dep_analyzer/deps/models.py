"""Data models for dependency information."""

from dataclasses import dataclass, field


@dataclass
class PackageDep:
    name: str                    # normalized lowercase name
    version_spec: str            # e.g. ">=3.2,<4.0"
    extras: list[str]            # e.g. ["security", "async"]
    source_file: str
    is_direct: bool = True

    @property
    def normalized_name(self) -> str:
        return self.name.lower().replace("-", "_")


@dataclass
class DependencySet:
    direct: list[PackageDep] = field(default_factory=list)
    transitive: list[PackageDep] = field(default_factory=list)
    source_files: list[str] = field(default_factory=list)

    @property
    def all_packages(self) -> list[PackageDep]:
        return self.direct + self.transitive

    def find(self, name: str) -> PackageDep | None:
        norm = name.lower().replace("-", "_")
        for p in self.all_packages:
            if p.normalized_name == norm:
                return p
        return None

    def direct_names(self) -> set[str]:
        return {p.normalized_name for p in self.direct}
