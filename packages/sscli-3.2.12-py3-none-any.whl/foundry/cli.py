from typing import Optional, List
from pathlib import Path
from foundry.constants import console, DISABLED_FEATURES_POLICY
import typer
from foundry.actions.explore import run_explore, run_explore_list, run_explore_json
from foundry.actions.generator import run_generator
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup
from foundry.actions.validation import run_smoke_tests
from foundry.actions.verify import run_verification
from foundry.actions.upgrade import run_upgrade
from foundry.auth import logout
from foundry.commands.auth import auth_app, run_whoami
from foundry.commands.interactive import interactive_app
from foundry.commands.observability import observability_app
from foundry.commands.internals import internals_app
from foundry.commands.feedback import feedback_app
from foundry.utils import is_internal_dev

app = typer.Typer(
    help="Seed & Source CLI Tool",
    no_args_is_help=False,
    add_completion=True,
)

COMING_SOON_FLAG_MESSAGES = {
    cfg["flag"]: cfg["message"] for cfg in DISABLED_FEATURES_POLICY.values()
}


def _exit_coming_soon(flag: str) -> None:
    console.print(f"[red]❌ Error: {flag} is coming soon.[/red]")
    console.print(f"[yellow]{COMING_SOON_FLAG_MESSAGES[flag]}[/yellow]")
    raise typer.Exit(code=1)

# Add sub-apps from separate modules
app.add_typer(auth_app, name="auth")
app.add_typer(interactive_app, name="interactive")
app.add_typer(observability_app, name="obs", help="Observability, diff, and workspace tools")
app.add_typer(feedback_app, name="feedback", help="Submit feedback, bugs, and feature requests")

# Only expose dev tools in internal development mode
if is_internal_dev():
    app.add_typer(internals_app, name="internals", help="Internal-projects execution and annotation tools")
    from foundry.commands.dev import dev_app
    app.add_typer(dev_app, name="dev", help="Development and maintenance tools")


@app.callback(invoke_without_command=True)
def default_action(ctx: typer.Context):
    """Default action: show interactive menu if no command is provided."""
    if ctx.invoked_subcommand is None:
        from foundry.interactive import interactive_menu
        interactive_menu()


@app.command("whoami")
def whoami():
    run_whoami()


@app.command("logout")
def logout_cmd():
    """Clear local credentials and logout."""
    logout()


@app.command("explore")
def explore(
    list_mode: bool = typer.Option(False, "--list", help="Non-interactive plain-text list (safe in pipes)"),
    json_mode: bool = typer.Option(False, "--json", help="Non-interactive JSON catalog output (safe in pipes)"),
):
    """List available templates. Use --list or --json for pipe-safe non-interactive output."""
    import sys
    if json_mode:
        run_explore_json()
        return
    if list_mode:
        run_explore_list()
        return
    if not sys.stdout.isatty():
        # Non-interactive terminal (piped output) — fall back to plain list
        run_explore_list()
        return
    run_explore()


@app.command("new")
def new(
    template: str = typer.Option(..., help="Template to use — try 'rails-api', 'python-saas', 'react-client', or 'static-landing'"),
    name: str = typer.Option(..., help="Your app name — used as the project directory and package name"),
    target: Optional[str] = typer.Option(
        None, help="Where to create the project (defaults to --name if not set)"
    ),
    no_lint: bool = typer.Option(False, "--no-lint", help="Skip the built-in linter setup (ruff for Python, rubocop for Rails, eslint for React)"),
    with_commerce: bool = typer.Option(
        False, "--with-commerce", help="Add a full e-commerce layer (products, orders, Stripe checkout) to your project"
    ),
    with_payment: bool = typer.Option(
        False, "--with-payment", help="Add Stripe payment processing to your project"
    ),
    with_tunnel: bool = typer.Option(
        False, "--with-tunnel", help="Add ngrok tunnel support for local development & webhooks"
    ),
    with_landing: bool = typer.Option(
        False, "--with-landing", help="Add a static landing page template to your project"
    ),
    with_admin: bool = typer.Option(
        False, "--with-admin", help="Add an admin dashboard with user management"
    ),
    with_sqlite: bool = typer.Option(
        False, "--with-sqlite", help="Use SQLite for local development (no database setup required)"
    ),
    with_ingestor: bool = typer.Option(
        False, "--with-ingestor", help="Add a data ingestion pipeline to your project"
    ),
    with_auth: bool = typer.Option(
        False, "--with-auth", help="Add authentication (login, sessions, JWT) to your project"
    ),
    with_seo_analyzer: bool = typer.Option(
        False, "--with-seo-analyzer", help="Add SEO analysis tools to your project"
    ),
    with_merchant_dashboard: bool = typer.Option(
        False, "--with-merchant-dashboard", help="Add a merchant dashboard with sales analytics"
    ),
    with_sidekiq: bool = typer.Option(
        False, "--with-sidekiq", help="Add background job processing with Sidekiq"
    ),
    with_ui_lib: Optional[str] = typer.Option(
        None, "--with-ui-lib", help="Add a pre-built UI component library to your project"
    ),
    use_ast_injection: bool = typer.Option(
        False, "--use-ast-injection", help="Use precise syntax-aware code injection (recommended for complex projects)"
    ),
    secrets: str = typer.Option(
        "Dotenv (Standard .env files)", help="How to manage secrets — default: .env files"
    ),
    content: Optional[str] = typer.Option(
        None, "--content", help="Path to a JSON blueprint file to pre-fill your landing page content (static-landing)"
    ),
    theme: Optional[str] = typer.Option(
        None, "--theme", help="Color theme for your landing page: emerald, midnight, slate, rose, amber (static-landing)"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview what would be generated without writing any files"),
    json: bool = typer.Option(False, "--json", help="Output the dry-run plan as JSON (use with --dry-run)"),
    stats: bool = typer.Option(False, "--stats", help="Show only file/line counts in dry-run output (use with --dry-run)"),
    output: Optional[str] = typer.Option(None, "--output", help="Save the dry-run output to a file instead of printing it (use with --dry-run)"),
):
    """Generate a new project from a template. Run 'sscli explore' to see all available templates."""
    _flag_map = {
        "auth": with_auth,
        "admin": with_admin,
        "tunnel": with_tunnel,
        "ingestor": with_ingestor,
        "merchant_dashboard": with_merchant_dashboard,
    }
    for key, cfg in DISABLED_FEATURES_POLICY.items():
        if _flag_map.get(key, False):
            _exit_coming_soon(cfg["flag"])

    # Validation: merchant-dashboard requires commerce
    if with_merchant_dashboard and not with_commerce:
        console.print("[red]❌ Error: --with-merchant-dashboard requires --with-commerce to be enabled.[/red]")
        console.print("[yellow]Use: sscli new react-client --with-commerce --with-merchant-dashboard --name [name][/yellow]")
        raise typer.Exit(code=1)
    
    run_generator(
        template_name=template,
        app_name=name,
        target_dir_name=target,
        use_linters=not no_lint,
        with_commerce=with_commerce,
        with_payment=with_payment,
        with_tunnel=with_tunnel,
        with_landing=with_landing,
        with_admin=with_admin,
        with_sqlite=with_sqlite,
        with_ingestor=with_ingestor,
        with_auth=with_auth,
        with_seo_analyzer=with_seo_analyzer,
        with_merchant_dashboard=with_merchant_dashboard,
        with_sidekiq=with_sidekiq,
        with_ui_lib=with_ui_lib,
        use_ast_injection=use_ast_injection,
        interactive=False,
        secrets_strategy=secrets,
        content_path=content,
        theme=theme,
        dry_run=dry_run,
        json_output=json,
        stats_only=stats,
        output_file=output,
    )


@app.command("inject")
def inject(
    path: Path = typer.Option(..., "--path", "-p", help="Path to the project"),
    template: Optional[str] = typer.Option(None, "--template", "-t", help="Template type (optional, auto-detects otherwise)"),
    features: List[str] = typer.Option([], "--features", "-f", help="List of features to inject (e.g. commerce, auth, admin, sqlite, ingestor, tunnel)"),
    use_ast_injection: bool = typer.Option(False, "--use-ast-injection", help="🔬 Use AST-based feature injection (experimental)"),
):
    """Inject features into an existing project."""
    from foundry.actions.features import inject_features
    from foundry.constants import console
    
    if not path.exists():
        console.print(f"[bold red]✗ Error: Path {path} does not exist[/bold red]")
        raise typer.Exit(1)
    
    # Auto-detect template if not provided
    if not template:
        if (path / "pyproject.toml").exists():
            template = "python-saas"
        elif (path / "package.json").exists():
            template = "react-client"
        elif (path / "Gemfile").exists():
            template = "rails-api"
        elif (path / "astro.config.mjs").exists():
            template = "static-landing"
        else:
            console.print("[bold red]✗ Error: Could not auto-detect template type. Please provide --template[/bold red]")
            raise typer.Exit(1)
        console.print(f"   - Auto-detected template: [bold cyan]{template}[/bold cyan]")

    # Map features list to boolean flags
    feat_map = {f.lower().replace("-", "_"): True for f in features}

    for feature_key, config in DISABLED_FEATURES_POLICY.items():
        if feat_map.get(feature_key, False):
            _exit_coming_soon(config["flag"])
    
    inject_features(
        path=path,
        template=template,
        commerce=feat_map.get("commerce", False),
        tunnel=feat_map.get("tunnel", False),
        admin=feat_map.get("admin", False),
        sqlite=feat_map.get("sqlite", False),
        ingestor=feat_map.get("ingestor", False),
        auth=feat_map.get("auth", False),
        seo_analyzer=feat_map.get("seo_analyzer", False),
        merchant_dashboard=feat_map.get("merchant_dashboard", False),
        payment=feat_map.get("payment", False),
        use_ast_injection=use_ast_injection,
        inject_static_premium_base=False,
    )
    console.print("\n[bold green]✅ Injection complete![/bold green]")


@app.command("setup")
def setup(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable detailed logging"
    ),
    force: bool = typer.Option(
        False, "--force", help="Force setup even if already configured"
    ),
    skip_deps: bool = typer.Option(
        False, "--skip-deps", help="Skip dependency installation"
    ),
    env: str = typer.Option("dev", "--env", help="Environment to setup (default: dev)"),
    strategy: Optional[str] = typer.Option(
        None, "--strategy", help="Setup strategy (docker, etc)"
    ),
):
    """Run setup for templates."""
    run_setup(
        verbose=verbose, force=force, skip_deps=skip_deps, env=env, strategy=strategy
    )


@app.command("validate")
def validate():
    """Run smoke tests."""
    run_smoke_tests()


@app.command("health")
def health():
    """Check configuration and health of templates."""
    run_health_check()


@app.command("verify")
def verify(
    skip_docker: bool = typer.Option(
        False, "--skip-docker", help="Skip Docker builds (faster, less thorough)"
    ),
    no_reports: bool = typer.Option(
        False, "--no-reports", help="Skip generating CSV/MD reports"
    ),
    features: bool = typer.Option(
        False, "--features", help="Run integration feature matrix tests"
    ),
):
    """Verify template integrity and buildability."""
    _result = run_verification(include_docker=not skip_docker, output_reports=not no_reports, include_features=features)
    if _result is False:
        raise typer.Exit(code=1)


@app.command("ready")
def ready(
    path: Optional[Path] = typer.Argument(
        None, help="Path to your generated project (defaults to current directory)"
    ),
):
    """Check if your project is ready to run locally with 'sscli dev'."""
    
    from foundry.actions.verification.project_validator import ProjectValidator
    
    project_path = path or Path.cwd()
    
    if not project_path.exists():
        console.print(f"[bold red]✗ Error: Path {project_path} does not exist[/bold red]")
        raise typer.Exit(code=1)
    
    validator = ProjectValidator(project_path)
    is_ready = validator.validate_all()
    
    if is_ready:
        raise typer.Exit(code=0)
    else:
        raise typer.Exit(code=1)


@app.command("upgrade")
def upgrade(
    project_path: Optional[str] = typer.Argument(
        None, help="Path to project (defaults to current directory)"
    ),
    to_version: Optional[str] = typer.Option(
        None, "--to-version", help="Target version (defaults to latest)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview changes without applying them"
    ),
    force: bool = typer.Option(
        False, "--force", help="Skip git status checks"
    ),
    interactive: bool = typer.Option(
        False, "--interactive", "-i", help="Confirm each codemod before applying"
    ),
    skip_verification: bool = typer.Option(
        False, "--skip-verification", help="Skip post-upgrade verification checks"
    ),
):
    """Upgrade a project to a newer template version."""
    
    if not run_upgrade(
        project_path=project_path,
        to_version=to_version,
        dry_run=dry_run,
        force=force,
        interactive=interactive,
        skip_verification=skip_verification,
    ):
        raise typer.Exit(code=1)