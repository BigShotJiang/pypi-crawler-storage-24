**Taxonomy & Governance:**

In a healthy model, knowledge flows from intent to action:
**Requirement (Why)** → **Policy (Law)** → **Decision (How)** → **Trace (Proof)**

#### Requirements (Problem Space)
Define **WHAT** the system must achieve or **WHICH** boundaries it must respect.

> [!IMPORTANT]
> **Source of Truth**: Requirements must originate EXCLUSIVELY from user input (prompts, documents, or explicit directions). Agents MUST NOT infer requirements; all functional and non-functional requirements must be citable back to a user-provided source.

| Type | Name | Definition | Example |
| :--- | :--- | :--- | :--- |
| **FR** | Functional | Specific behavior or feature. | "User can export data to CSV." |
| **NFR** | Non-Functional | Quality attributes (perf, security, UX). | "Exports must complete in <2s." |
| **CR** | Constraint | External, non-negotiable limitation. | "Must use AWS Frankfurt region." |
| **UR** | User-Specified | Raw input from user (needs refinement). | "Make it feel 'snappy'." |

#### Policies (Standing Laws)
A **Policy** is a reusable, mandatory rule that bridges Requirements and Decisions.
*   **Trigger**: Use a policy when you make the same recommendation >2 times.
*   **Scope**: Usually global or cross-application.
*   **Enforcement**: Mandatory. Deviations require an Architectural Decision (Policy Exception).
*   **Example**: *"All API calls must use Circuit Breakers to satisfy NFR (Resiliency)."*

#### Decisions (Action Space)
Defined by their **Reversibility** and **Impact**.

| Class | Reversibility | Impact | Definition |
| :--- | :--- | :--- | :--- |
| **Architectural** | High Cost | System-wide | Choices affecting core frameworks or primitives. |
| **Structural** | Moderate Cost | Component | Choices regarding organization or API contracts. |
| **Tactical** | Low Cost | Local/File | Logic, algorithms, or localized patterns. |

#### Governance Rules

1.  **Reversibility Filter (Avoid Bloat)**: Do not record every choice.
    - **Implicit follows Policy**: If a choice simply follows an existing Policy, **don't record it** as a separate decision.
    - **Explicit Deviation**: If you MUST break a policy, you MUST record it as a Decision.
    - **Arch/Struct Only**: Always record Architectural and Structural choices. Record Tactical only if logic is unintuitive.
2.  **Negative Knowledge**: Always document **Alternatives Considered** for Architectural and Structural decisions.
3.  **Promotion Strategy**:
    - **UR → FR/NFR**: Refine raw User Requirements into testable FRs/NFRs during research. *Note: Refinement must only clarify or formalize user intent, never invent it.*
    - **Tactical → Policy**: If a Tactical Decision is repeated across tasks, "promote" it to a Policy in the `REFLECT` phase.

**Validation:**
**Classification**: Adhere strictly to the definitions in Taxonomy & Governance when defining items.
**Traceability**: Every **Requirement** defines a user-facing capability. Every **Decision** defines the technical approach.
**Policies**: Mandatory standing rules for autonomous execution.
