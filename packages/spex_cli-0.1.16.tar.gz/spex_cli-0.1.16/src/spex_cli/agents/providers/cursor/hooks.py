import sys
from spex_cli.agents.hooks import base, cursor

def run_hook(event: str):
    """Execution entry point for Cursor hooks."""
    raw_data = base.get_input()
    
    # 1. Translate to unified format
    unified_data = cursor.translate_to_unified(event, raw_data)
    
    # 2. Dispatch based on event
    if event == base.HookEvent.SESSION_START:
        base.export_session_id(unified_data)
        base.record_session(unified_data)
        # Return env vars for Cursor to inject
        session_id = unified_data.get("session_id")
        if session_id:
            import json
            print(json.dumps({"env": {"SPEX_SESSION_ID": session_id}}))
    elif event == base.HookEvent.INJECT_CONTEXT:
        print(base.inject_memory_context())
    elif event in (base.HookEvent.USER_PROMPT, base.HookEvent.AFTER_TOOL):
        base.emit_interaction_metrics(unified_data)
        import json
        print(json.dumps({"decision": "allow"}))

def main():
    if len(sys.argv) < 2:
        return
    run_hook(sys.argv[1])

if __name__ == "__main__":
    main()
