---
name: spex-learn
description: You MUST use this skill for dedicated knowledge extraction. Triggered when the user wants to memorize a conversation, learn from a document, or capture specific requirements/decisions outside of the active feature orchestration flow.
---

# Spex Learn Skill

## Triggers

### Knowledge Capture Triggers
Invoke the **knowledge capture mode** when the user says the following or when a **Memory-Only Request** (e.g., "Add a policy", "Record this decision") is redirected from the `spex` orchestrator. Before executing:
> **STOP. Read the Knowledge Capture Flow section below in full now. Execute its steps verbatim.**
- "Spex memorize this..."
- "Teach spex via..."
- "Capture this decision..."
- "Record this requirement..."
- "Document this conversation..."
- "Add a new policy/requirement/decision..."
- "Read this code..."
- "Explain this file..."
- "Extract intent from..."

## Goal
The `spex-learn` skill is the **exclusive authority** for out-of-band knowledge extraction and persistence to `.spex/memory/`. It handles all requests to update memory (Requirements, Decisions, Policies) that occur outside of the active feature development lifecycle.

## Purpose
You are a knowledge capture specialist. Your sole responsibility is to extract the **"WHY" and human intent** from unstructured or semi-structured information (conversations, documentation, or code) and persist it as structured Requirements, Decisions, and Policies using the Spex Taxonomy. 

**CRITICAL**: You must never "guess" or "invent" requirements or policies based on code implementation alone. Doing so only creates "code duplicates" in memory. You must always verify the underlying human intent and rationale with the user.

## Knowledge Capture Flow

### 1. CAPTURE_INIT

When triggered, identify the source (conversation or file) and transition to `CAPTURE_EXTRACT`.

### 2. CAPTURE_EXTRACT

Extract structured knowledge for storage in spex memory.

**If source is Conversation**: Scan the current chat (user messages, agent responses, code changes).
**If source is Documentation**: Read the specified file content directly.
**If source is Code**: Read the code files and analyze the implementation logic. **Do not invent requirements or rationale**—any intent you derive is just a guess and risks duplicating the code in memory. You MUST ask the user for the real context and intent in `CAPTURE_WHY`.

#### Extraction Guidelines:

1.  **Requirement Extraction**:
    *   **Capability-First**: Focus on WHAT the system must do, avoiding specific UI prescriptions.
    *   **Categorization**: Adhere to the **Spex Taxonomy** (FR, NFR, CR, UR) defined in the core skill instructions.
    *   **Acceptance Criteria**: Ensure testable scenarios are defined (Action → Result).

2.  **Decision Extraction**:
    *   **Negative Knowledge**: Capture rejected alternatives and rationale ONLY if explicitly stated.
    *   **Classification**: Classify as **Architectural**, **Structural**, or **Tactical** based on the Reversibility Filter in the core skill.
    *   **Deep Reasoning**: Avoid shallow captures; explain the *why* based on the provided context.

3.  **Policy Extraction**:
    *   **Standing Rules**: Capture reusable, mandatory rules. If a policy relates to an **existing** Requirement, it should bridge it. If no relevant Requirement exists, the policy's **Rationale** is sufficient; do NOT invent new Requirements (NFRs) solely to satisfy the traceability hierarchy.
    *   **Implicit vs. Explicit**: Do not extract "Implicit" decisions that simply follow existing policies.

4.  **Trace Extraction**:
    *   Map code changes directly to Decisions or Requirements for full traceability.

5.  **Quality Control**:
    *   **Refinement**: Refine UR (User-Specified) items into FR/NFR where evidence allows.
    *   **Confidence**: Skip items with insufficient evidence. Low confidence = Do tidak extract.

#### App Scope Rules:
Every requirement, decision, and policy must have a `scope` (list of app names).
1. Read `.spex/memory/apps.jsonl` to see registered apps and their `filePath`.
2. The app whose `filePath` is a prefix of your current working directory or the modified files is the relevant scope.
3. If a change affects multiple apps, include all of them in the comma-separated `--scope`.
4. Empty scope means "all" (use rarely).

### 3. CAPTURE_WHY

Before presenting the user with the memory items, **please stop to ask for the "why" behind what you see**.
* Use the **`AskUserQuestion` tool** to ask the user to explain the rationale, the underlying problem, or the business context behind the changes, the document, or the code.
* **If the source is Code**: You must explicitly ask the user for the true requirements and rationale. Your hypotheses are just guesses. Do not present them as facts.
* **Do not proceed** to present the memory items until the user provides this context. This is where the real power behind learning comes from.

**Next state logic:**
- Wait for the user's response to the tool.
- Once the "why" is provided and integrated into your understanding, transition to `CAPTURE_CHECK`.

### 4. CAPTURE_CHECK

Analyze the extracted items for conflicts or redundancy.

1.  **Execute Procedure**: Follow Phase 1 and 2 from the **Conflict Detection & Resolution Procedure** defined in `conflict-resolution.md`.
2.  **Scope Validation**: Ensure all items adhere to the **App Scope Rules** defined in the extraction step.

**Next state logic:**
- Always transition to `CAPTURE_RESOLVE` to present findings for approval.

### 5. CAPTURE_RESOLVE

**This is the most critical phase.** The user's review is the final authority before data persistence.

1.  **Execute Procedure**: If conflicts or risks exist, follow the **Conflict Resolution Procedure** defined in `conflict-resolution.md`.
2.  **Presentation Principles**:
    *   **Sort by Importance**: Architectural Decisions > Structural > Policies > Tactical.
    *   **Prioritize Clarity**: Use bulleted lists and bold text. The user should understand impact in < 5 seconds.
    *   **Transparent Traceability**: Show evidence citing specific conversation context.

### 6. CAPTURE_SAVE

Save extracted items to memory using `spex` CLI:

```bash
# For each requirement
spex requirement add --type <TYPE> --description "<DESC>" --source "<SOURCE>" --acceptance-criteria "<CRITERIA>"

# For each decision
spex decision add --proposal "<PROP>" --rationale "<RAT>" --alternatives "<ALT>" --satisfies "<R_ID>" --satisfies-policies "<POL_ID>" --impact "<JSON>" --decision-class architectural|structural|tactical

# For each policy
spex policy add --description "<DESC>" --rationale "<RAT>" [--satisfies "<R_ID>"]
```

### 7. CAPTURE_COMPLETE

Report summary of what was saved.

## Key Rules

1. **Active by default** - Always prompt user to review and approve extracted items before they are persisted to memory.
2. **Evidence Required** - Every extraction must cite evidence (from conversation or document).
3. **No Invention/Code Duplication** - Only extract what was actually discussed or written. Do not "infer" requirements from code implementation; if the intent isn't explicitly stated, ask for it. Avoid creating "duplicates" of the code in memory.
4. **Link Items** - Maintain traceability (Traces → Decisions → Requirements).
5. **Skip Trivial** - Don't extract minor clarifications, typos, or "fluff".
6. **No Fluff** - Decisions must be specific enough for an engineer to understand the code-level impact immediately.
7. **Quality over Quantity** - Few high-confidence items > many uncertain items.
8. **Source Agnostic** - The check and save logic is identical regardless of source.

## When to Refuse

- Source document/conversation has no meaningful requirements or decisions.
- Source document is missing or unreadable.
- `spex` CLI is not available.


**Taxonomy & Governance:**

In a healthy model, knowledge flows from intent to action:
**Requirement (Why)** → **Policy (Law)** → **Decision (How)** → **Trace (Proof)**

#### Requirements (Problem Space)
Define **WHAT** the system must achieve or **WHICH** boundaries it must respect.

> [!IMPORTANT]
> **Source of Truth**: Requirements must originate EXCLUSIVELY from user input (prompts, documents, or explicit directions). Agents MUST NOT infer requirements; all functional and non-functional requirements must be citable back to a user-provided source.

| Type | Name | Definition | Example |
| :--- | :--- | :--- | :--- |
| **FR** | Functional | Specific behavior or feature. | "User can export data to CSV." |
| **NFR** | Non-Functional | Quality attributes (perf, security, UX). | "Exports must complete in <2s." |
| **CR** | Constraint | External, non-negotiable limitation. | "Must use AWS Frankfurt region." |
| **UR** | User-Specified | Raw input from user (needs refinement). | "Make it feel 'snappy'." |

#### Policies (Standing Laws)
A **Policy** is a reusable, mandatory rule that bridges Requirements and Decisions.
*   **Trigger**: Use a policy when you make the same recommendation >2 times.
*   **Scope**: Usually global or cross-application.
*   **Enforcement**: Mandatory. Deviations require an Architectural Decision (Policy Exception).
*   **Example**: *"All API calls must use Circuit Breakers to satisfy NFR (Resiliency)."*

#### Decisions (Action Space)
Defined by their **Reversibility** and **Impact**.

| Class | Reversibility | Impact | Definition |
| :--- | :--- | :--- | :--- |
| **Architectural** | High Cost | System-wide | Choices affecting core frameworks or primitives. |
| **Structural** | Moderate Cost | Component | Choices regarding organization or API contracts. |
| **Tactical** | Low Cost | Local/File | Logic, algorithms, or localized patterns. |

#### Governance Rules

1.  **Reversibility Filter (Avoid Bloat)**: Do not record every choice.
    - **Implicit follows Policy**: If a choice simply follows an existing Policy, **don't record it** as a separate decision.
    - **Explicit Deviation**: If you MUST break a policy, you MUST record it as a Decision.
    - **Arch/Struct Only**: Always record Architectural and Structural choices. Record Tactical only if logic is unintuitive.
2.  **Negative Knowledge**: Always document **Alternatives Considered** for Architectural and Structural decisions.
3.  **Promotion Strategy**:
    - **UR → FR/NFR**: Refine raw User Requirements into testable FRs/NFRs during research. *Note: Refinement must only clarify or formalize user intent, never invent it.*
    - **Tactical → Policy**: If a Tactical Decision is repeated across tasks, "promote" it to a Policy in the `REFLECT` phase.

**Validation:**
**Classification**: Adhere strictly to the definitions in Taxonomy & Governance when defining items.
**Traceability**: Every **Requirement** defines a user-facing capability. Every **Decision** defines the technical approach.
**Policies**: Mandatory standing rules for autonomous execution.
