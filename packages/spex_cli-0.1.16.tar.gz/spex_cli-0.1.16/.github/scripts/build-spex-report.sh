#!/bin/bash
set -euo pipefail

DECISIONS_FILE=".spex/memory/decisions.jsonl"
REQUIREMENTS_FILE=".spex/memory/requirements.jsonl"
PLANS_DIR=".spex/memory/plans"
POLICIES_FILE=".spex/memory/policies.jsonl"
APPS_FILE=".spex/memory/apps.jsonl"
MARKER="<!-- spex-pr-bot -->"

# ── 1. Extract context IDs from PR (Commits + Diff) ──────────────
COMMIT_DECISIONS=$(git log "$BASE_SHA..$HEAD_SHA" --format='%B' \
  | grep -iE 'decision[-_]id' \
  | grep -oE 'D-?[A-Za-z0-9]+' || true)
  
DIFF_DECISIONS=$(git diff -U0 "$BASE_SHA...$HEAD_SHA" -- "$DECISIONS_FILE" 2>/dev/null | grep '^+{' | sed 's/^+//' | jq -r '.id' || true)
DIFF_REQS=$(git diff -U0 "$BASE_SHA...$HEAD_SHA" -- "$REQUIREMENTS_FILE" 2>/dev/null | grep '^+{' | sed 's/^+//' | jq -r '.id' || true)
DIFF_PLANS=$(git diff --name-only "$BASE_SHA...$HEAD_SHA" -- "$PLANS_DIR/" 2>/dev/null \
  | sed 's|.*/||; s/\.json$//' | grep '^P-' | sort -u || true)
DIFF_POLICIES=$(git diff -U0 "$BASE_SHA...$HEAD_SHA" -- "$POLICIES_FILE" 2>/dev/null | grep '^+{' | sed 's/^+//' | jq -r '.id' || true)
DIFF_APPS=$(git diff -U0 "$BASE_SHA...$HEAD_SHA" -- "$APPS_FILE" 2>/dev/null | grep '^+{' | sed 's/^+//' | jq -r '.id' || true)

DECISION_IDS=$(printf "%s\n%s\n" "$COMMIT_DECISIONS" "$DIFF_DECISIONS" | grep -v '^$' | sort -u || true)
REQ_IDS_FROM_DIFF=$(printf "%s\n" "$DIFF_REQS" | grep -v '^$' | sort -u || true)
PLAN_IDS_FROM_DIFF=$(printf "%s\n" "$DIFF_PLANS" | grep -v '^$' | sort -u || true)
POLICY_IDS=$(printf "%s\n" "$DIFF_POLICIES" | grep -v '^$' | sort -u || true)
APP_IDS=$(printf "%s\n" "$DIFF_APPS" | grep -v '^$' | sort -u || true)

if [ -z "$DECISION_IDS" ] && [ -z "$REQ_IDS_FROM_DIFF" ] && [ -z "$PLAN_IDS_FROM_DIFF" ] && [ -z "$POLICY_IDS" ] && [ -z "$APP_IDS" ]; then
  echo "No Spex context changed or referenced — skipping comment."
  exit 0
fi

echo "Found decision IDs:"
echo "$DECISION_IDS"

echo "Found requirement IDs:"
echo "$REQ_IDS_FROM_DIFF"

# ── 2. Resolve context & Build Plan-Centric Markdown ────────
build_comment() {
  local policies_md="" apps_md=""
  declare -A dec_details
  declare -A req_details
  declare -A reqs_for_plan
  declare -A decs_for_plan
  declare -A seen_reqs

  # ----- Load Decisions -----
  while IFS= read -r dec_id; do
    [ -z "$dec_id" ] && continue

    DECISION=$(jq -rc --arg id "$dec_id" \
      'select(.id == $id and .status == "active")' \
      "$DECISIONS_FILE" | tail -1)

    if [ -z "$DECISION" ]; then
      decisions_md+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=decisions&id=$dec_id\"><code>$dec_id</code></a> — ⚠️ Unknown decision</summary>

> This decision ID was referenced in a commit but could not be found in memory.
</details>
"
      continue
    fi

    dec_details["$dec_id"]="$DECISION"

    # Stage linked requirements for discovery
    while IFS= read -r req_id; do
      [ -n "$req_id" ] && REQ_IDS_FROM_DIFF=$(printf "%s\n%s" "$REQ_IDS_FROM_DIFF" "$req_id")
    done < <(echo "$DECISION" | jq -r '.satisfies // [] | .[]')

  done <<< "$DECISION_IDS"
  
  # ----- Load Requirements -----
  ALL_REQ_IDS=$(printf "%s\n" "$REQ_IDS_FROM_DIFF" | grep -v '^$' | sort -u || true)

  while IFS= read -r req_id; do
    [ -z "$req_id" ] && continue
    [ "${seen_reqs[$req_id]+_}" ] && continue
    seen_reqs[$req_id]=1

    REQ=$(jq -rc --arg id "$req_id" \
      'select(.id == $id and .status == "active")' \
      "$REQUIREMENTS_FILE" | tail -1)

    [ -n "$REQ" ] && req_details["$req_id"]="$REQ"
  done <<< "$ALL_REQ_IDS"

  # ----- Build Relationship Maps -----
  plan_ids=()
  
  # 1. Map Reqs -> Plans
  for req_id in "${!req_details[@]}"; do
    pid=$(echo "${req_details[$req_id]}" | jq -r '.planId // ""')
    if [ -n "$pid" ]; then
      plan_ids+=("$pid")
      reqs_for_plan["$pid"]="${reqs_for_plan[$pid]:-} $req_id"
    else
      reqs_for_plan["_UNPLANNED_"]="${reqs_for_plan[_UNPLANNED_]:-} $req_id"
    fi
  done

  # 2. Add Explicit Plans
  while IFS= read -r pid; do
    [ -n "$pid" ] && plan_ids+=("$pid")
  done <<< "$PLAN_IDS_FROM_DIFF"

  UNIQUE_PLANS=$(printf '%s\n' "${plan_ids[@]:-}" | sort -u | grep -v '^$' || true)

  # 3. Map Decs -> Plans (via Satisfied Reqs)
  for dec_id in "${!dec_details[@]}"; do
    DEC="${dec_details[$dec_id]}"
    assigned=false
    
    while IFS= read -r satisfies_req; do
      [ -z "$satisfies_req" ] && continue
      for pid in $UNIQUE_PLANS; do
        if [[ " ${reqs_for_plan[$pid]:-} " =~ " $satisfies_req " ]]; then
          decs_for_plan["$pid"]="${decs_for_plan[$pid]:-} $dec_id"
          assigned=true
        fi
      done
    done < <(echo "$DEC" | jq -r '.satisfies // [] | .[]')
    
    if [ "$assigned" = false ]; then
      decs_for_plan["_UNPLANNED_"]="${decs_for_plan[_UNPLANNED_]:-} $dec_id"
    fi
  done

  # ----- Load Policies -----
  while IFS= read -r pol_id; do
    [ -z "$pol_id" ] && continue
    
    POL=$(jq -rc --arg id "$pol_id" \
      'select(.id == $id and .status == "active")' \
      "$POLICIES_FILE" | tail -1)

    if [ -z "$POL" ]; then
      policies_md+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=policies&id=$pol_id\"><code>$pol_id</code></a> — ⚠️ Unknown policy</summary>

> Could not be resolved from memory.
</details>
"
      continue
    fi

    POL_DESC=$(echo "$POL" | jq -r '.description // "—"')
    POL_RAT=$(echo "$POL" | jq -r '.rationale // "—"')
    POL_PLAN_ID=$(echo "$POL" | jq -r '.planId // ""')

    [ -n "$POL_PLAN_ID" ] && plan_ids+=("$POL_PLAN_ID")

    policies_md+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=policies&id=$pol_id\"><code>$pol_id</code></a> — 📜 Policy update</summary>

**Policy:** $POL_DESC

**Rationale:** $POL_RAT
</details>
"
  done <<< "$POLICY_IDS"
  
  # ----- Load Apps -----
  while IFS= read -r app_id; do
    [ -z "$app_id" ] && continue
    
    APP=$(jq -rc --arg id "$app_id" \
      'select(.id == $id and .status == "active")' \
      "$APPS_FILE" | tail -1)

    if [ -z "$APP" ]; then
      apps_md+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=apps&id=$app_id\"><code>$app_id</code></a> — ⚠️ Unknown app</summary>

> Could not be resolved from memory.
</details>
"
      continue
    fi

    APP_NAME=$(echo "$APP" | jq -r '.name // "—"')
    APP_TYPE=$(echo "$APP" | jq -r '.type // "—"')

    apps_md+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=apps&id=$app_id\"><code>$app_id</code></a> — 📦 App registry change</summary>

**Name:** $APP_NAME
**Type:** $APP_TYPE
</details>
"
  done <<< "$APP_IDS"

  # ----- Assemble Markdown Hierarchy -----
  HIERARCHY_MD=""
  
  for pid in $UNIQUE_PLANS "_UNPLANNED_"; do
    # Skip Unplanned area if empty
    if [ "$pid" = "_UNPLANNED_" ]; then
      if [ -z "${reqs_for_plan[_UNPLANNED_]:-}" ] && [ -z "${decs_for_plan[_UNPLANNED_]:-}" ]; then
        continue
      fi
      HIERARCHY_MD+="
---

### 🗂️ Unplanned Context
"
    else
      PLAN_FILE="$PLANS_DIR/${pid}.json"
      PLAN=""
      if [ -f "$PLAN_FILE" ]; then
        PLAN=$(jq -rc 'select(.status != "archived")' "$PLAN_FILE" 2>/dev/null || true)
      fi
      
      if [ -n "$PLAN" ]; then
        PLAN_FEAT=$(echo "$PLAN" | jq -r '.featureName // "—"')
        PLAN_GOAL=$(echo "$PLAN" | jq -r '.goal // "—"')
        PLAN_STATUS=$(echo "$PLAN" | jq -r '.status // "—"')
        HIERARCHY_MD+="
---

### 📋 Plan: [$PLAN_FEAT]($SPEX_BASE_URL/planner/$pid)
> $PLAN_GOAL

**Status:** \`$PLAN_STATUS\`

"
      else
        HIERARCHY_MD+="
---

### 📋 Plan: $pid (Unknown)

"
      fi
    fi

    # Print Requirements
    if [ -n "${reqs_for_plan[$pid]:-}" ]; then
      HIERARCHY_MD+="
#### 🟦 Requirements
"
      for req_id in $(echo "${reqs_for_plan[$pid]:-}" | tr ' ' '\n' | sort -u); do
        [ -z "$req_id" ] && continue
        REQ="${req_details[$req_id]:-}"
        [ -z "$REQ" ] && continue
        
        REQ_TYPE=$(echo "$REQ" | jq -r '.type // "?"')
        REQ_DESC=$(echo "$REQ" | jq -r '.description // "—"')
        REQ_AC=$(echo "$REQ"   | jq -r '.acceptanceCriteria // "—"')

        case "$REQ_TYPE" in
          FR)  TYPE_BADGE="🟦 FR"  ;;
          NFR) TYPE_BADGE="🟨 NFR" ;;
          CR)  TYPE_BADGE="🟥 CR"  ;;
          UR)  TYPE_BADGE="🟪 UR"  ;;
          *)   TYPE_BADGE="$REQ_TYPE" ;;
        esac

        HIERARCHY_MD+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=requirements&id=$req_id\"><code>$req_id</code></a> · $TYPE_BADGE — $REQ_DESC</summary>

**Acceptance criteria:** $REQ_AC
</details>
"
      done
    fi

    # Print Decisions
    if [ -n "${decs_for_plan[$pid]:-}" ]; then
      HIERARCHY_MD+="
#### 🧱 Decisions
"
      for dec_id in $(echo "${decs_for_plan[$pid]:-}" | tr ' ' '\n' | sort -u); do
        [ -z "$dec_id" ] && continue
        DEC="${dec_details[$dec_id]:-}"
        [ -z "$DEC" ] && continue
        
        PROPOSAL=$(echo "$DEC" | jq -r '.proposal // "No proposal"')
        RATIONALE=$(echo "$DEC" | jq -r '.rationale // "—"')
        ALTERNATIVES=$(echo "$DEC" | jq -r '.alternatives // "—"')
        CLASS=$(echo "$DEC" | jq -r '.decisionClass // "—"')
        SATISFIES=$(echo "$DEC" | jq -r '.satisfies // [] | join(", ")')

        case "$CLASS" in
          architectural) CLASS_BADGE="🏛️ architectural" ;;
          structural)    CLASS_BADGE="🧱 structural" ;;
          tactical)      CLASS_BADGE="⚙️ tactical" ;;
          *)             CLASS_BADGE="$CLASS" ;;
        esac

        HIERARCHY_MD+="
<details>
<summary><a href=\"$SPEX_BASE_URL/governance?tab=decisions&id=$dec_id\"><code>$dec_id</code></a> · $CLASS_BADGE — $PROPOSAL</summary>

**Rationale:** $RATIONALE

**Alternatives considered:** $ALTERNATIVES

**Satisfies:** $SATISFIES
</details>
"
      done
    fi
  done

  # Compose counts
  DEC_COUNT=${#dec_details[@]}
  REQ_COUNT=${#req_details[@]}
  POL_COUNT=$(echo "$POLICY_IDS" | grep -c . || echo 0)
  APP_COUNT=$(echo "$APP_IDS" | grep -c . || echo 0)
  EXPLICIT_PLAN_COUNT=$(echo "$UNIQUE_PLANS" | grep -c . || echo 0)

  COUNTS_STR="**$DEC_COUNT decision(s)** · **$REQ_COUNT requirement(s)**"
  [ "$EXPLICIT_PLAN_COUNT" -gt 0 ] && COUNTS_STR+=" · **$EXPLICIT_PLAN_COUNT plan(s)**"
  [ "$POL_COUNT" -gt 0 ] && COUNTS_STR+=" · **$POL_COUNT policy(s)**"
  [ "$APP_COUNT" -gt 0 ] && COUNTS_STR+=" · **$APP_COUNT app(s)**"

  # Final report
  cat <<COMMENT
$MARKER
## 🔍 Spex Report

> $COUNTS_STR synced to this PR

$HIERARCHY_MD

$(if [ -n "$policies_md" ]; then echo -e "---\n\n### Policies\n\n$policies_md"; fi)

$(if [ -n "$apps_md" ]; then echo -e "---\n\n### Apps\n\n$apps_md"; fi)

---

<sub>Generated by [Spex PR Bot](.github/workflows/spex-pr-bot.yml)</sub>
COMMENT
}

COMMENT_BODY=$(build_comment)

# ── 3. Post or update comment (idempotent via HTML marker) ───────────
EXISTING_ID=$(curl -s \
  -H "Authorization: Bearer $GH_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  "https://api.github.com/repos/$REPO/issues/$PR_NUMBER/comments?per_page=100" \
  | jq -r --arg marker "$MARKER" \
    '.[] | select(.body | contains($marker)) | .id' \
  | head -1)

BODY_JSON=$(echo "$COMMENT_BODY" | jq -Rs '{body: .}')

if [ -n "$EXISTING_ID" ]; then
  curl -s -X PATCH \
    -H "Authorization: Bearer $GH_TOKEN" \
    -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/$REPO/issues/comments/$EXISTING_ID" \
    -d "$BODY_JSON" > /dev/null
  echo "Updated existing Spex comment ($EXISTING_ID)."
else
  curl -s -X POST \
    -H "Authorization: Bearer $GH_TOKEN" \
    -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/$REPO/issues/$PR_NUMBER/comments" \
    -d "$BODY_JSON" > /dev/null
  echo "Posted new Spex comment."
fi
