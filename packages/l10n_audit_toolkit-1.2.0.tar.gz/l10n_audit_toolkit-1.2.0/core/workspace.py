from __future__ import annotations

import io
import json
import os
import shutil
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any
from urllib.parse import urlparse
from urllib.request import urlopen
from zipfile import ZipFile

from core.audit_runtime import _load_project_profiles, detect_tools_dir
from core.profile_detection import LOW_CONFIDENCE_THRESHOLD, autodetect_profile

WORKSPACE_DIRNAME = ".l10n-audit"
WORKSPACE_CONFIG = "config.json"
WORKSPACE_VERSION = "version.json"
WORKSPACE_GLOSSARY = "glossary.json"
WORKSPACE_TEMPLATE_DIR = "toolkit-template"
CURRENT_CONFIG_VERSION = 1


def toolkit_version() -> str:
    try:
        return metadata.version("l10n-audit-toolkit")
    except metadata.PackageNotFoundError:
        return "1.2.0"


def workspace_dir(project_root: Path) -> Path:
    return project_root / WORKSPACE_DIRNAME


def workspace_config_path(project_root: Path) -> Path:
    return workspace_dir(project_root) / WORKSPACE_CONFIG


def workspace_version_path(project_root: Path) -> Path:
    return workspace_dir(project_root) / WORKSPACE_VERSION


def workspace_glossary_path(project_root: Path) -> Path:
    return workspace_dir(project_root) / WORKSPACE_GLOSSARY


def workspace_template_dir(project_root: Path) -> Path:
    return workspace_dir(project_root) / WORKSPACE_TEMPLATE_DIR


def find_project_root(start: Path) -> Path:
    current = start.resolve()
    if current.is_file():
        current = current.parent
    markers = (
        ".git",
        "pubspec.yaml",
        "artisan",
        "package.json",
        "assets/language",
        "resources/lang",
        "lib",
        "src",
    )
    for candidate in (current, *current.parents):
        if any((candidate / marker).exists() for marker in markers):
            return candidate
    return current


def detect_project_profile(project_root: Path, tools_dir: Path | None = None) -> tuple[str, dict[str, Any]]:
    detected_tools_dir = tools_dir or detect_tools_dir(__file__)
    profiles = _load_project_profiles(detected_tools_dir / "config")
    best, ranked = autodetect_profile(project_root, None, profiles)
    details = {
        "score": best.score,
        "reasons": list(best.reasons),
        "candidates": [
            {"profile": item.profile_name, "score": item.score, "reasons": list(item.reasons[:4])}
            for item in ranked[:5]
        ],
    }
    if best.score < LOW_CONFIDENCE_THRESHOLD:
        return "unknown", details
    return best.profile_name, details


def default_workspace_config(project_root: Path, profile_name: str) -> dict[str, Any]:
    return {
        "config_version": CURRENT_CONFIG_VERSION,
        "project_profile": profile_name,
        "source_locale": "en",
        "target_locales": ["ar"],
        "project_root": "..",
        "glossary_file": WORKSPACE_GLOSSARY,
        "results_dir": "Results",
        "languagetool_dir": "vendor",
        "ar_locale_qc": {
            "enable_exclamation_style": True,
            "enable_long_ui_string": True,
            "enable_similar_phrase_variation": True,
            "enable_suspicious_literal_translation": True,
        },
        "icu_message_audit": {
            "enabled": True,
            "strict_branch_matching": True,
            "enable_selectordinal": True,
        },
    }


def glossary_template_payload() -> dict[str, Any]:
    return {
        "meta": {
            "name": "Project Glossary Example",
            "version": "1.0",
            "status": "example",
            "source_language": "en",
            "target_language": "ar",
            "description": "Small neutral glossary example that shows the expected structure. Replace these entries with your project's approved terminology.",
        },
        "rules": {
            "forbidden_terms": [
                {"forbidden_ar": "ملف تعريفي", "use_instead": "ملف شخصي"},
            ]
        },
        "terms": [
            {
                "term_en": "Profile",
                "approved_ar": "ملف شخصي",
                "forbidden_ar": ["ملف تعريفي"],
                "category": "generic_ui",
                "definition": "A neutral example of a preferred Arabic UI term.",
            },
            {
                "term_en": "Save",
                "approved_ar": "حفظ",
                "forbidden_ar": ["خزن"],
                "category": "generic_ui",
                "definition": "A neutral example for a common action label.",
            },
        ],
    }


def version_payload(channel: str = "stable") -> dict[str, Any]:
    return {
        "workspace_version": CURRENT_CONFIG_VERSION,
        "toolkit_version": toolkit_version(),
        "channel": channel,
        "updated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    }


def default_repository_url() -> str:
    return str(os.environ.get("L10N_AUDIT_REPOSITORY", "")).strip()


def resolve_archive_url(repo: str, channel: str) -> str:
    repo = repo.strip()
    if not repo:
        raise ValueError("A repository URL is required for --from-github. Pass --repo or set L10N_AUDIT_REPOSITORY.")
    if repo.endswith(".zip") or repo.startswith("file://"):
        return repo
    parsed = urlparse(repo)
    if "github.com" not in parsed.netloc:
        raise ValueError("--repo must be a GitHub repository URL or a direct .zip archive URL.")
    clean = repo.rstrip("/")
    if clean.endswith(".git"):
        clean = clean[:-4]
    ref = "main" if channel == "main" else f"v{toolkit_version()}"
    return f"{clean}/archive/refs/{'heads' if channel == 'main' else 'tags'}/{ref}.zip"


def sync_templates_from_archive(project_root: Path, archive_url: str, channel: str) -> dict[str, Any]:
    target_dir = workspace_template_dir(project_root)
    if target_dir.exists():
        shutil.rmtree(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    with urlopen(archive_url) as response:
        archive_bytes = response.read()

    extracted_files = 0
    with ZipFile(io.BytesIO(archive_bytes)) as archive:
        for member in archive.infolist():
            parts = Path(member.filename).parts
            if not parts or member.is_dir():
                continue
            relative_parts = parts[1:] if len(parts) > 1 else parts
            if not relative_parts:
                continue
            destination = target_dir.joinpath(*relative_parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)
            extracted_files += 1

    return {
        "archive_url": archive_url,
        "channel": channel,
        "template_dir": target_dir,
        "extracted_files": extracted_files,
    }


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def init_workspace(
    project_root: Path,
    *,
    force: bool = False,
    channel: str = "stable",
    from_github: bool = False,
    repo: str | None = None,
) -> dict[str, Any]:
    workspace = workspace_dir(project_root)
    workspace.mkdir(parents=True, exist_ok=True)
    profile_name, detection = detect_project_profile(project_root)
    if profile_name == "unknown":
        profile_name = "auto"

    config_path = workspace_config_path(project_root)
    if force or not config_path.exists():
        write_json(config_path, default_workspace_config(project_root, profile_name))

    glossary_path = workspace_glossary_path(project_root)
    if force or not glossary_path.exists():
        write_json(glossary_path, glossary_template_payload())

    results_dir = workspace / "Results"
    results_dir.mkdir(parents=True, exist_ok=True)
    sync_info: dict[str, Any] | None = None
    if from_github:
        archive_url = resolve_archive_url(repo or default_repository_url(), channel)
        sync_info = sync_templates_from_archive(project_root, archive_url, channel)
    version = version_payload(channel=channel)
    if sync_info:
        version["github_sync"] = {
            "archive_url": sync_info["archive_url"],
            "template_dir": str(sync_info["template_dir"]),
            "extracted_files": sync_info["extracted_files"],
        }
    write_json(workspace_version_path(project_root), version)

    result = {
        "project_root": project_root,
        "workspace_dir": workspace,
        "config_path": config_path,
        "glossary_path": glossary_path,
        "results_dir": results_dir,
        "profile_name": profile_name,
        "detection": detection,
    }
    if sync_info:
        result["github_sync"] = sync_info
    return result


def update_workspace(
    project_root: Path,
    *,
    channel: str = "stable",
    from_github: bool = False,
    repo: str | None = None,
) -> dict[str, Any]:
    workspace = workspace_dir(project_root)
    if not workspace.exists():
        return init_workspace(project_root, force=False, channel=channel, from_github=from_github, repo=repo)

    config_path = workspace_config_path(project_root)
    if config_path.exists():
        current = read_json(config_path)
    else:
        current = {}
    detected_profile, _detection = detect_project_profile(project_root)
    defaults = default_workspace_config(project_root, detected_profile if detected_profile != "unknown" else str(current.get("project_profile") or "auto"))
    merged = dict(defaults)
    merged.update(current)
    merged["config_version"] = CURRENT_CONFIG_VERSION
    backup_path = config_path.with_suffix(".backup.json")
    if config_path.exists():
        shutil.copy2(config_path, backup_path)
    write_json(config_path, merged)

    glossary_path = workspace_glossary_path(project_root)
    if not glossary_path.exists():
        write_json(glossary_path, glossary_template_payload())

    sync_info: dict[str, Any] | None = None
    if from_github:
        archive_url = resolve_archive_url(repo or default_repository_url(), channel)
        sync_info = sync_templates_from_archive(project_root, archive_url, channel)
    version = version_payload(channel=channel)
    if sync_info:
        version["github_sync"] = {
            "archive_url": sync_info["archive_url"],
            "template_dir": str(sync_info["template_dir"]),
            "extracted_files": sync_info["extracted_files"],
        }
    write_json(workspace_version_path(project_root), version)
    result = {
        "project_root": project_root,
        "workspace_dir": workspace,
        "config_path": config_path,
        "backup_path": backup_path if backup_path.exists() else None,
        "glossary_path": glossary_path,
    }
    if sync_info:
        result["github_sync"] = sync_info
    return result


def workspace_status(project_root: Path) -> dict[str, Any]:
    workspace = workspace_dir(project_root)
    config_path = workspace_config_path(project_root)
    version_path = workspace_version_path(project_root)
    glossary_path = workspace_glossary_path(project_root)
    profile_name, detection = detect_project_profile(project_root)
    return {
        "project_root": project_root,
        "workspace_dir": workspace,
        "workspace_exists": workspace.exists(),
        "config_exists": config_path.exists(),
        "version_exists": version_path.exists(),
        "glossary_exists": glossary_path.exists(),
        "detected_profile": profile_name,
        "detection": detection,
        "config_path": config_path,
        "version_path": version_path,
        "glossary_path": glossary_path,
    }
