import copy
import logging
import sys
from pathlib import Path
from importlib import resources
from timeit import default_timer as timer
from shutil import copyfile
import warnings

import click
import numpy as np
import pandas as pd

from . import cluster
from . import db
from . import config
from . import plot



@click.group(context_settings=dict(help_option_names=['-h', '--help']))
def cli():
    pass


@cli.command(
    'run',
    context_settings=dict(
        ignore_unknown_options=True,
        allow_extra_args=True,
    )
)
@click.option("-c", "--config", "config_file", type=click.Path(exists=True), required=True, help="YAML config")
@click.option("-v", "--verbose", count=True, help="Print debug info.")
@click.option(
    "--evt-out/--no-evt-out",
    default=True,
    show_default=True,
    help="Write a copy of the input EVT parquet file to the output directory.",
)
@click.pass_context
def run_cmd(ctx, config_file, verbose, evt_out):
    """
    Find bead location and generate filtering parameters.
    """
    # Parse unknown options as config jinja2 template data
    i = 0
    template_data = {}
    while i < len(ctx.args) - 1:
        if ctx.args[i].startswith("--") and not ctx.args[i+1].startswith("--"):
            template_var = ctx.args[i][2:]
            # Replace dashes with underscores for python variable compatibility
            template_var = template_var.replace("-", "_")
            template_data[template_var] = ctx.args[i+1]
            i += 2
        else:
            i += 1

    # Configure logging
    if verbose == 0:
        loglevel = logging.INFO
    else:
        loglevel = logging.DEBUG
    logger = logging.getLogger()
    logger.setLevel(loglevel)
    logging_ch = logging.StreamHandler()
    logging_ch.setFormatter(logging.Formatter(fmt="%(asctime)s: %(levelname)s: %(message)s"))
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        logger.addHandler(logging_ch)

    # Print version
    from . import __version__
    logger.info("version = %s", __version__)

    # Read config
    if template_data:
        logger.info("using config template arguments: %s", template_data)
    logger.info("config file = %s", config_file)
    try:
        cconf = config.ClusterConfig.from_config_file(config_file, template_data=template_data)
    except Exception as e:
        logger.error(f"error reading config file: {e}")
        raise click.ClickException(f"error reading config file: {e}") from e
    logger.info("loaded config data")

    logger.info(cconf)

    evt_df = pd.read_parquet(cconf.evt_file)
    if len(evt_df) == 0:
        raise click.ClickException("no EVT data for bead finding")
    if "date" not in evt_df.columns:
        evt_df = evt_df.reset_index()  # maybe it's the index, don't drop
        if "date" not in evt_df.columns:
            raise click.ClickException("no date column in EVT dataframe")
    logger.info("%d particles in %s", len(evt_df), cconf.evt_file)

    # Apply any date filters
    if cconf.start_date or cconf.end_date:
        date_selector = np.full(len(evt_df), True, dtype=bool)
        logger.info("apply date filter, %s to %s", cconf.start_date, cconf.end_date)
        if cconf.start_date:
            date_selector = evt_df["date"] >= cconf.start_date
            logger.info("%s after start_date filter", np.sum(date_selector))
        if cconf.end_date:
            date_selector = date_selector & (evt_df["date"] <= cconf.end_date)
            logger.info("%s after end_date filter", np.sum(date_selector))
        evt_df = evt_df[date_selector]
        logger.info(
            "%s rows between %s and %s after date filter", len(evt_df), evt_df["date"].min(), evt_df["date"].max()
        )


    # Create output paths
    out_dir = Path(cconf.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    evt_copy_path = out_dir / f"{cconf.name}.input-evt.parquet"
    summary1_out_path = out_dir / f"{cconf.name}.summary.round1.parquet"
    summary2_out_path = out_dir / f"{cconf.name}.summary.round2.parquet"
    filter_params1_out_path = out_dir / f"{cconf.name}.filter_params.round1.parquet"
    filter_params2_out_path = out_dir / f"{cconf.name}.filter_params.round2.parquet"
    # results1_out_path = out_dir / f"{cconf.name}.results.round1.joblib"
    # results2_out_path = out_dir / f"{cconf.name}.results.round2.joblib"
    peaks1_plot_path = out_dir / f"{cconf.name}.peaks-properties.round1.png"
    peaks2_plot_path = out_dir / f"{cconf.name}.peaks-properties.round2.png"
    coords1_plot_path = out_dir / f"{cconf.name}.coords.round1.png"
    coords2_plot_path = out_dir / f"{cconf.name}.coords.round2.png"
    good_coords1_plot_path = out_dir / f"{cconf.name}.coords-good.round1.png"
    good_coords2_plot_path = out_dir / f"{cconf.name}.coords-good.round2.png"
    new_db_path = out_dir / f"{cconf.name}.db"

    # ------------------------------------------------------------------------ #
    # Round 1
    # ------------------------------------------------------------------------ #
    t0 = timer()

    logging.info("Round 1 starting")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=FutureWarning)
        results1 = cluster.cluster_cruise(evt_df, cconf, max_workers=cconf.workers)
    summary1 = results1.summary()
    try:
        filter_params1 = results1.create_filter_params(cconf)
    except ValueError as e:
        logger.error(e)
        logger.error("No good round 1 bead locations found, will skip round 2")
        filter_params1 = None

    # Save results
    logger.info("Saving round 1 results")
    # joblib.dump(results1, results1_out_path)
    if evt_out:
        copyfile(cconf.evt_file, evt_copy_path)
    else:
        logger.info("Skipping input EVT parquet output")
    summary1.to_parquet(summary1_out_path)
    if filter_params1 is not None:
        filter_params1.to_parquet(filter_params1_out_path)
    # Save plots
    logger.info("Saving round 1 plots")
    plot.plot_peak_props(
        results1,
        cconf,
    ).savefig(peaks1_plot_path)
    plot.plot_bead_coords(
        results1, cconf,
    ).savefig(coords1_plot_path)
    plot.plot_bead_coords(
        results1, cconf,
        only_good=True
    ).savefig(good_coords1_plot_path)

    t1 = timer()
    logger.info("Round 1 completed in %s sec", t1 - t0)

    if filter_params1 is None:
        logger.info("Exiting without round 2")
        return

    # Move filtering lines up to capture more OPP
    filter_params_for_round2 = filter_params1.copy()
    filter_params_for_round2["offset_small_D1"] += cconf.filtering_offset
    filter_params_for_round2["offset_small_D2"] += cconf.filtering_offset
    filter_params_for_round2["offset_large_D1"] += cconf.filtering_offset
    filter_params_for_round2["offset_large_D2"] += cconf.filtering_offset

    # ------------------------------------------------------------------------ #
    # Round 2
    # ------------------------------------------------------------------------ #
    cconf2 = copy.deepcopy(cconf)
    cconf2.filter_params_by_date = filter_params_for_round2

    logger.info("Round 2 starting")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=FutureWarning)
        results2 = cluster.cluster_cruise(evt_df, cconf2, max_workers=cconf2.workers)
    summary2 = results2.summary()
    filter_params2 = results2.create_filter_params(cconf)

    # Save results
    logger.info("Saving round 2 results")
    # joblib.dump(results2, results2_out_path)
    summary2.to_parquet(summary2_out_path)
    filter_params2.to_parquet(filter_params2_out_path)
    # Save plot
    logger.info("Saving round 2 plots")
    plot.plot_peak_props(
        results2,
        cconf,
    ).savefig(peaks2_plot_path)
    plot.plot_bead_coords(
        results2, cconf,
    ).savefig(coords2_plot_path)
    plot.plot_bead_coords(
        results2, cconf,
        only_good=True
    ).savefig(good_coords2_plot_path)
    # Save new seaflowpy/popcycle DB
    logger.info("Saving new database file")
    db.save_metadata(new_db_path, cruise=cconf.name, serial=cconf.serial)
    db.save_filter_params(new_db_path, results2.create_filter_params(cconf))
    if cconf.db_file:
        db.copy_gating(cconf.db_file, new_db_path)
        db.copy_sfl(cconf.db_file, new_db_path)
    
    # Export filter params
    results2.save_filter_params_to_file(
        params_file=out_dir / f"{cconf.name}.filter_params.filter.tsv",
        plan_file=out_dir / f"{cconf.name}.filter_params.filter_plan.tsv"
    )

    t2 = timer()
    logger.info("Round 2 completed in %s sec", t2 - t1)

    logger.info("Bead finding completed in %s sec", t2 - t0)


@cli.command("config")
def config_cmd():
    config = resources.files("beadclust").joinpath("data/config-template.yml").read_text(encoding="utf-8")
    sys.stdout.write(config)


@cli.command("version")
def version_cmd():
    from . import __version__
    click.echo(__version__)
