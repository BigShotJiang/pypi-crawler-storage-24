import logging
from typing import Any, Literal, Optional, TypeAlias

from matplotlib.artist import Artist
from matplotlib.colors import to_rgba
import matplotlib.pyplot as plt
import mplcursors
import numpy as np
import pandas as pd
from scipy.spatial import ConvexHull

from beadclust import cluster
from beadclust.filter import get_linear_pe_chl, make_hist
from beadclust.particleops import log_particles, unlog_particles

logger = logging.getLogger(__name__)


Channel: TypeAlias = Literal["fsc_small", "pe", "chl_small", "D1", "D2"]
AnnotateType: TypeAlias = list[Channel] | Channel | None

def plot_bead_coords(
    results: cluster.ClusterResultCollection,
    conf: cluster.ClusterConfig,
    hour: str = "",
    only_good: bool = False,
    start_dt: pd.Timestamp | str | None = None,
    end_dt: pd.Timestamp | str | None = None,
    annotate: AnnotateType = None,  # which row(s) to annotate with hoverover
):
    """Plot bead coordinate time series.

    Uses conf.spread_cutoff, conf.pe_chl_frac_med_cutoff,
    conf.pe_diff_cutoff, conf.min_fsc, conf.min_pe,
    conf.min_chl, and conf.db_filter_params.
    """
    # Fix up list of rows to annotate
    if annotate is None:
        annotate = []
    if isinstance(annotate, str):
        annotate = [annotate]
    else:
        annotate = list(annotate)

    coords = results.summary()
    coords = cluster.ClusterResultCollection.filter_summary(
        coords,
        conf,
        mark_only=True
    )

    # Adjust plot to fit within start and end datetimes
    if start_dt is None:
        if conf.dates is not None and not conf.dates.empty:
            start_dt = conf.dates["date"].min()
        else:
            start_dt = coords.index.min()
    else:
        start_dt = pd.to_datetime(start_dt)
        if start_dt > coords.index.min():
            logger.info("Filtering bead coords to start at %s", start_dt)
        elif start_dt < coords.index.min():
            logger.info("Requested start_dt %s is before earliest bead coord %s",
                        start_dt, coords.index.min())
        coords = coords[coords.index >= start_dt]
    if end_dt is None:
        if conf.dates is not None and not conf.dates.empty:
            end_dt = conf.dates["date"].max()
        else:
            end_dt = coords.index.max()
    else:
        end_dt = pd.to_datetime(end_dt)
        if end_dt < coords.index.max():
            logger.info("Filtering bead coords to end at %s", end_dt)
        elif end_dt > coords.index.max():
            logger.info("Requested end_dt %s is after latest bead coord %s",
                        end_dt, coords.index.max())
        coords = coords[coords.index <= end_dt]

    # Save full coords before optional only_good filter so failure/missing
    # markers always reflect all attempted timepoints.
    coords_all = coords
    if only_good:
        # Only keep "good" timepoints
        coords = coords[coords["good"]]

    # Orange markers: timepoints in results missing pe peak or any cluster
    failed_dates = coords_all[
        ~coords_all["flag_peak_pe"] | ~coords_all["flag_clusters_present"]
    ].index
    # Black markers: time bins from conf.dates not present in results at all
    missing_dates = pd.DatetimeIndex([])
    if conf.dates is not None and not conf.dates.empty:
        all_bins = pd.DatetimeIndex(
            conf.dates["date"].dt.floor(conf.time_res).unique()
        )
        missing_dates = all_bins.difference(coords_all.index)

    fig, axs = plt.subplots(8, 1, sharex=True, layout="constrained")
    fig.set_size_inches(6, 7)
    fig.suptitle("Bead locations")

    artists = _plot_bead_coords_row(
        axs[0],
        coords,
        "fsc_small",
        show_spread=True,
        hour=hour,
        y_min=conf.min_fsc or None,
        filter_params=conf.db_filter_params,
        failed_dates=failed_dates,
        missing_dates=missing_dates,
    )
    if "fsc_small" in annotate:
        logger.info("Applying mplcursors to fsc_small row")
        mplcursors.cursor(artists, hover=True).connect("add", mplcursor_datetime_formatter)

    artists = _plot_bead_coords_row(
        axs[1], coords, "pe", show_spread=True, hour=hour, y_min=conf.min_pe or None,
        failed_dates=failed_dates, missing_dates=missing_dates,
    )
    if "pe" in annotate:
        logger.info("Applying mplcursors to pe row")
        mplcursors.cursor(artists, hover=True).connect("add", mplcursor_datetime_formatter)

    artists = _plot_bead_coords_row(
        axs[2], coords, "chl_small", show_spread=True, hour=hour, y_min=conf.min_chl or None,
        failed_dates=failed_dates, missing_dates=missing_dates,
    )

    _plot_pe_peak_row(axs[3], coords, hour=hour, y_min=conf.min_pe or None)

    artists = _plot_bead_coords_row(
        axs[4],
        coords,
        "D1",
        hour=hour,
        show_spread=False,
        y_min=None,
        filter_params=conf.db_filter_params,
        failed_dates=failed_dates,
        missing_dates=missing_dates,
    )
    if "D1" in annotate:
        logger.info("Applying mplcursors to D1 row")
        mplcursors.cursor(artists, hover=True).connect("add", mplcursor_datetime_formatter)

    artists = _plot_bead_coords_row(
        axs[5],
        coords,
        "D2",
        hour=hour,
        show_spread=False,
        y_min=None,
        filter_params=conf.db_filter_params,
        failed_dates=failed_dates,
        missing_dates=missing_dates,
    )
    if "D2" in annotate:
        logger.info("Applying mplcursors to D2 row")
        mplcursors.cursor(artists, hover=True).connect("add", mplcursor_datetime_formatter)

    axs[6].plot(
        coords.index.to_numpy(),
        coords["peak_pe_chl_ratio_linear"],
        markersize=5,
        marker=".",
        linestyle="None",
        color="tab:purple"
    )
    if hour:
        try:
            coords_hour_row = coords.loc[hour]
        except KeyError:
            pass
        else:
            _highlight_hour(axs[6], pd.to_datetime(hour), coords_hour_row["peak_pe_chl_ratio_linear"])
    axs[6].set_ylabel("pe/chl")

    axs[7].plot(
        coords.index.to_numpy(),
        coords["peak_pe_med"] - coords["pe_2Q"],
        markersize=5,
        marker=".",
        linestyle="None",
        color="tab:purple"
    )
    if hour:
        try:
            coords_hour_row = coords.loc[hour]
        except KeyError:
            pass
        else:
            _highlight_hour(axs[7], pd.to_datetime(hour), coords_hour_row["peak_pe_med"] - coords_hour_row["pe_2Q"])
    axs[7].set_ylabel("pe diff (p-c)")
    axs[7].xaxis.set_tick_params(rotation=45)

    # Set x-axis limits on one axis to be shared by all
    axs[0].set_xlim(*_xlim_with_margin(start_dt, end_dt))

    return fig


def _plot_bead_coords_row(
    ax,
    coords: pd.DataFrame,
    col_prefix: str,
    show_spread: bool = True,
    y_min: float | None = 0,
    hour: str = "",
    filter_params: Optional[pd.DataFrame] = None,
    failed_dates: pd.DatetimeIndex | None = None,
    missing_dates: pd.DatetimeIndex | None = None,
) -> list[Artist]:
    if show_spread:
        yerr = coords[f"{col_prefix}_range"].to_numpy() / 2
    else:
        yerr = None

    # Create colors for each point and error bar. Blue for good, pink for high
    # spread in fsc_small or no clusters for all of fsc, D1, and D2.
    # Lower alpha if no pe peak was detected or pe peak pe/chl ratio is too low.
    colors = (
        to_rgba("tab:blue"),
        to_rgba("tab:cyan"),
        to_rgba("tab:pink"),
        to_rgba("tab:red")
    )
    bool_idx = [
        # Good clusters, good PE peak
        coords["flag_clusters_present"] & coords["flag_fsc_cluster_spread"] & coords["flag_peak_pe"] & coords["flag_pe_chl"] & coords["flag_pe_diff"],
        # Good clusters, bad or no PE peak
        coords["flag_clusters_present"] & coords["flag_fsc_cluster_spread"] & ((~coords["flag_peak_pe"]) | (~coords["flag_pe_chl"]) | (~coords["flag_pe_diff"])),
        # Bad clusters, good PE peak
        ((~coords["flag_clusters_present"]) | (~coords["flag_fsc_cluster_spread"])) & coords["flag_peak_pe"] & coords["flag_pe_chl"],
        # Bad clusters, bad or no PE peak
        ((~coords["flag_clusters_present"]) | (~coords["flag_fsc_cluster_spread"]) | (~coords["flag_pe_diff"])) & ((~coords["flag_peak_pe"]) | (~coords["flag_pe_chl"]))
    ]
    artists = []
    for i, _ in enumerate(colors):
        if yerr is not None:
            artists.append(ax.errorbar(
                coords[bool_idx[i]].index.to_numpy(),
                coords[bool_idx[i]][f"{col_prefix}_2Q"].to_numpy(),
                yerr=yerr[bool_idx[i]],
                elinewidth=0.5,
                markersize=5,
                marker=".",
                linestyle="None",
                c=colors[i],
            ))
        else:
            artists.extend(ax.plot(
                coords[bool_idx[i]].index.to_numpy(),
                coords[bool_idx[i]][f"{col_prefix}_2Q"].to_numpy(),
                markersize=5,
                marker=".",
                linestyle="None",
                c=colors[i],
            ))

    # Highlight one time point
    if hour:
        try:
            hour_row = coords.loc[hour]
        except KeyError:
            hour_row = None
        else:
            _highlight_hour(ax, pd.to_datetime(hour), hour_row[f"{col_prefix}_2Q"])

    # Draw traditional filter parameter line
    # Use 50% quantile since we're not showing filtering cutoffs, we're showing
    # db bead positions.
    if filter_params is not None:
        filter_params = filter_params[filter_params["quantile"] == 50]
        filter_params = filter_params.reset_index(drop=True)  # to make sure loc indexing works with integers
        if len(filter_params) > 1:
            for i in range(len(filter_params)-1):
                # Plot all filter params settings except the last one
                ax.plot(
                    [pd.to_datetime(str(filter_params.loc[i, "date"])), pd.to_datetime(str(filter_params.loc[i+1, "date"]))],
                    [filter_params.loc[i, f"beads_{col_prefix}"], filter_params.loc[i, f"beads_{col_prefix}"]],
                    alpha=0.5,
                    color="tab:gray",
                    linestyle="--",
                )
            i += 1  # set to the last set of parameters' index
        else:
            i = 0  # set to the only set of parameters' index
        # Now plot the last or only set of parameters to the end of the plot
        ax.plot(
            [pd.to_datetime(str(filter_params.loc[i, "date"])), pd.to_datetime(coords.index.max())],
            [filter_params.loc[i, f"beads_{col_prefix}"], filter_params.loc[i, f"beads_{col_prefix}"]],
            alpha=0.5,
            color="tab:gray",
            linestyle="--",
            )

    if y_min is not None:
        ax.set_ylim(y_min, 2**16)

    y_bottom = ax.get_ylim()[0]
    # Orange: timepoints in results missing a pe peak or any cluster output
    if failed_dates is not None and len(failed_dates) > 0:
        ax.plot(
            failed_dates,
            np.repeat(y_bottom, len(failed_dates)),
            marker=".",
            markersize=5,
            color="orange",
            alpha=0.5,
        )
    # Black: time bins from conf.dates not present in results at all
    if missing_dates is not None and len(missing_dates) > 0:
        ax.plot(
            missing_dates,
            np.repeat(y_bottom, len(missing_dates)),
            marker=".",
            markersize=5,
            color="black",
            alpha=0.5,
        )

    ax.set_ylabel(col_prefix)

    return artists


def mplcursor_datetime_formatter(sel):
    """Annotated text only shows date by default. Add time here."""
    x_date = pd.to_datetime(sel.target[0], unit='D', origin='unix')
    date_str = x_date.strftime("%Y-%m-%d %H:%M:%S")
    sel.annotation.set(text=f"x: {date_str}\ny: {sel.target[1]:.2f}")


def _plot_pe_peak_row(
    ax,
    coords,
    hour: str | None = None,
    y_min: float | None = 0,
):
    ax.plot(
        coords.index,
        coords["peak_pe_location"],
        marker=".",
        markersize=5,
        alpha=0.5,
        color="tab:purple",
        linestyle="None",
    )
    if hour:
        try:
            coords_hour_row = coords.loc[hour]
        except KeyError:
            pass
        else:
            _highlight_hour(ax, pd.to_datetime(hour), coords_hour_row["peak_pe_location"])
    if y_min is not None:
        ax.set_ylim(y_min, 2**16)
    ax.set_ylabel("pe peaks")


def _plot_summary_row_basic(ax, summary, good, hour, col, ylab=None, title=None):
    # Plot all peak points
    ax.plot(
        summary.index, summary[col],
        marker=".", markersize=5, alpha=0.5, color="tab:purple", linestyle="None"
    )
    # Plot good peak points
    ax.plot(
        good.index, good[col],
        marker=".", markersize=5, alpha=0.75, color="tab:blue", linestyle="None"
    )
    # Highlight hour
    if hour:
        _highlight_hour(ax, pd.to_datetime(hour), summary.loc[hour, col])
    if ylab:
        ax.set_ylabel(ylab)
    if title:
        ax.set_title(title)


def plot_peak_props(
    results: cluster.ClusterResultCollection,
    conf: cluster.ClusterConfig,
    hour: str = "",
):
    """Plot peak properties time series.

    Uses conf.spread_cutoff and conf.pe_diff_cutoff.
    """
    summary = results.summary()
    good = cluster.ClusterResultCollection.filter_summary(
        summary, conf
    )

    fig, axs = plt.subplots(9, 1, sharex=True, layout="constrained")
    fig.set_size_inches(6, 10)
    fig.suptitle("peak properties")

    rows = [
        {"col": "peak_pe_location", "ylab": "peak pe"},
        {"col": "peak_fsc_small_med", "ylab": "fsc med"},
        {"col": "peak_pe_med", "ylab": "pe med"},
        {"col": "peak_chl_small_med", "ylab": "chl med"},
        {"col": "peak_pe_chl_ratio_linear", "ylab": "linear pe/chl"},
        {"col": "peak_height", "ylab": "peak height"},
        {"col": "peak_width", "ylab": "peak width"},
        {"col": "peak_count", "ylab": "peak count"},
        {"col": "peak_idx", "ylab": "peak idx"}
    ]
    for i, row in enumerate(rows):
        _plot_summary_row_basic(axs[i], summary, good, hour, row["col"], row["ylab"])
    if conf.dates is not None and not conf.dates.empty:
        axs[0].set_xlim(*_xlim_with_margin(conf.dates["date"].min(), conf.dates["date"].max()))
    axs[-1].xaxis.set_tick_params(rotation=45)

    return fig


def plot_cluster_spreads(
    results: cluster.ClusterResultCollection,
    conf: cluster.ClusterConfig,
    hour: str = "",
):
    """Plot bead cluster spread time series.

    Uses conf.spread_cutoff and conf.pe_diff_cutoff.
    """
    summary = results.summary()
    good = cluster.ClusterResultCollection.filter_summary(
        summary, conf
    )
    fig, axs = plt.subplots(4, 1, sharex=True, layout="constrained")
    fig.set_size_inches(6, 4)
    fig.suptitle("Bead cluster spreads")
    rows = [
        {"col": "fsc_small_range", "ylab": "fsc_small"},
        {"col": "pe_range", "ylab": "pe"},
        {"col": "D1_range", "ylab": "D1"},
        {"col": "D2_range", "ylab": "D2"}
    ]
    for i, row in enumerate(rows):
        _plot_summary_row_basic(axs[i], summary, good, hour, row["col"], row["ylab"])
    if conf.dates is not None and not conf.dates.empty:
        axs[0].set_xlim(*_xlim_with_margin(conf.dates["date"].min(), conf.dates["date"].max()))
    axs[-1].xaxis.set_tick_params(rotation=45)


def plot_timings(
    results: cluster.ClusterResultCollection,
    conf: cluster.ClusterConfig,
    hour: str = "",
):
    """Plot per-timepoint timing breakdown.

    Uses conf.spread_cutoff and conf.pe_diff_cutoff.
    """
    summary = results.summary()
    good = cluster.ClusterResultCollection.filter_summary(
        summary, conf
    )
    fig, axs = plt.subplots(4, 1, layout="constrained", sharex=True)
    fig.set_size_inches(6, 4)
    rows = [
        {"col": "elapsed_filter", "ylab": "filter"},
        {"col": "elapsed_peak", "ylab": "peak"},
        {"col": "elapsed_cluster", "ylab": "cluster"},
        {"col": "elapsed_total", "ylab": "total"}
    ]
    for i, row in enumerate(rows):
        _plot_summary_row_basic(axs[i], summary, good, hour, row["col"], row["ylab"])
    if conf.dates is not None and not conf.dates.empty:
        axs[0].set_xlim(*_xlim_with_margin(conf.dates["date"].min(), conf.dates["date"].max()))
    axs[-1].xaxis.set_tick_params(rotation=45)


def plot_counts(
    results: cluster.ClusterResultCollection,
    conf: cluster.ClusterConfig,
    hour: str = "",
):
    """Plot per-timepoint particle counts.

    Uses conf.spread_cutoff and conf.pe_diff_cutoff.
    """
    summary = results.summary()
    good = cluster.ClusterResultCollection.filter_summary(
        summary, conf
    )
    fig, axs = plt.subplots(11, 1, layout="constrained", sharex=True)
    fig.set_size_inches(6, 12)
    rows = [
        {"col": "evt_count", "ylab": "evt"},
        {"col": "opp_count", "ylab": "opp"},
        {"col": "evt_min_val_count", "ylab": "evt_min_val"},
        {"col": "evt_pe_chl_count", "ylab": "evt_pe_chl"},
        {"col": "evt_peak_count", "ylab": "evt_peak"},
        {"col": "opp_min_val_count", "ylab": "opp_min_val"},
        {"col": "opp_pe_chl_count", "ylab": "opp_pe_chl"},
        {"col": "opp_peak_count", "ylab": "opp_peak"},
        {"col": "fsc_pe_cluster_count", "ylab": "fsc_pe_cluster"},
        {"col": "fsc_d1_cluster_count", "ylab": "fsc_d1_cluster"},
        {"col": "fsc_d2_cluster_count", "ylab": "fsc_d2_cluster"}
    ]
    for i, row in enumerate(rows):
        _plot_summary_row_basic(
            axs[i], summary, good, hour, row["col"], ylab=None, title=row["ylab"]
        )
    if conf.dates is not None and not conf.dates.empty:
        axs[0].set_xlim(*_xlim_with_margin(conf.dates["date"].min(), conf.dates["date"].max()))
    axs[-1].xaxis.set_tick_params(rotation=45)


def _highlight_hour(ax, x, y):
    ax.plot(x, y, "o", color="tab:green", linestyle="None", alpha=0.5, mfc="none")
    ax.axvline(x, alpha=0.2, color="tab:gray")


def _xlim_with_margin(lo: pd.Timestamp, hi: pd.Timestamp, margin: float = 0.05):
    """Return (left, right) with a 5% margin on each side, matching matplotlib's default autoscale margin."""
    span = hi - lo
    pad = span * margin
    return lo - pad, hi + pad


def plot_filtering_cytograms(
    res: cluster.ClusterResult,
    evt: pd.DataFrame,
    scatter=False,
    n=10000  # maximum particles to draw
):
    add_base_plot = _add_scatter if scatter else _add_hexbin

    logger.info("%d EVT events", len(evt))
    evt_ali = evt[res.filter_results.evt_ali]
    logger.info("%d EVT events after alignment", len(evt_ali))
    opp = evt[res.filter_results.opp]
    logger.info("%d OPP events", len(opp))

    fig, axs_ = plt.subplots(3, 2, layout="constrained")
    axs = list(axs_.flatten())
    axs.reverse()  # to pop last element off starting with 0, 0

    lims = _calc_lims(evt)
    # lims = {"fsc_small": (0, 1.05 * 2**16), "D1": (0, 1.05 * 2**16), "D2": (0, 1.05 * 2**16)}

    # EVT density with convex hull around aligned particles
    ax = axs.pop()
    aligned_hull = ConvexHull(evt_ali[["D1", "D2"]].to_numpy())
    aligned_hull_points = np.transpose(evt_ali.iloc[aligned_hull.vertices][["D1", "D2"]].values)
    aligned_hull_points = _close_poly(aligned_hull_points)
    add_base_plot(ax, cap(evt, n), ["D1", "D2"], "Raw EVT", lims=lims)
    ax.axline((0, 0), slope=1, color="gray", linestyle="dashed", alpha=0.5)
    ax.plot(aligned_hull_points[0], aligned_hull_points[1], color="tab:cyan", alpha=0.5)
    _set_aspect(ax, 1)

    # EVT density of just aligned particles
    ax = axs.pop()
    add_base_plot(ax, cap(evt_ali, n), ["D1", "D2"], "Aligned EVT", lims=lims)
    ax.axline((0, 0), slope=1, color="gray", linestyle="dashed", alpha=0.5)
    _set_aspect(ax, 1)

    ax = axs.pop()
    add_base_plot(ax, cap(evt_ali, n), ["fsc_small", "D1"], "Aligned EVT", lims=lims)
    if (res.conf.filter_params_by_date is not None) and (len(res.conf.filter_params_by_date) > 0):
        _add_filter_cutoff(ax, "D1", res.conf.filter_params_by_date)
    else:
        _add_roughfilter_cutoff(ax, evt_ali, "D1")
    _set_aspect(ax, 1)

    ax = axs.pop()
    add_base_plot(ax, cap(evt_ali, n), ["fsc_small", "D2"], "Aligned EVT", lims=lims)
    if (res.conf.filter_params_by_date is not None) and (len(res.conf.filter_params_by_date) > 0):
        _add_filter_cutoff(ax, "D2", res.conf.filter_params_by_date)
    else:
        _add_roughfilter_cutoff(ax, evt_ali, "D2")
    _set_aspect(ax, 1)

    ax = axs.pop()
    add_base_plot(ax, cap(opp, n), ["fsc_small", "D1"], "OPP", lims=lims)
    if (res.conf.filter_params_by_date is not None) and (len(res.conf.filter_params_by_date) > 0):
        _add_filter_cutoff(ax, "D1", res.conf.filter_params_by_date)
    else:
        _add_roughfilter_cutoff(ax, evt_ali, "D1")
    _set_aspect(ax, 1)

    ax = axs.pop()
    add_base_plot(ax, cap(opp, n), ["fsc_small", "D2"], "OPP ", lims=lims)
    if (res.conf.filter_params_by_date is not None) and (len(res.conf.filter_params_by_date) > 0):
        _add_filter_cutoff(ax, "D2", res.conf.filter_params_by_date)
    else:
        _add_roughfilter_cutoff(ax, evt_ali, "D2")
    _set_aspect(ax, 1)

    fig.set_figwidth(6)
    fig.set_figheight(10)

    return fig


def plot_bead_cytograms_evt(
    res: cluster.ClusterResult,
    evt: pd.DataFrame,
    scatter=False,
    show_cutoffs=False,
    apply_cutoffs=False,
    show_clusters=False,
    n=10000  # max particles to draw
):
    # Scatter or hexbin density
    add_base_plot = _add_scatter if scatter else _add_hexbin

    # Filter results
    filt_res = res.filter_results

    # Grab cutoffs
    pe_chl_cutoff = res.conf.pe_chl_cutoff
    min_fsc = res.conf.min_fsc
    min_fsc2 = filt_res.fsc_cutoff["cutoff"] if filt_res.fsc_cutoff is not None else None
    min_pe = res.conf.min_pe
    min_pe2 = filt_res.pe_cutoff["cutoff"] if filt_res.pe_cutoff is not None else None
    min_chl= res.conf.min_chl
    max_chl = filt_res.chl_cutoff["cutoff"] if filt_res.chl_cutoff is not None else None

    # Draw cutoffs?
    draw_min_fsc = None
    draw_min_fsc2 = None
    draw_min_pe = None
    draw_min_pe2 = None
    draw_min_chl = None
    draw_max_chl = None
    draw_peaks = None
    pe_chl_cutoff_point_and_slope = None

    # Cluster data
    # FSC/PE EVT cluster points
    evt_cluster_points = res.dfs["fsc_pe"][["fsc_small", "pe"]].to_numpy()
    # Points from evt_cluster_points used as input to D1 clustering
    d1_pe_cluster_points = res.dfs["fsc_pe"][["fsc_small", "D1"]].to_numpy()
    # Points from evt_cluster_points used as input to D2 clustering
    d2_pe_cluster_points = res.dfs["fsc_pe"][["fsc_small", "D2"]].to_numpy()
    # FSC/D1 EVT cluster points
    d1_cluster_points = res.dfs["fsc_D1"][["fsc_small", "D1"]].to_numpy()
    # FSC/D2 EVT cluster points
    d2_cluster_points = res.dfs["fsc_D2"][["fsc_small", "D2"]].to_numpy()

    # Scatter point style configs
    pe_cluster_scatter_color = "tab:purple" if scatter else "tab:blue"
    d12_cluster_scatter_color = "tab:red" if scatter else "tab:red"
    cluster_scatter_markersize = 1
    cluster_scatter_alpha = 0.5

    logger.info("%d EVT events", filt_res.counts["evt"])
    logger.info("%d EVT events after alignment", filt_res.counts["evt_ali"])
    logger.info("%d OPP events", filt_res.counts["opp"])

    lims = _calc_lims(evt)

    if apply_cutoffs:
        opp = evt[filt_res.opp_cut_peaks]
        evt_cut = evt[filt_res.evt_cut_peaks]
        logger.info("%d OPP events after applying cutoffs", len(opp))
        logger.info("%d EVT events after applying cutoffs", len(evt_cut))
    else:
        opp = evt[filt_res.opp]
        evt_cut = evt[filt_res.evt_ali]

    peaks = filt_res.peaks

    if show_cutoffs:
        draw_min_fsc = min_fsc
        draw_min_fsc2 = min_fsc2
        draw_min_pe = min_pe
        draw_min_pe2 = min_pe2
        draw_min_chl = min_chl
        draw_max_chl = max_chl
        draw_peaks = peaks
        # Point that PE/CHL cutoff line must go through. Don't use (0, 0) as this
        # would extend the axis scales farther than desired.
        pe_chl_cutoff_point = (max(min_pe, evt["pe"].min()), max(min_pe, evt["pe"].min()) * pe_chl_cutoff)
        pe_chl_cutoff_point_and_slope = (pe_chl_cutoff_point, pe_chl_cutoff)

    fig, axs_ = plt.subplots(3, 2, layout="constrained")
    axs = list(axs_.flatten())
    axs.reverse()  # to pop last element off starting with 0, 0

    # EVT chl pe (0, 0)
    ax = axs.pop()
    add_base_plot(
        ax,
        cap(evt_cut, n),
        ["chl_small", "pe"],
        "Aligned EVT",
        lims=lims,
        x_cutoff=draw_min_chl,
        x_cutoff2=draw_max_chl,
        y_cutoff=draw_min_pe,
        y_cutoff2=draw_min_pe2,
        peaks=draw_peaks,
        selected_peak=filt_res.selected_peak,
        pe_chl_cutoff_point_and_slope=pe_chl_cutoff_point_and_slope,
    )
    _set_aspect(ax, 1)

    # EVT fsc pe (0, 1)
    ax = axs.pop()
    add_base_plot(
        ax,
        cap(evt_cut, n),
        ["fsc_small", "pe"],
        "Aligned EVT",
        lims=lims,
        x_cutoff=draw_min_fsc,
        x_cutoff2=draw_min_fsc2,
        y_cutoff=draw_min_pe,
        y_cutoff2=draw_min_pe2,
        peaks=draw_peaks,
        selected_peak=filt_res.selected_peak,
    )
    if show_clusters:
        ax.plot(
            *np.transpose(evt_cluster_points),
            marker="o",
            markersize=cluster_scatter_markersize,
            linestyle="None",
            color=pe_cluster_scatter_color,
            markeredgecolor="None",
            alpha=cluster_scatter_alpha,
        )
    _set_aspect(ax, 1)

    # OPP pe chl (1, 0)
    ax = axs.pop()
    add_base_plot(
        ax,
        cap(opp, n),
        ["chl_small", "pe"],
        "OPP",
        lims=lims,
        x_cutoff=draw_min_chl,
        x_cutoff2=draw_max_chl,
        y_cutoff=draw_min_pe,
        y_cutoff2=draw_min_pe2,
        peaks=draw_peaks,
        selected_peak=filt_res.selected_peak,
        pe_chl_cutoff_point_and_slope=pe_chl_cutoff_point_and_slope,
    )
    _set_aspect(ax, 1)

    # OPP fsc pe (1, 1)
    ax = axs.pop()
    add_base_plot(
        ax,
        cap(opp, n),
        ["fsc_small", "pe"],
        "OPP",
        lims=lims,
        x_cutoff=draw_min_fsc,
        x_cutoff2=draw_min_fsc2,
        y_cutoff=draw_min_pe,
        y_cutoff2=draw_min_pe2,
        peaks=draw_peaks,
        selected_peak=filt_res.selected_peak,
    )
    _set_aspect(ax, 1)

    # EVT fsc D1 (2, 0)
    ax = axs.pop()
    add_base_plot(
        ax,
        cap(evt_cut, n),
        ["fsc_small", "D1"],
        "EVT",
        lims=lims,
        x_cutoff=draw_min_fsc,
        x_cutoff2=draw_min_fsc2,
    )
    if show_clusters:
        # Plot points that came from initial FSC/PE cluster, and were used as
        # input to D1 clustering
        ax.plot(
            *np.transpose(d1_pe_cluster_points),
            marker="o",
            markersize=cluster_scatter_markersize,
            linestyle="None",
            color=pe_cluster_scatter_color,
            markeredgecolor="None",
            alpha=cluster_scatter_alpha,
        )
        # Plot FSC/D1 points clustered
        ax.plot(
            *np.transpose(d1_cluster_points),
            marker="o",
            markersize=cluster_scatter_markersize,
            linestyle="None",
            color=d12_cluster_scatter_color,
            markeredgecolor="None",
            alpha=cluster_scatter_alpha,
        )
    _set_aspect(ax, 1)

    # EVT fsc D2 (2, 1)
    ax = axs.pop()
    add_base_plot(
        ax,
        cap(evt_cut, n),
        ["fsc_small", "D2"],
        "EVT",
        lims=lims,
        x_cutoff=draw_min_fsc,
        x_cutoff2=draw_min_fsc2,
    )
    if show_clusters:
        # Plot points that came from initial FSC/PE cluster, and were used as
        # input to D2 clustering
        ax.plot(
            *np.transpose(d2_pe_cluster_points),
            marker="o",
            markersize=cluster_scatter_markersize,
            linestyle="None",
            color=pe_cluster_scatter_color,
            markeredgecolor="None",
            alpha=cluster_scatter_alpha,
        )
        # Plot FSC/D1 points clustered
        ax.plot(
            *np.transpose(d2_cluster_points),
            marker="o",
            markersize=cluster_scatter_markersize,
            linestyle="None",
            color=d12_cluster_scatter_color,
            markeredgecolor="None",
            alpha=cluster_scatter_alpha,
        )
    _set_aspect(ax, 1)

    fig.set_figwidth(6)
    fig.set_figheight(10)

    return fig


def _add_hexbin(
    ax,
    df,
    cols,
    title,
    lims=None,
    x_cutoff=None,
    x_cutoff2=None,
    y_cutoff=None,
    y_cutoff2=None,
    peaks=None,
    selected_peak=None,
    pe_chl_cutoff_point_and_slope=None,
    bins="log"
):
    ax.hexbin(df[cols[0]].values, df[cols[1]].values, cmap="inferno", bins=bins)
    ax.set_facecolor("black")
    _finish_ax(
        ax,
        cols,
        title,
        lims=lims,
        x_cutoff=x_cutoff,
        x_cutoff2=x_cutoff2,
        y_cutoff=y_cutoff,
        y_cutoff2=y_cutoff2,
        peaks=peaks,
        selected_peak=selected_peak,
        pe_chl_cutoff_point_and_slope=pe_chl_cutoff_point_and_slope,
    )


def _add_scatter(
    ax,
    df,
    cols,
    title,
    lims=None,
    x_cutoff=None,
    x_cutoff2=None,
    y_cutoff=None,
    y_cutoff2=None,
    peaks=None,
    selected_peak=None,
    pe_chl_cutoff_point_and_slope=None,
):
    ax.plot(df[cols[0]].values, df[cols[1]].values, alpha=0.1, marker="o", markersize=2, linestyle="None")
    _finish_ax(
        ax,
        cols,
        title,
        lims=lims,
        x_cutoff=x_cutoff,
        x_cutoff2=x_cutoff2,
        y_cutoff=y_cutoff,
        y_cutoff2=y_cutoff2,
        peaks=peaks,
        selected_peak=selected_peak,
        pe_chl_cutoff_point_and_slope=pe_chl_cutoff_point_and_slope,
    )


def _add_filter_cutoff(ax, dcol, filter_params):
    filter_params = filter_params[filter_params["quantile"] == 2.5]
    notch_small = filter_params[f"notch_small_{dcol}"].values[0]  # slope
    offset_small = filter_params[f"offset_small_{dcol}"].values[0]  # y-offset
    notch_large = filter_params[f"notch_large_{dcol}"].values[0]  # slope
    offset_large = filter_params[f"offset_large_{dcol}"].values[0]  # y-offset

    ax.axline((0, offset_small), slope=notch_small, color="tab:cyan", linestyle="dashed", alpha=0.5)
    ax.axline((0,  offset_large), slope=notch_large, color="tab:cyan", linestyle="dashed", alpha=0.5)


def _add_roughfilter_cutoff(ax, aligned, dcol):
    # Note that because of floating-point precision limitations during equality
    # testing, the "largest fsc_small with smallest D1 or D2" points may not
    # pass filtering. So to accurately identify these points we must use aligned
    # EVT particles, not OPP particles.
    fsc_max = aligned["fsc_small"].max()
    bigs = aligned[aligned["fsc_small"] == fsc_max]
    best_big = (fsc_max, bigs[dcol].min())
    ax.axline((0, 0), best_big, color="tab:cyan", linestyle="dashed", alpha=0.5)
    ax.scatter(*best_big, color="tab:pink", alpha=0.5, zorder=2.5)


def _finish_ax(
    ax, cols, title, lims=None, x_cutoff=None, x_cutoff2=None, y_cutoff=None,
    y_cutoff2=None, peaks=None, selected_peak=None,
    pe_chl_cutoff_point_and_slope=None
):
    cutoff_color = "gray"
    cutoff2_color = "pink"
    ax.set_title(title, fontsize=10)
    ax.set_xlabel(cols[0])
    ax.set_ylabel(cols[1])

    if lims is not None:
        ax.set_xlim(lims[cols[0]])
        ax.set_ylim(lims[cols[1]])

    if x_cutoff is not None:
        ax.axvline(x=x_cutoff, color=cutoff_color, alpha=0.5, linestyle="dotted")
        if x_cutoff > 0:
            ax.text(x_cutoff, ax.get_ylim()[0] + 1000, f"{x_cutoff}", color=cutoff_color, rotation=90)
    if x_cutoff2 is not None:
        ax.axvline(x=x_cutoff2, color=cutoff2_color, alpha=0.5, linestyle="dotted")
        if x_cutoff2 > 0:
            ax.text(x_cutoff2, ax.get_ylim()[0] + 1000, f"{x_cutoff2}", color=cutoff2_color, rotation=90)
    if y_cutoff is not None:
        ax.axhline(y=y_cutoff, color=cutoff_color, alpha=0.5, linestyle="dotted")
        if y_cutoff > 0:
            ax.text(ax.get_xlim()[0] + 1000, y_cutoff, f"{y_cutoff}", color=cutoff_color)
    if y_cutoff2 is not None:
        ax.axhline(y=y_cutoff2, color=cutoff2_color, alpha=0.5, linestyle="dotted")
        if y_cutoff2 > 0:
            ax.text(ax.get_xlim()[0] + 1000, y_cutoff2, f"{y_cutoff2}", color=cutoff2_color)
    if pe_chl_cutoff_point_and_slope is not None:
        ax.axline(
            pe_chl_cutoff_point_and_slope[0],
            slope=pe_chl_cutoff_point_and_slope[1],
            color="tab:red",
            alpha=0.5,
            linestyle="dotted",
        )
    if peaks and not peaks["found"].empty and selected_peak is not None:
        sel_peak = peaks["found"].iloc[selected_peak]
        ax.axhline(sel_peak["location"], color="tab:olive", alpha=0.2)
        ax.axhline(sel_peak["low_cutoff"], color="tab:olive", alpha=0.5, linestyle="dotted")
        ax.axhline(sel_peak["high_cutoff"], color="tab:olive", alpha=0.5, linestyle="dotted")


def _set_aspect(ax, ratio):
    xmin, xmax = ax.get_xlim()
    ymin, ymax = ax.get_ylim()
    ax.set_aspect(abs((xmax - xmin) / (ymax - ymin)) * ratio)


def _calc_lims(df):
    lims = dict()
    for col in df.select_dtypes(include=np.number).columns:
        lims[col] = (df[col].min() * 0.95, df[col].max() * 1.05)
    return lims


def _close_poly(points: np.ndarray):
    """Close a polygon defined by an ndarray of shape = (2, n_points)"""
    if (points.size > 0) and (points.shape[0] == 2) and (not np.array_equal(points[:, 0], points[:, -1])):
        logger.info("closing polygon, %s != %s", points[:, 0], points[:, -1])
        return np.append(points, points[:, :1], axis=1)
    return points


def cap(df, n):
    if not n or n >= len(df):
        return df
    return df.sample(n=n, random_state=12345)


def plot_peaks(
    particles: pd.DataFrame,
    peaks: dict[str, Any],
    selected_peak: Optional[int]=None
):
    fig = plt.figure(figsize=(7.5, 6))
    gs = fig.add_gridspec(nrows=1, ncols=2, width_ratios=[4, 1], wspace=0.05)
    ax_hex = fig.add_subplot(gs[0, 0])
    ax_hist = fig.add_subplot(gs[0, 1], sharey=ax_hex)
    ax_hist.tick_params(axis="y", labelleft=False)
    ax_hex.set_title("PE peak finding")

    ax_hex.hexbin(particles["fsc_small"], particles["pe"], cmap="inferno")
    if peaks:
        for i, p in peaks["found"].iterrows():
            if selected_peak is not None and i == selected_peak:
                ax_hex.axhline(peaks["bin_midpoints"][int(p["idx"])], color="tab:red", alpha=0.85)
                ax_hex.axhline(p["low_cutoff"], color="tab:olive", alpha=0.85)
                ax_hex.axhline(p["high_cutoff"], color="tab:olive", alpha=0.85)
            else:
                ax_hex.axhline(peaks["bin_midpoints"][int(p["idx"])], color="tab:red", alpha=0.4)

        bins = [x.left for x in peaks["bin_intervals"]]
        bins.append(peaks["bin_intervals"][-1].right)
        ax_hist.hist(peaks["bin_midpoints"], bins, weights=peaks["counts"], orientation="horizontal")
        ax_hist.plot(peaks["counts_ma"], peaks["bin_midpoints"], marker=None, color="tab:pink")
        for i, p in peaks["found"].iterrows():
            # Peak location x marker
            peaks_x = peaks["counts_ma"][int(p["idx"])]
            peaks_y = peaks["bin_midpoints"][int(p["idx"])]
            # Peak width
            extent_xs = (peaks_x, peaks_x)
            extent_ys = (
                peaks_y - (peaks["bin_size"] * p["width"] / 2),
                peaks_y + (peaks["bin_size"] * p["width"] / 2)
            )
            if selected_peak is not None and selected_peak == i:
                # Peak cutoffs and double/half for selected peak
                ax_hist.plot(peaks_x, peaks_y, "x", color="tab:red", alpha=0.85)
                ax_hist.axhline(p["low_cutoff"], color="tab:olive", alpha=0.85)
                ax_hist.axhline(p["high_cutoff"], color="tab:olive", alpha=0.85)
                ax_hist.axhline(p["double"], color="tab:gray", alpha=0.85)
                ax_hist.axhline(p["half"], color="tab:gray", alpha=0.85)
                ax_hist.plot(extent_xs, extent_ys, marker=None, linestyle="solid", color="tab:red", alpha=0.5)
                double_lower_bound = log_particles(unlog_particles(extent_ys[0]) * 2)
                double_curp_upper_bound = log_particles(unlog_particles(extent_ys[1]) * 2)
                ax_hist.plot(
                    extent_xs,
                    [double_lower_bound, double_curp_upper_bound],
                    marker=None, linestyle=":", color="tab:pink", alpha=0.5
                )
            else:
                ax_hist.plot(peaks_x, peaks_y, "x", color="tab:red", alpha=0.5)
                ax_hist.plot(extent_xs, extent_ys, marker=None, linestyle="solid", color="tab:red", alpha=0.25)

    return fig


def plot_opp_with_peaks_and_marginals(
    res: cluster.ClusterResult,
    evt: pd.DataFrame,
    scatter=False,
    n=10000  # max particles to draw
):
    # Filter results
    filt_res = res.filter_results
    opp_cut = cap(evt[filt_res.opp_cut_max], n)  # OPP without PE saturated particles
    mask = filt_res.opp_cut_max
    # Create subset of OPP that pass PE and FSC cutoffs, if they exist.
    # Use this for PE/CHL ratios and scatter in CHL vs PE plot.
    if filt_res.pe_cutoff is not None:
        mask = mask & (evt["pe"] >= filt_res.pe_cutoff["cutoff"])
    if filt_res.fsc_cutoff is not None:
        mask = mask & (evt["fsc_small"] >= filt_res.fsc_cutoff["cutoff"])
    opp_cut2 = cap(evt[mask], n)


    # Linear PE/CHL ratios.
    opp_pe_chl = get_linear_pe_chl(opp_cut)
    opp_pe_chl2 = get_linear_pe_chl(opp_cut2)

    # Create figure
    fig = plt.figure(figsize=(10, 6), layout="constrained")
    gs = fig.add_gridspec(
        3, 4,
        height_ratios=[1, 1, 6],
        width_ratios=[
            6, 1, 6, 1
        ]
    )

    ax0 = fig.add_subplot(gs[2, 0])
    ax0_xratio = fig.add_subplot(gs[0, 0], sharex=ax0)
    ax0_xhist = fig.add_subplot(gs[1, 0], sharex=ax0)
    ax0_yratio = fig.add_subplot(gs[2, 1], sharey=ax0)
    ax1 = fig.add_subplot(gs[2, 2], sharey=ax0)
    ax1_yhist = fig.add_subplot(gs[2, 3], sharey=ax1)
    ax1_xratio = fig.add_subplot(gs[0, 2], sharex=ax1)
    ax1_xhist = fig.add_subplot(gs[1, 2], sharex=ax1)

    if scatter:
        ax0.plot(opp_cut["fsc_small"], opp_cut["pe"], alpha=0.1, marker="o", markersize=2, linestyle="None")
        ax1.plot(opp_cut2["chl_small"], opp_cut2["pe"], alpha=0.1, marker="o", markersize=2, linestyle="None")
    else:
        # Plot main cytograms as hexbin with log bins
        ax0.hexbin(opp_cut["fsc_small"], opp_cut["pe"], gridsize=100, bins="log")
        ax1.hexbin(opp_cut2["chl_small"], opp_cut2["pe"], gridsize=100, bins="log")

    # Hide Y labels on margin histograms and right cytogram
    for ax in [ax1, ax1_yhist, ax0_yratio]:
        ax.tick_params(axis="y", labelleft=False)
    # Hide X labels on margin histograms
    for ax in [ax0_xhist, ax0_xratio, ax1_xhist, ax1_xratio]:
        ax.tick_params(axis="x", labelbottom=False)
    
    # Plot PE/CHL-based FSC cutoff
    if filt_res.fsc_cutoff is not None:
        ax0.axvline(filt_res.fsc_cutoff["cutoff"], color="tab:blue", linestyle="dashed", alpha=0.5, label="FSC Cutoff")
        ax0_xratio.axvline(filt_res.fsc_cutoff["cutoff"], color="tab:blue", linestyle="--", alpha=0.5, label="FSC Cutoff")
        ax0_xhist.axvline(filt_res.fsc_cutoff["cutoff"], color="tab:blue", linestyle="--", alpha=0.5, label="FSC Cutoff")

    # Draw PE/CHL-based PE cutoff
    if filt_res.pe_cutoff is not None:
        ax0.axhline(filt_res.pe_cutoff["cutoff"], color="tab:green", linestyle="dashed", alpha=0.5, label="PE Cutoff")
        ax0_yratio.axhline(filt_res.pe_cutoff["cutoff"], color="tab:green", linestyle="--", alpha=0.5, label="PE Cutoff")
        ax1.axhline(filt_res.pe_cutoff["cutoff"], color="tab:green", linestyle="dashed", alpha=0.5, label="PE Cutoff")
        ax1_yhist.axhline(filt_res.pe_cutoff["cutoff"], color="tab:green", linestyle="--", alpha=0.5, label="PE Cutoff")

    # Draw PE/CHL-based CHL cutoff
    if filt_res.chl_cutoff is not None:
        ax1.axvline(filt_res.chl_cutoff["cutoff"], color="tab:orange", linestyle="dashed", alpha=0.5, label="CHL Cutoff")
        ax1_xhist.axvline(filt_res.chl_cutoff["cutoff"], color="tab:orange", linestyle="--", alpha=0.5, label="CHL Cutoff")
        ax1_xratio.axvline(filt_res.chl_cutoff["cutoff"], color="tab:orange", linestyle="--", alpha=0.5, label="CHL Cutoff")

    final_peaks = filt_res.peaks
    selected_peak = filt_res.selected_peak

    # ##########################################################################
    # Add marginal plots for PE, FSC, CHL distributions and linear PE/CHL ratios.
    # Note, PE, FSC, CHL distributions only show data that goes into peak
    # finding, which has PE/CHL-based PE and FSC cutoffs applied.
    # i.e. evt with mask filt_res.opp_cut_pechl2.
    # In contrast, PE/CHL ratio marginal plots are based on OPP data with only
    # max PE saturation cutoff applied, to show all data that goes into
    # calculating PE/CHL-based PE and FSC cutoffs.
    # ##########################################################################
    # Y-axis marginal plots
    # #####################
    # Plot PE distribution moving average along y-axis
    ax1_yhist.plot(final_peaks["counts_ma"], final_peaks["bin_midpoints"], color="C1", label="Counts MA")
    # Plot PE/CHL ratio moving average along y-axis (PE)
    opp_ratio_by_pe_ma = opp_pe_chl["by_pe"]["pe_chl_linear"].rolling(window=100, min_periods=80, center=True).median().fillna(0)
    ax0_yratio.plot(opp_ratio_by_pe_ma, opp_pe_chl["by_pe"]["pe"], color="C2", label="Ratio MA", marker=".", linestyle="None")
    ax0_yratio.set_xlim(left=0)
    ax0_yratio.margins(x=0.1)

    # X-axis marginal plots
    # #####################
    # Plot FSC distribution moving average along x-axis
    fsc_hist = make_hist(
        evt[filt_res.opp_cut_pechl2]["fsc_small"],
        bin_size=res.conf.peak_finder_params["bin_size"],
        ma_window=res.conf.peak_finder_params["ma_window"]
    )
    ax0_xhist.plot(fsc_hist["bin_midpoints"], fsc_hist["counts_ma"], color="C1", label="Counts MA")
    # Plot PE/CHL ratio moving average along x-axis (FSC)
    opp_ratio_by_fsc_ma = opp_pe_chl["by_fsc"]["pe_chl_linear"].rolling(window=100, min_periods=80, center=True).median().fillna(0)
    ax0_xratio.plot(opp_pe_chl["by_fsc"]["fsc_small"], opp_ratio_by_fsc_ma, color="C2", label="Ratio MA", marker=".", linestyle="None")
    ax0_xratio.set_ylim(bottom=0)
    ax0_xratio.margins(y=0.1)

    # Plot CHL distribution moving average along x-axis
    chl_hist = make_hist(
        evt[filt_res.opp_cut_pechl2]["chl_small"],
        bin_size=res.conf.peak_finder_params["bin_size"],
        ma_window=res.conf.peak_finder_params["ma_window"]
    )
    ax1_xhist.plot(chl_hist["bin_midpoints"], chl_hist["counts_ma"], color="C1", label="Counts MA")
    # Plot PE/CHL ratio moving average along x-axis (CHL)
    opp_ratio_by_chl_ma = opp_pe_chl2["by_chl"]["pe_chl_linear"].rolling(window=100, min_periods=80, center=True).median().fillna(0)
    ax1_xratio.plot(opp_pe_chl2["by_chl"]["chl_small"], opp_ratio_by_chl_ma, color="C2", label="Ratio MA", marker=".", linestyle="None")
    ax1_xratio.set_ylim(bottom=0)
    ax1_xratio.margins(y=0.1)

    # Add peak lines and filter masks
    if not final_peaks["found"].empty:
        for i, row in final_peaks["found"].iterrows():
            if selected_peak is not None and i == selected_peak:
                # Plot the selected peak
                color = "tab:red"
                ax0.axhline(row["location"], color=color, linestyle="dotted", alpha=0.9, label="Peak")
                ax1.axhline(row["location"], color=color, linestyle="dotted", alpha=0.9)
                ax1_yhist.axhline(row["location"], color=color, linestyle="dotted", alpha=0.9, label="Peak")
                ax0_yratio.axhline(row["location"], color=color, linestyle="dotted", alpha=0.9, label="Peak")
                ax0.axhline(row["low_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak Low Cutoff")
                ax0.axhline(row["high_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak High Cutoff")
                ax1.axhline(row["low_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak Low Cutoff")
                ax1.axhline(row["high_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak High Cutoff")
                ax1_yhist.axhline(row["low_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak Low Cutoff")
                ax1_yhist.axhline(row["high_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak High Cutoff")
                ax0_yratio.axhline(row["low_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak Low Cutoff")
                ax0_yratio.axhline(row["high_cutoff"], color=color, linestyle="dotted", alpha=0.5, label="Peak High Cutoff")
            else:
                # Only plot non-selected peaks in the PE marginal histogram
                color = "tab:olive"
                ax1_yhist.axhline(row["location"], color=color, linestyle="dotted", alpha=0.9, label="Peak")

    # Set Axis Labels
    ax0.set_ylabel("PE")
    ax1.set_xlabel("CHL")
    ax0.set_xlabel("FSC")

    # Set Titles
    ax0_xratio.set_title("OPP")
    ax1_xratio.set_title("OPP")

    # Set Histogram and Ratio Labels
    ax0_xhist.set_ylabel("Count")
    ax1_yhist.set_xlabel("Count")
    ax0_xratio.set_ylabel("PE/CHL")
    ax0_yratio.set_xlabel("PE/CHL")

    return fig
