from __future__ import annotations

import logging
from dataclasses import dataclass, field
from timeit import default_timer as timer
from typing import Any, Literal, Optional, TYPE_CHECKING, TypedDict

import numpy as np
import pandas as pd
import seaflowpy as sfp
from scipy.signal import find_peaks

from beadclust.errors import BeadFinderError
from beadclust.particleops import log_particles, unlog_particles

# Avoid circular import
if TYPE_CHECKING:
    from beadclust.cluster import ClusterConfig


logger = logging.getLogger(__name__)


@dataclass
class FilterResults:
    evt_ali: np.ndarray
    evt_cut_min: np.ndarray
    evt_cut_pechl: np.ndarray
    evt_cut_pechl2: np.ndarray
    evt_cut_peaks: np.ndarray
    opp: np.ndarray
    opp_cut_max: np.ndarray
    opp_cut_min: np.ndarray
    opp_cut_pechl: np.ndarray
    opp_cut_pechl2: np.ndarray
    opp_cut_peaks: np.ndarray
    peaks: dict[str, Any]
    peaks1: dict[str, Any]
    counts: dict[str, int]
    elapsed_total: float
    elapsed_peak: float
    pe_cutoff: Optional[PeChlCutoffResult] = field(default=None)
    fsc_cutoff: Optional[PeChlCutoffResult] = field(default=None)
    chl_cutoff: Optional[PeChlCutoffResult] = field(default=None)
    peaks2: dict[str, Any] | None = field(default=None)
    selected_peak: Optional[int] = field(default=None)


class PeChlCutoffResult(TypedDict):
    """
    Represents the result of identifying a PE/CHL cutoff based on the maximum
    PE/CHL ratio along a specified column.

    Attributes:
        cutoff: The value identified as the cutoff.
        cutoff_ratio: The linear PE/CHL ratio at the identified cutoff value.
        max_ratio: The maximum linear PE/CHL ratio.
    """
    cutoff: float
    cutoff_ratio: float
    max_ratio: float


def pipeline(evt: pd.DataFrame, conf: ClusterConfig) -> FilterResults:
    t0 = timer()
    particle_counts = {
        "evt": len(evt),
        "evt_ali": 0,
        "opp": 0,
        "opp_min_val": 0,
        "opp_max_val": 0,
        "opp_pe_chl": 0,
        "opp_peak": 0,
        "evt_min_val": 0,
        "evt_max_val": 0,
        "evt_pe_chl": 0,
        "evt_peak": 0,
    }
    evt = evt.reset_index(drop=True)
    logger.debug("%d total events", len(evt))
    col_sums = evt[["D1", "D2", "fsc_small", "chl_small", "pe"]].sum()
    logger.debug("column sums: %s", col_sums.to_dict())

    evt_ali = align(evt, conf.filtering_width, origin_align=conf.origin_align)
    particle_counts["evt_ali"] = evt_ali.sum()
    logger.debug("%d events after alignment", evt_ali.sum())

    # Filter EVT to create OPP. If no filter parameters are supplied, use rough filter. Otherwise use
    # supplied parameters to mark focused particles and use the most lenient
    # quantile as OPP.
    if (conf.filter_params_by_date is None) or len(conf.filter_params_by_date) == 0:
        logger.debug("Using rough filter to create OPP")
        try:
            opp = roughfilter(evt, aligned=evt_ali, width=conf.filtering_width, origin_align=conf.origin_align)
        except BeadFinderError as e:
            opp = np.zeros(len(evt), dtype=bool)
            logger.warning(f"no OPP, {e}")
    else:
        logger.debug("Using supplied filter parameters to create OPP")
        assert len(conf.filter_params_by_date) == 3
        fp = conf.filter_params_by_date.copy().reset_index(drop=True)
        fp["width"] = conf.filtering_width
        mark = mark_focused(evt, fp, aligned=evt_ali, origin_align=conf.origin_align)
        opp = mark["q2.5"].to_numpy()
    particle_counts["opp"] = opp.sum()
    logger.debug("%d OPP events", opp.sum())

    # Apply filter to exclude particles saturating FSC, CHL, PE PMTs. These
    # particles can throw off PE/CHL based filters and PE peak finding.
    opp_cut_max = opp & remove_saturated(evt, bins=conf.sat_bins)
    evt_cut_max = evt_ali & remove_saturated(evt, bins=conf.sat_bins)
    particle_counts["opp_max_val"] = opp_cut_max.sum()
    particle_counts["evt_max_val"] = evt_cut_max.sum()
    logger.debug("%d opp events after saturation filter with %d bins applied", opp_cut_max.sum(), conf.sat_bins)
    logger.debug("%d evt events after saturation filter with %d bins applied", evt_cut_max.sum(), conf.sat_bins)


    # Min value filter
    opp_cut_min = apply_min_cutoffs(evt, opp_cut_max, conf.min_pe, conf.min_fsc, conf.min_chl)
    evt_cut_min = apply_min_cutoffs(evt, evt_cut_max, conf.min_pe, conf.min_fsc, conf.min_chl)
    particle_counts["opp_min_val"] = opp_cut_min.sum()
    particle_counts["evt_min_val"] = evt_cut_min.sum()
    logger.debug(
        "%d opp events after min_pe:min_fsc %d:%d cutoff applied", opp_cut_min.sum(), conf.min_pe, conf.min_fsc
    )
    logger.debug(
        "%d evt events after min_pe:min_fsc %d:%d cutoff applied", evt_cut_min.sum(), conf.min_pe, conf.min_fsc
    )

    # Apply PE/CHL croco cutoff
    evt_all_cut_pechl = (evt["pe"].to_numpy() / evt["chl_small"].to_numpy()) >= conf.pe_chl_cutoff
    opp_cut_pechl = opp_cut_min & evt_all_cut_pechl
    evt_cut_pechl = evt_cut_min & evt_all_cut_pechl
    particle_counts["opp_pe_chl"] = opp_cut_pechl.sum()
    particle_counts["evt_pe_chl"] = evt_cut_pechl.sum()
    logger.debug("%d opp events after applying pe/chl >= %.02f", opp_cut_pechl.sum(), conf.pe_chl_cutoff)
    logger.debug("%d evt events after applying pe/chl >= %.02f", evt_cut_pechl.sum(), conf.pe_chl_cutoff)
    # opp_cut_pechl = opp_cut_min
    # evt_cut_pechl = evt_cut_min

    # Linear PE/CHL ratios
    opp_pe_chl_df = get_linear_pe_chl(evt[opp_cut_pechl])
    # Start with PE/CHL cutoff filter and then apply additional PE/CHL ratio-based
    # PE and FSC cutoffs below.
    opp_cut_pechl2 = opp_cut_pechl
    evt_cut_pechl2 = evt_cut_pechl
    # See if we can define a min PE cutoff to exclude syn based on max PE/CHL ratio
    pe_cutoff = pe_chl_based_cutoff(
        opp_pe_chl_df["by_pe"],
        "pe",
        offset=conf.pe_chl_based_cutoff_pe_offset,
        tol=conf.pe_chl_based_cutoff_pe_tol,
        mode="min"
    )
    logger.debug(f"Syn Cutoff PE (max ratio method): {pe_cutoff}")
    if pe_cutoff is not None:
        opp_cut_pechl2 = opp_cut_pechl2 & (evt["pe"] >= pe_cutoff["cutoff"]).to_numpy()
        evt_cut_pechl2 = evt_cut_pechl2 & (evt["pe"] >= pe_cutoff["cutoff"]).to_numpy()
    # Get fsc_small min cutoff based on max PE/CHL ratio along fsc_small
    # and cut OPP in fsc_small to isolate beads from syn
    fsc_cutoff = pe_chl_based_cutoff(
        opp_pe_chl_df["by_fsc"],
        "fsc_small",
        offset=conf.pe_chl_based_cutoff_fsc_offset,
        tol=conf.pe_chl_based_cutoff_fsc_tol,
        mode="min"
    )
    logger.debug(f"FSC Small Cutoff: {fsc_cutoff}")
    if fsc_cutoff is not None:
        opp_cut_pechl2 = opp_cut_pechl2 & (evt["fsc_small"] >= fsc_cutoff["cutoff"]).to_numpy()
        evt_cut_pechl2 = evt_cut_pechl2 & (evt["fsc_small"] >= fsc_cutoff["cutoff"]).to_numpy()
    # Get chl_small max cutoff based on max PE/CHL ratio along chl_small. Use
    # this to isolate beads from croco.
    # Recalculate PE/CHL ratio-based cutoffs after applying PE and FSC cutoffs
    # to exclude syn. When traversing CHL, syn and the beads overlap and the
    # bead PE/CHL signal gets swamped. See TN412_130 hour = 2023-02-01T00:00:00,
    # where there is a PE/CHL peak at a low CHL value, which causes this cutoff
    # to exclude all bead particles.
    opp_pe_chl_df = get_linear_pe_chl(evt[opp_cut_pechl2])
    chl_cutoff = pe_chl_based_cutoff(
        opp_pe_chl_df["by_chl"],
        "chl_small",
        offset=conf.pe_chl_based_cutoff_chl_offset,
        tol=conf.pe_chl_based_cutoff_chl_tol,
        mode="max"
    )
    logger.debug(f"CHL Small Cutoff: {chl_cutoff}")
    if chl_cutoff is not None:
        opp_cut_pechl2 = opp_cut_pechl2 & (evt["chl_small"] <= chl_cutoff["cutoff"]).to_numpy()
        evt_cut_pechl2 = evt_cut_pechl2 & (evt["chl_small"] <= chl_cutoff["cutoff"]).to_numpy()

    # Bead peak filter to exclude sticky bead doublet/triplet/etc clusters and
    # to exclude any synecho particles
    # Create OPP and EVT dataframes selected for particles for each PE peak found
    t1 = timer()
    peaks1 = find_bead_peaks(evt[opp_cut_pechl2], col="pe", **conf.peak_finder_params)
    if "found" in peaks1:
        logger.debug("%d peaks found", len(peaks1["found"]))
    selected_peak = pick_peak(peaks1, **conf.peak_picker_params)
    peaks2 = None
    final_peaks = peaks1
    if selected_peak is not None:
        p = peaks1["found"].iloc[selected_peak]
        logger.debug(
            "chose primary peak at pe=%.02f, pe/chl=%.02f",
            p["pe_med"],
            p["pe_chl_ratio_linear"],
        )
        # Remove all data below double this peek and see if any new peaks
        # get picked up with better pe/chl ratio. If there are bead doublet
        # and triplets, etc any new peaks detected will have the same pe/chl
        # ratio. If this is a syn peak, then beads should be the next peak
        # detected.
        # opp2 = opp_cut_pechl & (evt["pe"] > p["double"])
        # opp2 = opp_cut_pechl2 & (evt["pe"] > (p["pe_med"] + conf.peak_syn_filter_offset)).to_numpy()
        # peaks2 = find_bead_peaks(evt[opp2], col="pe", **conf.peak_finder_params)
        # if "found" in peaks2:
        #     logger.debug("%d peaks found after removing first selected peak", len(peaks2["found"]))
        # selected_peak2 = pick_peak(peaks2, **conf.peak_picker_params)
        # if selected_peak2 is not None:
        #     p2 = peaks2["found"].iloc[selected_peak2]
        #     logger.debug(
        #         "chose secondary peak at pe=%.02f, pe/chl=%.02f",
        #         p2["pe_med"],
        #         p2["pe_chl_ratio_linear"],
        #     )
        #     # If old peak pe/chl is not equal to new peak (with x% tolerance)
        #     # choose new peak
        #     if p["pe_chl_ratio_linear"] < ((1 - conf.peak_picker_params["pe_chl_tol"]) * p2["pe_chl_ratio_linear"]):
        #         p = p2
        #         final_peaks = peaks2
        #         selected_peak = selected_peak2
        #         logger.debug("secondary peak has significantly higher pe/chl, will be used")

        opp_cut_peaks = opp_cut_pechl2 & (evt["pe"].values >= p["low_cutoff"])
        opp_cut_peaks = opp_cut_peaks & (evt["pe"].values <= p["high_cutoff"])
        evt_cut_peaks = evt_cut_pechl2 & (evt["pe"].values >= p["low_cutoff"])
        evt_cut_peaks = evt_cut_peaks & (evt["pe"].values <= p["high_cutoff"])
    else:
        # Still put dataframes in *_cut_peaks even if there are no peaks
        opp_cut_peaks = opp_cut_pechl2
        evt_cut_peaks = evt_cut_pechl2
    t2 = timer()

    particle_counts["opp_peak"] = opp_cut_peaks.sum()
    particle_counts["evt_peak"] = evt_cut_peaks.sum()
    logger.debug("%s opp events after bead peak filter applied", particle_counts["opp_peak"])
    logger.debug("%s evt events after bead peak filter applied", particle_counts["evt_peak"])

    res = FilterResults(
        evt_ali=evt_ali,
        evt_cut_min=evt_cut_min,
        evt_cut_pechl=evt_cut_pechl,
        evt_cut_peaks=evt_cut_peaks,
        evt_cut_pechl2=evt_cut_pechl2,
        opp=opp,
        opp_cut_max=opp_cut_max,
        opp_cut_min=opp_cut_min,
        opp_cut_pechl=opp_cut_pechl,
        opp_cut_peaks=opp_cut_peaks,
        opp_cut_pechl2=opp_cut_pechl2,
        peaks=final_peaks,
        peaks1=peaks1,
        peaks2=peaks2,
        pe_cutoff=pe_cutoff,
        fsc_cutoff=fsc_cutoff,
        chl_cutoff=chl_cutoff,
        selected_peak=selected_peak,
        counts=particle_counts,
        elapsed_total = t2 - t0,
        elapsed_peak = t2 - t1
    )
    return res


def align(df: pd.DataFrame, width: float | int, origin_align: bool=True) -> np.ndarray:
    # Return boolean selection for aligned, non-noise, non-saturated particles
    # Aligned particles (D1 = D2), with correction for D1 D2 sensitivity
    # difference.
    noise = sfp.particleops.mark_noise(df)
    sat = sfp.particleops.mark_saturated(df) # D1 and D2 saturation
    sat_fsc = df["fsc_small"].to_numpy() == df["fsc_small"].max()
    if origin_align:
        origin = np.median(df["D2"].to_numpy() - df["D1"].to_numpy())
    else:
        origin = 0
    # Filter aligned particles (D1 = D2), with correction for D1 D2
    # sensitivity difference.
    alignedD1 = (df["D1"].to_numpy() + origin) < (df["D2"].to_numpy() + width)
    alignedD2 = df["D2"].to_numpy() < (df["D1"].to_numpy() + origin + width)
    aligned = (~noise) & (~sat) & (~sat_fsc) & alignedD1 & alignedD2
    return aligned


def apply_min_cutoffs(df, prev_sel, min_pe, min_fsc, min_chl):
    if prev_sel is not None:
        min_indexer = np.asarray(prev_sel)
    else:
        min_indexer = np.full(len(df.index), True)
    if min_pe:
        min_indexer = min_indexer & (df["pe"].values >= min_pe)
    if min_fsc:
        min_indexer = min_indexer & (df["fsc_small"].values >= min_fsc)
    if min_chl:
        min_indexer = min_indexer & (df["chl_small"].values >= min_chl)
    return min_indexer


def mark_focused(
        df: pd.DataFrame,
        params: pd.DataFrame,
        aligned: np.ndarray | pd.Series | None=None,
        origin_align: bool=True):
    # Check parameters
    param_keys = [
        "width",
        "notch_small_D1",
        "notch_small_D2",
        "notch_large_D1",
        "notch_large_D2",
        "offset_small_D1",
        "offset_small_D2",
        "offset_large_D1",
        "offset_large_D2",
        "quantile",
    ]
    if params is None:
        raise ValueError("Must provide filtering parameters")
    for k in param_keys:
        if k not in params.columns:
            raise ValueError(f"Missing filter parameter {k} in mark_focused")
    assert len(params["width"].unique()) == 1  # may as well check
    # Make sure params have 0-based indexing
    params = params.reset_index(drop=True)

    mark = pd.DataFrame()
    if aligned is None:
        # Apply noise, saturation, alignment filter
        aligned = align(df, float(params["width"][0]), origin_align=origin_align)
        logger.debug("%d EVT events after alignment", np.sum(aligned))

    for q in params["quantile"].sort_values():
        p = params[params["quantile"] == q].iloc[0]  # get first row of dataframe as series
        # Filter focused particles
        # Using underlying numpy arrays (values) to construct boolean
        # selector is about 10% faster than using pandas Series
        small_D1 = df["D1"].to_numpy() <= (
            (df["fsc_small"].to_numpy() * p["notch_small_D1"]) + p["offset_small_D1"]
        )
        small_D2 = df["D2"].to_numpy() <= (
            (df["fsc_small"].to_numpy() * p["notch_small_D2"]) + p["offset_small_D2"]
        )
        large_D1 = df["D1"].to_numpy() <= (
            (df["fsc_small"].to_numpy() * p["notch_large_D1"]) + p["offset_large_D1"]
        )
        large_D2 = df["D2"].to_numpy() <= (
            (df["fsc_small"].to_numpy() * p["notch_large_D2"]) + p["offset_large_D2"]
        )
        opp_selector = aligned & ((small_D1 & small_D2) | (large_D1 & large_D2))
        # Mark focused particles
        colname = f"q{sfp.util.quantile_str(q)}"
        mark[colname] = opp_selector

    mark.set_index(df.index.copy())  # match the index of df

    return mark


def roughfilter(
        df: pd.DataFrame,
        aligned: np.ndarray | pd.Series | None=None,
        width: float | int=5000,
        origin_align: bool=True) -> np.ndarray:
    if width is None:
        raise ValueError("Must supply width to roughfilter")
    # Prevent potential integer division bugs
    width = float(width)

    if len(df) == 0:
        return np.zeros(0, dtype=bool)

    if aligned is None:
        # Apply noise, saturation, alignment filter
        aligned = align(df, width, origin_align=origin_align)
        logger.debug("%d EVT events after alignment", aligned.sum())

    # Find fsc/d ratio (slope) for best large fsc particle
    fsc_small_max = df.loc[aligned, "fsc_small"].max()
    fsc_small_max_idx = (
        aligned &
        (df["fsc_small"].to_numpy() == fsc_small_max) &
        (df["D1"].to_numpy() > 0) &
        (df["D2"].to_numpy() > 0)
    )
    if fsc_small_max_idx.sum() == 0:
        raise BeadFinderError("no fsc_small.max() particles with D1 and D2 > 0")

    # Smallest D1 with maximum fsc_small
    min_d1 = df["D1"].to_numpy()[fsc_small_max_idx].min()
    slope_d1 = fsc_small_max / min_d1
    # Smallest D2 with maximum fsc_small
    min_d2 = df["D2"].to_numpy()[fsc_small_max_idx].min()
    slope_d2 = fsc_small_max / min_d2

    # Filter focused particles
    # Better fsc/d signal than best large fsc particle
    # oppD1 = (aligned_df["fsc_small"].to_numpy() / aligned_df["D1"].to_numpy()) >= slope_d1
    # oppD2 = (aligned_df["fsc_small"].to_numpy() / aligned_df["D2"].to_numpy()) >= slope_d2
    # Do this instead of avoid divide by zero
    oppD1 = df["fsc_small"].to_numpy() >= (df["D1"].to_numpy() * slope_d1)
    oppD2 = df["fsc_small"].to_numpy() >= (df["D2"].to_numpy() * slope_d2)
    return (aligned & oppD1 & oppD2)


def make_hist(
    s: pd.Series,
    bin_size: int=250,
    ma_window: int=8,
    fillna_zero: bool=True
) -> dict[str, Any]:
    bins = int((s.max() - s.min()) / bin_size) + 1
    hist = s.groupby(pd.cut(s, bins), observed=False).size()
    bin_labels = hist.index.to_numpy()
    bin_bounds = pd.DataFrame(
        {"left": [x.left for x in bin_labels], "right": [x.right for x in bin_labels]}
    )
    bin_mids = bin_bounds.mean(axis=1)
    hist = hist.reset_index(drop=True)
    # Set NaN to 0 as find_peaks warns about including NaN
    if fillna_zero:
        hist_ma = hist.rolling(ma_window, center=True).mean().fillna(0)
    else:
        hist_ma = hist.rolling(ma_window, center=True).mean()
    return {
        "counts": hist.to_numpy(),
        "counts_ma": hist_ma.to_numpy(),
        "bin_midpoints": bin_mids,
        "bin_intervals": bin_labels,
        "bin_size": bin_size
    }


def find_bead_peaks(
    df: pd.DataFrame,
    col: str="pe",
    bin_size: int=250,
    ma_window: int=8,
    peak_width: Optional[list[int]]=None,
    peak_height: int=5,
    peak_height_frac_max: float=0.8,
    cutoff_scalar: float=0.4,
) -> dict[str, Any]:
    if peak_width is None:
        peak_width = [2, 30]
    
    if df[col].empty:
        return {}
    # Histgram dict will serve as the base for our return value. We'll all
    # a "found" key to it with the dataframe of found peaks and their properties
    # later.
    r = make_hist(df[col], bin_size=bin_size, ma_window=ma_window)
    hist_ma = r["counts_ma"]
    bin_mids = r["bin_midpoints"]
    height = max(peak_height, hist_ma.max() * peak_height_frac_max)
    peaks, properties = find_peaks(hist_ma, height=height, width=peak_width)

    found = []
    for i, peak_bin in enumerate(peaks):
        f = {
            "idx": peak_bin,
            "location": bin_mids[peak_bin],
            "high_cutoff": log_particles(unlog_particles(bin_mids[peak_bin]) * (1 + cutoff_scalar)),
            "low_cutoff": log_particles(unlog_particles(bin_mids[peak_bin]) * (1 - cutoff_scalar)),
            "double": log_particles(unlog_particles(bin_mids[peak_bin]) * 2),
            "half": log_particles(unlog_particles(bin_mids[peak_bin]) / 2),
            "prominence": properties["prominences"][i],
            "height": properties["peak_heights"][i],
            "width": properties["widths"][i]
        }
        lwr = f["location"] - (bin_size * f["width"] / 2)
        upr = f["location"] + (bin_size * f["width"] / 2)
        peak_df = df[(df["pe"] >= lwr) & (df["pe"] <= upr)]
        f["pe_chl_ratio_linear"] = (unlog_particles(peak_df["pe"]) / unlog_particles(peak_df["chl_small"])).median()
        f["fsc_small_med"] = peak_df["fsc_small"].median()
        f["pe_med"] = peak_df["pe"].median()
        f["chl_small_med"] = peak_df["chl_small"].median()
        found.append(f)
    if found:
        r["found"] = pd.DataFrame(found).sort_values("location").reset_index(drop=True)
    else:
        r["found"] = pd.DataFrame()

    return r


def pick_peak(
    peaks: dict[str, Any],
    pe_chl_tol: float=0.25,
    height_tol: float=0.5
) -> int | None:
    """
    Pick the likely bead peak.

    Select peaks >= (1 - pe_chl_tol) * max peak pe/chl, and from that
    group keep peaks >= (1 - height_tol) * max peak height in the group.
    Then, working our way up from the lowest peak, if the next peak is < the
    current peak's high cutoff and it's height is >= than the current peak,
    choose it. Continue until we can't choose another peak based on these
    criteria. Assume the high cutoff has been chosen to exclude bead doublets,
    triplets, etc.

    If peaks is None or empty, or if no peaks are chosen, return None.
    """
    if (not peaks) or peaks["found"].empty:
        return None
    found = peaks["found"]
    logger.debug("peak linear pe/chl ratios are %s", found["pe_chl_ratio_linear"].to_list())
    logger.debug("peak heights are are %s", found["height"].to_list())
    pe_chl_cutoff = found["pe_chl_ratio_linear"].max() * (1 - pe_chl_tol)
    pe_chl_select = found["pe_chl_ratio_linear"] >= pe_chl_cutoff
    height_cutoff = found[pe_chl_select]["height"].max() * (1 - height_tol)
    height_select = found["height"] >= height_cutoff
    likely_beads = np.flatnonzero(pe_chl_select & height_select)
    if len(likely_beads) == 0:
        logger.debug("no likely bead peaks found")
        return None
    found = found.iloc[likely_beads]
    locations = found["location"].to_list()
    high_cutoffs = found["high_cutoff"].to_list()
    height = found["height"].to_list()
    logger.debug("likely bead peaks are %s at %s", likely_beads, locations)
    i = 0
    while i < len(locations) - 1:
        # Test if we should choose the next peak
        if (locations[i + 1] < high_cutoffs[i]) and (height[i + 1] >= height[i]):
            logger.debug("selecting next peak %s (loc=%s, height=%s), replacing current peak %s (loc=%s, height=%s, high_cutoff=%s)",
                likely_beads[i + 1], locations[i + 1], height[i + 1], likely_beads[i], locations[i], height[i], high_cutoffs[i])
            i += 1
        else:
            logger.debug("ignoring next peak %s (loc=%s, height=%s), selecting current peak %s (loc=%s, height=%s, high_cutoff=%s)",
                likely_beads[i + 1], locations[i + 1], height[i + 1], likely_beads[i], locations[i], height[i], high_cutoffs[i])
            break
    logger.debug("chosen peak is %s (loc=%s)", likely_beads[i], locations[i])
    return likely_beads[i]


def get_linear_pe_chl(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Get linear PE/CHL ratio for each pe, fsc_small, and chl_small value."""
    df = df.copy()
    df["pe_chl_linear"] = unlog_particles(df["pe"] - df["chl_small"])
    pe_chl_by_pe = df[["pe", "pe_chl_linear"]].groupby("pe")["pe_chl_linear"].median().reset_index()
    pe_chl_by_fsc = df[["fsc_small", "pe_chl_linear"]].groupby("fsc_small")["pe_chl_linear"].median().reset_index()
    pe_chl_by_chl = df[["chl_small", "pe_chl_linear"]].groupby("chl_small")["pe_chl_linear"].median().reset_index()
    return {
        "by_pe": pe_chl_by_pe,
        "by_fsc": pe_chl_by_fsc,
        "by_chl": pe_chl_by_chl
    }


def pe_chl_based_cutoff(
    df: pd.DataFrame,
    col: str,
    window: int=100,
    min_periods: int=80,
    offset: float=3000.0,
    tol=0.2,
    mode: Literal["min", "max"] = "min",
) -> PeChlCutoffResult | None:
    """
    Identify the `col` min or max cutoff based on the maximum PE/CHL ratio
    along `col`.

    Smooth ratio data with a moving average. Find the lowest (mode="min") or
    highest (mode="max") `col` value with PE/CHL ratio >= (1 - `tol`) * max_ratio.
    e.g. if max_ratio is 10.0, tol is 0.2, mode is "min", find the lowest value
    with ratio >= 8.0 (80% of max_ratio). This allows for some tolerance in
    identifying the cutoff in case of noise or a flat peak. This cutoff should
    be used to exclude particles with values below the cutoff since we used 
    mode="min". We add an offset to the cutoff to be sure we don't cut through
    bead particles.

    Returns:
        A PeChlCutoffResult dict. If no cutoff is found, for example if data is
        too sparse to find a clear max ratio after smoothing, returns None.
    """
    if mode not in ("min", "max"):
        raise ValueError(f"mode must be 'min' or 'max', got {mode!r}")

    df = df.copy()
    df["pe_chl_linear_ma"] = df["pe_chl_linear"].rolling(window=window, center=True, min_periods=min_periods).median()
    max_ratio = df["pe_chl_linear_ma"].max()
    logger.debug(f"Max PE/CHL Ratio: {max_ratio}")
    if tol is not None:
        tol_ratio = (1 - tol) * max_ratio
        logger.debug(f"PE/CHL Ratio Threshold with tol={tol}: {tol_ratio}")
    else:
        tol_ratio = max_ratio
    cutoff_rows = df[df["pe_chl_linear_ma"] >= tol_ratio]
    if cutoff_rows.empty:
        logger.debug("No rows found above threshold after rolling median.")
        return None
    if mode == "min":
        cutoff_row = cutoff_rows.sort_values(col).iloc[0]
        cutoff_value = cutoff_row[col] - offset
    else:  # mode == "max"
        cutoff_row = cutoff_rows.sort_values(col, ascending=False).iloc[0]
        cutoff_value = cutoff_row[col] + offset
    logger.debug(f"Cutoff {col}: {cutoff_value} (Row: {cutoff_row.to_dict()})")
    return {
        "cutoff": float(cutoff_value),
        "cutoff_ratio": float(cutoff_row["pe_chl_linear_ma"]),
        "max_ratio": float(max_ratio)
    }


def remove_saturated(df: pd.DataFrame, bins: int=100) -> np.ndarray:
    """Remove saturated particles in fsc_small, chl_small, and pe.

    We define saturated particles as those with values in the top 1 bin of the
    histogram of each channel.

    Return a boolean array indicating which particles are NOT saturated.
    """
    saturated = np.zeros(len(df), dtype=bool)
    for col in ["fsc_small", "chl_small", "pe"]:
        edges = np.histogram_bin_edges(df[col].to_numpy(), bins=bins)
        saturated |= df[col].to_numpy() > edges[-2]
    return ~saturated
