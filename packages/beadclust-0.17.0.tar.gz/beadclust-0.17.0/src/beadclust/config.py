from dataclasses import dataclass, field
from functools import cached_property
from importlib import resources
import logging
from pathlib import Path
from typing import Any

from beadclust import db
from beadclust import filter_params
from jinja2 import Environment, FileSystemLoader, select_autoescape
import pandas as pd
import yaml


logger = logging.getLogger(__name__)


def make_default_filter_params_by_date_dataframe() -> pd.DataFrame:
    return filter_params.make_empty_dataframe().set_index("date")


def read_config(config_file: Path | str, template_data: dict[str, str | int]) -> dict[str, Any]:
    p = Path(config_file)
    env = Environment(
        loader=FileSystemLoader(p.parents[0]),
        autoescape=select_autoescape()
    )
    template = env.get_template(p.name)
    template_text = template.render(template_data)
    config = yaml.safe_load(template_text)
    for date_key in ("start_date", "end_date"):
        if config.get(date_key) is not None:
            try:
                config[date_key] = pd.Timestamp(config[date_key])
            except Exception as e:
                raise ValueError(f"could not parse {date_key}={config[date_key]!r} as a timestamp") from e
    return config


@dataclass
class ClusterConfig:
    """Configuration for bead finding

    Attributes
    ----------
    name :
        Cruise name.
    serial :
        SeaFlow instrument serial number to use for calibrated filtering slopes
        lookup.
    dates :
        Dates from sfl table in sqlite3 SeaFlow database. Use to set plot limits
        and to set earliest filter_plan start_date.
    time_res :
        Pandas time window alias used to bin EVT data, e.g. 1h for 1 hour.
    min_fsc :
        ``fsc_small`` minimum cutoff to use when identifying beads clusters.
    min_pe :
        ``pe`` minimum cutoff to use when identifying beads clusters.
    min_chl :
        ``chl`` minimum cutoff to use when identifying beads clusters.
    pe_chl_cutoff :
        ``pe`` to ``chl_small`` ratio below which particles will be removed.
        Used to broadly discriminate beads from crocosphaera.
    peak_finder_params :
        Keyword arguments to find_bead_peaks(), to find the first bead peak
        in OPP PE data in original log form.
    peak_picker_params:
        Keyword arguments to pick_peak(), to pick the best peak.
    pe_chl_based_cutoff_fsc_offset:
        Offset for FSC when calculating PE/CHL-based minimum cutoff.
    pe_chl_based_cutoff_fsc_tol:
        Tolerance for FSC when calculating PE/CHL-based minimum cutoff.
    pe_chl_based_cutoff_pe_offset:
        Offset for PE when calculating PE/CHL-based minimum cutoff.
    pe_chl_based_cutoff_pe_tol:
        Tolerance for PE when calculating PE/CHL-based minimum cutoff.
    pe_chl_based_cutoff_chl_offset:
        Offset for CHL when calculating PE/CHL-based maximum cutoff.
    pe_chl_based_cutoff_chl_tol:
        Tolerance for CHL when calculating PE/CHL-based maximum cutoff.
    sat_bins:
        Number of bins to use when determining cutoff for removing
        saturated particles in FSC, PE, and CHL channels.
    peak_syn_filter_offset:
        How far above the first peak to begin looking for additional peaks with
        data below excluded.
    pe_chl_frac_med_cutoff:
        Fraction of the median PE/CHL ratio below which a timepoint is
        considered low quality.
    pe_diff_cutoff:
        Maximum difference between the detected PE peak location and the
        median of the fsc_pe cluster to consider the peak valid.
    min_cluster_frac :
        Minimum fraction of points passed to HDBSCAN that should be in the
        cluster.
    filtering_width :
        Tolerance for alignment equality between D1 and D2.
    filtering_offset:
        Additional D1, D2 offset to apply during round 2 filtering to make sure
        we capture enough OPP for bead detection.
    origin_align :
        Adjust for difference in sensitivity between D1 and D2 by median
        difference when selecting aligned particles.
    filter_params_by_date :
        Filtering parameters indexed by time bin timestamp. Will be used to
        filter EVT data using `filter.mark_focused` rather than
        `filter.roughfilter`.
    spread_cutoff :
        Cutoff for the `fsc_small` cluster range that identifies "good"
        cluster results.
    cluster_log :
        Cluster with raw log SeaFlow data. Otherwise cluster unlogged data.

    Properties:
    ----------
    instrument_slopes :
        SeaFlow instrument-calibrated filtering slopes for the instrument
        identified by `serial`. File reads are cached.
    """
    name: str = field(default="")
    serial: str = field(default="")
    dates: pd.DataFrame | None = field(default_factory=pd.DataFrame)
    time_res: str = field(default="1h")
    evt_file: str = field(default="")
    db_file: str = field(default="")
    out_dir: str = field(default="")
    start_date: pd.Timestamp | None = field(default=None)
    end_date: pd.Timestamp | None = field(default=None)
    workers: int = field(default=1)
    min_fsc: float = field(default=0)
    min_pe: float = field(default=0)
    min_chl: float = field(default=0)
    pe_chl_cutoff: float = field(default=0.9)
    sat_bins: int = field(default=100)
    peak_finder_params: dict[str, Any] = field(default_factory=dict)
    peak_picker_params: dict[str, Any] = field(default_factory=dict)
    pe_chl_based_cutoff_fsc_offset: float = field(default=3000.0)
    pe_chl_based_cutoff_fsc_tol: float = field(default=0.2)
    pe_chl_based_cutoff_pe_offset: float = field(default=3000.0)
    pe_chl_based_cutoff_pe_tol: float = field(default=0.2)
    pe_chl_based_cutoff_chl_offset: float = field(default=0.0)
    pe_chl_based_cutoff_chl_tol: float = field(default=0.75)
    peak_syn_filter_offset: float = field(default=10000)
    pe_chl_frac_med_cutoff: float = field(default=0.25)
    pe_diff_cutoff: float = field(default=2000)
    max_cluster_input: int = field(default=2000)
    min_cluster_frac: float = field(default=0.33)
    filtering_width: float = field(default=10000)
    filtering_offset: float = field(default=3000)
    origin_align: bool = field(default=True)
    filter_params_by_date: pd.DataFrame | None = field(default_factory=make_default_filter_params_by_date_dataframe)
    db_filter_params: pd.DataFrame | None = field(default_factory=pd.DataFrame)
    spread_cutoff: float = field(default=5000)
    cluster_log: bool = field(default=True)

    @classmethod
    def from_config_file(cls, config_file: Path | str, template_data: dict[str, str | int] | None=None, serial: str="", dates: pd.DataFrame | None=None, db_filter_params: pd.DataFrame | None=None) -> "ClusterConfig":
        # Read config file and fill in template variables if provided
        if template_data is None:
            template_data = {}
        config = read_config(config_file, template_data)

        # Determine serial: function argument takes precedence, then config
        # file value, then DB lookup
        db_file = config.get("db_file", "")
        if not serial:
            config_serial = config.get("serial", "")
            if config_serial:
                serial = str(config_serial)
        if not serial:
            logger.info("serial not provided, reading from db file")
            try:
                serial = db.get_serial(db_file)
            except Exception as e:
                logger.warning(f"could not read serial from db file: {e}")
                raise ValueError("serial not provided and could not be read from db file") from e
        if db_filter_params is None and db_file:
            logger.info("db_filter_params not provided, reading from db file")
            db_filter_params = db.get_filter_params(db_file)
            if len(db_filter_params) == 0:
                logger.info("no filter params found in db file")
                db_filter_params = None
        if dates is None:
            logger.info("dates not provided, reading from db file")
            try:
                dates = db.get_db_dates(db_file)
            except Exception as e:
                logger.warning(f"could not read dates from db file: {e}")
                raise ValueError("dates not provided and could not be read from db file") from e
            logger.info("DB date range: %s to %s", dates["date"].min(), dates["date"].max())

        # Create cluster config from config file dict
        cconf = cls(
            name=config["name"],
            serial=serial,
            dates=dates,
            time_res=config.get("time_resolution", "1h"),
            evt_file=config["evt_file"],
            db_file=db_file,
            out_dir=config["out_dir"],
            start_date=config.get("start_date"),
            end_date=config.get("end_date"),
            workers=config.get("workers", 1),
            min_fsc=config.get("min_fsc", 0),
            min_pe=config.get("min_pe", 0),
            min_chl=config.get("min_chl", 0),
            pe_chl_cutoff=config.get("pe_chl_cutoff", 0.9),
            sat_bins=config.get("sat_bins", 100),
            peak_finder_params={
                "peak_width": [config.get("peak_width_min", 2), config.get("peak_width_max", 30)],
                "bin_size": config.get("peak_bin_size", 250),
                "ma_window": config.get("peak_ma_window", 8),
                "peak_height_frac_max": config.get("peak_height_frac_max", 0.8),
                "cutoff_scalar": config.get("peak_cutoff_scalar", 0.5)
            },
            peak_picker_params={
                "pe_chl_tol": config.get("peak_picker_pe_chl_tol", 0.3),
                "height_tol": config.get("peak_picker_height_tol", 0.5)
            },
            pe_chl_based_cutoff_fsc_offset=config.get("pe_chl_based_cutoff_fsc_offset", 3000.0),
            pe_chl_based_cutoff_fsc_tol=config.get("pe_chl_based_cutoff_fsc_tol", 0.2),
            pe_chl_based_cutoff_pe_offset=config.get("pe_chl_based_cutoff_pe_offset", 3000.0),
            pe_chl_based_cutoff_pe_tol=config.get("pe_chl_based_cutoff_pe_tol", 0.2),
            pe_chl_based_cutoff_chl_offset=config.get("pe_chl_based_cutoff_chl_offset", 0.0),
            pe_chl_based_cutoff_chl_tol=config.get("pe_chl_based_cutoff_chl_tol", 0.75),
            peak_syn_filter_offset=config.get("peak_syn_filter_offset", 10000),
            filtering_width=config.get("filtering_width", 10000),
            filtering_offset=config.get("filtering_offset", 3000),
            origin_align=config.get("origin_align", True),
            max_cluster_input=config.get("max_cluster_input", 2000),
            min_cluster_frac=config.get("min_cluster_frac", 0.33),
            spread_cutoff=config.get("spread_cutoff", 5000),
            pe_diff_cutoff=config.get("pe_diff_cutoff", 2000),
            pe_chl_frac_med_cutoff=config.get("pe_chl_frac_med_cutoff", 0.25),
            db_filter_params=db_filter_params,
            cluster_log=config.get("cluster_log", True),
        )
        return cconf

    @cached_property
    def instrument_slopes(self) -> pd.Series:
        try:
            slopes = get_filter_calibration_slopes(self.serial)
        except ValueError as e:
            logger.warning(e)
            slopes = pd.Series([])
        return slopes

    def __str__(self) -> str:
        db_fp_rows = len(self.db_filter_params) if self.db_filter_params is not None else 0
        fp_by_date_rows = len(self.filter_params_by_date) if self.filter_params_by_date is not None else 0
        fields = []
        for f in self.__dataclass_fields__:
            if f == "db_filter_params":
                fields.append(f"db_filter_params=<{db_fp_rows} rows>")
            elif f == "filter_params_by_date":
                fields.append(f"filter_params_by_date=<{fp_by_date_rows} rows>")
            else:
                fields.append(f"{f}={getattr(self, f)!r}")
        return "ClusterConfig(\n" + ",\n".join(fields) + "\n)"


def get_filter_calibration_slopes(serial: str) -> pd.Series:
    logger.debug("reading filter calibration slopes file")
    with resources.files("beadclust").joinpath("data/seaflow_filter_slopes.csv").open("r", encoding="utf-8") as f:
        all_slopes = pd.read_csv(f)
    all_slopes["ins"] = all_slopes["ins"].astype(str)
    found = all_slopes[all_slopes["ins"] == serial]
    if len(found) == 0:
        raise ValueError(f"serial='{serial}' not found")
    if len(found) > 1:
        raise ValueError(f"duplicate slope entries for serial={serial}")
    slopes = found.squeeze()
    assert isinstance(slopes, pd.Series)
    return slopes
