"""
Analyzer - Semantic analysis as a separate phase

This module performs semantic analysis on a fully-expanded, normalized AST.
It walks the AST and raises errors for structural / semantic problems,
providing earlier and clearer diagnostics than the evaluator.

Phase 2: structural checks for all inline special forms migrated out of _lEval.
Phase 3: arity / type checks migrated out of primitives.
"""
from __future__ import annotations

from typing import Any

from pythonslisp.ltk.EnvironmentBase import EnvironmentBase
from pythonslisp.AST import LSymbol, LPrimitive
from pythonslisp.Exceptions import ( LAnalysisError,      # noqa: F401 (re-exported)
                                         LRuntimeError,
                                         LRuntimePrimError )


class Analyzer:
   """Performs semantic analysis on a fully-expanded, normalized AST."""

   @staticmethod
   def analyze( env: EnvironmentBase, sexpr: Any ) -> None:
      """
      Recursively walk sexpr, raising on structural / semantic problems.

      Checks are pure AST-structure checks (no evaluation).  Runtime checks
      (e.g., whether a variable is bound) remain in _lEval.
      """
      if not isinstance(sexpr, list) or len(sexpr) == 0:
         return

      head = sexpr[0]
      args = sexpr[1:]

      if not isinstance(head, LSymbol):
         # Compound head — recurse into all elements
         for elt in sexpr:
            Analyzer.analyze(env, elt)
         return

      name = head.name

      # ---------- QUOTE --------------------------------------------------
      if name == 'QUOTE':
         if len(args) != 1:
            raise LRuntimePrimError(env.lookup('QUOTE'), '1 argument expected.')
         return  # Don't recurse into quoted data

      # ---------- BACKQUOTE -----------------------------------------------
      if name == 'BACKQUOTE':
         if len(args) != 1:
            raise LRuntimePrimError(env.lookup('BACKQUOTE'), '1 argument expected.')
         return  # Don't recurse into backquote templates

      # ---------- IF -------------------------------------------------------
      if name == 'IF':
         numArgs = len(args)
         if not (2 <= numArgs <= 3):
            raise LRuntimePrimError(env.lookup('IF'), '2 or 3 arguments expected.')
         for elt in args:
            Analyzer.analyze(env, elt)
         return

      # ---------- LET / LET* ----------------------------------------------
      if name in ('LET', 'LET*'):
         Analyzer._analyzeLet(env, name, args)
         return

      # ---------- PROGN ---------------------------------------------------
      if name == 'PROGN':
         for elt in args:
            Analyzer.analyze(env, elt)
         return

      # ---------- SETQ ----------------------------------------------------
      if name == 'SETQ':
         Analyzer._analyzeSetq(env, args)
         return

      # ---------- BLOCK ----------------------------------------------------
      if name == 'BLOCK':
         Analyzer._analyzeBlock(env, args)
         return

      # ---------- RETURN-FROM ----------------------------------------------
      if name == 'RETURN-FROM':
         Analyzer._analyzeReturnFrom(env, args)
         return

      # ---------- RETURN ---------------------------------------------------
      if name == 'RETURN':
         if len(args) > 1:
            raise LRuntimeError('return: 0 or 1 arguments expected.')
         if len(args) == 1:
            Analyzer.analyze(env, args[0])
         return

      # ---------- CATCH ----------------------------------------------------
      if name == 'CATCH':
         if len(args) < 1:
            raise LRuntimeError('catch: at least 1 argument (tag) expected.')
         for elt in args:
            Analyzer.analyze(env, elt)
         return

      # ---------- COND -----------------------------------------------------
      if name == 'COND':
         Analyzer._analyzeCond(env, args)
         return

      # ---------- CASE -----------------------------------------------------
      if name == 'CASE':
         Analyzer._analyzeCase(env, args)
         return

      # ---------- LAMBDA --------------------------------------------------
      if name == 'LAMBDA':
         if len(args) < 1:
            raise LRuntimePrimError(env.lookup('LAMBDA'), '1 or more arguments expected.')
         if not isinstance(args[0], list):
            raise LRuntimePrimError(env.lookup('LAMBDA'), 'First argument expected to be a list of params.')
         for bodyForm in args[1:]:
            Analyzer.analyze(env, bodyForm)
         return

      # ---------- DEFMACRO ------------------------------------------------
      if name == 'DEFMACRO':
         if len(args) < 2:
            raise LRuntimePrimError(env.lookup('DEFMACRO'), '3 or more arguments expected.')
         if not isinstance(args[0], LSymbol):
            raise LRuntimePrimError(env.lookup('DEFMACRO'), 'Argument 1 expected to be a symbol.')
         if not isinstance(args[1], list):
            raise LRuntimePrimError(env.lookup('DEFMACRO'), 'Argument 2 expected to be a list of params.')
         funcBody = list(args[2:])
         if len(funcBody) < 1:
            raise LRuntimePrimError(env.lookup('DEFMACRO'), 'At least one body expression expected.')
         if isinstance(funcBody[0], str):
            funcBody = funcBody[1:]
         if len(funcBody) < 1:
            raise LRuntimePrimError(env.lookup('DEFMACRO'), 'At least one body expression expected after docstring.')
         return

      # ---------- MAKE-DICT ------------------------------------------------
      if name == 'MAKE-DICT':
         Analyzer._analyzeMakeDict(env, args)
         return

      # ---------- Everything else (regular calls, unknown special forms) ---
      # Generic arity check for primitives that carry arity metadata.
      if isinstance(head, LSymbol):
         try:
            callableObj = env.lookup(head.name)
            if isinstance(callableObj, LPrimitive):
               if callableObj.arity_msg:
                  numArgs = len(args)
                  tooFew  = numArgs < callableObj.min_args
                  tooMany = callableObj.max_args is not None and numArgs > callableObj.max_args
                  if tooFew or tooMany:
                     raise LRuntimePrimError(callableObj, callableObj.arity_msg)
               if not callableObj.preEvalArgs:
                  # Special-form primitives receive un-evaluated args whose
                  # structure is defined by the form itself (e.g. make-dict's
                  # (key val) pairs).  The analyzer cannot safely recurse into
                  # them, so delegate sub-expression analysis to the evaluator.
                  return
         except KeyError:
            pass
      for elt in sexpr:
         Analyzer.analyze(env, elt)

   # -----------------------------------------------------------------------

   @staticmethod
   def _analyzeLet( env: EnvironmentBase, name: str, args: list ) -> None:
      """Structural checks for (let ...) and (let* ...) forms."""
      if len(args) < 1:
         raise LRuntimePrimError(env.lookup(name), '2 or more arguments expected.')

      vardefs = args[0]
      body    = args[1:]

      if not isinstance(vardefs, list):
         raise LRuntimePrimError(env.lookup(name),
               'The first argument to let expected to be a list of variable initializations.')

      for varSpec in vardefs:
         if isinstance(varSpec, LSymbol):
            pass  # bare symbol — valid, no init form
         elif isinstance(varSpec, list):
            varSpecLen = len(varSpec)
            if varSpecLen == 1:
               if not isinstance(varSpec[0], LSymbol):
                  raise LRuntimePrimError(env.lookup(name),
                        'First element of a variable initializer pair expected to be a symbol.')
            elif varSpecLen == 2:
               varName, initForm = varSpec
               if not isinstance(varName, LSymbol):
                  raise LRuntimePrimError(env.lookup(name),
                        'First element of a variable initializer pair expected to be a symbol.')
               Analyzer.analyze(env, initForm)
            else:
               raise LRuntimePrimError(env.lookup(name),
                     'Variable initializer spec expected to be 1 or 2 elements long.')
         else:
            raise LRuntimePrimError(env.lookup(name),
                  'Variable initializer spec expected to be a symbol or a list.')

      for bodyForm in body:
         Analyzer.analyze(env, bodyForm)

   @staticmethod
   def _analyzeSetq( env: EnvironmentBase, args: list ) -> None:
      """Structural checks for (setq ...) forms."""
      numArgs = len(args)
      if numArgs == 0:
         raise LRuntimePrimError(env.lookup('SETQ'), 'At least 2 arguments expected.')
      if (numArgs % 2) != 0:
         raise LRuntimePrimError(env.lookup('SETQ'),
               f'An even number of arguments is expected.  Received {numArgs}.')
      for i in range(0, numArgs, 2):
         lval = args[i]
         rval = args[i + 1]
         if not isinstance(lval, LSymbol):
            raise LRuntimePrimError(env.lookup('SETQ'), 'First of setf pair must be a symbol.')
         Analyzer.analyze(env, rval)

   @staticmethod
   def _is_nil_val( val ) -> bool:
      """True iff val is the Lisp NIL (empty list)."""
      return isinstance(val, list) and not val

   @staticmethod
   def _analyzeBlock( env: EnvironmentBase, args: list ) -> None:
      """Structural checks for (block ...) forms."""
      if len(args) < 1:
         raise LRuntimeError('block: at least 1 argument (name) expected.')
      if not (isinstance(args[0], LSymbol) or Analyzer._is_nil_val(args[0])):
         raise LRuntimeError('block: name must be a symbol.')
      for bodyForm in args[1:]:
         Analyzer.analyze(env, bodyForm)

   @staticmethod
   def _analyzeReturnFrom( env: EnvironmentBase, args: list ) -> None:
      """Structural checks for (return-from ...) forms."""
      if len(args) < 1 or len(args) > 2:
         raise LRuntimeError('return-from: 1 or 2 arguments expected.')
      if not (isinstance(args[0], LSymbol) or Analyzer._is_nil_val(args[0])):
         raise LRuntimeError('return-from: name must be a symbol.')
      if len(args) == 2:
         Analyzer.analyze(env, args[1])

   @staticmethod
   def _analyzeCond( env: EnvironmentBase, args: list ) -> None:
      """Structural checks for (cond ...) forms."""
      if len(args) < 1:
         raise LRuntimePrimError(env.lookup('COND'), '1 or more arguments expected.')
      for i, clause in enumerate(args):
         if not isinstance(clause, list) or len(clause) == 0:
            raise LRuntimePrimError(env.lookup('COND'),
                  f'Entry {i+1} must be a non-empty list.')
         Analyzer.analyze(env, clause[0])
         for bodyForm in clause[1:]:
            Analyzer.analyze(env, bodyForm)

   @staticmethod
   def _analyzeCase( env: EnvironmentBase, args: list ) -> None:
      """Structural checks for (case ...) forms."""
      if len(args) < 2:
         raise LRuntimePrimError(env.lookup('CASE'), '2 or more arguments expected.')
      Analyzer.analyze(env, args[0])
      for i, clause in enumerate(args[1:]):
         if not isinstance(clause, list) or len(clause) == 0:
            raise LRuntimePrimError(env.lookup('CASE'),
                  f'Entry {i+1} must be a non-empty list.')
         Analyzer.analyze(env, clause[0])
         for bodyForm in clause[1:]:
            Analyzer.analyze(env, bodyForm)

   @staticmethod
   def _analyzeMakeDict( env: EnvironmentBase, args: list ) -> None:
      """Structural checks for (make-dict ...) forms."""
      requiredKeyType = None
      for entryNum, pair in enumerate(args):
         if not isinstance(pair, list) or len(pair) != 2:
            raise LRuntimePrimError(env.lookup('MAKE-DICT'),
                  f'Entry {entryNum + 1} does not contain a (key value) pair.')
         key, expr = pair
         if isinstance(key, LSymbol):
            effectiveType = str
         elif isinstance(key, (int, float, str)):
            effectiveType = type(key)
         else:
            raise LRuntimePrimError(env.lookup('MAKE-DICT'),
                  f'Entry {entryNum + 1} has an invalid key type.')
         if requiredKeyType is None:
            requiredKeyType = effectiveType
         elif effectiveType != requiredKeyType:
            raise LRuntimePrimError(env.lookup('MAKE-DICT'),
                  f'All keys in a map must be the same type. '
                  f'Entry {entryNum + 1} is {effectiveType.__name__}, '
                  f'expected {requiredKeyType.__name__}.')
         Analyzer.analyze(env, expr)
