from __future__ import annotations
import functools
from typing import Any, Callable

from pythonslisp.ltk.EnvironmentBase import EnvironmentBase
from pythonslisp.AST import LSymbol
from pythonslisp.AST import L_T, L_NIL
from pythonslisp.Context import Context
from pythonslisp.Exceptions import LRuntimePrimError
from pythonslisp.extensions import LambdaListMode


# ── Shared keyword-argument helpers ──────────────────────────────────────────

def _is_nil_val( val ) -> bool:
   """True iff val is the Lisp NIL (empty list)."""
   return isinstance( val, list ) and not val


def _extract_key( ctx: Any, env: Environment, key_fn: Any, item: Any ) -> Any:
   """Apply the :key function to item, or return item unchanged if key_fn is NIL."""
   if _is_nil_val( key_fn ):
      return item
   return ctx.lApply( ctx, env, key_fn, [item] )


def _apply_test( ctx: Any, env: Environment, test_fn: Any, item: Any, cell_key: Any ) -> bool:
   """Call test_fn(item, cell_key); return True iff the result is truthy (non-NIL)."""
   return ctx.lApply( ctx, env, test_fn, [item, cell_key] ) != L_NIL


def _validate_bounds( start: Any, end: Any, seqlen: int, fn: Any ) -> tuple[int, int]:
   """Validate :start and :end; return (start_n, end_n) as concrete ints."""
   if not isinstance( start, int ) or isinstance( start, bool ):
      raise LRuntimePrimError( fn, ':start must be a non-negative integer.' )
   if start < 0:
      raise LRuntimePrimError( fn, ':start must be non-negative.' )
   if _is_nil_val( end ):
      return start, seqlen
   if not isinstance( end, int ) or isinstance( end, bool ):
      raise LRuntimePrimError( fn, ':end must be a non-negative integer or NIL.' )
   if end < 0 or end > seqlen:
      raise LRuntimePrimError( fn, f':end {end} out of range for sequence of length {seqlen}.' )
   if end < start:
      raise LRuntimePrimError( fn, f':end {end} must be >= :start {start}.' )
   return start, end


def _validate_count( count: Any, fn: Any ):
   """Validate :count; return None for unlimited, else the int limit."""
   if _is_nil_val( count ):
      return None
   if not isinstance( count, int ) or isinstance( count, bool ):
      raise LRuntimePrimError( fn, ':count must be a non-negative integer or NIL.' )
   if count < 0:
      raise LRuntimePrimError( fn, ':count must be non-negative.' )
   return count


# ── Primitive registration ────────────────────────────────────────────────────

def register( primitive ) -> None:

   # ── Existing non-keyword primitives ────────────────────────────────────────

   @primitive( 'make-dict', '((key1 val1) (key2 val2) ...)',
               mode=LambdaListMode.DOC_ONLY, preEvalArgs=False )
   def LP_make_dict( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Constructs and returns a dict of key-value pairs."""
      theMapping = dict()
      for key, expr in args:
         if isinstance(key, LSymbol):
            key = key.name
         theMapping[key] = ctx.lEval(env, expr)
      return theMapping

   @primitive( 'car', '(list)' )
   def LP_car( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the first item in a list."""
      theList = args[0]

      if not isinstance(theList, list):
         raise LRuntimePrimError( LP_car, '1st argument expected to be a list.' )

      try:
         return theList[0]
      except IndexError:
         return L_NIL

   @primitive( 'cdr', '(list)' )
   def LP_cdr( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of the list minus the first element."""
      theList = args[0]

      if not isinstance(theList, list):
         raise LRuntimePrimError( LP_cdr, '1st argument expected to be a list.' )

      return theList[1:]

   @primitive( 'cons', '(obj list)' )
   def LP_cons( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of list with obj inserted into the front of the copy."""
      obj, consList = args

      if not isinstance(consList, list):
         raise LRuntimePrimError( LP_cons, '2nd argument expected to be a list.' )

      return [ obj, *consList ]

   @primitive( 'push!', '(list value)' )
   def LP_push( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Pushes a value onto the back of a list."""
      alist, value = args

      if not isinstance(alist, list):
         raise LRuntimePrimError( LP_push, '1st argument expected to be a list.' )
      alist.append( value )
      return alist

   @primitive( 'pop!', '(list)' )
   def LP_pop( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Pops and returns the last value of a list."""
      alist = args[0]

      if not isinstance(alist, list):
         raise LRuntimePrimError( LP_pop, '1st argument expected to be a list.' )

      try:
         value = alist.pop()
      except IndexError:
         raise LRuntimePrimError( LP_pop, 'Invalid argument.' )
      return value

   @primitive( 'at', '(keyOrIndex dictListOrStr)' )
   def LP_at( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the value at a specified index of a list or string,
      or specified key of a map."""
      key, keyed = args

      if not isinstance(keyed, (list, dict, str) ):
         raise LRuntimePrimError( LP_at, 'Invalid argument.  List, Dict, or String expected.' )

      if isinstance( key, LSymbol ):
         key = key.name

      try:
         return keyed[ key ]
      except ( KeyError, IndexError, TypeError ):
         raise LRuntimePrimError( LP_at, 'Invalid argument key/index.' )

   @primitive( 'at-set', '(keyOrIndex dictListOrStr newValue)' )
   def LP_atSet( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Sets the value at a specified index of a list,
      or specified key of a map.  Returns newValue."""
      key, keyed, newValue = args

      if not isinstance(keyed, (list, dict)):
         raise LRuntimePrimError( LP_atSet, 'Invalid argument.  List or Dict expected.' )

      if isinstance( key, LSymbol ):
         key = key.name

      try:
         keyed[ key ] = newValue
      except ( KeyError, IndexError, TypeError ):
         raise LRuntimePrimError( LP_atSet, 'Invalid argument key/index.' )

      return newValue

   @primitive( 'at-delete', '(keyOrIndex dictOrList)' )
   def LP_atDelete( ctx: Context, env: Environment, args: list[Any] ) -> bool:
      """Deletes the key-value pair from a map or list specified by keyOrIndex."""
      key, keyed = args

      if not isinstance( keyed, (list, dict) ):
         raise LRuntimePrimError( LP_atDelete, "Argument 2 expected to be a list or dict." )

      try:
         del keyed[key]
      except ( IndexError, KeyError, TypeError ):
         raise LRuntimePrimError( LP_atDelete, "Bad index or key into collection." )

      return L_T

   @primitive( 'at-insert', '(index list newItem)' )
   def LP_atInsert( ctx: Context, env: Environment, args: list[Any] ) -> bool:
      """Inserts newItem into list at the position specified by index.  Returns newItem."""
      index, lst, newItem = args

      if not isinstance(index, int):
         raise LRuntimePrimError( LP_atInsert, "Argument 1 expected to be an integer index." )

      if not isinstance( lst, list ):
         raise LRuntimePrimError( LP_atInsert, "Argument 2 expected to be a list." )

      lst.insert( index, newItem )
      return newItem

   @primitive( 'append', '(&rest lists)' )
   def LP_append( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a new list with the contents of the argument lists merged.  Order is retained.
(append) = NIL; (append lst) = lst; 2+ args: all must be proper lists."""
      if len(args) == 0:
         return L_NIL
      if len(args) == 1:
         return args[0]
      resultList = list( )
      for lst in args:
         if not isinstance( lst, list ):
            raise LRuntimePrimError( LP_append, 'Invalid argument.' )
         resultList.extend( lst )
      return resultList

   @primitive( 'hasValue?', '(value listOrDict)' )
   def LP_hasValue( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns t if the list/map contains value otherwise nil."""
      aVal, keyed = args

      if isinstance(keyed, list):
         pass
      elif isinstance(keyed, dict):
         keyed = keyed.values()
      else:
         raise LRuntimePrimError( LP_hasValue, 'Invalid argument.  Argument 2 expected to be a list or dict.')

      return L_T if aVal in keyed else L_NIL

   @primitive( 'update!', '(dict1 dict2)' )
   def LP_update( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Updates dict1's data with dict2's."""
      dict1, dict2 = args

      if not isinstance( dict1, dict ):
         raise LRuntimePrimError( LP_update, 'Argument 1 expected to be a dict.' )

      if not isinstance( dict2, dict ):
         raise LRuntimePrimError( LP_update, 'Argument 2 expected to be a dict.' )

      dict1.update( dict2 )
      return dict1

   @primitive( 'hasKey?', '(key dict)' )
   def LP_hasKey( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns t if the key is in the map otherwise nil."""
      aKey, aMap = args

      if not isinstance(aMap, dict):
         raise LRuntimePrimError( LP_hasKey, 'Invalid argument 2.  Dict expected.')

      if isinstance( aKey, LSymbol ):
         aKey = aKey.name

      return L_T if aKey in aMap else L_NIL

   @primitive( 'sort', '(sequence predicate &key (key nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_sort( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of the list sorted by predicate (a two-arg less-than test).
The optional :key function extracts the comparison key from each element."""
      seq      = env.lookup( 'SEQUENCE' )
      pred     = env.lookup( 'PREDICATE' )
      key_fn   = env.lookup( 'KEY' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_sort, 'Argument 1 expected to be a list.' )

      def _cmp( a, b ):
         ka = _extract_key( ctx, env, key_fn, a )
         kb = _extract_key( ctx, env, key_fn, b )
         if ctx.lApply( ctx, env, pred, [ka, kb] ) != L_NIL:
            return -1
         if ctx.lApply( ctx, env, pred, [kb, ka] ) != L_NIL:
            return 1
         return 0

      try:
         return sorted( seq, key=functools.cmp_to_key(_cmp) )
      except TypeError:
         raise LRuntimePrimError( LP_sort, 'Cannot sort a list with incomparable types.' )

   @primitive( 'length', '(sequence)' )
   def LP_length( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the number of elements in a list, string, or map."""
      arg = args[0]
      if isinstance(arg, (list, str, dict)):
         return len(arg)
      raise LRuntimePrimError( LP_length, 'Argument 1 must be a List, String, or Map.' )

   @primitive( 'subseq', '(sequence start &optional end)' )
   def LP_subseq( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a subsequence of a list or string from start (inclusive) to end (exclusive).
If end is not provided, returns from start to the end of the sequence."""
      seq = args[0]
      start = args[1]
      end = args[2] if len(args) > 2 else None

      if not isinstance(seq, (list, str)):
         raise LRuntimePrimError( LP_subseq, '1st argument must be a list or string.' )
      if not isinstance(start, int) or isinstance(start, bool):
         raise LRuntimePrimError( LP_subseq, '2nd argument must be an integer.' )
      if end is not None and (not isinstance(end, int) or isinstance(end, bool)):
         raise LRuntimePrimError( LP_subseq, '3rd argument must be an integer.' )

      seqLen = len(seq)
      if start < 0:
         raise LRuntimePrimError( LP_subseq, 'Start index must be non-negative.' )
      if start > seqLen:
         raise LRuntimePrimError( LP_subseq, 'Start index out of bounds.' )
      if end is not None:
         if end < 0:
            raise LRuntimePrimError( LP_subseq, 'End index must be non-negative.' )
         if end > seqLen:
            raise LRuntimePrimError( LP_subseq, 'End index out of bounds.' )
         if end < start:
            raise LRuntimePrimError( LP_subseq, 'End index must be >= start index.' )
         return seq[start:end]

      return seq[start:]

   # ── CL sequence functions with full keyword-argument support ───────────────

   @primitive( 'member', '(item list &key (test eql) (key nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_member( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the tail of list beginning with the first element whose :key
satisfies :test when compared to item.  Returns NIL if no match is found.
Default :test is eql.  Default :key is identity (NIL)."""
      item    = env.lookup( 'ITEM' )
      lst     = env.lookup( 'LIST' )
      test_fn = env.lookup( 'TEST' )
      key_fn  = env.lookup( 'KEY' )
      if not isinstance( lst, list ):
         raise LRuntimePrimError( LP_member, '2nd argument must be a list.' )
      for i in range( len(lst) ):
         if _apply_test( ctx, env, test_fn, item, _extract_key( ctx, env, key_fn, lst[i] ) ):
            return lst[i:]
      return L_NIL

   @primitive( 'assoc', '(item alist &key (test eql) (key nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_assoc( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the first pair in alist whose car (optionally extracted via :key)
satisfies :test when compared to item.  Non-cons elements in alist are skipped.
Returns NIL if no match is found.  Default :test is eql.  Default :key is identity."""
      item    = env.lookup( 'ITEM' )
      alist   = env.lookup( 'ALIST' )
      test_fn = env.lookup( 'TEST' )
      key_fn  = env.lookup( 'KEY' )
      if not isinstance( alist, list ):
         raise LRuntimePrimError( LP_assoc, '2nd argument must be a list.' )
      for pair in alist:
         if isinstance( pair, list ) and pair:
            if _apply_test( ctx, env, test_fn, item, _extract_key( ctx, env, key_fn, pair[0] ) ):
               return pair
      return L_NIL

   @primitive( 'find', '(item sequence &key (test eql) (key nil) (from-end nil) (start 0) (end nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_find( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the first element of sequence (bounded by :start/:end) whose :key
satisfies :test when compared to item.  If :from-end is true, searches right
to left and returns the rightmost match.  Returns NIL if not found."""
      item     = env.lookup( 'ITEM' )
      seq      = env.lookup( 'SEQUENCE' )
      test_fn  = env.lookup( 'TEST' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_find, '2nd argument must be a list.' )
      start_n, end_n = _validate_bounds( start, end, len(seq), LP_find )
      indices = range( start_n, end_n )
      if not _is_nil_val( from_end ):
         indices = reversed( range( start_n, end_n ) )
      for i in indices:
         if _apply_test( ctx, env, test_fn, item, _extract_key( ctx, env, key_fn, seq[i] ) ):
            return seq[i]
      return L_NIL

   @primitive( 'find-if', '(pred sequence &key (key nil) (from-end nil) (start 0) (end nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_find_if( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the first element of sequence (bounded by :start/:end) for which
pred returns true when applied to the element's :key.  If :from-end is true,
returns the rightmost such element.  Returns NIL if none found."""
      pred     = env.lookup( 'PRED' )
      seq      = env.lookup( 'SEQUENCE' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_find_if, '2nd argument must be a list.' )
      start_n, end_n = _validate_bounds( start, end, len(seq), LP_find_if )
      indices = range( start_n, end_n )
      if not _is_nil_val( from_end ):
         indices = reversed( range( start_n, end_n ) )
      for i in indices:
         cell_key = _extract_key( ctx, env, key_fn, seq[i] )
         if ctx.lApply( ctx, env, pred, [cell_key] ) != L_NIL:
            return seq[i]
      return L_NIL

   @primitive( 'position', '(item sequence &key (test eql) (key nil) (from-end nil) (start 0) (end nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_position( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the index in sequence of the first element whose :key satisfies
:test when compared to item.  If :from-end is true, returns the index of the
rightmost such element.  Returns NIL if not found."""
      item     = env.lookup( 'ITEM' )
      seq      = env.lookup( 'SEQUENCE' )
      test_fn  = env.lookup( 'TEST' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_position, '2nd argument must be a list.' )
      start_n, end_n = _validate_bounds( start, end, len(seq), LP_position )
      indices = range( start_n, end_n )
      if not _is_nil_val( from_end ):
         indices = reversed( range( start_n, end_n ) )
      for i in indices:
         if _apply_test( ctx, env, test_fn, item, _extract_key( ctx, env, key_fn, seq[i] ) ):
            return i
      return L_NIL

   @primitive( 'position-if', '(pred sequence &key (key nil) (from-end nil) (start 0) (end nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_position_if( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the index in sequence of the first element for which pred returns
true when applied to the element's :key.  If :from-end is true, returns the
index of the rightmost such element.  Returns NIL if none found."""
      pred     = env.lookup( 'PRED' )
      seq      = env.lookup( 'SEQUENCE' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_position_if, '2nd argument must be a list.' )
      start_n, end_n = _validate_bounds( start, end, len(seq), LP_position_if )
      indices = range( start_n, end_n )
      if not _is_nil_val( from_end ):
         indices = reversed( range( start_n, end_n ) )
      for i in indices:
         cell_key = _extract_key( ctx, env, key_fn, seq[i] )
         if ctx.lApply( ctx, env, pred, [cell_key] ) != L_NIL:
            return i
      return L_NIL

   @primitive( 'count', '(item sequence &key (test eql) (key nil) (from-end nil) (start 0) (end nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_count( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the number of elements in sequence (bounded by :start/:end) whose
:key satisfies :test when compared to item."""
      item    = env.lookup( 'ITEM' )
      seq     = env.lookup( 'SEQUENCE' )
      test_fn = env.lookup( 'TEST' )
      key_fn  = env.lookup( 'KEY' )
      start   = env.lookup( 'START' )
      end     = env.lookup( 'END' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_count, '2nd argument must be a list.' )
      start_n, end_n = _validate_bounds( start, end, len(seq), LP_count )
      n = 0
      for i in range( start_n, end_n ):
         if _apply_test( ctx, env, test_fn, item, _extract_key( ctx, env, key_fn, seq[i] ) ):
            n += 1
      return n

   @primitive( 'count-if', '(pred sequence &key (key nil) (from-end nil) (start 0) (end nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_count_if( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the number of elements in sequence (bounded by :start/:end) for
which pred returns true when applied to the element's :key."""
      pred   = env.lookup( 'PRED' )
      seq    = env.lookup( 'SEQUENCE' )
      key_fn = env.lookup( 'KEY' )
      start  = env.lookup( 'START' )
      end    = env.lookup( 'END' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_count_if, '2nd argument must be a list.' )
      start_n, end_n = _validate_bounds( start, end, len(seq), LP_count_if )
      n = 0
      for i in range( start_n, end_n ):
         cell_key = _extract_key( ctx, env, key_fn, seq[i] )
         if ctx.lApply( ctx, env, pred, [cell_key] ) != L_NIL:
            n += 1
      return n

   @primitive( 'remove', '(item sequence &key (test eql) (key nil) (from-end nil) (start 0) (end nil) (count nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_remove( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of sequence with elements matching item removed.  An
element matches if its :key satisfies :test when compared to item.  Only the
bounded region [:start, :end) is considered.  :count limits how many elements
are removed; :from-end causes removal from the right when :count is supplied."""
      item     = env.lookup( 'ITEM' )
      seq      = env.lookup( 'SEQUENCE' )
      test_fn  = env.lookup( 'TEST' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      count    = env.lookup( 'COUNT' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_remove, '2nd argument must be a list.' )
      seqlen = len( seq )
      start_n, end_n = _validate_bounds( start, end, seqlen, LP_remove )
      count_n = _validate_count( count, LP_remove )
      indices = list( range( start_n, end_n ) )
      if not _is_nil_val( from_end ):
         indices = list( reversed( indices ) )
      to_remove: set = set()
      n_removed = 0
      for idx in indices:
         if count_n is not None and n_removed >= count_n:
            break
         if _apply_test( ctx, env, test_fn, item, _extract_key( ctx, env, key_fn, seq[idx] ) ):
            to_remove.add( idx )
            n_removed += 1
      return [ seq[i] for i in range( seqlen ) if i not in to_remove ]

   @primitive( 'remove-if', '(pred sequence &key (key nil) (from-end nil) (start 0) (end nil) (count nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_remove_if( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of sequence with elements removed where pred returns true
for the element's :key.  Only the bounded region [:start, :end) is considered.
:count limits removals; :from-end causes removal from the right."""
      pred     = env.lookup( 'PRED' )
      seq      = env.lookup( 'SEQUENCE' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      count    = env.lookup( 'COUNT' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_remove_if, '2nd argument must be a list.' )
      seqlen = len( seq )
      start_n, end_n = _validate_bounds( start, end, seqlen, LP_remove_if )
      count_n = _validate_count( count, LP_remove_if )
      indices = list( range( start_n, end_n ) )
      if not _is_nil_val( from_end ):
         indices = list( reversed( indices ) )
      to_remove: set = set()
      n_removed = 0
      for idx in indices:
         if count_n is not None and n_removed >= count_n:
            break
         cell_key = _extract_key( ctx, env, key_fn, seq[idx] )
         if ctx.lApply( ctx, env, pred, [cell_key] ) != L_NIL:
            to_remove.add( idx )
            n_removed += 1
      return [ seq[i] for i in range( seqlen ) if i not in to_remove ]

   @primitive( 'remove-if-not', '(pred sequence &key (key nil) (from-end nil) (start 0) (end nil) (count nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_remove_if_not( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of sequence keeping only elements where pred returns true
for the element's :key.  Only the bounded region [:start, :end) is considered.
:count limits how many elements are removed; :from-end removes from the right."""
      pred     = env.lookup( 'PRED' )
      seq      = env.lookup( 'SEQUENCE' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      count    = env.lookup( 'COUNT' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_remove_if_not, '2nd argument must be a list.' )
      seqlen = len( seq )
      start_n, end_n = _validate_bounds( start, end, seqlen, LP_remove_if_not )
      count_n = _validate_count( count, LP_remove_if_not )
      indices = list( range( start_n, end_n ) )
      if not _is_nil_val( from_end ):
         indices = list( reversed( indices ) )
      to_remove: set = set()
      n_removed = 0
      for idx in indices:
         if count_n is not None and n_removed >= count_n:
            break
         cell_key = _extract_key( ctx, env, key_fn, seq[idx] )
         if ctx.lApply( ctx, env, pred, [cell_key] ) == L_NIL:   # remove where pred is FALSE
            to_remove.add( idx )
            n_removed += 1
      return [ seq[i] for i in range( seqlen ) if i not in to_remove ]

   @primitive( 'substitute', '(new old sequence &key (test eql) (key nil) (from-end nil) (start 0) (end nil) (count nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_substitute( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of sequence with occurrences of old replaced by new.  An
element matches old if its :key satisfies :test when compared to old.  Only
the bounded region [:start, :end) is considered.  :count limits replacements;
:from-end replaces from the right when :count is supplied."""
      new      = env.lookup( 'NEW' )
      old      = env.lookup( 'OLD' )
      seq      = env.lookup( 'SEQUENCE' )
      test_fn  = env.lookup( 'TEST' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      count    = env.lookup( 'COUNT' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_substitute, '3rd argument must be a list.' )
      seqlen = len( seq )
      start_n, end_n = _validate_bounds( start, end, seqlen, LP_substitute )
      count_n = _validate_count( count, LP_substitute )
      result = list( seq )
      indices = list( range( start_n, end_n ) )
      if not _is_nil_val( from_end ):
         indices = list( reversed( indices ) )
      n_done = 0
      for idx in indices:
         if count_n is not None and n_done >= count_n:
            break
         if _apply_test( ctx, env, test_fn, old, _extract_key( ctx, env, key_fn, seq[idx] ) ):
            result[idx] = new
            n_done += 1
      return result

   @primitive( 'substitute-if', '(new pred sequence &key (key nil) (from-end nil) (start 0) (end nil) (count nil))',
               mode=LambdaListMode.FULL_BINDING )
   def LP_substitute_if( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns a copy of sequence with elements replaced by new where pred returns
true for the element's :key.  Only the bounded region [:start, :end) is
considered.  :count limits replacements; :from-end replaces from the right."""
      new      = env.lookup( 'NEW' )
      pred     = env.lookup( 'PRED' )
      seq      = env.lookup( 'SEQUENCE' )
      key_fn   = env.lookup( 'KEY' )
      from_end = env.lookup( 'FROM-END' )
      start    = env.lookup( 'START' )
      end      = env.lookup( 'END' )
      count    = env.lookup( 'COUNT' )
      if not isinstance( seq, list ):
         raise LRuntimePrimError( LP_substitute_if, '3rd argument must be a list.' )
      seqlen = len( seq )
      start_n, end_n = _validate_bounds( start, end, seqlen, LP_substitute_if )
      count_n = _validate_count( count, LP_substitute_if )
      result = list( seq )
      indices = list( range( start_n, end_n ) )
      if not _is_nil_val( from_end ):
         indices = list( reversed( indices ) )
      n_done = 0
      for idx in indices:
         if count_n is not None and n_done >= count_n:
            break
         cell_key = _extract_key( ctx, env, key_fn, seq[idx] )
         if ctx.lApply( ctx, env, pred, [cell_key] ) != L_NIL:
            result[idx] = new
            n_done += 1
      return result

   # ── Multi-sequence mapping functions ──────────────────────────────────────

   @primitive( 'mapcar', '(fn seq &rest more-seqs)' )
   def LP_mapcar( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Applies fn element-wise across one or more sequences (lists) and returns
a list of the results.  Stops at the shortest sequence."""
      fn   = args[0]
      seqs = args[1:]
      for i, s in enumerate(seqs):
         if not isinstance( s, list ):
            raise LRuntimePrimError( LP_mapcar, f'Argument {i + 2} must be a list.' )
      result = []
      for elts in zip( *seqs ):
         result.append( ctx.lApply( ctx, env, fn, list(elts) ) )
      return result

   @primitive( 'every', '(pred seq &rest more-seqs)' )
   def LP_every( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns T if pred returns true for every element-wise group across sequences.
Returns NIL at the first false result.  Returns T for empty sequences."""
      pred = args[0]
      seqs = args[1:]
      for elts in zip( *seqs ):
         result = ctx.lApply( ctx, env, pred, list(elts) )
         if _is_nil_val( result ):
            return L_NIL
      return L_T

   @primitive( 'some', '(pred seq &rest more-seqs)' )
   def LP_some( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Returns the first truthy value pred returns across the sequences.
Returns NIL if pred returns NIL for every element-wise group."""
      pred = args[0]
      seqs = args[1:]
      for elts in zip( *seqs ):
         result = ctx.lApply( ctx, env, pred, list(elts) )
         if not _is_nil_val( result ):
            return result
      return L_NIL

   @primitive( 'mapc', '(fn seq &rest more-seqs)' )
   def LP_mapc( ctx: Context, env: Environment, args: list[Any] ) -> Any:
      """Applies fn element-wise across one or more sequences for side effects.
Returns the first sequence."""
      fn       = args[0]
      seqs     = args[1:]
      first_seq = seqs[0]
      for elts in zip( *seqs ):
         ctx.lApply( ctx, env, fn, list(elts) )
      return first_seq
