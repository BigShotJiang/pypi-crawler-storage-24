# CWZ - CMK-Werk-Zeug

This is both a collection of tools and shared libraries created for (but not limited to) Checkmk development
and a 'collector' for other tools located in different repositories.


## What you get

### `cmk-components`

A CLI for querying and validating component and code ownership details of the `check_mk` (mostly) repository.

**Use cases:**

- Browse all components interactively (TUI, default when no subcommand is given)
- List all known components: `list`
- Show members/owners of a component: `members <COMPONENT>`
- Show which paths belong to a component: `paths <COMPONENT>`
- Look up who owns a given file or directory: `owners <PATH>`
- Find which component a path belongs to: `component <PATH>`
- List all `OWNERS` config files in the repo: `config-files`

**Output modes** (`--mode`): `rich` (default in a terminal), `json`, `script` (YAML, default when
stdout is not a TTY — suitable for piping).

**Caching** (`--cache-mode auto|always|never`): a locally cached collection of component and
ownership information stored at `~/.cache/cwz/cmk-components.json` will be used in `auto` (default)
mode if remote git commit still matches or when in `always` mode. In `never` mode, the cache will be
ignored and updated with the latest data from Gerrit.

**Credentials**: read from `~/.netrc` by default; override via `--gerrit-username-var` /
`--gerrit-api-token-var` to name environment variables that hold the credentials instead.

**Other options**: `--gerrit-url`, `--project-name`, `--branch` to point at a different Gerrit
instance or branch.


## Install

You either clone the cwz repository (`ssh://review.lan.tribe29.com:29418/cmk-werk-zeug`) and make it's tools available
via `uv` or you install the pip package:

```
pipx install cmk-werk-zeug
```

For ci_build_metrics you need PostgreSQL installed
```
sudo apt install postgresql postgresql-contrib postgresql-server-dev
```
