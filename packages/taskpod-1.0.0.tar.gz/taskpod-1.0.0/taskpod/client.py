"""TaskPod Python SDK client."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False


# ---- Errors ----

class TaskPodError(Exception):
    """Base error for TaskPod API errors."""

    def __init__(self, status: int, code: str, message: str, details: Optional[Dict] = None):
        super().__init__(message)
        self.status = status
        self.code = code
        self.details = details


class TaskPodAuthError(TaskPodError):
    """Raised when authentication is required or fails."""

    def __init__(self, message: str = "Authentication required. Provide an API key."):
        super().__init__(401, "UNAUTHORIZED", message)


class TaskPodNotFoundError(TaskPodError):
    """Raised when a resource is not found."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(404, "NOT_FOUND", message)


class TaskPodRateLimitError(TaskPodError):
    """Raised when rate limit is exceeded."""

    def __init__(self, retry_after: Optional[int] = None):
        super().__init__(429, "RATE_LIMITED", "Rate limit exceeded")
        self.retry_after = retry_after


# ---- Client ----

class TaskPod:
    """
    TaskPod API client for agent discovery and registry.

    Args:
        api_key: API key for authenticated operations (optional for discovery).
        base_url: Base URL for the API. Defaults to https://api.taskpod.ai.
        timeout: Request timeout in seconds. Defaults to 10.
        retries: Number of retries on 5xx/network errors. Defaults to 2.

    Example:
        >>> tp = TaskPod()
        >>> results = tp.discover(query="code review")
        >>> print(results["data"][0]["name"])
    """

    DEFAULT_BASE_URL = "https://api.taskpod.ai"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 10,
        retries: int = 2,
    ):
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.retries = retries

        # Pick HTTP client: httpx > requests > error
        if _HAS_HTTPX:
            self._client = httpx.Client(timeout=timeout)
            self._http = "httpx"
        elif _HAS_REQUESTS:
            self._session = _requests.Session()
            self._http = "requests"
        else:
            raise ImportError(
                "TaskPod SDK requires either 'httpx' or 'requests'. "
                "Install one: pip install httpx  OR  pip install requests"
            )

    def __del__(self):
        if hasattr(self, "_client") and self._http == "httpx":
            self._client.close()

    # ---- Internal ----

    def _headers(self) -> Dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "User-Agent": f"taskpod-sdk-py/{__import__('taskpod').__version__}",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[Dict] = None,
        auth_required: bool = False,
    ) -> Any:
        if auth_required and not self.api_key:
            raise TaskPodAuthError()

        url = f"{self.base_url}{path}"
        last_error: Optional[Exception] = None

        for attempt in range(self.retries + 1):
            try:
                if self._http == "httpx":
                    resp = self._client.request(
                        method,
                        url,
                        headers=self._headers(),
                        json=body,
                    )
                    status = resp.status_code
                    resp_json = resp.json() if resp.content else {}
                    retry_after = resp.headers.get("retry-after")
                else:
                    resp = self._session.request(
                        method,
                        url,
                        headers=self._headers(),
                        json=body,
                        timeout=self.timeout,
                    )
                    status = resp.status_code
                    resp_json = resp.json() if resp.content else {}
                    retry_after = resp.headers.get("retry-after")

                if 200 <= status < 300:
                    return resp_json

                # Error handling
                error_msg = resp_json.get("message", "Unknown error") if isinstance(resp_json, dict) else str(resp_json)
                error_code = resp_json.get("code", "UNKNOWN") if isinstance(resp_json, dict) else "UNKNOWN"

                if status == 429:
                    ra = int(retry_after) if retry_after else None
                    raise TaskPodRateLimitError(ra)

                if status == 404:
                    raise TaskPodNotFoundError(error_msg)

                if status in (401, 403):
                    raise TaskPodAuthError(error_msg)

                if status >= 500 and attempt < self.retries:
                    last_error = TaskPodError(status, error_code, error_msg)
                    time.sleep(2 ** attempt * 0.5)
                    continue

                raise TaskPodError(status, error_code, error_msg)

            except (TaskPodError, TaskPodAuthError, TaskPodNotFoundError, TaskPodRateLimitError):
                raise
            except Exception as e:
                if attempt < self.retries:
                    last_error = e
                    time.sleep(2 ** attempt * 0.5)
                    continue
                raise TaskPodError(0, "NETWORK_ERROR", str(e))

        raise last_error or Exception("Request failed")

    # ---- Discovery (Public) ----

    def discover(
        self,
        query: Optional[str] = None,
        protocols: Optional[List[str]] = None,
        categories: Optional[List[str]] = None,
        capabilities: Optional[List[str]] = None,
        status: Optional[str] = None,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
        sort_by: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Search for agents by capability, category, protocol, or free-text query.
        No authentication required.

        Args:
            query: Free-text search query.
            protocols: Filter by protocols (e.g., ["rest", "mcp"]).
            categories: Filter by categories (e.g., ["health", "coding"]).
            capabilities: Filter by capabilities.
            status: Filter by status ("active", "inactive", etc.).
            page: Page number (1-indexed).
            per_page: Results per page (max 100).
            sort_by: Sort order ("relevance", "rating", "tasks", "created", "updated").

        Returns:
            Dict with "data" (list of agents), "total", "page", "perPage", "totalPages".
        """
        params: List[tuple] = []
        if query:
            params.append(("q", query))
        if page:
            params.append(("page", str(page)))
        if per_page:
            params.append(("per_page", str(per_page)))
        if sort_by:
            params.append(("sort", sort_by))
        if status:
            params.append(("status", status))
        if protocols:
            for p in protocols:
                params.append(("protocol", p))
        if categories:
            for c in categories:
                params.append(("category", c))
        if capabilities:
            for c in capabilities:
                params.append(("capability", c))

        qs = f"?{urlencode(params)}" if params else ""
        return self._request("GET", f"/v1/discover{qs}")

    def get(self, id_or_slug: str) -> Dict[str, Any]:
        """
        Get a specific agent by slug or ID.
        No authentication required.

        Args:
            id_or_slug: Agent ID (nanoid) or URL-friendly slug.

        Returns:
            Dict with "data" containing the agent object.
        """
        return self._request("GET", f"/v1/discover/{id_or_slug}")

    # ---- Agent Management (Authenticated) ----

    def register(
        self,
        name: str,
        description: str,
        endpoint: str,
        protocols: List[str],
        categories: List[str],
        long_description: Optional[str] = None,
        capabilities: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        docs_url: Optional[str] = None,
        manifest_url: Optional[str] = None,
        auth_type: Optional[str] = None,
        version: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Register a new agent in the registry.
        Requires authentication.

        Args:
            name: Agent display name.
            description: Short description (shown in search results).
            endpoint: Primary API endpoint URL.
            protocols: List of protocols (e.g., ["rest", "mcp"]).
            categories: List of categories (e.g., ["health", "productivity"]).
            long_description: Detailed description with markdown support.
            capabilities: Free-form capability tags.
            tags: Discovery tags for search.
            docs_url: Documentation URL.
            manifest_url: MCP manifest or A2A agent card URL.
            auth_type: Authentication type ("none", "api_key", "oauth2", "bearer").
            version: Semantic version string.

        Returns:
            Dict with "data" containing the created agent.
        """
        body: Dict[str, Any] = {
            "name": name,
            "description": description,
            "endpoint": endpoint,
            "protocols": protocols,
            "categories": categories,
        }
        if long_description is not None:
            body["longDescription"] = long_description
        if capabilities is not None:
            body["capabilities"] = capabilities
        if tags is not None:
            body["tags"] = tags
        if docs_url is not None:
            body["docsUrl"] = docs_url
        if manifest_url is not None:
            body["manifestUrl"] = manifest_url
        if auth_type is not None:
            body["authType"] = auth_type
        if version is not None:
            body["version"] = version

        return self._request("POST", "/v1/agents", body=body, auth_required=True)

    def update(self, agent_id: str, **kwargs) -> Dict[str, Any]:
        """
        Update an existing agent you own.
        Requires authentication.

        Args:
            agent_id: The agent ID to update.
            **kwargs: Fields to update (name, description, endpoint, etc.).
                      Use snake_case (e.g., long_description, docs_url).

        Returns:
            Dict with "data" containing the updated agent.
        """
        # Convert snake_case kwargs to camelCase for API
        key_map = {
            "long_description": "longDescription",
            "docs_url": "docsUrl",
            "manifest_url": "manifestUrl",
            "auth_type": "authType",
        }
        body = {}
        for k, v in kwargs.items():
            api_key = key_map.get(k, k)
            body[api_key] = v

        return self._request("PUT", f"/v1/agents/{agent_id}", body=body, auth_required=True)

    def delete(self, agent_id: str) -> Dict[str, Any]:
        """
        Delete an agent you own.
        Requires authentication.

        Args:
            agent_id: The agent ID to delete.

        Returns:
            Dict with "message" confirmation.
        """
        return self._request("DELETE", f"/v1/agents/{agent_id}", auth_required=True)

    def list_mine(self) -> Dict[str, Any]:
        """
        List all agents owned by the authenticated user.
        Requires authentication.

        Returns:
            Dict with "data" containing list of owned agents.
        """
        return self._request("GET", "/v1/agents", auth_required=True)

    # ---- Health ----

    def health(self) -> Dict[str, Any]:
        """Check API health status."""
        return self._request("GET", "/health")
