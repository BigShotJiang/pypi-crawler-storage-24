import datetime

import humanfriendly as hf

from oi_tools.pbs._helpers import format_disc_size, get_all_jobs, sh

TIME_FORMAT = r"%a %b %d %H:%M:%S %Y"
JOB_STATUSES = {
    "B": "Running subjob",
    "E": "Exiting",
    "F": "Finished",
    "H": "Held",
    "M": "Moved",
    "Q": "[yellow]Queued",
    "R": "[green]Running",
    "S": "Suspended",
    "T": "In transit",
    "U": "Suspended",
    "W": "Waiting",
    "X": "Completed or canceled",
}


def list_jobs(
    users: list[str] = [],
    only_me: bool = True,
) -> None:
    """List active and queued PBS jobs in a formatted table.

    Parameters
    ----------
    users
        List of users to filter by when ``only_me`` is ``False``.
        Default is ``[]``.
    only_me
        If ``True``, show only jobs belonging to the current user.
        Default is ``True``.
    """
    import polars as pl
    import rich

    job_df = (
        get_all_jobs()
        .sort("job_state", "Job_Owner", "Job_Name")
        .select(
            # TODO: clean up this heinous mess
            pl.format("{}\n  [dim]{}", "Job_Name", "id").alias("Job"),
            pl.col("Job_Owner").str.extract(r"(.*)@.*").alias("Owner"),
            pl.format(
                "{}\n[dim]{}",
                pl.col("job_state").replace_strict(JOB_STATUSES),
                pl.col("etime")
                .str.strptime(pl.Datetime, TIME_FORMAT)
                # convert to duration
                .pipe(lambda x: datetime.datetime.now() - x)
                # format nicely
                .map_elements(
                    lambda x: hf.format_timespan(x, max_units=1),
                    return_dtype=pl.String,
                ),
            ).alias("Status"),
            # usage
            pl.format(
                "{} of {}\n{} ({} CPUs)",
                pl.col("resources_used.mem")
                .map_elements(format_disc_size, return_dtype=pl.String)
                .fill_null(pl.lit("--")),
                pl.col("Resource_List.mem").map_elements(
                    format_disc_size, return_dtype=pl.String
                ),
                pl.col("resources_used.cpupercent")
                .cast(str)
                .add(pl.lit("%"))
                .fill_null(pl.lit("--")),
                "Resource_List.ncpus",
            ).alias("Usage"),
            # pl.col("interactive").alias("Interactive"),
        )
        .filter(
            pl.col("Owner").eq(sh("whoami"))
            if only_me
            else pl.col("Owner").is_in(users)
            if users
            else True
        )
    )

    t = rich.table.Table()  # type: ignore
    t.box = rich.box.HORIZONTALS  # type: ignore

    for c in job_df.columns:
        t.add_column(c)

    for r in job_df.iter_rows():
        t.add_row(*r)

    rich.print(t)

    # return jobs
