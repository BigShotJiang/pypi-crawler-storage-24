from __future__ import annotations

import datetime
import os
import re
import tempfile
import textwrap
from itertools import islice
from pathlib import Path
from typing import Iterable, Literal, Mapping, Sequence, Union, get_args

import rich

from oi_tools.pbs._helpers import (
    format_path,
    get_python,
    get_rscript,
    get_stata,
    quote_argument,
    sh,
    wait_for_job,
)

ArgumentType = Union[str, Path, float, int]


def submit_many_jobs(
    file: str | Path,
    args: Iterable[Sequence[ArgumentType]],
    *,
    max_concurrent_jobs: int = 7,
    stop_on_error: bool = True,
    **kwargs,
) -> None:
    """Submit multiple jobs to the PBS queue and block until all finish.

    Jobs are submitted in batches to keep at most ``max_concurrent_jobs``
    running or queued at any time. As each job completes, the next one is
    submitted automatically. If any job exits with a non-zero status,
    a :class:`~oi_tools.pbs.BatchJobError` is raised (unless
    ``stop_on_error=False``).

    Parameters
    ----------
    file
        Path to a Python script, or a module name (e.g.
        ``"myproject.submodule"``). Passed directly to
        :func:`submit_job`.
    args
        An iterable of argument lists, one per job. Each element is
        passed as the ``args`` parameter of :func:`submit_job`.
    max_concurrent_jobs
        Maximum number of jobs to have running or queued at any given time.
        Defaults to 7.
    stop_on_error
        If ``True`` (default), raise :class:`~oi_tools.pbs.BatchJobError`
        as soon as any job fails. If ``False``, continue submitting and
        waiting for the remaining jobs.
    **kwargs
        Additional keyword arguments forwarded to every
        :func:`submit_job` call (e.g. ``filetype``, ``mem``, ``cpus``,
        ``log_folder``, ``env_vars``, etc.).

    Examples
    --------
    Submit one job per year for 2000–2019, keeping at most 3 running at
    once, and block until all jobs finish:

    >>> many_args = [[str(year)] for year in range(2000, 2020)]
    >>> submit_many_jobs(  # doctest: +SKIP
    ...     "code/myscript.py",
    ...     many_args,
    ...     max_concurrent_jobs=3,
    ...     mem="16G",
    ... )

    Allow jobs to fail silently:

    >>> submit_many_jobs(  # doctest: +SKIP
    ...     "code/myscript.py",
    ...     many_args,
    ...     stop_on_error=False,
    ... )
    """
    if kwargs.get("wait"):
        raise ValueError("`wait=True` not allowed in `submit_many_jobs`")

    yet_to_submit = iter(args)

    # submit first round of jobs right off the bat
    ongoing_jobs = {
        submit_job(file, a, **kwargs): a
        for a in islice(yet_to_submit, max_concurrent_jobs)
    }

    while ongoing_jobs:
        # wait for a job to finish and remove it from ongoing_jobs
        completed_jobid = wait_for_job(ongoing_jobs, stop_on_error=stop_on_error)
        completed_args = ongoing_jobs.pop(completed_jobid)

        rich.print("[bold][green]Job complete!")
        print(f" - Arguments: {' '.join(map(str, completed_args))}")
        print(f" - Job ID: {completed_jobid}")

        # check if there's another job to submit
        a = next(yet_to_submit, None)
        if a is None:
            continue  #  no jobs remaining

        # submit the next job
        next_job = submit_job(file, a, **kwargs)
        ongoing_jobs[next_job] = a

    rich.print("\n\n[green] --- All jobs finished! ---")


FileType = Literal[
    "python_script",
    "python_module",
    "stata_script",
    "r_script",
    "sas_script",
]


def submit_job(
    file: str | Path,
    args: Sequence[ArgumentType] = [],
    *,
    mem: str | int = "8G",
    cpus: int = 4,
    wait: bool = False,
    log_folder: Path | str | None = Path("logs"),
    verbose: bool | None = True,
    filetype: FileType | None = None,
    base_job_name: str | None = None,
    python_executable: Path | None = None,
    cwd: Path | str | None = None,
    env_vars: dict[str, str] | None = None,
) -> str:
    """Submit a single script or module as a PBS job.

    Logs are written to ``<log_folder>/<base_job_name>/<args>/``, with one
    file per submission named by today's date and an incrementing counter
    (e.g. ``logs/myscript/2001/2026-01-15-1.log``).

    Parameters
    ----------
    file
        Path to a Python script (e.g. ``"code/myscript.py"``), a Stata
        do-file (e.g. ``"code/myscript.do"``), an R script
        (e.g. ``"code/myscript.r"``), or a fully-qualified Python module
        name (e.g. ``"myproject.submodule"``). The filetype is inferred
        from the file suffix; use ``filetype`` to override.
    args
        Command-line arguments to pass to the script or module.
        Defaults to no arguments.
    mem
        Memory to request. Can be an integer (treated as gigabytes) or a
        string such as ``"16G"``. Defaults to ``"8G"``.
    cpus
        Number of CPU cores to request. Defaults to 4.
    wait
        Whether to wait for the job to finish before returning
        (``True``) or immediately return (``False``).
    log_folder
        Directory in which to create log files. Set to ``None`` to
        discard output. Defaults to ``"logs"``.
    verbose
        Print job details and the generated PBS script before submitting.
        Defaults to ``True``.
    filetype
        Explicitly set the script type: ``"python_script"``,
        ``"python_module"``, ``"stata_script"``, or ``"r_script"``.
        If omitted, inferred from the file suffix (``.py`` →
        ``python_script``, ``.do`` → ``stata_script``, ``.r`` →
        ``r_script``). Falls back to ``"python_module"`` if unrecognized.
    base_job_name
        Base name used for the PBS job and the log subdirectory. Defaults
        to the script path with non-alphanumeric characters replaced by
        hyphens (e.g. ``"code/myscript.py"`` → ``"code-myscript"``).
    python_executable
        Path to the Python interpreter to use. Defaults to the first
        ``python3`` or ``python`` found on ``PATH``. Only used for Python
        jobs.
    cwd
        Working directory for the job. Defaults to the current directory
        at submission time.
    env_vars
        Optional dictionary of environment variables to export in the job
        script (e.g. ``{"MY_VAR": "value"}``). Defaults to ``None``.

    Returns
    -------
    str
        The PBS job ID returned by ``qsub`` (e.g. ``"12345.cluster"``).

    Examples
    --------
    Submit a Python script with a year argument:

    >>> from pathlib import Path
    >>> job_id = submit_job(  # doctest: +SKIP
    ...     "code/myscript.py",
    ...     ["2001"],
    ...     mem="16G",
    ...     cpus=8,
    ...     log_folder="logs",
    ...     python_executable=Path(".venv/bin/python3"),
    ...     base_job_name="jobname",
    ... )

    Submit a Stata do-file:

    >>> submit_job("code/myscript.do", ["2001"])  # doctest: +SKIP

    Submit an R script:

    >>> submit_job("code/myscript.r", ["2001"])  # doctest: +SKIP

    Submit a Python module:

    >>> submit_job("myproject.submodule", filetype="python_module")  # doctest: +SKIP

    Pass environment variables to the job:

    >>> submit_job(  # doctest: +SKIP
    ...     "code/myscript.py",
    ...     ["2001"],
    ...     env_vars={"MY_TOKEN": "abc123", "DATA_DIR": "/scratch/myproject"},
    ... )
    """
    if isinstance(mem, int):
        mem = f"{mem}G"

    # directory from which the python command is run
    cwd = Path.cwd() if cwd is None else Path(cwd)

    command = _create_command(
        file,
        args,
        filetype=filetype,
        python_executable=python_executable,
    )

    # name-of-script[arg1-arg2]
    base_job_name, job_name_suffix, full_job_name = _make_job_name(
        file, args, base_job_name
    )

    logfile = (
        _next_logfile(Path(log_folder) / base_job_name / job_name_suffix)
        if log_folder
        else Path(os.devnull)
    )

    # create logfile immediately so that subsequent jobs don't claim the same path
    logfile.parent.mkdir(exist_ok=True, parents=True)
    logfile.touch()

    pbs_script = _create_pbs_script(
        cpus=cpus,
        mem=mem,
        full_job_name=full_job_name,
        cwd=cwd,
        command=command,
        logfile=logfile,
        env_vars=env_vars,
    )

    if verbose:
        print(pbs_script)

    with tempfile.NamedTemporaryFile("wt", suffix=".pbs") as f:
        # write job script to temp file
        f.write(pbs_script)
        f.flush()

        # submit job
        job_id = sh("qsub", f.name)

    if verbose:
        rich.print(f"[bold][cyan]Submitted job: {file}")
        print(f" - File: {file}")
        print(f" - Arguments: {args}")
        print(f" - Job name: {full_job_name}")
        print(f" - Memory: {mem}, CPUs: {cpus}")
        print(f" - Logging to {format_path(logfile)}")
        print(f" - Job ID: {job_id}")

    if not wait:
        return job_id

    return wait_for_job(job_id)


def _make_job_name(
    file: str | Path,
    args: Sequence[ArgumentType],
    base_name: str | None = None,
) -> tuple[str, str, str]:
    base_name = base_name or re.sub(
        "[^a-zA-Z0-9]+",
        "-",
        Path(file).stem,
    )

    if args:
        suffix = re.sub("[^a-zA-Z0-9]+", "-", "-".join(str(a) for a in args))
        full_name = f"{base_name}[{suffix}]"
    else:
        suffix = ""
        full_name = base_name

    return base_name, suffix, full_name


def _create_pbs_script(
    *,
    cpus: int,
    mem: str,
    full_job_name: str,
    cwd: Path,
    command: str,
    logfile: Path,
    env_vars: Mapping[str, str] | None = None,
) -> str:
    export_lines = "\n".join(
        f"export {k}={quote_argument(v)}" for k, v in (env_vars or {}).items()
    )

    return textwrap.dedent(f"""
    #!/bin/bash
    #PBS -l ncpus={cpus}
    #PBS -l mem={mem}
    #PBS -N {full_job_name}

    # go to correct directory
    cd {quote_argument(cwd)}

    # export user-supplied environment variables
    {export_lines}

    # disable python stdout buffering so logs appear instantly
    export PYTHONUNBUFFERED=1

    {command} \\
        &> {quote_argument(logfile.absolute())}
    """)


def _next_logfile(folder: Path) -> Path:
    """Get the next available logfile in the given folder.

    For example, if the folder contains ``...-1`` and ``...-2``,
    this function will return ``...-3``.

    Parameters
    ----------
    folder
        Directory in which to create log files.

    Returns
    -------
    Path
        Path to the next available log file.
    """
    today = datetime.date.today().isoformat()
    log_pattern = rf"{today}-(\d+)\.log"

    existing_logfile_numbers = [
        int(match.group(1))
        for p in folder.glob("*.log")
        if (match := re.match(log_pattern, p.name))
    ]

    log_number = max(existing_logfile_numbers, default=0) + 1
    return folder / f"{today}-{log_number}.log"


def _create_command(
    file: str | Path,
    args: Sequence[ArgumentType] = [],
    *,
    filetype: str | None = None,
    python_executable: Path | None = None,
) -> str:
    if filetype is None:
        suffix_mapping: Mapping[str, FileType] = {
            ".py": "python_script",
            ".do": "stata_script",
            ".r": "r_script",
            ".sas": "sas_script",
        }
        suffix = Path(file).suffix.lower()

        filetype = suffix_mapping.get(suffix) or "python_module"

    # concat arguments, single-quoting each to handle spaces and single quotes
    all_args: list[str | Path | int | float]
    if filetype == "python_module":
        all_args = [python_executable or get_python(), "-m", file, *args]
    elif filetype == "python_script":
        all_args = [python_executable or get_python(), file, *args]
    elif filetype == "stata_script":
        all_args = [get_stata(), "-b", file, *args]
    elif filetype == "r_script":
        all_args = [get_rscript(), file, *args]
    elif filetype == "sas_script":
        all_args = ["sas", "-nodms", "-stdio", "<", file, *args]
    else:
        raise ValueError(f"filetype must be one of {get_args(FileType)}")

    return " ".join(map(quote_argument, all_args))
