from typing import Literal

import polars as pl

from oi_tools.polars_helpers import IntoPolarsExpression, to_masked_expr


def weighted_mean(
    x: IntoPolarsExpression,
    w: IntoPolarsExpression,
) -> pl.Expr:
    """Compute the weighted mean of an expression.

    Rows where either ``x`` or ``w`` is null are omitted.

    Parameters
    ----------
    x
        First expression.
    w
        Weights.

    Returns
    -------
    pl.Expr
        The weighted mean.

    Examples
    --------
    >>> df = pl.DataFrame({"x": [0.0, 1.0], "w": [1.0, 3.0]})
    >>> df.select(weighted_mean("x", "w")).item()
    0.75

    Null values in either ``x`` or ``w`` are omitted:

    >>> df = pl.DataFrame({"x": [0.0, None, 1.0], "w": [1.0, 1.0, 3.0]})
    >>> df.select(weighted_mean("x", "w")).item()
    0.75
    """
    # FIX: do we really want to return nan on empty sums?
    x, w = to_masked_expr(x, w)

    return x.dot(w) / w.sum()


def weighted_covariance(
    x: IntoPolarsExpression,
    y: IntoPolarsExpression,
    w: IntoPolarsExpression,
    *,
    weight_type: Literal["frequency", "precision"],
    ddof: int = 1,
) -> pl.Expr:
    """Compute the weighted covariance between two expressions.

    Rows where any of ``x``, ``y``, or ``w`` is null are omitted.
    See the documentation for `np.cov <https://numpy.org/doc/stable/reference/generated/numpy.cov.html>`_
    for more.

    Parameters
    ----------
    x
        First expression.
    y
        Second expression.
    w
        Weights.
    weight_type
        The type of weight.

        - ``"frequency"`` weights treat each weight as a repeat count, giving
          normalization ``1 / (sum(w) - ddof)``. Like ``fweights`` in Stata.

        - ``"precision"`` (analytic/reliability) weights treat each weight as an
          inverse variance, giving normalization ``sum(w) / (sum(w)**2 - ddof * sum(w**2))``.
          Like ``aweights`` in Stata.

    ddof
        Delta degrees of freedom.

    Returns
    -------
    pl.Expr
        The weighted covariance.

    Examples
    --------
    >>> df = pl.DataFrame(
    ...     {"x": [0.0, 1.0, 2.0], "y": [2.0, 1.0, 0.0], "w": [1.0, 3.0, 1.0]}
    ... )
    >>> df.select(weighted_covariance("x", "y", "w", weight_type="frequency")).item()
    -0.5

    >>> df = pl.DataFrame(
    ...     {"x": [0.0, 1.0, 2.0], "y": [2.0, 1.0, 0.0], "w": [1.0, 2.0, 1.0]}
    ... )
    >>> df.select(weighted_covariance("x", "y", "w", weight_type="precision")).item()
    -0.8

    See Also
    --------
    weighted_variance

    """
    x, y, w = to_masked_expr(x, y, w)

    x_bar = x.dot(w) / w.sum()
    y_bar = y.dot(w) / w.sum()

    numerator = ((x - x_bar) * w * (y - y_bar)).sum()

    if weight_type == "frequency":
        denominator = w.sum() - ddof
    elif weight_type == "precision":
        denominator = (w.sum() ** 2 - ddof * w.dot(w)) / w.sum()
    else:
        raise ValueError(f"invalid weight type: {weight_type}")

    return numerator / denominator


def weighted_variance(
    x: IntoPolarsExpression,
    w: IntoPolarsExpression,
    *,
    weight_type: Literal["frequency", "precision"],
    ddof: int = 1,
) -> pl.Expr:
    """Compute the weighted variance of an expression.

    Rows where either ``x`` or ``w`` is null are omitted.
    See the documentation for `np.cov <https://numpy.org/doc/stable/reference/generated/numpy.cov.html>`_
    for more.

    Parameters
    ----------
    x
        The expression.
    w
        Weights.
    weight_type
        See func:`weighted_covariance`.

    Returns
    -------
    pl.Expr
        The weighted variance.

    Examples
    --------
    >>> df = pl.DataFrame({"x": [0.0, 1.0, 2.0], "w": [1.0, 3.0, 1.0]})
    >>> df.select(weighted_variance("x", "w", weight_type="frequency")).item()
    0.5

    >>> df = pl.DataFrame({"x": [0.0, 1.0, 2.0], "w": [1.0, 2.0, 1.0]})
    >>> df.select(weighted_variance("x", "w", weight_type="precision")).item()
    0.8

    See Also
    --------
    weighted_covariance
    """
    return weighted_covariance(x=x, y=x, w=w, weight_type=weight_type, ddof=ddof)
