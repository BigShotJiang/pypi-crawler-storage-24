from typing import Literal

import polars as pl

from oi_tools.polars_helpers import IntoPolarsExpression, to_expr
from oi_tools.stats._means_and_variances import weighted_mean

QuantileTieHandlingMethod = Literal["arbitrary", "average"]


def weighted_rank(
    x: IntoPolarsExpression,
    w: IntoPolarsExpression,
    *,
    ties: QuantileTieHandlingMethod = "average",
) -> pl.Expr:
    """Compute the weighted quantile rank of an expression.

    Parameters
    ----------
    x
        The values to rank.
    w
        The weights associated with each value.
    ties
        How to handle assigning quantiles in the case of ties:

        - ``"arbitrary"``: break ties arbitrarily,
        - ``"average"``: assign each unit the average rank of all units with the same ``x`` value.

    Returns
    -------
    pl.Expr
        A Polars expression producing ranks in (0, 1).

    Examples
    --------
    >>> df = pl.DataFrame({"x": [1.0, 2.0], "w": [1.0, 3.0]})
    >>> df.select(weighted_rank("x", "w")).to_series().to_list()
    [0.125, 0.625]

    Notes
    -----
    Behavior is undefined if ``w`` contains null values.
    """
    x = to_expr(x)
    w = to_expr(w)

    ranks_before_handling_ties = (
        # sort by x and get quantile midpoints
        w.sort_by(x)
        .pipe(lambda sorted_weights: sorted_weights.cum_sum() - sorted_weights / 2)
        # then put back in original order
        .gather(x.rank(method="ordinal") - 1)
        # then divide by the total weight to get a rank in (0, 1)
        .truediv(w.filter(x.is_not_null()).sum())
    )

    if ties == "arbitrary":
        return ranks_before_handling_ties

    # NOTE:
    # we want to do something like this:
    # >> return ranks.mean().over(ranks)
    # ... but this won't work if this function is called within a group-by context
    # (because polars doesn't allow nested group-bys)
    # instead, we define a helper function to operate on the series themselves

    # PERF: would it be better to have the entire function operate on
    # series instead of just this last step?

    return pl.map_batches(
        [ranks_before_handling_ties, w, x],
        lambda xwv: (
            pl.DataFrame(dict(unaveraged=xwv[0], w=xwv[1], x=xwv[2]))
            .select(pl.col("unaveraged").pipe(weighted_mean, "w").over("x"))
            .get_column("unaveraged")
        ),
        is_elementwise=False,
        returns_scalar=False,
        return_dtype=pl.dtype_of(x),
    )


def weighted_bin(
    x: IntoPolarsExpression,
    w: IntoPolarsExpression,
    n_bins: int = 10,
    *,
    ties: QuantileTieHandlingMethod = "average",
) -> pl.Expr:
    """Bin values into weighted quantile bins.

    Parameters
    ----------
    x
        The values to bin.
    w
        The weights associated with each value.
    n_bins
        The number of bins. Default is 10.
    ties
        How to handle ties when assigning ranks. Default is ``"average"``.

    Returns
    -------
    pl.Expr
        A Polars expression producing integer bin labels.

    """
    raise NotImplementedError
