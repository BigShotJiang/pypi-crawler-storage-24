from __future__ import annotations

import importlib.resources
import subprocess
import webbrowser
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler

import typer
from rich import print as rprint

app = typer.Typer(
    no_args_is_help=True,
    add_completion=False,
    rich_markup_mode="rich",
    epilog="[dim]Written by Alistair Pattison in Spring 2026.",
)


@app.command("docs")
def serve_documentation(
    *,
    host: str = "localhost",
    port: int = 8000,
    build: bool = False,
) -> None:
    """Serve the [cyan]oi-tools[/cyan] HTML documentation."""
    docs_path = importlib.resources.files("oi_tools") / "_docs" / "html"

    with importlib.resources.as_file(docs_path) as docs_dir:
        if build:
            print("Building documentation...")
            subprocess.check_call(
                ["sphinx-build", "docs", str(docs_dir)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

        if not docs_dir.exists():
            rprint(
                "Documentation not found. "
                "Include the [cyan]--build[/cyan] flag to build the documentation."
            )
            raise typer.Exit(1)

        rprint(f"Serving documentation on [cyan]{host}:{port}[/cyan]")
        rprint("[dim](Use ctrl+c to stop)[/dim]")

        webbrowser.open(f"http://{host}:{port}")
        HTTPServer(
            (host, port),
            partial(SimpleHTTPRequestHandler, directory=docs_dir),
        ).serve_forever()


@app.callback()
def callback() -> None:
    """Command line app for the [cyan]oi-tools[/cyan] package."""
    pass


def main() -> None:
    """Basic driver function for the CLI."""  # noqa: D401
    # TODO: some kind of wrapper for submitting pbs jobs via the command line
    # maybe in a separate CLI accessible at `pbs` or `q`

    app()
