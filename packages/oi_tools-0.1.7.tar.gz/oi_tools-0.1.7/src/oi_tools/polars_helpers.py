"""Various helper functions for working with Polars."""

from collections.abc import Collection
from typing import Sequence, Union

import polars as pl
from polars import selectors as cs

IntoPolarsExpression = Union[str, pl.Expr, int, float]
IntoPolarsSelector = Union[Collection[str], cs.Selector]


def to_selector(x: IntoPolarsSelector) -> cs.Selector:
    """Convert the input to a Polars selector.

    Parameters
    ----------
    x
        A Polars selector or a collection of column names.

    Returns
    -------
    cs.Selector
        A Polars column selector.
    """
    if isinstance(x, cs.Selector):
        return x

    if isinstance(x, Collection):
        return cs.by_name(x)

    raise TypeError


def to_expr(x: IntoPolarsExpression) -> pl.Expr:
    """Convert the input to a Polars expression.

    Parameters
    ----------
    x
        A Polars expression, column name string, or numeric literal.

    Returns
    -------
    pl.Expr
        A Polars expression.
    """
    if isinstance(x, pl.Expr):
        return x

    if isinstance(x, str):
        return pl.col(x)

    if isinstance(x, (int, float)):
        return pl.lit(x)

    raise TypeError


def to_masked_expr(*xs: IntoPolarsExpression) -> Sequence[pl.Expr]:
    """Create a set of expressions with a standardized null mask.

    All output expressions evaluate to null wherever any input expression is null.

    Parameters
    ----------
    *xs
        Expressions to mask.

    Returns
    -------
    Sequence[pl.Expr]
        Expressions that evaluate to null when any input is null.
    """
    xs_exprs = [to_expr(x) for x in xs]

    # true when all inputs are not null
    mask = pl.all_horizontal(x.is_not_null() for x in xs_exprs)

    return [pl.when(mask).then(x) for x in xs_exprs]
