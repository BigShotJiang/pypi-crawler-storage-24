"""CertiSigma Census — Cryptographic file inventory and exfiltration detection."""

__version__ = "0.6.1"
