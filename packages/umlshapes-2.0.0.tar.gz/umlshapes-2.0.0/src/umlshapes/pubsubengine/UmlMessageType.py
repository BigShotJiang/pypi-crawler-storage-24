
from enum import StrEnum


class UmlMessageType(StrEnum):
    """

    """
    UML_SHAPE_SELECTED = 'Uml Shape Selected'
    FRAME_LEFT_CLICK   = 'Frame Left Click'
    FRAME_MODIFIED     = 'Frame Modified'
    SHAPE_MOVING       = 'Shape Moving'         # Only the 'master' shape issues this message

    SD_LIFELINE_CLICKED  = 'SDLifeLine Clicked'

    CREATE_LOLLIPOP           = 'Create Lollipop'
    REQUEST_LOLLIPOP_LOCATION = 'Request Lollipop Location'
    UPDATE_APPLICATION_STATUS = 'Update Application Status'

    UNDO = 'Undo'
    REDO = 'Redo'

    CUT_SHAPES        = 'CutShapes'
    COPY_SHAPES       = 'CopyShapes'
    PASTE_SHAPES      = 'PasteShapes'
    SELECT_ALL_SHAPES = 'SelectAllShapes'

    EDIT_CLASS    = 'Edit Class'
    EDIT_NOTE     = 'Edit Note'
    EDIT_TEXT     = 'Edit Text'
    EDIT_ACTOR    = 'Edit Actor'
    EDIT_USE_CASE = 'Edit Use Case'

