# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [0.1.0] - 2026-03-24

### Added

- Initial release.

## [0.1.1] - 2026-03-24

### Added

- License and badges added.
