
import requests
import pandas as pd
import io
import time
import os
import sys
import hashlib
from datetime import datetime
from pymongo import MongoClient
from colorama import Fore, Style, init as colorama_init

colorama_init(autoreset=True)

# ----------------- Database Layer -----------------
class Database:
    def __init__(self, mongo_uri, db_name):
        try:
            self.client = MongoClient(
                mongo_uri,
                serverSelectionTimeoutMS=50000,
                connectTimeoutMS=100000
            )
            self.client.server_info()
            self.db = self.client[db_name]
        except Exception as e:
            print(f"❌ Connection Error: {e}")
            raise

        self.users        = self.db["users"]
        self.access_tokens = self.db["accesstokens"]
        self.user_plans   = self.db["userplans"]
        self.plans        = self.db["plans"]


# ----------------- Token Manager -----------------
class TokenManager:
    def __init__(self, db: Database, raw_token: str):
        self.db           = db
        self.raw_token    = raw_token.strip()
        self.hashed_token = self._hash_token(self.raw_token)

    def _hash_token(self, token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def check_token_and_credits(self):
        token_doc = self.db.access_tokens.find_one(
            {"token": self.hashed_token, "isActive": True}
        )
        if not token_doc:
            return {"valid": False, "error": "Invalid or inactive access token"}

        user_id  = token_doc["userId"]
        plan_doc = self.db.user_plans.find_one({
            "userId":   user_id,
            "isActive": True,
            "expiresAt": {"$gte": datetime.utcnow()},
        })
        if not plan_doc:
            return {"valid": False, "error": "No active subscription plan found"}

        credits = plan_doc.get("creditsRemaining", 0)
        if credits <= 0:
            return {
                "valid": False,
                "error": "Credits exhausted. Please subscribe to a plan to continue.",
                "creditsRemaining": 0,
            }
        return {
            "valid":            True,
            "userId":           user_id,
            "planId":           plan_doc["_id"],
            "creditsRemaining": credits,
        }

    def deduct_credit(self):
        token_doc = self.db.access_tokens.find_one(
            {"token": self.hashed_token, "isActive": True}
        )
        if not token_doc:
            return False

        user_id  = token_doc["userId"]
        plan_doc = self.db.user_plans.find_one({
            "userId":   user_id,
            "isActive": True,
            "expiresAt": {"$gte": datetime.utcnow()},
        })
        if not plan_doc:
            return False
        if plan_doc.get("creditsRemaining", 0) <= 0:
            return False

        result = self.db.user_plans.update_one(
            {"_id": plan_doc["_id"], "creditsRemaining": {"$gt": 0}},
            {
                "$inc": {"creditsRemaining": -1},
                "$set": {"updatedAt": datetime.utcnow()},
            },
        )
        return result.modified_count > 0

    def get_remaining_credits(self):
        token_doc = self.db.access_tokens.find_one(
            {"token": self.hashed_token, "isActive": True}
        )
        if not token_doc:
            return 0

        user_id  = token_doc["userId"]
        plan_doc = self.db.user_plans.find_one({
            "userId":   user_id,
            "isActive": True,
            "expiresAt": {"$gte": datetime.utcnow()},
        })
        if not plan_doc:
            return 0
        return max(plan_doc.get("creditsRemaining", 0), 0)


# ----------------- Client Class -----------------
class Client:
    SUPPORTED_TICKERS = {
        "TCS", "HDFCBANK", "BHARTIARTL", "ICICIBANK", "SBIN", "INFY",
        "BAJFINANCE", "HINDUNILVR", "ITC", "MARUTI", "HCLTECH", "SUNPHARMA",
        "KOTAKBANK", "AXISBANK", "TATAMOTORS", "ULTRACEMCO", "BAJAJFINSV",
        "ADANIPORTS", "NTPC", "ONGC", "ASIANPAINT", "JSWSTEEL", "ADANIPOWER",
        "WIPRO", "ADANIENT", "POWERGRID", "NESTLEIND", "COALINDIA", "INDIGO",
        "HINDZINC", "TATASTEEL", "VEDL", "SBILIFE", "EICHERMOT", "GRASIM",
        "HINDALCO", "LTIM", "TVSMOTOR", "DIVISLAB", "HDFCLIFE", "PIDILITIND",
        "CHOLAFIN", "BRITANNIA", "AMBUJACEM", "GAIL", "BANKBARODA", "GODREJCP",
        "HEROMOTOCO", "TATAPOWER",
    }

    def __init__(
        self,
        access_token=None,
        token=None,
        base_url="http://34.70.223.89:8000/predict",
        mongo_uri="mongodb+srv://ankitarrow:ankitarrow@cluster0.zcajdur.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
        db_name="test",
    ):
        if access_token is None and token is None:
            raise ValueError("Access token must be provided as 'access_token' or 'token'.")

        self.access_token = (access_token or token).strip()
        self.base_url     = base_url

        print("=" * 60)
        print(" Initializing Mintzy")
        print("=" * 60)

        self.db            = Database(mongo_uri, db_name)
        self.token_manager = TokenManager(self.db, self.access_token)

    # ------------------------------------------------------------------
    # INTERNAL: parse server response → dict  { ticker -> list[dict] }
    # ------------------------------------------------------------------
    def _parse_response(self, response_json, tickers, parameters):
        """
        Returns:
            parsed   : { ticker: [ {Date, Time, Predicted Price}, ... ] }
            warnings : [ string ]
        """
        parsed   = {}
        warnings = []

        if not isinstance(response_json, dict):
            warnings.append(f"Unexpected response type: {type(response_json)}")
            return parsed, warnings

        result = response_json.get("result", response_json)

        for ticker in tickers:
            ticker_data = result.get(ticker) if isinstance(result, dict) else None

            if ticker_data is None:
                warnings.append(f"No data returned for {ticker}")
                continue

            if isinstance(ticker_data, str):
                warnings.append(f"{ticker}: server error — {ticker_data}")
                continue

            ticker_rows = []

            for param in parameters:
                param_data = (
                    ticker_data.get(param)
                    if isinstance(ticker_data, dict)
                    else None
                )

                if param_data is None:
                    warnings.append(f"{param} data missing for {ticker}")
                    continue

                # ── structured dict response ──────────────────────────
                if isinstance(param_data, dict):
                    timestamps       = param_data.get("timestamps", [])
                    predicted_prices = param_data.get("predicted_prices", [])
                    dates            = param_data.get("dates", [])
                    times            = param_data.get("times", [])

                    if not predicted_prices:
                        warnings.append(f"Empty prediction data for {ticker}.{param}")
                        continue

                    for i, price in enumerate(predicted_prices):
                        if price is None:
                            continue

                        # resolve timestamp
                        if i < len(timestamps):
                            ts_str = str(timestamps[i])
                            try:
                                dt       = datetime.fromisoformat(ts_str)
                                date_str = dt.strftime("%Y-%m-%d")
                                time_str = dt.strftime("%H:%M:%S")
                            except Exception:
                                date_str = str(dates[i]) if i < len(dates) else ts_str
                                time_str = str(times[i]) if i < len(times) else ""
                        else:
                            date_str = str(dates[i]) if i < len(dates) else ""
                            time_str = str(times[i]) if i < len(times) else ""

                        ticker_rows.append({
                            "Date":            date_str,
                            "Time":            time_str,
                            "Predicted Price": float(price),
                        })

                # ── legacy CSV string response ────────────────────────
                elif isinstance(param_data, str):
                    for line in param_data.strip().split("\n")[1:]:
                        parts = line.split()
                        if len(parts) >= 3:
                            ticker_rows.append({
                                "Date":            parts[0],
                                "Time":            parts[1],
                                "Predicted Price": float(parts[2]),
                            })
                else:
                    warnings.append(
                        f"Unsupported payload type for {ticker}.{param}: {type(param_data)}"
                    )

            if ticker_rows:
                parsed[ticker] = ticker_rows
            else:
                warnings.append(f"No valid rows parsed for {ticker}")

        return parsed, warnings

    # ------------------------------------------------------------------
    # INTERNAL: print one ticker's block immediately (avoids buffering)
    # ------------------------------------------------------------------
    def _print_ticker_block(self, ticker, rows, col_widths, spacing, divider_width):
        """Print a single ticker's rows directly to stdout and flush."""

        thin_div = "-" * divider_width

        def fmt(values):
            return spacing.join(
                f"{str(v):<{w}}" for v, w in zip(values, col_widths)
            )

        for row in rows:
            # ── round price to 2 decimal places ──────────────────────────
            price = f"{float(row['Predicted Price']):.2f}"
            line  = fmt([ticker, row["Date"], row["Time"], price])
            print(line)

        print(thin_div)
        sys.stdout.flush()        # ← force flush after every ticker block

    # ------------------------------------------------------------------
    # PUBLIC: format + stream-print the full prediction table
    # ------------------------------------------------------------------
    def _render_and_print(self, parsed, tickers):
        if not parsed:
            print("  No prediction data available.")
            return

        headers = ["Ticker", "Date", "Time", "Predicted Price"]
        spacing = "       "

        # ── compute column widths using ROUNDED prices ─────────────────
        all_rows_flat = []
        for ticker, rows in parsed.items():
            for r in rows:
                price_str = f"{float(r['Predicted Price']):.2f}"   # ← rounded
                all_rows_flat.append(
                    [ticker, r["Date"], r["Time"], price_str]
                )

        col_widths = []
        for idx, header in enumerate(headers):
            col_values = [row[idx] for row in all_rows_flat]
            col_widths.append(
                max(len(header), max((len(v) for v in col_values), default=0))
            )

        divider_width = sum(col_widths) + len(spacing) * (len(headers) - 1)
        divider       = "=" * divider_width

        def fmt(values):
            return spacing.join(
                f"{str(v):<{w}}" for v, w in zip(values, col_widths)
            )

        # ── header ─────────────────────────────────────────────────────
        print(divider)
        print(Fore.CYAN + fmt(headers) + Fore.RESET)
        print(divider)
        sys.stdout.flush()

        # ── one block per ticker — flush after each ─────────────────────
        for ticker in tickers:
            rows = parsed.get(ticker)
            if not rows:
                continue
            self._print_ticker_block(
                ticker, rows, col_widths, spacing, divider_width
            )

        sys.stdout.flush()
    # ------------------------------------------------------------------
    # INTERNAL: build combined DataFrame (returned to caller)
    # ------------------------------------------------------------------
    def _build_dataframe(self, parsed, tickers):
        frames = []
        for ticker in tickers:
            rows = parsed.get(ticker)
            if not rows:
                continue
            df = pd.DataFrame(rows)
            df.insert(0, "Ticker", ticker)
            frames.append(df[["Ticker", "Date", "Time", "Predicted Price"]])

        if frames:
            return pd.concat(frames, ignore_index=True)
        return pd.DataFrame(columns=["Ticker", "Date", "Time", "Predicted Price"])

    # ------------------------------------------------------------------
    # PUBLIC API
    # ------------------------------------------------------------------
    def get_prediction(self, tickers, time_frame, parameters, candle="1m"):
        # normalise inputs
        if isinstance(tickers, str):
            tickers = [tickers]
        if not isinstance(tickers, list):
            return {"success": False, "error": "Tickers must be a string or list"}

        invalid = [t for t in tickers if t.upper() not in self.SUPPORTED_TICKERS]
        if invalid:
            msg = f"Ticker(s) not supported currently: {', '.join(invalid)}"
            print(f"❌ {msg}")
            print(f"\n✅ Supported tickers: {', '.join(sorted(self.SUPPORTED_TICKERS))}")
            return {"success": False, "error": msg}

        tickers = [t.upper() for t in tickers]

        if isinstance(parameters, str):
            parameters = [parameters]

        try:
            print("\n" + "=" * 60)
            print("Getting Predictions")
            print("=" * 60)

            token_check = self.token_manager.check_token_and_credits()
            if not token_check["valid"]:
                print(f"❌ {token_check['error']}")
                return {"success": False, "error": token_check["error"]}

            print(f"📊 Tickers   : {', '.join(tickers)}")
            print(f"⏰ Time Frame: {time_frame}")
            print(f"🕒 Candle    : {candle}")
            print(f"📈 Parameters: {', '.join(parameters)}")

            payload = {
                "action": {
                    "action_type": "predict",
                    "predict": {
                        "given": {
                            "ticker":     tickers,
                            "time_frame": time_frame,
                            "candle":     candle,
                        },
                        "required": {"parameters": parameters},
                    },
                }
            }

            print("\n🔄 Fetching Predictions ...")
            response = requests.post(
                self.base_url,
                json=payload,
                headers={"X-Access-Token": self.access_token},
                timeout=300,
            )
            response.raise_for_status()
            response_json = response.json()

            # parse
            parsed, warnings = self._parse_response(response_json, tickers, parameters)

            # print any warnings first
            for w in warnings:
                print(f"⚠️  {w}")
                sys.stdout.flush()

            # stream-print table (flush per ticker — no truncation)
            print("\n" + "=" * 60)
            print(f"✅ Predictions ({time_frame}, candle={candle})")
            print("=" * 60)
            self._render_and_print(parsed, tickers)

            # deduct credit
            if self.token_manager.deduct_credit():
                remaining = self.token_manager.get_remaining_credits()
            else:
                remaining = 0

            print(f"💳 Remaining credits: {remaining}")
            if remaining <= 10:
                print(f"⚠️  Warning: Only {remaining} credits remaining!")
            if remaining == 0:
                print("❌ Credits exhausted! Please subscribe to a plan.")
            print("=" * 60)
            sys.stdout.flush()

            # build DataFrame for return value
            df = self._build_dataframe(parsed, tickers)

            return {
                "success":          True,
                "data":             df,
                "credits_remaining": remaining,
                "timestamp":        datetime.now().isoformat(),
            }

        except requests.exceptions.Timeout:
            msg = "Request timed out. Please try again."
            print(f" {msg}")
            return {"success": False, "error": msg}

        except requests.exceptions.RequestException as e:
            msg = f"API request failed: {str(e)}"
            print(f" {msg}")
            return {"success": False, "error": msg}

        except Exception as e:
            import traceback
            traceback.print_exc()
            msg = f"Unexpected error: {str(e)}"
            print(f" {msg}")
            return {"success": False, "error": msg}

    def get_credits(self):
        credits = self.token_manager.get_remaining_credits()
        print(f"💳 Remaining credits: {credits}")
        return credits
