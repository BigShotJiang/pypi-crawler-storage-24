"""
Pydantic schemas for Screenplay model JSONFields.

These schemas validate the JSONFields on screenplay-related models:
- Screenplay.parsed_metadata
- Location.int_ext_options, production_notes
- Scene.scene_arc_beats
- SceneContent.formatting
- Character.traits

Usage:
    from lightwave.schema.pydantic.models.screenplays import (
        ScreenplayMetadataSchema,
        LocationProductionNotesSchema,
        SceneArcBeatsSchema,
        TextFormattingSchema,
        CharacterTraitsSchema,
    )
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ScreenplayMetadataSchema(JSONFieldSchema):
    """
    Schema for Screenplay.parsed_metadata JSONField.

    Title page data extracted from FDX files.
    Contains writer credits, contact info, copyright, and draft date.

    Example:
        {
            "title": "The Great Adventure",
            "written_by": ["John Doe", "Jane Smith"],
            "contact_info": "john@example.com",
            "copyright": "© 2024 Production Co.",
            "draft_date": "January 15, 2024",
            "draft_color": "blue",
            "based_on": "Original screenplay"
        }
    """

    title: str | None = Field(None, description="Screenplay title from title page")
    written_by: list[str] = Field(default_factory=list, description="Writer credits")
    contact_info: str | None = Field(None, description="Contact information")
    copyright: str | None = Field(None, description="Copyright notice")
    draft_date: str | None = Field(None, description="Draft date")
    draft_color: str | None = Field(None, description="Revision color")
    based_on: str | None = Field(None, description="Based on source material")
    registered_wga: str | None = Field(None, description="WGA registration number")
    additional_credits: list[str] = Field(default_factory=list, description="Additional credits (story by, etc.)")


class LocationProductionNotesSchema(JSONFieldSchema):
    """
    Schema for Location.production_notes JSONField.

    Production notes for screenplay locations.
    Contains accessibility info, permits, contacts, and photos.

    Example:
        {
            "accessibility": "Wheelchair accessible",
            "permit_required": true,
            "permit_contact": "City Film Office",
            "site_contact": {"name": "John", "phone": "555-1234"},
            "photos": ["location_scout_01.jpg"],
            "parking_notes": "Street parking only",
            "power_available": true,
            "notes": "Great natural light in morning"
        }
    """

    accessibility: str | None = Field(None, description="Accessibility information")
    permit_required: bool = Field(False, description="Whether permit is required")
    permit_contact: str | None = Field(None, description="Permit contact info")
    site_contact: dict[str, str] | None = Field(None, description="Site contact person (name, phone, email)")
    photos: list[str] = Field(default_factory=list, description="Photo references/URLs")
    parking_notes: str | None = Field(None, description="Parking information")
    power_available: bool | None = Field(None, description="Whether power is available")
    restroom_access: bool | None = Field(None, description="Restroom availability")
    catering_area: bool | None = Field(None, description="Catering area available")
    load_in_notes: str | None = Field(None, description="Equipment load-in notes")
    notes: str | None = Field(None, description="General production notes")


class SceneArcBeatsSchema(JSONFieldSchema):
    """
    Schema for Scene.scene_arc_beats JSONField.

    Character arc data and story beats from FDX parsing.
    Contains emotional beats, plot points, and character arcs.

    Example:
        {
            "story_beat": "Inciting Incident",
            "emotional_tone": "tense",
            "character_arcs": {
                "HERO": {"state": "conflicted", "goal": "escape"},
                "VILLAIN": {"state": "determined", "goal": "capture"}
            },
            "plot_points": ["Discovery of the secret", "First confrontation"],
            "themes": ["betrayal", "redemption"]
        }
    """

    story_beat: str | None = Field(None, description="Story beat classification")
    emotional_tone: str | None = Field(None, description="Emotional tone of scene")
    character_arcs: dict[str, dict[str, str]] = Field(
        default_factory=dict, description="Character arc data by character name"
    )
    plot_points: list[str] = Field(default_factory=list, description="Plot points in this scene")
    themes: list[str] = Field(default_factory=list, description="Thematic elements")
    tension_level: int | None = Field(None, ge=1, le=10, description="Tension level (1-10)")
    pacing: str | None = Field(None, description="Scene pacing (slow, medium, fast)")


class TextFormattingSchema(JSONFieldSchema):
    """
    Schema for SceneContent.formatting JSONField.

    Text formatting flags for scene content blocks.
    Tracks bold, italic, underline, strikethrough, etc.

    Example:
        {
            "bold": false,
            "italic": true,
            "underline": false,
            "strikethrough": false,
            "all_caps": false,
            "color": null
        }
    """

    bold: bool = Field(False, description="Text is bold")
    italic: bool = Field(False, description="Text is italic")
    underline: bool = Field(False, description="Text is underlined")
    strikethrough: bool = Field(False, description="Text has strikethrough")
    all_caps: bool = Field(False, description="Text is all caps")
    color: str | None = Field(None, description="Text color (hex code)")
    font_size: int | None = Field(None, description="Font size override")
    alignment: str | None = Field(None, description="Text alignment (left, center, right)")


class CharacterTraitsSchema(JSONFieldSchema):
    """
    Schema for Character.traits JSONField.

    Character traits extracted from screenplay.
    Contains age, gender, occupation, and description.

    Example:
        {
            "age": "mid-30s",
            "gender": "female",
            "occupation": "Detective",
            "physical_description": "Tall, athletic build",
            "personality": "Determined, analytical",
            "background": "Former military intelligence",
            "distinguishing_features": ["scar on left cheek"]
        }
    """

    age: str | None = Field(None, description="Character age or age range")
    gender: str | None = Field(None, description="Character gender")
    occupation: str | None = Field(None, description="Character occupation")
    physical_description: str | None = Field(None, description="Physical appearance")
    personality: str | None = Field(None, description="Personality traits")
    background: str | None = Field(None, description="Character background/history")
    distinguishing_features: list[str] = Field(default_factory=list, description="Notable physical features")
    relationships: dict[str, str] = Field(default_factory=dict, description="Relationships to other characters")
    arc_summary: str | None = Field(None, description="Character arc summary")
