"""
Pydantic schemas for Filmography model JSONFields.

These schemas validate the JSONFields on filmography models:
- FilmographyCredit.metadata

SST Source: definitions/data/models/movies.yaml (FilmographyCredit section)
Field Options: definitions/config/constraints/movie_options.yaml

Usage:
    from lightwave.schema.pydantic.models.filmography import (
        FilmographyCreditMetadataSchema,
    )
"""

from __future__ import annotations

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FilmographyCreditMetadataSchema(JSONFieldSchema):
    """
    Schema for FilmographyCredit.metadata JSONField.

    Stores additional filmography claim data not captured by standard fields.

    Example:
        {
            "portfolio_display": true,
            "show_poster": true,
            "custom_description": "Shot on ARRI Alexa Mini LF with Cooke S7/i lenses",
            "media_urls": [
                "https://cdn.example.com/bts-photo-1.jpg"
            ],
            "awards": ["Best Cinematography - Sundance 2024"],
            "external_links": {
                "imdb": "https://www.imdb.com/title/tt1234567/",
                "letterboxd": "https://letterboxd.com/film/movie-name/"
            }
        }
    """

    portfolio_display: bool = Field(
        True,
        description="Whether to show this credit in portfolio view",
    )
    show_poster: bool = Field(
        True,
        description="Whether to display the movie poster with this credit",
    )
    custom_description: str = Field(
        "",
        description="User's custom description of their work on this project",
    )
    media_urls: list[str] = Field(
        default_factory=list,
        description="URLs to BTS photos or other media for this credit",
    )
    awards: list[str] = Field(
        default_factory=list,
        description="Awards received for work on this project",
    )
    external_links: dict[str, str] = Field(
        default_factory=dict,
        description="External URLs (imdb, letterboxd, vimeo, etc.)",
    )
    reel_timestamp: str = Field(
        "",
        description="Timestamp in user's reel where this project appears (MM:SS)",
    )
