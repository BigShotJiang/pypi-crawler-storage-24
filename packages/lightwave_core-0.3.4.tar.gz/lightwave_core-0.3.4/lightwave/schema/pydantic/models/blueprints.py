"""
Pydantic schemas for Blueprint model JSONFields.

These schemas validate the JSONFields on blueprint-related models:
- SiteMapBlueprint: navigation_structure, staging_data
- SiteMapBlueprintNode: seo_metadata, conversion_goals
- PageBlueprint: component_list, layout_metadata, staging_component_list
- ContentRequirement: validation_rules, good_examples, bad_examples, tone_voice
- UserFlowBlueprint: stages, staging_stages

Usage:
    from lightwave.schema.pydantic.models.blueprints import (
        NavigationStructureSchema,
        SeoMetadataSchema,
        ComponentListItemSchema,
        LayoutMetadataSchema,
        ValidationRulesSchema,
        ToneVoiceSchema,
        UserFlowStageSchema,
    )
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class NavigationStructureSchema(JSONFieldSchema):
    """
    Schema for SiteMapBlueprint.navigation_structure JSONField.

    Navigation menus structure mapping menu names to page titles.

    Example:
        {
            "main": ["About", "Features", "Pricing", "Blog"],
            "footer": ["Privacy", "Terms", "Contact"],
            "mobile": ["Features", "Pricing", "Login"]
        }
    """

    main: list[str] = Field(default_factory=list, description="Main navigation items")
    footer: list[str] = Field(default_factory=list, description="Footer navigation items")
    mobile: list[str] = Field(default_factory=list, description="Mobile navigation items")
    secondary: list[str] = Field(default_factory=list, description="Secondary navigation items")


class SeoMetadataSchema(JSONFieldSchema):
    """
    Schema for SiteMapBlueprintNode.seo_metadata JSONField.

    SEO metadata for page nodes.

    Example:
        {
            "meta_title": "About Us | Cineos",
            "meta_description": "Learn about Cineos and our mission...",
            "og_image": "/images/about-og.jpg",
            "keywords": ["filmmaking", "production", "tools"],
            "canonical_url": "https://cineos.io/about",
            "no_index": false
        }
    """

    meta_title: str | None = Field(None, description="SEO title tag")
    meta_description: str | None = Field(None, description="Meta description")
    og_image: str | None = Field(None, description="Open Graph image URL")
    og_title: str | None = Field(None, description="Open Graph title override")
    og_description: str | None = Field(None, description="Open Graph description override")
    keywords: list[str] = Field(default_factory=list, description="SEO keywords")
    canonical_url: str | None = Field(None, description="Canonical URL")
    no_index: bool = Field(False, description="Prevent search indexing")
    no_follow: bool = Field(False, description="Prevent link following")
    structured_data: dict[str, Any] | None = Field(None, description="JSON-LD structured data")


class ComponentListItemSchema(JSONFieldSchema):
    """
    Schema for individual component in PageBlueprint.component_list.

    Defines a component in the page blueprint layout.

    Example:
        {
            "component_type": "hero",
            "order": 0,
            "variant": "centered",
            "notes": "Hero with company tagline",
            "props_override": {}
        }
    """

    component_type: str = Field(..., description="Component type (hero, cta, features, etc.)")
    order: int = Field(0, ge=0, description="Order in page layout")
    variant: str = Field("default", description="Component variant")
    notes: str = Field("", description="Implementation notes")
    props_override: dict[str, Any] = Field(default_factory=dict, description="Props to override defaults")
    is_optional: bool = Field(False, description="Whether component is optional")


class LayoutMetadataSchema(JSONFieldSchema):
    """
    Schema for PageBlueprint.layout_metadata JSONField.

    Layout hints for page rendering.

    Example:
        {
            "max_width": "1200px",
            "spacing": "relaxed",
            "background_color": "#ffffff",
            "container_padding": "2rem"
        }
    """

    max_width: str | None = Field(None, description="Maximum content width")
    spacing: str = Field("normal", description="Spacing preset (compact, normal, relaxed)")
    background_color: str | None = Field(None, description="Page background color")
    container_padding: str | None = Field(None, description="Container padding")
    full_width_sections: list[int] = Field(
        default_factory=list, description="Component indices that should be full-width"
    )
    sticky_header: bool = Field(True, description="Whether header should be sticky")
    show_breadcrumbs: bool = Field(False, description="Show breadcrumb navigation")


class ValidationRulesSchema(JSONFieldSchema):
    """
    Schema for ContentRequirement.validation_rules JSONField.

    Validation rules for content fields.

    Example:
        {
            "min_words": 5,
            "max_words": 10,
            "min_chars": 20,
            "max_chars": 100,
            "no_periods": true,
            "benefit_focused": true,
            "action_verb_first": false,
            "required": true
        }
    """

    min_words: int | None = Field(None, ge=0, description="Minimum word count")
    max_words: int | None = Field(None, ge=0, description="Maximum word count")
    min_chars: int | None = Field(None, ge=0, description="Minimum character count")
    max_chars: int | None = Field(None, ge=0, description="Maximum character count")
    no_periods: bool = Field(False, description="Headlines shouldn't end with periods")
    benefit_focused: bool = Field(False, description="Should contain benefit language")
    action_verb_first: bool = Field(False, description="Should start with action verb")
    required: bool = Field(True, description="Whether field is required")
    pattern: str | None = Field(None, description="Regex pattern to match")
    forbidden_words: list[str] = Field(default_factory=list, description="Words that should not appear")


class ToneVoiceSchema(JSONFieldSchema):
    """
    Schema for ContentRequirement.tone_voice JSONField.

    Tone and voice specification for content.

    Example:
        {
            "tone": "confident",
            "voice": "professional",
            "formality": "semi-formal",
            "emotion": "optimistic",
            "person": "second"
        }
    """

    tone: str | None = Field(
        None,
        description="Tone (confident, friendly, authoritative, casual, urgent)",
    )
    voice: str | None = Field(None, description="Voice (professional, conversational, technical)")
    formality: str | None = Field(None, description="Formality level (formal, semi-formal, casual)")
    emotion: str | None = Field(None, description="Emotional quality (optimistic, empathetic, neutral)")
    person: str | None = Field(None, description="Person (first, second, third)")
    avoid: list[str] = Field(default_factory=list, description="Phrases or styles to avoid")


class UserFlowStageSchema(JSONFieldSchema):
    """
    Schema for individual stage in UserFlowBlueprint.stages list.

    Defines a stage in the user journey funnel.

    Example:
        {
            "name": "Awareness",
            "entry_points": ["/", "/blog", "/features"],
            "goal": "Learn about product value",
            "success_criteria": ["Time on page > 30s", "Scroll depth > 50%"],
            "drop_off_risks": ["Unclear value prop", "No clear CTA"],
            "optimizations": ["Stronger headline", "Video demo above fold"]
        }
    """

    name: str = Field(..., description="Stage name (Awareness, Consideration, etc.)")
    entry_points: list[str] = Field(default_factory=list, description="URLs/paths where users enter this stage")
    goal: str = Field("", description="What the user should accomplish")
    success_criteria: list[str] = Field(default_factory=list, description="Metrics that indicate success")
    drop_off_risks: list[str] = Field(default_factory=list, description="Reasons users might leave")
    optimizations: list[str] = Field(default_factory=list, description="Suggested improvements")
    conversion_events: list[str] = Field(default_factory=list, description="Analytics events to track")
    estimated_time: str | None = Field(None, description="Expected time users spend in this stage")
