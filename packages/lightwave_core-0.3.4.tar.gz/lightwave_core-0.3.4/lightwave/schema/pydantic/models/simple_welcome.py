"""
Simple Welcome Email Props Schema.

SST Source: definitions/emails/simple-welcome.yaml

This schema provides type-safe props for the SimpleWelcome01 email template.
The TypeScript interface in the React component should mirror this schema.

Flow: YAML definition → Pydantic schema → TypeScript types → React Email

Usage:
    from lightwave.schema.pydantic.models.simple_welcome import SimpleWelcomeProps

    props = SimpleWelcomeProps(
        recipient_name="Olivia",
        message_body="Welcome to LightWave!",
        cta_href="https://app.cineos.io/login",
    )
    # Serialize to JSON for React Email
    props_json = props.model_dump(mode="json", by_alias=True)
"""

from typing import Literal

from pydantic import ConfigDict, Field, HttpUrl, field_validator

from lightwave.schema.pydantic.core.base import LightwaveBaseSchema


class SimpleWelcomeProps(LightwaveBaseSchema):
    """
    Props for SimpleWelcome01 email template.

    Matches TypeScript interface:
        interface SimpleWelcomeProps {
            recipientName: string;
            previewText?: string;
            greeting?: string | null;
            headline?: string | null;
            messageBody: string;
            signOff?: string;
            ctaText?: string;
            ctaHref: string;
            theme?: "light" | "dark";
        }
    """

    # Recipient info
    recipient_name: str = Field(
        ...,
        min_length=1,
        serialization_alias="recipientName",
        description="Recipient's display name for greeting",
    )

    # Email content
    preview_text: str = Field(
        "Welcome to LightWave",
        serialization_alias="previewText",
        description="Preview text shown in email clients",
    )

    greeting: str | None = Field(
        None,
        description="Custom greeting override. If null, uses 'Hi {recipient_name},'",
    )

    headline: str | None = Field(
        None,
        description="Optional headline above the message body",
    )

    message_body: str = Field(
        ...,
        min_length=1,
        serialization_alias="messageBody",
        description="Main email body content (supports line breaks)",
    )

    sign_off: str = Field(
        "Thanks,\nThe team",
        serialization_alias="signOff",
        description="Sign-off text at end of message",
    )

    # CTA Button
    cta_text: str = Field(
        "Log in",
        serialization_alias="ctaText",
        description="Call-to-action button text",
    )

    cta_href: HttpUrl = Field(
        ...,
        serialization_alias="ctaHref",
        description="Call-to-action button link",
    )

    # Theme
    theme: Literal["light", "dark"] = Field(
        "light",
        description="Email color theme",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        extra="forbid",
    )

    @field_validator("recipient_name")
    @classmethod
    def validate_recipient_name(cls, v: str) -> str:
        """Ensure recipient name is not just whitespace."""
        if not v.strip():
            raise ValueError("recipient_name cannot be empty or whitespace")
        return v.strip()

    @property
    def formatted_greeting(self) -> str:
        """Get the actual greeting to display."""
        if self.greeting:
            return self.greeting
        return f"Hi {self.recipient_name},"


# Export for convenient imports
__all__ = ["SimpleWelcomeProps"]
