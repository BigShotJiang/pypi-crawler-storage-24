"""
Pydantic schemas for Django model JSONFields.

These schemas validate data stored in PostgreSQL JSONB columns.
Each schema corresponds to a JSONField in a Django model.

Usage:
    from lightwave.schema.pydantic.models import (
        # createOS schemas
        PersonaSchema,
        UserFlowSchema,
        ImplementationPlanRiskSchema,
        DebriefInsightSchema,
        # CMS schemas
        SiteSettingsSchema,
        PageMetadataSchema,
        AgentPermissionsSchema,
        # AI schemas
        AgentInputContextSchema,
        AgentOutputResultSchema,
        # Production schemas
        ProjectSettingsSchema,
        WeatherForecastSchema,
        # ... and more
    )
"""

from lightwave.schema.pydantic.models.accounting import (
    QBOWebhookDataChangeSchema,
    QBOWebhookEntitySchema,
    QBOWebhookPayloadSchema,
)
from lightwave.schema.pydantic.models.ai import (
    AgentInputContextSchema,
    AgentOutputResultSchema,
    AutomationErrorSchema,
    BugReportContextSchema,
    HallucinationInputDataSchema,
    ValidationResultSchema,
)
from lightwave.schema.pydantic.models.blueprints import (
    ComponentListItemSchema,
    LayoutMetadataSchema,
    NavigationStructureSchema,
    SeoMetadataSchema,
    ToneVoiceSchema,
    UserFlowStageSchema,
    ValidationRulesSchema,
)
from lightwave.schema.pydantic.models.claude import (
    AgentMetricsSchema,
    AgentSuggestionRequestSchema,
    AgentSuggestionResponseSchema,
    AgentToolConfigSchema,
    # Rule schemas
    BranchPatternSchema,
    # Context schemas
    ContextProfileConfigSchema,
    # API schemas
    ContextRequestSchema,
    ContextResponseSchema,
    # Agent schemas
    IntentPatternSchema,
    # Knowledge schemas
    KnowledgeSourceSchema,
    # Package schemas
    PackageVersionSchema,
    RuleApplicabilitySchema,
    SecurityAdvisorySchema,
    SessionSummarySchema,
    StalenessInfoSchema,
    # Session schemas
    ToolInvocationSchema,
)
from lightwave.schema.pydantic.models.cms import (
    # Agent permissions
    AgentPermissionsSchema,
    AuthSettingsSchema,
    BrandSettingsSchema,
    BulkOperationPayloadSchema,
    CodeBlockPropsSchema,
    # Component props
    ComponentPropsBaseSchema,
    CTAPropsSchema,
    FeatureGridPropsSchema,
    FeatureSettingsSchema,
    HeadingBlockPropsSchema,
    HeroPropsSchema,
    ImageBlockPropsSchema,
    InlineBlockSchema,
    PageBlockReferenceSchema,
    # Outbox payloads
    PageCreationPayloadSchema,
    PageDeletionPayloadSchema,
    # Page schemas
    PageMetadataSchema,
    PageUpdatePayloadSchema,
    PageVersionDataSchema,
    # Block props
    ParagraphBlockPropsSchema,
    QuoteBlockPropsSchema,
    # Site settings
    SiteSettingsSchema,
    ThemeSettingsSchema,
)
from lightwave.schema.pydantic.models.constitution import (
    AgentDefaults,
    # Composed constitution
    ComposedConstitution,
    # Config
    ConstitutionConfig,
    Constraint,
    FinancialContext,
    KnowledgeBook,
    KnowledgeFilm,
    # User context models
    LegalEntityContext,
    # Base constitution models
    Principle,
    ProfessionalContext,
    SecondBrainEntryContext,
    TransformationPromise,
    UserIdentityContext,
    UserPrincipleEntry,
    VerificationContext,
    VoiceModel,
    WeightedConstraint,
)
from lightwave.schema.pydantic.models.createos import (
    # UserStory JSONField schemas
    AcceptanceCriterionSchema,
    # ImplementationPlan JSONField schemas
    CriticalFileSchema,
    # Debrief JSONField schemas
    DebriefInsightSchema,
    DependencySchema,
    EdgeCaseSchema,
    ImplementationPlanRiskSchema,
    InterviewMessageSchema,
    PastAchievementSchema,
    PatternSchema,
    PersonaSchema,
    RBACRequirementSchema,
    RoadmapMilestoneSchema,
    TechnicalConstraintSchema,
    # TestSpecification JSONField schemas
    TestScenarioSchema,
    UserFlowSchema,
)
from lightwave.schema.pydantic.models.deployment import (
    CommandResult,
    # Configuration
    DeploymentConfig,
    # Execution
    DeploymentRun,
    DeploymentValidator,
    EnvironmentDefinition,
    # Enums
    EnvironmentType,
    # Failure modes
    FailureMode,
    InfraConfig,
    ManualRollback,
    PhaseDefinition,
    PhaseResult,
    PhaseType,
    RollbackCommand,
    # Rollback
    RollbackConfig,
    SchemaUpdate,
    # Steps and Phases
    StepDefinition,
    StepResult,
    StepStatus,
    # Validation
    ValidationCriteria,
    ValidationError,
    ValidationResult,
    ValidationType,
    execute_command,
)
from lightwave.schema.pydantic.models.documents import (
    # Base schemas
    BaseDocumentMetadataSchema,
    # Category-specific schemas
    BlogMetadataSchema,
    DocumentCategoryConfigSchema,
    DocumentMetadataSchema,
    EmailTemplateMetadataSchema,
    FeatureMetadataSchema,
    InternalMetadataSchema,
    KnowledgeMetadataSchema,
    LegalMetadataSchema,
    MarketingMetadataSchema,
    SupportMetadataSchema,
    # Factory functions
    get_metadata_schema,
    validate_document_metadata,
)
from lightwave.schema.pydantic.models.emails import (
    ActionMetadataSchema,
    EmailAttachmentSchema,
    EmailEventPayloadSchema,
    EmailRecipientSchema,
    ExtractedEntitiesSchema,
    GmailScopesSchema,
    RawEmailHeadersSchema,
    SegmentFilterSchema,
    SubscriberPreferencesSchema,
    SuggestedActionSchema,
)
from lightwave.schema.pydantic.models.google import (
    SyncChangeSchema,
    SyncMetadataSchema,
    SyncRolesSchema,
    validate_groups_list,
)
from lightwave.schema.pydantic.models.infrastructure import (
    AttackResultSchema,
    SecurityDrillReportSchema,
    VulnerabilityScanResultSchema,
    validate_report_data,
)
from lightwave.schema.pydantic.models.principles import (
    KeywordsSchema,
    validate_keywords_list,
)
from lightwave.schema.pydantic.models.production import (
    DeliverableSpecsSchema,
    ProjectSettingsSchema,
    WeatherForecastSchema,
)
from lightwave.schema.pydantic.models.screenplays import (
    CharacterTraitsSchema,
    LocationProductionNotesSchema,
    SceneArcBeatsSchema,
    ScreenplayMetadataSchema,
    TextFormattingSchema,
)
from lightwave.schema.pydantic.models.tenants import (
    TenantFeaturesSchema,
)

__all__ = [
    # =========================================================================
    # createOS schemas
    # =========================================================================
    # UserStory
    "PersonaSchema",
    "UserFlowSchema",
    "EdgeCaseSchema",
    "TechnicalConstraintSchema",
    "RBACRequirementSchema",
    "InterviewMessageSchema",
    "AcceptanceCriterionSchema",
    # TestSpecification
    "TestScenarioSchema",
    # ImplementationPlan
    "RoadmapMilestoneSchema",
    "PastAchievementSchema",
    "CriticalFileSchema",
    "DependencySchema",
    "ImplementationPlanRiskSchema",
    # Debrief
    "PatternSchema",
    "DebriefInsightSchema",
    # =========================================================================
    # CMS schemas
    # =========================================================================
    # Site settings
    "SiteSettingsSchema",
    "BrandSettingsSchema",
    "AuthSettingsSchema",
    "FeatureSettingsSchema",
    "ThemeSettingsSchema",
    # Page schemas
    "PageMetadataSchema",
    "PageBlockReferenceSchema",
    "InlineBlockSchema",
    "PageVersionDataSchema",
    # Outbox payloads
    "PageCreationPayloadSchema",
    "PageUpdatePayloadSchema",
    "PageDeletionPayloadSchema",
    "BulkOperationPayloadSchema",
    # Component props
    "ComponentPropsBaseSchema",
    "HeroPropsSchema",
    "CTAPropsSchema",
    "FeatureGridPropsSchema",
    # Block props
    "ParagraphBlockPropsSchema",
    "HeadingBlockPropsSchema",
    "ImageBlockPropsSchema",
    "CodeBlockPropsSchema",
    "QuoteBlockPropsSchema",
    # Agent permissions
    "AgentPermissionsSchema",
    # =========================================================================
    # AI Agent Tracking schemas
    # =========================================================================
    "AgentInputContextSchema",
    "AgentOutputResultSchema",
    "HallucinationInputDataSchema",
    "ValidationResultSchema",
    "AutomationErrorSchema",
    "BugReportContextSchema",
    # =========================================================================
    # Screenplay schemas (CineOS)
    # =========================================================================
    "ScreenplayMetadataSchema",
    "LocationProductionNotesSchema",
    "SceneArcBeatsSchema",
    "TextFormattingSchema",
    "CharacterTraitsSchema",
    # =========================================================================
    # Production schemas (CineOS)
    # =========================================================================
    "ProjectSettingsSchema",
    "WeatherForecastSchema",
    "DeliverableSpecsSchema",
    # =========================================================================
    # Principles schemas (v_guru)
    # =========================================================================
    "KeywordsSchema",
    "validate_keywords_list",
    # =========================================================================
    # Email schemas
    # =========================================================================
    "EmailRecipientSchema",
    "RawEmailHeadersSchema",
    "EmailAttachmentSchema",
    "ExtractedEntitiesSchema",
    "SuggestedActionSchema",
    "ActionMetadataSchema",
    "GmailScopesSchema",
    "EmailEventPayloadSchema",
    "SubscriberPreferencesSchema",
    "SegmentFilterSchema",
    # =========================================================================
    # Blueprint schemas (UX planning)
    # =========================================================================
    "NavigationStructureSchema",
    "SeoMetadataSchema",
    "ComponentListItemSchema",
    "LayoutMetadataSchema",
    "ValidationRulesSchema",
    "ToneVoiceSchema",
    "UserFlowStageSchema",
    # =========================================================================
    # Google Workspace schemas
    # =========================================================================
    "SyncRolesSchema",
    "SyncChangeSchema",
    "SyncMetadataSchema",
    "validate_groups_list",
    # =========================================================================
    # Accounting schemas (QuickBooks)
    # =========================================================================
    "QBOWebhookEntitySchema",
    "QBOWebhookDataChangeSchema",
    "QBOWebhookPayloadSchema",
    # =========================================================================
    # Tenant schemas
    # =========================================================================
    "TenantFeaturesSchema",
    # =========================================================================
    # Infrastructure schemas (Security Audit)
    # =========================================================================
    "AttackResultSchema",
    "VulnerabilityScanResultSchema",
    "SecurityDrillReportSchema",
    "validate_report_data",
    # =========================================================================
    # Deployment schemas
    # =========================================================================
    # Enums
    "EnvironmentType",
    "PhaseType",
    "StepStatus",
    "ValidationType",
    # Configuration
    "DeploymentConfig",
    "InfraConfig",
    "EnvironmentDefinition",
    # Steps and Phases
    "StepDefinition",
    "StepResult",
    "PhaseDefinition",
    "PhaseResult",
    # Validation
    "ValidationCriteria",
    "ValidationResult",
    "ValidationError",
    # Failure modes
    "FailureMode",
    "SchemaUpdate",
    # Rollback
    "RollbackConfig",
    "RollbackCommand",
    "ManualRollback",
    # Execution
    "DeploymentRun",
    "DeploymentValidator",
    "CommandResult",
    "execute_command",
    # =========================================================================
    # Claude Control Plane schemas
    # =========================================================================
    # Rule schemas
    "BranchPatternSchema",
    "RuleApplicabilitySchema",
    # Agent schemas
    "IntentPatternSchema",
    "AgentToolConfigSchema",
    "AgentMetricsSchema",
    # Knowledge schemas
    "KnowledgeSourceSchema",
    "StalenessInfoSchema",
    # Context schemas
    "ContextProfileConfigSchema",
    # Package schemas
    "PackageVersionSchema",
    "SecurityAdvisorySchema",
    # Session schemas
    "ToolInvocationSchema",
    "SessionSummarySchema",
    # API schemas
    "ContextRequestSchema",
    "ContextResponseSchema",
    "AgentSuggestionRequestSchema",
    "AgentSuggestionResponseSchema",
    # =========================================================================
    # Document schemas (Unified Document Model)
    # =========================================================================
    # Base schemas
    "BaseDocumentMetadataSchema",
    "DocumentCategoryConfigSchema",
    "DocumentMetadataSchema",
    # Category-specific schemas
    "KnowledgeMetadataSchema",
    "LegalMetadataSchema",
    "BlogMetadataSchema",
    "MarketingMetadataSchema",
    "FeatureMetadataSchema",
    "SupportMetadataSchema",
    "InternalMetadataSchema",
    "EmailTemplateMetadataSchema",
    # Factory functions
    "get_metadata_schema",
    "validate_document_metadata",
    # =========================================================================
    # Constitution schemas (Dynamic AI Context)
    # =========================================================================
    # Config
    "ConstitutionConfig",
    # Base constitution models
    "Principle",
    "VoiceModel",
    "KnowledgeBook",
    "KnowledgeFilm",
    "TransformationPromise",
    "Constraint",
    "WeightedConstraint",
    "AgentDefaults",
    # User context models
    "LegalEntityContext",
    "FinancialContext",
    "ProfessionalContext",
    "VerificationContext",
    "UserIdentityContext",
    "UserPrincipleEntry",
    "SecondBrainEntryContext",
    # Composed constitution
    "ComposedConstitution",
]
