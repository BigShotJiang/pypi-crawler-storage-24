"""
Pydantic schemas for Production model JSONFields.

These schemas validate the JSONFields on production-related models:
- Project.settings
- ShootDay.weather_forecast
- CallSheet.distribution_list
- Deliverable.specs

Usage:
    from lightwave.schema.pydantic.models.production import (
        ProjectSettingsSchema,
        WeatherForecastSchema,
        DeliverableSpecsSchema,
    )
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ProjectSettingsSchema(JSONFieldSchema):
    """
    Schema for Project.settings JSONField.

    Additional project configuration for film production.
    Contains technical specs, workflow settings, and preferences.

    Example:
        {
            "frame_rate": "23.976",
            "resolution": "4096x2160",
            "codec": "ARRIRAW",
            "color_pipeline": "ACES",
            "luts": ["show_lut_v3.cube"],
            "dailies_format": "ProRes 422",
            "editorial_fps": "24",
            "delivery_specs": {}
        }
    """

    frame_rate: str | None = Field(None, description="Project frame rate")
    resolution: str | None = Field(None, description="Target resolution")
    codec: str | None = Field(None, description="Preferred codec")
    color_pipeline: str | None = Field(None, description="Color management pipeline")
    luts: list[str] = Field(default_factory=list, description="LUT files for the project")
    dailies_format: str | None = Field(None, description="Dailies delivery format")
    editorial_fps: str | None = Field(None, description="Editorial timeline frame rate")
    delivery_specs: dict[str, str] = Field(default_factory=dict, description="Final delivery specifications")
    audio_sample_rate: str | None = Field(None, description="Audio sample rate")
    audio_bit_depth: str | None = Field(None, description="Audio bit depth")
    timecode_format: str | None = Field(None, description="Timecode format (drop/non-drop)")
    backup_strategy: str | None = Field(None, description="Data backup strategy")


class WeatherForecastSchema(JSONFieldSchema):
    """
    Schema for ShootDay.weather_forecast JSONField.

    Weather forecast data for shoot day planning.
    Contains temperature, conditions, and hourly breakdown.

    Example:
        {
            "date": "2024-01-15",
            "sunrise": "07:15",
            "sunset": "17:30",
            "temperature_high": 72,
            "temperature_low": 55,
            "conditions": "Partly Cloudy",
            "precipitation_chance": 20,
            "wind_speed": 8,
            "wind_direction": "NW",
            "humidity": 45,
            "hourly": [
                {"hour": 6, "temp": 55, "conditions": "Clear"},
                {"hour": 12, "temp": 70, "conditions": "Partly Cloudy"}
            ],
            "alerts": [],
            "source": "weather.gov"
        }
    """

    date: str | None = Field(None, description="Forecast date (YYYY-MM-DD)")
    sunrise: str | None = Field(None, description="Sunrise time (HH:MM)")
    sunset: str | None = Field(None, description="Sunset time (HH:MM)")
    temperature_high: float | None = Field(None, description="High temperature (°F)")
    temperature_low: float | None = Field(None, description="Low temperature (°F)")
    conditions: str | None = Field(None, description="Weather conditions summary")
    precipitation_chance: float | None = Field(None, ge=0, le=100, description="Precipitation chance (%)")
    wind_speed: float | None = Field(None, description="Wind speed (mph)")
    wind_direction: str | None = Field(None, description="Wind direction")
    humidity: float | None = Field(None, ge=0, le=100, description="Humidity (%)")
    uv_index: int | None = Field(None, ge=0, le=11, description="UV index")
    hourly: list[dict[str, float | int | str]] = Field(default_factory=list, description="Hourly forecast breakdown")
    alerts: list[str] = Field(default_factory=list, description="Weather alerts/warnings")
    source: str | None = Field(None, description="Weather data source")
    last_updated: str | None = Field(None, description="Last update timestamp")


class DeliverableSpecsSchema(JSONFieldSchema):
    """
    Schema for Deliverable.specs JSONField.

    Technical specifications for deliverables.
    Contains resolution, codec, color space, and audio details.

    Example:
        {
            "resolution": "3840x2160",
            "frame_rate": "23.976",
            "codec": "ProRes 422 HQ",
            "bit_depth": "10-bit",
            "color_space": "Rec. 709",
            "hdr": false,
            "audio_codec": "PCM",
            "audio_channels": "5.1",
            "audio_sample_rate": "48000",
            "loudness_standard": "EBU R128",
            "subtitles_format": "SRT",
            "container": "MOV",
            "notes": "Per distributor specifications v2.1"
        }
    """

    resolution: str | None = Field(None, description="Video resolution")
    frame_rate: str | None = Field(None, description="Frame rate")
    codec: str | None = Field(None, description="Video codec")
    bit_depth: str | None = Field(None, description="Color bit depth")
    color_space: str | None = Field(None, description="Color space")
    hdr: bool = Field(False, description="HDR enabled")
    hdr_format: str | None = Field(None, description="HDR format if applicable")
    audio_codec: str | None = Field(None, description="Audio codec")
    audio_channels: str | None = Field(None, description="Audio channel layout")
    audio_sample_rate: str | None = Field(None, description="Audio sample rate")
    audio_bit_depth: str | None = Field(None, description="Audio bit depth")
    loudness_standard: str | None = Field(None, description="Loudness standard (EBU R128, ATSC A/85)")
    subtitles_format: str | None = Field(None, description="Subtitles format")
    subtitles_languages: list[str] = Field(default_factory=list, description="Subtitle languages required")
    container: str | None = Field(None, description="Container format (MOV, MXF, etc.)")
    max_file_size: str | None = Field(None, description="Maximum file size limit")
    delivery_method: str | None = Field(None, description="Delivery method (Aspera, FTP, physical)")
    notes: str | None = Field(None, description="Additional specification notes")
