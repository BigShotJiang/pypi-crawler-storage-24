"""
Pydantic schemas for Tenant model JSONFields.

These schemas validate the features JSONField on the Tenant model.

Usage:
    from lightwave.schema.pydantic.models.tenants import TenantFeaturesSchema
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TenantFeaturesSchema(JSONFieldSchema):
    """
    Schema for Tenant.features JSONField.

    Feature flags that control tenant-level functionality.
    All features default to False if not specified.

    Example:
        {
            "use_teams": true,
            "use_subscriptions": true,
            "use_chat": true,
            "use_cineos": false,
            "use_createos": true
        }
    """

    # Core features (available to all tenants)
    use_teams: bool = Field(False, description="Enable team collaboration features")
    use_subscriptions: bool = Field(False, description="Enable subscription billing")
    use_chat: bool = Field(False, description="Enable AI chat functionality")
    use_ai: bool = Field(False, description="Enable AI agent features")

    # CineOS features (film production)
    use_cineos: bool = Field(False, description="Enable CineOS film production features")
    use_screenplays: bool = Field(False, description="Enable screenplay management")
    use_call_sheets: bool = Field(False, description="Enable call sheet generation")
    use_shot_lists: bool = Field(False, description="Enable shot list planning")

    # createOS features (task/project management)
    use_createos: bool = Field(False, description="Enable createOS task management")
    use_tasks: bool = Field(False, description="Enable task tracking")
    use_projects: bool = Field(False, description="Enable project management")
    use_site_builder: bool = Field(False, description="Enable site building CMS")

    # E-commerce features
    use_ecommerce: bool = Field(False, description="Enable e-commerce functionality")
    use_portfolio: bool = Field(False, description="Enable portfolio features")
    use_gallery: bool = Field(False, description="Enable gallery features")

    # Photography features
    use_print_shop: bool = Field(False, description="Enable print shop")
    use_client_proofing: bool = Field(False, description="Enable client proofing")
    use_booking: bool = Field(False, description="Enable booking system")

    # Admin features
    use_admin_dashboard: bool = Field(False, description="Enable admin dashboard")
    use_platform_management: bool = Field(False, description="Enable platform management")
    use_accounting: bool = Field(False, description="Enable accounting integrations")

    # Development
    use_all_features: bool = Field(False, description="Enable all features (dev only)")
