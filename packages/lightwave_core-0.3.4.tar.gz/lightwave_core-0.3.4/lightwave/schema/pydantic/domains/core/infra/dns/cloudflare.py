"""
Pydantic schemas for core.infra.dns.cloudflare.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class CloudflareZoneSchema(BaseModel):
    """Schema for CloudflareZone."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class DNSRecordSchema(BaseModel):
    """Schema for DNSRecord."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
