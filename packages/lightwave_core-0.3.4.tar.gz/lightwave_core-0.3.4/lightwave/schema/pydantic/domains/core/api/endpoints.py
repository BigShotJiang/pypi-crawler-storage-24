"""
Pydantic schemas for core.api.endpoints.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class APIEndpointSchema(BaseModel):
    """Schema for APIEndpoint."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class RateLimitSchema(BaseModel):
    """Schema for RateLimit."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
