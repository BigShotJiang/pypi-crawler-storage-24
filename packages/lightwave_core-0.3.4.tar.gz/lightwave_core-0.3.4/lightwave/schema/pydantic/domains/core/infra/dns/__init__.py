"""Pydantic schemas for core.infra.dns."""

from .cloudflare import *
