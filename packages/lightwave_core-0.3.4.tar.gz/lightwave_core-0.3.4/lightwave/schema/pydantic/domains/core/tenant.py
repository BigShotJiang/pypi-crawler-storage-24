"""
Pydantic schemas for core.tenant.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class TenantSchema(BaseModel):
    """Schema for Tenant."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class DomainSchema(BaseModel):
    """Schema for Domain."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class UserTenantAccessSchema(BaseModel):
    """Schema for UserTenantAccess."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
