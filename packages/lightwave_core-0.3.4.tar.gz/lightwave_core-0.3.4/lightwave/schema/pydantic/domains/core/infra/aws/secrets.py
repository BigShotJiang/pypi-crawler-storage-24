"""
Pydantic schemas for core.infra.aws.secrets.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SecretReferenceSchema(BaseModel):
    """Schema for SecretReference."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class SecretRotationSchema(BaseModel):
    """Schema for SecretRotation."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
