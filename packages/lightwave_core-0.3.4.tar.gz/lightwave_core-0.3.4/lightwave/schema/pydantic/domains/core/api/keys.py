"""
Pydantic schemas for core.api.keys.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class AgentAPIKeySchema(BaseModel):
    """Schema for AgentAPIKey."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class APIKeyPermissionsSchema(BaseModel):
    """Schema for APIKeyPermissions."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
