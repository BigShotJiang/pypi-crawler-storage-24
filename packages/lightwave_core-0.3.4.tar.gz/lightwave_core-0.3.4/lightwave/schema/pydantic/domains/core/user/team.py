"""
Pydantic schemas for core.user.team.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class TeamSchema(BaseModel):
    """Schema for Team."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class MembershipSchema(BaseModel):
    """Schema for Membership."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class InvitationSchema(BaseModel):
    """Schema for Invitation."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
