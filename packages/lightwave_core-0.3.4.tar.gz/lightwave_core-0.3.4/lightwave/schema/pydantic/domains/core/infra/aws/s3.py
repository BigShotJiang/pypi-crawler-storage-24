"""
Pydantic schemas for core.infra.aws.s3.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class S3BucketSchema(BaseModel):
    """Schema for S3Bucket."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class S3ObjectSchema(BaseModel):
    """Schema for S3Object."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
