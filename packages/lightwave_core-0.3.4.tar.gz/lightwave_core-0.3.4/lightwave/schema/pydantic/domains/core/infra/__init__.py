"""Pydantic schemas for core.infra."""
