"""
Pydantic schemas for core.infra.aws.ses.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SESIdentitySchema(BaseModel):
    """Schema for SESIdentity."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class EmailTemplateSchema(BaseModel):
    """Schema for EmailTemplate."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
