"""
Core app schemas - shared functionality across all platform apps.

Submodules:
    user/       - User profile, authentication, team management
    billing/    - Subscription plans, payment schemas
    tenant/     - Multi-tenant configuration
    api/        - API keys, endpoint definitions
    infra/      - AWS service schemas (SES, S3, Secrets)
"""

from . import api, infra, user
from .billing import *
from .tenant import *

__all__ = ["api", "infra", "user"]
