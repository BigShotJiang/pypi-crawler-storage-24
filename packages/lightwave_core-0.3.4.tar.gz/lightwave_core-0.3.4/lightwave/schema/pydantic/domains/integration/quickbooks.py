"""
Pydantic schemas for integration.quickbooks.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class QBOConnectionSchema(BaseModel):
    """Schema for QBOConnection."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class QBOSyncLogSchema(BaseModel):
    """Schema for QBOSyncLog."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
