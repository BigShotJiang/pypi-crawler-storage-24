"""
Pydantic schemas for integration.google.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class WorkspaceSyncLogSchema(BaseModel):
    """Schema for WorkspaceSyncLog."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class GoogleCredentialsSchema(BaseModel):
    """Schema for GoogleCredentials."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
