"""
Integration app schemas - external service integrations.

Submodules:
    google/     - Google Workspace sync, Calendar, Drive schemas
    quickbooks/ - QuickBooks Online connection schemas
"""

from .google import *
from .quickbooks import *

__all__ = ["google", "quickbooks"]
