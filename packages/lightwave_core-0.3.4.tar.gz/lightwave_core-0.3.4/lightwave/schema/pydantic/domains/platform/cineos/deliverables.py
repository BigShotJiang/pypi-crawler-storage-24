"""
Pydantic schemas for platform.cineos.deliverables.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class DeliverableSchema(BaseModel):
    """Schema for Deliverable."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class DistributionChannelSchema(BaseModel):
    """Schema for DistributionChannel."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
