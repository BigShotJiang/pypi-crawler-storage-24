"""
Pydantic schemas for platform.ux.blueprints.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class BlueprintSchema(BaseModel):
    """Schema for Blueprint."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class BlueprintSchemaSchema(BaseModel):
    """Schema for BlueprintSchema."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class IslandConfigSchema(BaseModel):
    """Schema for IslandConfig."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
