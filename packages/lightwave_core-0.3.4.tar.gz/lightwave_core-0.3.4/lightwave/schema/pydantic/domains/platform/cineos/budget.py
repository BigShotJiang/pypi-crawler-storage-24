"""
Pydantic schemas for platform.cineos.budget.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class BudgetAccountSchema(BaseModel):
    """Schema for BudgetAccount."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class InvoiceSchema(BaseModel):
    """Schema for Invoice."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class CrewPaymentSchema(BaseModel):
    """Schema for CrewPayment."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
