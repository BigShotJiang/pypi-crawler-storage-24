"""
Pydantic schemas for platform.createos.planning.

These schemas validate JSONFields in Django planning models:
- LifeDomain: Strategic life areas
- Epic: Large feature groupings
- Sprint: Development iterations

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos.planning import EpicSchema

Note: These are placeholder schemas - add fields as Django models are implemented.
"""

from __future__ import annotations

from pydantic import ConfigDict

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class LifeDomainSchema(JSONFieldSchema):
    """
    Schema for LifeDomain JSONFields.

    LifeDomain represents a strategic area of life/work being tracked.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when LifeDomain model is implemented


class EpicSchema(JSONFieldSchema):
    """
    Schema for Epic JSONFields.

    Epic represents a large feature grouping or initiative.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Epic model JSONFields are defined


class SprintSchema(JSONFieldSchema):
    """
    Schema for Sprint JSONFields.

    Sprint represents a development iteration with goals and tasks.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Sprint model JSONFields are defined


__all__ = [
    "LifeDomainSchema",
    "EpicSchema",
    "SprintSchema",
]
