"""
Pydantic schemas for platform.cineos.breakdown.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SceneBreakdownSchema(BaseModel):
    """Schema for SceneBreakdown."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class BreakdownCategorySchema(BaseModel):
    """Schema for BreakdownCategory."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class BreakdownElementSchema(BaseModel):
    """Schema for BreakdownElement."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
