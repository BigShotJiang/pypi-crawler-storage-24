"""
Pydantic schemas for platform.email.campaigns.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class CampaignSchema(BaseModel):
    """Schema for Campaign."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class CampaignRecipientSchema(BaseModel):
    """Schema for CampaignRecipient."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class CampaignStatsSchema(BaseModel):
    """Schema for CampaignStats."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
