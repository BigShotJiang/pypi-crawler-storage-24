"""
Pydantic schemas for platform.createos.learning.

These schemas validate JSONFields in Debrief Django models.

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos import DebriefInsightSchema, PatternSchema
"""

from __future__ import annotations

from pydantic import ConfigDict

from lightwave.schema.pydantic.core.base import JSONFieldSchema

# Re-export from models/ (canonical source)
from lightwave.schema.pydantic.models.createos import (
    DebriefInsightSchema,
    PatternSchema,
)


class DebriefSchema(JSONFieldSchema):
    """
    Schema for Debrief model.

    Debrief captures lessons learned after completing a UserStory/Task.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Debrief model structure is finalized


__all__ = [
    "DebriefSchema",
    "DebriefInsightSchema",
    "PatternSchema",
]
