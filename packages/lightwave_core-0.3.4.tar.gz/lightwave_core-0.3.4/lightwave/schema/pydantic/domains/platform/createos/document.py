"""
Pydantic schemas for platform.createos.document.

These schemas validate JSONFields in Document Django models.

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos.document import DocumentSchema

Note: These are placeholder schemas - add fields as Django models are implemented.
"""

from __future__ import annotations

from pydantic import ConfigDict

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class DocumentSchema(JSONFieldSchema):
    """
    Schema for Document model JSONFields.

    Document represents structured documentation within createOS.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Document model is implemented


class NoteSchema(JSONFieldSchema):
    """
    Schema for Note model JSONFields.

    Note represents quick captures and observations.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Note model is implemented


class KnowledgeLinkSchema(JSONFieldSchema):
    """
    Schema for KnowledgeLink JSONFields.

    Links between documents, notes, and other knowledge artifacts.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when KnowledgeLink is implemented


__all__ = [
    "DocumentSchema",
    "NoteSchema",
    "KnowledgeLinkSchema",
]
