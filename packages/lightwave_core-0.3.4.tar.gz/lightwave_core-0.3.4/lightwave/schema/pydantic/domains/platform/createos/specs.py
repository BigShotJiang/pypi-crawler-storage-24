"""
Pydantic schemas for platform.createos.specs.

These schemas validate JSONFields in TestSpecification and ImplementationPlan Django models.

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos import TestScenarioSchema

Note: TestScenarioSchema and AcceptanceCriterionSchema are also re-exported from stories.py.
"""

# Re-export JSONField schemas from models/ (canonical source)
from lightwave.schema.pydantic.models.createos import (
    AcceptanceCriterionSchema,
    CriticalFileSchema,
    DependencySchema,
    ImplementationPlanRiskSchema,
    PastAchievementSchema,
    RoadmapMilestoneSchema,
    TestScenarioSchema,
)

__all__ = [
    # TestSpecification JSONField schemas
    "TestScenarioSchema",
    "AcceptanceCriterionSchema",
    # ImplementationPlan JSONField schemas
    "RoadmapMilestoneSchema",
    "PastAchievementSchema",
    "CriticalFileSchema",
    "DependencySchema",
    "ImplementationPlanRiskSchema",
]
