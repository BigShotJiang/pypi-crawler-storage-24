"""
Platform app schemas - LightWave platform-specific apps.

Submodules:
    createos/   - UserStory, Task, Sprint, Planning schemas
    email/      - Campaign, Inbox, Email event schemas
    site/       - CMS, Page, Site settings schemas
    ux/         - UX blueprint and component schemas
    ai/         - AI tracking and Claude integration schemas
    cineos/     - Screenplay, Production, Crew schemas
"""

from . import ai, cineos, createos, email, site, ux

__all__ = ["ai", "cineos", "createos", "email", "site", "ux"]
