"""
Pydantic schemas for platform.createos.project.

These schemas validate JSONFields in Project Django models.

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos.project import ProjectSettingsSchema
"""

from __future__ import annotations

from pydantic import ConfigDict

from lightwave.schema.pydantic.core.base import JSONFieldSchema

# Re-export from models/ (canonical source)
from lightwave.schema.pydantic.models.production import (
    ProjectSettingsSchema,
)


class ProjectSchema(JSONFieldSchema):
    """
    Schema for Project model JSONFields.

    Project represents a top-level project container in createOS.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Project model JSONFields are defined


__all__ = [
    "ProjectSchema",
    "ProjectSettingsSchema",
]
