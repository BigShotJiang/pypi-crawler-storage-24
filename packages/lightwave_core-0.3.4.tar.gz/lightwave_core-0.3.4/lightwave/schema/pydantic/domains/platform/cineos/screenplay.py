"""
Pydantic schemas for platform.cineos.screenplay.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class ScreenplaySchema(BaseModel):
    """Schema for Screenplay."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class SceneSchema(BaseModel):
    """Schema for Scene."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class CharacterSchema(BaseModel):
    """Schema for Character."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class DialogueSchema(BaseModel):
    """Schema for Dialogue."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
