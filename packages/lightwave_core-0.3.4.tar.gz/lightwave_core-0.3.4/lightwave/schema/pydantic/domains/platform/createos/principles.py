"""
Pydantic schemas for platform.createos.principles.

These schemas validate JSONFields in Principle Django models.

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos.principles import KeywordsSchema
"""

from __future__ import annotations

from pydantic import ConfigDict

from lightwave.schema.pydantic.core.base import JSONFieldSchema

# Re-export from models/ (canonical source)
from lightwave.schema.pydantic.models.principles import (
    KeywordsSchema,
    validate_keywords_list,
)


class PrincipleSchema(JSONFieldSchema):
    """
    Schema for Principle model JSONFields.

    Principle represents a guiding principle from v_guru.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Principle model JSONFields are defined


class PrincipleApplicationSchema(JSONFieldSchema):
    """
    Schema for PrincipleApplication JSONFields.

    Tracks how principles are applied in context.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when PrincipleApplication is implemented


__all__ = [
    "KeywordsSchema",
    "validate_keywords_list",
    "PrincipleSchema",
    "PrincipleApplicationSchema",
]
