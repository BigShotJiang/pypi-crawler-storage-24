"""
Pydantic schemas for platform.ai.tracking.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class AIInteractionSchema(BaseModel):
    """Schema for AIInteraction."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class TokenUsageSchema(BaseModel):
    """Schema for TokenUsage."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class PromptLogSchema(BaseModel):
    """Schema for PromptLog."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
