"""Pydantic schemas for platform.email."""

from .campaigns import *
from .inbox import *
