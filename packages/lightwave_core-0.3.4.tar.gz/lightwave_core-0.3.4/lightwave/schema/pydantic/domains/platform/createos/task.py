"""
Pydantic schemas for platform.createos.task.

These schemas validate JSONFields in Task Django models.

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos.task import TaskMetadataSchema

Note: These are placeholder schemas - add fields as Django models are implemented.
"""

from __future__ import annotations

from pydantic import ConfigDict

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TaskSchema(JSONFieldSchema):
    """
    Schema for Task model JSONFields.

    Task represents a unit of work within a Sprint or UserStory.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Task model JSONFields are defined


class TaskDependencySchema(JSONFieldSchema):
    """
    Schema for Task dependencies JSONField.

    Represents dependencies between tasks.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when TaskDependency is implemented


class TaskMetadataSchema(JSONFieldSchema):
    """
    Schema for Task metadata JSONField.

    Stores additional task metadata not captured in model fields.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # TODO: Add fields when Task metadata structure is defined


__all__ = [
    "TaskSchema",
    "TaskDependencySchema",
    "TaskMetadataSchema",
]
