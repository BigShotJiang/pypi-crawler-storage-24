"""
Pydantic schemas for platform.ai.claude.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class ClaudeRuleSchema(BaseModel):
    """Schema for ClaudeRule."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class ClaudeAgentSchema(BaseModel):
    """Schema for ClaudeAgent."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class ContextProfileSchema(BaseModel):
    """Schema for ContextProfile."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class PackageStateSchema(BaseModel):
    """Schema for PackageState."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
