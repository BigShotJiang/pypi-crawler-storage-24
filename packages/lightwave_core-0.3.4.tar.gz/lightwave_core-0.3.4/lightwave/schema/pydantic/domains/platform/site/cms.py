"""
Pydantic schemas for platform.site.cms.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class OutboxItemSchema(BaseModel):
    """Schema for OutboxItem."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class PageVersionSchema(BaseModel):
    """Schema for PageVersion."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class ContentRevisionSchema(BaseModel):
    """Schema for ContentRevision."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
