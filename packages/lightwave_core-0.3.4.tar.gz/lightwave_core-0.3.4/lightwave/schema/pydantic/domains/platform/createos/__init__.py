"""
Pydantic schemas for platform.createos app.

This package mirrors the Django createos app structure and provides
Pydantic schemas for JSONField validation.

Submodules:
    stories.py    - UserStory JSONField schemas (personas, flows, edge cases)
    specs.py      - TestSpecification and ImplementationPlan JSONField schemas
    task.py       - Task model schemas
    planning.py   - LifeDomain, Epic, Sprint schemas
    learning.py   - Debrief and pattern schemas
    document.py   - Document, Note, KnowledgeLink schemas
    principles.py - Principle and keywords schemas
    project.py    - Project settings schemas

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos import PersonaSchema, UserFlowSchema
"""

# UserStory JSONField schemas
# Document schemas
from .document import (
    DocumentSchema,
    KnowledgeLinkSchema,
    NoteSchema,
)

# Learning schemas
from .learning import (
    DebriefSchema,
)

# Planning schemas
from .planning import (
    EpicSchema,
    LifeDomainSchema,
    SprintSchema,
)

# Principles schemas
from .principles import (
    KeywordsSchema,
    PrincipleApplicationSchema,
    PrincipleSchema,
    validate_keywords_list,
)

# Project schemas
from .project import (
    ProjectSchema,
    ProjectSettingsSchema,
)
from .stories import (
    AcceptanceCriterionSchema,
    CriticalFileSchema,
    DebriefInsightSchema,
    DependencySchema,
    EdgeCaseSchema,
    ImplementationPlanRiskSchema,
    InterviewMessageSchema,
    PastAchievementSchema,
    PatternSchema,
    PersonaSchema,
    RBACRequirementSchema,
    RoadmapMilestoneSchema,
    TechnicalConstraintSchema,
    TestScenarioSchema,
    UserFlowSchema,
)

# Task schemas
from .task import (
    TaskDependencySchema,
    TaskMetadataSchema,
    TaskSchema,
)

__all__ = [
    # UserStory JSONField schemas
    "PersonaSchema",
    "UserFlowSchema",
    "EdgeCaseSchema",
    "TechnicalConstraintSchema",
    "RBACRequirementSchema",
    "InterviewMessageSchema",
    "AcceptanceCriterionSchema",
    # TestSpecification JSONField schemas
    "TestScenarioSchema",
    # ImplementationPlan JSONField schemas
    "RoadmapMilestoneSchema",
    "PastAchievementSchema",
    "CriticalFileSchema",
    "DependencySchema",
    "ImplementationPlanRiskSchema",
    # Debrief JSONField schemas
    "PatternSchema",
    "DebriefInsightSchema",
    "DebriefSchema",
    # Task schemas
    "TaskSchema",
    "TaskDependencySchema",
    "TaskMetadataSchema",
    # Planning schemas
    "LifeDomainSchema",
    "EpicSchema",
    "SprintSchema",
    # Document schemas
    "DocumentSchema",
    "NoteSchema",
    "KnowledgeLinkSchema",
    # Principles schemas
    "KeywordsSchema",
    "validate_keywords_list",
    "PrincipleSchema",
    "PrincipleApplicationSchema",
    # Project schemas
    "ProjectSchema",
    "ProjectSettingsSchema",
]
