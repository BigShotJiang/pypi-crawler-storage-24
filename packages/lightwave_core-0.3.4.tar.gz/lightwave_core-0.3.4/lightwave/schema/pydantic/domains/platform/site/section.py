"""
Pydantic schemas for CMS section configuration.

Sections are React component configurations stored in Page.sections JSONField.
Each section maps to a marketing component in lightwave-ui.

Naming convention:
    type = folder name (e.g., "hero", "features", "pricing")
    variant = component name (e.g., "HeroScreenMockup05", "FeaturesList02")
"""

from __future__ import annotations

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class SectionConfig(JSONFieldSchema):
    """
    Configuration for a single CMS section (React component).

    Maps directly to lightwave-ui marketing components:
    - type: Component category (matches folder in lightwave-ui/src/components/marketing/)
    - variant: Exact component name (e.g., "HeroScreenMockup05")
    - order: Render order (lower = earlier)
    - props: Component props passed to React component

    Example:
        {
            "type": "hero",
            "variant": "HeroScreenMockup05",
            "order": 0,
            "props": {
                "headline": "Build faster",
                "subheadline": "Ship today",
                "ctaText": "Get Started",
                "ctaHref": "/signup"
            }
        }
    """

    type: str = Field(
        ...,
        description="Section category matching lightwave-ui folder (e.g., 'hero', 'features')",
        min_length=1,
    )
    variant: str = Field(
        ...,
        description="Exact component name (e.g., 'HeroScreenMockup05')",
        min_length=1,
    )
    order: int = Field(
        default=0,
        ge=0,
        description="Render order (lower = earlier)",
    )
    props: dict[str, Any] = Field(
        default_factory=dict,
        description="Props passed to the React component",
    )


class SectionConfigList(JSONFieldSchema):
    """
    Wrapper for validating a list of sections.

    Used for validating Page.sections JSONField.

    Example:
        sections_data = [{"type": "hero", "variant": "HeroScreenMockup05", ...}]
        validated = SectionConfigList(sections=sections_data)
    """

    sections: list[SectionConfig] = Field(
        default_factory=list,
        description="List of section configurations",
    )

    @classmethod
    def validate_list(cls, sections: list[dict[str, Any]]) -> list[SectionConfig]:
        """
        Validate a list of section dicts and return typed SectionConfig list.

        Args:
            sections: Raw list of section dictionaries from JSONField

        Returns:
            List of validated SectionConfig objects
        """
        instance = cls(sections=sections)
        return instance.sections
