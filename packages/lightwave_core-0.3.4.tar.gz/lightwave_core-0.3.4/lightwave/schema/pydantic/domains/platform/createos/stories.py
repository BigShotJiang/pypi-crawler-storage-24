"""
Pydantic schemas for platform.createos.stories.

These schemas validate JSONFields in createOS Django models:
- UserStory: personas, user_flows, edge_cases, technical_constraints, etc.
- TestSpecification: test_scenarios, acceptance_criteria
- ImplementationPlan: risks, dependencies, critical_files
- Debrief: patterns_used, patterns_discovered, insights

Import pattern (PREFERRED):
    from lightwave.schema.pydantic.domains.platform.createos import PersonaSchema

Also available (deprecated path):
    from lightwave.schema.pydantic.models.createos import PersonaSchema
"""

# Re-export full implementations from models/ (canonical source)
from lightwave.schema.pydantic.models.createos import (
    AcceptanceCriterionSchema,
    CriticalFileSchema,
    DebriefInsightSchema,
    DependencySchema,
    EdgeCaseSchema,
    ImplementationPlanRiskSchema,
    InterviewMessageSchema,
    PastAchievementSchema,
    PatternSchema,
    PersonaSchema,
    RBACRequirementSchema,
    RoadmapMilestoneSchema,
    TechnicalConstraintSchema,
    TestScenarioSchema,
    UserFlowSchema,
)

__all__ = [
    # UserStory JSONField schemas
    "PersonaSchema",
    "UserFlowSchema",
    "EdgeCaseSchema",
    "TechnicalConstraintSchema",
    "RBACRequirementSchema",
    "InterviewMessageSchema",
    "AcceptanceCriterionSchema",
    # TestSpecification JSONField schemas
    "TestScenarioSchema",
    # ImplementationPlan JSONField schemas
    "RoadmapMilestoneSchema",
    "PastAchievementSchema",
    "CriticalFileSchema",
    "DependencySchema",
    "ImplementationPlanRiskSchema",
    # Debrief JSONField schemas
    "PatternSchema",
    "DebriefInsightSchema",
]
