"""
Pydantic schemas for platform.email.inbox.

These schemas validate JSONFields in Django models.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class GmailCredentialsSchema(BaseModel):
    """Schema for GmailCredentials."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class InboxMessageSchema(BaseModel):
    """Schema for InboxMessage."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass


class ThreadSummarySchema(BaseModel):
    """Schema for ThreadSummary."""

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )

    # TODO: Add fields based on apps.yaml definition
    pass
