"""
App-mirrored Pydantic schemas.

This package structure mirrors the Django apps in lightwave-platform/backend/apps/.
Each subpackage contains Pydantic schemas for that Django app's JSONFields.

Structure:
    apps/
    ├── core/           # Core shared functionality
    │   ├── user/       # User, Auth, Team schemas
    │   ├── billing/    # Subscription, Payment schemas
    │   ├── tenant/     # Tenant configuration schemas
    │   ├── api/        # API key and endpoint schemas
    │   └── infra/      # AWS SES, S3, Secrets schemas
    ├── platform/       # Platform-specific apps
    │   ├── createos/   # UserStory, Task, Sprint schemas
    │   ├── email/      # Campaign, Inbox schemas
    │   ├── site/       # CMS, Page schemas
    │   ├── ux/         # UX blueprint schemas
    │   ├── ai/         # AI tracking schemas
    │   └── cineos/     # Screenplay, Production schemas
    └── integration/    # External service integrations
        ├── google/     # Google Workspace sync
        └── quickbooks/ # QBO connection schemas

Import pattern:
    # Preferred for app-specific schemas
    from lightwave.schema.pydantic.domains.platform.createos import PersonaSchema
    from lightwave.schema.pydantic.domains.core.user import UserProfileSchema

    # Also available via submodule imports
    from lightwave.schema.pydantic.domains import core, platform, integration

Type Lineage:
    YAML (SST) → Pydantic (here) → Django Model → Ninja API → TypeScript → React UI
"""

from . import core, integration, platform

__all__ = ["core", "platform", "integration"]
