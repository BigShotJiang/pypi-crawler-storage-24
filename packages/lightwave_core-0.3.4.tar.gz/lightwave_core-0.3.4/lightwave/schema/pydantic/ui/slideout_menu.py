"""
Pydantic schema for SlideoutMenu component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/slideout-menus/slideout-menu.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ModalOverlayProps(JSONFieldSchema):
    """Props for ModalOverlay component."""

    pass


class ModalProps(JSONFieldSchema):
    """Props for Modal component."""

    pass


class DialogProps(JSONFieldSchema):
    """Props for Dialog component."""

    pass


class SlideoutMenuProps(JSONFieldSchema):
    """Props for SlideoutMenu component."""

    children: str | dict[str, Any] | None
    dialog_class_name: str | None = Field(default=None, alias="dialogClassName")


class SlideoutHeaderProps(JSONFieldSchema):
    """Props for SlideoutHeader component."""

    on_close: Any | None = Field(default=None, alias="onClose")
