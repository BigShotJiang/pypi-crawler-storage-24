"""
Pydantic schema for SidebarDualTier component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/sidebar-navigation/sidebar-dual-tier.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItemType


class SidebarNavigationDualTierProps(JSONFieldSchema):
    """Props for SidebarNavigationDualTier component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    feature_card: str | dict[str, Any] | None | None = Field(
        default=None, alias="featureCard", description="Feature card to display."
    )
    items: list[NavItemType] = Field(description="List of items to display.")
    footer_items: list[NavItemType] | None = Field(
        default=None, alias="footerItems", description="List of footer items to display."
    )
    hide_border: bool | None = Field(
        default=None, alias="hideBorder", description="Whether to hide the right side border."
    )
