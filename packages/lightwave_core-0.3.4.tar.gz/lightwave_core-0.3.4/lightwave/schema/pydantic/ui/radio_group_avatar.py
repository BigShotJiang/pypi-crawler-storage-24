"""
Pydantic schema for RadioGroupAvatar component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/radio-groups/radio-group-avatar.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import AvatarItemType


class RadioGroupAvatarProps(JSONFieldSchema):
    """Props for RadioGroupAvatar component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    items: list[AvatarItemType]
