"""
Pydantic schema for PinInput component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/pin-input/pin-input.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class RootProps(JSONFieldSchema):
    """Props for Root component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)
    disabled: bool | None = Field(default=None)


class GroupProps(JSONFieldSchema):
    """Props for Group component."""

    pass
