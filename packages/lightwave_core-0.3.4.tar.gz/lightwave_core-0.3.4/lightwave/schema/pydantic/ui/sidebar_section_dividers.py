"""
Pydantic schema for SidebarSectionDividers component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/sidebar-navigation/sidebar-section-dividers.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItemDividerType, NavItemType


class SidebarNavigationSectionDividersProps(JSONFieldSchema):
    """Props for SidebarNavigationSectionDividers component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    items: list[NavItemType | NavItemDividerType] = Field(description="List of items to display.")
