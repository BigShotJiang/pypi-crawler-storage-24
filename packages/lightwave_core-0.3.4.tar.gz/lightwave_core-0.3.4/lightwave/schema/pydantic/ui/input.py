"""
Pydantic schema for Input component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/input/input.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class InputBaseProps(JSONFieldSchema):
    """Props for InputBase component."""

    tooltip: str | None = Field(default=None, description="Tooltip message on hover.")
    size: Literal["md", "sm"] | None = Field(default="sm", description="Input size.")
    placeholder: str | None = Field(default=None, description="Placeholder text.")
    icon_class_name: str | None = Field(default=None, alias="iconClassName", description="Class name for the icon.")
    input_class_name: str | None = Field(default=None, alias="inputClassName", description="Class name for the input.")
    wrapper_class_name: str | None = Field(
        default=None, alias="wrapperClassName", description="Class name for the input wrapper."
    )
    tooltip_class_name: str | None = Field(
        default=None, alias="tooltipClassName", description="Class name for the tooltip."
    )
    shortcut: str | bool | None = Field(default=None, description="Keyboard shortcut to display.")
    ref: T | None = Field(default=None)
    group_ref: T | None = Field(default=None, alias="groupRef")
    icon: T | None = Field(default=None, description="Icon component to display on the left side of the input.")


class BaseProps(JSONFieldSchema):
    """Props for Base component."""

    label: str | None = Field(default=None, description="Label text for the input")
    hint: str | dict[str, Any] | None | None = Field(default=None, description="Helper text displayed below the input")


class TextFieldProps(JSONFieldSchema):
    """Props for TextField component."""

    ref: T | None = Field(default=None)


class InputProps(JSONFieldSchema):
    """Props for Input component."""

    hide_required_indicator: bool | None = Field(
        default=None, alias="hideRequiredIndicator", description="Whether to hide required indicator from label"
    )
