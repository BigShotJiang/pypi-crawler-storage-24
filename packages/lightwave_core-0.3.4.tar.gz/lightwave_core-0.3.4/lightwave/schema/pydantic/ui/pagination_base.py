"""
Pydantic schema for PaginationBase component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/pagination/pagination-base.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class PaginationRootProps(JSONFieldSchema):
    """Props for PaginationRoot component."""

    sibling_count: int | float | None = Field(
        default=None,
        alias="siblingCount",
        description="Number of sibling pages to show on each side of the current page",
    )
    page: int | float = Field(description="Current active page number")
    total: int | float = Field(description="Total number of pages")
    children: str | dict[str, Any] | None = Field(default=None)
    style: Any | None = Field(default=None, description="The style of the pagination root.")
    class_name: str | None = Field(
        default=None, alias="className", description="The class name of the pagination root."
    )
    on_page_change: Any | None = Field(
        default=None,
        alias="onPageChange",
        description="Callback function that's called when the page changes with the new page number.",
    )


class TriggerRenderProps(JSONFieldSchema):
    """Props for TriggerRender component."""

    is_disabled: bool = Field(alias="isDisabled")
    on_click: Any = Field(alias="onClick")


class TriggerProps(JSONFieldSchema):
    """Props for Trigger component."""

    children: str | dict[str, Any] | None = Field(
        default=None, description="The children of the trigger. Can be a render prop or a valid element."
    )
    style: Any | None = Field(default=None, description="The style of the trigger.")
    class_name: str | Any | None = Field(default=None, alias="className", description="The class name of the trigger.")
    as_child: bool | None = Field(
        default=None,
        alias="asChild",
        description="If true, the child element will be cloned and passed down the prop of the trigger.",
    )
    direction: Literal["next", "prev"] = Field(description="The direction of the trigger.")
    aria_label: str | None = Field(default=None, alias="ariaLabel", description="The aria label of the trigger.")


class PaginationItemRenderProps(JSONFieldSchema):
    """Props for PaginationItemRender component."""

    is_selected: bool = Field(alias="isSelected")
    on_click: Any = Field(alias="onClick")
    value: int | float = Field(default=0)
    aria_current: Any | None = Field(default=None, alias="aria-current")
    aria_label_render: str | None = Field(default=None, alias="aria-label")


class PaginationItemProps(JSONFieldSchema):
    """Props for PaginationItem component."""

    value: int | float = Field(description="The value of the pagination item.")
    is_current: bool = Field(alias="isCurrent", description="Whether the pagination item is the current page.")
    children: str | dict[str, Any] | None = Field(
        default=None, description="The children of the pagination item. Can be a render prop or a valid element."
    )
    style: Any | None = Field(default=None, description="The style object of the pagination item.")
    class_name: str | Any | None = Field(
        default=None, alias="className", description="The class name of the pagination item."
    )
    aria_label: str | None = Field(
        default=None, alias="ariaLabel", description="The aria label of the pagination item."
    )
    as_child: bool | None = Field(
        default=None,
        alias="asChild",
        description="If true, the child element will be cloned and passed down the prop of the item.",
    )


class PaginationEllipsisProps(JSONFieldSchema):
    """Props for PaginationEllipsis component."""

    key: int | float = Field(default=0)
    children: str | dict[str, Any] | None = Field(default=None)
    style: Any | None = Field(default=None)
    class_name: str | Any | None = Field(default=None, alias="className")


class PaginationContextComponentProps(JSONFieldSchema):
    """Props for PaginationContextComponent component."""

    children: str | dict[str, Any] | None = Field(default=None)
