"""
Pydantic schema for ProgressCircles component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/progress-indicators/progress-circles.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ProgressBarProps(JSONFieldSchema):
    """Props for ProgressBar component."""

    value: int | float
    min: int | float | None = Field(default=None)
    max: int | float | None = Field(default=None)
    size: Literal["lg", "md", "sm", "xs", "xxs"]
    label: str | None = Field(default=None)
    value_formatter: Any | None = Field(default=None, alias="valueFormatter")
