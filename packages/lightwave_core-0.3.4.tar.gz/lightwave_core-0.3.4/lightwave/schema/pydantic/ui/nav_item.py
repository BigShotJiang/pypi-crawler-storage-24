"""
Pydantic schema for NavItem component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/base-components/nav-item.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class NavItemBaseProps(JSONFieldSchema):
    """Props for NavItemBase component."""

    icon_only: bool | None = Field(
        default=None, alias="iconOnly", description="Whether the nav item shows only an icon."
    )
    open: bool | None = Field(default=None, description="Whether the collapsible nav item is open.")
    href: str | None = Field(default=None, description="URL to navigate to when the nav item is clicked.")
    type: Literal["collapsible", "collapsible-child", "link"] = Field(description="Type of the nav item.")
    icon: str | None = Field(default=None, description="Icon component to display.")
    badge: str | dict[str, Any] | None | None = Field(default=None, description="Badge to display.")
    current: bool | None = Field(default=None, description="Whether the nav item is currently active.")
    truncate: bool | None = Field(default=None, description="Whether to truncate the label text.")
    on_click: Any | None = Field(default=None, alias="onClick", description="Handler for click events.")
    children: str | dict[str, Any] | None | None = Field(default=None, description="Content to display.")
