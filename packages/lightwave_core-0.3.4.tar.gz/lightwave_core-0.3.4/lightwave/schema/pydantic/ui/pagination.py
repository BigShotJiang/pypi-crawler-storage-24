"""
Pydantic schema for Pagination component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/pagination/pagination.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class PaginationProps(JSONFieldSchema):
    """Props for Pagination component."""

    rounded: bool | None = Field(default=None, description="Whether the pagination buttons are rounded.")


class MobilePaginationProps(JSONFieldSchema):
    """Props for MobilePagination component."""

    page: int | float | None = Field(default=None, description="The current page.")
    total: int | float | None = Field(default=None, description="The total number of pages.")
    class_name: str | None = Field(
        default=None, alias="className", description="The class name of the pagination component."
    )
    on_page_change: Any | None = Field(
        default=None, alias="onPageChange", description="The function to call when the page changes."
    )


class PaginationCardMinimalProps(JSONFieldSchema):
    """Props for PaginationCardMinimal component."""

    page: int | float | None = Field(default=None, description="The current page.")
    total: int | float | None = Field(default=None, description="The total number of pages.")
    align: Literal["center", "left", "right"] | None = Field(
        default=None, description="The alignment of the pagination."
    )
    class_name: str | None = Field(
        default=None, alias="className", description="The class name of the pagination component."
    )
    on_page_change: Any | None = Field(
        default=None, alias="onPageChange", description="The function to call when the page changes."
    )


class PaginationButtonGroupProps(JSONFieldSchema):
    """Props for PaginationButtonGroup component."""

    align: Literal["center", "left", "right"] | None = Field(
        default=None, description="The alignment of the pagination."
    )
