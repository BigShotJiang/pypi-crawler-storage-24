"""
Pydantic schema for Tags component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/tags/tags.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TagGroupProps(JSONFieldSchema):
    """Props for TagGroup component."""

    label: str
    size: Literal["lg", "md", "sm"] | None = Field(default=None)


class TagProps(JSONFieldSchema):
    """Props for Tag component."""

    pass
