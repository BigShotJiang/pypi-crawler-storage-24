"""
Pydantic schema for TagCheckbox component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/tags/base-components/tag-checkbox.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TagCheckboxProps(JSONFieldSchema):
    """Props for TagCheckbox component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    is_focused: bool | None = Field(default=None, alias="isFocused")
    is_selected: bool | None = Field(default=None, alias="isSelected")
    is_disabled: bool | None = Field(default=None, alias="isDisabled")
