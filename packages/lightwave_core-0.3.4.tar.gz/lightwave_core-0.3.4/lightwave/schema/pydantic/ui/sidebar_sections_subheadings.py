"""
Pydantic schema for SidebarSectionsSubheadings component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/sidebar-navigation/sidebar-sections-subheadings.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItem


class SidebarNavigationSectionsSubheadingsProps(JSONFieldSchema):
    """Props for SidebarNavigationSectionsSubheadings component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    items: list[NavItem] = Field(description="List of items to display.")
