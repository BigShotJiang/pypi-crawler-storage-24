"""
Pydantic schema for Dribbble component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/social-icons/dribbble.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class Props(JSONFieldSchema):
    """Props for  component."""

    size: int | float | None = Field(default=None)
