"""
Pydantic schema for Header component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/header-navigation/header.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import HeaderNavItem


class HeaderProps(JSONFieldSchema):
    """Props for Header component."""

    items: list[HeaderNavItem] | None = Field(default=None)
    is_full_width: bool | None = Field(default=None, alias="isFullWidth")
    is_floating: bool | None = Field(default=None, alias="isFloating")
    class_name: str | None = Field(default=None, alias="className")
