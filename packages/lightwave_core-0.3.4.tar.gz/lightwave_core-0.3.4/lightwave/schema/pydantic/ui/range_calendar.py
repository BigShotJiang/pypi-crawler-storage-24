"""
Pydantic schema for RangeCalendar component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/date-picker/range-calendar.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import DateValue


class RangeCalendarProps(JSONFieldSchema):
    """Props for RangeCalendar component."""

    highlighted_dates: list[DateValue] | None = Field(
        default=None, alias="highlightedDates", description="The dates to highlight."
    )
    presets: DateValue | None = Field(default=None, description="The date presets to display.")
