"""
Pydantic schema for NavMenuItem component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/header-navigation/base-components/nav-menu-item.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class NavMenuItemLinkProps(JSONFieldSchema):
    """Props for NavMenuItemLink component."""

    href: str
    icon: str | dict[str, Any] | None | None = Field(default=None)
    icon_class_name: str | None = Field(default=None, alias="iconClassName")
    class_name: str | None = Field(default=None, alias="className")
    title: str
    subtitle: str | None = Field(default=None)
    badge: str | dict[str, Any] | None | None = Field(default=None)
    actions_content: str | dict[str, Any] | None | None = Field(default=None, alias="actionsContent")
