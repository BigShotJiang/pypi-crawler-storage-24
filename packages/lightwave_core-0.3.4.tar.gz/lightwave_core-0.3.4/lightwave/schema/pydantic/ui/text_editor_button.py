"""
Pydantic schema for TextEditorButton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/text-editor/text-editor-button.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class EditorButtonProps(JSONFieldSchema):
    """Props for EditorButton component."""

    is_active: bool | None = Field(default=None, alias="isActive")
