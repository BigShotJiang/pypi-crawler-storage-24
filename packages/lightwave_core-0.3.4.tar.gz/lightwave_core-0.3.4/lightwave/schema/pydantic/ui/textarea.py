"""
Pydantic schema for Textarea component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/textarea/textarea.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TextAreaBaseProps(JSONFieldSchema):
    """Props for TextAreaBase component."""

    ref: Any | None = Field(default=None)


class TextFieldProps(JSONFieldSchema):
    """Props for TextField component."""

    label: str | None = Field(default=None, description="Label text for the textarea")
    hint: str | dict[str, Any] | None = Field(default=None, description="Helper text displayed below the textarea")
    tooltip: str | None = Field(default=None, description="Tooltip message displayed after the label.")
    text_area_class_name: str | Any | None = Field(
        default=None, alias="textAreaClassName", description="Class name for the textarea wrapper"
    )
    ref: Any | None = Field(default=None, description="Ref for the textarea wrapper")
    text_area_ref: Any | None = Field(default=None, alias="textAreaRef", description="Ref for the textarea")
    hide_required_indicator: bool | None = Field(
        default=None, alias="hideRequiredIndicator", description="Whether to hide required indicator from label."
    )
    placeholder: str | None = Field(default=None, description="Placeholder text.")
    rows: int | float | None = Field(default=None, description="Visible height of textarea in rows .")
    cols: int | float | None = Field(default=None, description="Visible width of textarea in columns.")
