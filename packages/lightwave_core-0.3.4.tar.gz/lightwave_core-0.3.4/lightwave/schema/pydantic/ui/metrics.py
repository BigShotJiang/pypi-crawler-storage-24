"""
Pydantic schema for Metrics component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/metrics/metrics.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class MetricChangeIndicatorProps(JSONFieldSchema):
    """Props for MetricChangeIndicator component."""

    type: Literal["modern", "simple", "trend"]
    trend: Literal["negative", "positive"]
    value: str | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
