"""
Pydantic schema for SectionLabel component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/section-headers/section-label.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class SectionLabelRootProps(JSONFieldSchema):
    """Props for SectionLabelRoot component."""

    title: str | dict[str, Any] | None
    size: Literal["md", "sm"] | None = Field(default=None)
    is_required: bool | None = Field(default=None, alias="isRequired")
    description: str | dict[str, Any] | None | None = Field(default=None)
    tooltip: str | None = Field(default=None)
    tooltip_description: str | None = Field(default=None, alias="tooltipDescription")
    children: str | dict[str, Any] | None | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
