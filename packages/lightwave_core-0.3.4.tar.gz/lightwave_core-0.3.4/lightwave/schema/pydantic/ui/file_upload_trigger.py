"""
Pydantic schema for FileUploadTrigger component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/file-upload-trigger/file-upload-trigger.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FileTriggerProps(JSONFieldSchema):
    """Props for FileTrigger component."""

    accepted_file_types: list[str] | None = Field(
        default=None, alias="acceptedFileTypes", description="Specifies what mime type of files are allowed."
    )
    allows_multiple: bool | None = Field(
        default=None, alias="allowsMultiple", description="Whether multiple files can be selected."
    )
    default_camera: Literal["environment", "user"] | None = Field(
        default=None,
        alias="defaultCamera",
        description="Specifies the use of a media capture mechanism to capture the media on the spot.",
    )
    on_select: Any | None = Field(default=None, alias="onSelect", description="Handler when a user selects a file.")
    children: str | dict[str, Any] | None = Field(description="The children of the component.")
    accept_directory: bool | None = Field(
        default=None,
        alias="acceptDirectory",
        description="Enables the selection of directories instead of individual files.",
    )
