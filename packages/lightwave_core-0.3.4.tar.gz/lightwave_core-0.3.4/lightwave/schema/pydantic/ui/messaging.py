"""
Pydantic schema for Messaging component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/messaging/messaging.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class MessageStatusProps(JSONFieldSchema):
    """Props for MessageStatus component."""

    status: Literal["failed", "read", "sent"]
    read_at: str | None = Field(default=None, alias="readAt")


class MessageItemProps(JSONFieldSchema):
    """Props for MessageItem component."""

    msg: Any
    show_user_label: bool | None = Field(default=None, alias="showUserLabel")
