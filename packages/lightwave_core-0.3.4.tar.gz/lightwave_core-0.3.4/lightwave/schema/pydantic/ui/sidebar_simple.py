"""
Pydantic schema for SidebarSimple component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/sidebar-navigation/sidebar-simple.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItemType


class SidebarNavigationProps(JSONFieldSchema):
    """Props for SidebarNavigation component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    items: list[NavItemType] = Field(description="List of items to display.")
    footer_items: list[NavItemType] | None = Field(
        default=None, alias="footerItems", description="List of footer items to display."
    )
    feature_card: str | dict[str, Any] | None | None = Field(
        default=None, alias="featureCard", description="Feature card to display."
    )
    show_account_card: bool | None = Field(
        default=None, alias="showAccountCard", description="Whether to show the account card."
    )
    hide_border: bool | None = Field(
        default=None, alias="hideBorder", description="Whether to hide the right side border."
    )
    class_name: str | None = Field(
        default=None, alias="className", description="Additional CSS classes to apply to the sidebar."
    )
