"""
Pydantic schema for CreditCard component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: shared-assets/credit-card/credit-card.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class CreditCardProps(JSONFieldSchema):
    """Props for CreditCard component."""

    company: str | None = Field(default=None)
    card_number: str | None = Field(default=None, alias="cardNumber")
    card_holder: str | None = Field(default=None, alias="cardHolder")
    card_expiration: str | None = Field(default=None, alias="cardExpiration")
    type: T | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    width: int | float | None = Field(default=None)


class IllustrationProps(JSONFieldSchema):
    """Props for Illustration component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)
    svg_class_name: str | None = Field(default=None, alias="svgClassName")
    children_class_name: str | None = Field(default=None, alias="childrenClassName")
