"""
Pydantic schema for NavMenuItemCard component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/header-navigation/base-components/nav-menu-item-card.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ImageCardProps(JSONFieldSchema):
    """Props for ImageCard component."""

    href: str | None = Field(default=None)
    img_src: str | None = Field(default=None, alias="imgSrc")
    title: str
    subtitle: str
    actions_content: str | dict[str, Any] | None | None = Field(default=None, alias="actionsContent")


class VideoCardProps(JSONFieldSchema):
    """Props for VideoCard component."""

    href: str | None = Field(default=None)
    img_src: str = Field(alias="imgSrc")
    title: str
    description: str
    actions_content: str | dict[str, Any] | None | None = Field(default=None, alias="actionsContent")


class FeatureCardProps(JSONFieldSchema):
    """Props for FeatureCard component."""

    href: str | None = Field(default=None)
    img_src: str = Field(alias="imgSrc")
    title: str
    description: str
    actions_content: str | dict[str, Any] | None | None = Field(default=None, alias="actionsContent")
