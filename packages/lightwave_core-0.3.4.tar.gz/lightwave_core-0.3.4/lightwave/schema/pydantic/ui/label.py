"""
Pydantic schema for Label component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/input/label.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class LabelProps(JSONFieldSchema):
    """Props for Label component."""

    children: str | dict[str, Any] | None
    is_required: bool | None = Field(default=None, alias="isRequired")
    tooltip: str | None = Field(default=None)
    tooltip_description: str | None = Field(default=None, alias="tooltipDescription")
    ref: T | None = Field(default=None)
