"""
Pydantic schema for Toggle component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/toggle/toggle.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ToggleBaseProps(JSONFieldSchema):
    """Props for ToggleBase component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    slim: bool | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    is_hovered: bool | None = Field(default=None, alias="isHovered")
    is_focus_visible: bool | None = Field(default=None, alias="isFocusVisible")
    is_selected: bool | None = Field(default=None, alias="isSelected")
    is_disabled: bool | None = Field(default=None, alias="isDisabled")


class ToggleProps(JSONFieldSchema):
    """Props for Toggle component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    label: str | None = Field(default=None)
    hint: str | dict[str, Any] | None | None = Field(default=None)
    slim: bool | None = Field(default=None)
