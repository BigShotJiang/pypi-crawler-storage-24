"""
Pydantic schema for Box component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: shared-assets/illustrations/box.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class IllustrationProps(JSONFieldSchema):
    """Props for Illustration component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)
    svg_class_name: str | None = Field(default=None, alias="svgClassName")
    children_class_name: str | None = Field(default=None, alias="childrenClassName")
