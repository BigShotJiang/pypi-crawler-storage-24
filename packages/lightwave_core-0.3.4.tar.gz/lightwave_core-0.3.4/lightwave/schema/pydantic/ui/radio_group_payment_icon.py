"""
Pydantic schema for RadioGroupPaymentIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/radio-groups/radio-group-payment-icon.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import PaymentCardItemType


class RadioGroupPaymentIconProps(JSONFieldSchema):
    """Props for RadioGroupPaymentIcon component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    items: list[PaymentCardItemType]
