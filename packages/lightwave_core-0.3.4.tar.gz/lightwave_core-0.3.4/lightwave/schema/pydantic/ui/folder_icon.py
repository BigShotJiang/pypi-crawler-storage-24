"""
Pydantic schema for FolderIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/folder-icon.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FolderProps(JSONFieldSchema):
    """Props for Folder component."""

    color: Literal["brand", "gray"]
    type: Literal["closed", "open"] | None = Field(default=None)
