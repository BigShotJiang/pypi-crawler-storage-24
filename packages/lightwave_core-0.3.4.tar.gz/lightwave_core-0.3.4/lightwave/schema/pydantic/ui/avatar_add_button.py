"""
Pydantic schema for AvatarAddButton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/base-components/avatar-add-button.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AvatarAddButtonProps(JSONFieldSchema):
    """Props for AvatarAddButton component."""

    size: Literal["md", "sm", "xs"]
    title: str | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
