"""
Pydantic schema for CalendarMonthViewCell component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/base-components/calendar-month-view-cell.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CalendarMonthViewCellProps(JSONFieldSchema):
    """Props for CalendarMonthViewCell component."""

    day: int | float
    state: Literal["current", "default", "selected"] | None = Field(default=None)
    is_disabled: bool | None = Field(default=None, alias="isDisabled")
