"""
Pydantic schema for CalendarViewDropdown component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/base-components/calendar-view-dropdown.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ItemProps(JSONFieldSchema):
    """Props for Item component."""

    label: str
    value: str
    addon: str | None = Field(default=None)


class CalendarViewDropdownProps(JSONFieldSchema):
    """Props for CalendarViewDropdown component."""

    options: list[ItemProps]
    value: str
    on_selection_change: Any = Field(alias="onSelectionChange")
