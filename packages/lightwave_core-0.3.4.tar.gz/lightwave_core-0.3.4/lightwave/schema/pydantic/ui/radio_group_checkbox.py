"""
Pydantic schema for RadioGroupCheckbox component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/radio-groups/radio-group-checkbox.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import RadioGroupItemType


class RadioGroupCheckboxProps(JSONFieldSchema):
    """Props for RadioGroupCheckbox component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    items: list[RadioGroupItemType]
