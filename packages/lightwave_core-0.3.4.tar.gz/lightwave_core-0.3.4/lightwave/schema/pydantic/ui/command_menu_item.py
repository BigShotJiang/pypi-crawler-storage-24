"""
Pydantic schema for CommandMenuItem component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/base-components/command-menu-item.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommandDropdownMenuItemProps(JSONFieldSchema):
    """Props for CommandDropdownMenuItem component."""

    pass
