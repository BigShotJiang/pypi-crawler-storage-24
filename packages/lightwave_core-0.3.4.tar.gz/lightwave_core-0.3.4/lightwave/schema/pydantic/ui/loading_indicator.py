"""
Pydantic schema for LoadingIndicator component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/loading-indicator/loading-indicator.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class LoadingIndicatorProps(JSONFieldSchema):
    """Props for LoadingIndicator component."""

    type: Literal["dot-circle", "line-simple", "line-spinner"] | None = Field(
        default="line-simple", description="The visual style of the loading indicator."
    )
    size: Literal["lg", "md", "sm", "xl"] | None = Field(default="sm", description="The size of the loading indicator.")
    label: str | None = Field(default=None, description="Optional text label displayed below the indicator.")
