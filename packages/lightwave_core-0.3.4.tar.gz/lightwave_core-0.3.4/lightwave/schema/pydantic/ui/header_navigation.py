"""
Pydantic schema for HeaderNavigation component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/header-navigation.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItem


class HeaderNavigationBaseProps(JSONFieldSchema):
    """Props for HeaderNavigationBase component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    items: list[NavItem] = Field(description="List of items to display.")
    sub_items: list[NavItem] | None = Field(default=None, alias="subItems", description="List of sub-items to display.")
    trailing_content: str | dict[str, Any] | None | None = Field(
        default=None, alias="trailingContent", description="Content to display in the trailing position."
    )
    show_avatar_dropdown: bool | None = Field(
        default=None, alias="showAvatarDropdown", description="Whether to show the avatar dropdown."
    )
    hide_border: bool | None = Field(default=None, alias="hideBorder", description="Whether to hide the bottom border.")
