"""
Pydantic schema for Tabs component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/tabs/tabs.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class TabListComponentProps(JSONFieldSchema):
    """Props for TabListComponent component."""

    size: Literal["md", "sm"] | None = Field(default=None, description="The size of the tab list.")
    type: T | None = Field(default=None, description="The type of the tab list.")
    orientation: Any | None = Field(default=None, description="The orientation of the tab list.")
    items: list[T] = Field(description="The items of the tab list.")
    full_width: bool | None = Field(default=None, alias="fullWidth", description="Whether the tab list is full width.")


class TabComponentProps(JSONFieldSchema):
    """Props for TabComponent component."""

    label: str | dict[str, Any] | None | None = Field(default=None, description="The label of the tab.")
    children: str | dict[str, Any] | None | None = Field(default=None, description="The children of the tab.")
    badge: str | int | float | None = Field(default=None, description="The badge displayed next to the label.")
