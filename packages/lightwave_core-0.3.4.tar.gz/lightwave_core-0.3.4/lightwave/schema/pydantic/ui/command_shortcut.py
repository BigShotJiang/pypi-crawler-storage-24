"""
Pydantic schema for CommandShortcut component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/base-components/command-shortcut.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommandShortcutProps(JSONFieldSchema):
    """Props for CommandShortcut component."""

    keys: list[str]
    with_then: bool | None = Field(default=None, alias="withThen")
    class_name: str | None = Field(default=None, alias="className")
