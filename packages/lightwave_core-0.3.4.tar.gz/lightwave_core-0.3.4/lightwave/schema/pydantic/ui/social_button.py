"""
Pydantic schema for SocialButton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/buttons/social-button.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommonProps(JSONFieldSchema):
    """Props for Common component."""

    social: Literal["apple", "dribble", "facebook", "figma", "google", "twitter"]
    disabled: bool | None = Field(default=None)
    theme: Literal["brand", "color", "gray"] | None = Field(default=None)
    size: Literal["2xl", "lg", "md", "sm", "xl"] | None = Field(default=None)


class ButtonProps(JSONFieldSchema):
    """Props for Button component."""

    slot: str | None = Field(default=None)


class LinkProps(JSONFieldSchema):
    """Props for Link component."""

    pass


class SocialButtonProps(JSONFieldSchema):
    """Props for SocialButton component."""

    pass
