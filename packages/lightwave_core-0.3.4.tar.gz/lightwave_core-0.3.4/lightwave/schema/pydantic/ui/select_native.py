"""
Pydantic schema for SelectNative component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/select/select-native.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class SelectOptionItem(JSONFieldSchema):
    """Individual option item for native select."""

    label: str = Field(description="Display label for the option")
    value: str = Field(description="Value of the option")
    disabled: bool | None = Field(default=None, description="Whether the option is disabled")


class NativeSelectProps(JSONFieldSchema):
    """Props for NativeSelect component."""

    label: str | None = Field(default=None)
    hint: str | None = Field(default=None)
    select_class_name: str | None = Field(default=None, alias="selectClassName")
    options: list[SelectOptionItem] | list[dict[str, Any]] = Field(default_factory=list)
