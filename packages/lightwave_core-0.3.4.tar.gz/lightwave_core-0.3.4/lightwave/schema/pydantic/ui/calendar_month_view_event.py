"""
Pydantic schema for CalendarMonthViewEvent component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/base-components/calendar-month-view-event.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CalendarMonthViewEventProps(JSONFieldSchema):
    """Props for CalendarMonthViewEvent component."""

    label: str
    supporting_text: str | None = Field(default=None, alias="supportingText")
    with_dot: bool | None = Field(default=None, alias="withDot")
    color: Literal["blue", "brand", "gray", "green", "indigo", "orange", "pink", "purple", "yellow"] | None = Field(
        default=None
    )
    collapse_on_mobile: bool | None = Field(default=None, alias="collapseOnMobile")
