"""
Pydantic schema for Button component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/buttons/button.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommonProps(JSONFieldSchema):
    """Common props shared between button and anchor variants"""

    is_disabled: bool | None = Field(
        default=None, alias="isDisabled", description="Disables the button and shows a disabled state"
    )
    is_loading: bool | None = Field(
        default=None, alias="isLoading", description="Shows a loading spinner and disables the button"
    )
    size: Literal["lg", "md", "sm", "xl"] | None = Field(default=None, description="The size variant of the button")
    color: (
        Literal[
            "link-color",
            "link-destructive",
            "link-gray",
            "primary",
            "primary-destructive",
            "secondary",
            "secondary-destructive",
            "tertiary",
            "tertiary-destructive",
        ]
        | None
    ) = Field(default=None, description="The color variant of the button")
    icon_leading: str | dict[str, Any] | None | None = Field(
        default=None, alias="iconLeading", description="Icon component or element to show before the text"
    )
    icon_trailing: str | dict[str, Any] | None | None = Field(
        default=None, alias="iconTrailing", description="Icon component or element to show after the text"
    )
    no_text_padding: bool | None = Field(
        default=None, alias="noTextPadding", description="Removes horizontal padding from the text content"
    )
    show_text_while_loading: bool | None = Field(
        default=None, alias="showTextWhileLoading", description="When true, keeps the text visible during loading state"
    )


class ButtonProps(JSONFieldSchema):
    """Props for Button component."""

    color: Literal["primary", "secondary"] | None = Field(default=None)
    size: Any | None = Field(default=None)


class LinkProps(JSONFieldSchema):
    """Props for the link variant (anchor tag)"""

    pass


class Props(JSONFieldSchema):
    """Union type of button and link props"""

    pass
