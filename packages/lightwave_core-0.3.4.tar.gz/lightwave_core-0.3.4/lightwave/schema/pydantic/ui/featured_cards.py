"""
Pydantic schema for FeaturedCards component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/base-components/featured-cards.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeaturedCardCommonProps(JSONFieldSchema):
    """Props for FeaturedCardCommon component."""

    title: str
    description: str | dict[str, Any] | None
    confirm_label: str = Field(alias="confirmLabel")
    class_name: str | None = Field(default=None, alias="className")
    on_dismiss: Any = Field(alias="onDismiss")
    on_confirm: Any = Field(alias="onConfirm")
