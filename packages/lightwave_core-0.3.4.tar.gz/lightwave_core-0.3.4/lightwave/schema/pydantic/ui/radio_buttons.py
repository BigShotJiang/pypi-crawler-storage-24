"""
Pydantic schema for RadioButtons component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/radio-buttons/radio-buttons.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class RadioButtonBaseProps(JSONFieldSchema):
    """Props for RadioButtonBase component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    is_focus_visible: bool | None = Field(default=None, alias="isFocusVisible")
    is_selected: bool | None = Field(default=None, alias="isSelected")
    is_disabled: bool | None = Field(default=None, alias="isDisabled")


class RadioButtonProps(JSONFieldSchema):
    """Props for RadioButton component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    label: str | dict[str, Any] | None | None = Field(default=None)
    hint: str | dict[str, Any] | None | None = Field(default=None)
    ref: T | None = Field(default=None)


class RadioGroupProps(JSONFieldSchema):
    """Props for RadioGroup component."""

    children: str | dict[str, Any] | None
    class_name: str | None = Field(default=None, alias="className")
