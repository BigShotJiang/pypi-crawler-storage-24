"""
Pydantic schema for AvatarProfilePhoto component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/avatar-profile-photo.tsx
"""

from typing import Literal

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AvatarProfilePhotoProps(JSONFieldSchema):
    """Props for AvatarProfilePhoto component."""

    size: Literal["lg", "md", "sm"]
