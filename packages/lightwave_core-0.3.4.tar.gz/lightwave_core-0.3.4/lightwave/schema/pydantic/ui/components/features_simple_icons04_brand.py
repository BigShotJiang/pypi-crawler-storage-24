"""
Pydantic schema for FeaturesSimpleIcons04Brand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-simple-icons-04-brand.tsx
Component Path: marketing/features/features-simple-icons-04-brand
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem, T


class FeaturesSimpleIcons04BrandProps(JSONFieldSchema):
    """Props for FeaturesSimpleIcons04Brand"""

    header_icon: T | None = Field(default=None, alias="headerIcon", description="Header icon")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
