"""
Pydantic schema for ContentDivider component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/content-divider/content-divider.tsx
Component Path: application/content-divider/content-divider
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ContentDividerProps(JSONFieldSchema):
    """Props for ContentDivider component."""

    type: Literal["background-fill", "dual-line", "single-line"]
    children: str | dict[str, Any] | None
    class_name: str | None = Field(default=None, alias="className")
