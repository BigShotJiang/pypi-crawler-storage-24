"""
Pydantic schema for ContactCenteredMap component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/contact/contact-centered-map.tsx
Component Path: marketing/contact/contact-centered-map
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import Location


class ContactCenteredMapProps(JSONFieldSchema):
    """Props for ContactCenteredMap component."""

    label: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main heading")
    description: str | None = Field(default=None, description="Description text")
    locations: list[Location] | None = Field(default=None, description="Array of locations to display")
    map_url: str | None = Field(
        default=None, alias="mapUrl", description="Map embed URL (e.g., Snazzy Maps, Google Maps embed)"
    )
    hide_map: bool | None = Field(default=None, alias="hideMap", description="Hide the map")
