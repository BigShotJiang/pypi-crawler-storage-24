"""
Pydantic schema for BlogSectionSimpleCenterAligned02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/blog/blog-section-simple-center-aligned-02.tsx
Component Path: marketing/blog/blog-section-simple-center-aligned-02
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import Article, SortOption, T


class BlogSectionSimpleCenterAligned02Props(JSONFieldSchema):
    """Props for BlogSectionSimpleCenterAligned02 component."""

    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    posts: list[Article] | None = Field(default=None)
    show_filters: bool | None = Field(default=None, alias="showFilters")
    show_sort: bool | None = Field(default=None, alias="showSort")
    categories: list[T] | None = Field(default=None)
    sort_options: list[SortOption] | None = Field(default=None, alias="sortOptions")
    max_articles: int | float | None = Field(default=None, alias="maxArticles")
