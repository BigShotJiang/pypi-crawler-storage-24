"""
Pydantic schema for FeaturesIconsAndImage03 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icons-and-image-03.tsx
Component Path: marketing/features/features-icons-and-image-03
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconsAndImage03Props(JSONFieldSchema):
    """Props for FeaturesIconsAndImage03"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
    video: Any | None = Field(default=None, description="Video configuration")
