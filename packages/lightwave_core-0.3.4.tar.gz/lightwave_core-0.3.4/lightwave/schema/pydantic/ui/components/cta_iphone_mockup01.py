"""
Pydantic schema for CtaIphoneMockup01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-iphone-mockup-01.tsx
Component Path: marketing/cta/cta-iphone-mockup-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CTAIPhoneMockup01Props(JSONFieldSchema):
    """Props for CTAIPhoneMockup01 component."""

    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    mockup_image_light: str | None = Field(default=None, alias="mockupImageLight")
    mockup_image_dark: str | None = Field(default=None, alias="mockupImageDark")
    show_app_store_button: bool | None = Field(default=None, alias="showAppStoreButton")
    show_google_play_button: bool | None = Field(default=None, alias="showGooglePlayButton")
