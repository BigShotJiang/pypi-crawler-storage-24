"""
Pydantic schema for FeaturesAlternatingLayout02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-alternating-layout-02.tsx
Component Path: marketing/features/features-alternating-layout-02
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class FeaturesAlternatingLayout02Props(JSONFieldSchema):
    """Props for FeaturesAlternatingLayout02"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    sections: list[T] | None = Field(default=None, description="Feature sections")
