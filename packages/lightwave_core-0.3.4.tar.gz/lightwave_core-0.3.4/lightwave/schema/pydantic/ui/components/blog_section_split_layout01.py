"""
Pydantic schema for BlogSectionSplitLayout01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/blog/blog-section-split-layout-01.tsx
Component Path: marketing/blog/blog-section-split-layout-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import Article, SortOption, T


class BlogSectionSplitLayout01Props(JSONFieldSchema):
    """Props for BlogSectionSplitLayout01 component."""

    eyebrow: str | None = Field(default=None)
    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    articles: list[Article] | None = Field(default=None)
    show_filters: bool | None = Field(default=None, alias="showFilters")
    show_sort: bool | None = Field(default=None, alias="showSort")
    categories: list[T] | None = Field(default=None)
    sort_options: list[SortOption] | None = Field(default=None, alias="sortOptions")
    max_articles: int | float | None = Field(default=None, alias="maxArticles")
    button_label: str | None = Field(default=None, alias="buttonLabel")
    button_href: str | None = Field(default=None, alias="buttonHref")
