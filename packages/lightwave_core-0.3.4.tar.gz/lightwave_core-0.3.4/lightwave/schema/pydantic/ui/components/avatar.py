"""
Pydantic schema for Avatar component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/avatar.tsx
Component Path: base/avatar/avatar
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AvatarProps(JSONFieldSchema):
    """Props for Avatar component."""

    size: Any | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    src: str | None = Field(default=None)
    alt: str | None = Field(default=None)
    contrast_border: bool | None = Field(
        default=None, alias="contrastBorder", description="Display a contrast border around the avatar."
    )
    badge: str | dict[str, Any] | None | None = Field(default=None, description="Display a badge (i.e. company logo).")
    status: Literal["offline", "online"] | None = Field(default=None, description="Display a status indicator.")
    verified: bool | None = Field(default=False, description="Display a verified tick icon.")
    initials: str | None = Field(
        default=None, description="The initials of the user to display if no image is available."
    )
    placeholder_icon: str | None = Field(
        default=None, alias="placeholderIcon", description="An icon to display if no image is available."
    )
    placeholder: str | dict[str, Any] | None | None = Field(
        default=None, description="A placeholder to display if no image is available."
    )
    focusable: bool | None = Field(
        default=False,
        description="Whether the avatar should show a focus ring when the parent group is in focus. For example, when the avatar is wrapped inside a link.",
    )
