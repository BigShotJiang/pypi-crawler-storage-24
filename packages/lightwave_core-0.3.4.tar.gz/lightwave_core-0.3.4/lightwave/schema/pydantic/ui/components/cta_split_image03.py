"""
Pydantic schema for CtaSplitImage03 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-split-image-03.tsx
Component Path: marketing/cta/cta-split-image-03
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CTASplitImage03Props(JSONFieldSchema):
    """Props for CTASplitImage03 component."""

    eyebrow: str | None = Field(default=None)
    headline: str | None = Field(default=None)
    headline_mobile: str | None = Field(default=None, alias="headlineMobile")
    description: str | None = Field(default=None)
    primary_cta_text: str | None = Field(default=None, alias="primaryCtaText")
    primary_cta_href: str | None = Field(default=None, alias="primaryCtaHref")
    secondary_cta_text: str | None = Field(default=None, alias="secondaryCtaText")
    secondary_cta_href: str | None = Field(default=None, alias="secondaryCtaHref")
    image_src: str | None = Field(default=None, alias="imageSrc")
    image_alt: str | None = Field(default=None, alias="imageAlt")
