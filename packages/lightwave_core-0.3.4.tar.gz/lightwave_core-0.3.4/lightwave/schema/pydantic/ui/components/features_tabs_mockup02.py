"""
Pydantic schema for FeaturesTabsMockup02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-tabs-mockup-02.tsx
Component Path: marketing/features/features-tabs-mockup-02
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeaturesTabsMockup02Props(JSONFieldSchema):
    """Props for FeaturesTabsMockup02 component."""

    badge: str | None = Field(default=None, description="Badge label")
    mobile_mockup: Any | None = Field(default=None, alias="mobileMockup", description="Mobile mockup images")
    tabs: list[dict[str, Any]] | None = Field(default=None, description="Tab items")
