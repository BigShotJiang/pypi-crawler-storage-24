"""
Pydantic schema for BrandLogo component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/logo/brand-logo.tsx
Component Path: foundations/logo/brand-logo
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BrandLogoProps(JSONFieldSchema):
    """Props for BrandLogo component."""

    logo_url: str = Field(alias="logoUrl", description="URL to the logo image (from CDN)")
    name: str = Field(description="Brand name to display next to logo")
    show_text: bool | None = Field(
        default=None, alias="showText", description="Show text alongside logo (default: true)"
    )
    size: Literal["lg", "md", "sm", "xl"] | None = Field(default=None, description="Size variant")


class BrandLogoMinimalProps(JSONFieldSchema):
    """Props for BrandLogoMinimal component."""

    pass
