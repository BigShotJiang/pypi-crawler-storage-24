"""
Pydantic schema for CareersCard01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/careers/careers-card-01.tsx
Component Path: marketing/careers/careers-card-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import DepartmentOption, JobCard01Props


class CareersCard01Props(JSONFieldSchema):
    """Props for CareersCard01 component."""

    headline: str | None = Field(default=None, description="Main heading")
    description: str | None = Field(default=None, description="Description text")
    jobs: list[JobCard01Props] | None = Field(default=None, description="Array of job postings")
    departments: list[DepartmentOption] | None = Field(default=None, description="Array of department filter options")
