"""
Pydantic schema for FeaturesIconsAndMockup04 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icons-and-mockup-04.tsx
Component Path: marketing/features/features-icons-and-mockup-04
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconsAndMockup04Props(JSONFieldSchema):
    """Props for FeaturesIconsAndMockup04"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    left_features: list[FeatureItem] | None = Field(
        default=None, alias="leftFeatures", description="Left column features"
    )
    right_features: list[FeatureItem] | None = Field(
        default=None, alias="rightFeatures", description="Right column features"
    )
    mockup: Any | None = Field(default=None, description="Mockup images")
