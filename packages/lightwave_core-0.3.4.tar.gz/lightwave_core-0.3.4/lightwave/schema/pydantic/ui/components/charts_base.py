"""
Pydantic schema for ChartsBase component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/charts/charts-base.tsx
Component Path: application/charts/charts-base
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ChartTooltipContentProps(JSONFieldSchema):
    """Props for ChartTooltipContent component."""

    is_radial_chart: bool | None = Field(default=None, alias="isRadialChart")
    is_pie_chart: bool | None = Field(default=None, alias="isPieChart")
    label: str | None = Field(default=None)
    payload: Any | None = Field(default=None)


class ChartActiveDotProps(JSONFieldSchema):
    """Props for ChartActiveDot component."""

    payload: Any | None = Field(default=None)
