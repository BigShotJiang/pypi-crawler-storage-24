"""
Pydantic schema for FeaturesIntegrationsIcons01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-integrations-icons-01.tsx
Component Path: marketing/features/features-integrations-icons-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import IntegrationIcon, T


class FeaturesIntegrationsIcons01Props(JSONFieldSchema):
    """Props for FeaturesIntegrationsIcons01"""

    badge_label: str | None = Field(default=None, alias="badgeLabel", description="Badge text")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    primary_cta: T | None = Field(default=None, alias="primaryCta", description="Primary CTA button")
    secondary_cta: T | None = Field(default=None, alias="secondaryCta", description="Secondary CTA button")
    integrations: list[IntegrationIcon] | None = Field(default=None, description="Integration icons")
