"""
Pydantic schema for DateRangePicker component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/date-picker/date-range-picker.tsx
Component Path: application/date-picker/date-range-picker
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class DateRangePickerProps(JSONFieldSchema):
    """Props for DateRangePicker component."""

    on_apply: Any | None = Field(
        default=None, alias="onApply", description="The function to call when the apply button is clicked."
    )
    on_cancel: Any | None = Field(
        default=None, alias="onCancel", description="The function to call when the cancel button is clicked."
    )
