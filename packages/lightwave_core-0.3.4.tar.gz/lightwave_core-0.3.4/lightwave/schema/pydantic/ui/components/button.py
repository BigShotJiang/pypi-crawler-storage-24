"""
Pydantic schema for Button component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: emails/_components/button.tsx
Component Path: emails/_components/button
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ButtonProps(JSONFieldSchema):
    """Props for Button component."""

    color: Literal["primary", "secondary"] | None = Field(default=None)
    size: Any | None = Field(default=None)
