"""
Pydantic schema for FeaturesIconCards02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icon-cards-02.tsx
Component Path: marketing/features/features-icon-cards-02
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconCards02Props(JSONFieldSchema):
    """Props for FeaturesIconCards02"""

    header_icon: str | None = Field(default=None, alias="headerIcon", description="Header icon name")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
