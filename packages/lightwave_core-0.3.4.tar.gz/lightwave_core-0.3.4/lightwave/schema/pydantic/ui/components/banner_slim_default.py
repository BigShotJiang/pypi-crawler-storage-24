"""
Pydantic schema for BannerSlimDefault component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/banners/banner-slim-default.tsx
Component Path: marketing/banners/banner-slim-default
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BannerSlimDefaultExtendedProps(JSONFieldSchema):
    """Props for BannerSlimDefaultExtended component."""

    headline: str | None = Field(default=None, description="Main headline text")
    link_text: str | None = Field(default=None, alias="linkText", description="Link text")
    link_href: str | None = Field(default=None, alias="linkHref", description="Link URL")
    on_dismiss: Any | None = Field(default=None, alias="onDismiss", description="On dismiss callback")
