"""
Pydantic schema for FeaturesSimpleIcons04 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-simple-icons-04.tsx
Component Path: marketing/features/features-simple-icons-04
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesSimpleIcons04Props(JSONFieldSchema):
    """Props for FeaturesSimpleIcons04"""

    icon: str | None = Field(default=None, description="Icon name for the header")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
