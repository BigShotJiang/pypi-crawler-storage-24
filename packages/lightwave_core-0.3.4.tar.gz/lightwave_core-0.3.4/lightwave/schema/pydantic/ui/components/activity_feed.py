"""
Pydantic schema for ActivityFeed component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/activity-feed/activity-feed.tsx
Component Path: application/activity-feed/activity-feed
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeedItemProps(JSONFieldSchema):
    """Props for FeedItem component."""

    connector: bool | None = Field(default=None)
    size: Literal["md", "sm"] | None = Field(default=None)
