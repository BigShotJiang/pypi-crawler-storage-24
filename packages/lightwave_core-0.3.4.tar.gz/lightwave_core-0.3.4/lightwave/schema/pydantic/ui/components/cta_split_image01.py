"""
Pydantic schema for CtaSplitImage01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-split-image-01.tsx
Component Path: marketing/cta/cta-split-image-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CTASplitImage01ExtendedProps(JSONFieldSchema):
    """Props for CTASplitImage01Extended component."""

    features: list[str] | None = Field(default=None, description="Feature list items")
