"""
Pydantic schema for ContentSectionRichText01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/content/content-section-rich-text-01.tsx
Component Path: marketing/content/content-section-rich-text-01
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ContentSectionRichText01Props(JSONFieldSchema):
    """Props for ContentSectionRichText01 component."""

    body_content: str | None = Field(default=None, alias="bodyContent", description="Body content (HTML)")
    author: Any | None = Field(default=None, description="Author info")
    share_url: str | None = Field(default=None, alias="shareUrl", description="Share URL")
