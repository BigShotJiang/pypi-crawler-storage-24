"""
Pydantic schema for AiAssistantModal component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/modals/ai-assistant-modal.tsx
Component Path: application/modals/ai-assistant-modal
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AIAssistantModalProps(JSONFieldSchema):
    """Props for AIAssistantModal component."""

    transcription_endpoint: str | None = Field(
        default=None,
        alias="transcriptionEndpoint",
        description="API endpoint for audio transcription (default: /api/ai/transcribe/)",
    )
    on_message_submit: Any | None = Field(
        default=None,
        alias="onMessageSubmit",
        description="Callback when a message is submitted (text or transcribed voice)",
    )
