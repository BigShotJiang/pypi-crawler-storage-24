"""
Pydantic schema for AngelList component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/social-icons/angel-list.tsx
Component Path: foundations/social-icons/angel-list
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class Props(JSONFieldSchema):
    """Props for  component."""

    size: int | float | None = Field(default=None)
