"""
Pydantic schema for FeaturesSimpleIcons02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-simple-icons-02.tsx
Component Path: marketing/features/features-simple-icons-02
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesSimpleIcons02Props(JSONFieldSchema):
    """Props for FeaturesSimpleIcons02 component."""

    eyebrow: str | None = Field(default=None, description="Small text above heading")
    headline: str | None = Field(default=None, description="Section headline")
    subheading: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
