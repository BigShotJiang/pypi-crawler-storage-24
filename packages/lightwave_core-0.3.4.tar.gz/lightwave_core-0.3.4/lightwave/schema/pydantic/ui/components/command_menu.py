"""
Pydantic schema for CommandMenu component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/command-menu.tsx
Component Path: application/command-menus/command-menu
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import CommandMenuGroupType


class CommandMenuRootProps(JSONFieldSchema):
    """Props for CommandMenuRoot component."""

    placeholder: str | None = Field(default=None)
    empty_state: str | dict[str, Any] | None | None = Field(default=None, alias="emptyState")
    dialog_class_name: Any = Field(default=None, alias="dialogClassName")
    overlay_class_name: Any = Field(default=None, alias="overlayClassName")
    items: list[CommandMenuGroupType] | None = Field(default=None)
    default_items: list[CommandMenuGroupType] | None = Field(default=None, alias="defaultItems")
    sensitivity: Literal["accent", "base", "case", "variant"] | None = Field(default=None)
    shortcut: str | None = Field(default=None)
    filter: bool | Any = Field(default=None)


class CommandMenuProps(JSONFieldSchema):
    """Props for CommandMenu component."""

    dialog_class_name: Any = Field(default=None, alias="dialogClassName")


class CommandMenuListProps(JSONFieldSchema):
    """Props for CommandMenuList component."""

    pass


class CommandMenuSectionProps(JSONFieldSchema):
    """Props for CommandMenuSection component."""

    title: str | None = Field(default=None)


class PreviewChildrenProps(JSONFieldSchema):
    """Props for PreviewChildren component."""

    selected_id: Any = Field(alias="selectedId", description="The unique identifier (`Key`) of the selected item.")


class CommandMenuPreviewProps(JSONFieldSchema):
    """Props for CommandMenuPreview component."""

    as_child: bool | None = Field(default=None, alias="asChild")
    children: str | dict[str, Any] | None
