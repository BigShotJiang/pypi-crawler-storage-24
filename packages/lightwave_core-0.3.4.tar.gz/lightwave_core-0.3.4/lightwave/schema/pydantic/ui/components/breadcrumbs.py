"""
Pydantic schema for Breadcrumbs component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/breadcrumbs/breadcrumbs.tsx
Component Path: application/breadcrumbs/breadcrumbs
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class BreadcrumbsProps(JSONFieldSchema):
    """Props for Breadcrumbs component."""

    divider: Literal["chevron", "slash"] | None = Field(default=None)
    children: str | dict[str, Any] | None
    type: T | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    max_visible_items: int | float | None = Field(
        default=None,
        alias="maxVisibleItems",
        description="The maximum number of visible items. If the number of items exceeds this value, the breadcrumbs will collapse into a single item with an ellipsis that can be expanded.",
    )
