"""
Pydantic schema for FeaturesIconsAndImage04 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icons-and-image-04.tsx
Component Path: marketing/features/features-icons-and-image-04
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconsAndImage04Props(JSONFieldSchema):
    """Props for FeaturesIconsAndImage04"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
    image: Any | None = Field(default=None, description="Image source and alt")
