"""
Pydantic schema for CTASkeleton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: skeletons/CTASkeleton.tsx
Component Path: skeletons/CTASkeleton
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class CTASkeletonProps(JSONFieldSchema):
    """Props for CTASkeleton component."""

    variant: T | None = Field(default=None, description="CTA variant layout")
    with_features: bool | None = Field(default=None, alias="withFeatures", description="Show feature list items")
    class_name: str | None = Field(default=None, alias="className", description="Additional className")
