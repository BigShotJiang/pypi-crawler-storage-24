"""
Pydantic schema for BannerSlimBrand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/banners/banner-slim-brand.tsx
Component Path: marketing/banners/banner-slim-brand
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BannerSlimBrandProps(JSONFieldSchema):
    """Props for BannerSlimBrand component."""

    headline: str | None = Field(default=None, description="Main headline text")
    link_text: str | None = Field(default=None, alias="linkText", description="Link text")
    link_href: str | None = Field(default=None, alias="linkHref", description="Link URL")
    on_dismiss: Any | None = Field(default=None, alias="onDismiss", description="On dismiss callback")
