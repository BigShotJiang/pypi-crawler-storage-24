"""
Pydantic schema for Cell component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/date-picker/cell.tsx
Component Path: application/date-picker/cell
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CalendarCellProps(JSONFieldSchema):
    """Props for CalendarCell component."""

    is_range_calendar: bool | None = Field(
        default=None, alias="isRangeCalendar", description="Whether the calendar is a range calendar."
    )
    is_highlighted: bool | None = Field(
        default=None, alias="isHighlighted", description="Whether the cell is highlighted."
    )
