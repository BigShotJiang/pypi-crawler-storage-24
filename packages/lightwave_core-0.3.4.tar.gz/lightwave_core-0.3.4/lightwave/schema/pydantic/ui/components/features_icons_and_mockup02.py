"""
Pydantic schema for FeaturesIconsAndMockup02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icons-and-mockup-02.tsx
Component Path: marketing/features/features-icons-and-mockup-02
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconsAndMockup02Props(JSONFieldSchema):
    """Props for FeaturesIconsAndMockup02"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
    mockup: Any | None = Field(default=None, description="Mockup images")
