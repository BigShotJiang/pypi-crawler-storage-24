"""
Pydantic schema for CtaSimpleCentered component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-simple-centered.tsx
Component Path: marketing/cta/cta-simple-centered
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CTASimpleCenteredProps(JSONFieldSchema):
    """Props for CTASimpleCentered component."""

    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    primary_cta_text: str | None = Field(default=None, alias="primaryCtaText")
    primary_cta_href: str | None = Field(default=None, alias="primaryCtaHref")
    secondary_cta_text: str | None = Field(default=None, alias="secondaryCtaText")
    secondary_cta_href: str | None = Field(default=None, alias="secondaryCtaHref")
