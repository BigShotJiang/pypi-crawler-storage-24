"""
Pydantic schema for BannerSingleActionDefaultFullWidth component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/banners/banner-single-action-default-full-width.tsx
Component Path: marketing/banners/banner-single-action-default-full-width
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BannerSingleActionDefaultFullWidthProps(JSONFieldSchema):
    """Props for BannerSingleActionDefaultFullWidth component."""

    headline: str | None = Field(default=None, description="Main headline text")
    on_dismiss: Any | None = Field(default=None, alias="onDismiss", description="On dismiss callback")
