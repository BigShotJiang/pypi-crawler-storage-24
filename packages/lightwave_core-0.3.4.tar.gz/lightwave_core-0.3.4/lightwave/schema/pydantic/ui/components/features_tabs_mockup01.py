"""
Pydantic schema for FeaturesTabsMockup01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-tabs-mockup-01.tsx
Component Path: marketing/features/features-tabs-mockup-01
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeaturesTabsMockup01Props(JSONFieldSchema):
    """Props for FeaturesTabsMockup01 component."""

    badge: str | None = Field(default=None, description="Badge label")
    mockup: Any | None = Field(default=None, description="Mockup images with light/dark variants")
    tabs: list[dict[str, Any]] | None = Field(default=None, description="Tab items")
