"""
Shared type definitions for UI component schemas.

AUTO-GENERATED - DO NOT EDIT MANUALLY

This module provides type placeholders for TypeScript types
that were extracted from component props. These are typed as Any
since the full structure comes from TypeScript interfaces.
"""

from typing import Any, TypeVar

# Generic type placeholder for TypeScript generics
T = TypeVar("T", bound=Any)

# =============================================================================
# Component Item Types (extracted from TypeScript)
# =============================================================================

# These types represent complex objects from TypeScript interfaces.
# They're defined as Any here since full validation happens at runtime.
# TODO: Generate proper Pydantic models for these from TypeScript.

# Articles and Blog
Article = Any
SortOption = Any

# Navigation
NavItem = Any
NavItemType = Any
NavItemDividerType = Any
HeaderNavItem = Any
AuthMenuItem = Any

# Features
FeatureItem = Any
FeatureItemWithIcon = Any
FeatureSection = Any
FeatureSection03 = Any
FeatureSection04 = Any

# Footer
FooterNavCategory = Any
FooterSocialLink = Any
FooterLegalLink = Any
FooterSocialItem = Any

# Testimonials and Reviews
ReviewItem = Any
MetricItem = Any

# Forms and Inputs
SelectItemType = Any
RadioGroupItemType = Any
CommandMenuGroupType = Any
IconCardItemType = Any
AvatarItemType = Any
PaymentCardItemType = Any
Item = Any

# Social and Integrations
SocialProvider = Any
IntegrationItem = Any
IntegrationIcon = Any
LogoItem = Any

# Calendar and Dates
DateValue = Any

# Application-specific
NotificationItem = Any
InboxEmail = Any
SupportAvatar = Any
GalleryImage = Any

# Pricing and Plans
PlanItem = Any
CreditCardConfig = Any

# Contact and Location
ContactMethod = Any
Location = Any

# Careers
JobCard01Props = Any
DepartmentOption = Any

# FAQ
FAQItemWithIcon = Any

# =============================================================================
# React/HTML Types
# =============================================================================

# ReactNode placeholder (children, icons, etc.)
ReactNode = Any

# HTML element refs
HTMLElement = Any

# Theme type
Theme = Any
