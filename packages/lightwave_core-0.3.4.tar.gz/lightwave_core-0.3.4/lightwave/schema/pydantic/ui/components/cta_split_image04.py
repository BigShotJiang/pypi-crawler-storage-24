"""
Pydantic schema for CtaSplitImage04 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-split-image-04.tsx
Component Path: marketing/cta/cta-split-image-04
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CTASplitImage04Props(JSONFieldSchema):
    """Props for CTASplitImage04 component."""

    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    primary_cta_text: str | None = Field(default=None, alias="primaryCtaText")
    primary_cta_href: str | None = Field(default=None, alias="primaryCtaHref")
    secondary_cta_text: str | None = Field(default=None, alias="secondaryCtaText")
    secondary_cta_href: str | None = Field(default=None, alias="secondaryCtaHref")
    image_src: str | None = Field(default=None, alias="imageSrc")
    image_alt: str | None = Field(default=None, alias="imageAlt")
