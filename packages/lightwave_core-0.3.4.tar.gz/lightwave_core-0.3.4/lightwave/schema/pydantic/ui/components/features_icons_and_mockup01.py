"""
Pydantic schema for FeaturesIconsAndMockup01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icons-and-mockup-01.tsx
Component Path: marketing/features/features-icons-and-mockup-01
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconsAndMockup01Props(JSONFieldSchema):
    """Props for FeaturesIconsAndMockup01"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
    mockup: Any | None = Field(default=None, description="Mockup images")
