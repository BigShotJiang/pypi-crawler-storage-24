"""
Pydantic schema for Badges component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/badges/badges.tsx
Component Path: base/badges/badges
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class BadgeProps(JSONFieldSchema):
    """Props for Badge component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    color: T | None = Field(default=None)
    children: str | dict[str, Any] | None
    class_name: str | None = Field(default=None, alias="className")


class BadgeWithDotProps(JSONFieldSchema):
    """Props for BadgeWithDot component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    color: T | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    children: str | dict[str, Any] | None


class BadgeWithIconProps(JSONFieldSchema):
    """Props for BadgeWithIcon component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    color: T | None = Field(default=None)
    icon_leading: T | None = Field(default=None, alias="iconLeading")
    icon_trailing: T | None = Field(default=None, alias="iconTrailing")
    children: str | dict[str, Any] | None
    class_name: str | None = Field(default=None, alias="className")


class BadgeWithFlagProps(JSONFieldSchema):
    """Props for BadgeWithFlag component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    flag: T | None = Field(default=None)
    color: T | None = Field(default=None)
    children: str | dict[str, Any] | None


class BadgeWithImageProps(JSONFieldSchema):
    """Props for BadgeWithImage component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    img_src: str = Field(alias="imgSrc")
    color: T | None = Field(default=None)
    children: str | dict[str, Any] | None


class BadgeWithButtonProps(JSONFieldSchema):
    """Props for BadgeWithButton component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    icon: T | None = Field(default=None)
    color: T | None = Field(default=None)
    children: str | dict[str, Any] | None
    button_label: str | None = Field(default=None, alias="buttonLabel", description="The label for the button.")
    on_button_click: T | None = Field(
        default=None, alias="onButtonClick", description="The click event handler for the button."
    )


class BadgeIconProps(JSONFieldSchema):
    """Props for BadgeIcon component."""

    type: T | None = Field(default=None)
    size: Any | None = Field(default=None)
    icon: T
    color: T | None = Field(default=None)
    children: str | dict[str, Any] | None | None = Field(default=None)
