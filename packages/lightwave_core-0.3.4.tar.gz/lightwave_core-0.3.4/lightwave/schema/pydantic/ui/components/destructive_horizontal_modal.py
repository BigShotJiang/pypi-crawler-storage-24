"""
Pydantic schema for DestructiveHorizontalModal component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/modals/destructive-horizontal-modal.tsx
Component Path: application/modals/destructive-horizontal-modal
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class DestructiveHorizontalModalProps(JSONFieldSchema):
    """Props for the DestructiveHorizontalModal component.
    All string props support CMS-driven content with path template defaults."""

    title: str | None = Field(default=None, description="Modal title text")
    description: str | None = Field(default=None, description="Description text explaining the destructive action")
    confirm_label: str | None = Field(
        default=None, alias="confirmLabel", description="Primary destructive action button label"
    )
    cancel_label: str | None = Field(default=None, alias="cancelLabel", description="Secondary action button label")
    checkbox_label: str | None = Field(
        default=None, alias="checkboxLabel", description='Checkbox label for "don\'t show again" option'
    )
    show_checkbox: bool | None = Field(default=None, alias="showCheckbox", description="Whether to show the checkbox")
    icon: T | None = Field(default=None, description="Icon component to display in the featured icon")
    is_open: bool | None = Field(default=None, alias="isOpen", description="Controlled open state")
    on_open_change: Any | None = Field(
        default=None, alias="onOpenChange", description="Callback when open state changes"
    )
    on_confirm: Any | None = Field(
        default=None, alias="onConfirm", description="Callback when confirm button is clicked"
    )
    on_cancel: Any | None = Field(default=None, alias="onCancel", description="Callback when cancel button is clicked")
    on_checkbox_change: Any | None = Field(
        default=None, alias="onCheckboxChange", description="Callback when checkbox state changes"
    )
