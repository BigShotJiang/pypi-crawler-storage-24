"""
Pydantic schema for DynamicForm component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/form/dynamic/dynamic-form.tsx
Component Path: base/form/dynamic/dynamic-form
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class DynamicFormProps(JSONFieldSchema):
    """Props for DynamicForm component."""

    schema: Any = Field(description="Form schema configuration")
    on_submit: Any = Field(alias="onSubmit", description="Submit handler")
    on_cancel: Any | None = Field(default=None, alias="onCancel", description="Cancel handler")
    default_values: T | None = Field(default=None, alias="defaultValues", description="Default form values")
    is_loading: bool | None = Field(default=None, alias="isLoading", description="Loading state")
    is_disabled: bool | None = Field(default=None, alias="isDisabled", description="Disabled state")
    class_name: str | None = Field(default=None, alias="className", description="Additional className")
    children: str | dict[str, Any] | None | None = Field(
        default=None, description="Children rendered after fields (before buttons)"
    )


class FormContentProps(JSONFieldSchema):
    """Props for FormContent component."""

    schema: Any
    is_loading: bool | None = Field(default=None, alias="isLoading")
    is_disabled: bool | None = Field(default=None, alias="isDisabled")
    on_cancel: Any | None = Field(default=None, alias="onCancel")
    children: str | dict[str, Any] | None | None = Field(default=None)
