"""
Pydantic schema for DestructiveStackedLeftAlignedModal component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/modals/destructive-stacked-left-aligned-modal.tsx
Component Path: application/modals/destructive-stacked-left-aligned-modal
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class DestructiveStackedLeftAlignedModalProps(JSONFieldSchema):
    """Props for the DestructiveStackedLeftAlignedModal component.
    All string props support CMS-driven content with path template defaults."""

    title: str | None = Field(default=None, description="Modal title text")
    description: str | None = Field(default=None, description="Description text explaining the destructive action")
    confirm_label: str | None = Field(
        default=None, alias="confirmLabel", description="Primary destructive action button label"
    )
    cancel_label: str | None = Field(default=None, alias="cancelLabel", description="Secondary action button label")
    icon: T | None = Field(default=None, description="Icon component to display in the featured icon")
    is_open: bool | None = Field(default=None, alias="isOpen", description="Controlled open state")
    on_open_change: Any | None = Field(
        default=None, alias="onOpenChange", description="Callback when open state changes"
    )
    on_confirm: Any | None = Field(
        default=None, alias="onConfirm", description="Callback when confirm button is clicked"
    )
    on_cancel: Any | None = Field(default=None, alias="onCancel", description="Callback when cancel button is clicked")
