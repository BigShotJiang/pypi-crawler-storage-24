"""
Pydantic schema for Calendar component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/date-picker/calendar.tsx
Component Path: application/date-picker/calendar
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import DateValue


class CalendarProps(JSONFieldSchema):
    """Props for Calendar component."""

    highlighted_dates: list[DateValue] | None = Field(
        default=None, alias="highlightedDates", description="The dates to highlight."
    )
