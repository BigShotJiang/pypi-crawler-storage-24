"""
UI Component schemas with path-based registry.

Mirrors lightwave-ui/src/components/ structure:
- base/: Base components (buttons, inputs, forms)
- marketing/: Marketing page components (hero, features, testimonials)
- application/: Application components (tables, modals, navigation)
- compound/: Compound components (features, pricing, testimonials)
- foundations/: Foundation components (icons, logos)

Component Path Registry:
    Maps TanStack SSR component paths to Pydantic schemas:
    marketing/header-section/hero-screen-mockup-05 → HeroScreenMockup05Props

Usage:
    # Direct import
    from lightwave.schema.pydantic.ui.components import HeroScreenMockup05Props

    # Path-based lookup for TanStack SSR
    from lightwave.schema.pydantic.ui.components import get_component_schema
    schema = get_component_schema("marketing/header-section/hero-screen-mockup-05")
"""

from __future__ import annotations

import importlib
import json
import logging
from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pydantic import BaseModel

logger = logging.getLogger(__name__)

# =============================================================================
# Component Path Registry
# =============================================================================

# Registry of component paths to (module_path, class_name) tuples
_COMPONENT_REGISTRY: dict[str, tuple[str, str]] = {}


def _kebab_to_snake(s: str) -> str:
    """
    Convert kebab-case to snake_case (matching generator output).

    Numbers are treated as part of the previous word:
    - hero-screen-mockup-05 → hero_screen_mockup05
    """
    import re

    # First convert to snake_case
    result = s.replace("-", "_")
    # Remove underscores before numbers (matching generator behavior)
    result = re.sub(r"_(\d)", r"\1", result)
    return result


def _kebab_to_pascal(s: str) -> str:
    """Convert kebab-case to PascalCase."""
    return "".join(word.capitalize() for word in s.split("-"))


def register_component(component_path: str, module_path: str, class_name: str) -> None:
    """
    Register a component schema.

    Args:
        component_path: Path identifier (e.g., "marketing/header-section/hero-screen-mockup-05")
        module_path: Python module path
        class_name: Props class name (e.g., "HeroScreenMockup05Props")
    """
    _COMPONENT_REGISTRY[component_path] = (module_path, class_name)


@lru_cache(maxsize=256)
def get_component_schema(component_path: str) -> type[BaseModel] | None:
    """
    Get the Pydantic schema for a component path.

    Args:
        component_path: Path identifier (e.g., "marketing/header-section/hero-screen-mockup-05")

    Returns:
        The Props schema class, or None if not found.
    """
    # Check registry first
    if component_path in _COMPONENT_REGISTRY:
        module_path, class_name = _COMPONENT_REGISTRY[component_path]
        try:
            module = importlib.import_module(module_path)
            return getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            logger.warning("Failed to load schema %s.%s: %s", module_path, class_name, e)
            return None

    # Try dynamic lookup based on path convention
    parts = component_path.split("/")
    if len(parts) < 1:
        return None

    # Build module path and class name from component path
    # e.g., "marketing/header-section/hero-screen-mockup-05" -> hero_screen_mockup05.py, HeroScreenMockup05Props
    component = _kebab_to_snake(parts[-1])
    class_name = _kebab_to_pascal(parts[-1]) + "Props"

    # Try to import from flat structure (all components in same dir)
    module_patterns = [
        f"lightwave.schema.pydantic.ui.components.{component}",
    ]

    # Also try category-based lookup
    if len(parts) >= 2:
        category = _kebab_to_snake(parts[0])
        section = _kebab_to_snake(parts[1]) if len(parts) > 2 else None
        if section:
            module_patterns.insert(0, f"lightwave.schema.pydantic.ui.components.{category}.{section}.{component}")
        module_patterns.insert(1, f"lightwave.schema.pydantic.ui.components.{category}.{component}")

    for module_path in module_patterns:
        try:
            module = importlib.import_module(module_path)
            schema = getattr(module, class_name, None)
            if schema:
                _COMPONENT_REGISTRY[component_path] = (module_path, class_name)
                return schema
        except ImportError:
            continue

    logger.debug("No schema found for: %s", component_path)
    return None


def serialize_component_props(component_path: str, props: dict) -> str:
    """
    Validate and serialize component props to JSON with camelCase keys.

    Falls back to raw JSON if no schema found.
    """
    if not props:
        return "{}"

    schema = get_component_schema(component_path)
    if schema:
        try:
            validated = schema.model_validate(props)
            return validated.model_dump_json(by_alias=True, exclude_none=True)
        except Exception as e:
            logger.warning("Validation failed for %s: %s", component_path, e)

    return json.dumps(props)


# =============================================================================
# Generated Schema Imports (AUTO-GENERATED)
# =============================================================================

from .activity_feed import *  # noqa: F401, F403, E402
from .ai_assistant_modal import *  # noqa: F401, F403, E402
from .ai_input import *  # noqa: F401, F403, E402
from .alerts import *  # noqa: F401, F403, E402
from .angel_list import *  # noqa: F401, F403, E402
from .apple import *  # noqa: F401, F403, E402
from .avatar import *  # noqa: F401, F403, E402
from .avatar_label_group import *  # noqa: F401, F403, E402
from .avatar_profile_photo import *  # noqa: F401, F403, E402
from .badge_groups import *  # noqa: F401, F403, E402
from .badges import *  # noqa: F401, F403, E402
from .banner_dual_action_brand import *  # noqa: F401, F403, E402
from .banner_dual_action_brand_full_width import *  # noqa: F401, F403, E402
from .banner_dual_action_default import *  # noqa: F401, F403, E402
from .banner_dual_action_default_full_width import *  # noqa: F401, F403, E402
from .banner_single_action_brand import *  # noqa: F401, F403, E402
from .banner_single_action_brand_full_width import *  # noqa: F401, F403, E402
from .banner_single_action_default import *  # noqa: F401, F403, E402
from .banner_single_action_default_full_width import *  # noqa: F401, F403, E402
from .banner_slim_brand import *  # noqa: F401, F403, E402
from .banner_slim_brand_full_width import *  # noqa: F401, F403, E402
from .banner_slim_default import *  # noqa: F401, F403, E402
from .banner_slim_default_full_width import *  # noqa: F401, F403, E402
from .banner_text_field_brand import *  # noqa: F401, F403, E402
from .banner_text_field_brand_full_width import *  # noqa: F401, F403, E402
from .banner_text_field_default import *  # noqa: F401, F403, E402
from .banner_text_field_default_full_width import *  # noqa: F401, F403, E402
from .blog_header_featured_post01 import *  # noqa: F401, F403, E402
from .blog_section_carousel_layout01 import *  # noqa: F401, F403, E402
from .blog_section_carousel_layout02 import *  # noqa: F401, F403, E402
from .blog_section_simple_center_aligned01 import *  # noqa: F401, F403, E402
from .blog_section_simple_center_aligned02 import *  # noqa: F401, F403, E402
from .blog_section_simple_left_aligned01 import *  # noqa: F401, F403, E402
from .blog_section_simple_left_aligned02 import *  # noqa: F401, F403, E402
from .blog_section_split_layout01 import *  # noqa: F401, F403, E402
from .blog_section_split_layout02 import *  # noqa: F401, F403, E402
from .box import *  # noqa: F401, F403, E402
from .brand_logo import *  # noqa: F401, F403, E402
from .breadcrumb_item import *  # noqa: F401, F403, E402
from .breadcrumbs import *  # noqa: F401, F403, E402
from .button import *  # noqa: F401, F403, E402
from .button_group import *  # noqa: F401, F403, E402
from .button_utility import *  # noqa: F401, F403, E402
from .calendar import *  # noqa: F401, F403, E402
from .careers_card01 import *  # noqa: F401, F403, E402
from .carousel_base import *  # noqa: F401, F403, E402
from .cell import *  # noqa: F401, F403, E402
from .charts_base import *  # noqa: F401, F403, E402
from .checkbox import *  # noqa: F401, F403, E402
from .close_button import *  # noqa: F401, F403, E402
from .cloud import *  # noqa: F401, F403, E402
from .clubhouse import *  # noqa: F401, F403, E402
from .code_snippet import *  # noqa: F401, F403, E402
from .combobox import *  # noqa: F401, F403, E402
from .command_menu import *  # noqa: F401, F403, E402
from .contact_centered_map import *  # noqa: F401, F403, E402
from .contact_simple_links01 import *  # noqa: F401, F403, E402
from .content_divider import *  # noqa: F401, F403, E402
from .content_section_rich_text01 import *  # noqa: F401, F403, E402
from .content_section_simple01 import *  # noqa: F401, F403, E402
from .content_section_simple02 import *  # noqa: F401, F403, E402
from .content_section_simple03 import *  # noqa: F401, F403, E402
from .content_simple import *  # noqa: F401, F403, E402
from .credit_card import *  # noqa: F401, F403, E402
from .cropper import *  # noqa: F401, F403, E402
from .cta_abstract_images_brand import *  # noqa: F401, F403, E402
from .cta_iphone_mockup01 import *  # noqa: F401, F403, E402
from .cta_iphone_mockup04 import *  # noqa: F401, F403, E402
from .cta_simple_centered import *  # noqa: F401, F403, E402
from .cta_skeleton import *  # noqa: F401, F403, E402
from .cta_split_image01 import *  # noqa: F401, F403, E402
from .cta_split_image03 import *  # noqa: F401, F403, E402
from .cta_split_image04 import *  # noqa: F401, F403, E402
from .cta_split_image_quote01 import *  # noqa: F401, F403, E402
from .cta_split_image_quote02 import *  # noqa: F401, F403, E402
from .cta_split_image_quote03 import *  # noqa: F401, F403, E402
from .date_input import *  # noqa: F401, F403, E402
from .date_picker import *  # noqa: F401, F403, E402
from .date_picker_modal import *  # noqa: F401, F403, E402
from .date_range_picker import *  # noqa: F401, F403, E402
from .destructive_horizontal_modal import *  # noqa: F401, F403, E402
from .destructive_stacked_left_aligned_modal import *  # noqa: F401, F403, E402
from .discord import *  # noqa: F401, F403, E402
from .documents import *  # noqa: F401, F403, E402
from .dribbble import *  # noqa: F401, F403, E402
from .dropdown import *  # noqa: F401, F403, E402
from .dynamic_form import *  # noqa: F401, F403, E402
from .empty_state import *  # noqa: F401, F403, E402
from .facebook import *  # noqa: F401, F403, E402
from .faq_accordion01_brand import *  # noqa: F401, F403, E402
from .faq_accordion03 import *  # noqa: F401, F403, E402
from .faq_simple02_brand import *  # noqa: F401, F403, E402
from .featured_icon import *  # noqa: F401, F403, E402
from .features_alternating_layout01 import *  # noqa: F401, F403, E402
from .features_alternating_layout02 import *  # noqa: F401, F403, E402
from .features_alternating_layout03 import *  # noqa: F401, F403, E402
from .features_alternating_layout04 import *  # noqa: F401, F403, E402
from .features_center_mockup01 import *  # noqa: F401, F403, E402
from .features_center_mockup02 import *  # noqa: F401, F403, E402
from .features_icon_cards01 import *  # noqa: F401, F403, E402
from .features_icon_cards02 import *  # noqa: F401, F403, E402
from .features_icons_and_image01 import *  # noqa: F401, F403, E402
from .features_icons_and_image02 import *  # noqa: F401, F403, E402
from .features_icons_and_image03 import *  # noqa: F401, F403, E402
from .features_icons_and_image04 import *  # noqa: F401, F403, E402
from .features_icons_and_mockup01 import *  # noqa: F401, F403, E402
from .features_icons_and_mockup02 import *  # noqa: F401, F403, E402
from .features_icons_and_mockup03 import *  # noqa: F401, F403, E402
from .features_icons_and_mockup04 import *  # noqa: F401, F403, E402
from .features_icons_and_mockup05 import *  # noqa: F401, F403, E402
from .features_icons_and_mockup06 import *  # noqa: F401, F403, E402
from .features_integrations_icons01 import *  # noqa: F401, F403, E402
from .features_integrations_icons02 import *  # noqa: F401, F403, E402
from .features_integrations_icons03 import *  # noqa: F401, F403, E402
from .features_integrations_icons04 import *  # noqa: F401, F403, E402
from .features_large_screen_mockup01 import *  # noqa: F401, F403, E402
from .features_simple_icons01 import *  # noqa: F401, F403, E402
from .features_simple_icons01_brand import *  # noqa: F401, F403, E402
from .features_simple_icons02 import *  # noqa: F401, F403, E402
from .features_simple_icons02_brand import *  # noqa: F401, F403, E402
from .features_simple_icons03 import *  # noqa: F401, F403, E402
from .features_simple_icons04 import *  # noqa: F401, F403, E402
from .features_simple_icons04_brand import *  # noqa: F401, F403, E402
from .features_skeleton import *  # noqa: F401, F403, E402
from .features_tabs_mockup01 import *  # noqa: F401, F403, E402
from .features_tabs_mockup02 import *  # noqa: F401, F403, E402
from .field_renderer import *  # noqa: F401, F403, E402
from .figma import *  # noqa: F401, F403, E402
from .file_upload_base import *  # noqa: F401, F403, E402
from .file_upload_trigger import *  # noqa: F401, F403, E402
from .folder_icon import *  # noqa: F401, F403, E402
from .footer_large01 import *  # noqa: F401, F403, E402
from .footer_large01_brand import *  # noqa: F401, F403, E402
from .footer_large02 import *  # noqa: F401, F403, E402
from .footer_large03 import *  # noqa: F401, F403, E402
from .footer_large04 import *  # noqa: F401, F403, E402
from .footer_large05 import *  # noqa: F401, F403, E402
from .footer_large06 import *  # noqa: F401, F403, E402
from .footer_large06_brand import *  # noqa: F401, F403, E402
from .footer_large07 import *  # noqa: F401, F403, E402
from .footer_large08 import *  # noqa: F401, F403, E402
from .footer_large15 import *  # noqa: F401, F403, E402
from .footer_large15_brand import *  # noqa: F401, F403, E402
from .footer_small01 import *  # noqa: F401, F403, E402
from .footer_small02 import *  # noqa: F401, F403, E402
from .footer_small03 import *  # noqa: F401, F403, E402
from .footer_small04 import *  # noqa: F401, F403, E402
from .github import *  # noqa: F401, F403, E402
from .google import *  # noqa: F401, F403, E402
from .header import *  # noqa: F401, F403, E402
from .header_minimal import *  # noqa: F401, F403, E402
from .header_navigation import *  # noqa: F401, F403, E402
from .header_space_between_buttons import *  # noqa: F401, F403, E402
from .hero_abstract_angles01 import *  # noqa: F401, F403, E402
from .hero_abstract_angles02 import *  # noqa: F401, F403, E402
from .hero_abstract_angles03 import *  # noqa: F401, F403, E402
from .hero_abstract_angles04 import *  # noqa: F401, F403, E402
from .hero_card_mockup01 import *  # noqa: F401, F403, E402
from .hero_card_mockup02 import *  # noqa: F401, F403, E402
from .hero_card_mockup03 import *  # noqa: F401, F403, E402
from .hero_card_mockup04 import *  # noqa: F401, F403, E402
from .hero_card_mockup05 import *  # noqa: F401, F403, E402
from .hero_card_mockup06 import *  # noqa: F401, F403, E402
from .hero_card_mockup07 import *  # noqa: F401, F403, E402
from .hero_card_mockup08 import *  # noqa: F401, F403, E402
from .hero_color_card01 import *  # noqa: F401, F403, E402
from .hero_color_card02 import *  # noqa: F401, F403, E402
from .hero_color_card03 import *  # noqa: F401, F403, E402
from .hero_color_card04 import *  # noqa: F401, F403, E402
from .hero_geometric_shapes01 import *  # noqa: F401, F403, E402
from .hero_geometric_shapes03 import *  # noqa: F401, F403, E402
from .hero_geometric_shapes04 import *  # noqa: F401, F403, E402
from .hero_iphone_mockup01 import *  # noqa: F401, F403, E402
from .hero_iphone_mockup02 import *  # noqa: F401, F403, E402
from .hero_iphone_mockup03 import *  # noqa: F401, F403, E402
from .hero_iphone_mockup04 import *  # noqa: F401, F403, E402
from .hero_screen_mockup01 import *  # noqa: F401, F403, E402
from .hero_screen_mockup02 import *  # noqa: F401, F403, E402
from .hero_screen_mockup03 import *  # noqa: F401, F403, E402
from .hero_screen_mockup04 import *  # noqa: F401, F403, E402
from .hero_screen_mockup05 import *  # noqa: F401, F403, E402
from .hero_screen_mockup06 import *  # noqa: F401, F403, E402
from .hero_screen_mockup07 import *  # noqa: F401, F403, E402
from .hero_screen_mockup08 import *  # noqa: F401, F403, E402
from .hero_simple_text01 import *  # noqa: F401, F403, E402
from .hero_simple_text02 import *  # noqa: F401, F403, E402
from .hero_skeleton import *  # noqa: F401, F403, E402
from .hero_split_form01 import *  # noqa: F401, F403, E402
from .hero_split_form02 import *  # noqa: F401, F403, E402
from .hero_split_image01 import *  # noqa: F401, F403, E402
from .hero_split_image02 import *  # noqa: F401, F403, E402
from .hero_split_image03 import *  # noqa: F401, F403, E402
from .hero_split_image04 import *  # noqa: F401, F403, E402
from .hero_split_image05 import *  # noqa: F401, F403, E402
from .hero_split_image06 import *  # noqa: F401, F403, E402
from .hint_text import *  # noqa: F401, F403, E402
from .hook_form import *  # noqa: F401, F403, E402
from .horizontal_modal import *  # noqa: F401, F403, E402
from .icon import *  # noqa: F401, F403, E402
from .inbox import *  # noqa: F401, F403, E402
from .input import *  # noqa: F401, F403, E402
from .input_group import *  # noqa: F401, F403, E402
from .input_payment import *  # noqa: F401, F403, E402
from .instagram import *  # noqa: F401, F403, E402
from .iphone_mockup import *  # noqa: F401, F403, E402
from .label import *  # noqa: F401, F403, E402
from .layers import *  # noqa: F401, F403, E402
from .linkedin import *  # noqa: F401, F403, E402
from .loading_indicator import *  # noqa: F401, F403, E402
from .login_card_combined import *  # noqa: F401, F403, E402
from .login_modal import *  # noqa: F401, F403, E402
from .messaging import *  # noqa: F401, F403, E402
from .metrics import *  # noqa: F401, F403, E402
from .metrics_image_with_cards01 import *  # noqa: F401, F403, E402
from .metrics_image_with_cards02 import *  # noqa: F401, F403, E402
from .metrics_simple_accent_line import *  # noqa: F401, F403, E402
from .metrics_simple_centered_text import *  # noqa: F401, F403, E402
from .metrics_simple_with_actions01 import *  # noqa: F401, F403, E402
from .metrics_simple_with_actions02 import *  # noqa: F401, F403, E402
from .multi_select import *  # noqa: F401, F403, E402
from .newsletter_card_horizontal import *  # noqa: F401, F403, E402
from .newsletter_simple_left import *  # noqa: F401, F403, E402
from .not_found_illustration01 import *  # noqa: F401, F403, E402
from .not_found_simple01 import *  # noqa: F401, F403, E402
from .notifications import *  # noqa: F401, F403, E402
from .pagination import *  # noqa: F401, F403, E402
from .pagination_base import *  # noqa: F401, F403, E402
from .pagination_dot import *  # noqa: F401, F403, E402
from .pagination_line import *  # noqa: F401, F403, E402
from .password_prompt_modal import *  # noqa: F401, F403, E402
from .pin_input import *  # noqa: F401, F403, E402
from .pinterest import *  # noqa: F401, F403, E402
from .popover import *  # noqa: F401, F403, E402
from .pricing_section_simple_cards01 import *  # noqa: F401, F403, E402
from .pricing_skeleton import *  # noqa: F401, F403, E402
from .progress_circles import *  # noqa: F401, F403, E402
from .progress_indicators import *  # noqa: F401, F403, E402
from .progress_steps import *  # noqa: F401, F403, E402
from .qr_code import *  # noqa: F401, F403, E402
from .radio_buttons import *  # noqa: F401, F403, E402
from .radio_group_avatar import *  # noqa: F401, F403, E402
from .radio_group_checkbox import *  # noqa: F401, F403, E402
from .radio_group_icon_card import *  # noqa: F401, F403, E402
from .radio_group_icon_simple import *  # noqa: F401, F403, E402
from .radio_group_payment_icon import *  # noqa: F401, F403, E402
from .radio_group_radio_button import *  # noqa: F401, F403, E402
from .range_calendar import *  # noqa: F401, F403, E402
from .range_preset import *  # noqa: F401, F403, E402
from .rating_badge import *  # noqa: F401, F403, E402
from .rating_stars import *  # noqa: F401, F403, E402
from .reddit import *  # noqa: F401, F403, E402
from .round_button import *  # noqa: F401, F403, E402
from .section_label import *  # noqa: F401, F403, E402
from .select import *  # noqa: F401, F403, E402
from .select_item import *  # noqa: F401, F403, E402
from .select_native import *  # noqa: F401, F403, E402
from .sidebar_dual_tier import *  # noqa: F401, F403, E402
from .sidebar_section_dividers import *  # noqa: F401, F403, E402
from .sidebar_sections_subheadings import *  # noqa: F401, F403, E402
from .sidebar_simple import *  # noqa: F401, F403, E402
from .sidebar_slim import *  # noqa: F401, F403, E402
from .signal import *  # noqa: F401, F403, E402
from .signup01_modal import *  # noqa: F401, F403, E402
from .signup02_modal import *  # noqa: F401, F403, E402
from .signup_card_combined import *  # noqa: F401, F403, E402
from .skeleton_base import *  # noqa: F401, F403, E402
from .slideout_menu import *  # noqa: F401, F403, E402
from .slider import *  # noqa: F401, F403, E402
from .snapchat import *  # noqa: F401, F403, E402
from .social_button import *  # noqa: F401, F403, E402
from .social_proof_card_brand import *  # noqa: F401, F403, E402
from .social_proof_full_width import *  # noqa: F401, F403, E402
from .social_proof_press_mentions import *  # noqa: F401, F403, E402
from .stacked_left_aligned_modal import *  # noqa: F401, F403, E402
from .star_icon import *  # noqa: F401, F403, E402
from .step1_check_email import *  # noqa: F401, F403, E402
from .step1_forgot_password import *  # noqa: F401, F403, E402
from .step2_check_email import *  # noqa: F401, F403, E402
from .step2_enter_code_manually import *  # noqa: F401, F403, E402
from .step3_set_new_password import *  # noqa: F401, F403, E402
from .step3_success import *  # noqa: F401, F403, E402
from .step4_success import *  # noqa: F401, F403, E402
from .table import *  # noqa: F401, F403, E402
from .tabs import *  # noqa: F401, F403, E402
from .tags import *  # noqa: F401, F403, E402
from .team_section_image_card01 import *  # noqa: F401, F403, E402
from .team_section_image_collage01 import *  # noqa: F401, F403, E402
from .team_section_image_glass03 import *  # noqa: F401, F403, E402
from .telegram import *  # noqa: F401, F403, E402
from .testimonial_abstract_image import *  # noqa: F401, F403, E402
from .testimonial_card import *  # noqa: F401, F403, E402
from .testimonial_glassmorphic_cards01 import *  # noqa: F401, F403, E402
from .testimonial_simple_left_aligned import *  # noqa: F401, F403, E402
from .testimonial_social_cards01 import *  # noqa: F401, F403, E402
from .testimonial_social_cards02 import *  # noqa: F401, F403, E402
from .testimonials_skeleton import *  # noqa: F401, F403, E402
from .text_editor import *  # noqa: F401, F403, E402
from .text_editor_button import *  # noqa: F401, F403, E402
from .text_editor_toolbar import *  # noqa: F401, F403, E402
from .text_editor_tooltip import *  # noqa: F401, F403, E402
from .textarea import *  # noqa: F401, F403, E402
from .theme_provider import *  # noqa: F401, F403, E402
from .theme_toggle import *  # noqa: F401, F403, E402
from .tiktok import *  # noqa: F401, F403, E402
from .toggle import *  # noqa: F401, F403, E402
from .tooltip import *  # noqa: F401, F403, E402
from .tumblr import *  # noqa: F401, F403, E402
from .twitter import *  # noqa: F401, F403, E402
from .twofa_code_modal import *  # noqa: F401, F403, E402
from .user_avatar_dropdown import *  # noqa: F401, F403, E402
from .verification_code_modal import *  # noqa: F401, F403, E402
from .video_player import *  # noqa: F401, F403, E402
from .warning_horizontal_modal import *  # noqa: F401, F403, E402
from .warning_stacked_left_aligned_modal import *  # noqa: F401, F403, E402
from .x import *  # noqa: F401, F403, E402
from .youtube import *  # noqa: F401, F403, E402

__all__ = [
    # Registry functions
    "get_component_schema",
    "register_component",
    "serialize_component_props",
]
