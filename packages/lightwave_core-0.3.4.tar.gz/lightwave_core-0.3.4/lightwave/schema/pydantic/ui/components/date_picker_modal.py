"""
Pydantic schema for DatePickerModal component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/modals/date-picker-modal.tsx
Component Path: application/modals/date-picker-modal
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class DatePickerModalProps(JSONFieldSchema):
    """Props for DatePickerModal component."""

    on_apply: Any | None = Field(default=None, alias="onApply")
    on_cancel: Any | None = Field(default=None, alias="onCancel")
