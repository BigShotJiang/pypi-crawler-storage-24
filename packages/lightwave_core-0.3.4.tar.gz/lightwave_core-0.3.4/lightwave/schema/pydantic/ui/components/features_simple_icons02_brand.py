"""
Pydantic schema for FeaturesSimpleIcons02Brand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-simple-icons-02-brand.tsx
Component Path: marketing/features/features-simple-icons-02-brand
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItemWithIcon


class FeaturesSimpleIcons02BrandProps(JSONFieldSchema):
    """Props for FeaturesSimpleIcons02Brand"""

    features: list[FeatureItemWithIcon] | None = Field(default=None)
