"""
Pydantic schema for FaqAccordion01Brand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/faq/faq-accordion-01-brand.tsx
Component Path: marketing/faq/faq-accordion-01-brand
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import SupportAvatar


class FAQAccordion01BrandProps(JSONFieldSchema):
    """Props for FAQAccordion01Brand component."""

    cta_heading: str | None = Field(default=None, alias="ctaHeading", description="CTA section heading")
    cta_description: str | None = Field(default=None, alias="ctaDescription", description="CTA section description")
    cta_button_label: str | None = Field(default=None, alias="ctaButtonLabel", description="CTA button label")
    cta_button_href: str | None = Field(default=None, alias="ctaButtonHref", description="CTA button href")
    support_avatars: list[SupportAvatar] | None = Field(
        default=None, alias="supportAvatars", description="Support avatars for CTA section"
    )
    hide_cta: bool | None = Field(default=None, alias="hideCta", description="Hide the CTA section")
