"""
Pydantic schema for ContentSimple component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/content/content-simple.tsx
Component Path: marketing/content/content-simple
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class ContentSimpleProps(JSONFieldSchema):
    """Props for ContentSimple component."""

    date_label: str | None = Field(default=None, alias="dateLabel", description="Date label")
    headline: str | None = Field(default=None, description="Main heading")
    description: str | None = Field(default=None, description="Description text")
    tabs: list[T] | None = Field(default=None, description="Tab options")
    body_content: str | None = Field(default=None, alias="bodyContent", description="Body content (HTML)")
