"""
Pydantic schema for BlogSectionSimpleCenterAligned01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/blog/blog-section-simple-center-aligned-01.tsx
Component Path: marketing/blog/blog-section-simple-center-aligned-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import Article, SortOption, T


class BlogSectionSimpleCenterAligned01Props(JSONFieldSchema):
    """Props for BlogSectionSimpleCenterAligned01 component."""

    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    posts: list[Article] | None = Field(default=None)
    show_filters: bool | None = Field(default=None, alias="showFilters", description="Show category filter tabs")
    show_sort: bool | None = Field(default=None, alias="showSort", description="Show sort dropdown")
    categories: list[T] | None = Field(default=None, description="Category tabs for filtering")
    sort_options: list[SortOption] | None = Field(default=None, alias="sortOptions", description="Sort options")
    max_articles: int | float | None = Field(
        default=None, alias="maxArticles", description="Max articles to display (0 = all)"
    )
