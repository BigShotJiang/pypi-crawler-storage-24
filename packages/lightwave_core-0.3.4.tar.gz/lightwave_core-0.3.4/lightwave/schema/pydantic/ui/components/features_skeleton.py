"""
Pydantic schema for FeaturesSkeleton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: skeletons/FeaturesSkeleton.tsx
Component Path: skeletons/FeaturesSkeleton
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeaturesSkeletonProps(JSONFieldSchema):
    """Props for FeaturesSkeleton component."""

    variant: Any | None = Field(default=None, description="Features variant layout")
    features: Literal[3, 4, 6] | None = Field(default=None, description="Number of features to show")
    class_name: str | None = Field(default=None, alias="className", description="Additional className")


class FeatureItemSkeletonProps(JSONFieldSchema):
    """Props for FeatureItemSkeleton component."""

    align: Literal["center", "left"] | None = Field(default=None, description="Alignment of the feature item")
    with_icon: bool | None = Field(default=None, alias="withIcon", description="Show icon")
    class_name: str | None = Field(default=None, alias="className")
