"""
Pydantic schema for BannerTextFieldBrandFullWidth component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/banners/banner-text-field-brand-full-width.tsx
Component Path: marketing/banners/banner-text-field-brand-full-width
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BannerTextFieldBrandFullWidthProps(JSONFieldSchema):
    """Props for BannerTextFieldBrandFullWidth component."""

    headline: str | None = Field(default=None, description="Main headline text")
    headline_extended: str | None = Field(
        default=None, alias="headlineExtended", description="Extended headline for desktop"
    )
    input_placeholder: str | None = Field(default=None, alias="inputPlaceholder", description="Input placeholder")
    submit_text: str | None = Field(default=None, alias="submitText", description="Submit button text")
    on_submit: Any | None = Field(default=None, alias="onSubmit", description="On form submit callback")
    on_dismiss: Any | None = Field(default=None, alias="onDismiss", description="On dismiss callback")
