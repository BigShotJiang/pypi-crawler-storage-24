"""
Pydantic schema for FeaturesSimpleIcons01Brand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-simple-icons-01-brand.tsx
Component Path: marketing/features/features-simple-icons-01-brand
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesSimpleIcons01BrandProps(JSONFieldSchema):
    """Props for FeaturesSimpleIcons01Brand"""

    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
