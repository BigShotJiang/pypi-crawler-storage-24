"""
Pydantic schema for Alerts component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/alerts/alerts.tsx
Component Path: application/alerts/alerts
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AlertFloatingProps(JSONFieldSchema):
    """Props for AlertFloating component."""

    title: str = Field(description="The title of the alert.")
    description: str | dict[str, Any] | None = Field(description="The description of the alert.")
    confirm_label: str = Field(alias="confirmLabel", description="The label for the confirm button.")
    dismiss_label: str | None = Field(
        default="Dismiss", alias="dismissLabel", description="The label for the dismiss button."
    )
    color: Literal["brand", "default", "error", "gray", "success", "warning"] | None = Field(
        default="default", description="The color of the alert."
    )
    on_close: Any | None = Field(
        default=None, alias="onClose", description="The function to call when the dismiss button is clicked."
    )
    on_confirm: Any | None = Field(
        default=None, alias="onConfirm", description="The function to call when the confirm button is clicked."
    )


class AlertFullWidthProps(JSONFieldSchema):
    """Props for AlertFullWidth component."""

    title: str = Field(description="The title of the alert.")
    description: str | dict[str, Any] | None = Field(description="The description of the alert.")
    confirm_label: str = Field(alias="confirmLabel", description="The label for the confirm button.")
    dismiss_label: str | None = Field(
        default="Dismiss", alias="dismissLabel", description="The label for the dismiss button."
    )
    action_type: Literal["button", "link"] | None = Field(
        default="button", alias="actionType", description="The type of the action buttons."
    )
    color: Literal["brand", "default", "error", "gray", "success", "warning"] | None = Field(
        default="default", description="The color of the alert."
    )
    on_close: Any | None = Field(
        default=None, alias="onClose", description="The function to call when the dismiss button is clicked."
    )
    on_confirm: Any | None = Field(
        default=None, alias="onConfirm", description="The function to call when the confirm button is clicked."
    )
