"""
Pydantic schema for Combobox component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/select/combobox.tsx
Component Path: base/select/combobox
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import SelectItemType, T


class ComboBoxProps(JSONFieldSchema):
    """Props for ComboBox component."""

    shortcut: bool | None = Field(default=None)
    items: list[SelectItemType] | None = Field(default=None)
    popover_class_name: str | None = Field(default=None, alias="popoverClassName")
    shortcut_class_name: str | None = Field(default=None, alias="shortcutClassName")
    children: Literal[
        "/Users/joelschaeffer/dev/lightwave-media/packages/lightwave-ui/node_modules/.pnpm/@types+react@19.2.8/node_modules/@types/react/index",
        "/Users/joelschaeffer/dev/lightwave-media/packages/lightwave-ui/node_modules/.pnpm/@types+react@19.2.8/node_modules/@types/react/index",
    ]


class ComboBoxValueProps(JSONFieldSchema):
    """Props for ComboBoxValue component."""

    size: Literal["md", "sm"]
    shortcut: bool
    placeholder: str | None = Field(default=None)
    shortcut_class_name: str | None = Field(default=None, alias="shortcutClassName")
    on_focus: Any | None = Field(default=None, alias="onFocus")
    on_pointer_enter: Any | None = Field(default=None, alias="onPointerEnter")
    ref: T | None = Field(default=None)
