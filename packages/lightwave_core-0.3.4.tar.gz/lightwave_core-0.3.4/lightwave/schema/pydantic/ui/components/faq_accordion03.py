"""
Pydantic schema for FaqAccordion03 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/faq/faq-accordion-03.tsx
Component Path: marketing/faq/faq-accordion-03
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FAQAccordion03Props(JSONFieldSchema):
    """Props for FAQAccordion03 component."""

    contact_link_text: str | None = Field(default=None, alias="contactLinkText", description="Contact link text")
    contact_link_href: str | None = Field(default=None, alias="contactLinkHref", description="Contact link href")
