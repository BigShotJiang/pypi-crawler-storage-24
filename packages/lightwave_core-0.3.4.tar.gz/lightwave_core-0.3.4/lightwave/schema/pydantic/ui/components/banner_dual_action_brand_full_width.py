"""
Pydantic schema for BannerDualActionBrandFullWidth component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/banners/banner-dual-action-brand-full-width.tsx
Component Path: marketing/banners/banner-dual-action-brand-full-width
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BannerDualActionBrandFullWidthProps(JSONFieldSchema):
    """Props for BannerDualActionBrandFullWidth component."""

    headline: str | None = Field(default=None, description="Main headline text")
    link_text: str | None = Field(default=None, alias="linkText", description="Link text")
    link_href: str | None = Field(default=None, alias="linkHref", description="Link URL")
    on_dismiss: Any | None = Field(default=None, alias="onDismiss", description="On dismiss callback")
