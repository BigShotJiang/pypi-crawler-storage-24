"""
Pydantic schema for FeaturesAlternatingLayout01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-alternating-layout-01.tsx
Component Path: marketing/features/features-alternating-layout-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureSection


class FeaturesAlternatingLayout01Props(JSONFieldSchema):
    """Props for FeaturesAlternatingLayout01"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    sections: list[FeatureSection] | None = Field(default=None, description="Feature sections (alternating left/right)")
