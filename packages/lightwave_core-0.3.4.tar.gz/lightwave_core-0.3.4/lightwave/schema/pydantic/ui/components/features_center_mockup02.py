"""
Pydantic schema for FeaturesCenterMockup02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-center-mockup-02.tsx
Component Path: marketing/features/features-center-mockup-02
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesCenterMockup02Props(JSONFieldSchema):
    """Props for FeaturesCenterMockup02"""

    badge_label: str | None = Field(default=None, alias="badgeLabel", description="Badge text")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
    mockups: Any | None = Field(default=None, description="Mockup images")
