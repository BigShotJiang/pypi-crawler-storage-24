"""
Pydantic schema for AiInput component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: inputs/ai-input.tsx
Component Path: inputs/ai-input
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AiInputProps(JSONFieldSchema):
    """Props for AiInput component."""

    context: str | None = Field(
        default=None, description="Context about what the user is doing (helps AI provide better suggestions)"
    )
    field_type: str | None = Field(
        default=None,
        alias="fieldType",
        description='Type of field being completed (e.g., "email_subject", "project_name")',
    )
    placeholder: str | None = Field(default=None, description="Placeholder text for the input")
    value: str | None = Field(default=None, description="Controlled value (for React Hook Form integration)")
    on_change: Any | None = Field(default=None, alias="onChange", description="Callback when value changes")
    on_blur: Any | None = Field(default=None, alias="onBlur", description="Callback when input loses focus")
    debounce_ms: int | float | None = Field(
        default=None, alias="debounceMs", description="Debounce delay in ms before fetching suggestions (default: 300)"
    )
    min_chars: int | float | None = Field(
        default=None, alias="minChars", description="Minimum characters before fetching suggestions (default: 3)"
    )
    max_suggestions: int | float | None = Field(
        default=None, alias="maxSuggestions", description="Maximum number of suggestions to show (default: 5, max: 10)"
    )
    class_name: str | None = Field(default=None, alias="className", description="Additional CSS classes for the input")
    id: str | None = Field(default=None, description="Input ID (for labels)")
    name: str | None = Field(default=None, description="Input name (for forms)")
    disabled: bool | None = Field(default=None, description="Whether the input is disabled")
    suggestions_endpoint: str | None = Field(
        default=None,
        alias="suggestionsEndpoint",
        description="API endpoint for suggestions (default: /api/ai/suggestions/)",
    )
