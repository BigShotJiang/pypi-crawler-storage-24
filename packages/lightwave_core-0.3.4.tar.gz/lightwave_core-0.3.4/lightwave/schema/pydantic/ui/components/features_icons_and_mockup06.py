"""
Pydantic schema for FeaturesIconsAndMockup06 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icons-and-mockup-06.tsx
Component Path: marketing/features/features-icons-and-mockup-06
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import CreditCardConfig, FeatureItem


class FeaturesIconsAndMockup06Props(JSONFieldSchema):
    """Props for FeaturesIconsAndMockup06"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
    credit_cards: list[CreditCardConfig] | None = Field(
        default=None, alias="creditCards", description="Credit cards to display"
    )
