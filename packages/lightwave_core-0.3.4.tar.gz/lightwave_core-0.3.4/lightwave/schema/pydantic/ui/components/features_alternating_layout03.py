"""
Pydantic schema for FeaturesAlternatingLayout03 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-alternating-layout-03.tsx
Component Path: marketing/features/features-alternating-layout-03
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureSection03


class FeaturesAlternatingLayout03Props(JSONFieldSchema):
    """Props for FeaturesAlternatingLayout03"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    sections: list[FeatureSection03] | None = Field(default=None, description="Feature sections")
