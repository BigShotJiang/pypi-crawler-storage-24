"""
Pydantic schema for FeaturesLargeScreenMockup01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-large-screen-mockup-01.tsx
Component Path: marketing/features/features-large-screen-mockup-01
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeaturesLargeScreenMockup01Props(JSONFieldSchema):
    """Props for FeaturesLargeScreenMockup01"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    mockup: Any | None = Field(default=None, description="Mockup image with light/dark variants")
