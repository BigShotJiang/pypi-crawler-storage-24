"""
Pydantic schema for ContactSimpleLinks01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/contact/contact-simple-links-01.tsx
Component Path: marketing/contact/contact-simple-links-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import ContactMethod


class ContactSimpleLinks01Props(JSONFieldSchema):
    """Props for ContactSimpleLinks01 component."""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main heading")
    description: str | None = Field(default=None, description="Description text")
    methods: list[ContactMethod] | None = Field(default=None, description="Array of contact methods")
