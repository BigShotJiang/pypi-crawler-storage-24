"""
Pydantic schema for FeaturesSimpleIcons01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-simple-icons-01.tsx
Component Path: marketing/features/features-simple-icons-01
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FeaturesSimpleIcons01Props(JSONFieldSchema):
    """Props for FeaturesSimpleIcons01 component."""

    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    features: list[dict[str, Any]] | None = Field(default=None)
