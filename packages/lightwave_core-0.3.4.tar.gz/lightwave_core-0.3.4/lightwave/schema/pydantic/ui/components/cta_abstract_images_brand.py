"""
Pydantic schema for CtaAbstractImagesBrand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-abstract-images-brand.tsx
Component Path: marketing/cta/cta-abstract-images-brand
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CTAAbstractImagesBrandProps(JSONFieldSchema):
    """Props for CTAAbstractImagesBrand component."""

    headline: str | None = Field(default=None, description="Main heading text")
    description: str | None = Field(default=None, description="Subheading/description text")
    primary_label: str | None = Field(default=None, alias="primaryLabel", description="Primary button label")
    primary_href: str | None = Field(default=None, alias="primaryHref", description="Primary button URL/href")
    secondary_label: str | None = Field(default=None, alias="secondaryLabel", description="Secondary button label")
    secondary_href: str | None = Field(default=None, alias="secondaryHref", description="Secondary button URL/href")
    show_images: bool | None = Field(
        default=None, alias="showImages", description="Whether to show the decorative image grid (default: true)"
    )
