"""
Pydantic schema for FaqSimple02Brand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/faq/faq-simple-02-brand.tsx
Component Path: marketing/faq/faq-simple-02-brand
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FAQItemWithIcon


class FAQSimple02BrandProps(JSONFieldSchema):
    """Props for FAQSimple02Brand"""

    items: list[FAQItemWithIcon] | None = Field(default=None)
