"""
Pydantic schema for ContentSectionSimple03 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/content/content-section-simple-03.tsx
Component Path: marketing/content/content-section-simple-03
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ContentSectionSimple03Props(JSONFieldSchema):
    """Props for ContentSectionSimple03 component."""

    eyebrow: str | None = Field(default=None, description="Small text above heading")
    headline: str | None = Field(default=None, description="Main heading")
    description: str | None = Field(default=None, description="Description text")
    left_content: str | None = Field(default=None, alias="leftContent", description="Left column body content (HTML)")
    right_content: str | None = Field(
        default=None, alias="rightContent", description="Right column body content (HTML)"
    )
