"""
Pydantic schema for FeaturesIntegrationsIcons03 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-integrations-icons-03.tsx
Component Path: marketing/features/features-integrations-icons-03
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import IntegrationItem


class FeaturesIntegrationsIcons03Props(JSONFieldSchema):
    """Props for FeaturesIntegrationsIcons03"""

    badge_label: str | None = Field(default=None, alias="badgeLabel", description="Badge text")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    integrations: list[IntegrationItem] | None = Field(default=None, description="Integration items")
