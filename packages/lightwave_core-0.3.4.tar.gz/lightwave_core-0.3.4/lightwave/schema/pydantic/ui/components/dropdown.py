"""
Pydantic schema for Dropdown component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/dropdown/dropdown.tsx
Component Path: base/dropdown/dropdown
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class DropdownItemProps(JSONFieldSchema):
    """Props for DropdownItem component."""

    label: str | None = Field(default=None, description="The label of the item to be displayed.")
    addon: str | None = Field(default=None, description="An addon to be displayed on the right side of the item.")
    unstyled: bool | None = Field(default=None, description="If true, the item will not have any styles.")
    icon: str | None = Field(default=None, description="An icon to be displayed on the left side of the item.")


class DropdownMenuProps(JSONFieldSchema):
    """Props for DropdownMenu component."""

    pass


class DropdownPopoverProps(JSONFieldSchema):
    """Props for DropdownPopover component."""

    pass
