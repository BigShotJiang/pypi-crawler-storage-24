"""
Pydantic schema for FeaturesIntegrationsIcons04 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-integrations-icons-04.tsx
Component Path: marketing/features/features-integrations-icons-04
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import IntegrationItem


class FeaturesIntegrationsIcons04Props(JSONFieldSchema):
    """Props for FeaturesIntegrationsIcons04"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    integrations: list[IntegrationItem] | None = Field(default=None, description="Integration items")
