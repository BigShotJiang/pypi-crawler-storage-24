"""
Pydantic schema for ContentSectionSimple01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/content/content-section-simple-01.tsx
Component Path: marketing/content/content-section-simple-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ContentSectionSimple01Props(JSONFieldSchema):
    """Props for ContentSectionSimple01 component."""

    headline: str | None = Field(default=None, description="Main heading")
    description: str | None = Field(default=None, description="Description text")
    body_content: str | None = Field(default=None, alias="bodyContent", description="Body content (HTML string)")
    icon: str | None = Field(default=None, description="Icon name")
