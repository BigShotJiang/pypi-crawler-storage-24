"""
Pydantic schema for FeaturesIconCards01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-icon-cards-01.tsx
Component Path: marketing/features/features-icon-cards-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesIconCards01Props(JSONFieldSchema):
    """Props for FeaturesIconCards01"""

    label: str | None = Field(default=None)
    headline: str | None = Field(default=None)
    description: str | None = Field(default=None)
    features: list[FeatureItem] | None = Field(default=None)
