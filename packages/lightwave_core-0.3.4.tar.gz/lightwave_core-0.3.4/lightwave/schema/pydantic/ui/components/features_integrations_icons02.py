"""
Pydantic schema for FeaturesIntegrationsIcons02 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-integrations-icons-02.tsx
Component Path: marketing/features/features-integrations-icons-02
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import IntegrationIcon, T


class FeaturesIntegrationsIcons02Props(JSONFieldSchema):
    """Props for FeaturesIntegrationsIcons02"""

    eyebrow: str | None = Field(default=None, description="Small text above heading")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    cta: T | None = Field(default=None, description="CTA button")
    integrations: list[IntegrationIcon] | None = Field(default=None, description="Integration icons")
