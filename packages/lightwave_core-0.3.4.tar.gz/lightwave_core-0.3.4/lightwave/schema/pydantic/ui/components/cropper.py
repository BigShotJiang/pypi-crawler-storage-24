"""
Pydantic schema for Cropper component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: shared-assets/image-cropper/cropper.tsx
Component Path: shared-assets/image-cropper/cropper
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ImgProps(JSONFieldSchema):
    """Props for Img component."""

    pass
