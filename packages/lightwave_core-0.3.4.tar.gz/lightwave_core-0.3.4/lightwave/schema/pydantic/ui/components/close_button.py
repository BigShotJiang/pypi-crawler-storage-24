"""
Pydantic schema for CloseButton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/buttons/close-button.tsx
Component Path: base/buttons/close-button
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CloseButtonProps(JSONFieldSchema):
    """Props for CloseButton component."""

    theme: Literal["dark", "light"] | None = Field(default=None)
    size: Literal["lg", "md", "sm", "xs"] | None = Field(default=None)
    label: str | None = Field(default=None)
