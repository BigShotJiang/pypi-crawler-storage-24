"""
Pydantic schema for FeaturesAlternatingLayout04 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-alternating-layout-04.tsx
Component Path: marketing/features/features-alternating-layout-04
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureSection04


class FeaturesAlternatingLayout04Props(JSONFieldSchema):
    """Props for FeaturesAlternatingLayout04"""

    eyebrow: str | None = Field(default=None, description="Small label above heading")
    headline: str | None = Field(default=None, description="Main section headline")
    description: str | None = Field(default=None, description="Section description")
    sections: list[FeatureSection04] | None = Field(default=None, description="Feature sections")
