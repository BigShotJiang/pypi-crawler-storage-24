"""
Pydantic schema for BannerDualActionBrand component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/banners/banner-dual-action-brand.tsx
Component Path: marketing/banners/banner-dual-action-brand
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class BannerDualActionBrandProps(JSONFieldSchema):
    """Props for BannerDualActionBrand component."""

    headline: str | None = Field(default=None, description="Main headline text")
    link_text: str | None = Field(default=None, alias="linkText", description="Link text")
    link_href: str | None = Field(default=None, alias="linkHref", description="Link URL")
    on_dismiss: Any | None = Field(default=None, alias="onDismiss", description="On dismiss callback")
