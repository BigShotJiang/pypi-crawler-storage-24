"""
Pydantic schema for CtaSplitImageQuote01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/cta/cta-split-image-quote-01.tsx
Component Path: marketing/cta/cta-split-image-quote-01
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import ReviewItem


class CTASplitImageQuote01Props(JSONFieldSchema):
    """Props for CTASplitImageQuote01 component."""

    headline: str | None = Field(default=None)
    features: list[str] | None = Field(default=None)
    primary_cta_text: str | None = Field(default=None, alias="primaryCtaText")
    primary_cta_href: str | None = Field(default=None, alias="primaryCtaHref")
    secondary_cta_text: str | None = Field(default=None, alias="secondaryCtaText")
    secondary_cta_href: str | None = Field(default=None, alias="secondaryCtaHref")
    reviews: list[ReviewItem] | None = Field(default=None)
