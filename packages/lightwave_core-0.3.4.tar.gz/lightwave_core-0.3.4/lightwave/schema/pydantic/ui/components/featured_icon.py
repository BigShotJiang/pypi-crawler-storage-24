"""
Pydantic schema for FeaturedIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/featured-icon/featured-icon.tsx
Component Path: foundations/featured-icon/featured-icon
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class FeaturedIconProps(JSONFieldSchema):
    """Props for FeaturedIcon component."""

    ref: T | None = Field(default=None)
    children: str | dict[str, Any] | None | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    icon: str | dict[str, Any] | None | None = Field(default=None)
    size: Literal["lg", "md", "sm", "xl"] | None = Field(default=None)
    color: Literal["brand", "error", "gray", "success", "warning"]
    theme: Literal["dark", "gradient", "light", "modern", "modern-neue", "outline"] | None = Field(default=None)
