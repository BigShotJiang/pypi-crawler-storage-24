"""
Pydantic schema for FeaturesCenterMockup01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/features/features-center-mockup-01.tsx
Component Path: marketing/features/features-center-mockup-01
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import FeatureItem


class FeaturesCenterMockup01Props(JSONFieldSchema):
    """Props for FeaturesCenterMockup01"""

    badge_label: str | None = Field(default=None, alias="badgeLabel", description="Badge text")
    headline: str | None = Field(default=None, description="Section headline")
    description: str | None = Field(default=None, description="Section description")
    mockup: Any | None = Field(default=None, description="Mockup images")
    features: list[FeatureItem] | None = Field(default=None, description="Feature items")
