"""
Pydantic schema for BlogHeaderFeaturedPost01 component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: marketing/blog/blog-header-featured-post-01.tsx
Component Path: marketing/blog/blog-header-featured-post-01
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import Article


class BlogHeaderFeaturedPost01Props(JSONFieldSchema):
    """Props for BlogHeaderFeaturedPost01
    When values are unresolved pointers (e.g., "component.blog-hero.headline"),
    they're displayed as-is for debugging."""

    label: str | None = Field(default=None, description='Small label above the headline (default: "Our blog")')
    headline: str | None = Field(default=None, description='Main headline (default: "Resources and insights")')
    description: str | None = Field(default=None, description="Description text below headline")
    featured_post: Any | None = Field(
        default=None, alias="featuredPost", description="Featured article to display prominently"
    )
    posts: list[Article] | None = Field(default=None, description="Blog posts to display in the grid")
    categories: list[dict[str, Any]] | None = Field(default=None, description="Category tabs for filtering")
    header_props: Any | None = Field(
        default=None, alias="headerProps", description="Props passed to embedded Header component"
    )
    show_header: bool | None = Field(
        default=None,
        alias="showHeader",
        description="Show embedded floating header (default: true). Set to false to use separate header island.",
    )
    header_variant: Literal["header-default", "header-minimal"] | None = Field(
        default=None, alias="headerVariant", description='Header variant to use (default: "header-default").'
    )
