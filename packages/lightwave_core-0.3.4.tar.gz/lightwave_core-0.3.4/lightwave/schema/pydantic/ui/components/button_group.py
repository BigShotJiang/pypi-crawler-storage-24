"""
Pydantic schema for ButtonGroup component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/button-group/button-group.tsx
Component Path: base/button-group/button-group
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ButtonGroupItemProps(JSONFieldSchema):
    """Props for ButtonGroupItem component."""

    icon_leading: str | dict[str, Any] | None | None = Field(default=None, alias="iconLeading")
    icon_trailing: str | dict[str, Any] | None | None = Field(default=None, alias="iconTrailing")
    on_click: Any | None = Field(default=None, alias="onClick")
    class_name: str | None = Field(default=None, alias="className")


class ButtonGroupProps(JSONFieldSchema):
    """Props for ButtonGroup component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
