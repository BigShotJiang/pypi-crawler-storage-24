"""
Pydantic schema for Table component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/table/table.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class TableCardHeaderProps(JSONFieldSchema):
    """Props for TableCardHeader component."""

    title: str = Field(description="The title of the table card header.")
    badge: str | dict[str, Any] | None | None = Field(
        default=None, description="The badge displayed next to the title."
    )
    description: str | None = Field(default=None, description="The description of the table card header.")
    content_trailing: str | dict[str, Any] | None | None = Field(
        default=None, alias="contentTrailing", description="The content displayed after the title and badge."
    )
    class_name: str | None = Field(
        default=None, alias="className", description="The class name of the table card header."
    )


class TableRootProps(JSONFieldSchema):
    """Props for TableRoot component."""

    size: Literal["md", "sm"] | None = Field(default=None)


class TableHeaderProps(JSONFieldSchema):
    """Props for TableHeader component."""

    bordered: bool | None = Field(default=None)


class TableHeadProps(JSONFieldSchema):
    """Props for TableHead component."""

    label: str | None = Field(default=None)
    tooltip: str | None = Field(default=None)


class TableRowProps(JSONFieldSchema):
    """Props for TableRow component."""

    highlight_selected_row: bool | None = Field(default=None, alias="highlightSelectedRow")


class TableCellProps(JSONFieldSchema):
    """Props for TableCell component."""

    ref: T | None = Field(default=None)
