"""
Pydantic schema for VerifiedTick component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/base-components/verified-tick.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class VerifiedTickProps(JSONFieldSchema):
    """Props for VerifiedTick component."""

    size: Literal["2xl", "3xl", "4xl", "lg", "md", "sm", "xl", "xs"]
    class_name: str | None = Field(default=None, alias="className")
