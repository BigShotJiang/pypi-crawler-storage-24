"""
Pydantic schema for HookForm component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/form/hook-form.tsx
"""

from typing import Any

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class FormProps(JSONFieldSchema):
    """Props for Form component."""

    form: T
    children: str | dict[str, Any] | None


class FormFieldProps(JSONFieldSchema):
    """Props for FormField component."""

    name: T
    control: T
    children: str | dict[str, Any] | None
