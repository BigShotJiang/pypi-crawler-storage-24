"""
Pydantic schema for RadioGroupIconSimple component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/radio-groups/radio-group-icon-simple.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import RadioGroupItemType


class RadioGroupIconSimpleProps(JSONFieldSchema):
    """Props for RadioGroupIconSimple component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    items: list[RadioGroupItemType]
