"""
Pydantic schema for Slider component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/slider/slider.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class SliderProps(JSONFieldSchema):
    """Props for Slider component."""

    label_position: Literal["bottom", "default", "top-floating"] | None = Field(default=None, alias="labelPosition")
    label_formatter: Any | None = Field(default=None, alias="labelFormatter")
