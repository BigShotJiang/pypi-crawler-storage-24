"""
Pydantic schema for CommandMenuFooter component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/base-components/command-menu-footer.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommandMenuFooterProps(JSONFieldSchema):
    """Props for CommandMenuFooter component."""

    class_name: str | None = Field(default=None, alias="className")
