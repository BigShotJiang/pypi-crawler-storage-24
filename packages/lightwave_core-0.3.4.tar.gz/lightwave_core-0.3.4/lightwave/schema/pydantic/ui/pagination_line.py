"""
Pydantic schema for PaginationLine component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/pagination/pagination-line.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class PaginationLineProps(JSONFieldSchema):
    """Props for PaginationLine component."""

    size: Literal["lg", "md"] | None = Field(default=None, description="The size of the pagination line.")
    framed: bool | None = Field(default=None, description="Whether the pagination is displayed in a card.")
