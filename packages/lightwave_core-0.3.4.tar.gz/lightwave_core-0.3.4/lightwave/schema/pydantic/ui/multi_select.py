"""
Pydantic schema for MultiSelect component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/select/multi-select.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import SelectItemType, T


class ComboBoxValueProps(JSONFieldSchema):
    """Props for ComboBoxValue component."""

    size: Literal["md", "sm"]
    shortcut: bool | None = Field(default=None)
    is_disabled: bool | None = Field(default=None, alias="isDisabled")
    placeholder: str | None = Field(default=None)
    shortcut_class_name: str | None = Field(default=None, alias="shortcutClassName")
    placeholder_icon: T | None = Field(default=None, alias="placeholderIcon")
    ref: T | None = Field(default=None)
    on_focus: Any | None = Field(default=None, alias="onFocus")
    on_pointer_enter: Any | None = Field(default=None, alias="onPointerEnter")


class MultiSelectProps(JSONFieldSchema):
    """Props for MultiSelect component."""

    hint: str | None = Field(default=None)
    label: str | None = Field(default=None)
    tooltip: str | None = Field(default=None)
    size: Literal["md", "sm"] | None = Field(default=None)
    placeholder: str | None = Field(default=None)
    shortcut: bool | None = Field(default=None)
    items: list[SelectItemType] | None = Field(default=None)
    popover_class_name: str | None = Field(default=None, alias="popoverClassName")
    shortcut_class_name: str | None = Field(default=None, alias="shortcutClassName")
    selected_items: list[SelectItemType] = Field(alias="selectedItems")
    placeholder_icon: T | None = Field(default=None, alias="placeholderIcon")
    children: Literal[
        "/Users/joelschaeffer/dev/lightwave-media/packages/lightwave-ui/sandbox/untitled-ui/node_modules/@types/react/index",
        "/Users/joelschaeffer/dev/lightwave-media/packages/lightwave-ui/sandbox/untitled-ui/node_modules/@types/react/index",
    ]
    on_item_cleared: Any | None = Field(default=None, alias="onItemCleared")
    on_item_inserted: Any | None = Field(default=None, alias="onItemInserted")
