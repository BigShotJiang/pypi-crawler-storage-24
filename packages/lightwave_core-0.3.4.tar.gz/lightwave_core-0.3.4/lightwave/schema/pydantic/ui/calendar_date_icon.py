"""
Pydantic schema for CalendarDateIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/base-components/calendar-date-icon.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CalendarDateIconProps(JSONFieldSchema):
    """Props for CalendarDateIcon component."""

    month: str
    day: int | float
    class_name: str | None = Field(default=None, alias="className")
