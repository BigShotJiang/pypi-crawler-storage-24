"""
Pydantic schema for CommandMenuNavigationIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/base-components/command-menu-navigation-icon.tsx
"""

from typing import Any

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommandMenuNavigationIconProps(JSONFieldSchema):
    """Props for CommandMenuNavigationIcon component."""

    type: Any
    icon: str


class CommandMenuNavigationTextProps(JSONFieldSchema):
    """Props for CommandMenuNavigationText component."""

    type: Any
    label: str


class Props(JSONFieldSchema):
    """Props for  component."""

    pass
