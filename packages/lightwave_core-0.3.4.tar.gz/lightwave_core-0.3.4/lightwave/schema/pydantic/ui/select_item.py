"""
Pydantic schema for SelectItem component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/select/select-item.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class SelectItemProps(JSONFieldSchema):
    """Props for SelectItem component."""

    pass
