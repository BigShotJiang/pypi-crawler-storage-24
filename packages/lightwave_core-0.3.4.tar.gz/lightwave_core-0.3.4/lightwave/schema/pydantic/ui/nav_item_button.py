"""
Pydantic schema for NavItemButton component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/base-components/nav-item-button.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class NavItemButtonProps(JSONFieldSchema):
    """Props for NavItemButton component."""

    open: bool | None = Field(default=None, description="Whether the collapsible nav item is open.")
    href: str | None = Field(default=None, description="URL to navigate to when the button is clicked.")
    label: str = Field(description="Label text for the button.")
    icon: str = Field(description="Icon component to display.")
    current: bool | None = Field(default=None, description="Whether the button is currently active.")
    size: Literal["lg", "md"] | None = Field(default=None, description="Size of the button.")
    on_click: Any | None = Field(default=None, alias="onClick", description="Handler for click events.")
    class_name: str | None = Field(
        default=None, alias="className", description="Additional CSS classes to apply to the button."
    )
    tooltip_placement: Literal["bottom", "left", "right", "top"] | None = Field(
        default=None, alias="tooltipPlacement", description="Placement of the tooltip."
    )
