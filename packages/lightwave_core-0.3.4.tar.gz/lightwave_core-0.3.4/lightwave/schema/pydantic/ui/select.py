"""
Pydantic schema for Select component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/select/select.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import SelectItemType, T


class CommonProps(JSONFieldSchema):
    """Props for Common component."""

    hint: str | None = Field(default=None)
    label: str | None = Field(default=None)
    tooltip: str | None = Field(default=None)
    size: Literal["md", "sm"] | None = Field(default=None)
    placeholder: str | None = Field(default=None)


class SelectProps(JSONFieldSchema):
    """Props for Select component."""

    items: list[SelectItemType] | None = Field(default=None)
    popover_class_name: str | None = Field(default=None, alias="popoverClassName")
    placeholder_icon: str | dict[str, Any] | None | None = Field(default=None, alias="placeholderIcon")
    children: str | dict[str, Any] | None


class SelectValueProps(JSONFieldSchema):
    """Props for SelectValue component."""

    is_open: bool = Field(alias="isOpen")
    size: Literal["md", "sm"]
    is_focused: bool = Field(alias="isFocused")
    is_disabled: bool = Field(alias="isDisabled")
    placeholder: str | None = Field(default=None)
    ref: T | None = Field(default=None)
    placeholder_icon: str | dict[str, Any] | None | None = Field(default=None, alias="placeholderIcon")
