"""
Pydantic schema for PaginationDot component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/pagination/pagination-dot.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class PaginationDotProps(JSONFieldSchema):
    """Props for PaginationDot component."""

    size: Literal["lg", "md"] | None = Field(default=None, description="The size of the pagination dot.")
    is_brand: bool | None = Field(
        default=None, alias="isBrand", description="Whether the pagination uses brand colors."
    )
    framed: bool | None = Field(default=None, description="Whether the pagination is displayed in a card.")
