"""
Pydantic schema for EmptyState component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/empty-state/empty-state.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class RootContextProps(JSONFieldSchema):
    """Props for RootContext component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)


class RootProps(JSONFieldSchema):
    """Props for Root component."""

    pass


class FileTypeIconProps(JSONFieldSchema):
    """Props for FileTypeIcon component."""

    type: (
        Literal[
            "aep",
            "ai",
            "audio",
            "avi",
            "code",
            "css",
            "csv",
            "dmg",
            "doc",
            "document",
            "docx",
            "empty",
            "eps",
            "exe",
            "fig",
            "folder",
            "gif",
            "html",
            "image",
            "img",
            "indd",
            "java",
            "jpeg",
            "jpg",
            "js",
            "json",
            "mkv",
            "mp3",
            "mp4",
            "mpeg",
            "pdf",
            "pdf-simple",
            "png",
            "ppt",
            "pptx",
            "psd",
            "rar",
            "rss",
            "spreadsheets",
            "sql",
            "svg",
            "tiff",
            "txt",
            "video",
            "video-01",
            "video-02",
            "wav",
            "webp",
            "xls",
            "xlsx",
            "xml",
            "zip",
        ]
        | None
    ) = Field(default=None)
    theme: Literal["default", "gray", "solid"] | None = Field(default=None)


class HeaderProps(JSONFieldSchema):
    """Props for Header component."""

    pattern: Literal["circle", "grid", "grid-check", "none", "square"] | None = Field(default=None)
    pattern_size: Literal["lg", "md", "sm"] | None = Field(default=None, alias="patternSize")
