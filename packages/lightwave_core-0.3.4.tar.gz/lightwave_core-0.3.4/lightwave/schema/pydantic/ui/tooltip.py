"""
Pydantic schema for Tooltip component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/tooltip/tooltip.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TooltipProps(JSONFieldSchema):
    """Props for Tooltip component."""

    title: str | dict[str, Any] | None = Field(description="The title of the tooltip.")
    description: str | dict[str, Any] | None | None = Field(default=None, description="The description of the tooltip.")
    arrow: bool | None = Field(default=False, description="Whether to show the arrow on the tooltip.")
    delay: int | float | None = Field(default=300, description="Delay in milliseconds before the tooltip is shown.")


class TooltipTriggerProps(JSONFieldSchema):
    """Props for TooltipTrigger component."""

    pass
