"""
Pydantic schema for ProgressIndicators component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/progress-indicators/progress-indicators.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ProgressBarProps(JSONFieldSchema):
    """Props for ProgressBar component."""

    value: int | float = Field(description="The current value of the progress bar.")
    min: int | float | None = Field(default=0, description="The minimum value of the progress bar.")
    max: int | float | None = Field(default=100, description="The maximum value of the progress bar.")
    class_name: str | None = Field(
        default=None,
        alias="className",
        description="Optional additional CSS class names for the progress bar container.",
    )
    progress_class_name: str | None = Field(
        default=None,
        alias="progressClassName",
        description="Optional additional CSS class names for the progress bar indicator element.",
    )
    value_formatter: Any | None = Field(
        default=None,
        alias="valueFormatter",
        description="Optional function to format the displayed value. It receives the raw value and the calculated percentage.",
    )


class ProgressIndicatorWithTextProps(JSONFieldSchema):
    """Props for ProgressIndicatorWithText component."""

    label_position: Any | None = Field(
        default=None,
        alias="labelPosition",
        description="Specifies the layout of the text relative to the progress bar. - `right`: Text is displayed to the right of the progress bar. - `bottom`: Text is displayed below the progress bar, aligned to the right. - `top-floating`: Text is displayed in a floating tooltip above the progress indicator. - `bottom-floating`: Text is displayed in a floating tooltip below the progress indicator.",
    )
