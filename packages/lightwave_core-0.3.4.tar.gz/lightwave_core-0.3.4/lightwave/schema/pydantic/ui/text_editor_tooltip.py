"""
Pydantic schema for TextEditorTooltip component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/text-editor/text-editor-tooltip.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TextEditorTooltipProps(JSONFieldSchema):
    """Props for TextEditorTooltip component."""

    class_name: str | None = Field(default=None, alias="className")
