"""
Pydantic schema for CodeSnippet component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/code-snippet/code-snippet.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CodeSnippetProps(JSONFieldSchema):
    """Props for CodeSnippet component."""

    code: str | None = Field(
        default=None,
        description="The code to be syntax highlighted. Can be provided in two ways: 1. As a string via this prop for client-side highlighting 2. As pre-highlighted nodes via children prop for server-side highlighting",
    )
    language: Any = Field(
        description="The programming language of the code snippet. Determines syntax highlighting rules."
    )
    show_line_numbers: bool | None = Field(
        default=True, alias="showLineNumbers", description="Whether to display line numbers alongside the code."
    )
    children: str | dict[str, Any] | None | None = Field(
        default=None,
        description="Pre-highlighted code nodes that were generated on the server. Alternative to passing raw code string via the `code` prop.",
    )
