"""
Pydantic schema for CarouselBase component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/carousel/carousel-base.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CarouselContentProps(JSONFieldSchema):
    """Props for CarouselContent component."""

    class_name: str | None = Field(default=None, alias="className", description="The class name of the content.")
    overflow_hidden: bool | None = Field(
        default=None, alias="overflowHidden", description="Whether to hide the overflow."
    )


class TriggerRenderProps(JSONFieldSchema):
    """Props for TriggerRender component."""

    is_disabled: bool = Field(alias="isDisabled")
    on_click: Any = Field(alias="onClick")


class TriggerProps(JSONFieldSchema):
    """Props for Trigger component."""

    ref: Any | None = Field(default=None, description="The ref of the trigger.")
    as_child: bool | None = Field(
        default=None,
        alias="asChild",
        description="If true, the child element will be cloned and passed down the prop of the trigger.",
    )
    direction: Literal["next", "prev"] = Field(description="The direction of the trigger.")
    children: str | dict[str, Any] | None = Field(
        default=None, description="The children of the trigger. Can be a render prop or a valid element."
    )
    style: Any | None = Field(default=None, description="The style of the trigger.")
    class_name: str | Any | None = Field(default=None, alias="className", description="The class name of the trigger.")


class CarouselIndicatorRenderProps(JSONFieldSchema):
    """Props for CarouselIndicatorRender component."""

    is_selected: bool = Field(alias="isSelected")
    on_click: Any = Field(alias="onClick")


class CarouselIndicatorProps(JSONFieldSchema):
    """Props for CarouselIndicator component."""

    index: int | float = Field(description="The index of the indicator.")
    as_child: bool | None = Field(
        default=None,
        alias="asChild",
        description="If true, the child element will be cloned and passed down the prop of the indicator.",
    )
    is_selected: bool | None = Field(
        default=None, alias="isSelected", description="If true, the indicator will be selected."
    )
    children: str | dict[str, Any] | None = Field(
        default=None, description="The children of the indicator. Can be a render prop or a valid element."
    )
    style: Any | None = Field(default=None, description="The style of the indicator.")
    class_name: str | Any | None = Field(
        default=None, alias="className", description="The class name of the indicator."
    )


class CarouselIndicatorGroupProps(JSONFieldSchema):
    """Props for CarouselIndicatorGroup component."""

    children: str | dict[str, Any] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")


class CarouselProps(JSONFieldSchema):
    """Props for Carousel component."""

    pass


class CarouselContextProps(JSONFieldSchema):
    """Props for CarouselContext component."""

    pass
