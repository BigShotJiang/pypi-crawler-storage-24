"""
Pydantic schema for QrCode component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: shared-assets/qr-code.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class QRCodeProps(JSONFieldSchema):
    """Props for QRCode component."""

    value: str = Field(description="The value to encode in the QR code.")
    options: Any | None = Field(default=None, description="Additional options to customize the QR code.")
    size: Literal["lg", "md"] | None = Field(default="md", description="The size of the QR code.")
    class_name: str | None = Field(
        default=None, alias="className", description="The class name to apply to the QR code."
    )
