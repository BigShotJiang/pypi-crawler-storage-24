"""
Pydantic schema for HintText component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/input/hint-text.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class HintTextProps(JSONFieldSchema):
    """Props for HintText component."""

    is_invalid: bool | None = Field(
        default=None, alias="isInvalid", description="Indicates that the hint text is an error message."
    )
    ref: T | None = Field(default=None)
    children: str | dict[str, Any] | None
