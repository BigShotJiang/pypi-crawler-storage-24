"""
Pydantic schema for CalendarHeader component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/base-components/calendar-header.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import ItemProps


class CalendarHeaderProps(JSONFieldSchema):
    """Props for CalendarHeader component."""

    date: Any
    selected_view: str = Field(alias="selectedView")
    view_options: list[ItemProps] = Field(alias="viewOptions")
    on_selection_change: Any = Field(alias="onSelectionChange")
    on_click_prev: Any | None = Field(default=None, alias="onClickPrev")
    on_click_next: Any | None = Field(default=None, alias="onClickNext")
    on_click_today: Any | None = Field(default=None, alias="onClickToday")
