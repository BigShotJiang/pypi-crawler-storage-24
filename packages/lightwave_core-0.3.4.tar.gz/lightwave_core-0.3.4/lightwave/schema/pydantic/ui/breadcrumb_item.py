"""
Pydantic schema for BreadcrumbItem component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/breadcrumbs/breadcrumb-item.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class BreadcrumbItemBaseProps(JSONFieldSchema):
    """Props for BreadcrumbItemBase component."""

    href: str | None = Field(default=None)
    icon: str | dict[str, Any] | None | None = Field(default=None)
    type: Literal["button", "text"] | None = Field(default=None)
    current: bool | None = Field(default=None)
    children: str | dict[str, Any] | None | None = Field(default=None)


class BreadcrumbItemProps(JSONFieldSchema):
    """Props for BreadcrumbItem component."""

    href: str | None = Field(default=None)
    divider: Literal["chevron", "slash"] | None = Field(default=None)
    type: T | None = Field(default=None)
    is_ellipsis: bool | None = Field(default=None, alias="isEllipsis")
    children: str | dict[str, Any] | None | None = Field(default=None)
    icon: str | dict[str, Any] | None | None = Field(default=None)
    on_click: Any | None = Field(default=None, alias="onClick")
