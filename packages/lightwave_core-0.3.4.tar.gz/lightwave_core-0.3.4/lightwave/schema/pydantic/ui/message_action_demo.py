"""
Pydantic schema for MessageAction.demo component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/messaging/message-action.demo.tsx
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class MessageActionMinimalProps(BaseModel):
    """Props for MessageActionMinimal component."""

    on_submit: Any | None = Field(default=None, alias="onSubmit")

    model_config = ConfigDict(
        populate_by_name=True,  # Allow both snake_case and camelCase
        extra="forbid",
    )


class MessageActionTextareaProps(BaseModel):
    """Props for MessageActionTextarea component."""

    text_area_class_name: str | None = Field(default=None, alias="textAreaClassName")
    on_submit: Any | None = Field(default=None, alias="onSubmit")

    model_config = ConfigDict(
        populate_by_name=True,  # Allow both snake_case and camelCase
        extra="forbid",
    )


class MessageActionAdvancedProps(BaseModel):
    """Props for MessageActionAdvanced component."""

    text_area_class_name: str | None = Field(default=None, alias="textAreaClassName")
    on_submit: Any | None = Field(default=None, alias="onSubmit")

    model_config = ConfigDict(
        populate_by_name=True,  # Allow both snake_case and camelCase
        extra="forbid",
    )
