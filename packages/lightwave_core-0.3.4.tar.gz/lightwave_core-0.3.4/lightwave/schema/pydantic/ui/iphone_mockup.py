"""
Pydantic schema for IphoneMockup component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: shared-assets/iphone-mockup.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class IPhoneMockupProps(JSONFieldSchema):
    """Props for IPhoneMockup component."""

    image: str = Field(description="The image to display on the phone.")
    image_dark: str | None = Field(
        default=None,
        alias="imageDark",
        description="The dark mode image to display in dark mode. If not provided, the light mode image will be used in dark mode.",
    )
    theme: Literal["dark", "light"] | None = Field(default="light", description="The theme of the phone.")
