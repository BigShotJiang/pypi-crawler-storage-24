"""
Pydantic schema for RatingBadge component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/rating-badge.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class RatingBadgeProps(JSONFieldSchema):
    """Props for RatingBadge component."""

    title: str | None = Field(default=None)
    subtitle: str | None = Field(default=None)
    rating: int | float | None = Field(default=None)
    theme: Literal["dark", "light"] | None = Field(default=None)
