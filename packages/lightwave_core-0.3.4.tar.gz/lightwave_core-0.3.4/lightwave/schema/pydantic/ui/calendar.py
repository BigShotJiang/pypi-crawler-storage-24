"""
Pydantic schema for Calendar component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/calendar.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import DateValue, T, ZonedEvent


class PositionedEventProps(JSONFieldSchema):
    """Props for PositionedEvent component."""

    event: ZonedEvent
    day_start: T = Field(alias="dayStart")
    time_zone: str = Field(alias="timeZone")
    slot_height: int | float = Field(alias="slotHeight")
    overlap_index: int | float = Field(alias="overlapIndex")
    total_overlapping: int | float = Field(alias="totalOverlapping")
    set_selected_date: Any = Field(alias="setSelectedDate")
    time_formatter: Any = Field(alias="timeFormatter")


class MonthViewProps(JSONFieldSchema):
    """Props for MonthView component."""

    current_month_date: Any = Field(alias="currentMonthDate")
    selected_date: Any = Field(alias="selectedDate")
    zoned_events: list[ZonedEvent] = Field(alias="zonedEvents")
    locale: str
    time_zone: str = Field(alias="timeZone")
    set_selected_date: Any = Field(alias="setSelectedDate")
    full_date_formatter: Any = Field(alias="fullDateFormatter")
    short_weekday_formatter: Any = Field(alias="shortWeekdayFormatter")
    time_formatter: Any = Field(alias="timeFormatter")
    class_name: str | None = Field(default=None, alias="className")


class MobileSingleDayGridProps(JSONFieldSchema):
    """Props for MobileSingleDayGrid component."""

    day_to_display: Any = Field(alias="dayToDisplay")
    day_events: list[ZonedEvent] = Field(alias="dayEvents")
    time_zone: str = Field(alias="timeZone")
    locale: str
    current_time: T = Field(alias="currentTime")
    set_selected_date: Any = Field(alias="setSelectedDate")
    time_formatter: Any = Field(alias="timeFormatter")
    class_name: str | None = Field(default=None, alias="className")


class WeekViewDayProps(JSONFieldSchema):
    """Props for WeekViewDay component."""

    day: Any
    is_last_day: bool = Field(alias="isLastDay")
    visible_events: list[ZonedEvent] = Field(alias="visibleEvents")
    time_zone: str = Field(alias="timeZone")
    slot_height: int | float = Field(alias="slotHeight")
    set_selected_date: Any = Field(alias="setSelectedDate")
    time_formatter: Any = Field(alias="timeFormatter")


class WeekViewProps(JSONFieldSchema):
    """Props for WeekView component."""

    current_month_date: Any = Field(alias="currentMonthDate")
    selected_date: Any = Field(alias="selectedDate")
    zoned_events: list[ZonedEvent] = Field(alias="zonedEvents")
    locale: str
    time_zone: str = Field(alias="timeZone")
    current_time: T = Field(alias="currentTime")
    set_selected_date: Any = Field(alias="setSelectedDate")
    short_weekday_formatter: Any = Field(alias="shortWeekdayFormatter")
    time_formatter: Any = Field(alias="timeFormatter")
    hour_only_formatter: Any = Field(alias="hourOnlyFormatter")
    class_name: str | None = Field(default=None, alias="className")
    view: str | None = Field(default=None)


class DayViewProps(JSONFieldSchema):
    """Props for DayView component."""

    day_to_display: Any = Field(alias="dayToDisplay")
    selected_date: Any = Field(alias="selectedDate")
    zoned_events: list[ZonedEvent] = Field(alias="zonedEvents")
    locale: str
    time_zone: str = Field(alias="timeZone")
    current_time: T = Field(alias="currentTime")
    set_selected_date: Any = Field(alias="setSelectedDate")
    short_weekday_formatter: Any = Field(alias="shortWeekdayFormatter")
    time_formatter: Any = Field(alias="timeFormatter")
    hour_only_formatter: Any = Field(alias="hourOnlyFormatter")
    class_name: str | None = Field(default=None, alias="className")
    view: str | None = Field(default=None)


class CalendarProps(JSONFieldSchema):
    """Props for Calendar component."""

    highlighted_dates: list[DateValue] | None = Field(
        default=None, alias="highlightedDates", description="The dates to highlight."
    )
