"""
Pydantic schema for SidebarSlim component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/sidebar-navigation/sidebar-slim.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItem


class SidebarNavigationSlimProps(JSONFieldSchema):
    """Props for SidebarNavigationSlim component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    items: list[NavItem] = Field(description="List of items to display.")
    footer_items: list[NavItem] | None = Field(
        default=None, alias="footerItems", description="List of footer items to display."
    )
    hide_border: bool | None = Field(default=None, alias="hideBorder", description="Whether to hide the border.")
    hide_right_border: bool | None = Field(
        default=None, alias="hideRightBorder", description="Whether to hide the right side border."
    )
