"""
Pydantic schema for Notifications component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/notifications/notifications.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class IconNotificationProps(JSONFieldSchema):
    """Props for IconNotification component."""

    title: str
    description: str
    confirm_label: str | None = Field(default=None, alias="confirmLabel")
    dismiss_label: str | None = Field(default=None, alias="dismissLabel")
    hide_dismiss_label: bool | None = Field(default=None, alias="hideDismissLabel")
    icon: str | None = Field(default=None)
    color: Literal["brand", "default", "error", "gray", "success", "warning"] | None = Field(default=None)
    progress: int | float | None = Field(default=None)
    on_close: Any | None = Field(default=None, alias="onClose")
    on_confirm: Any | None = Field(default=None, alias="onConfirm")


class AvatarNotificationProps(JSONFieldSchema):
    """Props for AvatarNotification component."""

    name: str
    content: str
    avatar: str
    date: str
    confirm_label: str = Field(alias="confirmLabel")
    dismiss_label: str | None = Field(default=None, alias="dismissLabel")
    hide_dismiss_label: bool | None = Field(default=None, alias="hideDismissLabel")
    icon: str | None = Field(default=None)
    color: Literal["brand", "default", "error", "gray", "success", "warning"] | None = Field(default=None)
    on_close: Any | None = Field(default=None, alias="onClose")
    on_confirm: Any | None = Field(default=None, alias="onConfirm")


class ImageNotificationProps(JSONFieldSchema):
    """Props for ImageNotification component."""

    title: str
    description: str
    confirm_label: str = Field(alias="confirmLabel")
    dismiss_label: str | None = Field(default=None, alias="dismissLabel")
    hide_dismiss_label: bool | None = Field(default=None, alias="hideDismissLabel")
    image_mobile: str = Field(alias="imageMobile")
    image_desktop: str = Field(alias="imageDesktop")
    on_close: Any | None = Field(default=None, alias="onClose")
    on_confirm: Any | None = Field(default=None, alias="onConfirm")
