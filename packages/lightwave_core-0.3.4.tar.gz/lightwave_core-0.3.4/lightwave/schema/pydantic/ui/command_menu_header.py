"""
Pydantic schema for CommandMenuHeader component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/base-components/command-menu-header.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommandMenuHeaderProps(JSONFieldSchema):
    """Props for CommandMenuHeader component."""

    children: str | dict[str, Any] | None
    size: Literal["md", "sm"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
