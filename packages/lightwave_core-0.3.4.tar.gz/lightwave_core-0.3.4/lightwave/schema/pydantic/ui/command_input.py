"""
Pydantic schema for CommandInput component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/command-menus/base-components/command-input.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommandInputProps(JSONFieldSchema):
    """Props for CommandInput component."""

    pass
