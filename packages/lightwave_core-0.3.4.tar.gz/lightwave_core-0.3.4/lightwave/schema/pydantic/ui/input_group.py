"""
Pydantic schema for InputGroup component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/input/input-group.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class InputPrefixProps(JSONFieldSchema):
    """Props for InputPrefix component."""

    position: Literal["leading", "trailing"] | None = Field(default=None, description="The position of the prefix.")
    size: Literal["md", "sm"] | None = Field(default=None, description="The size of the prefix.")
    is_disabled: bool | None = Field(
        default=None, alias="isDisabled", description="Indicates that the prefix is disabled."
    )


class InputGroupProps(JSONFieldSchema):
    """Props for InputGroup component."""

    prefix: str | None = Field(
        default=None, description="A prefix text that is displayed in the same box as the input."
    )
    leading_addon: str | dict[str, Any] | None | None = Field(
        default=None,
        alias="leadingAddon",
        description="A leading addon that is displayed with visual separation from the input.",
    )
    trailing_addon: str | dict[str, Any] | None | None = Field(
        default=None,
        alias="trailingAddon",
        description="A trailing addon that is displayed with visual separation from the input.",
    )
    class_name: str | None = Field(
        default=None, alias="className", description="The class name to apply to the input group."
    )
    children: str | dict[str, Any] | None = Field(description="The children of the input group (i.e `<InputBase />`)")
