"""
Pydantic schema for DateInput component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/date-picker/date-input.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class DateInputProps(JSONFieldSchema):
    """Props for DateInput component."""

    pass
