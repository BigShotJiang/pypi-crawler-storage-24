"""
Pydantic schema for AvatarCompanyIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/base-components/avatar-company-icon.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AvatarCompanyIconProps(JSONFieldSchema):
    """Props for AvatarCompanyIcon component."""

    size: Literal["2xl", "lg", "md", "sm", "xl", "xs"]
    src: str
    alt: str | None = Field(default=None)
