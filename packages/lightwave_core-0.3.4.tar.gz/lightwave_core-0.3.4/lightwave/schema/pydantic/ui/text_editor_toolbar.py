"""
Pydantic schema for TextEditorToolbar component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/text-editor/text-editor-toolbar.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TextEditorToolbarProps(JSONFieldSchema):
    """Props for TextEditorToolbar component."""

    class_name: str | None = Field(default=None, alias="className")
    type: Literal["advanced", "simple"] | None = Field(default=None)
    floating: bool | None = Field(default=None)
    hide_font_size: bool | None = Field(default=None, alias="hideFontSize")
