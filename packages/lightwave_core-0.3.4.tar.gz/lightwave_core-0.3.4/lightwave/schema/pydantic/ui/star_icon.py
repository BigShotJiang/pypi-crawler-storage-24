"""
Pydantic schema for StarIcon component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: foundations/star-icon.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class StarIconProps(JSONFieldSchema):
    """Props for StarIcon component."""

    progress: int | float | None = Field(
        default=100, description="The progress of the star icon. It should be a number between 0 and 100."
    )


class RatingStarsProps(JSONFieldSchema):
    """Props for RatingStars component."""

    rating: int | float | None = Field(default=5, description="The rating to display.")
    stars: int | float | None = Field(default=None, description="The number of stars to display.")
    star_class_name: str | None = Field(
        default=None, alias="starClassName", description="The class name of the star icon."
    )
