"""
Pydantic schema for AvatarOnlineIndicator component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/base-components/avatar-online-indicator.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AvatarOnlineIndicatorProps(JSONFieldSchema):
    """Props for AvatarOnlineIndicator component."""

    size: Literal["2xl", "3xl", "4xl", "lg", "md", "sm", "xl", "xs"]
    status: Literal["offline", "online"]
    class_name: str | None = Field(default=None, alias="className")
