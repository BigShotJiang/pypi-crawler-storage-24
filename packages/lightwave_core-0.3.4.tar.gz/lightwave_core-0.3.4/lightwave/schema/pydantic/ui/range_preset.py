"""
Pydantic schema for RangePreset component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/date-picker/range-preset.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import DateValue


class RangePresetButtonProps(JSONFieldSchema):
    """Props for RangePresetButton component."""

    value: DateValue
