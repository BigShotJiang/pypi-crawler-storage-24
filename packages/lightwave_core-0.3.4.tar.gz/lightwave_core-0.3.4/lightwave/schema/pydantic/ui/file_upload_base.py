"""
Pydantic schema for FileUploadBase component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/file-upload/file-upload-base.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class FileUploadDropZoneProps(JSONFieldSchema):
    """Props for FileUploadDropZone component."""

    class_name: str | None = Field(default=None, alias="className", description="The class name of the drop zone.")
    hint: str | None = Field(default=None, description="A hint text explaining what files can be dropped.")
    is_disabled: bool | None = Field(
        default=None, alias="isDisabled", description="Disables dropping or uploading files."
    )
    accept: str | None = Field(
        default=None,
        description='Specifies the types of files that the server accepts. Examples: "image/*", ".pdf,image/*", "image/*,video/mpeg,application/pdf"',
    )
    allows_multiple: bool | None = Field(
        default=None, alias="allowsMultiple", description="Allows multiple file uploads."
    )
    max_size: int | float | None = Field(default=None, alias="maxSize", description="Maximum file size in bytes.")
    on_drop_files: Any | None = Field(
        default=None,
        alias="onDropFiles",
        description="Callback function that is called with the list of dropped files when files are dropped on the drop zone.",
    )
    on_drop_unaccepted_files: Any | None = Field(
        default=None,
        alias="onDropUnacceptedFiles",
        description="Callback function that is called with the list of unaccepted files when files are dropped on the drop zone.",
    )
    on_size_limit_exceed: Any | None = Field(
        default=None,
        alias="onSizeLimitExceed",
        description="Callback function that is called with the list of files that exceed the size limit when files are dropped on the drop zone.",
    )


class FileListItemProps(JSONFieldSchema):
    """Props for FileListItem component."""

    name: str = Field(description="The name of the file.")
    size: int | float = Field(description="The size of the file.")
    progress: int | float = Field(description="The upload progress of the file.")
    failed: bool | None = Field(default=None, description="Whether the file failed to upload.")
    type: (
        Literal[
            "aep",
            "ai",
            "audio",
            "avi",
            "code",
            "css",
            "csv",
            "dmg",
            "doc",
            "document",
            "docx",
            "empty",
            "eps",
            "exe",
            "fig",
            "folder",
            "gif",
            "html",
            "image",
            "img",
            "indd",
            "java",
            "jpeg",
            "jpg",
            "js",
            "json",
            "mkv",
            "mp3",
            "mp4",
            "mpeg",
            "pdf",
            "pdf-simple",
            "png",
            "ppt",
            "pptx",
            "psd",
            "rar",
            "rss",
            "spreadsheets",
            "sql",
            "svg",
            "tiff",
            "txt",
            "video",
            "video-01",
            "video-02",
            "wav",
            "webp",
            "xls",
            "xlsx",
            "xml",
            "zip",
        ]
        | None
    ) = Field(default=None, description="The type of the file.")
    class_name: str | None = Field(default=None, alias="className", description="The class name of the file list item.")
    file_icon_variant: Literal["default", "gray", "solid"] | None = Field(
        default=None, alias="fileIconVariant", description="The variant of the file icon."
    )
    on_delete: Any | None = Field(
        default=None, alias="onDelete", description="The function to call when the file is deleted."
    )
    on_retry: Any | None = Field(
        default=None, alias="onRetry", description="The function to call when the file upload is retried."
    )
