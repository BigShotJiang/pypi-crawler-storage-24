"""
Pydantic schema for NavList component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/app-navigation/base-components/nav-list.tsx
"""

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import NavItemDividerType, NavItemType


class NavListProps(JSONFieldSchema):
    """Props for NavList component."""

    active_url: str | None = Field(default=None, alias="activeUrl", description="URL of the currently active item.")
    class_name: str | None = Field(
        default=None, alias="className", description="Additional CSS classes to apply to the list."
    )
    items: list[NavItemType | NavItemDividerType] = Field(description="List of items to display.")
