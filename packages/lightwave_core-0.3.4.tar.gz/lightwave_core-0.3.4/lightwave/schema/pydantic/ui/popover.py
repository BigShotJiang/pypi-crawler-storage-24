"""
Pydantic schema for Popover component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/select/popover.tsx
"""

from typing import Literal

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class PopoverProps(JSONFieldSchema):
    """Props for Popover component."""

    size: Literal["md", "sm"]
