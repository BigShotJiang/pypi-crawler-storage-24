"""
Pydantic schema for BadgeGroups component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/badges/badge-groups.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class BadgeGroupProps(JSONFieldSchema):
    """Props for BadgeGroup component."""

    children: str | dict[str, Any] | None | None = Field(default=None)
    addon_text: str = Field(alias="addonText")
    size: Any | None = Field(default=None)
    color: Any
    theme: T | None = Field(default=None)
    align: Any | None = Field(default=None, description="Alignment of the badge addon element.")
    icon_trailing: str | dict[str, Any] | None | None = Field(default=None, alias="iconTrailing")
    class_name: str | None = Field(default=None, alias="className")
