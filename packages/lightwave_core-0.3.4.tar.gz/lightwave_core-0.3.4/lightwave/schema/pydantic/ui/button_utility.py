"""
Pydantic schema for ButtonUtility component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/buttons/button-utility.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CommonProps(JSONFieldSchema):
    """Common props shared between button and anchor variants"""

    is_disabled: bool | None = Field(
        default=None, alias="isDisabled", description="Disables the button and shows a disabled state"
    )
    size: Literal["sm", "xs"] | None = Field(default=None, description="The size variant of the button")
    color: Literal["secondary", "tertiary"] | None = Field(default=None, description="The color variant of the button")
    icon: str | dict[str, Any] | None | None = Field(default=None, description="The icon to display in the button")
    tooltip: str | None = Field(default=None, description="The tooltip to display when hovering over the button")
    tooltip_placement: Any | None = Field(
        default=None, alias="tooltipPlacement", description="The placement of the tooltip"
    )


class ButtonProps(JSONFieldSchema):
    """Props for the button variant (non-link)"""

    slot: str | None = Field(default=None, description="Slot name for react-aria component")


class LinkProps(JSONFieldSchema):
    """Props for the link variant (anchor tag)"""

    pass


class Props(JSONFieldSchema):
    """Union type of button and link props"""

    pass
