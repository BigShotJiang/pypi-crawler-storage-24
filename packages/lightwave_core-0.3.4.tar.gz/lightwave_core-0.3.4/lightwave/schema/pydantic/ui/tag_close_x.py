"""
Pydantic schema for TagCloseX component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/tags/base-components/tag-close-x.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class TagCloseXProps(JSONFieldSchema):
    """Props for TagCloseX component."""

    size: Literal["lg", "md", "sm"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
