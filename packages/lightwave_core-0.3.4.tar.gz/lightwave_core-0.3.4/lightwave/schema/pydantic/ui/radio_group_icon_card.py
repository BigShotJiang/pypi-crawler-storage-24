"""
Pydantic schema for RadioGroupIconCard component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/radio-groups/radio-group-icon-card.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import IconCardItemType


class RadioGroupIconCardProps(JSONFieldSchema):
    """Props for RadioGroupIconCard component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    items: list[IconCardItemType]
