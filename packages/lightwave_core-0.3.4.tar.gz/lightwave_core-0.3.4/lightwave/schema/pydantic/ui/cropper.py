"""
Pydantic schema for Cropper component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: shared-assets/image-cropper/cropper.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class ImgProps(JSONFieldSchema):
    """Props for Img component."""

    pass
