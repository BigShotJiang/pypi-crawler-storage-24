"""
Pydantic schema for CalendarColumnHeader component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: application/calendar/base-components/calendar-column-header.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class CalendarColumnHeaderProps(JSONFieldSchema):
    """Props for CalendarColumnHeader component."""

    week_day: str = Field(alias="weekDay")
    day: int | float | None = Field(default=None)
    state: Literal["current", "default", "selected"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    on_click: Any | None = Field(default=None, alias="onClick")
