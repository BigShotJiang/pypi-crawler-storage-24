"""
Pydantic schema for AvatarLabelGroup component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/avatar/avatar-label-group.tsx
"""

from typing import Any, Literal

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class AvatarLabelGroupProps(JSONFieldSchema):
    """Props for AvatarLabelGroup component."""

    size: Literal["lg", "md", "sm", "xl"]
    title: str | dict[str, Any] | None
    subtitle: str | dict[str, Any] | None
