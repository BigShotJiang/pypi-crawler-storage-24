"""
Pydantic schema for Checkbox component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/checkbox/checkbox.tsx
"""

from typing import Any, Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class CheckboxBaseProps(JSONFieldSchema):
    """Props for CheckboxBase component."""

    size: Literal["md", "sm"] | None = Field(default=None)
    class_name: str | None = Field(default=None, alias="className")
    is_focus_visible: bool | None = Field(default=None, alias="isFocusVisible")
    is_selected: bool | None = Field(default=None, alias="isSelected")
    is_disabled: bool | None = Field(default=None, alias="isDisabled")
    is_indeterminate: bool | None = Field(default=None, alias="isIndeterminate")


class CheckboxProps(JSONFieldSchema):
    """Props for Checkbox component."""

    ref: T | None = Field(default=None)
    size: Literal["md", "sm"] | None = Field(default=None)
    label: str | dict[str, Any] | None | None = Field(default=None)
    hint: str | dict[str, Any] | None | None = Field(default=None)
