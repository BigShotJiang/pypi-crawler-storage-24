"""
Pydantic schema for VideoPlayer component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/video-player/video-player.tsx
"""

from typing import Literal

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class VideoPlayerProps(JSONFieldSchema):
    """Props for VideoPlayer component."""

    src: str = Field(description="The URL of the video.")
    type: str | None = Field(default=None, description="The MIME type of the video.")
    auto_play: bool | None = Field(
        default=None, alias="autoPlay", description="Whether the video should start playing as soon as it's ready."
    )
    thumbnail_url: str | None = Field(
        default=None,
        alias="thumbnailUrl",
        description="URL of the thumbnail image to show before the video starts playing.",
    )
    thumbnail_alt: str | None = Field(
        default=None, alias="thumbnailAlt", description="Alt text for the thumbnail image."
    )
    show_thumbnail_overlay: bool | None = Field(
        default=None,
        alias="showThumbnailOverlay",
        description="Whether to show a semi-transparent overlay on top of the thumbnail image.",
    )
    thumbnail_button_class_name: str | None = Field(
        default=None, alias="thumbnailButtonClassName", description="Class name for the thumbnail button."
    )
    size: Literal["lg", "md", "sm"] | None = Field(default=None, description="Size of the video player.")
    class_name: str | None = Field(default=None, alias="className")
