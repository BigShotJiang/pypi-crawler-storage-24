"""
Pydantic schema for TextEditor component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/text-editor/text-editor.tsx
"""

from typing import Any

from pydantic import Field

from lightwave.schema.pydantic.core.base import JSONFieldSchema

from ._types import T


class TextEditorRootProps(JSONFieldSchema):
    """Props for TextEditorRoot component."""

    class_name: str | None = Field(default=None, alias="className")
    is_disabled: bool | None = Field(default=None, alias="isDisabled")
    limit: int | float | None = Field(default=None)
    placeholder: str | None = Field(default=None)
    is_invalid: bool | None = Field(default=None, alias="isInvalid")
    children: str | dict[str, Any] | None | None = Field(default=None)
    input_class_name: str | None = Field(default=None, alias="inputClassName")
    ref: T | None = Field(default=None)


class TextEditorContentProps(JSONFieldSchema):
    """Props for TextEditorContent component."""

    ref: T | None = Field(default=None)


class TextEditorLabelProps(JSONFieldSchema):
    """Props for TextEditorLabel component."""

    pass


class TextEditorHintTextProps(JSONFieldSchema):
    """Props for TextEditorHintText component."""

    pass
