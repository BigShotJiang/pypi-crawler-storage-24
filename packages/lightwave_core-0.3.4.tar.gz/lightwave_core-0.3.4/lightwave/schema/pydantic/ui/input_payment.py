"""
Pydantic schema for InputPayment component.

AUTO-GENERATED FROM ui-manifest.json - DO NOT EDIT MANUALLY
Source: base/input/input-payment.tsx
"""

from lightwave.schema.pydantic.core.base import JSONFieldSchema


class PaymentInputProps(JSONFieldSchema):
    """Props for PaymentInput component."""

    pass
