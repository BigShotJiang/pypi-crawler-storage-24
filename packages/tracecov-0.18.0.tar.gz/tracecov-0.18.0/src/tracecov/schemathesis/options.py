from __future__ import annotations

import click
from schemathesis import cli

_VALID_FORMATS = ("text", "html", "markdown")


class CsvFormatChoice(click.Choice):
    """Comma-separated coverage format values, mirroring schemathesis's CsvChoice pattern."""

    def __init__(self) -> None:
        super().__init__(_VALID_FORMATS)

    def convert(
        self,
        value: str | tuple[str, ...],
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> tuple[str, ...]:
        if isinstance(value, tuple):
            return value
        seen: set[str] = set()
        result = []
        for part in value.replace(",", " ").split():
            validated = super().convert(part, param, ctx)
            if validated not in seen:
                seen.add(validated)
                result.append(validated)
        return tuple(result) if result else ("html",)


group = cli.add_group("Coverage options")
group.add_option(
    "--coverage-format",
    help="Output format(s) for coverage reports, comma-separated (e.g. html,text)",
    type=CsvFormatChoice(),
    default="html",
    metavar="FORMAT",
    envvar="SCHEMATHESIS_COVERAGE_FORMAT",
)
group.add_option(
    "--coverage-report-path",
    help="File path for the HTML coverage report (--coverage-report-html-path takes priority)",
    type=click.Path(
        file_okay=True,
        dir_okay=False,
        writable=True,
        path_type=str,
    ),
    hidden=True,
    envvar="SCHEMATHESIS_COVERAGE_REPORT_PATH",
)
group.add_option(
    "--coverage-report-html-path",
    help="File path for the HTML coverage report",
    type=click.Path(
        file_okay=True,
        dir_okay=False,
        writable=True,
        path_type=str,
    ),
    default=None,
    envvar="SCHEMATHESIS_COVERAGE_REPORT_HTML_PATH",
)
group.add_option(
    "--coverage-report-markdown-path",
    help="File path for the Markdown coverage report",
    type=click.Path(
        file_okay=True,
        dir_okay=False,
        writable=True,
        path_type=str,
    ),
    default=None,
    envvar="SCHEMATHESIS_COVERAGE_REPORT_MARKDOWN_PATH",
)
group.add_option(
    "--coverage-no-report",
    help="Do not generate coverage report",
    is_flag=True,
    default=False,
    envvar="SCHEMATHESIS_COVERAGE_NO_REPORT",
)
group.add_option(
    "--coverage-show-missing",
    help="Show items with no coverage",
    type=click.Choice(["parameters"]),
    default=None,
    metavar="",
    envvar="SCHEMATHESIS_COVERAGE_SHOW_MISSING",
)
group.add_option(
    "--coverage-skip-covered",
    help="Skip operations with 100% coverage",
    is_flag=True,
    default=False,
    envvar="SCHEMATHESIS_COVERAGE_SKIP_COVERED",
)
group.add_option(
    "--coverage-skip-empty",
    help="Skip operations without any collected data",
    is_flag=True,
    default=False,
    envvar="SCHEMATHESIS_COVERAGE_SKIP_EMPTY",
)
group.add_option(
    "--coverage-markdown-report-url",
    help="URL of the full HTML report to link from the Markdown report footer",
    type=str,
    default=None,
    envvar="SCHEMATHESIS_COVERAGE_MARKDOWN_REPORT_URL",
)
group.add_option(
    "--coverage-markdown-weak-threshold",
    help=(
        "Parameter coverage percentage (0-100) below which an operation is flagged in the Markdown report"
        " (default: 100, flag any incomplete coverage)"
    ),
    type=click.IntRange(0, 100),
    default=None,
    envvar="SCHEMATHESIS_COVERAGE_MARKDOWN_WEAK_THRESHOLD",
)
group.add_option(
    "--coverage-markdown-is-pull-request",
    help="Enable PR consequence framing in the Markdown report headline",
    is_flag=True,
    default=False,
    envvar="SCHEMATHESIS_COVERAGE_MARKDOWN_IS_PULL_REQUEST",
)
