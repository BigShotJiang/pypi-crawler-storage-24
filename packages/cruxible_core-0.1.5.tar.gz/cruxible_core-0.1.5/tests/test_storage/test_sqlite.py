"""Tests for SQLite receipt storage."""

import pytest

from cruxible_core.receipt.builder import ReceiptBuilder
from cruxible_core.receipt.types import Receipt
from cruxible_core.storage.sqlite import SQLiteStore


@pytest.fixture
def store() -> SQLiteStore:
    return SQLiteStore(":memory:")


@pytest.fixture
def sample_receipt() -> Receipt:
    builder = ReceiptBuilder(query_name="parts_for_vehicle", parameters={"vehicle_id": "V-1"})
    builder.record_entity_lookup(entity_type="Vehicle", entity_id="V-1")
    tid = builder.record_traversal(
        from_entity_type="Vehicle",
        from_entity_id="V-1",
        to_entity_type="Part",
        to_entity_id="P-1",
        relationship="fits",
        edge_props={"verified": True},
    )
    builder.record_filter(filter_spec={"verified": True}, passed=True, parent_id=tid)
    results = [{"entity_type": "Part", "entity_id": "P-1"}]
    builder.record_results(results)
    return builder.build(results)


class TestSQLiteStore:
    def test_save_and_get(self, store: SQLiteStore, sample_receipt: Receipt):
        receipt_id = store.save_receipt(sample_receipt)
        assert receipt_id == sample_receipt.receipt_id

        loaded = store.get_receipt(receipt_id)
        assert loaded is not None
        assert loaded.receipt_id == sample_receipt.receipt_id
        assert loaded.query_name == "parts_for_vehicle"
        assert loaded.parameters == {"vehicle_id": "V-1"}
        assert len(loaded.nodes) == len(sample_receipt.nodes)
        assert len(loaded.edges) == len(sample_receipt.edges)
        assert len(loaded.results) == len(sample_receipt.results)

    def test_get_nonexistent(self, store: SQLiteStore):
        assert store.get_receipt("RCP-nonexistent") is None

    def test_save_overwrites(self, store: SQLiteStore, sample_receipt: Receipt):
        store.save_receipt(sample_receipt)
        store.save_receipt(sample_receipt)
        loaded = store.get_receipt(sample_receipt.receipt_id)
        assert loaded is not None

    def test_list_receipts(self, store: SQLiteStore, sample_receipt: Receipt):
        store.save_receipt(sample_receipt)

        items = store.list_receipts()
        assert len(items) == 1
        assert items[0]["receipt_id"] == sample_receipt.receipt_id
        assert items[0]["query_name"] == "parts_for_vehicle"
        assert items[0]["parameters"] == {"vehicle_id": "V-1"}
        assert store.count_receipts() == 1

    def test_list_filter_by_query_name(self, store: SQLiteStore):
        b1 = ReceiptBuilder(query_name="query_a", parameters={})
        b2 = ReceiptBuilder(query_name="query_b", parameters={})
        store.save_receipt(b1.build(results=[]))
        store.save_receipt(b2.build(results=[]))

        items = store.list_receipts(query_name="query_a")
        assert len(items) == 1
        assert items[0]["query_name"] == "query_a"
        assert store.count_receipts(query_name="query_a") == 1

    def test_list_limit_and_offset(self, store: SQLiteStore):
        for i in range(5):
            b = ReceiptBuilder(query_name="q", parameters={"i": i})
            store.save_receipt(b.build(results=[]))

        items = store.list_receipts(limit=2)
        assert len(items) == 2

        all_items = store.list_receipts(limit=10)
        assert len(all_items) == 5

        offset_items = store.list_receipts(limit=2, offset=3)
        assert len(offset_items) == 2

    def test_delete_receipt(self, store: SQLiteStore, sample_receipt: Receipt):
        store.save_receipt(sample_receipt)
        assert store.delete_receipt(sample_receipt.receipt_id) is True
        assert store.get_receipt(sample_receipt.receipt_id) is None

    def test_delete_nonexistent(self, store: SQLiteStore):
        assert store.delete_receipt("RCP-nonexistent") is False

    def test_list_empty(self, store: SQLiteStore):
        assert store.list_receipts() == []

    def test_receipt_preserves_dag_structure(
        self,
        store: SQLiteStore,
        sample_receipt: Receipt,
    ):
        store.save_receipt(sample_receipt)
        loaded = store.get_receipt(sample_receipt.receipt_id)

        node_types = {n.node_type for n in loaded.nodes}
        assert "query" in node_types
        assert "entity_lookup" in node_types
        assert "edge_traversal" in node_types
        assert "filter_applied" in node_types
        assert "result" in node_types

        edge_types = {e.edge_type for e in loaded.edges}
        assert "consulted" in edge_types
        assert "traversed" in edge_types
        assert "filtered" in edge_types
        assert "produced" in edge_types

    def test_get_receipts_for_entity(self, store: SQLiteStore, sample_receipt: Receipt):
        store.save_receipt(sample_receipt)
        ids = store.get_receipts_for_entity("Part", "P-1")
        assert sample_receipt.receipt_id in ids

    def test_receipt_entity_index_replaces_old_rows(self, store: SQLiteStore):
        builder = ReceiptBuilder(query_name="q", parameters={})
        builder.record_entity_lookup(entity_type="Vehicle", entity_id="V-1")
        first = builder.build(results=[])
        receipt_id = store.save_receipt(first)
        assert store.get_receipts_for_entity("Vehicle", "V-1") == [receipt_id]

        updated = first.model_copy()
        updated.nodes = []
        store.save_receipt(updated)
        assert store.get_receipts_for_entity("Vehicle", "V-1") == []

    def test_file_persistence(self, tmp_path):
        db_path = tmp_path / "test.db"
        store1 = SQLiteStore(db_path)

        b = ReceiptBuilder(query_name="q", parameters={"x": 1})
        receipt = b.build(results=[])
        store1.save_receipt(receipt)
        store1.close()

        store2 = SQLiteStore(db_path)
        loaded = store2.get_receipt(receipt.receipt_id)
        assert loaded is not None
        assert loaded.query_name == "q"
        store2.close()
