"""Platform configuration for multi-platform firmware development."""

from typing import TypedDict


class PlatformConfig(TypedDict):
    """Configuration for a specific firmware development platform."""

    name: str  # 顯示名稱，例如 "STM32 + Keil"
    forbidden_dirs: list[str]  # 禁止修改的目錄
    allowed_dirs: list[str]  # 允許修改的目錄
    stop_conditions: list[str]  # AI 停止修復的條件描述


# 平台配置字典
PLATFORMS: dict[str, PlatformConfig] = {
    "stm32_keil": {
        "name": "STM32 + Keil",
        "forbidden_dirs": ["SYSTEM", "CORE", "HALLIB", "HARDWARE"],
        "allowed_dirs": ["USER"],
        "stop_conditions": [
            "Error originates from SYSTEM/, CORE/, HALLIB/, or HARDWARE/ directories",
            "Missing header files (e.g., *.h not found)",
            "Requires downloading or installing any dependencies",
            "Requires modifying system configuration or compiler settings",
            "Involves HAL library, BSP files, or SDK file issues",
        ],
    },
    "am62x": {
        "name": "TI AM62x",
        "forbidden_dirs": [],  # AM62x 通常沒有禁止修改的目錄限制
        "allowed_dirs": [],  # 允許所有目錄
        "stop_conditions": [
            "Missing header files (e.g., *.h not found)",
            "Requires downloading or installing any dependencies",
            "Requires modifying system configuration or compiler settings",
        ],
    },
    "raspberry-pi": {
        "name": "Raspberry Pi",
        "forbidden_dirs": [],
        "allowed_dirs": [],
        "stop_conditions": [
            "Missing header files (e.g., *.h not found)",
            "Requires downloading or installing any dependencies",
            "Requires modifying system configuration or compiler settings",
        ],
    },
    "risc-v": {
        "name": "RISC-V",
        "forbidden_dirs": [],
        "allowed_dirs": [],
        "stop_conditions": [
            "Missing header files (e.g., *.h not found)",
            "Requires downloading or installing any dependencies",
            "Requires modifying system configuration or compiler settings",
        ],
    },
    "generic": {
        "name": "Generic Firmware",
        "forbidden_dirs": [],
        "allowed_dirs": [],
        "stop_conditions": [
            "Missing header files (e.g., *.h not found)",
            "Requires downloading or installing any dependencies",
            "Requires modifying system configuration or compiler settings",
        ],
    },
}


def get_platform_config(platform: str) -> PlatformConfig:
    """
    Get platform configuration by platform identifier.

    Args:
        platform: Platform identifier (e.g., 'stm32_keil')

    Returns:
        PlatformConfig dictionary

    Raises:
        ValueError: If platform is not supported
    """
    if platform not in PLATFORMS:
        raise ValueError(f"Unsupported platform: {platform}. Supported platforms: {', '.join(PLATFORMS.keys())}")
    return PLATFORMS[platform]


def list_platforms() -> list[str]:
    """List all supported platform identifiers."""
    return list(PLATFORMS.keys())
