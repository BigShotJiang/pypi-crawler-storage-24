"""FWAuto templates package."""
