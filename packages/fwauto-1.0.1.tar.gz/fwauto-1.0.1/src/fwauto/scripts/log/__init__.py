"""Log delegation scripts."""
