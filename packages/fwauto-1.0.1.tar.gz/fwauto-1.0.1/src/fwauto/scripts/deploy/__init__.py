"""Deploy delegation scripts."""
