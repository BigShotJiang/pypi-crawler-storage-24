import pyfiglet
from rich.console import Console
from rich.panel import Panel
from rich.align import Align
from rich import box

import time
class Banner:

    def __init__(self, console: Console):
        self.font="ansi_shadow"
        self.create_baner = pyfiglet.figlet_format
        self.console: Console = console

    def style_banner(self, name) -> str:
        banner = self.create_baner(name, font=self.font)
        panel = Panel(banner.strip("\n"), padding=(2, 1, 2, 1), box=box.SIMPLE_HEAD)
        self.console.print(Align.center(panel))

    def description_panel(self, description: str, title: str) -> None:
        panel = Panel(
            description, title=title, border_style='white', box=box.DOUBLE
        )
        self.console.print(panel, justify="center")

    def about(self) -> None:
        self.style_banner("ARES-V3")
        
    def home_banner(self) -> None:
        self.style_banner("ARES-V3")
        self.description_panel("[bold]ARES-V3  is standing by. All modules are optimized for speed and bypass-resiliency.", "[bold][cheetah=[green]Shadow-runner[/green]]")
