# SPDX-FileCopyrightText: 2024-2026 Nicholas Siemons and Adrian Yao
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Termination tape for wound electrode assemblies."""

from time import time
from steer_core.Constants.Units import *

from steer_core.Mixins.Coordinates import CoordinateMixin
from steer_core.Mixins.Datum import DatumMixin
from steer_core.Mixins.TypeChecker import ValidationMixin
from steer_core.Mixins.Dunder import DunderMixin
from steer_core.Mixins.Plotter import PlotterMixin
from steer_core.Mixins.Serializer import SerializerMixin
from steer_core.Mixins.Propagation import PropagationMixin, propagating_setter

from steer_core.Decorators.General import calculate_all_properties

from steer_opencell_design.Materials.Other import TapeMaterial

from typing import Tuple
from copy import deepcopy
import numpy as np


class Tape(
    CoordinateMixin,
    DatumMixin,
    ValidationMixin,
    DunderMixin,
    PlotterMixin,
    PropagationMixin,
    SerializerMixin,
    ):
    """Adhesive tape used to secure the outer wraps of wound jelly roll assemblies. Manages tape geometry (width, thickness) and material properties."""

    def __init__(
        self,
        material: TapeMaterial,
        thickness: float,
        width: float = None,
        length: float = None,
        datum: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        name: str = "Tape"
    ):
        """
        Initialize an object that represents insulating tape

        Parameters
        ----------
        material : TapeMaterial
            Material of the tape.
        thickness : float
            Thickness of the tape in um.
        width : float, optional
            Width of the tape in mm. If None, bulk properties won't be calculated until set.
        length : float, optional
            Length of the tape in mm. If None, bulk properties won't be calculated until set.
        datum : Tuple[float, float, float], optional
            Reference point (x, y, z) in mm. Defaults to (0.0, 0.0, 0.0).
        name : str, optional
            Name of the tape. Defaults to 'Tape'.
        """
        self._update_properties = False

        # Initialize _datum early so mixin properties work during component setup
        self._datum = tuple(float(d) * MM_TO_M for d in datum)

        self.thickness = thickness
        self.material = material
        self.datum = datum
        self.name = name

        # Set width and length after other properties
        if width is not None:
            self.width = width
        else:
            self._width = None

        if length is not None:
            self.length = length
        else:
            self._length = None

        self._calculate_all_properties()

        self._update_properties = True

    def _calculate_all_properties(self):
        """
        Calculate all properties of the separator.
        This method is called when length or width is set.
        """
        self._calculate_areal_properties()
        self._calculate_bulk_properties()

    def _calculate_areal_properties(self):
        """Calculate areal cost from material and thickness."""
        self._areal_cost = self._material._specific_cost * self._material._density * self._thickness

    def _calculate_bulk_properties(self):
        """
        Calculate bulk properties of the separator.
        Only calculates if both length and width are available.
        """
        if self._length is None or self._width is None:
            self._area = None
            self._mass = None
            self._cost = None
            self._pore_volume = None
            return

        self._area = self._length * self._width
        _mass = self._area * self._material._density * self._thickness
        mass = _mass * KG_TO_G
        self._material.mass = mass

        self._mass = self._material._mass
        self._cost = self._material._cost

    def _set_width_range(self, jellyroll, length_multiplier: float = 1.1):
        """Set the valid tape width range from the anode foil length."""

        self._width_range = (
            jellyroll._layup._anode._current_collector._y_foil_length, 
            jellyroll._layup._anode._current_collector._y_foil_length * length_multiplier
        )

    @property
    def areal_cost_range(self) -> Tuple[float, float]:
        """Get the allowable areal cost range in $/m²."""
        min = self._material._specific_cost_range[0] * self._material._density * self._thickness
        max = self._material._specific_cost_range[1] * self._material._density * self._thickness
        return (
            np.round(min, 2), 
            np.round(max, 2)
        )
            
    @property
    def cost(self) -> float:
        """Get the total tape cost in $."""
        if self._cost is None:
            return None
        return np.round(self._cost, 2)

    @property
    def mass(self) -> float:
        """Get the total tape mass in g."""
        if self._mass is None:
            return None
        return np.round(self._mass * KG_TO_G, 2)

    @property
    def area(self) -> float:
        """Get the total tape area in cm²."""
        if self._area is None:
            return None
        return np.round(self._area * M_TO_CM**2, 2)

    @property
    def areal_cost(self) -> float:
        """Get the areal cost of the tape in $/m²."""
        return np.round(self._areal_cost, 2)

    @property
    def name(self) -> str:
        """Get the tape name."""
        return self._name

    @property
    def length(self) -> float:
        """Get the tape length in mm."""
        if self._length is None:
            return None
        return np.round(self._length * M_TO_MM, 2)
    
    @property
    def length_range(self):
        """Get the allowable tape length range in mm."""
        return (0, 1000)

    @property
    def width(self) -> float:
        """Get the tape width in mm."""
        if self._width is None:
            return None
        return np.round(self._width * M_TO_MM, 2)

    @property
    def width_range(self):
        """Get the allowable tape width range in mm."""

        if hasattr(self, "_width_range"):
            return (
                np.round(self._width_range[0] * M_TO_MM, 2),
                np.round(self._width_range[1] * M_TO_MM, 2),
            )
        else:
            return (0, 300)

    @property
    def material(self) -> TapeMaterial:
        """Get the tape material."""
        return self._material

    @property
    def thickness(self):
        """Get the tape thickness in µm."""
        return np.round(self._thickness * M_TO_UM, 2)

    @property
    def thickness_range(self):
        """Get the allowable tape thickness range in µm."""
        return (0, 100)

    @areal_cost.setter
    @calculate_all_properties
    def areal_cost(self, areal_cost: float) -> None:
        self.validate_positive_float(areal_cost, "Areal Cost")
        new_material_specific_cost = areal_cost / (self.material._density * self._thickness)  # $/kg
        self._material.specific_cost = new_material_specific_cost

    @name.setter
    def name(self, name: str) -> None:
        self.validate_string(name, "Name")
        self._name = name

    @length.setter
    @calculate_all_properties
    def length(self, length: float) -> None:
        self.validate_positive_float(length, "Length")
        self._length = float(length) * MM_TO_M

    @width.setter
    @calculate_all_properties
    def width(self, width: float) -> None:
        self.validate_positive_float(width, "Width")
        self._width = float(width) * MM_TO_M

    @material.setter
    @calculate_all_properties
    @propagating_setter(deepcopy=True)
    def material(self, material: TapeMaterial) -> None:
        self.validate_type(material, TapeMaterial, "Material")
        self._material = material  # Already a copy due to decorator

    @thickness.setter
    @calculate_all_properties
    def thickness(self, thickness: float) -> None:
        self.validate_positive_float(thickness, "Thickness")
        self._thickness = float(thickness) * UM_TO_M

