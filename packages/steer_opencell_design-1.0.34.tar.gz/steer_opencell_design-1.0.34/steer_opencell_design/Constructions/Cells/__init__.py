# SPDX-FileCopyrightText: 2024-2026 Nicholas Siemons and Adrian Yao
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Complete battery cell definitions for cylindrical, prismatic, pouch, and flex-frame formats."""
