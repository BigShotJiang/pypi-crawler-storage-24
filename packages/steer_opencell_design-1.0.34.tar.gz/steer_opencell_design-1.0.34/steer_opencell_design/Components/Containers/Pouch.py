# SPDX-FileCopyrightText: 2024-2026 Nicholas Siemons and Adrian Yao
# SPDX-License-Identifier: AGPL-3.0-or-later

"""Pouch cell container components (laminate sheets, terminals, encapsulation)."""

from typing import Tuple

from steer_opencell_design.Components.Containers.Base import _Container
from steer_core.Utils import round_dict_recursive
from steer_core.Constants.Units import *

from steer_core.Mixins.Coordinates import CoordinateMixin
from steer_core.Mixins.Datum import DatumMixin
from steer_core.Mixins.TypeChecker import ValidationMixin
from steer_core.Mixins.Dunder import DunderMixin
from steer_core.Mixins.Plotter import PlotterMixin
from steer_core.Mixins.Serializer import SerializerMixin
from steer_core.Mixins.Propagation import PropagationMixin, propagating_setter

from steer_core.Decorators.General import calculate_all_properties
from steer_core.Decorators.Coordinates import calculate_coordinates

from steer_opencell_design.Materials.Other import CurrentCollectorMaterial, PrismaticContainerMaterial

from typing import Tuple
from copy import deepcopy
import numpy as np
import pandas as pd
import plotly.graph_objects as go


class LaminateSheet(
    CoordinateMixin,
    DatumMixin,
    ValidationMixin,
    PropagationMixin,
    DunderMixin,
    PlotterMixin,
    SerializerMixin,
    ):
    """Laminate film sheet for pouch cell packaging.

    Provides geometry, coordinates, and visualization traces for top and bottom laminate layers.
    """

    def __init__(
        self,
        areal_cost: float,
        density: float,
        thickness: float,
        datum: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        name: str = "Laminate Sheet"
    ):
        """
        Initialize an object that represents a laminate sheet

        Parameters
        ----------
        areal_cost : float
            Areal cost of the laminate in $/m².
        density : float
            Density of the laminate in g/cm^3.
        thickness : float
            Thickness of the laminate in um.
        datum : Tuple[float, float, float], optional
            Reference point (x, y, z) in mm. Defaults to (0.0, 0.0, 0.0).
        name : str, optional
            Name of the laminate sheet. Defaults to 'Laminate Sheet'.
        """
        self._update_properties = False

        self._hot_pressed = False

        # Initialize _datum early so mixin properties work during component setup
        self._datum = tuple(float(d) * MM_TO_M for d in datum)

        self.areal_cost = areal_cost
        self.density = density
        self.thickness = thickness
        self.datum = datum
        self.name = name

        # Initialize width and height as None
        self._width = None
        self._height = None

        self._calculate_all_properties()

        self._update_properties = True

    # Private functions
    def _calculate_all_properties(self):
        """
        Calculate all properties of the laminate sheet.
        This method is called when height or width is set.
        """
        self._calculate_bulk_properties()
        self._calculate_coordinates()

    def _calculate_bulk_properties(self):
        """
        Calculate bulk properties of the laminate sheet.
        Only calculates if both height and width are available.
        """
        if self._height is None or self._width is None:
            self._area = None
            self._mass = None
            self._cost = None
            return

        self._area = self._height * self._width
        self._mass = self._area * self._density * self._thickness
        self._cost = self._areal_cost * self._area

    def _calculate_coordinates(self):
        """Calculate top-down, right-left, and bottom-up view coordinates."""

        if self._width is None or self._height is None:
            return
        
        self._calculate_top_down_coordinates()
        self._calculate_right_left_coordinates()
        self._calculate_bottom_up_coordinates()

    def _calculate_top_down_coordinates(self):
        """Calculate the top-down (x-y) footprint coordinates."""
        
        x, y = self.build_square_array(
            self._datum[0] - self._width / 2,
            self._datum[1] - self._height / 2,
            self._width, 
            self._height
        )

        self._top_down_coordinates = np.column_stack((x, y))

        return self._top_down_coordinates

    def _generate_bucket_cross_section(self, axis: int, start: float, end: float, perpendicular_pos: float) -> np.ndarray:
        """Generate a bucket-shaped cross-section with smooth rounded corners.

        Creates a centerline path following the bucket profile, then extrudes it
        perpendicular to the surface to create top and bottom surfaces with
        constant thickness.  Transition zones sit entirely outside the cavity
        boundaries so the laminate reaches full depth exactly at the assembly
        edges.  Cosine interpolation gives C1-smooth (zero-slope) endpoints.
        """
        cavity_min = self._cavity_coordinates[:, axis].min()
        cavity_max = self._cavity_coordinates[:, axis].max()

        smooth_width = max(self._thickness * 0.5, abs(self._cavity_depth) * 0.2)

        def cosine_blend(coord_array: np.ndarray, z0: float, z1: float,
                         x_start: float, x_end: float) -> np.ndarray:
            """Smooth transition from z0 to z1 with zero slope at both ends."""
            t = np.clip((coord_array - x_start) / (x_end - x_start), 0.0, 1.0)
            blend = 0.5 * (1.0 - np.cos(np.pi * t))
            return z0 + (z1 - z0) * blend

        # Adaptive point counts proportional to segment length
        min_pts = 6
        total_pts = 200
        seg_lengths = [
            abs(cavity_min - smooth_width - start),
            smooth_width,
            abs(cavity_max - cavity_min),
            smooth_width,
            abs(end - (cavity_max + smooth_width)),
        ]
        length_sum = sum(seg_lengths) or 1.0
        seg_pts = [max(min_pts, int(round(total_pts * l / length_sum))) for l in seg_lengths]

        centerline_z = perpendicular_pos - self._thickness / 2
        cavity_z = centerline_z - self._cavity_depth

        # Segment 1: Left flat (seal region)
        left_flat = np.linspace(start, cavity_min - smooth_width, seg_pts[0])
        z_left_flat = np.full(seg_pts[0], centerline_z)

        # Segment 2: Left transition — entirely outside cavity boundary
        trans_left_start = cavity_min - smooth_width
        trans_left_end = cavity_min
        left_corner = np.linspace(trans_left_start, trans_left_end, seg_pts[1])
        z_left_corner = cosine_blend(left_corner, centerline_z, cavity_z,
                                     trans_left_start, trans_left_end)

        # Segment 3: Cavity flat (spans full assembly width/height)
        cavity_flat = np.linspace(cavity_min, cavity_max, seg_pts[2])
        z_cavity_flat = np.full(seg_pts[2], cavity_z)

        # Segment 4: Right transition — entirely outside cavity boundary
        trans_right_start = cavity_max
        trans_right_end = cavity_max + smooth_width
        right_corner = np.linspace(trans_right_start, trans_right_end, seg_pts[3])
        z_right_corner = cosine_blend(right_corner, cavity_z, centerline_z,
                                      trans_right_start, trans_right_end)

        # Segment 5: Right flat (seal region)
        right_flat = np.linspace(cavity_max + smooth_width, end, seg_pts[4])
        z_right_flat = np.full(seg_pts[4], centerline_z)

        centerline_coords = np.concatenate([
            left_flat, left_corner, cavity_flat, right_corner, right_flat
        ])
        centerline_z_all = np.concatenate([
            z_left_flat, z_left_corner, z_cavity_flat, z_right_corner, z_right_flat
        ])

        # Extrude perpendicular to the surface (normal-based offset)
        half_t = self._thickness / 2
        n = len(centerline_coords)

        dc = np.empty(n)
        dz = np.empty(n)
        dc[1:-1] = centerline_coords[2:] - centerline_coords[:-2]
        dz[1:-1] = centerline_z_all[2:] - centerline_z_all[:-2]
        dc[0] = centerline_coords[1] - centerline_coords[0]
        dz[0] = centerline_z_all[1] - centerline_z_all[0]
        dc[-1] = centerline_coords[-1] - centerline_coords[-2]
        dz[-1] = centerline_z_all[-1] - centerline_z_all[-2]

        mag = np.sqrt(dc * dc + dz * dz)
        mag[mag == 0] = 1.0
        nx = -dz / mag
        nz = dc / mag

        top_coords = centerline_coords + half_t * nx
        top_z = centerline_z_all + half_t * nz
        bot_coords = centerline_coords[::-1] - half_t * nx[::-1]
        bot_z = centerline_z_all[::-1] - half_t * nz[::-1]

        all_coords = np.concatenate([top_coords, bot_coords, [top_coords[0]]])
        all_z = np.concatenate([top_z, bot_z, [top_z[0]]])

        return np.column_stack((all_coords, all_z))

    def _calculate_right_left_coordinates(self):
        """Calculate the side cross-section coordinates (right/left view)."""
        
        if not self._hot_pressed:
            # Simple flat sheet - rectangular cross-section
            y, z = self.build_square_array(
                self._datum[1] - self._height / 2,
                self._datum[2] - self._thickness / 2,
                self._height,
                self._thickness
            )
            self._right_left_coordinates = np.column_stack((y, z))
        else:
            # Hot-pressed sheet with bucket-shaped dip
            start = self._datum[1] - self._height / 2
            end = self._datum[1] + self._height / 2
            top_z = self._datum[2] + self._thickness / 2
            
            self._right_left_coordinates = self._generate_bucket_cross_section(
                axis=1,  # y-axis
                start=start,
                end=end,
                perpendicular_pos=top_z
            )

        return self._right_left_coordinates

    def _calculate_bottom_up_coordinates(self):
        """Calculate the front/back cross-section coordinates (bottom-up view)."""
        
        if not self._hot_pressed:
            # Simple flat sheet - rectangular cross-section
            x, z = self.build_square_array(
                self._datum[0] - self._width / 2,
                self._datum[2] - self._thickness / 2,
                self._width,
                self._thickness
            )
            self._bottom_up_coordinates = np.column_stack((x, z))
        else:
            # Hot-pressed sheet with bucket-shaped dip
            start = self._datum[0] - self._width / 2
            end = self._datum[0] + self._width / 2
            top_z = self._datum[2] + self._thickness / 2
            
            self._bottom_up_coordinates = self._generate_bucket_cross_section(
                axis=0,  # x-axis
                start=start,
                end=end,
                perpendicular_pos=top_z
            )

        return self._bottom_up_coordinates
    
    @calculate_coordinates
    def _hot_press(
        self, 
        _depth: float, 
        _width: float, 
        _height: float,
        _datum: Tuple[float, float] = (0.0, 0.0)
    ) -> None:
        """Set the laminate as hot-pressed and recalculate coordinates."""
        self._set_hot_press_state(_depth, _width, _height, _datum)

    def _set_hot_press_state(
        self,
        _depth: float,
        _width: float,
        _height: float,
        _datum: Tuple[float, float] = (0.0, 0.0)
    ) -> None:
        """Set hot-press state without triggering coordinate recalculation.

        Use this when the caller will handle coordinate recalculation
        (e.g. during batch encapsulation updates).
        """
        if _width > self._width or _height > self._height:
            raise ValueError("Cavity dimensions exceed laminate dimensions.")

        if _depth == 0:
            self._hot_pressed = False
            return 

        self._hot_pressed = True
        self._cavity_depth = _depth

        _cavity_x = self._datum[0] + _datum[0]
        _cavity_y = self._datum[1] + _datum[1]

        x, y = self.build_square_array(
            _cavity_x - _width / 2,
            _cavity_y - _height / 2,
            _width,
            _height
        )

        if min(y) < min(self._top_down_coordinates[:, 1]) or max(y) > max(self._top_down_coordinates[:, 1]):
            raise ValueError("Cavity height exceeds laminate height.")
        if min(x) < min(self._top_down_coordinates[:, 0]) or max(x) > max(self._top_down_coordinates[:, 0]):
            raise ValueError("Cavity width exceeds laminate width.")

        self._cavity_coordinates = np.column_stack((x, y))

    # Public functions
    def plot_top_down_view(self, **kwargs) -> go.Figure:
        """Get a Plotly Figure showing the top-down view of the laminate sheet.
        
        Returns a go.Figure with the laminate sheet footprint.
        """
        import plotly.graph_objects as go
        
        if not hasattr(self, '_top_down_coordinates') or self._top_down_coordinates is None:
            return go.Figure()
        
        fig = go.Figure()
        fig.add_trace(self.top_down_trace)
        
        fig.update_layout(
            xaxis=self.SCHEMATIC_X_AXIS,
            yaxis=self.SCHEMATIC_Y_AXIS,
            paper_bgcolor=kwargs.get("paper_bgcolor", "white"),
            plot_bgcolor=kwargs.get("plot_bgcolor", "white"),
            **kwargs,
        )
        
        return fig

    def plot_right_left_view(self, **kwargs) -> go.Figure:
        """Get a Plotly Figure showing the right-left (side) view of the laminate sheet.
        
        Returns a go.Figure with the laminate sheet cross-section.
        """
        import plotly.graph_objects as go
        
        if not hasattr(self, '_right_left_coordinates') or self._right_left_coordinates is None:
            return go.Figure()
        
        fig = go.Figure()
        fig.add_trace(self.right_left_trace)
        
        fig.update_layout(
            xaxis=self.SCHEMATIC_Y_AXIS,
            yaxis=self.SCHEMATIC_Z_AXIS,
            paper_bgcolor=kwargs.get("paper_bgcolor", "white"),
            plot_bgcolor=kwargs.get("plot_bgcolor", "white"),
            **kwargs,
        )
        
        return fig

    def plot_bottom_up_view(self, **kwargs) -> go.Figure:
        """Get a Plotly Figure showing the bottom-up view of the laminate sheet.
        
        Returns a go.Figure with the laminate sheet cross-section.
        """
        import plotly.graph_objects as go
        
        if not hasattr(self, '_bottom_up_coordinates') or self._bottom_up_coordinates is None:
            return go.Figure()
        
        fig = go.Figure()
        fig.add_trace(self.bottom_up_trace)
        
        fig.update_layout(
            xaxis=self.SCHEMATIC_X_AXIS,
            yaxis=self.SCHEMATIC_Z_AXIS,
            paper_bgcolor=kwargs.get("paper_bgcolor", "white"),
            plot_bgcolor=kwargs.get("plot_bgcolor", "white"),
            **kwargs,
        )
        
        return fig

    # Properties
    @property
    def cost(self) -> float:
        """Sheet cost in $."""
        if self._cost is None:
            return None
        return np.round(self._cost, 2)

    @property
    def mass(self) -> float:
        """Sheet mass in g."""
        if self._mass is None:
            return None
        return np.round(self._mass * KG_TO_G, 2)

    @property
    def area(self) -> float:
        """Sheet area in cm²."""
        if self._area is None:
            return None
        return np.round(self._area * M_TO_CM**2, 2)

    @property
    def areal_cost(self) -> float:
        """Areal cost in $/m²."""
        return np.round(self._areal_cost, 2)

    @property
    def areal_cost_range(self):
        """Valid areal cost range in $/m²."""
        return (0, 0.1)
    
    @property
    def areal_cost_hard_range(self):
        """Hard limit areal cost range in $/m²."""
        return (0, 1)

    @property
    def name(self) -> str:
        """Display name."""
        return self._name

    @property
    def height(self) -> float:
        """Sheet height in mm."""
        if self._height is None:
            return None
        return np.round(self._height * M_TO_MM, 2)
    
    @property
    def height_range(self):
        """Valid height range in mm."""
        return (0, 1000)

    @property
    def width(self) -> float:
        """Sheet width in mm."""
        if self._width is None:
            return None
        return np.round(self._width * M_TO_MM, 2)

    @property
    def width_range(self):
        """Valid width range in mm."""

        if hasattr(self, "_width_range"):
            return (
                np.round(self._width_range[0] * M_TO_MM, 2),
                np.round(self._width_range[1] * M_TO_MM, 2),
            )
        else:
            return (0, 500)

    @property
    def density(self) -> float:
        """Density in g/cm³."""
        return np.round(self._density * KG_TO_G / M_TO_CM**3, 2)
    
    @property
    def density_range(self):
        """Valid density range in g/cm³."""
        return (0, 5)

    @property
    def thickness(self):
        """Sheet thickness in µm."""
        return np.round(self._thickness * M_TO_UM, 2)

    @property
    def thickness_range(self):
        """Valid thickness range in µm."""
        return (0, 100)

    @property
    def top_down_coordinates(self):
        """Get the top-down coordinates in mm.
        
        Returns coordinates as a DataFrame with 'x' and 'y' columns.
        """
        if not hasattr(self, '_top_down_coordinates') or self._top_down_coordinates is None:
            return None
        
        # Perform operations on numpy array first for speed
        coords_mm = self._top_down_coordinates * M_TO_MM
        coords_rounded = np.round(coords_mm, 5)
        return pd.DataFrame(coords_rounded, columns=['X (mm)', 'Y (mm)'])

    @property
    def right_left_coordinates(self):
        """Get the right-left (side) cross-section coordinates in mm.
        
        Returns coordinates as a DataFrame with 'y' and 'z' columns.
        """
        if not hasattr(self, '_right_left_coordinates') or self._right_left_coordinates is None:
            return None
        
        coords_mm = self._right_left_coordinates * M_TO_MM
        coords_rounded = np.round(coords_mm, 5)
        return pd.DataFrame(coords_rounded, columns=['y', 'z'])

    @property
    def bottom_up_coordinates(self):
        """Get the bottom-up cross-section coordinates in mm.
        
        Returns coordinates as a DataFrame with 'x' and 'z' columns.
        """
        if not hasattr(self, '_bottom_up_coordinates') or self._bottom_up_coordinates is None:
            return None
        
        coords_mm = self._bottom_up_coordinates * M_TO_MM
        coords_rounded = np.round(coords_mm, 5)
        return pd.DataFrame(coords_rounded, columns=['x', 'z'])

    @property
    def right_left_trace(self):
        """Get a Plotly Scatter trace for the right-left (side) view.
        
        Returns a go.Scatter trace showing the cross-section of the laminate sheet.
        """
        import plotly.graph_objects as go
        
        if not hasattr(self, '_right_left_coordinates') or self._right_left_coordinates is None:
            return None
        
        coords = self.right_left_coordinates
        
        trace = go.Scatter(
            x=coords['y'],
            y=coords['z'],
            mode='lines',
            name=self._name,
            line=dict(color='rgb(128, 128, 128)', width=1),
            fill='toself',
            fillcolor='rgba(211, 211, 211, 1.0)',
            legendgroup='Laminate Sheet',
            showlegend=True,
            line_shape='spline',
        )
        
        return trace

    @property
    def bottom_up_trace(self):
        """Get a Plotly Scatter trace for the bottom-up view.
        
        Returns a go.Scatter trace showing the cross-section of the laminate sheet.
        """
        import plotly.graph_objects as go
        
        if not hasattr(self, '_bottom_up_coordinates') or self._bottom_up_coordinates is None:
            return None
        
        coords = self.bottom_up_coordinates
        
        trace = go.Scatter(
            x=coords['x'],
            y=coords['z'],
            mode='lines',
            name=self._name,
            line=dict(color='rgb(128, 128, 128)', width=1),
            fill='toself',
            fillcolor='rgba(211, 211, 211, 1.0)',
            legendgroup='Laminate Sheet',
            showlegend=True,
            line_shape='spline',
        )
        
        return trace

    @property
    def top_down_trace(self):
        """Get a Plotly Scatter trace for the top-down view.
        
        Returns a go.Scatter trace showing the laminate sheet footprint.
        """
        import plotly.graph_objects as go
        
        if not hasattr(self, '_top_down_coordinates') or self._top_down_coordinates is None:
            return None
        
        coords = self.top_down_coordinates
        
        trace = go.Scatter(
            x=coords['X (mm)'],
            y=coords['Y (mm)'],
            mode='lines',
            name=self._name,
            line=dict(color='black', width=1),
            fill='toself',
            fillcolor='rgba(211, 211, 211, 1.0)',
            legendgroup='Laminate Sheet',
            showlegend=True,
        )
        
        return trace

    # Setters
    @areal_cost.setter
    @calculate_all_properties
    def areal_cost(self, areal_cost: float) -> None:
        self.validate_positive_float(areal_cost, "Areal Cost")
        self._areal_cost = float(areal_cost)

    @density.setter
    @calculate_all_properties
    def density(self, density: float) -> None:
        self.validate_positive_float(density, "Density")
        self._density = float(density) * G_TO_KG / CM_TO_M**3

    # Override datum setter to use decorator
    @DatumMixin.datum.setter
    @calculate_coordinates
    def datum(self, datum: Tuple[float, float, float]) -> None:
        """Set the datum position in mm."""
        self.validate_datum(datum)
        self._datum = tuple(coord * MM_TO_M for coord in datum)

    @name.setter
    def name(self, name: str) -> None:
        self.validate_string(name, "Name")
        self._name = name

    @height.setter
    @calculate_all_properties
    def height(self, height: float) -> None:
        self.validate_positive_float(height, "Height")
        self._height = float(height) * MM_TO_M

    @width.setter
    @calculate_all_properties
    def width(self, width: float) -> None:
        self.validate_positive_float(width, "Width")
        self._width = float(width) * MM_TO_M

    @thickness.setter
    @calculate_all_properties
    def thickness(self, thickness: float) -> None:
        self.validate_positive_float(thickness, "Thickness")
        self._thickness = float(thickness) * UM_TO_M


class PouchTerminal(
    CoordinateMixin,
    DatumMixin,
    ValidationMixin,
    PropagationMixin,
    DunderMixin,
    PlotterMixin,
    SerializerMixin
):
    """
    A pouch terminal connector component with rectangular prismatic geometry.
    
    The PouchTerminal represents a terminal tab that extends from a pouch cell,
    typically made from metal materials like aluminum or copper. It has a 
    rectangular cross-section defined by width, length, and height.
    """

    def __init__(
        self,
        material,
        width: float,
        length: float,
        thickness: float,
        datum: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        name: str = "Pouch Terminal",
    ):
        """
        Initialize a pouch terminal connector.
        
        Parameters
        ----------
        material : PrismaticContainerMaterial
            Material for the terminal (typically metal).
        width : float
            Width of the terminal in mm. Must be positive.
        length : float
            Length of the terminal in mm. Must be positive.
        thickness : float
            Thickness of the terminal in mm. Must be positive.
        datum : Tuple[float, float, float], optional
            Center position in mm as (x, y, z) coordinates. Defaults to (0.0, 0.0, 0.0).
        name : str, optional
            Component identifier name. Defaults to "Pouch Terminal".
            
        Raises
        ------
        ValueError
            If width, length, or thickness <= 0 when provided.
        """
        self._update_properties = False

        # Initialize _datum early so mixin properties work during component setup
        self._datum = tuple(float(d) * MM_TO_M for d in datum)

        self.material = material
        self.width = width
        self.length = length
        self.thickness = thickness
        self.datum = datum
        self.name = name

        self._update_properties = True
        self._calculate_all_properties()

    def _calculate_all_properties(self):
        """Calculate all properties of the terminal."""
        self._calculate_bulk_properties()
        self._calculate_coordinates()

    def _calculate_bulk_properties(self):
        """Calculate volume, mass, and cost of the terminal."""
        # Volume in m³
        _volume = self._width * self._length * self._thickness
        volume = _volume * M_TO_CM**3
        self._material.volume = volume

        self._volume = self._material._volume
        self._mass = self._material._mass
        self._cost = self._material._cost

    def _calculate_coordinates(self):
        """Calculate the 3D coordinates of the terminal."""
        self._calculate_top_down_coordinates()
        self._calculate_right_left_coordinates()

    def _calculate_top_down_coordinates(self):
        """Calculate top-down view coordinates."""
        x, y = self.build_square_array(
            self._datum[0] - self._width / 2,
            self._datum[1] - self._length / 2,
            self._width,
            self._length
        )
        self._top_down_coordinates = np.column_stack((x, y))
        return self._top_down_coordinates

    def _calculate_right_left_coordinates(self):
        """Calculate right-left view coordinates."""
        x, z = self.build_square_array(
            self._datum[1] - self._length / 2,
            self._datum[2] - self._thickness / 2,
            self._length,
            self._thickness
        )
        self._right_left_coordinates = np.column_stack((x, z))
        return self._right_left_coordinates

    # Properties
    @property
    def right_left_coordinates(self):
        """Get the right-left coordinates in mm.
        
        Returns coordinates as a DataFrame with 'x' and 'z' columns.
        """
        # Perform operations on numpy array first for speed
        coords_mm = self._right_left_coordinates * M_TO_MM
        coords_rounded = np.round(coords_mm, 5)
        return pd.DataFrame(coords_rounded, columns=['X (mm)', 'Z (mm)'])
    
    @property
    def right_left_trace(self):
        """Get a Plotly Scatter trace for the right-left view.
        
        Returns a go.Scatter trace showing the terminal cross-section.
        """
        import plotly.graph_objects as go
        
        coords = self.right_left_coordinates
        
        trace = go.Scatter(
            x=coords['X (mm)'],
            y=coords['Z (mm)'],
            mode='lines',
            name=self._name,
            line=dict(color='black', width=1),
            fill='toself',
            fillcolor=self._material._color,
            legendgroup='Pouch Terminal',
            showlegend=True,
        )
        
        return trace

    @property
    def volume(self) -> float:
        """Volume in cm³."""
        return np.round(self._volume * M_TO_CM**3, 2)

    @property
    def mass(self) -> float:
        """Mass in g."""
        return np.round(self._mass * KG_TO_G, 2)

    @property
    def cost(self) -> float:
        """Cost in $."""
        return np.round(self._cost, 2)

    @property
    def width(self) -> float:
        """Width in mm."""
        return np.round(self._width * M_TO_MM, 2)

    @property
    def width_range(self):
        """Width range in mm."""
        return (0, 100)

    @property
    def length(self) -> float:
        """Length in mm."""
        return np.round(self._length * M_TO_MM, 2)

    @property
    def length_range(self):
        """Length range in mm."""
        return (0, 200)

    @property
    def thickness(self) -> float:
        """Thickness in mm."""
        return np.round(self._thickness * M_TO_MM, 2)

    @property
    def thickness_range(self):
        """Thickness range in mm."""
        return (0, 50)

    @property
    def name(self) -> str:
        """Component name."""
        return self._name

    @property
    def material(self) -> PrismaticContainerMaterial:
        """Get material."""
        return self._material
    
    @property
    def top_down_coordinates(self):
        """Get the top-down coordinates in mm.
        
        Returns coordinates as a DataFrame with 'x' and 'y' columns.
        """
        # Perform operations on numpy array first for speed
        coords_mm = self._top_down_coordinates * M_TO_MM
        coords_rounded = np.round(coords_mm, 5)
        return pd.DataFrame(coords_rounded, columns=['X (mm)', 'Y (mm)'])
    
    @property
    def top_down_trace(self):
        """Get a Plotly Scatter trace for the top-down view.
        
        Returns a go.Scatter trace showing the terminal footprint.
        """
        import plotly.graph_objects as go
        
        coords = self.top_down_coordinates
        
        trace = go.Scatter(
            x=coords['X (mm)'],
            y=coords['Y (mm)'],
            mode='lines',
            name=self._name,
            line=dict(color='black', width=1),
            fill='toself',
            fillcolor=self._material._color,
            legendgroup='Pouch Terminal',
            showlegend=True,
        )
        
        return trace

    @material.setter
    @propagating_setter(deepcopy=True)
    def material(self, material: PrismaticContainerMaterial | CurrentCollectorMaterial | None) -> None:
        """Set material."""

        if material is not None:
            self.validate_type(material, (PrismaticContainerMaterial, CurrentCollectorMaterial), "Material")

        self._material = material

    @width.setter
    @calculate_all_properties
    def width(self, width: float) -> None:
        """Set width in mm."""
        self.validate_positive_float(width, "Width")
        self._width = float(width) * MM_TO_M

    @length.setter
    @calculate_all_properties
    def length(self, length: float) -> None:
        """Set length in mm."""
        self.validate_positive_float(length, "Length")
        self._length = float(length) * MM_TO_M

    @thickness.setter
    @calculate_all_properties
    def thickness(self, thickness: float) -> None:
        """Set thickness in mm."""
        self.validate_positive_float(thickness, "Thickness")
        self._thickness = float(thickness) * MM_TO_M

    # Override datum setter to use decorator
    @DatumMixin.datum.setter
    @calculate_coordinates
    def datum(self, datum: Tuple[float, float, float]) -> None:
        """Set datum position in mm."""
        self.validate_datum(datum)
        self._datum = tuple(coord * MM_TO_M for coord in datum)

    @name.setter
    def name(self, name: str) -> None:
        """Set component name."""
        self.validate_string(name, "Name")
        self._name = name


class PouchEncapsulation(_Container, DatumMixin):
    """Complete pouch cell encapsulation combining top/bottom laminate sheets and terminals.

    Manages pouch geometry, hot-pressing cavity formation, and provides mass/cost breakdowns.
    """

    def __init__(
            self,
            cathode_terminal: PouchTerminal,
            anode_terminal: PouchTerminal,
            top_laminate: LaminateSheet,
            bottom_laminate: LaminateSheet,
            width: float = None,
            height: float = None,
            thickness: float = None,
            name: str = "Pouch Encapsulation",
            datum: Tuple[float, float, float] = (0.0, 0.0, 0.0)
        ):

        self._update_properties = False
        self._terminals_positioned = False
        
        # Initialize _datum early so mixin properties work during component setup
        self._datum = tuple(float(d) * MM_TO_M for d in datum)
        
        # Initialize volume to None
        self._volume = None
        
        self.cathode_terminal = cathode_terminal
        self.anode_terminal = anode_terminal
        self.top_laminate = top_laminate
        self.bottom_laminate = bottom_laminate
        self.name = name
        self.datum = datum
        
        self.width = width
        self.height = height
        self.thickness = thickness

        self._update_properties = True
        self._calculate_all_properties()

    def _calculate_all_properties(self):
        """Calculate all properties of the pouch encapsulation."""
        self._top_laminate._calculate_all_properties()
        self._bottom_laminate._calculate_all_properties()
        self._calculate_bulk_properties()
        self._calculate_coordinates()

    def _calculate_bulk_properties(self):
        
        """Calculate bulk properties including volume, mass, and cost."""

        if self._top_laminate._mass is not None and self._bottom_laminate._mass is not None:
            self._calculate_mass()
        if self._top_laminate._cost is not None and self._bottom_laminate._cost is not None:
            self._calculate_cost()
        if self._top_laminate._mass is not None and self._bottom_laminate._mass is not None and self._thickness is not None and self._terminals_positioned:
            self._calculate_volume()

    def _calculate_coordinates(self):
        """Calculate coordinates for all components."""
        # Position laminates relative to datum
        # Top laminate above datum
        if self.top_laminate.width is not None and self.top_laminate.height is not None:

            self._top_laminate.datum = (
                self._datum[0] * M_TO_MM,
                self._datum[1] * M_TO_MM,
                (self._datum[2] + self._top_laminate._thickness / 2) * M_TO_MM
            )
        
        # Bottom laminate below datum
        if self.bottom_laminate.width is not None and self.bottom_laminate.height is not None:

            self._bottom_laminate.datum = (
                self._datum[0] * M_TO_MM,
                self._datum[1] * M_TO_MM,
                (self._datum[2] - self._bottom_laminate._thickness / 2) * M_TO_MM
            )

    def _calculate_mass(self):
        """Calculate total mass and mass breakdown."""
        cathode_mass = self._cathode_terminal._mass
        anode_mass = self._anode_terminal._mass
        
        top_laminate_mass = self._top_laminate._mass
        bottom_laminate_mass = self._bottom_laminate._mass
        
        self._mass = cathode_mass + anode_mass + top_laminate_mass + bottom_laminate_mass
        
        self._mass_breakdown = {
            "Cathode Terminal": cathode_mass,
            "Anode Terminal": anode_mass,
            "Laminates": top_laminate_mass + bottom_laminate_mass
        }

    def _calculate_cost(self):
        """Calculate total cost and cost breakdown."""
        cathode_cost = self._cathode_terminal._cost
        anode_cost = self._anode_terminal._cost
        
        top_laminate_cost = self._top_laminate._cost
        bottom_laminate_cost = self._bottom_laminate._cost
        
        self._cost = cathode_cost + anode_cost + top_laminate_cost + bottom_laminate_cost
        
        self._cost_breakdown = {
            "Cathode Terminal": cathode_cost,
            "Anode Terminal": anode_cost,
            "Top Laminate": top_laminate_cost,
            "Bottom Laminate": bottom_laminate_cost
        }

    def _calculate_volume(self):
        """Calculate the volume of the encapsulation."""

        if self._thickness is None or not self._terminals_positioned:
            self._volume = None
            return
        
        # aggregate the coordinates to find max width and height
        _coordinates = np.vstack((
            self._top_laminate._top_down_coordinates,
            self._bottom_laminate._top_down_coordinates,
            self._cathode_terminal._top_down_coordinates,
            self._anode_terminal._top_down_coordinates
        ))

        _max_x = np.max(_coordinates[:, 0])
        _min_x = np.min(_coordinates[:, 0])
        _max_y = np.max(_coordinates[:, 1])
        _min_y = np.min(_coordinates[:, 1])

        _width = _max_x - _min_x
        _height = _max_y - _min_y

        self._volume = _width * _height * self._thickness

    def plot_side_view(self, **kwargs) -> go.Figure:
        """Get a Plotly Figure showing the side view of the pouch encapsulation."""        
        traces = []
        traces.append(self._cathode_terminal.right_left_trace)
        traces.append(self._anode_terminal.right_left_trace)
        traces.append(self._top_laminate.right_left_trace)
        traces.append(self._bottom_laminate.right_left_trace)

        fig = go.Figure(data=traces)

        # Apply layout
        fig.update_layout(
            xaxis=self.SCHEMATIC_X_AXIS,
            yaxis=self.SCHEMATIC_Y_AXIS,
            paper_bgcolor=kwargs.get("paper_bgcolor", "white"),
            plot_bgcolor=kwargs.get("plot_bgcolor", "white"),
            **kwargs,
        )

        return fig
    
    def plot_top_down_view(self, **kwargs) -> go.Figure:
        """Get a Plotly Figure showing the top view of the pouch encapsulation."""        
        traces = []
        traces.append(self._bottom_laminate.top_down_trace)
        traces.append(self._cathode_terminal.top_down_trace)
        traces.append(self._anode_terminal.top_down_trace)
        traces.append(self._top_laminate.top_down_trace)

        fig = go.Figure(data=traces)

        # Apply layout
        fig.update_layout(
            xaxis=self.SCHEMATIC_X_AXIS,
            yaxis=self.SCHEMATIC_Y_AXIS,
            paper_bgcolor=kwargs.get("paper_bgcolor", "white"),
            plot_bgcolor=kwargs.get("plot_bgcolor", "white"),
            **kwargs,
        )

        return fig

    @property
    def thickness(self) -> float:
        """Get thickness of the encapsulation in mm."""
        if self._thickness is None:
            return None
        return np.round(self._thickness * M_TO_MM, 2)
    
    @property
    def volume(self) -> float:
        """Total volume in cm³."""
        if self._volume is None:
            return None
        return np.round(self._volume * M_TO_CM**3, 2)
    
    @property
    def mass(self) -> float:
        """Total mass in g."""
        return np.round(self._mass * KG_TO_G, 2)

    @property
    def cost(self) -> float:
        """Total cost in $."""
        return np.round(self._cost, 2)

    @property
    def name(self) -> str:
        """Encapsulation name."""
        return self._name

    @property
    def cathode_terminal(self) -> PouchTerminal:
        """Cathode terminal component."""
        return self._cathode_terminal

    @property
    def anode_terminal(self) -> PouchTerminal:
        """Anode terminal component."""
        return self._anode_terminal

    @property
    def top_laminate(self) -> LaminateSheet:
        """Top laminate sheet."""
        return self._top_laminate

    @property
    def bottom_laminate(self) -> LaminateSheet:
        """Bottom laminate sheet."""
        return self._bottom_laminate

    @property
    def width(self) -> float:
        """Width of the laminate sheets in mm."""
        return self._top_laminate.width

    @property
    def height(self) -> float:
        """Height of the laminate sheets in mm."""
        return self._top_laminate.height

    @property
    def mass_breakdown(self) -> dict:
        """Mass breakdown by component in g."""
        return round_dict_recursive(self._mass_breakdown, 2, KG_TO_G)

    @property
    def cost_breakdown(self) -> dict:
        """Cost breakdown by component in $."""
        return round_dict_recursive(self._cost_breakdown, 2)

    @thickness.setter
    @calculate_all_properties
    def thickness(self, thickness: float) -> None:
        """Set thickness of both laminate sheets in mm."""
        if thickness is None:
            self._thickness = None
            return
        self.validate_positive_float(thickness, "Thickness")
        self._thickness = float(thickness) * MM_TO_M

    # Override datum setter to use decorator
    @DatumMixin.datum.setter
    @calculate_all_properties
    def datum(self, value: Tuple[float, float, float]) -> None:
        """Set datum position in mm."""
        self.validate_datum(value)
        self._datum = tuple(coord * MM_TO_M for coord in value)

    @name.setter
    def name(self, name: str) -> None:
        """Set encapsulation name."""
        self.validate_string(name, "Name")
        self._name = name
            
    @cathode_terminal.setter
    @calculate_all_properties
    @propagating_setter()
    def cathode_terminal(self, terminal: PouchTerminal) -> None:
        """Set cathode terminal."""

        self.validate_type(terminal, PouchTerminal, "Cathode Terminal")

        if 'cathode' not in terminal.name.lower():
            terminal.name = f"{terminal.name} (Cathode)"

        self._cathode_terminal = terminal

    @anode_terminal.setter
    @calculate_all_properties
    @propagating_setter()
    def anode_terminal(self, terminal: PouchTerminal) -> None:
        """Set anode terminal."""

        self.validate_type(terminal, PouchTerminal, "Anode Terminal")

        if 'anode' not in terminal.name.lower():
            terminal.name = f"{terminal.name} (Anode)"

        self._anode_terminal = terminal

    @top_laminate.setter
    @calculate_all_properties
    @propagating_setter()
    def top_laminate(self, laminate: LaminateSheet) -> None:
        """Set top laminate sheet."""
        self.validate_type(laminate, LaminateSheet, "Top Laminate")
        self._top_laminate = laminate

    @bottom_laminate.setter
    @calculate_all_properties
    @propagating_setter()
    def bottom_laminate(self, laminate: LaminateSheet) -> None:
        """Set bottom laminate sheet."""
        self.validate_type(laminate, LaminateSheet, "Bottom Laminate")
        self._bottom_laminate = laminate

    @width.setter
    @calculate_all_properties
    def width(self, width: float) -> None:
        """Set width of both laminate sheets in mm."""
        if width is None:
            self._width = None
            return
        self.validate_positive_float(width, "Width")
        width_m = float(width) * MM_TO_M
        self._top_laminate._width = width_m
        self._bottom_laminate._width = width_m

    @height.setter
    @calculate_all_properties
    def height(self, height: float) -> None:
        """Set height of both laminate sheets in mm."""
        if height is None:
            self._height = None
            return
        self.validate_positive_float(height, "Height")
        height_m = float(height) * MM_TO_M
        self._top_laminate._height = height_m
        self._bottom_laminate._height = height_m

    @classmethod
    def from_prismatic(
        cls,
        prismatic_encapsulation,
        terminal_width: float = None,
        terminal_length: float = None,
        terminal_thickness: float = None,
        laminate_areal_cost: float = 2.5,
        laminate_density: float = 920.0,
        laminate_thickness: float = 50.0,
    ):
        """Create a PouchEncapsulation from a PrismaticEncapsulation.

        Converts a prismatic encapsulation to pouch format by removing rigid structure
        and creating flexible laminate packaging. Dimensions are mapped to preserve
        internal volume:
        - pouch width = prismatic width
        - pouch height = prismatic length
        - pouch thickness = prismatic internal height

        Parameters
        ----------
        prismatic_encapsulation : PrismaticEncapsulation
            The prismatic encapsulation to convert from.
        terminal_width : float, optional
            Width of pouch terminals in mm. Defaults to pouch_width / 6 if not specified.
        terminal_length : float, optional
            Length of pouch terminals in mm. Defaults to pouch_height / 10 if not specified.
        terminal_thickness : float, optional
            Thickness of pouch terminals in mm. Defaults to 1.0 if not specified.
        laminate_areal_cost : float, optional
            Areal cost of laminate sheets in $/m². Defaults to 2.5.
        laminate_density : float, optional
            Density of laminate sheets in g/cm³. Defaults to 920.0.
        laminate_thickness : float, optional
            Thickness of laminate sheets in µm. Defaults to 50.0.

        Returns
        -------
        PouchEncapsulation
            A new pouch encapsulation with dimensions mapped from prismatic.

        Raises
        ------
        TypeError
            If prismatic_encapsulation is not a PrismaticEncapsulation instance.

        Examples
        --------
        >>> from steer_opencell_design.Components.Containers.Prismatic import PrismaticEncapsulation
        >>> prismatic = PrismaticEncapsulation(...)
        >>> pouch = PouchEncapsulation.from_prismatic(prismatic)
        """
        # Import here to avoid circular dependency
        from steer_opencell_design.Components.Containers.Prismatic import PrismaticEncapsulation

        if not isinstance(prismatic_encapsulation, PrismaticEncapsulation):
            raise TypeError(
                f"Expected PrismaticEncapsulation, got {type(prismatic_encapsulation).__name__}"
            )

        # Get material from prismatic encapsulation (use canister material)
        terminal_material = prismatic_encapsulation.canister.material

        # Map dimensions: width->width, length->height, internal_height->thickness
        pouch_width = prismatic_encapsulation.width
        pouch_height = prismatic_encapsulation.length
        pouch_thickness = prismatic_encapsulation.internal_height

        # Derive terminal dimensions from pouch dimensions if not specified
        if terminal_width is None:
            terminal_width = pouch_width / 6
        if terminal_length is None:
            terminal_length = pouch_height / 10
        if terminal_thickness is None:
            terminal_thickness = 1.0

        # Create terminals
        cathode_terminal = PouchTerminal(
            material=terminal_material,
            width=terminal_width,
            length=terminal_length,
            thickness=terminal_thickness,
            name="Cathode Terminal"
        )

        anode_terminal = PouchTerminal(
            material=terminal_material,
            width=terminal_width,
            length=terminal_length,
            thickness=terminal_thickness,
            name="Anode Terminal"
        )

        # Create laminate sheets
        top_laminate = LaminateSheet(
            areal_cost=laminate_areal_cost,
            density=laminate_density,
            thickness=laminate_thickness,
            name="Top Laminate"
        )

        bottom_laminate = LaminateSheet(
            areal_cost=laminate_areal_cost,
            density=laminate_density,
            thickness=laminate_thickness,
            name="Bottom Laminate"
        )

        # Create and return pouch encapsulation
        return cls(
            cathode_terminal=cathode_terminal,
            anode_terminal=anode_terminal,
            top_laminate=top_laminate,
            bottom_laminate=bottom_laminate,
            width=pouch_width,
            height=pouch_height,
            thickness=pouch_thickness,
        )

    @classmethod
    def from_cylindrical(
        cls,
        cylindrical_encapsulation,
        terminal_width: float = None,
        terminal_length: float = None,
        terminal_thickness: float = None,
        laminate_areal_cost: float = 2.5,
        laminate_density: float = 920.0,
        laminate_thickness: float = 50.0,
    ):
        """Create a PouchEncapsulation from a CylindricalEncapsulation.

        Converts a cylindrical encapsulation to pouch format by removing rigid structure
        and creating flexible laminate packaging. Dimensions are mapped to preserve
        internal volume:
        - pouch width = 2 × radius (cylinder diameter)
        - pouch height = cylinder height
        - pouch thickness = 2 × radius (cylinder diameter)

        Parameters
        ----------
        cylindrical_encapsulation : CylindricalEncapsulation
            The cylindrical encapsulation to convert from.
        terminal_width : float, optional
            Width of pouch terminals in mm. Defaults to pouch_width / 6 if not specified.
        terminal_length : float, optional
            Length of pouch terminals in mm. Defaults to pouch_height / 10 if not specified.
        terminal_thickness : float, optional
            Thickness of pouch terminals in mm. Defaults to 1.0 if not specified.
        laminate_areal_cost : float, optional
            Areal cost of laminate sheets in $/m². Defaults to 2.5.
        laminate_density : float, optional
            Density of laminate sheets in g/cm³. Defaults to 920.0.
        laminate_thickness : float, optional
            Thickness of laminate sheets in µm. Defaults to 50.0.

        Returns
        -------
        PouchEncapsulation
            A new pouch encapsulation with dimensions mapped from cylindrical.

        Raises
        ------
        TypeError
            If cylindrical_encapsulation is not a CylindricalEncapsulation instance.

        Examples
        --------
        >>> from steer_opencell_design.Components.Containers.Cylindrical import CylindricalEncapsulation
        >>> cylindrical = CylindricalEncapsulation(...)
        >>> pouch = PouchEncapsulation.from_cylindrical(cylindrical)
        """
        # Import here to avoid circular dependency
        from steer_opencell_design.Components.Containers.Cylindrical import CylindricalEncapsulation

        if not isinstance(cylindrical_encapsulation, CylindricalEncapsulation):
            raise TypeError(
                f"Expected CylindricalEncapsulation, got {type(cylindrical_encapsulation).__name__}"
            )

        # Get material from cylindrical encapsulation (use canister material)
        terminal_material = cylindrical_encapsulation.canister.material

        # Map dimensions: diameter for both width and thickness, height->height
        diameter = 2 * cylindrical_encapsulation.radius
        pouch_width = diameter
        pouch_height = cylindrical_encapsulation.height
        pouch_thickness = diameter

        # Derive terminal dimensions from pouch dimensions if not specified
        if terminal_width is None:
            terminal_width = pouch_width / 6
        if terminal_length is None:
            terminal_length = pouch_height / 10
        if terminal_thickness is None:
            terminal_thickness = 1.0

        # Create terminals
        cathode_terminal = PouchTerminal(
            material=terminal_material,
            width=terminal_width,
            length=terminal_length,
            thickness=terminal_thickness,
            name="Cathode Terminal"
        )

        anode_terminal = PouchTerminal(
            material=terminal_material,
            width=terminal_width,
            length=terminal_length,
            thickness=terminal_thickness,
            name="Anode Terminal"
        )

        # Create laminate sheets
        top_laminate = LaminateSheet(
            areal_cost=laminate_areal_cost,
            density=laminate_density,
            thickness=laminate_thickness,
            name="Top Laminate"
        )

        bottom_laminate = LaminateSheet(
            areal_cost=laminate_areal_cost,
            density=laminate_density,
            thickness=laminate_thickness,
            name="Bottom Laminate"
        )

        # Create and return pouch encapsulation
        return cls(
            cathode_terminal=cathode_terminal,
            anode_terminal=anode_terminal,
            top_laminate=top_laminate,
            bottom_laminate=bottom_laminate,
            width=pouch_width,
            height=pouch_height,
            thickness=pouch_thickness,
        )



