from __future__ import annotations

from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.other import Organ, OrganChronicScore
from cidc_api.models.db.stage2.base_orm import BaseORM
from cidc_api.models.db.stage2.trial_orm import TrialORM
from cidc_api.models.types import PreOrPostEnrollment


class GVHDOrganChronicORM(BaseORM):
    __tablename__ = "gvhd_organ_chronic"
    __repr_attrs__ = ["gvhd_organ_chronic_id", "organ"]
    __data_category__ = "gvhd_organ_chronic"
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    gvhd_organ_chronic_id: Mapped[int] = mapped_column(primary_key=True)
    gvhd_diagnosis_chronic_id: Mapped[int] = mapped_column(
        ForeignKey("stage2.gvhd_diagnosis_chronic.gvhd_diagnosis_chronic_id", ondelete="CASCADE")
    )
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage2.participant.participant_id", ondelete="CASCADE"))
    organ: Mapped[Organ]
    chronic_score: Mapped[OrganChronicScore]
    pre_or_post_enrollment: Mapped[PreOrPostEnrollment]

    trial: Mapped[TrialORM] = relationship(back_populates="gvhd_organ_chronics", cascade="all, delete")
    gvhd_diagnosis_chronic: Mapped[GVHDDiagnosisChronicORM] = relationship(
        back_populates="gvhd_organ_chronics", cascade="all, delete"
    )
    participant: Mapped[ParticipantORM] = relationship(back_populates="gvhd_organ_chronics", cascade="all, delete")
