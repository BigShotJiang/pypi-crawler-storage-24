from __future__ import annotations
from pydantic import NonNegativeInt

from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.models.db.stage1.base_orm import BaseORM
from cidc_api.models.db.stage1.trial_orm import TrialORM
from cidc_api.code_systems.uberon import UberonAnatomicalTerm
from cidc_api.models.types import SurgicalProcedure, YNU


class SurgeryORM(BaseORM):
    __tablename__ = "surgery"
    __repr_attrs__ = ["surgery_id", "procedure"]
    __data_category__ = "surgery"
    __exclude_during_promotion__ = ["surgery_id", "treatment_id", "participant_id"]
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    surgery_id: Mapped[int] = mapped_column(primary_key=True)
    treatment_id: Mapped[int] = mapped_column(ForeignKey("stage1.treatment.treatment_id", ondelete="CASCADE"))
    participant_id: Mapped[int] = mapped_column(ForeignKey("stage1.participant.participant_id", ondelete="CASCADE"))

    procedure: Mapped[SurgicalProcedure]
    procedure_other: Mapped[str | None]
    days_to_procedure: Mapped[NonNegativeInt]
    anatomical_location: Mapped[UberonAnatomicalTerm]
    therapeutic: Mapped[YNU]
    findings: Mapped[str | None]
    extent_of_residual_disease: Mapped[str | None]
    treatment_description: Mapped[str]

    trial: Mapped[TrialORM] = relationship(back_populates="surgeries", cascade="all, delete")
    treatment: Mapped[TreatmentORM] = relationship(back_populates="surgeries", cascade="all, delete")
    participant: Mapped[ParticipantORM] = relationship(back_populates="surgeries", cascade="all, delete")
