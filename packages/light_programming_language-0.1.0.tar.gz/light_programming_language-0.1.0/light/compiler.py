# light/compiler.py

import sys
import os

def compilar_arquivo(caminho_entrada, caminho_saida=None):
    """
    Compila um arquivo .light em .clighted
    """
    if not os.path.exists(caminho_entrada):
        print(f"Erro: arquivo '{caminho_entrada}' não existe.")
        return

    if caminho_saida is None:
        base = os.path.splitext(caminho_entrada)[0]
        caminho_saida = base + ".clighted"

    try:
        with open(caminho_entrada, "r", encoding="utf-8") as f:
            codigo_light = f.read()

        # Aqui você pode processar o código (lexer, parser, AST)
        # Por enquanto apenas copia o conteúdo para .clighted
        with open(caminho_saida, "w", encoding="utf-8") as f:
            f.write("# Light Compiled File\n")
            f.write(codigo_light)

        print(f"Arquivo compilado com sucesso: {caminho_saida}")

    except Exception as e:
        print(f"Erro ao compilar: {e}")

def main():
    """
    Função principal do CLI 'lightc'
    """
    if len(sys.argv) < 2:
        print("Uso: lightc <arquivo.light> [saida.clighted]")
        sys.exit(1)

    caminho_entrada = sys.argv[1]
    caminho_saida = sys.argv[2] if len(sys.argv) > 2 else None

    compilar_arquivo(caminho_entrada, caminho_saida)

if __name__ == "__main__":
    main()
