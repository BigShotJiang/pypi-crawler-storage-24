import urllib.request, requests
import json
import ssl
import threading
import time, json
from google.oauth2 import service_account
import google.auth.transport.requests


class FireBase:
    def __init__(self, conf):
        # Твой проект использует europe-west1 регион
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.running = False
        self.conf = conf
        
        
        with open(conf, "r") as f:
            self.project_id = json.load(f)["project_id"]
            
        # Проверяем какой URL рабочий

    def rtdb(self, conf):
        with open(conf, "r") as f:
            self.secret_key = json.load(f)["client"][0]["api_key"][0]["current_key"]
            
            print(self.secret_key)
            possible_urls = [
                f"https://{self.project_id}.firebaseio.com",  # США
                f"https://{self.project_id}.europe-west1.firebasedatabase.app",  # Европа
                f"https://{self.project_id}.asia-northeast1.firebasedatabase.app",  # Азия
                f"https://{self.project_id}.us-central1.firebasedatabase.app",  # США (новый формат)
                f"https://{self.project_id}-default-rtdb.firebaseio.com",  # Стандартный
                f"https://{self.project_id}-default-rtdb.europe-west1.firebasedatabase.app",  # Ваш случай
            ]
            for url in possible_urls:
                # Пробуем получить корневой путь
                test_url = f"{url}/.json"
                try:
                    response = requests.get(test_url, timeout=3)
                    if response.status_code in [200, 401, 403]:
                        self.base_url = url
                        break
                except:
                    pass

    def _get_access_token(self):
            self.credentials = service_account.Credentials.from_service_account_file(
                self.conf,
                scopes=['https://www.googleapis.com/auth/firebase.messaging']
                )
            
            auth_request = google.auth.transport.requests.Request()
            self.credentials.refresh(auth_request)
            
            return self.credentials.token
        
    def listen(self, path, callback):
        """Запускает прослушивание изменений"""
        self.running = True
        thread = threading.Thread(target=self._listen_thread, args=(path, callback))
        thread.daemon = True
        thread.start()
        return thread
    
    def _listen_thread(self, path, callback):
        """Поток для long polling"""
        url = f"{self.base_url}/{path}.json?auth={self.secret_key}"
        last_data = None
        
        while self.running:
            try:
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, context=self.ssl_context) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    
                    # Если данные изменились
                    if data != last_data:
                        callback(data)
                        last_data = data
                    
                    # Небольшая задержка между запросами
                    time.sleep(1)
                    
            except Exception as e:
                print(f"Ошибка прослушивания: {e}")
                time.sleep(5)  # Пауза перед повторной попыткой

    def _firebase_request(self, method, path, data=None):
        """Универсальная функция для работы с Firebase"""
        url = f"{self.base_url}/{path}.json?auth={self.secret_key}"
    
    # Создаем запрос
        req = urllib.request.Request(url, method=method)
    
    # Добавляем заголовки - важно указать UTF-8
        req.add_header('Content-Type', 'application/json; charset=utf-8')
    
    # Если есть данные для отправки
        if data:
            # Явно указываем ensure_ascii=False для сохранения русских букв
            json_str = json.dumps(data, ensure_ascii=False)
            data_bytes = json_str.encode('utf-8')
            req.data = data_bytes
    
        try:
        # Отправляем запрос
            with urllib.request.urlopen(req, context=self.ssl_context) as response:
                response_data = response.read().decode('utf-8')
                return json.loads(response_data) if response_data else None
        except urllib.error.HTTPError as e:
            return None
        except Exception as e:
            return None

    def delete_data(self, path):
        """Удаление данных"""
        return self._firebase_request('DELETE', path)
    
    def write_data(self, path, data):
        """Запись данных (полная замена)"""
        return self._firebase_request('PUT', path, data)
    
    def stop(self):
        self.running = False
    
    def send_push(self, device_token, title, message):
        """Максимально простая функция отправки"""
    
        access_token = self._get_access_token()
        if not access_token:
            return False
        

        
        url = f"https://fcm.googleapis.com/v1/projects/{self.project_id}/messages:send"
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {access_token}',
        }
        
        payload = {
            "message": {
                "token": device_token,
                "notification": {
                    "title": title,
                    "body": message
                },
                "android": {
                    "priority": "high"
                }
            }
        }

        response = requests.post(url, headers=headers, json=payload, timeout=30)
        if response.status_code == 200:
                return True
        else:
                return False
                

# Использование real-time
FireBase(r"/Users/homr/Desktop/sos/прога/drone-e9f5a-firebase-adminsdk-fbsvc-988fa77bf8.json").rtdb(r"/Users/homr/Desktop/sos/прога/google-services.json")
# Запуск