#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lua_library" for configuration "Release"
set_property(TARGET lua_library APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(lua_library PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/liblua-5.4.a"
  )

list(APPEND _cmake_import_check_targets lua_library )
list(APPEND _cmake_import_check_files_for_lua_library "${_IMPORT_PREFIX}/lib64/liblua-5.4.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
