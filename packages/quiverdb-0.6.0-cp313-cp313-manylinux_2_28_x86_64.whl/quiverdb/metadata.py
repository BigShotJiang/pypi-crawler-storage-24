from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class DataType(IntEnum):
    """Data type constants matching C API quiver_data_type_t."""

    INTEGER = 0
    FLOAT = 1
    STRING = 2
    DATE_TIME = 3
    NULL = 4


@dataclass(frozen=True)
class CSVOptions:
    """Options for CSV import and export operations."""

    date_time_format: str = ""
    enum_labels: dict[str, dict[str, dict[str, int]]] = field(default_factory=dict)


@dataclass(frozen=True)
class ScalarMetadata:
    """Metadata for a scalar attribute in a collection."""

    name: str
    data_type: DataType
    not_null: bool
    primary_key: bool
    default_value: str | None
    is_foreign_key: bool
    references_collection: str | None
    references_column: str | None


@dataclass(frozen=True)
class GroupMetadata:
    """Metadata for a vector, set, or time series group in a collection."""

    group_name: str
    dimension_column: str  # empty string for vector/set groups
    value_columns: list[ScalarMetadata]
