"""Auto-generated CFFI declarations. Do not edit manually.

Regenerate with: python generator/generator.py --output src/quiverdb/_declarations.py
"""

DECLARATIONS = """
// common.h
// Platform-specific export macros

// Error codes
typedef enum {
    QUIVER_OK = 0,
    QUIVER_ERROR = 1,
} quiver_error_t;

// Utility functions
const char* quiver_version(void);

// Error message capture - returns detailed error message from last operation
// Returns empty string if no error occurred. Thread-local storage.
const char* quiver_get_last_error(void);
void quiver_clear_last_error(void);

// options.h
typedef enum {
    QUIVER_LOG_DEBUG = 0,
    QUIVER_LOG_INFO = 1,
    QUIVER_LOG_WARN = 2,
    QUIVER_LOG_ERROR = 3,
    QUIVER_LOG_OFF = 4,
} quiver_log_level_t;

typedef struct {
    int read_only;
    quiver_log_level_t console_level;
} quiver_database_options_t;

// CSV options for controlling enum resolution and date formatting.
// All pointers are borrowed -- caller owns the memory, function reads during call only.
//
// Enum labels map attribute names to locale-keyed (string_label -> integer_value) pairs.
// Represented as grouped-by-attribute-and-locale parallel arrays:
//   enum_attribute_names[i]   = attribute name for group i
//   enum_locale_names[i]      = locale name for group i (e.g. "en", "pt")
//   enum_entry_counts[i]      = number of entries in group i
//   enum_labels[]             = all string labels, concatenated across groups
//   enum_values[]             = all integer values, concatenated across groups
//   enum_group_count          = total number of (attribute, locale) groups
//
// Example: {"status": {"en": {"Active": 1, "Inactive": 2}, "pt": {"Ativo": 1}}}
//   enum_attribute_names = ["status", "status"]
//   enum_locale_names    = ["en", "pt"]
//   enum_entry_counts    = [2, 1]
//   enum_labels          = ["Active", "Inactive", "Ativo"]
//   enum_values          = [1, 2, 1]
//   enum_group_count     = 2
typedef struct {
    const char* date_time_format;             // strftime format; "" = no formatting
    const char* const* enum_attribute_names;  // [enum_group_count]
    const char* const* enum_locale_names;     // [enum_group_count]
    const size_t* enum_entry_counts;          // [enum_group_count]
    const char* const* enum_labels;           // [sum of enum_entry_counts]
    const int64_t* enum_values;               // [sum of enum_entry_counts]
    size_t enum_group_count;                  // number of (attribute, locale) groups
} quiver_csv_options_t;

quiver_database_options_t quiver_database_options_default(void);
quiver_csv_options_t quiver_csv_options_default(void);

// database.h
// Attribute data structure
typedef enum {
    QUIVER_DATA_STRUCTURE_SCALAR = 0,
    QUIVER_DATA_STRUCTURE_VECTOR = 1,
    QUIVER_DATA_STRUCTURE_SET = 2
} quiver_data_structure_t;

// Attribute data types
typedef enum {
    QUIVER_DATA_TYPE_INTEGER = 0,
    QUIVER_DATA_TYPE_FLOAT = 1,
    QUIVER_DATA_TYPE_STRING = 2,
    QUIVER_DATA_TYPE_DATE_TIME = 3,
    QUIVER_DATA_TYPE_NULL = 4
} quiver_data_type_t;

// Opaque handle type
typedef struct quiver_database quiver_database_t;

// Database lifecycle
quiver_error_t quiver_database_open(const char* path,
                                                 const quiver_database_options_t* options,
                                                 quiver_database_t** out_db);
quiver_error_t quiver_database_from_migrations(const char* db_path,
                                                            const char* migrations_path,
                                                            const quiver_database_options_t* options,
                                                            quiver_database_t** out_db);
quiver_error_t quiver_database_from_schema(const char* db_path,
                                                        const char* schema_path,
                                                        const quiver_database_options_t* options,
                                                        quiver_database_t** out_db);
quiver_error_t quiver_database_close(quiver_database_t* db);
quiver_error_t quiver_database_is_healthy(quiver_database_t* db, int* out_healthy);
quiver_error_t quiver_database_path(quiver_database_t* db, const char** out_path);

// Transaction control
quiver_error_t quiver_database_begin_transaction(quiver_database_t* db);
quiver_error_t quiver_database_commit(quiver_database_t* db);
quiver_error_t quiver_database_rollback(quiver_database_t* db);
quiver_error_t quiver_database_in_transaction(quiver_database_t* db, _Bool* out_active);

// Version
quiver_error_t quiver_database_current_version(quiver_database_t* db, int64_t* out_version);

// Element operations (requires quiver_element_t from element.h)
typedef struct quiver_element quiver_element_t;
quiver_error_t quiver_database_create_element(quiver_database_t* db,
                                                           const char* collection,
                                                           quiver_element_t* element,
                                                           int64_t* out_id);
quiver_error_t quiver_database_update_element(quiver_database_t* db,
                                                           const char* collection,
                                                           int64_t id,
                                                           const quiver_element_t* element);
quiver_error_t quiver_database_delete_element(quiver_database_t* db, const char* collection, int64_t id);

// Read scalar attributes
quiver_error_t quiver_database_read_scalar_integers(quiver_database_t* db,
                                                                 const char* collection,
                                                                 const char* attribute,
                                                                 int64_t** out_values,
                                                                 size_t* out_count);

quiver_error_t quiver_database_read_scalar_floats(quiver_database_t* db,
                                                               const char* collection,
                                                               const char* attribute,
                                                               double** out_values,
                                                               size_t* out_count);

quiver_error_t quiver_database_read_scalar_strings(quiver_database_t* db,
                                                                const char* collection,
                                                                const char* attribute,
                                                                char*** out_values,
                                                                size_t* out_count);

// Read vector attributes
quiver_error_t quiver_database_read_vector_integers(quiver_database_t* db,
                                                                 const char* collection,
                                                                 const char* attribute,
                                                                 int64_t*** out_vectors,
                                                                 size_t** out_sizes,
                                                                 size_t* out_count);

quiver_error_t quiver_database_read_vector_floats(quiver_database_t* db,
                                                               const char* collection,
                                                               const char* attribute,
                                                               double*** out_vectors,
                                                               size_t** out_sizes,
                                                               size_t* out_count);

quiver_error_t quiver_database_read_vector_strings(quiver_database_t* db,
                                                                const char* collection,
                                                                const char* attribute,
                                                                char**** out_vectors,
                                                                size_t** out_sizes,
                                                                size_t* out_count);

// Read set attributes (same structure as vectors, uses same free functions)
quiver_error_t quiver_database_read_set_integers(quiver_database_t* db,
                                                              const char* collection,
                                                              const char* attribute,
                                                              int64_t*** out_sets,
                                                              size_t** out_sizes,
                                                              size_t* out_count);

quiver_error_t quiver_database_read_set_floats(quiver_database_t* db,
                                                            const char* collection,
                                                            const char* attribute,
                                                            double*** out_sets,
                                                            size_t** out_sizes,
                                                            size_t* out_count);

quiver_error_t quiver_database_read_set_strings(quiver_database_t* db,
                                                             const char* collection,
                                                             const char* attribute,
                                                             char**** out_sets,
                                                             size_t** out_sizes,
                                                             size_t* out_count);

// Read scalar attributes by element ID
quiver_error_t quiver_database_read_scalar_integer_by_id(quiver_database_t* db,
                                                                      const char* collection,
                                                                      const char* attribute,
                                                                      int64_t id,
                                                                      int64_t* out_value,
                                                                      int* out_has_value);

quiver_error_t quiver_database_read_scalar_float_by_id(quiver_database_t* db,
                                                                    const char* collection,
                                                                    const char* attribute,
                                                                    int64_t id,
                                                                    double* out_value,
                                                                    int* out_has_value);

quiver_error_t quiver_database_read_scalar_string_by_id(quiver_database_t* db,
                                                                     const char* collection,
                                                                     const char* attribute,
                                                                     int64_t id,
                                                                     char** out_value,
                                                                     int* out_has_value);

// Read vector attributes by element ID
quiver_error_t quiver_database_read_vector_integers_by_id(quiver_database_t* db,
                                                                       const char* collection,
                                                                       const char* attribute,
                                                                       int64_t id,
                                                                       int64_t** out_values,
                                                                       size_t* out_count);

quiver_error_t quiver_database_read_vector_floats_by_id(quiver_database_t* db,
                                                                     const char* collection,
                                                                     const char* attribute,
                                                                     int64_t id,
                                                                     double** out_values,
                                                                     size_t* out_count);

quiver_error_t quiver_database_read_vector_strings_by_id(quiver_database_t* db,
                                                                      const char* collection,
                                                                      const char* attribute,
                                                                      int64_t id,
                                                                      char*** out_values,
                                                                      size_t* out_count);

// Read set attributes by element ID
quiver_error_t quiver_database_read_set_integers_by_id(quiver_database_t* db,
                                                                    const char* collection,
                                                                    const char* attribute,
                                                                    int64_t id,
                                                                    int64_t** out_values,
                                                                    size_t* out_count);

quiver_error_t quiver_database_read_set_floats_by_id(quiver_database_t* db,
                                                                  const char* collection,
                                                                  const char* attribute,
                                                                  int64_t id,
                                                                  double** out_values,
                                                                  size_t* out_count);

quiver_error_t quiver_database_read_set_strings_by_id(quiver_database_t* db,
                                                                   const char* collection,
                                                                   const char* attribute,
                                                                   int64_t id,
                                                                   char*** out_values,
                                                                   size_t* out_count);

// Read element Ids
quiver_error_t quiver_database_read_element_ids(quiver_database_t* db,
                                                             const char* collection,
                                                             int64_t** out_ids,
                                                             size_t* out_count);

// Attribute metadata types
typedef struct {
    const char* name;
    quiver_data_type_t data_type;
    int not_null;
    int primary_key;
    const char* default_value;  // NULL if no default
    int is_foreign_key;
    const char* references_collection;  // NULL if not a foreign key
    const char* references_column;      // NULL if not a foreign key
} quiver_scalar_metadata_t;

typedef struct {
    const char* group_name;
    const char* dimension_column;  // NULL for vector/set groups; ordering column for time series
    quiver_scalar_metadata_t* value_columns;
    size_t value_column_count;
} quiver_group_metadata_t;

// Attribute metadata queries
quiver_error_t quiver_database_get_scalar_metadata(quiver_database_t* db,
                                                                const char* collection,
                                                                const char* attribute,
                                                                quiver_scalar_metadata_t* out_metadata);

quiver_error_t quiver_database_get_vector_metadata(quiver_database_t* db,
                                                                const char* collection,
                                                                const char* group_name,
                                                                quiver_group_metadata_t* out_metadata);

quiver_error_t quiver_database_get_set_metadata(quiver_database_t* db,
                                                             const char* collection,
                                                             const char* group_name,
                                                             quiver_group_metadata_t* out_metadata);

quiver_error_t quiver_database_get_time_series_metadata(quiver_database_t* db,
                                                                     const char* collection,
                                                                     const char* group_name,
                                                                     quiver_group_metadata_t* out_metadata);

// Free metadata
quiver_error_t quiver_database_free_scalar_metadata(quiver_scalar_metadata_t* metadata);
quiver_error_t quiver_database_free_group_metadata(quiver_group_metadata_t* metadata);

// List attributes/groups - returns full metadata
quiver_error_t quiver_database_list_scalar_attributes(quiver_database_t* db,
                                                                   const char* collection,
                                                                   quiver_scalar_metadata_t** out_metadata,
                                                                   size_t* out_count);

quiver_error_t quiver_database_list_vector_groups(quiver_database_t* db,
                                                               const char* collection,
                                                               quiver_group_metadata_t** out_metadata,
                                                               size_t* out_count);

quiver_error_t quiver_database_list_set_groups(quiver_database_t* db,
                                                            const char* collection,
                                                            quiver_group_metadata_t** out_metadata,
                                                            size_t* out_count);

quiver_error_t quiver_database_list_time_series_groups(quiver_database_t* db,
                                                                    const char* collection,
                                                                    quiver_group_metadata_t** out_metadata,
                                                                    size_t* out_count);

// Free metadata arrays
quiver_error_t quiver_database_free_scalar_metadata_array(quiver_scalar_metadata_t* metadata,
                                                                       size_t count);
quiver_error_t quiver_database_free_group_metadata_array(quiver_group_metadata_t* metadata, size_t count);

// Read time series group by element ID - returns multi-column typed data
// Columns are returned in schema definition order (dimension first, then value columns)
// Column data arrays are typed: INTEGER -> int64_t*, FLOAT -> double*, STRING/DATE_TIME -> char**
quiver_error_t quiver_database_read_time_series_group(quiver_database_t* db,
                                                                   const char* collection,
                                                                   const char* group,
                                                                   int64_t id,
                                                                   char*** out_column_names,
                                                                   int** out_column_types,
                                                                   void*** out_column_data,
                                                                   size_t* out_column_count,
                                                                   size_t* out_row_count);

// Update time series group - replaces all rows for element with multi-column typed data
// column_names[]: column names (including dimension column, any order)
// column_types[]: quiver_data_type_t per column
// column_data[]: typed array per column (int64_t* for INTEGER, double* for FLOAT, const char** for STRING/DATE_TIME)
// Pass column_count == 0 and row_count == 0 with NULL arrays to clear all rows
quiver_error_t quiver_database_update_time_series_group(quiver_database_t* db,
                                                                     const char* collection,
                                                                     const char* group,
                                                                     int64_t id,
                                                                     const char* const* column_names,
                                                                     const int* column_types,
                                                                     const void* const* column_data,
                                                                     size_t column_count,
                                                                     size_t row_count);

// Free multi-column time series read results
// Uses column_types to determine deallocation strategy per column
quiver_error_t quiver_database_free_time_series_data(char** column_names,
                                                                  int* column_types,
                                                                  void** column_data,
                                                                  size_t column_count,
                                                                  size_t row_count);

// Time series files - singleton table storing file paths for external time series data
// Check if collection has a time_series_files table
quiver_error_t quiver_database_has_time_series_files(quiver_database_t* db,
                                                                  const char* collection,
                                                                  int* out_result);

// List columns in time series files table
quiver_error_t quiver_database_list_time_series_files_columns(quiver_database_t* db,
                                                                           const char* collection,
                                                                           char*** out_columns,
                                                                           size_t* out_count);

// Read time series files (returns parallel arrays of column names and paths)
quiver_error_t quiver_database_read_time_series_files(quiver_database_t* db,
                                                                   const char* collection,
                                                                   char*** out_columns,
                                                                   char*** out_paths,
                                                                   size_t* out_count);

// Update time series files
quiver_error_t quiver_database_update_time_series_files(quiver_database_t* db,
                                                                     const char* collection,
                                                                     const char* const* columns,
                                                                     const char* const* paths,
                                                                     size_t count);

// Free time series files read results
quiver_error_t quiver_database_free_time_series_files(char** columns, char** paths, size_t count);

// Memory cleanup for read results
quiver_error_t quiver_database_free_integer_array(int64_t* values);
quiver_error_t quiver_database_free_float_array(double* values);
quiver_error_t quiver_database_free_string_array(char** values, size_t count);
// Memory cleanup for single string returned by query/read-by-id operations
quiver_error_t quiver_database_free_string(char* str);

// Memory cleanup for vector read results
quiver_error_t quiver_database_free_integer_vectors(int64_t** vectors, size_t* sizes, size_t count);
quiver_error_t quiver_database_free_float_vectors(double** vectors, size_t* sizes, size_t count);
quiver_error_t quiver_database_free_string_vectors(char*** vectors, size_t* sizes, size_t count);

// CSV operations
quiver_error_t quiver_database_export_csv(quiver_database_t* db,
                                                       const char* collection,
                                                       const char* group,
                                                       const char* path,
                                                       const quiver_csv_options_t* options);
quiver_error_t quiver_database_import_csv(quiver_database_t* db,
                                                       const char* collection,
                                                       const char* group,
                                                       const char* path,
                                                       const quiver_csv_options_t* options);

// Query methods - execute SQL and return first row's first column
quiver_error_t quiver_database_query_string(quiver_database_t* db,
                                                         const char* sql,
                                                         char** out_value,
                                                         int* out_has_value);

quiver_error_t quiver_database_query_integer(quiver_database_t* db,
                                                          const char* sql,
                                                          int64_t* out_value,
                                                          int* out_has_value);

quiver_error_t quiver_database_query_float(quiver_database_t* db,
                                                        const char* sql,
                                                        double* out_value,
                                                        int* out_has_value);

// Parameterized query methods
// param_types[i]: QUIVER_DATA_TYPE_INTEGER (0), QUIVER_DATA_TYPE_FLOAT (1),
//                 QUIVER_DATA_TYPE_STRING (2), QUIVER_DATA_TYPE_NULL (4)
// param_values[i]: pointer to int64_t, double, const char*, or NULL
quiver_error_t quiver_database_query_string_params(quiver_database_t* db,
                                                                const char* sql,
                                                                const int* param_types,
                                                                const void* const* param_values,
                                                                size_t param_count,
                                                                char** out_value,
                                                                int* out_has_value);

quiver_error_t quiver_database_query_integer_params(quiver_database_t* db,
                                                                 const char* sql,
                                                                 const int* param_types,
                                                                 const void* const* param_values,
                                                                 size_t param_count,
                                                                 int64_t* out_value,
                                                                 int* out_has_value);

quiver_error_t quiver_database_query_float_params(quiver_database_t* db,
                                                               const char* sql,
                                                               const int* param_types,
                                                               const void* const* param_values,
                                                               size_t param_count,
                                                               double* out_value,
                                                               int* out_has_value);

// Schema inspection
quiver_error_t quiver_database_describe(quiver_database_t* db);

// element.h
// Opaque handle type
typedef struct quiver_element quiver_element_t;

// Element builder
quiver_error_t quiver_element_create(quiver_element_t** out_element);
quiver_error_t quiver_element_destroy(quiver_element_t* element);
quiver_error_t quiver_element_clear(quiver_element_t* element);

// Scalar setters
quiver_error_t quiver_element_set_integer(quiver_element_t* element, const char* name, int64_t value);
quiver_error_t quiver_element_set_float(quiver_element_t* element, const char* name, double value);
quiver_error_t quiver_element_set_string(quiver_element_t* element, const char* name, const char* value);
quiver_error_t quiver_element_set_null(quiver_element_t* element, const char* name);

// Array setters - C++ create_element routes these to vector/set tables based on schema
quiver_error_t quiver_element_set_array_integer(quiver_element_t* element,
                                                             const char* name,
                                                             const int64_t* values,
                                                             int32_t count);
quiver_error_t quiver_element_set_array_float(quiver_element_t* element,
                                                           const char* name,
                                                           const double* values,
                                                           int32_t count);
quiver_error_t quiver_element_set_array_string(quiver_element_t* element,
                                                            const char* name,
                                                            const char* const* values,
                                                            int32_t count);

// Accessors
quiver_error_t quiver_element_has_scalars(quiver_element_t* element, int* out_result);
quiver_error_t quiver_element_has_arrays(quiver_element_t* element, int* out_result);
quiver_error_t quiver_element_scalar_count(quiver_element_t* element, size_t* out_count);
quiver_error_t quiver_element_array_count(quiver_element_t* element, size_t* out_count);

// Pretty print (caller must free returned string with quiver_database_free_string)
quiver_error_t quiver_element_to_string(quiver_element_t* element, char** out_string);

"""
