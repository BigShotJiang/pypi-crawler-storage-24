"""
Simplified LLM SDK - Universal interface for OpenAI, Gemini, and Ollama

This module provides a clean, unified interface for calling multiple LLM providers
with consistent parameter handling and response formatting.
"""

import json
import os
import time
import base64
import mimetypes
from abc import ABC, abstractmethod
from typing import Dict, List, Type, Optional, Literal, Any, Union, ClassVar
from datetime import datetime, timezone
from pydantic import BaseModel, Field, field_validator
from google.genai.types import Part, Content
from google import genai
from openai import OpenAI
from ollama import Client
from dotenv import load_dotenv

load_dotenv()

# ==================== LLM PROVIDER BASE CLASS ====================


class LLMProvider(ABC):
    """
    Interface for all LLM model providers.

    To add a new parameter:
    1. Add it to LLMInvoker.ChatCompletionInput
    2. Implement handling in each provider's invoke() method
    """

    class ModelInfo(BaseModel):
        """Information about a model's capabilities and limits."""

        model_name: str
        provider: str
        context_window: Optional[int] = None
        max_output_tokens: Optional[int] = None

    @abstractmethod
    def invoke(self, input_data: "LLMInvoker.ChatCompletionInput") -> Dict[str, Any]:
        """Execute chat completion and return standardized response data."""
        pass

    @abstractmethod
    def get_model_info(self, model_name: str) -> "ModelInfo":
        """Get information about the model's limits (context window, etc.)."""
        pass

    @staticmethod
    def model_matches(model: str, prefixes: List[str]) -> bool:
        """Check if model name starts with any given prefix."""
        return any(model.startswith(p) for p in prefixes)


# ==================== GEMINI PROVIDER ====================


class GeminiProvider(LLMProvider):
    """Google Gemini models provider."""

    # Gemini thinking configuration mappings
    GEMINI_THINKING_BUDGET_MAP = {
        "none": 0,
        "low": 512,
        "medium": 8192,
        "high": 24576,
        "dynamic": -1,
    }
    THINKING_LEVEL_MAP = {
        "none": "minimal",
        "low": "low",
        "medium": "medium",
        "high": "high",
        "dynamic": "high",
    }
    REASONING_SUMMARY_MAP = {
        "none": False,
        "concise": True,
        "detailed": True,
        "auto": True,
    }

    def __init__(self, api_key: str):
        self.client = genai.Client(api_key=api_key)

    def get_model_info(self, model_name: str) -> LLMProvider.ModelInfo:
        """Fetch model limits dynamically from Gemini API."""
        try:
            # Gemini model names in API often start with 'models/' if not provided
            full_name = (
                model_name
                if model_name.startswith("models/")
                else f"models/{model_name}"
            )
            raw_model = self.client.models.get(model=full_name)
            return LLMProvider.ModelInfo(
                model_name=model_name,
                provider="gemini",
                context_window=raw_model.input_token_limit,
                max_output_tokens=raw_model.output_token_limit,
            )
        except Exception:
            # Fallback for unknown models
            return LLMProvider.ModelInfo(model_name=model_name, provider="gemini")

    def invoke(self, input_data: "LLMInvoker.ChatCompletionInput") -> Dict[str, Any]:
        """Execute Gemini chat completion."""
        # Parse messages
        system_prompt, contents = self._parse_messages(input_data.messages)

        # Convert reasoning_summary to include_thoughts
        include_thoughts = self.REASONING_SUMMARY_MAP.get(
            input_data.reasoning_summary or "none", False
        )

        # Build configuration
        config = self._build_config(
            input_data.model_name,
            system_prompt,
            input_data.response_schema,
            input_data.temperature,
            input_data.max_output_tokens,
            input_data.reasoning_effort,
            include_thoughts,
            input_data.gemini_thinking_budget,
            input_data.tools,
            input_data.tool_choice,
        )

        # Make API call
        raw = self.client.models.generate_content(
            model=input_data.model_name,
            contents=contents,
            config=genai.types.GenerateContentConfig(**config),
        )

        return self._extract_response(raw, input_data.response_schema, include_thoughts)

    def _parse_messages(self, messages: List[Dict]) -> tuple:
        """Convert OpenAI messages to Gemini format with consolidated tool responses."""
        system_prompt = ""
        contents = []
        # Map tool_call_id to function name
        id_to_name = {}

        for msg in messages:
            role = msg.get("role")
            content = msg.get("content", "") or ""

            # 1. System Prompt Handling
            if role in ["system", "developer"]:
                if isinstance(content, list):
                    system_prompt += "".join(
                        p.get("text", "") for p in content if p.get("type") == "text"
                    )
                else:
                    system_prompt += content
                continue

            parts = []

            # 2. Tool Response Consolidation (CRITICAL)
            if role == "tool":
                tc_id = msg.get("tool_call_id")
                func_name = id_to_name.get(tc_id, "unknown_function")

                # Parse JSON strings to dicts for FunctionResponse
                response_dict = content
                if isinstance(content, str):
                    try:
                        response_dict = json.loads(content)
                    except json.JSONDecodeError:
                        response_dict = {"result": content}

                # If the last message in contents is already a 'function' role, append to it
                if contents and contents[-1].role == "function":
                    contents[-1].parts.append(
                        Part.from_function_response(
                            name=func_name, response=response_dict
                        )
                    )
                else:
                    # Start a new function content block
                    contents.append(
                        Content(
                            role="function",
                            parts=[
                                Part.from_function_response(
                                    name=func_name, response=response_dict
                                )
                            ],
                        )
                    )
                continue  # Skip the standard logic below for tool roles

            # 3. Standard Role Mapping
            gemini_role = "model" if role == "assistant" else "user"

            # 4. Content/Multimodal Parsing
            content_parts = (
                content
                if isinstance(content, list)
                else [{"type": "text", "text": content}]
            )
            for part in content_parts:
                part_type = part.get("type", "text")
                if part_type == "text" and part.get("text"):
                    parts.append(Part.from_text(text=part.get("text")))
                elif part_type == "image_url":
                    image_data = part.get("image_url", {})
                    url = image_data.get("url", "")

                    if url.startswith("data:"):
                        # Handle base64 data URI (OpenAI format)
                        try:
                            header, encoded = url.split(",", 1)
                            mime_type = header.split(":", 1)[1].split(";", 1)[0]
                            data = base64.b64decode(encoded)
                            parts.append(
                                Part.from_bytes(data=data, mime_type=mime_type)
                            )
                        except Exception as e:
                            print(f"Error decoding base64 image: {e}")

                    elif url.startswith(("http://", "https://")):
                        # For public URLs, it's often more reliable to download and send as bytes
                        # unless you are using the Vertex AI backend with Cloud Storage URIs (gs://)
                        try:
                            import requests

                            response = requests.get(url, timeout=10)
                            response.raise_for_status()
                            mime_type = response.headers.get(
                                "Content-Type", "image/jpeg"
                            )
                            parts.append(
                                Part.from_bytes(
                                    data=response.content, mime_type=mime_type
                                )
                            )
                        except Exception as e:
                            print(f"Error fetching image from URL: {e}")

                    else:
                        # Assume local path
                        try:
                            with open(url, "rb") as f:
                                data = f.read()
                            mime_type, _ = mimetypes.guess_type(url)
                            parts.append(
                                Part.from_bytes(
                                    data=data, mime_type=mime_type or "image/jpeg"
                                )
                            )
                        except Exception as e:
                            print(f"Error reading local image file at {url}: {e}")

            # 5. Assistant Tool Calls
            if role == "assistant" and msg.get("tool_calls"):
                for tc in msg["tool_calls"]:
                    f_name = tc["function"]["name"]
                    f_args = tc["function"]["arguments"]
                    id_to_name[tc.get("id")] = f_name

                    if isinstance(f_args, str):
                        try:
                            f_args = json.loads(f_args)
                        except:
                            f_args = {"args": f_args}

                    parts.append(Part.from_function_call(name=f_name, args=f_args))

            if parts:
                contents.append(Content(role=gemini_role, parts=parts))

        return system_prompt, contents

    def _build_config(
        self,
        model_name: str,
        system_prompt: str,
        response_schema: Optional[Type[BaseModel]],
        temperature: Optional[float],
        max_output_tokens: Optional[int],
        reasoning_effort: Optional[str],
        include_thoughts: bool,
        gemini_thinking_budget: Optional[int],
        tools: Optional[List[Dict[str, Any]]],
        tool_choice: Optional[Union[str, Dict[str, Any]]],
    ) -> Dict:
        """Build Gemini generation configuration."""
        config = {"system_instruction": system_prompt}

        # Response schema
        if response_schema:
            config.update(
                {
                    "response_schema": response_schema,
                    "response_mime_type": "application/json",
                }
            )

        # Temperature
        if temperature is not None:
            config["temperature"] = temperature

        # Max tokens
        if max_output_tokens:
            config["max_output_tokens"] = max_output_tokens

        # Thinking configuration
        thinking = self._build_thinking_config(
            model_name, reasoning_effort, include_thoughts, gemini_thinking_budget
        )
        if thinking:
            config["thinking_config"] = genai.types.ThinkingConfig(**thinking)

        # Tool configuration
        if tools:
            config["tools"] = self._convert_tools_to_gemini(tools)

            # Tool choice configuration
            if tool_choice:
                config["tool_config"] = self._build_tool_config(tool_choice)

        return config

    def _build_thinking_config(
        self,
        model_name: str,
        reasoning_effort: Optional[str],
        include_thoughts: bool,
        gemini_thinking_budget: Optional[int],
    ) -> Dict:
        """Build thinking configuration for reasoning models."""
        thinking = {}

        if include_thoughts:
            thinking["include_thoughts"] = True

        # Handle gemini_thinking_budget or reasoning_effort
        # If both provided, gemini_thinking_budget takes precedence
        if gemini_thinking_budget is not None and model_name.startswith("gemini-2.5"):
            thinking["thinking_budget"] = max(0, min(24576, gemini_thinking_budget))
        elif reasoning_effort:
            if model_name.startswith("gemini-3"):
                thinking["thinking_level"] = self.THINKING_LEVEL_MAP.get(
                    reasoning_effort, "high"
                )
            elif model_name.startswith("gemini-2.5"):
                thinking["thinking_budget"] = self.GEMINI_THINKING_BUDGET_MAP.get(
                    reasoning_effort, -1
                )

        return thinking

    def _convert_tools_to_gemini(self, tools: List[Dict[str, Any]]) -> List[Dict]:
        """Convert OpenAI tool format to Gemini function declarations."""
        gemini_tools = []
        for tool in tools:
            func = tool.get("function", {})
            gemini_func = {
                "function_declarations": [
                    {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                    }
                ]
            }
            if "parameters" in func:
                # Clean the parameters to remove OpenAI-specific fields
                params = self._clean_parameters_for_gemini(func["parameters"])
                gemini_func["function_declarations"][0]["parameters"] = params
            gemini_tools.append(gemini_func)
        return gemini_tools

    def _clean_parameters_for_gemini(
        self, parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Remove OpenAI-specific fields from parameters schema.
        Gemini doesn't support: additionalProperties, strict, etc.
        """
        if not isinstance(parameters, dict):
            return parameters

        # Create a clean copy
        cleaned = {}

        # Fields to exclude (OpenAI-specific)
        exclude_fields = {"additionalProperties", "strict"}

        for key, value in parameters.items():
            if key in exclude_fields:
                continue

            # Recursively clean nested objects
            if isinstance(value, dict):
                cleaned[key] = self._clean_parameters_for_gemini(value)
            elif isinstance(value, list):
                cleaned[key] = [
                    (
                        self._clean_parameters_for_gemini(item)
                        if isinstance(item, dict)
                        else item
                    )
                    for item in value
                ]
            else:
                cleaned[key] = value

        return cleaned

    def _build_tool_config(self, tool_choice: Union[str, Dict[str, Any]]) -> Dict:
        """Build Gemini tool config from tool_choice."""
        if isinstance(tool_choice, str):
            if tool_choice == "auto":
                return {"function_calling_config": {"mode": "AUTO"}}
            elif tool_choice == "none":
                return {"function_calling_config": {"mode": "NONE"}}
            elif tool_choice == "required":
                return {"function_calling_config": {"mode": "ANY"}}
        elif isinstance(tool_choice, dict) and "function" in tool_choice:
            # Specific function
            return {
                "function_calling_config": {
                    "mode": "ANY",
                    "allowed_function_names": [tool_choice["function"]["name"]],
                }
            }
        return {"function_calling_config": {"mode": "AUTO"}}

    def _extract_response(
        self, raw, response_schema: Optional[Type[BaseModel]], include_thoughts: bool
    ) -> Dict[str, Any]:
        """Extract standardized response from Gemini API response."""

        # Initialize defaults
        text_content = ""
        tool_calls = []
        reasoning_parts = []
        finish_reason = None

        if raw.candidates:
            candidate = raw.candidates[0]
            finish_reason = (
                str(candidate.finish_reason.name) if candidate.finish_reason else None
            )

            # Iterate through parts to avoid the .text warning
            for part in candidate.content.parts:
                # 1. Handle Text
                if part.text:
                    text_content += part.text

                # 2. Handle Function Calls
                if part.function_call:
                    tool_calls.append(
                        {
                            "id": f"call_{len(tool_calls)}_{int(time.time())}",  # Generate unique ID
                            "type": "function",
                            "function": {
                                "name": part.function_call.name,
                                "arguments": (
                                    json.dumps(dict(part.function_call.args))
                                    if part.function_call.args
                                    else "{}"
                                ),
                            },
                        }
                    )

                # 3. Handle Reasoning (Thoughts)
                if include_thoughts and getattr(part, "thought", False):
                    reasoning_parts.append(part.text)

        # Determine the primary 'response' field
        # If schema is used, use the parsed object; otherwise, use the collected text
        final_response = (
            raw.parsed if response_schema else (text_content if text_content else None)
        )

        result = {
            "response": final_response,
            "reasoning_summary": (
                "\n\n".join(reasoning_parts) if reasoning_parts else None
            ),
            "tool_calls": tool_calls if tool_calls else None,
            "usage": {},
            "finish_reason": finish_reason,
        }

        # Extract usage metadata (Keep your existing usage logic)
        if hasattr(raw, "usage_metadata") and raw.usage_metadata:
            m = raw.usage_metadata
            result["usage"] = {
                "input_tokens": getattr(m, "prompt_token_count", None),
                "output_tokens": getattr(m, "candidates_token_count", None),
                "reasoning_tokens": getattr(m, "thoughts_token_count", None),
                "cached_tokens": getattr(m, "cached_content_token_count", None),
                "total_tokens": getattr(m, "total_token_count", None),
            }

        return result


# ==================== OPENAI PROVIDER ====================


class OpenAIProvider(LLMProvider):
    """
    OpenAI models provider using the latest Responses API.

    API Structure (as of 2026):
    ---------------------------
    The Responses API (client.responses.create) is OpenAI's unified interface that
    supersedes the legacy Chat Completions API. It provides:

    1. Request Parameters:
       - model: Model identifier (e.g., "gpt-4", "o1", "gpt-5")
       - input: Messages array (same format as legacy messages parameter)
       - temperature: Sampling temperature (0.0-2.0)
       - max_output_tokens: Maximum tokens in response
       - reasoning: Object containing reasoning configuration:
         * effort: "low" | "medium" | "high" | "minimal" (for reasoning models)
         * summary: "none" | "concise" | "detailed" | "auto" (reasoning summary level)
       - output: Object containing output configuration:
         * format: "json_schema" (for structured output)
         * json_schema: Object containing name and schema (for structured output)

    2. Response Structure:
       - output: List of output items:
         * type: "text" | "parsed" | "reasoning"
         * content/text: Text response content
         * parsed: Parsed Pydantic model
         * summary/content: Reasoning summary (for type="reasoning")
         * finish_reason: Completion reason ("stop", "length", etc.)
       - usage: Token usage information
         * input_tokens: Tokens in the input
         * output_tokens: Tokens in the output
         * total_tokens: Total tokens used

    Key Differences from Legacy API:
    - Uses 'input' instead of 'messages' (though messages format is supported)
    - Reasoning configuration is a nested object, not separate parameters
    - Response uses 'output' field instead of 'choices[0].message'
    - Unified interface for both standard and reasoning models

    IMPORTANT: Chat Completions API Features:
    - reasoning_effort: ✅ SUPPORTED (controls reasoning depth for o1/o3 models)
    - reasoning_summary: ❌ NOT SUPPORTED (reasoning tokens are internal only)
      * Reasoning tokens are generated and billed, but not exposed in the response
      * Only the final answer is returned
    - structured_outputs: ✅ FULLY SUPPORTED via chat.completions.parse()

    Parameter Restrictions by Model Type:
    - Reasoning models (o1, o3, o4, gpt-5):
      * temperature: ❌ NOT SUPPORTED (only default temperature=1 allowed)
      * top_p: ❌ NOT SUPPORTED (only default top_p=1 allowed)
      * Reason: These models use internal chain-of-thought reasoning that would be
        disrupted by sampling parameter adjustments
      * Use reasoning_effort instead to control output quality
    - Standard models (gpt-4, gpt-3.5-turbo):
      * temperature: ✅ SUPPORTED (0.0-2.0)
      * top_p: ✅ SUPPORTED (0.0-1.0)
    """

    # Model-specific configurations
    REASONING_MODELS = ["o1", "o3", "o4", "gpt-5"]
    MAX_COMPLETION_TOKENS_MODELS = ["o1", "o3", "o4", "gpt-5"]
    VALID_REASONING_SUMMARY = ["none", "concise", "detailed", "auto"]

    # Parameter restrictions for reasoning models
    # Reasoning models use internal chain-of-thought and don't support sampling parameters
    MODELS_WITHOUT_TEMPERATURE = [
        "o1",
        "o3",
        "o4",
        "gpt-5",
    ]  # Only support temperature=1 (default)
    MODELS_WITHOUT_TOP_P = ["o1", "o3", "o4", "gpt-5"]  # Only support top_p=1 (default)

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        # Use provided base_url or fall back to OPENAI_BASE_URL env var
        url = base_url
        self.client = OpenAI(api_key=api_key, base_url=url)

    def get_model_info(self, model_name: str) -> LLMProvider.ModelInfo:
        """
        Return model limits for OpenAI models using an exhaustive static mapping.
        Note: OpenAI does not provide context window via API as of early 2026.
        """
        # Comprehensive OpenAI model metadata mapping (Updated: Jan 2026)
        # Merged context window and max output tokens for better maintainability
        model_metadata = {
            # GPT-5 Series (Flagship 2025-2026)
            "gpt-5.2": {"context_window": 400000, "max_output_tokens": 128000},
            "gpt-5.1": {"context_window": 400000, "max_output_tokens": 128000},
            "gpt-5-nano": {"context_window": 400000, "max_output_tokens": 128000},
            "gpt-5": {"context_window": 400000, "max_output_tokens": 128000},
            # o-series (Reasoning Models)
            "o3-mini": {"context_window": 200000, "max_output_tokens": 100000},
            "o3": {"context_window": 200000, "max_output_tokens": 100000},
            "o1": {"context_window": 200000, "max_output_tokens": 100000},
            "o4-mini": {"context_window": 200000, "max_output_tokens": 100000},
            "o1-preview": {"context_window": 128000, "max_output_tokens": 32768},
            "o1-mini": {"context_window": 128000, "max_output_tokens": 65536},
            # GPT-4.x Series
            "gpt-4.1": {"context_window": 1047576, "max_output_tokens": 32768},
            "gpt-4.1-mini": {"context_window": 1047576, "max_output_tokens": 32768},
            "gpt-4.1-nano": {"context_window": 1047576, "max_output_tokens": 32768},
            "gpt-4o": {"context_window": 128000, "max_output_tokens": 16384},
            "gpt-4o-mini": {"context_window": 128000, "max_output_tokens": 16384},
            "gpt-4-turbo": {"context_window": 128000, "max_output_tokens": 4096},
            "gpt-4": {"context_window": 8192, "max_output_tokens": 8192},
            # GPT-3.5 Series
            "gpt-3.5-turbo": {"context_window": 16385, "max_output_tokens": 4096},
            # Legacy & Specialized Models
            "davinci-002": {"context_window": 16384, "max_output_tokens": 16384},
            "babbage-002": {"context_window": 16384, "max_output_tokens": 16384},
            "gpt-oss": {"context_window": 131072, "max_output_tokens": 131072},
        }

        ctx = None
        max_out = None
        # Try to match by prefix (longest match first for accuracy)
        sorted_prefixes = sorted(model_metadata.keys(), key=len, reverse=True)
        for prefix in sorted_prefixes:
            if model_name.startswith(prefix):
                info = model_metadata[prefix]
                ctx = info.get("context_window")
                max_out = info.get("max_output_tokens")
                break

        return LLMProvider.ModelInfo(
            model_name=model_name,
            provider="openai",
            context_window=ctx,
            max_output_tokens=max_out,
        )

    def invoke(self, input_data: "LLMInvoker.ChatCompletionInput") -> Dict[str, Any]:
        """Execute OpenAI chat completion using chat.completions API.

        Uses chat.completions.parse() for structured outputs (Pydantic models)
        Uses chat.completions.create() for plain text responses
        """
        # Build parameters
        params = self._build_params(
            input_data.model_name,
            input_data.messages,
            input_data.temperature,
            input_data.max_output_tokens,
            input_data.reasoning_effort,
            input_data.response_schema,
            input_data.tools,
            input_data.tool_choice,
        )

        # Make API call - use parse() for structured outputs, create() for plain text
        if input_data.response_schema:
            raw = self.client.chat.completions.parse(**params)
        else:
            raw = self.client.chat.completions.create(**params)

        # Extract response
        return self._extract_response(raw, input_data.response_schema)

    def _build_params(
        self,
        model_name: str,
        messages: List[Dict],
        temperature: Optional[float],
        max_output_tokens: Optional[int],
        reasoning_effort: Optional[str],
        response_schema: Optional[Type[BaseModel]],
        tools: Optional[List[Dict[str, Any]]],
        tool_choice: Optional[Union[str, Dict[str, Any]]],
    ) -> Dict:
        """Build OpenAI Chat Completions API parameters."""
        # Process messages to handle local files in multimodal content
        processed_messages = []
        for msg in messages:
            new_msg = dict(msg)
            if isinstance(new_msg.get("content"), list):
                new_content = []
                for part in new_msg["content"]:
                    if part.get("type") == "image_url":
                        image_data = part.get("image_url", {})
                        url = image_data.get("url", "")
                        if url and not url.startswith(("http", "data:")):
                            # Assume local path, convert to base64
                            try:
                                with open(url, "rb") as f:
                                    data = base64.b64encode(f.read()).decode("utf-8")
                                mime_type, _ = mimetypes.guess_type(url)
                                new_content.append(
                                    {
                                        "type": "image_url",
                                        "image_url": {
                                            "url": f"data:{mime_type or 'image/jpeg'};base64,{data}"
                                        },
                                    }
                                )
                                continue
                            except Exception:
                                pass
                    new_content.append(part)
                new_msg["content"] = new_content
            processed_messages.append(new_msg)

        params = {"model": model_name, "messages": processed_messages}

        # Temperature - skip for reasoning models (they only support default temperature=1)
        if temperature is not None:
            if not self.model_matches(model_name, self.MODELS_WITHOUT_TEMPERATURE):
                params["temperature"] = temperature
            # else: silently skip temperature for reasoning models to avoid API errors

        # Max output tokens
        if max_output_tokens:
            # For reasoning models (o1, o3, etc.), use max_completion_tokens
            if self.model_matches(model_name, self.MAX_COMPLETION_TOKENS_MODELS):
                params["max_completion_tokens"] = max_output_tokens
            else:
                params["max_tokens"] = max_output_tokens

        # Reasoning effort (for reasoning models)
        if reasoning_effort and self.model_matches(model_name, self.REASONING_MODELS):
            params["reasoning_effort"] = reasoning_effort

        # Structured output - for parse() API, pass the Pydantic model directly
        if response_schema:
            params["response_format"] = response_schema

        # Tool calling - tools are already in OpenAI format, pass them directly
        if tools:
            params["tools"] = tools

            # Tool choice
            if tool_choice:
                params["tool_choice"] = tool_choice

        return params

    def _extract_response(
        self, raw, response_schema: Optional[Type[BaseModel]]
    ) -> Dict[str, Any]:
        """Extract standardized response from Chat Completions API response."""

        # Extract from choices[0]
        choice = raw.choices[0] if raw.choices else None
        if not choice:
            return {
                "response": None,
                "reasoning_summary": None,
                "tool_calls": None,
                "usage": {},
                "finish_reason": "error",
            }

        # Get message content
        message = choice.message
        response_content = None
        tool_calls = None

        # Check for tool calls
        if hasattr(message, "tool_calls") and message.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "type": tc.type,
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in message.tool_calls
            ]

        # Check for content (parsed or regular)
        if response_schema and hasattr(message, "parsed") and message.parsed:
            response_content = message.parsed
        elif hasattr(message, "content") and message.content:
            response_content = message.content

        result = {
            "response": response_content,
            "reasoning_summary": None,  # Not supported in chat.completions API
            "tool_calls": tool_calls,
            "usage": {},
            "finish_reason": (
                choice.finish_reason if hasattr(choice, "finish_reason") else "stop"
            ),
        }

        # Extract usage metadata
        if hasattr(raw, "usage") and raw.usage:
            u = raw.usage

            # Extract reasoning tokens from completion_tokens_details object
            reasoning_tokens = None
            if hasattr(u, "completion_tokens_details") and u.completion_tokens_details:
                reasoning_tokens = getattr(
                    u.completion_tokens_details, "reasoning_tokens", None
                )

            # Extract cached tokens from prompt_tokens_details object
            cached_tokens = None
            if hasattr(u, "prompt_tokens_details") and u.prompt_tokens_details:
                cached_tokens = getattr(u.prompt_tokens_details, "cached_tokens", None)

            result["usage"] = {
                "input_tokens": getattr(u, "prompt_tokens", None),
                "output_tokens": getattr(u, "completion_tokens", None),
                "reasoning_tokens": reasoning_tokens,
                "cached_tokens": cached_tokens,
                "total_tokens": getattr(u, "total_tokens", None),
            }

        return result


# ==================== OLLAMA PROVIDER ====================


class OllamaProvider(LLMProvider):
    """Ollama local models provider using the Chat API.

    Uses /api/chat endpoint which supports:
    - messages: Native messages array (system/user/assistant roles)
    - format: JSON schema for structured outputs
    - think: Reasoning output (boolean or "low"/"medium"/"high")
    - options: Model parameters (temperature, num_predict, etc.)
    """

    # Models that support level-based think parameter ("low", "medium", "high")
    # Most models only support boolean True/False
    THINK_LEVEL_MODELS = [
        "gpt-oss",
        # Add other models here as they gain level-based think support
    ]

    # Models that support the 'think' parameter (reasoning/thinking)
    THINKING_CAPABLE_MODELS = [
        "deepseek-r1",
        "qwen2.5",
        "qwq",
        "gpt-oss",
        "llama3.1",  # 70B and 405B variants support thinking
        # Note: llama3.2, gemma, mistral, and most other models do NOT support thinking
    ]

    # Models that support tool/function calling
    TOOL_CAPABLE_MODELS = [
        "llama3.1",
        "llama3.2",
        "mistral-nemo",
        "firefunction-v2",
        "qwen2.5",
        "command-r",
        "command-r-plus",
    ]

    def __init__(self, host_url: str):
        self.client = Client(host=host_url)

    def get_model_info(self, model_name: str) -> LLMProvider.ModelInfo:
        """Fetch model info dynamically from Ollama local API."""
        ctx_window = None
        max_out = None

        try:
            raw_info = self.client.show(model=model_name)

            # Support both 'modelinfo' (newer/user version) and 'model_info' (standard)
            info = getattr(raw_info, "modelinfo", None) or getattr(
                raw_info, "model_info", None
            )

            if info:
                # Exhaustive search for any relevant key
                # Covers architecture-prefixed keys (mistral.context_length, qwen3.context_length, etc.)
                for key, value in info.items():
                    k_lower = key.lower()

                    # 1. Context Window
                    if (
                        k_lower.endswith(".context_length")
                        or k_lower == "num_ctx"
                        or k_lower == "context_length"
                    ):
                        ctx_window = value

                    # 2. Max Output Tokens (rarely in modelinfo, but check keys like .max_tokens)
                    if k_lower.endswith(".max_tokens") or k_lower.endswith(
                        ".num_predict"
                    ):
                        max_out = value

            # 3. Check for num_predict in the 'parameters' string (most common for Ollama)
            params_str = getattr(raw_info, "parameters", "")
            if params_str:
                import re

                # Match "num_predict 4096" or "num_predict: 4096"
                match = re.search(r"num_predict\s+[:]?\s*(\d+)", params_str)
                if match:
                    max_out = int(match.group(1))

        except Exception as e:
            # Silent fail to return partial info if possible
            pass

        return LLMProvider.ModelInfo(
            model_name=model_name,
            provider="ollama",
            context_window=ctx_window,
            max_output_tokens=max_out,
        )

    def invoke(self, input_data: "LLMInvoker.ChatCompletionInput") -> Dict[str, Any]:
        """Execute Ollama chat completion."""
        # Warn if tools are provided but model doesn't support them
        if input_data.tools:
            model_base = input_data.model_name.split(":")[0]  # Get base model name
            if not any(
                model_base.startswith(capable) for capable in self.TOOL_CAPABLE_MODELS
            ):
                import warnings

                warnings.warn(
                    f"Model '{input_data.model_name}' may not support tool calling. "
                    f"Tool-capable models include: {', '.join(self.TOOL_CAPABLE_MODELS)}. "
                    f"The model may ignore tools and generate a direct text response instead.",
                    UserWarning,
                )

        # Build all parameters including model, messages, options, format, and think
        params = self._build_params(
            input_data.model_name,
            input_data.messages,
            input_data.temperature,
            input_data.max_output_tokens,
            input_data.reasoning_effort,
            input_data.reasoning_summary,
            input_data.response_schema,
            input_data.tools,
        )

        # Make API call
        raw = self.client.chat(**params)

        # Parse structured output if schema provided
        if input_data.response_schema:
            content = raw["message"]["content"]
            # Clean JSON from markdown code blocks if needed
            if "```" in content:
                content = (
                    content.split("```json")[-1].split("```")[0].strip()
                    if "```json" in content
                    else content.split("```")[1].strip()
                )
            result = self._extract_response(raw)
            result["response"] = input_data.response_schema.model_validate_json(content)
            return result
        else:
            return self._extract_response(raw)

    def _build_params(
        self,
        model_name: str,
        messages: List[Dict],
        temperature: Optional[float],
        max_output_tokens: Optional[int],
        reasoning_effort: Optional[str],
        reasoning_summary: Optional[str],
        response_schema: Optional[Type[BaseModel]],
        tools: Optional[List[Dict[str, Any]]],
    ) -> Dict:
        """Build Ollama chat API parameters."""
        # Process messages for multimodal content
        processed_messages = []
        for msg in messages:
            # Create a clean message with only keys Ollama expects
            new_msg = {"role": msg.get("role"), "content": msg.get("content", "")}

            # Add tool_calls if present
            if "tool_calls" in msg:
                new_msg["tool_calls"] = msg["tool_calls"]

            content = new_msg.get("content")

            if isinstance(content, list):
                text_content = ""
                images = []
                for part in content:
                    if part.get("type") == "text":
                        text_content += part.get("text", "")
                    elif part.get("type") == "image_url":
                        image_data = part.get("image_url", {})
                        url = image_data.get("url", "")
                        if url:
                            try:
                                # Warn if the model name doesn't contain common vision indicators
                                model_lower = model_name.lower()
                                if (
                                    "vision" not in model_lower
                                    and "llava" not in model_lower
                                ):
                                    import warnings

                                    warnings.warn(
                                        f"Model '{model_name}' may not follow multimodal inputs. "
                                        f"Please ensure you use a vision-capable model (e.g., llama3.2-vision, llava).",
                                        UserWarning,
                                    )

                                if url.startswith("data:"):
                                    # Extract base64 from data URI
                                    encoded = url.split(",", 1)[1]
                                    images.append(encoded)
                                elif url.startswith(("http", "https")):
                                    # Remote URL - Fetching not yet implemented in this simplified SDK
                                    pass
                                else:
                                    # READ LOCAL FILE AND ENCODE TO BASE64
                                    # Base64 strings are the native REST API format for Ollama
                                    if os.path.exists(url):
                                        with open(url, "rb") as f:
                                            images.append(
                                                base64.b64encode(f.read()).decode(
                                                    "utf-8"
                                                )
                                            )
                            except Exception:
                                pass

                new_msg["content"] = text_content
                if images:
                    new_msg["images"] = images

            processed_messages.append(new_msg)

        # Base parameters
        params = {
            "model": model_name,
            "messages": processed_messages,
        }

        # Build options (temperature, num_predict)
        options = {}
        if temperature is not None:
            options["temperature"] = temperature
        if max_output_tokens:
            options["num_predict"] = max_output_tokens

        if options:
            params["options"] = options

        # Add format parameter for structured output
        if response_schema:
            params["format"] = response_schema.model_json_schema()

        # Map reasoning parameters to 'think'
        think = self._map_reasoning(model_name, reasoning_effort, reasoning_summary)
        if think is not None:
            params["think"] = think

        # Tool calling - tools are already in OpenAI format, pass them directly
        if tools:
            params["tools"] = tools

        return params

    def _map_reasoning(
        self, model_name: str, effort: Optional[str], summary: Optional[str]
    ) -> Any:
        """Map reasoning_effort and reasoning_summary to Ollama's think parameter.

        Valid Values:
        - reasoning_effort: ["none", "low", "medium", "high", "dynamic"]
        - reasoning_summary: ["none", "concise", "detailed", "auto"]

        Priority Logic:
        1. Check if model supports thinking at all - if not, return None
        2. If reasoning_effort is low/medium/high AND model supports levels -> use that value
        3. If reasoning_effort is low/medium/high BUT model doesn't support levels -> set think=True
        4. If reasoning_effort is "dynamic" -> set think=True (let model decide)
        5. If reasoning_summary is set (not "none") -> set think=True
        6. Otherwise -> return None

        Note: Only models in THINK_LEVEL_MODELS support "low"/"medium"/"high" values.
              Other models (DeepSeek, Qwen, etc.) only support True/False.
        """
        # Check if model supports thinking at all
        model_base = model_name.split(":")[0]
        supports_thinking = any(
            model_base.startswith(capable) for capable in self.THINKING_CAPABLE_MODELS
        )

        if not supports_thinking:
            # Model doesn't support thinking - don't add 'think' parameter
            return None

        # Check if model supports level-based thinking
        supports_levels = any(
            model_name.startswith(prefix) for prefix in self.THINK_LEVEL_MODELS
        )

        # Priority 2 & 3: Explicit effort level
        if effort and effort in ["low", "medium", "high"]:
            if supports_levels:
                return effort  # Return level for GPT-OSS-like models
            else:
                return True  # Return boolean for DeepSeek/Qwen-like models

        # Priority 4: Dynamic reasoning effort (let model decide)
        if effort == "dynamic":
            return True

        # Priority 5: Summary requested (enable thinking)
        if summary and summary in ["concise", "detailed", "auto"]:
            return True

        return None

    def _extract_response(self, raw) -> Dict[str, Any]:
        """Extract standardized response from Ollama Chat API response."""
        pt = raw.get("prompt_eval_count")
        ot = raw.get("eval_count")

        # Extract message object (ollama._types.Message)
        message = raw.get("message")

        # Extract content and thinking using getattr (message is an object, not dict)
        content = getattr(message, "content", None) if message else None
        thinking = getattr(message, "thinking", None) if message else None

        # Extract tool calls if present
        tool_calls = None
        if message and hasattr(message, "tool_calls") and message.tool_calls:
            tool_calls = [
                {
                    "id": f"call_{i}",  # Ollama may not provide IDs
                    "type": "function",
                    "function": {
                        "name": (
                            tc.function.name
                            if hasattr(tc, "function")
                            else tc.get("name", "")
                        ),
                        "arguments": (
                            json.dumps(tc.function.arguments)
                            if hasattr(tc, "function")
                            and hasattr(tc.function, "arguments")
                            else tc.get("arguments", "{}")
                        ),
                    },
                }
                for i, tc in enumerate(message.tool_calls)
            ]

        return {
            "response": content,
            "reasoning_summary": thinking,
            "tool_calls": tool_calls,
            "usage": {
                "input_tokens": pt,
                "output_tokens": ot,
                "total_tokens": (pt or 0) + (ot or 0) or None,
            },
            "finish_reason": raw.get("done_reason", "stop"),
        }


# ==================== MAIN LLM INVOKER ====================


class LLMInvoker:
    """
    Universal LLM invoker that routes requests to appropriate providers.

    Supports OpenAI, Google Gemini, and Ollama with a unified interface.
    """

    # --- NESTED CLASSES ---

    class FileInfo(BaseModel):
        """Metadata for files/images passed to the LLM."""

        path: Optional[str] = None
        url: Optional[str] = None
        base64: Optional[str] = None
        mime_type: Optional[str] = None

        def get_bytes(self) -> bytes:
            """Retrieve file content as bytes."""
            if self.base64:
                return base64.b64decode(self.base64)
            if self.path:
                with open(self.path, "rb") as f:
                    return f.read()
            # Note: URL fetching would need a library like httpx/requests
            raise ValueError("No data source found for FileInfo")

        def get_mime_type(self) -> str:
            """Determine mime type of the file."""
            if self.mime_type:
                return self.mime_type
            if self.path:
                mime, _ = mimetypes.guess_type(self.path)
                return mime or "application/octet-stream"
            return "application/octet-stream"

    class ChatCompletionInput(BaseModel):
        """Input parameters for chat completion requests with built-in validation."""

        VALID_PROVIDERS: ClassVar[List[str]] = ["gemini", "openai", "ollama"]
        VALID_REASONING_EFFORTS: ClassVar[List[str]] = [
            "none",
            "low",
            "medium",
            "high",
            "dynamic",
        ]
        VALID_REASONING_SUMMARIES: ClassVar[List[str]] = [
            "none",
            "concise",
            "detailed",
            "auto",
        ]
        VALID_MESSAGE_ROLES: ClassVar[List[str]] = [
            "system",
            "user",
            "assistant",
            "developer",
            "tool",
        ]

        MIN_TEMPERATURE: ClassVar[float] = 0.0
        MAX_TEMPERATURE: ClassVar[float] = 2.0
        MIN_GEMINI_THINKING_BUDGET: ClassVar[int] = 0
        MAX_GEMINI_THINKING_BUDGET: ClassVar[int] = 24576

        provider: Literal["gemini", "openai", "ollama"]
        model_name: str = Field(..., min_length=1, description="Model identifier")
        messages: List[Dict[str, Any]] = Field(
            ..., min_length=1, description="Conversation messages"
        )
        api_key: Optional[str] = None
        host_url: Optional[str] = None
        response_schema: Optional[Type[BaseModel]] = None
        temperature: Optional[float] = Field(
            None,
            ge=MIN_TEMPERATURE,
            le=MAX_TEMPERATURE,
            description="Sampling temperature (0.0-2.0)",
        )
        max_output_tokens: Optional[int] = Field(
            None, gt=0, description="Maximum output tokens"
        )
        reasoning_effort: Optional[
            Literal["none", "low", "medium", "high", "dynamic"]
        ] = None
        reasoning_summary: Optional[Literal["none", "concise", "detailed", "auto"]] = (
            None
        )
        gemini_thinking_budget: Optional[int] = Field(
            None,
            ge=MIN_GEMINI_THINKING_BUDGET,
            le=MAX_GEMINI_THINKING_BUDGET,
            description="Gemini thinking budget (0-24576)",
        )
        tools: Optional[List[Dict[str, Any]]] = Field(
            None, description="List of tools in OpenAI format"
        )
        tool_choice: Optional[Union[str, Dict[str, Any]]] = Field(
            None,
            description="Controls which tool to call. Can be 'auto', 'none', 'required', or specific tool name",
        )

        @field_validator("messages")
        @classmethod
        def validate_messages(cls, v):
            """Ensure messages have required fields and valid roles."""
            if not v:
                raise ValueError("Messages list cannot be empty")

            for i, msg in enumerate(v):
                if not isinstance(msg, dict):
                    raise ValueError(f"Message {i} must be a dictionary")
                if "role" not in msg:
                    raise ValueError(f"Message {i} missing 'role' field")
                if msg["role"] not in cls.VALID_MESSAGE_ROLES:
                    raise ValueError(f"Message {i} has invalid role '{msg['role']}'.")
                if "content" not in msg:
                    raise ValueError(f"Message {i} missing 'content' field")
                content = msg["content"]
                if not isinstance(content, (str, list, type(None))):
                    raise ValueError(
                        f"Message {i} content must be a string, list, or None"
                    )
                if (
                    content is None
                    or (isinstance(content, str) and not content.strip())
                    or (isinstance(content, list) and not content)
                ):
                    has_tool_calls = "tool_calls" in msg and msg.get("tool_calls")
                    is_tool_role = msg["role"] == "tool"
                    if not has_tool_calls and not is_tool_role:
                        raise ValueError(
                            f"Message {i} content cannot be empty unless tool_calls are present"
                        )
            return v

        model_config = {"validate_assignment": True}

    class UsageMetadata(BaseModel):
        """Token usage information across all providers."""

        input_tokens: Optional[int] = None
        output_tokens: Optional[int] = None
        reasoning_tokens: Optional[int] = None
        cached_tokens: Optional[int] = None
        total_tokens: Optional[int] = None

    class TimingInfo(BaseModel):
        """Request timing information."""

        start_time: Optional[str] = None
        end_time: Optional[str] = None
        latency_ms: Optional[float] = None

    class ChatCompletionResponse(BaseModel):
        """Unified response format across all providers."""

        response: Union[BaseModel, str, None]
        reasoning_summary: Optional[str] = None
        tool_calls: Optional[List[Dict[str, Any]]] = Field(
            None, description="Tool calls requested by the model."
        )
        usage: "LLMInvoker.UsageMetadata" = Field(
            default_factory=lambda: LLMInvoker.UsageMetadata()
        )
        timing: "LLMInvoker.TimingInfo" = Field(
            default_factory=lambda: LLMInvoker.TimingInfo()
        )
        finish_reason: Optional[str] = None
        input_parameters: "LLMInvoker.ChatCompletionInput"
        success: bool = True
        error_message: Optional[str] = None

    class ToolExecutor:
        """Utility class for executing tool calls returned by LLM models."""

        def __init__(self, tools_map: Dict[str, Any]):
            self.tools_map = tools_map

        def execute(
            self,
            tool_calls: Optional[List[Dict[str, Any]]],
            parallel: bool = True,
            timeout: Optional[float] = 30.0,
        ) -> List[Dict[str, Any]]:
            if not tool_calls:
                return []
            if parallel:
                return self._execute_parallel(tool_calls, timeout)
            return self._execute_sequential(tool_calls, timeout)

        def _execute_sequential(
            self, tool_calls: List[Dict[str, Any]], timeout: Optional[float]
        ) -> List[Dict[str, Any]]:
            return [self._execute_single(tc, timeout) for tc in tool_calls]

        def _execute_parallel(
            self, tool_calls: List[Dict[str, Any]], timeout: Optional[float]
        ) -> List[Dict[str, Any]]:
            from concurrent.futures import (
                ThreadPoolExecutor,
                TimeoutError as FutureTimeoutError,
            )

            results = []
            with ThreadPoolExecutor(max_workers=min(len(tool_calls), 10)) as executor:
                futures = {
                    executor.submit(self._execute_single, tc, timeout): tc
                    for tc in tool_calls
                }
                for tool_call in tool_calls:
                    future = next(f for f, tc in futures.items() if tc == tool_call)
                    try:
                        results.append(future.result(timeout=timeout))
                    except Exception as e:
                        results.append(self._format_error_response(tool_call, str(e)))
            return results

        def _execute_single(
            self, tool_call: Dict[str, Any], timeout: Optional[float]
        ) -> Dict[str, Any]:
            tool_call_id = tool_call.get("id", "unknown")
            function_info = tool_call.get("function", {})
            function_name = function_info.get("name", "")
            arguments_str = function_info.get("arguments", "{}")
            try:
                arguments = (
                    json.loads(arguments_str)
                    if isinstance(arguments_str, str)
                    else arguments_str
                )
                if function_name not in self.tools_map:
                    return self._format_error_response(
                        tool_call, f"Unknown function: {function_name}"
                    )
                result = self.tools_map[function_name](**arguments)
                content = (
                    json.dumps(result)
                    if isinstance(result, (dict, list))
                    else str(result)
                )
                return {
                    "role": "tool",
                    "tool_call_id": tool_call_id,
                    "content": content,
                }
            except Exception as e:
                return self._format_error_response(tool_call, str(e))

        def _format_error_response(
            self, tool_call: Dict[str, Any], error_message: str
        ) -> Dict[str, Any]:
            return {
                "role": "tool",
                "tool_call_id": tool_call.get("id", "unknown"),
                "content": json.dumps({"error": error_message}),
            }

    # --- END NESTED CLASSES ---

    PROVIDER_MAP = {
        "gemini": GeminiProvider,
        "openai": OpenAIProvider,
        "ollama": OllamaProvider,
    }

    def _get_invoker(
        self,
        provider: str,
        api_key: Optional[str] = None,
        host_url: Optional[str] = None,
    ):
        if provider not in self.PROVIDER_MAP:
            raise ValueError(f"Unknown provider: {provider}")
        provider_class = self.PROVIDER_MAP[provider]
        if provider == "ollama":
            return provider_class(host_url=host_url)
        elif provider == "openai":
            return provider_class(api_key=api_key, base_url=host_url)
        return provider_class(api_key=api_key)

    def _normalize_tool_calls_for_provider(
        self, tool_calls: Optional[List[Dict[str, Any]]], provider: str
    ) -> Optional[List[Dict[str, Any]]]:
        if not tool_calls:
            return tool_calls
        normalized = []
        for tc in tool_calls:
            normalized_tc = tc.copy()
            if "function" in normalized_tc:
                func = normalized_tc["function"].copy()
                arguments = func.get("arguments")
                if provider == "ollama":
                    if isinstance(arguments, str):
                        try:
                            func["arguments"] = json.loads(arguments)
                        except json.JSONDecodeError:
                            func["arguments"] = {}
                else:
                    if isinstance(arguments, dict):
                        func["arguments"] = json.dumps(arguments)
                normalized_tc["function"] = func
            normalized.append(normalized_tc)
        return normalized

    def get_model_info(
        self,
        provider: str,
        model_name: str,
        api_key: Optional[str] = None,
        host_url: Optional[str] = None,
    ) -> LLMProvider.ModelInfo:
        invoker = self._get_invoker(provider, api_key, host_url)
        return invoker.get_model_info(model_name)

    def chat_completion(
        self, input_data: "LLMInvoker.ChatCompletionInput"
    ) -> ChatCompletionResponse:
        start_timestamp = datetime.now(timezone.utc)
        error_msg, success = None, True
        try:
            provider = self._get_invoker(
                input_data.provider, input_data.api_key, input_data.host_url
            )
            extracted = provider.invoke(input_data)
        except Exception as e:
            success, error_msg = False, str(e)
            extracted = {"response": None, "usage": {}, "finish_reason": "error"}
        end_timestamp = datetime.now(timezone.utc)
        latency_ms = (end_timestamp - start_timestamp).total_seconds() * 1000
        return self.ChatCompletionResponse(
            response=extracted.get("response"),
            reasoning_summary=extracted.get("reasoning_summary"),
            tool_calls=extracted.get("tool_calls"),
            usage=self.UsageMetadata(**extracted.get("usage", {})),
            timing=self.TimingInfo(
                start_time=start_timestamp.isoformat(),
                end_time=end_timestamp.isoformat(),
                latency_ms=latency_ms,
            ),
            finish_reason=extracted.get("finish_reason"),
            input_parameters=input_data,
            success=success,
            error_message=error_msg,
        )

    def chat_completion_with_tools(
        self,
        input_data: "LLMInvoker.ChatCompletionInput",
        tool_executor: ToolExecutor,
        max_iterations: int = 5,
        verbose: bool = False,
    ) -> ChatCompletionResponse:
        messages = list(input_data.messages)
        iteration = 0
        while iteration < max_iterations:
            iteration += 1
            current_input = self.ChatCompletionInput(
                provider=input_data.provider,
                model_name=input_data.model_name,
                messages=messages,
                api_key=input_data.api_key,
                host_url=input_data.host_url,
                response_schema=input_data.response_schema,
                temperature=input_data.temperature,
                max_output_tokens=input_data.max_output_tokens,
                reasoning_effort=input_data.reasoning_effort,
                reasoning_summary=input_data.reasoning_summary,
                gemini_thinking_budget=input_data.gemini_thinking_budget,
                tools=input_data.tools,
                tool_choice=input_data.tool_choice,
            )
            response = self.chat_completion(current_input)
            if not response.success:
                return response
            if not response.tool_calls:
                if response.response and response.response.strip():
                    return response
                continue
            normalized_tool_calls = self._normalize_tool_calls_for_provider(
                response.tool_calls, input_data.provider
            )
            messages.append(
                {
                    "role": "assistant",
                    "content": response.response or "",
                    "tool_calls": normalized_tool_calls,
                }
            )
            tool_messages = tool_executor.execute(response.tool_calls, parallel=True)
            messages.extend(tool_messages)
        final_input = self.ChatCompletionInput(
            provider=input_data.provider,
            model_name=input_data.model_name,
            messages=messages,
            api_key=input_data.api_key,
            host_url=input_data.host_url,
            response_schema=input_data.response_schema,
            temperature=input_data.temperature,
            max_output_tokens=input_data.max_output_tokens,
            reasoning_effort=input_data.reasoning_effort,
            reasoning_summary=input_data.reasoning_summary,
            gemini_thinking_budget=input_data.gemini_thinking_budget,
            tools=None,
            tool_choice=None,
        )
        final_response = self.chat_completion(final_input)
        input_data.messages = messages
        return final_response
