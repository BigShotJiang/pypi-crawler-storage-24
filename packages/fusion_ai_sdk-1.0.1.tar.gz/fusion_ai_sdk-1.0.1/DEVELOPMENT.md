# Development Guide

This document covers how to set up a local development environment, build, and publish the `fusion-ai-sdk` package to PyPI.

## Setup

Install all dependencies (including dev tools) using `uv`:

```bash
uv sync --dev
```

## Building the Package

To build the distribution bundles (`.tar.gz` source distribution and `.whl` wheel):

```bash
uv build
```

This generates the package files inside the `dist/` directory.

## Publishing to PyPI

To upload the built package to the Python Package Index:

```bash
uv publish
```

You will be prompted to supply your **PyPI API token**. You can generate one at [pypi.org/manage/account/token](https://pypi.org/manage/account/token/).

### Publishing to TestPyPI (recommended for validation)

Before pushing to the real PyPI, you can test the upload on TestPyPI:

```bash
uv publish --publish-url https://test.pypi.org/legacy/
```

## Versioning

Update the `version` field in `pyproject.toml` before each release:

```toml
[project]
name = "fusion-ai-sdk"
version = "1.1.0"  # <-- bump this
```

Then tag the release in Git:

```bash
git tag -a v1.1.0 -m "Release v1.1.0"
git push origin v1.1.0
```
