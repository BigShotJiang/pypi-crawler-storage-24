sqli_pattern_time = 0.1
ssti_pattern_time = 0.1
xss_pattern_time = 0.2