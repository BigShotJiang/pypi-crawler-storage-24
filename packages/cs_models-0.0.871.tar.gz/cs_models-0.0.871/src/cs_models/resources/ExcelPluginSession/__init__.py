"""ExcelPluginSession resource."""
