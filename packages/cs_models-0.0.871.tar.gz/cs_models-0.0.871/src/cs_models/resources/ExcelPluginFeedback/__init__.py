"""ExcelPluginFeedback resource."""
