from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    Boolean,
    ForeignKey,
    Text,
    UniqueConstraint,
    Index,
)

from ...database import Base


class ConferencePlannerAbstractModel(Base):
    __tablename__ = 'conference_planner_abstracts'

    id = Column(Integer, primary_key=True)
    planner_id = Column(
        Integer,
        ForeignKey('conference_planners.id'),
        nullable=False,
    )
    pubmed_id = Column(
        Integer,
        ForeignKey('pubmed.id'),
        nullable=False,
    )
    artifact_id = Column(String(64), nullable=False)
    sequence_number = Column(Integer, nullable=False)
    row_payload = Column(Text, nullable=True)
    is_deleted = Column(Boolean, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        UniqueConstraint('planner_id', 'pubmed_id', name='uq_conference_planner_abstracts_planner_pubmed'),
        Index('idx_conference_planner_abstracts_planner_sequence', 'planner_id', 'sequence_number'),
    )
