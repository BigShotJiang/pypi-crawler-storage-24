from marshmallow import (
    Schema,
    fields,
)


class ConferencePlannerAbstractResourceSchema(Schema):
    id = fields.Integer(dump_only=True)
    planner_id = fields.Integer(required=True)
    pubmed_id = fields.Integer(required=True)
    artifact_id = fields.String(required=True)
    sequence_number = fields.Integer(required=True)
    row_payload = fields.String(allow_none=True)
    is_deleted = fields.Boolean(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)
