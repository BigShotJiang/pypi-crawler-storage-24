"""Tools for input transformations"""
