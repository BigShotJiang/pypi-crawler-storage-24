"""AlphaBeta kernel"""
