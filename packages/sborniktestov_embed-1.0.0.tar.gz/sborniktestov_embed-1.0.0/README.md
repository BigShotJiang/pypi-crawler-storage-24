# sborniktestov-embed

Embed interactive quizzes from [sborniktestov.ru](https://sborniktestov.ru/) into any website. 15,000+ quizzes: personality tests, knowledge checks, professional assessments, and more.

Python library + CLI tool. Generates the HTML that the [embed loader](https://sborniktestov.ru/embed/) expects.

## Install

```bash
pip install sborniktestov-embed
```

## Python API

```python
from sborniktestov_embed import Embed

# Basic embed
e = Embed(12345)
print(e.render())

# Customized
e = Embed(12345,
    comments="1",
    header="0",
    color_accent="4CAF50",
    color_bg="f5f5f5",
    radius="12",
    font_question="18",
)
print(e.render())
```

### Output

```html
<div class="st-embed" data-quiz-id="12345" data-comments="1" data-color-accent="4CAF50">
  <a href="https://sborniktestov.ru">Sbornik Testov</a>
</div>
<script async src="https://sborniktestov.ru/embed/loader.js"></script>
```

### Methods

```python
e.render()      # Full HTML: div + script
e.div()         # Container div only (when loader.js is already on page)
e.script()      # Script tag only
e.iframe_url()  # Direct iframe URL (bypassing loader.js)
```

## CLI

```bash
# Full embed code
sborniktestov-embed 12345

# Just the iframe URL
sborniktestov-embed 12345 --url-only

# Customized
sborniktestov-embed 12345 --comments --no-header --color-accent 4CAF50 --radius 12

# Div only (when you have multiple quizzes and one script tag)
sborniktestov-embed 12345 --div-only
```

## Available Options

**Display:** `comments`, `related`, `header`, `desc`, `stats` (all 0/1)

**Layout:** `width`, `min_height`, `max_width`

**Colors (hex, no #):** `color_accent`, `color_bg`, `color_title`, `color_text`, `color_btn_text`, `color_selected_bg`, `color_progress_bg`, `color_progress_fill`, `color_border`, `color_border_selected`, `color_btn_prev`, `color_hover`

**Typography (px):** `font_title`, `font_desc`, `font_stats`, `font_question`, `font_answer`, `radius`, `padding`

## CMS Plugins

- [WordPress](https://wordpress.org/plugins/quiz-embed/) — `[sborniktestov id="12345"]`
- [Joomla](https://extensions.joomla.org/extension/sborniktestov/) — `{sborniktestov id=12345}`
- [Moodle](https://moodle.org/plugins/filter_sborniktestov) — auto-embed filter
- [Drupal](https://www.drupal.org/project/sborniktestov) — module

## Visual Configurator

Use the [embed configurator](https://sborniktestov.ru/embed/) to customize with a live preview.

## License

MIT — [sborniktestov.ru](https://sborniktestov.ru/)
