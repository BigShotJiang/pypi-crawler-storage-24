"""CLI: generate sborniktestov.ru embed code."""

import argparse
from . import Embed


def main():
    p = argparse.ArgumentParser(description="Generate embed code for sborniktestov.ru quizzes")
    p.add_argument("quiz_id", type=int, help="Quiz ID (from sborniktestov.ru/quiz/ID)")
    p.add_argument("--comments", action="store_true", help="Show comments")
    p.add_argument("--related", action="store_true", help="Show related quizzes")
    p.add_argument("--no-header", action="store_true", help="Hide title")
    p.add_argument("--no-desc", action="store_true", help="Hide description")
    p.add_argument("--no-stats", action="store_true", help="Hide statistics")
    p.add_argument("--color-accent", help="Accent color (hex, no #)")
    p.add_argument("--color-bg", help="Background color (hex, no #)")
    p.add_argument("--color-text", help="Text color (hex, no #)")
    p.add_argument("--radius", type=int, help="Border radius (px)")
    p.add_argument("--max-width", type=int, help="Max content width (px)")
    p.add_argument("--url-only", action="store_true", help="Print only the iframe URL")
    p.add_argument("--div-only", action="store_true", help="Print only the div (no script tag)")

    args = p.parse_args()

    kwargs = {}
    if args.comments:    kwargs["comments"] = "1"
    if args.related:     kwargs["related"] = "1"
    if args.no_header:   kwargs["header"] = "0"
    if args.no_desc:     kwargs["desc"] = "0"
    if args.no_stats:    kwargs["stats"] = "0"
    if args.color_accent: kwargs["color_accent"] = args.color_accent
    if args.color_bg:    kwargs["color_bg"] = args.color_bg
    if args.color_text:  kwargs["color_text"] = args.color_text
    if args.radius:      kwargs["radius"] = args.radius
    if args.max_width:   kwargs["max_width"] = args.max_width

    embed = Embed(args.quiz_id, **kwargs)

    if args.url_only:
        print(embed.iframe_url())
    elif args.div_only:
        print(embed.div())
    else:
        print(embed.render())


if __name__ == "__main__":
    main()
