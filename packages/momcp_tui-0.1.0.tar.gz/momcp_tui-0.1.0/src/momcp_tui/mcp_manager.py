from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, Optional

import contextlib

import httpx
from mcp import ClientSession, StdioServerParameters
from mcp.client.streamable_http import streamable_http_client
from mcp.client.stdio import stdio_client


@dataclass
class MCPServerConfig:
    name: str
    type: str = "stdio"  # stdio | streamableHttp
    # stdio
    command: Optional[str] = None
    args: Optional[list[str]] = None
    env: Optional[dict[str, str]] = None
    # streamableHttp
    url: Optional[str] = None
    headers: Optional[dict[str, str]] = None


class MCPManager:
    def __init__(self) -> None:
        self._loop = asyncio.new_event_loop()
        self._servers: dict[str, MCPServerConfig] = {}
        self._sessions: dict[str, ClientSession] = {}
        self._stacks: dict[str, contextlib.AsyncExitStack] = {}

    def register_server(self, cfg: MCPServerConfig) -> None:
        self._servers[cfg.name] = cfg

    def is_connected(self, name: str) -> bool:
        return name in self._sessions

    def connect(self, name: str) -> None:
        cfg = self._servers[name]
        asyncio.run_coroutine_threadsafe(self._connect_async(cfg), self._loop).result()

    def disconnect(self, name: str) -> None:
        asyncio.run_coroutine_threadsafe(self._disconnect_async(name), self._loop).result()

    def list_tools(self, name: str) -> list[dict[str, Any]]:
        result = asyncio.run_coroutine_threadsafe(self._list_tools_async(name), self._loop).result()
        return list(result or [])

    def call_tool(self, name: str, tool_name: str, arguments: dict[str, Any]) -> Any:
        return asyncio.run_coroutine_threadsafe(
            self._call_tool_async(name, tool_name, arguments), self._loop
        ).result()

    def start_loop_in_thread(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    async def _connect_async(self, cfg: MCPServerConfig) -> None:
        if cfg.name in self._sessions:
            return
        stack = contextlib.AsyncExitStack()
        try:
            if cfg.type == "streamableHttp":
                if not cfg.url:
                    raise ValueError("streamableHttp server 缺少 url")
                http_client = httpx.AsyncClient(
                    headers=cfg.headers or {},
                    timeout=httpx.Timeout(10.0, read=30.0),
                )
                await stack.enter_async_context(http_client)
                transport_cm = streamable_http_client(cfg.url, http_client=http_client)
                read, write, _get_session_id = await stack.enter_async_context(transport_cm)
                session = await stack.enter_async_context(ClientSession(read, write))
                await session.initialize()
                self._sessions[cfg.name] = session
                self._stacks[cfg.name] = stack
                return

            if not cfg.command:
                raise ValueError("stdio server 缺少 command")
            params = StdioServerParameters(command=cfg.command, args=cfg.args or [], env=cfg.env)
            transport_cm = stdio_client(params)
            read, write = await stack.enter_async_context(transport_cm)
            session = await stack.enter_async_context(ClientSession(read, write))
            await session.initialize()
            self._sessions[cfg.name] = session
            self._stacks[cfg.name] = stack
        except Exception:
            await stack.aclose()
            raise

    async def _disconnect_async(self, name: str) -> None:
        self._sessions.pop(name, None)
        stack = self._stacks.pop(name, None)
        if stack is not None:
            await stack.aclose()

    async def _list_tools_async(self, name: str) -> list[Dict[str, Any]]:
        if name not in self._sessions:
            await self._connect_async(self._servers[name])
        session = self._sessions[name]
        resp = await session.list_tools()
        return [t.model_dump() if hasattr(t, "model_dump") else dict(t) for t in resp.tools]

    async def _call_tool_async(self, name: str, tool_name: str, arguments: dict[str, Any]) -> Any:
        if name not in self._sessions:
            await self._connect_async(self._servers[name])
        session = self._sessions[name]
        resp = await session.call_tool(tool_name, arguments)
        if hasattr(resp, "model_dump"):
            return resp.model_dump()
        return resp

