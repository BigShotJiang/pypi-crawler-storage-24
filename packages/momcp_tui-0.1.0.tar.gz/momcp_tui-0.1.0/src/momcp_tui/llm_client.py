from __future__ import annotations

import os
import json
from typing import Any, Dict, Iterable, Iterator, List, Optional, TypedDict

import httpx

from .config import LLMConfig


class ChatResult(TypedDict):
    content: str
    reasoning: Optional[str]


class ChatStreamEvent(TypedDict, total=False):
    content_delta: str
    reasoning_delta: str
    done: bool


class ToolFunction(TypedDict):
    name: str
    arguments: str


class ToolCall(TypedDict):
    id: str
    type: str
    function: ToolFunction


class ChatToolsResult(TypedDict, total=False):
    content: str
    reasoning: Optional[str]
    tool_calls: list[ToolCall]


class LLMClient:
    def __init__(self, cfg: LLMConfig) -> None:
        self.cfg = cfg

    def _get_api_key(self) -> str:
        key = self.cfg.get_api_key()
        if key:
            return key
        return os.getenv("OPENAI_API_KEY", "")

    def _build_headers(self) -> Dict[str, str]:
        headers = {
            "Content-Type": "application/json",
        }
        key = self._get_api_key()
        if key:
            headers["Authorization"] = f"Bearer {key}"
        return headers

    def chat(self, messages: List[Dict[str, str]]) -> ChatResult:
        if not self._get_api_key():
            raise RuntimeError(
                f"当前模型（{self.cfg.provider}）未配置 API KEY。"
                "请使用 /model set 切换模型后按提示输入，或使用 /api_key set 设置。"
            )

        url = self.cfg.base_url.rstrip("/") + "/chat/completions"
        payload: Dict[str, Any] = {
            "model": self.cfg.model,
            "messages": messages,
        }

        with httpx.Client(timeout=60) as client:
            resp = client.post(url, headers=self._build_headers(), json=payload)
            resp.raise_for_status()
            data = resp.json()

        try:
            message = data["choices"][0]["message"]
            content = message.get("content") or ""
            # 兼容 DeepSeek / 部分 OpenAI-compat：reasoning_content
            reasoning = message.get("reasoning_content")
            if reasoning is not None and reasoning == "":
                reasoning = None
            return {"content": content, "reasoning": reasoning}
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(f"LLM 响应解析失败: {data}") from exc

    def chat_stream(self, messages: List[Dict[str, str]]) -> Iterator[ChatStreamEvent]:
        if not self._get_api_key():
            raise RuntimeError(
                f"当前模型（{self.cfg.provider}）未配置 API KEY。"
                "请使用 /model set 切换模型后按提示输入，或使用 /api_key set 设置。"
            )

        url = self.cfg.base_url.rstrip("/") + "/chat/completions"
        payload: Dict[str, Any] = {
            "model": self.cfg.model,
            "messages": messages,
            "stream": True,
        }

        def iter_sse_lines(resp: httpx.Response) -> Iterable[str]:
            for raw in resp.iter_lines():
                if not raw:
                    continue
                line = raw.decode("utf-8") if isinstance(raw, (bytes, bytearray)) else raw
                yield line

        with httpx.Client(timeout=None) as client:
            with client.stream("POST", url, headers=self._build_headers(), json=payload) as resp:
                resp.raise_for_status()
                for line in iter_sse_lines(resp):
                    if not line.startswith("data:"):
                        continue
                    data_str = line[len("data:") :].strip()
                    if data_str == "[DONE]":
                        yield {"done": True}
                        return
                    try:
                        data = json.loads(data_str)
                        choice = (data.get("choices") or [{}])[0]
                        delta = choice.get("delta") or {}
                        content_delta = delta.get("content") or ""
                        reasoning_delta = delta.get("reasoning_content") or ""
                        event: ChatStreamEvent = {}
                        if content_delta:
                            event["content_delta"] = content_delta
                        if reasoning_delta:
                            event["reasoning_delta"] = reasoning_delta
                        if event:
                            yield event
                    except Exception:
                        continue

    def chat_tools(self, messages: List[Dict[str, Any]], tools: list[dict[str, Any]]) -> ChatToolsResult:
        if not self._get_api_key():
            raise RuntimeError(
                f"当前模型（{self.cfg.provider}）未配置 API KEY。"
                "请使用 /model set 切换模型后按提示输入，或使用 /api_key set 设置。"
            )

        url = self.cfg.base_url.rstrip("/") + "/chat/completions"
        payload: Dict[str, Any] = {
            "model": self.cfg.model,
            "messages": messages,
            "tools": tools,
            "tool_choice": "auto",
        }

        with httpx.Client(timeout=60) as client:
            resp = client.post(url, headers=self._build_headers(), json=payload)
            resp.raise_for_status()
            data = resp.json()

        try:
            message = data["choices"][0]["message"]
            out: ChatToolsResult = {}
            if message.get("content") is not None:
                out["content"] = message.get("content") or ""
            reasoning = message.get("reasoning_content")
            if reasoning:
                out["reasoning"] = reasoning
            tool_calls = message.get("tool_calls") or []
            if tool_calls:
                out["tool_calls"] = tool_calls
            return out
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(f"LLM 响应解析失败: {data}") from exc

