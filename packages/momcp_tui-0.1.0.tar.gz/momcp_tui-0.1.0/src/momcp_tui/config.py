from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:  # Python 3.11+
    import tomllib  # type: ignore[attr-defined]
except ModuleNotFoundError:  # Python 3.10 及以下使用第三方 tomli
    import tomli as tomllib  # type: ignore[no-redef]


CONFIG_DIR = Path.home() / ".momcp"
CONFIG_PATH = CONFIG_DIR / "config.toml"


@dataclass
class LLMConfig:
    provider: str = "openai"
    base_url: str = "https://api.openai.com/v1"
    model: str = "gpt-4.1-mini"
    api_keys: dict[str, str] = field(default_factory=dict)

    def get_api_key(self, provider: str | None = None) -> str:
        p = provider or self.provider
        return self.api_keys.get(p, "")

    def set_api_key(self, provider: str, key: str) -> None:
        """设置指定 provider 的 API KEY。"""
        self.api_keys[provider] = key


@dataclass
class MCPConfig:
    enabled: list[str]
    servers: dict[str, dict] = field(default_factory=dict)
    allowed_paths: list[str] = field(default_factory=list)


@dataclass
class AppConfig:
    llm: LLMConfig
    mcp: MCPConfig
    user_name: str = ""


def load_config() -> AppConfig:
    if not CONFIG_PATH.exists():
        return AppConfig(
            llm=LLMConfig(),
            mcp=MCPConfig(
                enabled=["web-search", "filesystem", "code-editor"],
                servers={
                    "momcp": {
                        "command": "python",
                        "args": ["-m", "momcp_tui.mcp_servers.server"],
                    }
                    ,
                    "aisearch-mcp-server": {
                        "type": "streamableHttp",
                        "description": "搜索实时信息，支持使用大模型进行总结回复。",
                        "url": "https://qianfan.baidubce.com/v2/ai_search/mcp",
                        "headers": {"Authorization": ""},
                    }
                },
            ),
            user_name="",
        )

    with CONFIG_PATH.open("rb") as f:
        raw = tomllib.load(f)

    llm_raw = raw.get("llm", {})
    mcp_raw = raw.get("mcp", {})
    user_raw = raw.get("user", {})

    provider = llm_raw.get("provider", "openai")
    raw_api_keys = dict(llm_raw.get("api_keys") or {})
    api_keys: dict[str, str] = {}
    for prov, val in raw_api_keys.items():
        if isinstance(val, str):
            api_keys[prov] = val
    if llm_raw.get("api_key") and provider not in api_keys:
        api_keys[provider] = llm_raw["api_key"]

    llm = LLMConfig(
        provider=provider,
        base_url=llm_raw.get("base_url", "https://api.openai.com/v1"),
        model=llm_raw.get("model", "gpt-4.1-mini"),
        api_keys=api_keys,
    )
    if not (mcp_raw.get("servers") or {}) and raw.get("mcpServers"):
        mcp_raw = dict(mcp_raw)
        mcp_raw["servers"] = raw.get("mcpServers") or {}

    raw_servers = dict(mcp_raw.get("servers") or {})

    mcp = MCPConfig(
        enabled=mcp_raw.get(
            "enabled", ["web-search", "filesystem", "code-editor"]
        ),
        servers=raw_servers,
        allowed_paths=list(mcp_raw.get("allowed_paths") or []),
    )

    changed = False
    if not mcp.servers:
        mcp.servers = {}
        changed = True
    if "momcp" not in mcp.servers:
        mcp.servers["momcp"] = {
            "command": "python",
            "args": ["-m", "momcp_tui.mcp_servers.server"],
        }
        changed = True
    if "aisearch-mcp-server" not in mcp.servers:
        mcp.servers["aisearch-mcp-server"] = {
            "type": "streamableHttp",
            "description": "搜索实时信息，支持使用大模型进行总结回复。",
            "url": "https://qianfan.baidubce.com/v2/ai_search/mcp",
            "headers": {"Authorization": ""},
        }
        changed = True
    if "word-document-server" not in mcp.servers:
        mcp.servers["word-document-server"] = {
            "command": "/Users/andyjin/Office-Word-MCP-Server/venv/bin/python",
            "args": [
                "/Users/andyjin/Office-Word-MCP-Server/word_mcp_server.py"
            ],
        }
        changed = True
    user_name = (user_raw.get("name") or "").strip()
    cfg = AppConfig(llm=llm, mcp=mcp, user_name=user_name)
    if changed:
        try:
            save_config(cfg)
        except Exception:
            pass
    return cfg


def ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _escape_toml_str(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def save_config(config: AppConfig) -> None:
    ensure_config_dir()
    lines: list[str] = [
        "[llm]",
        f'provider = "{config.llm.provider}"',
        f'base_url = "{config.llm.base_url}"',
        f'model = "{config.llm.model}"',
        "",
        "[llm.api_keys]",
    ]
    for p, k in sorted(config.llm.api_keys.items()):
        if k:
            lines.append(f'{p} = "{_escape_toml_str(k)}"')
    lines.extend([
        "",
        "[mcp]",
        "enabled = [" + ", ".join(f'"{name}"' for name in config.mcp.enabled) + "]",
        "allowed_paths = [" + ", ".join(f'"{_escape_toml_str(p)}"' for p in config.mcp.allowed_paths) + "]",
        "",
    ])

    for server_name, raw_s in sorted((config.mcp.servers or {}).items()):
        if not isinstance(raw_s, dict):
            continue
        lines.append(f"[mcp.servers.{server_name}]")
        server_type = raw_s.get("type") or "stdio"
        lines.append(f'type = "{_escape_toml_str(str(server_type))}"')
        if raw_s.get("description"):
            lines.append(f'description = "{_escape_toml_str(str(raw_s.get("description")))}"')
        if raw_s.get("url"):
            lines.append(f'url = "{_escape_toml_str(str(raw_s.get("url")))}"')
        if raw_s.get("command"):
            lines.append(f'command = "{_escape_toml_str(str(raw_s.get("command")))}"')
        if raw_s.get("args") is not None:
            args = raw_s.get("args") or []
            lines.append("args = [" + ", ".join(f'\"{_escape_toml_str(str(a))}\"' for a in args) + "]")
        lines.append("")

        headers = raw_s.get("headers") or {}
        if isinstance(headers, dict) and headers:
            lines.append(f"[mcp.servers.{server_name}.headers]")
            for hk, hv in sorted(headers.items()):
                v = str(hv)
                lines.append(f'{hk} = "{_escape_toml_str(v)}"')
            lines.append("")

    lines.extend([
        "[user]",
        f'name = "{_escape_toml_str(config.user_name)}"',
        "",
    ])
    CONFIG_PATH.write_text("\n".join(lines), encoding="utf-8")


BUILTIN_MODELS: dict[str, dict] = {
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "models": ["gpt-4.1-mini", "gpt-4.1"],
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com/v1",
        "models": ["deepseek-chat", "deepseek-reasoner"],
    },
    "qwen": {
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "models": ["qwen-plus", "qwen-turbo", "qwen-max"],
    },
    "kimi": {
        "base_url": "https://api.moonshot.cn/v1",
        "models": ["kimi-k2-turbo-preview", "kimi-k2-0711-preview"],
    },
}


def resolve_model(model_name: str) -> tuple[str, str] | None:
    for provider, info in BUILTIN_MODELS.items():
        if model_name in info["models"]:
            return (provider, info["base_url"])
    return None


def list_all_models() -> list[tuple[str, str, str]]:
    result: list[tuple[str, str, str]] = []
    for provider, info in sorted(BUILTIN_MODELS.items()):
        label = PROVIDER_LABELS.get(provider, provider)
        models_str = "、".join(info["models"])
        result.append((label, provider, models_str))
    return result


PROVIDER_LABELS: dict[str, str] = {
    "openai": "OpenAI",
    "deepseek": "DeepSeek",
    "qwen": "通义千问",
    "kimi": "Kimi",
}


def get_model_display_name(provider: str) -> str:
    return PROVIDER_LABELS.get(provider, provider)


def apply_model(config: AppConfig, model_name: str) -> bool:
    resolved = resolve_model(model_name)
    if not resolved:
        return False
    provider, base_url = resolved
    config.llm.provider = provider
    config.llm.base_url = base_url
    config.llm.model = model_name
    return True


