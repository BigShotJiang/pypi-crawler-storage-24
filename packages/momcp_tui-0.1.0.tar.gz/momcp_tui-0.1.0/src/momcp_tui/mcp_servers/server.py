from __future__ import annotations

import argparse
import os
from pathlib import Path

from fastmcp import FastMCP


def _resolve_allowed(roots: list[Path], p: str, default_root: Path) -> Path:
    target = (default_root / p).resolve() if not Path(p).is_absolute() else Path(p).resolve()
    for r in roots:
        r = r.resolve()
        try:
            target.relative_to(r)
            return target
        except Exception:
            continue
    raise ValueError(f"路径越界：{target} 不在白名单目录下")


def build_server(root: Path, allowed_paths: list[str]) -> FastMCP:
    mcp = FastMCP(name="momcp-local")
    default_root = root.resolve()
    allowed_roots = [default_root] + [Path(p).expanduser() for p in allowed_paths]

    @mcp.tool(name="fs_list", description="列出目录内容（相对 root 的路径）。")
    def fs_list(path: str = ".") -> list[str]:
        p = _resolve_allowed(allowed_roots, path, default_root)
        if not p.exists():
            raise FileNotFoundError(str(p))
        if not p.is_dir():
            raise NotADirectoryError(str(p))
        items = []
        for child in sorted(p.iterdir(), key=lambda x: x.name):
            suffix = "/" if child.is_dir() else ""
            items.append(child.name + suffix)
        return items

    @mcp.tool(name="fs_read", description="读取文件内容（UTF-8）。")
    def fs_read(path: str) -> str:
        p = _resolve_allowed(allowed_roots, path, default_root)
        if not p.exists():
            raise FileNotFoundError(str(p))
        if p.is_dir():
            raise IsADirectoryError(str(p))
        return p.read_text(encoding="utf-8", errors="replace")

    @mcp.tool(name="fs_write", description="写入文件内容（UTF-8）。默认覆盖。")
    def fs_write(path: str, content: str, overwrite: bool = True) -> str:
        p = _resolve_allowed(allowed_roots, path, default_root)
        if p.exists() and (not overwrite):
            raise FileExistsError(str(p))
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"ok: wrote {path} ({len(content)} chars)"

    @mcp.tool(name="fs_mkdir", description="创建目录。")
    def fs_mkdir(path: str, parents: bool = True, exist_ok: bool = True) -> str:
        p = _resolve_allowed(allowed_roots, path, default_root)
        p.mkdir(parents=parents, exist_ok=exist_ok)
        return f"ok: mkdir {path}"

    @mcp.tool(name="fs_delete", description="删除文件或目录（可递归）。")
    def fs_delete(path: str, recursive: bool = False) -> str:
        p = _resolve_allowed(allowed_roots, path, default_root)
        if not p.exists():
            return f"ok: already missing {path}"
        if p.is_dir():
            if not recursive and any(p.iterdir()):
                raise IsADirectoryError(f"{path} 非空目录，recursive=false")
            # 递归删除
            for child in sorted(p.rglob("*"), reverse=True):
                if child.is_file() or child.is_symlink():
                    child.unlink()
                elif child.is_dir():
                    child.rmdir()
            p.rmdir()
            return f"ok: deleted dir {path}"
        p.unlink()
        return f"ok: deleted file {path}"

    @mcp.tool(name="code_replace", description="在文件中替换文本（默认替换首次出现）。")
    def code_replace(path: str, old: str, new: str, count: int = 1) -> str:
        p = _resolve_allowed(allowed_roots, path, default_root)
        text = p.read_text(encoding="utf-8", errors="replace")
        if old not in text:
            raise ValueError("old 未在文件中找到")
        updated = text.replace(old, new, count)
        p.write_text(updated, encoding="utf-8")
        return f"ok: replaced {count} occurrence(s) in {path}"

    @mcp.tool(
        name="code_write",
        description="直接写入完整文件内容（用于代码撰写/重写）。",
    )
    def code_write(path: str, content: str, overwrite: bool = True) -> str:
        return fs_write(path=path, content=content, overwrite=overwrite)

    return mcp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=os.getcwd(), help="工作区根目录")
    parser.add_argument(
        "--allow",
        action="append",
        default=[],
        help="允许访问的额外路径（可重复指定多次）",
    )
    args = parser.parse_args()

    root = Path(args.root)
    server = build_server(root=root, allowed_paths=list(args.allow or []))
    # stdio 模式运行
    server.run()


if __name__ == "__main__":
    main()

