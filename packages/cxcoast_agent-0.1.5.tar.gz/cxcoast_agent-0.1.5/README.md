# CXCoast Agent

AI agent for organizational knowledge. Search, create, and manage your knowledge base from the terminal.

## Install

```bash
pip install cxcoast-agent
```

## Getting Started

```bash
# Login with your CXCoast account
cxcoast-agent login

# Start interactive session
cxcoast-agent
```

## Features

- **Knowledge Search**: hybrid search (semantic + keyword) across your organization's knowledge base
- **Article Management**: create, browse, and categorize knowledge articles
- **Interactive Terminal UI**: rich Textual interface with planning, tool calls, and streaming
- **MCP Integration**: knowledge tools loaded automatically from your CXCoast instance
- **BYOK**: bring your own LLM key (OpenAI, Anthropic, Google)
- **File Operations**: read, write, and analyze files on your local machine
- **Non-Interactive Mode**: single queries for scripting and automation

## Commands

```
cxcoast-agent login              Login with your CXCoast account
cxcoast-agent status             Check connection status
cxcoast-agent logout             Logout and revoke API key
cxcoast-agent                    Start interactive session
cxcoast-agent -n "query" -q      Non-interactive single query
cxcoast-agent --help             Full help
```

## Links

- [CXCoast Knowledge Hub](https://khub.cxcoast.com)
- [CXCoast Website](https://www.cxcoast.com)
- [Documentation](https://docs.cxcoast.com/cli)

---

**CXCoast Technology Solutions & Consulting W.L.L.**

Al Raya Tower, Office 51, Building 1025, Road 3621, Seef, Bahrain

+973 350 988 52 | hello@cxcoast.com

Sunday to Thursday: 9:00 AM to 6:00 PM

## License

Proprietary. CXCoast Technology Solutions & Consulting W.L.L. All rights reserved.
