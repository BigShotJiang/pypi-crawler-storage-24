"""Hotel Key enforcement — the single gate for ``codemind init`` and ``codemind scan``.

Pricing model (v4 — server-authoritative, tamper-proof):

  Free tier (permanent — no expiry):
    - 1 project (enforced SERVER-SIDE — cannot be bypassed by editing local files)
    - All core tools work offline (MCP, scaffold, decisions, health)
    - AI via BYOK (user sets ANTHROPIC_API_KEY — they pay Anthropic directly)

  ``codemind init``:
    - Class A project (already in activated_projects)   → always allow (offline ok)
    - New project                                       → call server to validate
    - Server returns 402                                → block + upgrade message + rollback

  ``codemind scan``:
    - Always allowed for any initialized project (graph exists)
    - Never blocked — scan is never paused

  AI features (enrichment, Pro review/brief/impact):
    - BYOK features: allowed if ANTHROPIC_API_KEY is set (free tier)
    - Pro features: require paid-tier feature in features list
    - Expired paid license: server removes features on next validate

All other commands (serve, check, scaffold, decide, query) are never blocked.
"""

from __future__ import annotations

from dataclasses import dataclass

from codemind.license.license import (
    LicenseState,
    FEATURE_AI_ENRICHMENT,
    FEATURE_AI_ENRICHMENT_BYOK,
    FEATURE_PRO_REVIEW,
    FEATURE_PRO_BRIEF,
    FEATURE_PRO_IMPACT,
)


@dataclass
class EnforcementResult:
    """Return value from every enforcer check."""

    allowed: bool
    reason: str = ""    # shown on block; empty when allowed
    warning: str = ""   # advisory banner; shown but does not block


class LicenseEnforcer:
    """Apply Hotel Key rules. Stateless — takes a :class:`LicenseState` each call."""

    def check_init(self, state: LicenseState, project_id: str) -> EnforcementResult:
        """Can ``codemind init`` proceed for *project_id*?

        Class A projects (already in activated_projects) are always allowed,
        even offline. For new projects, this always returns allowed=True —
        the server is the authoritative gate and will return HTTP 402 if the
        plan limit is reached. The CLI rolls back .codemind/ on 402.
        """
        # Class A: project was previously registered on this key — always allow
        if state.is_class_a(project_id):
            return EnforcementResult(allowed=True)

        # New project: allow through — server validates and enforces limits
        return EnforcementResult(allowed=True)

    def check_scan(
        self,
        state: LicenseState,
        project_id: str,
        graph_exists: bool,
    ) -> EnforcementResult:
        """Can ``codemind scan`` proceed?

        Scan is always allowed for initialized projects. It is never paused —
        only AI enrichment may be restricted by the features list.
        """
        return EnforcementResult(allowed=True)

    def ai_allowed(self, state: LicenseState) -> bool:
        """True when server-paid AI enrichment may run (Pro+).

        Free tier users run AI via BYOK (their own key) — always allowed
        if they have set ANTHROPIC_API_KEY. Only the Pro-tier managed
        enrichment (we pay) requires a non-expired paid license.
        """
        return state.has_feature(FEATURE_AI_ENRICHMENT)

    def byok_ai_allowed(self, state: LicenseState) -> bool:
        """True when BYOK AI (user's own key) may run — free + paid tiers."""
        return (
            state.has_feature(FEATURE_AI_ENRICHMENT_BYOK)
            or state.has_feature(FEATURE_AI_ENRICHMENT)
        )

    def pro_features_allowed(self, state: LicenseState) -> bool:
        """True when Pro AI commands (review, brief, impact --ai) are available."""
        return any(
            state.has_feature(f)
            for f in (FEATURE_PRO_REVIEW, FEATURE_PRO_BRIEF, FEATURE_PRO_IMPACT)
        )
