"""License state model and manager for ~/.codemind/license.yml.

Local file is intentionally minimal — only 3 fields:
  license_key        — needed to call the server
  features           — cached from server; controls what CLI features are enabled
  activated_projects — Class A registry (projects activated on this key)

ALL enforcement (project limits, tier, expiry) is server-side.
Nothing in this file can be edited to bypass plan limits.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

# ── Paths ─────────────────────────────────────────────────────────────────────

LICENSE_DIR = Path.home() / ".codemind"
LICENSE_FILE = LICENSE_DIR / "license.yml"

# ── Feature constants ──────────────────────────────────────────────────────────

FEATURE_AI_ENRICHMENT = "ai_enrichment"           # Pro: we pay
FEATURE_AI_ENRICHMENT_BYOK = "ai_enrichment_byok" # Free: user pays own key
FEATURE_STACK_DISCOVERY = "stack_discovery"
FEATURE_STACK_DISCOVERY_BYOK = "stack_discovery_byok"
FEATURE_UNLIMITED_PROJECTS = "unlimited_projects"
FEATURE_TEAM_DASHBOARD = "team_dashboard"
FEATURE_PRO_REVIEW = "pro_review"
FEATURE_PRO_BRIEF = "pro_brief"
FEATURE_PRO_IMPACT = "pro_impact"

FREE_FEATURES: list[str] = [FEATURE_AI_ENRICHMENT_BYOK, FEATURE_STACK_DISCOVERY_BYOK]
PRO_FEATURES: list[str] = [
    FEATURE_AI_ENRICHMENT,
    FEATURE_STACK_DISCOVERY,
    FEATURE_UNLIMITED_PROJECTS,
    FEATURE_PRO_REVIEW,
    FEATURE_PRO_BRIEF,
    FEATURE_PRO_IMPACT,
]
TEAM_FEATURES: list[str] = PRO_FEATURES + [FEATURE_TEAM_DASHBOARD]

# Legacy aliases — kept so any imports elsewhere don't break
TRIAL_FEATURES = FREE_FEATURES
FREE_PROJECT_LIMIT = 1       # informational only — enforcement is server-side
OFFLINE_GRACE_DAYS = 7       # kept for backwards-compat with any imports

# Tier name constants — kept for any code that imports them
TIER_FREE = "free"
TIER_TRIAL = "trial"
TIER_PRO = "pro"
TIER_TEAM = "team"
TIER_ENTERPRISE = "enterprise"
EXPIRY_WARNING_DAYS = 5


@dataclass
class LicenseState:
    """In-memory representation of ~/.codemind/license.yml.

    Minimal by design — only what is needed for offline operation.
    The server is the single source of truth for tier, project limits, and expiry.
    """

    license_key: str = ""
    features: list[str] = field(default_factory=list)
    activated_projects: list[str] = field(default_factory=list)

    # ── Methods ───────────────────────────────────────────────────────────────

    def is_class_a(self, project_id: str) -> bool:
        """True if project was previously activated on this key.

        Class A projects always work offline — the key was server-validated at
        activation time and the project_id is in the local registry.
        """
        return bool(project_id) and project_id in self.activated_projects

    def has_feature(self, feature: str) -> bool:
        """True if feature is in the server-controlled features list."""
        return feature in self.features

    @property
    def active_project_count(self) -> int:
        return len(self.activated_projects)


class LicenseManager:
    """Read/write ~/.codemind/license.yml atomically."""

    def __init__(self, license_file: Path = LICENSE_FILE) -> None:
        self._path = license_file

    def exists(self) -> bool:
        return self._path.exists()

    def load(self) -> LicenseState:
        """Load license state. Returns empty (no key) if file missing or corrupt."""
        if not self._path.exists():
            return LicenseState()
        try:
            raw = yaml.safe_load(self._path.read_text(encoding="utf-8")) or {}
            return self._from_dict(raw)
        except Exception:
            return LicenseState()

    def save(self, state: LicenseState) -> None:
        """Atomically write license state to disk."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".yml.tmp")
        tmp.write_text(
            yaml.dump(self._to_dict(state), default_flow_style=False,
                      allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
        tmp.replace(self._path)

    def add_activated_project(self, project_id: str) -> None:
        """Register project_id as Class A (idempotent)."""
        if not project_id:
            return
        state = self.load()
        if project_id not in state.activated_projects:
            state.activated_projects.append(project_id)
            self.save(state)

    # ── Private ───────────────────────────────────────────────────────────────

    def _from_dict(self, data: dict[str, Any]) -> LicenseState:
        """Parse any dict (server response or local file) into LicenseState.

        Extra fields from old license.yml files (tier, project_limit, expires_at,
        grace_days, validated_at, email) are silently ignored — migration is
        automatic the next time save() is called.
        """
        activated = data.get("activated_projects") or []
        # Server returns list of UUID strings; old local files do too.
        # Guard against any list-of-dicts format just in case.
        activated_ids = [
            a["project_id"] if isinstance(a, dict) else str(a)
            for a in activated
        ]
        return LicenseState(
            license_key=data.get("license_key", ""),
            features=list(data.get("features") or []),
            activated_projects=activated_ids,
        )

    def _to_dict(self, state: LicenseState) -> dict[str, Any]:
        """Only write the 3 essential fields — nothing else is stored locally."""
        return {
            "license_key": state.license_key,
            "features": state.features,
            "activated_projects": state.activated_projects,
        }
