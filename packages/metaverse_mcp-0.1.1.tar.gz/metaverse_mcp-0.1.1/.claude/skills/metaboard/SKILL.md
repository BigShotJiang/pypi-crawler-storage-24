---
name: metaboard
description: Build a complete Metabase dashboard from a description. Creates all necessary questions and assembles them into a dashboard.
allowed-tools: mcp__metaverse__list_databases,mcp__metaverse__run_query,mcp__metaverse__create_question,mcp__metaverse__create_dashboard,mcp__metaverse__add_card_to_dashboard,EnterPlanMode,ExitPlanMode
context: fork
---

Build a Metabase dashboard for: $ARGUMENTS

## Phase 1 — Explore (before entering plan mode)
1. Read `metaverse://schema` — understand all tables and fields
2. Break the description into 3–6 distinct metrics or views (e.g. "monthly revenue", "top customers", "refund rate")
3. For each metric: write SQL and validate with `run_query`

## Phase 2 — Plan
Call `EnterPlanMode` and present:
- Proposed dashboard name
- Each card: metric name, display type, x/y columns, SQL (in a code block), and first 3 rows as a markdown table
- Proposed layout (grid positions; 24-column grid, default card 12×8)

Choose display type from the query result columns:
- Single number → `scalar`
- Time series (date/month/week on X) → `line`
- Rankings or category comparisons → `bar`
- Multi-column breakdown → `table`

## Phase 3 — Execute (after plan approval)
4. For each metric:
   a. `create_question(name, database_id, sql, display=..., x_column=..., y_columns=[...])`
      - Always pass `x_column` and `y_columns` for bar/line/area/row/combo displays
      - Use the exact column names from the `run_query` result
   b. `execute_question(card_id)` — confirm it runs; if it fails, `delete_question(card_id)` and fix the SQL before continuing
5. `create_dashboard(name, description)`
6. `add_card_to_dashboard` for each question:
   - Place left-to-right, top-to-bottom (increment col by size_x, wrap row by size_y)
7. Return: dashboard name and full Metabase URL
