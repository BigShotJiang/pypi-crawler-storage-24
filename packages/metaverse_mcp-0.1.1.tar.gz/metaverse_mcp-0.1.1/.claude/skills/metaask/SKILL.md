---
name: metaask
description: Answer a factual data question by querying Metabase. Use when the user asks "how many X", "what is Y", "show me Z", or any question about data in the database.
allowed-tools: mcp__metaverse__run_query,mcp__metaverse__list_databases
context: fork
---

Answer this data question using Metabase: $ARGUMENTS

Rules:
- Use **only MCP tools** throughout. Do not write scripts, run shell commands, or use any non-MCP tools.

Steps:
1. Read `metaverse://schema` — understand all databases, tables, and fields
2. Write a focused SQL query that answers the question precisely. Use JOINs if needed.
3. `run_query(database_id, sql)` — execute it (use `list_databases` only if the database_id is unclear)
6. Format the output:
   - Bold one-sentence summary first: **Result**: [direct answer]
   - Then a markdown table with the full results
   - If truncated: add "_Showing top N rows — refine the query for more._"

Be direct. No reasoning, no preamble — just the answer.
