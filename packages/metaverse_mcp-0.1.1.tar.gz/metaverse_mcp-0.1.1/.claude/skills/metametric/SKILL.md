---
name: metametric
description: Create or explore a reusable MBQL metric in Metabase. Use when the user wants to define a named aggregation (e.g. "Total Revenue", "Active Users Count") tied to a specific table, or when they want to see what an existing metric returns.
allowed-tools: mcp__metaverse__list_databases,mcp__metaverse__list_tables,mcp__metaverse__describe_table,mcp__metaverse__list_metrics,mcp__metaverse__get_metric,mcp__metaverse__execute_metric,mcp__metaverse__create_metric,mcp__metaverse__archive_metric,EnterPlanMode,ExitPlanMode
context: fork
---

Create or explore a Metabase metric for: $ARGUMENTS

## Phase 1 — Explore (before entering plan mode)

**If the request is about an existing metric** (e.g. "show me", "what does X return", "run X"):
1. `list_metrics` — find the matching metric by name
2. `get_metric` — retrieve its definition
3. `execute_metric` — run it and collect the result
4. Skip to Output (no plan mode needed for read-only).

**If the request is to create a new metric**:
1. `list_metrics` — check whether a metric with the same purpose already exists; if so, confirm with the user before creating a duplicate
2. `list_databases` → `list_tables(database_id)` — identify the right table
3. `describe_table(table_id)` — find exact field names **and IDs** (`id` field is required for non-count aggregations)
4. Determine:
   - `aggregation_type`: `count` (no field needed) · `sum` · `avg` · `distinct` · `min` · `max`
   - `field_id`: from `describe_table` results (required for everything except `count`)

## Phase 2 — Plan (create path only)
Call `EnterPlanMode`, then present:
- Metric name and description
- Table it will be based on
- Aggregation: `<type>(<field_name>)` — e.g. `sum(TOTAL)` or `count(*)`
- The `field_id` that will be used (from `describe_table`)

Wait for user approval via `ExitPlanMode`. If they request changes, revise and re-present.

## Phase 3 — Execute (create path only)
5. `create_metric(name, database_id, table_id, aggregation_type, field_id, description)`
6. `execute_metric(metric_id)` — run it immediately to confirm it works
7. Return: metric name, aggregation, result value, and Metabase URL

## Output format
Always return a concise summary:
```
Metric: <name>
Aggregation: <type>(<field>) on <table>
Result: <value or table>
URL: <link>
```
