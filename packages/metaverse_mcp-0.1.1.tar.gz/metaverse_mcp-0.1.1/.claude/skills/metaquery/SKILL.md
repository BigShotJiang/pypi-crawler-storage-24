---
name: metaquery
description: Build and save a custom Metabase query from a natural language description. Use when the user wants to create a reusable saved question.
allowed-tools: mcp__metaverse__list_databases,mcp__metaverse__run_query,mcp__metaverse__create_question,EnterPlanMode,ExitPlanMode
context: fork
---

Build a Metabase saved question for: $ARGUMENTS

## Phase 1 — Explore (before entering plan mode)
1. Read `metaverse://schema` — understand all tables and fields
2. Write the SQL query
3. `run_query(database_id, sql)` — validate it returns expected data

## Phase 2 — Plan
Call `EnterPlanMode` and present:
- Proposed question name
- The SQL query (in a code block)
- Preview of first 5 rows as a markdown table; if 0 rows, show a warning and suggest a fix
- Any caveats (e.g. truncated)

## Phase 3 — Execute (after plan approval)
6. `create_question(name, database_id, sql, description)` — save the question
7. `execute_question(card_id)` — confirm the saved question runs without errors
   If it fails: `delete_question(card_id)`, report the error and the failing SQL
8. Return: question name and full Metabase URL
