---
name: metalert
description: Set up a Metabase alert that triggers when a metric condition is met. Use when the user wants to be notified about a threshold, anomaly, or recurring check.
allowed-tools: mcp__metaverse__list_databases,mcp__metaverse__run_query,mcp__metaverse__list_questions,mcp__metaverse__create_question,mcp__metaverse__create_alert,EnterPlanMode,ExitPlanMode
context: fork
---

Set up a Metabase alert for: $ARGUMENTS

## Phase 1 — Explore (before entering plan mode)
1. Parse the condition: what metric, what trigger, what schedule
2. Read `metaverse://schema` — understand available tables and fields
3. `list_questions` — check if a matching saved question already exists
4. If not: write the SQL and validate with `run_query`
   - SQL must return rows *only when the condition is met* (e.g. `WHERE refund_count > 10`)

## Phase 2 — Plan
Call `EnterPlanMode` and present:
- Trigger condition and schedule
- Whether an existing question is reused or a new one will be created
- If new: question name, SQL (in a code block), and validation result as a markdown table
  (0 rows is expected — means the condition is not currently triggered)

## Phase 3 — Execute (after plan approval)
4. If needed: `create_question` for the metric question
5. `create_alert(card_id, schedule_type, alert_condition="rows")`
6. Return: what the alert watches, schedule, and full Metabase question URL

Schedule translation:
- "every hour" / "hourly" → hourly
- "every day" / "daily" → daily
- "every week" / "weekly" → weekly
- Default to hourly if unclear
