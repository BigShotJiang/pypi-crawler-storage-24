# Metaverse — Claude Context

## Project

AI-powered Metabase interface. MCP server runs at `http://localhost:8000/mcp` (start with `just up`).

## Available Skills

| Skill | Use for |
|-------|---------|
| `/metaask [question]` | Quick data question → formatted table |
| `/metaquery [description]` | Build and save a complex query |
| `/metaboard [description]` | Build a complete dashboard |
| `/metalert [condition]` | Set up a metric alert |
| `/metametric [description]` | Create or explore a reusable MBQL metric |

## MCP Tools

```
list_databases()                                                              → [{id, name, engine}]
list_tables(database_id)                                                      → [{id, name, schema}]
describe_table(table_id)                                                      → {name, fields: [{id, name, type, is_pk, fk_target}]}
run_query(database_id, sql, limit=100)                                        → {columns, rows, row_count, truncated}
list_questions()                                                              → [{id, name, database_id}]
get_question(card_id)                                                         → {id, name, sql, ...}
create_question(name, database_id, sql, display="table", description="")      → {id, name, url}
update_question(card_id, name?, sql?, display?, description?)                 → {id, name, url}
execute_question(card_id, limit=100)                                          → {columns, rows, ...}
delete_question(card_id)                                                      → {deleted}
list_dashboards()                                                             → [{id, name, description}]
get_dashboard(dashboard_id)                                                   → {id, name, cards: [...]}
create_dashboard(name, description="")                                        → {id, name, url}
add_card_to_dashboard(dashboard_id, card_id, row, col, size_x, size_y)       → {dashboard_id, card_count, url}
remove_card_from_dashboard(dashboard_id, card_id)                             → {dashboard_id, card_count, url}
update_card_on_dashboard(dashboard_id, card_id, row?, col?, size_x?, size_y?) → {dashboard_id, card_count, url}
list_alerts()                                                                 → [{id, card_id, card_name, send_condition, active}]
create_alert(card_id, schedule_type, alert_condition)                         → {id, card_id, send_condition, active}
delete_alert(alert_id)                                                        → {deleted, alert_id}
list_metrics()                                                                → [{id, name, description, table_id, database_id, archived}]
get_metric(metric_id)                                                         → {id, name, description, table_id, database_id, definition, archived}
create_metric(name, database_id, table_id, aggregation_type, field_id?)       → {id, name, url}
archive_metric(metric_id)                                                     → {archived, metric_id}
execute_metric(metric_id, limit=100)                                          → {columns, rows, row_count, truncated}
```

## Usage Notes

- Always call `list_databases` first — the database ID is required for queries
- Always call `describe_table` before writing SQL or creating metrics — never guess column names or field IDs
- `describe_table` returns `id` on each field — use this as `field_id` when calling `create_metric`
- The data database is typically named "Metaverse Data" (database_id varies per environment)
- Dashboard grid is 24 columns wide; default card size is 12×8

## Confirmation Before Mutating

Before calling any write or delete tool (`create_question`, `update_question`, `delete_question`, `create_dashboard`, `add_card_to_dashboard`, `remove_card_from_dashboard`, `update_card_on_dashboard`, `create_alert`, `delete_alert`, `create_metric`, `archive_metric`), **always present a plan to the user and wait for explicit confirmation**:

1. Summarise what will be created/modified/deleted
2. Show the SQL or key parameters involved
3. Include a preview of the data (first 5 rows) when relevant

Only proceed after the user confirms. If they request adjustments, revise and re-confirm.
