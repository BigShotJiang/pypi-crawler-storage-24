"""MCP prompts — mirror of Claude Code skills, available in any MCP client (Claude Desktop, etc.)."""

from metaverse.app import mcp


@mcp.prompt()
def metaask(question: str) -> str:
    """Answer a data question by querying Metabase. Returns a markdown table + one-line summary."""
    return f"""Answer this data question using Metabase: {question}

1. list_databases — identify which database to query
2. list_tables(database_id) — find relevant tables
3. describe_table(table_id) — understand field names and types
4. Write a focused SQL query that answers the question precisely
5. run_query(database_id, sql) — execute (default limit 100 rows)
6. Format output:
   - Bold one-sentence summary: "**Result**: [answer]"
   - Markdown table of results
   - If truncated: "_Showing top 100 rows._"

Keep it concise. Lead with the answer."""


@mcp.prompt()
def metaquery(description: str) -> str:
    """Build and save a reusable Metabase question from a natural language description."""
    return f"""Build a Metabase saved question for: {description}

Phase 1 — Explore:
1. list_databases + list_tables — find relevant tables
2. describe_table on all relevant tables — understand exact column names
3. Write and validate the SQL with run_query
4. Choose a clear, descriptive name (e.g. "Orders by Customer – Last 30 Days")

Phase 2 — Confirm:
Present to the user:
- Proposed question name
- The SQL (in a code block)
- Preview of first 5 rows as a markdown table (| col | col | with header separator)
  If 0 rows: show a warning and suggest a fix before asking to save.
Ask for approval before saving. If they request changes, revise and re-confirm.

Phase 3 — Save:
5. create_question(name, database_id, sql, description)
6. Return: question name and full Metabase URL"""


@mcp.prompt()
def metaboard(description: str) -> str:
    """Build a complete Metabase dashboard — creates all questions and assembles the layout."""
    return f"""Build a Metabase dashboard for: {description}

Phase 1 — Explore:
1. list_databases + list_tables — understand available data
2. Break the description into 3–6 distinct metrics (e.g. "monthly revenue", "top customers")
3. For each metric: describe_table → write SQL → validate with run_query

Phase 2 — Confirm:
Present to the user:
- Proposed dashboard name
- Each card: metric name, SQL (in a code block), first 3 rows as a markdown table
- Proposed layout (24-column grid, default card 12×8)
Ask for approval before creating anything.

Phase 3 — Create:
4. create_question for each metric — note returned ids
5. create_dashboard(name, description)
6. add_card_to_dashboard for each question (left-to-right, top-to-bottom)
7. Return: dashboard name and full Metabase URL"""


@mcp.prompt()
def metalert(condition: str) -> str:
    """Set up a Metabase alert that triggers when a metric condition is met."""
    return f"""Set up a Metabase alert for: {condition}

Phase 1 — Explore:
1. Parse: what metric, what trigger threshold, what schedule
2. list_questions — check if a matching question already exists
3. If not: describe_table → write SQL → validate with run_query
   - SQL must return rows ONLY when the condition is met (e.g. WHERE refund_count > 10)

Phase 2 — Confirm:
Present to the user:
- Trigger condition and schedule
- Whether an existing question is reused or a new one will be created
- If new: question name, SQL (in a code block), validation result as a markdown table
  (0 rows is expected — it means the condition is not currently triggered)
Ask for approval before creating anything.

Phase 3 — Create:
4. If needed: create_question for the metric
5. create_alert(card_id, schedule_type, alert_condition="rows")
6. Return: what it watches, schedule, and full Metabase question URL

Schedule: "hourly" → hourly | "daily" → daily | "weekly" → weekly | default: hourly"""
