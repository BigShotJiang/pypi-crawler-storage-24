"""VisiblyAI MCP Server - SEO tools for Claude Code."""

__version__ = "0.2.1"