import os
import platform

def shout():
    """A simple function to test that the link works!"""
    username = os.getlogin()
    system = platform.system()
    print(f"--- 🚀 SUCCESS! ---")
    print(f"Hello {username}!")
    print(f"Your {system} machine is now running code downloaded from Pip.")
    print(f"-------------------")

if __name__ == "__main__":
    shout()