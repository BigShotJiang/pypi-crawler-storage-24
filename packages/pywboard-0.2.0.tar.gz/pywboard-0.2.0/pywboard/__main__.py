"""Allow running as: python -m pywboard [image_path]"""
from pywboard.app import main

main()
