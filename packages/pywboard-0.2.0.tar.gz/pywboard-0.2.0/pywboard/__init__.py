"""pywboard - Network Annotation Whiteboard"""
from pywboard.app import __version__
