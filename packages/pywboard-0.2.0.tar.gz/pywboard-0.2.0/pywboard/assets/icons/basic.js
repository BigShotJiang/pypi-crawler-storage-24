/**
 * pywboard Icon Set: Basic
 * Simple, clean network icons for quick diagramming.
 * All icons use a 64x64 viewBox.
 *
 * Icon function signature: function(color, size) → SVG string
 */
(function(){
  window.registerIconSet("basic", "Basic", {
    router: {
      label: "Router",
      svg: function(c,s){
        return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   xmlns:osb="http://www.openswatchbook.org/uri/2009/osb"
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   version="1.1"
   id="svg6315"
   viewBox="0 0 146.47212 146.45606"
   height="41.333153mm"
   width="41.337688mm">
  <defs
     id="defs6317">
    <linearGradient
       osb:paint="solid"
       id="linearGradient819">
      <stop
         id="stop817"
         offset="0"
         style="stop-color:#dddddd;stop-opacity:1;" />
    </linearGradient>
    <linearGradient
       gradientUnits="userSpaceOnUse"
       y2="73.235916"
       x2="146.47183"
       y1="73.235916"
       x1="3.5762787e-06"
       id="linearGradient821"
       xlink:href="#linearGradient819"
       gradientTransform="matrix(0.99449835,0,0,0.99438474,0.4032344,0.40318833)" />
  </defs>
  <metadata
     id="metadata6320">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     id="g857">
    <ellipse
       ry="70.420441"
       rx="70.428482"
       style="opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:5.6151762;stroke-linecap:square;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1;paint-order:normal"
       id="path815"
       cx="73.236069"
       cy="73.228027" />
    <path
       id="rect827-0-3"
       d="M 33.088769,33.085566 V 66.301839 L 45.088962,54.303037 65.699451,73.22803 45.094734,92.158786 33.088769,80.154219 v 33.216291 h 33.220052 l -12.005955,-12.00464 18.9331,-20.602205 18.92699,20.607915 -12.000209,11.99889 33.218623,-0.002 0.002,-33.214769 L 101.37152,92.164122 80.772525,73.227966 101.37721,54.296922 113.38319,66.301496 V 33.085584 L 80.16311,33.085548 92.169056,45.090168 73.235974,65.69234 54.297455,45.095941 66.309184,33.085584 Z"
       style="opacity:1;fill:#3a3a3a;fill-opacity:1;stroke:#2c2c2c;stroke-width:1.82743692;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1;paint-order:normal" />
  </g>
</svg>
`;
      }
    },
    switch_l2: {
      label: "Switch",
      svg: function(c,s){
        return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   version="1.1"
   id="svg7778"
   viewBox="0 0 146.47219 146.23581"
   height="41.270992mm"
   width="41.337704mm">
  <defs
     id="defs7780" />
  <metadata
     id="metadata7783">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     id="g818">
    <rect
       ry="8.9952965"
       y="2.8232942"
       x="2.8232944"
       height="140.58922"
       width="140.82561"
       id="rect4136-2-3-3"
       style="opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:5.6465888;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:2;stroke-dasharray:none;stroke-opacity:1" />
    <path
       id="rect864"
       d="m 100.89651,19.426022 c -3.465719,1.393109 -5.628681,3.725199 -6.945482,6.66687 l 14.786862,17.195437 -89.234127,-0.55481 c -1.281942,3.526045 -1.479555,7.166663 0,10.984498 l 89.254927,-0.55481 -14.953226,17.144168 c 1.2205,3.43447 3.629553,5.553303 6.900426,6.718139 l 25.03525,-28.707277 z"
       style="fill:#3a3a3a;fill-opacity:1;stroke:#2c2c2c;stroke-width:2.28006816;stroke-linecap:butt;stroke-linejoin:round;stroke-miterlimit:2;stroke-dasharray:none;stroke-opacity:1;paint-order:normal" />
    <path
       id="rect864-2"
       d="m 44.348723,126.80978 c 3.465713,-1.39311 5.628683,-3.7252 6.945479,-6.66687 l -14.786864,-17.19544 89.234122,0.55481 c 1.28194,-3.526038 1.47956,-7.166657 0,-10.984496 l -89.254923,0.55481 14.953231,-17.14416 c -1.220501,-3.43448 -3.629553,-5.55331 -6.900431,-6.71814 L 19.504099,97.917569 Z"
       style="fill:#3a3a3a;fill-opacity:1;stroke:#2c2c2c;stroke-width:2.28006816;stroke-linecap:butt;stroke-linejoin:round;stroke-miterlimit:2;stroke-dasharray:none;stroke-opacity:1;paint-order:normal" />
  </g>
</svg>
`;
      }
    },
    firewall: {
      label: "Firewall",
      svg: function(c,s){
        return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   width="44.719856mm"
   height="41.337704mm"
   viewBox="0 0 158.45619 146.47219"
   id="svg4294"
   version="1.1">
  <defs
     id="defs4296" />
  <metadata
     id="metadata4299">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     transform="translate(4.2915344e-6)"
     id="g869">
    <rect
       ry="3.816956"
       y="4.0686131"
       x="4.0686092"
       height="138.33496"
       width="150.31897"
       id="rect6782-4-65-3-0-6"
       style="opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:8.13722706;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1" />
    <rect
       style="opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-5"
       width="147.8936"
       height="28.35601"
       x="5.2812467"
       y="4.4881825" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-3"
       width="147.8936"
       height="28.35601"
       x="5.2812467"
       y="113.628" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-5"
       width="51.38068"
       height="28.189941"
       x="5.2812467"
       y="59.411709" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-6"
       width="49.467712"
       height="25.67437"
       x="29.213806"
       y="33.051807" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-2"
       width="24.194138"
       height="25.49596"
       x="5.2812467"
       y="33.141006" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-3-9"
       width="49.467712"
       height="25.67437"
       x="78.700119"
       y="33.051807" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-9-1"
       width="24.194138"
       height="25.49596"
       x="128.98065"
       y="33.141006" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-2-2"
       width="51.38068"
       height="28.189941"
       x="101.79416"
       y="59.411709" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-8-7"
       width="49.467712"
       height="25.67437"
       x="29.248823"
       y="88.420822" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-97-0"
       width="24.184027"
       height="25.964542"
       x="5.3212972"
       y="88.275734" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-3-3-9"
       width="49.467712"
       height="25.67437"
       x="78.735085"
       y="88.420822" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-9-6-3"
       width="24.184027"
       height="25.964542"
       x="128.9493"
       y="88.275734" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-1-6"
       width="45.02253"
       height="28.274075"
       x="56.716785"
       y="59.369617" />
  </g>
</svg>
`;
      }
    },
    cloud: {
      label: "Cloud",
      svg: function(c,s){
        return '<svg xmlns="http://www.w3.org/2000/svg" width="'+s+'" height="'+s+'" viewBox="0 0 64 64">'
          +'<path d="M16,44 C10,44 6,40 6,34 C6,28 10,24 16,24 C16,16 22,10 32,10 C42,10 48,16 48,24 C54,24 58,28 58,34 C58,40 54,44 48,44 Z" fill="none" stroke="'+c+'" stroke-width="3" stroke-linejoin="round"/>'
          +'</svg>';
      }
    },
    server: {
      label: "Server",
      svg: function(c,s){
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 34 44" width="41.337688mm" height="41.333153mm" fill="#3a3a3a" fill-rule="evenodd" stroke="#2c2c2c" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#A" x=".5" y=".5"/><symbol id="A" overflow="visible"><path d="M24.379 7.864H0v34.603h24.379z" stroke="none" fill="#fdfdfd"/><g stroke="#3a3a3a" stroke-linejoin="miter" stroke-width=".786"><path d="M24.379 7.864H0v34.602h24.379" stroke-linecap="square" fill="none"/><path d="M24.379 42.467l7.864-7.471V0H7.864L0 7.864h24.379v34.603z" fill="#fdfdfd"/></g><path d="M24.379 7.864L32.243 0z" stroke="none" fill="#fdfdfd"/><g stroke="#3a3a3a" stroke-linejoin="miter" fill="none" stroke-width=".786"><path d="M24.379 7.864L32.243 0M.393 17.301h23.593M.393 28.311h23.593M8.65 23.986h6.685M8.65 22.02h6.685" stroke-linecap="square"/><path d="M18.088 26.346v-6.685H5.898v6.685h12.189z"/></g></symbol></svg>`;
      }
    },
    loadbal: {
      label: "LB",
      svg: function(c,s){
        return `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   width="44.719856mm"
   height="41.337704mm"
   viewBox="0 0 158.45619 146.47219"
   id="svg4294"
   version="1.1">
  <defs
     id="defs4296" />
  <metadata
     id="metadata4299">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     transform="translate(4.2915344e-6)"
     id="g869">
    <rect
       ry="3.816956"
       y="4.0686131"
       x="4.0686092"
       height="138.33496"
       width="150.31897"
       id="rect6782-4-65-3-0-6"
       style="opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:8.13722706;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1" />
    <rect
       style="opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-5"
       width="147.8936"
       height="28.35601"
       x="5.2812467"
       y="4.4881825" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-3"
       width="147.8936"
       height="28.35601"
       x="5.2812467"
       y="113.628" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-5"
       width="51.38068"
       height="28.189941"
       x="5.2812467"
       y="59.411709" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-6"
       width="49.467712"
       height="25.67437"
       x="29.213806"
       y="33.051807" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-2"
       width="24.194138"
       height="25.49596"
       x="5.2812467"
       y="33.141006" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-3-9"
       width="49.467712"
       height="25.67437"
       x="78.700119"
       y="33.051807" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-9-1"
       width="24.194138"
       height="25.49596"
       x="128.98065"
       y="33.141006" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-2-2"
       width="51.38068"
       height="28.189941"
       x="101.79416"
       y="59.411709" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-8-7"
       width="49.467712"
       height="25.67437"
       x="29.248823"
       y="88.420822" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-97-0"
       width="24.184027"
       height="25.964542"
       x="5.3212972"
       y="88.275734" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-3-3-9"
       width="49.467712"
       height="25.67437"
       x="78.735085"
       y="88.420822" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-9-2-9-6-3"
       width="24.184027"
       height="25.964542"
       x="128.9493"
       y="88.275734" />
    <rect
       style="display:inline;opacity:1;fill:#fdfdfd;fill-opacity:1;stroke:#2c2c2c;stroke-width:6.50978184;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:3.875;stroke-dasharray:none;stroke-opacity:1"
       id="rect5963-6-2-1-6"
       width="45.02253"
       height="28.274075"
       x="56.716785"
       y="59.369617" />
  </g>
</svg>
`;
      }
    }
  });
})();