/**
 * pywboard Icon Set Template
 * ===========================
 *
 * Copy this file, rename it (e.g., my-icons.js), and fill in your icons.
 *
 * RULES:
 * 1. Each icon is a function(color, size) that returns an SVG string
 * 2. The SVG should use viewBox="0 0 64 64" (all icons are 64x64)
 * 3. Use the 'color' parameter (c) for all stroke/fill colors
 * 4. Use the 'size' parameter (s) for the SVG width/height attributes
 * 5. The label is shown in the palette (keep it short: 2-8 chars)
 * 6. Icon keys should be lowercase, no spaces (use underscores)
 * 7. The set ID must be unique across all loaded sets
 *
 * LOADING:
 * - Place .js files in pywboard/assets/icons/
 * - They're auto-loaded by the PyQt6 wrapper
 * - For browser use: add <script src="icons/my-icons.js"></script>
 *   to annotate.html before the closing </body> tag
 *
 * PALETTE:
 * - The palette grid is 3 columns wide
 * - 6-9 icons per set is ideal
 * - Max ~12 before scrolling becomes needed
 */
(function(){
  window.registerIconSet("template", "My Icons", {

    // Example icon: a simple box
    example_box: {
      label: "Box",
      svg: function(c, s){
        return '<svg xmlns="http://www.w3.org/2000/svg" width="'+s+'" height="'+s+'" viewBox="0 0 64 64">'
          +'<rect x="8" y="8" width="48" height="48" rx="4" fill="none" stroke="'+c+'" stroke-width="3"/>'
          +'</svg>';
      }
    },

    // Example icon: a circle with a label
    example_node: {
      label: "Node",
      svg: function(c, s){
        return '<svg xmlns="http://www.w3.org/2000/svg" width="'+s+'" height="'+s+'" viewBox="0 0 64 64">'
          +'<circle cx="32" cy="32" r="24" fill="none" stroke="'+c+'" stroke-width="3"/>'
          +'<text x="32" y="36" fill="'+c+'" font-family="monospace" font-size="12" text-anchor="middle">N</text>'
          +'</svg>';
      }
    }

    // Add more icons here...
  });
})();
