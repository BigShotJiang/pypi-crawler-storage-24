/**
 * pywboard Icon Set: Cisco
 * Cisco-style network topology icons.
 * All icons use a 64x64 viewBox.
 *
 * Icon function signature: function(color, size) → SVG string
 *
 * NOTE: Each icon's internal SVG IDs are namespaced (e.g. "rtr_A", "sw2_A")
 *       to prevent collisions when multiple icons are rendered in the same DOM.
 */
(function(){
  window.registerIconSet("cisco", "Cisco", {
    router: {
      label: "Router",
      svg: function(c,s){
        // Cisco cylindrical router with connection arrows
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 59 40" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#rtr_A" x=".5" y=".5"/><symbol id="rtr_A" overflow="visible"><use xlink:href="#rtr_C" stroke="none" fill="#000"/><use xlink:href="#rtr_C" stroke="#fff" stroke-linejoin="miter" fill="none" stroke-width=".787"/><use xlink:href="#rtr_D" stroke="none" fill="#000"/><use xlink:href="#rtr_D" stroke="#fff" stroke-linejoin="miter" fill="none" stroke-width=".787"/><path d="M22.442 6.685l2.362 3.543-9.054 2.362 1.968-1.575L3.547 8.653 7.09 5.898 20.867 8.26l1.575-1.575zm12.596 8.66l-1.575-3.543 8.267-1.575-1.575 1.181 13.778 2.362-3.543 2.755-13.384-2.755-1.968 1.575zm-4.33-10.628l9.054-2.362v3.936L37.4 5.898l-4.33 3.543-4.33-.394 4.724-3.936-2.755-.394zm-3.937 14.171l-8.66 1.575-.394-3.936 2.362.394 4.724-3.936 4.33.787-5.117 4.33 2.755.787z" stroke="none"/></symbol><defs><path id="rtr_C" d="M57.865 11.416c0 5.905-12.99 11.022-28.736 11.022C12.99 22.438 0 17.321 0 11.416v16.139c0 6.298 12.99 11.416 29.129 11.416 15.745 0 28.736-5.117 28.736-11.416z"/><path id="rtr_D" d="M29.129 22.437c15.745 0 28.736-5.117 28.736-11.022C57.865 5.117 44.875 0 29.129 0 12.99 0 0 5.117 0 11.416c0 5.905 12.99 11.022 29.129 11.022z"/></defs></svg>`;
      }
    },
    switch_l2: {
      label: "L2 Switch",
      svg: function(c,s){
        // Cisco L2 switch - rectangle with bidirectional arrows
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 77 39" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#sw2_A" x=".5" y=".5"/><symbol id="sw2_A" overflow="visible"><g fill="#000"><path d="M56.302 36.616V18.111H0v18.505h56.302z" stroke="none"/><g stroke="#fff" stroke-linejoin="miter" stroke-width=".787"><path d="M0 18.111L22.836 0h52.365L56.302 18.111H0z"/><path d="M56.302 37.01l18.899-20.473V0L56.302 18.111V37.01z"/></g></g><path d="M33.073 13.387l-1.181.787H17.717l-1.181 1.575-3.937-1.575 7.481-2.362-1.181 1.575h14.174zm11.024-6.693l-1.181.787H28.742L27.56 9.056l-3.937-1.969 7.481-1.969-1.181 1.575h14.174zm-8.662 4.331l1.181-.787h13.78l1.575-1.575 3.544 1.575-7.481 2.362 1.575-1.575H35.435zm7.087-6.693l1.181-1.181h14.174l1.181-1.181 3.937 1.575-7.481 1.969 1.181-1.181H42.522z" stroke="none"/></symbol></svg>`;
      }
    },
    switch_l3: {
      label: "L3 Switch",
      svg: function(c,s){
        // Cisco multilayer switch - rectangle with directional arrows
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 42 43" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><style><![CDATA[.B{fill:none}.C{stroke-linecap:square}.D{stroke-width:1.969}.E{stroke-width:.394}.F{stroke-linejoin:miter}.G{stroke-width:.788}]]></style><use xlink:href="#sw3_A" x=".5" y=".5"/><symbol id="sw3_A" overflow="visible"><g stroke="#fff" class="F"><path d="M33.869 41.745V7.089H0v34.656h33.869z" fill="#000" class="G"/><path d="M16.934 18.116h10.633" class="B C D"/><path d="M27.961 14.965v6.301l3.544-3.151-3.544-3.151z" class="E"/><path d="M16.934 30.324h10.633" class="B C D"/><path d="M27.961 27.174v5.907l3.544-2.757-3.544-3.151z" class="E"/><path d="M11.027 24.417V13.784" class="B C D"/><path d="M7.876 13.39h5.907l-2.757-3.544-3.15 3.544z" class="E"/><path d="M22.842 24.417V13.784" class="B C D"/><path d="M19.691 13.39h6.301l-3.151-3.544-3.151 3.544z" class="E"/><path d="M22.842 24.417v10.239" class="B C D"/><path d="M25.992 35.05h-5.907l2.757 3.544 3.151-3.544z" class="E"/><path d="M11.027 24.417v10.239" class="B C D"/><path d="M14.177 35.05H8.27l2.757 3.544 3.151-3.544z" class="E"/><path d="M16.934 30.324H6.695" class="B C D"/><path d="M6.301 33.474v-5.907l-3.544 2.757 3.544 3.151z" class="E"/><path d="M16.934 18.116H6.695" class="B C D"/><path d="M6.301 21.266v-5.907l-3.544 2.757 3.544 3.151z" class="E"/><g class="G"><path d="M33.869 7.089H0L8.664 0h32.293v34.656l-7.089 7.089V7.089z" fill="#000"/><path d="M33.869 7.089L40.958 0" class="B C"/></g></g><use xlink:href="#sw3_C" stroke="none" fill="#000"/><use xlink:href="#sw3_C" stroke="#fff" stroke-width="1.575" class="B F"/></symbol><defs><path id="sw3_C" d="M16.929 31.512a7.06 7.06 0 0 0 7.089-7.089c0-3.938-3.151-7.482-7.089-7.482S9.84 20.485 9.84 24.423a7.06 7.06 0 0 0 7.089 7.089z"/></defs></svg>`;
      }
    },
    firewall: {
      label: "Firewall",
      svg: function(c,s){
        // Cisco firewall - brick wall pattern
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 52" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><style><![CDATA[.B{stroke:#fff}.C{stroke-linejoin:miter}.D{fill:#000}.E{stroke-width:.787}.F{stroke:none}.G{stroke-linecap:square}.H{fill:none}]]></style><use xlink:href="#fw_A" x=".5" y=".5"/><symbol id="fw_A" overflow="visible"><g class="B C D E"><path d="M0 50.368V8.657h12.592v41.711H0z"/><path d="M12.592 8.657H0L11.411 0h10.624l-9.444 8.657z"/><path d="M22.036 0v39.743l-9.444 10.624V8.657L22.036 0z"/></g><path d="M19.281 9.05V2.361z" class="D F"/><path d="M19.281 9.05V2.361" class="B C E G H"/><path d="M19.281 22.822v-6.689z" class="D F"/><path d="M19.281 22.822v-6.689" class="B C E G H"/><path d="M19.281 36.202v-6.69z" class="D F"/><path d="M19.281 36.202v-6.689" class="B C E G H"/><path d="M22.036 33.054l-9.444 10.624z" class="D F"/><path d="M22.036 33.054l-9.444 10.624" class="B C E G H"/><path d="M22.036 26.364l-9.444 10.231z" class="D F"/><path d="M22.036 26.364l-9.444 10.231" class="B C E G H"/><path d="M22.036 19.675l-9.444 9.837z" class="D F"/><path d="M22.036 19.675l-9.444 9.837" class="B C E G H"/><path d="M22.036 12.985l-9.444 9.837z" class="D F"/><path d="M22.036 12.985l-9.444 9.837" class="B C E G H"/><path d="M22.036 6.689l-9.444 9.05z" class="D F"/><path d="M22.036 6.689l-9.444 9.05" class="B C E G H"/><path d="M12.592 8.657L22.036 0z" class="D F"/><path d="M12.592 8.657L22.036 0" class="B C E G H"/><path d="M12.592 43.285H0z" class="D F"/><path d="M12.592 43.285H0" class="B C E G H"/><path d="M12.592 36.595H0z" class="D F"/><path d="M12.592 36.595H0" class="B C E G H"/><path d="M12.592 29.512H0z" class="D F"/><path d="M12.592 29.512H0" class="B C E G H"/><path d="M12.592 22.429H0z" class="D F"/><path d="M12.592 22.429H0" class="B C E G H"/><path d="M12.592 15.74H0z" class="D F"/><path d="M12.592 15.74H0" class="B C E G H"/><path d="M16.133 46.432v-6.689z" class="D F"/><path d="M16.133 46.432v-6.689" class="B C E G H"/><path d="M16.133 33.054v-7.083z" class="D F"/><path d="M16.133 33.054v-7.083" class="B C E G H"/><path d="M16.133 19.281v-6.689z" class="D F"/><path d="M16.133 19.281v-6.689" class="B C E G H"/></symbol></svg>`;
      }
    },
    cloud: {
      label: "Cloud",
      svg: function(c,s){
        // Network cloud - flatter, wider (no internal IDs needed - no symbols/defs)
        return '<svg xmlns="http://www.w3.org/2000/svg" width="'+s+'" height="'+s+'" viewBox="0 0 64 64">'
          +'<path d="M12,44 C6,44 2,39 2,33 C2,27 6,23 12,22 C13,14 20,8 30,8 C38,8 44,12 47,18 C48,17 50,17 52,18 C58,20 60,26 58,32 C62,34 62,40 58,43 C56,44 54,44 52,44 Z" fill="none" stroke="'+c+'" stroke-width="2.5" stroke-linejoin="round"/>'
          +'</svg>';
      }
    },
    server: {
      label: "Server",
      svg: function(c,s){
        // Cisco server/host - monitor style
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 34 44" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#srv_A" x=".5" y=".5"/><symbol id="srv_A" overflow="visible"><path d="M24.379 7.864H0v34.603h24.379z" stroke="none" fill="#000"/><g stroke="#fff" stroke-linejoin="miter" stroke-width=".786"><path d="M24.379 7.864H0v34.602h24.379" stroke-linecap="square" fill="none"/><path d="M24.379 42.467l7.864-7.471V0H7.864L0 7.864h24.379v34.603z" fill="#000"/></g><path d="M24.379 7.864L32.243 0z" stroke="none" fill="#000"/><g stroke="#fff" stroke-linejoin="miter" fill="none" stroke-width=".786"><path d="M24.379 7.864L32.243 0M.393 17.301h23.593M.393 28.311h23.593M8.65 23.986h6.685M8.65 22.02h6.685" stroke-linecap="square"/><path d="M18.088 26.346v-6.685H5.898v6.685h12.189z"/></g></symbol></svg>`;
      }
    },
    loadbal: {
      label: "LB",
      svg: function(c,s){
        // Load balancer - currently same artwork as server (TODO: differentiate)
        return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 60 40" fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round"><use xlink:href="#LB" x=".5" y=".5"/><symbol id="LB" overflow="visible"><g stroke="#fff" stroke-linejoin="miter" fill="#000" stroke-width=".787"><path d="M0 38.542h52.7V7.866H0v30.676z"/><path d="M58.993 29.103L52.7 38.542V7.866L58.993 0v29.103z"/><path d="M9.439 0h49.554L52.7 7.866H0L9.439 0z"/></g><g stroke="none"><path d="M18.484 24.777H7.079V22.81h11.405v-2.753l6.686 3.933-6.686 3.539v-2.753zm23.204 0H30.676V22.81h11.012v-2.753l6.686 3.933-6.686 3.539v-2.753zm-1.966-9.046l-9.045 6.293-1.18-1.573 9.439-6.292-1.573-2.36 7.472-.393-3.54 6.686-1.573-2.36zm0 16.125l-9.045-6.293-1.18 1.573 9.439 6.293-1.573 2.36 7.472.393-3.54-6.686-1.573 2.36z" fill="#000"/><path d="M18.091 23.597H7.079v-1.573h11.012v-2.753l6.686 3.54-6.686 3.933v-3.146zm23.597 0H30.283v-1.573h11.405v-2.753l6.292 3.54-6.292 3.933v-3.146zm-1.966-9.045l-9.439 6.293-1.18-1.573 9.439-5.899-1.18-2.36 7.472-.393-3.54 6.293-1.573-2.36zm0 16.125l-9.439-5.899-1.18 1.573 9.439 5.899-1.18 2.36 7.472.393-3.54-6.293-1.573 1.967z"/></g></symbol></svg>`;
      }
    }
  });
})();