// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This file acts as a single compilation unit for the mcap library.
// This resolves linker errors one-definition-rule violations.

// This define is the key. It tells the mcap headers to include the
// actual function bodies.
#ifndef MCAP_IMPLEMENTATION
#define MCAP_IMPLEMENTATION
#endif

// Include the primary headers for the mcap library.
// Since MCAP_IMPLEMENTATION is defined, the preprocessor will now
// include the implementation code from within these headers or
// any .inl files they include.
#include "mcap/mcap.hpp"
