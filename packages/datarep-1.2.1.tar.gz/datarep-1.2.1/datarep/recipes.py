"""Recipe store — save, load, and replay working retrieval code."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from importlib import resources
from pathlib import Path
from typing import Any

from datarep.config import get_recipes_dir


class RecipeStore:
    """Manages saved retrieval recipes."""

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def save(
        self,
        recipe_id: str,
        source_name: str,
        code: str,
        description: str | None = None,
        access_strategy: str | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """INSERT INTO recipes (id, source_name, description, code, access_strategy, version, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 1, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                   code = excluded.code,
                   description = excluded.description,
                   access_strategy = excluded.access_strategy,
                   version = version + 1,
                   updated_at = excluded.updated_at""",
            (recipe_id, source_name, description, code, access_strategy, now, now),
        )
        self._conn.commit()

        row = self._conn.execute(
            "SELECT version, created_at, updated_at FROM recipes WHERE id = ?",
            (recipe_id,),
        ).fetchone()

        recipes_dir = get_recipes_dir()
        recipes_dir.mkdir(parents=True, exist_ok=True)
        recipe_file = recipes_dir / f"{recipe_id}.py"
        header = f'# Recipe: {recipe_id}\n# Source: {source_name}\n# Description: {description or "N/A"}\n# Strategy: {access_strategy or "N/A"}\n# Version: {row["version"]}\n# Created: {row["created_at"]}\n\n'
        recipe_file.write_text(header + code)

        return {
            "id": recipe_id,
            "source_name": source_name,
            "description": description,
            "access_strategy": access_strategy,
            "version": row["version"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def get(self, recipe_id: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT id, source_name, description, code, access_strategy, last_used_at, times_used, version, created_at, updated_at FROM recipes WHERE id = ?",
            (recipe_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "source_name": row["source_name"],
            "description": row["description"],
            "code": row["code"],
            "access_strategy": row["access_strategy"],
            "last_used_at": row["last_used_at"],
            "times_used": row["times_used"],
            "version": row["version"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def list(self, source_name: str | None = None) -> list[dict[str, Any]]:
        if source_name:
            rows = self._conn.execute(
                "SELECT id, source_name, description, access_strategy, last_used_at, times_used, version, created_at, updated_at FROM recipes WHERE source_name = ?",
                (source_name,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT id, source_name, description, access_strategy, last_used_at, times_used, version, created_at, updated_at FROM recipes"
            ).fetchall()
        return [
            {
                "id": r["id"],
                "source_name": r["source_name"],
                "description": r["description"],
                "access_strategy": r["access_strategy"],
                "last_used_at": r["last_used_at"],
                "times_used": r["times_used"],
                "version": r["version"],
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
            }
            for r in rows
        ]

    def record_use(self, recipe_id: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            "UPDATE recipes SET last_used_at = ?, times_used = times_used + 1 WHERE id = ?",
            (now, recipe_id),
        )
        self._conn.commit()

    def delete(self, recipe_id: str) -> bool:
        cursor = self._conn.execute("DELETE FROM recipes WHERE id = ?", (recipe_id,))
        self._conn.commit()
        recipe_file = get_recipes_dir() / f"{recipe_id}.py"
        if recipe_file.exists():
            recipe_file.unlink()
        return cursor.rowcount > 0

    def find_for_source(self, source_name: str, connector: str | None = None) -> dict[str, Any] | None:
        """Find the most recently used recipe for a source.

        Tries an exact match on *source_name* first.  If nothing is found and
        *connector* differs from *source_name*, falls back to recipes whose
        ``source_name`` equals the connector — so a single generic recipe (e.g.
        ``whatsapp_web_v1`` with ``source_name='whatsapp_web'``) can serve any
        account that has ``connector='whatsapp_web'``.
        """
        row = self._conn.execute(
            """SELECT id, source_name, description, code, access_strategy, last_used_at, times_used, version, created_at, updated_at
               FROM recipes WHERE source_name = ?
               ORDER BY COALESCE(last_used_at, created_at) DESC LIMIT 1""",
            (source_name,),
        ).fetchone()

        if row is None and connector and connector != source_name:
            row = self._conn.execute(
                """SELECT id, source_name, description, code, access_strategy, last_used_at, times_used, version, created_at, updated_at
                   FROM recipes WHERE source_name = ?
                   ORDER BY COALESCE(last_used_at, created_at) DESC LIMIT 1""",
                (connector,),
            ).fetchone()

        if row is None:
            return None
        return {
            "id": row["id"],
            "source_name": row["source_name"],
            "description": row["description"],
            "code": row["code"],
            "access_strategy": row["access_strategy"],
            "last_used_at": row["last_used_at"],
            "times_used": row["times_used"],
            "version": row["version"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    def seed_builtin_recipes(self) -> list[str]:
        """Load built-in seed recipes that don't already exist in the DB.

        Returns list of recipe IDs that were seeded.
        """
        seed_pkg = "datarep.seed_recipes"
        try:
            manifest_ref = resources.files(seed_pkg).joinpath("manifest.json")
            manifest_text = manifest_ref.read_text(encoding="utf-8")
        except (FileNotFoundError, ModuleNotFoundError):
            return []

        entries = json.loads(manifest_text)
        seeded = []

        for entry in entries:
            recipe_id = entry["id"]
            source_name = entry["source_name"]

            existing = self._conn.execute(
                "SELECT 1 FROM recipes WHERE id = ?", (recipe_id,)
            ).fetchone()
            if existing:
                continue

            self._conn.execute(
                "INSERT OR IGNORE INTO sources (name, source_type, config, connector, label) VALUES (?, ?, '{}', ?, ?)",
                (source_name, entry.get("source_type", "unknown"), source_name, source_name),
            )

            code_ref = resources.files(seed_pkg).joinpath(f"{recipe_id}.py")
            code = code_ref.read_text(encoding="utf-8")

            self.save(
                recipe_id=recipe_id,
                source_name=source_name,
                code=code,
                description=entry.get("description"),
                access_strategy=entry.get("access_strategy"),
            )
            seeded.append(recipe_id)

        return seeded
