from dataclasses import dataclass
from dataclass_wizard import YAMLWizard

@dataclass
class KO(YAMLWizard):
    items: list[str]

    def list(self):
        pass

@dataclass
class OK(YAMLWizard):
    items: list[str]
