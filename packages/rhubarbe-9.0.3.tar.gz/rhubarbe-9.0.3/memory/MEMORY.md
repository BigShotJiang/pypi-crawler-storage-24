# Project Memory

## Nightly script hang analysis
Detailed analysis of why `r2lab-embedded/nightly/nightly.py` sporadically hangs for days.
See `memory/HANG_FOREVER.md`.
Key suspects: Python 3.12 `asyncio.wait_for` cancellation semantics change,
`SidecarSyncClient` blocking call without timeout, `all_off()` via `os.system()` without timeout.

## Timeout mechanisms available (beyond asyncio)
See `memory/TIMEOUT-LEVERS.md`.
Key principle: asyncio cancellation is a cooperation protocol — fragile in 3.12+.
Prefer library-level timeouts (asyncssh `connect_timeout=`, aiohttp `ClientTimeout`),
`subprocess.run(timeout=)`, `signal.alarm()`, or systemd `TimeoutStartSec`.
