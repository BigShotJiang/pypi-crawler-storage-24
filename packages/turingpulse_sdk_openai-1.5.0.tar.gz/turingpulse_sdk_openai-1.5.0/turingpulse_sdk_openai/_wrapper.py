"""OpenAI monkey-patch + proxy instrumentation for TuringPulse.

Two usage patterns:

1. **Patch** (global, affects all OpenAI calls)::

    from turingpulse_sdk_openai import patch_openai, unpatch_openai
    patch_openai(name="My Workflow")
    # ... all openai.ChatCompletion.create() calls are now instrumented
    unpatch_openai()

2. **Proxy** (explicit, per-client)::

    from turingpulse_sdk_openai import OpenAIProxy
    client = OpenAIProxy(openai.OpenAI(), name="My Workflow")
    client.chat.completions.create(...)
"""

from __future__ import annotations

import logging
from contextvars import ContextVar
from typing import Any, Optional

from turingpulse_sdk import instrument, GovernanceDirective
from turingpulse_sdk.config import MAX_FIELD_SIZE
from turingpulse_sdk.context import current_context
from turingpulse_sdk.exceptions import ConfigurationError
from turingpulse_sdk.integrations.base import _LLMClientProxy

logger = logging.getLogger("turingpulse.sdk.openai")

_INSTRUMENTING: ContextVar[bool] = ContextVar("_tp_openai_instrumenting", default=False)

_ORIGINAL_CREATE: Any = None
_ORIGINAL_ACREATE: Any = None


def _extract_usage(response: Any) -> tuple[int, int]:
    """Extract input/output token counts from an OpenAI response."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return 0, 0
    return (
        getattr(usage, "prompt_tokens", 0) or 0,
        getattr(usage, "completion_tokens", 0) or 0,
    )


def _extract_model(response: Any) -> str:
    return getattr(response, "model", "unknown")


def patch_openai(
    *,
    name: str | None = None,
    governance: Optional[GovernanceDirective] = None,
) -> None:
    """Monkey-patch ``openai.resources.chat.completions.Completions.create``.

    Requires ``name`` or ``TP_WORKFLOW_NAME`` env var to be set.
    """
    import os

    global _ORIGINAL_CREATE, _ORIGINAL_ACREATE

    effective_name = name or os.getenv("TP_WORKFLOW_NAME", "")
    if not effective_name:
        raise ConfigurationError(
            "patch_openai() requires name= or TP_WORKFLOW_NAME to be set."
        )

    try:
        from openai.resources.chat.completions import Completions, AsyncCompletions
    except ImportError as exc:
        raise ImportError("openai package is required: pip install openai>=1.78.0") from exc

    if _ORIGINAL_CREATE is not None:
        logger.warning("OpenAI is already patched — skipping duplicate patch_openai()")
        return

    _ORIGINAL_CREATE = Completions.create
    _ORIGINAL_ACREATE = AsyncCompletions.create

    @instrument(name=effective_name, governance=governance)
    def _patched_create(self_completions, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return _ORIGINAL_CREATE(self_completions, *args, **kwargs)

        token = _INSTRUMENTING.set(True)
        try:
            response = _ORIGINAL_CREATE(self_completions, *args, **kwargs)
            _record_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    @instrument(name=effective_name, governance=governance)
    async def _patched_acreate(self_completions, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return await _ORIGINAL_ACREATE(self_completions, *args, **kwargs)

        token = _INSTRUMENTING.set(True)
        try:
            response = await _ORIGINAL_ACREATE(self_completions, *args, **kwargs)
            _record_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    Completions.create = _patched_create
    AsyncCompletions.create = _patched_acreate
    logger.info("OpenAI patched for TuringPulse instrumentation")


def unpatch_openai() -> None:
    """Restore original OpenAI methods."""
    global _ORIGINAL_CREATE, _ORIGINAL_ACREATE

    if _ORIGINAL_CREATE is None:
        return

    try:
        from openai.resources.chat.completions import Completions, AsyncCompletions
        Completions.create = _ORIGINAL_CREATE
        AsyncCompletions.create = _ORIGINAL_ACREATE
    except ImportError:
        pass

    _ORIGINAL_CREATE = None
    _ORIGINAL_ACREATE = None
    logger.info("OpenAI unpatched — original methods restored")


def _record_span(response: Any, kwargs: dict) -> None:
    """Populate the current execution context with OpenAI response data."""
    ctx = current_context()
    if not ctx:
        return

    ctx.framework = "openai"
    ctx.node_type = "llm"

    input_tokens, output_tokens = _extract_usage(response)
    ctx.set_tokens(input_tokens, output_tokens)
    ctx.set_model(_extract_model(response), "openai")

    messages = kwargs.get("messages", [])
    if messages:
        last_user = next((m for m in reversed(messages) if m.get("role") == "user"), None)
        system = next((m for m in messages if m.get("role") == "system"), None)
        if last_user:
            ctx.set_prompt(
                str(last_user.get("content", ""))[:MAX_FIELD_SIZE],
                system_prompt=str(system.get("content", ""))[:MAX_FIELD_SIZE] if system else None,
            )

    tools_def = kwargs.get("tools")
    if tools_def:
        tool_names = []
        for t in tools_def:
            func = t.get("function") if isinstance(t, dict) else getattr(t, "function", None)
            if func:
                tname = func.get("name") if isinstance(func, dict) else getattr(func, "name", None)
                if tname:
                    tool_names.append(tname)
        if tool_names:
            ctx.available_tools = tool_names
    else:
        functions_def = kwargs.get("functions")
        if functions_def:
            tool_names = [
                f.get("name") if isinstance(f, dict) else getattr(f, "name", None)
                for f in functions_def
            ]
            tool_names = [n for n in tool_names if n]
            if tool_names:
                ctx.available_tools = tool_names

    choices = getattr(response, "choices", [])
    if choices:
        output = getattr(choices[0], "message", None)
        if output:
            ctx.set_io(output_data=str(getattr(output, "content", ""))[:MAX_FIELD_SIZE])

            tool_calls = getattr(output, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    ctx.add_tool_call(
                        tool_name=getattr(tc.function, "name", "unknown"),
                        tool_args={"arguments": getattr(tc.function, "arguments", "")},
                        tool_id=getattr(tc, "id", None),
                    )


class OpenAIProxy(_LLMClientProxy):
    """Proxy wrapper for an OpenAI client instance.

    Usage::

        from openai import OpenAI
        from turingpulse_sdk_openai import OpenAIProxy

        client = OpenAIProxy(OpenAI(), name="My Workflow")
        response = client.chat.completions.create(model="gpt-4", messages=[...])
    """

    def __init__(
        self,
        client: Any,
        *,
        name: str,
        governance: Optional[GovernanceDirective] = None,
    ):
        super().__init__(client, provider="openai")
        object.__setattr__(self, "_tp_name", name)
        object.__setattr__(self, "_tp_governance", governance)

    @property
    def chat(self) -> Any:
        real_chat = getattr(object.__getattribute__(self, "_tp_client"), "chat")
        return _ChatProxy(
            real_chat,
            name=object.__getattribute__(self, "_tp_name"),
            governance=object.__getattribute__(self, "_tp_governance"),
        )


class _ChatProxy:
    def __init__(self, chat: Any, *, name: str, governance: Optional[GovernanceDirective]):
        self._chat = chat
        self._name = name
        self._governance = governance

    @property
    def completions(self) -> "_CompletionsProxy":
        return _CompletionsProxy(
            self._chat.completions,
            name=self._name,
            governance=self._governance,
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._chat, name)


class _CompletionsProxy:
    def __init__(self, completions: Any, *, name: str, governance: Optional[GovernanceDirective]):
        self._completions = completions
        self._name = name
        self._governance = governance

    @instrument(name="")  # name set dynamically
    def create(self, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return self._completions.create(**kwargs)

        token = _INSTRUMENTING.set(True)
        try:
            response = self._completions.create(**kwargs)
            _record_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._completions, name)
