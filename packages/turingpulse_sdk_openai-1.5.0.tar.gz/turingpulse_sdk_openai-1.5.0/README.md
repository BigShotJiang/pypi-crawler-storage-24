# turingpulse-sdk-openai

TuringPulse SDK integration for OpenAI — automatic tracing for GPT-4, GPT-4o, and Embeddings.

## Installation

```bash
pip install turingpulse-sdk-openai
```

## Quick Start

```python
from openai import OpenAI
from turingpulse_sdk import init, TuringPulseConfig
from turingpulse_sdk_openai import patch_openai

init(TuringPulseConfig(api_key="sk_live_...", workflow_name="my-project"))
patch_openai(name="my-project")

client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Documentation

Full documentation: [turingpulse.ai/docs/sdk/openai](https://turingpulse.ai/docs/sdk/openai)

## Requirements

- Python >= 3.11
- turingpulse-sdk >= 1.0.0
- openai >= 1.78.0
