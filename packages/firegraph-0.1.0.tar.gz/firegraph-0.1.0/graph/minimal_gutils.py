"""
Minimal GUtils for standalone firegraph (no qbrain).
Same add_node/add_edge/save_graph interface as full GUtils.
"""
import json
import re

import networkx as nx

# Keys to strip before JSON serialization (e.g. callable)
_NON_SERIALIZABLE_KEYS = {"callable"}


def _save_graph_fallback(G, dest_path: str):
    """Save graph to JSON, stripping non-serializable node/edge attrs."""
    G_copy = nx.MultiGraph() if isinstance(G, nx.MultiGraph) else nx.Graph()
    for nid, attrs in G.nodes(data=True):
        clean = {k: v for k, v in attrs.items() if k not in _NON_SERIALIZABLE_KEYS}
        G_copy.add_node(nid, **clean)
    for src, trgt, *rest in G.edges(data=True):
        attrs = rest[0] if rest else {}
        G_copy.add_edge(src, trgt, **{k: v for k, v in attrs.items() if k not in _NON_SERIALIZABLE_KEYS})
    data = nx.node_link_data(G_copy, edges="edges")
    with open(dest_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)


class MinimalGUtils:
    """Minimal GUtils for standalone use (no qbrain). Same add_node/add_edge interface."""

    def __init__(self, G=None, nx_only=True, **kwargs):
        self.G = nx.MultiGraph() if G is None else G
        self.nx_only = nx_only

    def _clean(self, s):
        return re.sub(r"[^a-zA-Z0-9_]", "", str(s)) if s else ""

    def add_node(self, attrs: dict, flatten=False):
        t = attrs.get("type")
        if not t:
            raise ValueError("NODE HAS NO ATTR type")
        nid = attrs["id"]
        self.G.add_node(nid, **{k: v for k, v in attrs.items() if k != "id"})
        return True

    def add_edge(self, src=None, trgt=None, attrs: dict = None, **kwargs):
        attrs = attrs or {}
        src = src or attrs.get("src")
        trgt = trgt or attrs.get("trgt")
        src_layer = (attrs.get("src_layer") or "NODE").upper().replace(" ", "_")
        trgt_layer = (attrs.get("trgt_layer") or "NODE").upper().replace(" ", "_")
        rel = (attrs.get("rel") or "link").lower().replace(" ", "_")
        if src and trgt:
            edge_attrs = {k: v for k, v in attrs.items() if k not in ("src", "trgt", "src_layer", "trgt_layer", "rel")}
            self.G.add_edge(src, trgt, rel=rel, src_layer=src_layer, trgt_layer=trgt_layer, **edge_attrs)

    def save_graph(self, dest_file):
        _save_graph_fallback(self.G, dest_file)
