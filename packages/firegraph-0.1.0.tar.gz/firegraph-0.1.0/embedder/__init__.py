"""
Embedder: sentence-transformers for semantic similarity.
Requires: pip install firegraph[semantic]
"""
import json

import numpy as np
from functools import lru_cache

try:
    from sentence_transformers import SentenceTransformer
    _EMBEDDER_AVAILABLE = True
except ImportError:
    SentenceTransformer = None  # type: ignore[assignment]
    _EMBEDDER_AVAILABLE = False

EMBEDDER = None


@lru_cache(maxsize=1)
def get_embedder(dim=7):
    if not _EMBEDDER_AVAILABLE:
        raise ImportError("sentence-transformers required. Install: pip install firegraph[semantic]")
    global EMBEDDER
    if EMBEDDER is None:
        model = "all-mpnet-base-v2" if dim == 7 else "all-MiniLM-L6-v2"
        return SentenceTransformer(model)
    return EMBEDDER


@lru_cache(maxsize=1)
def embed(text):
    if not _EMBEDDER_AVAILABLE or EMBEDDER is None:
        raise ImportError("sentence-transformers required. Install: pip install firegraph[semantic]")
    if isinstance(text, dict):
        text = json.dumps(text)
    return np.array(EMBEDDER.encode(str(text.lower())), dtype=np.float64)


@lru_cache(maxsize=128)
def similarity(vec1_tuple, vec2_tuple):
    v1 = np.array(vec1_tuple)
    v2 = np.array(vec2_tuple)
    return np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))


if _EMBEDDER_AVAILABLE:
    EMBEDDER = get_embedder()

__all__ = ["embed", "similarity", "get_embedder"]


