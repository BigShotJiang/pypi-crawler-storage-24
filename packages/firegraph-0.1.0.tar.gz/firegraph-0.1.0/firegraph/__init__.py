"""
Firegraph: analyze Python code structure, build relational graph, visualize.
Single import point for all public API.
"""
from run_firegraph import run_workflow
from graph_creator import StructInspector
from graph import (
    GUtils,
    SemanticMaster,
    DATA_PROCESSORS,
    create_g_visual,
)

# Optional embedder (requires sentence-transformers, semantic extra)
try:
    from embedder import embed, similarity, get_embedder
    _EMBEDDER_EXPORTS = ("embed", "similarity", "get_embedder")
except ImportError:
    embed = None  # type: ignore[assignment]
    similarity = None  # type: ignore[assignment]
    get_embedder = None  # type: ignore[assignment]
    _EMBEDDER_EXPORTS = ()

__all__ = [
    "run_workflow",
    "StructInspector",
    "GUtils",
    "SemanticMaster",
    "DATA_PROCESSORS",
    "create_g_visual",
    *_EMBEDDER_EXPORTS,
]

__version__ = "0.1.0"
