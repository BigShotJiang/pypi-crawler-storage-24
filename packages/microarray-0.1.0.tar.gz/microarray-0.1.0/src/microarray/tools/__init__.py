"""Tools for microarray data analysis.

This module provides analytical tools for microarray data, including:
- Dimension reduction (MDS)
- Biomart-based feature annotation
"""

from microarray.tools._biomart import BiomartDataset, annotate
from microarray.tools._empirical_bayes import ebayes, squeeze_var
from microarray.tools._linear_models import lm_fit
from microarray.tools._mds import mds
from microarray.tools._pca import pca
from microarray.tools._score import score
from microarray.tools._toptable import top_table

__all__ = [
    "mds",
    "pca",
    "BiomartDataset",
    "annotate",
    "ebayes",
    "squeeze_var",
    "lm_fit",
    "score",
    "top_table",
]
