"""Gene set scoring helpers for sample-level summaries."""

from collections.abc import Sequence
from typing import Literal

import numpy as np
from anndata import AnnData
from scipy import sparse


def score(
    adata: AnnData,
    gene_set: Sequence[str],
    method: Literal["mean", "median", "zscore"] = "mean",
    *,
    score_name: str = "score",
    var_key: str | None = None,
    layer: str | None = None,
    copy: bool = False,
) -> AnnData | None:
    """Compute per-sample gene set scores and write them to ``adata.obs``.

    Args:
        adata: AnnData object with expression values in ``.X`` or ``layer``.
        gene_set: Sequence of genes/features to score.
        method: Scoring method: ``"mean"``, ``"median"``, or ``"zscore"``.
        score_name: Column name used in ``adata.obs`` for output scores.
        var_key: Optional ``adata.var`` column containing feature identifiers.
            If not provided, ``adata.var_names`` are used.
        layer: Optional layer key to use instead of ``adata.X``.
        copy: Return a copy instead of writing into ``adata`` in place.

    Returns:
        Modified AnnData when ``copy=True``, else ``None``.

    Raises:
        ValueError: If ``gene_set`` is empty, method is unknown, or no genes match.
        KeyError: If ``var_key`` or ``layer`` is missing.
    """
    adata = adata.copy() if copy else adata

    if len(gene_set) == 0:
        raise ValueError("gene_set must contain at least one gene")

    if var_key is None:
        feature_ids = adata.var_names.astype(str)
    else:
        if var_key not in adata.var.columns:
            raise KeyError(f"AnnData .var has no '{var_key}' column")
        feature_ids = adata.var[var_key].astype(str)

    gene_lookup = {str(gene) for gene in gene_set}
    feature_mask = np.asarray(feature_ids.isin(gene_lookup), dtype=bool)
    if not np.any(feature_mask):
        raise ValueError("None of the provided genes were found in AnnData features")

    if layer is None:
        matrix = adata.X
    else:
        if layer not in adata.layers:
            raise KeyError(f"AnnData .layers has no '{layer}' layer")
        matrix = adata.layers[layer]

    subset = matrix[:, feature_mask]
    if sparse.issparse(subset):
        values = subset.toarray()
    else:
        values = np.asarray(subset)

    if method == "mean":
        scores = np.nanmean(values, axis=1)
    elif method == "median":
        scores = np.nanmedian(values, axis=1)
    elif method == "zscore":
        gene_mean = np.nanmean(values, axis=0)
        gene_std = np.nanstd(values, axis=0)
        z_values = np.zeros_like(values, dtype=float)
        valid = gene_std > 0
        z_values[:, valid] = (values[:, valid] - gene_mean[valid]) / gene_std[valid]
        scores = np.nanmean(z_values, axis=1)
    else:
        raise ValueError(f"Unknown scoring method: {method}")

    adata.obs[score_name] = np.asarray(scores, dtype=float)

    return adata if copy else None
