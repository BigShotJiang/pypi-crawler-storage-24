"""Multidimensional scaling for microarray data."""

import numpy as np
from anndata import AnnData
from sklearn.manifold import MDS
from sklearn.metrics import pairwise_distances


def mds(
    adata: AnnData,
    top: int = 500,
    gene_selection: str = "common",
    n_components: int = 2,
    obsm_key: str = "X_mds",
    random_state: int = 42,
    copy: bool = False,
) -> AnnData | None:
    """Compute Multidimensional Scaling (MDS) embedding.

    MDS reduces high-dimensional expression data to a lower-dimensional space
    while preserving pairwise distances between samples. This is useful for
    visualizing sample relationships and identifying outliers or batch effects.

    Args:
        adata: AnnData object with probe-level expression data in .X
        top: Number of top varying probes to use for distance calculation. Default 500.
        gene_selection: Method for selecting genes:
            - "common": Use top probes with highest median absolute deviation
            - "pairwise": Use different probes for each pair (not implemented)
        n_components: Number of dimensions to reduce to. Default 2.
        obsm_key: Key to store the MDS embedding in .obsm. Default "X_mds".
        random_state: Random state for reproducibility. Default 42.
        copy: Return a copy instead of writing to adata. Default False.

    Returns:
        Returns None if `copy=False`, else returns an `AnnData` object with the
        MDS embedding stored in `.obsm[obsm_key]`.

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> import microarray as ma
        >>> data = np.random.randn(1000, 6)
        >>> adata = ad.AnnData(data.T)  # Samples x probes
        >>> ma.tl.mds(adata, top=500)
        >>> print(adata.obsm["X_mds"].shape)
        (6, 2)
    """
    adata = adata.copy() if copy else adata

    # Get expression matrix (samples x probes)
    expr = adata.X
    n_samples, n_probes = expr.shape

    # Convert to log2 if not already
    if expr.min() >= 0 and (expr.max() - expr.min()) > 20:
        log_expr = np.log2(expr + 1)
    else:
        log_expr = expr

    # Gene selection
    if gene_selection == "common":
        # Calculate median absolute deviation for each probe
        mad = np.median(np.abs(log_expr - np.median(log_expr, axis=0)), axis=0)
        # Select top varying probes
        top_n = min(top, n_probes)
        top_indices = np.argpartition(mad, -top_n)[-top_n:]
        expr_subset = log_expr[:, top_indices]
    elif gene_selection == "pairwise":
        raise NotImplementedError("Pairwise gene selection not yet implemented")
    else:
        raise ValueError(f"Unknown gene_selection method: {gene_selection}")

    # Calculate pairwise distances
    # Use Euclidean distance by default
    distances = pairwise_distances(expr_subset, metric="euclidean")

    # Perform MDS
    mds_model = MDS(
        n_components=n_components,
        metric="precomputed",
        n_init=4,
        init="random",
        random_state=random_state,
    )
    coords = mds_model.fit_transform(distances)

    # Store in obsm
    adata.obsm[obsm_key] = coords

    # Store parameters in uns
    adata.uns[obsm_key] = {
        "params": {
            "top": top,
            "gene_selection": gene_selection,
            "n_components": n_components,
            "random_state": random_state,
        }
    }

    return adata if copy else None
