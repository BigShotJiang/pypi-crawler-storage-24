"""Helper functions for F-distribution estimation.

This module provides utilities for fitting scaled F-distributions to sample
variances, which is a key component of the empirical Bayes variance moderation.
"""

import warnings

import numpy as np
from scipy.optimize import root_scalar
from scipy.special import digamma, polygamma


def trigamma_inverse(x: float, tol: float = 1e-8) -> float:
    """Compute the inverse trigamma function.

    The trigamma function is the second derivative of the log-gamma function.
    This function finds y such that trigamma(y) = x.

    Parameters
    ----------
    x : float
        Target value for which to find the inverse trigamma.
    x : float
        Target value for which to find the inverse trigamma.
    tol : float, default=1e-8
        Convergence tolerance for the root-finding algorithm.

    Returns:
    -------
    float
        Value y such that trigamma(y) ≈ x.

    Notes:
    -----
    Uses scipy.optimize.root_scalar with the 'brentq' method for numerical
    inversion. The search is bounded between 0.001 and 10000 to ensure
    convergence for typical variance estimation scenarios.

    Examples:
    --------
    >>> from microarray.tools._fdist import trigamma_inverse
    >>> # trigamma(1) ≈ 1.6449
    >>> trigamma_inverse(1.6449)
    1.0
    """
    if x <= 0:
        raise ValueError("trigamma_inverse requires positive input")

    # Define the function to find root of: trigamma(y) - x = 0
    def f(y):
        return polygamma(1, y) - x

    # Use reasonable bounds for typical variance scenarios
    try:
        result = root_scalar(f, bracket=[0.001, 10000], method="brentq", xtol=tol)
        return result.root
    except ValueError:
        # If bracket doesn't work, try a wider range
        warnings.warn("Standard bracket failed, trying extended range", stacklevel=2)
        result = root_scalar(f, bracket=[1e-6, 1e6], method="brentq", xtol=tol)
        return result.root


def fit_fdist(x: np.ndarray, df1: np.ndarray, covariate=None, robust: bool = False) -> tuple[float, float]:
    """Fit scaled F-distribution to sample variances.

    Estimates the scale and degrees of freedom of a scaled F-distribution by
    matching the mean and variance of log-transformed variances (method of moments).
    This is used for empirical Bayes variance shrinkage in limma.

    Parameters
    ----------
    x : np.ndarray
        Sample variances (gene-wise residual variances).
    df1 : np.ndarray
        Degrees of freedom for each sample variance (residual df per gene).
    covariate : np.ndarray, optional
        Covariate for modeling intensity-dependent variance trends.
        Not implemented in this version.
    robust : bool, default=False
        Use robust estimation resistant to outlier variances.
        Not implemented in this version.

    Returns:
    -------
    tuple of (float, float)
        - scale: Scale parameter (s2.prior, prior variance estimate)
        - df2: Degrees of freedom (df.prior)

    Notes:
    -----
    The algorithm works as follows:

    1. Compute z = log(variance) for each gene
    2. Adjust for expected value: e = z - digamma(df1/2) + log(df1/2)
    3. Compute moments of e: mean (emean) and variance (evar)
    4. Estimate df2 using trigamma inverse: trigamma(df2/2) = evar
    5. Estimate scale from mean: s20 = exp(emean + digamma(df2/2) - log(df2/2))

    This method is based on the limma package's fitFDist function.

    References:
    ----------
    Smyth, G. K. (2004). Linear models and empirical Bayes methods for assessing
    differential expression in microarray experiments. Statistical Applications
    in Genetics and Molecular Biology, 3(1).

    Examples:
    --------
    >>> import numpy as np
    >>> from microarray.tools._fdist import fit_fdist
    >>> # Simulate some gene-wise variances
    >>> variances = np.random.gamma(shape=5, scale=0.1, size=1000)
    >>> df = np.full(1000, 10)  # All genes have df=10
    >>> scale, df_prior = fit_fdist(variances, df)
    >>> print(f"Prior variance: {scale:.3f}, Prior df: {df_prior:.2f}")
    """
    if covariate is not None:
        raise NotImplementedError("Covariate trends not yet implemented")
    if robust:
        raise NotImplementedError("Robust estimation not yet implemented")

    # Remove missing values and non-positive variances
    ok = np.isfinite(x) & np.isfinite(df1) & (x > 0) & (df1 > 0)
    x = x[ok]
    df1 = df1[ok]

    if len(x) < 2:
        warnings.warn("Too few variances for F-distribution fitting", stacklevel=2)
        return np.nan, np.nan

    # Work on log scale
    z = np.log(x)

    # Adjust for expected value of log(chi-square / df)
    # E[log(variance)] = digamma(df/2) - log(df/2) + log(s2.prior) + log(df2/2) - digamma(df2/2)
    # So: z - digamma(df1/2) + log(df1/2) should have mean: log(s2.prior) + log(df2/2) - digamma(df2/2)
    e = z - digamma(df1 / 2) + np.log(df1 / 2)

    # Estimate moments
    emean = np.mean(e)
    evar = np.var(e, ddof=1)

    # Estimate df2 from variance: Var[log(chi-square/df)] = trigamma(df/2)
    # So evar = trigamma(df2/2), hence df2 = 2 * trigamma_inverse(evar)
    if evar > 0:
        try:
            df2 = 2 * trigamma_inverse(evar)
        except Exception as exc:  # noqa: BLE001
            warnings.warn(f"Failed to estimate df.prior: {exc}", stacklevel=2)
            df2 = 4.0  # Default fallback
    else:
        # Very small variance means large df
        df2 = 100.0

    # Estimate scale from mean
    # emean = log(s2.prior) + log(df2/2) - digamma(df2/2)
    # So: s2.prior = exp(emean - log(df2/2) + digamma(df2/2))
    s2_prior = np.exp(emean - np.log(df2 / 2) + digamma(df2 / 2))

    # Sanity checks
    if not np.isfinite(df2) or df2 <= 0:
        warnings.warn("Invalid df.prior estimated, using default", stacklevel=2)
        df2 = 4.0

    if not np.isfinite(s2_prior) or s2_prior <= 0:
        warnings.warn("Invalid s2.prior estimated, using median variance", stacklevel=2)
        s2_prior = np.median(x)

    return s2_prior, df2
