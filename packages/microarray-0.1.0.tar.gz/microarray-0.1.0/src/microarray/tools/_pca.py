"""Principal component analysis for microarray data."""

from __future__ import annotations

import numpy as np
from anndata import AnnData
from scipy import sparse
from sklearn.decomposition import PCA


def pca(
    adata: AnnData,
    n_components: int | None = None,
    obsm_key: str = "X_pca",
    layer: str | None = None,
    scale: bool = False,
    random_state: int | None = 42,
    copy: bool = False,
) -> AnnData | None:
    """Compute a PCA embedding and store it in ``adata.obsm``.

    Args:
        adata: AnnData object with expression values in ``.X`` or ``layer``.
        n_components: Number of principal components to compute.
            Defaults to ``adata.n_obs``.
        obsm_key: Key used to store coordinates in ``adata.obsm``.
        layer: Optional layer key to use instead of ``adata.X``.
        scale: Whether to z-scale each feature before PCA.
        random_state: Random seed used by PCA solvers that require randomness.
        copy: Return a modified copy instead of writing in place.

    Returns:
        Modified AnnData when ``copy=True``, else ``None``.

    Raises:
        ValueError: If ``n_components`` is invalid.
        KeyError: If ``layer`` is provided but missing from ``adata.layers``.
    """
    adata = adata.copy() if copy else adata

    if layer is None:
        matrix = adata.X
    else:
        if layer not in adata.layers:
            raise KeyError(f"AnnData .layers has no '{layer}' layer")
        matrix = adata.layers[layer]

    values = matrix.toarray() if sparse.issparse(matrix) else np.asarray(matrix)
    values = np.asarray(values, dtype=float)

    if values.ndim != 2:
        raise ValueError("Expected a 2D expression matrix")

    if n_components is None:
        n_components = adata.n_obs

    if n_components < 1:
        raise ValueError("n_components must be at least 1")

    max_components = min(values.shape)
    if n_components > max_components:
        raise ValueError(f"n_components must be <= {max_components} for input with shape {values.shape}")

    if scale:
        mean = np.nanmean(values, axis=0)
        std = np.nanstd(values, axis=0)
        scaled = values - mean
        valid = std > 0
        scaled[:, valid] = scaled[:, valid] / std[valid]
        values = scaled

    model = PCA(n_components=n_components, random_state=random_state)
    coords = model.fit_transform(values)

    adata.obsm[obsm_key] = coords
    adata.uns[obsm_key] = {
        "variance_ratio": model.explained_variance_ratio_.copy(),
        "variance": model.explained_variance_.copy(),
        "components": model.components_.copy(),
        "params": {
            "n_components": n_components,
            "layer": layer,
            "scale": scale,
            "random_state": random_state,
        },
    }

    return adata if copy else None
