"""Extract and format top differentially expressed genes.

This module provides functions for extracting results from empirical Bayes
moderated differential expression analysis, with multiple testing correction
and flexible sorting/filtering options.
"""

import warnings
from typing import Literal

import numpy as np
import pandas as pd
from anndata import AnnData
from scipy import stats
from statsmodels.stats.multitest import multipletests


def top_table(
    data: AnnData | dict,
    group: str | None = None,
    coef: int | None = None,
    reference: int | None = None,
    number: int = 10,
    adjust_method: str = "fdr_bh",
    sort_by: Literal["logfc", "avg_expr", "t", "p_value", "b", "none"] = "b",
    p_value: float = 1.0,
    lfc: float = 0.0,
) -> pd.DataFrame:
    """Extract top differentially expressed genes from a moderated fit.

    Creates a summary table of the top genes ranked by evidence of differential
    expression, with multiple testing correction and flexible filtering/sorting.
    This is the final step in limma-style differential expression analysis.

    Parameters
    ----------
    fit : dict
        Linear model fit object from ebayes(), containing:
        - coefficients: coefficient estimates
        - t: moderated t-statistics
        - p_value: raw p-values
        - lods: B-statistics (log-odds)
        - genes: gene identifiers
        - adata: AnnData object for annotation retrieval
    coef : int, optional
        Which coefficient/contrast to extract. If None, uses the first coefficient
        (index 0). Coefficients correspond to columns in the design matrix.
    reference : int, optional
        Reference coefficient index for a pairwise contrast. When provided,
        statistics are computed for (coef - reference). This is useful for
        no-intercept group-mean designs where columns represent groups.
    number : int, default=10
        Maximum number of genes to return.
    adjust_method : str, default="fdr_bh"
        Multiple testing correction method. Options:
        - "bonferroni": Bonferroni correction
        - "sidak": Sidak correction
        - "holm-sidak": Holm-Sidak correction
        - "holm": Holm correction
        - "simes-hochberg": Simes-Hochberg correction
        - "hommel": Hommel correction
        - "fdr_bh": Benjamini-Hochberg FDR (default)
        - "fdr_by": Benjamini-Yekutieli FDR
        - "fdr_tsbh": Two-stage Benjamini-Hochberg
        - "fdr_tsbky": Two-stage Benjamini-Krieger-Yekutieli
    sort_by : {"logfc", "avg_expr", "t", "p_value", "b", "none"}, default="b"
        Column to sort results by:
        - "logfc": Log fold-change (descending absolute value)
        - "avg_expr": Average expression level (descending)
        - "t": Moderated t-statistic (descending absolute value)
        - "p_value": P-value (ascending)
        - "b": B-statistic/log-odds (descending)
        - "none": No sorting (gene order as in original data)
    p_value : float, default=1.0
        Filter genes by adjusted p-value threshold. Only genes with
        p_adj ≤ p_value are returned.
    lfc : float, default=0.0
        Filter genes by log-fold-change threshold. Only genes with
        |logfc| ≥ lfc are returned.

    Returns:
    -------
    pd.DataFrame
        Results table with the following columns:
        - Gene identifiers (index)
        - logfc: Log2 fold-change for the selected coefficient
        - avg_expr: Average expression across all samples
        - t: Moderated t-statistic
        - p_value: Raw p-value
        - p_adj: Adjusted p-value (multiple testing corrected)
        - b: B-statistic (log-odds of differential expression)

        Additional columns from adata.var are also included if available.

    Notes:
    -----
    **Multiple Testing Correction:**

    When testing thousands of genes simultaneously, multiple testing correction
    is essential to control false discovery rate (FDR) or family-wise error rate
    (FWER). The default "fdr_bh" (Benjamini-Hochberg) controls FDR, meaning that
    among genes called significant at level α, we expect α proportion to be false
    positives.

    **Sorting and Filtering:**

    The function applies filtering (p_value and lfc thresholds) before selecting
    the top 'number' genes. Sorting determines which genes appear in the top N.

    **B-statistic:**

    The B-statistic (log-odds) is often the best ranking criterion because it
    accounts for both effect size and statistical significance. Higher B values
    indicate stronger evidence of differential expression.

    **Typical Usage:**

    1. Fit linear models: fit = lm_fit(adata, design)
    2. Moderate variances: fit = ebayes(fit)
    3. Extract top genes: results = top_table(fit, coef=1, number=100)

    Examples:
    --------
    >>> import microarray as ma
    >>> import numpy as np
    >>> # After lm_fit and ebayes
    >>> fit = ma.tl.ebayes(fit)
    >>> # Get top 20 genes for coefficient 1 (e.g., treatment effect)
    >>> results = ma.tl.top_table(fit, coef=1, number=20)
    >>> print(results)
    >>> # Filter by adjusted p-value and fold-change
    >>> sig_genes = ma.tl.top_table(
    ...     fit,
    ...     coef=1,
    ...     number=1000,
    ...     p_value=0.05,  # FDR < 5%
    ...     lfc=1.0,  # |log2FC| > 1 (i.e., >2-fold change)
    ...     sort_by="logfc",
    ... )
    >>> print(f"Found {len(sig_genes)} significant genes")
    >>> # Get all genes, sorted by p-value
    >>> all_results = ma.tl.top_table(
    ...     fit,
    ...     coef=1,
    ...     number=np.inf,  # Get all genes
    ...     sort_by="p_value",
    ... )
    >>> # Create volcano plot
    >>> import matplotlib.pyplot as plt
    >>> plt.scatter(all_results["logfc"], -np.log10(all_results["p_value"]))
    >>> plt.xlabel("Log2 Fold Change")
    >>> plt.ylabel("-log10(P-value)")
    >>> plt.title("Volcano Plot")

    References:
    ----------
    Smyth, G. K. (2004). Linear models and empirical Bayes methods for assessing
    differential expression in microarray experiments. Statistical Applications
    in Genetics and Molecular Biology, 3(1).

    Benjamini, Y., and Hochberg, Y. (1995). Controlling the false discovery rate:
    a practical and powerful approach to multiple testing. Journal of the Royal
    Statistical Society B, 57, 289-300.

    See Also:
    --------
    lm_fit : Fit linear models
    ebayes : Apply empirical Bayes moderation
    """
    if isinstance(data, AnnData):
        adata = data
        fit = adata.uns.get("lm_fit")
        if fit is None:
            raise ValueError("No fit object found in adata.uns['lm_fit']. Run lm_fit and ebayes first.")
    else:
        fit = data
        adata = fit.get("adata") if isinstance(fit, dict) else None

    # Validate that ebayes has been run
    required_keys = ["t", "p_value", "coefficients", "genes"]
    for key in required_keys:
        if key not in fit:
            raise ValueError(f"Fit object missing '{key}'. Did you run ebayes() before top_table()?")

    # Select coefficient.
    # Limma's topTable avoids using intercept-only tests by default when
    # multiple coefficients are present.
    n_coef = fit["coefficients"].shape[1]
    design = fit.get("design")

    if group is not None:
        group_to_column = fit.get("group_to_column")
        design_columns = fit.get("design_columns")
        if group_to_column is None or design_columns is None:
            raise ValueError("Fit object does not contain group metadata. Re-run lm_fit with groupby.")

        if hasattr(group_to_column, "__len__") and len(group_to_column) == 0:
            raise ValueError("Fit object does not contain group metadata. Re-run lm_fit with groupby.")

        if hasattr(design_columns, "__len__") and len(design_columns) == 0:
            raise ValueError("Fit object does not contain group metadata. Re-run lm_fit with groupby.")

        if not isinstance(group_to_column, dict):
            raise ValueError("Fit object contains invalid 'group_to_column' metadata. Re-run lm_fit with groupby.")

        if not isinstance(design_columns, list):
            design_columns = list(design_columns)

        if group not in group_to_column:
            valid_groups = ", ".join(str(x) for x in group_to_column.keys())
            raise ValueError(f"Unknown group '{group}'. Valid groups: {valid_groups}")
        coef = int(design_columns.index(group_to_column[group]))
    elif coef is not None:
        warnings.warn("'coef' is deprecated. Use 'group' instead.", DeprecationWarning, stacklevel=2)

    is_binary_one_hot = False
    if design is not None and design.ndim == 2 and design.shape[1] == n_coef:
        is_binary = np.all(np.isclose(design, 0.0) | np.isclose(design, 1.0))
        row_sums = np.sum(design, axis=1)
        one_hot_rows = np.all(np.isclose(row_sums, 1.0))
        nonempty_groups = np.all(np.sum(design, axis=0) > 0)
        is_binary_one_hot = bool(is_binary and one_hot_rows and nonempty_groups)

    if coef is None:
        if is_binary_one_hot and n_coef == 2:
            # Common limma design (~0 + group): default to group2 - group1.
            coef = 1
            reference = 0
        elif n_coef == 1:
            coef = 0
        else:
            coef = 0
            if design is not None and design.ndim == 2 and design.shape[1] == n_coef:
                intercept_cols = np.where(np.all(np.isclose(design, 1.0), axis=0))[0]
                candidates = [i for i in range(n_coef) if i not in set(intercept_cols)]
                if candidates:
                    coef = candidates[0]

    if coef < 0 or coef >= n_coef:
        raise ValueError(f"Invalid coefficient index {coef}. Valid range: 0 to {fit['coefficients'].shape[1] - 1}")

    # For two-group one-hot designs (no intercept), treat coef as group-vs-group
    # by default, matching expected DE behavior without an explicit contrasts step.
    if reference is None and is_binary_one_hot and n_coef == 2:
        reference = 1 - coef

    if reference is not None:
        if reference < 0 or reference >= n_coef:
            raise ValueError(
                f"Invalid reference index {reference}. Valid range: 0 to {fit['coefficients'].shape[1] - 1}"
            )
        if reference == coef:
            raise ValueError("reference must be different from coef")

    # Extract statistics for selected coefficient
    # n_genes = len(fit["genes"])
    if reference is None:
        logFC = fit["coefficients"][:, coef]
        t_stat = fit["t"][:, coef]
        p_val = fit["p_value"][:, coef]
        B_stat = fit["lods"][:, coef]
    else:
        cvec = np.zeros(n_coef, dtype=float)
        cvec[coef] = 1.0
        cvec[reference] = -1.0

        logFC = fit["coefficients"] @ cvec

        cov_coef = fit.get("cov_coefficients")
        if cov_coef is None:
            raise ValueError("Fit object missing 'cov_coefficients'.")
        c_unscaled = float(np.sqrt(cvec @ cov_coef @ cvec))

        se = c_unscaled * np.sqrt(fit["s2_post"])
        with np.errstate(divide="ignore", invalid="ignore"):
            t_stat = logFC / se
        p_val = 2 * stats.t.sf(np.abs(t_stat), fit["df_total"])

        var_prior = fit.get("var_prior")
        if var_prior is None:
            B_stat = np.full_like(logFC, np.nan, dtype=float)
        else:
            var_prior_contrast = float(np.sum((cvec**2) * np.asarray(var_prior)))
            with np.errstate(divide="ignore", invalid="ignore"):
                r = (c_unscaled**2 + var_prior_contrast) / (c_unscaled**2)
                t2 = t_stat**2
                df_prior = fit.get("df_prior", np.inf)
                if np.isfinite(df_prior) and df_prior <= 1e6:
                    kernel = (1.0 + fit["df_total"]) / 2.0 * np.log((t2 + fit["df_total"]) / (t2 / r + fit["df_total"]))
                else:
                    kernel = t2 * (1.0 - 1.0 / r) / 2.0
                proportion = fit.get("proportion", 0.01)
                B_stat = np.log(proportion / (1.0 - proportion)) - np.log(r) / 2.0 + kernel

    # Compute average expression across samples
    # adata.X is samples × genes, so mean over axis 0
    if adata is None:
        raise ValueError("AnnData object is required to compute AveExpr. Pass AnnData input to top_table.")
    ave_expr = np.mean(adata.X, axis=0)
    if ave_expr.ndim > 1:
        ave_expr = ave_expr.squeeze()

    # Apply multiple testing correction
    # Remove NaN p-values
    valid_pvals = ~np.isnan(p_val)
    adj_p_val = np.full_like(p_val, np.nan)

    if np.sum(valid_pvals) > 0:
        _, adj_p_val[valid_pvals], _, _ = multipletests(
            p_val[valid_pvals],
            method=adjust_method,
            is_sorted=False,
            returnsorted=False,
        )

    # Create results DataFrame
    results = pd.DataFrame(
        {
            "logfc": logFC,
            "avg_expr": ave_expr,
            "t": t_stat,
            "p_value": p_val,
            "p_adj": adj_p_val,
            "b": B_stat,
        },
        index=fit["genes"],
    )

    # Add gene annotations from adata.var if available
    if adata.var.shape[1] > 0:
        # Join with var DataFrame (excluding index which is already used)
        for col in adata.var.columns:
            if col not in results.columns:
                results[col] = adata.var[col].values

    # Apply filters
    mask = (results["p_adj"] <= p_value) & (np.abs(results["logfc"]) >= lfc)
    results = results[mask]

    # Sort results
    if sort_by == "logfc":
        results = results.iloc[np.argsort(-np.abs(results["logfc"].values))]
    elif sort_by == "avg_expr":
        results = results.sort_values("avg_expr", ascending=False)
    elif sort_by == "t":
        results = results.iloc[np.argsort(-np.abs(results["t"].values))]
    elif sort_by == "p_value":
        results = results.sort_values("p_value", ascending=True)
    elif sort_by == "b":
        results = results.sort_values("b", ascending=False)
    elif sort_by == "none":
        pass  # No sorting
    else:
        raise ValueError(f"Invalid sort_by: {sort_by}. Use 'logfc', 'avg_expr', 't', 'p_value', 'b', or 'none'.")

    # Limit to top N genes
    if number < len(results):
        results = results.iloc[:number]

    return results
