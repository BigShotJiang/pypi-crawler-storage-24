"""Empirical Bayes variance moderation for differential expression analysis.

This module implements empirical Bayes methods for moderating gene-wise variance
estimates by shrinking them towards a common value, improving statistical power
for detecting differential expression.
"""

import numpy as np
from anndata import AnnData
from scipy import stats

from ._fdist import fit_fdist


def squeeze_var(
    var: np.ndarray,
    df: np.ndarray,
    covariate=None,
    robust: bool = False,
) -> dict:
    """Squeeze sample variances towards a common value using empirical Bayes.

    Estimates hyperparameters (prior variance and prior degrees of freedom) from
    the distribution of sample variances, then computes shrunken posterior variances.
    This is the core variance moderation step in limma's empirical Bayes framework.

    Parameters
    ----------
    var : np.ndarray
        Sample variances (typically residual variances from linear model fit).
        Shape: (n_genes,)
    df : np.ndarray
        Degrees of freedom for each variance estimate.
        Shape: (n_genes,)
    covariate : np.ndarray, optional
        Covariate for intensity-dependent variance modeling.
        Not implemented in this version.
    robust : bool, default=False
        Use robust estimation resistant to outlier variances.
        Not implemented in this version.

    Returns:
    -------
    dict
        Dictionary containing:
        - var_post: np.ndarray, posterior (moderated) variances
        - var_prior: float, prior variance estimate (s2.prior)
        - df_prior: float, prior degrees of freedom
        - df_total: np.ndarray, total degrees of freedom (df + df.prior)

    Notes:
    -----
    **Algorithm:**

    1. Fit scaled F-distribution to sample variances to estimate hyperparameters:
       - s2.prior (prior variance)
       - df.prior (prior degrees of freedom)

    2. Compute posterior variances using Bayesian updating:

       var_post = (df * var + df.prior * s2.prior) / (df + df.prior)

    This is equivalent to assuming:
    - Prior: s2.prior * df.prior / chi-square(df.prior)
    - Likelihood: var * df / chi-square(df)
    - Posterior: convex combination weighted by degrees of freedom

    The moderated variances have increased degrees of freedom (df.total = df + df.prior),
    which improves stability of variance estimates, especially for small sample sizes.

    Examples:
    --------
    >>> import numpy as np
    >>> from microarray.tools._empirical_bayes import squeeze_var
    >>> # Simulate gene-wise variances
    >>> np.random.seed(42)
    >>> variances = np.random.gamma(shape=5, scale=0.2, size=1000)
    >>> df = np.full(1000, 8)  # 8 degrees of freedom per gene
    >>> # Squeeze variances
    >>> result = squeeze_var(variances, df)
    >>> print(f"Prior variance: {result['var_prior']:.3f}")
    >>> print(f"Prior df: {result['df_prior']:.2f}")
    >>> # Posterior variances are shrunk towards prior
    >>> import matplotlib.pyplot as plt
    >>> plt.scatter(variances, result["var_post"], alpha=0.5)
    >>> plt.xlabel("Sample variance")
    >>> plt.ylabel("Posterior variance")
    >>> plt.plot([0, 2], [0, 2], "r--", label="No shrinkage")
    >>> plt.legend()

    References:
    ----------
    Smyth, G. K. (2004). Linear models and empirical Bayes methods for assessing
    differential expression in microarray experiments. Statistical Applications
    in Genetics and Molecular Biology, 3(1).
    """
    # Fit F-distribution to estimate hyperparameters
    s2_prior, df_prior = fit_fdist(var, df, covariate=covariate, robust=robust)

    # Compute posterior variances
    # Bayesian updating: posterior = (df * var + df.prior * s2.prior) / df.total
    df_total = df + df_prior
    var_post = (df * var + df_prior * s2_prior) / df_total

    return {
        "var_post": var_post,
        "var_prior": s2_prior,
        "df_prior": df_prior,
        "df_total": df_total,
    }


def ebayes(
    data: AnnData | dict,
    proportion: float = 0.01,
    robust: bool = False,
    copy: bool = False,
    return_fit: bool = False,
) -> AnnData | dict | None:
    """Apply empirical Bayes moderation to linear model fit.

    Moderates gene-wise variance estimates by shrinking them towards a common
    value, then computes moderated t-statistics and p-values. This is the second
    step in limma-style differential expression analysis (after lm_fit).

    Parameters
    ----------
    data : AnnData | dict
        AnnData object with fit data stored in `.uns['lm_fit']` (preferred),
        or a fit dictionary from lm_fit() for backward compatibility.
        The fit object must contain:
        - coefficients: coefficient estimates
        - stdev_unscaled: unscaled standard errors
        - sigma: residual standard deviations
        - df_residual: residual degrees of freedom
        - cov_coefficients: coefficient covariance matrix
    proportion : float, default=0.01
        Assumed proportion of genes that are differentially expressed.
        Used for computing B-statistics (log-odds).
    robust : bool, default=False
        Use robust variance estimation.
        Not implemented in this version.

    copy : bool, default=False
        If `data` is AnnData, whether to work on a copy.
    return_fit : bool, default=False
        If True, return moderated fit dictionary. Otherwise, store results in
        `.uns['lm_fit']` and return AnnData if `copy=True`, else None.

    Returns:
    -------
    AnnData | dict | None
        Enhanced fit dictionary when `return_fit=True`, else AnnData/None.
        Additional fields include:
        - t: np.ndarray, moderated t-statistics (n_genes, n_coefficients)
        - p_value: np.ndarray, two-sided p-values (n_genes, n_coefficients)
        - lods: np.ndarray, B-statistics (log-odds of DE) (n_genes, n_coefficients)
        - s2_prior: float, prior variance estimate
        - df_prior: float, prior degrees of freedom
        - s2_post: np.ndarray, posterior variances (n_genes,)
        - df_total: np.ndarray, total degrees of freedom (n_genes,)
        - var_prior: np.ndarray, prior variance for each coefficient (n_coefficients,)

        All original fields from the input fit object are preserved.

    Notes:
    -----
    **Algorithm:**

    1. **Variance moderation** via squeeze_var():
       - Estimate prior variance (s2.prior) and prior df (df.prior)
       - Compute posterior variances: s2.post

    2. **Moderated t-statistics**:

       t = coefficients / (stdev.unscaled * sqrt(s2.post))

       where stdev.unscaled is from the linear model fit.

    3. **P-values**:
       Computed using t-distribution with df.total degrees of freedom:

       p.value = 2 * P(T > |t|) where T ~ t(df.total)

    4. **B-statistics** (log-odds of differential expression):
       Uses empirical Bayes mixture model to estimate:

       B = log-odds that gene is differentially expressed

       Computed using tmixture_matrix() which estimates the variance of
       true log-fold-changes and computes posterior probabilities.

    The moderated statistics have improved power compared to ordinary t-statistics,
    especially when the number of samples is small, because they borrow information
    across genes to stabilize variance estimates.

    Examples:
    --------
    >>> import microarray as ma
    >>> import numpy as np
    >>> # After fitting linear models
    >>> fit = ma.tl.lm_fit(adata, design)
    >>> # Apply empirical Bayes moderation
    >>> fit = ma.tl.ebayes(fit)
    >>> # Access moderated statistics
    >>> print("Moderated t-statistics shape:", fit["t"].shape)
    >>> print("P-values shape:", fit["p_value"].shape)
    >>> print(f"Prior df: {fit['df_prior']:.2f}")
    >>> print(f"Prior variance: {fit['s2_prior']:.4f}")
    >>> # Genes with smallest p-values for first coefficient
    >>> coef_idx = 0
    >>> top_genes = np.argsort(fit["p_value"][:, coef_idx])[:10]
    >>> print("Top 10 genes:", fit["genes"][top_genes])

    References:
    ----------
    Smyth, G. K. (2004). Linear models and empirical Bayes methods for assessing
    differential expression in microarray experiments. Statistical Applications
    in Genetics and Molecular Biology, 3(1).

    See Also:
    --------
    lm_fit : Fit linear models (required before ebayes)
    squeeze_var : Variance shrinkage function
    top_table : Extract and format top DE genes
    """
    if proportion <= 0 or proportion >= 1:
        raise ValueError("proportion must be strictly between 0 and 1")

    if isinstance(data, AnnData):
        adata = data.copy() if copy else data
        fit = adata.uns.get("lm_fit")
        if fit is None:
            raise ValueError("No fit object found in adata.uns['lm_fit']. Run lm_fit first.")
    else:
        adata = None
        fit = data

    # Extract components from fit
    coefficients = fit["coefficients"]
    stdev_unscaled = fit["stdev_unscaled"]
    sigma = fit["sigma"]
    df_residual = fit["df_residual"]

    if coefficients is None or stdev_unscaled is None or sigma is None or df_residual is None:
        raise ValueError("No data, or argument is not a valid lm_fit object")
    if np.all(df_residual == 0):
        raise ValueError("No residual degrees of freedom in linear model fits")
    if np.all(~np.isfinite(sigma)):
        raise ValueError("No finite residual standard deviations")

    n_genes, n_coef = coefficients.shape

    # Squeeze variances using empirical Bayes
    squeeze_result = squeeze_var(
        var=sigma**2,  # Convert sd to variance
        df=df_residual,
        robust=robust,
    )

    s2_post = squeeze_result["var_post"]
    s2_prior = squeeze_result["var_prior"]
    df_prior = squeeze_result["df_prior"]
    df_total = squeeze_result["df_total"]

    # Compute moderated t-statistics: t = coef / stdev.unscaled / sqrt(s2.post)
    with np.errstate(divide="ignore", invalid="ignore"):
        t_statistics = coefficients / stdev_unscaled / np.sqrt(s2_post[:, np.newaxis])

    # Limma bounds moderated df by pooled residual df
    df_total = np.minimum(df_total, np.nansum(df_residual))

    # Compute two-sided p-values using t-distribution
    # df_total is (n_genes,), need to broadcast for each coefficient
    p_values = 2 * stats.t.sf(np.abs(t_statistics), df_total[:, np.newaxis])

    # Limma-style B-statistics (log-odds of differential expression)
    var_prior_lim = (0.1**2 / np.median(s2_prior), 4.0**2 / np.median(s2_prior))
    var_prior = _tmixture_matrix(
        t_statistics=t_statistics,
        stdev_unscaled=stdev_unscaled,
        df_total=df_total,
        proportion=proportion,
        v0_lim=var_prior_lim,
    )
    if np.any(np.isnan(var_prior)):
        var_prior[np.isnan(var_prior)] = 1.0 / s2_prior

    with np.errstate(divide="ignore", invalid="ignore"):
        r = (stdev_unscaled**2 + var_prior[np.newaxis, :]) / stdev_unscaled**2
        t2 = t_statistics**2
        if df_prior > 1e6:
            kernel = t2 * (1.0 - 1.0 / r) / 2.0
        else:
            kernel = (
                (1.0 + df_total[:, np.newaxis])
                / 2.0
                * np.log((t2 + df_total[:, np.newaxis]) / (t2 / r + df_total[:, np.newaxis]))
            )
        lods = np.log(proportion / (1.0 - proportion)) - np.log(r) / 2.0 + kernel

    # Add results to fit object
    fit["t"] = t_statistics
    fit["p_value"] = p_values
    fit["lods"] = lods  # B-statistic
    fit["s2_prior"] = s2_prior
    fit["df_prior"] = df_prior
    fit["s2_post"] = s2_post
    fit["df_total"] = df_total
    fit["var_prior"] = var_prior
    fit["proportion"] = proportion
    fit["_moderated"] = True

    if adata is not None:
        adata.uns["lm_fit"] = fit
        if return_fit:
            return fit
        return adata if copy else None

    return fit


def _tmixture_matrix(
    t_statistics: np.ndarray,
    df_total: np.ndarray,
    stdev_unscaled: np.ndarray,
    proportion: float,
    v0_lim: tuple[float, float] | None = None,
) -> np.ndarray:
    """Estimate prior variances for each coefficient using limma's t-mixture model."""
    t_statistics = np.asarray(t_statistics)
    stdev_unscaled = np.asarray(stdev_unscaled)

    if t_statistics.shape != stdev_unscaled.shape:
        raise ValueError("Dimensions of t_statistics and stdev_unscaled must match")

    n_coef = t_statistics.shape[1]
    v0 = np.zeros(n_coef, dtype=float)
    for j in range(n_coef):
        v0[j] = _tmixture_vector(
            t_statistics[:, j],
            stdev_unscaled[:, j],
            df_total,
            proportion,
            v0_lim,
        )
    return v0


def _tmixture_vector(
    tstat: np.ndarray,
    stdev_unscaled: np.ndarray,
    df: np.ndarray,
    proportion: float,
    v0_lim: tuple[float, float] | None = None,
) -> float:
    """Estimate scale factor in a mixture of two t-distributions (limma-compatible)."""
    tstat = np.asarray(tstat, dtype=float)
    stdev_unscaled = np.asarray(stdev_unscaled, dtype=float)
    df = np.asarray(df, dtype=float)

    ok = np.isfinite(tstat) & np.isfinite(stdev_unscaled) & np.isfinite(df)
    if not np.any(ok):
        return np.nan

    tstat = np.abs(tstat[ok])
    stdev_unscaled = stdev_unscaled[ok]
    df = df[ok]

    ngenes = tstat.size
    ntarget = int(np.ceil(proportion / 2.0 * ngenes))
    if ntarget < 1:
        return np.nan

    p = max(ntarget / ngenes, proportion)

    max_df = np.max(df)
    low_df = df < max_df
    if np.any(low_df):
        tail_p = stats.t.logsf(tstat[low_df], df=df[low_df])
        tstat[low_df] = stats.t.isf(np.exp(tail_p), df=max_df)

    o = np.argsort(tstat)[::-1][:ntarget]
    tstat = tstat[o]
    v1 = stdev_unscaled[o] ** 2

    r = np.arange(1, ntarget + 1)
    p0 = 2.0 * stats.t.sf(tstat, df=max_df)
    ptarget = (((r - 0.5) / ngenes) - (1.0 - p) * p0) / p

    v0 = np.zeros(ntarget, dtype=float)
    pos = ptarget > p0
    if np.any(pos):
        qtarget = stats.t.isf(ptarget[pos] / 2.0, df=max_df)
        with np.errstate(divide="ignore", invalid="ignore"):
            v0[pos] = v1[pos] * ((tstat[pos] / qtarget) ** 2 - 1.0)

    if v0_lim is not None:
        v0 = np.clip(v0, v0_lim[0], v0_lim[1])

    return float(np.nanmean(v0))
