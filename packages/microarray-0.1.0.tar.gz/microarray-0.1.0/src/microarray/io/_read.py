"""High-level readers for raw CEL data."""

from __future__ import annotations

import os
from glob import glob
from typing import Literal

from anndata import AnnData, concat
from tqdm import tqdm

from microarray.io._anndata_converter import cel_to_anndata
from microarray.io._cdf import CdfFile

DEFAULT_CEL_PATTERNS = ["*.cel", "*.cel.gz"]


def _collect_cel_paths(folder: str, patterns: str | list[str] | None = None) -> list[str]:
    """Collect CEL file paths from a folder using common CEL filename patterns.

    Parameters
    ----------
    folder : str
        Path to the folder containing CEL files.
    patterns : str or list of str, optional
        Filename patterns to match CEL files. Defaults to common CEL patterns.

    Returns:
    -------
    list of str
        List of paths to the CEL files found in the folder.

    Raises:
    ------
    ValueError
        If the specified folder does not exist or if no CEL files are found.
    """
    if not os.path.isdir(folder):
        raise ValueError(f"Not a directory: {folder}")

    if patterns is None:
        patterns = DEFAULT_CEL_PATTERNS

    cel_paths = []
    if isinstance(patterns, str):
        patterns = [patterns]
    for pattern in patterns:
        cel_paths.extend(glob(os.path.join(folder, pattern)))

    if len(cel_paths) == 0:
        raise ValueError(f"No CEL files found in folder: {folder}")

    return cel_paths


def read_cel(cel_file: str, cdf_file: str | CdfFile) -> AnnData:
    """Read a CEL file and return an unprocessed AnnData object.

    The resulting object is probe-grid based (one sample, all array positions)
    and does not require CDF annotation.

    Parameters
    ----------
    cel_file : str
        Path to the CEL file.
    cdf_file : str or CdfFile
        Path to the CDF file or a parsed CdfFile instance for metadata.

    Returns:
    --------
    AnnData
        Unprocessed probe-grid AnnData with shape (1, n_cells).
    """
    sample_name = os.path.splitext(os.path.split(cel_file)[-1])[0]
    return cel_to_anndata(cel_file, cdf_file, sample_name=sample_name)


def read_cel_batch(
    cel_folder: str,
    cdf_file: str | CdfFile,
    patterns: str | list[str] | None = None,
    axis: Literal[0, 1] = 0,
    join: Literal["inner", "outer"] = "outer",
    merge: Literal["same", "unique"] | None = "same",
    verbose: bool = True,
) -> AnnData:
    """Read all CEL files from a folder and stack them into one AnnData object.

    Parameters
    ----------
    cel_folder : str
        Path to the folder containing CEL files.
    cdf_file : str or CdfFile
        Path to the CDF file or a parsed CdfFile instance for metadata.
    patterns : str or list of str, optional
        Filename patterns to match CEL files. Defaults to common CEL patterns.
    join : {"inner", "outer"}, optional
        How to join variables when concatenating. Defaults to "outer".
    merge : {"same", "unique"}, optional
        How to merge observations when concatenating. Defaults to "same".


    Returns:
    -------
    AnnData
        Stacked AnnData object with shape (n_samples, n_cells).
    """
    cel_paths = _collect_cel_paths(cel_folder, patterns)

    batch: list[AnnData] = []

    for path in tqdm(cel_paths, desc="Reading CEL files", disable=not verbose):
        if not os.path.isfile(path):
            raise ValueError(f"File not found: {path}")
        batch.append(read_cel(path, cdf_file))

    n_features = batch[0].n_vars
    for adata in batch[1:]:
        if adata.n_vars != n_features:
            raise ValueError("CEL files in folder have inconsistent chip dimensions and cannot be stacked.")

    return concat(
        batch,
        axis=axis,
        merge=merge,
        join=join,
    )
