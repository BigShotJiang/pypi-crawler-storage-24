"""AnnData converter for microarray CEL/CDF data."""

import os
from collections import defaultdict

import numpy as np
import pandas as pd
from anndata import AnnData

from microarray.io._cdf import CdfFile, parse_cdf
from microarray.io._cel import CelFile, parse_cel


def cel_to_anndata(
    cel_path: str | CelFile,
    cdf_path: str | CdfFile,
    sample_name: str | None = None,
) -> AnnData:
    """Convert a single CEL file to a probe-level AnnData object.

    Creates an AnnData with shape (1, n_cells) where each variable represents
    an individual CDF cell (probe):

    - ``.X`` contains per-cell intensities.
    - ``.var`` contains ``probeset_id``, ``probe_index`` (0-based rank within
      probeset by ascending ``expos``, so 0 = 3' end), ``probe_type``
      (``"pm"``, ``"mm"``, or ``"unknown"``), ``gene_id`` (gene identifier
      extracted from probeset name), and ``suffix`` (Affymetrix probe type
      suffix such as ``"_at"`` for antisense target).
    - ``.obs`` contains sample metadata from the CEL header.
    - ``.layers`` contains per-cell QC arrays: ``stdevs``, ``npixels``,
      ``masks``, ``outliers``, ``modified``.
    - ``.uns`` contains CDF chip info and CEL file metadata.


    Parameters
    ----------
    cel_path : str | CelFile
        Path to the CEL file or a parsed :class:`~microarray.io.CelFile`
        instance.
    cdf_path : str | CdfFile
        Path to the CDF file or a parsed :class:`~microarray.io.CdfFile`
        instance.
    sample_name : str | None
        Name used as the observation index.  Defaults to the CEL file's
        basename, or ``"unknown"`` when a :class:`~microarray.io.CelFile`
        instance is supplied without a path.

    Returns:
    -------
    AnnData
        Probe-level AnnData with shape ``(1, n_cells)``.
    """
    # Parse input files if they are paths
    if isinstance(cel_path, str):
        cel_file_path = cel_path
        cel_file = parse_cel(cel_path)
    else:
        cel_file_path = None
        cel_file = cel_path

    if isinstance(cdf_path, str):
        cdf_file = parse_cdf(cdf_path)
    else:
        cdf_file = cdf_path

    if sample_name is None:
        sample_name = os.path.basename(cel_file_path) if cel_file_path else "unknown"

    obs = pd.DataFrame(
        {
            "sample_name": [sample_name],
            "cel_version": [cel_file.version],
            "nrows": [cel_file.nrows],
            "ncols": [cel_file.ncols],
            "algorithm": [cel_file.algorithm],
        },
        index=[sample_name],
    )

    uns = {
        "cel_metadata": {
            "total_x": cel_file.total_x,
            "total_y": cel_file.total_y,
            "offset_x": cel_file.offset_x,
            "offset_y": cel_file.offset_y,
            "grid_corner_ul": cel_file.grid_corner_ul,
            "grid_corner_ur": cel_file.grid_corner_ur,
            "grid_corner_ll": cel_file.grid_corner_ll,
            "grid_corner_lr": cel_file.grid_corner_lr,
            "axis_invert_x": cel_file.axis_invert_x,
            "axis_invert_y": cel_file.axis_invert_y,
            "swap_xy": cel_file.swap_xy,
            "algorithm_parameters": cel_file.algorithm_parameters,
            "dat_header": cel_file.dat_header,
        },
        "cdf_metadata": {
            "chip_name": cdf_file.chip_info.name,
            "chip_rows": cdf_file.chip_info.rows,
            "chip_cols": cdf_file.chip_info.cols,
            "number_of_units": cdf_file.chip_info.number_of_units,
            "max_unit": cdf_file.chip_info.max_unit,
            "num_qc_units": cdf_file.chip_info.num_qc_units,
        },
    }

    # Collect cells per probeset to compute ordinal ranks.
    # Structure: {probeset_id: [(expos, x, y, is_pm), ...]}
    ps_cells: dict[str, list[tuple]] = defaultdict(list)

    for unit in cdf_file.units:
        for block in unit.blocks:
            probeset_id = block.name if block.name and block.name != "NONE" else unit.name
            for cell in block.cells:
                expos_val = cell.expos if cell.expos is not None else 0
                ps_cells[probeset_id].append((expos_val, cell.x, cell.y, cell.is_pm))

    # Sort by expos within each probeset and assign ordinal rank.
    # Smallest expos = 3' end = rank 0.
    probeset_ids: list[str] = []
    probe_indices: list[int] = []
    probe_types: list[str] = []
    probe_var_ids: list[str] = []
    intensities_list: list[float] = []
    stdevs_list: list[float] = []
    npixels_list: list[float] = []
    masks_list: list[float] = []
    outliers_list: list[float] = []
    modified_list: list[float] = []

    for probeset_id, cells in ps_cells.items():
        cells_sorted = sorted(cells, key=lambda c: c[0])
        for ordinal_rank, (_, cx, cy, cell_is_pm) in enumerate(cells_sorted):
            intensity = float(cel_file.intensities[cy, cx]) if cel_file.intensities is not None else float("nan")
            stdev = float(cel_file.stdevs[cy, cx]) if cel_file.stdevs is not None else float("nan")
            npixels = float(cel_file.npixels[cy, cx]) if cel_file.npixels is not None else float("nan")
            masks = float(cel_file.masks[cy, cx]) if cel_file.masks is not None else float("nan")
            outliers = float(cel_file.outliers[cy, cx]) if cel_file.outliers is not None else float("nan")
            modified = float(cel_file.modified[cy, cx]) if cel_file.modified is not None else float("nan")

            if cell_is_pm is True:
                probe_type = "pm"
            elif cell_is_pm is False:
                probe_type = "mm"
            else:
                probe_type = "unknown"

            var_id = f"{probeset_id}:{cx}:{cy}"
            probeset_ids.append(probeset_id)
            probe_indices.append(ordinal_rank)
            probe_types.append(probe_type)
            probe_var_ids.append(var_id)
            intensities_list.append(intensity)
            stdevs_list.append(stdev)
            npixels_list.append(npixels)
            masks_list.append(masks)
            outliers_list.append(outliers)
            modified_list.append(modified)

    n_cells = len(probeset_ids)
    X = np.array(intensities_list, dtype=np.float32).reshape(1, n_cells)

    var = pd.DataFrame(
        {
            "probeset_id": probeset_ids,
            "probe_index": probe_indices,
            "probe_type": probe_types,
        },
        index=probe_var_ids,
    )

    # Merge probeset_info (gene_id and suffix) into var
    if cdf_file.probeset_info is not None:
        # Map probeset_id to gene_id and suffix by looking up in probeset_info
        gene_ids = []
        suffixes = []
        for ps_id in probeset_ids:
            if ps_id in cdf_file.probeset_info.index:
                info = cdf_file.probeset_info.loc[ps_id]
                gene_ids.append(info["gene_id"])
                suffixes.append(info["suffix"])
            else:
                # Fallback if probeset not in probeset_info
                gene_ids.append(ps_id)
                suffixes.append("")

        var["gene_id"] = gene_ids
        var["suffix"] = suffixes

    layers = {
        "stdevs": np.array(stdevs_list, dtype=np.float32).reshape(1, n_cells),
        "npixels": np.array(npixels_list, dtype=np.float32).reshape(1, n_cells),
        "masks": np.array(masks_list, dtype=np.float32).reshape(1, n_cells),
        "outliers": np.array(outliers_list, dtype=np.float32).reshape(1, n_cells),
        "modified": np.array(modified_list, dtype=np.float32).reshape(1, n_cells),
    }

    return AnnData(X=X, obs=obs, var=var, layers=layers, uns=uns)
