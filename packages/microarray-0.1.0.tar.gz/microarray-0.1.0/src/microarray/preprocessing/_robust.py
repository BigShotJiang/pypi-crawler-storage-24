"""Robust statistical methods for microarray preprocessing.

This module provides robust statistical methods used in expression estimation,
particularly in the MAS5 algorithm.
"""

import numpy as np
from numpy.typing import NDArray


def tukey_biweight(
    x: NDArray[np.floating],
    c: float = 5.0,
    epsilon: float = 0.0001,
    max_iter: int = 50,
    tol: float = 1e-7,
) -> float:
    """Compute Tukey's biweight (bisquare) robust mean.

    This function calculates a robust estimate of the mean using Tukey's biweight
    algorithm. It downweights outliers based on their distance from the median,
    providing more robust estimates than the arithmetic mean.

    The algorithm computes weights based on standardized residuals:
    - w_i = (1 - u_i^2)^2 for |u_i| <= 1
    - w_i = 0 for |u_i| > 1

    where u_i = (x_i - m) / (c * s + epsilon), m is the median, and s is the
    median absolute deviation (MAD).

    Parameters
    ----------
    x : NDArray[np.floating]
        Input array of values, 1-dimensional.
    c : float, default=5.0
        Tuning constant that controls the downweighting of outliers.
        Larger values assign more weight to outliers. Common values:
        - c=5: standard for expression summarization (MAS5)
        - c=6: more permissive
        - c=4.685: asymptotically 95% efficiency for normal data
    epsilon : float, default=0.0001
        Small constant added to prevent division by zero when MAD is very small.
    max_iter : int, default=50
        Maximum number of iterations for refinement (currently single-pass).
    tol : float, default=1e-7
        Convergence tolerance (currently unused, reserved for iterative version).

    Returns:
    -------
    float
        The Tukey biweight estimate of the mean.

    Notes:
    -----
    This implementation follows the Affymetrix MAS5 algorithm as implemented in
    the affy R package (tukey.biweight.R). The single-pass version is used,
    which computes weights based on deviations from the median.

    For data with no variability (all values identical), the function returns
    the common value.

    References:
    ----------
    .. [1] Mosteller, F., and Tukey, J. W. (1977), Data Analysis and Regression:
           A Second Course in Statistics. Addison-Wesley.
    .. [2] Affymetrix (2002). Statistical Algorithms Description Document.

    Examples:
    --------
    >>> import numpy as np
    >>> from microarray.preprocessing import tukey_biweight
    >>> x = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 100.0])  # one outlier
    >>> tukey_biweight(x)
    2.9998...
    >>> np.mean(x)  # regular mean is heavily influenced
    19.166...
    """
    x = np.asarray(x, dtype=np.float64)

    if x.ndim != 1:
        raise ValueError(f"Input must be 1-dimensional, got shape {x.shape}")

    if len(x) == 0:
        raise ValueError("Input array is empty")

    # Compute median and median absolute deviation
    m = np.median(x)
    s = np.median(np.abs(x - m))

    # Handle case where all values are identical (s = 0)
    if s < epsilon:
        return float(m)

    # Compute standardized residuals
    u = (x - m) / (c * s + epsilon)

    # Compute weights: w = (1 - u^2)^2 for |u| <= 1, else 0
    w = np.zeros_like(u)
    mask = np.abs(u) <= 1
    w[mask] = (1 - u[mask] ** 2) ** 2

    # Compute weighted mean
    if np.sum(w) == 0:
        # All points are outliers, fall back to median
        return float(m)

    t_bi = np.sum(w * x) / np.sum(w)
    return float(t_bi)


def tukey_biweight_summary(
    x: NDArray[np.floating],
    c: float = 5.0,
    epsilon: float = 0.0001,
) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
    """Apply Tukey biweight to summarize across probes for each sample.

    This function is designed for probeset summarization, where each column
    represents a sample and each row represents a probe. It applies the
    Tukey biweight algorithm to each column independently.

    Parameters
    ----------
    x : NDArray[np.floating]
        Input array of shape (n_probes, n_samples).
    c : float, default=5.0
        Tuning constant for Tukey biweight.
    epsilon : float, default=0.0001
        Small constant to prevent division by zero.

    Returns:
    -------
    exprs : NDArray[np.floating]
        Array of shape (n_samples,) containing the biweight estimates.
    se_exprs : NDArray[np.floating]
        Array of shape (n_samples,) containing NaN values (standard errors
        not computed in this implementation, following affy R package).

    Notes:
    -----
    This function matches the behavior of tukeybiweight() in the affy R package,
    which returns NA for standard errors.

    Examples:
    --------
    >>> import numpy as np
    >>> from microarray.preprocessing import tukey_biweight_summary
    >>> # 5 probes, 3 samples
    >>> x = np.array(
    ...     [[1.0, 10.0, 100.0], [2.0, 11.0, 101.0], [3.0, 12.0, 102.0], [4.0, 13.0, 103.0], [5.0, 14.0, 104.0]]
    ... )
    >>> exprs, se = tukey_biweight_summary(x)
    >>> exprs.shape
    (3,)
    """
    x = np.asarray(x, dtype=np.float64)

    if x.ndim != 2:
        raise ValueError(f"Input must be 2-dimensional, got shape {x.shape}")

    n_samples = x.shape[1]
    exprs = np.empty(n_samples, dtype=np.float64)

    for i in range(n_samples):
        exprs[i] = tukey_biweight(x[:, i], c=c, epsilon=epsilon)

    # Standard errors not computed (following affy R package behavior)
    se_exprs = np.full(n_samples, np.nan, dtype=np.float64)

    return exprs, se_exprs
