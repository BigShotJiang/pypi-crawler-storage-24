"""RMA (Robust Multi-array Average) normalization pipeline."""

import warnings

import numpy as np
from anndata import AnnData

from microarray.preprocessing._background import rma_background_correct
from microarray.preprocessing._log2 import _is_log_transformed, log2
from microarray.preprocessing._normalize import normalize_quantile
from microarray.preprocessing._summarize import summarize_probesets


def rma(
    adata: AnnData,
    background_correct: bool = True,
    normalize: bool = True,
    log_transform: bool = True,
    summarize: bool = True,
    output_level: str = "gene",
    copy: bool = True,
) -> AnnData | None:
    """Apply RMA (Robust Multi-array Average) normalization to microarray data.

    RMA is a widely-used preprocessing method for Affymetrix microarrays that
    combines background correction, quantile normalization, log transformation,
    and robust summarization.

    The standard RMA pipeline consists of:
    1. Background correction using a convolution model
    2. Quantile normalization across samples
    3. Log2 transformation
    4. Probeset summarization using median polish

    Parameters
    ----------
    adata
        AnnData object with shape (n_samples, n_probes).
        Should contain raw intensity values from multiple CEL files.
        Use `microarray.io.cel_batch_to_anndata()` to load data.
    background_correct
        If True, apply RMA background correction.
    normalize
        If True, apply quantile normalization across samples.
        Requires n_samples > 1; skipped with warning for single sample.
    log_transform
        If True, apply log2 transformation to intensities.
    summarize
        If True, apply median polish summarization to probesets.
        Requires 'gene_id' column in `.var`.
    output_level
        Output granularity when summarize=True:
        - 'gene': Return gene-level data (n_samples, n_genes)
        - 'probe': Keep probe-level data with effects in `.layers`
        Ignored if summarize=False.
    copy
        If True, return a new AnnData object. If False, may modify in place
        (except when output_level='gene', which always returns new object).

    Returns:
    -------
    AnnData or None
        Processed AnnData object if `copy=True`.
        If `copy=False` and `output_level='probe'`, modifies in place and returns None.
        Full RMA parameters and history are stored in `.uns['rma']`.

    Raises:
    ------
    ValueError
        If input validation fails (e.g., empty data, incompatible parameters).

    Examples:
    --------
    >>> # Standard RMA with gene-level output
    >>> import microarray as ma
    >>> adata = ma.io.cel_batch_to_anndata(
    ...     cel_paths=["sample1.CEL", "sample2.CEL"], cdf_path="chip.cdf", annotation_db_path="annotations.db"
    ... )
    >>> adata_rma = ma.pp.rma(adata)
    >>> print(adata_rma.shape)  # (2, n_genes)

    >>> # Partial RMA: only background correction and normalization
    >>> adata_norm = ma.pp.rma(adata, background_correct=True, normalize=True, log_transform=True, summarize=False)
    >>> print(adata_norm.shape)  # (2, n_probes) - still probe-level

    >>> # RMA with probe-level output
    >>> adata_probes = ma.pp.rma(adata, output_level="probe")

    Notes:
    -----
    RMA was developed for Affymetrix oligonucleotide arrays and is one of
    the most widely-used preprocessing methods due to its robustness and
    performance in reducing technical variation.

    The method assumes:
    - Multiple samples are being processed together (for normalization)
    - Data are from PM (perfect match) probes
    - Probes are grouped into probesets representing genes/transcripts

    References:
    ----------
    .. [1] Irizarry, R.A., Hobbs, B., Collin, F., et al. (2003).
           Exploration, normalization, and summaries of high density
           oligonucleotide array probe level data.
           Biostatistics, 4(2), 249-264.

    .. [2] Bolstad, B.M., Irizarry, R.A., Astrand, M., Speed, T.P. (2003).
           A comparison of normalization methods for high density
           oligonucleotide array data based on variance and bias.
           Bioinformatics, 19(2), 185-193.
    """
    # Validate input
    _validate_rma_input(adata, summarize)

    # Check if already processed
    if _is_likely_processed(adata):
        warnings.warn(
            "Input data appears to already be processed (values in log scale or "
            "normalized). Applying RMA to already-processed data may give "
            "incorrect results.",
            UserWarning,
            stacklevel=2,
        )

    # Initialize result
    adata_result = adata.copy() if copy else adata

    # Track which steps were applied
    steps_applied = []

    # Step 1: Background correction
    if background_correct:
        rma_background_correct(adata_result, copy=False)
        steps_applied.append("background_correction")

    # Step 2: Quantile normalization
    if normalize:
        if adata_result.n_obs == 1:
            warnings.warn(
                "Skipping quantile normalization: only 1 sample provided. Normalization requires multiple samples.",
                UserWarning,
                stacklevel=2,
            )
        else:
            normalize_quantile(adata_result, copy=False)
            steps_applied.append("quantile_normalization")

    # Step 3: Log transformation
    if log_transform:
        # Check if already log-transformed
        if not _is_log_transformed(adata_result):
            log2(adata_result, copy=False)
            steps_applied.append("log2_transform")
        else:
            warnings.warn(
                "Data appears to already be log-transformed. Skipping log transformation.",
                UserWarning,
                stacklevel=2,
            )

    # Step 4: Probeset summarization
    if summarize:
        if "gene_id" not in adata_result.var.columns:
            warnings.warn(
                "Cannot summarize probesets: 'gene_id' column missing from .var. "
                "Load data with annotation_db_path to enable summarization. "
                "Skipping summarization step.",
                UserWarning,
                stacklevel=2,
            )
        else:
            # Note: summarize_probesets returns new AnnData for gene-level output
            result_or_none = summarize_probesets(
                adata_result,
                method="medpolish",
                output_level=output_level,
                copy=False if output_level == "probe" else True,
            )
            # If gene-level, we get a new object; if probe-level with copy=False, we get None
            if result_or_none is not None:
                adata_result = result_or_none
            steps_applied.append("median_polish_summarization")

    # Store RMA parameters and history
    adata_result.uns["rma"] = {
        "background_correct": background_correct,
        "normalize": normalize,
        "log_transform": log_transform,
        "summarize": summarize,
        "output_level": output_level if summarize else "probe",
        "steps_applied": steps_applied,
        "n_samples": adata.n_obs,
        "n_probes_input": adata.n_vars,
        "n_features_output": adata_result.n_vars,
    }

    return adata_result if copy else None


def _validate_rma_input(adata: AnnData, summarize: bool) -> None:
    """Validate input AnnData for RMA processing."""
    if adata is None:
        raise ValueError("adata cannot be None")

    if adata.X is None:
        raise ValueError("AnnData.X must contain intensity values")

    if adata.n_obs < 1:
        raise ValueError("AnnData must contain at least one sample")

    if adata.n_vars < 1:
        raise ValueError("AnnData must contain at least one probe")

    # Check for negative values (indicates already processed data)
    if np.any(adata.X < 0):
        warnings.warn(
            "Input data contains negative values. RMA expects raw positive intensities.",
            UserWarning,
            stacklevel=2,
        )

    # Check for NaN or inf values
    if np.any(~np.isfinite(adata.X)):
        raise ValueError("Input data contains NaN or infinite values. RMA requires finite intensity values.")


def _is_likely_processed(adata: AnnData) -> bool:
    """Check if data appears to already be processed.

    Checks for signs of normalization or log transformation.
    """
    # Check for log transformation
    if _is_log_transformed(adata):
        return True

    # Check if normalization metadata exists
    if "normalization" in adata.uns:
        return True

    if "rma" in adata.uns:
        return True

    return False
