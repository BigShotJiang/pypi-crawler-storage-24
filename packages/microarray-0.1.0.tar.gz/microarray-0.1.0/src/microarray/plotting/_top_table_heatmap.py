from __future__ import annotations

import inspect
from typing import Any

from anndata import AnnData
from matplotlib.axes import Axes
from matplotlib.figure import Figure

from microarray.plotting._heatmap import heatmap
from microarray.tools._toptable import top_table

_TOP_TABLE_KWARGS = set(inspect.signature(top_table).parameters.keys()) - {"data", "group", "number"}
_HEATMAP_KWARGS = set(inspect.signature(heatmap).parameters.keys()) - {"adata", "genes", "groupby", "title", "show"}


def top_table_heatmap(
    adata: AnnData,
    n_top: int = 10,
    groupby: str | None = None,
    title: str | None = None,
    show: bool = True,
    **kwargs: Any,
) -> tuple[Figure, dict[str, Axes | None]]:
    """Plot top marker genes per condition in a clustered heatmap.

    This helper uses :func:`microarray.tools.top_table` to collect top marker
    genes for each condition and then visualizes the combined gene set using
    :func:`microarray.plotting.heatmap`.

    Args:
        adata: AnnData object containing a moderated fit in ``adata.uns['lm_fit']``.
        n_top: Number of top genes to extract per condition.
        groupby: Grouping column in ``adata.obs``. If omitted, uses
            ``adata.uns['lm_fit']['groupby']``.
        title: Optional heatmap title. Uses a default title when omitted.
        show: Whether to show the matplotlib figure.
        **kwargs: Additional keyword arguments forwarded to
            :func:`microarray.tools.top_table` and/or
            :func:`microarray.plotting.heatmap`, depending on supported
            parameter names.

    Returns:
        A tuple ``(figure, axes_dict)`` as returned by :func:`heatmap`.
    """
    if n_top <= 0:
        raise ValueError("n_top must be a positive integer")

    fit = adata.uns.get("lm_fit")
    if fit is None:
        raise ValueError("No fit object found in adata.uns['lm_fit']. Run lm_fit and ebayes first.")

    if groupby is None:
        groupby = fit.get("groupby")
    if not groupby:
        raise ValueError("groupby must be provided or available in adata.uns['lm_fit']['groupby']")
    if groupby not in adata.obs:
        raise ValueError(f"Column '{groupby}' not found in adata.obs")

    group_to_column = fit.get("group_to_column")
    if isinstance(group_to_column, dict) and len(group_to_column) > 0:
        groups = list(group_to_column.keys())
    else:
        groups = list(dict.fromkeys(adata.obs[groupby].astype(str).tolist()))

    top_kwargs: dict[str, Any] = {}
    heatmap_kwargs: dict[str, Any] = {}
    unknown_keys: list[str] = []

    for key, value in kwargs.items():
        matched = False
        if key in _TOP_TABLE_KWARGS:
            top_kwargs[key] = value
            matched = True
        if key in _HEATMAP_KWARGS:
            heatmap_kwargs[key] = value
            matched = True
        if not matched:
            unknown_keys.append(key)

    if unknown_keys:
        unknown_str = ", ".join(sorted(unknown_keys))
        raise TypeError(f"Unknown keyword argument(s): {unknown_str}")

    marker_genes: list[str] = []
    seen: set[str] = set()
    for group in groups:
        results = top_table(adata, group=str(group), number=n_top, **top_kwargs)
        for gene in results.index.astype(str):
            if gene not in seen:
                marker_genes.append(gene)
                seen.add(gene)

    if len(marker_genes) == 0:
        raise ValueError("No marker genes found. Adjust filtering parameters for top_table.")

    heatmap_title = title if title is not None else f"Top {n_top} marker genes per {groupby}"
    return heatmap(adata, genes=marker_genes, groupby=groupby, title=heatmap_title, show=show, **heatmap_kwargs)
