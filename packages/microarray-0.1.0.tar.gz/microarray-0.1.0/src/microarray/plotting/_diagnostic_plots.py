"""Diagnostic plot functions for microarray data analysis."""

from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from anndata import AnnData
from matplotlib.axes import Axes

from microarray.plotting._utils import get_default_colors


def mds(
    adata: AnnData,
    obsm_key: str = "X_mds",
    top: int = 500,
    gene_selection: str = "common",
    dimensions: int = 2,
    labels: list[str] | None = None,
    colors: list[str] | str | None = None,
    groups: np.ndarray | list | None = None,
    xlab: str | None = None,
    ylab: str | None = None,
    title: str = "MDS Plot",
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Plot Multidimensional Scaling (MDS) embedding.

    Visualizes the MDS embedding stored in `.obsm` to show sample relationships
    in 2D space. Samples that are similar (highly correlated) appear close together,
    while dissimilar samples are far apart. Essential for quality control and
    identifying batch effects or outliers.

    Note:
        If MDS embedding is not found in `.obsm[obsm_key]`, it will be computed
        automatically using `microarray.tl.mds()` with the provided parameters.

    Args:
        adata: AnnData object with MDS embedding in .obsm or expression data in .X
        obsm_key: Key in .obsm where the MDS embedding is stored. Default "X_mds".
        top: Number of top varying probes to use if computing MDS. Default 500.
        gene_selection: Method for selecting genes if computing MDS. Default "common".
        dimensions: Number of dimensions to plot (must be 2). Default 2.
        labels: Custom labels for each sample. If None, uses obs_names.
        colors: Color(s) for points. Can be single color or list of colors per sample.
        groups: Group assignments for color coding. If provided with colors as dict,
            maps groups to colors.
        xlab: X-axis label. If None, uses "Dimension 1".
        ylab: Y-axis label. If None, uses "Dimension 2".
        title: Plot title
        ax: Existing Axes object. If None, creates new figure.
        **kwargs: Additional arguments passed to ax.scatter()

    Returns:
        Axes object with MDS plot

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> import microarray as ma
        >>> data = np.random.randn(1000, 6)
        >>> adata = ad.AnnData(data.T)
        >>> # Compute MDS first
        >>> ma.tl.mds(adata, top=500)
        >>> # Then plot it
        >>> ax = ma.pl.mds(adata)
        >>> # Or let the plot function compute it automatically
        >>> ax = ma.pl.mds(adata, top=500)
        >>> # With group coloring
        >>> groups = ["control", "control", "control", "treated", "treated", "treated"]
        >>> ax = ma.pl.mds(adata, groups=groups)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 7))

    if dimensions != 2:
        raise NotImplementedError("Only 2D MDS plots are currently supported")

    # Check if MDS embedding exists, if not compute it
    if obsm_key not in adata.obsm:
        # Import here to avoid circular dependency
        from microarray.tools import mds as compute_mds

        compute_mds(adata, top=top, gene_selection=gene_selection, n_components=dimensions, obsm_key=obsm_key)

    # Get MDS coordinates from obsm
    coords = adata.obsm[obsm_key]
    n_samples = coords.shape[0]

    # Prepare labels
    if labels is None:
        labels = list(adata.obs_names) if adata.obs_names is not None else [f"Sample {i}" for i in range(n_samples)]

    # Prepare colors
    if groups is not None:
        unique_groups = np.unique(groups)
        n_groups = len(unique_groups)

        # If colors is a dict, map groups to colors
        if isinstance(colors, dict):
            color_map = colors
        else:
            # Generate default colors for groups
            default_colors = get_default_colors(n_groups)
            color_map = dict(zip(unique_groups, default_colors, strict=False))

        # Plot by group for legend
        for group in unique_groups:
            mask = np.array(groups) == group
            ax.scatter(
                coords[mask, 0],
                coords[mask, 1],
                c=color_map[group],
                label=str(group),
                s=100,
                alpha=0.7,
                edgecolors="black",
                linewidth=0.5,
                **kwargs,
            )
        ax.legend(loc="best", frameon=True)
    else:
        # Single color or list of colors without grouping
        if colors is None:
            colors = get_default_colors(1)[0]

        if isinstance(colors, str):
            # Single color for all points
            ax.scatter(
                coords[:, 0], coords[:, 1], c=colors, s=100, alpha=0.7, edgecolors="black", linewidth=0.5, **kwargs
            )
        else:
            # List of colors
            ax.scatter(
                coords[:, 0], coords[:, 1], c=colors, s=100, alpha=0.7, edgecolors="black", linewidth=0.5, **kwargs
            )

    # Add labels to points
    for i, label in enumerate(labels):
        ax.annotate(
            label, (coords[i, 0], coords[i, 1]), xytext=(5, 5), textcoords="offset points", fontsize=9, alpha=0.8
        )

    # Set labels
    if xlab is None:
        xlab = "Dimension 1"
    if ylab is None:
        ylab = "Dimension 2"

    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)

    ax.grid(True, alpha=0.3, linestyle="--")
    ax.axhline(y=0, color="gray", linewidth=0.5, alpha=0.5)
    ax.axvline(x=0, color="gray", linewidth=0.5, alpha=0.5)

    return ax


def sa(
    adata: AnnData,
    fit_values: np.ndarray | None = None,
    xlab: str = "Average log-expression",
    ylab: str = "Sqrt(standard deviation)",
    title: str = "SA Plot",
    show_trend: bool = True,
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Sigma vs average plot for mean-variance relationship.

    SA plot (also called mean-variance plot) shows the relationship between
    average expression and variability. Used to assess variance stabilization
    and the appropriateness of statistical models.

    Plots sqrt(standard deviation) vs mean log-expression. If fit_values are
    provided (e.g., from limma's empirical Bayes estimation), shows the
    smoothed variance trend.

    Args:
        adata: AnnData object with probe-level expression data in .X
        fit_values: Fitted/smoothed variance values from statistical model.
            If provided, overlays trend line.
        xlab: X-axis label
        ylab: Y-axis label
        title: Plot title
        show_trend: Whether to show smoothed trend line. Default True.
        ax: Existing Axes object. If None, creates new figure.
        **kwargs: Additional arguments passed to ax.scatter()

    Returns:
        Axes object with SA plot

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> from microarray.plotting import sa
        >>> data = np.random.randn(1000, 6)
        >>> adata = ad.AnnData(data.T)
        >>> ax = sa(adata)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 6))

    # Get expression matrix (samples x probes)
    expr = adata.X

    # Convert to log2 if not already
    if expr.min() >= 0 and (expr.max() - expr.min()) > 20:
        log_expr = np.log2(expr + 1)
    else:
        log_expr = expr

    # Calculate mean and standard deviation for each probe
    mean_expr = np.mean(log_expr, axis=0)
    std_expr = np.std(log_expr, axis=0, ddof=1)  # Sample std dev

    # Remove NaN/Inf values
    mask = np.isfinite(mean_expr) & np.isfinite(std_expr) & (std_expr > 0)
    mean_expr = mean_expr[mask]
    std_expr = std_expr[mask]

    # Transform standard deviation
    sqrt_std = np.sqrt(std_expr)

    # Create scatter plot
    ax.scatter(mean_expr, sqrt_std, alpha=0.5, s=10, **kwargs)

    # Add trend line if fit values provided
    if fit_values is not None:
        fit_values = fit_values[mask]
        sqrt_fit = np.sqrt(fit_values)

        # Sort for plotting
        sort_idx = np.argsort(mean_expr)
        ax.plot(mean_expr[sort_idx], sqrt_fit[sort_idx], color="red", linewidth=2, label="Fitted trend")
        ax.legend(loc="best")
    elif show_trend:
        # Calculate simple smoothed trend using local polynomial
        try:
            from scipy.signal import savgol_filter

            # Sort by mean expression
            sort_idx = np.argsort(mean_expr)
            sorted_mean = mean_expr[sort_idx]
            sorted_sqrt_std = sqrt_std[sort_idx]

            # Apply Savitzky-Golay filter for smoothing
            window_length = min(51, len(sorted_mean) // 10)
            if window_length % 2 == 0:
                window_length += 1
            if window_length >= 3:
                smoothed = savgol_filter(sorted_sqrt_std, window_length, 3)
                ax.plot(sorted_mean, smoothed, color="red", linewidth=2, label="Smoothed trend")
                ax.legend(loc="best")
        except ImportError:
            pass  # Skip trend line if scipy not available

    # Set labels and title
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)

    ax.grid(True, alpha=0.3, linestyle="--")

    return ax
