from typing import Any

import matplotlib.colors as mcolors
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
from anndata import AnnData
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.stats import zscore

from microarray.plotting._utils import get_default_colors


def _to_dense_array(x: Any) -> np.ndarray:
    """Convert sparse or dense array-like values to numpy ndarray."""
    if hasattr(x, "toarray"):
        return np.asarray(x.toarray())
    return np.asarray(x)


def _style_dendrogram_axis(ax: Axes) -> None:
    """Remove ticks and frame from dendrogram axis."""
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_frame_on(False)
    for spine in ax.spines.values():
        spine.set_visible(False)


def _equalize_linkage_levels(z: np.ndarray) -> np.ndarray:
    """Return a copy of linkage matrix with uniformly spaced merge heights."""
    z_eq = z.copy()
    z_eq[:, 2] = np.arange(1, z.shape[0] + 1, dtype=float)
    return z_eq


def _resolve_group_colors(
    group_levels: list[str],
    group_colors: dict[str, str] | str | mcolors.Colormap | None,
) -> dict[str, str]:
    """Resolve group color mapping from explicit map, cmap name/object, or defaults."""
    if isinstance(group_colors, dict):
        resolved = dict(group_colors)
        missing = [g for g in group_levels if g not in resolved]
        if missing:
            fallback = get_default_colors(len(missing))
            resolved.update(dict(zip(missing, fallback, strict=False)))
        return resolved

    if group_colors is None:
        default_colors = get_default_colors(len(group_levels))
        return dict(zip(group_levels, default_colors, strict=False))

    cmap_obj = plt.get_cmap(group_colors) if isinstance(group_colors, str) else group_colors
    if len(group_levels) == 1:
        return {group_levels[0]: mcolors.to_hex(cmap_obj(0.5))}

    if isinstance(cmap_obj, mcolors.ListedColormap) and cmap_obj.N > 0:
        # Sample at bin centers to preserve listed color order (e.g. tab10/tab20)
        positions = ((np.arange(len(group_levels)) % cmap_obj.N) + 0.5) / cmap_obj.N
    else:
        positions = np.linspace(0.0, 1.0, len(group_levels), endpoint=True)
    sampled = [mcolors.to_hex(cmap_obj(p)) for p in positions]
    return dict(zip(group_levels, sampled, strict=False))


def heatmap(
    adata: AnnData,
    genes: list[str],
    groupby: str | None = None,
    group_colors: dict[str, str] | str | mcolors.Colormap | None = None,
    swap_axes: bool = False,
    show_dendrograms: bool = True,
    dendrogram_axes: str | None = None,
    z_score: bool = True,
    cmap: str = "RdBu_r",
    vmin: float = -2,
    vmax: float = 2,
    title: str = "Hierarchical Clustering Heatmap",
    figsize: tuple[float, float] = (14, 10),
    colorbar_shrink: float = 0.7,
    show: bool = True,
) -> tuple[Figure, dict[str, Axes | None]]:
    """Plot sample-by-gene heatmap with optional hierarchical clustering.

    Args:
            adata: AnnData object containing expression data in ``.X``.
            genes: Ordered list of genes to display in the heatmap.
            groupby: Optional ``adata.obs`` column used for sample group annotations.
            group_colors: Optional group color mapping or colormap (name/object).
            swap_axes: If True, transpose heatmap so genes are rows and samples are columns.
            show_dendrograms: Backward-compatible toggle for showing dendrograms.
            dendrogram_axes: Which dendrograms to display: ``"x"``, ``"y"``, ``"both"``, or ``"none"``.
            z_score: If True, z-score each gene across samples.
            cmap: Colormap used for heatmap values.
            vmin: Lower color limit for heatmap.
            vmax: Upper color limit for heatmap.
            title: Figure title.
            figsize: Figure size passed to matplotlib.
            colorbar_shrink: Shrink factor for colorbar to reduce visual footprint.
            show: If True, call ``fig.show()`` before returning.

    Returns:
            Tuple of ``(Figure, axes_dict)``. The dictionary contains
            ``heatmap``, ``dendrogram_row``, ``dendrogram_col``, ``groupbar``, and ``colorbar``.
    """
    genes = [g for g in dict.fromkeys(genes) if g in adata.var_names]
    if len(genes) == 0:
        raise ValueError("None of the provided genes were found in adata.var_names")

    x = _to_dense_array(adata[:, adata.var.index.isin(genes)].X)
    if z_score:
        x = zscore(x, axis=0, nan_policy="omit")
        x = np.nan_to_num(x, nan=0.0)

    sample_names = np.array(adata.obs_names)
    gene_names = np.array(genes)
    matrix = x.T if swap_axes else x

    if dendrogram_axes is None:
        dendrogram_mode = "both" if show_dendrograms else "none"
    else:
        dendrogram_mode = str(dendrogram_axes).lower()

    valid_dendrogram_modes = {"none", "x", "y", "both"}
    if dendrogram_mode not in valid_dendrogram_modes:
        raise ValueError("dendrogram_axes must be one of: 'none', 'x', 'y', 'both'")

    show_dendrogram_x = dendrogram_mode in {"x", "both"}
    show_dendrogram_y = dendrogram_mode in {"y", "both"}

    z_rows = None
    z_cols = None
    row_order = np.arange(matrix.shape[0])
    col_order = np.arange(matrix.shape[1])

    if show_dendrogram_y and matrix.shape[0] > 1:
        z_rows = linkage(matrix, method="ward", metric="euclidean")
        row_order = np.array(dendrogram(z_rows, no_plot=True)["leaves"])

    if show_dendrogram_x and matrix.shape[1] > 1:
        z_cols = linkage(matrix.T, method="ward", metric="euclidean")
        col_order = np.array(dendrogram(z_cols, no_plot=True)["leaves"])

    x_ord = matrix[np.ix_(row_order, col_order)]

    if swap_axes:
        row_labels = gene_names[row_order]
        col_labels = sample_names[col_order]
    else:
        row_labels = sample_names[row_order]
        col_labels = gene_names[col_order]

    has_groups = groupby is not None
    if has_groups and groupby not in adata.obs:
        raise ValueError(f"Column '{groupby}' not found in adata.obs")

    use_groupbar_column = has_groups and not swap_axes

    n_rows = 2 if show_dendrogram_x else 1
    heatmap_row_idx = 1 if show_dendrogram_x else 0

    width_ratios = [4.6]
    if show_dendrogram_y:
        width_ratios.append(1.0)
    if use_groupbar_column:
        width_ratios.append(0.14)
        width_ratios.append(0.22)

    fig = plt.figure(figsize=figsize)
    if n_rows == 2:
        gs = fig.add_gridspec(
            2,
            len(width_ratios),
            width_ratios=width_ratios,
            height_ratios=[1.0, 4.6],
            hspace=0.05,
            wspace=0.05,
        )
    else:
        gs = fig.add_gridspec(1, len(width_ratios), width_ratios=width_ratios, wspace=0.05)

    ax_heatmap = fig.add_subplot(gs[heatmap_row_idx, 0])
    ax_dendro_col = fig.add_subplot(gs[0, 0]) if show_dendrogram_x else None
    ax_dendro_row = fig.add_subplot(gs[heatmap_row_idx, 1]) if show_dendrogram_y else None
    group_col_idx = (2 + int(show_dendrogram_y)) if use_groupbar_column else None

    if ax_dendro_col is not None and z_cols is not None:
        z_cols_eq = _equalize_linkage_levels(z_cols)
        dendrogram(
            z_cols_eq,
            ax=ax_dendro_col,
            orientation="top",
            no_labels=True,
            link_color_func=lambda _: "black",
        )
    if ax_dendro_row is not None and z_rows is not None:
        z_rows_eq = _equalize_linkage_levels(z_rows)
        dendrogram(
            z_rows_eq,
            ax=ax_dendro_row,
            orientation="right",
            no_labels=True,
            link_color_func=lambda _: "black",
        )

    if ax_dendro_col is not None:
        _style_dendrogram_axis(ax_dendro_col)
    if ax_dendro_row is not None:
        _style_dendrogram_axis(ax_dendro_row)

    im = ax_heatmap.imshow(x_ord, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax)
    ax_heatmap.set_xlabel("Samples" if swap_axes else "Genes")
    ax_heatmap.set_ylabel("Genes" if swap_axes else "Samples")
    ax_heatmap.set_xticks(np.arange(len(col_labels)))
    ax_heatmap.set_xticklabels(col_labels, rotation=90)
    ax_heatmap.set_yticks(np.arange(len(row_labels)))
    ax_heatmap.set_yticklabels(row_labels)
    ax_heatmap.yaxis.tick_left()
    ax_heatmap.yaxis.set_label_position("left")
    ax_heatmap.tick_params(axis="y", labelleft=True, labelright=False)

    ax_groupbar = None
    if has_groups:
        group_values_full = adata.obs[groupby].astype(str).to_numpy()
        sample_order = col_order if swap_axes else row_order
        group_values = group_values_full[sample_order]
        group_levels = list(dict.fromkeys(group_values.tolist()))

        group_colors = _resolve_group_colors(group_levels, group_colors)

        legend_handles = [mpatches.Patch(facecolor=group_colors[g], edgecolor="black", label=g) for g in group_levels]
        ax_heatmap.legend(
            handles=legend_handles,
            title=str(groupby),
            loc="upper left",
            bbox_to_anchor=(1.02, 1.2),
            frameon=False,
        )

    if has_groups and group_col_idx is not None:
        ax_groupbar = fig.add_subplot(gs[heatmap_row_idx, group_col_idx])
        rgba = np.array([mcolors.to_rgba(group_colors[g]) for g in group_values]).reshape(-1, 1, 4)
        ax_groupbar.imshow(rgba, aspect="auto", origin="upper")
        ax_groupbar.set_xticks([])
        ax_groupbar.set_yticks([])
        for spine in ax_groupbar.spines.values():
            spine.set_visible(False)
    elif has_groups and swap_axes:
        ax_groupbar = ax_heatmap.inset_axes([0.0, 1.01, 1.0, 0.04], transform=ax_heatmap.transAxes)
        rgba = np.array([mcolors.to_rgba(group_colors[g]) for g in group_values]).reshape(1, -1, 4)
        ax_groupbar.imshow(rgba, aspect="auto", origin="upper")
        ax_groupbar.set_xticks([])
        ax_groupbar.set_yticks([])
        for spine in ax_groupbar.spines.values():
            spine.set_visible(False)

    shrink = float(np.clip(colorbar_shrink, 0.2, 1.0))
    cbar_width = 0.20 * shrink
    cbar_bottom = 0.05
    cbar_left = 0.95 - cbar_width
    ax_cbar = fig.add_axes([cbar_left, cbar_bottom, cbar_width, 0.018])
    cbar = fig.colorbar(im, cax=ax_cbar, orientation="horizontal")
    cbar.set_label("Z-score" if z_score else "Expression")

    fig.suptitle(title)

    if show:
        fig.show()

    return fig, {
        "heatmap": ax_heatmap,
        "dendrogram_row": ax_dendro_row,
        "dendrogram_col": ax_dendro_col,
        "groupbar": ax_groupbar,
        "colorbar": ax_cbar,
    }
