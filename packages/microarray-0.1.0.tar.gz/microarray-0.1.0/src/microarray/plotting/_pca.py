"""PCA plotting for microarray data."""

from __future__ import annotations

from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from adjustText import adjust_text
from anndata import AnnData
from matplotlib.axes import Axes
from matplotlib.colors import Colormap

from microarray.plotting._utils import get_default_colors


def pca(
    adata: AnnData,
    obsm_key: str = "X_pca",
    components: tuple[int, int] = (1, 2),
    labels: list[str] | None = None,
    colors: str | None = None,
    cmap: str | Colormap = "viridis",
    xlab: str | None = None,
    ylab: str | None = None,
    title: str = "PCA Plot",
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Plot PCA coordinates stored in ``adata.obsm``.

    If ``obsm_key`` does not exist, PCA is computed automatically using
    :func:`microarray.tools.pca`.

    Args:
        adata: AnnData object with PCA embedding in ``.obsm`` or expression data.
        obsm_key: Key in ``.obsm`` where PCA coordinates are stored.
        components: 1-based component indices to plot (e.g. ``(1, 2)``).
        labels: Optional labels for each sample. Defaults to ``adata.obs_names``.
        colors: Optional ``adata.obs`` column used for coloring points.
            Categorical columns are shown with a legend. Numeric columns
            are shown with a continuous colormap.
        cmap: Colormap used when ``colors`` points to a numeric ``adata.obs`` column.
        xlab: Optional x-axis label.
        ylab: Optional y-axis label.
        title: Plot title.
        ax: Existing matplotlib axes to reuse.
        **kwargs: Extra arguments forwarded to ``ax.scatter``.

    Returns:
        Matplotlib Axes with PCA scatter plot.

    Raises:
        ValueError: If components are invalid for the available embedding.
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 7))

    if len(components) != 2:
        raise ValueError("components must contain exactly two indices")

    if obsm_key not in adata.obsm:
        raise KeyError(f"AnnData .obsm has no '{obsm_key}' key. Compute PCA first using microarray.tools.pca.")

    coords = np.asarray(adata.obsm[obsm_key])
    n_samples, n_dims = coords.shape

    x_idx = components[0] - 1
    y_idx = components[1] - 1
    if x_idx < 0 or y_idx < 0 or x_idx >= n_dims or y_idx >= n_dims:
        raise ValueError(f"components={components} are out of bounds for embedding with {n_dims} dimensions")

    if labels is None:
        labels = list(adata.obs_names) if adata.obs_names is not None else [f"Sample {i}" for i in range(n_samples)]

    if colors is None:
        point_color = get_default_colors(1)[0]
        ax.scatter(
            coords[:, x_idx],
            coords[:, y_idx],
            c=point_color,
            s=100,
            alpha=0.7,
            edgecolors="black",
            linewidth=0.5,
            **kwargs,
        )
    else:
        if colors not in adata.obs.columns:
            raise KeyError(f"AnnData .obs has no '{colors}' column")

        group_values = adata.obs[colors]
        numeric_values = np.asarray(group_values)

        if np.issubdtype(numeric_values.dtype, np.number):
            scatter = ax.scatter(
                coords[:, x_idx],
                coords[:, y_idx],
                c=numeric_values.astype(float),
                cmap=cmap,
                s=100,
                alpha=0.7,
                edgecolors="black",
                linewidth=0.5,
                **kwargs,
            )
            colorbar = ax.figure.colorbar(scatter, ax=ax)
            colorbar.set_label(colors)
        else:
            unique_groups = np.unique(numeric_values.astype(str))
            default_colors = get_default_colors(len(unique_groups))
            color_map = dict(zip(unique_groups, default_colors, strict=False))

            for group in unique_groups:
                mask = numeric_values.astype(str) == group
                ax.scatter(
                    coords[mask, x_idx],
                    coords[mask, y_idx],
                    c=color_map[group],
                    label=str(group),
                    s=100,
                    alpha=0.7,
                    edgecolors="black",
                    linewidth=0.5,
                    **kwargs,
                )
            ax.legend(
                loc="upper left",
                bbox_to_anchor=(1.02, 1.0),
                borderaxespad=0.0,
                frameon=False,
                title=colors,
            )

    text_artists = []
    for i, label in enumerate(labels):
        text_artists.append(
            ax.annotate(
                label,
                (coords[i, x_idx], coords[i, y_idx]),
                fontsize=9,
                alpha=0.8,
            )
        )

    adjust_text(
        text_artists,
        ax=ax,
        expand=(1.02, 1.05),
        force_text=(0.05, 0.08),
        force_static=(0.05, 0.08),
        force_pull=(0.25, 0.25),
        max_move=10,
        min_arrow_len=0,
        arrowprops={"arrowstyle": "-", "color": "0.35", "lw": 0.6, "alpha": 0.8},
    )

    variance_ratio = None
    if obsm_key in adata.uns and isinstance(adata.uns[obsm_key], dict):
        variance_ratio = adata.uns[obsm_key].get("variance_ratio")

    if xlab is None:
        xlab = f"PC{components[0]}"
        if variance_ratio is not None and len(variance_ratio) > x_idx:
            xlab = f"{xlab} ({100 * float(variance_ratio[x_idx]):.1f}%)"
    if ylab is None:
        ylab = f"PC{components[1]}"
        if variance_ratio is not None and len(variance_ratio) > y_idx:
            ylab = f"{ylab} ({100 * float(variance_ratio[y_idx]):.1f}%)"

    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)

    ax.grid(False)

    return ax


def pca_variance(
    adata: AnnData,
    obsm_key: str = "X_pca",
    xlab: str = "Component",
    ylab: str = "Cumulative variance explained",
    title: str = "PCA Cumulative Variance",
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Plot cumulative explained variance from a fitted PCA.

    Args:
        adata: AnnData object with PCA variance information in ``adata.uns``.
        obsm_key: PCA key used in ``adata.uns`` (default: ``"X_pca"``).
        xlab: X-axis label.
        ylab: Y-axis label.
        title: Plot title.
        ax: Existing matplotlib axes to reuse.
        **kwargs: Extra arguments forwarded to ``ax.plot``.

    Returns:
        Matplotlib Axes with cumulative variance line chart.

    Raises:
        KeyError: If variance ratio is unavailable in ``adata.uns``.
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 6))

    if obsm_key not in adata.uns or not isinstance(adata.uns[obsm_key], dict):
        raise KeyError(f"AnnData .uns has no '{obsm_key}' PCA metadata. Compute PCA first using microarray.tools.pca.")

    variance_ratio = adata.uns[obsm_key].get("variance_ratio")
    if variance_ratio is None:
        raise KeyError(
            f"AnnData .uns['{obsm_key}'] has no 'variance_ratio'. Compute PCA first using microarray.tools.pca."
        )

    variance_ratio = np.asarray(variance_ratio, dtype=float)
    cumulative = np.cumsum(variance_ratio)
    components = np.arange(1, cumulative.size + 1)

    ax.plot(components, cumulative, marker="o", **kwargs)
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)
    ax.set_xlim(1, max(1, cumulative.size))
    ax.set_ylim(0.0, 1.05)
    ax.grid(False)

    return ax


def pca_feature_variance(
    adata: AnnData,
    component: int = 1,
    n_var: int = 20,
    obsm_key: str = "X_pca",
    xlab: str = "Feature rank",
    ylab: str = "Variance contribution",
    title: str | None = None,
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Plot top feature variance contributions for one PCA component.

    This uses squared PCA loadings as per-feature variance contribution within
    a selected component and ranks features in decreasing order.

    Args:
        adata: AnnData object with PCA metadata in ``adata.uns``.
        component: 1-based PCA component index to inspect.
        n_var: Number of top-ranked features to display.
        obsm_key: PCA key used in ``adata.uns`` (default: ``"X_pca"``).
        xlab: X-axis label.
        ylab: Y-axis label.
        title: Plot title. Defaults to ``"PC{component} Feature Variance"``.
        ax: Existing matplotlib axes to reuse.
        **kwargs: Extra arguments forwarded to ``ax.plot``.

    Returns:
        Matplotlib Axes with ranked feature variance contributions.

    Raises:
        KeyError: If PCA metadata/components are unavailable.
        ValueError: If ``component`` or ``n_var`` is invalid.
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 6))

    if n_var < 1:
        raise ValueError("n_var must be at least 1")
    if component < 1:
        raise ValueError("component must be at least 1")

    if obsm_key not in adata.uns or not isinstance(adata.uns[obsm_key], dict):
        raise KeyError(f"AnnData .uns has no '{obsm_key}' PCA metadata. Compute PCA first using microarray.tools.pca.")

    components = adata.uns[obsm_key].get("components")
    if components is None:
        raise KeyError(
            f"AnnData .uns['{obsm_key}'] has no 'components'. Recompute PCA with a version that stores loadings."
        )

    components = np.asarray(components, dtype=float)
    n_components, n_features = components.shape
    if component > n_components:
        raise ValueError(f"component must be <= {n_components}")

    contribution = np.square(components[component - 1])
    top_n = min(n_var, n_features)
    top_idx = np.argsort(contribution)[::-1][:top_n]
    top_contrib = contribution[top_idx]
    ranks = np.arange(1, top_n + 1)

    feature_names = np.asarray(adata.var_names.astype(str)) if adata.var_names is not None else np.array([])
    if feature_names.size != n_features:
        feature_names = np.array([f"Feature {i}" for i in range(n_features)])

    ax.plot(ranks, top_contrib, marker="o", alpha=0.1, **kwargs)

    for rank, value, idx in zip(ranks, top_contrib, top_idx, strict=False):
        ax.text(
            rank,
            value,
            feature_names[idx],
            rotation=90,
            ha="center",
            va="center",
            fontsize=8,
        )

    if title is None:
        title = f"PC{component} Feature Variance"

    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)
    ax.grid(False)

    return ax
