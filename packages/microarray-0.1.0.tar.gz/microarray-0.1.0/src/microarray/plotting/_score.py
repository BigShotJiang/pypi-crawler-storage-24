from typing import Literal

from anndata import AnnData
from matplotlib.axes import Axes
from matplotlib.figure import Figure

from ._base import _plot_obs_barplot, _plot_obs_boxplot, _plot_obs_violinplot


def score(
    adata: AnnData,
    groupby: str | None = None,
    score_name: str = "score",
    kind: Literal["bar", "box", "violin"] = "bar",
    **kwargs,
) -> tuple[Figure, Axes]:
    """Plot gene set scores.

    This function computes gene set scores using :func:`score` and then visualizes them.

    Args:
        adata: AnnData object with expression values in ``.X`` or ``layer``.
        groupby: Optional column in ``adata.obs`` to group samples by for plotting.
        score_name: Column name in ``adata.obs`` where scores are stored.
        kind: Type of plot to create. Options are "bar", "box", or "violin".
        **kwargs: Additional keyword arguments passed to the underlying plotting function.

    Returns:
        A tuple containing a matplotlib Figure and Axes object with the plot of scores.
    """
    if kind == "bar":
        return _plot_obs_barplot(adata, groupby=groupby, values=score_name, **kwargs)
    elif kind == "box":
        return _plot_obs_boxplot(adata, groupby=groupby, values=score_name, **kwargs)
    elif kind == "violin":
        return _plot_obs_violinplot(adata, groupby=groupby, values=score_name, **kwargs)
    else:
        raise ValueError(f"Invalid plot kind: {kind}. Choose from 'bar', 'box', or 'violin'.")
