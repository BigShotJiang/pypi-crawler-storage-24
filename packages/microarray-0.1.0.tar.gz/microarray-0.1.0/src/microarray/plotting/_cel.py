import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.colors import Colormap
from matplotlib.patches import Patch

from microarray.io import CelFile


def _set_spines(ax: Axes, show_spines: bool) -> None:
    ax.spines["top"].set_visible(show_spines)
    ax.spines["right"].set_visible(show_spines)
    ax.spines["bottom"].set_visible(show_spines)
    ax.spines["left"].set_visible(show_spines)


def _remove_ticks(ax: Axes) -> None:
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.set_xticks([])
    ax.set_yticks([])


def intensities(
    celfile: CelFile,
    show_spines: bool = True,
    show_ticks: bool = False,
    cmap: str | Colormap = "Reds",
    ax: Axes | None = None,
    title: str | None = "Intensities",
) -> Axes:
    """Plot the intensities of a CEL file."""
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 10))
    ax.imshow(celfile.intensities, cmap=cmap)
    if not show_ticks:
        _remove_ticks(ax)

    _set_spines(ax, show_spines)

    if title is not None:
        ax.set_title(title)

    return ax


def probe_annotations(
    celfile: CelFile,
    show_spines: bool = True,
    show_ticks: bool = False,
    ax: Axes | None = None,
    title: str | None = "Probe annotations",
) -> Axes:
    """Plot the probe annotations of a CEL file."""
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 10))
    ax.imshow(celfile.probe_annotation == None, cmap="gray")  # noqa: E711
    if not show_ticks:
        _remove_ticks(ax)

    _set_spines(ax, show_spines)

    if title is not None:
        ax.set_title(title)

    ax.legend(
        handles=[
            Patch(facecolor="black", label="Probe", linewidth=1, edgecolor="black"),
            Patch(facecolor="white", label="No probe", linewidth=1, edgecolor="black"),
        ],
        labels=["Probe", "No probe"],
        loc="upper left",
        bbox_to_anchor=(1, 1),
        frameon=False,
    )
    return ax
