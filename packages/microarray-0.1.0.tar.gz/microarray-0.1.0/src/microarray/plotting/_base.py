import matplotlib.pyplot as plt
import numpy as np
from anndata import AnnData
from matplotlib.axes import Axes
from matplotlib.colors import Colormap
from matplotlib.figure import Figure


def _plot_base(
    ax: Axes | None = None,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    figsize: tuple[float | int, float | int] = (5, 6),
) -> tuple[Figure, Axes]:

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    ax.set_xticks([])
    ax.set_xticklabels([])
    if ylabel is not None:
        ax.set_ylabel(ylabel)
    if xlabel is not None:
        ax.set_xlabel(xlabel)
    if title is not None:
        ax.set_title(title)

    return fig, ax


def _plot_obs_barplot(
    adata_obj: AnnData,
    groupby: str,
    values: str,
    ax: Axes | None = None,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    bar_alpha: float = 0.7,
    bar_width: float = 0.9,
    jitter_std: float = 0.05,
    jitter_seed: int = 42,
    figsize: tuple[float | int, float | int] = (5, 6),
    cmap: str | Colormap = "tab10",
    show: bool = True,
    show_legend: bool = True,
) -> tuple[Figure, Axes]:

    fig, ax = _plot_base(
        ax=ax,
        title=title,
        xlabel=xlabel,
        ylabel=ylabel,
        figsize=figsize,
    )

    obs = adata_obj.obs[[groupby, values]].copy()
    group_means = obs.groupby(groupby)[values].mean()

    conditions = group_means.index.tolist()
    x = np.arange(len(conditions))

    cmap = plt.get_cmap(cmap)
    colors = {cond: cmap(i % 10) for i, cond in enumerate(conditions)}

    ax.bar(
        x,
        group_means.values,
        color=[colors[c] for c in conditions],
        alpha=bar_alpha,
        width=bar_width,
        edgecolor="black",
    )

    rng = np.random.default_rng(jitter_seed)
    for i, cond in enumerate(conditions):
        y = obs.loc[obs[groupby] == cond, values].values
        jitter = rng.normal(0, jitter_std, size=len(y))
        ax.scatter(
            np.full(len(y), i) + jitter,
            y,
            color=colors[cond],
            edgecolor="black",
            s=45,
            label=cond,
            zorder=3,
        )

    if ylabel is None:
        ax.set_ylabel(values)
    if xlabel is None:
        ax.set_xlabel(groupby)

    if show_legend:
        ax.legend(
            title=None,
            loc="upper left",
            bbox_to_anchor=(1.02, 1),
            borderaxespad=0,
            frameon=False,
        )

    if show:
        fig.show()
    return fig, ax


def _plot_obs_violinplot(
    adata_obj: AnnData,
    groupby: str,
    values: str,
    ax: Axes | None = None,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    jitter_std: float = 0.05,
    jitter_seed: int = 42,
    figsize: tuple[float | int, float | int] = (5, 6),
    cmap: str | Colormap = "tab10",
    show: bool = True,
    show_legend: bool = True,
) -> tuple[Figure, Axes]:

    fig, ax = _plot_base(
        ax=ax,
        title=title,
        xlabel=xlabel,
        ylabel=ylabel,
        figsize=figsize,
    )

    obs = adata_obj.obs[[groupby, values]].copy()
    conditions = obs[groupby].unique().tolist()

    cmap = plt.get_cmap(cmap)
    colors = {cond: cmap(i % 10) for i, cond in enumerate(conditions)}

    data_to_plot = [obs.loc[obs[groupby] == cond, values].values for cond in conditions]
    violin_parts = ax.violinplot(data_to_plot, showmeans=False, showmedians=False, showextrema=False)

    for part, cond in zip(violin_parts["bodies"], conditions, strict=True):
        part.set_facecolor(colors[cond])
        part.set_edgecolor("black")
        part.set_alpha(0.7)

    rng = np.random.default_rng(jitter_seed)
    for i, cond in enumerate(conditions):
        y = obs.loc[obs[groupby] == cond, values].values
        jitter = rng.normal(0, jitter_std, size=len(y))
        ax.scatter(
            np.full(len(y), i + 1) + jitter,
            y,
            color=colors[cond],
            edgecolor="black",
            s=45,
            label=cond,
            zorder=3,
        )

    if ylabel is None:
        ax.set_ylabel(values)
    if xlabel is None:
        ax.set_xlabel(groupby)

    if show_legend:
        ax.legend(
            title=None,
            loc="upper left",
            bbox_to_anchor=(1.02, 1),
            borderaxespad=0,
            frameon=False,
        )

    if show:
        fig.show()
    return fig, ax


def _plot_obs_boxplot(
    adata_obj: AnnData,
    groupby: str,
    values: str,
    ax: Axes | None = None,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    jitter_std: float = 0.05,
    jitter_seed: int = 42,
    figsize: tuple[float | int, float | int] = (5, 6),
    cmap: str | Colormap = "tab10",
    show: bool = True,
    show_legend: bool = True,
    widths: float | list[float] = 0.9,
) -> tuple[Figure, Axes]:

    fig, ax = _plot_base(
        ax=ax,
        title=title,
        xlabel=xlabel,
        ylabel=ylabel,
        figsize=figsize,
    )

    obs = adata_obj.obs[[groupby, values]].copy()
    conditions = obs[groupby].unique().tolist()

    cmap = plt.get_cmap(cmap)
    colors = {cond: cmap(i % 10) for i, cond in enumerate(conditions)}

    data_to_plot = [obs.loc[obs[groupby] == cond, values].values for cond in conditions]
    bplot = ax.boxplot(data_to_plot, patch_artist=True, widths=widths)

    for patch, cond in zip(bplot["boxes"], conditions, strict=True):
        patch.set_facecolor(colors[cond])
        patch.set_edgecolor("black")

    for median in bplot["medians"]:
        median.set(color="black")

    rng = np.random.default_rng(jitter_seed)
    for i, cond in enumerate(conditions):
        y = obs.loc[obs[groupby] == cond, values].values
        jitter = rng.normal(0, jitter_std, size=len(y))
        ax.scatter(
            np.full(len(y), i + 1) + jitter,
            y,
            color=colors[cond],
            edgecolor="black",
            s=45,
            label=cond,
            zorder=3,
        )

    if ylabel is None:
        ax.set_ylabel(values)
    if xlabel is None:
        ax.set_xlabel(groupby)

    if show_legend:
        ax.legend(
            title=None,
            loc="upper left",
            bbox_to_anchor=(1.02, 1),
            borderaxespad=0,
            frameon=False,
        )

    if show:
        fig.show()
    return fig, ax
