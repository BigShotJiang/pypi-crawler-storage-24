"""MA and MD plot functions for microarray quality control."""

from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from anndata import AnnData
from matplotlib.axes import Axes

from microarray.plotting._utils import add_loess_curve, add_reference_line, with_highlights


def ma(
    adata: AnnData,
    arrays: tuple[int | str, int | str] | None = None,
    status: np.ndarray | None = None,
    span: float = 0.3,
    xlab: str = "A (average log-expression)",
    ylab: str = "M (log-ratio)",
    title: str = "",
    loess: bool = True,
    reference_line: bool = True,
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """MA plot (M vs A plot) for comparing two arrays or array vs reference.

    MA plot displays log-ratio (M) vs average log-expression (A) to visualize
    differences between two arrays. Useful for quality control and identifying
    systematic biases.

    M = log2(array1) - log2(array2)
    A = 0.5 * (log2(array1) + log2(array2))

    Args:
        adata: AnnData object with probe-level expression data in .X
        arrays: Tuple of two array indices/names to compare. If None, compares
            first array to pseudo-median reference.
        status: Status labels for highlighting points (e.g., 'up', 'down', 'not-significant')
        span: Smoothing span for LOESS curve (0-1). Default 0.3.
        xlab: X-axis label
        ylab: Y-axis label
        title: Plot title
        loess: Whether to add LOESS smoothing curve. Default True.
        reference_line: Whether to add horizontal line at M=0. Default True.
        ax: Existing Axes object. If None, creates new figure.
        **kwargs: Additional arguments passed to scatter plot

    Returns:
        Axes object with MA plot

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> from microarray.plotting import ma
        >>> # Compare two arrays
        >>> data = np.random.randn(1000, 4)
        >>> adata = ad.AnnData(data.T)
        >>> ax = ma(adata, arrays=(0, 1))
        >>> # Compare to median reference
        >>> ax = ma(adata)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 6))

    # Get expression matrix (probes x samples)
    # AnnData stores as samples x features, so transpose
    expr = adata.X.T  # Now probes x samples

    # Check for multiple arrays
    if expr.ndim == 1 or expr.shape[1] < 2:
        raise ValueError("AnnData must contain multiple arrays for MA plot")

    # Convert to log2 if not already
    # Check if data appears to be log-transformed (negative values or small range)
    if expr.min() < 0 or (expr.max() - expr.min()) < 20:
        # Likely already log-transformed
        log_expr = expr
    else:
        # Apply log2 transformation
        log_expr = np.log2(expr + 1)  # Add pseudocount to avoid log(0)

    # Select arrays to compare
    if arrays is None:
        # Compare first array to pseudo-median reference
        array1_idx = 0
        reference = np.median(log_expr, axis=1)  # Median across all arrays
        log_array1 = log_expr[:, array1_idx]
        log_array2 = reference
        if not title:
            title = "MA Plot: Array 0 vs Median"
    else:
        # Compare two specified arrays
        if len(arrays) != 2:
            raise ValueError("arrays must be a tuple of length 2")

        # Handle array indices or names
        if isinstance(arrays[0], str):
            array1_idx = list(adata.obs_names).index(arrays[0])
        else:
            array1_idx = arrays[0]

        if isinstance(arrays[1], str):
            array2_idx = list(adata.obs_names).index(arrays[1])
        else:
            array2_idx = arrays[1]

        log_array1 = log_expr[:, array1_idx]
        log_array2 = log_expr[:, array2_idx]
        if not title:
            title = f"MA Plot: Array {array1_idx} vs Array {array2_idx}"

    # Calculate M and A
    M = log_array1 - log_array2
    A = 0.5 * (log_array1 + log_array2)

    # Remove NaN/Inf values
    mask = np.isfinite(M) & np.isfinite(A)
    M = M[mask]
    A = A[mask]
    if status is not None:
        status = status[mask]

    # Create scatter plot with highlighting
    ax = with_highlights(A, M, status=status, xlab=xlab, ylab=ylab, title=title, ax=ax, **kwargs)

    # Add reference line at M=0
    if reference_line:
        add_reference_line(ax, y=0, color="gray", linestyle="--", linewidth=1)

    # Add LOESS smoothing curve
    if loess and len(A) > 10:
        add_loess_curve(ax, A, M, span=span, color="blue", linewidth=2, label="LOESS")
        ax.legend(loc="best")

    return ax
