"""Quality control plot functions for microarray data."""

from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from anndata import AnnData
from matplotlib.axes import Axes
from scipy import stats

from microarray.plotting._utils import get_default_colors


def densities(
    adata: AnnData,
    arrays: list[int | str] | None = None,
    colors: list[str] | None = None,
    xlab: str = "Log2 intensity",
    ylab: str = "Density",
    title: str = "Intensity Distributions",
    legend: bool | str = "best",
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Plot overlaid density estimates for multiple arrays.

    Displays kernel density estimates of probe intensity distributions
    for quality control. Similar arrays should have similar distributions.

    Args:
        adata: AnnData object with probe-level expression data in .X
        arrays: List of array indices/names to plot. If None, plots all arrays.
        colors: List of colors for each array. If None, uses default palette.
        xlab: X-axis label
        ylab: Y-axis label
        title: Plot title
        legend: Legend position ('best', 'upper right', etc.) or False to disable
        ax: Existing Axes object. If None, creates new figure.
        **kwargs: Additional arguments passed to ax.plot()

    Returns:
        Axes object with density plot

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> from microarray.plotting import densities
        >>> data = np.random.randn(1000, 4)
        >>> adata = ad.AnnData(data.T)
        >>> ax = densities(adata)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 6))

    # Get expression matrix (samples x probes)
    expr = adata.X

    # Convert to log2 if not already
    if expr.min() >= 0 and (expr.max() - expr.min()) > 20:
        # Likely raw intensity values
        log_expr = np.log2(expr + 1)
    else:
        log_expr = expr

    # Select arrays to plot
    if arrays is None:
        array_indices = list(range(expr.shape[0]))
        array_names = list(adata.obs_names) if adata.obs_names is not None else [f"Array {i}" for i in array_indices]
    else:
        array_indices = []
        array_names = []
        for arr in arrays:
            if isinstance(arr, str):
                idx = list(adata.obs_names).index(arr)
                array_indices.append(idx)
                array_names.append(arr)
            else:
                array_indices.append(arr)
                array_names.append(adata.obs_names[arr] if adata.obs_names is not None else f"Array {arr}")

    # Get colors
    if colors is None:
        colors = get_default_colors(len(array_indices))
    elif len(colors) < len(array_indices):
        colors = colors + get_default_colors(len(array_indices) - len(colors))

    # Plot density for each array
    for idx, name, color in zip(array_indices, array_names, colors, strict=False):
        data = log_expr[idx, :]
        # Remove NaN values
        data = data[np.isfinite(data)]

        if len(data) < 2:
            continue

        # Use kernel density estimation
        kde = stats.gaussian_kde(data)

        # Create x-axis for density plot
        x_min, x_max = data.min(), data.max()
        x_range = x_max - x_min
        x = np.linspace(x_min - 0.1 * x_range, x_max + 0.1 * x_range, 512)

        # Compute density
        density = kde(x)

        # Plot
        ax.plot(x, density, color=color, label=name, linewidth=2, **kwargs)

    # Set labels and title
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)

    # Add legend if requested
    if legend and len(array_indices) > 1:
        ax.legend(loc=legend if isinstance(legend, str) else "best", frameon=True)

    ax.grid(True, alpha=0.3, linestyle="--")
    ax.set_ylim(bottom=0)  # Density should start at 0

    return ax


def boxplot(
    adata: AnnData,
    arrays: list[int | str] | None = None,
    colors: list[str] | str | None = None,
    xlab: str = "Array",
    ylab: str = "Log2 intensity",
    title: str = "Intensity Boxplots",
    show_fliers: bool = False,
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Create boxplots of probe intensities across arrays.

    Displays distribution of probe intensities for each array using boxplots.
    Useful for comparing overall intensity levels and dispersion across arrays.

    Args:
        adata: AnnData object with probe-level expression data in .X
        arrays: List of array indices/names to plot. If None, plots all arrays.
        colors: Color(s) for boxes. Can be single color or list of colors.
        xlab: X-axis label
        ylab: Y-axis label
        title: Plot title
        show_fliers: Whether to show outlier points. Default False.
        ax: Existing Axes object. If None, creates new figure.
        **kwargs: Additional arguments passed to ax.boxplot()

    Returns:
        Axes object with boxplot

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> from microarray.plotting import boxplot
        >>> data = np.random.randn(1000, 4)
        >>> adata = ad.AnnData(data.T)
        >>> ax = boxplot(adata)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(max(8, len(adata.obs_names) * 0.8), 6))

    # Get expression matrix (samples x probes)
    expr = adata.X

    # Convert to log2 if not already
    if expr.min() >= 0 and (expr.max() - expr.min()) > 20:
        log_expr = np.log2(expr + 1)
    else:
        log_expr = expr

    # Select arrays to plot
    if arrays is None:
        array_indices = list(range(expr.shape[0]))
        array_names = list(adata.obs_names) if adata.obs_names is not None else [f"Array {i}" for i in array_indices]
    else:
        array_indices = []
        array_names = []
        for arr in arrays:
            if isinstance(arr, str):
                idx = list(adata.obs_names).index(arr)
                array_indices.append(idx)
                array_names.append(arr)
            else:
                array_indices.append(arr)
                array_names.append(adata.obs_names[arr] if adata.obs_names is not None else f"Array {arr}")

    # Prepare data for boxplot
    data_list = []
    for idx in array_indices:
        data = log_expr[idx, :]
        # Remove NaN values
        data = data[np.isfinite(data)]
        data_list.append(data)

    # Create boxplot
    bp = ax.boxplot(data_list, labels=array_names, showfliers=show_fliers, patch_artist=True, **kwargs)

    # Color boxes
    if colors is not None:
        if isinstance(colors, str):
            # Single color for all boxes
            for patch in bp["boxes"]:
                patch.set_facecolor(colors)
        else:
            # List of colors
            if len(colors) < len(array_indices):
                colors = colors + get_default_colors(len(array_indices) - len(colors))
            for patch, color in zip(bp["boxes"], colors, strict=False):
                patch.set_facecolor(color)

    # Set labels and title
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)

    # Rotate x-axis labels if many arrays
    if len(array_indices) > 4:
        ax.set_xticklabels(array_names, rotation=45, ha="right")

    ax.grid(True, alpha=0.3, linestyle="--", axis="y")

    return ax


def histogram(
    adata: AnnData,
    arrays: list[int | str] | None = None,
    bins: int = 50,
    colors: list[str] | None = None,
    xlab: str = "Log2 intensity",
    ylab: str = "Frequency",
    title: str = "Intensity Histograms",
    alpha: float = 0.6,
    legend: bool | str = "best",
    ax: Axes | None = None,
    **kwargs: Any,
) -> Axes:
    """Plot histograms of probe intensities for multiple arrays.

    Displays probe intensity distributions as histograms.
    Similar to densities() but shows actual counts rather than smoothed density.

    Args:
        adata: AnnData object with probe-level expression data in .X
        arrays: List of array indices/names to plot. If None, plots all arrays.
        bins: Number of histogram bins. Default 50.
        colors: List of colors for each array. If None, uses default palette.
        xlab: X-axis label
        ylab: Y-axis label
        title: Plot title
        alpha: Transparency of histogram bars (0-1)
        legend: Legend position ('best', 'upper right', etc.) or False to disable
        ax: Existing Axes object. If None, creates new figure.
        **kwargs: Additional arguments passed to ax.hist()

    Returns:
        Axes object with histogram

    Examples:
        >>> import anndata as ad
        >>> import numpy as np
        >>> from microarray.plotting import histogram
        >>> data = np.random.randn(1000, 4)
        >>> adata = ad.AnnData(data.T)
        >>> ax = histogram(adata)
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 6))

    # Get expression matrix (samples x probes)
    expr = adata.X

    # Convert to log2 if not already
    if expr.min() >= 0 and (expr.max() - expr.min()) > 20:
        log_expr = np.log2(expr + 1)
    else:
        log_expr = expr

    # Select arrays to plot
    if arrays is None:
        array_indices = list(range(expr.shape[0]))
        array_names = list(adata.obs_names) if adata.obs_names is not None else [f"Array {i}" for i in array_indices]
    else:
        array_indices = []
        array_names = []
        for arr in arrays:
            if isinstance(arr, str):
                idx = list(adata.obs_names).index(arr)
                array_indices.append(idx)
                array_names.append(arr)
            else:
                array_indices.append(arr)
                array_names.append(adata.obs_names[arr] if adata.obs_names is not None else f"Array {arr}")

    # Get colors
    if colors is None:
        colors = get_default_colors(len(array_indices))
    elif len(colors) < len(array_indices):
        colors = colors + get_default_colors(len(array_indices) - len(colors))

    # Determine common bin range across all arrays
    all_data = []
    for idx in array_indices:
        data = log_expr[idx, :]
        data = data[np.isfinite(data)]
        all_data.extend(data)

    bin_range = (np.min(all_data), np.max(all_data))

    # Plot histogram for each array
    for idx, name, color in zip(array_indices, array_names, colors, strict=False):
        data = log_expr[idx, :]
        data = data[np.isfinite(data)]

        if len(data) < 1:
            continue

        ax.hist(data, bins=bins, range=bin_range, color=color, alpha=alpha, label=name, edgecolor="none", **kwargs)

    # Set labels and title
    ax.set_xlabel(xlab)
    ax.set_ylabel(ylab)
    ax.set_title(title)

    # Add legend if requested
    if legend and len(array_indices) > 1:
        ax.legend(loc=legend if isinstance(legend, str) else "best", frameon=True)

    ax.grid(True, alpha=0.3, linestyle="--", axis="y")

    return ax
