import os
from typing import Any, BinaryIO, Literal
from urllib.parse import urlencode, urlunparse

import requests

TIMEOUT = 1000


def build_url(
    hostname: str,
    path: str,
    scheme: Literal["http", "https", "ftp"] | str = "https",
    query: dict[str, str | int | float] | None = None,
    fragment: str | None = None,
) -> str:
    """Build url from parts.

    Args:
        hostname (str): Hostname of url (e.g. "example.com").
        path (str): Path of url.
        scheme (Literal["http", "https", "ftp"] | str, optional): Schema of url. Defaults to `https`.
        query (dict[str, str | int | float] | None, optional): Query parameter. Defaults to `None`.
        fragment (str | None, optional): Fragment of url. Defaults to `None`.

    Returns:
        str: Full url as string.
    """
    query_encoded: str = ""

    if query is not None:
        query_encoded = urlencode(query)

    url = urlunparse(
        [
            scheme,
            hostname,
            path,
            "",
            query_encoded,
            "" if fragment is None else fragment,
        ]
    )
    return url


def _file_or_buffer(
    output_file: str | BinaryIO,
    overwrite: bool = False,
) -> BinaryIO:
    """Harmonize file name and buffer.

    Args:
        output_file (str | BinaryIO): Filename to save object to or file object.
        overwrite (bool, optional): Flag to overwrite, if output file already exist. Defaults to `False`.

    Returns:
        Memory buffer or opened File buffer.

    Raises:
        FileExistsError: If `overwrite=False` and output file already exists.
    """
    file_object: BinaryIO

    if isinstance(output_file, str):
        if overwrite is False and os.path.isfile(output_file):
            raise FileExistsError(f"Output file '{output_file}' already exists.")

        file_object = open(output_file, "wb")
    else:
        file_object = output_file

    return file_object


def download_file_stream(
    url: str,
    output_file: str | BinaryIO,
    overwrite: bool = False,
    chunk_size: int = 8192,
    request_kwargs: dict[str, Any] | None = None,
) -> None:
    """Download file as stream. Source: https://stackoverflow.com/questions/16694907/download-large-file-in-python-with-requests.

    Args:
        url (str): URL to download.
        output_file (str | BinaryIO): Filename to save object to or file object.
        overwrite (bool, optional): Flag to overwrite, if output file already exist. Defaults to `False`.
        chunk_size (int, optional): Size of downloaded chunk. Defaults to `8192`.
        request_kwargs (dict[str, Any] | None, optional): Extra arguments passed to `requests.get` function. Defaults to `None`.

    Raises:
        FileExistsError: If `overwrite=False` and output file already exists.
    """
    file_object = _file_or_buffer(
        output_file=output_file,
        overwrite=overwrite,
    )

    if request_kwargs is None:
        request_kwargs = {}

    if "timeout" not in request_kwargs:
        request_kwargs["timeout"] = TIMEOUT

    with requests.get(url, stream=True, **request_kwargs) as requests_content:
        requests_content.raise_for_status()
        for chunk in requests_content.iter_content(chunk_size=chunk_size):
            file_object.write(chunk)


def download_file(
    url: str,
    output_file: str | BinaryIO,
    overwrite: bool = False,
    request_kwargs: dict[str, Any] | None = None,
) -> None:
    """Download file.

    Args:
        url (str): URL to download.
        output_file (str | BinaryIO): Filename to save object to or file object.
        overwrite (bool, optional): Flag to overwrite, if output file already exist. Defaults to `False`.
        request_kwargs (dict[str, Any] | None, optional): Extra arguments passed to `requests.get` function. Defaults to `None`.

    Raises:
        FileExistsError: If `overwrite=False` and output file already exists.
    """
    file_object = _file_or_buffer(
        output_file=output_file,
        overwrite=overwrite,
    )

    if request_kwargs is None:
        request_kwargs = {}

    if "timeout" not in request_kwargs:
        request_kwargs["timeout"] = TIMEOUT

    response = requests.get(url, **request_kwargs)
    response.raise_for_status()

    file_object.write(response.content)
