import os

from microarray.io._cdf import CdfFile, parse_cdf


def _get_cache_dir() -> str:
    """Returns the path to the cache directory for CDF files."""
    cache_dir = os.path.join(os.getcwd(), ".cache", "cdf")
    # os.makedirs(cache_dir, exist_ok=True)
    assert os.path.isdir(cache_dir), f"Cache directory not found: {cache_dir}"
    return cache_dir


def hgu133a_cdf() -> CdfFile:
    """Returns the CDF file for the hgu133a microarray platform."""
    cache_dir = _get_cache_dir()
    cdf_path = os.path.join(cache_dir, "GPL24120_HGU133A_Hs_ENTREZG.cdf.gz")

    if not os.path.isfile(cdf_path):
        # TODO: download from GEO if not found
        raise FileNotFoundError(f"CDF file not found: {cdf_path}")

    return parse_cdf(cdf_path)


def hgu133plus2_cdf() -> CdfFile:
    """Returns the CDF file for the hgu133plus2 microarray platform."""
    cache_dir = _get_cache_dir()
    cdf_path = os.path.join(cache_dir, "GPL22945_HGU133Plus2_Hs_ENTREZG.cdf.gz")

    if not os.path.isfile(cdf_path):
        # TODO: download from GEO if not found
        raise FileNotFoundError(f"CDF file not found: {cdf_path}")

    return parse_cdf(cdf_path)
