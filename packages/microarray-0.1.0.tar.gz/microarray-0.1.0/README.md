# microarray
Processing microarray data in Python


## Installation

Use `pip` to install the microarray package:

`pip install microarray`

## Usage

```python
import microarray as ma
```

See tutorial notebook for detailed workflow examples.

## License

MIT
