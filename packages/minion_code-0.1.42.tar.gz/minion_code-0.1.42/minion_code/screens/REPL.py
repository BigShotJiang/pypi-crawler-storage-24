"""
REPL Screen Implementation using Textual UI Components
Python equivalent of /Users/femtozheng/web-project/Kode/src/screens/REPL.tsx
Simulates React-like component structure as documented in AGENTS.md
"""

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import (
    Input,
    RichLog,
    Button,
    Static,
    Header,
    Footer,
    Label,
    TextArea,
)
from textual.reactive import reactive, var
from textual import on, work
from textual.screen import Screen
from rich.text import Text
from rich.syntax import Syntax
from rich.console import Console
import asyncio
import os
from typing import List, Dict, Any, Optional, Callable, Union, Set
from dataclasses import dataclass, field
from enum import Enum
import uuid
import time
from pathlib import Path

# Session storage imports
from ..utils.session_storage import (
    Session,
    create_session,
    save_session,
    load_session,
    get_latest_session_id,
    add_message as session_add_message,
    restore_agent_history,
)
from ..utils.conversation_runtime import ConversationRuntimeState

# No logging in UI components to reduce noise


# Import shared types
from ..type_defs import (
    MessageType,
    InputMode,
    MessageContent,
    Message as MessageData,
    ToolUseConfirm,
    BinaryFeedbackContext,
    ToolJSXContext,
    REPLConfig,
    ModelInfo,
)
from ..utils.step_status import humanize_step_status


class Logo(Static):
    """Logo component equivalent to React Logo component"""

    def __init__(
        self,
        mcp_clients=None,
        is_default_model=True,
        update_banner_version=None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.mcp_clients = mcp_clients or []
        self.is_default_model = is_default_model
        self.update_banner_version = update_banner_version

    def render(self) -> str:
        logo_text = "🤖 Minion Code Assistant"
        if self.update_banner_version:
            logo_text += f" (Update available: {self.update_banner_version})"
        return logo_text


class ModeIndicator(Static):
    """Mode indicator component"""

    def __init__(self, mode: InputMode = InputMode.PROMPT, **kwargs):
        super().__init__(**kwargs)
        self.mode = mode

    def render(self) -> str:
        return f"Mode: {self.mode.value.upper()}"


class Spinner(Static):
    """Simple loading spinner - just one line of animated text"""

    DEFAULT_CSS = """
    Spinner {
        color: $primary;
        text-style: italic;
        height: 1;
        margin: 1 0;
        padding: 0 1;
    }
    """

    def __init__(self, message: str = "Processing", **kwargs):
        super().__init__("⠋ Processing...", **kwargs)
        self.base_message = message
        self.spinner_chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        self.spinner_index = 0
        self._timer = None

    def on_mount(self):
        self._timer = self.set_interval(0.1, self.update_spinner)

    def on_unmount(self):
        if self._timer:
            self._timer.stop()

    def update_spinner(self):
        self.spinner_index = (self.spinner_index + 1) % len(self.spinner_chars)
        self.update(f"{self.spinner_chars[self.spinner_index]} {self.base_message}...")

    def set_message(self, message: str):
        """Update the spinner message"""
        self.base_message = message


class MessageWidget(Container):
    """Individual message display widget with streaming support"""

    def __init__(
        self, message: MessageData, verbose: bool = False, debug: bool = False, **kwargs
    ):
        super().__init__(**kwargs)
        self.message = message
        self.verbose = verbose
        self.debug = debug
        self.is_streaming = (
            message.options.get("streaming", False) if message.options else False
        )
        self.is_error = (
            message.options.get("error", False) if message.options else False
        )

    def compose(self) -> ComposeResult:
        content_text = self._get_content_text()

        if self.message.type == MessageType.USER:
            yield Static(f"👤 User:", classes="user-label")
            yield Static(content_text, classes="user-message")
        elif self.message.type == MessageType.ASSISTANT:
            if self.is_streaming:
                yield Static(
                    f"🤖 Assistant: ⠋ Thinking...", classes="assistant-streaming"
                )
            elif self.is_error:
                yield Static(f"❌ Assistant:", classes="assistant-error-label")
                yield Static(content_text, classes="assistant-error")
            else:
                yield Static(f"🤖 Assistant:", classes="assistant-label")
                # Handle markdown content
                if "```" in content_text or content_text.startswith("#"):
                    from rich.markdown import Markdown

                    yield Static(Markdown(content_text), classes="assistant-message")
                else:
                    yield Static(content_text, classes="assistant-message")
        elif self.message.type == MessageType.PROGRESS:
            yield Static(f"⚙️ Progress:", classes="progress-label")
            yield Static(content_text, classes="progress-message")

    def _get_content_text(self) -> str:
        if isinstance(self.message.message.content, str):
            return self.message.message.content
        elif isinstance(self.message.message.content, list):
            # Extract text from structured content
            text_parts = []
            for block in self.message.message.content:
                if isinstance(block, dict) and block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
            return "\n".join(text_parts)
        return str(self.message.message.content)

    def update_streaming_content(self, new_content: str):
        """Update streaming message content"""
        if self.is_streaming:
            try:
                # Update the message content
                self.message.message.content = new_content
                # Find and update the static widget
                static_widgets = self.query("Static")
                if len(static_widgets) > 1:
                    static_widgets[1].update(new_content)
            except Exception:
                pass  # Silently handle streaming update errors

    def finalize_streaming(self, final_content: str):
        """Finalize streaming message with final content"""
        if self.is_streaming:
            self.is_streaming = False
            self.message.options["streaming"] = False
            self.message.message.content = final_content
            # Refresh the entire widget
            self.refresh()


# Import components
from ..components.PromptInput import PromptInput
from ..components.Messages import Messages
from ..components.ConfirmDialog import (
    ConfirmDialog,
    ChoiceDialog,
    InputDialog,
    FormDialog,
)

# Import adapters
from ..adapters.textual_adapter import TextualOutputAdapter


class CostThresholdDialog(Container):
    """Cost threshold warning dialog"""

    def compose(self) -> ComposeResult:
        yield Static("⚠️ Cost Threshold Warning", classes="dialog-title")
        yield Static("You have exceeded $5 in API costs. Please be mindful of usage.")
        yield Button("Acknowledge", id="acknowledge_btn", variant="primary")


class PermissionRequest(Container):
    """Permission request dialog for tool usage"""

    def __init__(self, tool_use_confirm: ToolUseConfirm, **kwargs):
        super().__init__(**kwargs)
        self.tool_use_confirm = tool_use_confirm

    def compose(self) -> ComposeResult:
        yield Static(f"🔧 Tool Permission Request", classes="dialog-title")
        yield Static(f"Tool: {self.tool_use_confirm.tool_name}")
        yield Static(f"Parameters: {self.tool_use_confirm.parameters}")
        with Horizontal():
            yield Button("Allow", id="allow_btn", variant="success")
            yield Button("Deny", id="deny_btn", variant="error")

    @on(Button.Pressed, "#allow_btn")
    def allow_tool(self):
        self.tool_use_confirm.on_confirm()

    @on(Button.Pressed, "#deny_btn")
    def deny_tool(self):
        self.tool_use_confirm.on_abort()


class MessageSelector(Container):
    """Message selector for conversation forking"""

    def __init__(self, messages: List[MessageData], **kwargs):
        super().__init__(**kwargs)
        self.messages = messages

    def compose(self) -> ComposeResult:
        yield Static("📝 Select Message to Fork From", classes="dialog-title")
        with ScrollableContainer():
            for i, message in enumerate(self.messages[-10:]):  # Show last 10 messages
                content = self._get_message_preview(message)
                yield Button(f"{i}: {content[:50]}...", id=f"msg_{i}")
        yield Button("Cancel", id="cancel_selector", variant="error")

    def _get_message_preview(self, message: MessageData) -> str:
        if isinstance(message.message.content, str):
            return message.message.content
        return str(message.message.content)[:50]


class REPL(Container):
    """
    Main REPL Component - Python equivalent of React REPL component
    Manages the entire conversation interface with AI assistant
    """

    DEFAULT_CSS = """
    /* Message styling */
    .user-message {
        background: $surface-lighten-1;
        margin: 0 0 1 0;
        padding: 0 1;
        border: none;
    }
    
    .assistant-message {
        background: transparent;
        margin: 0 0 1 0;
        padding: 0;
        border: none;
    }
    
    .assistant-streaming {
        background: transparent;
        color: $text-muted;
        margin: 0 0 1 0;
        padding: 0;
        border: none;
        text-style: italic;
    }
    
    .assistant-error {
        background: red 20%;
        color: white;
        margin: 0 0 1 0;
        padding: 0 1;
        border-left: solid red;
    }
    
    .progress-message {
        background: $surface-lighten-1;
        color: $text;
        margin: 0 0 1 0;
        padding: 0 1;
        border-left: solid yellow;
    }
    
    .dialog-title {
        text-style: bold;
        content-align: center middle;
        margin: 1;
        background: cyan 30%;
        color: black;
    }
    
    #messages_container {
        height: 1fr;
        margin: 0;
        scrollbar-background: gray 50%;
        scrollbar-color: white;
    }
    
    #main_input {
        width: 1fr;
        margin-right: 1;
        border: solid white;
        dock: bottom;
    }
    
    /* PromptInput component styles */
    .model-info {
        
        height: 1;
        content-align: right middle;
        color: white;
        margin-bottom: 1;
    }
    
    #input_container {
        margin: 1;
        padding: 1;
    }
    
    #mode_prefix {
        width: 3;
        content-align: center middle;
        text-style: bold;
    }
    
    .mode-bash #mode_prefix {
        color: yellow;
    }
    
    .mode-memory #mode_prefix {
        color: cyan;
    }
    
    #status_area {
        dock: bottom;
        height: 2;
        margin: 1;
    }
    
    .status-message {
        color: white;
        text-style: dim;
    }
    
    .model-switch-message {
        color: green;
        text-style: bold;
    }
    
    .help-text {
        margin-right: 0;
        margin-top: 0;
        margin-bottom: 0;
    }
    
    .help-text.active {
        color: white;
        text-style: bold;
    }
    
    .help-text.inactive {
        color: gray;
        text-style: dim;
    }
    
    Button {
        margin: 1;
    }
    
    Input {
        border: solid white;
    }
    

    """

    # Reactive properties equivalent to React useState
    fork_number = reactive(0)
    is_loading = reactive(False)  # Recompose when loading state changes
    messages = var(list)  # List[MessageData]
    input_value = reactive("")
    input_mode = reactive(InputMode.PROMPT)
    submit_count = reactive(0)
    is_message_selector_visible = reactive(
        False, recompose=True
    )  # Recompose when selector visibility changes
    show_cost_dialog = reactive(
        False, recompose=True
    )  # Recompose when dialog visibility changes
    have_shown_cost_dialog = reactive(False)
    should_show_prompt_input = reactive(True, recompose=True)

    def __init__(
        self,
        commands=None,
        safe_mode=False,
        debug=False,
        initial_fork_number=0,
        initial_prompt=None,
        message_log_name="default",
        should_show_prompt_input=True,
        tools=None,
        verbose=False,
        initial_messages=None,
        mcp_clients=None,
        is_default_model=True,
        initial_update_version=None,
        initial_update_commands=None,
        agent=None,  # Agent passed from app level
        resume_session_id=None,  # Session ID to resume
        continue_last=False,  # Continue most recent session
        **kwargs,
    ):
        super().__init__(**kwargs)

        # Props equivalent to TypeScript Props interface
        self.commands = commands or []
        self.safe_mode = safe_mode
        self.debug = debug
        self.initial_fork_number = initial_fork_number
        self.initial_prompt = initial_prompt
        print(f"DEBUG REPL.__init__: initial_prompt={initial_prompt}")
        self.message_log_name = message_log_name
        self.tools = tools or []
        self.verbose = verbose
        self.mcp_clients = mcp_clients or []
        self.is_default_model = is_default_model
        self.initial_update_version = initial_update_version
        self.initial_update_commands = initial_update_commands

        # Session management
        self.resume_session_id = resume_session_id
        self.continue_last = continue_last
        self.session: Optional[Session] = None

        # Initialize state
        self.messages = initial_messages or []
        print(f"DEBUG: REPL initialized with {len(self.messages)} messages")
        self.fork_number = initial_fork_number
        self.should_show_prompt_input = should_show_prompt_input

        # Agent from app level
        self.agent = agent

        # Internal state
        self.config = REPLConfig()
        self.abort_controller = None
        self.tool_jsx: Optional[ToolJSXContext] = None
        self.tool_use_confirm: Optional[ToolUseConfirm] = None
        self.binary_feedback_context: Optional[BinaryFeedbackContext] = None
        self.read_file_timestamps: Dict[str, float] = {}
        self.fork_convo_with_messages_on_next_render: Optional[List[MessageData]] = None

        # Output adapter for command execution
        self.output_adapter = TextualOutputAdapter(on_output=self.handle_command_output)
        self.active_dialog: Optional[Container] = None
        self.runtime_state = ConversationRuntimeState()

    def _create_test_messages(self) -> List[MessageData]:
        """Create some test messages for development/testing"""
        import time

        test_messages = []

        # Welcome message from assistant
        test_messages.append(
            MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(
                    "👋 Welcome to Minion Code Assistant! I'm here to help you with coding tasks, file operations, and more. What would you like to work on today?"
                ),
                timestamp=time.time() - 120,
                options={},
            )
        )

        # Example user message
        test_messages.append(
            MessageData(
                type=MessageType.USER,
                message=MessageContent(
                    "Can you help me understand how to use this REPL interface?"
                ),
                timestamp=time.time() - 100,
                options={},
            )
        )

        # Example assistant response with code
        test_messages.append(
            MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(
                    """Absolutely! Here's how to use the REPL interface:

## Input Modes
- **Prompt mode** (`>`): Regular conversation with the AI assistant
- **Bash mode** (`!`): Execute shell commands directly
- **Memory mode** (`#`): Add notes or generate content for AGENTS.md

## Keyboard Shortcuts
- `Enter`: Submit your message
- `Ctrl+Enter`, `Tab`, or `Ctrl+J`: Add a new line
- `Escape`: Switch modes or show message selector
- `Shift+M`: Quick model switching

## Examples
```bash
# Bash mode - execute commands
!ls -la

# Memory mode - add to AGENTS.md
#Create a new Python function for data processing

# Regular prompt
How do I implement error handling in Python?
```

Try typing something to get started!"""
                ),
                timestamp=time.time() - 80,
                options={},
            )
        )

        return test_messages

    def compose(self) -> ComposeResult:
        """Compose the REPL interface - equivalent to React render method"""
        with Vertical():
            # Logo at the top
            yield Logo(
                mcp_clients=self.mcp_clients,
                is_default_model=self.is_default_model,
                update_banner_version=self.initial_update_version,
            )

            # Messages container (main content area) - takes remaining space
            print(
                f"DEBUG: REPL.compose() creating Messages component with {len(self.messages)} messages"
            )
            yield Messages(
                messages=self.messages,
                tools=self.tools,
                verbose=self.verbose,
                debug=self.debug,
                id="messages_container",
            )

            # Loading indicator - simple one-line text with animation
            if self.is_loading:
                yield Spinner(message="Assistant is thinking")

            # Other dynamic content (dialogs, etc.) - also between Messages and PromptInput
            # Tool JSX (equivalent to {toolJSX ? toolJSX.jsx : null})
            if self.tool_jsx and self.tool_jsx.jsx:
                yield self.tool_jsx.jsx

            # Binary feedback (equivalent to BinaryFeedback component)
            if self.binary_feedback_context and not self.is_message_selector_visible:
                yield Static("🔄 Binary feedback component would render here")

            # Permission request (equivalent to PermissionRequest component)
            if (
                self.tool_use_confirm
                and not self.is_message_selector_visible
                and not self.binary_feedback_context
            ):
                yield PermissionRequest(self.tool_use_confirm)

            # Cost dialog (equivalent to CostThresholdDialog component)
            if self.show_cost_dialog and not self.is_loading:
                yield CostThresholdDialog()

            # Message selector (equivalent to {isMessageSelectorVisible && <MessageSelector />})
            if self.is_message_selector_visible:
                yield MessageSelector(messages=self.messages)

            # PromptInput component at the bottom (dock: bottom)
            if self.should_show_prompt_input:
                prompt_input = PromptInput(
                    commands=self.commands,
                    fork_number=self.fork_number,
                    message_log_name=self.message_log_name,
                    is_disabled=False,
                    is_loading=self.is_loading,
                    debug=self.debug,
                    verbose=self.verbose,
                    messages=self.messages,
                    tools=self.tools,
                    input_value=self.input_value,
                    mode=self.input_mode,
                    submit_count=self.submit_count,
                    read_file_timestamps=self.read_file_timestamps,
                    abort_controller=self.abort_controller,
                )

                # Set up callbacks
                prompt_input.on_query = self.on_query_from_prompt
                prompt_input.on_add_user_message = (
                    self.on_add_user_message_from_prompt
                )  # New immediate display callback
                prompt_input.on_input_change = self.on_input_change_from_prompt
                prompt_input.on_mode_change = self.on_mode_change_from_prompt
                prompt_input.on_submit_count_change = (
                    self.on_submit_count_change_from_prompt
                )
                prompt_input.set_is_loading = self.set_loading_from_prompt
                prompt_input.set_abort_controller = (
                    self.set_abort_controller_from_prompt
                )
                prompt_input.on_show_message_selector = self.show_message_selector
                prompt_input.set_fork_convo_with_messages = self.set_fork_convo_messages
                prompt_input.on_model_change = self.on_model_change_from_prompt
                prompt_input.set_tool_jsx = self.set_tool_jsx_from_prompt
                prompt_input.on_interrupt = self.on_interrupt_from_prompt
                prompt_input.on_execute_command = (
                    self.on_execute_command_from_prompt
                )  # Command execution callback

                yield prompt_input

    def on_mount(self):
        """Component lifecycle - equivalent to React useEffect(() => { onInit() }, [])"""
        # Initialize session
        self._init_session()
        self.call_later(self.on_init)
        # Set focus to the input after a short delay to ensure it's mounted
        self.set_timer(0.1, self._set_focus_to_input)

    def _init_session(self):
        """Initialize or restore session."""
        current_project = os.getcwd()

        # Try to restore session if requested
        if self.resume_session_id:
            self.session = load_session(self.resume_session_id)
            if self.session:
                print(
                    f"DEBUG: Restored session {self.resume_session_id} with {len(self.session.messages)} messages"
                )
                # Restore messages to UI
                self._restore_ui_messages_from_session()
            else:
                print(
                    f"DEBUG: Session {self.resume_session_id} not found, creating new"
                )
                self.session = create_session(current_project)
        elif self.continue_last:
            latest_id = get_latest_session_id(project_path=current_project)
            if latest_id:
                self.session = load_session(latest_id)
                if self.session:
                    print(
                        f"DEBUG: Continuing session {latest_id} with {len(self.session.messages)} messages"
                    )
                    # Restore messages to UI
                    self._restore_ui_messages_from_session()
                else:
                    self.session = create_session(current_project)
            else:
                self.session = create_session(current_project)
        else:
            # Create new session
            self.session = create_session(current_project)
            print(f"DEBUG: Created new session {self.session.metadata.session_id}")

    def _restore_ui_messages_from_session(self):
        """Restore UI messages from session."""
        if not self.session or not self.session.messages:
            return

        # Clear existing UI messages first
        self.messages.clear()

        # Convert session messages to MessageData for UI display
        for msg in self.session.messages:
            msg_type = MessageType.USER if msg.role == "user" else MessageType.ASSISTANT
            ui_message = MessageData(
                type=msg_type, message=MessageContent(msg.content), options={}
            )
            self.messages.append(ui_message)

        print(f"DEBUG: Restored {len(self.session.messages)} messages to UI")

    def _save_message_to_session(self, role: str, content: str):
        """Save a message to the current session."""
        if self.session:
            session_add_message(self.session, role, content, auto_save=True)
            if self.verbose:
                print(
                    f"DEBUG: Saved {role} message to session {self.session.metadata.session_id}"
                )

    def _set_focus_to_input(self):
        """Set focus to the main input widget"""
        try:
            # Try to find the main TextArea input
            input_widget = self.query_one("#main_input", expect_type=TextArea)
            input_widget.focus()
        except Exception:
            # If that fails, try to focus any TextArea or Input widget
            try:
                text_areas = self.query("TextArea")
                if text_areas:
                    text_areas[0].focus()
                else:
                    inputs = self.query("Input")
                    if inputs:
                        inputs[0].focus()
            except Exception:
                pass  # Silently handle focus errors

    async def on_init(self):
        """Initialize REPL - equivalent to React onInit function"""
        # Initial prompt processing moved to set_agent to ensure agent is ready
        pass

    @work(exclusive=False)
    async def _start_initial_prompt_worker(self):
        """Worker to process initial prompt."""
        print("DEBUG: _start_initial_prompt_worker started")
        await self._process_initial_prompt()

    async def _process_initial_prompt(self):
        """Process the initial prompt after agent is ready."""
        print(
            f"DEBUG _process_initial_prompt called: prompt={self.initial_prompt}, agent={self.agent}"
        )
        if not self.initial_prompt or not self.agent:
            print("DEBUG: Skipping - no prompt or no agent")
            return

        self.is_loading = True
        prompt_to_process = self.initial_prompt
        # Clear immediately to prevent re-processing
        self.initial_prompt = None

        try:
            print(f"DEBUG: Processing prompt: {prompt_to_process}")
            # Process initial prompt (equivalent to processUserInput)
            new_messages = await self.process_user_input(
                prompt_to_process, self.input_mode
            )
            print(f"DEBUG: Got {len(new_messages) if new_messages else 0} new messages")

            if new_messages:
                # Add to history (equivalent to addToHistory)
                self.add_to_history(prompt_to_process)

                # Update messages (equivalent to setMessages)
                self.messages = [*self.messages, *new_messages]

                # Update UI
                try:
                    messages_component = self.query_one(
                        "#messages_container", expect_type=Messages
                    )
                    messages_component.update_messages(self.messages)
                except Exception:
                    self.refresh()

                # Query API (equivalent to query function)
                print("DEBUG: Calling query_api")
                await self._process_prompt_batch(new_messages)
                print("DEBUG: query_api completed")

        except Exception as e:
            print(f"DEBUG: Error processing initial prompt: {e}")
            import traceback

            traceback.print_exc()
        finally:
            self.is_loading = False

    async def process_user_input(
        self, input_text: str, mode: InputMode
    ) -> List[MessageData]:
        """Process user input - equivalent to processUserInput function"""

        # Create user message
        user_message = MessageData(
            type=MessageType.USER,
            message=MessageContent(input_text),
            options={"isMemoryRequest": mode == InputMode.MEMORY},
        )

        # Handle different input modes
        if mode == InputMode.BASH:
            # Handle bash command
            result = await self.execute_bash_command(input_text)
            assistant_message = MessageData(
                type=MessageType.ASSISTANT, message=MessageContent(result)
            )
            return [user_message, assistant_message]
        elif mode == InputMode.MEMORY:
            # Handle memory request
            return [user_message]
        else:
            # Handle regular prompt
            return [user_message]

    async def execute_bash_command(self, command: str) -> str:
        """Execute bash command - simplified version"""
        try:
            import subprocess

            result = subprocess.run(
                command, shell=True, capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                return result.stdout or "Command executed successfully"
            else:
                return f"Error: {result.stderr}"
        except Exception as e:
            return f"Error executing command: {str(e)}"

    def _get_message_mode(self, message: MessageData) -> InputMode:
        """Extract the input mode from a user message."""
        mode_value = (
            message.options.get("mode")
            if message.options and isinstance(message.options, dict)
            else None
        )
        if not mode_value:
            return InputMode.PROMPT

        try:
            return InputMode(mode_value)
        except ValueError:
            return InputMode.PROMPT

    async def _process_special_mode_batch(
        self, messages: List[MessageData], mode: InputMode
    ) -> None:
        """Process bash and memory submissions through the shared message pipeline."""
        if not messages:
            return

        user_message = messages[-1]
        raw_content = user_message.message.content
        input_text = raw_content if isinstance(raw_content, str) else str(raw_content)

        if mode == InputMode.BASH:
            command = input_text[1:].strip() if input_text.startswith("!") else input_text
            result = await self.execute_bash_command(command)
            assistant_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(result),
                options={"mode": mode.value},
            )
            self.messages = [*self.messages, assistant_message]
            self._save_message_to_session("assistant", result)
            self._refresh_messages()
            return

        if mode != InputMode.MEMORY:
            return

        content = input_text[1:].strip() if input_text.startswith("#") else input_text
        if not content:
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent("❌ Memory input is empty."),
                options={"error": True},
            )
            self.messages = [*self.messages, error_message]
            self._save_message_to_session("assistant", "❌ Memory input is empty.")
            self._refresh_messages()
            return

        action_words = ["put", "create", "generate", "write", "give", "provide"]
        if any(word in content.lower() for word in action_words):
            await self.query_api(
                [
                    MessageData(
                        type=MessageType.USER,
                        message=MessageContent(content),
                        options={"isMemoryRequest": True, "mode": mode.value},
                    )
                ],
                manage_loading=False,
            )
            return

        try:
            agents_md_path = Path("AGENTS.md")
            if not agents_md_path.exists():
                with open(agents_md_path, "w", encoding="utf-8") as f:
                    f.write("# Agent Development Guidelines\n\n")

            with open(agents_md_path, "a", encoding="utf-8") as f:
                f.write(f"\n\n{content}\n")

            result = "✅ Memory added to AGENTS.md"
            assistant_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(result),
                options={"mode": mode.value},
            )
            self.messages = [*self.messages, assistant_message]
            self._save_message_to_session("assistant", result)
            self._refresh_messages()
        except Exception as e:
            error_text = f"❌ Failed to write memory to AGENTS.md: {e}"
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(error_text),
                options={"error": True},
            )
            self.messages = [*self.messages, error_message]
            self._save_message_to_session("assistant", error_text)
            self._refresh_messages()

    def set_agent(self, agent):
        """Set agent from app level and bind output adapter"""
        print(f"DEBUG set_agent: agent={agent}, initial_prompt={self.initial_prompt}")
        self.agent = agent
        # Bind output adapter to agent if it supports confirmation
        if hasattr(agent, "set_output_adapter"):
            agent.set_output_adapter(self.output_adapter)
        if hasattr(agent, "set_runtime_state"):
            agent.set_runtime_state(self.runtime_state)

        # Restore agent history from session if resuming
        if self.session and self.session.messages:
            restore_agent_history(agent, self.session, self.verbose)

        # Process initial prompt now that agent is ready
        if self.initial_prompt:
            print(f"DEBUG: Triggering initial prompt processing: {self.initial_prompt}")
            # Start the worker to process initial prompt
            self.abort_controller = self._start_initial_prompt_worker()

    def handle_command_output(self, output_type: str, data: dict):
        """Handle output from command execution via adapter"""
        if output_type == "panel":
            self.display_panel_output(data)
        elif output_type == "table":
            self.display_table_output(data)
        elif output_type == "text":
            self.display_text_output(data)
        elif output_type == "confirm":
            self.show_confirm_dialog(data)
        elif output_type == "choice":
            self.show_choice_dialog(data)
        elif output_type == "input":
            self.show_input_dialog(data)
        elif output_type == "form":
            self.show_form_dialog(data)

    def display_panel_output(self, data: dict):
        """Display panel output as a message"""
        content = (
            f"{data.get('title', '')}\n\n{data['content']}"
            if data.get("title")
            else data["content"]
        )
        message = MessageData(
            type=MessageType.ASSISTANT,
            message=MessageContent(content),
            options={"border_style": data.get("border_style", "blue")},
        )
        self.messages = [*self.messages, message]
        self._refresh_messages()

    def display_table_output(self, data: dict):
        """Display table output as formatted text"""
        # Format table as text
        headers = data.get("headers", [])
        rows = data.get("rows", [])
        title = data.get("title", "")

        lines = []
        if title:
            lines.append(f"=== {title} ===\n")

        if headers:
            lines.append(" | ".join(headers))
            lines.append("-" * (len(" | ".join(headers))))

        for row in rows:
            lines.append(" | ".join(str(cell) for cell in row))

        content = "\n".join(lines)
        message = MessageData(
            type=MessageType.ASSISTANT, message=MessageContent(content), options={}
        )
        self.messages = [*self.messages, message]
        self._refresh_messages()

    def display_text_output(self, data: dict):
        """Display plain text output"""
        message = MessageData(
            type=MessageType.ASSISTANT,
            message=MessageContent(data["content"]),
            options={"style": data.get("style", "")},
        )
        self.messages = [*self.messages, message]
        self._refresh_messages()

    def show_confirm_dialog(self, data: dict):
        """Show confirmation dialog"""
        if self.active_dialog:
            self.active_dialog.remove()

        self.active_dialog = ConfirmDialog(
            interaction_id=data["interaction_id"],
            message=data["message"],
            title=data.get("title", "Confirm"),
            ok_text=data.get("ok_text", "Yes"),
            cancel_text=data.get("cancel_text", "No"),
            on_result=self.handle_confirm_result,
        )
        self.mount(self.active_dialog)

    def show_choice_dialog(self, data: dict):
        """Show choice selection dialog"""
        if self.active_dialog:
            self.active_dialog.remove()

        self.active_dialog = ChoiceDialog(
            interaction_id=data["interaction_id"],
            message=data["message"],
            choices=data["choices"],
            title=data.get("title", "Select"),
            on_result=self.handle_choice_result,
        )
        self.mount(self.active_dialog)

    def show_input_dialog(self, data: dict):
        """Show text input dialog"""
        if self.active_dialog:
            self.active_dialog.remove()

        self.active_dialog = InputDialog(
            interaction_id=data["interaction_id"],
            message=data["message"],
            title=data.get("title", "Input"),
            default=data.get("default", ""),
            placeholder=data.get("placeholder", ""),
            on_result=self.handle_input_result,
        )
        self.mount(self.active_dialog)

    def show_form_dialog(self, data: dict):
        """Show structured form dialog."""
        if self.active_dialog:
            self.active_dialog.remove()

        self.active_dialog = FormDialog(
            interaction_id=data["interaction_id"],
            message=data.get("message", ""),
            fields=data.get("fields", []),
            title=data.get("title", "Form"),
            submit_text=data.get("submit_text", "Submit"),
            on_result=self.handle_form_result,
        )
        self.mount(self.active_dialog)

    def handle_confirm_result(self, interaction_id: str, result: bool):
        """Handle confirmation dialog result"""
        self.output_adapter.resolve_interaction(interaction_id, result)
        self.active_dialog = None

    def handle_choice_result(self, interaction_id: str, result: int):
        """Handle choice dialog result"""
        self.output_adapter.resolve_interaction(interaction_id, result)
        self.active_dialog = None

    def handle_input_result(self, interaction_id: str, result: Optional[str]):
        """Handle input dialog result"""
        self.output_adapter.resolve_interaction(interaction_id, result)
        self.active_dialog = None

    def handle_form_result(self, interaction_id: str, result: Optional[dict]):
        """Handle structured form result."""
        self.output_adapter.resolve_interaction(interaction_id, result)
        self.active_dialog = None

    def _refresh_messages(self):
        """Helper to refresh messages component"""
        try:
            messages_component = self.query_one("#messages_container", Messages)
            messages_component.update_messages(self.messages)
        except Exception:
            self.refresh()

    async def query_api(
        self, new_messages: List[MessageData], manage_loading: bool = True
    ):
        """Query the AI API with streaming support - equivalent to query function"""

        if not new_messages or new_messages[-1].type != MessageType.USER:
            return

        user_content = new_messages[-1].message.content

        # Check if agent is available
        if not self.agent:
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent("❌ Agent not initialized yet. Please wait..."),
                options={"error": True},
            )
            self.messages = [*self.messages, error_message]
            return

        try:
            # Set loading state with immediate UI feedback
            if manage_loading:
                self.is_loading = True

            # Add a temporary "thinking" message to show immediate feedback
            thinking_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent("🤔 Thinking..."),
                options={"streaming": True, "temporary": True},
            )
            self.messages = [*self.messages, thinking_message]

            # Update Messages component immediately
            try:
                messages_component = self.query_one(
                    "#messages_container", expect_type=Messages
                )
                messages_component.update_messages(self.messages)
            except Exception:
                self.refresh()  # Fallback to full refresh

            # Process with agent - check if it supports streaming
            try:
                if hasattr(self.agent, "run_async"):
                    # Try to use streaming if supported
                    try:
                        # Attempt streaming response with granular event handling
                        response_content = ""
                        current_status = ""

                        async for chunk in await self.agent.run_async(
                            user_content, stream=True
                        ):
                            chunk_type = getattr(chunk, "chunk_type", "text")
                            chunk_content = getattr(chunk, "content", str(chunk))
                            chunk_metadata = getattr(chunk, "metadata", {})

                            # Handle different chunk types
                            if chunk_type == "step_start":
                                # Show step indicator
                                current_status = f"🔄 {humanize_step_status(chunk_content)}"
                                status_message = MessageData(
                                    type=MessageType.PROGRESS,
                                    message=MessageContent(current_status),
                                    options={"streaming": True, "step_start": True},
                                )
                                self.messages = [*self.messages[:-1], status_message]

                            elif chunk_type == "thinking":
                                # Accumulate thinking content (LLM response)
                                response_content += chunk_content
                                streaming_message = MessageData(
                                    type=MessageType.ASSISTANT,
                                    message=MessageContent(
                                        f"{current_status}\n\n{response_content}"
                                        if current_status
                                        else response_content
                                    ),
                                    options={"streaming": True},
                                )
                                self.messages = [*self.messages[:-1], streaming_message]

                            elif chunk_type == "code_start":
                                # Show code execution indicator
                                code_preview = chunk_metadata.get(
                                    "code_preview", chunk_content[:100]
                                )
                                exec_status = f"⚙️ Executing code...\n```python\n{code_preview}\n```"
                                code_message = MessageData(
                                    type=MessageType.PROGRESS,
                                    message=MessageContent(
                                        f"{response_content}\n\n{exec_status}"
                                    ),
                                    options={"streaming": True, "code_executing": True},
                                )
                                self.messages = [*self.messages[:-1], code_message]

                            elif chunk_type == "code_result":
                                # Show code execution result
                                success = chunk_metadata.get("success", True)
                                if success:
                                    result_status = (
                                        f"✅ Code executed:\n{chunk_content}"
                                    )
                                else:
                                    result_status = (
                                        f"❌ Execution error:\n{chunk_content}"
                                    )

                                result_message = MessageData(
                                    type=MessageType.ASSISTANT,
                                    message=MessageContent(
                                        f"{response_content}\n\n{result_status}"
                                    ),
                                    options={"streaming": True, "code_result": True},
                                )
                                self.messages = [*self.messages[:-1], result_message]

                            elif chunk_type in (
                                "agent_response",
                                "final_answer",
                                "completion",
                            ):
                                # Final response - extract answer
                                final_content = (
                                    getattr(chunk, "answer", chunk_content)
                                    or chunk_content
                                )
                                response_content = str(final_content)
                                final_message = MessageData(
                                    type=MessageType.ASSISTANT,
                                    message=MessageContent(response_content),
                                    options={"streaming": True},
                                )
                                self.messages = [*self.messages[:-1], final_message]

                            else:
                                # Default: accumulate as text
                                response_content += chunk_content
                                streaming_message = MessageData(
                                    type=MessageType.ASSISTANT,
                                    message=MessageContent(response_content),
                                    options={"streaming": True},
                                )
                                self.messages = [*self.messages[:-1], streaming_message]

                            # Update UI
                            try:
                                messages_component = self.query_one(
                                    "#messages_container", expect_type=Messages
                                )
                                messages_component.update_messages(self.messages)
                            except Exception:
                                self.refresh()  # Fallback to full refresh

                        # Finalize the streaming message
                        final_message = MessageData(
                            type=MessageType.ASSISTANT,
                            message=MessageContent(response_content),
                            options={},  # Remove streaming flag
                        )
                        self.messages = [*self.messages[:-1], final_message]
                        messages_component = self.query_one(
                            "#messages_container", expect_type=Messages
                        )
                        messages_component.update_messages(self.messages)

                        # Save assistant response to session
                        if response_content:
                            self._save_message_to_session("assistant", response_content)

                    except Exception as e:
                        raise
                else:
                    # Agent doesn't support async, show error
                    error_message = MessageData(
                        type=MessageType.ASSISTANT,
                        message=MessageContent(
                            "❌ Agent does not support async operations"
                        ),
                        options={"error": True},
                    )
                    self.messages = [*self.messages[:-1], error_message]

                # Handle Memory mode special case
                if new_messages[-1].options and new_messages[-1].options.get(
                    "isMemoryRequest"
                ):
                    await self.handle_memory_response(self.messages[-1])

            except Exception as e:
                # Format error message for UI display
                error_text = self._format_error_for_ui(e)

                error_message = MessageData(
                    type=MessageType.ASSISTANT,
                    message=MessageContent(error_text),
                    options={"error": True},
                )
                # Replace thinking message with error
                self.messages = [*self.messages[:-1], error_message]

                # Update Messages component
                try:
                    messages_component = self.query_one(
                        "#messages_container", expect_type=Messages
                    )
                    messages_component.update_messages(self.messages)
                except Exception:
                    self.refresh()  # Fallback to full refresh

        except Exception as e:
            # Show error message to user
            error_text = self._format_error_for_ui(e)
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(error_text),
                options={"error": True},
            )

            # Replace thinking/streaming message with error
            if self.messages and (
                self.messages[-1].options.get("streaming")
                or self.messages[-1].options.get("temporary")
            ):
                self.messages = [*self.messages[:-1], error_message]
            else:
                self.messages = [*self.messages, error_message]

            # Update Messages component
            try:
                messages_component = self.query_one(
                    "#messages_container", expect_type=Messages
                )
                messages_component.update_messages(self.messages)
            except Exception:
                self.refresh()  # Fallback to full refresh

        finally:
            if manage_loading:
                self.is_loading = False

            # Final UI update to remove loading indicators
            try:
                messages_component = self.query_one(
                    "#messages_container", expect_type=Messages
                )
                messages_component.update_messages(self.messages)
            except Exception:
                self.refresh()  # Fallback to full refresh

    async def _process_prompt_batch(self, initial_messages: List[MessageData]):
        """Process the current prompt and any buffered prompts sequentially."""
        async with self.runtime_state.processing_lock:
            self.is_loading = True
            try:
                pending_messages: List[List[MessageData]] = [initial_messages]

                while pending_messages:
                    current_messages = pending_messages.pop(0)
                    last_message = current_messages[-1] if current_messages else None
                    mode = (
                        self._get_message_mode(last_message)
                        if last_message is not None
                        else InputMode.PROMPT
                    )

                    if mode in (InputMode.BASH, InputMode.MEMORY):
                        await self._process_special_mode_batch(current_messages, mode)
                    else:
                        await self.query_api(current_messages, manage_loading=False)

                    while True:
                        queued_prompt = self.runtime_state.pop_prompt()
                        if queued_prompt is None:
                            break

                        pending_messages.append(
                            [
                                MessageData(
                                    type=MessageType.USER,
                                    message=MessageContent(queued_prompt.content),
                                    options=queued_prompt.metadata.get("options", {}),
                                )
                            ]
                        )
            finally:
                self.is_loading = False
                self._refresh_messages()

    async def handle_memory_response(self, assistant_message: MessageData):
        """Handle Memory mode response - equivalent to handleHashCommand"""

        content = assistant_message.message.content
        if isinstance(content, str) and content.strip():
            # Save to AGENTS.md (equivalent to handleHashCommand)
            try:
                agents_md_path = Path("AGENTS.md")
                if agents_md_path.exists():
                    with open(agents_md_path, "a") as f:
                        f.write(
                            f"\n\n## Response - {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                        )
                        f.write(content)
                        f.write("\n")
            except Exception:
                pass  # Silently handle file write errors

    def add_to_history(self, command: str):
        """Add command to history - equivalent to addToHistory"""
        # This would integrate with the history system
        pass

    def on_cancel(self):
        """Cancel current operation - equivalent to onCancel function"""
        if not self.is_loading:
            return

        self.is_loading = False
        self.loading = False

        if self.tool_use_confirm:
            self.tool_use_confirm.on_abort()
        elif self.abort_controller:
            self.abort_controller.cancel()

        dropped_prompts = self.runtime_state.clear_pending_prompts()
        message_text = "Interrupted current task."
        if dropped_prompts:
            message_text += f" Discarded {dropped_prompts} buffered prompt(s)."
        self.messages = [
            *self.messages,
            MessageData(
                type=MessageType.PROGRESS,
                message=MessageContent(message_text),
                options={"interrupted": True},
            ),
        ]
        self._refresh_messages()

    # Callback methods for PromptInput component
    def on_add_user_message_from_prompt(self, user_message: MessageData):
        """Handle immediate user message display (synchronous)"""
        # 立即显示用户消息 - 同步操作，不等待任何异步处理
        self.messages = [*self.messages, user_message]

        # Save user message to session
        user_content = user_message.message.content
        if isinstance(user_content, str):
            self._save_message_to_session("user", user_content)

        # 立即更新UI显示用户消息
        try:
            messages_component = self.query_one(
                "#messages_container", expect_type=Messages
            )
            messages_component.update_messages(self.messages)
        except Exception:
            self.refresh()  # Fallback to full refresh

    async def on_query_from_prompt(
        self, messages: List[MessageData], abort_controller=None
    ):
        """Handle AI query processing (user message already displayed)"""
        # 用户消息已经通过 on_add_user_message_from_prompt 显示了
        # 这里只处理AI响应
        user_message = messages[-1] if messages else None
        if (
            user_message
            and (self.runtime_state.is_processing or self.is_loading)
            and isinstance(user_message.message.content, str)
        ):
            queue_size = self.runtime_state.queue_prompt(
                user_message.message.content,
                metadata={"options": user_message.options or {}},
            )
            queued_message = MessageData(
                type=MessageType.PROGRESS,
                message=MessageContent(
                    f"Buffered prompt queued. {queue_size} pending."
                ),
                options={"buffered_prompt": True},
            )
            self.messages = [*self.messages, queued_message]
            self._refresh_messages()
            return

        self.is_loading = True
        self.abort_controller = self.run_worker(
            self._process_ai_response(messages, abort_controller), exclusive=False
        )

    async def _process_ai_response(
        self, user_messages: List[MessageData], abort_controller=None
    ):
        """Process AI response in background worker"""
        try:
            await self._process_prompt_batch(user_messages)

        except asyncio.CancelledError:
            return
        except Exception as e:
            # Handle errors in background processing
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(f"❌ Error processing request: {str(e)}"),
                options={"error": True},
            )
            self.messages = [*self.messages, error_message]

            # Update UI with error
            try:
                messages_component = self.query_one(
                    "#messages_container", expect_type=Messages
                )
                messages_component.update_messages(self.messages)
            except Exception:
                self.refresh()

            # Clear loading state on error
            self.is_loading = False
        finally:
            self.abort_controller = None

    def on_input_change_from_prompt(self, value: str):
        """Handle input change from PromptInput"""
        self.input_value = value

    def on_mode_change_from_prompt(self, mode: InputMode):
        """Handle mode change from PromptInput"""
        self.input_mode = mode

    def on_submit_count_change_from_prompt(self, updater):
        """Handle submit count change from PromptInput"""
        if callable(updater):
            self.submit_count = updater(self.submit_count)
        else:
            self.submit_count = updater

    def set_loading_from_prompt(self, is_loading: bool):
        """Set loading state from PromptInput"""
        self.is_loading = is_loading

    def set_abort_controller_from_prompt(self, controller):
        """Set abort controller from PromptInput"""
        self.abort_controller = controller

    def on_interrupt_from_prompt(self):
        """Handle the double-Esc interrupt gesture from the prompt input."""
        self.on_cancel()

    def show_message_selector(self):
        """Show message selector from PromptInput"""
        self.is_message_selector_visible = True

    def set_fork_convo_messages(self, messages: List[MessageData]):
        """Set fork conversation messages from PromptInput"""
        self.fork_convo_with_messages_on_next_render = messages

    def on_model_change_from_prompt(self):
        """Handle model change from PromptInput"""
        self.fork_number += 1

    def set_tool_jsx_from_prompt(self, tool_jsx):
        """Set tool JSX from PromptInput"""
        self.tool_jsx = tool_jsx

    async def on_execute_command_from_prompt(self, command_name: str, args: str):
        """
        Execute a slash command (e.g., /clear, /help, /tools).
        Handles different command types:
        - LOCAL: Direct execution, returns result immediately
        - LOCAL_JSX: Requires UI interaction (dialogs, confirmations)
        - PROMPT: Replaces user input and sends to LLM for processing
        """
        from minion_code.commands import command_registry, CommandType

        # Get command class from registry
        command_class = command_registry.get_command(command_name)

        if not command_class:
            # Unknown command - show error
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(
                    f"❌ Unknown command: /{command_name}\n💡 Use '/help' to see available commands"
                ),
                options={"error": True},
            )
            self.messages = [*self.messages, error_message]
            self._refresh_messages()
            return

        # Handle different command types
        command_type = getattr(command_class, "command_type", CommandType.LOCAL)
        is_skill = getattr(command_class, "is_skill", False)

        if command_type == CommandType.PROMPT:
            # PROMPT type: Replace user input and send to LLM
            # Create command instance to get the expanded prompt
            command_instance = command_class(self.output_adapter, self.agent)
            try:
                expanded_prompt = await command_instance.get_prompt(args)

                # Add as user message and send to LLM
                user_message = MessageData(
                    type=MessageType.USER,
                    message=MessageContent(expanded_prompt),
                    options={"from_command": command_name},
                )
                self.messages = [*self.messages, user_message]
                self._save_message_to_session("user", expanded_prompt)
                self._refresh_messages()

                await self.on_query_from_prompt([user_message])

            except Exception as e:
                error_message = MessageData(
                    type=MessageType.ASSISTANT,
                    message=MessageContent(
                        f"❌ Error expanding /{command_name}: {str(e)}"
                    ),
                    options={"error": True},
                )
                self.messages = [*self.messages, error_message]
                self._refresh_messages()
            return

        # LOCAL and LOCAL_JSX types: Direct execution
        # Determine status message based on is_skill
        if is_skill:
            status_text = f"⚙️ /{command_name} skill is executing..."
        else:
            status_text = f"⚙️ /{command_name} is executing..."

        status_message = MessageData(
            type=MessageType.PROGRESS,
            message=MessageContent(status_text),
            options={"command": True},
        )
        self.messages = [*self.messages, status_message]
        self._refresh_messages()

        try:
            # Create command instance with TextualOutputAdapter
            command_instance = command_class(self.output_adapter, self.agent)

            # Special handling for quit command
            if command_name in ["quit", "exit", "q", "bye"]:
                command_instance._tui_instance = self

            # Execute the command
            await command_instance.execute(args)

            # Remove the status message after successful execution
            # (command output is handled by output_adapter callbacks)
            if self.messages and self.messages[-1].options.get("command"):
                self.messages = self.messages[:-1]
                self._refresh_messages()

        except Exception as e:
            # Show error message
            error_message = MessageData(
                type=MessageType.ASSISTANT,
                message=MessageContent(f"❌ Error executing /{command_name}: {str(e)}"),
                options={"error": True},
            )
            # Replace status message with error
            self.messages = [*self.messages[:-1], error_message]
            self._refresh_messages()

    def show_prompt_input(self):
        """Show the prompt input component"""
        self.should_show_prompt_input = True

    def hide_prompt_input(self):
        """Hide the prompt input component"""
        self.should_show_prompt_input = False

    def toggle_prompt_input(self):
        """Toggle the prompt input component visibility"""
        self.should_show_prompt_input = not self.should_show_prompt_input

    @on(Button.Pressed, "#acknowledge_btn")
    def acknowledge_cost_dialog(self):
        """Acknowledge cost threshold dialog"""
        self.show_cost_dialog = False
        self.have_shown_cost_dialog = True
        self.config.has_acknowledged_cost_threshold = True

    def normalize_messages(self) -> List[MessageData]:
        """Normalize messages - equivalent to normalizeMessages function"""
        # Filter out empty messages and normalize structure
        return [msg for msg in self.messages if self.is_not_empty_message(msg)]

    def is_not_empty_message(self, message: MessageData) -> bool:
        """Check if message is not empty - equivalent to isNotEmptyMessage"""
        if isinstance(message.message.content, str):
            return bool(message.message.content.strip())
        return bool(message.message.content)

    def get_unresolved_tool_use_ids(self) -> Set[str]:
        """Get unresolved tool use IDs - equivalent to getUnresolvedToolUseIDs"""
        # This would analyze messages for unresolved tool uses
        return set()

    def get_in_progress_tool_use_ids(self) -> Set[str]:
        """Get in-progress tool use IDs - equivalent to getInProgressToolUseIDs"""
        # This would analyze messages for in-progress tool uses
        return set()

    def get_errored_tool_use_ids(self) -> Set[str]:
        """Get errored tool use IDs - equivalent to getErroredToolUseMessages"""
        # This would analyze messages for errored tool uses
        return set()

    def _format_error_for_ui(self, error: Exception) -> str:
        """Format error message for UI display with appropriate context"""
        error_type = type(error).__name__
        error_msg = str(error)

        # Handle common error types with user-friendly messages
        if "ImportError" in error_type or "ModuleNotFoundError" in error_type:
            return f"❌ Module Error: {error_msg}\n💡 Try installing missing dependencies or check your environment setup."

        elif "ConnectionError" in error_type or "TimeoutError" in error_type:
            return f"❌ Connection Error: {error_msg}\n💡 Check your internet connection or API configuration."

        elif "PermissionError" in error_type:
            return f"❌ Permission Error: {error_msg}\n💡 Check file permissions or run with appropriate privileges."

        elif "FileNotFoundError" in error_type:
            return f"❌ File Not Found: {error_msg}\n💡 Verify the file path exists and is accessible."

        elif "ValueError" in error_type or "TypeError" in error_type:
            return f"❌ Input Error: {error_msg}\n💡 Please check your input format and try again."

        else:
            # Generic error with helpful context
            return f"❌ {error_type}: {error_msg}\n💡 If this error persists, please check the logs for more details."

    # Reactive property watchers (equivalent to React useEffect)
    def watch_fork_number(self, fork_number: int):
        """Watch fork number changes"""
        pass

    def watch_is_loading(self, is_loading: bool):
        """Watch loading state changes"""
        try:
            prompt_input = self.query_one(PromptInput)
            prompt_input.is_loading = is_loading
        except Exception:
            pass

    def watch_should_show_prompt_input(self, should_show: bool):
        """Watch prompt input visibility changes"""
        # This will trigger recomposition when the property changes
        pass

    def watch_messages(self, messages: List[MessageData]):
        """Watch messages changes - equivalent to useEffect([messages], ...)"""
        pass

        # Check cost threshold (equivalent to cost threshold useEffect)
        total_cost = self.get_total_cost()
        if (
            total_cost >= 5.0
            and not self.show_cost_dialog
            and not self.have_shown_cost_dialog
        ):
            self.show_cost_dialog = True

    def get_total_cost(self) -> float:
        """Get total API cost - equivalent to getTotalCost"""
        # This would calculate actual API costs
        return len(self.messages) * 0.01  # Mock cost calculation

    def _get_mode_prefix(self) -> str:
        """Get the mode prefix character"""
        if self.input_mode == InputMode.BASH:
            return "!"
        elif self.input_mode == InputMode.MEMORY:
            return "#"
        else:
            return ">"

    # Simplified event handlers for debugging
    @on(Input.Changed, "#simple_input")
    def on_simple_input_changed(self, event):
        """Handle simple input changes"""
        self.input_value = event.value

    @on(Input.Submitted, "#simple_input")
    @on(Button.Pressed, "#simple_send")
    async def on_simple_submit(self, event):
        """Handle simple input submission"""
        input_widget = self.query_one("#simple_input", expect_type=Input)
        input_text = input_widget.value.strip()

        if not input_text:
            return

        # Add user message to display
        user_message = MessageData(
            type=MessageType.USER,
            message=MessageContent(input_text),
            options={"mode": self.input_mode.value},
        )
        self.messages = [*self.messages, user_message]

        # Create simple response
        response_text = f"Received: {input_text} (mode: {self.input_mode.value})"
        assistant_message = MessageData(
            type=MessageType.ASSISTANT, message=MessageContent(response_text)
        )
        self.messages = [*self.messages, assistant_message]

        # Clear input
        input_widget.value = ""
        self.input_value = ""

        # Keep focus
        input_widget.focus()

    @on(Button.Pressed, "#simple_mode")
    def on_simple_mode_change(self):
        """Handle mode change"""
        modes = list(InputMode)
        current_index = modes.index(self.input_mode)
        self.input_mode = modes[(current_index + 1) % len(modes)]

        # Update mode indicator
        try:
            mode_indicator = self.query_one("#mode_indicator", expect_type=Static)
            mode_indicator.update(f" {self._get_mode_prefix()} ")

            # Update input placeholder
            input_widget = self.query_one("#simple_input", expect_type=Input)
            input_widget.placeholder = f"Enter {self.input_mode.value} command..."
        except:
            pass


class REPLApp(App):
    """
    Main REPL Application - equivalent to the main App wrapper in React
    Provides the application context, agent management, and styling
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Initialize with default props (equivalent to React props)
        self.repl_props = {
            "commands": [],
            "safe_mode": False,
            "debug": False,
            "initial_fork_number": 0,
            "initial_prompt": None,
            "message_log_name": "default",
            "should_show_prompt_input": True,
            "tools": [],
            "verbose": False,
            "initial_messages": [],
            "mcp_clients": [],
            "is_default_model": True,
            "initial_update_version": None,
            "initial_update_commands": None,
            "resume_session_id": None,
            "continue_last": False,
        }

        # App-level agent management
        self.agent = None
        self.agent_ready = False

    def compose(self) -> ComposeResult:
        """Compose the main application - equivalent to React App render"""
        yield Header(show_clock=False)
        # Pass agent to REPL component (filter out app-level props like 'model')
        repl_props_filtered = {k: v for k, v in self.repl_props.items() if k != "model"}
        repl_props_with_agent = {**repl_props_filtered, "agent": self.agent}
        yield REPL(**repl_props_with_agent)
        yield Footer()

    def on_mount(self):
        """Application mount lifecycle"""
        self.title = "Minion Code Assistant"
        # Initialize agent at app level
        self.run_worker(self._initialize_agent())

    async def _initialize_agent(self):
        """Initialize the MinionCodeAgent at app level"""
        try:
            from minion_code import MinionCodeAgent
            from minion_code.utils.logs import logger
            from minion_code.agents.hooks import create_default_hooks

            # Check for model from CLI or use default
            # Users can override with --model flag or config
            model_from_props = self.repl_props.get("model")
            default_llm = model_from_props if model_from_props else "claude-sonnet-4-5"

            # Get REPL component's output adapter for permission dialogs
            try:
                repl_component = self.query_one(REPL)
                output_adapter = repl_component.output_adapter
                hooks = create_default_hooks(output_adapter)
                logger.info(
                    "Created hooks with TextualOutputAdapter for permission dialogs"
                )
            except Exception as e:
                logger.warning(
                    f"Could not get output adapter, using autonomous hooks: {e}"
                )
                from minion_code.agents.hooks import create_autonomous_hooks

                hooks = create_autonomous_hooks()

            logger.info(f"Initializing agent with LLM: {default_llm}")
            self.agent = await MinionCodeAgent.create(
                name="REPL Assistant",
                llm=default_llm,
                hooks=hooks,
                # History decay: save large outputs to file after N steps
                decay_enabled=True,
                decay_ttl_steps=3,
                decay_min_size=100_000,  # 100KB
            )
            self.agent_ready = True

            logger.info(f"Agent initialized with {len(self.agent.tools)} tools")

            # Update REPL component with agent
            try:
                repl_component = self.query_one(REPL)
                repl_component.set_agent(self.agent)
                logger.info("Agent set on REPL component")
            except Exception as e:
                logger.warning(f"Could not set agent on REPL: {e}")

        except Exception as e:
            from minion_code.utils.logs import logger

            logger.error(f"Failed to initialize agent: {e}")
            self.agent_ready = False


# Utility functions equivalent to TypeScript utility functions
def should_render_statically(
    message: MessageData, messages: List[MessageData], unresolved_tool_use_ids: Set[str]
) -> bool:
    """
    Determine if message should render statically
    Equivalent to shouldRenderStatically function in TypeScript
    """
    if message.type in [MessageType.USER, MessageType.ASSISTANT]:
        # For now, render all user and assistant messages statically
        return True
    elif message.type == MessageType.PROGRESS:
        # Progress messages depend on tool use resolution
        return len(unresolved_tool_use_ids) == 0
    return True


def intersects(set_a: Set[str], set_b: Set[str]) -> bool:
    """Check if two sets intersect - equivalent to intersects function"""
    return len(set_a & set_b) > 0


# Factory function to create REPL with specific configuration
def create_repl(
    commands=None,
    safe_mode=False,
    debug=False,
    initial_prompt=None,
    verbose=False,
    resume_session_id=None,
    continue_last=False,
    **kwargs,
) -> REPLApp:
    """
    Create a configured REPL application
    Equivalent to calling REPL component with props in React
    """
    print(f"DEBUG create_repl: initial_prompt={initial_prompt}")
    app = REPLApp()
    app.repl_props.update(
        {
            "commands": commands or [],
            "safe_mode": safe_mode,
            "debug": debug,
            "initial_prompt": initial_prompt,
            "verbose": verbose,
            "resume_session_id": resume_session_id,
            "continue_last": continue_last,
            **kwargs,
        }
    )
    print(f"DEBUG create_repl: repl_props={app.repl_props}")
    return app


def run(
    initial_prompt=None,
    debug=False,
    verbose=False,
    resume_session_id=None,
    continue_last=False,
    model=None,
):
    """Run the REPL application with optional configuration"""
    # File-based logging for TUI debugging
    import logging

    logging.basicConfig(
        filename="/tmp/minion_repl_debug.log",
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
        force=True,  # Override any existing config
    )
    logging.debug(f"=== REPL run() called ===")
    logging.debug(f"initial_prompt: {repr(initial_prompt)}")
    logging.debug(f"debug: {debug}, verbose: {verbose}, model: {model}")
    logging.debug(
        f"resume_session_id: {resume_session_id}, continue_last: {continue_last}"
    )

    app = create_repl(
        initial_prompt=initial_prompt,
        debug=debug,
        verbose=verbose,
        resume_session_id=resume_session_id,
        continue_last=continue_last,
        model=model,
    )
    logging.debug(f"app.repl_props: {app.repl_props}")
    app.run()


if __name__ == "__main__":
    import sys

    # Parse command line arguments (basic implementation)
    initial_prompt = None
    debug = False
    verbose = False

    if len(sys.argv) > 1:
        if "--debug" in sys.argv:
            debug = True
        if "--verbose" in sys.argv:
            verbose = True
        if "--prompt" in sys.argv:
            prompt_index = sys.argv.index("--prompt")
            if prompt_index + 1 < len(sys.argv):
                initial_prompt = sys.argv[prompt_index + 1]

    run(initial_prompt=initial_prompt, debug=debug, verbose=verbose)
