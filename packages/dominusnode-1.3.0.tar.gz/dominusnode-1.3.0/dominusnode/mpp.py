"""MPP (Micropayment Protocol) resource -- info, top-ups, payment sessions, and keyless proxy access.

MPP allows AI agents to use the proxy WITHOUT any API key -- just pay per request.
Call ``get_challenge()`` to obtain a credential, then use ``build_proxy_headers()``
to construct the headers needed for keyless proxy access.
"""

from __future__ import annotations

import json
import math
from typing import Any, Dict

# IETF MPP auth scheme names
MPP_AUTH_SCHEME = "Payment"
MPP_AUTH_SCHEME_LEGACY = "MPP"
from urllib.parse import quote

from .http_client import AsyncHttpClient, SyncHttpClient
from .wallet import _validate_amount_cents


def _validate_finite_int(value: int, name: str) -> None:
    """Validate that *value* is a finite integer (guards against NaN/Infinity via float coercion)."""
    if not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    # Python int can't be NaN/Inf, but guard against float passed as int subclass
    as_float = float(value)
    if math.isnan(as_float) or math.isinf(as_float):
        raise ValueError(f"{name} must be a finite number")


def build_proxy_headers(credential: Dict[str, Any]) -> Dict[str, str]:
    """Build proxy Authorization header for keyless MPP access.

    Returns headers that should be set on the HTTP CONNECT / proxy request
    to route through the proxy without an API key.

    Args:
        credential: The credential dict from ``get_challenge()`` (or a manually
            constructed dict with at least ``challengeId``, ``nonce``, ``poolType``).

    Returns:
        Headers dict with ``Authorization: MPP <json>``.
    """
    return {
        "Authorization": MPP_AUTH_SCHEME + " " + json.dumps(credential, separators=(",", ":")),
    }


def build_session_headers(session_token: str) -> Dict[str, str]:
    """Build proxy session token header for ongoing MPP sessions.

    After opening a session, use the session token for subsequent requests
    within the same session.

    Args:
        session_token: The session token from an active MPP session.

    Returns:
        Headers dict with ``MPP-SESSION-TOKEN``.
    """
    if not session_token or not isinstance(session_token, str):
        raise ValueError("session_token must be a non-empty string")
    return {
        "MPP-SESSION-TOKEN": session_token,
    }


# ──────────────────────────────────────────────────────────────────────
# Sync
# ──────────────────────────────────────────────────────────────────────


class MppResource:
    """Synchronous MPP (Micropayment Protocol) operations.

    MPP enables keyless proxy access for AI agents: call ``get_challenge()`` to
    obtain a credential, then use ``build_proxy_headers()`` to construct the proxy
    Authorization header -- no API key needed.
    """

    def __init__(self, http: SyncHttpClient) -> None:
        self._http = http

    def get_info(self) -> dict:
        """Get MPP protocol information.

        This endpoint does not require authentication.

        Returns:
            Server response dict with MPP capabilities and configuration.
        """
        data = self._http.get("/api/mpp/info", requires_auth=False)
        return data

    def get_challenge(self, pool_type: str) -> dict:
        """Request an MPP challenge for keyless proxy access.

        This endpoint does not require authentication. The returned credential
        can be used with ``build_proxy_headers()`` to access the proxy without
        an API key.

        Args:
            pool_type: Proxy pool type -- ``"dc"`` (datacenter, $3/GB) or
                ``"residential"`` ($5/GB).

        Returns:
            Server response dict with ``challengeId``, ``nonce``, ``expiresAt``,
            ``poolType``, and ``credential``.
        """
        if pool_type not in ("dc", "residential"):
            raise ValueError("pool_type must be 'dc' or 'residential'")
        data = self._http.post(
            "/api/mpp/challenge",
            json={"poolType": pool_type},
            requires_auth=False,
        )
        return data

    def top_up(self, amount_cents: int, method: str) -> dict:
        """Top up the MPP balance.

        Requires authentication (wallet credit needs a user account).

        Args:
            amount_cents: Amount in cents (must be positive, <= 2,147,483,647).
            method: Payment method identifier (e.g. "stripe", "paypal", "crypto").

        Returns:
            Server response dict with top-up confirmation details.
        """
        _validate_finite_int(amount_cents, "amount_cents")
        _validate_amount_cents(amount_cents, "amount_cents")
        data = self._http.post("/api/mpp/topup", json={
            "amountCents": amount_cents,
            "method": method,
        })
        return data

    def open_session(self, max_deposit_cents: int, method: str, pool_type: str) -> dict:
        """Open a new MPP payment session (payment channel).

        This endpoint does not require authentication -- anonymous agents can
        open sessions by providing a payment method and deposit.

        Args:
            max_deposit_cents: Maximum deposit in cents (must be positive, <= 2,147,483,647).
            method: Payment method identifier.
            pool_type: Proxy pool type (e.g. "dc", "residential").

        Returns:
            Server response dict with session/channel details.
        """
        _validate_finite_int(max_deposit_cents, "max_deposit_cents")
        _validate_amount_cents(max_deposit_cents, "max_deposit_cents")
        data = self._http.post("/api/mpp/session/open", json={
            "maxDepositCents": max_deposit_cents,
            "method": method,
            "poolType": pool_type,
        }, requires_auth=False)
        return data

    def close_session(self, channel_id: str) -> dict:
        """Close an existing MPP payment session.

        Args:
            channel_id: The payment channel identifier.

        Returns:
            Server response dict with closure confirmation and final settlement.
        """
        data = self._http.post("/api/mpp/session/close", json={
            "channelId": channel_id,
        })
        return data

    def get_session(self, channel_id: str) -> dict:
        """Get details of an MPP payment session.

        Args:
            channel_id: The payment channel identifier (URL-encoded automatically).

        Returns:
            Server response dict with session state and usage details.
        """
        data = self._http.get(f"/api/mpp/session/{quote(channel_id, safe='')}")
        return data

    # Convenience re-exports as static methods for discoverability
    build_proxy_headers = staticmethod(build_proxy_headers)
    build_session_headers = staticmethod(build_session_headers)

    def __repr__(self) -> str:
        return "MppResource()"


# ──────────────────────────────────────────────────────────────────────
# Async
# ──────────────────────────────────────────────────────────────────────


class AsyncMppResource:
    """Asynchronous MPP (Micropayment Protocol) operations.

    MPP enables keyless proxy access for AI agents: call ``get_challenge()`` to
    obtain a credential, then use ``build_proxy_headers()`` to construct the proxy
    Authorization header -- no API key needed.
    """

    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_info(self) -> dict:
        """Get MPP protocol information.

        This endpoint does not require authentication.
        """
        data = await self._http.get("/api/mpp/info", requires_auth=False)
        return data

    async def get_challenge(self, pool_type: str) -> dict:
        """Request an MPP challenge for keyless proxy access.

        This endpoint does not require authentication. The returned credential
        can be used with ``build_proxy_headers()`` to access the proxy without
        an API key.

        Args:
            pool_type: Proxy pool type -- ``"dc"`` or ``"residential"``.
        """
        if pool_type not in ("dc", "residential"):
            raise ValueError("pool_type must be 'dc' or 'residential'")
        data = await self._http.post(
            "/api/mpp/challenge",
            json={"poolType": pool_type},
            requires_auth=False,
        )
        return data

    async def top_up(self, amount_cents: int, method: str) -> dict:
        """Top up the MPP balance.

        Requires authentication (wallet credit needs a user account).

        Args:
            amount_cents: Amount in cents (must be positive, <= 2,147,483,647).
            method: Payment method identifier (e.g. "stripe", "paypal", "crypto").
        """
        _validate_finite_int(amount_cents, "amount_cents")
        _validate_amount_cents(amount_cents, "amount_cents")
        data = await self._http.post("/api/mpp/topup", json={
            "amountCents": amount_cents,
            "method": method,
        })
        return data

    async def open_session(self, max_deposit_cents: int, method: str, pool_type: str) -> dict:
        """Open a new MPP payment session (payment channel).

        This endpoint does not require authentication -- anonymous agents can
        open sessions by providing a payment method and deposit.

        Args:
            max_deposit_cents: Maximum deposit in cents (must be positive, <= 2,147,483,647).
            method: Payment method identifier.
            pool_type: Proxy pool type (e.g. "dc", "residential").
        """
        _validate_finite_int(max_deposit_cents, "max_deposit_cents")
        _validate_amount_cents(max_deposit_cents, "max_deposit_cents")
        data = await self._http.post("/api/mpp/session/open", json={
            "maxDepositCents": max_deposit_cents,
            "method": method,
            "poolType": pool_type,
        }, requires_auth=False)
        return data

    async def close_session(self, channel_id: str) -> dict:
        """Close an existing MPP payment session.

        Args:
            channel_id: The payment channel identifier.
        """
        data = await self._http.post("/api/mpp/session/close", json={
            "channelId": channel_id,
        })
        return data

    async def get_session(self, channel_id: str) -> dict:
        """Get details of an MPP payment session.

        Args:
            channel_id: The payment channel identifier (URL-encoded automatically).
        """
        data = await self._http.get(f"/api/mpp/session/{quote(channel_id, safe='')}")
        return data

    # Convenience re-exports as static methods for discoverability
    build_proxy_headers = staticmethod(build_proxy_headers)
    build_session_headers = staticmethod(build_session_headers)

    def __repr__(self) -> str:
        return "AsyncMppResource()"
