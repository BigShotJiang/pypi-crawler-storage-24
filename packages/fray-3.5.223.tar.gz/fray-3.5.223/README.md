<div align="center">

# Fray

### Vibe security — just point and scan.

One command. Full pipeline. Zero config.

```
pip install fray && fray go target.com
```

[![PyPI](https://img.shields.io/pypi/v/fray.svg)](https://pypi.org/project/fray/)
[![Downloads](https://img.shields.io/pypi/dm/fray?color=6366f1)](https://pypi.org/project/fray/)
[![Payloads](https://img.shields.io/badge/Payloads-7%2C800+-red)](docs/payload-database-coverage.md)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**[Docs](https://dalisec.io/docs/)** · **[Discussions](https://github.com/dalisecurity/fray/discussions)** · **[dalisec.io](https://dalisec.io/)**

**🌐** **English** | [日本語](README.ja.md)

</div>

---

> **FOR AUTHORIZED SECURITY TESTING ONLY** — Only test systems you own or have explicit written permission to test.

<p align="center">
  <img src="docs/demo.gif" alt="fray go — full security audit in one command" width="720">
</p>

---

## Before Fray vs. With Fray

| Traditional | With Fray |
|---|---|
| Install 5+ tools (nmap, wafw00f, sqlmap, nikto, nuclei) | `pip install fray` |
| Learn each tool's flags and config formats | `fray go target.com` |
| Manually correlate findings across tools | Automatic: recon → test → report |
| Write scripts to chain tools together | 42 checks · 12 deep scan modules · 7,800+ payloads |
| Security expertise required | Built for anyone who ships web apps |

---

## What's New — v3.5.6

- **`fray analyze`** — per-pattern WAF bypass table. Confirms which payload patterns are blocked, then finds what gets through — with injection mechanics explaining *why* each bypass works
- **42 recon checks** — CVE probes for Next.js, Log4Shell, Spring4Shell, WordPress, Drupal fire automatically based on detected tech stack. No manual configuration
- **18 vendor feeds** — Unit 42, F5 Labs, Cloudflare, Imperva, PortSwigger, MSRC Patch Tuesday + 12 more. `fray feed --auto-add` pulls, validates PoC accuracy, and stages payloads
- **`fray vendor-intel`** — latest CVEs and posts from all 18 feeds in one terminal view
- **Wappalyzer** — 3,920 tech patterns from npm. Detects Shopify, EC-CUBE, Vercel, Datadog, Auth0, Kong, 4,200+ technologies from response headers, cookies, and scripts
- **Report** — security grade A–F with specific improvement steps, RDAP domain age, origin cloud provider (GCP/AWS/Azure), VPN CVEs in Known Vulnerabilities

→ [Full changelog](CHANGELOG.md)

---

## Core Commands

```bash
fray go <url>              # ★ Full pipeline: recon → test → report (start here)
fray recon <url>           # 42-check reconnaissance — WAF, TLS, CVEs, secrets, subdomains
fray test <url> --smart    # Smart payload selection from recon findings
fray analyze <url>         # Per-pattern WAF bypass analysis with bypass table
fray detect <url>          # WAF/CDN fingerprint (98 vendors)
fray harden <url>          # OWASP hardening audit (A–F grade)
fray vendor-intel          # Latest CVEs from 18 security vendor feeds
fray feed --auto-add       # Pull CVEs → validate PoC → update payload DB
fray smoke --local         # Test detection accuracy against localhost Docker lab
fray dashboard             # Web UI — timeline, diff, live reload
fray mcp                   # MCP server for Claude / ChatGPT / Cursor
```

`fray <url>` is a shortcut for `fray go <url>`.

---

## Who It's For

- **Developers** — run `fray go` before launch. Done.
- **Bug bounty hunters** — 7,800+ payloads, WAF bypass intelligence, adaptive cache learns across scans.
- **Pentesters** — 12 deep scan modules, stealth mode, auth support, per-pattern bypass analysis.
- **DevSecOps** — GitHub Action, SARIF output, `--json` for pipelines.
- **Security teams** — MCP server for AI agents, VS Code extension, 18 live threat intel feeds.

---

## Payload Coverage

7,800+ payloads across 43 categories:

| Category | Count | Category | Count |
|----------|-------|----------|-------|
| XSS | 1,329 | AI/LLM Prompt Injection | 410 |
| Web Shells | 994 | Path Traversal | 293 |
| WordPress | 964 | SQL Injection | 258 |
| LLM Testing | 740 | Command Injection | 233 |
| Other / Generic | 368 | SSTI | 220 |
| CSP Bypass | 177 | XXE | 178 |
| Modern Bypasses | 137 | API Security | 130 |
| SSRF Cloud Metadata | 123 | Prototype Pollution | 110 |
| CRLF Injection | 94 | Open Redirect | 91 |
| LDAP Injection | 90 | XPath Injection | 89 |
| JWT Attack | 32 | Supply Chain | 46 |
| Auth Bypass | 20 | GraphQL Attacks | 24 |
| Cache Poisoning | 20 | Deserialization | 16 |
| Mass Assignment | 25 | Race Condition | 16 |
| RAG Security | 16 | HTTP Smuggling | 17 |
| Host Header Injection | 15 | CORS | 15 |

[Full payload database →](docs/payload-database-coverage.md)

---

## MCP — AI Agent Integration

18 tools via [MCP](https://modelcontextprotocol.io/) for Claude, ChatGPT, Cursor, and any MCP client.

```bash
pip install 'fray[mcp]'
```

```json
{ "mcpServers": { "fray": { "command": "python", "args": ["-m", "fray.mcp_server"] } } }
```

Ask *"What XSS payloads bypass Cloudflare?"* — `suggest_payloads_for_waf`, `generate_bypass_strategy`, `analyze_response`, `hardening_check`, and 14 more tools run directly.

[Claude Code guide →](docs/claude-code-guide.md) · [ChatGPT guide →](docs/chatgpt-guide.md)

---

## CI/CD — GitHub Action

```yaml
# .github/workflows/waf.yml
- uses: dalisecurity/fray@v1
  with:
    target: https://staging.example.com
    categories: xss,sqli
```

Exits non-zero on bypass findings. Integrates with GitHub Security tab via SARIF. [CI/CD guide →](docs/github-action-guide.md)

---

## Auth & Stealth

```bash
fray test https://target.com --cookie "session=abc123"
fray test https://target.com --bearer eyJhbG...
fray test https://target.com --stealth -d 0.5      # randomized UA + jitter
fray recon https://target.com --scope scope.txt    # in-scope enforcement
```

[Auth guide →](docs/authentication-guide.md)

---

## Community

- **[Discussions](https://github.com/dalisecurity/fray/discussions)** — questions, ideas, show what you built
- **[Issues](https://github.com/dalisecurity/fray/issues)** — bugs and feature requests
- **[Contributing](CONTRIBUTING.md)** — PRs welcome. For AI coding agents, see [AGENTS.md](AGENTS.md)
- **VS Code Extension** — [![Install](https://img.shields.io/badge/VS_Code-Install-007ACC?logo=visualstudiocode)](https://marketplace.visualstudio.com/items?itemName=DaliSecurity.fray-security)

---

**MIT License** · Only test systems you own or have explicit authorization to test · Security issues: soc@dalisec.io

<div align="center">

**[dalisec.io](https://dalisec.io/)** · Built by hunters. For defenders.

</div>

<!-- mcp-name: io.github.dalisecurity/fray -->
