#!/usr/bin/env python3
"""
WAF Detector - Identify Web Application Firewall vendors
Detects 87 WAF/CDN/bot-protection vendors via headers, cookies, CNAME, server,
and response-body fingerprints.
"""

import socket
import ssl
import re
import urllib.parse
from typing import Dict, List, Optional, Tuple
from datetime import datetime


def _build_signatures_from_waf_cdn(entries: list) -> dict:
    """Translate _WAF_CDN_SIGNATURES list entries into the waf_signatures dict
    format expected by _analyze_signatures().

    The dns.py format uses:
        {"name": str, "waf": str|None, "cdn": str|None,
         "headers": {hdr_key: expected_val_or_empty_str},
         "server_contains": [...],   # optional
         "cookie_hints": [...],      # optional
         "cname_hints": [...]}

    We map this to:
        name -> {"headers": [...], "cookies": [...], "server": [...],
                 "response_codes": [], "response_text": [],
                 "cookie_hints": [...], "cname_hints": [...],
                 "_cdn": str|None, "_waf_label": str|None,
                 "server_contains": [...]}
    """
    out = {}
    for e in entries:
        name = e["name"]
        hdr_dict = e.get("headers", {})
        # Separate "server" key (exact substring match) from generic headers
        server_vals = []
        header_keys = []
        for k, v in hdr_dict.items():
            if k == "server":
                server_vals.append(v)
            else:
                header_keys.append(k)
        out[name] = {
            "headers": header_keys,
            "cookies": e.get("cookie_hints", []),
            "server": server_vals,
            "server_contains": e.get("server_contains", []),
            "response_codes": [],
            "response_text": [],
            "cname_hints": e.get("cname_hints", []),
            "_cdn": e.get("cdn"),
            "_waf_label": e.get("waf"),
        }
    return out

class Colors:
    """Terminal colors for better output"""
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'

class WAFDetector:
    """Detect WAF vendor based on response headers, cookies, and behavior"""
    
    def __init__(self):
        self.waf_signatures = {
            'Cloudflare': {
                'headers': ['cf-ray', 'cf-cache-status', '__cfduid', 'cf-request-id', 'cf-cache-status', 'cf-request-id'],
                'cookies': ['__cfduid', '__cflb', 'cf_clearance'],
                'response_codes': [403, 503, 520, 521, 522, 523, 524, 525, 526, 527],
                'response_text': ['cloudflare', 'attention required', 'ray id', 'checking your browser', 'just a moment', 'cf-error-details', 'cf-wrapper'],
                'server': ['cloudflare'],
                'error_patterns': [r'Ray ID: [a-f0-9]+', r'Cloudflare Ray ID'],
                'challenge_patterns': ['cf-challenge', 'cf-captcha-container']
            },
            'Akamai': {
                'headers': ['akamai-origin-hop', 'akamai-grn', 'x-akamai-session-id', 'akamai-x-cache', 'x-akamai-transformed', 'akamai-cache-status'],
                'cookies': ['ak_bmsc', 'bm_sv', 'bm_sz', 'akacd_', 'bm_mi'],
                'response_codes': [403, 503],
                'response_text': ['akamai', 'reference #', 'akamai technologies'],
                'server': ['akamaighost', 'akamai'],
                'error_patterns': [r'Reference #[\d\.]+', r'Akamai Error'],
                'bot_manager': True
            },
            'AWS WAF': {
                'headers': ['x-amzn-waf-action', 'x-amzn-waf-', 'x-amzn-requestid', 'x-amz-cf-id', 'x-amzn-trace-id', 'x-amz-apigw-id'],
                'cookies': ['awsalb', 'awsalbcors', 'awsalbapp', 'awsalbtg', 'awsalbtgcors'],
                'response_codes': [403, 429],
                'response_text': ['aws waf', 'request blocked by aws', 'x-amzn-waf', 'security policy', 'blocked by waf', 'aws', 'forbidden', 'access denied'],
                'server': ['awselb', 'awselb/2.0', 'amazon', 'cloudfront'],
                'error_patterns': [r'Request ID: [a-zA-Z0-9\-]+', r'x-amzn-waf-', r'security policy', r'blocked by waf'],
                'waf_specific_headers': ['x-amzn-waf-action', 'x-amzn-waf-'],
                'header_prefix': 'x-amzn-waf-',
                'header_combinations': [
                    ['x-amzn-requestid', 'x-amzn-trace-id', 'x-amz-cf-id'],
                    ['x-amzn-requestid', 'x-amz-cf-id']
                ],
                'response_body_patterns': ['request blocked by security policy', 'security violation', 'blocked by waf']
            },
            'Imperva (Incapsula)': {
                'headers': ['x-cdn', 'x-iinfo', 'x-true-client-ip'],
                'cookies': ['incap_ses', 'visid_incap', 'nlbi', 'incap'],
                'response_codes': [403],
                'response_text': ['incapsula', 'imperva', 'incident id', 'incap', 'support id'],
                'server': ['imperva', 'incapsula'],
                'error_patterns': [r'Incident ID: [a-zA-Z0-9]+', r'Support ID: [0-9]+'],
                'challenge_patterns': ['Verifying you are human']
            },
            'F5 BIG-IP': {
                'headers': ['x-wa-info', 'x-cnection'],
                'cookies': ['bigipserver', 'f5_cspm', 'ts', 'bigip'],
                'response_codes': [403],
                'response_text': ['the requested url was rejected', 'f5', 'please consult with your administrator'],
                'server': ['big-ip', 'bigip'],
                'error_patterns': [r'Support ID: [0-9]+', r'The requested URL was rejected']
            },
            'Fastly (Signal Sciences WAF)': {
                'headers': ['fastly-io-info', 'x-fastly-request-id', 'fastly-restarts', 'x-served-by', 'x-cache', 'x-timer', 'x-sigsci-requestid', 'x-sigsci-tags'],
                'cookies': ['fastly_'],
                'response_codes': [403, 406],
                'response_text': ['fastly', 'varnish', 'signal sciences', 'sigsci'],
                'server': ['fastly', 'varnish']
            },
            'Barracuda': {
                'headers': ['x-barracuda-url', 'x-barracuda-virus'],
                'cookies': ['barra_counter_session', 'barracuda'],
                'response_codes': [403],
                'response_text': ['barracuda', 'you have been blocked'],
                'server': ['barracuda']
            },
            'Citrix NetScaler': {
                'headers': ['ns-cache', 'citrix-transactionid', 'x-citrix-via'],
                'cookies': ['nsvs', 'citrix_ns_id', 'nsc_'],
                'response_codes': [403],
                'response_text': ['netscaler', 'citrix'],
                'server': ['netscaler']
            },
            'Radware': {
                'headers': ['x-protected-by'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['radware', 'appwall'],
                'server': []
            },
            'Microsoft Azure WAF': {
                'headers': ['x-azure-fdid', 'x-azure-ref', 'x-fd-healthprobe', 'x-azure-requestchain', 'x-azure-socketip', 'x-azure-clientip', 'x-azure-ja4-fingerprint', 'x-msedge-ref', 'x-azure-requestid'],
                'cookies': ['arr_affinity', 'arraffinity', 'arraffinitysamesite', 'ai_session', 'ai_user', 'x-azure-ref-originshield'],
                'response_codes': [403],
                'response_text': ['azure web application firewall', 'azure front door', 'x-azure-fdid', 'azure waf', 'request blocked by azure', 'access denied by waf', 'azure', 'microsoft'],
                'server': ['microsoft-iis', 'azure', 'kestrel', 'microsoft-httpapi'],
                'error_patterns': [r'X-Azure-Ref: [a-zA-Z0-9]+', r'X-Azure-FDID: [a-f0-9\-]+', r'blocked by azure', r'azure waf'],
                'front_door_headers': ['x-azure-fdid', 'x-fd-healthprobe', 'x-azure-requestchain'],
                'header_combinations': [
                    ['x-azure-fdid', 'x-azure-ref'],
                    ['x-azure-ref', 'x-fd-healthprobe']
                ],
                'response_body_patterns': ['azure web application firewall', 'request blocked by azure', 'access denied by waf'],
                'cache_patterns': ['TCP_DENIED', 'TCP_MISS']
            },
            'Google Cloud Armor': {
                'headers': ['x-goog-', 'x-cloud-trace-context', 'x-gfe-'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['google', 'cloud armor', 'gcp', 'your client does not have permission', 'google cloud platform'],
                'server': ['gws', 'gfe', 'Google Frontend'],
                'error_patterns': [r'cloud armor', r'does not have permission'],
                'gcp_headers': ['x-cloud-trace-context', 'x-goog-', 'x-gfe-'],
                'response_body_patterns': ['cloud armor', 'google cloud platform', 'your client does not have permission'],
                'recaptcha_indicators': ['recaptcha', 'g-recaptcha', 'google.com/recaptcha']
            },
            'Qualys WAF': {
                'headers': ['x-qualys'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['qualys'],
                'server': []
            },
            'Penta Security (WAPPLES)': {
                'headers': ['x-wapples'],
                'cookies': ['wapples'],
                'response_codes': [403],
                'response_text': ['wapples', 'penta security'],
                'server': []
            },
            'StackPath': {
                'headers': ['x-sp-url', 'x-stackpath-shield'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['stackpath'],
                'server': ['stackpath']
            },
            'Sophos': {
                'headers': ['x-sophos'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['sophos', 'utm'],
                'server': []
            },
            'Palo Alto (Prisma Cloud)': {
                'headers': ['x-pan-', 'x-prisma'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['palo alto', 'prisma'],
                'server': []
            },
            'Check Point': {
                'headers': ['x-checkpoint'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['check point', 'checkpoint'],
                'server': []
            },
            'Trustwave (ModSecurity)': {
                'headers': ['x-mod-security', 'x-trustwave'],
                'cookies': [],
                'response_codes': [403, 406],
                'response_text': ['mod_security', 'modsecurity', 'trustwave'],
                'server': ['mod_security']
            },
            'Scutum': {
                'headers': ['x-scutum'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['scutum'],
                'server': []
            },
            'Rohde & Schwarz': {
                'headers': ['x-rs-'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['rohde', 'schwarz'],
                'server': []
            },
            'Sucuri': {
                'headers': ['x-sucuri-id', 'x-sucuri-cache'],
                'cookies': ['sucuri_cloudproxy_uuid'],
                'response_codes': [403],
                'response_text': ['sucuri', 'cloudproxy', 'access denied - sucuri website firewall'],
                'server': ['sucuri/cloudproxy'],
                'error_patterns': [r'Sucuri WebSite Firewall', r'CloudProxy']
            },
            'Fortinet FortiWeb': {
                'headers': ['x-fortiweb'],
                'cookies': ['fortiwafsid', 'cookiesession1'],
                'response_codes': [403, 406],
                'response_text': ['fortiweb', 'fortigate', 'fortinet', '.fwb'],
                'server': ['fortiweb'],
                'error_patterns': [r'FortiWeb', r'The page cannot be displayed']
            },
            'Wallarm': {
                'headers': ['x-wallarm-waf-check'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['wallarm', 'ngx_wallarm'],
                'server': ['nginx-wallarm'],
                'error_patterns': [r'wallarm', r'ngx_wallarm']
            },
            'Reblaze': {
                'headers': ['x-reblaze-protection'],
                'cookies': ['rbzid', 'rbzsessionid'],
                'response_codes': [403],
                'response_text': ['reblaze', 'access denied'],
                'server': ['reblaze'],
                'error_patterns': [r'Reblaze', r'rbzid']
            },
            'Vercel': {
                'headers': ['x-vercel-id', 'x-vercel-cache'],
                'cookies': [],
                'response_codes': [403],
                'response_text': ['vercel', 'vercel firewall'],
                'server': ['vercel'],
                'error_patterns': [r'Vercel', r'x-vercel-id']
            }
        }

        # Merge in the 87-vendor _WAF_CDN_SIGNATURES from dns.py.
        # Entries already present in self.waf_signatures are skipped so the
        # richer hand-crafted entries above take precedence.
        try:
            from fray.recon.dns import _WAF_CDN_SIGNATURES
            _merged = _build_signatures_from_waf_cdn(_WAF_CDN_SIGNATURES)
            for _name, _sig in _merged.items():
                if _name not in self.waf_signatures:
                    self.waf_signatures[_name] = _sig
        except ImportError:
            pass

    def detect_waf(self, target: str, timeout: int = 8, verify_ssl: bool = True,
                   impersonate: str = None) -> Dict:
        """Detect WAF vendor for a target.

        Args:
            impersonate: Browser to impersonate TLS fingerprint (e.g. "chrome").
                         When set, uses curl_cffi instead of raw sockets.
        """
        
        # Parse target URL
        if not target.startswith('http'):
            target = f'https://{target}'
        
        parsed = urllib.parse.urlparse(target)
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == 'https' else 80)
        use_ssl = parsed.scheme == 'https'
        path = parsed.path or '/'
        
        results = {
            'target': target,
            'timestamp': datetime.now().isoformat(),
            'waf_detected': False,
            'waf_vendor': None,
            'cdn_vendor': None,
            'confidence': 0,
            'signatures_found': [],
            'headers': {},
            'cookies': [],
            'server': None,
            'status_code': None,
            'response_snippet': None
        }

        # ── Impersonated detection path (curl_cffi) ──
        if impersonate:
            try:
                from fray.impersonate import ImpersonatedSession, AVAILABLE
                if AVAILABLE:
                    return self._detect_waf_impersonated(
                        target, host, port, use_ssl, path, timeout,
                        verify_ssl, impersonate, results)
            except ImportError:
                pass
        
        try:
            # Create connection
            if use_ssl:
                ctx = ssl.create_default_context()
                if not verify_ssl:
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                sock = socket.create_connection((host, port), timeout=timeout)
                conn = ctx.wrap_socket(sock, server_hostname=host)

                # ── TLS cert org fingerprinting ──
                # Extract certificate issuer/subject org to identify CDN/WAF providers
                try:
                    cert = conn.getpeercert()
                    if cert:
                        _cert_subject = dict(x[0] for x in cert.get('subject', ()) if x)
                        _cert_issuer = dict(x[0] for x in cert.get('issuer', ()) if x)
                        _cert_org = _cert_subject.get('organizationName', '')
                        _cert_issuer_org = _cert_issuer.get('organizationName', '')
                        _cert_san = [v for t, v in cert.get('subjectAltName', ()) if t == 'DNS']
                        results['tls_cert'] = {
                            'subject_org': _cert_org,
                            'issuer_org': _cert_issuer_org,
                            'san_count': len(_cert_san),
                        }
                        # Known CDN/WAF cert org names → boost detection confidence
                        _TLS_CERT_HINTS = {
                            'cloudflare': 'cloudflare',
                            'amazon': 'aws_waf',
                            'akamai': 'akamai',
                            'imperva': 'imperva',
                            'incapsula': 'imperva',
                            'fastly': 'fastly',
                            'stackpath': 'stackpath',
                            'sucuri': 'sucuri',
                            'google trust': 'google_cloud_armor',
                        }
                        _combined_org = f"{_cert_org} {_cert_issuer_org}".lower()
                        for _hint_key, _hint_vendor in _TLS_CERT_HINTS.items():
                            if _hint_key in _combined_org:
                                results['tls_cert']['waf_hint'] = _hint_vendor
                                break
                except Exception:
                    pass
            else:
                conn = socket.create_connection((host, port), timeout=timeout)
            
            # Send request with suspicious payload to trigger WAF
            test_payload = "' OR '1'='1' --"
            enc = urllib.parse.quote(test_payload, safe='')
            req = f"GET {path}?test={enc} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
            
            conn.sendall(req.encode('utf-8', errors='replace'))
            
            # Read response
            resp = b""
            while True:
                try:
                    data = conn.recv(4096)
                    if not data:
                        break
                    resp += data
                    if len(resp) > 100000:
                        break
                except (socket.error, socket.timeout, OSError):
                    break
            
            conn.close()
            
            # Parse response
            resp_str = resp.decode('utf-8', errors='replace')
            
            # Extract status code
            status_match = re.search(r'HTTP/[\d.]+ (\d+)', resp_str)
            if status_match:
                results['status_code'] = int(status_match.group(1))
            
            # Extract headers
            header_section = resp_str.split('\r\n\r\n')[0] if '\r\n\r\n' in resp_str else resp_str
            for line in header_section.split('\r\n')[1:]:
                if ':' in line:
                    key, value = line.split(':', 1)
                    results['headers'][key.strip().lower()] = value.strip()
            
            # Extract server header
            results['server'] = results['headers'].get('server', None)
            
            # Extract cookies
            for key, value in results['headers'].items():
                if key == 'set-cookie':
                    cookie_name = value.split('=')[0].strip()
                    results['cookies'].append(cookie_name)
            
            # Get response body snippet
            if '\r\n\r\n' in resp_str:
                body = resp_str.split('\r\n\r\n', 1)[1][:500]
                results['response_snippet'] = body
            
            # Detect WAF
            detection_results = self._analyze_signatures(results)
            results.update(detection_results)

            # ── Vendor-specific canary probes ──
            # If passive detection found candidates with moderate confidence,
            # send vendor-specific payloads to confirm via block response fingerprint.
            _CANARY_PROBES = {
                'cloudflare': {
                    'payload': '?fray_canary=<script>cf_canary</script>',
                    'confirm': [r'cloudflare', r'cf-error', r'attention required', r'ray id', r'cf-ray'],
                    'status': [403, 503],
                },
                'aws_waf': {
                    'payload': "?fray_canary=' OR 1=1--",
                    'confirm': [r'x-amzn-requestid', r'aws-waf', r'request blocked', r'awselb'],
                    'status': [403],
                },
                'akamai': {
                    'payload': '?fray_canary=../../etc/passwd',
                    'confirm': [r'reference\s*#[\d.]+', r'akamai', r'akamaighost'],
                    'status': [403],
                },
                'imperva': {
                    'payload': '?fray_canary=|id',
                    'confirm': [r'incapsula', r'incident\s*id', r'imperva', r'_incap_'],
                    'status': [403],
                },
                'f5_bigip': {
                    'payload': '?fray_canary=<script>alert(1)</script>',
                    'confirm': [r'the requested url was rejected', r'support id', r'bigipserver'],
                    'status': [403, 500],
                },
                'modsecurity': {
                    'payload': "?fray_canary=<script>alert('xss')</script>",
                    'confirm': [r'mod_security', r'modsecurity', r'owasp.*crs', r'not acceptable'],
                    'status': [403, 406],
                },
                'fastly': {
                    'payload': '?fray_canary=<img src=x onerror=alert(1)>',
                    'confirm': [r'fastly', r'varnish', r'fastly-error'],
                    'status': [403, 503],
                },
                'sucuri': {
                    'payload': "?fray_canary='; DROP TABLE--",
                    'confirm': [r'sucuri', r'cloudproxy', r'access denied.*sucuri'],
                    'status': [403],
                },
                'barracuda': {
                    'payload': '?fray_canary=<script>alert(document.cookie)</script>',
                    'confirm': [r'barracuda', r'barra_counter_session', r'barracuda_',],
                    'status': [403],
                },
                'fortinet': {
                    'payload': '?fray_canary=../../etc/shadow',
                    'confirm': [r'fortigate', r'fortiweb', r'fortinet', r'fgd_icon'],
                    'status': [403],
                },
                'radware': {
                    'payload': '?fray_canary=<svg onload=alert(1)>',
                    'confirm': [r'radware', r'appwall', r'unauthorized activity'],
                    'status': [403],
                },
                'citrix': {
                    'payload': '?fray_canary=UNION SELECT 1,2,3--',
                    'confirm': [r'ns_af', r'citrix', r'netscaler', r'appfw'],
                    'status': [403, 302],
                },
            }
            _all_dets = results.get('all_detections', [])
            _canary_results = []
            # Only run canaries for vendors detected with confidence 20-80 (uncertain)
            _candidates = [d for d in _all_dets if 20 <= d.get('confidence', 0) <= 80]
            for _cand in _candidates[:3]:
                _v = _cand['vendor'].lower().replace(' ', '_')
                for _ck, _cv in _CANARY_PROBES.items():
                    if _ck in _v or _v in _ck:
                        try:
                            _csock = socket.create_connection((host, port), timeout=timeout)
                            if use_ssl:
                                _cctx = ssl.create_default_context()
                                if not verify_ssl:
                                    _cctx.check_hostname = False
                                    _cctx.verify_mode = ssl.CERT_NONE
                                _cconn = _cctx.wrap_socket(_csock, server_hostname=host)
                            else:
                                _cconn = _csock
                            _cpayload = urllib.parse.quote(_cv['payload'], safe='?=&/')
                            _creq = f"GET {path}{_cpayload} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
                            _cconn.sendall(_creq.encode('utf-8', errors='replace'))
                            _cresp = b""
                            while True:
                                try:
                                    _cd = _cconn.recv(4096)
                                    if not _cd:
                                        break
                                    _cresp += _cd
                                    if b"\r\n\r\n" in _cresp and len(_cresp) > 512:
                                        break
                                    if len(_cresp) > 16000:
                                        break
                                except (socket.error, socket.timeout, OSError):
                                    break
                            _cconn.close()
                            _cresp_str = _cresp.decode('utf-8', errors='replace').lower()
                            _confirmed = any(re.search(p, _cresp_str, re.I) for p in _cv['confirm'])
                            if _confirmed:
                                _cand['confidence'] = min(_cand['confidence'] + 25, 100)
                                _cand['signatures'].append(f"Canary probe confirmed: {_ck}")
                                _cand['signature_count'] += 1
                                _canary_results.append({'vendor': _ck, 'confirmed': True})
                            else:
                                _canary_results.append({'vendor': _ck, 'confirmed': False})
                        except Exception:
                            pass
                        break
            if _canary_results:
                results['canary_probes'] = _canary_results
                # Re-sort and update top match after canary boosts
                _all_dets.sort(key=lambda x: (x['confidence'], x['signature_count']), reverse=True)
                if _all_dets:
                    _top = _all_dets[0]
                    results['waf_vendor'] = _top['vendor']
                    results['confidence'] = _top['confidence']
                    results['signatures_found'] = _top['signatures']

            # ── Monitor mode detection ──
            # Send an obvious attack payload.  If the WAF is in monitor/log-only
            # mode it will pass the request through (200) instead of blocking (403).
            # Compare against a clean baseline to detect:
            #   - monitor mode (malicious passes, same as clean)
            #   - active blocking (malicious blocked, clean passes)
            #   - transparent (no WAF behaviour at all)
            if results.get('waf_vendor'):
                _MONITOR_PROBES = [
                    "<script>alert('fray_monitor_detect')</script>",
                    "' OR 1=1-- ",
                    "../../../etc/passwd",
                ]
                try:
                    # Baseline: clean request
                    _bsock = socket.create_connection((host, port), timeout=timeout)
                    if use_ssl:
                        _bctx = ssl.create_default_context()
                        if not verify_ssl:
                            _bctx.check_hostname = False
                            _bctx.verify_mode = ssl.CERT_NONE
                        _bconn = _bctx.wrap_socket(_bsock, server_hostname=host)
                    else:
                        _bconn = _bsock
                    _breq = f"GET {path}?_fray_baseline=1 HTTP/1.1\r\nHost: {host}\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\nConnection: close\r\n\r\n"
                    _bconn.sendall(_breq.encode('utf-8', errors='replace'))
                    _bresp = b""
                    while True:
                        try:
                            _bd = _bconn.recv(4096)
                            if not _bd:
                                break
                            _bresp += _bd
                            if len(_bresp) > 8000:
                                break
                        except (socket.error, socket.timeout, OSError):
                            break
                    _bconn.close()
                    _baseline_status = 0
                    _bfirst = _bresp.split(b"\r\n", 1)[0].decode('utf-8', errors='replace')
                    if ' ' in _bfirst:
                        try:
                            _baseline_status = int(_bfirst.split(' ')[1])
                        except (ValueError, IndexError):
                            pass

                    # Malicious probes
                    _probe_statuses = []
                    _probe_reflected = []
                    for _mp in _MONITOR_PROBES:
                        try:
                            _msock = socket.create_connection((host, port), timeout=timeout)
                            if use_ssl:
                                _mctx = ssl.create_default_context()
                                if not verify_ssl:
                                    _mctx.check_hostname = False
                                    _mctx.verify_mode = ssl.CERT_NONE
                                _mconn = _mctx.wrap_socket(_msock, server_hostname=host)
                            else:
                                _mconn = _msock
                            _enc = urllib.parse.quote(_mp, safe='')
                            _mreq = f"GET {path}?_fray_monitor={_enc} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\nConnection: close\r\n\r\n"
                            _mconn.sendall(_mreq.encode('utf-8', errors='replace'))
                            _mresp = b""
                            while True:
                                try:
                                    _md = _mconn.recv(4096)
                                    if not _md:
                                        break
                                    _mresp += _md
                                    if len(_mresp) > 8000:
                                        break
                                except (socket.error, socket.timeout, OSError):
                                    break
                            _mconn.close()
                            _mstatus = 0
                            _mfirst = _mresp.split(b"\r\n", 1)[0].decode('utf-8', errors='replace')
                            if ' ' in _mfirst:
                                try:
                                    _mstatus = int(_mfirst.split(' ')[1])
                                except (ValueError, IndexError):
                                    pass
                            _probe_statuses.append(_mstatus)
                            _mresp_str = _mresp.decode('utf-8', errors='replace')
                            _probe_reflected.append(_mp in _mresp_str or urllib.parse.unquote(_enc) in _mresp_str)
                        except Exception:
                            _probe_statuses.append(0)
                            _probe_reflected.append(False)

                    # Classify WAF mode
                    _blocked = sum(1 for s in _probe_statuses if s in (403, 406, 429, 503))
                    _passed = sum(1 for s in _probe_statuses if 200 <= s < 400)
                    _total = len(_MONITOR_PROBES)

                    if _blocked >= _total * 0.6:
                        results['waf_mode'] = 'blocking'
                        results['waf_mode_detail'] = f'{_blocked}/{_total} probes blocked (active enforcement)'
                    elif _passed >= _total * 0.6 and _baseline_status and 200 <= _baseline_status < 400:
                        # Malicious requests passed just like clean — monitor mode
                        results['waf_mode'] = 'monitor'
                        results['waf_mode_detail'] = f'{_passed}/{_total} attack probes passed through (logging only)'
                        # Flag as critical finding
                        if any(_probe_reflected):
                            results['waf_mode_detail'] += ' — payloads REFLECTED in response'
                    else:
                        results['waf_mode'] = 'unknown'
                        results['waf_mode_detail'] = f'Inconclusive: {_blocked} blocked, {_passed} passed, baseline={_baseline_status}'

                    results['monitor_probes'] = {
                        'baseline_status': _baseline_status,
                        'probe_statuses': _probe_statuses,
                        'probes_blocked': _blocked,
                        'probes_passed': _passed,
                        'payload_reflected': any(_probe_reflected),
                    }
                except Exception:
                    pass

        except Exception as e:
            results['error'] = str(e)
        
        return results
    
    def _detect_waf_impersonated(self, target, host, port, use_ssl, path,
                                  timeout, verify_ssl, browser, results):
        """WAF detection using curl_cffi browser impersonation.

        Uses real browser TLS fingerprint so WAFs that gate on JA3/JA4
        won't block us at the TLS layer.
        """
        from fray.impersonate import ImpersonatedSession

        with ImpersonatedSession(browser=browser, verify=verify_ssl, timeout=timeout) as sess:
            # Send suspicious payload to trigger WAF (same as raw path)
            test_payload = "' OR '1'='1' --"
            enc = urllib.parse.quote(test_payload, safe='')
            scheme = 'https' if use_ssl else 'http'
            port_s = '' if (use_ssl and port == 443) or (not use_ssl and port == 80) else f':{port}'
            url = f"{scheme}://{host}{port_s}{path}?test={enc}"

            try:
                r = sess.get(url)
                results['status_code'] = r.status_code
                results['response_snippet'] = r.text[:500] if r.text else None
                results['impersonated'] = sess.browser

                # Parse headers
                for k, v in r.headers.items():
                    results['headers'][k.lower()] = v
                results['server'] = results['headers'].get('server', None)

                # Extract cookies from set-cookie headers
                sc = r.headers.get('set-cookie', '')
                if sc:
                    for part in sc.split(','):
                        cookie_name = part.strip().split('=')[0].strip()
                        if cookie_name:
                            results['cookies'].append(cookie_name)

                # TLS cert info (curl_cffi doesn't expose cert, skip)
                # Run signature analysis
                detection_results = self._analyze_signatures(results)
                results.update(detection_results)

                # Canary probes via impersonated session
                _all_dets = results.get('all_detections', [])
                _CANARY_PROBES = {
                    'cloudflare': ('?fray_canary=<script>cf_canary</script>',
                                   [r'cloudflare', r'cf-error', r'attention required', r'ray id']),
                    'aws_waf': ("?fray_canary=' OR 1=1--",
                                [r'x-amzn-requestid', r'aws-waf', r'request blocked']),
                    'akamai': ('?fray_canary=../../etc/passwd',
                               [r'reference\s*#[\d.]+', r'akamai']),
                    'imperva': ('?fray_canary=|id',
                                [r'incapsula', r'incident\s*id', r'imperva']),
                    'f5_bigip': ('?fray_canary=<script>alert(1)</script>',
                                 [r'the requested url was rejected', r'support id']),
                }
                _candidates = [d for d in _all_dets if 20 <= d.get('confidence', 0) <= 80]
                _canary_results = []
                for _cand in _candidates[:3]:
                    _v = _cand['vendor'].lower().replace(' ', '_')
                    for _ck, (_cp, _cc) in _CANARY_PROBES.items():
                        if _ck in _v or _v in _ck:
                            try:
                                _curl = f"{scheme}://{host}{port_s}{path}{_cp}"
                                _cr = sess.get(_curl)
                                _ctext = _cr.text.lower() if _cr.text else ""
                                _confirmed = any(re.search(p, _ctext, re.I) for p in _cc)
                                if _confirmed:
                                    _cand['confidence'] = min(_cand['confidence'] + 25, 100)
                                    _cand['signatures'].append(f"Canary probe confirmed: {_ck}")
                                    _cand['signature_count'] += 1
                                    _canary_results.append({'vendor': _ck, 'confirmed': True})
                                else:
                                    _canary_results.append({'vendor': _ck, 'confirmed': False})
                            except Exception:
                                pass
                            break
                if _canary_results:
                    results['canary_probes'] = _canary_results
                    _all_dets.sort(key=lambda x: (x['confidence'], x['signature_count']), reverse=True)
                    if _all_dets:
                        _top = _all_dets[0]
                        results['waf_vendor'] = _top['vendor']
                        results['confidence'] = _top['confidence']
                        results['signatures_found'] = _top['signatures']

            except Exception as e:
                results['error'] = str(e)

        return results

    def _analyze_signatures(self, results: Dict) -> Dict:
        """Analyze response for WAF signatures"""
        
        detected_wafs = []
        detected_cdns = []

        for waf_name, signatures in self.waf_signatures.items():
            confidence = 0
            found_signatures = []
            signature_count = 0
            
            # Check headers (higher weight for unique headers)
            for header in signatures['headers']:
                for resp_header in results['headers'].keys():
                    if header.lower() in resp_header.lower():
                        # Give more weight to vendor-specific headers
                        if header.startswith(('cf-', 'x-amz', 'x-azure', 'akamai', 'x-iinfo')):
                            confidence += 35  # Unique vendor headers
                        else:
                            confidence += 25  # Generic headers
                        found_signatures.append(f"Header: {resp_header}")
                        signature_count += 1
            
            # Special handling for AWS WAF prefix matching (x-amzn-waf-*)
            if 'header_prefix' in signatures:
                prefix = signatures['header_prefix']
                for resp_header in results['headers'].keys():
                    if resp_header.lower().startswith(prefix.lower()):
                        confidence += 50  # Very strong indicator of AWS WAF
                        found_signatures.append(f"WAF-specific header: {resp_header}")
                        signature_count += 1
            
            # Special handling for Azure Front Door headers
            if 'front_door_headers' in signatures:
                fd_header_count = sum(1 for h in signatures['front_door_headers'] 
                                     if any(h.lower() in rh.lower() for rh in results['headers'].keys()))
                if fd_header_count >= 2:
                    confidence += 40  # Multiple Front Door headers = strong indicator
                    found_signatures.append(f"Azure Front Door: {fd_header_count} headers")
                    signature_count += 1
            
            # Check cookies (high confidence for vendor-specific cookies)
            for cookie in signatures['cookies']:
                for resp_cookie in results['cookies']:
                    if cookie.lower() in resp_cookie.lower():
                        # Vendor-specific cookies are strong indicators
                        if cookie.startswith(('__cfd', 'incap', 'ak_', 'awsalb', 'bigip')):
                            confidence += 30  # Unique vendor cookies
                        else:
                            confidence += 20  # Generic cookies
                        found_signatures.append(f"Cookie: {resp_cookie}")
                        signature_count += 1
            
            # Check server header (very strong indicator)
            if results['server']:
                for server_sig in signatures['server']:
                    if server_sig.lower() in results['server'].lower():
                        confidence += 35
                        found_signatures.append(f"Server: {results['server']}")
                        signature_count += 1

            # server_contains: substring match (from _WAF_CDN_SIGNATURES entries)
            if results['server'] and 'server_contains' in signatures:
                for fragment in signatures['server_contains']:
                    if fragment.lower() in results['server'].lower():
                        confidence += 35
                        found_signatures.append(f"Server~{fragment}: {results['server']}")
                        signature_count += 1

            # cname_hints: checked against x-served-by / via / any header value
            if 'cname_hints' in signatures and signatures['cname_hints']:
                all_hdr_values = ' '.join(results['headers'].values()).lower()
                for hint in signatures['cname_hints']:
                    if hint.lower() in all_hdr_values:
                        confidence += 25
                        found_signatures.append(f"CNAME/header hint: {hint}")
                        signature_count += 1
                        break

            # Check response text (moderate confidence)
            if results['response_snippet']:
                for text_sig in signatures['response_text']:
                    if text_sig.lower() in results['response_snippet'].lower():
                        # Vendor-specific error messages
                        if text_sig in ['cloudflare', 'incapsula', 'imperva', 'akamai']:
                            confidence += 20  # Unique vendor text
                        else:
                            confidence += 10  # Generic error text
                        found_signatures.append(f"Response text: {text_sig}")
                        signature_count += 1
            
            # Check error patterns (regex-based, high confidence)
            if results['response_snippet'] and 'error_patterns' in signatures:
                for pattern in signatures['error_patterns']:
                    if re.search(pattern, results['response_snippet'], re.IGNORECASE):
                        confidence += 25  # Error pattern match is strong indicator
                        found_signatures.append(f"Error pattern: {pattern}")
                        signature_count += 1
            
            # Check challenge patterns (CAPTCHA/challenge pages)
            if results['response_snippet'] and 'challenge_patterns' in signatures:
                for pattern in signatures['challenge_patterns']:
                    if pattern.lower() in results['response_snippet'].lower():
                        confidence += 20  # Challenge page is good indicator
                        found_signatures.append(f"Challenge: {pattern}")
                        signature_count += 1
            
            # Check WAF-specific headers (very high confidence)
            if 'waf_specific_headers' in signatures:
                for waf_header in signatures['waf_specific_headers']:
                    if waf_header.lower() in [h.lower() for h in results['headers'].keys()]:
                        confidence += 40  # WAF-specific header is very strong
                        found_signatures.append(f"WAF-specific header: {waf_header}")
                        signature_count += 1
            
            # Check response body patterns (advanced cloud WAF detection)
            if results['response_snippet'] and 'response_body_patterns' in signatures:
                for body_pattern in signatures['response_body_patterns']:
                    if body_pattern.lower() in results['response_snippet'].lower():
                        confidence += 15  # Response body pattern is strong indicator
                        found_signatures.append(f"Body pattern: {body_pattern}")
                        signature_count += 1
            
            # Check header combinations (multi-factor cloud WAF detection)
            if 'header_combinations' in signatures:
                for combo in signatures['header_combinations']:
                    matches = sum(1 for h in combo if h.lower() in [x.lower() for x in results['headers'].keys()])
                    if matches == len(combo):
                        # All headers in combination present
                        confidence += 20
                        found_signatures.append(f"Header combo: {len(combo)} headers")
                        signature_count += 1
                    elif matches >= len(combo) * 0.7:
                        # Most headers present (70%+)
                        confidence += 10
                        found_signatures.append(f"Partial combo: {matches}/{len(combo)}")
                        signature_count += 1
            
            # Check GCP-specific headers (Google Cloud Armor)
            if 'gcp_headers' in signatures:
                gcp_header_count = sum(1 for h in signatures['gcp_headers'] 
                                      if any(h.lower() in rh.lower() for rh in results['headers'].keys()))
                if gcp_header_count >= 2:
                    confidence += 30  # Multiple GCP headers = strong indicator
                    found_signatures.append(f"GCP headers: {gcp_header_count}")
                    signature_count += 1
            
            # Check cache patterns (Azure Front Door)
            if 'cache_patterns' in signatures and 'x-cache' in results['headers']:
                cache_value = results['headers']['x-cache']
                for cache_pattern in signatures['cache_patterns']:
                    if cache_pattern in cache_value:
                        confidence += 10
                        found_signatures.append(f"Cache pattern: {cache_pattern}")
                        signature_count += 1
            
            # Check status code (low weight, many WAFs use same codes)
            if results['status_code'] in signatures['response_codes']:
                # Give more weight to unique status codes
                if results['status_code'] in [520, 521, 522, 523, 524, 525, 526, 527]:
                    confidence += 15  # Cloudflare-specific codes
                elif results['status_code'] == 406:
                    confidence += 10  # Signal Sciences specific
                elif results['status_code'] == 429:
                    confidence += 10  # Rate limiting (WAF-specific)
                else:
                    confidence += 5  # Common codes
            
            # Bonus for multiple signature types (indicates stronger match)
            if signature_count >= 3:
                confidence += 15
            elif signature_count >= 2:
                confidence += 10
            
            if confidence > 0:
                _cdn_label = signatures.get('_cdn')
                # '_waf_label' key present with None value = CDN-only entry (no WAF)
                # '_waf_label' key absent = legacy hand-crafted entry, treat as WAF
                _has_waf_key = '_waf_label' in signatures
                _waf_label = signatures.get('_waf_label', waf_name)
                # For CDN-only entries (_waf_label explicitly None), waf_vendor is None
                _vendor = _waf_label if (_waf_label is not None) else None
                detected_wafs.append({
                    'vendor': _vendor if _vendor else waf_name,
                    'is_waf': not (_has_waf_key and _waf_label is None),
                    'confidence': min(confidence, 100),
                    'signatures': found_signatures,
                    'signature_count': signature_count,
                    '_cdn': _cdn_label,
                })
                if _cdn_label and _cdn_label not in detected_cdns:
                    detected_cdns.append(_cdn_label)
        
        # Boost confidence from TLS cert org hint
        _tls_hint = results.get('tls_cert', {}).get('waf_hint', '')
        if _tls_hint:
            for dw in detected_wafs:
                if _tls_hint.lower() in dw['vendor'].lower() or dw['vendor'].lower() in _tls_hint.lower():
                    dw['confidence'] = min(dw['confidence'] + 15, 100)
                    dw['signatures'].append(f"TLS cert org: {results['tls_cert'].get('issuer_org', '')}")
                    dw['signature_count'] += 1
                    break
            else:
                # TLS hint vendor not yet in detected list — add as low-confidence detection
                detected_wafs.append({
                    'vendor': _tls_hint,
                    'confidence': 15,
                    'signatures': [f"TLS cert org: {results['tls_cert'].get('issuer_org', '')}"],
                    'signature_count': 1,
                })

        # Sort by confidence, then by signature count
        detected_wafs.sort(key=lambda x: (x['confidence'], x['signature_count']), reverse=True)
        
        # Filter: only WAF entries (is_waf=True)
        # CDN-only entries still contribute to detected_cdns but
        # shouldn't be listed as the WAF vendor.
        waf_detections = [d for d in detected_wafs if d.get('is_waf', True)]

        if waf_detections:
            top_match = waf_detections[0]
            cdn_vendor = top_match.get('_cdn') or (detected_cdns[0] if detected_cdns else None)
            return {
                'waf_detected': True,
                'waf_vendor': top_match['vendor'],
                'cdn_vendor': cdn_vendor,
                'confidence': top_match['confidence'],
                'signatures_found': top_match['signatures'],
                'all_detections': waf_detections,
                'cdn_detections': detected_cdns,
            }
        elif detected_cdns:
            # CDN detected but no WAF
            return {
                'waf_detected': False,
                'waf_vendor': 'No WAF detected',
                'cdn_vendor': detected_cdns[0],
                'confidence': 0,
                'signatures_found': [],
                'all_detections': [],
                'cdn_detections': detected_cdns,
            }
        else:
            return {
                'waf_detected': False,
                'waf_vendor': 'Unknown or No WAF',
                'cdn_vendor': None,
                'confidence': 0,
                'signatures_found': [],
                'all_detections': [],
                'cdn_detections': [],
            }
    
    def print_results(self, results: Dict):
        """Print detection results in a formatted way"""
        
        print(f"\n{Colors.HEADER}{'='*70}{Colors.END}")
        print(f"{Colors.BOLD}WAF Detection Results{Colors.END}")
        print(f"{Colors.HEADER}{'='*70}{Colors.END}")
        
        print(f"\n{Colors.BLUE}Target:{Colors.END} {results['target']}")
        print(f"{Colors.BLUE}Status Code:{Colors.END} {results.get('status_code', 'N/A')}")
        
        if results.get('server'):
            print(f"{Colors.BLUE}Server:{Colors.END} {results['server']}")
        
        print(f"\n{Colors.HEADER}WAF Detection:{Colors.END}")
        
        target = results['target']
        if results['waf_detected']:
            color = Colors.GREEN if results['confidence'] >= 70 else Colors.YELLOW
            print(f"{color}✓ WAF Detected: {results['waf_vendor']}{Colors.END}")
            print(f"{Colors.BLUE}Confidence:{Colors.END} {results['confidence']}%")
            if results.get('cdn_vendor'):
                print(f"{Colors.BLUE}CDN:{Colors.END} {results['cdn_vendor']}")

            if results['signatures_found']:
                print(f"\n{Colors.BLUE}Signatures Found:{Colors.END}")
                for sig in results['signatures_found']:
                    print(f"  • {sig}")

            # Show other possible matches
            if len(results.get('all_detections', [])) > 1:
                print(f"\n{Colors.BLUE}Other Possible Matches:{Colors.END}")
                for detection in results['all_detections'][1:4]:
                    print(f"  • {detection['vendor']} ({detection['confidence']}%)")
        elif results.get('cdn_vendor'):
            print(f"{Colors.YELLOW}~ CDN Detected (no WAF): {results['cdn_vendor']}{Colors.END}")
            cdns = results.get('cdn_detections', [])
            if len(cdns) > 1:
                print(f"{Colors.BLUE}All CDNs:{Colors.END} {', '.join(cdns)}")

            # Next steps
            waf = results['waf_vendor']
            waf_slug = waf.lower().replace(" ", "_").split("(")[0].strip("_")
            print(f"\n{Colors.BOLD}Next Steps:{Colors.END}")
            print(f"  Test WAF bypass:   fray bypass {target} -c xss --waf {waf_slug} -m 30")
            print(f"  Run full test:     fray test {target} -c xss -m 50")
            print(f"  Run recon:         fray recon {target}")
        else:
            print(f"{Colors.YELLOW}✗ No WAF Detected{Colors.END}")
            print(f"  The target may not be using a WAF, or it's using a custom/unknown WAF")
            print(f"\n{Colors.BOLD}Next Steps:{Colors.END}")
            print(f"  Test anyway:       fray test {target} -c xss -m 20")
            print(f"  Run recon:         fray recon {target}")
            print(f"  Scan for inputs:   fray scan {target} -c xss")
        
        print(f"\n{Colors.HEADER}{'='*70}{Colors.END}\n")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='WAF Detector - Identify Web Application Firewall vendors',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Supported WAF/CDN Vendors (98 total):
  WAF+CDN: Cloudflare, Akamai, AWS WAF/Shield/CloudFront, Azure Front Door,
           Google Cloud Armor, Imperva, Fastly, Sucuri, Edgecast, Alibaba Cloud WAF,
           Tencent Cloud WAF, Baidu Cloud WAF, Huawei Cloud WAF, CDNetworks,
           StackPath, Limelight/Edgio, DDoS-Guard, ArvanCloud, Section.io, Instart,
           Webscale
  CDN-only: Azure CDN, Google Cloud CDN, KeyCDN, CDN77, BunnyCDN, MaxCDN,
            ChinaCache, CacheFly, Highwinds, Yottaa, GCore, Netlify, Vercel,
            Fly.io, Render, Railway
  Standalone WAF: F5 BIG-IP, Barracuda, FortiWeb, FortiADC, Citrix NetScaler,
                  ModSecurity, NAXSI, WebKnight, Wallarm, Radware, DenyAll,
                  SonicWall, Comodo, Wordfence, Shield Security, NinjaFirewall,
                  Prisma Cloud WAAS, Check Point CloudGuard, Sophos, Juniper WAS,
                  Airlock, A10 Thunder, Qualys WAF, Reblaze, LiteSpeed, OpenResty,
                  Zenedge, Qrator, StormWall, BitNinja, ThreatX, AppTrana, Prophaze
  Bot Protection: PerimeterX/HUMAN, DataDome, Kasada, Shape Security, ThreatX,
                  FingerprintJS, DataDog ASM, Contrast Security, Signal Sciences

Examples:
  # Detect WAF for a domain
  python3 waf_detector.py -t https://example.com
  
  # Detect WAF for multiple targets
  python3 waf_detector.py -t https://example.com -t https://api.example.com
  
  # Detect WAF from targets file
  python3 waf_detector.py --targets-file targets.txt
        """
    )
    
    parser.add_argument('-t', '--target', action='append', help='Target URL to check (can be used multiple times)')
    parser.add_argument('--targets-file', help='File containing list of target URLs (one per line)')
    parser.add_argument('--timeout', type=int, default=8, help='Request timeout (seconds)')
    parser.add_argument('-o', '--output', help='Output JSON file for results')
    
    args = parser.parse_args()
    
    # Get list of targets
    targets = []
    if args.targets_file:
        try:
            with open(args.targets_file, 'r') as f:
                targets = [line.strip() for line in f if line.strip() and not line.strip().startswith('#')]
        except Exception as e:
            print(f"{Colors.RED}Error loading targets file: {e}{Colors.END}")
            return
    elif args.target:
        targets = args.target
    else:
        parser.print_help()
        return
    
    # Detect WAF for each target
    detector = WAFDetector()
    all_results = []
    
    for target in targets:
        print(f"\n{Colors.BLUE}Checking: {target}{Colors.END}")
        results = detector.detect_waf(target, timeout=args.timeout)
        detector.print_results(results)
        all_results.append(results)
    
    # Save results if output file specified
    if args.output:
        import json
        with open(args.output, 'w') as f:
            json.dump(all_results, f, indent=2)
        print(f"{Colors.GREEN}✓ Results saved to: {args.output}{Colors.END}\n")


if __name__ == '__main__':
    main()
