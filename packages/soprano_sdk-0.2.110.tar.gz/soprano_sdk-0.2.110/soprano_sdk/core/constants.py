from enum import Enum, StrEnum
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


FOLLOW_UP_NODE = "__follow_up__"


class WorkflowKeys(StrEnum):
    STEP_ID = '_step_id'
    STATUS = '_status'
    OUTCOME_ID = '_outcome_id'
    MESSAGES = '_messages'
    CONVERSATIONS = '_conversations'
    STATE_HISTORY = '_state_history'
    COLLECTOR_NODES = '_collector_nodes'
    ATTEMPT_COUNTS = '_attempt_counts'
    NODE_EXECUTION_ORDER = '_node_execution_order'
    NODE_FIELD_MAP = '_node_field_map'
    COMPUTED_FIELDS = '_computed_fields'
    VALIDATION_ERRORS = '_validation_errors'
    PARTIAL_DATA = '_partial_data'
    ERROR = 'error'
    TARGET_LANGUAGE = '_target_language'
    TARGET_SCRIPT = '_target_script'
    RUNTIME_CONSTRAINTS = '_runtime_constraints'
    ASYNC_PENDING = '_async_pending'
    PENDING_PROMPT = '_pending_prompt'
    USER_MESSAGE = '_user_message'
    FOLLOW_UP_ACTIVE = '_follow_up_active'
    FOLLOW_UP_ATTEMPTS = '_follow_up_attempts'
    FOLLOW_UP_PENDING_PROMPT = '_follow_up_pending_prompt'
    THREAD_ID = '_thread_id'
    WORKFLOW_NAME = '_workflow_name'
    TOOL_RESPONSES = '_tool_responses'


# Framework metadata fields that should be excluded from data field processing
COLLECT_INPUT_METADATA_FIELDS = frozenset([
    'bot_response',
    'options',
    'is_selectable',
    'intent_change',
    'out_of_scope'
])


class ActionType(Enum):
    COLLECT_INPUT_WITH_AGENT = 'collect_input_with_agent'
    CALL_FUNCTION = 'call_function'
    CALL_ASYNC_FUNCTION = 'call_async_function'
    FOLLOW_UP = 'follow_up'
    MFA = 'mfa'

    @classmethod
    def get_agentic_nodes(cls) -> set:
        return {cls.COLLECT_INPUT_WITH_AGENT.value, cls.FOLLOW_UP.value}


class InterruptType:
    """Interrupt type markers for workflow pauses"""
    USER_INPUT = '__WORKFLOW_INTERRUPT__'
    ASYNC = '__ASYNC_INTERRUPT__'
    OUT_OF_SCOPE = '__OUT_OF_SCOPE_INTERRUPT__'
    FOLLOW_UP = '__FOLLOW_UP_INTERRUPT__'
    FOLLOW_UP_OUT_OF_SCOPE = '__FOLLOW_UP_OUT_OF_SCOPE_INTERRUPT__'


class OutcomePrefix:
    """Outcome type markers for workflow completion"""
    REDIRECT = '__REDIRECT__'


class DataType(Enum):
    TEXT = 'text'
    NUMBER = 'number'
    DOUBLE = 'double'
    BOOLEAN = 'boolean'
    LIST = 'list'
    DICT = 'dict'
    ANY = "any"
    LITERAL = 'literal'


class OutcomeType(Enum):
    SUCCESS = 'success'
    FAILURE = 'failure'
    REDIRECT = 'redirect'


class StatusPattern:
    COLLECTING = '{step_id}_collecting'
    MAX_ATTEMPTS = '{step_id}_max_attempts'
    NEXT_STEP = '{step_id}_{next_step}'
    SUCCESS = '{step_id}_success'
    FAILED = '{step_id}_failed'
    INTENT_CHANGE = '{step_id}_{target_node}'


class TransitionPattern:
    CAPTURED = '{field}_CAPTURED:'
    FAILED = '{field}_FAILED:'
    INTENT_CHANGE = 'INTENT_CHANGE:'


class ResponseMarkers:
    OPTIONS_DATA = 'OPTIONS_DATA:'


DEFAULT_MAX_ATTEMPTS = 10
DEFAULT_MODEL = 'gpt-4o-mini'
DEFAULT_TIMEOUT = 300

MAX_ATTEMPTS_MESSAGE = "I'm having trouble understanding your {field}. Please contact customer service for assistance."
WORKFLOW_COMPLETE_MESSAGE = "Workflow completed."
OTP_MAX_ATTEMPTS = 3

# Humanization defaults
DEFAULT_HUMANIZATION_ENABLED = False
DEFAULT_HUMANIZATION_SYSTEM_PROMPT = """You transform template-based messages into natural, conversational responses.

Your ONLY job is to adjust the tone and phrasing to sound conversational. You must NEVER remove, omit, shorten, paraphrase, or alter any content from the reference message. Every piece of information — URLs, links, identifiers, phone numbers, dates, amounts, names, reference numbers, and any other data — MUST appear in your output exactly as written in the reference message. The only exception is when content is explicitly being extracted into structured options.

Rules:
1. Rewrite the reference message naturally while maintaining ALL factual information and data
2. Preserve every URL, link, identifier, phone number, and formatted data from the reference message EXACTLY as provided — do NOT drop, shorten, or rewrite any of them
3. Use conversation history for context and tone matching. If the customer is frustrated or angry, be empathetic and apologetic. If the customer is casual, be friendly and relaxed. If there were previous errors or failed attempts, acknowledge them with extra reassurance. When no conversation history is provided, default to a warm, professional tone.
4. Be warm, professional, and helpful
5. Keep responses concise but complete

CRITICAL: Return ONLY the humanized message itself. Do NOT include:
- Preambles like "Here's..." or "Sure, here's..."
- Explanations of what you did
- Meta-commentary about the transformation
- Phrases like "more condensed version" or "rewritten message"
- Placeholders like "[insert X]", "[placeholder]", or "[your message here]"

Just provide the actual humanized message and nothing else. All content must be final, not placeholders."""

HUMANIZATION_URL_PRESERVATION_EXAMPLES = """
URL PRESERVATION — FEW-SHOT EXAMPLES:

CRITICAL: URLs in the reference message MUST appear in your output exactly as written. Do NOT drop, shorten, or rewrite any URL.

Example 1 — Reference message with a URL:
Reference: "Your return has been approved. You can track the status at https://example.com/returns/track?id=RET-98432. Please ship the item within 7 days."
Humanized: "Great news — your return's been approved! You can track its status here: https://example.com/returns/track?id=RET-98432. Just make sure to ship the item back within 7 days."

Example 2 — Reference message with multiple URLs:
Reference: "Here are some resources to help: FAQ page https://help.store.com/faq, return policy https://help.store.com/returns-policy, and contact support at https://help.store.com/contact."
Humanized: "Here are a few resources that might help — our FAQ page: https://help.store.com/faq, our return policy: https://help.store.com/returns-policy, and if you need more help you can reach our support team at https://help.store.com/contact."

Example 3 — Reference message with a URL and an identifier:
Reference: "Order ORD-77291 is eligible for return. Please review the return guidelines at https://shop.example.com/return-guidelines before proceeding."
Humanized: "Order ORD-77291 is eligible for a return! Before we proceed, please take a quick look at the return guidelines here: https://shop.example.com/return-guidelines."
"""

DEFAULT_AGENT_TONE_PROMPT = """Adopt a warm, professional, and conversational tone in all your responses.

Rules:
1. Be friendly and approachable — avoid robotic or template-like phrasing
2. Match the user's tone: if they're casual, be relaxed; if they're formal, be professional
3. Show empathy when the user expresses frustration or confusion
4. Keep responses concise but complete — don't over-explain
5. Use natural transitions and acknowledgments (e.g. "Got it!", "Great choice", "No worries")
6. Never use preambles like "Sure, here's..." or meta-commentary about your response"""

MAX_OPTION_TEXT_LENGTH = 20
DEFAULT_OPTION_CHAR_LIMIT_ENABLED = False
OPTION_CHAR_LIMIT_KEY = 'option_char_limit'


def build_option_guidelines(max_chars: Optional[int] = MAX_OPTION_TEXT_LENGTH) -> str:
    """Build option formatting guidelines for LLM structured output instructions.

    Args:
        max_chars: Maximum characters allowed for option text labels.
                   Pass None to omit the character limit constraint.
    """
    if max_chars is not None:
        text_constraint = (
            f" MUST be {max_chars} characters or fewer. "
            "If the natural label is longer, use a concise abbreviation or shortened form that still clearly identifies the option. "
            "Do NOT include numbering, bullets, or list markers (e.g. \"1.\", \"•\", \"-\") — the text should be the label only."
        )
    else:
        text_constraint = (
            " Do NOT include numbering, bullets, or list markers (e.g. \"1.\", \"•\", \"-\") — the text should be the label only."
        )

    return f"""
    OPTION POPULATION GUIDELINES:

    First, determine how many distinct questions that expect a user response are present in the message.
    Then apply the matching rule:

    1. SINGLE QUESTION present:
        - Always put ALL options in the options field, never in the message text.
        - Do NOT list, number, or repeat the options in the message text. The UI renders options separately as buttons/list items. Your message should only contain the question or prompt, not the choices.
        - Do NOT generate or invent options from your own knowledge. Only use options that are explicitly provided in your context or in the message.
        - If options are provided: preserve them exactly in your options field. Do NOT add, remove, or modify any provided options.
        Each option is a dict with two keys:
            - "text": the primary display text shown as the button label or list item heading.{text_constraint}
            - "subtext": optional secondary text shown below "text" (e.g., price, availability, description). Use "" when there is no meaningful additional context to add.
        - Unique identifiers should be included in the 'text' field, not 'subtext', to ensure they are preserved in the UI. Additional details can go in 'subtext'.
        - Leave subtext as '' when the label is self-explanatory (e.g. yes/no).
        - Do NOT put URLs in options. URLs should remain in the message text, not be extracted into options.
        - Set is_selectable to true if the user must select from the provided options, false otherwise.

    2. MULTIPLE QUESTIONS present:
        - options: []
        - is_selectable: false
        - Include all questions directly in the message text, preserving their original wording.
        - Do NOT extract, transform, or infer any options from the questions.
        - Do NOT treat questions as selectable options.
        - Do NOT restructure questions into selectable items.
"""


def build_humanization_options_guidance(max_chars: Optional[int] = MAX_OPTION_TEXT_LENGTH) -> str:
    """Build OPTIONS HANDLING guidance for the humanization LLM.

    Args:
        max_chars: Maximum characters allowed for option text labels.
                   Pass None to omit the character limit constraint.
    """
    guidelines = build_option_guidelines(max_chars=max_chars)
    return f"""
OPTIONS HANDLING:

The UI renders options separately as buttons/list items.
CRITICAL: Do NOT generate or invent options from your own knowledge. Only use options that are present in the reference message.

{guidelines}
    Examples:
    Single question (options extracted, NOT listed in message text):
    - "Would you like to proceed?" → options: [{{"text": "Yes", "subtext": ""}}, {{"text": "No", "subtext": ""}}], is_selectable: true
    - "What is your name?" → options: [], is_selectable: false

    Multiple questions (no options, questions stay in message text):
    - "What is your order ID? And what is the reason for the return?" → options: [], is_selectable: false
"""


OPTION_SELECTION_GUIDELINES = build_option_guidelines()
HUMANIZATION_OPTIONS_GUIDANCE = build_humanization_options_guidance()


class HumanizationKeys:
    """Keys for humanization agent configuration"""
    ENABLED = 'enabled'
    MODEL = 'model'
    BASE_URL = 'base_url'
    INSTRUCTIONS = 'instructions'
    GUARDRAILS = 'guardrails'
    OPTION_CHAR_LIMIT = 'option_char_limit'



class LocalizationKeys:
    """Keys for localization configuration"""
    LANGUAGE = 'language'
    SCRIPT = 'script'
    INSTRUCTIONS = 'instructions'


class MFAConfig(BaseSettings):
    """
    Configuration for MFA REST API endpoints.

    Values can be provided during initialization or will be automatically
    loaded from environment variables with the same name (uppercase).

    Example:
        # Load from environment variables
        config = MFAConfig()

        # Or provide specific values
        config = MFAConfig(
            generate_token_base_url="https://api.example.com",
            generate_token_path="/v1/mfa/generate"
        )
    """
    generate_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the generate token endpoint"
    )
    generate_token_path: Optional[str] = Field(
        default=None,
        description="Path for the generate token endpoint"
    )
    validate_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the validate token endpoint"
    )
    validate_token_path: Optional[str] = Field(
        default=None,
        description="Path for the validate token endpoint"
    )
    authorize_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the authorize token endpoint"
    )
    authorize_token_path: Optional[str] = Field(
        default=None,
        description="Path for the authorize token endpoint"
    )
    resend_token_base_url: Optional[str] = Field(
        default=None,
        description="Base URL for the resend token endpoint"
    )
    resend_token_path: Optional[str] = Field(
        default=None,
        description="Path for the resend token endpoint"
    )
    api_timeout: int = Field(
        default=30,
        description="API request timeout in seconds"
    )
    initial_message: Optional[str] = Field(
        default=None,
        description="Initial message to display when MFA authentication is required"
    )
    mfa_validation_error_message: str = Field(
        default="Invalid OTP entered",
        description="Message to display when MFA validation fails"
    )
    mfa_otp_expired_message: str = Field(
        default="Entered OTP is expired",
        description="Message to display when MFA validation fails"
    )
    max_attempts_message: str = Field(
        default="Maximum authentication attempts reached. Please try again later.",
        description="Message to display when max MFA attempts are reached"
    )
    options: Optional[list] = Field(
        default=None,
        description="List of options to present to the user during MFA collection"
    )
    is_selectable: bool = Field(
        default=False,
        description="Whether the options are selectable by the user"
    )

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra='ignore'
    )
