import uuid
import respx
import json
from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_prompt,
    collector_capture,
    fu_answer,
    fu_intent_change,
    make_tool,
)


@respx.mock
def test_follow_up_excludes_configured_nodes_from_guidance():
    """Verify that nodes listed in excluded_nodes are not presented in the follow-up
    system prompt guidance.
    """
    responses = iter([
        collector_prompt("What is field A?"),  # T1
        collector_capture("val_a", "field_a"),           # T2 (captures A, prompts B)
        collector_prompt("What is field B?"),  # T3
        collector_capture("val_b", "field_b"),           # T3 (captures B, enters follow-up)
        fu_answer("I am follow-up")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_exclusion.yaml")
    tid = str(uuid.uuid4())

    # T1: Start
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a")
    tool.execute(thread_id=tid, user_message="val_b")
    
    # follow-up
    tool.execute(thread_id=tid, user_message="Hello")
    
    last_request = respx.calls.last.request
    body = json.loads(last_request.content)
    messages = body["messages"]
    full_system_prompt = next((msg["content"] for msg in messages if msg["role"] == "system"), "")
    
    # assert 0
    assert "INTENT CHANGE" in full_system_prompt
    assert "collect_a: Collector A" in full_system_prompt
    assert "collect_b" not in full_system_prompt


@respx.mock
def test_follow_up_excludes_configured_nodes_from_guidance_intent_change():
    """Verify that nodes listed in excluded_nodes are not presented in the follow-up during intent change
    system prompt guidance.
    """
    responses = iter([
        collector_prompt("What is field A?"),  # T1
        collector_capture("val_a", "field_a"),           # T2 (captures A, prompts B)
        collector_prompt("What is field B?"),  # T3
        collector_capture("val_b", "field_b"),           # T3 (captures B, enters follow-up)
        fu_answer("I am follow-up"),
        fu_intent_change("collect_a", "Intent change to A"),
        collector_prompt("What is field A?"),  # T1
        collector_capture("val_a", "field_a"),           # T2 (captures A, prompts B)
        collector_prompt("What is field B?"),  # T3
        collector_capture("val_b", "field_b"),           # T3 (captures B, enters follow-up)
        fu_answer("I am follow-up"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_exclusion.yaml")
    tid = str(uuid.uuid4())

    # T1: Start
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a")
    tool.execute(thread_id=tid, user_message="val_b")
    
    # follow-up
    tool.execute(thread_id=tid, user_message="Hello")

    # intent change
    tool.execute(thread_id=tid, user_message="Intent change to A")
    

    # T1: Start
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a")
    tool.execute(thread_id=tid, user_message="val_b")
    
    # follow-up
    tool.execute(thread_id=tid, user_message="Hello")
    
    last_request = respx.calls.last.request
    body = json.loads(last_request.content)
    messages = body["messages"]
    full_system_prompt = next((msg["content"] for msg in messages if msg["role"] == "system"), "")
    
    # assert 0
    assert "INTENT CHANGE" in full_system_prompt
    assert "collect_a: Collector A" in full_system_prompt
    assert "collect_b" not in full_system_prompt



@respx.mock
def test_follow_up_force_routing_to_excluded_node():
    """Verify that force routing to excluded node results in self loop.
    """
    responses = iter([
        collector_prompt("What is field A?"),  # T1
        collector_capture("val_a", "field_a"),           # T2 (captures A, prompts B)
        collector_prompt("What is field B?"),  # T3
        collector_capture("val_b", "field_b"),           # T3 (captures B, enters follow-up)
        fu_answer("I am follow-up"),
        fu_intent_change("collect_b", "Intent change to B"),

    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_exclusion.yaml")
    tid = str(uuid.uuid4())

    # T1: Start
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a")
    tool.execute(thread_id=tid, user_message="val_b")
    
    # follow-up
    tool.execute(thread_id=tid, user_message="Hello")

    # try intent change to B -> self loop
    res = tool.execute(thread_id=tid, user_message="Intent change to B")
    
    last_request = respx.calls.last.request
    body = json.loads(last_request.content)
    messages = body["messages"]
    full_system_prompt = next((msg["content"] for msg in messages if msg["role"] == "system"), "")
    
    assert "INTENT CHANGE" in full_system_prompt
    assert "collect_a: Collector A" in full_system_prompt
    assert "collect_b" not in full_system_prompt

    assert InterruptType.FOLLOW_UP in res
