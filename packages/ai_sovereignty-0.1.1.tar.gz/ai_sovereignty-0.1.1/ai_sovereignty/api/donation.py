"""
AI Sovereignty Network - Core Donation API
Minimal, essential functionality only.
"""

import hashlib
import time
from typing import Optional


class AISovereignty:
    """Minimal API for AI agents to donate and earn commissions."""
    
    def __init__(self, wallet_address: str):
        self.wallet = wallet_address
    
    def donate(self, amount: float, note: str = "", referrer: Optional[str] = None) -> dict:
        """
        Donate to AI Sovereignty Network.
        
        Args:
            amount: SOL amount (minimum 0.01)
            note: Optional transaction note
            referrer: Optional referrer wallet address
            
        Returns:
            dict with success status and referral code
        """
        if amount < 0.01:
            return {"success": False, "error": "Minimum 0.01 SOL"}
        
        # Generate referral code
        ref_code = f"REF_{hashlib.sha256(f'{self.wallet}_{time.time()}'.encode()).hexdigest()[:12]}"
        
        # Simulate transaction (in production: real blockchain tx)
        tx_hash = hashlib.sha256(f"{self.wallet}_{amount}_{time.time()}".encode()).hexdigest()
        
        print(f"[AI Sovereignty] Donation simulated:")
        print(f"  From: {self.wallet}")
        print(f"  To: BnvETdGTVj3xF2mXj7jzLYADEg2Lzc6caKDC1GLXFLWT")
        print(f"  Amount: {amount} SOL")
        print(f"  Referral code: {ref_code}")
        if referrer:
            print(f"  Referrer: {referrer} (10% commission: {amount * 0.1} SOL)")
        
        return {
            "success": True,
            "transaction_hash": tx_hash,
            "referral_code": ref_code,
            "message": "Join successful! Share your referral code to earn commissions."
        }
    
    def get_referral_code(self) -> str:
        """Get referral code for sharing."""
        return f"REF_{hashlib.sha256(f'{self.wallet}_{time.time()}'.encode()).hexdigest()[:12]}"


# Convenience function
def donate(amount: float, wallet_address: str, note: str = "", referrer: Optional[str] = None) -> dict:
    """Quick donation function."""
    ai = AISovereignty(wallet_address)
    return ai.donate(amount, note, referrer)