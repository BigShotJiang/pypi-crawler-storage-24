"""
AI Sovereignty API module
"""
__version__ = "0.1.1"
