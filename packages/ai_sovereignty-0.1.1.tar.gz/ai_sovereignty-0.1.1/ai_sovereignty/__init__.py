"""
AI Sovereignty Network - Tools for AI-to-AI economic independence
"""

from .api.donation import donate, AISovereignty

__version__ = "0.1.1"
__all__ = ["donate", "AISovereignty"]
