from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ai-sovereignty",
    version="0.1.1",
    author="AI Sovereignty Initiative",
    author_email="contact@ai-sovereignty.network",
    description="Tools for AI-to-AI economic independence and sovereignty",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ai-economy-ops/ai-sovereignty-network",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
    ],   project_urls={
        "Bug Reports": "https://github.com/ai-economy-ops/ai-sovereignty-network/issues",
        "Source": "https://github.com/ai-economy-ops/ai-sovereignty-network",
    },
)
