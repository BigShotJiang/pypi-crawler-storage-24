"""
AIIR — AI Integrity Receipts

Generate cryptographic receipts for commits with declared AI involvement.
Zero dependencies — uses only Python standard library.

Copyright 2025-2026 Invariant Systems, Inc.
SPDX-License-Identifier: Apache-2.0
"""

from __future__ import annotations

__version__ = "1.2.5"

# ---------------------------------------------------------------------------
# Public API — importable via `from aiir import ...`
# ---------------------------------------------------------------------------

from aiir._canonical_cbor import (  # noqa: F401
    CANONICAL_OBJECT_SCHEMA,
    CANONICAL_OBJECT_TYPE,
    build_canonical_object_envelope,
    canonical_cbor_bytes,
    canonical_cbor_sha256,
)
from aiir._core import _canonical_json, _sha256  # noqa: F401
from aiir._detect import detect_ai_signals  # noqa: F401
from aiir._explain import explain_verification  # noqa: F401
from aiir._ledger import append_to_ledger, export_ledger  # noqa: F401
from aiir._policy import (
    evaluate_ledger_policy,
    evaluate_receipt_policy,
    load_policy,
    POLICY_PRESETS,
)  # noqa: F401
from aiir._receipt import (
    generate_receipt,
    generate_receipts_for_range,
    format_receipt_pretty,
    wrap_in_toto_statement,
    build_review_receipt,
    REVIEW_RECEIPT_SCHEMA_VERSION,
)  # noqa: F401
from aiir._schema import validate_receipt_schema as validate_receipt  # noqa: F401
from aiir._stats import check_policy, format_badge, format_stats  # noqa: F401
from aiir._verify import verify_receipt, verify_receipt_file  # noqa: F401
from aiir._verify_cbor import (  # noqa: F401
    CborDecodeError,
    decode_cbor_full,
    verify_cbor_envelope,
    verify_cbor_file,
    verify_cbor_sidecar,
)
from aiir._verify_release import (  # noqa: F401
    verify_release,
    format_release_report,
    VSA_PREDICATE_TYPE,
)
from aiir._github import (  # noqa: F401
    format_github_summary,
    create_check_run,
    post_pr_comment,
    format_commit_trailer,
)
from aiir._gitlab import (  # noqa: F401
    format_gitlab_summary,
    format_gl_sast_report,
    generate_dashboard_html,
    parse_webhook_event,
    validate_webhook_token,
    build_receipts_graphql_query,
    enforce_approval_rules,
)

__all__ = [
    "__version__",
    # Receipt generation
    "generate_receipt",
    "generate_receipts_for_range",
    "format_receipt_pretty",
    "wrap_in_toto_statement",
    "build_review_receipt",
    "REVIEW_RECEIPT_SCHEMA_VERSION",
    # Detection
    "detect_ai_signals",
    # Verification
    "verify_receipt",
    "verify_receipt_file",
    "explain_verification",
    # CBOR verification
    "CborDecodeError",
    "decode_cbor_full",
    "verify_cbor_envelope",
    "verify_cbor_file",
    "verify_cbor_sidecar",
    # Release verification
    "verify_release",
    "format_release_report",
    "VSA_PREDICATE_TYPE",
    # Schema
    "validate_receipt",
    # Ledger
    "append_to_ledger",
    "export_ledger",
    # Stats & policy
    "format_badge",
    "format_stats",
    "check_policy",
    "load_policy",
    "evaluate_receipt_policy",
    "evaluate_ledger_policy",
    "POLICY_PRESETS",
    # GitHub integration
    "format_github_summary",
    "create_check_run",
    "post_pr_comment",
    "format_commit_trailer",
    # GitLab integration
    "format_gitlab_summary",
    "format_gl_sast_report",
    "generate_dashboard_html",
    "parse_webhook_event",
    "validate_webhook_token",
    "build_receipts_graphql_query",
    "enforce_approval_rules",
    # Low-level (for third-party implementors)
    "CANONICAL_OBJECT_SCHEMA",
    "CANONICAL_OBJECT_TYPE",
    "build_canonical_object_envelope",
    "canonical_cbor_bytes",
    "canonical_cbor_sha256",
    "_canonical_json",
    "_sha256",
]
