from lerobot.policies.factory import make_pre_post_processors
from lerobot.policies.pi0 import PI0Policy

import torch
import warnings

from hook_vla_layers import *

# hmmm

# Determine device: use CUDA if available, else MPS on macOS, else CPU
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu" if not torch.backends.mps.is_available() else "mps")

print(f"Using device: {device}")

# Load model with device mapping
# This avoids state_dict key remapping issues caused by CUDA→MPS/CPU device mismatch
print("Loading model...")
model = PI0Policy.from_pretrained("lerobot/pi0_base").to(device).eval()
print("Model loaded successfully.")
def main():
    print("Walking through the policy's submodule tree...")
    print(type(model))
    walk_policy_children(model, verbose = True)
    print("Finished walking through the policy's submodule tree.")


if __name__ == "__main__":
    main()