"""Interlatent-instrumented backend for lerobot async inference.

Extends lerobot's PolicyServer with Interlatent activation capture.
The client side is lerobot's unmodified RobotClient.

Usage (drop-in replacement for lerobot's policy_server):
    python -m interlatent.lerobot.async_inference.async_rollout \\
        --host=0.0.0.0 \\
        --port=8080 \\
        --fps=30 \\
        --layer=auto

Then run lerobot's robot client as normal:
    python -m lerobot.async_inference.robot_client \\
        --robot.type=so100_follower ... \\
        --server_address=HOST:8080
"""

import argparse
import os
import time
import logging
import signal
from concurrent import futures

import grpc
import numpy as np

from lerobot.async_inference.configs import PolicyServerConfig
from lerobot.async_inference.policy_server import PolicyServer
from lerobot.transport import services_pb2, services_pb2_grpc
from lerobot.utils.import_utils import register_third_party_plugins

logger = logging.getLogger(__name__)


def _get_checkpoint_name(policy_path: str | None) -> str:
    """Derive a stable checkpoint name from a policy path or HuggingFace repo ID.

    - HF repo ID (contains '/' and is not a local file): uses the first 12 chars
      of the latest commit SHA via huggingface_hub.
    - Local file path: uses the unix epoch of the file's mtime.
    - None / fallback: uses current unix timestamp.
    """
    if policy_path is None:
        return str(int(time.time()))
    if "/" in policy_path and not os.path.exists(policy_path):
        # Treat as HuggingFace repo ID
        try:
            from huggingface_hub import repo_info
            info = repo_info(policy_path, repo_type="model")
            return info.sha[:12]
        except Exception:
            return str(int(time.time()))
    # Local file path → unix epoch mtime
    try:
        return str(int(os.stat(policy_path).st_mtime))
    except OSError:
        return str(int(time.time()))


def _proprio_context_fn(*, obs, reward, done, truncated, info):
    """context_fn for watch(): promotes named proprioception from info into ctx."""
    if info and "_proprio" in info:
        return {"observations": info["_proprio"]}
    return {}


class InterlatentPolicyServer(PolicyServer):
    """PolicyServer extended with Interlatent activation capture.

    Hooks Interlatent into the policy after it loads, capturing activations
    on every forward pass through the policy network automatically.
    On graceful shutdown, flushes and uploads all captured data to the Interlatent platform.
    """

    def __init__(
        self,
        config: PolicyServerConfig,
        *,
        interlatent_client,
        layer: str = "auto",
        collection_name: str,
        env_name: str | None = None,
        failures: dict[str, str] | None = None,
        successes: dict[str, str] | None = None,
    ) -> None:
        super().__init__(config)
        self._il = interlatent_client
        self._layer = layer
        self._collection_name = collection_name
        self._env_name = env_name
        self._failures = failures
        self._successes = successes
        self._inference_count = 0

        logger.info(f"InterlatentPolicyServer initialized with layer='{self._layer}', collection='{self._collection_name}', env='{self._env_name}'")

    # ------------------------------------------------------------------
    # Override: checkpoint when a client session ends (new client connects)
    # ------------------------------------------------------------------

    def Ready(self, request, context):  # noqa: N802
        # A new client is connecting. If the prior session produced data,
        # checkpoint before the server state is reset.
        if self._il is not None and self._inference_count > 0:
            try:
                logger.info("New client connecting — checkpointing Interlatent data from prior session...")
                self._il.checkpoint()
                logger.info("Interlatent mid-session checkpoint complete")
            except Exception as exc:
                logger.warning(f"Interlatent mid-session checkpoint failed: {exc}")
            finally:
                self._inference_count = 0

        return super().Ready(request, context)

    # ------------------------------------------------------------------
    # Override: hook Interlatent after policy loads
    # ------------------------------------------------------------------

    def SendPolicyInstructions(self, request, context):  # noqa: N802
        response = super().SendPolicyInstructions(request, context)

        if self.policy is not None and self._il is not None:
            self._il.watch(
                self.policy,
                env_name=self._env_name or f"lerobot_{self.policy_type}",
                layer=self._layer,
                collection_name=self._collection_name,
                capture_frames=True,
                context_fn=_proprio_context_fn,
            )
            logger.info(f"Interlatent watching policy ({self.policy_type}) on layer '{self._layer}'")

        return response

    # ------------------------------------------------------------------
    # Override: count inferences and checkpoint periodically
    # ------------------------------------------------------------------

    def _predict_action_chunk(self, observation_t):
        result = super()._predict_action_chunk(observation_t)
        self._inference_count += 1

        logger.info(observation_t.observation.keys())

        if self._il is not None:
            raw_obs = observation_t.observation
            frame = None
            named_proprio: dict[str, float] = {}

            image_suffixes = {k.rsplit(".", 1)[-1] for k in (self.policy_image_features or {})}
            for key, value in raw_obs.items():
                if key in image_suffixes:
                    if frame is None:
                        frame = value
                else:
                    try:
                        arr = np.asarray(value).flatten()
                        if len(arr) == 1:
                            named_proprio[key] = float(arr[0])
                        else:
                            for i, v in enumerate(arr):
                                named_proprio[f"{key}_{i}"] = float(v)
                    except Exception:
                        pass

            try:
                self._il.tick(
                    obs=None,
                    frame=frame,
                    info={"_proprio": named_proprio} if named_proprio else None,
                )
            except Exception as exc:
                logger.debug(f"Interlatent tick failed: {exc}")

        return result

    # ------------------------------------------------------------------
    # Override: flush and upload on shutdown
    # ------------------------------------------------------------------

    def stop(self) -> None:
        if self._il is not None:
            try:
                logger.info("checkpointing Interlatent data...")
                self._il.checkpoint(sae_k = 18)
                logger.info("Interlatent final checkpoint complete")
            except Exception as exc:
                logger.warning(f"Interlatent final checkpoint failed: {exc}")
            finally:
                self._il.close()

        super().stop()


# ---------------------------------------------------------------------------
# Server entrypoint
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="lerobot PolicyServer with Interlatent activation capture."
    )
    # Server config (mirrors lerobot PolicyServerConfig fields)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--inference-latency", type=float, default=1 / 30)
    parser.add_argument("--obs-queue-timeout", type=float, default=2.0)
    # Interlatent config
    parser.add_argument("--api-key", default=None)
    parser.add_argument(
        "--collection-name",
        required=False,
        default=None,
        help="Explicit checkpoint name. If omitted, derived from --policy-path.",
    )
    parser.add_argument(
        "--policy-path",
        default=None,
        help=(
            "HuggingFace repo ID (e.g. 'lerobot/act_so100') or local checkpoint "
            "file path. Used to derive a stable checkpoint name. Either this or "
            "--collection-name must be provided."
        ),
    )
    parser.add_argument("--env-name", default=None, help="Environment name override. Defaults to 'lerobot_<policy_type>'.")
    parser.add_argument("--layer", default="auto", help="Layer to capture activations from.")
    return parser


def serve() -> None:
    """Console script entrypoint: interlatent-lerobot-server."""
    import os
    from interlatent import Interlatent

    logging.basicConfig(level=logging.INFO)
    register_third_party_plugins()

    args = _build_parser().parse_args()

    api_key = args.api_key or os.environ.get("INTERLATENT_API_KEY")
    if not api_key:
        raise ValueError(
            "An Interlatent API key is required. "
            "Pass --api-key or set the INTERLATENT_API_KEY environment variable."
        )

    # Derive checkpoint name from --policy-path or fall back to --collection-name
    if args.policy_path:
        collection_name = _get_checkpoint_name(args.policy_path)
        logger.info("Derived checkpoint name '%s' from policy path '%s'", collection_name, args.policy_path)
    elif args.collection_name:
        collection_name = args.collection_name
    else:
        raise ValueError(
            "Either --policy-path or --collection-name must be provided."
        )

    il_client = Interlatent(api_key=api_key, db_path=f"./interlatent_runs/{time.time()}/raw.db", collection_name=collection_name)

    cfg = PolicyServerConfig(
        host=args.host,
        port=args.port,
        fps=args.fps,
        inference_latency=args.inference_latency,
        obs_queue_timeout=args.obs_queue_timeout,
    )

    server_impl = InterlatentPolicyServer(
        cfg,
        interlatent_client=il_client,
        layer=args.layer,
        collection_name=collection_name,
        env_name=args.env_name,
    )

    grpc_server = grpc.server(futures.ThreadPoolExecutor(max_workers=4))
    services_pb2_grpc.add_AsyncInferenceServicer_to_server(server_impl, grpc_server)
    grpc_server.add_insecure_port(f"{args.host}:{args.port}")

    def _handle_signal(signum, frame):
        logger.info("Shutdown signal received, stopping gRPC server...")
        grpc_server.stop(grace=10)

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    logger.info(f"InterlatentPolicyServer listening on {args.host}:{args.port}")
    grpc_server.start()
    grpc_server.wait_for_termination()

    logger.info("Shutting down, flushing Interlatent data...")
    server_impl.stop()


if __name__ == "__main__":
    serve()
