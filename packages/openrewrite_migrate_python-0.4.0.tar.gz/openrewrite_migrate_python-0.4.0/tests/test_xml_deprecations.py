"""Tests for XML deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.xml_deprecations import (
    ReplaceElementGetchildren,
    ReplaceElementGetiterator,
)

class TestReplaceElementGetiterator:
    """Tests for ReplaceElementGetiterator recipe."""

    def test_replaces_getiterator(self):
        spec = RecipeSpec(recipe=ReplaceElementGetiterator())
        spec.rewrite_run(
            python(
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                items = list(root.getiterator())
                """,
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                items = list(root.iter())
                """,
            )
        )

    def test_replaces_getiterator_with_tag(self):
        spec = RecipeSpec(recipe=ReplaceElementGetiterator())
        spec.rewrite_run(
            python(
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                tags = list(root.getiterator('tag'))
                """,
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                tags = list(root.iter('tag'))
                """,
            )
        )

    def test_no_change_when_already_iter(self):
        spec = RecipeSpec(recipe=ReplaceElementGetiterator())
        spec.rewrite_run(
            python(
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                items = list(root.iter())
                """
            )
        )

class TestReplaceElementGetchildren:
    """Tests for ReplaceElementGetchildren recipe."""

    def test_replaces_getchildren(self):
        spec = RecipeSpec(recipe=ReplaceElementGetchildren())
        spec.rewrite_run(
            python(
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                children = root.getchildren()
                """,
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                children = list(root)
                """,
            )
        )

    def test_replaces_getchildren_on_complex_select(self):
        spec = RecipeSpec(recipe=ReplaceElementGetchildren())
        spec.rewrite_run(
            python(
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                children = root.find('tag').getchildren()
                """,
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                children = list(root.find('tag'))
                """,
            )
        )

    def test_no_change_when_different_method(self):
        spec = RecipeSpec(recipe=ReplaceElementGetchildren())
        spec.rewrite_run(
            python(
                """
                import xml.etree.ElementTree as ET
                root = ET.parse('data.xml').getroot()
                children = list(root)
                """
            )
        )
