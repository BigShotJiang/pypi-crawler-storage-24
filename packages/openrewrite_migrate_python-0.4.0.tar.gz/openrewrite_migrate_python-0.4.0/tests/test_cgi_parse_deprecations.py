"""Tests for cgi.parse_qs/qsl → urllib.parse.parse_qs/qsl replacement recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.cgi_parse_deprecations import (
    ReplaceCgiParseQs,
    ReplaceCgiParseQsl,
)

class TestReplaceCgiParseQs:
    """Tests for ReplaceCgiParseQs recipe."""

    def test_replaces_cgi_parse_qs(self):
        spec = RecipeSpec(recipe=ReplaceCgiParseQs())
        spec.rewrite_run(
            python(
                """
                import cgi
                params = cgi.parse_qs(query)
                """,
                """
                import cgi
                params = urllib.parse.parse_qs(query)
                """,
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceCgiParseQs())
        spec.rewrite_run(
            python(
                """
                import other
                params = other.parse_qs(query)
                """
            )
        )

    def test_no_change_when_already_urllib(self):
        spec = RecipeSpec(recipe=ReplaceCgiParseQs())
        spec.rewrite_run(
            python(
                """
                import urllib.parse
                params = urllib.parse.parse_qs(query)
                """
            )
        )

class TestReplaceCgiParseQsl:
    """Tests for ReplaceCgiParseQsl recipe."""

    def test_replaces_cgi_parse_qsl(self):
        spec = RecipeSpec(recipe=ReplaceCgiParseQsl())
        spec.rewrite_run(
            python(
                """
                import cgi
                params = cgi.parse_qsl(query)
                """,
                """
                import cgi
                params = urllib.parse.parse_qsl(query)
                """,
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceCgiParseQsl())
        spec.rewrite_run(
            python(
                """
                import other
                params = other.parse_qsl(query)
                """
            )
        )
