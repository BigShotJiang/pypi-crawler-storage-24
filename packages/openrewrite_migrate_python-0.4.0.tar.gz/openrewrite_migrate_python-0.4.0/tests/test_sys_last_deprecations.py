"""Tests for sys.last_type/value/traceback → sys.last_exc replacement recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.sys_last_deprecations import (
    ReplaceSysLastExcInfo,
)

class TestReplaceSysLastExcInfo:
    """Tests for ReplaceSysLastExcInfo recipe."""

    def test_replaces_sys_last_value(self):
        """last_value is semantically equivalent to last_exc — auto-replaced."""
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                v = sys.last_value
                """,
                """
                import sys
                v = sys.last_exc
                """,
            )
        )

    def test_flags_sys_last_type(self):
        """last_type needs type(sys.last_exc) — flagged for manual review."""
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                t = sys.last_type
                """,
                """
                import sys
                t = /*~~(sys.last_type is deprecated in Python 3.12. Use type(sys.last_exc) instead.)~~>*/sys.last_type
                """,
            )
        )

    def test_flags_sys_last_traceback(self):
        """last_traceback needs sys.last_exc.__traceback__ — flagged for manual review."""
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                tb = sys.last_traceback
                """,
                """
                import sys
                tb = /*~~(sys.last_traceback is deprecated in Python 3.12. Use sys.last_exc.__traceback__ instead.)~~>*/sys.last_traceback
                """,
            )
        )

    def test_no_change_when_using_last_exc(self):
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python(
                """
                import sys
                exc = sys.last_exc
                """
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceSysLastExcInfo())
        spec.rewrite_run(
            python("t = other.last_type")
        )
