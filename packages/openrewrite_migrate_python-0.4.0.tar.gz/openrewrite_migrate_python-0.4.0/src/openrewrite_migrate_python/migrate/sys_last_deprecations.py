"""
Recipe for replacing deprecated sys.last_type/last_value/last_traceback
with sys.last_exc.

sys.last_type, sys.last_value, and sys.last_traceback were deprecated in
Python 3.12 in favor of sys.last_exc.

- sys.last_value is semantically equivalent to sys.last_exc (auto-replaced)
- sys.last_type and sys.last_traceback are not direct equivalents
  (would need type(sys.last_exc) and sys.last_exc.__traceback__) and are
  flagged for manual review.

See: https://docs.python.org/3/whatsnew/3.12.html#deprecated
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import FieldAccess, Identifier
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


@categorize(_Python312)
class ReplaceSysLastExcInfo(Recipe):
    """
    Replace `sys.last_value` with `sys.last_exc` and flag `sys.last_type`
    and `sys.last_traceback` for manual review.

    These attributes were deprecated in Python 3.12 in favor of
    `sys.last_exc` which provides the exception object directly.

    Only `sys.last_value` is semantically equivalent to `sys.last_exc`.
    `sys.last_type` would need `type(sys.last_exc)` and
    `sys.last_traceback` would need `sys.last_exc.__traceback__`,
    which require structural changes beyond a simple rename.

    Example:
        Before:
            import sys
            exc_value = sys.last_value

        After:
            import sys
            exc_value = sys.last_exc
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceSysLastExcInfo"

    @property
    def display_name(self) -> str:
        return "Replace `sys.last_value` with `sys.last_exc` and flag `sys.last_type` / `sys.last_traceback`"

    @property
    def description(self) -> str:
        return (
            "`sys.last_type`, `sys.last_value`, and `sys.last_traceback` were "
            "deprecated in Python 3.12. `sys.last_value` is auto-replaced with "
            "`sys.last_exc`; `sys.last_type` and `sys.last_traceback` are flagged "
            "for manual review."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12", "sys"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if not isinstance(field_access.name, Identifier):
                    return field_access

                attr_name = field_access.name.simple_name
                if attr_name not in ("last_type", "last_value", "last_traceback"):
                    return field_access

                target = field_access.target
                if not isinstance(target, Identifier):
                    return field_access
                if target.simple_name != "sys":
                    return field_access

                # Only last_value is a direct semantic equivalent of last_exc
                if attr_name == "last_value":
                    new_identifier = field_access.name.replace(_simple_name="last_exc")
                    old_padded = field_access.padding.name
                    new_padded = old_padded.replace(_element=new_identifier)
                    return field_access.padding.replace(_name=new_padded)

                # last_type and last_traceback need structural changes
                # (type(sys.last_exc) and sys.last_exc.__traceback__)
                if attr_name == "last_type":
                    return mark_deprecated(
                        field_access,
                        "sys.last_type is deprecated in Python 3.12. "
                        "Use type(sys.last_exc) instead."
                    )
                else:  # last_traceback
                    return mark_deprecated(
                        field_access,
                        "sys.last_traceback is deprecated in Python 3.12. "
                        "Use sys.last_exc.__traceback__ instead."
                    )

        return Visitor()
