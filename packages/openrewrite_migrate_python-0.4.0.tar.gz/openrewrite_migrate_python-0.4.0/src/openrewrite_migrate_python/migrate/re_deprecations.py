"""
Recipe for replacing deprecated re.template() and finding re.TEMPLATE usage.

re.template() and re.TEMPLATE were deprecated in Python 3.11 and
removed in Python 3.13.

re.template() is replaced with re.compile(). re.TEMPLATE/re.T flags
have no direct replacement and are flagged for manual review.

See: https://docs.python.org/3/whatsnew/3.11.html#deprecated
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import FieldAccess, Identifier, MethodInvocation
from ._markers import mark_deprecated

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


@categorize(_Python311)
class ReplaceReTemplate(Recipe):
    """
    Replace `re.template()` with `re.compile()` and find `re.TEMPLATE` usage.

    `re.template()` and `re.TEMPLATE` (aka `re.T`) were deprecated in
    Python 3.11 and removed in Python 3.13. The template flag made
    patterns match differently but was rarely useful.

    `re.template()` calls are automatically replaced with `re.compile()`.
    `re.TEMPLATE`/`re.T` flags are flagged for manual review since
    there is no direct replacement.

    Example:
        Before:
            import re
            pattern = re.template(r'\\d+')

        After:
            import re
            pattern = re.compile(r'\\d+')
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceReTemplate"

    @property
    def display_name(self) -> str:
        return "Replace `re.template()` with `re.compile()` and flag `re.TEMPLATE`/`re.T`"

    @property
    def description(self) -> str:
        return (
            "`re.template()` was deprecated in Python 3.11 and removed in 3.13. "
            "Calls are auto-replaced with `re.compile()`. "
            "`re.TEMPLATE`/`re.T` flags have no direct replacement and are flagged for manual review."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.11", "re"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "template":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "re":
                    return method

                # Replace template() with compile()
                new_name = method.name.replace(_simple_name="compile")
                return method.replace(_name=new_name)

            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if not isinstance(field_access.name, Identifier):
                    return field_access
                if field_access.name.simple_name not in ("TEMPLATE", "T"):
                    return field_access

                target = field_access.target
                if not isinstance(target, Identifier):
                    return field_access
                if target.simple_name != "re":
                    return field_access

                return mark_deprecated(
                    field_access,
                    f"re.{field_access.name.simple_name} was deprecated in Python 3.11 "
                    "and removed in 3.13."
                )

        return Visitor()
