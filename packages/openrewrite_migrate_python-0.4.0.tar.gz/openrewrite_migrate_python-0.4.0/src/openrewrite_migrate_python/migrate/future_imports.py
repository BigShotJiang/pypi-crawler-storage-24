"""
Recipe for removing obsolete __future__ imports.

In Python 3, many __future__ imports are no longer needed because their
features are enabled by default:
- print_function (default since Python 3.0)
- division (default since Python 3.0)
- unicode_literals (default since Python 3.0)
- absolute_import (default since Python 3.0)
- generators (default since Python 2.3)
- nested_scopes (default since Python 2.2)
- with_statement (default since Python 2.6)

The `annotations` import (PEP 563) is kept because it still has meaning
in Python 3.10+ (postponed evaluation of annotations).
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.java.tree import FieldAccess, Identifier

# Define category path: Python > Migrate
_Migrate = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
]

# __future__ imports that are obsolete in Python 3 and can be safely removed
OBSOLETE_FUTURE_IMPORTS = {
    "print_function",
    "division",
    "unicode_literals",
    "absolute_import",
    "generators",
    "nested_scopes",
    "with_statement",
}


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the imported name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        if isinstance(qualid.name, Identifier):
            return qualid.name.simple_name
    elif isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Migrate)
class RemoveFutureImports(Recipe):
    """
    Remove obsolete `from __future__ import ...` statements.

    In Python 3, many `__future__` imports are enabled by default and
    no longer needed. This recipe removes imports that are obsolete:
    - `print_function` (default since 3.0)
    - `division` (default since 3.0)
    - `unicode_literals` (default since 3.0)
    - `absolute_import` (default since 3.0)
    - `generators` (default since 2.3)
    - `nested_scopes` (default since 2.2)
    - `with_statement` (default since 2.6)

    The `annotations` import (PEP 563) is preserved.

    Example:
        Before:
            from __future__ import print_function, division, annotations

        After:
            from __future__ import annotations
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.RemoveFutureImports"

    @property
    def display_name(self) -> str:
        return "Remove obsolete `__future__` imports"

    @property
    def description(self) -> str:
        return (
            "Remove `from __future__ import ...` statements for features that "
            "are enabled by default in Python 3."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "future"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                # Check if this is a 'from __future__ import ...' statement
                from_part = multi.from_
                if from_part is None:
                    return multi
                if not isinstance(from_part, Identifier):
                    return multi
                if from_part.simple_name != "__future__":
                    return multi

                # Collect imported names and categorize them
                names = multi.names
                keep_indices = []
                for i, import_node in enumerate(names):
                    imported_name = _get_import_name(import_node)
                    if imported_name is not None and imported_name not in OBSOLETE_FUTURE_IMPORTS:
                        keep_indices.append(i)

                # If all names should be kept, no change
                if len(keep_indices) == len(names):
                    return multi

                # If all names should be removed, remove the entire statement
                if len(keep_indices) == 0:
                    # noinspection PyTypeChecker
                    return None

                # Partial removal: keep only non-obsolete names
                old_container = multi.padding.names
                old_elements = list(old_container.padding.elements)
                new_elements = [old_elements[i] for i in keep_indices]

                # Fix spacing: if the first remaining element had extra prefix
                # from being after a comma, use the prefix of the original first element
                if new_elements and keep_indices[0] != 0:
                    original_first = old_elements[0]
                    first = new_elements[0]
                    # Copy the prefix from original first element
                    new_first_elem = first.element.replace(
                        _prefix=original_first.element.prefix
                    )
                    new_elements[0] = first.replace(_element=new_first_elem)

                new_container = old_container.replace(_elements=new_elements)
                return multi.replace(_names=new_container)

        return Visitor()
