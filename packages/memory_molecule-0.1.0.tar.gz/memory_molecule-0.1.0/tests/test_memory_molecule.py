"""Tests for memory-molecule package."""
import os
import sys
import shutil
import tempfile
import unittest
from pathlib import Path

# Add package source to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from memory_molecule import MemoryMolecule, MemoryConfig, MemoryLoader
from memory_molecule.decay import compute_relevance, should_archive, decay_batch, importance_multiplier
from memory_molecule.storage import write_session, read_session
from memory_molecule.recall import recall_by_concept


class TestConfig(unittest.TestCase):
    def test_config_defaults(self):
        """MemoryConfig has correct defaults."""
        cfg = MemoryConfig()
        self.assertEqual(cfg.vault_path, Path("./vault"))
        self.assertIsNone(cfg.db_path)
        self.assertAlmostEqual(cfg.decay_factor, 0.95)
        self.assertAlmostEqual(cfg.archive_threshold, 0.1)
        self.assertEqual(cfg.tier1_max_tokens, 5000)
        self.assertEqual(cfg.tier2_max_tokens, 50000)
        self.assertEqual(cfg.tier3_max_tokens, 150000)
        self.assertEqual(cfg.project, "default")


class TestStore(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_store_creates_file(self):
        """store() writes to vault."""
        mm = MemoryMolecule(MemoryConfig(vault_path=self.tmp, project="test"))
        path = mm.store("test content", memory_type="decision", importance="foundational")
        self.assertTrue(Path(path).exists())
        content = read_session(path)
        self.assertIn("test content", content)
        self.assertIn("foundational", content)


class TestRecall(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_recall_returns_results(self):
        """recall() finds stored content."""
        mm = MemoryMolecule(MemoryConfig(vault_path=self.tmp, project="test"))
        mm.store("oracle architecture patterns and design", memory_type="knowledge", importance="foundational")
        results = mm.recall("oracle architecture")
        self.assertGreater(len(results), 0)
        self.assertIn("oracle", results[0]["content"].lower())


class TestDecay(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_decay_runs(self):
        """decay() returns DecayReport."""
        mm = MemoryMolecule(MemoryConfig(vault_path=self.tmp, project="test"))
        mm.store("some content", memory_type="session")
        report = mm.decay()
        self.assertEqual(report.total_memories, 1)
        self.assertGreaterEqual(report.highest_score, 0.0)
        self.assertLessEqual(report.highest_score, 1.0)


class TestSessionLifecycle(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_on_session_start(self):
        """on_session_start returns RecallBundle."""
        mm = MemoryMolecule(MemoryConfig(vault_path=self.tmp, project="test"))
        bundle = mm.on_session_start()
        self.assertIsInstance(bundle.recent_session, str)
        self.assertIsInstance(bundle.high_relevance, list)
        self.assertIsInstance(bundle.open_threads, list)
        self.assertIsInstance(bundle.decisions, list)


class TestCompression(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_compression_roundtrip(self):
        """write_session + read_session produce identical content."""
        original = "# Test Session\n\nThis is test content with unicode: café résumé naïve"
        path = write_session(self.tmp, "test", "2026-01-01", original)
        recovered = read_session(str(path))
        self.assertEqual(recovered, original)


class TestImportance(unittest.TestCase):
    def test_importance_multiplier(self):
        """hard_constraint > foundational > context > tactical."""
        self.assertGreater(importance_multiplier("hard_constraint"), importance_multiplier("foundational"))
        self.assertGreater(importance_multiplier("foundational"), importance_multiplier("context"))
        self.assertGreater(importance_multiplier("context"), importance_multiplier("tactical"))


class TestLoader(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def test_tier1_load(self):
        """load_tier1 returns dict with expected keys."""
        loader = MemoryLoader(MemoryConfig(vault_path=self.tmp, project="test"))
        result = loader.load_tier1()
        self.assertIn("content", result)
        self.assertIn("tokens", result)
        self.assertIn("sources", result)
        self.assertIsInstance(result["tokens"], int)


class TestImports(unittest.TestCase):
    def test_package_imports(self):
        """from memory_molecule import MemoryMolecule works."""
        from memory_molecule import MemoryMolecule, MemoryConfig, MemoryLoader
        self.assertTrue(callable(MemoryMolecule))
        self.assertTrue(callable(MemoryConfig))
        self.assertTrue(callable(MemoryLoader))

    def test_public_api(self):
        """MemoryMolecule has all required methods."""
        methods = ["store", "recall", "decay", "diff", "on_session_start", "on_session_end", "consolidate"]
        for method in methods:
            self.assertTrue(hasattr(MemoryMolecule, method), f"Missing method: {method}")


if __name__ == "__main__":
    unittest.main()
