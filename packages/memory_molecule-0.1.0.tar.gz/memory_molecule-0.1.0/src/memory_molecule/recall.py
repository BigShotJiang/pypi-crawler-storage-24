"""Recall operations — vendored from hadrons/memory_hadron.py. No external dependencies."""
from __future__ import annotations

import gzip
import re
from pathlib import Path

from .decay import importance_multiplier


def _tokenize(text: str) -> list[str]:
    """Split text into lowercase word tokens."""
    return re.findall(r"[a-z0-9]+", text.lower())


def _count_words(text: str) -> int:
    """Count whitespace-delimited words."""
    return len(text.split())


def _read_file(path: Path) -> str:
    """Read .md or .md.gz file."""
    if path.suffix == ".gz":
        try:
            return gzip.decompress(path.read_bytes()).decode("utf-8")
        except Exception:
            return ""
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return ""


def _detect_importance(content: str) -> str:
    """Detect importance level from content."""
    lower = content.lower()
    if "hard_constraint" in lower or "**importance:** hard_constraint" in lower:
        return "hard_constraint"
    if "foundational" in lower or "**importance:** foundational" in lower:
        return "foundational"
    if "tactical" in lower or "**importance:** tactical" in lower:
        return "tactical"
    return "context"


def recall_by_concept(
    query: str,
    vault_path: str | Path,
    top_k: int = 5,
    importance_weighted: bool = True,
) -> list[dict]:
    """Search vault by keyword matching, ranked by relevance. Supports .md and .md.gz."""
    keywords = _tokenize(query)
    if not keywords:
        return []

    root = Path(vault_path)
    results: list[dict] = []

    patterns = list(root.rglob("*.md")) + list(root.rglob("*.md.gz"))
    seen = set()
    for file_path in patterns:
        canonical = str(file_path).replace(".gz", "")
        if canonical in seen:
            continue
        seen.add(canonical)

        content = _read_file(file_path)
        if not content:
            continue

        content_lower = content.lower()
        hits = sum(1 for kw in keywords if kw in content_lower)
        match_score = hits / len(keywords)

        if match_score == 0:
            continue

        importance = _detect_importance(content) if importance_weighted else "context"
        mult = importance_multiplier(importance) if importance_weighted else 1.0
        weighted_score = match_score * mult

        results.append({
            "path": str(file_path),
            "content": content,
            "match_score": match_score,
            "weighted_score": weighted_score,
            "importance": importance,
            "word_count": _count_words(content),
        })

    results.sort(key=lambda r: r["weighted_score"], reverse=True)
    return results[:top_k]


def diff_sessions(session_a_path: str, session_b_path: str) -> dict:
    """Compute structured diff between two session files."""
    content_a = _read_file(Path(session_a_path))
    content_b = _read_file(Path(session_b_path))

    def _parse_sections(text: str) -> dict[str, str]:
        sections: dict[str, str] = {}
        parts = text.split("## ")
        for part in parts:
            if not part.strip():
                continue
            lines = part.split("\n", 1)
            header = lines[0].strip()
            body = lines[1].strip() if len(lines) > 1 else ""
            sections[header] = body
        return sections

    sections_a = _parse_sections(content_a)
    sections_b = _parse_sections(content_b)
    headers_a = set(sections_a.keys())
    headers_b = set(sections_b.keys())

    added = sorted(headers_b - headers_a)
    removed = sorted(headers_a - headers_b)
    changed = sorted(h for h in headers_a & headers_b if sections_a[h] != sections_b[h])

    parts_list: list[str] = []
    if added:
        parts_list.append(f"{len(added)} added")
    if removed:
        parts_list.append(f"{len(removed)} removed")
    if changed:
        parts_list.append(f"{len(changed)} changed")
    summary = ", ".join(parts_list) if parts_list else "no differences"

    return {"added": added, "removed": removed, "changed": changed, "summary": summary}
