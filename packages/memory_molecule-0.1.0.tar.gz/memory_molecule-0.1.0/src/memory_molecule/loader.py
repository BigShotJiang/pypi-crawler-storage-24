"""Tiered memory loader. No Oracle-specific imports."""
from __future__ import annotations

import subprocess
from pathlib import Path

from .config import MemoryConfig
from .recall import recall_by_concept
from .storage import read_session


def _count_tokens(text: str) -> int:
    """Estimate token count. Uses word count as approximation."""
    return len(text.split())


def _read_file(path: Path) -> str:
    """Read a file, supporting .md and .md.gz."""
    if not path.exists():
        return ""
    if path.suffix == ".gz":
        return read_session(str(path))
    return path.read_text(encoding="utf-8")


def load_tier1(config: MemoryConfig | None = None) -> dict:
    """Tier 1 — ALWAYS loaded. Invariants, latest context, git state. Target: 5K tokens."""
    cfg = config or MemoryConfig()
    vault = Path(cfg.vault_path)
    parts = []
    sources = []

    # Invariants
    invariants_path = vault / "shared" / "invariants.md"
    if invariants_path.exists():
        parts.append(invariants_path.read_text(encoding="utf-8"))
        sources.append("invariants.md")

    # Latest session
    sessions_dir = vault / cfg.project / "sessions"
    if sessions_dir.exists():
        files = sorted(sessions_dir.iterdir(), reverse=True)
        if files:
            content = read_session(str(files[0]))
            if content:
                parts.append(content[:3000])
                sources.append(files[0].name)

    # Git state
    try:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        log = subprocess.run(
            ["git", "log", "--oneline", "-5"],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        git_info = f"Branch: {branch}\n{log}"
        parts.append(git_info)
        sources.append("git_state")
    except Exception:
        pass

    content = "\n\n---\n\n".join(parts)
    tokens = _count_tokens(content)

    # Truncate to budget
    if tokens > cfg.tier1_max_tokens:
        ratio = cfg.tier1_max_tokens / max(tokens, 1)
        content = content[:int(len(content) * ratio)]
        tokens = _count_tokens(content)

    return {"content": content, "tokens": tokens, "sources": sources}


def load_tier2(config: MemoryConfig | None = None, days: int = 7) -> dict:
    """Tier 2 — RELEVANT. Recent sessions, decisions. Target: 50K tokens."""
    cfg = config or MemoryConfig()
    vault = Path(cfg.vault_path)
    parts = []
    sources = []

    # Recent sessions
    sessions_dir = vault / cfg.project / "sessions"
    if sessions_dir.exists():
        for f in sorted(sessions_dir.iterdir(), reverse=True)[:3]:
            content = read_session(str(f))
            if content:
                parts.append(f"## {f.name}\n{content}")
                sources.append(f.name)

    # Decisions
    decisions_dir = vault / cfg.project / "decisions"
    if decisions_dir.exists():
        for f in sorted(decisions_dir.iterdir(), reverse=True)[:10]:
            content = _read_file(f)
            if content:
                parts.append(f"## Decision: {f.name}\n{content}")
                sources.append(f.name)

    full_content = "\n\n".join(parts)
    tokens = _count_tokens(full_content)

    if tokens > cfg.tier2_max_tokens:
        ratio = cfg.tier2_max_tokens / max(tokens, 1)
        full_content = full_content[:int(len(full_content) * ratio)]
        tokens = _count_tokens(full_content)

    return {"content": full_content, "tokens": tokens, "sources": sources}


def load_tier3(config: MemoryConfig | None = None, query: str = "") -> dict:
    """Tier 3 — ON DEMAND. Full journals, expertise. Target: 150K tokens."""
    cfg = config or MemoryConfig()
    vault = Path(cfg.vault_path)
    parts = []
    sources = []

    if query:
        results = recall_by_concept(query, str(vault), top_k=10)
        for r in results:
            parts.append(f"## {Path(r['path']).name}\n{r['content'][:3000]}")
            sources.append(Path(r["path"]).name)

    # Expertise patterns
    patterns_dir = vault / cfg.project / "patterns"
    if patterns_dir.exists():
        for f in sorted(patterns_dir.iterdir(), reverse=True)[:5]:
            content = _read_file(f)
            if content:
                parts.append(f"## Expertise: {f.name}\n{content}")
                sources.append(f.name)

    full_content = "\n\n".join(parts)
    tokens = _count_tokens(full_content)

    if tokens > cfg.tier3_max_tokens:
        ratio = cfg.tier3_max_tokens / max(tokens, 1)
        full_content = full_content[:int(len(full_content) * ratio)]
        tokens = _count_tokens(full_content)

    return {"content": full_content, "tokens": tokens, "sources": sources}


def load(
    config: MemoryConfig | None = None,
    query: str = "",
    max_tokens: int = 200000,
) -> dict:
    """Load memory tiers until token budget is exhausted."""
    cfg = config or MemoryConfig()

    tier1 = load_tier1(cfg)
    remaining = max_tokens - tier1["tokens"]

    tier2 = {"content": "", "tokens": 0, "sources": []}
    if remaining > cfg.tier1_max_tokens:
        tier2 = load_tier2(cfg)
        if tier2["tokens"] > remaining:
            ratio = remaining / max(tier2["tokens"], 1)
            tier2["content"] = tier2["content"][:int(len(tier2["content"]) * ratio)]
            tier2["tokens"] = _count_tokens(tier2["content"])
        remaining -= tier2["tokens"]

    tier3 = {"content": "", "tokens": 0, "sources": []}
    if query and remaining > cfg.tier1_max_tokens:
        tier3 = load_tier3(cfg, query)
        if tier3["tokens"] > remaining:
            ratio = remaining / max(tier3["tokens"], 1)
            tier3["content"] = tier3["content"][:int(len(tier3["content"]) * ratio)]
            tier3["tokens"] = _count_tokens(tier3["content"])

    total = tier1["tokens"] + tier2["tokens"] + tier3["tokens"]

    return {
        "tier1": tier1,
        "tier2": tier2,
        "tier3": tier3,
        "total_tokens": total,
        "budget_used": total / max_tokens if max_tokens > 0 else 0,
        "max_tokens": max_tokens,
    }


class MemoryLoader:
    """Convenience class wrapping the tiered loading functions."""

    def __init__(self, config: MemoryConfig | None = None):
        self.config = config or MemoryConfig()

    def load_tier1(self) -> dict:
        return load_tier1(self.config)

    def load_tier2(self, days: int = 7) -> dict:
        return load_tier2(self.config, days)

    def load_tier3(self, query: str = "") -> dict:
        return load_tier3(self.config, query)

    def load(self, query: str = "", max_tokens: int = 200000) -> dict:
        return load(self.config, query, max_tokens)
