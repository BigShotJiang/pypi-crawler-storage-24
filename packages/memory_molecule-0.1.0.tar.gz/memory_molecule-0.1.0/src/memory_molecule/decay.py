"""Decay computation — vendored from quarks/decay_quarks.py. No external dependencies."""
from __future__ import annotations

import math

_BASE_DECAY_FACTOR = 0.95
_SECONDS_PER_DAY = 86400.0

_IMPORTANCE_RATES = {
    "hard_constraint": 0.5,
    "foundational": 0.7,
    "context": 1.0,
    "tactical": 1.5,
}

_IMPORTANCE_MULTIPLIER = {
    "hard_constraint": 2.0,
    "foundational": 1.5,
    "context": 1.0,
    "tactical": 0.8,
}


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def importance_multiplier(importance: str) -> float:
    """Return the importance multiplier for recall weighting."""
    return _IMPORTANCE_MULTIPLIER.get(importance, 1.0)


def compute_relevance(
    created_at: float,
    last_accessed: float,
    access_count: int,
    importance: str,
    now: float,
    decay_factor: float = _BASE_DECAY_FACTOR,
) -> float:
    """Compute relevance score using exponential decay with access reinforcement."""
    boost = min(0.3, access_count * 0.05)

    if now <= last_accessed:
        return _clamp(1.0 + boost, 0.0, 1.0)

    days_elapsed = (now - last_accessed) / _SECONDS_PER_DAY
    rate_multiplier = _IMPORTANCE_RATES.get(importance, 1.0)
    effective_factor = math.pow(decay_factor, rate_multiplier)
    base_score = math.pow(effective_factor, days_elapsed)

    return _clamp(base_score + boost, 0.0, 1.0)


def should_archive(score: float, threshold: float = 0.1) -> bool:
    """Return True if score is below archive threshold."""
    return score < threshold


def decay_batch(memories: list[dict], now: float, decay_factor: float = _BASE_DECAY_FACTOR) -> list[dict]:
    """Apply decay to a batch of memory dicts. Non-mutating."""
    results = []
    for mem in memories:
        updated = dict(mem)
        updated["relevance_score"] = compute_relevance(
            created_at=mem["created_at"],
            last_accessed=mem["last_accessed"],
            access_count=mem["access_count"],
            importance=mem["importance"],
            now=now,
            decay_factor=decay_factor,
        )
        results.append(updated)
    return results
