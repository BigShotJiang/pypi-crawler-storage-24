"""Configuration for memory-molecule."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class MemoryConfig:
    """Configuration for the MemoryMolecule system."""
    vault_path: str | Path = field(default_factory=lambda: Path("./vault"))
    db_path: str | Path | None = None
    decay_factor: float = 0.95
    archive_threshold: float = 0.1
    tier1_max_tokens: int = 5000
    tier2_max_tokens: int = 50000
    tier3_max_tokens: int = 150000
    observation_url: str = "http://localhost:4000/events"
    project: str = "default"

    def __post_init__(self):
        self.vault_path = Path(self.vault_path)
        if self.db_path is not None:
            self.db_path = Path(self.db_path)
