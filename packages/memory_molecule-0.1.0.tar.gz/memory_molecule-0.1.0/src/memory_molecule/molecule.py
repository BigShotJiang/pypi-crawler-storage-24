"""MemoryMolecule — the main coordinator class. No Oracle-specific imports."""
from __future__ import annotations

import json
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from .config import MemoryConfig
from .decay import compute_relevance, should_archive, decay_batch
from .recall import recall_by_concept, diff_sessions
from .storage import write_session, read_session, list_sessions


# ── Pydantic models ───────────────────────────────────────────


class DecayReport(BaseModel):
    """Result of a decay pass."""
    archived_count: int = Field(ge=0)
    lowest_score: float = Field(ge=0.0, le=1.0)
    highest_score: float = Field(ge=0.0, le=1.0)
    total_memories: int = Field(ge=0)


class SessionDiff(BaseModel):
    """Diff between two sessions."""
    added: list[str] = Field(default_factory=list)
    removed: list[str] = Field(default_factory=list)
    changed: list[str] = Field(default_factory=list)
    summary: str = ""


class RecallBundle(BaseModel):
    """Bundle of recalled memories for session start."""
    recent_session: str = ""
    high_relevance: list[dict[str, Any]] = Field(default_factory=list)
    open_threads: list[str] = Field(default_factory=list)
    decisions: list[str] = Field(default_factory=list)


# ── MemoryMolecule ────────────────────────────────────────────


class MemoryMolecule:
    """
    Persistent memory coordinator for agentic systems.

    Provides store, recall, decay, diff, and session lifecycle
    operations backed by a vault filesystem.
    """

    def __init__(self, config: MemoryConfig | None = None):
        self.config = config or MemoryConfig()
        self._vault = Path(self.config.vault_path)
        self._project = self.config.project
        self._sessions_dir = self._vault / self._project / "sessions"
        self._decisions_dir = self._vault / self._project / "decisions"
        self._patterns_dir = self._vault / self._project / "patterns"

    # ── Core operations ───────────────────────────────────────

    def store(self, content: str, memory_type: str = "session", importance: str = "context") -> str:
        """Write content to vault. Returns path of created file."""
        type_to_dir = {
            "session": self._sessions_dir,
            "decision": self._decisions_dir,
            "expertise": self._patterns_dir,
            "knowledge": self._vault / self._project / "knowledge",
        }
        target_dir = type_to_dir.get(memory_type, self._sessions_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now(timezone.utc)
        date_str = now.strftime("%Y-%m-%d")
        header = (
            f"# {memory_type.title()} — {date_str}\n"
            f"**Importance:** {importance}\n"
            f"**Written:** {now.isoformat()}\n\n"
        )
        full_content = header + content

        path = write_session(self._vault, self._project, date_str, full_content)
        self._emit("MemoryStore", {"memory_type": memory_type, "importance": importance, "path": str(path)})
        return str(path)

    def recall(self, query: str, top_k: int = 5) -> list[dict]:
        """Search vault by concept, ranked by importance-weighted relevance."""
        results = recall_by_concept(query, str(self._vault), top_k=top_k)
        self._emit("MemoryRecall", {"query": query, "results_count": len(results)})
        return results

    def decay(self) -> DecayReport:
        """Apply decay to all memories, archive low-relevance ones."""
        session_files = list(self._sessions_dir.glob("*")) if self._sessions_dir.exists() else []
        if not session_files:
            return DecayReport(archived_count=0, lowest_score=0.0, highest_score=0.0, total_memories=0)

        now = time.time()
        memories = []
        for fp in session_files:
            stat = fp.stat()
            memories.append({
                "path": fp,
                "created_at": stat.st_mtime,
                "last_accessed": stat.st_atime,
                "access_count": 1,
                "importance": "context",
            })

        scored = decay_batch(memories, now, self.config.decay_factor)

        archive_dir = self._vault / "archive"
        archived_files = []
        for mem in scored:
            if should_archive(mem["relevance_score"], self.config.archive_threshold):
                archive_dir.mkdir(parents=True, exist_ok=True)
                src = mem["path"]
                dest = archive_dir / src.name
                counter = 1
                while dest.exists():
                    dest = archive_dir / f"{src.stem}_{counter}{src.suffix}"
                    counter += 1
                src.rename(dest)
                archived_files.append(str(dest))

        scores = [m["relevance_score"] for m in scored]
        report = DecayReport(
            archived_count=len(archived_files),
            lowest_score=min(scores),
            highest_score=max(scores),
            total_memories=len(scored),
        )
        self._emit("MemoryDecay", report.model_dump())
        return report

    def diff(self, session_a: str, session_b: str) -> SessionDiff:
        """Compare two session files."""
        raw = diff_sessions(session_a, session_b)
        return SessionDiff(**raw)

    def on_session_start(self) -> RecallBundle:
        """Load high-relevance memories for session initialization."""
        try:
            recent_session = ""
            if self._sessions_dir.exists():
                session_files = sorted(self._sessions_dir.iterdir(), reverse=True)
                if session_files:
                    recent_session = read_session(str(session_files[0]))

            high_relevance = self.recall("architecture decisions priorities", top_k=5)
            open_threads = self._extract_section(recent_session, "Open Threads")
            decisions = self._extract_section(recent_session, "Decisions")

            bundle = RecallBundle(
                recent_session=recent_session[:4000],
                high_relevance=high_relevance,
                open_threads=open_threads,
                decisions=decisions,
            )
            self._emit("MemorySessionStart", {
                "recent_session_chars": len(recent_session),
                "high_relevance_count": len(high_relevance),
            })
            return bundle
        except Exception:
            return RecallBundle()

    def on_session_end(self, commits: list[str] | None = None, decisions: list[str] | None = None) -> None:
        """Write session summary, apply decay."""
        try:
            commits = commits or []
            decisions = decisions or []
            content = (
                "## Commits\n"
                + "\n".join(f"- {c}" for c in commits)
                + "\n\n## Decisions Made\n"
                + "\n".join(f"- {d}" for d in decisions)
                + "\n"
            )
            self.store(content, "session", "context")
            self.decay()
            self._emit("MemorySessionEnd", {"commits_count": len(commits), "decisions_count": len(decisions)})
        except Exception:
            pass

    def consolidate(self, session_id: str = "") -> str:
        """Return a text summary of recent sessions for context priming."""
        sessions = list_sessions(str(self._vault), self._project, n=3)
        parts = []
        for s in sessions:
            content = read_session(str(s))
            if content:
                parts.append(f"## {s.name}\n{content[:2000]}")
        return "\n\n".join(parts)

    # ── Private helpers ───────────────────────────────────────

    @staticmethod
    def _extract_section(content: str, section_name: str) -> list[str]:
        """Extract bullet items from a markdown section."""
        items = []
        in_section = False
        for line in content.splitlines():
            if line.strip().startswith(f"## {section_name}"):
                in_section = True
                continue
            if in_section and line.strip().startswith("## "):
                break
            if in_section and line.strip().startswith("- "):
                items.append(line.strip()[2:])
        return items

    def _emit(self, event_type: str, payload: dict) -> None:
        """Fire-and-forget observation event. Never raises."""
        try:
            data = json.dumps({
                "source_app": "memory_molecule",
                "session_id": f"mm-{self._project}",
                "hook_event_type": event_type,
                "payload": payload,
                "timestamp": time.time() * 1000,
            }).encode()
            req = urllib.request.Request(
                self.config.observation_url,
                data=data,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass
