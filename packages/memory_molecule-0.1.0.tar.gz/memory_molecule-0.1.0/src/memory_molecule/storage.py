"""Storage operations — vendored from hadrons/memory_hadron.py. No external dependencies."""
from __future__ import annotations

import gzip
from datetime import datetime, timezone
from pathlib import Path


def write_session(vault_path: str | Path, project: str, date: str, content: str) -> Path:
    """Write session content as .md.gz. Returns the written path."""
    root = Path(vault_path) / project / "sessions"
    root.mkdir(parents=True, exist_ok=True)
    filename = f"{date}-session.md.gz"
    gz_path = root / filename
    counter = 1
    while gz_path.exists():
        gz_path = root / f"{date}-session_{counter}.md.gz"
        counter += 1
    compressed = gzip.compress(content.encode("utf-8"))
    gz_path.write_bytes(compressed)
    # Verify round-trip
    verify = gzip.decompress(gz_path.read_bytes()).decode("utf-8")
    if verify != content:
        gz_path.unlink(missing_ok=True)
        raise ValueError("Compression verification failed")
    return gz_path


def read_session(path: str | Path) -> str:
    """Read a session file, supporting both .md and .md.gz."""
    p = Path(path)
    if p.suffix == ".gz" and p.exists():
        return gzip.decompress(p.read_bytes()).decode("utf-8")
    # Try .gz variant
    gz = Path(str(p) + ".gz") if not str(p).endswith(".gz") else p
    md = Path(str(p).replace(".gz", "")) if str(p).endswith(".gz") else p
    if gz.exists():
        return gzip.decompress(gz.read_bytes()).decode("utf-8")
    if md.exists():
        return md.read_text(encoding="utf-8")
    return ""


def list_sessions(vault_path: str | Path, project: str = "default", n: int = 10) -> list[Path]:
    """List the most recent n session files."""
    sessions_dir = Path(vault_path) / project / "sessions"
    if not sessions_dir.exists():
        return []
    files = sorted(sessions_dir.iterdir(), reverse=True)
    return files[:n]


def migrate_to_compressed(vault_path: str | Path) -> dict:
    """Migrate .md files to .md.gz. Safe: only deletes .md after verified .gz write."""
    root = Path(vault_path)
    migrated = []
    failed = []
    skipped = []
    _KEEP_UNCOMPRESSED = {"invariants.md", "SESSION_CONTEXT.md", "SESSION_RESUME.md", "MEMORY.md"}
    for md_file in root.rglob("*.md"):
        gz_file = Path(str(md_file) + ".gz")
        if gz_file.exists():
            skipped.append(str(md_file))
            continue
        if md_file.name in _KEEP_UNCOMPRESSED:
            skipped.append(str(md_file))
            continue
        try:
            content = md_file.read_text(encoding="utf-8")
            compressed = gzip.compress(content.encode("utf-8"))
            gz_file.write_bytes(compressed)
            # Verify
            verify = gzip.decompress(gz_file.read_bytes()).decode("utf-8")
            if verify != content:
                gz_file.unlink(missing_ok=True)
                failed.append(str(md_file))
                continue
            md_file.unlink()
            migrated.append(str(md_file))
        except Exception:
            failed.append(str(md_file))
    return {"migrated": len(migrated), "failed": len(failed), "skipped": len(skipped)}
