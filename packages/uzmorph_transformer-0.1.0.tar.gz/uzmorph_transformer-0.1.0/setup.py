from setuptools import setup, find_packages

setup(
    name="uzmorph-transformer",
    version="0.1.0",
    author="Ulugbek Salaev",
    description="Uzbek Neural Morphological Analyzer (Transformer Architecture)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/UlugbekSalaev/uzmorph_transformer",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'uzmorph_transformer': ['data/*.pth', 'data/*.json'],
    },
    install_requires=[
        "torch",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
