# uzmorph-transformer: Uzbek Neural Morphological Analyzer (Transformer Encoder Architecture)

**uzmorph-transformer** is a state-of-the-art word-level morphological analyzer for the Uzbek language. Unlike sequential RNNs, it uses a Multi-Head Self-Attention (Transformer Encoder) mechanism to capture complex character dependencies.

## Performance & Use Case
- **Architecture**: Transformer Encoder (Multi-Head Attention).
- **Strength**: Exceptional at analyzing very long or complex words (6+ suffixes) where sequential models might lose context. Handles long-range phonological dependencies with high precision.
- **Accuracy**: >95% (Scales significantly with complex data).
- **Ideal For**: Research-heavy NLP tasks and analyzing complex, highly-agglutinative Uzbek technical or literary texts.

## Installation
```bash
pip install uzmorph-transformer
```

## Quick Start (Usage Examples)

### 1. Simple Analysis (String Output)
```python
from uzmorph_transformer.uzmorph_transformer import uzmorph_transformer

analyzer = uzmorph_transformer()
result = analyzer.analyze("kitoblarimizdagilar")
print(result)

# Output:
# Result: 'kitoblarimizdagilar' -> Stem: kitob | POS: NOUN | Tags: [plural=1, possession=1, cases=Locative, plural=1]
```

### 2. Structured Data Export
```python
# To Dictionary
data = analyzer.analyze("yozayapmiz").to_dict()

# To JSON
json_out = analyzer.analyze("olma").to_json()
```

## Supported Tags & Features

### Part of Speech (POS)
- `NOUN` (Ot), `VERB` (Fe'l), `ADJ` (Sifat), `ADV` (Ravish), `NUM` (Son), `PRN` (Olmosh).

### Grammatical Features
- **Cases**: `Nominative`, `Ablative`, `Accusative`, `Dative`, `Genitive`, `Locative`.
- **Possession**: `1`, `2`, `3`.
- **Tense**: `Past`, `Present`, `Future`.
- **Voice**: `Causative`, `Passive`, `Reciprocal`, `Reflexive`.
- **Mood**: `Conditional`, `Imperative`, `Progressive`, `Message`, `Proposal`.

## License
MIT
