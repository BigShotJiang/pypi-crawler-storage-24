# bluefox-yml — Implementation Plan

> A Python package that parses, validates, and provides typed access to `bluefox.yml` manifests.

Used by both the CLI (`bfx release`, `bfx status`) and the platform (pipeline parsing). Published to PyPI as `bluefox-yml`.

Every step is a single, verifiable task. Don't move to the next step until the current one works. Each step says what "done" looks like.

---

## Part 1: Package Scaffold

### Step 1: Create the package structure

```
bluefox-yml/
├── pyproject.toml
├── uv.lock
├── README.md
├── bluefox_yml/
│   ├── __init__.py
│   └── py.typed          # PEP 561 marker for type checkers
└── tests/
    ├── __init__.py
    └── conftest.py
```

Use `hatchling` as build backend (consistent with the CLI and BFF packages). Dependencies: `pydantic>=2.0` and `pyyaml>=6.0`. Dev dependencies: `pytest`.

`__init__.py` exports nothing yet — just makes it a package.

**Done when:** `uv sync` works, `pytest` runs with 0 tests collected, `uv build` produces a wheel.

---

## Part 2: Models

### Step 2: `ComputeProcess` model

Create `bluefox_yml/models.py`. Define the Pydantic model for a single compute process.

```python
class ComputeProcess(BaseModel):
    mode: str           # defaults to the process key name (set by parent)
    port: int | None = None
    healthcheck: str = "/health"
```

No validation logic yet — just the shape.

**Done when:** You can instantiate `ComputeProcess(mode="app", port=8000)` and `ComputeProcess(mode="worker")`. Fields have correct types and defaults.

---

### Step 3: `DataPrimitive` model

Add to `models.py`:

```python
class DataPrimitive(BaseModel):
    engine: str
    version: int
    migrate: str | None = None
```

**Done when:** `DataPrimitive(engine="postgres", version=17, migrate="uv run alembic upgrade head")` works. `migrate` is optional.

---

### Step 4: `InMemoryPrimitive` model

Add to `models.py`:

```python
class InMemoryPrimitive(BaseModel):
    engine: str
    version: int
```

**Done when:** `InMemoryPrimitive(engine="redis", version=7)` works.

---

### Step 5: `Manifest` model

The top-level model that holds everything together.

```python
class Manifest(BaseModel):
    version: int
    name: str
    compute: dict[str, ComputeProcess]
    data: DataPrimitive | None = None
    in_memory: InMemoryPrimitive | None = None
```

Note: `in-memory` in YAML becomes `in_memory` in Python. Handle this with a Pydantic field alias.

**Done when:** You can construct a full `Manifest` from Python dicts. The `in-memory` → `in_memory` alias works. All fields have correct types and defaults.

---

## Part 3: YAML Loading

### Step 6: Raw YAML loader

Create `bluefox_yml/loader.py`. Write a function that reads a YAML file and returns the raw dict.

```python
def _load_yaml(path: Path) -> dict:
    """Read a YAML file and return the raw dict. Raises ManifestError on failure."""
```

Handle: file not found, YAML parse errors, file is not a dict (e.g., someone puts a list or scalar).

Create `bluefox_yml/exceptions.py`:

```python
class ManifestError(Exception):
    """Raised when a bluefox.yml is invalid."""
    def __init__(self, message: str, field: str | None = None):
        self.field = field
        super().__init__(message)
```

**Done when:** `_load_yaml(Path("bluefox.yml"))` returns a dict. Missing file raises `ManifestError("bluefox.yml not found")`. Invalid YAML raises `ManifestError` with a clear message.

---

### Step 7: Compute process key → mode defaulting

Before passing raw data to Pydantic, we need to process the `compute` section: each process key becomes the default `mode` if not explicitly set. Also handle the `{}` empty dict case (e.g., `worker: {}`).

```python
def _prepare_compute(raw_compute: dict) -> dict[str, dict]:
    """Inject default mode from key name, normalize empty dicts."""
```

- `worker: {}` → `{"worker": {"mode": "worker"}}`
- `worker:` (YAML null) → `{"worker": {"mode": "worker"}}`
- `app: {port: 8000}` → `{"app": {"port": 8000, "mode": "app"}}`
- `app: {port: 8000, mode: custom}` → `{"app": {"port": 8000, "mode": "custom"}}` (explicit wins)

**Done when:** All four cases above produce correct output. YAML null values are handled.

---

### Step 8: `in-memory` field alias handling

YAML has `in-memory` (hyphenated), Python needs `in_memory`. Handle this during raw dict processing before passing to Pydantic, or use Pydantic's `model_config` with `populate_by_name` and `alias_generator`, or a field-level `alias`.

Pick the approach that keeps the code simplest. I'd lean toward processing the raw dict:

```python
def _prepare_raw(raw: dict) -> dict:
    """Normalize raw YAML keys for Pydantic."""
    if "in-memory" in raw:
        raw["in_memory"] = raw.pop("in-memory")
    return raw
```

**Done when:** A YAML file with `in-memory:` is correctly parsed into the `in_memory` field on the Manifest model.

---

### Step 9: `load_manifest` — the public API

The main entry point. Ties together YAML loading, key normalization, compute defaulting, and Pydantic parsing.

```python
def load_manifest(path: Path | str = "bluefox.yml") -> Manifest:
    """Load and validate a bluefox.yml manifest. Raises ManifestError on failure."""
```

Steps inside:
1. `_load_yaml(path)` → raw dict
2. `_prepare_raw(raw)` → normalize keys
3. `_prepare_compute(raw["compute"])` → inject mode defaults
4. `Manifest(**raw)` → Pydantic validation
5. Catch `ValidationError`, convert to `ManifestError` with clear messages

**Done when:** `load_manifest("bluefox.yml")` returns a fully typed `Manifest` object for a valid file. Invalid files raise `ManifestError` with human-readable messages.

---

### Step 10: Test the loader with all spec examples

Write `tests/test_loader.py`. Create fixture YAML files (or use inline strings with `tmp_path`) for each example from the spec:

- Minimal — simple API, no database
- Typical — API with database
- Full — API + worker + database + cache
- The platform itself

Each test calls `load_manifest()` and asserts the returned `Manifest` has the correct field values, including defaulted `mode` and `healthcheck`.

**Done when:** All four spec examples parse correctly. Defaults are applied. Types are correct.

---

## Part 4: Validation Rules

One step per validation rule from the spec. Each step adds the validation and a test.

### Step 11: Validate `version` is present and equals 1

Add a Pydantic validator on `Manifest.version`:

```python
@field_validator("version")
@classmethod
def check_version(cls, v):
    if v != 1:
        raise ValueError("unsupported manifest version (expected 1)")
    return v
```

Test cases:
- `version: 1` → passes
- `version: 2` → `ManifestError`
- Missing `version` → `ManifestError`

**Done when:** Invalid or missing version produces a clear error.

---

### Step 12: Validate `name` is DNS-safe

Add a validator on `Manifest.name`. DNS-safe means:
- 3–63 characters
- Lowercase letters, digits, hyphens only
- Starts with a letter
- Ends with a letter or digit

Use a compiled regex: `^[a-z][a-z0-9-]{1,61}[a-z0-9]$`

Test cases:
- `my-app` → passes
- `canada-days` → passes
- `a` → fails (too short)
- `My-App` → fails (uppercase)
- `-bad` → fails (starts with hyphen)
- `bad-` → fails (ends with hyphen)
- `a-string-that-is-way-too-long...` (64+ chars) → fails

**Done when:** All test cases pass with clear error messages like `"name must be DNS-safe: lowercase letters, digits, hyphens, 3-63 characters"`.

---

### Step 13: Validate `name` is not reserved

Add a second validator on `name` (or extend the existing one):
- Reject any name starting with `bluefox-`
- Reject single-character names (already caught by DNS length, but be explicit)

Test cases:
- `bluefox-anything` → fails with `"name 'bluefox-anything' is reserved (bluefox- prefix is reserved for platform services)"`
- `bluefox-platform` → fails
- `myapp` → passes

**Done when:** Reserved names produce specific, helpful error messages.

---

### Step 14: Validate `compute` has at least one process

Add a validator on `Manifest.compute`:

```python
@field_validator("compute")
@classmethod
def check_compute_not_empty(cls, v):
    if not v:
        raise ValueError("compute must declare at least one process")
    return v
```

Test cases:
- `compute: {}` → fails
- `compute:` with one process → passes

**Done when:** Empty compute section is rejected.

---

### Step 15: Validate at most one process has `port`

Add a model validator (not field-level — this checks across processes):

```python
@model_validator(mode="after")
def check_single_routable(self):
    routable = [name for name, p in self.compute.items() if p.port is not None]
    if len(routable) > 1:
        raise ValueError(
            f"only one compute process may declare port, "
            f"but found: {', '.join(routable)}"
        )
    return self
```

Test cases:
- One process with port → passes
- Zero processes with port → passes (headless workers-only app)
- Two processes with port → fails with both names listed

**Done when:** Multiple routable processes are rejected with a clear message naming the offending processes.

---

### Step 16: Validate `healthcheck` only on routable processes

Add a model validator that checks: if a process has `healthcheck` set to something other than the default AND does not have `port`, reject it.

This is subtle — `healthcheck` defaults to `/health`, so we need to detect when it's been *explicitly* set on a non-routable process. Options:
1. Change the default to `None`, and only apply `/health` as the default when `port` is set.
2. Keep `/health` as default but ignore it when there's no port.

Option 1 is cleaner for the model. `healthcheck` defaults to `None`. A model validator sets it to `/health` for processes that have `port` and no explicit healthcheck. If a process without `port` has an explicit healthcheck, reject it.

Revise `ComputeProcess`:
```python
class ComputeProcess(BaseModel):
    mode: str
    port: int | None = None
    healthcheck: str | None = None  # default applied by Manifest validator
```

Test cases:
- Process with port, no healthcheck → gets `/health` automatically
- Process with port, healthcheck `/ready` → keeps `/ready`
- Process without port, no healthcheck → stays `None`
- Process without port, healthcheck `/health` → fails

**Done when:** Healthcheck defaults are applied correctly for routable processes. Explicit healthcheck on a non-routable process is rejected.

---

### Step 17: Validate `data.engine` is `postgres`

Add a validator on `DataPrimitive.engine`:

```python
SUPPORTED_DATA_ENGINES = {"postgres"}

@field_validator("engine")
@classmethod
def check_engine(cls, v):
    if v not in SUPPORTED_DATA_ENGINES:
        raise ValueError(f"unsupported data engine '{v}' (v1 supports: {', '.join(SUPPORTED_DATA_ENGINES)})")
    return v
```

Test cases:
- `engine: postgres` → passes
- `engine: mysql` → fails with message naming supported engines

**Done when:** Unsupported engines are rejected with a helpful message.

---

### Step 18: Validate `in-memory.engine` is `redis`

Same pattern on `InMemoryPrimitive`:

```python
SUPPORTED_IN_MEMORY_ENGINES = {"redis"}
```

Test cases:
- `engine: redis` → passes
- `engine: memcached` → fails

**Done when:** Unsupported in-memory engines are rejected.

---

### Step 19: Validate `data.version` and `in-memory.version` are positive integers

Add validators on both models:

```python
@field_validator("version")
@classmethod
def check_version_positive(cls, v):
    if v < 1:
        raise ValueError("version must be a positive integer")
    return v
```

Test cases:
- `version: 17` → passes
- `version: 0` → fails
- `version: -1` → fails

**Done when:** Invalid versions are rejected.

---

## Part 5: Helper Methods

### Step 20: Service name helpers

Add methods to `Manifest` that compute the Docker service names the platform will use:

```python
class Manifest:
    def service_name(self, process: str) -> str:
        """e.g., 'my-app_app', 'my-app_worker'"""
        return f"{self.name}_{process}"

    def db_service_name(self) -> str | None:
        """e.g., 'my-app-db'. None if no data primitive."""
        return f"{self.name}-db" if self.data else None

    def redis_service_name(self) -> str | None:
        """e.g., 'my-app-redis'. None if no in-memory primitive."""
        return f"{self.name}-redis" if self.in_memory else None
```

Test cases:
- App named `my-saas` with processes `app` and `worker` → `my-saas_app`, `my-saas_worker`
- App with data → `my-saas-db`
- App without data → `None`

**Done when:** Service name generation is correct and tested.

---

### Step 21: Docker image tag helpers

```python
class Manifest:
    def image_tag(self, version: int) -> str:
        """e.g., 'localhost:5000/my-app:v3'"""
        return f"localhost:5000/{self.name}:v{version}"

    def db_image(self) -> str | None:
        """e.g., 'postgres:17-alpine'. None if no data."""
        if not self.data:
            return None
        return f"{self.data.engine}:{self.data.version}-alpine"

    def redis_image(self) -> str | None:
        """e.g., 'redis:7-alpine'. None if no in-memory."""
        if not self.in_memory:
            return None
        return f"redis:{self.in_memory.version}-alpine"
```

Test cases:
- `data.engine: postgres, version: 17` → `postgres:17-alpine`
- `in_memory.engine: redis, version: 7` → `redis:7-alpine`
- `image_tag(3)` → `localhost:5000/my-app:v3`

**Done when:** Image tag generation is correct and tested.

---

### Step 22: Environment variable helpers

```python
class Manifest:
    def routable_process(self) -> tuple[str, ComputeProcess] | None:
        """Return (name, process) for the process with port, or None."""
        for name, proc in self.compute.items():
            if proc.port is not None:
                return (name, proc)
        return None

    def env_vars(self, process_name: str) -> dict[str, str]:
        """Base env vars the platform injects for a given process.

        Does NOT include DATABASE_URL/REDIS_URL (those come from provisioning)
        or user config vars (those come from the API).
        """
        proc = self.compute[process_name]
        env = {
            "APP_NAME": self.name,
            "MODE": proc.mode,
        }
        if proc.port:
            env["PORT"] = str(proc.port)
        return env
```

Test cases:
- `env_vars("app")` for a process with port 8000 → includes `PORT=8000`, `MODE=app`, `APP_NAME=my-app`
- `env_vars("worker")` for a background process → includes `MODE=worker`, `APP_NAME=my-app`, no `PORT`
- `routable_process()` returns the correct one, or `None` for headless apps

**Done when:** Env var generation is correct. Routable process lookup works.

---

## Part 6: Error Messages

### Step 23: Human-readable error formatting

Pydantic validation errors are structured but not user-friendly. Write a function that converts `ManifestError` (which wraps Pydantic errors) into clean, actionable messages.

```python
def format_error(error: ManifestError) -> str:
    """Format a ManifestError for CLI/log output."""
```

Target output style:
```
bluefox.yml error: name must be DNS-safe (got 'My-App')
bluefox.yml error: only one compute process may declare port (found: app, frontend)
bluefox.yml error: unsupported data engine 'mysql' (v1 supports: postgres)
bluefox.yml error: version is required
```

**Done when:** Every validation rule produces a one-line, human-readable error message. No Pydantic internals leak to the user.

---

## Part 7: Public API

### Step 24: Clean `__init__.py` exports

```python
# bluefox_yml/__init__.py
from bluefox_yml.loader import load_manifest
from bluefox_yml.models import (
    ComputeProcess,
    DataPrimitive,
    InMemoryPrimitive,
    Manifest,
)
from bluefox_yml.exceptions import ManifestError

__all__ = [
    "load_manifest",
    "Manifest",
    "ComputeProcess",
    "DataPrimitive",
    "InMemoryPrimitive",
    "ManifestError",
]
```

**Done when:** `from bluefox_yml import load_manifest, Manifest, ManifestError` works. The public API is clean and minimal.

---

## Part 8: Integration Readiness

### Step 25: Test with real manifests

Create a `tests/fixtures/` directory with the actual `bluefox.yml` files from the spec:

```
tests/fixtures/
├── minimal.yml         # simple API, no database
├── typical.yml         # API with database
├── full.yml            # API + worker + database + cache
├── platform.yml        # the platform itself
├── invalid_name.yml    # uppercase, reserved, too short, etc.
├── invalid_multi_port.yml
├── invalid_engine.yml
├── invalid_version.yml
└── empty_compute.yml
```

Write a test that loads each valid fixture and asserts the full object graph. Write a test for each invalid fixture that asserts the correct `ManifestError` message.

**Done when:** All fixtures pass. The test suite covers every validation rule from the spec. Running `pytest -v` shows a clear picture of what's tested.

---

### Step 26: Publish-ready `pyproject.toml`

Finalize the package metadata:

```toml
[project]
name = "bluefox-yml"
version = "0.1.0"
description = "Parser and validator for bluefox.yml app manifests"
requires-python = ">=3.12"
dependencies = [
    "pydantic>=2.0",
    "pyyaml>=6.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
]

[tool.hatch.build.targets.wheel]
packages = ["bluefox_yml"]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

**Done when:** `uv build` produces a wheel. `uv pip install dist/bluefox_yml-0.1.0-py3-none-any.whl` works. The package is ready for PyPI (publish when you're ready, not required for local development).

---

## Summary

At the end of this plan you have:

- A `bluefox-yml` package that any BFF project can depend on
- Typed Pydantic models matching the v1 spec exactly
- A single `load_manifest()` entry point that returns a validated `Manifest` or raises `ManifestError`
- Helper methods for service names, image tags, and env vars
- Human-readable error messages for every validation rule
- Full test coverage with fixture files from the spec

The CLI will use it as `from bluefox_yml import load_manifest` to read the app's manifest during `bfx release` and `bfx status`. The platform will use it to validate uploaded tarballs during the pipeline's parse step. Same package, same validation, same contract.
