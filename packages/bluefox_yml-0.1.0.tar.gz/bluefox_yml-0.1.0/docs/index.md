# bluefox-yml

Parser and validator for `bluefox.yml` app manifests. Define your application's compute, data, and in-memory primitives in a single YAML file. `bluefox-yml` validates the manifest and provides typed access to every field.

```bash
uv add bluefox-yml
```

---

## Quick start

```yaml title="bluefox.yml"
version: 1
name: my-saas

compute:
  app:
    port: 8000
  worker: {}

data:
  engine: postgres
  version: 17
  migrate: "uv run alembic upgrade head"
```

```python title="main.py"
from bluefox_yml import load_manifest

manifest = load_manifest("bluefox.yml")

print(manifest.name)                    # "my-saas"
print(manifest.compute["app"].port)     # 8000
print(manifest.data.engine)             # "postgres"
print(manifest.routable_process())      # ("app", ComputeProcess(...))
```

---

## What you get

- **Schema validation** — catches invalid manifests early with clear error messages.
- **DNS-safe names** — enforces lowercase, alphanumeric, hyphenated names (3-63 chars).
- **Engine constraints** — only allows supported engines (`postgres`, `redis` in v1).
- **Single routable process** — ensures at most one compute process declares a port.
- **Healthcheck defaults** — auto-injects `/health` for processes with a port.
- **Helper methods** — `service_name()`, `image_tag()`, `db_image()`, `env_vars()`, and more.

---

## Next steps

- [Getting started](getting-started.md) — install and write your first manifest
- [Reference](reference/manifest.md) — full API documentation
