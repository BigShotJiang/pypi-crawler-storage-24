# Manifest reference

## `Manifest`

The top-level model representing a parsed `bluefox.yml` file.

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `version` | `int` | *required* | Manifest version. Must be `1`. |
| `name` | `str` | *required* | DNS-safe app name (3-63 chars, lowercase alphanumeric + hyphens). |
| `compute` | `dict[str, ComputeProcess]` | *required* | Map of process name to configuration. At least one required. |
| `data` | `DataPrimitive \| None` | `None` | Database configuration. |
| `in_memory` | `InMemoryPrimitive \| None` | `None` | In-memory store configuration. YAML key is `in-memory`. |

### Validation rules

- `version` must equal `1`.
- `name` must match `^[a-z][a-z0-9-]{1,61}[a-z0-9]$` and must not start with `bluefox-`.
- `compute` must contain at least one process.
- At most one compute process may declare a `port`.
- `healthcheck` is only valid on processes that declare a `port`.

### Methods

#### `service_name(process: str) -> str`

Returns the Docker service name for a compute process.

```python
manifest.service_name("app")  # "my-saas_app"
```

#### `db_service_name() -> str | None`

Returns the database service name, or `None` if no data primitive.

```python
manifest.db_service_name()  # "my-saas-db"
```

#### `redis_service_name() -> str | None`

Returns the Redis service name, or `None` if no in-memory primitive.

```python
manifest.redis_service_name()  # "my-saas-redis"
```

#### `image_tag(version: int) -> str`

Returns the Docker image tag for the app.

```python
manifest.image_tag(3)  # "localhost:5000/my-saas:v3"
```

#### `db_image() -> str | None`

Returns the database Docker image, or `None` if no data primitive.

```python
manifest.db_image()  # "postgres:17-alpine"
```

#### `redis_image() -> str | None`

Returns the Redis Docker image, or `None` if no in-memory primitive.

```python
manifest.redis_image()  # "redis:7-alpine"
```

#### `routable_process() -> tuple[str, ComputeProcess] | None`

Returns the `(name, process)` tuple for the process with a port, or `None`.

```python
manifest.routable_process()  # ("app", ComputeProcess(mode="app", port=8000, healthcheck="/health"))
```

#### `env_vars(process_name: str) -> dict[str, str]`

Returns the base environment variables the platform injects for a process.

```python
manifest.env_vars("app")     # {"APP_NAME": "my-saas", "MODE": "app", "PORT": "8000"}
manifest.env_vars("worker")  # {"APP_NAME": "my-saas", "MODE": "worker"}
```

---

## `ComputeProcess`

A single compute process definition.

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `mode` | `str` | *required* | Process mode (injected from compute key name). |
| `port` | `int \| None` | `None` | Port to expose. Only one process may set this. |
| `healthcheck` | `str \| None` | `None` | Healthcheck path. Defaults to `/health` when port is set. |

---

## `DataPrimitive`

Database configuration.

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `engine` | `str` | *required* | Database engine. Must be `postgres` (v1). |
| `version` | `int` | *required* | Engine major version. Must be positive. |
| `migrate` | `str \| None` | `None` | Migration command to run on deploy. |

---

## `InMemoryPrimitive`

In-memory store configuration.

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `engine` | `str` | *required* | In-memory engine. Must be `redis` (v1). |
| `version` | `int` | *required* | Engine major version. Must be positive. |
