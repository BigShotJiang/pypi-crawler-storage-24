# Loader reference

## `load_manifest`

```python
def load_manifest(path: Path | str = "bluefox.yml") -> Manifest
```

Load and validate a `bluefox.yml` manifest file.

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `path` | `Path \| str` | `"bluefox.yml"` | Path to the manifest file. |

### Returns

A validated `Manifest` object.

### Raises

`ManifestError` if the file is missing, unreadable, contains invalid YAML, or fails validation.

### Example

```python
from bluefox_yml import load_manifest

manifest = load_manifest()                        # default: bluefox.yml
manifest = load_manifest("path/to/bluefox.yml")   # custom path
manifest = load_manifest(Path("bluefox.yml"))     # pathlib.Path
```

### Error messages

Validation errors are formatted as human-readable messages. Using `str(e)`:

```
bluefox.yml validation error:
  name: name must be DNS-safe: lowercase letters, digits, hyphens, 3-63 characters (got 'INVALID')
  compute: compute must declare at least one process
```

Using `format_error(e)`:

```
bluefox.yml error: bluefox.yml validation error:
  name: name must be DNS-safe: lowercase letters, digits, hyphens, 3-63 characters (got 'INVALID')
  compute: compute must declare at least one process
```
