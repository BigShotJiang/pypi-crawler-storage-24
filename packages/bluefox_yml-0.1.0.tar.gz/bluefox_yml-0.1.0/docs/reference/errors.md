# Error handling reference

## `ManifestError`

```python
class ManifestError(Exception):
    def __init__(self, message: str, field: str | None = None)
```

Raised when a `bluefox.yml` manifest is invalid. Wraps Pydantic validation errors into clean, human-readable messages.

### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `field` | `str \| None` | The field that caused the error, if applicable. |

### Example

```python
from bluefox_yml import load_manifest, ManifestError

try:
    manifest = load_manifest("bluefox.yml")
except ManifestError as e:
    print(e)          # human-readable message
    print(e.field)    # optional field name
```

---

## `format_error`

```python
def format_error(error: ManifestError) -> str
```

Format a `ManifestError` for CLI or log output. Prefixes the message with `bluefox.yml error:`.

### Example

```python
from bluefox_yml import load_manifest, ManifestError, format_error

try:
    manifest = load_manifest()
except ManifestError as e:
    print(format_error(e))
    # Output: "bluefox.yml error: bluefox.yml validation error:\n  name: ..."
```
