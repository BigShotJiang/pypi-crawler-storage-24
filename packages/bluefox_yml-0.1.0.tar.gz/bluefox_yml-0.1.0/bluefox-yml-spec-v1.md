# bluefox.yml Specification

> Version 1 — March 2026

The manifest is the contract between an app and the BlueFox Cloud platform. Every app deployed through the platform must have a `bluefox.yml` in its root.

---

## Overview

```yaml
version: 1

name: my-app

compute:
  app:
    port: 8000
  worker: {}

data:
  engine: postgres
  version: 17
  migrate: "uv run alembic upgrade head"

in-memory:
  engine: redis
  version: 7
```

---

## Fields

### `version` (required)

The manifest spec version. Must be `1` for this spec.

- Type: integer

```yaml
version: 1
```

---

### `name` (required)

The app's identifier. Used for service naming, subdomain routing, and registry tags.

- Type: string
- Must be DNS-safe: lowercase letters, digits, hyphens, 3–63 characters
- Must start with a letter, end with a letter or digit
- Must be unique across the platform

```yaml
name: canada-days
```

#### Reserved names

The parser rejects names that conflict with platform infrastructure:

- Any name starting with `bluefox-` (this covers all platform services: `bluefox-platform`, `bluefox-platform-db`, `bluefox-traefik`, `bluefox-registry`, `bluefox-storage`, and any future additions)
- Single-character names

---

### `compute` (required)

Declares the processes the app runs. At least one process is required. Each key is the process name (arbitrary, user-chosen).

```yaml
compute:
  app:
    port: 8000
  worker: {}
```

#### Process fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `port` | integer | no | — | If set, the process receives HTTP traffic via Traefik. Processes without `port` are background workers with no inbound HTTP. |
| `healthcheck` | string | no | `/health` | HTTP path for readiness checks. Only valid when `port` is set. Defaults to `/health` — only set this to override. |
| `mode` | string | no | process key name | Injected as `MODE=<value>` env var. Defaults to the process key name, so `app:` gets `MODE=app` and `worker:` gets `MODE=worker` automatically. Only set this to override. |

#### Routing rules

- Only one process may declare `port`. The parser rejects manifests with multiple routable processes.
- The routable process gets `<app-name>.<domain>` as its URL (e.g., `canada-days.bluefox.software`).
- Background processes (no `port`) are deployed on the internal overlay network only.

> **v2 expansion:** Multiple routable processes with subdomain rules (e.g., `worker-myapp.bluefox.software`). The `compute` shape already supports this — just relax the single-port constraint and add routing config.

#### Mode convention

`mode` is the platform standard for differentiating processes that share the same image. The platform injects `MODE` as an env var into every compute process. How the app uses it is the app's responsibility.

**Single-process apps** can ignore `MODE` entirely and use the Dockerfile's `CMD` as normal.

**Multi-process apps** typically use an entrypoint script that branches on `MODE`:

```bash
#!/bin/bash
case "$MODE" in
  app)     exec uvicorn app:create_app --factory --host 0.0.0.0 --port 8000 ;;
  worker)  exec uv run saq app.worker.settings ;;
  *)       echo "Unknown mode: $MODE" && exit 1 ;;
esac
```

The Dockerfile invokes the entrypoint:

```dockerfile
COPY entrypoint.sh ./
RUN chmod +x entrypoint.sh
CMD ["./entrypoint.sh"]
```

The convention is "your container receives `MODE`" — the filename, language, and mechanism are yours.

---

### `data` (optional)

Declares a managed database. The platform provisions it, injects the connection URL, handles daily backups, and never restarts it during code deploys.

```yaml
data:
  engine: postgres
  version: 17
  migrate: "uv run alembic upgrade head"
```

#### Data fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `engine` | string | yes | — | Database engine. v1 only supports `postgres`. |
| `version` | integer | yes | — | Engine major version (e.g., `17`). The platform selects the image (e.g., `postgres:17-alpine`). |
| `migrate` | string | no | — | Migration command. Runs as a one-shot container after build, before compute processes start. Uses the app's image, on the internal network, with all env vars injected including `DATABASE_URL`. |

#### Platform behavior

- Provisioned as a Swarm service named `<app-name>-db` on `bluefox-net`.
- Connection URL injected as `DATABASE_URL` into all compute processes.
- Format: `postgresql://<user>:<password>@<app-name>-db:5432/<db-name>`
- Daily backups managed by the platform (not configured in manifest).
- Not restarted during code deploys — data primitives have independent lifecycles.
- **Version changes on existing primitives are rejected.** Changing `version: 17` to `version: 18` on a running app requires an explicit migration path (out of scope for v1).

> **v2 expansion:** Named data instances for apps with multiple databases:
> ```yaml
> data:
>   main:
>     engine: postgres
>     version: 17
>     migrate: "uv run alembic upgrade head"
>   analytics:
>     engine: postgres
>     version: 17
>     migrate: "uv run alembic -c alembic-analytics.ini upgrade head"
> ```
> Env vars become `DATA_MAIN_URL`, `DATA_ANALYTICS_URL`. When only one instance exists, `DATABASE_URL` is also injected as a convenience alias. Migration dependency declarations (e.g., "this instance's migration is handled by another") are a v2 feature.

---

### `in-memory` (optional)

Declares a managed in-memory store. The platform provisions it and injects the connection URL.

```yaml
in-memory:
  engine: redis
  version: 7
```

#### In-memory fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `engine` | string | yes | — | Engine type. v1 only supports `redis`. |
| `version` | integer | yes | — | Engine major version (e.g., `7`). The platform selects the image (e.g., `redis:7-alpine`). |

#### Platform behavior

- Provisioned as a Swarm service named `<app-name>-redis` on `bluefox-net`.
- Connection URL injected as `REDIS_URL` into all compute processes.
- Format: `redis://<app-name>-redis:6379/0`
- Not restarted during code deploys.
- **Version changes on existing primitives are rejected** (same as data).

> **v2 expansion:** Named in-memory instances:
> ```yaml
> in-memory:
>   cache:
>     engine: redis
>     version: 7
>   queue:
>     engine: redis
>     version: 7
> ```
> Env vars become `IN_MEMORY_CACHE_URL`, `IN_MEMORY_QUEUE_URL`. When only one instance exists, `REDIS_URL` is also injected as a convenience alias.

---

## Build

Every app must include a `Dockerfile` in its root. The platform builds the image using `docker build` — no buildpacks, no auto-detection.

The tarball uploaded during `bfx release` respects `.gitignore` (via `git ls-files`). The manifest defines what the app *is*; `.gitignore` defines what gets *shipped*.

---

## Injected Environment Variables

The platform injects these env vars into every compute process:

| Variable | Source | Always present |
|----------|--------|---------------|
| `APP_NAME` | `name` field | yes |
| `MODE` | process `mode` (defaults to key name) | yes |
| `SECRET_KEY` | platform-generated per app | yes |
| `PORT` | process `port` field | only if `port` is set |
| `DATABASE_URL` | `data` primitive | only if `data` is declared |
| `REDIS_URL` | `in-memory` primitive | only if `in-memory` is declared |

User-defined config vars (set via `bfx config set`) are also injected into all compute processes.

---

## Deploy Lifecycle

When a release is created, the platform executes this pipeline:

1. **Parse** — Extract tarball, validate `bluefox.yml`
2. **Build** — `docker build` using the app's `Dockerfile`, tag and push to registry
3. **Provision** — Create any declared primitives that don't already exist (`data`, `in-memory`)
4. **Migrate** — If `data.migrate` is set, run it as a one-shot container with all env vars
5. **Deploy** — Create/update Swarm services for each compute process (start-first rolling update, zero-downtime)
6. **Route** — Write Traefik config for the routable process

Each step updates the release status. On failure, the release is marked `failed` and the pipeline stops.

---

## Infrastructure Service Names

The platform reserves these service names on the Docker Swarm cluster:

| Service | Name |
|---------|------|
| Platform API + dashboard | `bluefox-platform` |
| Platform database | `bluefox-platform-db` |
| Reverse proxy | `bluefox-traefik` |
| Image registry | `bluefox-registry` |
| Object storage (v2) | `bluefox-storage` |

All platform services use the `bluefox-` prefix. This is why app names starting with `bluefox-` are reserved.

App services follow the pattern `<app-name>_<process>` (e.g., `my-saas_app`, `my-saas_worker`). App primitives follow `<app-name>-db` and `<app-name>-redis`.

---

## Examples

### Minimal — simple API, no database

```yaml
version: 1
name: my-api

compute:
  app:
    port: 8000
```

Healthcheck defaults to `/health`. Mode defaults to `app`.

### Typical — API with database

```yaml
version: 1
name: canada-days

compute:
  app:
    port: 8000

data:
  engine: postgres
  version: 17
  migrate: "uv run alembic upgrade head"
```

### Full — API + worker + database + cache

```yaml
version: 1
name: my-saas

compute:
  app:
    port: 8000
  worker: {}

data:
  engine: postgres
  version: 17
  migrate: "uv run alembic upgrade head"

in-memory:
  engine: redis
  version: 7
```

### The platform itself

```yaml
version: 1
name: bluefox-platform

compute:
  app:
    port: 8000

data:
  engine: postgres
  version: 17
  migrate: "uv run alembic upgrade head"
```

---

## Validation Rules

The parser must enforce:

1. `version` is present and equals `1`
2. `name` is present, DNS-safe, and not reserved
3. `compute` is present and has at least one process
4. At most one compute process has `port`
5. `healthcheck` is only valid on a process that has `port`
6. If `data` is present, `engine` and `version` are required
7. If `in-memory` is present, `engine` and `version` are required
8. `data.engine` must be `postgres` (v1)
9. `in-memory.engine` must be `redis` (v1)
10. `data.migrate` is only valid when `data` is declared
11. A `Dockerfile` must exist in the tarball root (validated during pipeline, not by parser)

---

## v2 Expansion Summary

The v1 shape is designed to expand without breaking changes:

| Feature | v1 | v2 |
|---------|----|----|
| Compute processes | multiple, one routable | multiple routable with subdomain rules |
| Data primitives | single instance | named instances (`data.main`, `data.analytics`) |
| In-memory primitives | single instance | named instances (`in-memory.cache`, `in-memory.queue`) |
| Migrations | single command on `data` | per-primitive, with dependency declarations |
| Dockerfiles | one per app | optional per-process overrides |
| Scaling | not configurable | per-process replica count and auto-scaling rules |
| Data version upgrades | rejected | managed upgrade path |

v1 manifests remain valid in v2 — single `data:` and `in-memory:` objects become sugar for a single unnamed instance.
