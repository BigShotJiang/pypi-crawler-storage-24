import re

from pydantic import BaseModel, Field, field_validator, model_validator

_DNS_NAME_RE = re.compile(r"^[a-z][a-z0-9-]{1,61}[a-z0-9]$")


class ComputeProcess(BaseModel):
    mode: str
    port: int | None = None
    healthcheck: str | None = None

    @model_validator(mode="after")
    def set_default_healthcheck(self):
        if self.port is not None and self.healthcheck is None:
            self.healthcheck = "/health"
        return self


_VALID_DATA_ENGINES = {"postgres"}
_VALID_IN_MEMORY_ENGINES = {"redis"}


class DataPrimitive(BaseModel):
    engine: str
    version: int
    migrate: str | None = None

    @field_validator("version")
    @classmethod
    def check_version_positive(cls, v):
        if v < 1:
            raise ValueError("version must be a positive integer")
        return v

    @field_validator("engine")
    @classmethod
    def check_engine(cls, v):
        if v not in _VALID_DATA_ENGINES:
            raise ValueError(
                f"unsupported data engine '{v}' "
                f"(v1 supports: {', '.join(sorted(_VALID_DATA_ENGINES))})"
            )
        return v


class InMemoryPrimitive(BaseModel):
    engine: str
    version: int

    @field_validator("version")
    @classmethod
    def check_version_positive(cls, v):
        if v < 1:
            raise ValueError("version must be a positive integer")
        return v

    @field_validator("engine")
    @classmethod
    def check_engine(cls, v):
        if v not in _VALID_IN_MEMORY_ENGINES:
            raise ValueError(
                f"unsupported in-memory engine '{v}' "
                f"(v1 supports: {', '.join(sorted(_VALID_IN_MEMORY_ENGINES))})"
            )
        return v


class Manifest(BaseModel):
    version: int
    name: str
    compute: dict[str, ComputeProcess]
    data: DataPrimitive | None = None
    in_memory: InMemoryPrimitive | None = Field(default=None, alias="in-memory")

    model_config = {"populate_by_name": True}

    @field_validator("compute")
    @classmethod
    def check_compute_not_empty(cls, v):
        if not v:
            raise ValueError("compute must declare at least one process")
        return v

    @field_validator("version")
    @classmethod
    def check_version(cls, v):
        if v != 1:
            raise ValueError("unsupported manifest version (expected 1)")
        return v

    @field_validator("name")
    @classmethod
    def check_name_dns_safe(cls, v):
        if not _DNS_NAME_RE.match(v):
            raise ValueError(
                f"name must be DNS-safe: lowercase letters, digits, hyphens, "
                f"3-63 characters (got '{v}')"
            )
        if v.startswith("bluefox-"):
            raise ValueError(
                f"name '{v}' is reserved (bluefox- prefix is reserved for platform services)"
            )
        return v

    def service_name(self, process: str) -> str:
        """e.g., 'my-app_app', 'my-app_worker'"""
        return f"{self.name}_{process}"

    def db_service_name(self) -> str | None:
        """e.g., 'my-app-db'. None if no data primitive."""
        return f"{self.name}-db" if self.data else None

    def redis_service_name(self) -> str | None:
        """e.g., 'my-app-redis'. None if no in-memory primitive."""
        return f"{self.name}-redis" if self.in_memory else None

    def image_tag(self, version: int) -> str:
        """e.g., 'localhost:5000/my-app:v3'"""
        return f"localhost:5000/{self.name}:v{version}"

    def db_image(self) -> str | None:
        """e.g., 'postgres:17-alpine'. None if no data."""
        if not self.data:
            return None
        return f"{self.data.engine}:{self.data.version}-alpine"

    def redis_image(self) -> str | None:
        """e.g., 'redis:7-alpine'. None if no in-memory."""
        if not self.in_memory:
            return None
        return f"{self.in_memory.engine}:{self.in_memory.version}-alpine"

    def routable_process(self) -> tuple[str, ComputeProcess] | None:
        """Return (name, process) for the process with port, or None."""
        for name, proc in self.compute.items():
            if proc.port is not None:
                return (name, proc)
        return None

    def env_vars(self, process_name: str) -> dict[str, str]:
        """Base env vars the platform injects for a given process.

        Does NOT include DATABASE_URL/REDIS_URL (those come from provisioning)
        or user config vars (those come from the API).
        """
        proc = self.compute[process_name]
        env = {
            "APP_NAME": self.name,
            "MODE": proc.mode,
        }
        if proc.port is not None:
            env["PORT"] = str(proc.port)
        return env

    @model_validator(mode="after")
    def check_single_routable(self):
        routable = [name for name, p in self.compute.items() if p.port is not None]
        if len(routable) > 1:
            raise ValueError(
                f"only one compute process may declare port, "
                f"but found: {', '.join(routable)}"
            )
        return self

    @model_validator(mode="after")
    def check_healthcheck_only_on_routable(self):
        for name, p in self.compute.items():
            if p.port is None and p.healthcheck is not None:
                raise ValueError(
                    f"compute.{name}: healthcheck is only valid on "
                    f"processes that declare port"
                )
        return self
