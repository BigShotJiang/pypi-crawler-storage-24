from pathlib import Path

import yaml
from pydantic import ValidationError

from bluefox_yml.exceptions import ManifestError
from bluefox_yml.models import Manifest


def _load_yaml(path: Path) -> dict:
    """Read a YAML file and return the raw dict. Raises ManifestError on failure."""
    if not path.exists():
        raise ManifestError(f"{path} not found")

    try:
        content = path.read_text()
    except OSError as e:
        raise ManifestError(f"could not read {path}: {e}") from e

    try:
        raw = yaml.safe_load(content)
    except yaml.YAMLError as e:
        raise ManifestError(f"invalid YAML in {path}: {e}") from e

    if not isinstance(raw, dict):
        raise ManifestError(f"{path} must be a YAML mapping, got {type(raw).__name__}")

    return raw


def _prepare_compute(raw_compute: dict) -> dict[str, dict]:
    """Inject default mode from key name, normalize empty dicts and YAML nulls."""
    result = {}
    for key, value in raw_compute.items():
        if value is None:
            value = {}
        if not isinstance(value, dict):
            raise ManifestError(
                f"compute.{key}: expected a mapping, got {type(value).__name__}"
            )
        proc = dict(value)
        if "mode" not in proc:
            proc["mode"] = key
        result[key] = proc
    return result


def _prepare_raw(raw: dict) -> dict:
    """Normalize raw YAML keys for Pydantic. Returns a new dict, does not mutate input."""
    result = dict(raw)
    if "in-memory" in result:
        result["in_memory"] = result.pop("in-memory")
    return result


def load_manifest(path: Path | str = "bluefox.yml") -> Manifest:
    """Load and validate a bluefox.yml manifest. Raises ManifestError on failure."""
    path = Path(path)
    raw = _load_yaml(path)
    raw = _prepare_raw(raw)

    if "compute" in raw and isinstance(raw["compute"], dict):
        raw["compute"] = _prepare_compute(raw["compute"])

    try:
        return Manifest(**raw)
    except ValidationError as e:
        messages = []
        for error in e.errors():
            loc = " → ".join(str(part) for part in error["loc"])
            messages.append(f"{loc}: {error['msg']}")
        raise ManifestError(
            f"bluefox.yml validation error:\n" + "\n".join(f"  {m}" for m in messages)
        ) from e
