class ManifestError(Exception):
    """Raised when a bluefox.yml is invalid."""

    def __init__(self, message: str, field: str | None = None):
        self.field = field
        super().__init__(message)


def format_error(error: ManifestError) -> str:
    """Format a ManifestError for CLI/log output.

    Returns a single-line or multi-line string suitable for printing.
    No Pydantic internals leak to the user.
    """
    return f"bluefox.yml error: {error}"
