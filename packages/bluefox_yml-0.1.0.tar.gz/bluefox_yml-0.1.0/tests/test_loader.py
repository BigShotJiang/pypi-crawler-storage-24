import pytest

from bluefox_yml.exceptions import ManifestError, format_error
from bluefox_yml.loader import _load_yaml, _prepare_compute, _prepare_raw, load_manifest


def test_load_yaml__valid(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\nname: my-app\n")
    result = _load_yaml(f)
    assert result == {"version": 1, "name": "my-app"}


def test_load_yaml__file_not_found(tmp_path):
    with pytest.raises(ManifestError, match="not found"):
        _load_yaml(tmp_path / "missing.yml")


def test_load_yaml__invalid_yaml(tmp_path):
    f = tmp_path / "bad.yml"
    f.write_text(":\n  - :\n    bad: [unclosed")
    with pytest.raises(ManifestError, match="invalid YAML"):
        _load_yaml(f)


def test_load_yaml__not_a_dict_list(tmp_path):
    f = tmp_path / "list.yml"
    f.write_text("- one\n- two\n")
    with pytest.raises(ManifestError, match="must be a YAML mapping"):
        _load_yaml(f)


def test_load_yaml__not_a_dict_scalar(tmp_path):
    f = tmp_path / "scalar.yml"
    f.write_text("just a string")
    with pytest.raises(ManifestError, match="must be a YAML mapping"):
        _load_yaml(f)


def test_prepare_compute__empty_dict():
    result = _prepare_compute({"worker": {}})
    assert result == {"worker": {"mode": "worker"}}


def test_prepare_compute__yaml_null():
    result = _prepare_compute({"worker": None})
    assert result == {"worker": {"mode": "worker"}}


def test_prepare_compute__with_port():
    result = _prepare_compute({"app": {"port": 8000}})
    assert result == {"app": {"port": 8000, "mode": "app"}}


def test_prepare_compute__explicit_mode():
    result = _prepare_compute({"app": {"port": 8000, "mode": "custom"}})
    assert result == {"app": {"port": 8000, "mode": "custom"}}


def test_prepare_compute__multiple_processes():
    result = _prepare_compute({
        "app": {"port": 8000},
        "worker": None,
    })
    assert result == {
        "app": {"port": 8000, "mode": "app"},
        "worker": {"mode": "worker"},
    }


def test_prepare_raw__renames_in_memory():
    raw = {"version": 1, "name": "app", "in-memory": {"engine": "redis", "version": 7}}
    result = _prepare_raw(raw)
    assert "in_memory" in result
    assert "in-memory" not in result
    assert result["in_memory"] == {"engine": "redis", "version": 7}


def test_prepare_raw__does_not_mutate_input():
    raw = {"version": 1, "in-memory": {"engine": "redis", "version": 7}}
    original = dict(raw)
    _prepare_raw(raw)
    assert raw == original


def test_prepare_raw__no_in_memory():
    raw = {"version": 1, "name": "app"}
    result = _prepare_raw(raw)
    assert "in_memory" not in result
    assert "in-memory" not in result


def test_load_manifest__minimal(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\nname: my-api\ncompute:\n  app:\n    port: 8000\n")
    m = load_manifest(f)
    assert m.version == 1
    assert m.name == "my-api"
    assert m.compute["app"].port == 8000
    assert m.compute["app"].mode == "app"
    assert m.compute["app"].healthcheck == "/health"
    assert m.data is None
    assert m.in_memory is None


def test_load_manifest__full(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text(
        "version: 1\n"
        "name: my-saas\n"
        "compute:\n"
        "  app:\n"
        "    port: 8000\n"
        "  worker: {}\n"
        "data:\n"
        "  engine: postgres\n"
        "  version: 17\n"
        "  migrate: 'uv run alembic upgrade head'\n"
        "in-memory:\n"
        "  engine: redis\n"
        "  version: 7\n"
    )
    m = load_manifest(f)
    assert m.name == "my-saas"
    assert m.compute["app"].port == 8000
    assert m.compute["app"].mode == "app"
    assert m.compute["worker"].port is None
    assert m.compute["worker"].mode == "worker"
    assert m.data.engine == "postgres"
    assert m.data.version == 17
    assert m.data.migrate == "uv run alembic upgrade head"
    assert m.in_memory.engine == "redis"
    assert m.in_memory.version == 7


def test_load_manifest__worker_yaml_null(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\nname: my-app\ncompute:\n  app:\n    port: 8000\n  worker:\n")
    m = load_manifest(f)
    assert m.compute["worker"].mode == "worker"
    assert m.compute["worker"].port is None


def test_load_manifest__string_path(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\nname: my-api\ncompute:\n  app:\n    port: 8000\n")
    m = load_manifest(str(f))
    assert m.name == "my-api"


def test_load_manifest__missing_required_field(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\ncompute:\n  app:\n    port: 8000\n")
    with pytest.raises(ManifestError, match="name"):
        load_manifest(f)


def test_load_manifest__invalid_type(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\nname: my-api\ncompute:\n  app:\n    port: not-a-number\n")
    with pytest.raises(ManifestError, match="validation error"):
        load_manifest(f)


def test_load_manifest__invalid_data_engine_rejected(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text(
        "version: 1\nname: my-app\ncompute:\n  app:\n    port: 8000\n"
        "data:\n  engine: mysql\n  version: 8\n"
    )
    with pytest.raises(ManifestError, match="unsupported data engine"):
        load_manifest(f)


def test_load_manifest__invalid_in_memory_engine_rejected(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text(
        "version: 1\nname: my-app\ncompute:\n  app:\n    port: 8000\n"
        "in-memory:\n  engine: memcached\n  version: 1\n"
    )
    with pytest.raises(ManifestError, match="unsupported in-memory engine"):
        load_manifest(f)


def test_load_manifest__healthcheck_on_worker_rejected(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text(
        "version: 1\nname: my-app\ncompute:\n"
        "  worker:\n    healthcheck: /health\n"
    )
    with pytest.raises(ManifestError, match="healthcheck is only valid"):
        load_manifest(f)


def test_prepare_compute__non_dict_value_rejected():
    with pytest.raises(ManifestError, match="compute.worker.*expected a mapping.*int"):
        _prepare_compute({"worker": 42})


def test_prepare_compute__string_value_rejected():
    with pytest.raises(ManifestError, match="compute.app.*expected a mapping.*str"):
        _prepare_compute({"app": "somestring"})


# --- format_error ---


def test_format_error__validation_error(tmp_path):
    f = tmp_path / "bluefox.yml"
    f.write_text("version: 1\nname: My-App\ncompute:\n  app:\n    port: 8000\n")
    try:
        load_manifest(f)
    except ManifestError as e:
        msg = format_error(e)
        assert msg.startswith("bluefox.yml error:")
        assert "DNS-safe" in msg


def test_format_error__file_not_found(tmp_path):
    try:
        load_manifest(tmp_path / "missing.yml")
    except ManifestError as e:
        msg = format_error(e)
        assert msg.startswith("bluefox.yml error:")
        assert "not found" in msg


def test_format_error__simple():
    err = ManifestError("something went wrong")
    assert format_error(err) == "bluefox.yml error: something went wrong"


# --- Public API imports ---


def test_public_api_imports():
    from bluefox_yml import (
        ComputeProcess,
        DataPrimitive,
        InMemoryPrimitive,
        Manifest,
        ManifestError,
        format_error,
        load_manifest,
    )
    assert callable(load_manifest)
    assert callable(format_error)
    assert issubclass(ManifestError, Exception)
