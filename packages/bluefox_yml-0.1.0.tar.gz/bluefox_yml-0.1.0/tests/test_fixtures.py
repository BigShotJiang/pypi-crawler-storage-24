"""Integration tests using YAML fixture files from the spec examples."""

from pathlib import Path

import pytest

from bluefox_yml.exceptions import ManifestError
from bluefox_yml.loader import load_manifest

FIXTURES = Path(__file__).parent / "fixtures"


# --- Valid fixtures ---


def test_fixture__minimal():
    m = load_manifest(FIXTURES / "minimal.yml")
    assert m.version == 1
    assert m.name == "my-api"
    assert m.compute["app"].port == 8000
    assert m.compute["app"].mode == "app"
    assert m.compute["app"].healthcheck == "/health"
    assert m.data is None
    assert m.in_memory is None


def test_fixture__typical():
    m = load_manifest(FIXTURES / "typical.yml")
    assert m.name == "canada-days"
    assert m.compute["app"].port == 8000
    assert m.data.engine == "postgres"
    assert m.data.version == 17
    assert m.data.migrate == "uv run alembic upgrade head"
    assert m.in_memory is None


def test_fixture__full():
    m = load_manifest(FIXTURES / "full.yml")
    assert m.name == "my-saas"
    assert len(m.compute) == 2
    assert m.compute["app"].port == 8000
    assert m.compute["app"].mode == "app"
    assert m.compute["app"].healthcheck == "/health"
    assert m.compute["worker"].port is None
    assert m.compute["worker"].mode == "worker"
    assert m.compute["worker"].healthcheck is None
    assert m.data.engine == "postgres"
    assert m.data.version == 17
    assert m.data.migrate == "uv run alembic upgrade head"
    assert m.in_memory.engine == "redis"
    assert m.in_memory.version == 7


def test_fixture__full_service_names():
    m = load_manifest(FIXTURES / "full.yml")
    assert m.service_name("app") == "my-saas_app"
    assert m.service_name("worker") == "my-saas_worker"
    assert m.db_service_name() == "my-saas-db"
    assert m.redis_service_name() == "my-saas-redis"


def test_fixture__full_images():
    m = load_manifest(FIXTURES / "full.yml")
    assert m.db_image() == "postgres:17-alpine"
    assert m.redis_image() == "redis:7-alpine"
    assert m.image_tag(3) == "localhost:5000/my-saas:v3"


def test_fixture__full_env_vars():
    m = load_manifest(FIXTURES / "full.yml")
    assert m.env_vars("app") == {"APP_NAME": "my-saas", "MODE": "app", "PORT": "8000"}
    assert m.env_vars("worker") == {"APP_NAME": "my-saas", "MODE": "worker"}


def test_fixture__full_routable_process():
    m = load_manifest(FIXTURES / "full.yml")
    name, proc = m.routable_process()
    assert name == "app"
    assert proc.port == 8000


# --- Invalid fixtures ---


def test_fixture__invalid_name():
    with pytest.raises(ManifestError, match="DNS-safe"):
        load_manifest(FIXTURES / "invalid_name.yml")


def test_fixture__invalid_reserved_name():
    with pytest.raises(ManifestError, match="reserved"):
        load_manifest(FIXTURES / "invalid_reserved_name.yml")


def test_fixture__invalid_multi_port():
    with pytest.raises(ManifestError, match="only one compute process may declare port"):
        load_manifest(FIXTURES / "invalid_multi_port.yml")


def test_fixture__invalid_engine():
    with pytest.raises(ManifestError, match="unsupported data engine"):
        load_manifest(FIXTURES / "invalid_engine.yml")


def test_fixture__invalid_version():
    with pytest.raises(ManifestError, match="unsupported manifest version"):
        load_manifest(FIXTURES / "invalid_version.yml")


def test_fixture__empty_compute():
    with pytest.raises(ManifestError, match="at least one process"):
        load_manifest(FIXTURES / "empty_compute.yml")
