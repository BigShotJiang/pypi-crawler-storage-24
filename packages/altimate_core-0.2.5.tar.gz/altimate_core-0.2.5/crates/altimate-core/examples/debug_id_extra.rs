//! Debug the ID extra output column case.
use altimate_core::lineage::column_lineage as cl_mod;
use altimate_core::lineage::column_lineage;
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    let sql = r#"select t.* , count(distinct case when soc1.orders > 0 then soc1.id end) orders_before_snapshot ,
case when orders_before_snapshot  =0 then 'Signups'
when orders_before_snapshot = 1 then 'FTB'
when orders_before_snapshot = 2 then 'Second Order'
when orders_before_snapshot > 2 then '3+ Orders' end journey_stage,
from marketing_asset.su_ttb_audience_base t
left join
summary.shopping_order_cube_v6 soc1 on t.member_id = soc1.member_id and t.tenant = soc1.tenant and
soc1.tt_created_ts < snapshot_date
group by all
order by 1,4"#;

    // Check polyglot edges
    let poly = cl_mod::polyglot_column_lineage(sql, SqlDialect::Snowflake).unwrap();
    eprintln!("=== Polyglot edges ===");
    for e in &poly.edges {
        eprintln!(
            "  {} | {} -> {} (terminal: {:?})",
            e.source_table, e.source_column, e.target_column, e.terminal_kind
        );
    }

    // Check our full engine
    let schema: HashMap<String, serde_json::Value> = serde_json::from_str(
        r#"{
        "SU_TTB_AUDIENCE_BASE": {"MEMBER_ID": "VARCHAR", "TARGET_DATE_ID": "VARCHAR", "SNAPSHOT_DATE_ID": "VARCHAR", "FTB_MONTH": "VARCHAR", "TENANT": "VARCHAR", "TARGET_DATE": "VARCHAR", "SNAPSHOT_DATE": "VARCHAR", "SIGNUP_DATE": "VARCHAR"},
        "SHOPPING_ORDER_CUBE_V6": {"ID": "VARCHAR"}
    }"#,
    )
    .unwrap();

    let result = column_lineage(sql, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("\n=== ACTUAL output (our engine) ===");
    let mut keys: Vec<_> = result.column_dict.keys().collect();
    keys.sort();
    for k in keys {
        let mut srcs: Vec<_> = result.column_dict[k].iter().collect();
        srcs.sort();
        eprintln!("  {}:", k);
        for s in srcs {
            eprintln!("    <- {}", s);
        }
    }

    eprintln!("\n=== EXPECTED (ground truth) ===");
    let expected = vec![
        ("FTB_MONTH", vec!["\"SU_TTB_AUDIENCE_BASE\".\"FTB_MONTH\""]),
        ("MEMBER_ID", vec!["\"SU_TTB_AUDIENCE_BASE\".\"MEMBER_ID\""]),
        (
            "ORDERS_BEFORE_SNAPSHOT",
            vec!["\"SHOPPING_ORDER_CUBE_V6\".\"ID\""],
        ),
        (
            "SIGNUP_DATE",
            vec!["\"SU_TTB_AUDIENCE_BASE\".\"SIGNUP_DATE\""],
        ),
        (
            "SNAPSHOT_DATE",
            vec!["\"SU_TTB_AUDIENCE_BASE\".\"SNAPSHOT_DATE\""],
        ),
        (
            "SNAPSHOT_DATE_ID",
            vec!["\"SU_TTB_AUDIENCE_BASE\".\"SNAPSHOT_DATE_ID\""],
        ),
        (
            "TARGET_DATE",
            vec!["\"SU_TTB_AUDIENCE_BASE\".\"TARGET_DATE\""],
        ),
        (
            "TARGET_DATE_ID",
            vec!["\"SU_TTB_AUDIENCE_BASE\".\"TARGET_DATE_ID\""],
        ),
        ("TENANT", vec!["\"SU_TTB_AUDIENCE_BASE\".\"TENANT\""]),
    ];
    for (col, srcs) in &expected {
        eprintln!("  {}:", col);
        for s in srcs {
            eprintln!("    <- {}", s);
        }
    }
}
