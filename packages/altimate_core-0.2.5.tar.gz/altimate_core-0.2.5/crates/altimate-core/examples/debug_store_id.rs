//! Debug what polyglot-sql produces for the STORE_ID literal case.
use altimate_core::lineage::column_lineage as cl_mod;
use altimate_core::lineage::column_lineage;
use altimate_core::schema::types::SqlDialect;
use std::collections::HashMap;

fn main() {
    let sql = r#"SELECT
        distinct member_id, guid, email, solo_merchant_id,
        campaign, target_date, STORE_ID, SOLO_MERCHANT_SIZE,
        STORE_TYPE, recommended_store_rank, gender
    FROM (
        SELECT
            distinct mp.member_id, mp.guid, mp.email,
            store_campaign.STORE_ID as solo_merchant_id,
            '20260221_push_solo' campaign,
            '2026-02-21' target_date,
            '15569' as STORE_ID,
            case when store_campaign.GROUP_RANK = 4 then 'Small'
                 when store_campaign.GROUP_RANK = 3 then 'Medium'
                 else 'Big' end as SOLO_MERCHANT_SIZE,
            case when 15569 = store_campaign.STORE_ID then 'solo_store'
                 else 'recommended_store' end as STORE_TYPE,
            1 as recommended_store_rank,
            mp.gender
        FROM "DW"."MEMBER_PROFILE" mp
        INNER JOIN "MARKETING_ASSET"."PUSH_SOLO_TARGETING_STORE_GROUPS" store_campaign
            ON mp.member_id = store_campaign.member_id
    )"#;

    // Check polyglot edges
    let poly = cl_mod::polyglot_column_lineage(sql, SqlDialect::Snowflake).unwrap();
    eprintln!("=== Polyglot edges ===");
    for e in &poly.edges {
        eprintln!(
            "  {} | {} -> {} (terminal: {:?})",
            e.source_table, e.source_column, e.target_column, e.terminal_kind
        );
    }

    // Check our full engine
    let schema: HashMap<String, serde_json::Value> = serde_json::from_str(r#"{
        "MEMBER_PROFILE": {"MEMBER_ID": "VARCHAR", "GUID": "VARCHAR", "EMAIL": "VARCHAR", "GENDER": "VARCHAR"},
        "PUSH_SOLO_TARGETING_STORE_GROUPS": {"MEMBER_ID": "VARCHAR", "STORE_ID": "VARCHAR", "GROUP_RANK": "VARCHAR"}
    }"#).unwrap();

    let result = column_lineage(sql, SqlDialect::Snowflake, &schema, None).unwrap();
    eprintln!("\n=== Engine output ===");
    let mut keys: Vec<_> = result.column_dict.keys().collect();
    keys.sort();
    for k in keys {
        eprintln!("  {} => {:?}", k, result.column_dict[k]);
    }

    // Also test: what if STORE_ID is NOT in the schema?
    let schema_no_storeid: HashMap<String, serde_json::Value> = serde_json::from_str(r#"{
        "MEMBER_PROFILE": {"MEMBER_ID": "VARCHAR", "GUID": "VARCHAR", "EMAIL": "VARCHAR", "GENDER": "VARCHAR"},
        "PUSH_SOLO_TARGETING_STORE_GROUPS": {"MEMBER_ID": "VARCHAR", "GROUP_RANK": "VARCHAR"}
    }"#).unwrap();

    let result2 = column_lineage(sql, SqlDialect::Snowflake, &schema_no_storeid, None).unwrap();
    eprintln!("\n=== Engine output (STORE_ID removed from schema) ===");
    let mut keys: Vec<_> = result2.column_dict.keys().collect();
    keys.sort();
    for k in keys {
        eprintln!("  {} => {:?}", k, result2.column_dict[k]);
    }
}
