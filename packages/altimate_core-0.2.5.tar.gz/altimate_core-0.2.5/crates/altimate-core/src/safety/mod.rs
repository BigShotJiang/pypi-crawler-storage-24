//! SQL Safety Scanner — detects SQL injection patterns in agent-generated SQL.
//!
//! This module provides static analysis of SQL strings to detect injection
//! patterns, tautology attacks, encoding bypasses, and other threats.
//! It uses regex-based pattern matching and never executes SQL.
//!
//! # Usage
//!
//! ```rust
//! use altimate_core::safety::{scan_sql, is_safe, SafetyConfig};
//!
//! // Quick check with strict defaults
//! assert!(is_safe("SELECT id FROM users WHERE id = 1"));
//! assert!(!is_safe("SELECT 1; DROP TABLE users"));
//!
//! // Full scan with custom config
//! let config = SafetyConfig::default();
//! let result = scan_sql("SELECT * FROM users WHERE id = 1 OR 1=1", &config);
//! assert!(!result.safe);
//! for threat in &result.threats {
//!     println!("{}: {} ({})", threat.rule, threat.message, threat.severity);
//! }
//! ```

pub mod engine;
pub mod rules;
pub mod types;

// Re-export primary types for convenience
pub use engine::{is_safe, scan_sql};
pub use types::{SafetyConfig, SafetyRule, SafetyScanResult, SafetySeverity, ThreatFinding};
