//! Types for migration analysis.

use serde::{Deserialize, Serialize};

/// Risk level of a migration.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MigrationRisk {
    Safe,
    Caution,
    Dangerous,
    Destructive,
}

/// A single migration finding.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MigrationFinding {
    /// Risk level
    pub risk: MigrationRisk,
    /// What operation is being performed
    pub operation: String,
    /// Human-readable description
    pub message: String,
    /// Suggested mitigation
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mitigation: Option<String>,
    /// Rollback SQL if applicable
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rollback_sql: Option<String>,
}

/// Result of migration analysis.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MigrationResult {
    /// The migration SQL analyzed
    pub sql: String,
    /// Overall risk level (highest of any finding)
    pub overall_risk: MigrationRisk,
    /// Individual findings
    pub findings: Vec<MigrationFinding>,
    /// Whether the migration is safe to apply
    pub safe: bool,
    /// Generated rollback SQL
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rollback_sql: Option<String>,
}
