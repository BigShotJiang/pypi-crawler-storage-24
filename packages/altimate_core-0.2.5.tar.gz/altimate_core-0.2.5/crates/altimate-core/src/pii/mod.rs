//! PII Detection & Column Classification module.
//!
//! Scans schema columns for personally identifiable information (PII) patterns,
//! checks queries for PII access, and suggests dialect-specific masking expressions.
//!
//! # Usage
//!
//! ```rust,no_run
//! use altimate_core::pii::{classify_schema, check_query_pii};
//! use altimate_core::schema::types::{SchemaDefinition, SqlDialect};
//!
//! let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//! let report = classify_schema(&schema);
//! println!("PII columns: {}/{}", report.pii_count, report.total_columns);
//! ```

pub mod engine;
pub mod types;

pub use engine::{check_query_pii, classify_column, classify_schema};
pub use types::{
    PiiClassification, PiiColumnAccess, PiiColumnResult, PiiQueryResult, PiiReport, PiiRiskLevel,
};
