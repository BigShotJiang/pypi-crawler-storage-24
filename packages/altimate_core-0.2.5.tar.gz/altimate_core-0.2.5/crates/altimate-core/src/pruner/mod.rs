//! Context-aware schema pruning.
//!
//! Given a SQL query, returns only the relevant subset of the schema —
//! the tables and columns actually referenced. Reduces context window usage
//! for AI agents working with large schemas.

pub mod engine;
pub mod types;

pub use engine::prune_schema;
pub use types::*;
