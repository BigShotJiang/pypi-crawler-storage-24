//! Types for schema pruning.

use serde::{Deserialize, Serialize};

/// Result of schema pruning — a minimal schema subset.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PruneResult {
    /// Tables that are relevant to the query
    pub relevant_tables: Vec<String>,
    /// Total tables in original schema
    pub total_tables: usize,
    /// Pruned schema as YAML
    pub pruned_schema_yaml: String,
    /// How many tables were pruned
    pub tables_pruned: usize,
}
