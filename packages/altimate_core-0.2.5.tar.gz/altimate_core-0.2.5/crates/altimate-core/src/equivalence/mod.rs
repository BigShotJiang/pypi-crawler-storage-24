//! Query equivalence module.
//!
//! Compares two SQL queries heuristically to determine if they produce
//! the same results.
//!
//! The equivalence check analyzes:
//! - Output columns (names and types)
//! - Referenced tables
//! - Filter predicates (normalized)
//! - Join structure (types and conditions)
//! - Aggregation patterns
//! - Sort and limit clauses
//!
//! # Example
//!
//! ```rust,no_run
//! use altimate_core::equivalence::engine::check_equivalence;
//! use altimate_core::SchemaDefinition;
//!
//! # async fn example() {
//! let schema = SchemaDefinition::from_yaml_file("schema.yaml").unwrap();
//!
//! // Check if two queries are equivalent
//! let result = check_equivalence(
//!     "SELECT id FROM users WHERE age > 25",
//!     "SELECT id FROM users WHERE age > 25",
//!     &schema,
//! ).await;
//! assert!(result.equivalent);
//! # }
//! ```

pub mod engine;
pub mod types;
