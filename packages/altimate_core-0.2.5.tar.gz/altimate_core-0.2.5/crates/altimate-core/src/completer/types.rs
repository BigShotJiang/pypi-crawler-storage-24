//! Types for SQL completion.

use serde::{Deserialize, Serialize};

/// A single completion suggestion.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompletionItem {
    /// The text to insert
    pub label: String,
    /// Kind of completion
    pub kind: CompletionKind,
    /// Human-readable detail
    pub detail: String,
    /// Optional documentation
    #[serde(skip_serializing_if = "Option::is_none")]
    pub documentation: Option<String>,
    /// Relevance score (0.0 - 1.0)
    pub score: f64,
}

/// Kind of completion item.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CompletionKind {
    Table,
    Column,
    Function,
    Keyword,
    Alias,
    JoinCondition,
    Schema,
}

/// Result of SQL completion.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompletionResult {
    /// Cursor position in the SQL
    pub cursor_offset: usize,
    /// Context detected at cursor
    pub context: String,
    /// Completion suggestions sorted by relevance
    pub items: Vec<CompletionItem>,
}
