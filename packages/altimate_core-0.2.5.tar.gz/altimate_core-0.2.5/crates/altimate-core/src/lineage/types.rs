//! Types for lineage tracking.

use serde::{Deserialize, Serialize};

/// A column reference in the lineage graph.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ColumnRef {
    pub table: String,
    pub column: String,
}

/// A lineage edge: source column → target column.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LineageEdge {
    pub source: ColumnRef,
    pub target: ColumnRef,
    /// How the data flows: "direct", "transform", "aggregate", "filter"
    pub transform_type: String,
}

/// Lineage for a single query.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueryLineage {
    /// Tables read by this query
    pub source_tables: Vec<String>,
    /// Tables written by this query (for INSERT/CREATE)
    pub target_tables: Vec<String>,
    /// Column-level lineage edges
    pub edges: Vec<LineageEdge>,
    /// Columns in the output
    pub output_columns: Vec<String>,
}

/// Multi-query lineage result.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LineageResult {
    /// Per-query lineage
    pub queries: Vec<QueryLineage>,
    /// Table dependency order (topological sort)
    pub dependency_order: Vec<String>,
    /// Impact analysis: if a source column changes, what outputs are affected
    pub impact_map: Vec<ImpactEntry>,
}

/// Impact entry: changing a source affects these targets.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImpactEntry {
    pub source: ColumnRef,
    pub affected: Vec<ColumnRef>,
}
