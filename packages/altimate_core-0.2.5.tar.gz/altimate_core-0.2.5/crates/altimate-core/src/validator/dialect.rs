//! Multi-dialect SQL support.
//!
//! Maps altimate-core's SqlDialect enum to DataFusion/sqlparser dialect implementations.
//! This allows validating Snowflake, Postgres, BigQuery, etc. specific syntax.
//!
//! Note: DataFusion's sqlparser only has a subset of dialects. For dialects not
//! natively supported, we fall back to GenericDialect. The `polyglot` module
//! provides dialect-aware pre-validation for all 32 dialects.

use crate::schema::types::SqlDialect;
use datafusion::sql::sqlparser::dialect::{
    BigQueryDialect, DuckDbDialect, GenericDialect, HiveDialect, MySqlDialect, PostgreSqlDialect,
    RedshiftSqlDialect, SQLiteDialect, SnowflakeDialect,
};

/// Get the sqlparser dialect implementation for a given SqlDialect.
///
/// Returns a boxed trait object that can be passed to the parser.
/// Dialects not natively supported by sqlparser fall back to GenericDialect.
pub fn get_parser_dialect(
    dialect: SqlDialect,
) -> Box<dyn datafusion::sql::sqlparser::dialect::Dialect> {
    match dialect {
        SqlDialect::Generic | SqlDialect::DataFusion => Box::new(GenericDialect {}),
        SqlDialect::Snowflake => Box::new(SnowflakeDialect),
        SqlDialect::Postgres | SqlDialect::CockroachDB | SqlDialect::RisingWave => {
            Box::new(PostgreSqlDialect {})
        }
        SqlDialect::BigQuery => Box::new(BigQueryDialect),
        SqlDialect::DuckDB => Box::new(DuckDbDialect {}),
        SqlDialect::MySQL
        | SqlDialect::SingleStore
        | SqlDialect::TiDB
        | SqlDialect::Doris
        | SqlDialect::StarRocks => Box::new(MySqlDialect {}),
        SqlDialect::Hive | SqlDialect::Spark => Box::new(HiveDialect {}),
        SqlDialect::SQLite => Box::new(SQLiteDialect {}),
        SqlDialect::Redshift => Box::new(RedshiftSqlDialect {}),
        // Dialects without a native sqlparser implementation use GenericDialect
        SqlDialect::Databricks
        | SqlDialect::Athena
        | SqlDialect::ClickHouse
        | SqlDialect::Dremio
        | SqlDialect::Drill
        | SqlDialect::Druid
        | SqlDialect::Dune
        | SqlDialect::Exasol
        | SqlDialect::Fabric
        | SqlDialect::Materialize
        | SqlDialect::Oracle
        | SqlDialect::Presto
        | SqlDialect::Solr
        | SqlDialect::Tableau
        | SqlDialect::Teradata
        | SqlDialect::Trino
        | SqlDialect::TSQL => Box::new(GenericDialect {}),
    }
}
