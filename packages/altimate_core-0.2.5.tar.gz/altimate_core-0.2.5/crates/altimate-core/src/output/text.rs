//! Human-readable text output formatter for terminal display.

use crate::errors::types::{ValidationError, ValidationResult};

/// Format a ValidationResult as colored terminal text.
///
/// Uses ANSI color codes for a nice terminal experience.
/// Falls back to plain text if colors are disabled.
pub fn format_text(result: &ValidationResult) -> String {
    let mut output = String::new();

    if result.valid {
        output.push_str("✓ Query is valid\n");
        return output;
    }

    for error in &result.errors {
        output.push_str(&format_error(error));
        output.push('\n');
    }

    let error_count = result.errors.len();
    let warning_count = result.warnings.len();
    let error_plural = if error_count == 1 { "" } else { "s" };
    let warning_plural = if warning_count == 1 { "" } else { "s" };
    output.push_str(&format!(
        "\nFound {error_count} error{error_plural}, {warning_count} warning{warning_plural}.\n",
    ));

    output
}

/// Format a single validation error.
fn format_error(error: &ValidationError) -> String {
    let mut output = String::new();

    // Error line
    let location = error
        .location
        .as_ref()
        .map(|loc| format!(" [line {}, col {}]", loc.line, loc.column))
        .unwrap_or_default();

    output.push_str(&format!(
        "✗ Error {}: {}{}",
        error.code, error.message, location
    ));

    // Suggestions
    for suggestion in &error.suggestions {
        output.push_str(&format!(
            "\n  → {} (confidence: {:.2})",
            suggestion.message, suggestion.confidence
        ));
    }

    output
}
