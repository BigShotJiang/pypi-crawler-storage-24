//! SQL anti-pattern linter.
//!
//! Detects common SQL anti-patterns beyond basic validation:
//! SELECT *, missing WHERE on UPDATE/DELETE, cartesian products, etc.

pub mod engine;
pub mod rules;
pub mod types;

pub use engine::lint;
pub use types::*;
