//! Query observability and evaluation.
//!
//! Provides structured evaluation of SQL queries across multiple quality
//! dimensions (syntax, style, safety, complexity), producing scorecards,
//! letter grades, and observability events compatible with platforms like
//! Langfuse and LangSmith.

pub mod engine;
pub mod types;
