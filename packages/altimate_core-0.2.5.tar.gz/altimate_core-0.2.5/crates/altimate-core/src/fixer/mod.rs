//! SQL auto-fixer module.
//!
//! Takes broken SQL queries and rewrites them to fix validation errors.
//! Uses fuzzy-matched suggestions from the validator to apply corrections
//! iteratively until the query passes validation.

pub mod engine;
pub mod rewriter;
pub mod strategies;
pub mod types;
