//! Schema-free metadata extraction from SQL using polyglot-sql.
//!
//! Extracts tables, columns, functions, and structural signals from SQL
//! without requiring a schema definition. This enables the "millions of tables"
//! use case where you want to know what a query references before loading schemas.
//!
//! Note: polyglot-sql's AST traversal functions use deep recursion that can overflow
//! the default 8MB thread stack. All extraction functions run on a thread with a
//! larger stack (32MB) to avoid this.

use super::dialect_map::to_polyglot_dialect;
use super::types::{ExtractResult, StatementInfo, StatementTypesResult};
use crate::schema::types::SqlDialect;
use polyglot_sql::ast_transforms;
use polyglot_sql::expressions::Expression;

/// Stack size for AST traversal threads (32MB).
/// polyglot-sql's recursive AST walkers can overflow the default 8MB stack.
const AST_THREAD_STACK_SIZE: usize = 32 * 1024 * 1024;

/// Extract full metadata from a SQL query: tables, columns, functions, and structural signals.
///
/// This does NOT require a schema — it parses the SQL and walks the AST to extract
/// all referenced identifiers and structural properties.
pub fn extract_metadata(sql: &str, dialect: SqlDialect) -> Result<ExtractResult, String> {
    let sql = sql.to_string();
    std::thread::Builder::new()
        .stack_size(AST_THREAD_STACK_SIZE)
        .spawn(move || extract_metadata_inner(&sql, dialect))
        .map_err(|e| format!("failed to spawn extraction thread: {e}"))?
        .join()
        .map_err(|_| "extraction thread panicked".to_string())?
}

/// Inner implementation of extract_metadata, runs on a thread with a larger stack.
fn extract_metadata_inner(sql: &str, dialect: SqlDialect) -> Result<ExtractResult, String> {
    let pg_dialect = to_polyglot_dialect(dialect);
    let expressions = polyglot_sql::parse(sql, pg_dialect).map_err(|e| e.to_string())?;

    let mut all_tables = Vec::new();
    let mut all_columns = Vec::new();
    let mut all_functions = Vec::new();
    let mut has_subqueries = false;
    let mut has_aggregation = false;
    let mut has_window_functions = false;
    let mut total_nodes = 0;

    for expr in &expressions {
        let tables = ast_transforms::get_table_names(expr);
        let columns = ast_transforms::get_column_names(expr);
        let functions = ast_transforms::get_functions(expr);
        let subqueries = ast_transforms::get_subqueries(expr);
        let agg_functions = ast_transforms::get_aggregate_functions(expr);
        let window_functions = ast_transforms::get_window_functions(expr);
        let nodes = ast_transforms::node_count(expr);

        all_tables.extend(tables);
        all_columns.extend(columns);
        all_functions.extend(functions.iter().map(|f| format!("{f:?}")));
        has_subqueries = has_subqueries || !subqueries.is_empty();
        has_aggregation = has_aggregation || !agg_functions.is_empty();
        has_window_functions = has_window_functions || !window_functions.is_empty();
        total_nodes += nodes;
    }

    // Deduplicate
    all_tables.sort();
    all_tables.dedup();
    all_columns.sort();
    all_columns.dedup();
    all_functions.sort();
    all_functions.dedup();

    Ok(ExtractResult {
        tables: all_tables,
        columns: all_columns,
        functions: all_functions,
        has_subqueries,
        has_aggregation,
        has_window_functions,
        node_count: total_nodes,
    })
}

/// Extract only table names from a SQL query (no schema required).
pub fn extract_tables(sql: &str, dialect: SqlDialect) -> Result<Vec<String>, String> {
    let sql = sql.to_string();
    std::thread::Builder::new()
        .stack_size(AST_THREAD_STACK_SIZE)
        .spawn(move || extract_tables_inner(&sql, dialect))
        .map_err(|e| format!("failed to spawn extraction thread: {e}"))?
        .join()
        .map_err(|_| "extraction thread panicked".to_string())?
}

/// Inner implementation of extract_tables.
fn extract_tables_inner(sql: &str, dialect: SqlDialect) -> Result<Vec<String>, String> {
    let pg_dialect = to_polyglot_dialect(dialect);
    let expressions = polyglot_sql::parse(sql, pg_dialect).map_err(|e| e.to_string())?;

    let mut tables = Vec::new();
    for expr in &expressions {
        tables.extend(ast_transforms::get_table_names(expr));
    }
    tables.sort();
    tables.dedup();
    Ok(tables)
}

/// Extract the output column names from a SQL SELECT statement.
///
/// Returns the alias or column name for each item in the SELECT list, preserving
/// order. Unlike [`extract_columns`] which returns all *referenced* columns across
/// the entire query, this returns only the *output projection* names.
///
/// Errors if the query contains `SELECT *` or expressions without a deterministic
/// output name (e.g. bare literals or function calls without an alias).
pub fn extract_output_columns(sql: &str, dialect: SqlDialect) -> Result<Vec<String>, String> {
    let sql = sql.to_string();
    std::thread::Builder::new()
        .stack_size(AST_THREAD_STACK_SIZE)
        .spawn(move || extract_output_columns_inner(&sql, dialect))
        .map_err(|e| format!("failed to spawn extraction thread: {e}"))?
        .join()
        .map_err(|_| "extraction thread panicked".to_string())?
}

/// Inner implementation of extract_output_columns.
fn extract_output_columns_inner(sql: &str, dialect: SqlDialect) -> Result<Vec<String>, String> {
    let pg_dialect = to_polyglot_dialect(dialect);
    let expressions = polyglot_sql::parse(sql, pg_dialect).map_err(|e| e.to_string())?;

    let select = expressions
        .iter()
        .find_map(|expr| expr.as_select())
        .ok_or_else(|| "no SELECT statement found in SQL".to_string())?;

    let mut columns = Vec::new();
    for expr in &select.expressions {
        match expr {
            Expression::Alias(alias) => {
                columns.push(alias.alias.name.clone());
            }
            Expression::Column(col) => {
                columns.push(col.name.name.clone());
            }
            Expression::Identifier(id) => {
                columns.push(id.name.clone());
            }
            Expression::Star(_) => {
                return Err(format!(
                    "unable to extract output columns due to star: {expr}"
                ));
            }
            other => {
                return Err(format!(
                    "unable to determine output column name for expression: {other}"
                ));
            }
        }
    }

    Ok(columns)
}

/// Classify the statement type of each SQL statement using full AST parsing.
///
/// Unlike the simple first-keyword extraction used in the safety module, this
/// function parses a real AST via polyglot-sql and matches on the `Expression`
/// variant, correctly handling CTEs (`WITH … SELECT` → `SELECT`), set operations
/// (`UNION`, `INTERSECT`, `EXCEPT`), and all DDL / DML / DCL / TCL forms.
pub fn get_statement_types(sql: &str, dialect: SqlDialect) -> Result<StatementTypesResult, String> {
    let sql = sql.to_string();
    std::thread::Builder::new()
        .stack_size(AST_THREAD_STACK_SIZE)
        .spawn(move || get_statement_types_inner(&sql, dialect))
        .map_err(|e| format!("failed to spawn extraction thread: {e}"))?
        .join()
        .map_err(|_| "extraction thread panicked".to_string())?
}

/// Inner implementation — runs on a thread with a 32 MB stack.
fn get_statement_types_inner(
    sql: &str,
    dialect: SqlDialect,
) -> Result<StatementTypesResult, String> {
    let pg_dialect = to_polyglot_dialect(dialect);
    let expressions = polyglot_sql::parse(sql, pg_dialect).map_err(|e| e.to_string())?;

    let statements: Vec<StatementInfo> = expressions
        .iter()
        .filter(|e| e.is_statement())
        .map(classify_expression)
        .collect();

    let mut types: Vec<String> = statements
        .iter()
        .map(|s| s.statement_type.clone())
        .collect();
    types.sort();
    types.dedup();

    let mut categories: Vec<String> = statements.iter().map(|s| s.category.clone()).collect();
    categories.sort();
    categories.dedup();

    let statement_count = statements.len();
    Ok(StatementTypesResult {
        statements,
        statement_count,
        types,
        categories,
    })
}

/// Classify a raw `Command` expression by inspecting its text.
///
/// `Command` is polyglot-sql's fallback for statements it couldn't fully parse
/// into a typed AST node (e.g. bare "COMMIT", "ROLLBACK", dialect-specific
/// commands). We inspect the first token so destructive statements are never
/// silently dropped to UNKNOWN.
fn classify_command(text: &str) -> (&'static str, &'static str) {
    let keyword = text.split_whitespace().next().unwrap_or("").to_uppercase();
    match keyword.as_str() {
        "SELECT" => ("SELECT", "query"),
        // "WITH" is intentionally NOT mapped to query — WITH can wrap destructive
        // DML (e.g. Postgres `WITH cte AS (DELETE ...) SELECT ...`). If polyglot-sql
        // falls back to Command for a WITH statement, treat it as UNKNOWN/other
        // so callers block it rather than passing it as safe.
        "INSERT" => ("INSERT", "dml"),
        "UPDATE" => ("UPDATE", "dml"),
        "DELETE" => ("DELETE", "dml"),
        "MERGE" => ("MERGE", "dml"),
        "COPY" => ("COPY", "dml"),
        "PUT" => ("PUT", "dml"),
        "CREATE" => ("CREATE", "ddl"),
        "DROP" => ("DROP", "ddl"),
        "ALTER" => ("ALTER", "ddl"),
        "TRUNCATE" => ("TRUNCATE", "ddl"),
        "GRANT" => ("GRANT", "dcl"),
        "REVOKE" => ("REVOKE", "dcl"),
        "BEGIN" | "START" => ("BEGIN", "tcl"),
        "COMMIT" => ("COMMIT", "tcl"),
        "ROLLBACK" => ("ROLLBACK", "tcl"),
        _ => ("UNKNOWN", "other"),
    }
}

/// Map an `Expression` variant to a human-readable type and broad category.
fn classify_expression(expr: &Expression) -> StatementInfo {
    let (statement_type, category) = match expr {
        // ── Queries ──────────────────────────────────────────────────────
        // UNION / INTERSECT / EXCEPT / VALUES / subqueries are all read-only
        // queries — callers don't need to distinguish them from SELECT.
        Expression::Select(_)
        | Expression::Union(_)
        | Expression::Intersect(_)
        | Expression::Except(_)
        | Expression::Subquery(_)
        | Expression::Values(_)
        | Expression::PipeOperator(_) => ("SELECT", "query"),

        // ── DML ──────────────────────────────────────────────────────────
        Expression::Insert(_) => ("INSERT", "dml"),
        Expression::Update(_) => ("UPDATE", "dml"),
        Expression::Delete(_) => ("DELETE", "dml"),
        Expression::Merge(_) => ("MERGE", "dml"),
        Expression::Copy(_) => ("COPY", "dml"),
        Expression::Put(_) => ("PUT", "dml"),

        // ── DDL ──────────────────────────────────────────────────────────
        Expression::CreateTable(_) => ("CREATE TABLE", "ddl"),
        Expression::DropTable(_) => ("DROP TABLE", "ddl"),
        Expression::AlterTable(_) => ("ALTER TABLE", "ddl"),
        Expression::CreateIndex(_) => ("CREATE INDEX", "ddl"),
        Expression::DropIndex(_) => ("DROP INDEX", "ddl"),
        Expression::AlterIndex(_) => ("ALTER INDEX", "ddl"),
        Expression::CreateView(_) => ("CREATE VIEW", "ddl"),
        Expression::DropView(_) => ("DROP VIEW", "ddl"),
        Expression::AlterView(_) => ("ALTER VIEW", "ddl"),
        Expression::Truncate(_) | Expression::TruncateTable(_) => ("TRUNCATE", "ddl"),
        Expression::CreateSchema(_) => ("CREATE SCHEMA", "ddl"),
        Expression::DropSchema(_) | Expression::DropNamespace(_) => ("DROP SCHEMA", "ddl"),
        Expression::CreateDatabase(_) => ("CREATE DATABASE", "ddl"),
        Expression::DropDatabase(_) => ("DROP DATABASE", "ddl"),
        Expression::CreateFunction(_) => ("CREATE FUNCTION", "ddl"),
        Expression::DropFunction(_) => ("DROP FUNCTION", "ddl"),
        Expression::CreateProcedure(_) => ("CREATE PROCEDURE", "ddl"),
        Expression::DropProcedure(_) => ("DROP PROCEDURE", "ddl"),
        Expression::CreateSequence(_) => ("CREATE SEQUENCE", "ddl"),
        Expression::DropSequence(_) => ("DROP SEQUENCE", "ddl"),
        Expression::AlterSequence(_) => ("ALTER SEQUENCE", "ddl"),
        Expression::CreateTrigger(_) => ("CREATE TRIGGER", "ddl"),
        Expression::DropTrigger(_) => ("DROP TRIGGER", "ddl"),
        Expression::CreateType(_) => ("CREATE TYPE", "ddl"),
        Expression::DropType(_) => ("DROP TYPE", "ddl"),

        // ── DCL ──────────────────────────────────────────────────────────
        Expression::Grant(_) => ("GRANT", "dcl"),
        Expression::Revoke(_) => ("REVOKE", "dcl"),

        // ── TCL ──────────────────────────────────────────────────────────
        Expression::Transaction(_) => ("BEGIN", "tcl"),
        Expression::Commit(_) => ("COMMIT", "tcl"),
        Expression::Rollback(_) => ("ROLLBACK", "tcl"),

        // ── Session / other ───────────────────────────────────────────────
        Expression::Use(_) => ("USE", "other"),
        Expression::Set(_) | Expression::SetStatement(_) => ("SET", "other"),
        Expression::Show(_) => ("SHOW", "other"),
        Expression::Describe(_) => ("DESCRIBE", "other"),
        Expression::Pragma(_) => ("PRAGMA", "other"),
        Expression::Cache(_) => ("CACHE", "other"),
        Expression::Uncache(_) => ("UNCACHE", "other"),
        Expression::LoadData(_) => ("LOAD DATA", "other"),
        Expression::Kill(_) => ("KILL", "other"),
        Expression::Comment(_) => ("COMMENT", "other"),

        // Command is a parser fallback for raw/unparsed statements (e.g. "COMMIT", "ROLLBACK").
        // Inspect the raw text so destructive keywords are never silently dropped to UNKNOWN.
        // Note: even UNKNOWN/other is treated as unsafe by callers (only "query" is safe),
        // but explicit classification gives better diagnostics.
        Expression::Command(cmd) => classify_command(&cmd.this),

        _ => ("UNKNOWN", "other"),
    };

    StatementInfo {
        statement_type: statement_type.to_string(),
        category: category.to_string(),
    }
}

/// Extract only column names from a SQL query (no schema required).
pub fn extract_columns(sql: &str, dialect: SqlDialect) -> Result<Vec<String>, String> {
    let sql = sql.to_string();
    std::thread::Builder::new()
        .stack_size(AST_THREAD_STACK_SIZE)
        .spawn(move || extract_columns_inner(&sql, dialect))
        .map_err(|e| format!("failed to spawn extraction thread: {e}"))?
        .join()
        .map_err(|_| "extraction thread panicked".to_string())?
}

/// Inner implementation of extract_columns.
fn extract_columns_inner(sql: &str, dialect: SqlDialect) -> Result<Vec<String>, String> {
    let pg_dialect = to_polyglot_dialect(dialect);
    let expressions = polyglot_sql::parse(sql, pg_dialect).map_err(|e| e.to_string())?;

    let mut columns = Vec::new();
    for expr in &expressions {
        columns.extend(ast_transforms::get_column_names(expr));
    }
    columns.sort();
    columns.dedup();
    Ok(columns)
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn stypes(sql: &str) -> StatementTypesResult {
        get_statement_types(sql, SqlDialect::Generic).expect("parse failed")
    }

    fn stypes_dialect(sql: &str, dialect: SqlDialect) -> StatementTypesResult {
        get_statement_types(sql, dialect).expect("parse failed")
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    #[test]
    fn test_select() {
        let r = stypes("SELECT id, name FROM users WHERE id = 1");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "SELECT");
        assert_eq!(r.statements[0].category, "query");
    }

    #[test]
    fn test_cte_classified_as_select() {
        // WITH … SELECT must resolve to SELECT, not WITH or UNKNOWN
        let r = stypes("WITH cte AS (SELECT 1 AS n) SELECT n FROM cte");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "SELECT");
        assert_eq!(r.statements[0].category, "query");
    }

    #[test]
    fn test_union() {
        // UNION is a read-only query — same as SELECT from a safety perspective
        let r = stypes("SELECT 1 UNION SELECT 2");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "SELECT");
        assert_eq!(r.statements[0].category, "query");
    }

    #[test]
    fn test_intersect() {
        let r = stypes("SELECT 1 INTERSECT SELECT 1");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "SELECT");
        assert_eq!(r.statements[0].category, "query");
    }

    #[test]
    fn test_except() {
        let r = stypes("SELECT 1 EXCEPT SELECT 2");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "SELECT");
        assert_eq!(r.statements[0].category, "query");
    }

    // ── DML ───────────────────────────────────────────────────────────────────

    #[test]
    fn test_insert() {
        let r = stypes("INSERT INTO users (id, name) VALUES (1, 'Alice')");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "INSERT");
        assert_eq!(r.statements[0].category, "dml");
    }

    #[test]
    fn test_update() {
        let r = stypes("UPDATE users SET name = 'Bob' WHERE id = 1");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "UPDATE");
        assert_eq!(r.statements[0].category, "dml");
    }

    #[test]
    fn test_delete() {
        let r = stypes("DELETE FROM users WHERE id = 1");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "DELETE");
        assert_eq!(r.statements[0].category, "dml");
    }

    #[test]
    fn test_merge() {
        let r = stypes(
            "MERGE INTO target t \
             USING source s ON t.id = s.id \
             WHEN MATCHED THEN UPDATE SET t.name = s.name \
             WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name)",
        );
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "MERGE");
        assert_eq!(r.statements[0].category, "dml");
    }

    // ── DDL ───────────────────────────────────────────────────────────────────

    #[test]
    fn test_create_table() {
        let r = stypes("CREATE TABLE orders (id INT, total DECIMAL(10,2))");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "CREATE TABLE");
        assert_eq!(r.statements[0].category, "ddl");
    }

    #[test]
    fn test_drop_table() {
        let r = stypes("DROP TABLE orders");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "DROP TABLE");
        assert_eq!(r.statements[0].category, "ddl");
    }

    #[test]
    fn test_alter_table() {
        let r = stypes("ALTER TABLE users ADD COLUMN email VARCHAR(255)");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "ALTER TABLE");
        assert_eq!(r.statements[0].category, "ddl");
    }

    #[test]
    fn test_create_view() {
        let r = stypes("CREATE VIEW active_users AS SELECT * FROM users WHERE active = TRUE");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "CREATE VIEW");
        assert_eq!(r.statements[0].category, "ddl");
    }

    #[test]
    fn test_drop_view() {
        let r = stypes("DROP VIEW active_users");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "DROP VIEW");
        assert_eq!(r.statements[0].category, "ddl");
    }

    #[test]
    fn test_create_index() {
        let r = stypes("CREATE INDEX idx_users_email ON users (email)");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "CREATE INDEX");
        assert_eq!(r.statements[0].category, "ddl");
    }

    #[test]
    fn test_truncate() {
        let r = stypes("TRUNCATE TABLE users");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "TRUNCATE");
        assert_eq!(r.statements[0].category, "ddl");
    }

    // ── DCL ───────────────────────────────────────────────────────────────────

    #[test]
    fn test_grant() {
        let r = stypes("GRANT SELECT ON users TO analyst");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "GRANT");
        assert_eq!(r.statements[0].category, "dcl");
    }

    #[test]
    fn test_revoke() {
        let r = stypes("REVOKE SELECT ON users FROM analyst");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "REVOKE");
        assert_eq!(r.statements[0].category, "dcl");
    }

    // ── TCL ───────────────────────────────────────────────────────────────────

    #[test]
    fn test_commit() {
        let r = stypes("COMMIT");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "COMMIT");
        assert_eq!(r.statements[0].category, "tcl");
    }

    #[test]
    fn test_rollback() {
        let r = stypes("ROLLBACK");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "ROLLBACK");
        assert_eq!(r.statements[0].category, "tcl");
    }

    // ── Multi-statement ───────────────────────────────────────────────────────

    #[test]
    fn test_multi_statement() {
        let r = stypes("CREATE TABLE t (id INT); INSERT INTO t VALUES (1); SELECT * FROM t");
        assert_eq!(r.statement_count, 3);
        assert_eq!(r.statements[0].statement_type, "CREATE TABLE");
        assert_eq!(r.statements[1].statement_type, "INSERT");
        assert_eq!(r.statements[2].statement_type, "SELECT");
    }

    #[test]
    fn test_multi_select_union_vs_two_selects() {
        // Two separate SELECT statements separated by semicolon
        let r = stypes("SELECT 1; SELECT 2");
        assert_eq!(r.statement_count, 2);
        assert!(r.statements.iter().all(|s| s.statement_type == "SELECT"));

        // UNION is a single read-only statement — same type as SELECT
        let r2 = stypes("SELECT 1 UNION SELECT 2");
        assert_eq!(r2.statement_count, 1);
        assert_eq!(r2.statements[0].statement_type, "SELECT");
    }

    // ── Dialect-specific ──────────────────────────────────────────────────────

    #[test]
    fn test_snowflake_cte() {
        let r = stypes_dialect(
            "WITH base AS (SELECT * FROM raw.events) SELECT COUNT(*) FROM base",
            SqlDialect::Snowflake,
        );
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "SELECT");
    }

    #[test]
    fn test_insert_into_select() {
        // INSERT … SELECT should be classified as INSERT, not SELECT
        let r = stypes("INSERT INTO summary SELECT id, COUNT(*) FROM events GROUP BY id");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "INSERT");
        assert_eq!(r.statements[0].category, "dml");
    }

    #[test]
    fn test_create_table_as_select() {
        let r =
            stypes("CREATE TABLE archive AS SELECT * FROM users WHERE created_at < '2020-01-01'");
        assert_eq!(r.statement_count, 1);
        assert_eq!(r.statements[0].statement_type, "CREATE TABLE");
        assert_eq!(r.statements[0].category, "ddl");
    }

    // ── Destructive action detection ─────────────────────────────────────────
    // These tests validate the primary use-case: blocking dangerous SQL before
    // it reaches a database.

    fn is_destructive(sql: &str) -> bool {
        let r = stypes(sql);
        r.statements.iter().any(|s| {
            matches!(
                s.statement_type.as_str(),
                "DELETE"
                    | "DROP TABLE"
                    | "DROP VIEW"
                    | "DROP SCHEMA"
                    | "DROP DATABASE"
                    | "DROP FUNCTION"
                    | "DROP PROCEDURE"
                    | "TRUNCATE"
                    | "UPDATE"
                    | "MERGE"
                    | "INSERT"
            )
        })
    }

    #[test]
    fn test_detects_delete() {
        assert!(is_destructive("DELETE FROM users WHERE id = 1"));
    }

    #[test]
    fn test_detects_delete_without_where() {
        assert!(is_destructive("DELETE FROM users"));
    }

    #[test]
    fn test_detects_update() {
        assert!(is_destructive(
            "UPDATE users SET active = FALSE WHERE id = 99"
        ));
    }

    #[test]
    fn test_detects_update_without_where() {
        assert!(is_destructive("UPDATE users SET active = FALSE"));
    }

    #[test]
    fn test_detects_insert() {
        assert!(is_destructive(
            "INSERT INTO users (id, name) VALUES (1, 'Eve')"
        ));
    }

    #[test]
    fn test_detects_insert_select() {
        assert!(is_destructive(
            "INSERT INTO archive SELECT * FROM users WHERE created_at < '2020-01-01'"
        ));
    }

    #[test]
    fn test_detects_merge() {
        assert!(is_destructive(
            "MERGE INTO target t USING source s ON t.id = s.id \
             WHEN MATCHED THEN UPDATE SET t.name = s.name \
             WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name)"
        ));
    }

    #[test]
    fn test_detects_truncate() {
        assert!(is_destructive("TRUNCATE TABLE events"));
    }

    #[test]
    fn test_detects_drop_table() {
        assert!(is_destructive("DROP TABLE IF EXISTS temp_data"));
    }

    #[test]
    fn test_detects_drop_view() {
        assert!(is_destructive("DROP VIEW active_users"));
    }

    #[test]
    fn test_detects_destructive_hidden_in_multi_statement() {
        // A safe-looking SELECT followed by a hidden DELETE must be caught
        assert!(is_destructive(
            "SELECT COUNT(*) FROM users; DELETE FROM users WHERE active = FALSE"
        ));
    }

    #[test]
    fn test_detects_destructive_cte_wrapping_delete() {
        // Some dialects allow CTEs with DML; the DELETE must still be detected
        // (polyglot may or may not parse this depending on dialect, so we don't
        //  assert is_destructive — we only assert it doesn't panic)
        let _ = get_statement_types(
            "WITH deleted AS (DELETE FROM users WHERE id = 1 RETURNING id) SELECT * FROM deleted",
            SqlDialect::Postgres,
        );
    }

    #[test]
    fn test_safe_select_not_flagged_as_destructive() {
        assert!(!is_destructive(
            "SELECT id, name FROM users WHERE active = TRUE"
        ));
    }

    #[test]
    fn test_safe_cte_select_not_flagged_as_destructive() {
        assert!(!is_destructive(
            "WITH active AS (SELECT * FROM users WHERE active = TRUE) SELECT COUNT(*) FROM active"
        ));
    }

    #[test]
    fn test_safe_create_view_not_flagged_as_destructive() {
        // CREATE VIEW is DDL but not destructive (additive)
        assert!(!is_destructive(
            "CREATE VIEW summary AS SELECT COUNT(*) FROM users"
        ));
    }

    #[test]
    fn test_safe_read_only_union_not_flagged() {
        assert!(!is_destructive("SELECT 1 AS n UNION ALL SELECT 2"));
    }

    // ── Error cases ───────────────────────────────────────────────────────────

    #[test]
    fn test_empty_string_returns_zero_statements() {
        let r = stypes("");
        assert_eq!(r.statement_count, 0);
        assert!(r.statements.is_empty());
    }

    #[test]
    fn test_whitespace_only_returns_zero_statements() {
        let r = stypes("   \n\t  ");
        assert_eq!(r.statement_count, 0);
        assert!(r.statements.is_empty());
    }

    #[test]
    fn test_invalid_sql_returns_error() {
        let result = get_statement_types("THIS IS NOT SQL !!!@@@", SqlDialect::Generic);
        // Parser should either return an error OR parse with UNKNOWN statements
        // We only assert it doesn't panic
        let _ = result;
    }

    #[test]
    fn test_comment_only_returns_zero_statements() {
        let r = stypes("-- just a comment\n/* another comment */");
        assert_eq!(r.statement_count, 0);
    }
}
