//! Types for query rewriting.

use serde::{Deserialize, Serialize};

/// A suggested query rewrite.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RewriteSuggestion {
    /// Rule that triggered this suggestion
    pub rule: String,
    /// Human-readable explanation
    pub explanation: String,
    /// The rewritten SQL
    pub rewritten_sql: String,
    /// Estimated improvement (e.g., "reduce full table scan")
    pub improvement: String,
    /// Confidence level (0.0 - 1.0)
    pub confidence: f64,
}

/// Result of query rewriting.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RewriteResult {
    /// Original SQL
    pub original_sql: String,
    /// Suggested rewrites (may be empty if no improvements found)
    pub suggestions: Vec<RewriteSuggestion>,
    /// Index suggestions
    pub index_suggestions: Vec<IndexSuggestion>,
}

/// A suggested index to improve query performance.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IndexSuggestion {
    /// Table name
    pub table: String,
    /// Columns to index
    pub columns: Vec<String>,
    /// Why this index would help
    pub reason: String,
    /// CREATE INDEX DDL
    pub ddl: String,
}
