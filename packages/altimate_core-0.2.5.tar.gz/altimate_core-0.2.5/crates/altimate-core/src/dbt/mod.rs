//! dbt integration.
//!
//! Parses dbt project files, extracts SQL from models,
//! and validates against schemas.

pub mod parser;
pub mod types;

pub use parser::parse_dbt_project;
pub use types::*;
