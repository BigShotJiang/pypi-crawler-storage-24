//! Shared tokio runtime for async altimate-core calls.

use std::sync::OnceLock;
use tokio::runtime::Runtime;

static RT: OnceLock<Runtime> = OnceLock::new();

/// Returns a reference to the lazily-initialized tokio runtime.
pub fn runtime() -> &'static Runtime {
    RT.get_or_init(|| Runtime::new().expect("failed to create tokio runtime"))
}
