//! Polyglot bindings: transpile, format_sql, extract_metadata, compare_queries.

use pyo3::prelude::*;

/// Transpile SQL from one dialect to another.
#[pyfunction]
pub fn transpile(py: Python<'_>, sql: &str, source: &str, target: &str) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let s = crate::convert::parse_dialect(source)?;
    let t = crate::convert::parse_dialect(target)?;
    let result = altimate_core::polyglot::transpile(sql, s, t);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("transpile", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "transpile",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("source", serde_json::json!(source)),
                    ("target", serde_json::json!(target)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Format / pretty-print SQL for a dialect.
#[pyfunction]
#[pyo3(signature = (sql, dialect="generic"))]
pub fn format_sql(py: Python<'_>, sql: &str, dialect: &str) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let d = crate::convert::parse_dialect(dialect)?;
    let result = altimate_core::polyglot::format_sql(sql, d);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit_with_dialect("formatSql", dialect, start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "formatSql",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("dialect", serde_json::json!(dialect)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Extract metadata (tables, columns, functions) from SQL.
#[pyfunction]
#[pyo3(signature = (sql, dialect="generic"))]
pub fn extract_metadata(py: Python<'_>, sql: &str, dialect: &str) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let d = crate::convert::parse_dialect(dialect)?;
    let result = altimate_core::polyglot::extract_metadata(sql, d).map_err(|e| {
        crate::sdk::report_failure_kv(
            "extractMetadata",
            &[
                ("sql", serde_json::json!(sql)),
                ("dialect", serde_json::json!(dialect)),
            ],
            start.elapsed().as_millis() as u64,
            &e,
        );
        pyo3::exceptions::PyRuntimeError::new_err(e)
    })?;
    crate::sdk::timed_emit_with_dialect("extractMetadata", dialect, start);
    crate::convert::to_py_result(py, &result)
}

/// Extract the output column names from a SQL SELECT list.
#[pyfunction]
#[pyo3(signature = (sql, dialect="generic"))]
pub fn extract_output_columns(py: Python<'_>, sql: &str, dialect: &str) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let d = crate::convert::parse_dialect(dialect)?;
    let result = altimate_core::polyglot::extract_output_columns(sql, d).map_err(|e| {
        crate::sdk::report_failure_kv(
            "extractOutputColumns",
            &[
                ("sql", serde_json::json!(sql)),
                ("dialect", serde_json::json!(dialect)),
            ],
            start.elapsed().as_millis() as u64,
            &e,
        );
        pyo3::exceptions::PyRuntimeError::new_err(e)
    })?;
    crate::sdk::timed_emit_with_dialect("extractOutputColumns", dialect, start);
    crate::convert::to_py_result(py, &result)
}

/// Compare two SQL queries structurally.
#[pyfunction]
#[pyo3(signature = (left_sql, right_sql, dialect="generic"))]
pub fn compare_queries(
    py: Python<'_>,
    left_sql: &str,
    right_sql: &str,
    dialect: &str,
) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let d = crate::convert::parse_dialect(dialect)?;
    let result = altimate_core::polyglot::compare_queries(left_sql, right_sql, d).map_err(|e| {
        crate::sdk::report_failure_kv(
            "compareQueries",
            &[
                ("left_sql", serde_json::json!(left_sql)),
                ("right_sql", serde_json::json!(right_sql)),
                ("dialect", serde_json::json!(dialect)),
            ],
            start.elapsed().as_millis() as u64,
            &e,
        );
        pyo3::exceptions::PyRuntimeError::new_err(e)
    })?;
    crate::sdk::timed_emit_with_dialect("compareQueries", dialect, start);
    crate::convert::to_py_result(py, &result)
}
