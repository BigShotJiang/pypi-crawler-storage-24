//! Python-specific SDK wrappers. All logic lives in `altimate_sdk` crate.
//! This module only adds #[pyfunction] bindings for init/reset/flush.

use pyo3::prelude::*;

// Re-export everything the other modules need.
pub use altimate_sdk::{
    check_credits as check_credits_inner, count_credit, emit_event, is_initialized,
    report_failure_kv, timed_emit, timed_emit_with_dialect,
};

/// Initialize the SDK with credentials. Called by Python `altimate_core.init()`.
#[pyfunction]
#[pyo3(signature = (api_key, tenant, backend_url, report_failures, telemetry=true))]
pub fn _init_sdk(
    api_key: String,
    tenant: String,
    backend_url: String,
    report_failures: bool,
    telemetry: bool,
) -> PyResult<()> {
    altimate_sdk::init(api_key, tenant, backend_url, report_failures, telemetry)
        .map_err(pyo3::exceptions::PyRuntimeError::new_err)
}

/// Reset SDK state. Exposed for test teardown only.
#[pyfunction]
pub fn _reset_sdk() -> PyResult<()> {
    altimate_sdk::reset().map_err(pyo3::exceptions::PyRuntimeError::new_err)
}

/// Best-effort flush: drain the queue, then shut down the worker thread.
#[pyfunction]
pub fn _flush_sdk() -> PyResult<()> {
    altimate_sdk::flush();
    Ok(())
}

/// Check if credits are available for the given dataset type.
pub fn check_credits(dataset_type: &str) -> PyResult<()> {
    check_credits_inner(dataset_type).map_err(pyo3::exceptions::PyRuntimeError::new_err)
}
