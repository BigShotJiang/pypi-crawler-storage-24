//! Safety bindings: lint, scan_sql, is_safe, PII, semantics, glossary.

use crate::schema::Schema;
use pyo3::prelude::*;

/// Lint SQL for anti-patterns (SELECT *, missing WHERE, etc.).
#[pyfunction]
pub fn lint(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::linter::lint(sql, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("lint", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "lint",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Scan SQL for injection threats (10 detection rules).
#[pyfunction]
pub fn scan_sql(py: Python<'_>, sql: &str) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let config = altimate_core::safety::SafetyConfig::default();
    let result = altimate_core::safety::scan_sql(sql, &config);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("scanSql", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "scanSql",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Quick boolean check: is this SQL safe from injection?
#[pyfunction]
pub fn is_safe(sql: &str) -> bool {
    let start = std::time::Instant::now();
    let result = altimate_core::safety::is_safe(sql);
    crate::sdk::timed_emit("isSafe", start);
    result
}

/// Classify schema columns for PII exposure.
#[pyfunction]
pub fn classify_pii(py: Python<'_>, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::pii::classify_schema(&schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("classifyPii", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "classifyPii",
                &[],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Check if a query accesses PII columns.
#[pyfunction]
pub fn check_query_pii(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::pii::check_query_pii(sql, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("checkQueryPii", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "checkQueryPii",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Run semantic validation rules (cartesian products, wrong JOINs, NULL misuse).
#[pyfunction]
pub fn check_semantics(py: Python<'_>, sql: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = crate::runtime::runtime().block_on(
        altimate_core::semantic::engine::check_semantics(sql, &schema.inner),
    );
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("checkSemantics", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "checkSemantics",
                &[("sql", serde_json::json!(sql))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Resolve a business term to schema elements via fuzzy matching.
#[pyfunction]
pub fn resolve_term(py: Python<'_>, term: &str, schema: &Schema) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let result = altimate_core::glossary::resolve_term(term, &schema.inner);
    match crate::convert::to_py_result(py, &result) {
        Ok(obj) => {
            crate::sdk::timed_emit("resolveTerm", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "resolveTerm",
                &[("term", serde_json::json!(term))],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Analyze SQL for anti-patterns using the polyglot-sql tag engine.
///
/// Returns a dict with `parse_ok` (bool) and `results` (list of tag dicts).
/// Each tag dict has `tag_name`, `triggered`, and `reports`.
#[pyfunction]
#[pyo3(signature = (sql, dialect="snowflake", skip_tags=None))]
pub fn analyze_tags(
    py: Python<'_>,
    sql: &str,
    dialect: &str,
    skip_tags: Option<Vec<String>>,
) -> PyResult<PyObject> {
    let start = std::time::Instant::now();
    let dialect_type = str_to_polyglot_dialect(dialect)?;
    let config = altimate_core::tagger::AnalysisConfig {
        skip_tags: skip_tags.clone().unwrap_or_default(),
    };
    let output = altimate_core::tagger::analyze_tags(sql, dialect_type, &config);
    match crate::convert::to_py_result(py, &output) {
        Ok(obj) => {
            crate::sdk::timed_emit("analyzeTags", start);
            Ok(obj)
        }
        Err(e) => {
            crate::sdk::report_failure_kv(
                "analyzeTags",
                &[
                    ("sql", serde_json::json!(sql)),
                    ("dialect", serde_json::json!(dialect)),
                    ("skip_tags", serde_json::json!(skip_tags)),
                ],
                start.elapsed().as_millis() as u64,
                &e.to_string(),
            );
            Err(e)
        }
    }
}

/// Map a dialect string to polyglot-sql DialectType.
fn str_to_polyglot_dialect(s: &str) -> PyResult<polyglot_sql::dialects::DialectType> {
    use polyglot_sql::dialects::DialectType;
    match s.to_lowercase().as_str() {
        "snowflake" => Ok(DialectType::Snowflake),
        "postgres" | "postgresql" => Ok(DialectType::PostgreSQL),
        "bigquery" => Ok(DialectType::BigQuery),
        "databricks" => Ok(DialectType::Databricks),
        "duckdb" => Ok(DialectType::DuckDB),
        "mysql" => Ok(DialectType::MySQL),
        "redshift" => Ok(DialectType::Redshift),
        "hive" => Ok(DialectType::Hive),
        "spark" => Ok(DialectType::Spark),
        "sqlite" => Ok(DialectType::SQLite),
        "trino" => Ok(DialectType::Trino),
        "presto" => Ok(DialectType::Presto),
        "clickhouse" => Ok(DialectType::ClickHouse),
        "oracle" => Ok(DialectType::Oracle),
        "tsql" | "mssql" => Ok(DialectType::TSQL),
        "athena" => Ok(DialectType::Athena),
        "generic" => Ok(DialectType::Generic),
        _ => Err(pyo3::exceptions::PyValueError::new_err(format!(
            "unknown dialect '{s}' for analyze_tags. Supported: snowflake, postgres, bigquery, \
             databricks, duckdb, mysql, redshift, hive, spark, sqlite, trino, presto, \
             clickhouse, oracle, tsql, athena, generic"
        ))),
    }
}
