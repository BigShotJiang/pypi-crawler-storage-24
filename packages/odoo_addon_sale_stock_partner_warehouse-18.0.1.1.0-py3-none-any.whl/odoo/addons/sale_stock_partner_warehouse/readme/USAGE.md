You need at least to manage 2 different warehouses.
