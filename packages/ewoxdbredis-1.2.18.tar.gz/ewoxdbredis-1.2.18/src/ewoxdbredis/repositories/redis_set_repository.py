from typing import Any, List, Dict, Text, Optional, Tuple, TypeVar, Union, Awaitable, Set
import logging
import redis
from ewoxdbredis.repositories.redis_base_repository import RedisBaseRepository

T = TypeVar("T", redis.asyncio.RedisCluster, redis.asyncio.Redis)


class RedisSetRepository(RedisBaseRepository):
    def __init__(self, table_name:str="", separator:str=":") -> None:
        super().__init__(table_name, separator)


    async def add(self, connection:T, value:Any) -> bool:
        """ Returns true if the order of the set has changed """
        if (self._table_name):
            val:int = await connection.sadd(self._table_name, value)
            if (val >= 1):
                return True
        
        return False


    async def add_items(self, connection:T, items:list[Any]) -> bool:
        if (self._table_name):
            val:int = await connection.sadd(self._table_name, *items)
            if (val >= 1):
                return True
        
        return False


    async def get_items(self, connection:T) -> list[Any]:
        items:list[Any] = []
        if (self._table_name):

            items_inner:Set = await connection.smembers(self._table_name)
            items = list(items_inner)

        return items
    

    async def exist(self, connection:T, value:Any) -> bool:
        """ Check if a value exists in the set. """
        if (self._table_name):
            val:int = await connection.sismember(self._table_name, value)
            if (val == 1):
                return True
        
        return False


    async def delete(self, connection:T, value:Any) -> bool:
        if (self._table_name):
            await connection.srem(self._table_name, value)
            return True

        return False
    

    async def delete_items(self, connection:T, items:list[Any]) -> bool:
        if (self._table_name):
            await connection.srem(self._table_name, *items)
            return True

        return False
    

    async def delete_all(self, connection:T) -> bool:
        """ Delete the entire set key. Returns the number of keys that were removed. """
        if (self._table_name):
            num:int = await connection.delete(self._table_name)
            return True if num > 0 else False

        return False
    

    async def get_random(self, connection:T) -> Any:
        """ Pop a random member from the set. """
        if (self._table_name):
            value:Any = await connection.spop(self._table_name)
            return value
        
        return None