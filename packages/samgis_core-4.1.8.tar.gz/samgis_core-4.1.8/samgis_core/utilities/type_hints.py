"""custom type hints"""

from enum import StrEnum
from typing import Any


ListStr = list[str]
ListDict = list[dict[str, Any]]


class MatplotlibBackend(StrEnum):
    gtk3agg = "gtk3agg"
    gtk3cairo = "gtk3cairo"
    gtk4agg = "gtk4agg"
    gtk4cairo = "gtk4cairo"
    macosx = "macosx"
    nbagg = "nbagg"
    notebook = "notebook"
    qtagg = "qtagg"
    qtcairo = "qtcairo"
    qt5agg = "qt5agg"
    qt5cairo = "qt5cairo"
    tkagg = "tkagg"
    tkcairo = "tkcairo"
    webagg = "webagg"
    wx = "wx"
    wxagg = "wxagg"
    wxcairo = "wxcairo"
    agg = "agg"
    cairo = "cairo"
    pdf = "pdf"
    pgf = "pgf"
    ps = "ps"
    svg = "svg"
    template = "template"
