"""Get machine learning predictions from geodata raster images"""

import os

import structlog
from dotenv import load_dotenv

from samgis_core.utilities import session_logger


load_dotenv()
LOG_JSON_FORMAT = os.getenv("LOG_JSON_FORMAT", "").lower() in ("true", "1", "yes")
log_level = os.getenv("LOG_LEVEL", "INFO")
session_logger.setup_logging(json_logs=LOG_JSON_FORMAT, log_level=log_level)
app_logger = structlog.stdlib.get_logger(__name__)
