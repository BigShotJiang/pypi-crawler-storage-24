"""Tests for health and basic endpoints."""


class TestHealthEndpoint:
    """Tests for the /health endpoint."""

    def test_health_returns_200(self, client):
        """Health endpoint should return 200 OK."""
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_returns_healthy_status(self, client):
        """Health endpoint should return healthy status."""
        response = client.get("/health")
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data

    def test_health_no_auth_required(self, client):
        """Health endpoint should not require authentication."""
        # Even without DEV_MODE, health should work
        response = client.get("/health")
        assert response.status_code == 200


class TestOpenAPIEndpoint:
    """Tests for OpenAPI documentation."""

    def test_openapi_available(self, client):
        """OpenAPI schema should be available."""
        response = client.get("/openapi.json")
        assert response.status_code == 200
        data = response.json()
        assert "openapi" in data
        assert "paths" in data

    def test_docs_available(self, client):
        """Swagger docs should be available."""
        response = client.get("/docs")
        assert response.status_code == 200
