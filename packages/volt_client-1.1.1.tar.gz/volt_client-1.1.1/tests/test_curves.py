"""Tests for curves endpoints."""


class TestCurvesEndpoint:
    """Tests for the /curves endpoint."""

    def test_curves_returns_200(self, client):
        """Curves endpoint should return 200 OK."""
        response = client.get("/curves")
        assert response.status_code == 200

    def test_curves_returns_list(self, client):
        """Curves endpoint should return a list of curves."""
        response = client.get("/curves")
        data = response.json()
        assert isinstance(data, list)
        assert len(data) > 0

    def test_curves_have_required_fields(self, client):
        """Each curve should have required fields."""
        response = client.get("/curves")
        data = response.json()

        required_fields = ["curve_id", "curve_name"]
        for curve in data[:5]:  # Check first 5 curves
            for field in required_fields:
                assert field in curve, f"Missing field: {field}"

    def test_curves_filter_by_area(self, client):
        """Should be able to filter curves by area."""
        response = client.get("/curves?area=NO1")
        assert response.status_code == 200
        data = response.json()

        # All returned curves should be for NO1
        for curve in data:
            assert "no1" in curve["curve_name"].lower()

    def test_curves_filter_by_nonexistent_area(self, client):
        """Filtering by nonexistent area should return empty list."""
        response = client.get("/curves?area=FAKE_AREA")
        assert response.status_code == 200
        data = response.json()
        assert data == []

    def test_curves_filter_by_multiple_groups(self, client):
        """Should be able to filter curves by multiple groups."""
        response = client.get("/curves?groups=historical,mid-term")
        assert response.status_code == 200
        data = response.json()
        # All returned curves should have groups in the filter list
        for curve in data:
            assert curve["groups"].lower() in ["historical", "mid-term"]


class TestAreasEndpoint:
    """Tests for the /areas endpoint."""

    def test_areas_returns_200(self, client):
        """Areas endpoint should return 200 OK."""
        response = client.get("/areas")
        assert response.status_code == 200

    def test_areas_returns_list(self, client):
        """Areas endpoint should return a list of areas."""
        response = client.get("/areas")
        data = response.json()
        assert "areas" in data
        assert isinstance(data["areas"], list)
        assert len(data["areas"]) > 0


class TestGroupsEndpoint:
    """Tests for the /groups endpoint."""

    def test_groups_returns_200(self, client):
        """Groups endpoint should return 200 OK."""
        response = client.get("/groups")
        assert response.status_code == 200

    def test_groups_returns_list(self, client):
        """Groups endpoint should return a list of groups."""
        response = client.get("/groups")
        data = response.json()
        assert "groups" in data
        assert isinstance(data["groups"], list)
