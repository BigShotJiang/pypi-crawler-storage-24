"""Tests for data retrieval endpoints."""

from datetime import datetime

from volt_api.main import MidTermDataPoint


class TestMidTermDataPointModel:
    """Tests for the MidTermDataPoint response model."""

    def test_tag_accepts_none(self):
        """MidTermDataPoint should accept tag=None for curves without tags."""
        point = MidTermDataPoint(ts=datetime(2024, 1, 1), value=42.0, tag=None)
        assert point.tag is None

    def test_tag_accepts_string(self):
        """MidTermDataPoint should accept tag as a string."""
        point = MidTermDataPoint(ts=datetime(2024, 1, 1), value=42.0, tag="p_avg")
        assert point.tag == "p_avg"

    def test_tag_defaults_to_none(self):
        """MidTermDataPoint should default tag to None when omitted."""
        point = MidTermDataPoint(ts=datetime(2024, 1, 1), value=42.0)
        assert point.tag is None


class TestDataActualEndpoint:
    """Tests for the /data/actual endpoint."""

    def test_actual_requires_curve_id(self, client):
        """Should require curve_id parameter."""
        response = client.get("/data/actual?start_date=2024-01-01&end_date=2024-01-31")
        assert response.status_code == 422  # Validation error

    def test_actual_requires_start_date(self, client):
        """Should require start_date parameter."""
        response = client.get("/data/actual?curve_id=1&end_date=2024-01-31")
        assert response.status_code == 422

    def test_actual_requires_end_date(self, client):
        """Should require end_date parameter."""
        response = client.get("/data/actual?curve_id=1&start_date=2024-01-01")
        assert response.status_code == 422

    def test_actual_returns_404_for_unknown_curve(self, client):
        """Should return 404 for unknown curve."""
        response = client.get(
            "/data/actual?curve_id=999999999&start_date=2024-01-01&end_date=2024-01-31"
        )
        assert response.status_code == 404

    def test_actual_validates_date_format(self, client, sample_actual_curve_id):
        """Should validate date format."""
        response = client.get(
            f"/data/actual?curve_id={sample_actual_curve_id}&start_date=invalid&end_date=2024-01-31"
        )
        assert response.status_code == 400

    def test_actual_rejects_non_integer_curve_id(self, client):
        """Should reject non-integer curve_id."""
        response = client.get(
            "/data/actual?curve_id=not_a_number&start_date=2024-01-01&end_date=2024-01-31"
        )
        assert response.status_code == 422


class TestDataClosingEndpoint:
    """Tests for the /data/closing endpoint."""

    def test_closing_requires_curve_id(self, client):
        """Should require curve_id parameter."""
        response = client.get("/data/closing")
        assert response.status_code == 422

    def test_closing_returns_data(self, client, sample_closing_curve_id):
        """Should return data for valid closing curve."""
        response = client.get(f"/data/closing?curve_id={sample_closing_curve_id}")
        assert response.status_code in [200, 404]  # 404 if curve doesn't exist

        if response.status_code == 200:
            data = response.json()
            assert "curve_name" in data
            assert "data" in data
            assert "as_of" in data

    def test_settlement_alias_works(self, client, sample_closing_curve_id):
        """The /data/settlement endpoint should work as alias."""
        response = client.get(f"/data/settlement?curve_id={sample_closing_curve_id}")
        assert response.status_code in [200, 404]


class TestBulkDataEndpoint:
    """Tests for the /data bulk endpoint."""

    def test_bulk_requires_curve_ids(self, client):
        """Should require curve_ids parameter."""
        response = client.get("/data?start_date=2024-01-01&end_date=2024-01-31")
        assert response.status_code == 422

    def test_bulk_validates_curve_ids_format(self, client):
        """Should validate curve_ids format."""
        response = client.get("/data?curve_ids=invalid&start_date=2024-01-01&end_date=2024-01-31")
        assert response.status_code == 400

    def test_bulk_returns_empty_for_no_access(self, client):
        """Should return empty for curves user has no access to."""
        response = client.get("/data?curve_ids=999999999&start_date=2024-01-01&end_date=2024-01-31")
        assert response.status_code == 200
        data = response.json()
        # Either no accessible curves found or empty curves list
        assert "curves" in data or "message" in data


class TestDataFcastEndpoint:
    """Tests for the /data/fcast endpoint."""

    def test_fcast_returns_200_when_tag_is_null(self, client, sample_fcast_curve_id):
        """Curves where tag is NULL in curves_fcast should return 200, not 500."""
        response = client.get(
            f"/data/fcast?curve_id={sample_fcast_curve_id}"
            "&start_date=2024-01-01&end_date=2060-01-01"
        )
        # Should not be a 500 internal server error
        assert response.status_code != 500, (
            f"Got 500 for fcast curve {sample_fcast_curve_id} — "
            "likely MidTermDataPoint.tag does not accept None"
        )
        if response.status_code == 200:
            data = response.json()
            assert "data" in data
            assert "curve_id" in data


class TestBulkFcastFreqParameter:
    """Tests for freq/agg parameters on /data/fcast/bulk endpoint."""

    def test_bulk_fcast_accepts_freq(self, client):
        """Should accept freq parameter without error (returns empty for unknown curves)."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=monthly"
        )
        assert response.status_code == 200
        data = response.json()
        assert data["frequency"] == "monthly"
        assert data["agg"] == "avg"

    def test_bulk_fcast_accepts_freq_short(self, client):
        """Should accept short freq codes."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=m"
        )
        assert response.status_code == 200
        assert response.json()["frequency"] == "m"

    def test_bulk_fcast_accepts_agg_sum(self, client):
        """Should accept agg=sum."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=monthly&agg=sum"
        )
        assert response.status_code == 200
        data = response.json()
        assert data["agg"] == "sum"

    def test_bulk_fcast_rejects_invalid_freq(self, client):
        """Should reject invalid frequency."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=invalid"
        )
        assert response.status_code == 400
        assert "Invalid frequency" in response.json()["detail"]

    def test_bulk_fcast_rejects_invalid_agg(self, client):
        """Should reject invalid agg type."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=monthly&agg=median"
        )
        assert response.status_code == 400
        assert "Invalid agg" in response.json()["detail"]

    def test_bulk_fcast_no_freq_returns_null(self, client):
        """Without freq, frequency and agg should be null."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31"
        )
        assert response.status_code == 200
        data = response.json()
        assert data["frequency"] is None
        assert data["agg"] is None

    def test_bulk_fcast_freq_rejects_non_cet_tz(self, client):
        """Freq with non-CET timezone should be rejected."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=monthly&tz=US/Eastern"
        )
        assert response.status_code == 400
        assert "pre-aggregated in CET" in response.json()["detail"]

    def test_bulk_fcast_freq_accepts_cet_tz(self, client):
        """Freq with CET timezone should be accepted."""
        response = client.get(
            "/data/fcast/bulk?curve_ids=999999999&start_date=2024-01-01&end_date=2024-12-31&freq=monthly&tz=CET"
        )
        assert response.status_code == 200


class TestTimezoneParameter:
    """Tests for timezone parameter handling."""

    def test_timezone_cet_accepted(self, client, sample_closing_curve_id):
        """CET timezone should be accepted."""
        response = client.get(f"/data/closing?curve_id={sample_closing_curve_id}&tz=CET")
        assert response.status_code in [200, 404]

    def test_timezone_europe_oslo_accepted(self, client, sample_closing_curve_id):
        """Europe/Oslo timezone should be accepted."""
        response = client.get(f"/data/closing?curve_id={sample_closing_curve_id}&tz=Europe/Oslo")
        assert response.status_code in [200, 404]

    def test_invalid_timezone_rejected(self, client, sample_closing_curve_id):
        """Invalid timezone should be rejected."""
        response = client.get(f"/data/closing?curve_id={sample_closing_curve_id}&tz=Invalid/Zone")
        assert response.status_code == 400


class TestAggregationParameters:
    """Tests for aggregation parameters on /data/actual endpoint."""

    def test_valid_aggregation_accepted(self, client, sample_actual_curve_id):
        """Valid aggregation frequency should be accepted."""
        for agg in ["hourly", "daily", "weekly", "monthly", "yearly"]:
            response = client.get(
                f"/data/actual?curve_id={sample_actual_curve_id}&start_date=2024-01-01&end_date=2024-01-02&agg={agg}"
            )
            assert response.status_code in [200, 400, 404], f"Failed for agg={agg}"

    def test_invalid_aggregation_rejected(self, client, sample_actual_curve_id):
        """Invalid aggregation frequency should be rejected."""
        response = client.get(
            f"/data/actual?curve_id={sample_actual_curve_id}&start_date=2024-01-01&end_date=2024-01-02&agg=invalid"
        )
        assert response.status_code == 400
