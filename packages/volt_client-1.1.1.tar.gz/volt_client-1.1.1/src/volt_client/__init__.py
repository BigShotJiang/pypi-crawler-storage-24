"""
Volt Client - Python client for Volt Power Analytics API.

Usage:
    from volt_client import VoltClient

    client = VoltClient(api_key="volt_your_api_key")
    df = client.get_actual("price spot no1 nordpool eur mwh min60 actual", "2024-01-01", "2024-12-31")
"""

from volt_client.client import (
    DataFrame,
    VoltAccessError,
    VoltClient,
    VoltClientError,
    VoltCurveNotFoundError,
    VoltEmptyDataError,
)

__version__ = "1.0.0"
__all__ = [
    "VoltClient",
    "VoltClientError",
    "VoltAccessError",
    "VoltCurveNotFoundError",
    "VoltEmptyDataError",
    "DataFrame",
]
