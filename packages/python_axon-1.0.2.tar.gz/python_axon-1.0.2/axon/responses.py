"""
axon.responses
==============
HTTP error response helpers. Raise these from route handlers or services.

    from axon.responses import not_found, bad_request, forbidden

These raise PlatformHTTPException which the framework catches and converts
to a consistent JSON error shape:
    {"error": true, "status": 404, "code": "not_found", "message": "..."}
"""
from axon.core.routing.responses import (  # noqa: F401
    bad_request,
    unauthorized,
    forbidden,
    not_found,
    conflict,
    unprocessable,
    too_many_requests,
    server_error,
    service_unavailable,
    PlatformHTTPException,
)

__all__ = [
    "bad_request", "unauthorized", "forbidden", "not_found",
    "conflict", "unprocessable", "too_many_requests",
    "server_error", "service_unavailable",
    "PlatformHTTPException",
]
