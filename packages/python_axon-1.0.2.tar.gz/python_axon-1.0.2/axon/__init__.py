"""
Axon Framework
==============
A modular Python backend framework built on FastAPI.

    pip install axon-framework
    axon create_project myapp

Full import surface — everything a module builder needs:

    from axon import Module, Service, Model, Router, Manifest, Context, Log
    from axon import bind, make, override, extend, env, config
    from axon.fields import StringField, BoolField, IntField, ...
    from axon.auth import require_auth, require_role, optional_auth
"""
from __future__ import annotations

__version__ = "1.0.0"
__all__ = [
    # Core classes
    "Module", "Service", "Model", "Router", "Context", "Manifest", "Log",
    # Container
    "bind", "override", "extend", "instance", "make", "has_binding",
    # Events / jobs
    "on", "emit", "filter_event", "dispatch", "schedule",
    # Environment & config
    "env", "env_bool", "env_int", "env_list", "config", "config_set",
    # HTTP
    "abort", "url", "route",
    # Paths
    "base_path", "app_path", "storage_path", "public_path",
    "resource_path", "database_path",
    # Strings
    "str_slug", "str_snake", "str_camel", "str_pascal", "str_title",
    "str_plural", "str_singular", "str_truncate", "str_limit",
    "str_contains", "str_starts_with", "str_ends_with", "str_mask",
    "str_random", "str_pad", "str_repeat", "str_between", "str_word_count",
    "str_upper", "str_lower", "str_replace", "str_wrap", "str_is",
    "str_uuid", "str_headline",
    # Arrays
    "arr_get", "arr_set", "arr_has", "arr_except", "arr_only",
    "arr_flatten", "arr_pluck", "arr_group_by", "arr_unique",
    "arr_first", "arr_last", "arr_chunk", "arr_where",
    "arr_sort", "arr_map", "arr_filter", "arr_zip",
    "arr_sum", "arr_avg", "arr_min", "arr_max",
    "arr_key_by", "arr_count_by", "arr_partition",
    "arr_diff", "arr_intersect", "arr_merge", "arr_deep_merge",
    # Values
    "blank", "filled", "value_of", "optional", "tap", "once", "retry",
    # Security
    "bcrypt", "bcrypt_check", "hash_make", "hash_check",
    "md5", "sha256", "hmac_sign", "hmac_verify",
    # Numeric
    "num_clamp", "num_round", "num_format", "num_currency",
    "num_percent", "num_ordinal",
    # DateTime
    "now", "today", "timestamp", "now_iso", "diff_in_seconds", "human_time",
    # Files
    "file_exists", "file_get", "file_put", "file_extension", "file_basename",
    # Debug
    "dd", "dump",
]

# ── Core classes ──────────────────────────────────────────────────────────────
# Clean public aliases — Module, Service, Model instead of BaseModule, BaseService, AppModel

from axon.core.module.base_module  import BaseModule  as Module   # noqa: F401
from axon.core.module.base_service import BaseService as Service  # noqa: F401
from axon.core.db.app_model        import AppModel    as Model    # noqa: F401
from axon.core.routing.router      import Router, Context         # noqa: F401
from axon.core.module.manifest     import Manifest                # noqa: F401
from axon.core.logging.log         import Log                     # noqa: F401
from axon.core.module.vendor_provider import VendorProvider       # noqa: F401

# ── All helpers ───────────────────────────────────────────────────────────────
from axon.core.helpers import *  # noqa: F401, F403
