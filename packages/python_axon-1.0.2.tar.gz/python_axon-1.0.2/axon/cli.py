"""
axon CLI
========
The global entry point installed by pip.

    axon create_project myapp     → scaffold a new project
    axon --help                   → show all commands
"""
from __future__ import annotations

import sys


def main() -> None:
    """Entry point registered in pyproject.toml [project.scripts]."""
    from axon.core.kernel import execute_from_command_line
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
