"""
axon.core  --  Platform core.

Sub-packages:
    axon.core.engine    -- AppEngine, Container, HookBus
    axon.core.db        -- AppModel, fields, MigrationRunner
    axon.core.routing   -- Router, Context, inject(), responses
    axon.core.logging   -- Log
    axon.core.config    -- ConfigManager
    axon.core.module    -- BaseModule, BaseService, Manifest, ModuleLoader
"""
