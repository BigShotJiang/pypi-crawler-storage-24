# Compatibility shim — canonical import is now simply:
#
#   from axon import Module, bind, make, env, ...
#
# This file remains so any code that was already using
# "from axon.core.base_module import ..." continues to work.

from axon.core.module.base_module import BaseModule  # noqa: F401
from axon.core.helpers import *  # noqa: F401, F403
