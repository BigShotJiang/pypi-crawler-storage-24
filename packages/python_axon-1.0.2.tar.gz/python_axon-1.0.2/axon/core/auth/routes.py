"""
Auth Routes
===========
Platform-level auth HTTP endpoints.
Mounted by the engine at boot — not via module discovery.

Routes
------
    POST /auth/register    — create account, returns {user, token}
    POST /auth/login       — authenticate, returns {user, token}
    POST /auth/refresh     — refresh token (Bearer header required)
    GET  /auth/me          — current user profile (requires auth)
    PUT  /auth/me          — update profile (requires auth)
"""
from __future__ import annotations

from pydantic import BaseModel, field_validator

from axon.core.routing.router import Router, Context
from axon.core.auth.guards import require_auth
from axon.core.auth.services import UserService, TokenService
from axon.core.routing.responses import unauthorized, not_found


class RegisterIn(BaseModel):
    email:    str
    password: str
    name:     str = ""

    @field_validator("email")
    @classmethod
    def email_valid(cls, v):
        if "@" not in v or "." not in v.split("@")[-1]:
            raise ValueError("Invalid email address")
        return v.lower()

    @field_validator("password")
    @classmethod
    def password_length(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class LoginIn(BaseModel):
    email:    str
    password: str


class UpdateIn(BaseModel):
    name:     str | None = None
    password: str | None = None


# Public router
router = Router(prefix="/auth", tags=["auth"])

# Protected sub-group: /auth/me — require_auth auto-applied to all routes here
_me = router.group("/me", middleware=[require_auth])


@router.post("/register", status=201, name="auth.register",
             summary="Register a new account")
async def register(body: RegisterIn, ctx: Context,
                   users: UserService, tokens: TokenService):
    user  = users.create(email=body.email, password=body.password, name=body.name)
    token = tokens.issue(user)
    return {"user": user, "token": token}


@router.post("/login", name="auth.login",
             summary="Login and get an access token")
async def login(body: LoginIn, ctx: Context,
                users: UserService, tokens: TokenService):
    user = users.login(email=body.email, password=body.password)
    if not user:
        unauthorized("Invalid email or password", "invalid_credentials")
    token = tokens.issue(user)
    return {"user": user, "token": token}


@router.post("/refresh", name="auth.refresh",
             summary="Refresh an access token",
             middleware=[require_auth])
async def refresh_token(ctx: Context, tokens: TokenService):
    """require_auth validates the token — payload is in request.state.user."""
    user_payload = _get_auth_user(ctx)
    if not user_payload:
        unauthorized("Authentication required", "unauthenticated")
    # Build minimal user dict from JWT payload for re-issue
    user = {"id": user_payload["sub"],
            "email": user_payload["email"],
            "role":  user_payload.get("role", "user")}
    new_token = tokens.issue(user)
    return {"token": new_token}


@_me.get("", name="auth.me", summary="Get current user profile")
async def get_me(ctx: Context, users: UserService):
    user_payload = _get_auth_user(ctx)
    if not user_payload:
        unauthorized("Authentication required", "unauthenticated")
    user = users.find(user_payload["sub"])
    if not user:
        not_found("User not found")
    return user


@_me.put("", name="auth.me.update", summary="Update current user profile")
async def update_me(body: UpdateIn, ctx: Context, users: UserService):
    user_payload = _get_auth_user(ctx)
    if not user_payload:
        unauthorized("Authentication required", "unauthenticated")
    fields = {k: v for k, v in body.model_dump().items() if v is not None}
    result = users.update(user_payload["sub"], **fields)
    if not result:
        not_found("User not found")
    return result


def _get_auth_user(ctx: Context) -> dict | None:
    """Read authenticated user payload from request state (set by require_auth)."""
    try:
        return getattr(ctx._request.state, "user", None)
    except Exception:
        return None
