"""
Auth Guards
===========
Route-level and group-level middleware for protecting endpoints.
Import from here — these are platform guarantees, always available.

Per-route usage
---------------
    from axon.core.auth.guards import require_auth, require_role, optional_auth

    @router.get("/profile", middleware=[require_auth])
    async def profile(ctx: Context, svc: UserService):
        user_id = ctx.request.state.user["sub"]
        return svc.find(user_id)

Group-level usage (protects all routes in the group)
-----------------------------------------------------
    from axon.core.auth.guards import require_auth, require_role

    # All routes on this router require auth automatically
    protected = Router(prefix="/api", middleware=[require_auth])

    # Admin group — requires auth AND admin role
    admin = Router(prefix="/admin", middleware=[require_auth, require_role("admin")])

    @admin.get("/users")          # ← auth + role check, no decoration needed
    async def list_users(...): ...

Global middleware (all routes matching a path pattern)
------------------------------------------------------
    class Module(BaseModule):
        def register(self) -> None:
            # Protect everything under /admin globally
            self.use(require_auth, path="/admin/*", priority=5)

Accessing the user in a handler
--------------------------------
    user = ctx.request.state.user
    # → {"sub": "user-uuid", "email": "...", "role": "user", "exp": ...}
"""
from __future__ import annotations
from axon.core.routing.middleware import RequestContext


def _extract_token(req: RequestContext) -> str | None:
    """Pull Bearer token from Authorization header."""
    auth = req.header("authorization")
    if auth and auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return None


def _get_token_service():
    """Lazy-resolve TokenService from the container. No circular import."""
    import axon.core.engine.app_engine as _em
    engine = _em._engine_instance
    if engine is None:
        return None
    try:
        from axon.core.auth.services import TokenService
        return engine.container.make(TokenService)
    except Exception:
        return None


async def require_auth(req: RequestContext) -> None:
    """
    Reject request with 401 if no valid Bearer token is present.
    Sets req.state["user"] = JWT payload on success.
    """
    token = _extract_token(req)
    if not token:
        req.abort(401, "Authentication required", "unauthenticated")

    svc = _get_token_service()
    if not svc:
        req.abort(500, "Auth service unavailable", "server_error")

    payload = svc.verify(token)
    if not payload:
        req.abort(401, "Token is invalid or expired", "token_invalid")

    # Attach to request state — available as request.state.user in handlers
    req.state["user"] = payload


async def optional_auth(req: RequestContext) -> None:
    """
    Attach user to state if a valid token is present. Never rejects.
    Useful for public endpoints that show richer data when authenticated.
    """
    token = _extract_token(req)
    if not token:
        req.state["user"] = None
        return
    svc = _get_token_service()
    if svc:
        req.state["user"] = svc.verify(token)
    else:
        req.state["user"] = None


def require_role(*roles: str):
    """
    Factory: return middleware requiring the user to have one of the given roles.
    Must be chained after require_auth (which sets req.state["user"]).

    Usage:
        # Per-route
        @router.delete("/users/{id}", middleware=[require_auth, require_role("admin")])

        # Group-level — all routes in this router need admin role
        admin = Router(prefix="/admin", middleware=[require_auth, require_role("admin")])

        # Multiple allowed roles
        @router.post("/publish", middleware=[require_auth, require_role("admin", "editor")])
    """
    async def _check(req: RequestContext) -> None:
        user = req.state.get("user")
        if not user:
            req.abort(401, "Authentication required", "unauthenticated")
        if user.get("role") not in roles:
            req.abort(403, f"Required role: {' or '.join(roles)}", "forbidden")

    _check.__name__ = f"require_role({', '.join(roles)})"
    return _check
