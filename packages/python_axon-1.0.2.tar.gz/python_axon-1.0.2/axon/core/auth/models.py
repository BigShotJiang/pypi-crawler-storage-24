"""
Auth Models
===========
Platform-level user and token models.
Always present — modules extend or override these, never replace the table.

These live in core because auth is a platform guarantee, not an optional module.
Any module that needs to associate data with a user references auth_users.id.
"""
from datetime import datetime
from axon.core.db.app_model import AppModel
from axon.core.db.fields import (
    StringField, EmailField, BoolField, DateTimeField,
)


class User(AppModel):
    __tablename__ = "auth_users"

    email          = EmailField(unique=True, nullable=False, index=True)
    password_hash  = StringField(255, nullable=False)
    name           = StringField(120, default="")
    role           = StringField(50, default="user")
    is_active      = BoolField(default=True)
    last_login_at  = DateTimeField(nullable=True)

    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "email":      self.email,
            "name":       self.name,
            "role":       self.role,
            "is_active":  self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class PersonalAccessToken(AppModel):
    """
    Optional — for modules that want API-key style long-lived tokens.
    Not used by the default JWT flow but available for extension.
    """
    __tablename__ = "auth_tokens"

    user_id    = StringField(36, nullable=False, index=True)
    token_hash = StringField(255, nullable=False, unique=True)
    name       = StringField(120, default="default")
    expires_at = DateTimeField(nullable=True)
    last_used  = DateTimeField(nullable=True)
