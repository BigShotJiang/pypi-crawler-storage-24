"""
app.core.auth
=============
Platform authentication — always present, always available.

Quick imports
-------------
    from axon.core.auth import UserService, TokenService
    from axon.core.auth.guards import require_auth, require_role, optional_auth

Override in any module
----------------------
    from axon.core.auth import UserService

    class MyUserService(UserService):
        def login(self, *, email, password):
            # custom LDAP / SSO logic
            ...

    class Module(BaseModule):
        def register(self) -> None:
            self.override(UserService, MyUserService)
"""
from axon.core.auth.services import UserService, TokenService
from axon.core.auth.guards   import require_auth, require_role, optional_auth
from axon.core.auth.models   import User

__all__ = [
    "UserService",
    "TokenService",
    "require_auth",
    "require_role",
    "optional_auth",
    "User",
]
