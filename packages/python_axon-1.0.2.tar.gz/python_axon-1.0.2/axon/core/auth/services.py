"""
UserService + TokenService
==========================
Platform-level auth services. Always registered. Always available.

Override example — swap the entire user backend:
    class Module(BaseModule):
        def register(self) -> None:
            self.override(UserService, MyLDAPUserService)

Extend example — add OAuth on top of the default:
    class OAuthUserService(UserService):
        def login_with_google(self, token: str) -> dict: ...

    class Module(BaseModule):
        def register(self) -> None:
            self.override(UserService, OAuthUserService)

Any module that uses make(UserService) or injects svc: UserService
automatically gets the active implementation — zero call-site changes.
"""
from __future__ import annotations

import hashlib
import hmac
import time
from datetime import datetime, timezone
from typing import Optional

from axon.core.module.base_service import BaseService
from axon.core.logging.log import Log

TAG = "AuthService"


# ── Password hashing ──────────────────────────────────────────────────────────

def _hash_password(password: str) -> str:
    """PBKDF2-HMAC-SHA256 with 260k iterations. No bcrypt dep needed."""
    import os, base64
    salt = os.urandom(32)
    key  = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 260_000)
    return base64.b64encode(salt + key).decode()


def _verify_password(password: str, stored: str) -> bool:
    import base64
    try:
        raw  = base64.b64decode(stored.encode())
        salt = raw[:32]
        key  = raw[32:]
        test = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 260_000)
        return hmac.compare_digest(key, test)
    except Exception:
        return False


# ── Async emit helper ─────────────────────────────────────────────────────────

def _fire(coro) -> None:
    """
    Schedule a coroutine as a background task when a loop is running
    (normal HTTP request context), or silently discard it when called
    from a sync CLI context where no loop is active.

    This lets UserService methods stay synchronous while still
    emitting events during live requests.
    """
    import asyncio
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(coro)
    except RuntimeError:
        # No running loop — CLI context (createsuperuser, shell, seeder, etc.)
        # Close the coroutine to suppress the "never awaited" warning.
        coro.close()


# ── UserService ───────────────────────────────────────────────────────────────

class UserService(BaseService):
    """
    Create, find, authenticate, and manage users.

    All methods return plain dicts — no ORM objects leak outside this service.
    The platform registers this by default. Override with self.override(UserService, ...)
    """

    def create(self, *, email: str, password: str, name: str = "", role: str = "user") -> dict:
        from axon.core.auth.models import User
        from axon.core.routing.responses import conflict
        with self.db().session() as s:
            if s.query(User).filter_by(email=email.lower()).first():
                conflict(f"Email '{email}' is already registered")
            user = User(
                email         = email.lower(),
                password_hash = _hash_password(password),
                name          = name,
                role          = role,
            )
            s.add(user)
            s.flush()
            result = user.to_dict()
        Log.i(TAG, "user created: %s role=%s", email, role)
        _fire(self.emit("auth.user.created", result))
        return result

    def find(self, user_id: str) -> Optional[dict]:
        from axon.core.auth.models import User
        with self.db().session() as s:
            u = s.get(User, user_id)
            return u.to_dict() if u else None

    def find_by_email(self, email: str) -> Optional[dict]:
        from axon.core.auth.models import User
        with self.db().session() as s:
            u = s.query(User).filter_by(email=email.lower()).first()
            return u.to_dict() if u else None

    def login(self, *, email: str, password: str) -> Optional[dict]:
        from axon.core.auth.models import User
        with self.db().session() as s:
            u = s.query(User).filter_by(email=email.lower(), is_active=True).first()
            if not u or not _verify_password(password, u.password_hash):
                return None
            u.last_login_at = datetime.now(timezone.utc)
            s.flush()
            result = u.to_dict()
        _fire(self.emit("auth.user.logged_in", result))
        return result

    def update(self, user_id: str, **fields) -> Optional[dict]:
        from axon.core.auth.models import User
        _forbidden = {"id", "password_hash", "created_at"}
        with self.db().session() as s:
            u = s.get(User, user_id)
            if not u:
                return None
            if "password" in fields:
                u.password_hash = _hash_password(fields.pop("password"))
            for k, v in fields.items():
                if k not in _forbidden and hasattr(u, k):
                    setattr(u, k, v)
            s.flush()
            return u.to_dict()

    def delete(self, user_id: str) -> bool:
        from axon.core.auth.models import User
        with self.db().session() as s:
            u = s.get(User, user_id)
            if not u:
                return False
            s.delete(u)
        _fire(self.emit("auth.user.deleted", {"user_id": user_id}))
        return True

    def list(self, page: int = 1, per_page: int = 20) -> dict:
        from axon.core.auth.models import User
        from axon.core.db.paginator import Paginator
        with self.db().session() as s:
            q = s.query(User).order_by(User.created_at.desc())
            return Paginator(q, page=page, per_page=per_page,
                             serializer=lambda u: u.to_dict()).paginate()


# ── TokenService ──────────────────────────────────────────────────────────────

class TokenService(BaseService):
    """
    Issue and verify HS256 JWT tokens.
    No external JWT library — pure stdlib.

    Override to swap for RS256, use a token blacklist, or add refresh token
    persistence:
        class Module(BaseModule):
            def register(self) -> None:
                self.override(TokenService, RedisBackedTokenService)
    """

    def _secret(self) -> bytes:
        key = self.config("platform.secret_key", "change-me-in-production")
        if key == "change-me-in-production":
            Log.w(TAG, "platform.secret_key is not set — using insecure default")
        return key.encode()

    def _encode(self, payload: dict) -> str:
        import json, base64
        header    = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').rstrip(b"=")
        body      = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=")
        sig_input = header + b"." + body
        sig       = base64.urlsafe_b64encode(
            hmac.new(self._secret(), sig_input, hashlib.sha256).digest()
        ).rstrip(b"=")
        return (sig_input + b"." + sig).decode()

    def _decode(self, token: str) -> Optional[dict]:
        import json, base64
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None
            header_b, body_b, sig_b = parts
            expected = base64.urlsafe_b64encode(
                hmac.new(
                    self._secret(),
                    (header_b + "." + body_b).encode(),
                    hashlib.sha256,
                ).digest()
            ).rstrip(b"=").decode()
            if not hmac.compare_digest(sig_b, expected):
                return None
            padding = "=" * (4 - len(body_b) % 4)
            return json.loads(base64.urlsafe_b64decode(body_b + padding))
        except Exception:
            return None

    def issue(self, user: dict, *, ttl: int = 3600) -> str:
        """Issue a signed JWT. ttl in seconds (default 1 hour)."""
        payload = {
            "sub":   str(user["id"]),
            "id":   str(user["id"]),
            "email": user["email"],
            "role":  user.get("role", "user"),
            "iat":   int(time.time()),
            "exp":   int(time.time()) + ttl,
        }
        return self._encode(payload)

    def verify(self, token: str) -> Optional[dict]:
        """Verify signature and expiry. Returns payload dict or None."""
        payload = self._decode(token)
        if not payload:
            return None
        if payload.get("exp", 0) < time.time():
            return None
        return payload

    def refresh(self, token: str, *, ttl: int = 3600) -> Optional[str]:
        """Verify an existing token and re-issue a fresh one."""
        payload = self.verify(token)
        if not payload:
            return None
        user = {"id": payload["sub"], "email": payload["email"], "role": payload["role"]}
        return self.issue(user, ttl=ttl)
