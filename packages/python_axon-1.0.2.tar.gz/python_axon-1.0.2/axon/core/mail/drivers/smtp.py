"""
SmtpMailer
==========
Default mail driver. Sends via SMTP using stdlib smtplib — no extra deps.

Configuration (config.yaml or .env):
    platform:
      mail:
        host:     smtp.gmail.com
        port:     587
        username: you@gmail.com
        password: your-app-password
        from:     "Platform <you@gmail.com>"
        tls:      true      # STARTTLS (port 587)
        ssl:      false     # SMTPS (port 465)

Override with a third-party driver in any module:
    from axon.core.mail import Mailer

    class SendGridMailer(Mailer):
        def send(self, to, subject, body, **kwargs): ...

    class Module(BaseModule):
        def register(self) -> None:
            self.override(Mailer, SendGridMailer)

All other modules continue to use self.make(Mailer).send(...) unchanged.
"""
from __future__ import annotations

import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import TYPE_CHECKING

from axon.core.logging.log import Log

if TYPE_CHECKING:
    pass

TAG = "SmtpMailer"


class SmtpMailer:
    """
    SMTP mail sender. Auto-detects TLS vs SSL from config.
    Thread-safe: opens a new connection per send (suitable for low-volume).
    For high-volume, override with a connection-pooled driver.
    """

    def __init__(self, config) -> None:
        """
        config: callable or dict-like with get(key, default).
        Passed from the engine at bootstrap.
        """
        self._cfg = config

    def _c(self, key: str, default=None):
        if callable(self._cfg):
            return self._cfg(f"platform.mail.{key}", default)
        return self._cfg.get(f"platform.mail.{key}", default)

    def send(
        self,
        to:      str | list[str],
        subject: str,
        body:    str,
        *,
        html:    str | None = None,
        from_:   str | None = None,
        cc:      list[str] | None = None,
        bcc:     list[str] | None = None,
    ) -> bool:
        """
        Send an email. Returns True on success, False on failure.

        Args:
            to:      Single address or list of addresses.
            subject: Email subject line.
            body:    Plain-text body.
            html:    Optional HTML body. If provided, sends multipart/alternative.
            from_:   Override the configured from address.
            cc:      CC recipients.
            bcc:     BCC recipients (not visible in headers).
        """
        host     = self._c("host", "localhost")
        port     = int(self._c("port", 587))
        username = self._c("username", "")
        password = self._c("password", "")
        use_tls  = bool(self._c("tls", True))
        use_ssl  = bool(self._c("ssl", False))
        from_addr = from_ or self._c("from", username)

        recipients = [to] if isinstance(to, str) else list(to)
        all_rcpt   = recipients + (cc or []) + (bcc or [])

        # Build message
        if html:
            msg = MIMEMultipart("alternative")
            msg.attach(MIMEText(body, "plain"))
            msg.attach(MIMEText(html, "html"))
        else:
            msg = MIMEText(body, "plain")

        msg["Subject"] = subject
        msg["From"]    = from_addr
        msg["To"]      = ", ".join(recipients)
        if cc:
            msg["Cc"] = ", ".join(cc)

        try:
            if use_ssl:
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(host, port, context=context) as srv:
                    if username:
                        srv.login(username, password)
                    srv.sendmail(from_addr, all_rcpt, msg.as_string())
            else:
                with smtplib.SMTP(host, port) as srv:
                    if use_tls:
                        srv.starttls(context=ssl.create_default_context())
                    if username:
                        srv.login(username, password)
                    srv.sendmail(from_addr, all_rcpt, msg.as_string())

            Log.d(TAG, "sent → %s | %s", ", ".join(recipients), subject)
            return True

        except Exception as exc:
            Log.e(TAG, "failed to send to %s: %s", ", ".join(recipients), exc)
            return False

    def queue(self, to, subject, body, **kwargs) -> None:
        """
        Dispatch mail as a background job so the request returns immediately.
        Uses the platform job runner — retries on failure.
        """
        import axon.core.engine.app_engine as _em
        engine = _em._engine_instance
        if engine is None:
            self.send(to, subject, body, **kwargs)
            return

        from axon.core.engine.jobs import Job

        class _SendMailJob(Job):
            max_retries = 2
            retry_delay = 10.0

            async def handle(self, **kw) -> None:
                mailer = self.make("Mailer")
                mailer.send(kw["to"], kw["subject"], kw["body"],
                            html=kw.get("html"), from_=kw.get("from_"))

        engine.jobs.dispatch(_SendMailJob, to=to, subject=subject, body=body, **kwargs)
