"""
Built-in mail drivers.
Platform boots SmtpMailer by default if SMTP is configured, NullMailer otherwise.
"""
