"""
NullMailer
==========
Swallows all mail silently. Used when no SMTP config is present.
Logs at DEBUG level so developers know mail was "sent" during development.

Useful for:
- Local dev with no mail server
- Test environments
- CI pipelines

Switch to real mail by setting PLATFORM__MAIL__HOST in .env
"""
from __future__ import annotations
from axon.core.logging.log import Log

TAG = "NullMailer"


class NullMailer:
    """
    Drop-in replacement for any Mailer.
    Logs the would-be email but never actually sends anything.
    """

    def send(
        self,
        to:      str | list[str],
        subject: str,
        body:    str,
        *,
        html:    str | None = None,
        from_:   str | None = None,
        cc:      list[str] | None = None,
        bcc:     list[str] | None = None,
    ) -> bool:
        recipients = [to] if isinstance(to, str) else to
        Log.d(TAG, "NULL MAIL → %s | subject: %s", ", ".join(recipients), subject)
        return True

    def queue(self, to, subject, body, **kwargs) -> None:
        """Queue a mail for background sending (no-op in null driver)."""
        self.send(to, subject, body, **kwargs)
