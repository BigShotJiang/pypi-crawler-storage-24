"""
Mailer
======
Platform mail service. Always registered. Any module can send email.

Usage — anywhere in a service or route handler:
------------------------------------------------
    from axon.core.mail import Mailer

    class OrderService(BaseService):
        def confirm(self, order: dict) -> None:
            self.make(Mailer).send(
                to      = order["email"],
                subject = f"Order #{order['id']} confirmed",
                body    = f"Your order has been confirmed.",
                html    = "<h1>Order confirmed</h1>",
            )

        def confirm_async(self, order: dict) -> None:
            # Returns immediately — sends in background via job runner
            self.make(Mailer).queue(
                to      = order["email"],
                subject = f"Order #{order['id']} confirmed",
                body    = "Your order has been confirmed.",
            )

Swapping the driver — in any module:
--------------------------------------
    from axon.core.mail import Mailer

    class ResendMailer(Mailer):
        def send(self, to, subject, body, **kwargs) -> bool:
            # call Resend API
            ...

    class Module(BaseModule):
        def register(self) -> None:
            self.override(Mailer, ResendMailer)

    All callers of make(Mailer) now use Resend — zero other changes.

Auto-detection logic (at boot):
---------------------------------
    If platform.mail.host is configured → SmtpMailer
    Otherwise → NullMailer (logs but does not send)
"""
from __future__ import annotations
from typing import TYPE_CHECKING


class Mailer:
    """
    Abstract mail interface. Override this in a module to swap the transport.

    The platform registers a concrete implementation at boot based on config.
    You never instantiate this directly — use self.make(Mailer).
    """

    def send(
        self,
        to:      str | list[str],
        subject: str,
        body:    str,
        *,
        html:    str | None = None,
        from_:   str | None = None,
        cc:      list[str] | None = None,
        bcc:     list[str] | None = None,
    ) -> bool:
        """Send immediately. Returns True on success."""
        raise NotImplementedError

    def queue(
        self,
        to:      str | list[str],
        subject: str,
        body:    str,
        **kwargs,
    ) -> None:
        """Dispatch to background job runner. Returns immediately."""
        raise NotImplementedError


def _detect_driver(config) -> Mailer:
    """
    Auto-detect which driver to use based on config.
    Called once at engine boot.
    """
    def _get(key, default=None):
        if callable(getattr(config, "get", None)):
            return config.get(f"platform.mail.{key}", default)
        return default

    host = _get("host", "")
    if host:
        from axon.core.mail.drivers.smtp import SmtpMailer
        return SmtpMailer(config)

    from axon.core.mail.drivers.null import NullMailer
    return NullMailer()


__all__ = ["Mailer"]
