from axon.core.mail.mailer import Mailer, _detect_driver

__all__ = ["Mailer", "_detect_driver"]
