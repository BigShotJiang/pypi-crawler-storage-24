"""
Testing Infrastructure
======================
Boots the platform in test mode with an isolated SQLite database.
Each test class gets a fresh engine. No external deps beyond httpx.

Basic usage
-----------
    from axon.core.testing import PlatformTestCase

    class TestAuth(PlatformTestCase):
        async def test_register(self):
            res = await self.client.post("/auth/register", json={
                "email": "test@example.com",
                "password": "secret123",
                "name": "Test User",
            })
            self.assertEqual(res.status_code, 201)
            self.assertIn("token", res.json())

Overriding services for a test
--------------------------------
    class TestOrders(PlatformTestCase):
        async def asyncSetUp(self):
            await super().asyncSetUp()
            self.override(MailService, FakeMailService)

        async def test_order_sends_email(self):
            await self.client.post("/orders/", json={...})
            fake = self.resolve(MailService)
            self.assertEqual(fake.sent, 1)

Async context manager (no class needed)
-----------------------------------------
    async with platform_test_context() as ctx:
        res = await ctx.client.get("/health")
        assert res.status_code == 200
"""
from __future__ import annotations

import asyncio
import os
import unittest
from contextlib import asynccontextmanager
from typing import Any

# Force test DB before any module imports that might read config
os.environ.setdefault("PLATFORM__DATABASE_URL", "sqlite:///./test_platform.db")
os.environ.setdefault("PLATFORM__DEBUG",        "true")
os.environ.setdefault("PLATFORM__LOG_LEVEL",    "WARNING")


class _TestClient:
    """Thin async HTTP client wrapping httpx against the platform ASGI app."""

    def __init__(self, httpx_client, engine) -> None:
        self._http   = httpx_client
        self._engine = engine

    async def get(self, url: str, **kw):    return await self._http.get(url, **kw)
    async def post(self, url: str, **kw):   return await self._http.post(url, **kw)
    async def put(self, url: str, **kw):    return await self._http.put(url, **kw)
    async def patch(self, url: str, **kw):  return await self._http.patch(url, **kw)
    async def delete(self, url: str, **kw): return await self._http.delete(url, **kw)


def _make_test_asgi(engine):
    """
    Build a FastAPI ASGI app that uses an already-booted engine.
    Skips the lifespan boot entirely — engine was booted by the test setup.
    This is the fix for the double-engine problem: the test owns the engine,
    the ASGI app just uses it.
    """
    from fastapi import FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from fastapi.exceptions import RequestValidationError
    from fastapi.exceptions import HTTPException as FastAPIHTTPException
    from contextlib import asynccontextmanager

    from axon.core.routing.responses import PlatformHTTPException, _STATUS_CODES
    from axon.core.engine.platform_router import _build_platform_router

    @asynccontextmanager
    async def _noop_lifespan(_app):
        # Engine already booted — nothing to do here
        yield

    asgi = FastAPI(title="Platform [test]", lifespan=_noop_lifespan,
                   docs_url=None, redoc_url=None)

    # Mount all module routers from the pre-booted engine
    for fa_router in engine.collect_routers():
        asgi.include_router(fa_router)
    asgi.include_router(_build_platform_router(engine))

    @asgi.exception_handler(PlatformHTTPException)
    async def _exc(req, exc):
        return JSONResponse(status_code=exc.status_code, content=exc.to_dict())

    @asgi.exception_handler(RequestValidationError)
    async def _val(req, exc):
        errors = []
        for err in exc.errors():
            f = ".".join(str(l) for l in err.get("loc", [])[1:])
            errors.append({"field": f or "request", "message": err.get("msg", "invalid")})
        return JSONResponse(status_code=422, content={
            "error": True, "status": 422, "code": "validation_error",
            "message": "Request validation failed", "errors": errors,
        })

    @asgi.exception_handler(FastAPIHTTPException)
    async def _http(req, exc):
        code = _STATUS_CODES.get(exc.status_code, "error")
        return JSONResponse(status_code=exc.status_code, content={
            "error": True, "status": exc.status_code, "code": code, "message": exc.detail or "",
        })

    @asgi.exception_handler(Exception)
    async def _unhandled(req, exc):
        import logging
        logging.getLogger("platform.test").exception("Unhandled: %s", exc)
        return JSONResponse(status_code=500, content={
            "error": True, "status": 500, "code": "server_error", "message": str(exc),
        })

    @asgi.middleware("http")
    async def _pipeline(request, call_next):
        from axon.core.routing.middleware import RequestContext, RequestAborted
        req = RequestContext(
            method=request.method, path=request.url.path,
            headers=dict(request.headers), query=dict(request.query_params),
        )
        try:
            req = await engine.pipeline.run_request(req)
        except RequestAborted as exc:
            return JSONResponse(status_code=exc.status, content={
                "error": True, "status": exc.status,
                "message": exc.message, "code": exc.code,
            })
        for k, v in req.state.items():
            setattr(request.state, k, v)
        response = await call_next(request)
        res = await engine.pipeline.run_response(req,
              __import__("axon.core.routing.middleware", fromlist=["ResponseContext"])
              .ResponseContext(status_code=response.status_code))
        for k, v in res.headers.items():
            response.headers[k] = v
        return response

    asgi.add_middleware(CORSMiddleware, allow_origins=["*"],
                        allow_methods=["*"], allow_headers=["*"])
    return asgi


@asynccontextmanager
async def platform_test_context(database_url: str = "sqlite:///./test_platform.db"):
    """Async context manager that boots a full platform for testing."""
    os.environ["PLATFORM__DATABASE_URL"] = database_url

    import axon.core.engine.app_engine as engine_mod
    import axon.core.app_engine        as shim_mod
    from axon.core.engine.app_engine import AppEngine

    engine = await AppEngine.create()
    engine_mod._engine_instance = engine
    shim_mod._engine_instance   = engine

    import httpx
    asgi   = _make_test_asgi(engine)
    client_raw = httpx.AsyncClient(transport=httpx.ASGITransport(app=asgi), base_url="http://testserver")
    await client_raw.__aenter__()

    ctx        = type("TestCtx", (), {})()
    ctx.client = _TestClient(client_raw, engine)
    ctx.engine = engine

    try:
        yield ctx
    finally:
        await client_raw.__aexit__(None, None, None)
        await engine.shutdown()


class PlatformTestCase(unittest.IsolatedAsyncioTestCase):
    """
    Base class for platform integration tests.

    Boots the platform ONCE per test class with an isolated SQLite DB.
    The ASGI app is wired to the same engine — overrides take effect immediately.

    Attributes
    ----------
    client  : _TestClient  — HTTP client
    engine  : AppEngine    — running engine (direct access for advanced cases)

    Methods
    -------
    resolve(ServiceClass)            — get a live service instance
    override(Base, Replacement)      — replace a service binding for this test
    patch(Service, "method", fn)     — patch one method
    """

    _engine     = None
    _httpx_raw  = None

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        # Each test class gets an isolated DB — no cross-class state leakage
        import tempfile
        cls._db_file = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        cls._db_file.close()
        os.environ["PLATFORM__DATABASE_URL"] = f"sqlite:///{cls._db_file.name}"

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        try:
            os.unlink(cls._db_file.name)
        except Exception:
            pass

    async def asyncSetUp(self):
        import httpx
        import axon.core.engine.app_engine as engine_mod
        import axon.core.app_engine        as shim_mod
        from axon.core.engine.app_engine import AppEngine

        # Boot a fresh engine — owns the DB session, services, etc.
        self._engine = await AppEngine.create()
        engine_mod._engine_instance = self._engine
        shim_mod._engine_instance   = self._engine

        # Create all tables directly (tests use SQLite, skip Alembic)
        self._engine.db.create_all_for_testing()

        # Build ASGI from the pre-booted engine — NO second lifespan boot
        asgi = _make_test_asgi(self._engine)

        self._httpx_raw = httpx.AsyncClient(transport=httpx.ASGITransport(app=asgi), base_url="http://testserver")
        await self._httpx_raw.__aenter__()
        self.client = _TestClient(self._httpx_raw, self._engine)
        self.engine = self._engine

    async def asyncTearDown(self):
        # Truncate all tables between tests within a class to prevent state leakage
        if self._engine:
            try:
                from axon.core.app_model import metadata
                from sqlalchemy import text
                with self._engine.db._engine.connect() as conn:
                    for table in reversed(metadata.sorted_tables):
                        conn.execute(text(f"DELETE FROM {table.name}"))
                    conn.commit()
            except Exception:
                pass
        if self._httpx_raw:
            await self._httpx_raw.__aexit__(None, None, None)
        if self._engine:
            await self._engine.shutdown()
            self._engine = None

    def resolve(self, service_type) -> Any:
        """Get a resolved service instance from the container."""
        return self._engine.container.make(service_type)

    def override(self, base: type, replacement: type) -> None:
        """Replace a service binding for tests in this class."""
        self._engine.container.override(base, replacement, owner="test")

    def patch(self, service_type: type, method: str, fn) -> None:
        """Patch a single method on a service for this test."""
        self._engine.container.patch_method(service_type, method, fn, owner="test")
