"""
Axon Helpers
============
Laravel-inspired global helper functions. Import what you need:

    from axon.core.helpers import env, config, app, storage_path, base_path

Or use the wildcard import for the full set (fine in module files):

    from axon.core.helpers import *

All helpers that touch the running app resolve lazily — safe to import at
module level before the engine has booted, since the engine is only accessed
when the function is actually called.
"""
from __future__ import annotations

import os
import json
import re
from pathlib import Path
from typing import Any

_MISSING = object()

# ─────────────────────────────────────────────────────────────────────────────
# Internal — resolve the running AppEngine without a hard import cycle
# ─────────────────────────────────────────────────────────────────────────────

def _engine():
    from axon.core.engine.app_engine import _engine_instance
    if _engine_instance is None:
        raise RuntimeError(
            "The Axon engine has not booted yet. "
            "Do not call app-dependent helpers at import time."
        )
    return _engine_instance


def _project_root() -> Path:
    return Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


# ═════════════════════════════════════════════════════════════════════════════
# Environment helpers
# ═════════════════════════════════════════════════════════════════════════════

def env(key: str, default: Any = None) -> Any:
    """
    Read an environment variable, with an optional default.
    Automatically casts 'true'/'false'/'null'/'none' strings to Python types.

        DEBUG   = env('APP_DEBUG', False)
        DB_HOST = env('DB_HOST', 'localhost')
        API_KEY = env('STRIPE_KEY')          # raises if missing and no default
    """
    value = os.environ.get(key, _MISSING)
    if value is _MISSING:
        if default is _MISSING:
            raise KeyError(f"Environment variable '{key}' is not set and has no default.")
        return default
    return _cast_env(value)


def env_bool(key: str, default: bool = False) -> bool:
    """Read an env var and always return a bool."""
    return bool(_cast_env(os.environ.get(key, str(default))))


def env_int(key: str, default: int = 0) -> int:
    """Read an env var and always return an int."""
    return int(os.environ.get(key, default))


def env_list(key: str, default: list | None = None, separator: str = ",") -> list:
    """
    Read a comma-separated env var as a list.

        ALLOWED_HOSTS = env_list('ALLOWED_HOSTS', ['*'])
        # ALLOWED_HOSTS=example.com,api.example.com  →  ['example.com', 'api.example.com']
    """
    raw = os.environ.get(key)
    if raw is None:
        return default if default is not None else []
    return [item.strip() for item in raw.split(separator) if item.strip()]


def _cast_env(value: str) -> Any:
    """Cast common string representations to native Python types."""
    if isinstance(value, str):
        lower = value.lower().strip()
        if lower in ("true",  "yes", "1", "on"):  return True
        if lower in ("false", "no",  "0", "off"): return False
        if lower in ("null",  "none", ""):        return None
        # Try int, then float, otherwise leave as string
        try:    return int(value)
        except ValueError: pass
        try:    return float(value)
        except ValueError: pass
    return value


# ═════════════════════════════════════════════════════════════════════════════
# Config helpers
# ═════════════════════════════════════════════════════════════════════════════

def config(key: str, default: Any = None) -> Any:
    """
    Read a config value by dot-notation key from the running app.

        SECRET = config('platform.secret_key')
        DEBUG  = config('platform.debug', False)
        RATE   = config('billing.tax_rate', 0.16)
    """
    return _engine().config(key, default)


def config_set(key: str, value: Any) -> None:
    """
    Temporarily override a config value at runtime (in-process only).
    Useful in tests and feature flags. Does not persist to config.yaml.

        config_set('platform.debug', True)
        config_set('mail.driver', 'null')
    """
    cfg = _engine().cfg
    parts = key.split(".")
    cfg._set_nested(cfg._tree, parts, value)
    cfg._rebuild_flat()


# ═════════════════════════════════════════════════════════════════════════════
# Application / container helpers
# ═════════════════════════════════════════════════════════════════════════════

def app(abstract: str | type | None = None) -> Any:
    """
    Resolve a service from the container, or return the engine itself.

        engine      = app()
        user_svc    = app('UserService')
        user_svc    = app(UserService)    # by type

    Mirrors Laravel's app() helper exactly.
    """
    engine = _engine()
    if abstract is None:
        return engine
    return engine.container.make(abstract)


def make(abstract: str | type) -> Any:
    """Alias for app(abstract). Resolves a service from the container."""
    return _engine().container.make(abstract)


# ═════════════════════════════════════════════════════════════════════════════
# Path helpers
# ═════════════════════════════════════════════════════════════════════════════

def base_path(*parts: str) -> Path:
    """
    Absolute path from the project root.

        base_path()                  # → /home/user/myapp
        base_path('storage', 'app')  # → /home/user/myapp/storage/app
    """
    return _project_root().joinpath(*parts)


def app_path(*parts: str) -> Path:
    """Path inside app/.

        app_path('modules', 'billing')  # → .../app/modules/billing
    """
    return _project_root().joinpath("app", *parts)


def storage_path(*parts: str) -> Path:
    """
    Path inside storage/. Directory is created if it does not exist.

        storage_path('logs', 'app.log')
        storage_path('uploads', filename)
    """
    path = _project_root().joinpath("storage", *parts)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def public_path(*parts: str) -> Path:
    """Path inside public/.

        public_path('images', 'logo.png')
    """
    return _project_root().joinpath("public", *parts)


def resource_path(*parts: str) -> Path:
    """Path inside resources/.

        resource_path('templates', 'welcome.html')
    """
    return _project_root().joinpath("resources", *parts)


def database_path(*parts: str) -> Path:
    """Path inside database/.

        database_path('seeders', 'user_seeder.py')
    """
    return _project_root().joinpath("database", *parts)


# ═════════════════════════════════════════════════════════════════════════════
# String helpers
# ═════════════════════════════════════════════════════════════════════════════

def str_slug(value: str, separator: str = "-") -> str:
    """
    Convert a string to a URL-friendly slug.

        str_slug('Hello World!')      # → 'hello-world'
        str_slug('My Module', '_')    # → 'my_module'
    """
    value = value.lower().strip()
    value = re.sub(r"[^\w\s-]", "", value)
    value = re.sub(r"[\s_-]+", separator, value)
    return value.strip(separator)


def str_snake(value: str) -> str:
    """
    Convert CamelCase or PascalCase to snake_case.

        str_snake('OrderService')    # → 'order_service'
        str_snake('HTTPSClient')     # → 'https_client'
    """
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", value)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def str_camel(value: str) -> str:
    """
    Convert snake_case to camelCase.

        str_camel('order_service')   # → 'orderService'
    """
    parts = value.split("_")
    return parts[0] + "".join(p.title() for p in parts[1:])


def str_pascal(value: str) -> str:
    """
    Convert snake_case to PascalCase.

        str_pascal('order_service')  # → 'OrderService'
    """
    return "".join(p.title() for p in value.split("_"))


def str_title(value: str) -> str:
    """
    Convert snake_case or slug to Title Case.

        str_title('order_service')   # → 'Order Service'
        str_title('hello-world')     # → 'Hello World'
    """
    return re.sub(r"[_-]", " ", value).title()


def str_plural(word: str) -> str:
    """
    Naïve English pluralisation — good enough for model/table name generation.

        str_plural('order')    # → 'orders'
        str_plural('category') # → 'categories'
        str_plural('box')      # → 'boxes'
        str_plural('knife')    # → 'knives'
    """
    if word.endswith(("s", "x", "z", "ch", "sh")):
        return word + "es"
    if word.endswith("fe"):
        return word[:-2] + "ves"
    if word.endswith("f") and not word.endswith("ff"):
        return word[:-1] + "ves"
    if word.endswith("y") and len(word) > 1 and word[-2] not in "aeiou":
        return word[:-1] + "ies"
    if word.endswith("o") and word[-2] not in "aeiou":
        return word + "es"
    return word + "s"


def str_singular(word: str) -> str:
    """
    Naïve English singularisation.

        str_singular('orders')      # → 'order'
        str_singular('categories')  # → 'category'
    """
    if word.endswith("ies"):
        return word[:-3] + "y"
    if word.endswith("ves"):
        return word[:-3] + "fe"
    if word.endswith(("ses", "xes", "zes", "ches", "shes")):
        return word[:-2]
    if word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def str_truncate(value: str, length: int = 100, suffix: str = "...") -> str:
    """
    Truncate a string to *length* characters.

        str_truncate('A very long sentence', 10)  # → 'A very lon...'
    """
    if len(value) <= length:
        return value
    return value[:length - len(suffix)] + suffix


def str_contains(haystack: str, needles: str | list[str]) -> bool:
    """
    Check whether a string contains any of the given substrings.

        str_contains('hello world', 'world')           # → True
        str_contains('hello world', ['foo', 'world'])  # → True
    """
    if isinstance(needles, str):
        needles = [needles]
    return any(n in haystack for n in needles)


def str_starts_with(value: str, prefixes: str | list[str]) -> bool:
    """str_starts_with('hello', ['he', 'wo'])  # → True"""
    if isinstance(prefixes, str):
        prefixes = [prefixes]
    return any(value.startswith(p) for p in prefixes)


def str_ends_with(value: str, suffixes: str | list[str]) -> bool:
    """str_ends_with('hello.py', ['.py', '.txt'])  # → True"""
    if isinstance(suffixes, str):
        suffixes = [suffixes]
    return any(value.endswith(s) for s in suffixes)


def str_mask(value: str, keep_start: int = 0, keep_end: int = 4, mask: str = "*") -> str:
    """
    Mask the middle of a string — useful for logging credentials/keys.

        str_mask('my-secret-api-key')             # → '***************-key'
        str_mask('my-secret-api-key', keep_start=3, keep_end=3)  # → 'my-***********key'
    """
    if len(value) <= keep_start + keep_end:
        return mask * len(value)
    middle = len(value) - keep_start - keep_end
    return value[:keep_start] + mask * middle + value[len(value) - keep_end:]


# ═════════════════════════════════════════════════════════════════════════════
# Array / collection helpers
# ═════════════════════════════════════════════════════════════════════════════

def arr_get(data: dict, key: str, default: Any = None) -> Any:
    """
    Dot-notation dict access with a default.

        arr_get(user, 'address.city', 'Unknown')
    """
    parts = key.split(".")
    current = data
    for part in parts:
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current


def arr_set(data: dict, key: str, value: Any) -> dict:
    """
    Dot-notation dict setter — mutates and returns *data*.

        arr_set(user, 'address.city', 'Nairobi')
    """
    parts = key.split(".")
    current = data
    for part in parts[:-1]:
        current = current.setdefault(part, {})
    current[parts[-1]] = value
    return data


def arr_has(data: dict, key: str) -> bool:
    """Check if a dot-notation key exists in a nested dict."""
    return arr_get(data, key, _MISSING) is not _MISSING


def arr_except(data: dict, keys: list[str]) -> dict:
    """Return a copy of *data* without the specified keys.

        arr_except(user, ['password', 'token'])
    """
    return {k: v for k, v in data.items() if k not in keys}


def arr_only(data: dict, keys: list[str]) -> dict:
    """Return a copy of *data* with only the specified keys.

        arr_only(user, ['id', 'email', 'name'])
    """
    return {k: data[k] for k in keys if k in data}


def arr_flatten(data: list, depth: int = -1) -> list:
    """
    Flatten a nested list.

        arr_flatten([[1, 2], [3, [4, 5]]])        # → [1, 2, 3, 4, 5]
        arr_flatten([[1, [2, [3]]], 4], depth=1)  # → [1, [2, [3]], 4]
    """
    result = []
    for item in data:
        if isinstance(item, list) and depth != 0:
            result.extend(arr_flatten(item, depth - 1))
        else:
            result.append(item)
    return result


def arr_pluck(data: list[dict], key: str) -> list:
    """
    Extract a list of values for *key* from a list of dicts.

        arr_pluck(users, 'email')   # → ['a@x.com', 'b@x.com']
    """
    return [arr_get(item, key) for item in data]


def arr_group_by(data: list[dict], key: str) -> dict:
    """
    Group a list of dicts by the value of *key*.

        arr_group_by(orders, 'status')
        # → {'pending': [...], 'paid': [...]}
    """
    result: dict = {}
    for item in data:
        group_key = arr_get(item, key)
        result.setdefault(group_key, []).append(item)
    return result


def arr_unique(data: list) -> list:
    """Return list with duplicates removed, preserving order."""
    seen = set()
    out = []
    for item in data:
        k = json.dumps(item, sort_keys=True, default=str) if isinstance(item, dict) else item
        if k not in seen:
            seen.add(k)
            out.append(item)
    return out


def arr_first(data: list, predicate=None, default: Any = None) -> Any:
    """
    Return the first element — or first matching predicate result.

        arr_first(orders, lambda o: o['status'] == 'paid')
    """
    if predicate is None:
        return data[0] if data else default
    return next((item for item in data if predicate(item)), default)


def arr_last(data: list, predicate=None, default: Any = None) -> Any:
    """Return the last element matching the optional predicate."""
    if predicate is None:
        return data[-1] if data else default
    return next((item for item in reversed(data) if predicate(item)), default)


def arr_chunk(data: list, size: int) -> list[list]:
    """
    Split a list into chunks of *size*.

        arr_chunk([1,2,3,4,5], 2)   # → [[1,2],[3,4],[5]]
    """
    return [data[i:i + size] for i in range(0, len(data), size)]


def arr_where(data: list[dict], key: str, value: Any) -> list[dict]:
    """
    Filter a list of dicts where key == value.

        arr_where(orders, 'status', 'pending')
    """
    return [item for item in data if arr_get(item, key) == value]


# ═════════════════════════════════════════════════════════════════════════════
# Value / type helpers
# ═════════════════════════════════════════════════════════════════════════════

def blank(value: Any) -> bool:
    """
    True if value is None, empty string, empty list/dict, or whitespace-only string.
    Mirrors Laravel's blank().

        blank(None)    # True
        blank('')      # True
        blank('  ')    # True
        blank(0)       # False  — zero is not blank
        blank([])      # True
    """
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    if isinstance(value, (list, dict, set)):
        return len(value) == 0
    return False


def filled(value: Any) -> bool:
    """Opposite of blank(). True if value is present and non-empty."""
    return not blank(value)


def value_of(val: Any) -> Any:
    """
    If *val* is callable, call it and return the result. Otherwise return it.
    Mirrors Laravel's value() helper — useful for lazy defaults.

        value_of(42)            # → 42
        value_of(lambda: 42)    # → 42
    """
    return val() if callable(val) else val


def optional(obj: Any, default: Any = None) -> Any:
    """
    Return *obj* if it is not None, else *default*.
    Useful as a safe null-check without exceptions.

        optional(user, {}).get('email', '')
    """
    return obj if obj is not None else default


def tap(value: Any, callback) -> Any:
    """
    Call *callback* with *value*, then return *value* unchanged.
    Mirrors Laravel's tap() — great for debugging mid-chain.

        result = tap(some_dict, lambda d: logger.debug("dict: %s", d))
    """
    callback(value)
    return value


def once(fn):
    """
    Decorator — the wrapped function is only executed once per process.
    Subsequent calls return the cached result.

        @once
        def load_heavy_resource():
            ...
    """
    _cache = {}
    def wrapper(*args, **kwargs):
        if "result" not in _cache:
            _cache["result"] = fn(*args, **kwargs)
        return _cache["result"]
    wrapper.__wrapped__ = fn
    return wrapper


def retry(times: int = 3, delay: float = 0):
    """
    Decorator — retry a function up to *times* on any exception.

        @retry(times=3, delay=0.5)
        def call_external_api():
            ...
    """
    import time
    import functools
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(times):
                try:
                    return fn(*args, **kwargs)
                except Exception as e:
                    last_exc = e
                    if attempt < times - 1 and delay:
                        time.sleep(delay)
            raise last_exc
        return wrapper
    return decorator


# ═════════════════════════════════════════════════════════════════════════════
# Numeric helpers
# ═════════════════════════════════════════════════════════════════════════════

def num_clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp *value* between *min_val* and *max_val*."""
    return max(min_val, min(max_val, value))


def num_round(value: float, decimals: int = 2) -> float:
    """Round to *decimals* places using Python's built-in round."""
    return round(value, decimals)


def num_format(value: float, decimals: int = 2, thousands_sep: str = ",") -> str:
    """
    Format a number with thousands separator.

        num_format(1234567.89)   # → '1,234,567.89'
    """
    formatted = f"{value:,.{decimals}f}"
    if thousands_sep != ",":
        formatted = formatted.replace(",", thousands_sep)
    return formatted


# ═════════════════════════════════════════════════════════════════════════════
# Date / time helpers
# ═════════════════════════════════════════════════════════════════════════════

def now():
    """Return the current UTC datetime (timezone-aware)."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc)


def today():
    """Return today's date in UTC."""
    from datetime import date
    return date.today()


def timestamp() -> int:
    """Return the current UTC Unix timestamp as an int."""
    import time
    return int(time.time())


# ═════════════════════════════════════════════════════════════════════════════
# Debug helpers
# ═════════════════════════════════════════════════════════════════════════════

def dd(*values: Any) -> None:
    """
    Dump and die — print all values with types then raise SystemExit.
    Mirrors Laravel's dd(). Only for development.

        dd(user, order)
    """
    import pprint
    for v in values:
        print(f"\n[{type(v).__name__}]")
        pprint.pprint(v)
    raise SystemExit("dd() called — stopping execution.")


def dump(*values: Any) -> None:
    """
    Dump values without stopping execution. Mirrors Laravel's dump().

        dump(user)
        result = some_fn()
        dump(result)
    """
    import pprint
    for v in values:
        print(f"\n[{type(v).__name__}]")
        pprint.pprint(v)


# ═════════════════════════════════════════════════════════════════════════════
# String helpers (extended)
# ═════════════════════════════════════════════════════════════════════════════

def str_random(length: int = 16) -> str:
    """
    Generate a cryptographically random alphanumeric string.

        token = str_random(32)
        # → 'aB3xQr7mNpKw2LvZ...'
    """
    import secrets
    import string
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def str_pad(value: str, length: int, pad: str = " ", side: str = "right") -> str:
    """
    Pad a string to *length* on the given side ('left', 'right', 'both').

        str_pad('42', 5, '0', 'left')   # → '00042'
        str_pad('hi', 6, '-', 'both')   # → '--hi--'
    """
    if side == "left":
        return value.rjust(length, pad)
    if side == "both":
        total = length - len(value)
        left  = total // 2
        right = total - left
        return pad * left + value + pad * right
    return value.ljust(length, pad)


def str_repeat(value: str, times: int) -> str:
    """
    Repeat a string *times* times.

        str_repeat('ab', 3)   # → 'ababab'
    """
    return value * times


def str_between(value: str, start: str, end: str) -> str:
    """
    Extract the substring between *start* and *end*.

        str_between('<div>hello</div>', '<div>', '</div>')  # → 'hello'
        str_between('key=val&x=y', 'key=', '&')            # → 'val'

    Returns empty string if either delimiter is not found.
    """
    s = value.find(start)
    if s == -1:
        return ""
    s += len(start)
    e = value.find(end, s)
    if e == -1:
        return ""
    return value[s:e]


def str_word_count(value: str) -> int:
    """
    Count words in a string.

        str_word_count('hello world')   # → 2
    """
    return len(value.split())


def str_upper(value: str) -> str:
    """str_upper('hello')  # → 'HELLO'"""
    return value.upper()


def str_lower(value: str) -> str:
    """str_lower('HELLO')  # → 'hello'"""
    return value.lower()


def str_replace(value: str, search: str | list, replace: str | list) -> str:
    """
    Replace occurrences of *search* with *replace* in *value*.

        str_replace('Hello World', 'World', 'Axon')   # → 'Hello Axon'
        str_replace('a-b-c', ['-'], ['_'])            # → 'a_b_c'
    """
    if isinstance(search, list):
        if not isinstance(replace, list):
            replace = [replace] * len(search)
        for s, r in zip(search, replace):
            value = value.replace(s, r)
        return value
    return value.replace(search, replace)


def str_limit(value: str, limit: int = 100, end: str = "...") -> str:
    """
    Limit a string to *limit* characters. Alias for str_truncate with Laravel naming.

        str_limit('Long text here', 8)   # → 'Long tex...'
    """
    return str_truncate(value, limit, end)


def str_wrap(value: str, before: str, after: str | None = None) -> str:
    """
    Wrap a string with *before* (and optionally different *after*) string.

        str_wrap('world', 'Hello ', '!')   # → 'Hello world!'
        str_wrap('value', '"')             # → '"value"'
    """
    return before + value + (after if after is not None else before)


def str_is(pattern: str, value: str) -> bool:
    """
    Check if a string matches a pattern. Supports * as wildcard.

        str_is('foo/*', 'foo/bar')     # → True
        str_is('*.py', 'main.py')      # → True
        str_is('foo', 'foobar')        # → False
    """
    import fnmatch
    return fnmatch.fnmatch(value, pattern)


def str_uuid() -> str:
    """
    Generate a UUID4 string.

        id = str_uuid()   # → 'f47ac10b-58cc-4372-a567-0e02b2c3d479'
    """
    import uuid
    return str(uuid.uuid4())


def str_headline(value: str) -> str:
    """
    Convert snake_case, camelCase, or slug to a human-readable headline.

        str_headline('order_total_price')   # → 'Order Total Price'
        str_headline('emailAddress')        # → 'Email Address'
    """
    value = re.sub(r"([A-Z])", r" \1", value)
    value = re.sub(r"[-_]", " ", value)
    return " ".join(w.capitalize() for w in value.split())


# ═════════════════════════════════════════════════════════════════════════════
# Array / collection helpers (extended)
# ═════════════════════════════════════════════════════════════════════════════

def arr_sort(data: list, key: str | None = None, reverse: bool = False) -> list:
    """
    Sort a list, optionally by a dot-notation key for lists of dicts.

        arr_sort([3, 1, 2])                          # → [1, 2, 3]
        arr_sort(orders, key='total', reverse=True)  # → highest first
    """
    if key is None:
        return sorted(data, reverse=reverse)
    return sorted(data, key=lambda item: arr_get(item, key), reverse=reverse)


def arr_map(data: list, callback) -> list:
    """
    Apply *callback* to every element and return a new list.

        arr_map(prices, lambda p: p * 1.16)
    """
    return [callback(item) for item in data]


def arr_filter(data: list, callback=None) -> list:
    """
    Filter a list — keeps truthy values by default, or items where callback returns True.

        arr_filter([0, 1, None, 2, ''])              # → [1, 2]
        arr_filter(orders, lambda o: o['paid'])
    """
    if callback is None:
        return [item for item in data if item]
    return [item for item in data if callback(item)]


def arr_zip(keys: list, values: list) -> dict:
    """
    Combine two lists into a dict.

        arr_zip(['a', 'b'], [1, 2])   # → {'a': 1, 'b': 2}
    """
    return dict(zip(keys, values))


def arr_sum(data: list, key: str | None = None) -> float:
    """
    Sum a list or sum a key from a list of dicts.

        arr_sum([1, 2, 3])                   # → 6
        arr_sum(order_lines, 'total')        # → 349.50
    """
    if key is None:
        return sum(data)
    return sum(arr_get(item, key, 0) for item in data)


def arr_avg(data: list, key: str | None = None) -> float:
    """
    Average of a list or a key across a list of dicts.

        arr_avg([10, 20, 30])                # → 20.0
        arr_avg(products, 'price')
    """
    items = data if key is None else [arr_get(item, key, 0) for item in data]
    return sum(items) / len(items) if items else 0.0


def arr_min(data: list, key: str | None = None) -> Any:
    """Return the minimum value, or minimum by key for a list of dicts."""
    if key is None:
        return min(data)
    return min(arr_get(item, key) for item in data)


def arr_max(data: list, key: str | None = None) -> Any:
    """Return the maximum value, or maximum by key for a list of dicts."""
    if key is None:
        return max(data)
    return max(arr_get(item, key) for item in data)


def arr_key_by(data: list[dict], key: str) -> dict:
    """
    Re-index a list of dicts by the value of *key*.

        arr_key_by(users, 'id')   # → {1: {...}, 2: {...}}
    """
    return {arr_get(item, key): item for item in data}


def arr_count_by(data: list, callback=None) -> dict:
    """
    Count occurrences grouped by value or callback result.

        arr_count_by(['a', 'b', 'a', 'c'])             # → {'a': 2, 'b': 1, 'c': 1}
        arr_count_by(orders, lambda o: o['status'])
    """
    result: dict = {}
    for item in data:
        group = callback(item) if callback else item
        result[group] = result.get(group, 0) + 1
    return result


def arr_partition(data: list, predicate) -> tuple[list, list]:
    """
    Split a list into two: items that match and items that don't.

        passing, failing = arr_partition(orders, lambda o: o['paid'])
    """
    yes, no = [], []
    for item in data:
        (yes if predicate(item) else no).append(item)
    return yes, no


def arr_diff(a: list, b: list) -> list:
    """Return items in *a* that are not in *b*."""
    b_set = set(b)
    return [item for item in a if item not in b_set]


def arr_intersect(a: list, b: list) -> list:
    """Return items that appear in both *a* and *b*."""
    b_set = set(b)
    return [item for item in a if item in b_set]


def arr_merge(*dicts: dict) -> dict:
    """
    Shallow-merge any number of dicts. Later dicts win on key conflict.

        merged = arr_merge(defaults, overrides)
    """
    result: dict = {}
    for d in dicts:
        result.update(d)
    return result


def arr_deep_merge(*dicts: dict) -> dict:
    """
    Recursively merge any number of dicts. Later dicts win on leaf conflict.

        merged = arr_deep_merge(base, override)
    """
    result: dict = {}
    for d in dicts:
        for k, v in d.items():
            if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                result[k] = arr_deep_merge(result[k], v)
            else:
                result[k] = v
    return result


# ═════════════════════════════════════════════════════════════════════════════
# HTTP / routing helpers  (require running engine)
# ═════════════════════════════════════════════════════════════════════════════

def abort(status: int, message: str = "", code: str | None = None) -> None:
    """
    Raise an HTTP exception — stops execution and returns an error response.
    Mirrors Laravel's abort().

        abort(404, "User not found")
        abort(403, "Forbidden")
        abort(422, "Validation failed", code="validation_error")
    """
    from axon.core.routing.responses import (
        bad_request, unauthorized, forbidden, not_found,
        conflict, unprocessable, server_error,
    )
    _map = {
        400: bad_request,
        401: unauthorized,
        403: forbidden,
        404: not_found,
        409: conflict,
        422: unprocessable,
        500: server_error,
    }
    fn = _map.get(status)
    if fn:
        raise fn(message, code)  # type: ignore[misc]
    from axon.core.routing.responses import PlatformHTTPException
    raise PlatformHTTPException(status_code=status, message=message, code=code or "error")


def url(*parts: str) -> str:
    """
    Build an absolute URL from path parts using the app base URL from config.
    Falls back to a relative path if no base URL is configured.

        url('users', '42', 'profile')   # → 'https://example.com/users/42/profile'
        url('/api/orders')              # → 'https://example.com/api/orders'
    """
    base = config("platform.app_url", "").rstrip("/")
    path = "/".join(str(p).strip("/") for p in parts if p)
    return f"{base}/{path}" if base else f"/{path}"


def route(name: str) -> str | None:
    """
    Resolve a named route to its URL path.

        route('user.profile')   # → '/users/profile'
    """
    from axon.core.routing.router import _named_routes
    return _named_routes.get(name)


# ═════════════════════════════════════════════════════════════════════════════
# Security / hashing helpers
# ═════════════════════════════════════════════════════════════════════════════

def bcrypt(password: str, rounds: int = 12) -> str:
    """
    Hash a password using bcrypt.

        hashed = bcrypt('my-password')
        # store hashed in DB, never the raw password
    """
    import bcrypt as _bcrypt
    return _bcrypt.hashpw(password.encode("utf-8"), _bcrypt.gensalt(rounds)).decode("utf-8")


def bcrypt_check(password: str, hashed: str) -> bool:
    """
    Verify a plaintext password against a bcrypt hash.

        if bcrypt_check(plain, user['password_hash']):
            ...
    """
    import bcrypt as _bcrypt
    return _bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))


def hash_make(value: str) -> str:
    """Alias for bcrypt(). Hash a value — mirrors Laravel's Hash::make()."""
    return bcrypt(value)


def hash_check(value: str, hashed: str) -> bool:
    """Alias for bcrypt_check(). Mirrors Laravel's Hash::check()."""
    return bcrypt_check(value, hashed)


def md5(value: str) -> str:
    """Return the MD5 hex digest of *value*. Not for passwords — use bcrypt()."""
    import hashlib
    return hashlib.md5(value.encode()).hexdigest()


def sha256(value: str) -> str:
    """Return the SHA-256 hex digest of *value*."""
    import hashlib
    return hashlib.sha256(value.encode()).hexdigest()


def hmac_sign(value: str, secret: str) -> str:
    """
    HMAC-SHA256 sign a string. Useful for webhook verification.

        signature = hmac_sign(payload, env('WEBHOOK_SECRET'))
    """
    import hmac as _hmac
    import hashlib
    return _hmac.new(secret.encode(), value.encode(), hashlib.sha256).hexdigest()


def hmac_verify(value: str, signature: str, secret: str) -> bool:
    """
    Verify an HMAC-SHA256 signature using a constant-time comparison.

        if not hmac_verify(payload, request_sig, env('WEBHOOK_SECRET')):
            abort(403)
    """
    import hmac as _hmac
    expected = hmac_sign(value, secret)
    return _hmac.compare_digest(expected, signature)


# ═════════════════════════════════════════════════════════════════════════════
# Numeric helpers (extended)
# ═════════════════════════════════════════════════════════════════════════════

def num_currency(value: float, symbol: str = "$", decimals: int = 2) -> str:
    """
    Format a number as currency.

        num_currency(1234.5)           # → '$1,234.50'
        num_currency(9500, 'KES ')     # → 'KES 9,500.00'
    """
    return f"{symbol}{num_format(value, decimals)}"


def num_percent(value: float, total: float, decimals: int = 1) -> str:
    """
    Calculate and format a percentage.

        num_percent(25, 200)   # → '12.5%'
    """
    if total == 0:
        return f"0{'.' + '0' * decimals if decimals else ''}%"
    pct = (value / total) * 100
    return f"{round(pct, decimals)}%"


def num_ordinal(n: int) -> str:
    """
    Return the ordinal string for an integer.

        num_ordinal(1)    # → '1st'
        num_ordinal(12)   # → '12th'
        num_ordinal(23)   # → '23rd'
    """
    if 11 <= (n % 100) <= 13:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suffix}"


# ═════════════════════════════════════════════════════════════════════════════
# Date / time helpers (extended)
# ═════════════════════════════════════════════════════════════════════════════

def now_iso() -> str:
    """Return the current UTC datetime as an ISO 8601 string."""
    return now().isoformat()


def diff_in_seconds(dt_a, dt_b=None) -> float:
    """
    Return absolute difference in seconds between two datetimes.
    If *dt_b* is omitted, compares *dt_a* against now().

        age = diff_in_seconds(user.created_at)
    """
    from datetime import datetime, timezone
    if dt_b is None:
        dt_b = now()
    if hasattr(dt_a, "tzinfo") and dt_a.tzinfo is None:
        dt_a = dt_a.replace(tzinfo=timezone.utc)
    if hasattr(dt_b, "tzinfo") and dt_b.tzinfo is None:
        dt_b = dt_b.replace(tzinfo=timezone.utc)
    return abs((dt_b - dt_a).total_seconds())


def human_time(seconds: float) -> str:
    """
    Convert a number of seconds to a human-readable duration string.

        human_time(90)      # → '1 minute 30 seconds'
        human_time(3661)    # → '1 hour 1 minute'
    """
    seconds = int(seconds)
    parts = []
    for unit, size in [("day", 86400), ("hour", 3600), ("minute", 60), ("second", 1)]:
        count, seconds = divmod(seconds, size)
        if count:
            parts.append(f"{count} {unit}{'s' if count > 1 else ''}")
    return " ".join(parts) if parts else "0 seconds"


# ═════════════════════════════════════════════════════════════════════════════
# File / path helpers
# ═════════════════════════════════════════════════════════════════════════════

def file_exists(*parts: str) -> bool:
    """
    Check whether a file exists at a path built from *parts*.

        file_exists('storage', 'uploads', 'logo.png')
    """
    return Path(*parts).exists()


def file_get(*parts: str) -> str:
    """
    Read the contents of a file as a string.

        contents = file_get('storage', 'data.json')
    """
    return Path(*parts).read_text(encoding="utf-8")


def file_put(path: str, contents: str, append: bool = False) -> int:
    """
    Write *contents* to *path*. Creates parent directories if needed.
    Returns bytes written.

        file_put('storage/data.txt', 'hello')
        file_put('storage/log.txt', 'line\\n', append=True)
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if append else "w"
    return p.write_text(contents, encoding="utf-8") if not append else (
        p.open("a", encoding="utf-8").write(contents)
    )


def file_extension(path: str) -> str:
    """
    Return the file extension without the dot.

        file_extension('avatar.png')   # → 'png'
    """
    return Path(path).suffix.lstrip(".")


def file_basename(path: str, with_extension: bool = True) -> str:
    """
    Return the filename from a path.

        file_basename('/uploads/photo.jpg')          # → 'photo.jpg'
        file_basename('/uploads/photo.jpg', False)   # → 'photo'
    """
    p = Path(path)
    return p.name if with_extension else p.stem


# ═════════════════════════════════════════════════════════════════════════════
# Module-context helpers
# These are thin wrappers that forward to the running engine so you can
# write bare bind(), override(), make() etc. inside module files instead of
# self.bind(), self.override(), self.make().
#
# Usage — inside register() / boot() / any module method:
#
#     from axon.core.helpers import bind, override, make, on, emit
#
#     def register(self) -> None:
#         bind(OrderService)              # same as self.bind(OrderService)
#         override(MailService, SendGrid) # same as self.override(...)
#
#     async def boot(self) -> None:
#         on("order.created", handle_order)
#
# IMPORTANT: these helpers resolve through the live engine — they are safe
# to use inside lifecycle methods (register/boot) but NOT at module import
# time before the engine has booted.
# ═════════════════════════════════════════════════════════════════════════════

def bind(name_or_type, cls=None, *, singleton: bool = True) -> None:
    """
    Register a service in the container. Module-context alias for self.bind().

        bind(OrderService)                  # key = class name
        bind(OrderService, singleton=False) # transient
        bind("order_svc", OrderService)     # explicit string key
        bind(IMailer, SMTPMailer)           # bind interface → implementation
    """
    _engine().container.bind(name_or_type, cls, singleton=singleton)


def override(name_or_type, cls=None, *, singleton: bool = True) -> None:
    """
    Replace another module's service. Module-context alias for self.override().

        override(MailService, ResendMailService)
    """
    _engine().container.override(name_or_type, cls, singleton=singleton)


def extend(name_or_type, extended_cls: type, *, singleton: bool = True) -> None:
    """
    Wrap an existing service with a subclass. Module-context alias for self.extend().

        extend(AuthService, OTPAuthService)
    """
    _engine().container.extend(name_or_type, extended_cls, singleton=singleton)


def instance(name: str, obj) -> None:
    """
    Register a pre-built object as a singleton. Module-context alias for self.instance().

        instance("redis_client", Redis(host=env("REDIS_HOST")))
    """
    _engine().container.instance(name, obj)


def has_binding(name_or_type) -> bool:
    """
    Check whether a service is registered in the container.

        if has_binding(CacheService):
            cache = make(CacheService)
    """
    return _engine().container.has(name_or_type)


def on(event: str, handler, *, priority: int = 100) -> None:
    """
    Subscribe to a platform event. Module-context alias for self.on().

        on("order.created", handle_order_created)
        on("platform.booted", lambda payload: Log.i("App", "ready"))
    """
    _engine().hooks.on(event, handler, priority=priority)


async def emit(event: str, payload=None) -> None:
    """
    Fire a platform event. Module-context alias for self.emit().

        await emit("order.shipped", {"order_id": order.id})
    """
    await _engine().hooks.emit(event, payload)


async def filter_event(event: str, value) -> any:
    """
    Run a value through the filter bus. Module-context alias for self.filter().

        price = await filter_event("order.price", base_price)
    """
    return await _engine().hooks.filter(event, value)


def dispatch(job_class, *, delay: float = 0, **kwargs) -> None:
    """
    Dispatch a background job. Module-context alias for self.dispatch().

        dispatch(SendWelcomeEmail, user_id=user["id"])
        dispatch(SendReminder, delay=3600, booking_id=booking["id"])
    """
    _engine().jobs.dispatch(job_class, delay=delay, **kwargs)


def schedule(cron: str, handler, *, name: str = "") -> None:
    """
    Register a cron-style scheduled task. Module-context alias for self.schedule().

        schedule("0 * * * *", cleanup_expired_tokens)
        schedule("*/5 * * * *", sync_exchange_rates, name="rate_sync")
    """
    _engine().scheduler.add(
        cron, handler,
        owner="",
        name=name or getattr(handler, "__name__", repr(handler)),
    )


# ═════════════════════════════════════════════════════════════════════════════
# Public API
# ═════════════════════════════════════════════════════════════════════════════

__all__ = [
    # env
    "env", "env_bool", "env_int", "env_list",
    # config
    "config", "config_set",
    # app / container
    "app", "make",
    # paths
    "base_path", "app_path", "storage_path", "public_path",
    "resource_path", "database_path",
    # strings (core)
    "str_slug", "str_snake", "str_camel", "str_pascal", "str_title",
    "str_plural", "str_singular", "str_truncate", "str_limit",
    "str_contains", "str_starts_with", "str_ends_with", "str_mask",
    # strings (extended)
    "str_random", "str_pad", "str_repeat", "str_between", "str_word_count",
    "str_upper", "str_lower", "str_replace", "str_wrap", "str_is",
    "str_uuid", "str_headline",
    # arrays (core)
    "arr_get", "arr_set", "arr_has", "arr_except", "arr_only",
    "arr_flatten", "arr_pluck", "arr_group_by", "arr_unique",
    "arr_first", "arr_last", "arr_chunk", "arr_where",
    # arrays (extended)
    "arr_sort", "arr_map", "arr_filter", "arr_zip",
    "arr_sum", "arr_avg", "arr_min", "arr_max",
    "arr_key_by", "arr_count_by", "arr_partition",
    "arr_diff", "arr_intersect", "arr_merge", "arr_deep_merge",
    # values
    "blank", "filled", "value_of", "optional", "tap", "once", "retry",
    # module-context (container + events + jobs)
    "bind", "override", "extend", "instance", "has_binding",
    "on", "emit", "filter_event", "dispatch", "schedule",
    # http / routing
    "abort", "url", "route",
    # security / hashing
    "bcrypt", "bcrypt_check", "hash_make", "hash_check",
    "md5", "sha256", "hmac_sign", "hmac_verify",
    # numeric (core)
    "num_clamp", "num_round", "num_format",
    # numeric (extended)
    "num_currency", "num_percent", "num_ordinal",
    # datetime (core)
    "now", "today", "timestamp",
    # datetime (extended)
    "now_iso", "diff_in_seconds", "human_time",
    # files
    "file_exists", "file_get", "file_put", "file_extension", "file_basename",
    # debug
    "dd", "dump",
]
