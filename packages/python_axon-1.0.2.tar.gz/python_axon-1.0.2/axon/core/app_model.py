# Backward-compat shim -- canonical location: axon.core.db.app_model
from axon.core.db.app_model import AppModel  # noqa: F401
