"""
Paginator
=========
Standard pagination for any SQLAlchemy query.
Produces a consistent response shape across all list endpoints.

Usage in a service
------------------
    from axon.core.db.paginator import Paginator

    class OrderService(BaseService):
        def list(self, page: int = 1, per_page: int = 20) -> dict:
            with self.db().session() as s:
                q = s.query(Order).order_by(Order.created_at.desc())
                return Paginator(q, page=page, per_page=per_page).paginate()

Usage in a route
----------------
    @router.get("/")
    async def list_orders(ctx: Context, svc: OrderService,
                          page: int = 1, per_page: int = 20):
        return svc.list(page=page, per_page=per_page)

Response shape
--------------
    {
        "items":    [...],
        "total":    100,
        "page":     1,
        "per_page": 20,
        "pages":    5,
        "has_next": true,
        "has_prev": false,
    }
"""
from __future__ import annotations
from typing import Any, Callable


class Paginator:
    DEFAULT_PER_PAGE = 20
    MAX_PER_PAGE     = 100

    def __init__(
        self,
        query,
        *,
        page: int      = 1,
        per_page: int  = DEFAULT_PER_PAGE,
        serializer: Callable[[Any], dict] | None = None,
    ) -> None:
        self._query      = query
        self.page        = max(1, page)
        self.per_page    = min(max(1, per_page), self.MAX_PER_PAGE)
        self._serializer = serializer

    def paginate(self) -> dict:
        total  = self._query.count()
        pages  = max(1, -(-total // self.per_page))          # ceil division
        offset = (self.page - 1) * self.per_page
        items  = self._query.offset(offset).limit(self.per_page).all()

        if self._serializer:
            items = [self._serializer(i) for i in items]
        else:
            items = [i.to_dict() if hasattr(i, "to_dict") else i for i in items]

        return {
            "items":    items,
            "total":    total,
            "page":     self.page,
            "per_page": self.per_page,
            "pages":    pages,
            "has_next": self.page < pages,
            "has_prev": self.page > 1,
        }
