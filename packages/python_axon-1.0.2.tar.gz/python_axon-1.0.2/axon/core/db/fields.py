"""
Platform Field Types
====================
Every field type a module model will ever need, exposed as plain
platform primitives.  SQLAlchemy is an implementation detail —
module builders never import or see it.

Module usage
------------
    from axon.core.app_model import AppModel
    from axon.core.fields import (
        StringField, TextField, IntField, FloatField,
        BoolField, DateTimeField, DateField, JSONField,
        ForeignKey, Relationship,
    )

    class Post(AppModel):
        title   = StringField(max_length=255, required=True, index=True)
        body    = TextField()
        views   = IntField(default=0)
        rating  = FloatField(nullable=True)
        active  = BoolField(default=True)
        meta    = JSONField(nullable=True)
        user_id = ForeignKey("users.id")
        user    = Relationship("User", back="posts")

Field reference
---------------
StringField(max_length=255, *, required=False, default=None,
            index=False, unique=False, nullable=True)
    → VARCHAR(max_length)

TextField(*, required=False, default=None, nullable=True)
    → TEXT

IntField(*, required=False, default=None,
         index=False, unique=False, nullable=True)
    → INTEGER

BigIntField(...)   → BIGINT
FloatField(...)    → FLOAT
DecimalField(precision=10, scale=2, ...)  → NUMERIC(p, s)

BoolField(*, default=False, required=False, nullable=False)
    → BOOLEAN

DateTimeField(*, auto_now=False, auto_now_add=False,
              required=False, default=None, nullable=True)
    auto_now     — update to UTC now on every save
    auto_now_add — set to UTC now on first insert only

DateField(...)     → DATE
TimeField(...)     → TIME
UUIDField(*, primary_key=False, default_uuid4=True, ...)  → UUID / CHAR(36)
EmailField(*)      → VARCHAR(254) — same as StringField but documents intent
SlugField(*)       → VARCHAR(255) — same but documents intent
PasswordField(*)   → VARCHAR(255) — same but documents intent

JSONField(*, required=False, default=None, nullable=True)
    → JSON (Postgres) / TEXT (SQLite/MySQL, auto serialised)

ChoiceField(choices, max_length=50, ...)
    choices — list of str values or list of (value, label) tuples
    → VARCHAR validated against choices at the Python level

ForeignKey(target, *, nullable=True, index=True, on_delete="CASCADE")
    target — "table_name.column"  e.g.  "users.id"
    → INTEGER column + FK constraint

Relationship(model_name, *, back=None, lazy="select")
    → SQLAlchemy relationship() — navigation only, no column created
"""

from __future__ import annotations

from datetime import datetime, date, time, timezone
from decimal import Decimal
from typing import Any, Sequence
import uuid as _uuid_mod

from sqlalchemy import (
    BigInteger,
    Boolean,
    Column,
    Date,
    DateTime,
    Float,
    Integer,
    JSON,
    Numeric,
    String,
    Text,
    Time,
    ForeignKey as _SAForeignKey,
)
from sqlalchemy.orm import relationship as _relationship


# ──────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ──────────────────────────────────────────────────────────────────────────────

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _col(sa_type, *, required: bool, default, nullable: bool,
         index: bool = False, unique: bool = False,
         primary_key: bool = False, **extra) -> Column:
    """Translate platform kwargs to a SQLAlchemy Column."""
    # required=True → nullable=False and no server default
    # If caller explicitly sets nullable it wins over required
    is_nullable = not required if nullable is None else nullable
    return Column(
        sa_type,
        nullable=is_nullable,
        default=default,
        index=index,
        unique=unique,
        primary_key=primary_key,
        **extra,
    )


# ──────────────────────────────────────────────────────────────────────────────
# String / text
# ──────────────────────────────────────────────────────────────────────────────

def StringField(
    max_length: int = 255,
    *,
    required: bool = False,
    default: str | None = None,
    index: bool = False,
    unique: bool = False,
    nullable: bool | None = None,
) -> Column:
    """Variable-length string. Defaults to VARCHAR(255)."""
    return _col(String(max_length), required=required, default=default,
                nullable=True if nullable is None else nullable,
                index=index, unique=unique)


def TextField(
    *,
    required: bool = False,
    default: str | None = None,
    nullable: bool = True,
) -> Column:
    """Unlimited text. Use for bodies, descriptions, long content."""
    return _col(Text, required=required, default=default, nullable=nullable)


def EmailField(
    *,
    required: bool = False,
    default: str | None = None,
    index: bool = False,
    unique: bool = False,
    nullable: bool | None = None,
) -> Column:
    """VARCHAR(254) — semantically an email address."""
    return _col(String(254), required=required, default=default,
                nullable=True if nullable is None else nullable,
                index=index, unique=unique)


def SlugField(
    max_length: int = 255,
    *,
    required: bool = False,
    default: str | None = None,
    index: bool = True,
    unique: bool = False,
    nullable: bool | None = None,
) -> Column:
    """VARCHAR(255) — URL-safe slug. Indexed by default."""
    return _col(String(max_length), required=required, default=default,
                nullable=True if nullable is None else nullable,
                index=index, unique=unique)


def PasswordField(
    *,
    required: bool = False,
    nullable: bool = False,
) -> Column:
    """VARCHAR(255) — hashed password storage."""
    return _col(String(255), required=required, default=None, nullable=nullable)


# ──────────────────────────────────────────────────────────────────────────────
# Numeric
# ──────────────────────────────────────────────────────────────────────────────

def IntField(
    *,
    required: bool = False,
    default: int | None = None,
    index: bool = False,
    unique: bool = False,
    nullable: bool | None = None,
) -> Column:
    """Standard 32-bit integer."""
    return _col(Integer, required=required, default=default,
                nullable=True if nullable is None else nullable,
                index=index, unique=unique)


def BigIntField(
    *,
    required: bool = False,
    default: int | None = None,
    index: bool = False,
    unique: bool = False,
    nullable: bool | None = None,
) -> Column:
    """64-bit integer. Use for counters, large IDs, snowflakes."""
    return _col(BigInteger, required=required, default=default,
                nullable=True if nullable is None else nullable,
                index=index, unique=unique)


def FloatField(
    *,
    required: bool = False,
    default: float | None = None,
    nullable: bool | None = None,
) -> Column:
    """Floating-point number. Not suitable for currency — use DecimalField."""
    return _col(Float, required=required, default=default,
                nullable=True if nullable is None else nullable)


def DecimalField(
    precision: int = 10,
    scale: int = 2,
    *,
    required: bool = False,
    default: Decimal | None = None,
    nullable: bool | None = None,
) -> Column:
    """
    Fixed-precision decimal. Suitable for prices, balances, measurements.
    precision — total digits;  scale — digits after decimal point.
    """
    return _col(Numeric(precision=precision, scale=scale),
                required=required, default=default,
                nullable=True if nullable is None else nullable)


# ──────────────────────────────────────────────────────────────────────────────
# Boolean
# ──────────────────────────────────────────────────────────────────────────────

def BoolField(
    *,
    default: bool = False,
    required: bool = False,
    nullable: bool = False,
) -> Column:
    """Boolean true/false. Defaults to False, not nullable."""
    return _col(Boolean, required=required, default=default, nullable=nullable)


# ──────────────────────────────────────────────────────────────────────────────
# Date / time
# ──────────────────────────────────────────────────────────────────────────────

def DateTimeField(
    *,
    auto_now: bool = False,
    auto_now_add: bool = False,
    required: bool = False,
    default: datetime | None = None,
    nullable: bool = True,
) -> Column:
    """
    Timezone-aware datetime.

    auto_now_add=True  — set to UTC now on INSERT (like Django's auto_now_add)
    auto_now=True      — update to UTC now on every UPDATE
    """
    _default  = _utcnow if auto_now_add else default
    _onupdate = _utcnow if auto_now     else None
    return Column(
        DateTime(timezone=True),
        default=_default,
        onupdate=_onupdate,
        nullable=nullable,
    )


def DateField(
    *,
    required: bool = False,
    default: date | None = None,
    nullable: bool = True,
) -> Column:
    """Calendar date (no time component)."""
    return _col(Date, required=required, default=default, nullable=nullable)


def TimeField(
    *,
    required: bool = False,
    default: time | None = None,
    nullable: bool = True,
) -> Column:
    """Wall-clock time (no date component)."""
    return _col(Time, required=required, default=default, nullable=nullable)


# ──────────────────────────────────────────────────────────────────────────────
# UUID
# ──────────────────────────────────────────────────────────────────────────────

def UUIDField(
    *,
    primary_key: bool = False,
    default_uuid4: bool = True,
    required: bool = False,
    index: bool = False,
    unique: bool = False,
    nullable: bool | None = None,
) -> Column:
    """
    UUID stored as a native UUID type (Postgres) or CHAR(36) (SQLite/MySQL).
    Generates a UUID4 by default.
    """
    try:
        # Use native UUID type on Postgres
        from sqlalchemy.dialects.postgresql import UUID as _PGUUID
        sa_type = _PGUUID(as_uuid=True)
    except ImportError:
        # Fallback: store as string
        sa_type = String(36)

    _default = _uuid_mod.uuid4 if default_uuid4 else None
    return Column(
        sa_type,
        primary_key=primary_key,
        default=_default,
        nullable=False if primary_key else (True if nullable is None else nullable),
        index=index,
        unique=unique or primary_key,
    )


# ──────────────────────────────────────────────────────────────────────────────
# JSON
# ──────────────────────────────────────────────────────────────────────────────

def JSONField(
    *,
    required: bool = False,
    default: Any = None,
    nullable: bool = True,
) -> Column:
    """
    JSON column. Native JSON on Postgres; TEXT with auto-serialisation on
    SQLite and MySQL (handled transparently by SQLAlchemy).
    """
    return _col(JSON, required=required,
                default=default if default is not None else (dict if not nullable else None),
                nullable=nullable)


# ──────────────────────────────────────────────────────────────────────────────
# Choice / enum
# ──────────────────────────────────────────────────────────────────────────────

def ChoiceField(
    choices: Sequence[str | tuple[str, str]],
    max_length: int = 50,
    *,
    required: bool = False,
    default: str | None = None,
    nullable: bool | None = None,
) -> Column:
    """
    VARCHAR column constrained to a set of allowed values.

    choices can be:
        ["draft", "published", "archived"]
        [("draft", "Draft"), ("published", "Published")]   ← (value, label)

    Validation happens at the Python level (via a SQLAlchemy event).
    No database ENUM type is created, keeping migrations simple.
    """
    # Normalise to list of string values
    values = [c if isinstance(c, str) else c[0] for c in choices]

    col = _col(String(max_length), required=required, default=default,
               nullable=True if nullable is None else nullable)

    # Attach the valid values as metadata so validators can read them
    col.info["choices"] = values
    return col


# ──────────────────────────────────────────────────────────────────────────────
# Relationships
# ──────────────────────────────────────────────────────────────────────────────

def ForeignKey(
    target: str,
    *,
    nullable: bool = True,
    index: bool = True,
    on_delete: str = "CASCADE",
) -> Column:
    """
    Integer FK column pointing at *target* (format: "table_name.column").

    Example
    -------
        author_id = ForeignKey("users.id")
    """
    return Column(
        Integer,
        _SAForeignKey(target, ondelete=on_delete),
        nullable=nullable,
        index=index,
    )


def Relationship(
    model: str,
    *,
    back: str | None = None,
    lazy: str = "select",
) -> Any:
    """
    Declare a navigation relationship to another model.
    Does NOT create a database column — pair with a ForeignKey.

    Parameters
    ----------
    model : str   Target model class name, e.g. "User"
    back  : str   Name of the reverse attribute on the target model
    lazy  : str   SQLAlchemy loading strategy: "select", "joined", "subquery", "dynamic"

    Example
    -------
        author_id = ForeignKey("users.id")
        author    = Relationship("User", back="posts")
    """
    kwargs: dict[str, Any] = {"lazy": lazy}
    if back:
        kwargs["back_populates"] = back
    return _relationship(model, **kwargs)
