"""
Migration Runner
================
Owns the SQLAlchemy engine and session factory.
Auto-discovers every AppModel subclass across all loaded modules,
then delegates ALL schema management to Alembic.

Modules never create engines, sessions, or migration files.
manage.py is the only CLI surface for Alembic commands.

Boot flow (called by AppEngine):
    runner.configure(database_url, engine_options)
    runner.discover_models(modules_root)   <- imports every module's models.py
    runner.run_migrations()                <- alembic upgrade head

Supported databases (install the matching driver):
    SQLite     sqlite:///./platform.db              (built-in, default)
    PostgreSQL postgresql://user:pass@host/db        pip install psycopg2-binary
    MySQL      mysql+pymysql://user:pass@host/db     pip install pymysql
    MariaDB    mariadb+pymysql://user:pass@host/db   pip install pymysql
    MS SQL     mssql+pyodbc://user:pass@host/db      pip install pyodbc
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker

logger = logging.getLogger(__name__)

import os
ALEMBIC_CFG_PATH = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd())) / "alembic.ini"


# ──────────────────────────────────────────────────────────────────────────────
# Database URL builder
# Translates the structured config.yaml database: block into a SQLAlchemy URL.
# ──────────────────────────────────────────────────────────────────────────────

_ENGINE_DEFAULTS: dict[str, tuple[str, int]] = {
    "sqlite":       ("",          0),
    "postgresql":   ("psycopg2",  5432),
    "postgres":     ("psycopg2",  5432),   # alias
    "mysql":        ("pymysql",   3306),
    "mariadb":      ("pymysql",   3306),
    "mssql":        ("pyodbc",    1433),
    "oracle":       ("cx_oracle", 1521),
}


def _build_database_url(
    engine:   str,
    name:     str  = "./platform.db",
    host:     str  = "localhost",
    port:     Any  = None,
    user:     str  = "",
    password: str  = "",
    driver:   str  = "",
) -> str:
    """
    Build a SQLAlchemy connection URL from individual config values.

    Examples:
        _build_database_url("sqlite", name="./platform.db")
        # → sqlite:///./platform.db

        _build_database_url("postgresql", name="mydb", host="localhost",
                            user="root", password="secret")
        # → postgresql+psycopg2://root:secret@localhost:5432/mydb

        _build_database_url("mysql", name="shop", host="db.host",
                            port=3307, user="admin", password="pw",
                            driver="pymysql")
        # → mysql+pymysql://admin:pw@db.host:3307/shop
    """
    engine = engine.lower().strip()

    if engine in ("sqlite", "sqlite3"):
        return f"sqlite:///{name}"

    default_driver, default_port = _ENGINE_DEFAULTS.get(engine, ("", 5432))
    resolved_driver = (driver or default_driver).strip()
    resolved_port   = int(port) if port else default_port
    dialect         = f"{engine}+{resolved_driver}" if resolved_driver else engine

    if user and password:
        from urllib.parse import quote_plus
        safe_pw = quote_plus(str(password))
        return f"{dialect}://{user}:{safe_pw}@{host}:{resolved_port}/{name}"
    elif user:
        return f"{dialect}://{user}@{host}:{resolved_port}/{name}"
    else:
        return f"{dialect}://{host}:{resolved_port}/{name}"


class MigrationRunner:
    """
    Manages the database engine, sessions, and Alembic migrations.

    All schema changes go through Alembic.
    create_all is intentionally not used in production paths.
    """

    def __init__(self) -> None:
        self._engine = None
        self._session_factory = None
        self._database_url: str = "sqlite:///./platform.db"

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def configure(self, database_url: str, *, echo: bool = False, **pool_kwargs) -> None:
        """
        Build the SQLAlchemy engine and session factory.

        pool_kwargs are passed directly to create_engine — useful for tuning:
            pool_size, max_overflow, pool_timeout (ignored for SQLite).
        """
        connect_args: dict[str, Any] = {}
        if database_url.startswith("sqlite"):
            connect_args["check_same_thread"] = False
            # SQLite does not support pool_size / max_overflow
            pool_kwargs = {}

        self._database_url = database_url
        self._engine = create_engine(
            database_url,
            connect_args=connect_args,
            echo=echo,
            pool_pre_ping=True,
            **pool_kwargs,
        )
        self._session_factory = sessionmaker(
            bind=self._engine,
            autocommit=False,
            autoflush=False,
        )
        logger.info("MigrationRunner: engine configured -> %s", _sanitize_url(database_url))

    def configure_from_config(self, cfg) -> None:
        """
        Build the database URL from the structured config.yaml database: block.
        Falls back to the flat database_url string for backward compat.

        config.yaml structured form:
            platform:
              database:
                engine:   postgresql     # sqlite | postgresql | mysql | mariadb | mssql
                name:     mydb           # file path for sqlite, db name for others
                host:     localhost
                port:     5432           # null = use engine default
                user:     myuser
                password: secret
                driver:   ""             # optional: psycopg2, pymysql, pyodbc …
                echo:     false
                pool_size:    5
                max_overflow: 10
                pool_timeout: 30

        Env-var overrides (standard double-underscore convention):
            PLATFORM__DATABASE__ENGINE=postgresql
            PLATFORM__DATABASE__HOST=db.prod.internal
            PLATFORM__DATABASE__PASSWORD=s3cret
        """
        # Flat URL takes priority — backward compat for existing projects
        flat_url = cfg.get("platform.database_url", None)
        if flat_url:
            self.configure(flat_url)
            return

        url = _build_database_url(
            engine   = cfg.get("platform.database.engine",   "sqlite"),
            name     = cfg.get("platform.database.name",     "./platform.db"),
            host     = cfg.get("platform.database.host",     "localhost"),
            port     = cfg.get("platform.database.port",     None),
            user     = cfg.get("platform.database.user",     ""),
            password = cfg.get("platform.database.password", ""),
            driver   = cfg.get("platform.database.driver",   ""),
        )

        echo = bool(cfg.get("platform.database.echo", False))

        pool_kwargs: dict = {}
        for key in ("pool_size", "max_overflow", "pool_timeout"):
            val = cfg.get(f"platform.database.{key}", None)
            if val is not None:
                pool_kwargs[key] = int(val)

        self.configure(url, echo=echo, **pool_kwargs)

    # ------------------------------------------------------------------
    # Model discovery
    # ------------------------------------------------------------------

    def discover_models(self, modules_root: Path) -> None:
        """
        Walk every sub-package of *modules_root* and import any models.py
        found there.  Importing is enough — SQLAlchemy registers every
        AppModel subclass in the shared metadata, making them visible to
        Alembic's autogenerate comparison in env.py.
        """
        if not modules_root.is_dir():
            logger.warning("MigrationRunner: modules root not found: %s", modules_root)
            return

        for _finder, pkg_name, _is_pkg in pkgutil.walk_packages(
            path=[str(modules_root)],
            prefix="app.modules.",
            onerror=lambda name: logger.warning("MigrationRunner: scan error in %s", name),
        ):
            if pkg_name.endswith(".models"):
                try:
                    importlib.import_module(pkg_name)
                    logger.debug("MigrationRunner: imported %s", pkg_name)
                except Exception:
                    logger.exception("MigrationRunner: failed to import %s", pkg_name)

        from axon.core.db.app_model import metadata
        table_names = sorted(metadata.tables.keys())
        logger.info(
            "MigrationRunner: %d table(s) registered — %s",
            len(table_names),
            table_names,
        )

    # ------------------------------------------------------------------
    # Migrations  (Alembic-only)
    # ------------------------------------------------------------------

    def create_all_for_testing(self) -> None:
        """
        Create all registered tables directly via SQLAlchemy metadata.
        USE ONLY IN TESTS — bypasses Alembic, no migration history.
        Called automatically by PlatformTestCase setup.
        """
        if self._engine is None:
            raise RuntimeError("Call configure() before create_all_for_testing()")
        from axon.core.db.app_model import metadata
        metadata.create_all(self._engine)
        logger.debug("MigrationRunner: create_all_for_testing — tables created")

    def run_migrations(self) -> None:
        """
        Apply all pending Alembic migrations (upgrade head).
        Called automatically by AppEngine on every boot.
        Safe to run repeatedly — Alembic is idempotent.
        """
        if self._engine is None:
            raise RuntimeError("Call configure() before run_migrations()")

        if not ALEMBIC_CFG_PATH.exists():
            raise FileNotFoundError(
                f"alembic.ini not found at {ALEMBIC_CFG_PATH}. "
                "Run: python manage.py migrate  to initialise Alembic."
            )

        try:
            from alembic import command
            cfg = _make_alembic_config(self._database_url)
            command.upgrade(cfg, "head")
            logger.info("MigrationRunner: schema is up to date (alembic upgrade head)")
        except Exception:
            logger.exception("MigrationRunner: migration failed")
            raise

    # ------------------------------------------------------------------
    # Session access
    # ------------------------------------------------------------------

    @contextmanager
    def session(self) -> Generator[Session, None, None]:
        """
        Context-manager session — commits on clean exit, rolls back on error.

            with db.session() as s:
                s.add(obj)
        """
        if self._session_factory is None:
            raise RuntimeError("Call configure() before requesting sessions")
        db: Session = self._session_factory()
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def raw_session(self) -> Session:
        """
        Bare Session — caller is responsible for commit/rollback/close.
        Prefer the context-manager form for routine use.
        """
        if self._session_factory is None:
            raise RuntimeError("Call configure() before requesting sessions")
        return self._session_factory()

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def ping(self) -> bool:
        """Return True if the database is reachable."""
        if self._engine is None:
            return False
        try:
            with self._engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return True
        except Exception:
            return False

    def dispose(self) -> None:
        """Release all pooled connections. Called by AppEngine on shutdown."""
        if self._engine:
            self._engine.dispose()
            logger.info("MigrationRunner: engine disposed")

    @property
    def database_url(self) -> str:
        return self._database_url


# ------------------------------------------------------------------
# Shared Alembic config factory
# Used by MigrationRunner AND manage.py so both always agree on paths.
# ------------------------------------------------------------------

def _make_alembic_config(database_url: str | None = None):
    """
    Build an Alembic Config pointing at alembic.ini.
    Optionally overrides sqlalchemy.url in-process (no file mutation).
    """
    from alembic.config import Config as AlembicConfig
    cfg = AlembicConfig(str(ALEMBIC_CFG_PATH))
    if database_url:
        cfg.set_main_option("sqlalchemy.url", database_url)
    return cfg


def _sanitize_url(url: str) -> str:
    """Strip password from URLs before logging."""
    if "@" in url:
        scheme, rest = url.split("://", 1)
        credentials, host = rest.split("@", 1)
        user = credentials.split(":")[0]
        return f"{scheme}://{user}:***@{host}"
    return url
