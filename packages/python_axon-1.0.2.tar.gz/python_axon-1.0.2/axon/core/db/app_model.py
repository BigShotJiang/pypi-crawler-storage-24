"""
AppModel — Base Database Model
================================
All module models extend this class. SQLAlchemy is a platform concern —
module builders never import from it directly.

Module usage
------------
    from axon.core.app_model import AppModel
    from axon.core.fields import StringField, TextField, BoolField, ForeignKey

    class Post(AppModel):
        title   = StringField(max_length=255, required=True, index=True)
        body    = TextField()
        active  = BoolField(default=True)

That is the complete import surface for a model file.
No sqlalchemy, no Column, no String, no Integer — ever.

Provided automatically (no need to declare)
-------------------------------------------
    id         IntField  — auto-increment primary key
    created_at DateTimeField(auto_now_add=True)
    updated_at DateTimeField(auto_now=True)
    __tablename__         — auto-derived from class name (snake_case)
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Integer
from sqlalchemy.orm import DeclarativeBase, declared_attr

# Re-export fields so modules can optionally do:
#   from axon.core.app_model import AppModel, StringField, ...
# (but the canonical import is from axon.core.fields)
from axon.core.fields import (  # noqa: F401  — re-exported for convenience
    BigIntField,
    BoolField,
    ChoiceField,
    DateField,
    DateTimeField,
    DecimalField,
    EmailField,
    FloatField,
    ForeignKey,
    IntField,
    JSONField,
    PasswordField,
    Relationship,
    SlugField,
    StringField,
    TextField,
    TimeField,
    UUIDField,
)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class _Base(DeclarativeBase):
    """SQLAlchemy declarative base — internal, never import directly."""


class AppModel(_Base):
    """
    Abstract base for every module model.

    Automatically provides:
      - __tablename__  derived from class name  (PostTag → post_tag)
      - id             auto-increment integer primary key
      - created_at     UTC timestamp set on insert
      - updated_at     UTC timestamp updated on every save

    Override __tablename__ in your model only if you need a custom table name.
    """

    __abstract__ = True

    @declared_attr.directive
    @classmethod
    def __tablename__(cls) -> str:  # type: ignore[override]
        s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", cls.__name__)
        return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

    id = Column(Integer, primary_key=True, autoincrement=True, index=True)

    created_at = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=_utcnow,
                        onupdate=_utcnow, nullable=False)

    def to_dict(self) -> dict:
        """Serialise all columns to a plain dict."""
        return {col.name: getattr(self, col.name) for col in self.__table__.columns}

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} id={self.id!r}>"


# Migration runner reads this to find all registered tables
metadata = _Base.metadata
