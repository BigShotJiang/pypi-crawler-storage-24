"""
Configuration Manager
=====================
Loads the root platform config (config.yaml / .env) then merges
each module's declared config schema on top.

Access pattern (from anywhere):
    app.config("example_module.database_url")
    app.config("platform.debug", default=False)

Modules never read os.environ or open files themselves.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import dotenv_values

logger = logging.getLogger(__name__)

# Sentinel so we can distinguish "key missing" from "value is None"
_MISSING = object()


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base* (non-destructive to base)."""
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _flatten(d: dict, prefix: str = "") -> dict[str, Any]:
    """Flatten {'a': {'b': 1}} → {'a.b': 1}"""
    items: dict[str, Any] = {}
    for k, v in d.items():
        full_key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            items.update(_flatten(v, full_key))
        else:
            items[full_key] = v
    return items


class ConfigManager:
    """
    Two-phase config loader:

    Phase 1 — Platform boot:
        load_root(config_yaml, env_file)
        Reads config.yaml and .env, stores under the 'platform' namespace.

    Phase 2 — Module loading:
        merge_module_config(module_name, schema_dict, env_overrides)
        Called by the loader for each module after it reads the module's
        config.py.  The module's defaults are merged, then any matching
        env vars (MODULE_NAME__KEY) override them.

    Internal storage is a nested dict tree; lookups use dot-notation keys.
    """

    def __init__(self) -> None:
        self._tree: dict[str, Any] = {}
        self._flat: dict[str, Any] = {}   # rebuilt on every merge
        self._env_values: dict[str, Any] = {}  # cached env + .env values

    # ------------------------------------------------------------------
    # Phase 1 — Root load
    # ------------------------------------------------------------------

    def load_root(
        self,
        config_yaml: Path | None = None,
        env_file: Path | None = None,
    ) -> None:
        root: dict[str, Any] = {}

        # 1. Read config.yaml
        if config_yaml and config_yaml.exists():
            with config_yaml.open() as fh:
                data = yaml.safe_load(fh) or {}
            root = _deep_merge(root, data)
            logger.debug("ConfigManager: loaded %s", config_yaml)

        # 2. Read .env file
        env_values: dict[str, Any] = {}
        if env_file and env_file.exists():
            env_values = dict(dotenv_values(env_file))  # type: ignore[arg-type]
            logger.debug("ConfigManager: loaded %s (%d keys)", env_file, len(env_values))

        # 3. Merge real env vars on top (real env wins over .env file)
        env_values.update(os.environ)
        
        # Cache for module config merging
        self._env_values = env_values

        # 4. Map PLATFORM__KEY=value → platform.key
        for raw_key, value in env_values.items():
            if "__" in raw_key:
                parts = raw_key.lower().split("__")
                self._set_nested(root, parts, value)

        self._tree = root
        self._rebuild_flat()
        logger.info("ConfigManager: root config loaded (%d flat keys)", len(self._flat))

    # ------------------------------------------------------------------
    # Phase 2 — Module schema merging
    # ------------------------------------------------------------------

    def merge_module_config(
        self,
        module_name: str,
        defaults: dict[str, Any],
    ) -> None:
        """
        Merge a module's default config tree under its namespace,
        then apply env-var overrides shaped MODULE_NAME__KEY=value.
        """
        # Start from module defaults
        merged: dict[str, Any] = dict(defaults)

        # Apply env overrides: EXAMPLE_MODULE__DB_URL → example_module.db_url
        prefix = module_name.upper() + "__"
        for raw_key, value in self._env_values.items():
            if raw_key.startswith(prefix):
                sub_key = raw_key[len(prefix):].lower()
                parts = sub_key.split("__")
                self._set_nested(merged, parts, value)

        # Slot under module namespace in the tree
        if module_name not in self._tree:
            self._tree[module_name] = {}
        self._tree[module_name] = _deep_merge(self._tree[module_name], merged)
        self._rebuild_flat()
        logger.debug(
            "ConfigManager: merged config for module '%s'", module_name
        )

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = _MISSING) -> Any:
        """
        Retrieve a value by dot-notation key.

        Raises KeyError if key is missing and no default is given.
        """
        value = self._flat.get(key, _MISSING)
        if value is _MISSING:
            if default is _MISSING:
                raise KeyError(
                    f"Config key '{key}' not found. "
                    f"Available top-level namespaces: {sorted(self._tree)}"
                )
            return default
        return value

    def namespace(self, prefix: str) -> dict[str, Any]:
        """Return all keys under a given namespace as a flat dict."""
        dot_prefix = prefix.rstrip(".") + "."
        return {
            k[len(dot_prefix):]: v
            for k, v in self._flat.items()
            if k.startswith(dot_prefix)
        }

    def as_dict(self) -> dict[str, Any]:
        """Return a deep copy of the full config tree."""
        import copy
        return copy.deepcopy(self._tree)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _set_nested(self, target: dict, parts: list[str], value: Any) -> None:
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        target[parts[-1]] = value

    def _rebuild_flat(self) -> None:
        self._flat = _flatten(self._tree)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<ConfigManager namespaces={sorted(self._tree)}>"
