"""
Migration Runner
================
Owns the SQLAlchemy engine and session factory.
Auto-discovers every AppModel subclass across all loaded modules,
then delegates ALL schema management to Alembic.

Modules never create engines, sessions, or migration files.
manage.py is the only CLI surface for Alembic commands.

Boot flow (called by AppEngine):
    runner.configure(database_url)
    runner.discover_models(modules_root)   <- imports every module's models.py
    runner.run_migrations()                <- alembic upgrade head
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker

logger = logging.getLogger(__name__)

# Canonical path to alembic.ini — two levels up: app/core/ -> app/ -> project root
_PROJECT_ROOT = Path(__file__).parent.parent.parent
ALEMBIC_CFG_PATH = _PROJECT_ROOT / "alembic.ini"


class MigrationRunner:
    """
    Manages the database engine, sessions, and Alembic migrations.

    All schema changes go through Alembic.
    create_all is intentionally not used in production paths.
    """

    def __init__(self) -> None:
        self._engine = None
        self._session_factory = None
        self._database_url: str = "sqlite:///./platform.db"

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def configure(self, database_url: str) -> None:
        """Build the engine and session factory from *database_url*."""
        connect_args: dict[str, Any] = {}
        if database_url.startswith("sqlite"):
            connect_args["check_same_thread"] = False

        self._database_url = database_url
        self._engine = create_engine(
            database_url,
            connect_args=connect_args,
            echo=False,
            pool_pre_ping=True,
        )
        self._session_factory = sessionmaker(
            bind=self._engine,
            autocommit=False,
            autoflush=False,
        )
        logger.info("MigrationRunner: engine configured -> %s", _sanitize_url(database_url))

    # ------------------------------------------------------------------
    # Model discovery
    # ------------------------------------------------------------------

    def discover_models(self, modules_root: Path) -> None:
        """
        Walk every sub-package of *modules_root* and import any models.py
        found there.  Importing is enough — SQLAlchemy registers every
        AppModel subclass in the shared metadata, making them visible to
        Alembic's autogenerate comparison in env.py.
        """
        if not modules_root.is_dir():
            logger.warning("MigrationRunner: modules root not found: %s", modules_root)
            return

        for _finder, pkg_name, _is_pkg in pkgutil.walk_packages(
            path=[str(modules_root)],
            prefix="app.modules.",
            onerror=lambda name: logger.warning("MigrationRunner: scan error in %s", name),
        ):
            if pkg_name.endswith(".models"):
                try:
                    importlib.import_module(pkg_name)
                    logger.debug("MigrationRunner: imported %s", pkg_name)
                except Exception:
                    logger.exception("MigrationRunner: failed to import %s", pkg_name)

        from axon.core.db.app_model import metadata
        table_names = sorted(metadata.tables.keys())
        logger.info(
            "MigrationRunner: %d table(s) registered — %s",
            len(table_names),
            table_names,
        )

    # ------------------------------------------------------------------
    # Migrations  (Alembic-only)
    # ------------------------------------------------------------------

    def run_migrations(self) -> None:
        """
        Apply all pending Alembic migrations (upgrade head).
        Called automatically by AppEngine on every boot.
        Safe to run repeatedly — Alembic is idempotent.
        """
        if self._engine is None:
            raise RuntimeError("Call configure() before run_migrations()")

        if not ALEMBIC_CFG_PATH.exists():
            raise FileNotFoundError(
                f"alembic.ini not found at {ALEMBIC_CFG_PATH}. "
                "Run: python manage.py migrate  to initialise Alembic."
            )

        try:
            from alembic import command
            cfg = _make_alembic_config(self._database_url)
            command.upgrade(cfg, "head")
            logger.info("MigrationRunner: schema is up to date (alembic upgrade head)")
        except Exception:
            logger.exception("MigrationRunner: migration failed")
            raise

    # ------------------------------------------------------------------
    # Session access
    # ------------------------------------------------------------------

    @contextmanager
    def session(self) -> Generator[Session, None, None]:
        """
        Context-manager session — commits on clean exit, rolls back on error.

            with db.session() as s:
                s.add(obj)
        """
        if self._session_factory is None:
            raise RuntimeError("Call configure() before requesting sessions")
        db: Session = self._session_factory()
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def raw_session(self) -> Session:
        """
        Bare Session — caller is responsible for commit/rollback/close.
        Prefer the context-manager form for routine use.
        """
        if self._session_factory is None:
            raise RuntimeError("Call configure() before requesting sessions")
        return self._session_factory()

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def ping(self) -> bool:
        """Return True if the database is reachable."""
        if self._engine is None:
            return False
        try:
            with self._engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return True
        except Exception:
            return False

    def dispose(self) -> None:
        """Release all pooled connections. Called by AppEngine on shutdown."""
        if self._engine:
            self._engine.dispose()
            logger.info("MigrationRunner: engine disposed")

    @property
    def database_url(self) -> str:
        return self._database_url


# ------------------------------------------------------------------
# Shared Alembic config factory
# Used by MigrationRunner AND manage.py so both always agree on paths.
# ------------------------------------------------------------------

def _make_alembic_config(database_url: str | None = None):
    """
    Build an Alembic Config pointing at alembic.ini.
    Optionally overrides sqlalchemy.url in-process (no file mutation).
    """
    from alembic.config import Config as AlembicConfig
    cfg = AlembicConfig(str(ALEMBIC_CFG_PATH))
    if database_url:
        cfg.set_main_option("sqlalchemy.url", database_url)
    return cfg


def _sanitize_url(url: str) -> str:
    """Strip password from URLs before logging."""
    if "@" in url:
        scheme, rest = url.split("://", 1)
        credentials, host = rest.split("@", 1)
        user = credentials.split(":")[0]
        return f"{scheme}://{user}:***@{host}"
    return url
