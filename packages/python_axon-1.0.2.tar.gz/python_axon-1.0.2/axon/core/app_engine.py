# Backward-compat shim -- canonical location: axon.core.engine.app_engine
from axon.core.engine.app_engine import AppEngine, _engine_instance  # noqa: F401
