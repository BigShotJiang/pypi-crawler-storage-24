"""
Platform Logger  —  Log
=======================
Android-style logging API. Module builders never touch Python's logging
module directly — they use Log.d(), Log.i(), Log.w(), Log.e(), Log.wtf().

The platform controls:
  - Log level globally (via config  platform.log_level)
  - Per-tag level overrides         (via config  platform.log_tags.MY_TAG=DEBUG)
  - Output format
  - Colour in terminals

Module usage
------------
    from axon.core.log import Log

    Log.d("OrderService", "Processing order %s", order_id)
    Log.i("OrderService", "Order %s created successfully", order_id)
    Log.w("OrderService", "Retry %d for order %s", attempt, order_id)
    Log.e("OrderService", "Payment failed for order %s", order_id, exc=e)
    Log.wtf("OrderService", "This should never happen: %s", state)

Methods
-------
Log.d(tag, msg, *args)               DEBUG   — detailed trace, dev only
Log.i(tag, msg, *args)               INFO    — normal operational events
Log.w(tag, msg, *args)               WARNING — unexpected but recoverable
Log.e(tag, msg, *args, exc=None)     ERROR   — failures; pass exc= to attach traceback
Log.wtf(tag, msg, *args)             CRITICAL — impossible states; always logged

Configuration (config.yaml)
---------------------------
platform:
  log_level: INFO           # global level: DEBUG | INFO | WARNING | ERROR | CRITICAL
  log_format: pretty        # pretty (coloured) | plain | json
  log_tags:
    OrderService: DEBUG      # per-tag override — this tag logs at DEBUG regardless of global
    PaymentService: WARNING
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any

# ── Colour codes (ANSI — disabled automatically if not a TTY) ──────────────
_RESET  = "\033[0m"
_GREY   = "\033[38;5;240m"
_CYAN   = "\033[36m"
_GREEN  = "\033[32m"
_YELLOW = "\033[33m"
_RED    = "\033[31m"
_BOLD_RED = "\033[1;31m"
_BLUE   = "\033[34m"

_USE_COLOUR = sys.stdout.isatty() or os.environ.get("FORCE_COLOR") == "1"

_LEVEL_COLOURS = {
    logging.DEBUG:    _GREY,
    logging.INFO:     _GREEN,
    logging.WARNING:  _YELLOW,
    logging.ERROR:    _RED,
    logging.CRITICAL: _BOLD_RED,
}

_LEVEL_LABELS = {
    logging.DEBUG:    "D",
    logging.INFO:     "I",
    logging.WARNING:  "W",
    logging.ERROR:    "E",
    logging.CRITICAL: "F",   # Fatal / WTF
}


class _PlatformFormatter(logging.Formatter):
    """
    Pretty formatter:  D/TAG: message
    Mirrors Android logcat output style.
    """

    def format(self, record: logging.LogRecord) -> str:
        label = _LEVEL_LABELS.get(record.levelno, "?")
        tag   = getattr(record, "platform_tag", record.name)
        msg   = record.getMessage()

        if _USE_COLOUR:
            colour = _LEVEL_COLOURS.get(record.levelno, _RESET)
            line = f"{colour}{label}/{tag}{_RESET}: {msg}"
        else:
            line = f"{label}/{tag}: {msg}"

        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)

        return line


class _PlainFormatter(logging.Formatter):
    """Machine-readable plain text: LEVEL tag: message"""

    def format(self, record: logging.LogRecord) -> str:
        label = _LEVEL_LABELS.get(record.levelno, "?")
        tag   = getattr(record, "platform_tag", record.name)
        msg   = record.getMessage()
        line  = f"{self.formatTime(record)} {label}/{tag}: {msg}"
        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)
        return line


class _JsonFormatter(logging.Formatter):
    """JSON formatter for log aggregators (Datadog, Loki, etc.)"""

    def format(self, record: logging.LogRecord) -> str:
        import json
        from datetime import datetime, timezone
        payload: dict[str, Any] = {
            "ts":    datetime.now(timezone.utc).isoformat(),
            "level": _LEVEL_LABELS.get(record.levelno, "?"),
            "tag":   getattr(record, "platform_tag", record.name),
            "msg":   record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload)


# ── Per-tag level cache ────────────────────────────────────────────────────
_tag_levels: dict[str, int] = {}       # populated by Log.configure()
_global_level: int = logging.INFO
_root_handler: logging.Handler | None = None


def _level_for_tag(tag: str) -> int:
    return _tag_levels.get(tag, _global_level)


def _emit(level: int, tag: str, msg: str, *args: Any,
          exc_info=None) -> None:
    if level < _level_for_tag(tag):
        return
    record = logging.LogRecord(
        name=f"module.{tag}",
        level=level,
        pathname="",
        lineno=0,
        msg=msg,
        args=args,
        exc_info=exc_info,
    )
    record.platform_tag = tag
    if _root_handler:
        _root_handler.handle(record)
    else:
        # Fallback before configure() is called
        logging.getLogger(f"module.{tag}").log(level, msg, *args,
                                                exc_info=exc_info)


# ── Public API ──────────────────────────────────────────────────────────────

class Log:
    """
    Android-style static logger.  No instantiation needed.

    Log.d(tag, msg, *args)
    Log.i(tag, msg, *args)
    Log.w(tag, msg, *args)
    Log.e(tag, msg, *args, exc=None)
    Log.wtf(tag, msg, *args)
    """

    @staticmethod
    def d(tag: str, msg: str, *args: Any) -> None:
        """DEBUG — verbose trace, shown only at DEBUG level."""
        _emit(logging.DEBUG, tag, msg, *args)

    @staticmethod
    def i(tag: str, msg: str, *args: Any) -> None:
        """INFO — normal operational event."""
        _emit(logging.INFO, tag, msg, *args)

    @staticmethod
    def w(tag: str, msg: str, *args: Any) -> None:
        """WARNING — unexpected but the app can continue."""
        _emit(logging.WARNING, tag, msg, *args)

    @staticmethod
    def e(tag: str, msg: str, *args: Any, exc: BaseException | None = None) -> None:
        """ERROR — something failed. Pass exc= to attach the traceback."""
        exc_info = (type(exc), exc, exc.__traceback__) if exc else None
        _emit(logging.ERROR, tag, msg, *args, exc_info=exc_info)

    @staticmethod
    def wtf(tag: str, msg: str, *args: Any) -> None:
        """
        CRITICAL — 'What a Terrible Failure'.
        Use for states that should be logically impossible.
        Always logged regardless of configured level.
        """
        _emit(logging.CRITICAL, tag, msg, *args)


# ── Platform-internal: called once by AppEngine during boot ────────────────

def configure(
    level: str = "INFO",
    fmt: str = "pretty",
    tag_overrides: dict[str, str] | None = None,
) -> None:
    """
    Configure the Log system.  Called by AppEngine — module builders
    never call this directly.

    Parameters
    ----------
    level          Global minimum level: DEBUG | INFO | WARNING | ERROR | CRITICAL
    fmt            Output format: pretty | plain | json
    tag_overrides  Per-tag level overrides: {"OrderService": "DEBUG"}
    """
    global _global_level, _tag_levels, _root_handler

    _global_level = getattr(logging, level.upper(), logging.INFO)

    _tag_levels = {
        tag: getattr(logging, lvl.upper(), logging.INFO)
        for tag, lvl in (tag_overrides or {}).items()
    }

    # Build formatter
    fmt_lower = fmt.lower()
    if fmt_lower == "json":
        formatter: logging.Formatter = _JsonFormatter()
    elif fmt_lower == "plain":
        formatter = _PlainFormatter()
    else:
        formatter = _PlatformFormatter()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    handler.setLevel(logging.DEBUG)   # handler passes everything; we gate above

    _root_handler = handler

    # Also configure Python's root logger so platform-internal logs
    # (SQLAlchemy, Alembic, Uvicorn) respect the global level
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(_global_level)

    Log.d("Log", "Log system configured — level=%s fmt=%s tag_overrides=%s",
          level, fmt, tag_overrides or {})
