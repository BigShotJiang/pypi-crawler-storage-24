"""
Service Container
=================
Global registry that binds names to classes or instances.
Supports singleton and transient lifecycles.
Modules register services here; nothing imports directly from another module.
"""

from __future__ import annotations

import threading
from typing import Any, Callable, Type, TypeVar, overload

T = TypeVar("T")

_SENTINEL = object()


class BindingNotFoundError(Exception):
    pass


class CircularDependencyError(Exception):
    pass


class _Binding:
    __slots__ = ("factory", "singleton", "_instance", "_lock")

    def __init__(self, factory: Callable[[], Any], singleton: bool) -> None:
        self.factory = factory
        self.singleton = singleton
        self._instance: Any = _SENTINEL
        self._lock = threading.Lock()

    def resolve(self) -> Any:
        if not self.singleton:
            return self.factory()
        if self._instance is _SENTINEL:
            with self._lock:
                if self._instance is _SENTINEL:          # double-checked
                    self._instance = self.factory()
        return self._instance


class Container:
    """
    Lightweight service container.

    Usage
    -----
    container = Container()

    # Singleton (default)
    container.bind("db", DatabaseService)
    container.bind("db", DatabaseService, singleton=True)

    # Transient — new instance every call
    container.bind("mailer", MailerService, singleton=False)

    # Pre-built instance
    container.instance("config", resolved_config_object)

    # Resolve
    db = container.make("db")
    db = container.make("db", DatabaseService)   # type-checked variant
    """

    def __init__(self) -> None:
        self._bindings: dict[str, _Binding] = {}
        self._aliases: dict[str, str] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def bind(
        self,
        name_or_type: str | type,
        cls: type | Callable[[], Any] | None = None,
        *,
        singleton: bool = True,
    ) -> None:
        """
        Bind a name or type to a class or factory callable.

        Two forms:
            bind("order_svc", OrderService)     # string key (old style)
            bind(OrderService)                  # type key — key = class name
            bind(OrderService, singleton=False) # transient
        """
        if isinstance(name_or_type, str):
            # Old style: bind("name", cls)
            if cls is None:
                raise ValueError("bind(name, cls) requires cls when name is a string")
            key     = name_or_type
            factory = cls
        else:
            # New style: bind(MyClass) — key derived from class name
            key     = name_or_type.__name__
            factory = name_or_type if cls is None else cls

        with self._lock:
            self._bindings[key] = _Binding(factory, singleton)

    def instance(self, name: str, obj: Any) -> None:
        """Register a pre-built instance as a singleton."""
        binding = _Binding(lambda: obj, singleton=True)
        binding._instance = obj                          # bypass factory
        with self._lock:
            self._bindings[name] = binding

    def alias(self, alias: str, target: str) -> None:
        """Register an alias so multiple names map to the same binding."""
        with self._lock:
            self._aliases[alias] = target

    # ------------------------------------------------------------------
    # Resolution
    # ------------------------------------------------------------------

    def make(self, name: str, expected_type: Type[T] | None = None) -> Any:
        """
        Resolve a service by name.
        Raises BindingNotFoundError if unknown.
        Raises TypeError if expected_type is given and resolved type doesn't match.
        """
        canonical = self._aliases.get(name, name)
        binding = self._bindings.get(canonical)
        if binding is None:
            raise BindingNotFoundError(
                f"No binding found for '{name}'. "
                f"Registered names: {sorted(self._bindings)}"
            )
        obj = binding.resolve()
        if expected_type is not None and not isinstance(obj, expected_type):
            raise TypeError(
                f"Expected '{name}' to be {expected_type.__name__}, "
                f"got {type(obj).__name__}"
            )
        return obj

    def has(self, name: str) -> bool:
        canonical = self._aliases.get(name, name)
        return canonical in self._bindings

    def all_names(self) -> list[str]:
        return sorted(self._bindings.keys())

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def __getitem__(self, name: str) -> Any:
        return self.make(name)

    def __contains__(self, name: str) -> bool:
        return self.has(name)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Container bindings={self.all_names()}>"
