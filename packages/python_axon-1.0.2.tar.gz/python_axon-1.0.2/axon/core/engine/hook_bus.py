"""
Hook & Filter Bus
=================
Decoupled event system that lets modules talk to each other
without importing from each other.

  emit(event, payload)           — fire-and-forget; no return value
  filter(event, value)           — passes value through every listener in order
  on(event, handler, priority)   — register a listener (sync or async)
  off(event, handler)            — unregister a listener
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass(order=True)
class _Handler:
    priority: int
    handler: Callable = field(compare=False)
    is_async: bool = field(compare=False)

    def __hash__(self) -> int:
        return id(self.handler)


class HookBus:
    """
    Central event / filter bus.

    Lifecycle
    ---------
    All handlers registered via ``on()`` persist for the lifetime of the bus.
    Use ``off()`` to remove a specific handler.

    Priority
    --------
    Lower numbers run first (0 = highest priority, 100 = default).
    """

    def __init__(self) -> None:
        # event_name → sorted list of _Handler
        self._listeners: dict[str, list[_Handler]] = defaultdict(list)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def on(
        self,
        event: str,
        handler: Callable,
        *,
        priority: int = 100,
    ) -> None:
        """
        Register a handler for *event*.

        Handler signature for emit events:
            def handler(payload: Any) -> None

        Handler signature for filter events:
            def handler(value: Any) -> Any   # must return (possibly modified) value

        Both sync and async callables are supported.
        """
        entry = _Handler(
            priority=priority,
            handler=handler,
            is_async=asyncio.iscoroutinefunction(handler),
        )
        listeners = self._listeners[event]
        listeners.append(entry)
        listeners.sort()                                   # keep priority order
        logger.debug("HookBus: registered handler for '%s' (priority=%d)", event, priority)

    def off(self, event: str, handler: Callable) -> bool:
        """Unregister a handler. Returns True if it was found and removed."""
        listeners = self._listeners.get(event, [])
        for entry in listeners:
            if entry.handler is handler:
                listeners.remove(entry)
                return True
        return False

    # ------------------------------------------------------------------
    # Emission
    # ------------------------------------------------------------------

    async def emit(self, event: str, payload: Any = None) -> None:
        """
        Fire an event. All listeners are called; return values are ignored.
        Exceptions in one handler do NOT stop others — they are logged.
        """
        listeners = self._listeners.get(event, [])
        if not listeners:
            return

        logger.debug("HookBus: emit '%s' to %d handler(s)", event, len(listeners))

        for entry in listeners:
            try:
                if entry.is_async:
                    await entry.handler(payload)
                else:
                    entry.handler(payload)
            except Exception:                              # noqa: BLE001
                logger.exception(
                    "HookBus: unhandled error in handler for event '%s'", event
                )

    def emit_sync(self, event: str, payload: Any = None) -> None:
        """Synchronous wrapper — creates an event loop if none is running."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # schedule as a task; caller won't await results
                asyncio.ensure_future(self.emit(event, payload))
            else:
                loop.run_until_complete(self.emit(event, payload))
        except RuntimeError:
            asyncio.run(self.emit(event, payload))

    # ------------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------------

    async def filter(self, event: str, value: Any) -> Any:
        """
        Pass *value* through every listener registered for *event* in priority
        order. Each listener receives the (possibly modified) value from the
        previous listener and returns its own version.

        If a listener raises, the exception is logged and the current value is
        passed unchanged to the next listener.
        """
        listeners = self._listeners.get(event, [])
        logger.debug("HookBus: filter '%s' through %d handler(s)", event, len(listeners))

        for entry in listeners:
            try:
                if entry.is_async:
                    result = await entry.handler(value)
                else:
                    result = entry.handler(value)
                if result is not None:
                    value = result
            except Exception:                              # noqa: BLE001
                logger.exception(
                    "HookBus: unhandled error in filter handler for event '%s'", event
                )
        return value

    def filter_sync(self, event: str, value: Any) -> Any:
        """Synchronous wrapper for filter."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Can't block — caller must use async variant in async context
                raise RuntimeError(
                    "filter_sync() called from within a running event loop. "
                    "Use `await bus.filter(...)` instead."
                )
            return loop.run_until_complete(self.filter(event, value))
        except RuntimeError:
            return asyncio.run(self.filter(event, value))

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def listeners_for(self, event: str) -> list[Callable]:
        return [e.handler for e in self._listeners.get(event, [])]

    def registered_events(self) -> list[str]:
        return sorted(self._listeners.keys())

    def __repr__(self) -> str:  # pragma: no cover
        counts = {e: len(h) for e, h in self._listeners.items()}
        return f"<HookBus events={counts}>"
