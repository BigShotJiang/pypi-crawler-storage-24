"""
Service Container
=================
Manages service bindings with full override/extend/decorate support.

Binding modes
-------------
bind(MyService)                         register (first or replace)
bind(MyService, override=True)          explicit replacement -- logs warning if nothing to replace
extend(MyService, MyExtendedService)    wrap -- original stays accessible as MyService.base
decorate(MyService, my_decorator_fn)    functional wrap -- fn(original) -> new_instance

Resolution
----------
make("MyService")      resolve by name
make(MyService)        resolve by type
"""
from __future__ import annotations

import threading
from typing import Any, Callable, Type, TypeVar

T = TypeVar("T")

_SENTINEL = object()


class BindingNotFoundError(Exception):
    pass


class _Binding:
    __slots__ = ("factory", "singleton", "_instance", "_lock", "owner", "mode")

    def __init__(
        self,
        factory: Callable[[], Any],
        singleton: bool,
        owner: str = "",
        mode: str = "bind",   # bind | override | extend | decorate
    ) -> None:
        self.factory   = factory
        self.singleton = singleton
        self._instance: Any = _SENTINEL
        self._lock     = threading.Lock()
        self.owner     = owner   # module name that registered this
        self.mode      = mode

    def resolve(self) -> Any:
        if not self.singleton:
            return self.factory()
        if self._instance is _SENTINEL:
            with self._lock:
                if self._instance is _SENTINEL:
                    self._instance = self.factory()
        return self._instance

    def invalidate(self) -> None:
        """Clear cached singleton so the next make() re-instantiates."""
        with self._lock:
            self._instance = _SENTINEL


class Container:
    """
    Service container with override/extend/decorate semantics.

    All methods are thread-safe.
    """

    def __init__(self) -> None:
        self._bindings: dict[str, _Binding]       = {}
        self._aliases:  dict[str, str]             = {}
        self._history:  dict[str, list[_Binding]]  = {}  # audit trail
        self._lock      = threading.Lock()

    # ── Helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _key(name_or_type: str | type) -> str:
        return name_or_type if isinstance(name_or_type, str) else name_or_type.__name__

    def _record(self, key: str, binding: _Binding) -> None:
        self._history.setdefault(key, []).append(binding)

    # ── Registration ──────────────────────────────────────────────────────

    def bind(
        self,
        name_or_type: str | type,
        cls: type | Callable[[], Any] | None = None,
        *,
        singleton: bool = True,
        owner: str = "",
    ) -> None:
        """
        Register (or replace) a service.

        bind(OrderService)                  key = class name, factory = class
        bind(OrderService, singleton=False) transient
        bind("order_svc", OrderService)     explicit string key
        bind(IMailer, SMTPMailer)           bind interface to implementation
        """
        key, factory = self._resolve_args(name_or_type, cls)
        binding = _Binding(factory, singleton, owner=owner, mode="bind")
        with self._lock:
            self._record(key, binding)
            self._bindings[key] = binding

    def override(
        self,
        name_or_type: str | type,
        cls: type | Callable[[], Any] | None = None,
        *,
        singleton: bool = True,
        owner: str = "",
    ) -> None:
        """
        Explicitly replace a binding registered by another module.

        override(SMTPMailer, ResendMailer)

        Unlike bind(), override() is semantically clear about intent.
        Both work the same way mechanically — override() is the signal to
        readers that this module is intentionally replacing something.
        """
        key, factory = self._resolve_args(name_or_type, cls)
        binding = _Binding(factory, singleton, owner=owner, mode="override")
        with self._lock:
            self._record(key, binding)
            self._bindings[key] = binding

    def extend(
        self,
        name_or_type: str | type,
        extended_cls: type,
        *,
        singleton: bool = True,
        owner: str = "",
    ) -> None:
        """
        Wrap an existing service with a new class.

        The original service is accessible as  container.make("OriginalName.base").
        The extended class receives the original instance as its first constructor
        argument, so it can delegate to it.

        Example:
            # auth_module registers AuthService
            # otp_module extends it:

            class OTPAuthService(BaseService):
                def __init__(self, base: AuthService) -> None:
                    super().__init__()
                    self._base = base        # original

                def login(self, credentials):
                    user = self._base.login(credentials)   # delegate
                    self._send_otp(user)
                    return user

            # In otp_module.register():
            self.extend(AuthService, OTPAuthService)
        """
        key = self._key(name_or_type)
        ext_key = extended_cls.__name__

        with self._lock:
            original_binding = self._bindings.get(key)
            if original_binding is None:
                raise BindingNotFoundError(
                    f"extend('{key}'): no existing binding found. "
                    f"Make sure the module providing '{key}' is listed in requires[]."
                )

            # Preserve original under ".base" key
            base_key = key + ".base"
            self._bindings[base_key] = original_binding

            # Build extended factory: resolve original first, pass to extended_cls
            def _extended_factory(
                _orig_binding=original_binding,
                _ext=extended_cls,
            ):
                original = _orig_binding.resolve()
                return _ext(original)

            binding = _Binding(_extended_factory, singleton, owner=owner, mode="extend")
            self._record(key, binding)
            self._bindings[key] = binding

    def decorate(
        self,
        name_or_type: str | type,
        decorator_fn: Callable[[Any], Any],
        *,
        owner: str = "",
    ) -> None:
        """
        Apply a functional decorator to an existing binding.
        The decorator receives the resolved original and returns a replacement.

        Useful for wrapping without subclassing — e.g. adding caching,
        logging, or metrics to an existing service.

        Example:
            def add_caching(mail_service):
                mail_service.send = cached(mail_service.send)
                return mail_service

            self.decorate(MailService, add_caching)
        """
        key = self._key(name_or_type)

        with self._lock:
            original_binding = self._bindings.get(key)
            if original_binding is None:
                raise BindingNotFoundError(
                    f"decorate('{key}'): no existing binding found."
                )

            base_key = key + ".base"
            self._bindings[base_key] = original_binding

            def _decorated_factory(
                _orig=original_binding,
                _dec=decorator_fn,
            ):
                return _dec(_orig.resolve())

            binding = _Binding(_decorated_factory, True, owner=owner, mode="decorate")
            self._record(key, binding)
            self._bindings[key] = binding

    def patch_method(
        self,
        name_or_type: str | type,
        method_name: str,
        new_fn: Callable,
        *,
        owner: str = "",
    ) -> None:
        """
        Replace a single method on an already-bound service instance.
        The exact Python equivalent of  service.method = newFunction  in JS.

        The replacement function receives the original bound method as its
        first argument so you can call through to it (like super()).

        Example
        -------
            # patch_module replaces only the `send` method of MailService,
            # leaving everything else on the original untouched:

            def my_send(original_send, to, subject, body, **kwargs):
                Log.i("PatchModule", "intercepted mail to %s", to)
                return original_send(to, subject, body, **kwargs)

            self.patch_method(MailService, "send", my_send)

            # Equivalent JS mental model:
            #   mailService.send = (to, subject, body) => {
            #       console.log("intercepted");
            #       return originalSend(to, subject, body);
            #   }

        The original method is accessible as  service.<method_name>__original
        if you need it directly later.

        Unlike extend() / decorate(), patch_method() mutates the *live instance*
        in place — it does not create a new object.  This means it works even
        after the service has already been resolved and cached as a singleton.
        """
        key = self._key(name_or_type)

        with self._lock:
            binding = self._bindings.get(key)
            if binding is None:
                raise BindingNotFoundError(
                    f"patch_method('{key}', '{method_name}'): no binding found."
                )

        # Resolve the instance (creates it if first access)
        instance = binding.resolve()

        original = getattr(instance, method_name, None)
        if original is None:
            raise AttributeError(
                f"patch_method: '{type(instance).__name__}' has no method '{method_name}'"
            )

        import functools

        # Bind the original as the first argument to new_fn
        # so the caller can call through: new_fn(original, *args)
        patched = functools.partial(new_fn, original)
        functools.update_wrapper(patched, new_fn)

        # Store original for inspection / further patching
        setattr(instance, method_name + "__original", original)
        setattr(instance, method_name, patched)

        self._record(key, _Binding(lambda: instance, True, owner=owner, mode="patch_method"))

    def instance(self, name: str, obj: Any, *, owner: str = "") -> None:
        """Register a pre-built instance as a singleton."""
        binding = _Binding(lambda: obj, singleton=True, owner=owner, mode="bind")
        binding._instance = obj
        with self._lock:
            self._record(name, binding)
            self._bindings[name] = binding

    def alias(self, alias: str, target: str) -> None:
        """Make alias resolve to the same binding as target."""
        with self._lock:
            self._aliases[alias] = target

    # ── Resolution ────────────────────────────────────────────────────────

    def make(self, name_or_type: str | type, expected_type: Type[T] | None = None) -> Any:
        """
        Resolve a service by name or type.
        make("MailService")  or  make(MailService)  are equivalent.
        Append ".base" to get the original before extend/decorate:
            make("MailService.base")
        """
        key      = self._key(name_or_type)
        canonical = self._aliases.get(key, key)
        binding  = self._bindings.get(canonical)
        if binding is None:
            raise BindingNotFoundError(
                f"No binding found for '{key}'. "
                f"Registered: {sorted(self._bindings)}"
            )
        obj = binding.resolve()
        if expected_type is not None and not isinstance(obj, expected_type):
            raise TypeError(
                f"Expected '{key}' to be {expected_type.__name__}, "
                f"got {type(obj).__name__}"
            )
        return obj

    def has(self, name_or_type: str | type) -> bool:
        key = self._key(name_or_type)
        canonical = self._aliases.get(key, key)
        return canonical in self._bindings

    def all_names(self) -> list[str]:
        return sorted(self._bindings.keys())

    def binding_info(self, name_or_type: str | type) -> dict | None:
        """Return metadata about a binding — owner, mode, history."""
        key = self._key(name_or_type)
        binding = self._bindings.get(key)
        if not binding:
            return None
        history = [
            {"owner": b.owner, "mode": b.mode}
            for b in self._history.get(key, [])
        ]
        return {
            "key":     key,
            "owner":   binding.owner,
            "mode":    binding.mode,
            "history": history,
        }

    # ── Helpers ────────────────────────────────────────────────────────────

    def _resolve_args(
        self,
        name_or_type: str | type,
        cls: type | Callable | None,
    ) -> tuple[str, Callable]:
        if isinstance(name_or_type, str):
            if cls is None:
                raise ValueError("bind(name, cls): cls required when name is a string")
            return name_or_type, cls
        key     = name_or_type.__name__
        factory = name_or_type if cls is None else cls
        return key, factory

    def __getitem__(self, name: str) -> Any:
        return self.make(name)

    def __contains__(self, name: str) -> bool:
        return self.has(name)

    def __repr__(self) -> str:
        return f"<Container bindings={self.all_names()}>"
