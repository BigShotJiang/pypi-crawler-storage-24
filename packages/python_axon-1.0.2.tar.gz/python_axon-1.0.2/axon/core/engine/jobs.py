"""
Background Job Runner
=====================
Fire-and-forget async jobs with retry, delay, and error handling.
No external queue needed — runs in the same process using asyncio.
For production scale, swap the backend via the driver pattern.

Module usage
------------
    from axon.core.engine.jobs import Job

    class Module(BaseModule):
        async def boot(self) -> None:
            self.on("user.registered", self._on_registered)

        async def _on_registered(self, payload: dict) -> None:
            # Dispatch to background — request returns immediately
            self.dispatch(SendWelcomeEmail, user_id=payload["user_id"])
            self.dispatch(CreateTrialSubscription, user_id=payload["user_id"])

Job definition
--------------
    from axon.core.engine.jobs import Job

    class SendWelcomeEmail(Job):
        max_retries = 3
        retry_delay = 5   # seconds between retries

        async def handle(self, user_id: int) -> None:
            mailer = self.make(MailService)
            user   = self.make(UserService).find(user_id)
            await mailer.send(user.email, "Welcome!", render("welcome", user=user))

Delayed jobs
------------
    self.dispatch(SendReminder, delay=3600, booking_id=booking.id)

Retry on specific exceptions
-----------------------------
    class SendSMS(Job):
        retry_on = (SMSGatewayError, TimeoutError)
        max_retries = 5
        retry_delay = 30
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

log = logging.getLogger("platform.jobs")


class Job:
    """Base class for all background jobs."""
    max_retries: int         = 0
    retry_delay: float       = 5.0
    retry_on:    tuple       = (Exception,)

    _engine = None           # set by JobRunner at dispatch time

    def make(self, service_type) -> Any:
        return self._engine.container.make(service_type)

    def config(self, key: str, default=None) -> Any:
        return self._engine.cfg.get(key, default)

    async def handle(self, **kwargs) -> None:
        raise NotImplementedError("Job.handle() must be implemented")


class JobRunner:
    MAX_QUEUE_SIZE    = 1000   # configurable — warn at 80%, hard cap at 100%
    WARN_QUEUE_AT     = 0.8    # warn when queue reaches 80% capacity

    def __init__(self) -> None:
        self._queue:  asyncio.Queue = asyncio.Queue(maxsize=self.MAX_QUEUE_SIZE)
        self._running = False
        self._workers: list[asyncio.Task] = []
        self._engine  = None

    def set_engine(self, engine) -> None:
        self._engine = engine

    async def start(self, workers: int = 4) -> None:
        self._running = True
        for _ in range(workers):
            t = asyncio.create_task(self._worker())
            self._workers.append(t)
        # log.info("I/JobRunner: started %d worker(s)", workers)

    async def stop(self) -> None:
        self._running = False
        for t in self._workers:
            t.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        log.info("I/JobRunner: stopped")

    def dispatch(
        self,
        job_class: type[Job],
        *,
        delay: float = 0,
        **kwargs,
    ) -> None:
        """Enqueue a job. Returns immediately."""
        asyncio.create_task(self._enqueue(job_class, delay, kwargs))

    async def _enqueue(self, job_class, delay: float, kwargs: dict) -> None:
        if delay > 0:
            await asyncio.sleep(delay)
        # Backpressure: warn as queue fills, drop with error when full
        qsize = self._queue.qsize()
        if qsize >= self.MAX_QUEUE_SIZE * self.WARN_QUEUE_AT:
            log.warning("JobRunner: queue at %d/%d — consider scaling workers",
                        qsize, self.MAX_QUEUE_SIZE)
        try:
            self._queue.put_nowait((job_class, kwargs))
        except asyncio.QueueFull:
            log.error("JobRunner: queue full (%d) — dropping %s",
                      self.MAX_QUEUE_SIZE, job_class.__name__)

    async def _worker(self) -> None:
        while self._running:
            try:
                job_class, kwargs = await asyncio.wait_for(
                    self._queue.get(), timeout=1.0
                )
                await self._run(job_class, kwargs)
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("JobRunner: unexpected worker error")

    async def _run(self, job_class: type[Job], kwargs: dict) -> None:
        attempts = 0
        max_attempts = 1 + getattr(job_class, "max_retries", 0)
        retry_delay  = getattr(job_class, "retry_delay", 5.0)
        retry_on     = getattr(job_class, "retry_on", (Exception,))

        while attempts < max_attempts:
            try:
                job = job_class()
                job._engine = self._engine
                await job.handle(**kwargs)
                log.debug("JobRunner: %s completed", job_class.__name__)
                return
            except tuple(retry_on) as exc:
                attempts += 1
                if attempts < max_attempts:
                    log.warning(
                        "JobRunner: %s failed (%s) — retrying in %ss (%d/%d)",
                        job_class.__name__, exc, retry_delay, attempts, max_attempts - 1,
                    )
                    await asyncio.sleep(retry_delay)
                else:
                    log.error(
                        "JobRunner: %s failed after %d attempt(s): %s",
                        job_class.__name__, attempts, exc,
                    )
            except Exception:
                log.exception("JobRunner: %s raised unexpected error", job_class.__name__)
                return
