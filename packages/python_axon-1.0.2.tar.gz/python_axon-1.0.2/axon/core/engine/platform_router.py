"""
Platform built-in routes
========================
Home, health, and status endpoints.

These are registered by the Application class at boot — NOT by any module.
Modules can override responses via filter events or by binding a controller:

Override the home response via filter:
    # In any module's boot():
    self.on("platform.home.response", my_home_handler)

    async def my_home_handler(data: dict) -> dict:
        data["app"] = "My SaaS"
        data["version"] = "2.1.0"
        return data

Override the health check via filter:
    self.on("platform.health.response", my_health_handler)

    async def my_health_handler(data: dict) -> dict:
        data["redis"] = check_redis()
        data["queue"] = check_queue()
        return data

Replace the root endpoint entirely:
    # In register():
    self.instance("platform.home_controller", MyHomeController())
    # MyHomeController must implement async def __call__(self) -> dict
"""
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from axon.core.engine.app_engine import AppEngine


def _build_platform_router(engine: "AppEngine"):
    """
    Build and return the platform's built-in FastAPI APIRouter.
    Called once by Application at boot — invisible to modules.
    """
    from fastapi import APIRouter

    router = APIRouter(tags=["platform"])

    @router.get("/")
    async def home():
        # Modules can override via platform.home_controller binding
        if engine.container.has("platform.home_controller"):
            controller = engine.container.make("platform.home_controller")
            return await controller()

        # Default payload — modules can filter/extend via hook
        data = {
            "status": "running",
        }
        return await engine.hooks.filter("platform.home.response", data)

    @router.get("/health")
    async def health():
        data = {
            "status": "ok",
            "db": engine.db.ping(),
        }
        return await engine.hooks.filter("platform.health.response", data)

    @router.get("/platform/status")
    async def status():
        return engine.status()

    @router.get("/platform/modules")
    async def modules():
        if not engine.loader:
            return {"modules": []}
        return {
            "modules": [
                {
                    "name":        m.name,
                    "version":     m.version,
                    "description": m.description,
                }
                for m in engine.loader.modules
            ]
        }

    return router
