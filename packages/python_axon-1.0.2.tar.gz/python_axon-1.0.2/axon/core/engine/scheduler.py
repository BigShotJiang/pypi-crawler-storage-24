"""
Task Scheduler
==============
Cron-style background task scheduler integrated with the platform lifecycle.
Starts at boot, stops at shutdown. No external dependencies (pure Python).

Module usage
------------
    from axon.core.engine.scheduler import schedule

    class Module(BaseModule):
        async def boot(self) -> None:
            # Run every hour
            self.schedule("0 * * * *", self._cleanup_expired_tokens)
            # Run every 5 minutes
            self.schedule("*/5 * * * *", self._sync_rates)
            # Run once a day at 2am
            self.schedule("0 2 * * *", self._generate_invoices)

        async def _cleanup_expired_tokens(self) -> None:
            with self.db().session() as s:
                s.query(Token).filter(Token.expires_at < datetime.utcnow()).delete()
            self.log_i("cleaned up expired tokens")

Cron syntax
-----------
    * * * * *
    | | | | └── day of week  (0-6, 0=Sunday)
    | | | └──── month        (1-12)
    | | └────── day of month (1-31)
    | └──────── hour         (0-23)
    └────────── minute       (0-59)

    Supports: * (any), */n (every n), n (exact), n-m (range), n,m (list)
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Callable

log = logging.getLogger("platform.scheduler")


def _matches_field(value: int, expr: str) -> bool:
    """Check if value matches a single cron field expression."""
    if expr == "*":
        return True
    if expr.startswith("*/"):
        step = int(expr[2:])
        return value % step == 0
    if "-" in expr:
        a, b = expr.split("-", 1)
        return int(a) <= value <= int(b)
    if "," in expr:
        return value in (int(x) for x in expr.split(","))
    return value == int(expr)


def _cron_matches(cron: str, dt: datetime) -> bool:
    parts = cron.strip().split()
    if len(parts) != 5:
        raise ValueError(f"Invalid cron expression: {cron!r}")
    minute, hour, dom, month, dow = parts
    return (
        _matches_field(dt.minute,     minute) and
        _matches_field(dt.hour,       hour)   and
        _matches_field(dt.day,        dom)    and
        _matches_field(dt.month,      month)  and
        _matches_field(dt.weekday() % 7, dow)  # Python Mon=0, cron Sun=0
    )


class _ScheduledTask:
    __slots__ = ("cron", "handler", "owner", "name")

    def __init__(self, cron: str, handler: Callable, owner: str, name: str) -> None:
        self.cron    = cron
        self.handler = handler
        self.owner   = owner
        self.name    = name


class Scheduler:
    def __init__(self) -> None:
        self._tasks: list[_ScheduledTask] = []
        self._running = False
        self._task: asyncio.Task | None = None

    def add(self, cron: str, handler: Callable, *, owner: str = "", name: str = "") -> None:
        self._tasks.append(_ScheduledTask(
            cron    = cron,
            handler = handler,
            owner   = owner,
            name    = name or getattr(handler, "__name__", repr(handler)),
        ))
        log.debug("Scheduler: registered '%s' cron='%s' owner=%s", name, cron, owner)

    async def start(self) -> None:
        self._running = True
        self._task = asyncio.create_task(self._loop())
        # log.info("I/Scheduler: started with %d task(s)", len(self._tasks))

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        log.info("I/Scheduler: stopped")

    async def _loop(self) -> None:
        # Align to the next whole minute
        now    = datetime.now(timezone.utc)
        delay  = 60 - now.second - now.microsecond / 1_000_000
        await asyncio.sleep(delay)

        while self._running:
            now = datetime.now(timezone.utc)
            for task in self._tasks:
                try:
                    if _cron_matches(task.cron, now):
                        log.info("I/Scheduler: running '%s'", task.name)
                        if asyncio.iscoroutinefunction(task.handler):
                            asyncio.create_task(task.handler())
                        else:
                            task.handler()
                except Exception:
                    log.exception("Scheduler: error in task '%s'", task.name)
            # Sleep until the next minute
            await asyncio.sleep(60 - datetime.now(timezone.utc).second)
