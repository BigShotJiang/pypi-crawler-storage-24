"""
AppEngine  --  Platform Runtime Host
=====================================
Owns every subsystem. One instance per process.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from axon.core.config.config_manager import ConfigManager
from axon.core.engine.container import Container
from axon.core.engine.hook_bus import HookBus
from axon.core.db.migration_runner import MigrationRunner
from axon.core.routing.middleware import MiddlewarePipeline
from axon.core.engine.scheduler import Scheduler
from axon.core.engine.jobs import JobRunner
from axon.core.module.module_loader import ModuleLoader
from axon.core.logging.log import Log, configure as _configure_log

logger = logging.getLogger(__name__)

_engine_instance: "AppEngine | None" = None

def _project_root() -> Path:
    """Resolve the current project root. Respects AXON_PROJECT_ROOT env var."""
    return Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))

def _get_defaults():
    root = _project_root()
    return (
        root / "config.yaml",       # _CONFIG_YAML
        root / ".env",              # _ENV_FILE
        root / "app" / "modules",   # _MODULES_DIR
    )

# Kept for backward compat — callers that import these names directly
_CONFIG_YAML    = None   # resolved lazily in create()
_ENV_FILE       = None
_MODULES_DIR    = None


class AppEngine:

    def __init__(self) -> None:
        self.container = Container()
        self.hooks     = HookBus()
        self.cfg       = ConfigManager()
        self.db        = MigrationRunner()
        self.loader:   ModuleLoader | None = None
        self.pipeline  = MiddlewarePipeline()
        self.scheduler = Scheduler()
        self.jobs      = JobRunner()
        self._booted   = False

    @classmethod
    async def create(
        cls,
        config_yaml: Path | None = None,
        env_file:    Path | None = None,
        modules_dir: Path | None = None,
    ) -> "AppEngine":
        engine = cls()
        defaults = _get_defaults()
        await engine._boot(
            config_yaml = config_yaml or defaults[0],
            env_file    = env_file    or defaults[1],
            modules_dir = modules_dir or defaults[2],
        )
        return engine

    async def _boot(self, config_yaml: Path, env_file: Path, modules_dir: Path) -> None:
        if self._booted:
            raise RuntimeError("AppEngine.boot() called twice")

        # 1. Config
        self.cfg.load_root(config_yaml=config_yaml, env_file=env_file)

        # 2. Logging
        _configure_log(
            level         = self.cfg.get("platform.log_level", "INFO"),
            fmt           = self.cfg.get("platform.log_format", "pretty"),
            tag_overrides = self.cfg.get("platform.log_tags", {}),
        )

        # 3. Database — supports both flat database_url and structured database: block
        self.db.configure_from_config(self.cfg)

        # 4. Core services in container
        self.container.instance("config",    self.cfg)
        self.container.instance("hooks",     self.hooks)
        self.container.instance("db",        self.db)
        self.container.instance("engine",    self)
        self.container.instance("pipeline",  self.pipeline)
        self.container.instance("scheduler", self.scheduler)
        self.container.instance("jobs",      self.jobs)
        self.jobs.set_engine(self)

        # 4b. Platform auth
        from axon.core.auth.services import UserService, TokenService
        self.container.bind(UserService,  singleton=True, owner="platform.auth")
        self.container.bind(TokenService, singleton=True, owner="platform.auth")

        # 4c. Platform mail
        from axon.core.mail.mailer import Mailer, _detect_driver
        _mail_instance = _detect_driver(self.cfg)
        self.container.instance("Mailer", _mail_instance)

        # 5. Discover + load local modules
        self.loader = ModuleLoader(modules_dir, self)
        modules = self.loader.discover_and_load()

        # 5b. Load vendor modules declared in app/providers/providers.py
        from axon.core.module.vendor_loader import load_vendor_modules
        vendor_modules = load_vendor_modules(self)
        if vendor_modules:
            # Prepend vendors so local modules can list them in requires[]
            modules = vendor_modules + modules

        # 6. register() — sync, all modules
        for mod in modules:
            Log.d("AppEngine", "registering '%s'", mod.name)
            mod.register()
            # Wire manifest.provides → container aliases so make("binance_keys_svc")
            # resolves to whatever BinanceKeyService is bound as.
            manifest = self.loader.manifests.get(mod.name)
            if manifest:
                for provided in manifest.provides:
                    # Only alias if not already a real binding (lets modules
                    # bind the alias key directly if they prefer)
                    if not self.container.has(provided):
                        # Find the first binding that was registered by this module
                        # and alias the provides name to it
                        owned = [
                            name for name, b in self.container._bindings.items()
                            if b.owner == mod.name and not name.endswith(".base")
                        ]
                        if owned:
                            self.container.alias(provided, owned[0])
                            Log.d("AppEngine", "alias '%s' → '%s'", provided, owned[0])

        # 7. Discover models
        import axon.core.auth.models  # noqa — registers auth_users / auth_tokens
        self.db.discover_models(modules_dir)

        # 8. boot()
        for mod in modules:
            Log.d("AppEngine", "booting '%s'", mod.name)
            await mod.boot()

        self._booted = True
        names = [m.name for m in modules]
        await self.scheduler.start()
        await self.jobs.start()
        await self.hooks.emit("platform.booted", {"modules": names})

    def collect_routers(self) -> list:
        from axon.core.routing.router import Router
        import importlib
        fa_routers = []

        import importlib as _il
        _auth_routes_mod = _il.import_module("axon.core.auth.routes")
        for _attr in dir(_auth_routes_mod):
            _obj = getattr(_auth_routes_mod, _attr)
            if isinstance(_obj, Router):
                fa_routers.append(_obj._to_fastapi_router(self, "auth"))

        for module in (self.loader.modules if self.loader else []):
            manifest  = self.loader.manifests.get(module.name)
            candidates: list[Router] = []

            if manifest and manifest.routes:
                pkg_path = f"app.modules.{module.name}.{manifest.routes}"
                try:
                    routes_mod = importlib.import_module(pkg_path)
                    for attr_name in dir(routes_mod):
                        obj = getattr(routes_mod, attr_name)
                        if isinstance(obj, Router):
                            candidates.append(obj)
                except ImportError as exc:
                    Log.e("AppEngine", "cannot import routes '%s': %s", pkg_path, exc)

            single = getattr(module, "router", None)
            multi  = getattr(module, "routers", None)
            if isinstance(single, Router):
                candidates.append(single)
            if isinstance(multi, (list, tuple)):
                candidates.extend(r for r in multi if isinstance(r, Router))

            for r in candidates:
                fa_routers.append(r._to_fastapi_router(self, module.name))

        return fa_routers

    async def shutdown(self) -> None:
        if not self._booted or self.loader is None:
            return
        Log.i("AppEngine", "shutting down...")
        await self.hooks.emit("platform.shutting_down", {})
        for mod in reversed(self.loader.modules):
            try:
                await mod.shutdown()
            except Exception as exc:
                Log.e("AppEngine", "error shutting down '%s'", mod.name, exc=exc)
        self.db.dispose()
        Log.i("AppEngine", "shutdown complete")

    def config(self, key: str, default: Any = None) -> Any:
        return self.cfg.get(key, default)

    def make(self, name: str) -> Any:
        return self.container.make(name)

    def bind(self, name: str, cls: type, *, singleton: bool = True) -> None:
        self.container.bind(name, cls, singleton=singleton)

    def instance(self, name: str, obj: Any) -> None:
        self.container.instance(name, obj)

    def status(self) -> dict:
        return {
            "booted":   self._booted,
            "modules":  [m.name for m in (self.loader.modules if self.loader else [])],
            "services": self.container.all_names(),
            "events":   self.hooks.registered_events(),
            "db_ok":    self.db.ping(),
        }

    def __repr__(self) -> str:
        modules = [m.name for m in (self.loader.modules if self.loader else [])]
        return f"<AppEngine booted={self._booted} modules={modules}>"
