"""
Application
===========
The ASGI application factory.
main.py in every axon project does exactly one thing:
    from axon.core.engine.application import app
"""
from __future__ import annotations

import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s -- %(message)s",
    stream=sys.stdout,
)

from axon.core.engine.app_engine import AppEngine, _get_defaults
import axon.core.engine.app_engine as _engine_mod


def _create_asgi_app():
    from fastapi import FastAPI, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from contextlib import asynccontextmanager
    from typing import AsyncGenerator

    from axon.core.routing.responses import PlatformHTTPException
    from axon.core.engine.platform_router import _build_platform_router

    _engine: AppEngine | None = None

    @asynccontextmanager
    async def _lifespan(_app: FastAPI) -> AsyncGenerator[None, None]:
        nonlocal _engine

        _engine = AppEngine()
        _engine_mod._engine_instance = _engine

        # Also publish to user project's app.core.app_engine shim if present
        try:
            import app.core.app_engine as _shim  # graceful compat shim for old projects
            _shim._engine_instance = _engine
        except ImportError:
            pass

        config_yaml, env_file, modules_dir = _get_defaults()
        await _engine._boot(
            config_yaml=config_yaml,
            env_file=env_file,
            modules_dir=modules_dir,
        )

        for fa_router in _engine.collect_routers():
            _app.include_router(fa_router)

        _app.include_router(_build_platform_router(_engine))
        await _engine.hooks.emit("platform.app.configure", _app)

        yield

        await _engine.shutdown()

    _asgi = FastAPI(
        title="Axon Platform",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=_lifespan,
    )

    @_asgi.exception_handler(PlatformHTTPException)
    async def _exc_handler(request: Request, exc: PlatformHTTPException):
        return JSONResponse(status_code=exc.status_code, content=exc.to_dict())

    from fastapi.exceptions import RequestValidationError
    @_asgi.exception_handler(RequestValidationError)
    async def _validation_exc_handler(request: Request, exc: RequestValidationError):
        errors = []
        for err in exc.errors():
            field = ".".join(str(l) for l in err.get("loc", [])[1:])
            errors.append({"field": field or "request", "message": err.get("msg", "invalid")})
        return JSONResponse(status_code=422, content={
            "error": True, "status": 422, "code": "validation_error",
            "message": "Request validation failed", "errors": errors,
        })

    from fastapi.exceptions import HTTPException as FastAPIHTTPException
    @_asgi.exception_handler(FastAPIHTTPException)
    async def _http_exc_handler(request: Request, exc: FastAPIHTTPException):
        from axon.core.routing.responses import _STATUS_CODES
        code = _STATUS_CODES.get(exc.status_code, "error")
        return JSONResponse(status_code=exc.status_code, content={
            "error": True, "status": exc.status_code,
            "code": code, "message": exc.detail or "",
        })

    @_asgi.exception_handler(Exception)
    async def _unhandled_exc_handler(request: Request, exc: Exception):
        logging.getLogger("platform").exception("Unhandled exception: %s", exc)
        msg = str(exc) if (_engine and _engine.cfg.get("platform.debug", False)) else "An internal error occurred"
        return JSONResponse(status_code=500, content={
            "error": True, "status": 500, "code": "server_error", "message": msg,
        })

    @_asgi.middleware("http")
    async def _pipeline_middleware(request, call_next):
        from axon.core.routing.middleware import RequestContext, ResponseContext, RequestAborted
        from fastapi.responses import JSONResponse

        if _engine is None:
            return await call_next(request)

        req = RequestContext(
            method  = request.method,
            path    = request.url.path,
            headers = dict(request.headers),
            query   = dict(request.query_params),
        )

        try:
            req = await _engine.pipeline.run_request(req)
        except RequestAborted as exc:
            return JSONResponse(
                status_code=exc.status,
                content={"error": True, "status": exc.status,
                         "message": exc.message, "code": exc.code},
            )

        for k, v in req.state.items():
            setattr(request.state, k, v)

        response = await call_next(request)
        res = ResponseContext(status_code=response.status_code)
        res = await _engine.pipeline.run_response(req, res)

        for k, v in res.headers.items():
            response.headers[k] = v
        if res.status_code != response.status_code:
            response.status_code = res.status_code

        return response

    import os
    origins = os.environ.get("PLATFORM__CORS__ALLOW_ORIGINS", "*").split(",")
    _asgi.add_middleware(
        CORSMiddleware,
        allow_origins     = origins,
        allow_methods     = ["*"],
        allow_headers     = ["*"],
        allow_credentials = False,
    )

    return _asgi


app: object = _create_asgi_app()
