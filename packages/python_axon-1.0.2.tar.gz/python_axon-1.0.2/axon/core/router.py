# Backward-compat shim -- canonical location: axon.core.routing.router
from axon.core.routing.router import Router, Context  # noqa: F401
