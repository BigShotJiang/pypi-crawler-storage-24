"""
BaseService
===========
Every service class in a module should extend this.
Provides the same platform conveniences as BaseModule without the
lifecycle hooks — services are not lifecycle-managed by the platform,
they are resolved from the container on demand.

Usage
-----
    # services.py
    from axon.core.module.base_service import BaseService
    from axon.core.log import Log

    class OrderService(BaseService):

        def create(self, customer: str, amount: float) -> dict:
            self.log_i("creating order for %s", customer)
            with self.db().session() as s:
                ...

        def notify(self, order_id: int) -> None:
            # Resolve another service from the container
            mailer = self.make("MailService")
            mailer.send(...)

            # Fire an event
            import asyncio
            asyncio.create_task(self.emit("order.created", {"id": order_id}))

Cross-module service access
---------------------------
If your service needs another module's service, use self.make():

    class BillingService(BaseService):
        def charge(self, user_id: int, amount: float):
            # Resolve auth module's UserService — no direct import
            users = self.make("UserService")
            user  = users.find(user_id)
            ...

    Or inject lazily at class level with inject():

        from axon.core.routing.inject import inject

        class BillingService(BaseService):
            _users: "UserService" = inject("UserService")

            def charge(self, user_id: int, amount: float):
                user = self._users.find(user_id)   # resolved on first access
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING, TypeVar, overload

if TYPE_CHECKING:
    from axon.core.db.migration_runner import MigrationRunner
    from axon.core.engine.app_engine import AppEngine

from axon.core.logging.log import Log

T = TypeVar("T")


class BaseService:
    """
    Base class for all module services.

    The container instantiates services with no arguments.
    Platform deps (app, db, config) are resolved lazily from _engine_instance.

    Subclass this and add your business logic methods.
    Do NOT override __init__ unless you call super().__init__() first.
    """

    #: Log tag — defaults to class name. Override to customise.
    tag: str = ""

    def __init__(self) -> None:
        from axon.core.engine.app_engine import _engine_instance
        self._app: "AppEngine" = _engine_instance  # type: ignore[assignment]
        if not self.tag:
            self.tag = self.__class__.__name__

    # ------------------------------------------------------------------
    # Platform API
    # ------------------------------------------------------------------

    @overload
    def make(self, name_or_type: type[T]) -> T: ...

    @overload
    def make(self, name_or_type: str) -> Any: ...

    def make(self, name_or_type: str | type[T]) -> T | Any:
        """Resolve any registered service from the container."""
        return self._app.container.make(name_or_type)

    def config(self, key: str, default: Any = None) -> Any:
        """Read config by dot-notation key. e.g. config('auth.secret')"""
        return self._app.config(key, default)

    def db(self) -> "MigrationRunner":
        """Return the DB runner — use db().session() as a context manager."""
        return self._app.db

    async def emit(self, event: str, payload: Any = None) -> None:
        """Fire a platform event."""
        await self._app.hooks.emit(event, payload)

    async def filter(self, event: str, value: Any) -> Any:
        """Run a value through the filter bus."""
        return await self._app.hooks.filter(event, value)

    # ------------------------------------------------------------------
    # Logging shortcuts
    # ------------------------------------------------------------------

    def log_d(self, msg: str, *args) -> None:
        Log.d(self.tag, msg, *args)

    def log_i(self, msg: str, *args) -> None:
        Log.i(self.tag, msg, *args)

    def log_w(self, msg: str, *args) -> None:
        Log.w(self.tag, msg, *args)

    def log_e(self, msg: str, *args, exc: BaseException | None = None) -> None:
        Log.e(self.tag, msg, *args, exc=exc)

    def log_wtf(self, msg: str, *args) -> None:
        Log.wtf(self.tag, msg, *args)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"
