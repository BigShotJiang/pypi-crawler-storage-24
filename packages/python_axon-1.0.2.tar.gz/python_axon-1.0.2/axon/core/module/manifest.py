"""
Manifest
========
The typed contract every module declares to the platform.

Module usage
------------
    # manifest.py  (every module must have this file)
    from axon.core.manifest import Manifest

    manifest = Manifest(
        name        = "billing",
        version     = "1.0.0",
        description = "Handles invoices, payments, and subscriptions.",
        author      = "BEANNSOFTS LIMITED",
        requires    = ["auth"],          # load after auth module
        provides    = ["billing_svc"],   # services we expose
        config      = {
            "currency":    "KES",
            "tax_rate":    0.16,
            "trial_days":  14,
        },
    )

That is the only thing in manifest.py. No free variables, no guessing field names,
no silent typos — the platform validates the object at load time.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


# Semver-ish: 1, 1.0, or 1.0.0  (all digits and dots)
_VERSION_RE = re.compile(r"^\d+(\.\d+){0,2}$")
# snake_case identifier
_NAME_RE    = re.compile(r"^[a-z][a-z0-9_]*$")


@dataclass
class Manifest:
    """
    Declares everything the platform needs to know about a module
    before loading it.

    Parameters
    ----------
    name : str
        Unique snake_case identifier.  Must match the module folder name.
        Example: ``"billing"``, ``"user_auth"``.

    version : str
        Semantic version string.  Examples: ``"1"``, ``"1.0"``, ``"1.2.3"``.

    description : str
        One-line human-readable summary shown in platform status output.

    author : str
        Author name or team name.

    requires : list[str]
        Names of other modules this module depends on.
        The platform guarantees those modules are started first.
        Example: ``["auth", "mailer"]``

    provides : list[str]
        Informational — service or capability names this module registers.
        Used for documentation and dependency validation.
        Example: ``["billing_svc", "invoice_pdf"]``

    enabled : bool
        Set to ``False`` to disable the module without deleting it.
        Disabled modules are skipped entirely at discovery time.

    config : dict
        Default configuration values for this module.
        Keys become available via ``ctx.config("module_name.key")``.
        Override any key with an env var: ``MODULE_NAME__KEY=value``.

        Example::

            config = {
                "currency":  "KES",
                "tax_rate":  0.16,
                "debug":     False,
            }
    """

    name:        str
    version:     str                     = "1.0.0"
    description: str                     = ""
    author:      str                     = ""
    requires:    list[str]               = field(default_factory=list)
    provides:    list[str]               = field(default_factory=list)
    replaces:    list[str]               = field(default_factory=list)
    enabled:     bool                    = True
    config:      dict[str, Any]          = field(default_factory=dict)
    routes:      str | None              = None
    # routes: dotted path to the route entry-point module, relative to the module package.
    #   "routes"        → app.modules.<name>.routes
    #   "http.routes"   → app.modules.<name>.http.routes
    #   "api.v1.routes" → app.modules.<name>.api.v1.routes
    # If None or omitted, no routes are mounted for this module.
    # The platform imports this module and collects all Router instances at top level.

    # ------------------------------------------------------------------
    # Validation — runs automatically on construction
    # ------------------------------------------------------------------

    def __post_init__(self) -> None:
        errors: list[str] = []

        # name
        if not self.name:
            errors.append("'name' is required")
        elif not _NAME_RE.match(self.name):
            errors.append(
                f"'name' must be lowercase snake_case (got {self.name!r}). "
                "Example: 'billing', 'user_auth'"
            )

        # version
        if not _VERSION_RE.match(self.version):
            errors.append(
                f"'version' must be a semver string like '1.0.0' (got {self.version!r})"
            )

        # requires — must all be valid names
        for dep in self.requires:
            if not _NAME_RE.match(dep):
                errors.append(
                    f"'requires' entry {dep!r} is not a valid module name. "
                    "Use snake_case identifiers."
                )

        # config — keys must be strings, no nesting (flat key=value)
        for k, v in self.config.items():
            if not isinstance(k, str):
                errors.append(f"config key {k!r} must be a string")
            if isinstance(v, dict):
                errors.append(
                    f"config[{k!r}] is a nested dict — config values must be "
                    "scalars (str, int, float, bool). "
                    "Use 'module_name.key' dot-notation to access them."
                )

        if errors:
            bullet = "\n  • "
            raise ValueError(
                f"Manifest for {self.name!r} has {len(errors)} error(s):"
                f"{bullet}{bullet.join(errors)}"
            )

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "enabled" if self.enabled else "DISABLED"
        return f"<Manifest {self.name} v{self.version} [{status}]>"
