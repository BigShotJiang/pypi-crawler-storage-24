"""
VendorLoader
============
Reads app/providers/providers.py, discovers installed vendor packages via
Python entry points, and returns Module instances ready for the normal
boot pipeline.

Flow
----
1. Import app/providers/providers.py
2. Read its `providers` list (list of _VendorRef objects)
3. For each ref, find the matching entry point in "axon.providers" group
4. Load the VendorProvider subclass, get module_package
5. Import module_package, find Module class, instantiate
6. Merge the vendor's manifest.config into ConfigManager
7. Return instances — AppEngine adds them to the module list

Entry point format (vendor's pyproject.toml)
--------------------------------------------
    [project.entry-points."axon.providers"]
    resend = "axon_resend.provider:ResendProvider"
"""
from __future__ import annotations

import importlib
import importlib.metadata
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from axon.core.engine.app_engine import AppEngine
    from axon.core.module.base_module import BaseModule

from axon.core.module.vendor_provider import VendorProvider, _VendorRef

logger = logging.getLogger(__name__)

_ENTRY_POINT_GROUP = "axon.providers"


# ── Entry point discovery ─────────────────────────────────────────────────────

def _discover_installed() -> dict[str, type[VendorProvider]]:
    """Scan installed packages for axon.providers entry points."""
    found: dict[str, type[VendorProvider]] = {}
    try:
        eps = importlib.metadata.entry_points(group=_ENTRY_POINT_GROUP)
    except Exception as exc:
        logger.warning("VendorLoader: failed to scan entry points: %s", exc)
        return found

    for ep in eps:
        try:
            cls = ep.load()
            if isinstance(cls, type) and issubclass(cls, VendorProvider):
                cls.validate()
                found[ep.name] = cls
                logger.debug("VendorLoader: found '%s' → %s", ep.name, cls.module_package)
            else:
                logger.warning(
                    "VendorLoader: '%s' is not a VendorProvider subclass — skipped.", ep.name
                )
        except Exception as exc:
            logger.warning("VendorLoader: failed to load entry point '%s': %s", ep.name, exc)

    return found


# ── Providers file loader ─────────────────────────────────────────────────────

def _load_providers_file() -> list[_VendorRef]:
    """
    Import app/providers/providers.py and return its `providers` list.
    Returns empty list if the file does not exist (providers are optional).
    """
    project_root = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))
    providers_file = project_root / "app" / "providers" / "providers.py"

    if not providers_file.exists():
        return []

    import importlib.util
    spec = importlib.util.spec_from_file_location("_axon_providers", providers_file)
    if spec is None or spec.loader is None:
        return []

    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    except Exception as exc:
        logger.error("VendorLoader: error in app/providers/providers.py: %s", exc, exc_info=True)
        return []

    raw = getattr(mod, "providers", [])
    if not isinstance(raw, list):
        logger.warning(
            "VendorLoader: providers.py must define `providers` as a list — found %s",
            type(raw).__name__,
        )
        return []

    refs = []
    for item in raw:
        if isinstance(item, _VendorRef):
            refs.append(item)
        else:
            logger.warning("VendorLoader: unrecognised entry in providers list: %r — skipped", item)

    return refs


# ── Main load function ────────────────────────────────────────────────────────

def load_vendor_modules(app: "AppEngine") -> list["BaseModule"]:
    """
    Load all vendor modules declared in app/providers/providers.py.
    Returns instantiated BaseModule objects ready for the boot pipeline.
    """
    refs = _load_providers_file()
    if not refs:
        return []

    installed = _discover_installed()
    instances: list["BaseModule"] = []

    for ref in refs:
        provider_cls = installed.get(ref.name)
        if provider_cls is None:
            logger.warning(
                "VendorLoader: provider '%s' is listed in providers.py but not installed. "
                "Run: pip install python-axon-%s",
                ref.name, ref.name,
            )
            continue

        try:
            pkg       = provider_cls.module_package
            module_pkg = importlib.import_module(pkg)
            module_cls = getattr(module_pkg, "Module", None)

            if module_cls is None:
                logger.warning("VendorLoader: '%s' has no Module class — skipped.", pkg)
                continue

            from axon.core.module.base_module import BaseModule
            if not issubclass(module_cls, BaseModule):
                logger.warning("VendorLoader: '%s.Module' is not a BaseModule — skipped.", pkg)
                continue

            # Merge vendor manifest config into ConfigManager
            try:
                manifest_mod = importlib.import_module(f"{pkg}.manifest")
                manifest     = getattr(manifest_mod, "manifest", None)
                if manifest:
                    # Apply any config_overrides from VendorProvider.use(config={...})
                    merged_config = dict(manifest.config)
                    for env_key, env_val in ref.config_overrides.items():
                        # Convert RESEND__API_KEY → api_key inside the resend namespace
                        prefix = manifest.name.upper() + "__"
                        if env_key.upper().startswith(prefix):
                            sub = env_key[len(prefix):].lower()
                            merged_config[sub] = env_val

                    app.cfg.merge_module_config(manifest.name, merged_config)
                    if hasattr(app, "loader") and app.loader:
                        app.loader.manifests[manifest.name] = manifest
            except Exception as exc:
                logger.debug("VendorLoader: no manifest for '%s': %s", pkg, exc)

            instance = module_cls(app)
            instances.append(instance)
            logger.info("VendorLoader: loaded vendor '%s' from '%s'", ref.name, pkg)

        except Exception as exc:
            logger.error(
                "VendorLoader: failed to load vendor '%s': %s", ref.name, exc, exc_info=True
            )

    return instances
