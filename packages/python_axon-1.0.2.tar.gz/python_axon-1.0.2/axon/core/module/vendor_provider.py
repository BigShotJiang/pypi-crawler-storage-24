"""
VendorProvider
==============
Base class for pip-installable Axon vendor modules.

A vendor package (e.g. python-axon-resend) ships one class that inherits
from VendorProvider and registers it via a Python package entry point:

    [project.entry-points."axon.providers"]
    resend = "axon_resend.provider:ResendProvider"

After that, users install the package and list it in app/providers/providers.py:

    from axon.core.module.vendor_provider import VendorProvider

    providers = [
        VendorProvider.use("resend"),
    ]

Or with config overrides:

    providers = [
        VendorProvider.use("resend", config={
            "RESEND__FROM": "MyApp <no-reply@myapp.com>",
        }),
    ]

Then run:
    ./manage vendor:publish resend   → writes env stubs to .env.example
    ./manage vendor:list             → shows all installed vendors + their keys
"""
from __future__ import annotations
from typing import Any


class VendorProvider:
    """
    Descriptor for a vendor-published Axon module.

    Vendor package authors subclass this and set module_package,
    config_keys, and optional_keys.

    App developers never subclass this — they call VendorProvider.use("name").
    """

    # ── Set by the vendor package author ─────────────────────────────────
    #: Dotted path to the package containing the Module class
    #: e.g. "axon_resend.resend"
    module_package: str = ""

    #: Required env vars this module needs → short description
    #: These become uncommented stubs in .env.example after vendor:publish
    config_keys: dict[str, str] = {}

    #: Optional / tunable env vars → description
    #: These become commented-out hints in .env.example
    optional_keys: dict[str, str] = {}

    # ── Set by VendorProvider.use() at app level ──────────────────────────
    _overrides: dict[str, Any]

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls._overrides = {}

    # ── App-developer API ─────────────────────────────────────────────────

    @classmethod
    def use(cls, name: str, *, config: dict[str, Any] | None = None) -> "_VendorRef":
        """
        Reference a vendor provider by its registered entry point name.
        Used in app/providers/providers.py.

            from axon.core.module.vendor_provider import VendorProvider

            providers = [
                VendorProvider.use("resend"),
                VendorProvider.use("stripe", config={"STRIPE__CURRENCY": "KES"}),
            ]
        """
        return _VendorRef(name=name, config_overrides=config or {})

    # ── Vendor author API ─────────────────────────────────────────────────

    @classmethod
    def provider_name(cls) -> str:
        return cls.module_package.split(".")[-1] if cls.module_package else cls.__name__

    @classmethod
    def validate(cls) -> None:
        if not cls.module_package:
            raise ValueError(
                f"{cls.__name__}.module_package must be the dotted path "
                "to your module package, e.g. 'axon_resend.resend'."
            )


class _VendorRef:
    """
    Internal — a reference to a vendor by name, produced by VendorProvider.use().
    Held in the providers list and resolved by VendorLoader at boot.
    """
    __slots__ = ("name", "config_overrides")

    def __init__(self, name: str, config_overrides: dict[str, Any]) -> None:
        self.name             = name
        self.config_overrides = config_overrides

    def __repr__(self) -> str:
        return f"<VendorRef name={self.name!r}>"
