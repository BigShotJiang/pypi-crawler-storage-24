"""
Module Loader
=============
Discovers, validates, and dependency-sorts all modules under /modules.

Flow:
    discover()   → find all module folders
    validate()   → ensure manifest + BaseModule contract are met
    order()      → topological sort by `requires`
    load()       → instantiate each module class
"""

from __future__ import annotations

import importlib
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from axon.core.app_engine import AppEngine
    from axon.core.base_module import BaseModule

logger = logging.getLogger(__name__)


# Manifest is now a proper platform type — import from its canonical location
from axon.core.module.manifest import Manifest  # noqa: F401


# ------------------------------------------------------------------
# Errors
# ------------------------------------------------------------------

class ModuleValidationError(Exception):
    pass


class CircularDependencyError(Exception):
    pass


class MissingDependencyError(Exception):
    pass


# ------------------------------------------------------------------
# Loader
# ------------------------------------------------------------------

class ModuleLoader:
    """
    Discovers and loads all enabled modules from *modules_root*.

    After calling ``discover_and_load()``, the ``.modules`` attribute
    contains ordered, instantiated module objects ready for boot.
    """

    def __init__(self, modules_root: Path, app: "AppEngine") -> None:
        self.modules_root = modules_root
        self.app = app
        self.manifests: dict[str, Manifest] = {}
        self.modules: list["BaseModule"] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def discover_and_load(self) -> list["BaseModule"]:
        """Full pipeline: discover → validate → order → instantiate."""
        raw = self._discover()
        validated = self._validate_all(raw)
        ordered = self._topological_sort(validated)
        self.modules = self._instantiate(ordered)
        return self.modules

    # ------------------------------------------------------------------
    # Step 1 — Discover
    # ------------------------------------------------------------------

    def _discover(self) -> list[Path]:
        """Return all sub-directories of modules_root that look like modules."""
        if not self.modules_root.is_dir():
            logger.warning("ModuleLoader: modules directory not found: %s", self.modules_root)
            return []

        candidates: list[Path] = []
        for path in sorted(self.modules_root.iterdir()):
            if not path.is_dir():
                continue
            if path.name.startswith(("_", ".")):
                continue
            candidates.append(path)

        return candidates

    # ------------------------------------------------------------------
    # Step 2 — Validate
    # ------------------------------------------------------------------

    def _validate_all(self, paths: list[Path]) -> list[tuple[Path, Manifest]]:
        valid: list[tuple[Path, Manifest]] = []
        for path in paths:
            try:
                manifest = self._load_manifest(path)
            except ModuleValidationError as exc:
                logger.warning("ModuleLoader: skipping '%s' — %s", path.name, exc)
                continue

            if not manifest.enabled:
                logger.info("ModuleLoader: module '%s' is disabled, skipping", manifest.name)
                continue

            self.manifests[manifest.name] = manifest
            valid.append((path, manifest))

        return valid

    def _load_manifest(self, path: Path) -> Manifest:
        pkg          = f"app.modules.{path.name}"
        manifest_pkg = f"{pkg}.manifest"

        try:
            mod = importlib.import_module(manifest_pkg)
        except ModuleNotFoundError as exc:
            raise ModuleValidationError(
                f"Missing manifest.py in '{path.name}'. "
                "Create manifest.py with a Manifest instance."
            ) from exc
        except Exception as exc:
            raise ModuleValidationError(
                f"Error importing manifest for '{path.name}': {exc}"
            ) from exc

        from axon.core.module.manifest import Manifest as ManifestClass

        obj = getattr(mod, "manifest", None)

        if obj is None:
            # Detect old free-variable style and give a migration hint
            old_name = getattr(mod, "name", None)
            if old_name:
                _n = getattr(mod, "name", path.name)
                _v = getattr(mod, "version", "1.0.0")
                _d = getattr(mod, "description", "")
                hint = (
                    "from axon.core.manifest import Manifest"
                    + chr(10) + chr(10)
                    + "manifest = Manifest("
                    + chr(10)
                    + '    name        = "' + _n + '",'
                    + chr(10)
                    + '    version     = "' + _v + '",'
                    + chr(10)
                    + '    description = "' + _d + '",'
                    + chr(10)
                    + ")"
                )
                raise ModuleValidationError(
                    f"'{path.name}/manifest.py' uses the old variable style. "
                    "Replace loose variables with a Manifest instance:"
                    + chr(10) + chr(10) + hint
                )
            raise ModuleValidationError(
                f"'{path.name}/manifest.py' must assign a Manifest instance "
                "to a variable named 'manifest'."
                + chr(10) + chr(10)
                + "  from axon.core.manifest import Manifest"
                + chr(10)
                + '  manifest = Manifest(name="' + path.name + '", ...)'
            )

        if not isinstance(obj, ManifestClass):
            raise ModuleValidationError(
                f"'{path.name}/manifest.py': 'manifest' must be a "
                f"Manifest instance, got {type(obj).__name__!r}."
            )

        if obj.name != path.name:
            raise ModuleValidationError(
                f"'{path.name}/manifest.py': manifest.name={obj.name!r} "
                f"does not match the folder name {path.name!r}. "
                "They must be identical."
            )

        # Validate __init__.py exports Module(BaseModule)
        try:
            init_mod = importlib.import_module(pkg)
        except Exception as exc:
            raise ModuleValidationError(
                f"Cannot import '{pkg}.__init__': {exc}"
            ) from exc

        module_cls = getattr(init_mod, "Module", None)
        if module_cls is None:
            raise ModuleValidationError(
                f"'{pkg}.__init__' must export a class named 'Module'."
            )

        from axon.core.base_module import BaseModule
        if not (isinstance(module_cls, type) and issubclass(module_cls, BaseModule)):
            raise ModuleValidationError(
                f"'{pkg}.Module' must be a subclass of BaseModule."
            )

        return obj


    # ------------------------------------------------------------------
    # Step 3 — Topological sort (Kahn's algorithm)
    # ------------------------------------------------------------------

    def _topological_sort(
        self, validated: list[tuple[Path, Manifest]]
    ) -> list[tuple[Path, Manifest]]:
        name_to_entry = {m.name: (p, m) for p, m in validated}

        # Validate all dependencies are present
        for _, manifest in validated:
            for dep in manifest.requires:
                if dep not in name_to_entry:
                    raise MissingDependencyError(
                        f"Module '{manifest.name}' requires '{dep}', "
                        f"which is not loaded. "
                        f"Loaded: {sorted(name_to_entry)}"
                    )

        # Build adjacency + in-degree
        in_degree: dict[str, int] = {m.name: 0 for _, m in validated}
        dependents: dict[str, list[str]] = {m.name: [] for _, m in validated}

        for _, manifest in validated:
            for dep in manifest.requires:
                dependents[dep].append(manifest.name)
                in_degree[manifest.name] += 1

        # Kahn's BFS
        queue = [name for name, deg in in_degree.items() if deg == 0]
        ordered: list[str] = []

        while queue:
            node = queue.pop(0)
            ordered.append(node)
            for dependent in dependents[node]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        if len(ordered) != len(name_to_entry):
            cycle = sorted(set(name_to_entry) - set(ordered))
            raise CircularDependencyError(
                f"Circular dependency detected among: {cycle}"
            )

        # logger.info("ModuleLoader: load order: %s", ordered)
        return [name_to_entry[name] for name in ordered]

    # ------------------------------------------------------------------
    # Step 4 — Instantiate
    # ------------------------------------------------------------------

    def _instantiate(
        self, ordered: list[tuple[Path, Manifest]]
    ) -> list["BaseModule"]:
        instances: list["BaseModule"] = []
        for path, manifest in ordered:
            pkg = f"app.modules.{path.name}"
            init_mod = importlib.import_module(pkg)
            module_cls = init_mod.Module

            # Merge module config schema into ConfigManager
            if manifest.config:
                self.app.cfg.merge_module_config(
                    manifest.name, manifest.config
                )

            instance = module_cls(self.app)
            instances.append(instance)
            # logger.info(
            #     "ModuleLoader: instantiated '%s' v%s",
            #     manifest.name,
            #     manifest.version,
            # )
        return instances
