"""
BaseModule  --  Abstract contract for all modules.
"""
from __future__ import annotations

import abc
from typing import TYPE_CHECKING, Any, Callable, TypeVar, overload

if TYPE_CHECKING:
    from axon.core.engine.app_engine import AppEngine

from axon.core.logging.log import Log
from axon.core.module.manifest import Manifest      # noqa: F401 -- re-exported
from axon.core.routing.router import Context, Router  # noqa: F401 -- re-exported
from axon.core.routing.inject import inject          # noqa: F401 -- re-exported
from axon.core.routing.middleware import RequestContext, ResponseContext  # noqa: F401 -- re-exported
from axon.core.routing.responses import (            # noqa: F401 -- re-exported
    bad_request, unauthorized, forbidden, not_found,
    conflict, unprocessable, server_error,
)

T = TypeVar("T")

class BaseModule(abc.ABC):
    """
    Extend this in your module's __init__.py.

    Module builder imports (everything you need):
        from axon.core.base_module import (
            BaseModule, Manifest, Router, Context,
            inject, Log,
            bad_request, unauthorized, forbidden,
            not_found, conflict, unprocessable, server_error,
        )

    Routing (two styles):
        # Simple -- single router as class attribute
        class Module(BaseModule):
            router = Router(prefix="/orders")

            @router.get("/{id}")
            async def get(order_id: int, ctx: Context, svc: OrderService):
                ...

        # Complex -- multiple routers from sub-files
        class Module(BaseModule):
            from .controllers.orders import router as orders_router
            from .controllers.payments import router as payments_router
            routers = [orders_router, payments_router]
    """

    def __init__(self, app: "AppEngine") -> None:
        self.app = app
        self.tag: str = self.name

    # ── Identity ──────────────────────────────────────────────────────────

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Unique snake_case identifier. Must match manifest.name."""

    @property
    def version(self) -> str:
        return "0.0.0"

    @property
    def description(self) -> str:
        return ""

    # ── Routing ───────────────────────────────────────────────────────────

    #: Single router -- assign a Router() instance here
    router: "Router | None" = None
    #: Multiple routers -- assign a list of Router() instances here
    routers: "list[Router] | None" = None

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def register(self) -> None:
        """
        Phase 1 -- called sync before any module boots.
        Bind services into the container.
        Do NOT resolve other services here.
        """

    async def boot(self) -> None:
        """
        Phase 2 -- called async after all modules have registered.
        Register hook listeners, open connections, resolve services.
        """

    async def shutdown(self) -> None:
        """
        Called on graceful shutdown in reverse dependency order.
        Close connections, flush buffers, release resources.
        """

    # ── Platform API ──────────────────────────────────────────────────────

    def bind(self, name_or_type, cls=None, *, singleton: bool = True) -> None:
        """
        Register a service.
            self.bind(OrderService)                   # by type, key = class name
            self.bind(OrderService, singleton=False)  # transient
            self.bind("order_svc", OrderService)      # explicit string key
            self.bind(IMailer, SMTPMailer)            # bind interface to impl
        """
        self.app.container.bind(name_or_type, cls, singleton=singleton, owner=self.name)

    def override(self, name_or_type, cls=None, *, singleton: bool = True) -> None:
        """
        Explicitly replace another module's service.
        Semantically identical to bind() but signals intent to readers.

            # resend_module replaces the default SMTP mailer:
            self.override(MailService, ResendMailService)

            # Any module using make(MailService) or svc: MailService DI
            # now gets ResendMailService -- no calling code changes.
        """
        self.app.container.override(name_or_type, cls, singleton=singleton, owner=self.name)

    def extend(self, name_or_type, extended_cls: type, *, singleton: bool = True) -> None:
        """
        Wrap an existing service with a subclass/decorator class.
        The original is preserved under  make("ServiceName.base").

        The extended class receives the original instance as its first
        constructor argument -- delegate to it for unchanged behaviour.

        Example (otp_module extending auth_module's AuthService):

            class OTPAuthService(AuthService):
                def __init__(self, base: AuthService) -> None:
                    # Do NOT call super().__init__() here -- base is already built
                    self._base = base

                def login(self, credentials):
                    user = self._base.login(credentials)  # delegate
                    self._issue_otp(user)                 # add behaviour
                    return user

            # In otp_module.register()  (requires = ["auth"] in manifest):
            self.extend(AuthService, OTPAuthService)

        The requires = ["auth"] in manifest.py guarantees auth registers
        first so the original binding exists when extend() is called.
        """
        self.app.container.extend(name_or_type, extended_cls, singleton=singleton, owner=self.name)

    def patch_method(
        self,
        name_or_type,
        method_name: str,
        new_fn,
    ) -> None:
        """
        Replace a single method on a live service instance.
        Python equivalent of  service.method = newFunction  in JavaScript.

        The replacement function receives the ORIGINAL method as its first
        argument so you can call through to it:

            def my_send(original_send, to, subject, body):
                Log.i(self.tag, "intercepted send to %s", to)
                return original_send(to, subject, body)  # call through

            self.patch_method(MailService, "send", my_send)

        Works on already-resolved singletons — mutates the live instance.
        Original preserved at  service.method_name__original.

        Compare with decorate() which wraps the whole service object,
        and extend() which subclasses it. patch_method() is the surgical
        option -- one method, in place, no new class needed.
        """
        self.app.container.patch_method(name_or_type, method_name, new_fn, owner=self.name)

    def decorate(self, name_or_type, decorator_fn) -> None:
        """
        Wrap a service with a function instead of a subclass.
        Useful for adding cross-cutting concerns without subclassing.

            def add_metrics(svc):
                original_send = svc.send
                def send_with_metrics(*a, **kw):
                    timer.start()
                    result = original_send(*a, **kw)
                    timer.record()
                    return result
                svc.send = send_with_metrics
                return svc

            self.decorate(MailService, add_metrics)
        """
        self.app.container.decorate(name_or_type, decorator_fn, owner=self.name)

    def instance(self, name: str, obj: Any) -> None:
        self.app.container.instance(name, obj, owner=self.name)

    def use(
        self,
        handler: Callable,
        *,
        path: str = "",
        priority: int = 100,
    ) -> None:
        """
        Register a request middleware for this module.
        Runs before every matching request, in priority order across all modules.

            async def _auth_check(self, req: RequestContext) -> None:
                token = req.header("Authorization")
                if not token:
                    req.abort(401, "Authentication required")

            # In register() or boot():
            self.use(self._auth_check)
            self.use(self._auth_check, path="/admin/*", priority=10)
        """
        self.app.pipeline.add_request(handler, path=path, priority=priority, owner=self.name)

    def schedule(self, cron: str, handler: Callable, *, name: str = "") -> None:
        """
        Register a cron-style background task.
        Called in boot() after the engine is ready.

            self.schedule("0 * * * *",  self._cleanup)     # every hour
            self.schedule("*/5 * * * *", self._sync)       # every 5 min
            self.schedule("0 2 * * *",   self._report)     # daily at 2am
        """
        self.app.scheduler.add(
            cron, handler,
            owner=self.name,
            name=name or getattr(handler, "__name__", repr(handler)),
        )

    def dispatch(self, job_class, *, delay: float = 0, **kwargs) -> None:
        """
        Dispatch a background job. Returns immediately.

            self.dispatch(SendWelcomeEmail, user_id=user.id)
            self.dispatch(SendReminder, delay=3600, booking_id=booking.id)
        """
        self.app.jobs.dispatch(job_class, delay=delay, **kwargs)

    def use_response(
        self,
        handler: Callable,
        *,
        path: str = "",
        priority: int = 100,
    ) -> None:
        """
        Register a response middleware for this module.
        Runs after every matching route handler, before the response is sent.

            async def _add_cors(self, res: ResponseContext) -> ResponseContext:
                res.set_header("X-Module", self.name)
                return res

            self.use_response(self._add_cors)
        """
        self.app.pipeline.add_response(handler, path=path, priority=priority, owner=self.name)

    @overload
    def make(self, name_or_type: type[T]) -> T: ...

    @overload
    def make(self, name_or_type: str) -> Any: ...

    def make(self, name_or_type: str | type[T]) -> T | Any:
        return self.app.container.make(name_or_type)

    def on(self, event: str, handler, *, priority: int = 100) -> None:
        self.app.hooks.on(event, handler, priority=priority)

    async def emit(self, event: str, payload: Any = None) -> None:
        await self.app.hooks.emit(event, payload)

    async def filter(self, event: str, value: Any) -> Any:
        return await self.app.hooks.filter(event, value)

    def config(self, key: str, default: Any = None) -> Any:
        return self.app.config(key, default)

    # ── Log shortcuts ─────────────────────────────────────────────────────

    def log_d(self, msg: str, *args) -> None:
        Log.d(self.tag, msg, *args)

    def log_i(self, msg: str, *args) -> None:
        Log.i(self.tag, msg, *args)

    def log_w(self, msg: str, *args) -> None:
        Log.w(self.tag, msg, *args)

    def log_e(self, msg: str, *args, exc=None) -> None:
        Log.e(self.tag, msg, *args, exc=exc)

    def log_wtf(self, msg: str, *args) -> None:
        Log.wtf(self.tag, msg, *args)

    def __repr__(self) -> str:
        return f"<Module {self.name} v{self.version}>"
