"""
DatabaseKernel
==============
Low-level database utilities used by migration commands and any other
kernel that needs to drop, inspect, or probe the database directly.

Intentionally has no dependency on AppEngine or the running platform —
safe to call before the app boots (e.g. migrate:fresh, db:wipe).
"""
from __future__ import annotations

import os
from pathlib import Path

_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


def _info(msg: str) -> None: print(f"  ℹ️  {msg}")


def load_db_url() -> str:
    """
    Read the database URL from config.yaml / .env without booting the engine.
    Supports both the flat database_url string and the structured database: block.
    """
    from axon.core.config.config_manager import ConfigManager
    from axon.core.db.migration_runner import _build_database_url
    cfg = ConfigManager()
    cfg.load_root(
        config_yaml=_PROJECT_ROOT / "config.yaml",
        env_file=_PROJECT_ROOT / ".env",
    )
    # Flat URL takes priority — backward compat
    flat = cfg.get("platform.database_url", None)
    if flat:
        return flat
    return _build_database_url(
        engine   = cfg.get("platform.database.engine",   "sqlite"),
        name     = cfg.get("platform.database.name",     "./platform.db"),
        host     = cfg.get("platform.database.host",     "localhost"),
        port     = cfg.get("platform.database.port",     None),
        user     = cfg.get("platform.database.user",     ""),
        password = cfg.get("platform.database.password", ""),
        driver   = cfg.get("platform.database.driver",   ""),
    )


def sanitize_url(url: str) -> str:
    """Strip password from a database URL before logging."""
    if "@" in url:
        scheme, rest = url.split("://", 1)
        creds, host  = rest.split("@", 1)
        return f"{scheme}://{creds.split(':')[0]}:***@{host}"
    return url


def drop_all(db_url: str) -> None:
    """
    Drop every table (and enum type on Postgres) from the database.
    Routes to the correct backend automatically.

    Used by:
        MigrationKernel.fresh()
        MigrationKernel.wipe()
    """
    if db_url.startswith("sqlite"):
        drop_sqlite(db_url)
    else:
        drop_postgres(db_url)


def drop_sqlite(db_url: str) -> None:
    """Delete the SQLite database file."""
    path_str = db_url.replace("sqlite:///", "")
    db_path  = (_PROJECT_ROOT / path_str).resolve()
    if db_path.exists():
        db_path.unlink()
        _info(f"Deleted {db_path.name}")
    else:
        _info("Database file not found (already clean)")


def drop_postgres(db_url: str) -> None:
    """
    Drop all tables and enum types in the public schema.
    Uses CASCADE so foreign-key order doesn't matter.
    """
    from sqlalchemy import create_engine, text

    sync = db_url.replace("+asyncpg", "").replace("+aiosqlite", "")
    engine = create_engine(sync)

    with engine.begin() as conn:
        conn.execute(text("""
            DO $$ DECLARE r RECORD; BEGIN
                FOR r IN (
                    SELECT tablename FROM pg_tables WHERE schemaname = 'public'
                ) LOOP
                    EXECUTE 'DROP TABLE IF EXISTS ' || quote_ident(r.tablename) || ' CASCADE';
                END LOOP;
            END $$;
        """))
        conn.execute(text("""
            DO $$ DECLARE r RECORD; BEGIN
                FOR r IN (
                    SELECT typname FROM pg_type
                    WHERE  typtype = 'e'
                    AND    typnamespace = 'public'::regnamespace
                ) LOOP
                    EXECUTE 'DROP TYPE IF EXISTS ' || quote_ident(r.typname) || ' CASCADE';
                END LOOP;
            END $$;
        """))

    engine.dispose()
    _info("All tables and enum types dropped")


def ping(db_url: str) -> bool:
    """Return True if the database is reachable."""
    try:
        from sqlalchemy import create_engine, text
        sync   = db_url.replace("+asyncpg", "").replace("+aiosqlite", "")
        engine = create_engine(sync, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        engine.dispose()
        return True
    except Exception:
        return False


# Verbosity → log level mapping (mirrors Django's --verbosity convention)
_VERBOSITY_LEVEL = {
    0: "ERROR",    # errors only
    1: "WARNING",  # default — silent boot, clean CLI output
    2: "INFO",     # shows module registration, boot steps
    3: "DEBUG",    # full trace — everything
}


def boot_cli_engine(verbosity: int = 1):
    """
    Boot the platform engine for CLI use — synchronous.

    verbosity controls log output during boot (mirrors Django --verbosity):
        0  errors only
        1  silent boot, clean CLI output  (default)
        2  shows module registration and boot steps
        3  full debug trace

    Usage:
        engine = boot_cli_engine(verbosity=verbosity)
        svc = engine.container.make(MyService)
        shutdown_cli_engine(engine)
    """
    import asyncio

    level = _VERBOSITY_LEVEL.get(verbosity, "WARNING")

    async def _boot():
        from axon.core.logging.log import configure as _log_configure
        _log_configure(level=level, fmt="pretty")

        from axon.core.engine.app_engine import AppEngine
        import axon.core.engine.app_engine as _mod
        engine = AppEngine()
        _mod._engine_instance = engine
        try:
            import axon.core.app_engine as _shim
            _shim._engine_instance = engine
        except ImportError:
            pass

        from axon.core.engine.app_engine import _CONFIG_YAML, _ENV_FILE, _MODULES_DIR
        await engine._boot(
            config_yaml=_CONFIG_YAML,
            env_file=_ENV_FILE,
            modules_dir=_MODULES_DIR,
        )
        return engine

    return asyncio.run(_boot())


def shutdown_cli_engine(engine, verbosity: int = 1) -> None:
    """Cleanly shut down an engine started with boot_cli_engine()."""
    import asyncio
    # Keep shutdown silent unless verbosity is high
    if verbosity < 2:
        from axon.core.logging.log import configure as _log_configure
        _log_configure(level="ERROR", fmt="pretty")
    asyncio.run(engine.shutdown())
