"""
ServerKernel
============
Development server commands.

Commands:
    runserver [host] [port]
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


class ServerKernel:

    @staticmethod
    def runserver(host: str = "0.0.0.0", port: int = 8000) -> None:
        """Start the FastAPI development server with live reload."""
        print(f"\n  🌐  http://{host}:{port}   (Ctrl+C to stop)\n")
        subprocess.run(
            [
                "uvicorn", "main:app",
                "--host", host,
                "--port", str(port),
                "--reload",
                "--reload-dir", str(_PROJECT_ROOT / "app"),
            ],
            cwd=_PROJECT_ROOT,
            env=os.environ.copy(),
        )
