"""
MigrationKernel
===============
All database migration and seeding logic.
Called exclusively by manage — never imported by the running app.

Commands surfaced:
    makemigrations [name]
    migrate [--step=N]
    migrate:rollback [--step=N]
    migrate:reset
    migrate:refresh [--step=N]
    migrate:fresh [--seed]
    migrate:status
    migrate:check
    migrate:seed  /  db:seed
    db:wipe
"""
from __future__ import annotations

import asyncio
import importlib.util
import os
import subprocess
import sys
from pathlib import Path


# ── Project paths (resolved once) ─────────────────────────────────────────────
_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))
_ALEMBIC_DIR  = _PROJECT_ROOT / "alembic"
_ALEMBIC_INI  = _PROJECT_ROOT / "alembic.ini"
_VERSIONS_DIR = _ALEMBIC_DIR / "versions"
_SEEDS_DIR    = _PROJECT_ROOT / "database" / "seeders"

_DO_NOT_EDIT = """\
# ╔══════════════════════════════════════════════════════════════╗
# ║  DO NOT EDIT — auto-managed by the platform                  ║
# ║  Changes here will be overwritten on next bootstrap.         ║
# ╚══════════════════════════════════════════════════════════════╝
"""


# ══════════════════════════════════════════════════════════════════════════════
#  Output helpers  (private to this module)
# ══════════════════════════════════════════════════════════════════════════════

def _ok(msg: str)   -> None: print(f"  ✅ {msg}")
def _warn(msg: str) -> None: print(f"  ⚠️  {msg}")
def _err(msg: str)  -> None: print(f"  ❌ {msg}")
def _info(msg: str) -> None: print(f"  ℹ️  {msg}")
def _step(msg: str) -> None: print(f"\n  › {msg}")


# ══════════════════════════════════════════════════════════════════════════════
#  Shell helpers
# ══════════════════════════════════════════════════════════════════════════════

def _run(cmd: list[str], *, check: bool = True, capture: bool = False,
         env: dict | None = None) -> subprocess.CompletedProcess:
    if capture:
        return subprocess.run(
            cmd, check=check, capture_output=True, text=True,
            cwd=_PROJECT_ROOT, env=env or os.environ.copy(),
        )
    return subprocess.run(cmd, check=check, cwd=_PROJECT_ROOT,
                          env=env or os.environ.copy())


def _alembic(*args: str, capture: bool = False,
             check: bool = True) -> subprocess.CompletedProcess:
    return _run(["alembic", *args], capture=capture, check=check)


# ── DB helpers (shared with other kernels) ────────────────────────────────────
from axon.core.kernel.db import load_db_url as _load_db_url, drop_all as _drop_all


# ══════════════════════════════════════════════════════════════════════════════
#  Alembic bootstrap  (first-run, transparent)
# ══════════════════════════════════════════════════════════════════════════════

def _bootstrap_alembic() -> bool:
    """Silently create all Alembic scaffolding if it doesn't exist yet."""
    if _ALEMBIC_INI.exists() and (_ALEMBIC_DIR / "env.py").exists():
        return False

    _step("First run — bootstrapping migration environment…")
    _VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
    (_VERSIONS_DIR / ".gitkeep").touch()
    _write_alembic_ini()
    _write_env_py()
    _write_mako_template()
    _ok("Migration environment ready.")
    return True


def _write_alembic_ini() -> None:
    _ALEMBIC_INI.write_text(_DO_NOT_EDIT + """\
[alembic]
script_location      = alembic
file_template        = %%(year)d%%(month).2d%%(day).2d_%%(hour).2d%%(minute).2d_%%(rev)s_%%(slug)s
truncate_slug_length = 40
sqlalchemy.url       = sqlite:///./platform.db
compare_server_default = true
compare_type           = true

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level    = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level    = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level    = INFO
handlers =
qualname = alembic

[handler_console]
class     = StreamHandler
args      = (sys.stderr,)
level     = NOTSET
formatter = generic

[formatter_generic]
format   = %(levelname)-5.5s [%(name)s] %(message)s
datefmt  = %H:%M:%S
""")


def _write_env_py() -> None:
    (_ALEMBIC_DIR / "__init__.py").touch()
    (_ALEMBIC_DIR / "env.py").write_text(_DO_NOT_EDIT + '''\
from __future__ import annotations

import importlib, pkgutil, sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

_ROOT = Path(__file__).parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

config = context.config

if config.config_file_name:
    fileConfig(config.config_file_name)


def _db_url() -> str:
    injected = config.get_main_option("sqlalchemy.url", "")
    if injected and "platform.db" not in injected:
        return injected
    try:
        from axon.core.config.config_manager import ConfigManager
        cm = ConfigManager()
        cm.load_root(config_yaml=_ROOT / "config.yaml", env_file=_ROOT / ".env")
        return cm.get("platform.database_url", "sqlite:///./platform.db")
    except Exception:
        return injected or "sqlite:///./platform.db"


def _import_models() -> None:
    try:
        import axon.core.auth.models  # noqa
    except Exception as exc:
        import logging
        logging.getLogger("alembic.env").warning("skip core auth models: %s", exc)

    root = _ROOT / "app" / "modules"
    if not root.is_dir():
        return
    for _, pkg, _ in pkgutil.walk_packages([str(root)], prefix="app.modules."):
        if pkg.endswith(".models"):
            try:
                importlib.import_module(pkg)
            except Exception as exc:
                import logging
                logging.getLogger("alembic.env").warning("skip %s: %s", pkg, exc)


_import_models()
config.set_main_option("sqlalchemy.url", _db_url())

from axon.core.db.app_model import metadata as target_metadata  # noqa: E402

_sqlite = config.get_main_option("sqlalchemy.url", "").startswith("sqlite")


def run_migrations_offline() -> None:
    context.configure(
        url=config.get_main_option("sqlalchemy.url"),
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        compare_server_default=True,
        render_as_batch=_sqlite,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
            compare_server_default=True,
            render_as_batch=_sqlite,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
''')


def _write_mako_template() -> None:
    (_ALEMBIC_DIR / "script.py.mako").write_text(_DO_NOT_EDIT + '''\
"""${message}

Revision ID: ${up_revision}
Revises:     ${down_revision | comma,n}
Create Date: ${create_date}
"""
from __future__ import annotations
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
${imports if imports else ""}

revision: str = ${repr(up_revision)}
down_revision: Union[str, None] = ${repr(down_revision)}
branch_labels: Union[str, Sequence[str], None] = ${repr(branch_labels)}
depends_on: Union[str, Sequence[str], None] = ${repr(depends_on)}


def upgrade() -> None:
    ${upgrades if upgrades else "pass"}


def downgrade() -> None:
    ${downgrades if downgrades else "pass"}
''')


# ══════════════════════════════════════════════════════════════════════════════
#  Sync guard
# ══════════════════════════════════════════════════════════════════════════════

def _sync_guard() -> None:
    result = _alembic("current", capture=True, check=False)
    stderr = result.stderr or ""
    if "Target database is not up to date" in stderr or "Can't locate revision" in stderr:
        _warn("DB out of sync — auto-repairing…")
        _alembic("stamp", "head", check=False)


# ══════════════════════════════════════════════════════════════════════════════
#  Engine boot helper  (for seed — needs full platform)
# ══════════════════════════════════════════════════════════════════════════════

async def _boot_engine():
    from axon.core.engine.app_engine import AppEngine
    import axon.core.engine.app_engine as _mod
    import axon.core.app_engine as _shim
    engine = AppEngine()
    _mod._engine_instance  = engine
    _shim._engine_instance = engine
    from axon.core.engine.app_engine import _CONFIG_YAML, _ENV_FILE, _MODULES_DIR
    await engine._boot(config_yaml=_CONFIG_YAML, env_file=_ENV_FILE, modules_dir=_MODULES_DIR)
    return engine


# ══════════════════════════════════════════════════════════════════════════════
#  MigrationKernel — public interface
# ══════════════════════════════════════════════════════════════════════════════

class MigrationKernel:

    # ── makemigrations ────────────────────────────────────────────────────────

    @staticmethod
    def makemigrations(name: str | None = None) -> None:
        _bootstrap_alembic()
        _sync_guard()

        label = name or "auto"
        _step(f"Detecting schema changes — '{label}'")

        result = _run(
            ["alembic", "revision", "--autogenerate", "-m", label],
            capture=True, check=False,
        )
        stdout = result.stdout or ""
        stderr = result.stderr or ""

        if result.returncode != 0:
            if "Target database is not up to date" in stderr:
                _warn("Out of sync — stamping and retrying…")
                _alembic("stamp", "head")
                _run(["alembic", "revision", "--autogenerate", "-m", label])
                _ok("Migration created.")
            elif "No changes in schema detected" in stdout:
                _ok("No changes detected — nothing to migrate.")
            else:
                _err("Migration generation failed:")
                print(stderr or stdout)
                sys.exit(1)
        else:
            for line in stdout.splitlines():
                if ".py" in line and ("Generating" in line or "Running" in line):
                    filename = Path(line.strip().split()[-1]).name
                    _info(f"Created: alembic/versions/{filename}")
            _ok("Migration file created successfully.")

    # ── migrate ───────────────────────────────────────────────────────────────

    @staticmethod
    def migrate(step: int | None = None) -> None:
        _bootstrap_alembic()
        _sync_guard()

        target = f"+{step}" if step else "head"
        _step(f"Running migrations → {target}")

        result = _alembic("upgrade", target, capture=True, check=False)

        if result.returncode != 0:
            stderr = result.stderr or ""
            if "already exists" in stderr or "DuplicateTable" in stderr:
                _warn("Tables already exist — stamping current state…")
                _alembic("stamp", "head")
                _ok("Database synced.")
                return
            if "Target database is not up to date" in stderr:
                _warn("Out of sync — stamping and retrying…")
                _alembic("stamp", "head")
                _alembic("upgrade", target)
                return
            _err("Migration failed:")
            print(result.stdout or "")
            print(stderr)
            sys.exit(1)

        output = (result.stdout or "").strip()
        if output:
            print(output)
        _ok("Migrations applied successfully.")

    # ── rollback ──────────────────────────────────────────────────────────────

    @staticmethod
    def rollback(step: int = 1) -> None:
        _step(f"Rolling back {step} migration(s)…")
        _alembic("downgrade", f"-{step}")
        _ok(f"Rolled back {step} migration(s).")

    # ── reset ─────────────────────────────────────────────────────────────────

    @staticmethod
    def reset() -> None:
        _step("Rolling back ALL migrations…")
        result = _alembic("downgrade", "base", capture=True, check=False)
        if result.returncode != 0:
            stderr = result.stderr or ""
            if (
                "No downgrade path" in stderr
                or "nothing to downgrade" in stderr.lower()
                or "OperationalError" in stderr
            ):
                _info("Partial rollback — stamping base.")
                _alembic("stamp", "base", check=False)
            else:
                print(stderr)
        else:
            _ok("All migrations rolled back.")

    # ── refresh ───────────────────────────────────────────────────────────────

    @staticmethod
    def refresh(step: int | None = None) -> None:
        _step("Refreshing migrations…")
        if step:
            _info(f"Rolling back {step} migration(s)…")
            _alembic("downgrade", f"-{step}")
            _info("Re-applying…")
            _alembic("upgrade", "head")
        else:
            MigrationKernel.reset()
            _info("Re-applying all migrations…")
            _alembic("upgrade", "head")
        _ok("Database refreshed.")

    # ── fresh ─────────────────────────────────────────────────────────────────

    @staticmethod
    def fresh(seed: bool = False) -> None:
        print()
        print("  ┌─────────────────────────────────────────────────┐")
        print("  │  ⚠️   DESTRUCTIVE OPERATION                      │")
        print("  │  ALL TABLES WILL BE DROPPED AND RECREATED.      │")
        print("  │  ALL DATA WILL BE PERMANENTLY LOST.             │")
        print("  └─────────────────────────────────────────────────┘")
        print()
        if input("  Type 'yes' to confirm: ").strip().lower() != "yes":
            print("  Aborted.")
            return

        db_url = _load_db_url()
        _step("Wiping database…")
        _drop_all(db_url)
        _alembic("stamp", "base", check=False)

        _step("Running all migrations from scratch…")
        result = _alembic("upgrade", "head", capture=True, check=False)
        if result.returncode != 0:
            stderr = result.stderr or ""
            if "already exists" in stderr or "DuplicateTable" in stderr:
                _warn("Duplicate detected — stamping head…")
                _alembic("stamp", "head", check=False)
            else:
                print(result.stdout or "")
                print(stderr)
                sys.exit(1)
        _ok("Database wiped and rebuilt.")

        if seed:
            _step("Seeding…")
            MigrationKernel.seed()

    # ── status ────────────────────────────────────────────────────────────────

    @staticmethod
    def status() -> None:
        _bootstrap_alembic()
        print()
        print("  ── Current revision ─────────────────────────────────")
        _alembic("current")
        print("  ── Migration history ────────────────────────────────")
        _alembic("history", "--verbose", check=False)

    # ── check ─────────────────────────────────────────────────────────────────

    @staticmethod
    def check() -> None:
        _bootstrap_alembic()
        _step("Checking for schema drift…")

        result = _run(
            ["alembic", "revision", "--autogenerate", "-m", "drift_check"],
            capture=True, check=False,
        )
        stdout = result.stdout or ""

        # Find generated file
        generated: Path | None = None
        for line in stdout.splitlines():
            if ".py" in line and ("Generating" in line or "Running" in line):
                parts = line.strip().split()
                if parts:
                    path = Path(parts[-1])
                    if path.exists():
                        generated = path
                        break

        if generated is None:
            if "No changes in schema detected" in stdout:
                _ok("Schema is in sync — no drift detected.")
                return
            _warn("Could not determine drift status.")
            _info(stdout or result.stderr or "")
            return

        content = generated.read_text()
        generated.unlink()  # never keep drift-check files

        has_ops = any(marker in content for marker in [
            "op.create_table", "op.add_column", "op.drop_table",
            "op.drop_column", "op.alter_column", "op.create_index",
            "op.drop_index", "op.create_unique_constraint",
        ])

        if has_ops:
            _err("Schema drift detected! Models have changes not captured in migrations.")
            _info("Run './manage makemigrations' to create the missing migration.")
            _info("Commit the migration file before deploying.")
            sys.exit(1)
        else:
            _ok("Schema is in sync — no drift detected.")

    # ── seed ──────────────────────────────────────────────────────────────────

    @staticmethod
    def seed() -> None:
        _step("Running seeders…")

        if not _SEEDS_DIR.is_dir():
            _warn(f"No seeders directory at {_SEEDS_DIR.relative_to(_PROJECT_ROOT)}")
            _info("Create database/seeders/your_seeder.py with async def run(engine): ...")
            return

        seeders = sorted(_SEEDS_DIR.glob("*.py"))
        if not seeders:
            _warn("No seeder files found.")
            return

        engine = asyncio.run(_boot_engine())
        ran = 0

        for seeder_path in seeders:
            if seeder_path.name.startswith("_"):
                continue
            spec = importlib.util.spec_from_file_location(seeder_path.stem, seeder_path)
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if hasattr(mod, "run"):
                _info(f"Running {seeder_path.name}…")
                if asyncio.iscoroutinefunction(mod.run):
                    asyncio.run(mod.run(engine))
                else:
                    mod.run(engine)
                ran += 1
            else:
                _warn(f"{seeder_path.name} has no run(engine) — skipped")

        asyncio.run(engine.shutdown())
        _ok(f"{ran} seeder(s) completed.")

    # ── wipe ──────────────────────────────────────────────────────────────────

    @staticmethod
    def wipe() -> None:
        print()
        print("  ┌──────────────────────────────────────────────┐")
        print("  │  ⚠️   db:wipe — ALL TABLES WILL BE DROPPED   │")
        print("  └──────────────────────────────────────────────┘")
        print()
        if input("  Type 'yes' to confirm: ").strip().lower() != "yes":
            print("  Aborted.")
            return

        _step("Wiping database…")
        _drop_all(_load_db_url())
        _alembic("stamp", "base", check=False)
        _ok("All tables dropped. Run 'migrate' to recreate.")
