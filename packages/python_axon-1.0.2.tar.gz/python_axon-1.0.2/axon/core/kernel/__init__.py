"""
Kernel
======
The platform's management surface. Imported by manage and the axon CLI.
"""
from __future__ import annotations

import subprocess
import sys

from axon.core.kernel.migrations import MigrationKernel
from axon.core.kernel.scaffold   import ScaffoldKernel
from axon.core.kernel.server     import ServerKernel
from axon.core.kernel.console    import ConsoleKernel
from axon.core.kernel.introspect import IntrospectKernel
from axon.core.kernel.users      import UserKernel
from axon.core.kernel.vendor     import VendorKernel
from axon.core.kernel.db import (
    drop_all, drop_sqlite, drop_postgres,
    load_db_url, ping,
    boot_cli_engine, shutdown_cli_engine,
)


def execute_from_command_line(argv: list[str]) -> None:
    if len(argv) < 2:
        _print_help()
        sys.exit(0)

    cmd  = argv[1].lower()
    args = argv[2:]

    verbosity = _int_flag(args, "verbosity", default=1)

    dispatch = {
        # ── Migrations ────────────────────────────────────────────────
        "makemigrations":   lambda: MigrationKernel.makemigrations(
                                args[0] if args and not args[0].startswith("--") else None
                            ),
        "migrate":          lambda: MigrationKernel.migrate(
                                _int_flag(args, "step") or None
                            ),
        "migrate:rollback": lambda: MigrationKernel.rollback(_int_flag(args, "step", 1)),
        "migrate:reset":    lambda: MigrationKernel.reset(),
        "migrate:refresh":  lambda: MigrationKernel.refresh(
                                _int_flag(args, "step") or None
                            ),
        "migrate:fresh":    lambda: MigrationKernel.fresh(seed=_flag(args, "seed")),
        "migrate:status":   lambda: MigrationKernel.status(),
        "migrate:check":    lambda: MigrationKernel.check(),
        "migrate:seed":     lambda: MigrationKernel.seed(),
        "db:seed":          lambda: MigrationKernel.seed(),
        "db:wipe":          lambda: MigrationKernel.wipe(),

        # ── Scaffolding ───────────────────────────────────────────────
        "create_project":   lambda: ScaffoldKernel.create_project(
                                _require(args, "axon create_project <name>")
                            ),
        "make:module":      lambda: ScaffoldKernel.make_module(
                                _require(args, "./manage make:module <name>")
                            ),

        # ── Server ────────────────────────────────────────────────────
        "runserver":        lambda: ServerKernel.runserver(
                                args[0] if len(args) > 0 else "0.0.0.0",
                                int(args[1]) if len(args) > 1 else 8000,
                            ),

        # ── Shells ────────────────────────────────────────────────────
        "shell":            lambda: ConsoleKernel.shell(verbosity=verbosity),
        "dbshell":          lambda: ConsoleKernel.dbshell(),

        # ── Introspection ─────────────────────────────────────────────
        "status":           lambda: IntrospectKernel.status(verbosity=verbosity),

        # ── Users ─────────────────────────────────────────────────────
        "createsuperuser":  lambda: UserKernel.createsuperuser(
                                email     = _kv_flag(args, "email"),
                                password  = _kv_flag(args, "password"),
                                name      = _kv_flag(args, "name"),
                                verbosity = verbosity,
                            ),

        # ── Vendor providers ──────────────────────────────────────────
        "vendor:list":      lambda: VendorKernel.list_vendors(),
        "vendor:publish":   lambda: VendorKernel.publish(
                                _require(args, "./manage vendor:publish <n>")
                            ),

        # ── Help ──────────────────────────────────────────────────────
        "help":   _print_help,
        "--help": _print_help,
        "-h":     _print_help,
    }

    if cmd not in dispatch:
        print(f"  ❌ Unknown command: '{cmd}'")
        _print_help()
        sys.exit(1)

    try:
        dispatch[cmd]()
    except subprocess.CalledProcessError as exc:
        print(f"  ❌ Command failed (exit {exc.returncode})")
        sys.exit(exc.returncode)
    except KeyboardInterrupt:
        print("\n  Aborted.")
        sys.exit(0)


def _int_flag(args: list[str], flag: str, default: int = 0) -> int:
    for arg in args:
        if arg.startswith(f"--{flag}="):
            return int(arg.split("=", 1)[1])
        if arg.isdigit():
            return int(arg)
    return default


def _flag(args: list[str], flag: str) -> bool:
    return f"--{flag}" in args


def _kv_flag(args: list[str], flag: str) -> str | None:
    for arg in args:
        if arg.startswith(f"--{flag}="):
            return arg.split("=", 1)[1]
    return None


def _require(args: list[str], usage: str) -> str:
    if not args or args[0].startswith("--"):
        print(f"  ❌ Usage: {usage}")
        sys.exit(1)
    return args[0]


def _print_help() -> None:
    print("""
  ╔══════════════════════════════════════════════════════════════════╗
  ║              Axon Framework — Management CLI                     ║
  ╚══════════════════════════════════════════════════════════════════╝

  GLOBAL (axon CLI — run anywhere)
  ─────────────────────────────────
  axon create_project <name>         Bootstrap a new Axon project

  MIGRATIONS  (run inside a project via ./manage)
  ────────────────────────────────────────────────
  makemigrations [name]              Detect model changes → create migration
  migrate [--step=N]                 Run all pending migrations
  migrate:rollback [--step=N]        Roll back last N migrations (default: 1)
  migrate:reset                      Roll back ALL migrations
  migrate:refresh [--step=N]         Reset then re-run all migrations
  migrate:fresh [--seed]             Wipe DB and re-run from scratch
  migrate:status                     Show migration history
  migrate:check                      Detect model drift (exits 1 if out of sync)
  migrate:seed  /  db:seed           Run database seeders
  db:wipe                            Drop all tables

  SCAFFOLDING
  ────────────
  make:module <name>                 Scaffold a new module with full boilerplate

  SERVER
  ───────
  runserver [host] [port]            Start dev server (default: 0.0.0.0:8000)

  SHELLS
  ───────
  shell                              Python REPL with full platform context
  dbshell                            Native DB shell (psql or sqlite3)

  INTROSPECTION
  ──────────────
  status                             Show platform status (modules, services, DB)

  VENDOR PROVIDERS
  ─────────────────
  vendor:list                        Show all installed axon vendor providers
  vendor:publish <n>              Write vendor config stubs to .env.example

  USERS
  ──────
  createsuperuser                    Create an admin user (interactive)
  createsuperuser --email= --password= --name=   Non-interactive / CI

  GLOBAL FLAGS
  ─────────────
  --verbosity=0   errors only
  --verbosity=1   clean CLI output  (default)
  --verbosity=2   show module registration + boot steps
  --verbosity=3   full debug trace
""")


__all__ = [
    "execute_from_command_line",
    "MigrationKernel",
    "ScaffoldKernel",
    "ServerKernel",
    "ConsoleKernel",
    "IntrospectKernel",
    "UserKernel",
    "drop_all", "drop_sqlite", "drop_postgres",
    "load_db_url", "ping",
]
