"""
ConsoleKernel
=============
Interactive shell commands.

Commands:
    shell      Python REPL with full platform context pre-loaded
    dbshell    Native DB shell (psql or sqlite3)
"""
from __future__ import annotations

import asyncio
import code
import os
import re
import subprocess
import sys
from pathlib import Path

_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


async def _boot_engine():
    from axon.core.engine.app_engine import AppEngine
    import axon.core.engine.app_engine as _mod
    import axon.core.app_engine as _shim
    engine = AppEngine()
    _mod._engine_instance  = engine
    _shim._engine_instance = engine
    from axon.core.engine.app_engine import _CONFIG_YAML, _ENV_FILE, _MODULES_DIR
    await engine._boot(config_yaml=_CONFIG_YAML, env_file=_ENV_FILE, modules_dir=_MODULES_DIR)
    return engine


class ConsoleKernel:

    @staticmethod
    def shell() -> None:
        """Python REPL with the full platform context pre-loaded."""
        engine = asyncio.run(_boot_engine())
        module_names = [m.name for m in engine.loader.modules] if engine.loader else []

        banner = (
            "\n  ╔═══════════════════════════════════════════════════╗\n"
            "  ║   Modular Monolith Platform — Interactive Shell   ║\n"
            "  ╚═══════════════════════════════════════════════════╝\n"
            "\n"
            "  Globals : engine  container  db  hooks  asyncio\n"
           f"  Modules : {module_names}\n"
            "\n"
            "  Examples:\n"
            "    greeter = engine.make('greeter'); greeter.greet('World')\n"
            "    with db.session() as s: items = s.query(MyModel).all()\n"
        )

        local_vars: dict = {
            "engine":    engine,
            "container": engine.container,
            "db":        engine.db,
            "hooks":     engine.hooks,
            "asyncio":   asyncio,
        }
        if engine.loader:
            for mod in engine.loader.modules:
                local_vars[mod.name] = mod

        try:
            code.interact(banner=banner, local=local_vars, exitmsg="")
        finally:
            asyncio.run(engine.shutdown())

    @staticmethod
    def dbshell() -> None:
        """Open a native database shell (psql for Postgres, sqlite3 for SQLite)."""
        from axon.core.kernel.db import load_db_url
        db_url = load_db_url()

        if db_url.startswith("sqlite"):
            path_str = db_url.replace("sqlite:///", "")
            db_path  = (_PROJECT_ROOT / path_str).resolve()
            print(f"\n  🗄️  sqlite3 {db_path.name}\n")
            subprocess.run(["sqlite3", str(db_path)], cwd=_PROJECT_ROOT, check=False)
            return

        sync = db_url.replace("postgresql+asyncpg://", "postgresql://")
        m = re.match(r"postgresql://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)", sync)
        if not m:
            print(f"  ❌ Cannot parse DATABASE_URL")
            sys.exit(1)

        user, password, host, port, database = m.groups()
        env = os.environ.copy()
        env["PGPASSWORD"] = password
        print(f"\n  🗄️  psql {user}@{host}:{port}/{database}\n")
        subprocess.run(
            ["psql", "-h", host, "-p", port, "-U", user, "-d", database],
            env=env, cwd=_PROJECT_ROOT, check=False,
        )
