"""
ScaffoldKernel
==============
Two commands:
    create_project <n>   Bootstrap a brand-new Axon project directory
    make:module    <n>   Generate a module inside an existing project
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path


def _ok(msg: str)   -> None: print(f"  \u2705 {msg}")
def _err(msg: str)  -> None: print(f"  \u274c {msg}")
def _info(msg: str) -> None: print(f"  \u2139\ufe0f  {msg}")
def _step(msg: str) -> None: print(f"\n  \u203a {msg}")


class ScaffoldKernel:

    @staticmethod
    def create_project(name: str) -> None:
        """Bootstrap a brand-new Axon project at ./<n>/."""

        if not re.match(r'^[a-z][a-z0-9_]*$', name):
            _err(f"Invalid project name: '{name}'")
            _info("Project names must be lowercase snake_case: my_app, trading_bot")
            sys.exit(1)

        target = Path.cwd() / name
        if target.exists():
            _err(f"Directory '{name}' already exists.")
            sys.exit(1)

        _step(f"Creating project '{name}'\u2026")

        # ── Directory tree ─────────────────────────────────────────────────────────────
        (target / "app" / "modules").mkdir(parents=True)
        (target / "app" / "providers").mkdir(parents=True)
        (target / "app" / "http").mkdir(parents=True)
        (target / "app").joinpath("__init__.py").write_text("")
        (target / "app" / "modules").joinpath("__init__.py").write_text("")
        (target / "app" / "providers").joinpath("__init__.py").write_text("")
        (target / "app" / "http").joinpath("__init__.py").write_text("")
        _ok("app/  directory structure")

        # ── main.py ─────────────────────────────────────────────────────────────
        (target / "main.py").write_text(
            "from axon.core.engine.application import app  # noqa: F401\n"
        )
        _ok("main.py")

        # ── app/http/asgi.py ──────────────────────────────────────────────────────
        (target / "app" / "http" / "asgi.py").write_text(
            '''"""
ASGI entry point — for production servers (gunicorn, uvicorn, granian).

Gunicorn + uvicorn workers:
    gunicorn app.http.asgi:app -w 4 -k uvicorn.workers.UvicornWorker

Uvicorn directly:
    uvicorn app.http.asgi:app --host 0.0.0.0 --port 8000 --workers 4

Docker CMD example:
    CMD ["gunicorn", "app.http.asgi:app", "-w", "4",
         "-k", "uvicorn.workers.UvicornWorker", "--bind", "0.0.0.0:8000"]
"""
from axon.core.engine.application import app  # noqa: F401
'''
        )
        _ok("app/http/asgi.py")

        # ── app/http/wsgi.py ──────────────────────────────────────────────────────
        (target / "app" / "http" / "wsgi.py").write_text(
            '''"""
WSGI entry point — for traditional WSGI servers.

Note: prefer asgi.py for full async support.
Use this only for platforms that require a WSGI interface.

Gunicorn:
    gunicorn app.http.wsgi:app --bind 0.0.0.0:8000
"""
from axon.core.engine.application import app as _asgi_app

try:
    from asgiref.sync import AsyncToSync  # pip install asgiref
    app = AsyncToSync(_asgi_app)
except ImportError:
    raise ImportError(
        "WSGI mode requires asgiref: pip install asgiref"
    )
'''
        )
        _ok("app/http/wsgi.py")

        # ── app/providers/providers.py ──────────────────────────────────────────
        (target / "app" / "providers" / "providers.py").write_text(f'''\
"""
providers.py
============
Register vendor modules (pip-installed python-axon-* packages) here.

Install a vendor, then add it to the list below:

    pip install python-axon-resend
    # add: VendorProvider.use("resend")
    # run: ./manage vendor:publish resend
"""
from axon import VendorProvider

# ── Vendor providers ─────────────────────────────────────────────────────────────
# Add installed vendors below. Run ./manage vendor:list to see available ones.
providers: list = [
    # VendorProvider.use("resend"),
    # VendorProvider.use("stripe"),
]
''')
        _ok("app/providers/providers.py")

        # ── manage ─────────────────────────────────────────────────────────────
        manage = target / "manage"
        manage.write_text(
            "#!/usr/bin/env python3\n"
            "import os, sys\n"
            "from pathlib import Path\n\n"
            "os.environ.setdefault('AXON_PROJECT_ROOT', str(Path(__file__).parent.resolve()))\n"
            "sys.path.insert(0, str(Path(__file__).parent.resolve()))\n\n"
            "from axon.core.kernel import execute_from_command_line\n\n"
            "if __name__ == '__main__':\n"
            "    execute_from_command_line(sys.argv)\n"
        )
        manage.chmod(0o755)
        _ok("manage  (executable)")

        # ── config.yaml ─────────────────────────────────────────────────────────────
        (target / "config.yaml").write_text(f"""\
# config.yaml — {name}
# All values available via app.config("platform.<key>") or config("platform.<key>").
# Override any key with an env var:  PLATFORM__SECRET_KEY=my-secret
#
# Vendor modules are registered in app/providers/providers.py.
# Run ./manage vendor:publish <name> to write their env stubs here.

platform:

  # ---- Database ----------------------------------------------------------
  database_url: ""            # raw URL overrides the block below if set
  database:
    engine:   sqlite          # sqlite | postgresql | mysql | mariadb | mssql
    name:     ./platform.db
    host:     localhost
    port:     ~
    user:     ""
    password: ""
    driver:   ""
    echo:     false
    pool_size:    5
    max_overflow: 10
    pool_timeout: 30

  # ---- Application -------------------------------------------------------
  debug:      false
  secret_key: "change-me-in-production"
  app_url:    ""
  allowed_hosts:
    - "*"

  # ---- Logging -----------------------------------------------------------
  log_level: "INFO"

  # ---- Modules -----------------------------------------------------------
  disabled_modules: []

  # ---- Mail (built-in SMTP) ----------------------------------------------
  mail:
    host:     ""
    port:     587
    username: ""
    password: ""
    from:     "App <no-reply@example.com>"
    tls:      true
    ssl:      false
""")
        _ok("config.yaml")

        # ── .env.example ───────────────────────────────────────────────────────────
        (target / ".env.example").write_text("""\
# .env.example — copy to .env and fill in values
# Vendor env vars (RESEND__, STRIPE__ etc.) are added by:
#   ./manage vendor:publish <name>

APP_NAME={name}
APP_ENV=local
PLATFORM__SECRET_KEY=change-me
PLATFORM__DEBUG=false
PLATFORM__APP_URL=http://localhost:8000
PLATFORM__DATABASE__ENGINE=sqlite
PLATFORM__DATABASE__NAME=./platform.db
""".format(name=name))
        _ok(".env.example")

        # ── .gitignore ─────────────────────────────────────────────────────────────
        (target / ".gitignore").write_text("""\
__pycache__/
*.pyc
*.pyo
.env
*.db
*.sqlite3
.venv/
venv/
dist/
*.egg-info/
""")
        _ok(".gitignore")

        # ── requirements.txt ────────────────────────────────────────────────────────────
        (target / "requirements.txt").write_text("""\
python-axon
uvicorn[standard]
gunicorn
alembic
""")
        _ok("requirements.txt")

        # ── Summary ─────────────────────────────────────────────────────────────
        w = max(len(name) + 22, 60)
        print()
        print(f"  ╔{'\u2550' * w}╗")
        print(f"  ║  Project '{name}' created ✅{' ' * (w - len(name) - 20)}║")
        print(f"  ╠{'\u2550' * w}╣")
        for f in [
            "main.py                        ← dev entry point",
            "manage                         ← CLI",
            "config.yaml                    ← platform config",
            "app/modules/                   ← your modules",
            "app/providers/providers.py     ← vendor registration",
            "app/http/asgi.py               ← production ASGI",
            "app/http/wsgi.py               ← WSGI fallback",
        ]:
            print(f"  ║   {f:<{w - 4}}║")
        print(f"  ╠{'\u2550' * w}╣")
        print(f"  ║  cd {name:<{w - 6}}║")
        print(f"  ║  pip install -r requirements.txt{' ' * (w - 34)}║")
        print(f"  ║  ./manage migrate{' ' * (w - 18)}║")
        print(f"  ║  ./manage runserver{' ' * (w - 20)}║")
        print(f"  ╚{'\u2550' * w}╝")
        print()


    # ══════════════════════════════════════════════════════════════════
    #  make:module
    # ══════════════════════════════════════════════════════════════════

    @staticmethod
    def make_module(name: str) -> None:
        """Scaffold a new module inside an existing Axon project."""

        if not re.match(r'^[a-z][a-z0-9_]*$', name):
            _err(f"Invalid module name: '{name}'")
            _info("Module names must be lowercase snake_case: billing, order_tracking")
            sys.exit(1)

        project_root = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))
        modules_dir  = project_root / "app" / "modules"

        if not modules_dir.exists():
            _err(f"app/modules/ not found. Are you inside an Axon project?")
            sys.exit(1)

        module_dir = modules_dir / name
        if module_dir.exists():
            _err(f"Module '{name}' already exists at app/modules/{name}/")
            sys.exit(1)

        class_name   = ''.join(w.title() for w in name.split('_'))
        service_name = f"{class_name}Service"
        url_prefix   = name.replace('_', '-')

        _step(f"Scaffolding module '{name}'…")
        module_dir.mkdir(parents=True)

        # manifest.py
        (module_dir / "manifest.py").write_text(f"""\
from axon import Manifest

manifest = Manifest(
    name        = "{name}",
    version     = "1.0.0",
    description = "",
    author      = "",
    requires    = [],
    provides    = ["{name}_svc"],
    enabled     = True,
    routes      = "routes",
    config      = {{
        # "key": "default_value",
    }},
)
""")
        _ok("manifest.py")

        # models.py
        (module_dir / "models.py").write_text(f"""\
from axon import Model as AxonModel
from axon.fields import (
    StringField, TextField, IntField, DecimalField,
    BoolField, DateTimeField, ForeignKey,
    ChoiceField, JSONField,
)


class {class_name}(AxonModel):
    \"\"\"Main model for the {name} module.\"\"\"
    # name   = StringField(max_length=255, required=True)
    # status = ChoiceField(["active", "inactive"], default="active")
    pass
""")
        _ok("models.py")

        # schemas.py
        (module_dir / "schemas.py").write_text(f"""\
from pydantic import BaseModel
from typing import Optional


class {class_name}In(BaseModel):
    \"\"\"Request body for creating a {class_name}.\"\"\"
    # name: str
    pass


class {class_name}UpdateIn(BaseModel):
    \"\"\"Request body for updating a {class_name}. All fields optional.\"\"\"
    # name: Optional[str] = None
    pass
""")
        _ok("schemas.py")

        # services.py
        (module_dir / "services.py").write_text(f"""\
from axon import Service as AxonService
from axon import Log

TAG = "{service_name}"


class {service_name}(AxonService):
    \"\"\"Business logic for the {name} module.\"\"\"

    def list(self, page: int = 1, per_page: int = 20) -> dict:
        from .models import {class_name}
        from axon.core.db.paginator import Paginator
        with self.db().session() as s:
            q = s.query({class_name}).order_by({class_name}.created_at.desc())
            return Paginator(q, page=page, per_page=per_page).paginate()

    def find(self, item_id: int) -> dict | None:
        from .models import {class_name}
        with self.db().session() as s:
            row = s.query({class_name}).filter_by(id=item_id).first()
            return row.to_dict() if row else None

    def create(self, data: dict) -> dict:
        from .models import {class_name}
        with self.db().session() as s:
            item = {class_name}(**data)
            s.add(item)
            s.flush()
            Log.i(TAG, "created id=%d", item.id)
            return item.to_dict()

    def update(self, item_id: int, data: dict) -> dict | None:
        from .models import {class_name}
        with self.db().session() as s:
            row = s.query({class_name}).filter_by(id=item_id).first()
            if not row:
                return None
            for k, v in data.items():
                setattr(row, k, v)
            s.flush()
            return row.to_dict()

    def delete(self, item_id: int) -> bool:
        from .models import {class_name}
        with self.db().session() as s:
            row = s.query({class_name}).filter_by(id=item_id).first()
            if not row:
                return False
            s.delete(row)
            return True
""")
        _ok("services.py")

        # hooks.py
        (module_dir / "hooks.py").write_text(f"""\
from axon import Log

TAG = "{class_name}Hooks"


async def on_platform_booted(payload: dict) -> None:
    Log.d(TAG, "platform booted: %s", payload.get("modules", []))
""")
        _ok("hooks.py")

        # routes.py
        (module_dir / "routes.py").write_text(f"""\
from axon import Router
from axon.auth import require_auth
from axon.responses import not_found
from .services import {service_name}
from .schemas import {class_name}In, {class_name}UpdateIn

router = Router(prefix="/{url_prefix}", tags=["{name}"])


@router.get("/", summary="List {name}")
async def index(ctx, svc: {service_name}, page: int = 1, per_page: int = 20):
    return svc.list(page=page, per_page=per_page)


@router.get("/{{item_id}}", summary="Get {name}")
async def show(item_id: int, ctx, svc: {service_name}):
    item = svc.find(item_id)
    if not item:
        raise not_found("{class_name} not found")
    return item


protected = router.group("", middleware=[require_auth])


@protected.post("/", status=201, summary="Create {name}")
async def store(body: {class_name}In, ctx, svc: {service_name}):
    return svc.create(body.model_dump(exclude_none=True))


@protected.put("/{{item_id}}", summary="Update {name}")
async def update(item_id: int, body: {class_name}UpdateIn, ctx, svc: {service_name}):
    item = svc.update(item_id, body.model_dump(exclude_none=True))
    if not item:
        raise not_found("{class_name} not found")
    return item


@protected.delete("/{{item_id}}", status=204, summary="Delete {name}")
async def destroy(item_id: int, ctx, svc: {service_name}):
    if not svc.delete(item_id):
        raise not_found("{class_name} not found")
""")
        _ok("routes.py")

        # __init__.py
        (module_dir / "__init__.py").write_text(f"""\
from axon import Module as AxonModule
from .services import {service_name}


class Module(AxonModule):

    @property
    def name(self) -> str:
        return "{name}"

    def register(self) -> None:
        self.bind({service_name})

    async def boot(self) -> None:
        from .hooks import on_platform_booted
        self.on("platform.booted", on_platform_booted)
        self.log_i("booted")

    async def shutdown(self) -> None:
        self.log_i("shutting down")
""")
        _ok("__init__.py")

        # Summary
        w = max(len(name) + 20, 54)
        print()
        print(f"  ╔{'═' * w}╗")
        print(f"  ║  Module '{name}' created{' ' * (w - len(name) - 12)}║")
        print(f"  ╠{'═' * w}╣")
        print(f"  ║  📁 app/modules/{name}/{' ' * (w - len(name) - 17)}║")
        for f in ["manifest.py", "__init__.py", "models.py", "services.py",
                  "schemas.py", "routes.py", "hooks.py"]:
            print(f"  ║     ├── {f}{' ' * (w - len(f) - 9)}║")
        print(f"  ╠{'═' * w}╣")
        print(f"  ║  Next steps:{' ' * (w - 13)}║")
        print(f"  ║  1. Add fields to models.py{' ' * (w - 28)}║")
        print(f"  ║  2. ./manage makemigrations {name}{' ' * (w - len(name) - 30)}║")
        print(f"  ║  3. ./manage migrate{' ' * (w - 21)}║")
        print(f"  ╚{'═' * w}╝")
        print()
