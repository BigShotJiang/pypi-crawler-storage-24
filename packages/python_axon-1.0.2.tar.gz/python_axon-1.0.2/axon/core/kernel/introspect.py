"""
IntrospectKernel
================
Platform introspection commands.

Commands:
    status    Show platform status (modules, services, DB health)
"""
from __future__ import annotations
import os

import asyncio
from pathlib import Path

_PROJECT_ROOT = Path(os.environ.get("AXON_PROJECT_ROOT", Path.cwd()))


async def _boot_engine():
    from axon.core.engine.app_engine import AppEngine
    import axon.core.engine.app_engine as _mod
    import axon.core.app_engine as _shim
    engine = AppEngine()
    _mod._engine_instance  = engine
    _shim._engine_instance = engine
    from axon.core.engine.app_engine import _CONFIG_YAML, _ENV_FILE, _MODULES_DIR
    await engine._boot(config_yaml=_CONFIG_YAML, env_file=_ENV_FILE, modules_dir=_MODULES_DIR)
    return engine


class IntrospectKernel:

    @staticmethod
    def status() -> None:
        """Boot the platform and print a full status report."""
        print("\n  › Booting platform for status check…")
        engine = asyncio.run(_boot_engine())
        s = engine.status()

        print()
        print("  ╔══════════════════════════════════════════╗")
        print("  ║           Platform Status                ║")
        print("  ╠══════════════════════════════════════════╣")
        print(f"  ║  Booted   › {'Yes' if s['booted'] else 'No':<30}║")
        print(f"  ║  DB OK    › {'Yes' if s['db_ok'] else 'No':<30}║")
        print(f"  ║  Modules  › {str(s['modules']):<30}║")
        print(f"  ║  Services › {str(len(s['services'])) + ' registered':<30}║")
        print(f"  ║  Events   › {str(len(s['events'])) + ' registered':<30}║")
        print("  ╚══════════════════════════════════════════╝")
        print()

        asyncio.run(engine.shutdown())
