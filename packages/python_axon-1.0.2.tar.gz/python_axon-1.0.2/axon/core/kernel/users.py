"""
UserKernel
==========
User management commands. Boots the full platform engine — has access
to the live UserService (and any override a module has registered).

Commands:
    createsuperuser              Interactive prompt — creates a superuser
    createsuperuser --email= --password= --name=   Non-interactive (CI/scripts)

Verbosity (mirrors Django):
    --verbosity=0   errors only
    --verbosity=1   silent boot, clean output  (default)
    --verbosity=2   shows module registration + boot steps
    --verbosity=3   full debug trace
"""
from __future__ import annotations

import sys


def _ok(msg: str)   -> None: print(f"  ✅ {msg}")
def _err(msg: str)  -> None: print(f"  ❌ {msg}")
def _info(msg: str) -> None: print(f"  ℹ️  {msg}")
def _step(msg: str) -> None: print(f"\n  › {msg}")


class UserKernel:

    @staticmethod
    def createsuperuser(
        email:      str | None = None,
        password:   str | None = None,
        name:       str | None = None,
        verbosity:  int        = 1,
    ) -> None:
        """
        Create a superuser (role='admin') interactively or non-interactively.

        Interactive (prompts for missing fields):
            ./manage createsuperuser

        Non-interactive (CI / Docker entrypoint):
            ./manage createsuperuser --email=admin@example.com --password=secret --name=Admin

        Verbosity:
            ./manage createsuperuser --verbosity=2   # see what's loading
            ./manage createsuperuser --verbosity=3   # full debug trace
        """
        print()
        print("  ╔══════════════════════════════════════╗")
        print("  ║       Create Superuser               ║")
        print("  ╚══════════════════════════════════════╝")
        print()

        # ── Collect fields interactively if not provided ───────────────
        if not email:
            email = _prompt("Email address", required=True)

        if not name:
            name = _prompt("Full name (optional)", required=False) or ""

        if not password:
            password = _prompt_password()

        # ── Basic validation before booting the engine ─────────────────
        if "@" not in email or "." not in email.split("@")[-1]:
            _err("Invalid email address.")
            sys.exit(1)

        if len(password) < 8:
            _err("Password must be at least 8 characters.")
            sys.exit(1)

        # ── Boot engine ────────────────────────────────────────────────

        if verbosity >= 2:
            _step("Booting platform…")

        from axon.core.kernel.db import boot_cli_engine, shutdown_cli_engine
        engine = boot_cli_engine(verbosity=verbosity)

        try:
            from axon.core.auth.services import UserService
            svc = engine.container.make(UserService)

            existing = svc.find_by_email(email)
            if existing:
                if existing.get("role") == "admin":
                    _err(f"Superuser with email '{email}' already exists.")
                else:
                    _step(f"User '{email}' exists — upgrading to superuser…")
                    svc.update(existing["id"], role="admin")
                    _ok(f"User '{email}' is now a superuser.")
                shutdown_cli_engine(engine, verbosity=verbosity)
                return

            user = svc.create(
                email    = email,
                password = password,
                name     = name,
                role     = "admin",
            )

            print()
            print("  ╔══════════════════════════════════════╗")
            print("  ║  Superuser created successfully  ✅  ║")
            print("  ╠══════════════════════════════════════╣")
            print(f"  ║  ID    › {str(user['id']):<28}║")
            print(f"  ║  Email › {user['email']:<28}║")
            print(f"  ║  Name  › {(user.get('name') or '—'):<28}║")
            print(f"  ║  Role  › {user['role']:<28}║")
            print("  ╚══════════════════════════════════════╝")
            print()

        except Exception as exc:
            _err(f"Failed to create superuser: {exc}")
            shutdown_cli_engine(engine, verbosity=verbosity)
            sys.exit(1)

        shutdown_cli_engine(engine, verbosity=verbosity)


# ── Prompt helpers ────────────────────────────────────────────────────────────

def _prompt(label: str, *, required: bool = True) -> str:
    while True:
        try:
            value = input(f"  {label}: ").strip()
        except KeyboardInterrupt:
            print("\n  Aborted.")
            sys.exit(0)
        if value:
            return value
        if not required:
            return ""
        _err(f"{label} is required.")


def _prompt_password() -> str:
    import getpass
    while True:
        try:
            pw  = getpass.getpass("  Password (min 8 chars): ")
            pw2 = getpass.getpass("  Password (again):       ")
        except KeyboardInterrupt:
            print("\n  Aborted.")
            sys.exit(0)
        if pw != pw2:
            _err("Passwords do not match. Try again.")
            continue
        if len(pw) < 8:
            _err("Password must be at least 8 characters.")
            continue
        return pw
