"""
Manifest — canonical import path for module developers.

    from axon.core.manifest import Manifest

This is the authoritative re-export. The actual implementation lives in
app/core/module/manifest.py — import from either path, same class.
"""
from axon.core.module.manifest import Manifest  # noqa: F401
