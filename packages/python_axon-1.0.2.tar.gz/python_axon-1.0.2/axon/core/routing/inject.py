"""
Dependency Injection
====================
Two forms of injection:

1. Handler parameter injection (boot-time, zero runtime cost)
   ─────────────────────────────────────────────────────────
   Annotate route handler params with a registered service type.
   The platform resolves once at mount time and bakes it into the closure.

       @router.get("/orders")
       async def list_orders(ctx: Context, svc: OrderService):
           return svc.list_all()

2. Class-level inject() descriptor (lazy, first-access resolution)
   ────────────────────────────────────────────────────────────────
   Use inject() to declare a cross-module dependency at the class level.
   Resolution happens from the container the first time the attribute
   is accessed — NOT at import time.

       from axon.core.routing.inject import inject

       class BillingService(BaseService):
           # Resolved from container["UserService"] on first access
           _users: "UserService" = inject(UserService)
           # Or by string name (for forward references / optional deps):
           _mailer = inject("MailService")

       # In a method:
       def charge(self, user_id, amount):
           user = self._users.find(user_id)   # container resolves UserService here
           ...

   inject() stores the resolved instance on the instance dict after first
   access so subsequent calls are a plain attribute lookup — no container
   overhead after the first call.
"""

from __future__ import annotations

import inspect
import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from axon.core.engine.container import Container

logger = logging.getLogger(__name__)

_PASSTHROUGH_TYPES = {int, str, float, bool, bytes, type(None)}


def _is_pydantic(tp: Any) -> bool:
    try:
        from pydantic import BaseModel
        return isinstance(tp, type) and issubclass(tp, BaseModel)
    except ImportError:
        return False


def _container_key(tp: type | str) -> str:
    if isinstance(tp, str):
        return tp
    return tp.__name__


# ── Descriptor ────────────────────────────────────────────────────────────

class inject:
    """
    Lazy dependency descriptor. Declare on a class, access on an instance.

    Usage:
        class MyService(BaseService):
            _auth: "AuthService" = inject(AuthService)
            _mail = inject("MailService")   # forward ref / by name

    The container is not touched until the attribute is first accessed,
    so circular module load order is not a problem.
    After first access, the resolved value is cached on the instance dict.
    """

    def __init__(self, service: type | str, *, optional: bool = False) -> None:
        """
        Parameters
        ----------
        service  : The service class or string name to resolve.
        optional : If True, return None instead of raising if not registered.
        """
        self._key      = _container_key(service)
        self._optional = optional
        self._attr: str = ""   # set by __set_name__

    def __set_name__(self, owner: type, name: str) -> None:
        self._attr = name

    def __get__(self, obj: Any, objtype: type | None = None) -> Any:
        if obj is None:
            # Class-level access — return descriptor itself
            return self

        # Check instance dict first (cached after first resolution)
        cached = obj.__dict__.get(self._attr)
        if cached is not None:
            return cached

        # Resolve from container
        from axon.core.engine.app_engine import _engine_instance
        if _engine_instance is None:
            raise RuntimeError(
                f"inject('{self._key}'): platform not booted yet. "
                "inject() resolves lazily — do not access injected attributes "
                "during class definition or at import time."
            )
        container = _engine_instance.container

        if self._optional and not container.has(self._key):
            return None

        resolved = container.make(self._key)
        # Cache on instance to avoid container lookup on every access
        obj.__dict__[self._attr] = resolved
        logger.debug("inject: resolved '%s' -> %s", self._key, type(resolved).__name__)
        return resolved

    def __set__(self, obj: Any, value: Any) -> None:
        # Allow direct assignment (e.g. in tests to mock the dep)
        obj.__dict__[self._attr] = value

    def __repr__(self) -> str:
        return f"inject('{self._key}')"


# ── Boot-time handler injection (used by router._wrap_handler) ─────────────

class InjectionError(Exception):
    """Raised at boot when a required injection cannot be satisfied."""


def build_injector(
    fn: Any,
    container: "Container",
    resolved_hints: dict[str, Any],
    ctx_type: type,
    skip_names: set[str],
) -> dict[str, Any]:
    """
    Inspect fn's parameters and return {param_name: resolved_service}
    for every injectable parameter.

    Called once at mount time — result baked into the wrapper closure.

    Parameters
    ----------
    fn             : Original handler function
    container      : Platform service container
    resolved_hints : Result of typing.get_type_hints(fn) — forward refs resolved
    ctx_type       : Context class — always skip
    skip_names     : Additional param names to skip (e.g. 'self', 'cls')
    """
    injected: dict[str, Any] = {}
    sig = inspect.signature(fn)

    for param_name, param in sig.parameters.items():
        if param_name in skip_names:
            continue

        tp = resolved_hints.get(param_name, param.annotation)

        if tp is inspect.Parameter.empty:
            continue
        if tp is ctx_type:
            continue
        if tp in _PASSTHROUGH_TYPES:
            continue
        if _is_pydantic(tp):
            continue
        if not isinstance(tp, type):
            continue

        key = _container_key(tp)
        if not container.has(key):
            continue

        try:
            service = container.make(key)
        except Exception as exc:
            raise InjectionError(
                f"Cannot inject '{param_name}: {tp.__name__}' into "
                f"'{fn.__name__}': container.make('{key}') failed: {exc}"
            ) from exc

        injected[param_name] = service
        logger.debug("DI: %s.%s -> container['%s']", fn.__name__, param_name, key)

    return injected
