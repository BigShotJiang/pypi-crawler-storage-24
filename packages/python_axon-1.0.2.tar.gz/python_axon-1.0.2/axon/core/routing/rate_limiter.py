"""
Rate Limiter
============
In-memory token-bucket rate limiter usable as route or global middleware.

Route-level usage (decorator)
------------------------------
    from axon.core.routing.rate_limiter import rate_limit

    @router.post("/login", middleware=[rate_limit(5, per="minute")])
    async def login(body: LoginIn, ctx: Context, svc: AuthService): ...

Global usage (module-level, all routes)
-----------------------------------------
    class Module(BaseModule):
        def register(self) -> None:
            from axon.core.routing.rate_limiter import rate_limit
            self.use(rate_limit(100, per="minute"), path="/api/*", priority=5)

Key strategies
--------------
    rate_limit(10, per="minute")                    # per IP
    rate_limit(10, per="minute", key="user_id")     # per req.state["user_id"]
    rate_limit(10, per="minute", key=my_key_fn)     # custom fn(req) -> str

Limits
------
    per="second"    per="minute"    per="hour"    per="day"
"""
from __future__ import annotations

import time
import threading
from typing import Callable

from axon.core.routing.middleware import RequestContext

_WINDOWS = {"second": 1, "minute": 60, "hour": 3600, "day": 86400}


class _Bucket:
    __slots__ = ("tokens", "last_refill")

    def __init__(self, capacity: int) -> None:
        self.tokens      = capacity
        self.last_refill = time.monotonic()


class RateLimiter:
    def __init__(
        self,
        limit:    int,
        window:   int,                    # seconds
        key:      str | Callable | None = None,
    ) -> None:
        self._limit   = limit
        self._window  = window
        self._key     = key
        self._buckets: dict[str, _Bucket] = {}
        self._lock    = threading.Lock()

    def _get_key(self, req: RequestContext) -> str:
        if self._key is None:
            return req.header("x-forwarded-for") or req.header("x-real-ip") or "unknown"
        if callable(self._key):
            return str(self._key(req))
        return str(req.state.get(self._key, "unknown"))

    def _refill(self, bucket: _Bucket) -> None:
        now     = time.monotonic()
        elapsed = now - bucket.last_refill
        refill  = int(elapsed / self._window * self._limit)
        if refill > 0:
            bucket.tokens      = min(self._limit, bucket.tokens + refill)
            bucket.last_refill = now

    def _evict_stale(self) -> None:
        """Remove buckets inactive for more than 2 windows — prevents unbounded growth."""
        cutoff  = time.monotonic() - (self._window * 2)
        stale   = [k for k, b in self._buckets.items() if b.last_refill < cutoff]
        for k in stale:
            del self._buckets[k]

    async def __call__(self, req: RequestContext) -> None:
        k = self._get_key(req)
        with self._lock:
            # Evict stale buckets every ~100 requests to prevent memory growth
            if len(self._buckets) % 100 == 0 and self._buckets:
                self._evict_stale()
            if k not in self._buckets:
                self._buckets[k] = _Bucket(self._limit)
            bucket = self._buckets[k]
            self._refill(bucket)
            if bucket.tokens <= 0:
                req.abort(429, "Rate limit exceeded", "too_many_requests")
            bucket.tokens -= 1


def rate_limit(
    limit: int,
    *,
    per:  str                  = "minute",
    key:  str | Callable | None = None,
) -> RateLimiter:
    """
    Create a rate limiter middleware callable.

        rate_limit(10, per="minute")
        rate_limit(5,  per="second", key="user_id")
    """
    window = _WINDOWS.get(per)
    if window is None:
        raise ValueError(f"rate_limit: unknown period '{per}'. Use: {list(_WINDOWS)}")
    return RateLimiter(limit, window, key=key)
