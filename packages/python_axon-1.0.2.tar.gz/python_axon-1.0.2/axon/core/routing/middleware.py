"""
Module Middleware Pipeline
==========================
Lets modules intercept HTTP requests and responses without importing
any web framework. This is entirely separate from FastAPI/Starlette
middleware -- it runs inside the platform's own layer.

Two entry points:

1. request_middleware(handler)    -- called before the route handler
2. response_middleware(handler)   -- called after the route handler

How modules register middleware
--------------------------------
    # In Module.register() or boot():

    from axon.core.routing.middleware import RequestContext, ResponseContext

    class Module(BaseModule):
        def register(self) -> None:
            # Register request middleware
            self.use(self._auth_check)          # runs before every request
            self.use(self._auth_check, path="/orders/*")  # path filter

            # Register response middleware
            self.use_response(self._add_headers)

        async def _auth_check(self, req: RequestContext) -> RequestContext | None:
            token = req.header("Authorization")
            if not token:
                req.abort(401, "Authentication required")
            # returning req continues the chain
            # returning None also continues
            # calling req.abort() stops the chain and returns an error response

        async def _add_headers(self, res: ResponseContext) -> ResponseContext:
            res.set_header("X-Powered-By", "Platform")
            return res

Route-level middleware (decorators on individual handlers)
----------------------------------------------------------
    @router.get("/admin/users", middleware=[require_auth, require_role("admin")])
    async def list_users(ctx: Context): ...

    # Middleware functions for route decorators:
    async def require_auth(req: RequestContext) -> RequestContext | None:
        if not req.header("Authorization"):
            req.abort(401, "Token required")

    def require_role(role: str):
        async def _check(req: RequestContext) -> RequestContext | None:
            user = req.state.get("user")
            if not user or role not in user.get("roles", []):
                req.abort(403, f"Role '{role}' required")
        return _check

Request context fields
-----------------------
req.method          GET, POST, PUT, ...
req.path            /orders/42
req.headers         dict-like (case-insensitive)
req.query           dict of query params
req.body            raw body bytes (if already read)
req.state           mutable dict for passing data between middleware
req.header(name)    convenience getter with optional default
req.abort(status, message, code=None)   stop chain, return error response

Response context fields
------------------------
res.status_code     int
res.body            dict | list | None
res.headers         dict
res.set_header(k,v) convenience setter
res.set_status(n)   convenience setter
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable


# ── Request context ───────────────────────────────────────────────────────

class RequestAborted(Exception):
    """Raised by req.abort() to short-circuit the middleware chain."""
    def __init__(self, status: int, message: str, code: str = "") -> None:
        self.status  = status
        self.message = message
        self.code    = code or _STATUS_CODES.get(status, "error")
        super().__init__(message)


@dataclass
class RequestContext:
    method:  str
    path:    str
    headers: dict[str, str]        = field(default_factory=dict)
    query:   dict[str, str]        = field(default_factory=dict)
    body:    bytes | None          = None
    state:   dict[str, Any]        = field(default_factory=dict)

    def header(self, name: str, default: str = "") -> str:
        return self.headers.get(name.lower(), self.headers.get(name, default))

    def abort(self, status: int, message: str = "", code: str = "") -> None:
        """Stop the middleware chain and return an error response."""
        raise RequestAborted(status, message, code)


# ── Response context ──────────────────────────────────────────────────────

@dataclass
class ResponseContext:
    status_code: int              = 200
    body:        Any              = None
    headers:     dict[str, str]   = field(default_factory=dict)

    def set_header(self, name: str, value: str) -> None:
        self.headers[name] = value

    def set_status(self, code: int) -> None:
        self.status_code = code


# ── Middleware registry ───────────────────────────────────────────────────

@dataclass(order=True)
class _MiddlewareEntry:
    priority:   int
    handler:    Callable = field(compare=False)
    path_prefix: str     = field(compare=False, default="")  # "" = all paths
    owner:      str      = field(compare=False, default="")


class MiddlewarePipeline:
    """
    Ordered pipeline of request/response middleware.
    Registered by modules via BaseModule.use() / use_response().
    Executed by the platform's ASGI middleware layer.
    """

    def __init__(self) -> None:
        self._request:  list[_MiddlewareEntry] = []
        self._response: list[_MiddlewareEntry] = []

    def add_request(
        self,
        handler: Callable,
        *,
        path: str = "",
        priority: int = 100,
        owner: str = "",
    ) -> None:
        self._request.append(_MiddlewareEntry(priority, handler, path, owner))
        self._request.sort()

    def add_response(
        self,
        handler: Callable,
        *,
        path: str = "",
        priority: int = 100,
        owner: str = "",
    ) -> None:
        self._response.append(_MiddlewareEntry(priority, handler, path, owner))
        self._response.sort()

    def _matches(self, entry: _MiddlewareEntry, path: str) -> bool:
        if not entry.path_prefix:
            return True
        pattern = entry.path_prefix.rstrip("*")
        return path.startswith(pattern)

    async def run_request(self, req: RequestContext) -> RequestContext:
        """Run all matching request middleware in priority order."""
        import asyncio, inspect
        for entry in self._request:
            if not self._matches(entry, req.path):
                continue
            if asyncio.iscoroutinefunction(entry.handler):
                result = await entry.handler(req)
            else:
                result = entry.handler(req)
            if result is not None:
                req = result
        return req

    async def run_response(self, req: RequestContext, res: ResponseContext) -> ResponseContext:
        """Run all matching response middleware in priority order."""
        import asyncio
        for entry in self._response:
            if not self._matches(entry, req.path):
                continue
            if asyncio.iscoroutinefunction(entry.handler):
                result = await entry.handler(res)
            else:
                result = entry.handler(res)
            if result is not None:
                res = result
        return res


# ── Status code map ───────────────────────────────────────────────────────
_STATUS_CODES = {
    400: "bad_request", 401: "unauthorized", 403: "forbidden",
    404: "not_found", 409: "conflict", 422: "unprocessable",
    429: "too_many_requests", 500: "server_error", 503: "service_unavailable",
}
