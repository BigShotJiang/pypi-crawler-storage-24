"""
HTTP Response Helpers
=====================
Raise typed platform exceptions from any route handler.
The platform catches them and returns the correct HTTP response.
No HTTP knowledge leaks into module code.

Usage
-----
    from axon.core.routing.responses import (
        ok, created, no_content,
        bad_request, unauthorized, forbidden,
        not_found, conflict, unprocessable,
        server_error,
    )

    # In a route handler:
    @router.get("/{order_id}")
    async def get_order(order_id: int, ctx: Context, svc: OrderService):
        order = svc.find(order_id)
        if not order:
            not_found(f"Order {order_id} does not exist")
        if order["status"] == "cancelled":
            bad_request("Cannot modify a cancelled order")
        return order

    # Or use ctx shorthand (same functions, accessible on Context):
    async def get_order(order_id: int, ctx: Context, svc: OrderService):
        order = svc.find(order_id)
        if not order:
            ctx.not_found(f"Order {order_id} does not exist")
        return order

Response shape
--------------
All error responses return:
    {
        "error": true,
        "status": 404,
        "message": "Order 42 does not exist",
        "code": "not_found"       # snake_case error code
    }

Success helpers return platform Response objects (rarely needed — just
return a plain dict/list for 200/201/204 responses).
"""

from __future__ import annotations

from typing import Any


# ── Exception hierarchy ────────────────────────────────────────────────────

class PlatformHTTPException(Exception):
    """Base for all platform HTTP exceptions. Caught by the error handler."""
    status_code: int = 500
    code: str = "error"

    def __init__(self, message: str = "", code: str | None = None) -> None:
        self.message = message or self.__class__.__doc__ or "An error occurred"
        if code:
            self.code = code
        super().__init__(self.message)

    def to_dict(self) -> dict[str, Any]:
        return {
            "error":   True,
            "status":  self.status_code,
            "message": self.message,
            "code":    self.code,
        }


class BadRequestError(PlatformHTTPException):
    """The request was malformed or contained invalid data."""
    status_code = 400
    code = "bad_request"

class UnauthorizedError(PlatformHTTPException):
    """Authentication is required or the provided credentials are invalid."""
    status_code = 401
    code = "unauthorized"

class ForbiddenError(PlatformHTTPException):
    """You do not have permission to perform this action."""
    status_code = 403
    code = "forbidden"

class NotFoundError(PlatformHTTPException):
    """The requested resource was not found."""
    status_code = 404
    code = "not_found"

class ConflictError(PlatformHTTPException):
    """The request conflicts with the current state of the resource."""
    status_code = 409
    code = "conflict"

class UnprocessableError(PlatformHTTPException):
    """The request was well-formed but contained semantic errors."""
    status_code = 422
    code = "unprocessable"

class TooManyRequestsError(PlatformHTTPException):
    """Rate limit exceeded."""
    status_code = 429
    code = "too_many_requests"

class ServerError(PlatformHTTPException):
    """An internal server error occurred."""
    status_code = 500
    code = "server_error"

class ServiceUnavailableError(PlatformHTTPException):
    """The service is temporarily unavailable."""
    status_code = 503
    code = "service_unavailable"


# ── Raise helpers (functions that raise, not return) ──────────────────────
# Using functions instead of constructors means: no "raise" keyword in user code,
# which reads more naturally in conditional branches.

def bad_request(message: str = "", code: str | None = None) -> None:
    """Raise a 400 Bad Request response."""
    raise BadRequestError(message, code)

def unauthorized(message: str = "", code: str | None = None) -> None:
    """Raise a 401 Unauthorized response."""
    raise UnauthorizedError(message or "Authentication required", code)

def forbidden(message: str = "", code: str | None = None) -> None:
    """Raise a 403 Forbidden response."""
    raise ForbiddenError(message or "You do not have permission to do this", code)

def not_found(message: str = "", code: str | None = None) -> None:
    """Raise a 404 Not Found response."""
    raise NotFoundError(message or "Resource not found", code)

def conflict(message: str = "", code: str | None = None) -> None:
    """Raise a 409 Conflict response."""
    raise ConflictError(message, code)

def unprocessable(message: str = "", code: str | None = None) -> None:
    """Raise a 422 Unprocessable Entity response."""
    raise UnprocessableError(message, code)

def too_many_requests(message: str = "", code: str | None = None) -> None:
    """Raise a 429 Too Many Requests response."""
    raise TooManyRequestsError(message or "Rate limit exceeded", code)

def server_error(message: str = "", code: str | None = None) -> None:
    """Raise a 500 Internal Server Error response."""
    raise ServerError(message or "An internal error occurred", code)

def service_unavailable(message: str = "", code: str | None = None) -> None:
    """Raise a 503 Service Unavailable response."""
    raise ServiceUnavailableError(message, code)

# Exported for use by exception handlers
_STATUS_CODES = {
    400: "bad_request", 401: "unauthorized", 403: "forbidden",
    404: "not_found", 409: "conflict", 422: "validation_error",
    429: "too_many_requests", 500: "server_error", 503: "service_unavailable",
}
