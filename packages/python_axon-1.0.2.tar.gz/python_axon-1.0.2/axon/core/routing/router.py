"""
Platform Router
===============
The only routing API module builders ever touch.
No FastAPI, Starlette, or HTTP imports needed in module code.

Basic usage
-----------
    from axon.core.routing.router import Router, Context

    router = Router(prefix="/orders", tags=["orders"])

    @router.get("/")
    async def list_orders(ctx: Context, svc: OrderService): ...

    @router.post("/", status=201)
    async def create_order(body: OrderIn, ctx: Context, svc: OrderService): ...

Group middleware (Laravel-style route groups)
---------------------------------------------
    from axon.core.auth.guards import require_auth, require_role

    # All routes on this router automatically require auth
    router = Router(prefix="/orders", middleware=[require_auth])

    # Nested group — inherits parent + adds role check
    admin = router.group("/admin", middleware=[require_role("admin")])

    @admin.delete("/{id}")   # runs: require_auth → require_role("admin") → handler
    async def delete_order(id: str, ctx: Context, svc: OrderService): ...

Resource routes (CRUD shorthand)
---------------------------------
    router.resource("/orders", OrderController)
    # Generates: index, store, show, update, destroy routes automatically

Named routes
------------
    @router.get("/profile", name="user.profile")
    async def profile(...): ...
    ctx.route_url("user.profile")   # → /api/profile

Module routes file (manifest.routes)
--------------------------------------
    # manifest.py
    manifest = Manifest(name="orders", routes="routes")
    # → platform imports app.modules.orders.routes and mounts all Router instances
"""

from __future__ import annotations

import inspect
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from axon.core.engine.app_engine import AppEngine

logger = logging.getLogger(__name__)

# Global named route registry — populated at mount time
_named_routes: dict[str, str] = {}


@dataclass
class _Route:
    method:     str
    path:       str
    handler:    Callable
    status:     int
    summary:    str | None
    name:       str | None
    middleware: list = field(default_factory=list)  # per-route only


# ── Context ───────────────────────────────────────────────────────────────────

class Context:
    """
    Injected into every route handler that declares ctx: Context.
    Platform services and HTTP helpers — no web framework imports needed.
    """

    def __init__(self, app: "AppEngine") -> None:
        self._app     = app
        self._request = None  # FastAPI Request, set by handler wrapper at request time

    def make(self, name_or_type) -> Any:
        return self._app.container.make(name_or_type)

    def config(self, key: str, default: Any = None) -> Any:
        return self._app.config(key, default)

    async def emit(self, event: str, payload: Any = None) -> None:
        await self._app.hooks.emit(event, payload)

    async def filter(self, event: str, value: Any) -> Any:
        return await self._app.hooks.filter(event, value)

    def db(self):
        return self._app.db

    def route_url(self, name: str) -> str | None:
        """Resolve a named route to its URL path."""
        return _named_routes.get(name)

    def bad_request(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import bad_request
        bad_request(message, code)

    def unauthorized(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import unauthorized
        unauthorized(message, code)

    def forbidden(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import forbidden
        forbidden(message, code)

    def not_found(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import not_found
        not_found(message, code)

    def conflict(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import conflict
        conflict(message, code)

    def unprocessable(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import unprocessable
        unprocessable(message, code)

    def server_error(self, message: str = "", code: str | None = None) -> None:
        from axon.core.routing.responses import server_error
        server_error(message, code)


# ── Router ────────────────────────────────────────────────────────────────────

class Router:
    """
    Platform router. Declare routes with decorators.
    Supports group middleware, nested groups, and resource shorthand.

    Parameters
    ----------
    prefix     : URL prefix for all routes on this router.
    tags       : OpenAPI doc tags.
    middleware : Callables run before every route on this router (group middleware).
    _parent_mw : Internal — middleware inherited from parent .group() call.
    """

    def __init__(
        self,
        prefix:     str             = "",
        tags:       list[str]       | None = None,
        middleware: list[Callable]  | None = None,
        _parent_mw: list[Callable]  | None = None,
    ) -> None:
        self.prefix       = prefix.rstrip("/")
        self.tags         = list(tags or [])
        self._group_mw    = list(middleware or [])
        self._parent_mw   = list(_parent_mw or [])
        self._routes: list[_Route] = []

    @property
    def _effective_mw(self) -> list[Callable]:
        """Full group middleware chain: parent → own. Per-route appended at mount."""
        return self._parent_mw + self._group_mw

    # ── Group / nesting ───────────────────────────────────────────────────────

    def group(
        self,
        prefix:     str,
        *,
        middleware: list[Callable] | None = None,
        tags:       list[str]      | None = None,
    ) -> "Router":
        """
        Create a child router inheriting this router's prefix and middleware.

        Child prefix  = self.prefix + prefix
        Child mw chain = self._effective_mw → middleware

        Example:
            api   = Router(prefix="/api", middleware=[require_auth])
            admin = api.group("/admin", middleware=[require_role("admin")])

            @admin.delete("/users/{id}")
            # chain: require_auth → require_role("admin") → handler
        """
        return Router(
            prefix     = self.prefix + prefix.rstrip("/"),
            tags       = tags or self.tags,
            middleware = middleware,
            _parent_mw = self._effective_mw,
        )

    # ── Route registration ────────────────────────────────────────────────────

    def _decorator(self, method: str, path: str, *, status: int = 200,
                   summary: str | None = None, name: str | None = None,
                   middleware: list | None = None):
        def decorator(fn: Callable) -> Callable:
            self._routes.append(_Route(
                method     = method,
                path       = path,
                handler    = fn,
                status     = status,
                summary    = summary or _humanise(fn.__name__),
                name       = name or fn.__name__,
                middleware = list(middleware or []),
            ))
            return fn
        return decorator

    def get(self, path: str, *, status: int = 200, summary: str | None = None,
            name: str | None = None, middleware: list | None = None):
        return self._decorator("get", path, status=status, summary=summary,
                               name=name, middleware=middleware)

    def post(self, path: str, *, status: int = 200, summary: str | None = None,
             name: str | None = None, middleware: list | None = None):
        return self._decorator("post", path, status=status, summary=summary,
                               name=name, middleware=middleware)

    def put(self, path: str, *, status: int = 200, summary: str | None = None,
            name: str | None = None, middleware: list | None = None):
        return self._decorator("put", path, status=status, summary=summary,
                               name=name, middleware=middleware)

    def patch(self, path: str, *, status: int = 200, summary: str | None = None,
              name: str | None = None, middleware: list | None = None):
        return self._decorator("patch", path, status=status, summary=summary,
                               name=name, middleware=middleware)

    def delete(self, path: str, *, status: int = 204, summary: str | None = None,
               name: str | None = None, middleware: list | None = None):
        return self._decorator("delete", path, status=status, summary=summary,
                               name=name, middleware=middleware)

    # ── Resource routes ───────────────────────────────────────────────────────

    def resource(
        self,
        path:    str,
        controller,
        *,
        only:    list[str] | None = None,
        except_: list[str] | None = None,
    ) -> None:
        """
        Register standard CRUD routes for a controller class.

        Controller methods → routes:
            index   → GET    {path}/
            store   → POST   {path}/
            show    → GET    {path}/{id}
            update  → PUT    {path}/{id}
            destroy → DELETE {path}/{id}

        Only generates methods that exist on the controller.

        Example:
            class OrderController:
                async def index(self, ctx: Context, svc: OrderService): ...
                async def show(self, id: str, ctx: Context, svc: OrderService): ...

            router.resource("/orders", OrderController)
            # skip some:
            router.resource("/orders", OrderController, only=["index", "show"])
            router.resource("/orders", OrderController, except_=["destroy"])
        """
        path = path.rstrip("/")

        _MAP = [
            ("index",   "get",    "/",      200, "List"),
            ("store",   "post",   "/",      201, "Create"),
            ("show",    "get",    "/{id}",  200, "Get"),
            ("update",  "put",    "/{id}",  200, "Update"),
            ("destroy", "delete", "/{id}",  204, "Delete"),
        ]

        allowed = set(only) if only else {a for a, *_ in _MAP}
        if except_:
            allowed -= set(except_)

        inst         = controller()
        resource_tag = path.lstrip("/").replace("/", ".")

        for action, method, suffix, status, verb in _MAP:
            if action not in allowed:
                continue
            fn = getattr(inst, action, None)
            if fn is None:
                continue
            self._routes.append(_Route(
                method     = method,
                path       = path + suffix,
                handler    = fn,
                status     = status,
                summary    = f"{verb} {resource_tag}",
                name       = f"{resource_tag}.{action}",
                middleware = [],
            ))
            logger.debug("resource: %s %s%s%s → %s.%s",
                         method.upper(), self.prefix, path, suffix,
                         controller.__name__, action)

    # ── FastAPI translation ───────────────────────────────────────────────────

    def _to_fastapi_router(self, app: "AppEngine", module_name: str):
        """Translate to a FastAPI APIRouter. Called once at lifespan startup."""
        from fastapi import APIRouter as _APIRouter

        tags      = self.tags or [module_name]
        fa_router = _APIRouter(prefix=self.prefix, tags=tags)

        for route in self._routes:
            # Full chain: group (inherited + own) → per-route
            full_mw = self._effective_mw + route.middleware
            wrapped = _wrap_handler(route.handler, app, route_middleware=full_mw)

            registrar = getattr(fa_router, route.method)
            registrar(
                route.path,
                status_code    = route.status,
                summary        = route.summary,
                name           = route.name,
                response_model = None,
            )(wrapped)

            # Register named route globally
            if route.name:
                _named_routes[route.name] = self.prefix + route.path

            logger.debug("Router: %s %s%s → %s",
                         route.method.upper(), self.prefix, route.path,
                         route.handler.__name__)

        return fa_router

    def __repr__(self) -> str:
        return (f"<Router prefix={self.prefix!r} "
                f"routes={len(self._routes)} "
                f"group_mw={len(self._effective_mw)}>")


# ── Handler wrapping ──────────────────────────────────────────────────────────

def _wrap_handler(
    fn: Callable,
    app: "AppEngine",
    route_middleware: list | None = None,
) -> Callable:
    """
    Produce a FastAPI-compatible coroutine that:
    - Strips self/cls (class-defined handlers)
    - Injects Context (with _request set for state access)
    - Injects registered services via DI
    - Leaves path/query/body params for FastAPI
    - Runs full middleware chain before the handler
    """
    from axon.core.routing.inject import build_injector

    try:
        import typing
        hints = typing.get_type_hints(fn)
    except Exception:
        hints = {}

    sig    = inspect.signature(fn)
    params = list(sig.parameters.keys())

    implicit: set[str] = set()
    if params and params[0] in ("self", "cls"):
        implicit.add(params[0])

    ctx_names = [
        name for name, p in sig.parameters.items()
        if name not in implicit
        and (hints.get(name) is Context or p.annotation is Context)
    ]
    ctx_name = ctx_names[0] if ctx_names else None

    skip     = implicit | ({ctx_name} if ctx_name else set())
    injected = build_injector(fn, app.container, hints, Context, skip)
    skip    |= set(injected.keys())

    other_params = [
        p for name, p in sig.parameters.items()
        if name not in skip
    ]

    if not ctx_name and not injected and not implicit and not route_middleware:
        return fn

    exec_ns: dict = {
        "_fn":       fn,
        "_app":      app,
        "Context":   Context,
        "_injected": injected,
    }

    param_strs: list[str] = []
    for p in other_params:
        ann = hints.get(p.name, p.annotation)
        if ann is inspect.Parameter.empty:
            param_strs.append(p.name)
        else:
            slot = "_ann_" + p.name
            exec_ns[slot] = ann
            if p.default is inspect.Parameter.empty:
                param_strs.append(p.name + ": " + slot)
            else:
                def_slot        = "_def_" + p.name
                exec_ns[def_slot] = p.default
                param_strs.append(p.name + ": " + slot + " = " + def_slot)

    param_list   = ", ".join(param_strs)
    implicit_arg = (list(implicit)[0] + "=None") if implicit else ""
    fa_args      = ", ".join(p.name + "=" + p.name for p in other_params)
    di_args      = ", ".join(n + "=_injected[" + repr(n) + "]" for n in injected)
    is_async     = inspect.iscoroutinefunction(fn)

    if route_middleware:
        from axon.core.routing.middleware import RequestContext, RequestAborted
        from fastapi import Request as _FReq
        from fastapi.responses import JSONResponse as _FResp

        exec_ns.update({
            "_FReq":   _FReq,
            "_RCtx":   RequestContext,
            "_RAbort": RequestAborted,
            "_FResp":  _FResp,
            "_mws":    route_middleware,
        })

        # Build ctx-aware inner function
        if ctx_name:
            ctx_parts = [x for x in [implicit_arg, fa_args] if x]
            ctx_parts += [ctx_name + "=_ctx_i"]
            ctx_parts += [n + "=_injected[" + repr(n) + "]" for n in injected]
            ctx_call  = ", ".join(ctx_parts)
            inner_sig = (param_list + ", _request=None") if param_list else "_request=None"
            inner_lines = [
                "async def _inner(" + inner_sig + "):",
                "    _ctx_i = Context(_app)",
                "    _ctx_i._request = _request",
                "    return " + ("await " if is_async else "") + "_fn(" + ctx_call + ")",
            ]
        else:
            all_call_parts = [x for x in [implicit_arg, fa_args, di_args] if x]
            all_call       = ", ".join(all_call_parts)
            inner_sig = (param_list + ", _request=None") if param_list else "_request=None"
            inner_lines = [
                "async def _inner(" + inner_sig + "):",
                "    return " + ("await " if is_async else "") + "_fn(" + all_call + ")",
            ]

        exec(compile("\n".join(inner_lines),
                     "<platform_inner:" + fn.__name__ + ">", "exec"), exec_ns)

        rp    = "request: _FReq"
        mw_pl = (rp + ", " + param_list) if param_list else rp
        icall = "_inner(" + (", ".join(p.name for p in other_params) + ", " if other_params else "") + "_request=request)"

        lines = [
            "async def _h(" + mw_pl + "):",
            "    _req = _RCtx(method=request.method, path=request.url.path,",
            "        headers=dict(request.headers), query=dict(request.query_params))",
            "    import asyncio as _aio",
            "    for _mw in _mws:",
            "        try:",
            "            _r = await _mw(_req) if _aio.iscoroutinefunction(_mw) else _mw(_req)",
            "            if _r is not None: _req = _r",
            "        except _RAbort as _e:",
            "            return _FResp(status_code=_e.status, content={'error':True,",
            "                'status':_e.status,'message':_e.message,'code':_e.code})",
            "    for _k,_v in _req.state.items(): setattr(request.state, _k, _v)",
            "    return await " + icall,
        ]
        exec(compile("\n".join(lines),
                     "<platform_route_mw:" + fn.__name__ + ">", "exec"), exec_ns)
        wrapper = exec_ns["_h"]

    else:
        if ctx_name:
            ctx_parts = [x for x in [implicit_arg, fa_args] if x]
            ctx_parts += [ctx_name + "=_ctx_i"]
            ctx_parts += [n + "=_injected[" + repr(n) + "]" for n in injected]
            ctx_call  = ", ".join(ctx_parts)
            src = ("async def _h(" + param_list + "):\n"
                   "    _ctx_i = Context(_app)\n"
                   "    return " + ("await " if is_async else "") + "_fn(" + ctx_call + ")\n")
        else:
            all_parts = [x for x in [implicit_arg, fa_args, di_args] if x]
            all_args  = ", ".join(all_parts)
            pfx  = "async " if is_async else ""
            call = ("await " if is_async else "") + "_fn(" + all_args + ")"
            src  = pfx + "def _h(" + param_list + "):\n    return " + call + "\n"
        exec(compile(src, "<platform_route:" + fn.__name__ + ">", "exec"), exec_ns)
        wrapper = exec_ns["_h"]

    wrapper.__name__     = fn.__name__
    wrapper.__doc__      = fn.__doc__
    wrapper.__module__   = fn.__module__
    wrapper.__qualname__ = fn.__qualname__
    return wrapper


def _humanise(name: str) -> str:
    return name.replace("_", " ").title()
