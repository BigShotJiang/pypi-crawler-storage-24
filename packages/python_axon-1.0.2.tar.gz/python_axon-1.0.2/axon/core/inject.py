"""
Dependency Injection
====================
Optional type-based injection for route handlers.
Module builders annotate handler parameters with service types —
the platform resolves them from the container at boot time (not per-request).

How it works
------------
1. Module registers a service in register():
       self.bind(OrderService)           # bind by type
       self.bind(OrderService, singleton=True)

2. Handler declares the type as a parameter:
       @router.get("/orders")
       async def list_orders(ctx: Context, svc: OrderService):
           return svc.list_all()

3. At mount time (once, at boot) the platform inspects the handler signature,
   sees OrderService, looks it up in the container by class name, and wraps
   the handler to inject it automatically.

4. At request time: a dict lookup + one container.make() call — microseconds.

Registration
------------
    # In Module.register():
    self.bind(OrderService)               # bind class — resolves by class name
    self.bind(OrderService, singleton=True)
    self.bind(OrderService, singleton=False)  # new instance per injection

    # bind() by type is new — string-based bind() still works too:
    self.bind("order_svc", OrderService)  # old style, ctx.make("order_svc")

Injection rules
---------------
- Parameters annotated with a class that is registered in the container
  are injected automatically.
- `ctx: Context` is always injected by the platform — no registration needed.
- Unknown types are left for FastAPI to handle (path params, query params, body).
- If a registered type is NOT in the container when routes are mounted,
  the platform raises InjectionError at boot — fail fast, never at request time.
- Circular dependencies between injected services are detected at boot.

What does NOT get injected
--------------------------
- Python builtins: int, str, float, bool, bytes
- Pydantic models (treated as request body by FastAPI)
- Optional[X] where X is not registered — treated as a query param
"""

from __future__ import annotations

import inspect
import logging
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from axon.core.container import Container

logger = logging.getLogger(__name__)

# Types that must never be injected — passed to FastAPI's normal param handling
_PASSTHROUGH_TYPES = {int, str, float, bool, bytes, type(None)}


class InjectionError(Exception):
    """Raised at boot time when a required injection cannot be satisfied."""


def _is_pydantic(tp: Any) -> bool:
    """True if tp is a Pydantic BaseModel subclass."""
    try:
        from pydantic import BaseModel
        return isinstance(tp, type) and issubclass(tp, BaseModel)
    except ImportError:
        return False


def _container_key(tp: type) -> str:
    """Derive the container lookup key from a type."""
    return tp.__name__


def build_injector(
    fn: Any,
    container: "Container",
    resolved_hints: dict[str, Any],
    ctx_type: type,
) -> dict[str, Any]:
    """
    Inspect *fn*'s parameters and return a dict of
    ``{param_name: resolved_service}`` for every injectable parameter.

    Called once at mount time — result is baked into the wrapper closure.

    Parameters
    ----------
    fn             : The original handler function
    container      : The platform service container
    resolved_hints : Result of typing.get_type_hints(fn)
    ctx_type       : The Context class (to skip it — handled elsewhere)

    Returns
    -------
    dict mapping param_name → resolved service instance (or factory key)
    """
    injected: dict[str, Any] = {}

    sig = inspect.signature(fn)

    for param_name, param in sig.parameters.items():
        tp = resolved_hints.get(param_name, param.annotation)

        # Skip unannotated, Context, builtins, Pydantic models
        if tp is inspect.Parameter.empty:
            continue
        if tp is ctx_type:
            continue
        if tp in _PASSTHROUGH_TYPES:
            continue
        if _is_pydantic(tp):
            continue
        if not isinstance(tp, type):
            continue

        key = _container_key(tp)

        if not container.has(key):
            # Not in container — could be a path/query param; let FastAPI handle it
            continue

        # Resolve now to catch errors at boot time
        try:
            service = container.make(key)
        except Exception as exc:
            raise InjectionError(
                f"Cannot inject '{param_name}: {tp.__name__}' into "
                f"'{fn.__name__}' — container.make('{key}') failed: {exc}"
            ) from exc

        injected[param_name] = service
        logger.debug(
            "DI: '%s' parameter '%s: %s' → container['%s']",
            fn.__name__, param_name, tp.__name__, key,
        )

    return injected
