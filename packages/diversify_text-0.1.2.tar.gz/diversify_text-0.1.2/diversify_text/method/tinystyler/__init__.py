"""TinyStyler method submodule."""

from diversify_text.method.tinystyler.method import TinyStylerMethod
from diversify_text.method.tinystyler.styles import DEFAULT_STYLE_BANK, DEFAULT_STYLES

__all__ = ["TinyStylerMethod", "DEFAULT_STYLE_BANK", "DEFAULT_STYLES"]
