"""Ledger configuration objects."""
