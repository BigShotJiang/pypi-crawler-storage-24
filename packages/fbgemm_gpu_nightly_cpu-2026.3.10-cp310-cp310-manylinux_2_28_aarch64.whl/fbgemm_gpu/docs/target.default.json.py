
{
    "version": "2026.3.10",
    "target": "default",
    "variant": "cpu"
}
