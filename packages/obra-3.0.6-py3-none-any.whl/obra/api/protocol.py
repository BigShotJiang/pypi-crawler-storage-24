"""Shared protocol types for the Hybrid Architecture.

This public module and its adjacent `protocol*.py` family modules are kept
byte-for-byte in sync between:
- functions/src/orchestration/protocol*.py
- obra/api/protocol*.py

Protocol Design (from PRD Section 1):
    - Server owns the brain (decisions, orchestration logic)
    - Client owns the hands (execution, code access)

Message Flow:
    Client -> Server: SessionStart, DerivedPlan, ExaminationReport,
                     RevisedPlan, ExecutionResult, AgentReport, FixResult, UserDecision
    Server -> Client: DeriveRequest, IntentRequest, ExamineRequest, RevisionRequest,
                     ExecutionRequest, ReviewRequest, FixRequest, EscalationNotice,
                     CompletionNotice, Story0Request

Phase Flow:
    DERIVATION -> STORY0 or EXECUTION -> REVIEW (workflow-governed)

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - functions/src/orchestration/coordinator.py
    - functions/src/state/session_schema.py
"""

import json
import logging
from dataclasses import dataclass, field
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any

from obra.workflow.stage_artifacts import (
    collect_artifact_contract_issues,
    normalize_stage_output_artifacts,
    normalize_workflow_accumulation_artifact,
)
from .protocol_core import (
    ActionType,
    AgentReportStatus,
    AgentType,
    BYPASS_MODE_TO_CLI_FLAG,
    DEFAULT_REPORT_REVIEW_AGENT_TYPES,
    DEFAULT_REVIEW_AGENTS,
    EscalationEnvelope,
    EscalationReason,
    ExecutionStatus,
    FixStatus,
    LegacyPhaseNormalizationPayload,
    LifecycleDecisionPayload,
    PlanItemType,
    Priority,
    QualityPolicyMode,
    ServerAction,
    SessionPhase,
    SessionStatus,
    UserDecisionChoice,
    VerificationOutcome,
    VerificationScope,
    WorkflowLifecyclePayload,
    _coerce_lifecycle_payload,
    _coerce_optional_dict,
    safe_enum_parse,
)
from .protocol_reports import (
    AgentReport,
    DerivedPlan,
    EscalationDecision,
    ExaminationReport,
    ExecutionResult,
    FixReport,
    FixResult,
    PlanUploadRequest,
    PlanUploadResponse,
    ProgressEvent,
    ResumeContext,
    ResumeRequest,
    RevisedPlan,
    SessionStart,
    UserDecision,
)
from .protocol_workflow import (
    WorkflowCandidateEnvelope,
    WorkflowMutationEvent,
    WorkflowMutationResult,
    WorkflowRevisionPayload,
    WorkflowRevisionRef,
    WorkflowSemanticView,
)

logger = logging.getLogger(__name__)


@dataclass
class DeriveRequest:
    """Request to derive a plan from objective.

    Sent by server after SessionStart to instruct client
    to derive an implementation plan.

    Attributes:
        objective: Task objective to plan for
        userplan_id: Required UserPlan ID that this derivation is for
        userplan_version: Required version of UserPlan used for derivation
        userplan_steps: Optional UserPlan step metadata for source linkage
        project_context: Project context (languages, frameworks, etc.)
        llm_provider: LLM provider to use
        constraints: Derivation constraints
        plan_items_reference: Plan items to preserve from previous derivation (for --from-step)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
        complexity_score: Pre-computed complexity score for exploration triggers (ADR-055)
        skip_story0: If True, skip Story 0 derivation step (debug/re-derive)
        intent_ready: If True, intent was pre-validated and should be loaded from storage
        workflow_derivation_request: Optional canonical workflow-derivation request
            carried from session start into the active derive action
    """

    objective: str
    userplan_id: str  # Required: UserPlan ID for derivation linkage
    userplan_version: int  # Required: Version of UserPlan used for derivation
    userplan_steps: list[dict[str, Any]] = field(default_factory=list)
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    constraints: dict[str, Any] = field(default_factory=dict)
    plan_items_reference: list[dict[str, Any]] = field(default_factory=list)
    base_prompt: str | None = None
    from_step: int | None = None  # Re-derive from step N, preserving steps 1 to N-1
    complexity_score: float | None = None  # Pre-computed complexity score (ADR-055)
    skip_story0: bool = False  # If True, skip Story 0 derivation step
    intent_ready: bool = False  # If True, intent pre-validated; load from storage
    workflow_derivation_request: dict[str, Any] | None = None
    derivation_id: str | None = None
    operator_review_checkpoint_state: dict[str, Any] = field(default_factory=dict)
    accepted_revision_ref: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "DeriveRequest":
        """Create from ServerAction payload.

        Raises:
            ValueError: If userplan_id is missing from the payload
            ValueError: If userplan_version is missing from the payload
        """
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for derivation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for derivation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            userplan_steps=payload.get("userplan_steps", []),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            constraints=payload.get("constraints", {}),
            plan_items_reference=payload.get("plan_items_reference", []),
            base_prompt=payload.get("base_prompt"),
            from_step=payload.get("from_step"),
            complexity_score=payload.get("complexity_score"),
            skip_story0=bool(payload.get("skip_story0", False)),
            intent_ready=bool(payload.get("intent_ready", False)),
            workflow_derivation_request=(
                payload.get("workflow_derivation_request")
                if isinstance(payload.get("workflow_derivation_request"), dict)
                else None
            ),
            derivation_id=(
                str(payload.get("derivation_id"))
                if payload.get("derivation_id") is not None
                else None
            ),
            operator_review_checkpoint_state=_coerce_optional_dict(
                payload.get("operator_review_checkpoint_state")
            ),
            accepted_revision_ref=_coerce_optional_dict(
                payload.get("accepted_revision_ref")
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
        )


@dataclass
class IntentRequest:
    """Request to generate and enrich intent before derivation.

    Sent by server when intent validation is enabled, to collect enriched
    intent content for SenseCheck validation prior to derivation.

    Attributes:
        objective: Task objective to derive intent for
        userplan_id: Required UserPlan ID that this intent is for
        userplan_version: Required version of UserPlan used for intent generation
        project_context: Project context (languages, frameworks, etc.)
        llm_provider: LLM provider to use
        from_step: Optional re-derivation start step for context
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
    """

    objective: str
    userplan_id: str
    userplan_version: int
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    from_step: int | None = None
    base_prompt: str | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "IntentRequest":
        """Create from ServerAction payload.

        Raises:
            ValueError: If userplan_id is missing from the payload
            ValueError: If userplan_version is missing from the payload
        """
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for intent generation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for intent generation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            from_step=payload.get("from_step"),
            base_prompt=payload.get("base_prompt"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "objective": self.objective,
            "userplan_id": self.userplan_id,
            "userplan_version": self.userplan_version,
            "project_context": self.project_context,
            "llm_provider": self.llm_provider,
        }
        if self.from_step is not None:
            data["from_step"] = self.from_step
        if self.base_prompt is not None:
            data["base_prompt"] = self.base_prompt
        return data


@dataclass
class ExamineRequest:
    """Request to examine the current plan.

    Sent by server after DerivedPlan or RevisedPlan to instruct
    client to examine the plan using LLM.

    Attributes:
        plan_version_id: Version ID of plan to examine
        plan_items: Plan items to examine
        all_plan_item_ids: Optional full plan item ID list for cross-batch dependency checks
        thinking_required: Whether extended thinking is required
        reasoning_level: Reasoning level (standard, high, max)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        iteration: Current refinement cycle number (None if not in a cycle)
        max_iterations: Maximum refinement iterations allowed (None if unbounded)
        batches: All examination batches for parallel dispatch (each batch has
            plan_items and all_plan_item_ids). Empty list for legacy single-batch flow.
    """

    plan_version_id: str
    plan_items: list[dict[str, Any]]
    thinking_required: bool = True
    reasoning_level: str = "standard"
    base_prompt: str | None = None
    iteration: int | None = None
    max_iterations: int | None = None
    all_plan_item_ids: list[str] | None = None
    batches: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExamineRequest":
        """Create from ServerAction payload."""
        raw_all_plan_item_ids = payload.get("all_plan_item_ids")
        all_plan_item_ids = None
        if isinstance(raw_all_plan_item_ids, list):
            normalized_ids = [
                str(item_id).strip()
                for item_id in raw_all_plan_item_ids
                if str(item_id).strip()
            ]
            all_plan_item_ids = normalized_ids or None
        return cls(
            plan_version_id=payload.get("plan_version_id", ""),
            plan_items=payload.get("plan_items", []),
            thinking_required=payload.get("thinking_required", True),
            reasoning_level=payload.get("reasoning_level", "standard"),
            base_prompt=payload.get("base_prompt"),
            iteration=payload.get("iteration"),
            max_iterations=payload.get("max_iterations"),
            all_plan_item_ids=all_plan_item_ids,
            batches=payload.get("batches", []),
        )


@dataclass
class RevisionRequest:
    """Request to revise the plan based on issues.

    Sent by server after ExaminationReport when blocking issues found.

    Attributes:
        issues: All issues from examination
        blocking_issues: Issues that must be addressed
        current_plan_version_id: Current plan version ID
        focus_areas: Areas to focus revision on
        batch_index: Zero-based revision batch index for batched revise flows
        total_batches: Total revision batches in current revise flow
        batches_remaining: Number of remaining batches after current batch
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        proposed_defaults: Proposed defaults to unblock P1 issues (optional)
        userplan_id: Optional UserPlan ID for source_step_id fallbacks
        batches: All revision batches for parallel dispatch (each batch has
            issues, blocking_issues, focus_areas). Empty list for legacy single-batch flow.
        full_plan_items: Complete plan items used as merge base for client-side
            revision overlay in parallel dispatch mode.
    """

    issues: list[dict[str, Any]]
    blocking_issues: list[dict[str, Any]]
    current_plan_version_id: str = ""
    focus_areas: list[str] = field(default_factory=list)
    batch_index: int = 0
    total_batches: int = 0
    batches_remaining: int = 0
    base_prompt: str | None = None
    proposed_defaults: list[dict[str, Any]] | None = None
    userplan_id: str | None = None
    batches: list[dict[str, Any]] = field(default_factory=list)
    full_plan_items: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "RevisionRequest":
        """Create from ServerAction payload."""
        return cls(
            issues=payload.get("issues", []),
            blocking_issues=payload.get("blocking_issues", []),
            current_plan_version_id=payload.get("current_plan_version_id", ""),
            focus_areas=payload.get("focus_areas", []),
            batch_index=int(payload.get("batch_index", 0) or 0),
            total_batches=int(payload.get("total_batches", 0) or 0),
            batches_remaining=int(payload.get("batches_remaining", 0) or 0),
            base_prompt=payload.get("base_prompt"),
            proposed_defaults=payload.get("proposed_defaults"),
            userplan_id=payload.get("userplan_id"),
            batches=payload.get("batches", []),
            full_plan_items=payload.get("full_plan_items", []),
        )


@dataclass
class ExecutionRequest:
    """Request to execute a plan item.

    Sent by server when plan passes examination.

    Attributes:
        plan_items: All plan items
        execution_index: Index of item to execute
        current_item: The specific item to execute
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        execution_context: Server-supplied context for deduplication (Issue #6)
    """

    plan_items: list[dict[str, Any]]
    execution_index: int = 0
    current_item: dict[str, Any] | None = None
    base_prompt: str | None = None
    execution_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExecutionRequest":
        """Create from ServerAction payload."""
        plan_items = payload.get("plan_items", [])
        execution_index = payload.get("execution_index", 0)
        current_item = None
        if plan_items and not (0 <= execution_index < len(plan_items)):
            # Defensive fallback for partial plan payloads.
            execution_index = 0
        if plan_items and 0 <= execution_index < len(plan_items):
            current_item = plan_items[execution_index]
        return cls(
            plan_items=plan_items,
            execution_index=execution_index,
            current_item=current_item,
            base_prompt=payload.get("base_prompt"),
            execution_context=payload.get("execution_context"),
        )


@dataclass
class ReviewRequest:
    """Request to run review agents on executed item.

    Sent by server after ExecutionResult.

    Attributes:
        item_id: Plan item ID that was executed
        agents_to_run: Optional list of agent types to run; defaults to
            report-review compatible baseline when missing/None/empty
        agent_budgets: Timeout/weight budgets per agent
        format: Optional output format (e.g., text, json)
        fail_on: Optional fail-fast threshold (e.g., p1, p2)
        complexity: Optional complexity tier provided by the server (simple|medium|complex)
        tests_required: Whether coverage gaps should be treated as blocking
        review_cycle_id: Optional review cycle identifier for event correlation
        diagnostic: Optional review-routing diagnostic message from server
        execution_status: Optional execution status context from prior action
        changed_files: Optional execution-scoped file paths for focused review
    """

    item_id: str
    agents_to_run: list[str] | None = None
    agent_budgets: dict[str, dict[str, Any]] = field(default_factory=dict)
    format: str | None = None
    fail_on: str | None = None
    complexity: str | None = None
    tests_required: bool = False
    review_cycle_id: str | None = None
    diagnostic: str | None = None
    execution_status: str | None = None
    changed_files: list[str] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ReviewRequest":
        """Create from ServerAction payload."""
        agents = payload.get("agents_to_run")
        if not agents:
            agents = payload.get("review_agents")

        agents_to_run = DEFAULT_REPORT_REVIEW_AGENT_TYPES.copy()
        if isinstance(agents, list) and agents:
            agents_to_run = agents

        complexity_value = payload.get("complexity")
        complexity = str(complexity_value) if complexity_value is not None else None
        return cls(
            item_id=payload.get("item_id", ""),
            agents_to_run=agents_to_run,
            agent_budgets=payload.get("agent_budgets", {}),
            format=payload.get("format"),
            fail_on=payload.get("fail_on"),
            complexity=complexity,
            tests_required=bool(payload.get("tests_required", False)),
            review_cycle_id=(
                str(payload.get("review_cycle_id"))
                if payload.get("review_cycle_id") is not None
                else None
            ),
            diagnostic=payload.get("diagnostic"),
            execution_status=(
                str(payload.get("execution_status"))
                if payload.get("execution_status") is not None
                else None
            ),
            changed_files=payload.get("changed_files"),
        )


@dataclass
class FixRequest:
    """Request to fix issues found during review.

    Sent by server after AgentReport when issues need fixing.

    Attributes:
        issues_to_fix: List of issues to fix (may be strings or dicts)
        execution_order: Order to fix issues (by ID)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        item_id: Plan item ID being fixed (ISSUE-SAAS-021)
        issue_details: Full issue dicts with priority info (FIX-PRIORITY-LOSS-001)
        issue_details may include test-gap metadata (issue_type, target_test_file,
        target_paths, test_name, arrange/act/assert) to guide test-focused fixes.
        fix_history: Optional summary of previous fix attempts
        fresh_fix: Whether this request is a guarded convergence fresh-fix pass
        refactor_mode: Whether this request permits architectural refactor scope
        fix_attempt: Current attempt number (1-indexed, 0 = not set)
        max_fix_attempts: Maximum fix attempts allowed
        item_context: Plan item metadata (title, description, acceptance_criteria)
        sibling_issues: Other blocking issues for cross-issue context awareness
    """

    issues_to_fix: list[dict[str, Any]]
    execution_order: list[str] = field(default_factory=list)
    base_prompt: str | None = None
    item_id: str = ""  # ISSUE-SAAS-021: Track item for fix-review loop
    issue_details: list[dict[str, Any]] = field(
        default_factory=list
    )  # FIX-PRIORITY-LOSS-001
    fix_history: str | None = None
    fresh_fix: bool = False
    refactor_mode: bool = False
    fix_attempt: int = 0  # Current attempt number (1-indexed, 0 = not set)
    max_fix_attempts: int = 3  # Maximum attempts allowed
    item_context: dict[str, Any] = field(default_factory=dict)  # Plan item metadata
    sibling_issues: list[dict[str, Any]] = field(
        default_factory=list
    )  # Other blocking issues for context

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "FixRequest":
        """Create from ServerAction payload."""
        return cls(
            issues_to_fix=payload.get("issues_to_fix", []),
            execution_order=payload.get("execution_order", []),
            base_prompt=payload.get("base_prompt"),
            item_id=payload.get("item_id", ""),  # ISSUE-SAAS-021
            issue_details=payload.get("issue_details", []),  # FIX-PRIORITY-LOSS-001
            fix_history=payload.get("fix_history"),
            fresh_fix=bool(payload.get("fresh_fix", False)),
            refactor_mode=bool(payload.get("refactor_mode", False)),
            fix_attempt=int(payload.get("fix_attempt", 0) or 0),
            max_fix_attempts=int(payload.get("max_fix_attempts", 3) or 3),
            item_context=payload.get("item_context", {}),
            sibling_issues=payload.get("sibling_issues", []),
        )


# =============================================================================
# Validator Messages (FEAT-SENSECHECK-PIPELINE-001)
# =============================================================================


VALIDATOR_STAGES = {
    "intent",
    "plan",
    "review_filter",
    "code",
    "code_verify",
    "escalation_fix",
}
VALIDATOR_SUBJECT_TYPES = {
    "intent",
    "plan_items",
    "agent_reports",
    "code_delta",
    "escalation_context",
}
ESCALATION_FIXER_ROUTES = frozenset(
    {
        "amend_plan",
        "fix_code",
        "reclassify_review",
        "retry_stage",
        "escalate",
    }
)
ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES = frozenset(
    {"auto", "tests", "lint", "security"}
)
_VALIDATOR_SCHEMA_PACKAGE = f"{__package__.rsplit('.', 1)[0]}.config.schemas"
_VALIDATOR_SCHEMA_FILE = "validator_payload.schema.json"


@lru_cache(maxsize=1)
def _load_validator_payload_schema() -> dict[str, Any]:
    try:
        schema_path = resources.files(_VALIDATOR_SCHEMA_PACKAGE).joinpath(
            _VALIDATOR_SCHEMA_FILE
        )
        content = schema_path.read_text(encoding="utf-8")
        return json.loads(content) if content.strip() else {}
    except Exception as exc:
        raise RuntimeError(
            "Failed to load validator schema from packaged resources "
            f"{_VALIDATOR_SCHEMA_PACKAGE}.{_VALIDATOR_SCHEMA_FILE}: {exc}"
        ) from exc


def _schema_type_matches(value: Any, expected_type: str) -> bool:
    if expected_type == "boolean":
        return isinstance(value, bool)
    if expected_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected_type == "string":
        return isinstance(value, str)
    if expected_type == "object":
        return isinstance(value, dict)
    if expected_type == "array":
        return isinstance(value, list)
    return True


def _validate_against_schema(
    value: Any, schema: dict[str, Any], path: str = "payload"
) -> tuple[bool, str]:
    expected_type = schema.get("type")
    if expected_type:
        types = expected_type if isinstance(expected_type, list) else [expected_type]
        if not any(_schema_type_matches(value, t) for t in types):
            return False, f"{path} must be of type {expected_type}"

    if "enum" in schema and value not in schema["enum"]:
        return False, f"{path} must be one of {schema['enum']}"

    if expected_type == "integer" and "minimum" in schema:
        minimum = schema.get("minimum")
        if isinstance(value, int) and not isinstance(value, bool) and value < minimum:
            return False, f"{path} must be >= {minimum}"

    if expected_type == "object":
        if not isinstance(value, dict):
            return False, f"{path} must be an object"
        required = schema.get("required", [])
        for field_name in required:
            if field_name not in value:
                return False, f"Missing required field: {field_name}"

        properties = schema.get("properties", {})
        for key, subschema in properties.items():
            if key in value:
                is_valid, error = _validate_against_schema(
                    value[key],
                    subschema,
                    path=f"{path}.{key}",
                )
                if not is_valid:
                    return False, error

        if schema.get("additionalProperties") is False:
            extra = set(value.keys()) - set(properties.keys())
            if extra:
                return False, f"Unexpected fields: {', '.join(sorted(extra))}"

    if expected_type == "array":
        if not isinstance(value, list):
            return False, f"{path} must be an array"
        items_schema = schema.get("items")
        if items_schema:
            for index, item in enumerate(value):
                is_valid, error = _validate_against_schema(
                    item,
                    items_schema,
                    path=f"{path}[{index}]",
                )
                if not is_valid:
                    return False, error

    return True, ""


def _validate_validator_schema(
    payload: dict[str, Any],
    schema_name: str,
) -> tuple[bool, str]:
    try:
        schema = _load_validator_payload_schema()
    except FileNotFoundError as exc:
        return False, str(exc)

    definitions = schema.get("$defs", {})
    definition = definitions.get(schema_name)
    if not isinstance(definition, dict):
        return False, f"Schema definition not found: {schema_name}"
    return _validate_against_schema(payload, definition)


@dataclass
class ValidatorRequest:
    """Request to execute a validator on the client.

    Sent by the server to request a validator run against a subject payload.

    Attributes:
        stage: Validation stage (intent, plan, review_filter, code)
        subject_type: Type of subject payload (intent, plan_items, agent_reports, code_delta)
        subject_payload: Payload to validate
        prompt_id: Prompt identifier for provenance
        prompt_version: Prompt version for provenance
        compiled_prompt: Fully compiled prompt text (server-owned)
        timeout_s: Timeout in seconds for validator execution
        config: Validator config (schema_validation, prompt_provenance, etc.)
    """

    stage: str
    subject_type: str
    subject_payload: dict[str, Any]
    prompt_id: str
    prompt_version: str
    compiled_prompt: str
    timeout_s: int
    config: dict[str, Any]

    @classmethod
    def from_payload(
        cls, payload: dict[str, Any], *, schema_validation: bool = True
    ) -> "ValidatorRequest":
        """Create from ServerAction payload with validation."""
        request = cls(
            stage=payload.get("stage", ""),
            subject_type=payload.get("subject_type", ""),
            subject_payload=payload.get("subject_payload", {}),
            prompt_id=payload.get("prompt_id", ""),
            prompt_version=payload.get("prompt_version", ""),
            compiled_prompt=payload.get("compiled_prompt", ""),
            timeout_s=payload.get("timeout_s", 30),
            config=payload.get("config", {}),
        )
        is_valid, error = validate_validator_request(
            request, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"ValidatorRequest validation failed: {error}")
        return request

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage": self.stage,
            "subject_type": self.subject_type,
            "subject_payload": self.subject_payload,
            "prompt_id": self.prompt_id,
            "prompt_version": self.prompt_version,
            "compiled_prompt": self.compiled_prompt,
            "timeout_s": self.timeout_s,
            "config": self.config,
        }


@dataclass
class ValidatorResult:
    """Result payload returned by a validator."""

    sound: bool
    issues: list[dict[str, Any]] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    decisions: list[dict[str, Any]] = field(default_factory=list)
    version: str = "v1"
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "sound": self.sound,
            "issues": self.issues,
            "constraints": self.constraints,
            "decisions": self.decisions,
            "version": self.version,
            "provenance": self.provenance,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any], *, schema_validation: bool = True
    ) -> "ValidatorResult":
        """Create from dictionary with validation."""
        result = cls(
            sound=bool(data.get("sound", False)),
            issues=data.get("issues", []),
            constraints=data.get("constraints", []),
            decisions=data.get("decisions", []),
            version=data.get("version", "v1"),
            provenance=data.get("provenance", {}),
        )
        is_valid, error = validate_validator_result(
            result, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"ValidatorResult validation failed: {error}")
        return result


@dataclass
class EscalationFixerResult:
    """Result payload returned by the escalation-fixer validator."""

    repairable: bool
    route: str
    root_cause: str = ""
    summary: str = ""
    amend_plan: dict[str, Any] | None = None
    fix_code: dict[str, Any] | None = None
    reclassify_review: dict[str, Any] | None = None
    retry_stage: dict[str, Any] | None = None
    version: str = "v1"
    provenance: dict[str, Any] = field(default_factory=dict)
    stage: str = "escalation_fix"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        result: dict[str, Any] = {
            "stage": self.stage,
            "repairable": self.repairable,
            "route": self.route,
            "root_cause": self.root_cause,
            "summary": self.summary,
            "version": self.version,
            "provenance": self.provenance,
        }
        if self.amend_plan is not None:
            result["amend_plan"] = self.amend_plan
        if self.fix_code is not None:
            result["fix_code"] = self.fix_code
        if self.reclassify_review is not None:
            result["reclassify_review"] = self.reclassify_review
        if self.retry_stage is not None:
            result["retry_stage"] = self.retry_stage
        return result

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        schema_validation: bool = True,
    ) -> "EscalationFixerResult":
        """Create from dictionary with validation."""
        result = cls(
            stage=str(data.get("stage", "escalation_fix") or "escalation_fix"),
            repairable=bool(data.get("repairable", False)),
            route=str(data.get("route", "") or ""),
            root_cause=str(data.get("root_cause", "") or ""),
            summary=str(data.get("summary", "") or ""),
            amend_plan=_coerce_optional_dict(data.get("amend_plan"))
            if data.get("amend_plan") is not None
            else None,
            fix_code=_coerce_optional_dict(data.get("fix_code"))
            if data.get("fix_code") is not None
            else None,
            reclassify_review=_coerce_optional_dict(data.get("reclassify_review"))
            if data.get("reclassify_review") is not None
            else None,
            retry_stage=_coerce_optional_dict(data.get("retry_stage"))
            if data.get("retry_stage") is not None
            else None,
            version=str(data.get("version", "v1") or "v1"),
            provenance=_coerce_optional_dict(data.get("provenance")),
        )
        is_valid, error = validate_escalation_fixer_result(
            result, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"EscalationFixerResult validation failed: {error}")
        return result


@dataclass
class StoryPreflightResult:
    """Result payload returned by Story Pre-flight verification."""

    findings: list[dict[str, Any]] = field(default_factory=list)
    task_modifications: list[dict[str, Any]] = field(default_factory=list)
    sense_check: dict[str, Any] | None = None
    resolved_findings: list[dict[str, Any]] = field(default_factory=list)
    loop_metadata: dict[str, Any] = field(default_factory=dict)
    disposition: str = "PROCEED"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "findings": self.findings,
            "task_modifications": self.task_modifications,
            "sense_check": self.sense_check,
            "resolved_findings": self.resolved_findings,
            "loop_metadata": self.loop_metadata,
            "disposition": self.disposition,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StoryPreflightResult":
        """Create from dictionary with validation."""
        disposition = str(data.get("disposition", "PROCEED")).upper()
        allowed = {"PROCEED", "REVISE", "ESCALATE"}
        if disposition not in allowed:
            msg = (
                f"StoryPreflightResult disposition must be one of "
                f"{sorted(allowed)}, got {disposition!r}"
            )
            raise ValueError(msg)
        return cls(
            findings=data.get("findings", []),
            task_modifications=data.get("task_modifications", []),
            sense_check=data.get("sense_check"),
            resolved_findings=data.get("resolved_findings", []),
            loop_metadata=data.get("loop_metadata", {}),
            disposition=disposition,
        )


@dataclass
class StoryPreflightRequest:
    """Request to run story pre-flight verification and refinement.

    Sent by the server before entering execution for a story boundary.

    Attributes:
        story_item: Story-level item payload under evaluation
        plan_items: Full execution-plan items for context and dependency checks
        exploration_context: Optional exploration artifacts used by preflight checks
    """

    story_item: dict[str, Any] = field(default_factory=dict)
    plan_items: list[dict[str, Any]] = field(default_factory=list)
    exploration_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "StoryPreflightRequest":
        """Create from ServerAction payload."""
        raw_story_item = payload.get("story_item")
        raw_plan_items = payload.get("plan_items")
        raw_exploration_context = payload.get("exploration_context")
        return cls(
            story_item=raw_story_item if isinstance(raw_story_item, dict) else {},
            plan_items=raw_plan_items if isinstance(raw_plan_items, list) else [],
            exploration_context=(
                raw_exploration_context
                if isinstance(raw_exploration_context, dict)
                else None
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "story_item": self.story_item,
            "plan_items": self.plan_items,
        }
        if self.exploration_context is not None:
            data["exploration_context"] = self.exploration_context
        return data


def validate_validator_request(
    request: ValidatorRequest, *, schema_validation: bool = True
) -> tuple[bool, str]:
    """Validate a ValidatorRequest."""
    if not isinstance(request, ValidatorRequest):
        return False, "Request must be a ValidatorRequest"
    if not request.stage:
        return False, "Missing required field: stage"
    if request.stage not in VALIDATOR_STAGES:
        return False, f"Invalid stage: {request.stage}"
    if not request.subject_type:
        return False, "Missing required field: subject_type"
    if request.subject_type not in VALIDATOR_SUBJECT_TYPES:
        return False, f"Invalid subject_type: {request.subject_type}"
    if request.subject_payload is None:
        return False, "Missing required field: subject_payload"
    if not isinstance(request.subject_payload, dict):
        return False, "subject_payload must be a dict"
    if request.prompt_id is None:
        return False, "Missing required field: prompt_id"
    if request.prompt_version is None:
        return False, "Missing required field: prompt_version"
    if request.compiled_prompt is None:
        return False, "Missing required field: compiled_prompt"
    if request.timeout_s is None:
        return False, "Missing required field: timeout_s"
    if not isinstance(request.timeout_s, int):
        return False, "timeout_s must be an int"
    if request.config is None:
        return False, "Missing required field: config"
    if not isinstance(request.config, dict):
        return False, "config must be a dict"
    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            request.to_dict(), "validator_request"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


def validate_validator_result(
    result: ValidatorResult, *, schema_validation: bool = True
) -> tuple[bool, str]:
    """Validate a ValidatorResult."""
    if not isinstance(result, ValidatorResult):
        return False, "Result must be a ValidatorResult"
    if not isinstance(result.sound, bool):
        return False, "sound must be a bool"
    if not isinstance(result.issues, list):
        return False, "issues must be a list"
    if not isinstance(result.constraints, list):
        return False, "constraints must be a list"
    if not isinstance(result.decisions, list):
        return False, "decisions must be a list"
    if not isinstance(result.provenance, dict):
        return False, "provenance must be a dict"
    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            result.to_dict(), "validator_result"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


def validate_escalation_fixer_result(
    result: EscalationFixerResult,
    *,
    schema_validation: bool = True,
) -> tuple[bool, str]:
    """Validate an EscalationFixerResult."""
    if not isinstance(result, EscalationFixerResult):
        return False, "Result must be an EscalationFixerResult"
    if result.stage != "escalation_fix":
        return False, "stage must be 'escalation_fix'"
    if not isinstance(result.repairable, bool):
        return False, "repairable must be a bool"
    if result.route not in ESCALATION_FIXER_ROUTES:
        return False, f"route must be one of {sorted(ESCALATION_FIXER_ROUTES)}"
    if not isinstance(result.root_cause, str):
        return False, "root_cause must be a string"
    if not isinstance(result.summary, str):
        return False, "summary must be a string"
    if not isinstance(result.version, str):
        return False, "version must be a string"
    if not isinstance(result.provenance, dict):
        return False, "provenance must be a dict"

    route_payloads = {
        "amend_plan": result.amend_plan,
        "fix_code": result.fix_code,
        "reclassify_review": result.reclassify_review,
        "retry_stage": result.retry_stage,
    }
    for route_name, payload in route_payloads.items():
        if payload is not None and not isinstance(payload, dict):
            return False, f"{route_name} must be a dict when provided"

    required_payload_field = {
        "amend_plan": "amend_plan",
        "fix_code": "fix_code",
        "reclassify_review": "reclassify_review",
        "retry_stage": "retry_stage",
    }.get(result.route)
    if required_payload_field is not None and getattr(result, required_payload_field) is None:
        return False, f"{required_payload_field} is required for route={result.route!r}"

    if result.route == "fix_code":
        payload = result.fix_code or {}
        reason = payload.get("reason")
        guidance = payload.get("guidance")
        if not isinstance(reason, str) or not reason.strip():
            return False, "fix_code.reason must be a non-empty string"
        if not isinstance(guidance, str) or not guidance.strip():
            return False, "fix_code.guidance must be a non-empty string"
        issue_ids = payload.get("issue_ids", [])
        if not isinstance(issue_ids, list) or not all(
            isinstance(issue_id, str) for issue_id in issue_ids
        ):
            return False, "fix_code.issue_ids must be a list[str]"
        fresh_fix = payload.get("fresh_fix")
        if fresh_fix is not None and not isinstance(fresh_fix, bool):
            return False, "fix_code.fresh_fix must be a bool when provided"
        drop_fix_history = payload.get("drop_fix_history")
        if drop_fix_history is not None and not isinstance(drop_fix_history, bool):
            return False, "fix_code.drop_fix_history must be a bool when provided"
        verification_scope = payload.get("verification_scope")
        if verification_scope is not None:
            if not isinstance(verification_scope, str) or not verification_scope.strip():
                return False, "fix_code.verification_scope must be a non-empty string"
            if (
                verification_scope.strip().lower()
                not in ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES
            ):
                return (
                    False,
                    "fix_code.verification_scope must be one of "
                    f"{sorted(ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES)}",
                )

    if schema_validation:
        schema_valid, schema_error = _validate_validator_schema(
            result.to_dict(), "escalation_fixer_result"
        )
        if not schema_valid:
            return False, schema_error
    return True, ""


# =============================================================================
# Pipeline Stage Messages (FEAT-PIPELINE-001)
# =============================================================================


@dataclass
class StageRoutingSignal:
    """Advisory routing recommendation returned by a stage runner."""

    recommended_action: str = ""
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "recommended_action": self.recommended_action,
            "reason": self.reason,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageRoutingSignal | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            recommended_action=str(data.get("recommended_action", "") or ""),
            reason=str(data.get("reason", "") or ""),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class StageLoopSignal:
    """Advisory loop-control recommendation returned by a stage runner."""

    recommended_action: str = ""
    reason: str = ""
    current_iteration: int = 0
    max_iterations: int = 0
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: "PendingManualPayload | None" = None
    resume: "LoopResumePayload | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "recommended_action": self.recommended_action,
            "reason": self.reason,
            "current_iteration": self.current_iteration,
            "max_iterations": self.max_iterations,
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict()
                if self.pending_manual is not None
                else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageLoopSignal | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            recommended_action=str(data.get("recommended_action", "") or ""),
            reason=str(data.get("reason", "") or ""),
            current_iteration=int(data.get("current_iteration", 0) or 0),
            max_iterations=int(data.get("max_iterations", 0) or 0),
            loop_verdict=str(data.get("loop_verdict", "") or ""),
            loop_state=str(data.get("loop_state", "") or ""),
            pending_manual=PendingManualPayload.from_dict(data.get("pending_manual")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class LoopResumePayload:
    """Explicit loop-resume metadata carried across request, result, and state payloads."""

    checkpoint: str = ""
    strategy: str = ""
    token: str = ""
    token_field: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "checkpoint": self.checkpoint,
            "strategy": self.strategy,
            "token": self.token,
            "token_field": self.token_field,
            "metadata": self.metadata,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "LoopResumePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            checkpoint=str(data.get("checkpoint", "") or ""),
            strategy=str(data.get("strategy", "") or ""),
            token=str(data.get("token", "") or ""),
            token_field=str(data.get("token_field", "") or ""),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
            workflow_lifecycle=_coerce_lifecycle_payload(
                data.get("workflow_lifecycle")
            ),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class PendingManualPayload:
    """Explicit metadata for a stage paused in pending-manual loop state."""

    reason: str = ""
    required_action: str = ""
    blocking: bool = True
    resume: LoopResumePayload | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "reason": self.reason,
            "required_action": self.required_action,
            "blocking": self.blocking,
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "metadata": self.metadata,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "PendingManualPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            reason=str(data.get("reason", "") or ""),
            required_action=str(data.get("required_action", "") or ""),
            blocking=bool(
                True if data.get("blocking") is None else data.get("blocking")
            ),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
            workflow_lifecycle=_coerce_lifecycle_payload(
                data.get("workflow_lifecycle")
            ),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class WaitPayload:
    """Explicit WAIT action payload contract for polling and resume flows."""

    status: str = ""
    reason: str = ""
    confidence: float | None = None
    polling: dict[str, Any] = field(default_factory=dict)
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    derivation_id: str | None = None
    operator_review_checkpoint_state: dict[str, Any] = field(default_factory=dict)
    accepted_revision_ref: dict[str, Any] = field(default_factory=dict)
    expected_baseline_ref: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        payload: dict[str, Any] = {
            "status": self.status,
            "reason": self.reason,
            "polling": self.polling,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
        }
        if self.confidence is not None:
            payload["confidence"] = self.confidence
        if self.pending_manual is not None:
            payload["pending_manual"] = self.pending_manual.to_dict()
        if self.resume is not None:
            payload["resume"] = self.resume.to_dict()
        if self.derivation_id is not None:
            payload["derivation_id"] = self.derivation_id
        if self.operator_review_checkpoint_state:
            payload["operator_review_checkpoint_state"] = (
                self.operator_review_checkpoint_state
            )
        if self.accepted_revision_ref:
            payload["accepted_revision_ref"] = self.accepted_revision_ref
        if self.expected_baseline_ref:
            payload["expected_baseline_ref"] = self.expected_baseline_ref
        if self.correlation:
            payload["correlation"] = self.correlation
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "WaitPayload":
        """Create from ServerAction payload."""
        return cls(
            status=str(payload.get("status") or ""),
            reason=str(payload.get("reason") or ""),
            confidence=(
                float(payload["confidence"])
                if payload.get("confidence") is not None
                else None
            ),
            polling=_coerce_optional_dict(payload.get("polling")),
            pending_manual=PendingManualPayload.from_dict(
                payload.get("pending_manual")
            ),
            resume=LoopResumePayload.from_dict(payload.get("resume")),
            workflow_lifecycle=_coerce_lifecycle_payload(
                payload.get("workflow_lifecycle")
            ),
            lifecycle_decisions=_coerce_optional_dict(
                payload.get("lifecycle_decisions")
            ),
            legacy_phase_normalization=_coerce_optional_dict(
                payload.get("legacy_phase_normalization")
            ),
            derivation_id=(
                str(payload.get("derivation_id"))
                if payload.get("derivation_id") is not None
                else None
            ),
            operator_review_checkpoint_state=_coerce_optional_dict(
                payload.get("operator_review_checkpoint_state")
            ),
            accepted_revision_ref=_coerce_optional_dict(
                payload.get("accepted_revision_ref")
            ),
            expected_baseline_ref=_coerce_optional_dict(
                payload.get("expected_baseline_ref")
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
            metadata=_coerce_optional_dict(payload.get("metadata")),
        )


@dataclass
class ArtifactReferencePayload:
    """Wire-safe canonical artifact reference."""

    target_artifact_type: str = ""
    target_artifact_id: str = ""
    target_version_selector: str = "latest"
    relationship_type: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "target_artifact_type": self.target_artifact_type,
            "target_artifact_id": self.target_artifact_id,
            "target_version_selector": self.target_version_selector,
            "relationship_type": self.relationship_type,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any] | None
    ) -> "ArtifactReferencePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            target_artifact_type=str(data.get("target_artifact_type", "") or ""),
            target_artifact_id=str(data.get("target_artifact_id", "") or ""),
            target_version_selector=str(
                data.get("target_version_selector", "latest") or "latest"
            ),
            relationship_type=str(data.get("relationship_type", "") or ""),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class ResolvedStageAssetBindingPayload:
    """Wire-safe resolved stage-template binding metadata."""

    binding_role: str = ""
    binding_scope: str = ""
    stage_id: str = ""
    artifact_ref: ArtifactReferencePayload | None = None
    content_format: str = ""
    adoption_state: str = ""
    materialized_path: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "binding_role": self.binding_role,
            "binding_scope": self.binding_scope,
            "stage_id": self.stage_id,
            "artifact_ref": (
                self.artifact_ref.to_dict() if self.artifact_ref is not None else None
            ),
            "content_format": self.content_format,
            "adoption_state": self.adoption_state,
            "materialized_path": self.materialized_path,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any] | None
    ) -> "ResolvedStageAssetBindingPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            binding_role=str(data.get("binding_role", "") or ""),
            binding_scope=str(data.get("binding_scope", "") or ""),
            stage_id=str(data.get("stage_id", "") or ""),
            artifact_ref=ArtifactReferencePayload.from_dict(data.get("artifact_ref")),
            content_format=str(data.get("content_format", "") or ""),
            adoption_state=str(data.get("adoption_state", "") or ""),
            materialized_path=str(data.get("materialized_path", "") or ""),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class ProducedArtifactPayload:
    """Wire-safe produced artifact metadata used by stage runners."""

    artifact_type: str = ""
    artifact_id: str = ""
    version: str = ""
    compatibility_version: str = ""
    created_at: str = ""
    producer_kind: str = ""
    producer_id: str = ""
    operation_kind: str = ""
    workflow_execution_id: str = ""
    attempt_id: str = ""
    stage_id: str = ""
    stage_name: str = ""
    path: str = ""
    file_targets: list[str] = field(default_factory=list)
    files_changed: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "artifact_type": self.artifact_type,
            "artifact_id": self.artifact_id,
            "version": self.version,
            "compatibility_version": self.compatibility_version,
            "created_at": self.created_at,
            "producer_kind": self.producer_kind,
            "producer_id": self.producer_id,
            "operation_kind": self.operation_kind,
            "workflow_execution_id": self.workflow_execution_id,
            "attempt_id": self.attempt_id,
            "stage_id": self.stage_id,
            "stage_name": self.stage_name,
            "path": self.path,
            "file_targets": self.file_targets,
            "files_changed": self.files_changed,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "ProducedArtifactPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            artifact_type=str(data.get("artifact_type", "") or ""),
            artifact_id=str(data.get("artifact_id", "") or ""),
            version=str(data.get("version", "") or ""),
            compatibility_version=str(data.get("compatibility_version", "") or ""),
            created_at=str(data.get("created_at", "") or ""),
            producer_kind=str(data.get("producer_kind", "") or ""),
            producer_id=str(data.get("producer_id", "") or ""),
            operation_kind=str(data.get("operation_kind", "") or ""),
            workflow_execution_id=str(data.get("workflow_execution_id", "") or ""),
            attempt_id=str(data.get("attempt_id", "") or ""),
            stage_id=str(data.get("stage_id", "") or ""),
            stage_name=str(data.get("stage_name", "") or ""),
            path=str(data.get("path", "") or ""),
            file_targets=(
                [
                    str(item)
                    for item in data.get("file_targets", [])
                    if str(item).strip()
                ]
                if isinstance(data.get("file_targets"), list)
                else []
            ),
            files_changed=(
                [
                    str(item)
                    for item in data.get("files_changed", [])
                    if str(item).strip()
                ]
                if isinstance(data.get("files_changed"), list)
                else []
            ),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class StageRunnerContext:
    """Typed runtime context passed to a stage runner."""

    stage_name: str = ""
    stage_execution_id: str = ""
    trigger: str = ""
    input_type: str = ""
    domain_id: str = ""
    workflow_refs: dict[str, Any] = field(default_factory=dict)
    stage_refs: dict[str, Any] = field(default_factory=dict)
    workflow_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    execution_input_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    stage_asset_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    resolved_stage_asset_bindings: list[ResolvedStageAssetBindingPayload] = field(
        default_factory=list
    )
    prior_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(
        default_factory=list
    )
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)
    loop_state: dict[str, Any] = field(default_factory=dict)
    loop_verdict: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    working_directory: str = ""
    timeout_s: int = 600
    runtime_metadata: dict[str, Any] = field(default_factory=dict)
    runner_config: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "stage_execution_id": self.stage_execution_id,
            "trigger": self.trigger,
            "input_type": self.input_type,
            "domain_id": self.domain_id,
            "workflow_refs": self.workflow_refs,
            "stage_refs": self.stage_refs,
            "workflow_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.workflow_artifact_refs
            ],
            "execution_input_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.execution_input_artifact_refs
            ],
            "stage_asset_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.stage_asset_artifact_refs
            ],
            "resolved_stage_asset_bindings": [
                binding.to_dict() for binding in self.resolved_stage_asset_bindings
            ],
            "prior_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.prior_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "payload": self.payload,
            "history": self.history,
            "loop_state": self.loop_state,
            "loop_verdict": self.loop_verdict,
            "pending_manual": (
                self.pending_manual.to_dict()
                if self.pending_manual is not None
                else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
            "working_directory": self.working_directory,
            "timeout_s": self.timeout_s,
            "runtime_metadata": self.runtime_metadata,
            "runner_config": self.runner_config,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "StageRunnerContext":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return cls()
        return cls(
            stage_name=str(data.get("stage_name", "") or ""),
            stage_execution_id=str(data.get("stage_execution_id", "") or ""),
            trigger=str(data.get("trigger", "") or ""),
            input_type=str(data.get("input_type", "") or ""),
            domain_id=str(data.get("domain_id", "") or ""),
            workflow_refs=(
                data.get("workflow_refs", {})
                if isinstance(data.get("workflow_refs"), dict)
                else {}
            ),
            stage_refs=(
                data.get("stage_refs", {})
                if isinstance(data.get("stage_refs"), dict)
                else {}
            ),
            workflow_artifact_refs=[
                artifact_ref
                for item in (data.get("workflow_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            execution_input_artifact_refs=[
                artifact_ref
                for item in (data.get("execution_input_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            stage_asset_artifact_refs=[
                artifact_ref
                for item in (data.get("stage_asset_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            resolved_stage_asset_bindings=[
                binding
                for item in (data.get("resolved_stage_asset_bindings") or [])
                for binding in [ResolvedStageAssetBindingPayload.from_dict(item)]
                if binding is not None
            ],
            prior_stage_output_artifact_refs=[
                artifact_ref
                for item in (data.get("prior_stage_output_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            accepted_stage_output_artifact_refs=[
                artifact_ref
                for item in (data.get("accepted_stage_output_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            candidate_stage_output_artifacts=[
                artifact
                for item in (data.get("candidate_stage_output_artifacts") or [])
                for artifact in [ProducedArtifactPayload.from_dict(item)]
                if artifact is not None
            ],
            accepted_workflow_accumulation_artifact_ref=ArtifactReferencePayload.from_dict(
                data.get("accepted_workflow_accumulation_artifact_ref")
            ),
            candidate_workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                data.get("candidate_workflow_accumulation_artifact")
            ),
            payload=(
                data.get("payload", {}) if isinstance(data.get("payload"), dict) else {}
            ),
            history=(
                data.get("history", []) if isinstance(data.get("history"), list) else []
            ),
            loop_state=(
                data.get("loop_state", {})
                if isinstance(data.get("loop_state"), dict)
                else {}
            ),
            loop_verdict=str(data.get("loop_verdict", "") or ""),
            pending_manual=PendingManualPayload.from_dict(data.get("pending_manual")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            workflow_lifecycle=_coerce_lifecycle_payload(
                data.get("workflow_lifecycle")
            ),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
            working_directory=str(data.get("working_directory", "") or ""),
            timeout_s=int(data.get("timeout_s", 600) or 600),
            runtime_metadata=(
                data.get("runtime_metadata", {})
                if isinstance(data.get("runtime_metadata"), dict)
                else {}
            ),
            runner_config=(
                data.get("runner_config", {})
                if isinstance(data.get("runner_config"), dict)
                else {}
            ),
        )


@dataclass
class PipelineStageRequest:
    """Request to run a custom pipeline stage."""

    stage_name: str
    trigger: str
    input_type: str
    runner_id: str = ""
    runner_version: str = ""
    runner_selector: str = ""
    runner_kind: str = "extension_runner"
    runner_diagnostic: "RunnerDiagnosticPayload | None" = None
    stage_execution_id: str = ""
    runner_position: int = 0
    runner_count: int = 1
    context: StageRunnerContext = field(default_factory=StageRunnerContext)
    timeout_s: int = 600
    workflow_artifact_refs: list[ArtifactReferencePayload] = field(default_factory=list)
    execution_input_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    stage_asset_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    resolved_stage_asset_bindings: list[ResolvedStageAssetBindingPayload] = field(
        default_factory=list
    )
    prior_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(
        default_factory=list
    )
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    content: dict[str, Any] = field(default_factory=dict)
    iteration: int = 0
    max_iterations: int = 3

    def __post_init__(self) -> None:
        """Hydrate canonical request fields from whichever shape was provided."""
        if isinstance(self.context, dict):
            self.context = StageRunnerContext.from_dict(self.context)
        if isinstance(self.runner_diagnostic, dict):
            self.runner_diagnostic = RunnerDiagnosticPayload.from_dict(
                self.runner_diagnostic
            )
        self.workflow_artifact_refs = _parse_artifact_refs(self.workflow_artifact_refs)
        self.execution_input_artifact_refs = _parse_artifact_refs(
            self.execution_input_artifact_refs
        )
        self.stage_asset_artifact_refs = _parse_artifact_refs(
            self.stage_asset_artifact_refs
        )
        self.resolved_stage_asset_bindings = _parse_resolved_stage_asset_bindings(
            self.resolved_stage_asset_bindings
        )
        self.prior_stage_output_artifact_refs = _parse_artifact_refs(
            self.prior_stage_output_artifact_refs
        )
        self.accepted_stage_output_artifact_refs = _parse_artifact_refs(
            self.accepted_stage_output_artifact_refs
        )
        self.candidate_stage_output_artifacts = _parse_produced_artifacts(
            normalize_stage_output_artifacts(self.candidate_stage_output_artifacts)
        )
        if isinstance(self.accepted_workflow_accumulation_artifact_ref, dict):
            self.accepted_workflow_accumulation_artifact_ref = (
                ArtifactReferencePayload.from_dict(
                    self.accepted_workflow_accumulation_artifact_ref
                )
            )
        if isinstance(self.candidate_workflow_accumulation_artifact, dict):
            self.candidate_workflow_accumulation_artifact = (
                ProducedArtifactPayload.from_dict(
                    normalize_workflow_accumulation_artifact(
                        self.candidate_workflow_accumulation_artifact
                    )
                )
            )
        if isinstance(self.pending_manual, dict):
            self.pending_manual = PendingManualPayload.from_dict(self.pending_manual)
        if isinstance(self.resume, dict):
            self.resume = LoopResumePayload.from_dict(self.resume)
        content_payload = self.content if isinstance(self.content, dict) else {}
        context_payload = (
            self.context.payload if isinstance(self.context.payload, dict) else {}
        )
        stage_output_payloads: list[ProducedArtifactPayload] | list[dict[str, Any]] = (
            self.stage_output_artifacts
        )
        if not stage_output_payloads and isinstance(
            content_payload.get("stage_output_artifacts"), list
        ):
            stage_output_payloads = content_payload.get("stage_output_artifacts", [])
        if not stage_output_payloads and isinstance(
            context_payload.get("stage_output_artifacts"), list
        ):
            stage_output_payloads = context_payload.get("stage_output_artifacts", [])
        workflow_accumulation_payload: (
            ProducedArtifactPayload | dict[str, Any] | None
        ) = self.workflow_accumulation_artifact
        if workflow_accumulation_payload is None and isinstance(
            content_payload.get("workflow_accumulation_artifact"), dict
        ):
            workflow_accumulation_payload = content_payload.get(
                "workflow_accumulation_artifact"
            )
        if workflow_accumulation_payload is None and isinstance(
            context_payload.get("workflow_accumulation_artifact"), dict
        ):
            workflow_accumulation_payload = context_payload.get(
                "workflow_accumulation_artifact"
            )

        issues = collect_artifact_contract_issues(
            payload=content_payload,
            stage_output_artifacts=stage_output_payloads,
            candidate_stage_output_artifacts=self.candidate_stage_output_artifacts,
            accepted_stage_output_artifact_refs=self.accepted_stage_output_artifact_refs,
            workflow_accumulation_artifact=workflow_accumulation_payload,
            candidate_workflow_accumulation_artifact=(
                self.candidate_workflow_accumulation_artifact
            ),
            accepted_workflow_accumulation_artifact_ref=(
                self.accepted_workflow_accumulation_artifact_ref
            ),
        )
        issues.extend(
            collect_artifact_contract_issues(
                payload=context_payload,
                stage_output_artifacts=(
                    context_payload.get("stage_output_artifacts", [])
                    if isinstance(context_payload.get("stage_output_artifacts"), list)
                    else None
                ),
                candidate_stage_output_artifacts=(
                    context_payload.get("candidate_stage_output_artifacts", [])
                    if isinstance(
                        context_payload.get("candidate_stage_output_artifacts"), list
                    )
                    else None
                ),
                accepted_stage_output_artifact_refs=(
                    context_payload.get("accepted_stage_output_artifact_refs", [])
                    if isinstance(
                        context_payload.get("accepted_stage_output_artifact_refs"), list
                    )
                    else None
                ),
                workflow_accumulation_artifact=context_payload.get(
                    "workflow_accumulation_artifact"
                ),
                candidate_workflow_accumulation_artifact=context_payload.get(
                    "candidate_workflow_accumulation_artifact"
                ),
                accepted_workflow_accumulation_artifact_ref=context_payload.get(
                    "accepted_workflow_accumulation_artifact_ref"
                ),
            )
        )
        _raise_artifact_contract_issues(issues)

        self.stage_output_artifacts = _parse_produced_artifacts(
            normalize_stage_output_artifacts(stage_output_payloads)
        )
        if workflow_accumulation_payload is not None:
            self.workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
                normalize_workflow_accumulation_artifact(workflow_accumulation_payload)
            )
        else:
            self.workflow_accumulation_artifact = None

        if not self.stage_execution_id:
            runner_fragment = self.runner_id or "runner"
            self.stage_execution_id = (
                f"{self.stage_name}:{runner_fragment}:{self.runner_position}"
            )

        if not self.content and self.context.payload:
            self.content = dict(self.context.payload)

        if not self.context.stage_name:
            self.context.stage_name = self.stage_name
        if not self.context.stage_execution_id:
            self.context.stage_execution_id = self.stage_execution_id
        if not self.context.trigger:
            self.context.trigger = self.trigger
        if not self.context.input_type:
            self.context.input_type = self.input_type
        if not self.context.payload and self.content:
            self.context.payload = dict(self.content)
        if not self.context.timeout_s:
            self.context.timeout_s = self.timeout_s
        if not self.workflow_artifact_refs and self.context.workflow_artifact_refs:
            self.workflow_artifact_refs = list(self.context.workflow_artifact_refs)
        if (
            not self.execution_input_artifact_refs
            and self.context.execution_input_artifact_refs
        ):
            self.execution_input_artifact_refs = list(
                self.context.execution_input_artifact_refs
            )
        if (
            not self.stage_asset_artifact_refs
            and self.context.stage_asset_artifact_refs
        ):
            self.stage_asset_artifact_refs = list(
                self.context.stage_asset_artifact_refs
            )
        if (
            not self.resolved_stage_asset_bindings
            and self.context.resolved_stage_asset_bindings
        ):
            self.resolved_stage_asset_bindings = list(
                self.context.resolved_stage_asset_bindings
            )
        if (
            not self.prior_stage_output_artifact_refs
            and self.context.prior_stage_output_artifact_refs
        ):
            self.prior_stage_output_artifact_refs = list(
                self.context.prior_stage_output_artifact_refs
            )
        if (
            not self.accepted_stage_output_artifact_refs
            and self.context.accepted_stage_output_artifact_refs
        ):
            self.accepted_stage_output_artifact_refs = list(
                self.context.accepted_stage_output_artifact_refs
            )
        if (
            not self.candidate_stage_output_artifacts
            and self.context.candidate_stage_output_artifacts
        ):
            self.candidate_stage_output_artifacts = list(
                self.context.candidate_stage_output_artifacts
            )
        if (
            self.accepted_workflow_accumulation_artifact_ref is None
            and self.context.accepted_workflow_accumulation_artifact_ref is not None
        ):
            self.accepted_workflow_accumulation_artifact_ref = (
                self.context.accepted_workflow_accumulation_artifact_ref
            )
        if (
            self.candidate_workflow_accumulation_artifact is None
            and self.context.candidate_workflow_accumulation_artifact is not None
        ):
            self.candidate_workflow_accumulation_artifact = (
                self.context.candidate_workflow_accumulation_artifact
            )
        if not self.context.workflow_artifact_refs and self.workflow_artifact_refs:
            self.context.workflow_artifact_refs = list(self.workflow_artifact_refs)
        if (
            not self.context.execution_input_artifact_refs
            and self.execution_input_artifact_refs
        ):
            self.context.execution_input_artifact_refs = list(
                self.execution_input_artifact_refs
            )
        if (
            not self.context.stage_asset_artifact_refs
            and self.stage_asset_artifact_refs
        ):
            self.context.stage_asset_artifact_refs = list(
                self.stage_asset_artifact_refs
            )
        if (
            not self.context.resolved_stage_asset_bindings
            and self.resolved_stage_asset_bindings
        ):
            self.context.resolved_stage_asset_bindings = list(
                self.resolved_stage_asset_bindings
            )
        if (
            not self.context.prior_stage_output_artifact_refs
            and self.prior_stage_output_artifact_refs
        ):
            self.context.prior_stage_output_artifact_refs = list(
                self.prior_stage_output_artifact_refs
            )
        if (
            not self.context.accepted_stage_output_artifact_refs
            and self.accepted_stage_output_artifact_refs
        ):
            self.context.accepted_stage_output_artifact_refs = list(
                self.accepted_stage_output_artifact_refs
            )
        if (
            not self.context.candidate_stage_output_artifacts
            and self.candidate_stage_output_artifacts
        ):
            self.context.candidate_stage_output_artifacts = list(
                self.candidate_stage_output_artifacts
            )
        if (
            self.context.accepted_workflow_accumulation_artifact_ref is None
            and self.accepted_workflow_accumulation_artifact_ref is not None
        ):
            self.context.accepted_workflow_accumulation_artifact_ref = (
                self.accepted_workflow_accumulation_artifact_ref
            )
        if (
            self.context.candidate_workflow_accumulation_artifact is None
            and self.candidate_workflow_accumulation_artifact is not None
        ):
            self.context.candidate_workflow_accumulation_artifact = (
                self.candidate_workflow_accumulation_artifact
            )

        if isinstance(self.content, dict):
            if (
                self.stage_output_artifacts
                and "stage_output_artifacts" not in self.content
            ):
                self.content["stage_output_artifacts"] = [
                    artifact.to_dict() for artifact in self.stage_output_artifacts
                ]
            if (
                self.workflow_accumulation_artifact is not None
                and "workflow_accumulation_artifact" not in self.content
            ):
                self.content["workflow_accumulation_artifact"] = (
                    self.workflow_accumulation_artifact.to_dict()
                )
        if isinstance(self.context.payload, dict):
            if (
                self.stage_output_artifacts
                and "stage_output_artifacts" not in self.context.payload
            ):
                self.context.payload["stage_output_artifacts"] = [
                    artifact.to_dict() for artifact in self.stage_output_artifacts
                ]
            if (
                self.workflow_accumulation_artifact is not None
                and "workflow_accumulation_artifact" not in self.context.payload
            ):
                self.context.payload["workflow_accumulation_artifact"] = (
                    self.workflow_accumulation_artifact.to_dict()
                )

        loop_state = (
            self.context.loop_state if isinstance(self.context.loop_state, dict) else {}
        )
        if not self.iteration and "current_iteration" in loop_state:
            self.iteration = int(loop_state.get("current_iteration", 0) or 0)
        if (
            self.max_iterations == 3
            and "max_iterations" in loop_state
            and loop_state.get("max_iterations") is not None
        ):
            self.max_iterations = int(loop_state.get("max_iterations", 3) or 3)

        if not loop_state:
            self.context.loop_state = {
                "current_iteration": self.iteration,
                "max_iterations": self.max_iterations,
            }
        else:
            self.context.loop_state.setdefault("current_iteration", self.iteration)
            self.context.loop_state.setdefault("max_iterations", self.max_iterations)
        if self.loop_state:
            self.context.loop_state["state"] = self.loop_state
        if self.loop_verdict and not self.context.loop_verdict:
            self.context.loop_verdict = self.loop_verdict
        if self.pending_manual is not None and self.context.pending_manual is None:
            self.context.pending_manual = self.pending_manual
        if self.resume is not None and self.context.resume is None:
            self.context.resume = self.resume

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "PipelineStageRequest":
        """Create from ServerAction payload."""
        context = StageRunnerContext.from_dict(payload.get("context"))
        loop_state = context.loop_state if isinstance(context.loop_state, dict) else {}
        runner_id = str(payload.get("runner_id") or "")
        runner_position = int(payload.get("runner_position", 0) or 0)
        stage_name = str(payload.get("stage_name") or context.stage_name or "")
        stage_execution_id = str(
            payload.get("stage_execution_id")
            or context.stage_execution_id
            or (
                f"{stage_name}:{runner_id or 'runner'}:{runner_position}"
                if stage_name
                else ""
            )
        )
        return cls(
            stage_name=stage_name,
            trigger=str(payload.get("trigger") or context.trigger or ""),
            input_type=str(payload.get("input_type") or context.input_type or ""),
            runner_id=runner_id,
            runner_version=str(payload.get("runner_version", "") or ""),
            runner_selector=str(payload.get("runner_selector", "") or ""),
            runner_kind=str(payload.get("runner_kind") or "extension_runner"),
            runner_diagnostic=RunnerDiagnosticPayload.from_dict(
                payload.get("runner_diagnostic")
            ),
            stage_execution_id=stage_execution_id,
            runner_position=runner_position,
            runner_count=int(payload.get("runner_count", 1) or 1),
            context=context,
            timeout_s=int(payload.get("timeout_s") or context.timeout_s or 600),
            workflow_artifact_refs=[
                artifact_ref
                for item in (payload.get("workflow_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            execution_input_artifact_refs=[
                artifact_ref
                for item in (payload.get("execution_input_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            stage_asset_artifact_refs=[
                artifact_ref
                for item in (payload.get("stage_asset_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            resolved_stage_asset_bindings=[
                binding
                for item in (payload.get("resolved_stage_asset_bindings") or [])
                for binding in [ResolvedStageAssetBindingPayload.from_dict(item)]
                if binding is not None
            ],
            prior_stage_output_artifact_refs=[
                artifact_ref
                for item in (payload.get("prior_stage_output_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            accepted_stage_output_artifact_refs=[
                artifact_ref
                for item in (payload.get("accepted_stage_output_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            candidate_stage_output_artifacts=[
                artifact
                for item in (payload.get("candidate_stage_output_artifacts") or [])
                for artifact in [ProducedArtifactPayload.from_dict(item)]
                if artifact is not None
            ],
            accepted_workflow_accumulation_artifact_ref=ArtifactReferencePayload.from_dict(
                payload.get("accepted_workflow_accumulation_artifact_ref")
            ),
            candidate_workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                payload.get("candidate_workflow_accumulation_artifact")
            ),
            loop_verdict=str(payload.get("loop_verdict") or ""),
            loop_state=str(payload.get("loop_state") or ""),
            pending_manual=PendingManualPayload.from_dict(
                payload.get("pending_manual")
            ),
            resume=LoopResumePayload.from_dict(payload.get("resume")),
            stage_output_artifacts=[
                artifact
                for item in (payload.get("stage_output_artifacts") or [])
                for artifact in [ProducedArtifactPayload.from_dict(item)]
                if artifact is not None
            ],
            workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                payload.get("workflow_accumulation_artifact")
            ),
            content=(
                payload.get("content", {})
                if isinstance(payload.get("content"), dict)
                else dict(context.payload)
            ),
            iteration=int(
                payload.get("iteration")
                if payload.get("iteration") is not None
                else loop_state.get("current_iteration", 0)
            ),
            max_iterations=int(
                payload.get("max_iterations")
                if payload.get("max_iterations") is not None
                else loop_state.get("max_iterations", 3)
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "trigger": self.trigger,
            "runner_id": self.runner_id,
            "runner_version": self.runner_version,
            "runner_selector": self.runner_selector,
            "runner_kind": self.runner_kind,
            "runner_diagnostic": (
                self.runner_diagnostic.to_dict()
                if self.runner_diagnostic is not None
                else None
            ),
            "stage_execution_id": self.stage_execution_id,
            "runner_position": self.runner_position,
            "runner_count": self.runner_count,
            "context": self.context.to_dict(),
            "timeout_s": self.timeout_s,
            "workflow_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.workflow_artifact_refs
            ],
            "execution_input_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.execution_input_artifact_refs
            ],
            "stage_asset_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.stage_asset_artifact_refs
            ],
            "resolved_stage_asset_bindings": [
                binding.to_dict() for binding in self.resolved_stage_asset_bindings
            ],
            "prior_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.prior_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict()
                if self.pending_manual is not None
                else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "stage_output_artifacts": [
                artifact.to_dict() for artifact in self.stage_output_artifacts
            ],
            "workflow_accumulation_artifact": (
                self.workflow_accumulation_artifact.to_dict()
                if self.workflow_accumulation_artifact is not None
                else None
            ),
            "input_type": self.input_type,
            "content": self.content,
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
        }


@dataclass
class RunnerDiagnosticPayload:
    """Structured runner resolution or installability diagnostic."""

    code: str
    message: str
    runner_id: str = ""
    requested_selector: str = ""
    requested_version: str = ""
    source_layer: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "RunnerDiagnosticPayload | None":
        """Create from dictionary payload."""
        if not isinstance(data, dict):
            return None
        return cls(
            code=str(data.get("code", "") or ""),
            message=str(data.get("message", "") or ""),
            runner_id=str(data.get("runner_id", "") or ""),
            requested_selector=str(data.get("requested_selector", "") or ""),
            requested_version=str(data.get("requested_version", "") or ""),
            source_layer=str(data.get("source_layer", "") or ""),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary payload."""
        return {
            "code": self.code,
            "message": self.message,
            "runner_id": self.runner_id,
            "requested_selector": self.requested_selector,
            "requested_version": self.requested_version,
            "source_layer": self.source_layer,
        }


@dataclass
class PipelineStageResult:
    """Result from a custom pipeline stage execution."""

    stage_name: str
    stage_execution_id: str = ""
    execution_status: str = "complete"
    outcome: str = "passed"
    findings: list[dict[str, Any]] = field(default_factory=list)
    stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(
        default_factory=list
    )
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    routing_signal: StageRoutingSignal | None = None
    loop_signal: StageLoopSignal | None = None
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    runner_id: str = ""
    runner_version: str = ""
    runner_selector: str = ""
    runner_diagnostic: "RunnerDiagnosticPayload | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)
    verdict: str = "sound"
    issues: list[dict[str, Any]] = field(default_factory=list)
    iteration: int = 0
    duration_s: float = 0.0

    def __post_init__(self) -> None:
        """Hydrate canonical result fields while preserving diagnostic signals."""
        if isinstance(self.routing_signal, dict):
            self.routing_signal = StageRoutingSignal.from_dict(self.routing_signal)
        if isinstance(self.loop_signal, dict):
            self.loop_signal = StageLoopSignal.from_dict(self.loop_signal)
        if isinstance(self.pending_manual, dict):
            self.pending_manual = PendingManualPayload.from_dict(self.pending_manual)
        if isinstance(self.resume, dict):
            self.resume = LoopResumePayload.from_dict(self.resume)
        self.workflow_lifecycle = _coerce_lifecycle_payload(self.workflow_lifecycle)
        self.lifecycle_decisions = _coerce_optional_dict(self.lifecycle_decisions)
        self.legacy_phase_normalization = _coerce_optional_dict(
            self.legacy_phase_normalization
        )
        if isinstance(self.runner_diagnostic, dict):
            self.runner_diagnostic = RunnerDiagnosticPayload.from_dict(
                self.runner_diagnostic
            )
        issues = collect_artifact_contract_issues(
            stage_output_artifacts=self.stage_output_artifacts,
            candidate_stage_output_artifacts=self.candidate_stage_output_artifacts,
            accepted_stage_output_artifact_refs=self.accepted_stage_output_artifact_refs,
            workflow_accumulation_artifact=self.workflow_accumulation_artifact,
            candidate_workflow_accumulation_artifact=(
                self.candidate_workflow_accumulation_artifact
            ),
            accepted_workflow_accumulation_artifact_ref=(
                self.accepted_workflow_accumulation_artifact_ref
            ),
        )
        if isinstance(self.metadata, dict) and (
            self.metadata.get("produced_outputs")
            or self.metadata.get("files_changed")
            or self.metadata.get("file_targets")
        ):
            issues.extend(collect_artifact_contract_issues(payload=self.metadata))
        _raise_artifact_contract_issues(issues)
        self.candidate_stage_output_artifacts = _parse_produced_artifacts(
            normalize_stage_output_artifacts(self.candidate_stage_output_artifacts)
        )
        self.accepted_stage_output_artifact_refs = _parse_artifact_refs(
            self.accepted_stage_output_artifact_refs
        )
        if isinstance(self.candidate_workflow_accumulation_artifact, dict):
            self.candidate_workflow_accumulation_artifact = (
                ProducedArtifactPayload.from_dict(
                    normalize_workflow_accumulation_artifact(
                        self.candidate_workflow_accumulation_artifact
                    )
                )
            )
        if isinstance(self.accepted_workflow_accumulation_artifact_ref, dict):
            self.accepted_workflow_accumulation_artifact_ref = (
                ArtifactReferencePayload.from_dict(
                    self.accepted_workflow_accumulation_artifact_ref
                )
            )
        self.stage_output_artifacts = _parse_produced_artifacts(
            normalize_stage_output_artifacts(self.stage_output_artifacts)
        )
        if isinstance(self.workflow_accumulation_artifact, dict):
            self.workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
                normalize_workflow_accumulation_artifact(
                    self.workflow_accumulation_artifact
                )
            )
        if not self.runner_id and isinstance(self.metadata, dict):
            self.runner_id = str(self.metadata.get("runner_id", "") or "")
        if not self.runner_version and isinstance(self.metadata, dict):
            self.runner_version = str(self.metadata.get("runner_version", "") or "")
        if not self.runner_selector and isinstance(self.metadata, dict):
            self.runner_selector = str(self.metadata.get("runner_selector", "") or "")
        if self.runner_diagnostic is None and isinstance(self.metadata, dict):
            self.runner_diagnostic = RunnerDiagnosticPayload.from_dict(
                self.metadata.get("runner_diagnostic")
            )
        if not self.findings and self.issues:
            self.findings = list(self.issues)
        if not self.issues and self.findings:
            self.issues = list(self.findings)

        if not self.duration_s and isinstance(self.metadata, dict):
            duration_value = self.metadata.get("duration_s")
            if duration_value is not None:
                self.duration_s = float(duration_value)

        if not self.verdict:
            self.verdict = (
                "sound" if self.outcome == "passed" and not self.issues else "issues"
            )
        if not self.outcome:
            self.outcome = "passed" if self.verdict == "sound" else "issues_found"
        if not self.execution_status:
            self.execution_status = "complete"
        if self.verdict == "sound" and (self.issues or self.findings):
            self.verdict = "issues"
        if self.verdict != "sound" and self.outcome == "passed":
            self.outcome = "issues_found"
        if isinstance(self.metadata, dict):
            if self.runner_id and "runner_id" not in self.metadata:
                self.metadata["runner_id"] = self.runner_id
            if self.runner_version and "runner_version" not in self.metadata:
                self.metadata["runner_version"] = self.runner_version
            if self.runner_selector and "runner_selector" not in self.metadata:
                self.metadata["runner_selector"] = self.runner_selector
            if (
                self.runner_diagnostic is not None
                and "runner_diagnostic" not in self.metadata
            ):
                self.metadata["runner_diagnostic"] = self.runner_diagnostic.to_dict()
            if self.loop_verdict and "loop_verdict" not in self.metadata:
                self.metadata["loop_verdict"] = self.loop_verdict
            if self.loop_state and "loop_state" not in self.metadata:
                self.metadata["loop_state"] = self.loop_state

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "stage_execution_id": self.stage_execution_id,
            "execution_status": self.execution_status,
            "outcome": self.outcome,
            "findings": self.findings,
            "stage_output_artifacts": [
                artifact.to_dict() for artifact in self.stage_output_artifacts
            ],
            "workflow_accumulation_artifact": (
                self.workflow_accumulation_artifact.to_dict()
                if self.workflow_accumulation_artifact is not None
                else None
            ),
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "routing_signal": (
                self.routing_signal.to_dict() if self.routing_signal else None
            ),
            "loop_signal": self.loop_signal.to_dict() if self.loop_signal else None,
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict()
                if self.pending_manual is not None
                else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
            "runner_id": self.runner_id,
            "runner_version": self.runner_version,
            "runner_selector": self.runner_selector,
            "runner_diagnostic": (
                self.runner_diagnostic.to_dict()
                if self.runner_diagnostic is not None
                else None
            ),
            "metadata": self.metadata,
            "verdict": self.verdict,
            "issues": self.issues,
            "iteration": self.iteration,
            "duration_s": self.duration_s,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PipelineStageResult":
        """Create from dictionary."""
        _raise_artifact_contract_issues(
            collect_artifact_contract_issues(
                payload=data,
                stage_output_artifacts=(
                    data.get("stage_output_artifacts", [])
                    if isinstance(data.get("stage_output_artifacts"), list)
                    else None
                ),
                candidate_stage_output_artifacts=(
                    data.get("candidate_stage_output_artifacts", [])
                    if isinstance(data.get("candidate_stage_output_artifacts"), list)
                    else None
                ),
                accepted_stage_output_artifact_refs=(
                    data.get("accepted_stage_output_artifact_refs", [])
                    if isinstance(data.get("accepted_stage_output_artifact_refs"), list)
                    else None
                ),
                workflow_accumulation_artifact=data.get(
                    "workflow_accumulation_artifact"
                ),
                candidate_workflow_accumulation_artifact=data.get(
                    "candidate_workflow_accumulation_artifact"
                ),
                accepted_workflow_accumulation_artifact_ref=data.get(
                    "accepted_workflow_accumulation_artifact_ref"
                ),
            )
        )
        return cls(
            stage_name=str(data.get("stage_name", "") or ""),
            stage_execution_id=str(data.get("stage_execution_id", "") or ""),
            execution_status=str(data.get("execution_status") or "complete"),
            outcome=str(
                data.get("outcome")
                or (
                    "passed"
                    if data.get("verdict", "sound") == "sound"
                    else "issues_found"
                )
            ),
            findings=(
                data.get("findings", [])
                if isinstance(data.get("findings"), list)
                else []
            ),
            stage_output_artifacts=[
                artifact
                for item in (data.get("stage_output_artifacts") or [])
                for artifact in [ProducedArtifactPayload.from_dict(item)]
                if artifact is not None
            ],
            workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                data.get("workflow_accumulation_artifact")
            ),
            candidate_stage_output_artifacts=[
                artifact
                for item in (data.get("candidate_stage_output_artifacts") or [])
                for artifact in [ProducedArtifactPayload.from_dict(item)]
                if artifact is not None
            ],
            accepted_stage_output_artifact_refs=[
                artifact_ref
                for item in (data.get("accepted_stage_output_artifact_refs") or [])
                for artifact_ref in [ArtifactReferencePayload.from_dict(item)]
                if artifact_ref is not None
            ],
            candidate_workflow_accumulation_artifact=ProducedArtifactPayload.from_dict(
                data.get("candidate_workflow_accumulation_artifact")
            ),
            accepted_workflow_accumulation_artifact_ref=ArtifactReferencePayload.from_dict(
                data.get("accepted_workflow_accumulation_artifact_ref")
            ),
            routing_signal=StageRoutingSignal.from_dict(data.get("routing_signal")),
            loop_signal=StageLoopSignal.from_dict(data.get("loop_signal")),
            loop_verdict=str(data.get("loop_verdict") or ""),
            loop_state=str(data.get("loop_state") or ""),
            pending_manual=PendingManualPayload.from_dict(data.get("pending_manual")),
            resume=LoopResumePayload.from_dict(data.get("resume")),
            workflow_lifecycle=_coerce_lifecycle_payload(
                data.get("workflow_lifecycle")
            ),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
            runner_id=str(data.get("runner_id", "") or ""),
            runner_version=str(data.get("runner_version", "") or ""),
            runner_selector=str(data.get("runner_selector", "") or ""),
            runner_diagnostic=RunnerDiagnosticPayload.from_dict(
                data.get("runner_diagnostic")
            ),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
            verdict=str(data.get("verdict", "sound") or "sound"),
            issues=data.get("issues", [])
            if isinstance(data.get("issues"), list)
            else [],
            iteration=int(data.get("iteration", 0) or 0),
            duration_s=float(data.get("duration_s", 0.0) or 0.0),
        )


def _parse_artifact_refs(
    refs: list[ArtifactReferencePayload] | list[dict[str, Any]] | None,
) -> list[ArtifactReferencePayload]:
    """Normalize artifact reference payloads from dicts or dataclasses."""
    normalized: list[ArtifactReferencePayload] = []
    for item in refs or []:
        if isinstance(item, ArtifactReferencePayload):
            normalized.append(item)
        elif isinstance(item, dict):
            artifact_ref = ArtifactReferencePayload.from_dict(item)
            if artifact_ref is not None:
                normalized.append(artifact_ref)
    return normalized


def _parse_resolved_stage_asset_bindings(
    bindings: list[ResolvedStageAssetBindingPayload] | list[dict[str, Any]] | None,
) -> list[ResolvedStageAssetBindingPayload]:
    """Normalize resolved stage bindings from dict or dataclass form."""
    normalized: list[ResolvedStageAssetBindingPayload] = []
    for item in bindings or []:
        if isinstance(item, ResolvedStageAssetBindingPayload):
            normalized.append(item)
            continue
        if isinstance(item, dict):
            binding = ResolvedStageAssetBindingPayload.from_dict(item)
            if binding is not None:
                normalized.append(binding)
    return normalized


def _parse_produced_artifacts(
    artifacts: list[ProducedArtifactPayload] | list[dict[str, Any]] | None,
) -> list[ProducedArtifactPayload]:
    """Normalize produced artifact payloads from dicts or dataclasses."""
    normalized: list[ProducedArtifactPayload] = []
    for item in artifacts or []:
        if isinstance(item, ProducedArtifactPayload):
            normalized.append(item)
        elif isinstance(item, dict):
            artifact = ProducedArtifactPayload.from_dict(item)
            if artifact is not None:
                normalized.append(artifact)
    return normalized


def _raise_artifact_contract_issues(issues: list[dict[str, Any]]) -> None:
    """Raise a deterministic validation error for typed artifact contract issues."""
    if not issues:
        return
    first_issue = issues[0]
    field_name = str(first_issue.get("field") or "artifact_contract")
    message = str(first_issue.get("message") or "Invalid stage artifact payload.")
    raise ValueError(f"{field_name}: {message}")


@dataclass
class EscalationNotice:
    """Notice that session requires human intervention.

    Sent by server when max iterations reached or oscillation detected.

    Attributes:
        escalation_id: Unique escalation identifier
        reason: Reason for escalation
        reason_text: Human-readable escalation detail
        reason_code: Machine-readable escalation detail code
        invariant_errors: Structured invariant/integrity errors
        repair_attempt_history: Auto-repair attempt diagnostics
        blocking_issues: Issues causing escalation
        escalation_context: Structured phase-specific blocker context
        iteration_history: Summary of iterations
        options: Available user options
        convergence_diagnostic: Optional convergence guard context for user display
        metadata: ServerAction metadata attached to the escalation action
        extra: Escalation payload fields outside the canonical schema
    """

    escalation_id: str
    reason: EscalationReason
    reason_text: str = ""
    reason_code: str = ""
    invariant_errors: list[str] = field(default_factory=list)
    repair_attempt_history: list[dict[str, Any]] = field(default_factory=list)
    blocking_issues: list[dict[str, Any]] = field(default_factory=list)
    escalation_context: dict[str, Any] = field(default_factory=dict)
    iteration_history: list[dict[str, Any]] = field(default_factory=list)
    options: list[dict[str, Any]] = field(default_factory=list)
    convergence_diagnostic: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(
        cls,
        payload: dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> "EscalationNotice":
        """Create from ServerAction payload.

        Uses safe enum parsing for forward compatibility - unknown escalation
        reasons from newer servers will be mapped to EscalationReason.UNKNOWN.
        """
        raw_convergence_diagnostic = payload.get("convergence_diagnostic", {})
        raw_escalation_context = payload.get("escalation_context", {})
        raw_invariant_errors = payload.get("invariant_errors", [])
        raw_repair_attempt_history = payload.get("repair_attempt_history", [])
        escalation_context: dict[str, Any] = {}
        if isinstance(raw_escalation_context, dict):
            escalation_context.update(raw_escalation_context)
        # Backward compatibility: older payloads may attach blocker context at top-level.
        for legacy_key in (
            "blocking_failures",
            "non_blocking_failures",
            "completed_prereqs",
            "failed_prereqs",
            "status",
        ):
            if legacy_key not in escalation_context and legacy_key in payload:
                escalation_context[legacy_key] = payload.get(legacy_key)
        known_keys = {
            "escalation_id",
            "reason",
            "reason_text",
            "reason_code",
            "invariant_errors",
            "repair_attempt_history",
            "blocking_issues",
            "escalation_context",
            "iteration_history",
            "options",
            "convergence_diagnostic",
            "blocking_failures",
            "non_blocking_failures",
            "completed_prereqs",
            "failed_prereqs",
            "status",
        }
        extra_payload = {
            key: value for key, value in payload.items() if key not in known_keys
        }
        return cls(
            escalation_id=payload.get("escalation_id", ""),
            reason=safe_enum_parse(
                EscalationReason,
                payload.get("reason"),
                EscalationReason.BLOCKED,
            ),
            reason_text=str(payload.get("reason_text", "") or ""),
            reason_code=str(payload.get("reason_code", "") or ""),
            invariant_errors=(
                raw_invariant_errors if isinstance(raw_invariant_errors, list) else []
            ),
            repair_attempt_history=(
                raw_repair_attempt_history
                if isinstance(raw_repair_attempt_history, list)
                else []
            ),
            blocking_issues=payload.get("blocking_issues", []),
            escalation_context=escalation_context,
            iteration_history=payload.get("iteration_history", []),
            options=payload.get("options", []),
            convergence_diagnostic=(
                raw_convergence_diagnostic
                if isinstance(raw_convergence_diagnostic, dict)
                else {}
            ),
            metadata=metadata if isinstance(metadata, dict) else {},
            extra=extra_payload,
        )


@dataclass
class CompletionNotice:
    """Notice that session has completed (success or escalation).

    Sent by server when all items executed/reviewed or session terminates.

    Attributes:
        session_summary: Summary of completed session
        items_completed: Number of items completed
        total_iterations: Total refinement iterations
        quality_score: Final quality score
        was_escalated: Whether session ended via escalation
        terminal_phase: Session phase when completion occurred
        plan_final: Final plan items (optional)
        objective: Original user objective
        work_summary: 2-3 bullet summary of work done
        duration_seconds: This invocation duration
        total_duration_seconds: Cumulative duration across invocations
        invocation_count: Number of run/resume calls
        files_created: List of files created
        files_modified: List of files modified
        git_branch: Current git branch
        git_commit_hash: Commit hash if committed
        termination_reason: Reason for non-success termination
        warnings: Any warnings to display
        epics_completed: Count of completed epics
        epics_total: Total epic count
        stories_completed: Count of completed stories
        stories_total: Total story count
        tasks_completed: Count of completed tasks
        tasks_total: Total task count

    Note:
        CompletionNotice is a distinct return type and does not carry an
        action field. Client code should handle it explicitly (e.g., via
        isinstance checks) rather than reading result.action.
    """

    session_summary: str = ""
    items_completed: int = 0
    total_iterations: int = 0
    quality_score: float = 0.0
    was_escalated: bool = False
    terminal_phase: str = ""
    plan_final: list[dict[str, Any]] = field(default_factory=list)
    # Enhanced closeout fields (FEAT-SESSION-CLOSEOUT-001)
    objective: str = ""
    work_summary: list[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    total_duration_seconds: float = 0.0
    invocation_count: int = 1
    files_created: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    git_branch: str = ""
    git_commit_hash: str = ""
    termination_reason: str = ""
    warnings: list[str] = field(default_factory=list)
    epics_completed: int = 0
    epics_total: int = 0
    stories_completed: int = 0
    stories_total: int = 0
    tasks_completed: int = 0
    tasks_total: int = 0

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "CompletionNotice":
        """Create from ServerAction payload."""
        summary = payload.get("session_summary", {})
        return cls(
            session_summary=summary.get("objective", ""),
            items_completed=summary.get("items_completed", 0),
            total_iterations=summary.get("total_iterations", 0),
            quality_score=summary.get("quality_score", 0.0),
            was_escalated=payload.get("was_escalated", False),
            terminal_phase=payload.get("terminal_phase", ""),
            plan_final=payload.get("plan_final", []),
            # Enhanced closeout fields
            objective=summary.get("objective", ""),
            work_summary=payload.get("work_summary", []),
            duration_seconds=payload.get("duration_seconds", 0.0),
            total_duration_seconds=payload.get("total_duration_seconds", 0.0),
            invocation_count=payload.get("invocation_count", 1),
            files_created=payload.get("files_created", []),
            files_modified=payload.get("files_modified", []),
            git_branch=payload.get("git_branch", ""),
            git_commit_hash=payload.get("git_commit_hash", ""),
            termination_reason=payload.get("termination_reason", ""),
            warnings=payload.get("warnings", []),
            epics_completed=payload.get("epics_completed", 0),
            epics_total=payload.get("epics_total", 0),
            stories_completed=payload.get("stories_completed", 0),
            stories_total=payload.get("stories_total", 0),
            tasks_completed=payload.get("tasks_completed", 0),
            tasks_total=payload.get("tasks_total", 0),
        )


__all__ = [
    # Utilities
    "safe_enum_parse",
    # Enums
    "ActionType",
    "SessionPhase",
    "SessionStatus",
    "Priority",
    "ExecutionStatus",
    "AgentType",
    "EscalationReason",
    "UserDecisionChoice",
    # Server -> Client
    "ServerAction",
    "EscalationEnvelope",
    "WorkflowLifecyclePayload",
    "LifecycleDecisionPayload",
    "LegacyPhaseNormalizationPayload",
    "DeriveRequest",
    "IntentRequest",
    "ExamineRequest",
    "RevisionRequest",
    "ExecutionRequest",
    "ReviewRequest",
    "FixRequest",
    "ValidatorRequest",
    "ValidatorResult",
    "EscalationFixerResult",
    "StageRoutingSignal",
    "StageLoopSignal",
    "LoopResumePayload",
    "PendingManualPayload",
    "WaitPayload",
    "StageRunnerContext",
    "PipelineStageRequest",
    "PipelineStageResult",
    "EscalationNotice",
    "CompletionNotice",
    # Client -> Server
    "PlanUploadRequest",
    "PlanUploadResponse",
    "SessionStart",
    "ResumeRequest",
    "DerivedPlan",
    "ExaminationReport",
    "RevisedPlan",
    "ExecutionResult",
    "AgentReport",
    "FixResult",
    "FixReport",
    "UserDecision",
    "EscalationDecision",
    "WorkflowCandidateEnvelope",
    "WorkflowMutationEvent",
    "WorkflowMutationResult",
    "WorkflowRevisionPayload",
    "WorkflowRevisionRef",
    "WorkflowSemanticView",
    # Resume
    "ResumeContext",
    # Progress (ISSUE-CLI-023)
    "ProgressEvent",
    # Validator schema validation
    "validate_validator_request",
    "validate_validator_result",
    "validate_escalation_fixer_result",
]
