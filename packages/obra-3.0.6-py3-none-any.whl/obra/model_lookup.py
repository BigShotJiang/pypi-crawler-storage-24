"""Model Lookup — Canonical Model Registry and Provider Access.

This module owns ``MODEL_REGISTRY``, the single source of truth for LLM
provider configurations, model definitions, and validation functions.

Sibling modules ``token_budgets`` and ``quality_tiers`` import
``MODEL_REGISTRY`` from here — dependency direction is always inward
toward this module.

Example:
    >>> from obra.model_lookup import validate_model, get_cli_args
    >>> result = validate_model("anthropic", "sonnet")
    >>> result.valid
    True
    >>> get_cli_args("anthropic", "opus")
    ['--model', 'opus']

Migration Note:
    Extracted from ``obra.model_registry`` as part of REFACTOR-SCHEMAS-P7-001.
    ``obra.model_registry`` re-exports every public symbol for backward
    compatibility.
"""

import sys
import warnings
from dataclasses import dataclass, field
from enum import Enum
from typing import Literal

# =============================================================================
# Quality Tier Type (needed by ModelInfo.quality_tier annotation)
# =============================================================================

QualityTier = Literal["fast", "medium", "high"]

# =============================================================================
# Reasoning Constants (needed by MODEL_REGISTRY data below)
# =============================================================================

# Normalized reasoning levels used across providers (canonical source — ADR-073)
REASONING_LEVELS = ("off", "low", "medium", "high", "extra high", "maximum")
REASONING_ROLE_TIER_KEYS = (
    "orchestrator.fast",
    "orchestrator.medium",
    "orchestrator.high",
    "implementation.fast",
    "implementation.medium",
    "implementation.high",
)

_MEDIUM_REASONING_BY_ROLE_TIER = {key: "medium" for key in REASONING_ROLE_TIER_KEYS}
_HIGH_REASONING_BY_ROLE_TIER = {key: "high" for key in REASONING_ROLE_TIER_KEYS}
_MEDIUM_WITH_HIGH_HIGH_TIER_REASONING_BY_ROLE_TIER = _MEDIUM_REASONING_BY_ROLE_TIER | {
    "orchestrator.high": "high",
    "implementation.high": "high",
}

# Schema version for breaking change detection
REGISTRY_VERSION = "1.0.0"


# =============================================================================
# Legacy Load Warning
# =============================================================================


def _warn_if_legacy_loaded() -> None:
    """Warn if deprecated obra_client.model_registry is also loaded.

    This helps detect mixed imports during migration from obra_client to obra.
    The warning is emitted once per session.
    """
    if "obra_client.model_registry" in sys.modules:
        from obra.messages import get_message

        warnings.warn(
            "Both 'obra.model_registry' and 'obra_client.model_registry' are loaded. "
            + get_message(
                "warning.deprecation.package",
                old="obra_client.model_registry",
                new="obra.model_registry",
            )
            + " Update imports from 'from obra_client.model_registry import ...' "
            "to 'from obra.model_registry import ...'.",
            DeprecationWarning,
            stacklevel=3,
        )


# Check for legacy module on import
_warn_if_legacy_loaded()


# =============================================================================
# Data Classes
# =============================================================================


class ModelStatus(Enum):
    """Status of a model in the registry.

    TESTED: Verified working via CLI testing
    DOCUMENTED: From official docs, not yet tested
    DEPRECATED: Known to be removed or failing
    RESTRICTED: Requires specific auth (e.g., API key only)
    """

    TESTED = "tested"
    DOCUMENTED = "documented"
    DEPRECATED = "deprecated"
    RESTRICTED = "restricted"


@dataclass
class ModelInfo:
    """Information about a specific model.

    Attributes:
        id: Model identifier to pass to CLI
        display_name: Human-readable name for UI
        status: Verification status
        resolves_to: Canonical model ID (for aliases)
        description: Brief description
        note: Additional context (e.g., "Requires API key")
        context_window: Total token limit (prompt + output + reserved) if known
        input_limit: Maximum prompt/input tokens supported (if different from total)
        output_limit: Maximum output tokens supported (if different from total)
        reserved_tokens: Tokens held back for system use (metadata, function calls)
        capabilities: Future feature flags (vision, tools, streaming)
        quality_tier: Explicit quality tier override for hybrid resolution.
            If set, this takes precedence over dimension-based resolution.
        reasoning_default_level: Optional model-specific default reasoning level.
        reasoning_role_tier_defaults: Optional role/tier-specific defaults.
            Keys: orchestrator.fast|medium|high and implementation.fast|medium|high.
        reasoning_supported_levels: Optional set of normalized reasoning levels
            supported by the model (defaults to provider-level support).
    """

    id: str
    display_name: str
    status: ModelStatus
    resolves_to: str | None = None
    description: str | None = None
    note: str | None = None
    context_window: int | None = None
    input_limit: int | None = None
    output_limit: int | None = None
    reserved_tokens: int | None = None
    capabilities: set[str] = field(default_factory=set)
    quality_tier: QualityTier | None = None  # Explicit override (hybrid approach)
    reasoning_default_level: str | None = None
    reasoning_role_tier_defaults: dict[str, str] | None = None
    reasoning_supported_levels: set[str] | None = None

    @property
    def is_usable(self) -> bool:
        """Whether this model can be used (not deprecated)."""
        return self.status != ModelStatus.DEPRECATED


@dataclass
class ProviderConfig:
    """Configuration for an LLM provider.

    Attributes:
        name: Provider company name (e.g., "Anthropic")
        cli: CLI/product name (e.g., "Claude")
        description: Short description for UI display
        flag: Model flag (e.g., "--model")
        default_model: Default model ID (None = auto-select)
        models: Available models
        invalid_patterns: Known invalid formats
        oauth_supported: Whether OAuth auth works
        api_key_env: Env var for API key auth
        default_reasoning_level: Default normalized reasoning level
        reasoning_level_map: Normalized -> provider-specific reasoning value
        reasoning_supported_levels: Optional set of supported reasoning levels
    """

    name: str
    cli: str
    description: str
    flag: str
    default_model: str | None
    models: dict[str, ModelInfo]
    invalid_patterns: set[str] = field(default_factory=set)
    oauth_supported: bool = True
    api_key_env: str | None = None
    default_reasoning_level: str = "medium"
    reasoning_level_map: dict[str, str | None] = field(default_factory=dict)
    reasoning_supported_levels: set[str] | None = None


@dataclass
class ValidationResult:
    """Result of model validation.

    Attributes:
        valid: Whether the model is valid for use
        model_id: The model identifier that was validated
        status: Model status from registry (if found)
        warning: Warning message (model works but has caveats)
        error: Error message (model will not work)
    """

    valid: bool
    model_id: str
    status: ModelStatus | None = None
    warning: str | None = None
    error: str | None = None


# =============================================================================
# Model Registry Data - February 2026
# =============================================================================

MODEL_REGISTRY: dict[str, ProviderConfig] = {
    "anthropic": ProviderConfig(
        name="Anthropic",
        cli="Claude",
        description="AI thinking partner for developers",
        flag="--model",
        default_model="opus",
        default_reasoning_level="high",
        reasoning_level_map={
            "off": None,
            "low": "low",
            "medium": "medium",
            "high": "high",
            "extra high": "high",
            "maximum": "high",
        },
        oauth_supported=True,
        api_key_env="ANTHROPIC_API_KEY",
        invalid_patterns={
            "sonnet-4",
            "Sonnet-4-5",
            "claude-sonnet-4",
            "claude-3-5-sonnet-*",  # Deprecated format
        },
        models={
            # Aliases (tested)
            "sonnet": ModelInfo(
                id="sonnet",
                display_name="Sonnet 4.6",
                status=ModelStatus.TESTED,
                resolves_to="claude-sonnet-4-6",
                description="Fast and capable",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "opus": ModelInfo(
                id="opus",
                display_name="Opus 4.6 (1M)",
                status=ModelStatus.TESTED,
                resolves_to="claude-opus-4-6",
                description="Most capable, 1M context default",
                context_window=1_000_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "haiku": ModelInfo(
                id="haiku",
                display_name="Haiku 4.5",
                status=ModelStatus.TESTED,
                resolves_to="claude-haiku-4-5-20251001",
                description="Fastest, lighter tasks",
                context_window=200_000,
                reasoning_supported_levels={"off", "low", "medium"},
            ),
            # Full model IDs (tested)
            "claude-sonnet-4-6": ModelInfo(
                id="claude-sonnet-4-6",
                display_name="Sonnet 4.6 (explicit)",
                status=ModelStatus.TESTED,
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-opus-4-6": ModelInfo(
                id="claude-opus-4-6",
                display_name="Opus 4.6 (1M context)",
                status=ModelStatus.TESTED,
                context_window=1_000_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-opus-4-6-200k": ModelInfo(
                id="claude-opus-4-6-200k",
                display_name="Opus 4.6 (200K context)",
                status=ModelStatus.TESTED,
                resolves_to="claude-opus-4-6",
                description="Opus 4.6 with 200K context window",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-haiku-4-5": ModelInfo(
                id="claude-haiku-4-5",
                display_name="Haiku 4.5 (explicit)",
                status=ModelStatus.TESTED,
                resolves_to="claude-haiku-4-5-20251001",
                context_window=200_000,
                reasoning_supported_levels={"off", "low", "medium"},
            ),
            # Legacy models (deprecated)
            "claude-sonnet-4-5": ModelInfo(
                id="claude-sonnet-4-5",
                display_name="Sonnet 4.5",
                status=ModelStatus.DEPRECATED,
                description="Previous generation - use 'sonnet' for 4.6",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-sonnet-4-5-20250929": ModelInfo(
                id="claude-sonnet-4-5-20250929",
                display_name="Sonnet 4.5",
                status=ModelStatus.DEPRECATED,
                description="Previous generation - use 'sonnet' for 4.6",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-opus-4-5": ModelInfo(
                id="claude-opus-4-5",
                display_name="Opus 4.5",
                status=ModelStatus.DEPRECATED,
                description="Previous generation - use 'opus' for 4.6",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-opus-4-5-20251101": ModelInfo(
                id="claude-opus-4-5-20251101",
                display_name="Opus 4.5",
                status=ModelStatus.DEPRECATED,
                description="Previous generation - use 'opus' for 4.6",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
            "claude-sonnet-4-20250514": ModelInfo(
                id="claude-sonnet-4-20250514",
                display_name="Sonnet 4.0",
                status=ModelStatus.DEPRECATED,
                description="Previous generation - use 'sonnet' for 4.6",
                context_window=200_000,
                reasoning_supported_levels=set(REASONING_LEVELS),
            ),
        },
    ),
    "google": ProviderConfig(
        name="Google",
        cli="Gemini",
        description="Fast multimodal with large context",
        flag="--model",
        default_model="gemini-2.5-flash",
        default_reasoning_level="medium",
        reasoning_level_map={
            "off": None,
            "low": None,
            "medium": None,
            "high": None,
            "maximum": None,
        },
        oauth_supported=True,
        api_key_env="GOOGLE_API_KEY",
        invalid_patterns=set(),
        models={
            # Aliases (tested)
            "gemini": ModelInfo(
                id="gemini",
                display_name="Gemini (2.5 Flash)",
                status=ModelStatus.TESTED,
                resolves_to="gemini-2.5-flash",
                description="Balanced speed and reasoning - recommended",
                context_window=1_000_000,
            ),
            # Full model IDs
            "gemini-2.5-pro": ModelInfo(
                id="gemini-2.5-pro",
                display_name="Gemini 2.5 Pro",
                status=ModelStatus.TESTED,
                description="Complex reasoning tasks",
                context_window=1_000_000,
            ),
            "gemini-2.5-flash": ModelInfo(
                id="gemini-2.5-flash",
                display_name="Gemini 2.5 Flash",
                status=ModelStatus.TESTED,
                description="Balanced speed and reasoning",
                context_window=1_000_000,
            ),
            "gemini-2.5-flash-lite": ModelInfo(
                id="gemini-2.5-flash-lite",
                display_name="Gemini 2.5 Flash Lite",
                status=ModelStatus.DOCUMENTED,
                description="Quick, simple tasks",
                context_window=192_000,
            ),
            "gemini-3-pro-preview": ModelInfo(
                id="gemini-3-pro-preview",
                display_name="Gemini 3 Pro Preview",
                status=ModelStatus.DOCUMENTED,
                description="Next-gen complex reasoning",
                note="Requires preview features enabled",
                context_window=1_000_000,
            ),
            "gemini-3-flash-preview": ModelInfo(
                id="gemini-3-flash-preview",
                display_name="Gemini 3 Flash Preview",
                status=ModelStatus.DOCUMENTED,
                description="Next-gen balanced speed and reasoning",
                note="Requires preview features enabled",
                context_window=1_000_000,
            ),
        },
    ),
    "ollama": ProviderConfig(
        name="Ollama",
        cli="Ollama",
        description="Run models locally, keep data safe",
        flag="run",  # ollama run <model>
        default_model="qwen2.5-coder:32b",
        default_reasoning_level="medium",
        reasoning_level_map={
            "off": None,
            "low": None,
            "medium": None,
            "high": None,
            "maximum": None,
        },
        oauth_supported=False,
        api_key_env=None,  # Local, no API key
        invalid_patterns=set(),
        # Curated subset of common local models to keep UI manageable.
        models={
            "phi3:mini": ModelInfo(
                id="phi3:mini",
                display_name="Phi-3 Mini",
                status=ModelStatus.DOCUMENTED,
                description="Ultra-compact model for constrained environments",
                context_window=4_096,
            ),
            "phi3:medium": ModelInfo(
                id="phi3:medium",
                display_name="Phi-3 Medium",
                status=ModelStatus.DOCUMENTED,
                description="Mid-size Phi-3 model for balanced local workloads",
                context_window=128_000,
            ),
            "qwen2.5-coder:3b": ModelInfo(
                id="qwen2.5-coder:3b",
                display_name="Qwen 2.5 Coder 3B",
                status=ModelStatus.DOCUMENTED,
                description="Small but capable coding model",
                context_window=8_192,
            ),
            "qwen2.5-coder:7b": ModelInfo(
                id="qwen2.5-coder:7b",
                display_name="Qwen 2.5 Coder 7B",
                status=ModelStatus.DOCUMENTED,
                description="Balanced performance/resource model",
                context_window=16_384,
            ),
            "qwen2.5-coder:14b": ModelInfo(
                id="qwen2.5-coder:14b",
                display_name="Qwen 2.5 Coder 14B",
                status=ModelStatus.DOCUMENTED,
                description="Good balance for medium contexts",
                context_window=32_768,
            ),
            "qwen2.5-coder:32b": ModelInfo(
                id="qwen2.5-coder:32b",
                display_name="Qwen 2.5 Coder 32B",
                status=ModelStatus.TESTED,
                description="Production-grade local model (recommended)",
                context_window=128_000,
            ),
            "qwen2.5:7b": ModelInfo(
                id="qwen2.5:7b",
                display_name="Qwen 2.5 7B",
                status=ModelStatus.DOCUMENTED,
                description="General-purpose local model for mixed tasks",
                context_window=32_768,
            ),
            "qwen2.5:14b": ModelInfo(
                id="qwen2.5:14b",
                display_name="Qwen 2.5 14B",
                status=ModelStatus.DOCUMENTED,
                description="Stronger general-purpose local model",
                context_window=32_768,
            ),
            "qwen2.5:32b": ModelInfo(
                id="qwen2.5:32b",
                display_name="Qwen 2.5 32B",
                status=ModelStatus.DOCUMENTED,
                description="Large general-purpose local model",
                context_window=32_768,
                quality_tier="high",
            ),
            "llama3.3:70b": ModelInfo(
                id="llama3.3:70b",
                display_name="Llama 3.3 70B",
                status=ModelStatus.DOCUMENTED,
                description="Large local reasoning model",
                context_window=128_000,
                quality_tier="high",
            ),
            "deepseek-r1:7b": ModelInfo(
                id="deepseek-r1:7b",
                display_name="DeepSeek R1 7B",
                status=ModelStatus.DOCUMENTED,
                description="Local reasoning model (smaller)",
            ),
            "deepseek-r1:14b": ModelInfo(
                id="deepseek-r1:14b",
                display_name="DeepSeek R1 14B",
                status=ModelStatus.DOCUMENTED,
                description="Local reasoning model (medium)",
                quality_tier="medium",
            ),
            "deepseek-r1:32b": ModelInfo(
                id="deepseek-r1:32b",
                display_name="DeepSeek R1 32B",
                status=ModelStatus.DOCUMENTED,
                description="Local reasoning model (large)",
                quality_tier="high",
            ),
        },
    ),
    "openai": ProviderConfig(
        name="OpenAI",
        cli="Codex",
        description="Lightweight coding agent",
        flag="--model",
        default_model="gpt-5.4",
        default_reasoning_level="medium",
        reasoning_level_map={
            "off": "low",
            "low": "low",
            "medium": "medium",
            "high": "high",
            "extra high": "xhigh",
            "maximum": "xhigh",
        },
        oauth_supported=True,
        api_key_env="OPENAI_API_KEY",
        invalid_patterns=set(),
        models={
            # Aliases (tested)
            "codex": ModelInfo(
                id="codex",
                display_name="Codex (GPT-5.4)",
                status=ModelStatus.DOCUMENTED,
                resolves_to="gpt-5.4",
                description="Latest frontier agentic coding model - recommended",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=(
                    _MEDIUM_WITH_HIGH_HIGH_TIER_REASONING_BY_ROLE_TIER.copy()
                ),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            # Full model IDs (tested)
            "gpt-5.4": ModelInfo(
                id="gpt-5.4",
                display_name="GPT-5.4",
                status=ModelStatus.DOCUMENTED,
                description="Latest GPT-5 model for coding and agentic tasks",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=(
                    _MEDIUM_WITH_HIGH_HIGH_TIER_REASONING_BY_ROLE_TIER.copy()
                ),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "gpt-5.3-codex": ModelInfo(
                id="gpt-5.3-codex",
                display_name="GPT-5.3 Codex",
                status=ModelStatus.TESTED,
                description="Previous frontier agentic coding model",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=(
                    _MEDIUM_WITH_HIGH_HIGH_TIER_REASONING_BY_ROLE_TIER.copy()
                ),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "gpt-5.3-codex-spark": ModelInfo(
                id="gpt-5.3-codex-spark",
                display_name="GPT-5.3 Codex Spark",
                status=ModelStatus.DOCUMENTED,
                description="Faster, lower-cost GPT-5.3 Codex variant",
                context_window=128_000,
                input_limit=128_000,
                output_limit=64_000,
                reserved_tokens=0,
                quality_tier="fast",
                reasoning_role_tier_defaults=_HIGH_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "gpt-5.2-codex": ModelInfo(
                id="gpt-5.2-codex",
                display_name="GPT-5.2 Codex",
                status=ModelStatus.TESTED,
                description="Latest frontier agentic coding model",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=_MEDIUM_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "gpt-5.1-codex-max": ModelInfo(
                id="gpt-5.1-codex-max",
                display_name="GPT-5.1 Codex Max",
                status=ModelStatus.TESTED,
                description="Codex-optimized flagship for deep and fast reasoning",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=_MEDIUM_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "gpt-5.1-codex-mini": ModelInfo(
                id="gpt-5.1-codex-mini",
                display_name="GPT-5.1 Codex Mini",
                status=ModelStatus.TESTED,
                description="Optimized for codex - cheaper, faster, but less capable",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=_MEDIUM_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"medium", "high"},
            ),
            "gpt-5.2": ModelInfo(
                id="gpt-5.2",
                display_name="GPT-5.2",
                status=ModelStatus.TESTED,
                description="Latest GPT model for coding and agentic tasks",
                context_window=400_000,
                input_limit=258_000,
                output_limit=128_000,
                reserved_tokens=14_000,
                reasoning_role_tier_defaults=_MEDIUM_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "gpt-4o": ModelInfo(
                id="gpt-4o",
                display_name="GPT-4o",
                status=ModelStatus.DEPRECATED,
                note="Legacy model - use gpt-5.4 or gpt-5.3-codex instead",
                context_window=128_000,
                reasoning_role_tier_defaults=_MEDIUM_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"low", "medium", "high", "extra high"},
            ),
            "o3": ModelInfo(
                id="o3",
                display_name="O3",
                status=ModelStatus.DEPRECATED,
                note="Not in active use",
                description="Reasoning-focused model",
                context_window=200_000,
                reasoning_role_tier_defaults=_MEDIUM_REASONING_BY_ROLE_TIER.copy(),
                reasoning_supported_levels={"off", "low", "medium", "high"},
            ),
        },
    ),
}


# =============================================================================
# Registry API Functions
# =============================================================================


def get_provider(provider: str) -> ProviderConfig | None:
    """Get provider configuration.

    Args:
        provider: Provider name (anthropic, google, openai)

    Returns:
        ProviderConfig or None if provider not found
    """
    return MODEL_REGISTRY.get(provider)


def get_model_info(
    provider: str,
    model: str,
    *,
    resolve_aliases: bool = True,
) -> ModelInfo | None:
    """Get model info for a provider, optionally resolving aliases."""
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return None
    model_info = config.models.get(model)
    if not model_info:
        return None
    if resolve_aliases and model_info.resolves_to:
        resolved = config.models.get(model_info.resolves_to)
        return resolved or model_info
    return model_info


def get_provider_names() -> list[str]:
    """Get list of supported provider names.

    Returns:
        List of provider names (e.g., ["anthropic", "google", "openai"])
    """
    return list(MODEL_REGISTRY.keys())


def get_provider_models(
    provider: str,
    include_deprecated: bool = False,
    only_tested: bool = False,
) -> list[ModelInfo]:
    """Get available models for a provider.

    Args:
        provider: Provider name (anthropic, google, openai)
        include_deprecated: Include deprecated models
        only_tested: Only return models with TESTED status

    Returns:
        List of ModelInfo objects

    Example:
        >>> models = get_provider_models("anthropic", only_tested=True)
        >>> [m.id for m in models]
        ['sonnet', 'opus', 'haiku', 'claude-sonnet-4-6', ...]
    """
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return []

    models = []
    for model in config.models.values():
        if not include_deprecated and model.status == ModelStatus.DEPRECATED:
            continue
        if only_tested and model.status != ModelStatus.TESTED:
            continue
        models.append(model)

    return models


def validate_model(provider: str, model: str) -> ValidationResult:
    """Validate a model identifier for a provider.

    Checks:
    1. Provider exists
    2. Model doesn't match invalid patterns
    3. Model is in registry (with status)
    4. Unknown models are allowed with warning (future-proofing)

    Args:
        provider: Provider name
        model: Model identifier to validate

    Returns:
        ValidationResult with validity and any warnings/errors

    Example:
        >>> result = validate_model("anthropic", "sonnet")
        >>> result.valid, result.status
        (True, ModelStatus.TESTED)

        >>> result = validate_model("anthropic", "sonnet-4")
        >>> result.valid, result.error
        (False, "Invalid model format: sonnet-4...")
    """
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return ValidationResult(
            valid=False,
            model_id=model,
            error=f"Unknown provider: {provider}. Valid providers: {', '.join(get_provider_names())}",
        )

    # Check invalid patterns
    for pattern in config.invalid_patterns:
        if pattern.endswith("*"):
            if model.startswith(pattern[:-1]):
                return ValidationResult(
                    valid=False,
                    model_id=model,
                    error=f"Invalid model format: {model}. Pattern '{pattern}' is not supported.",
                )
        elif model == pattern:
            return ValidationResult(
                valid=False,
                model_id=model,
                error=f"Invalid model format: {model}. Try 'sonnet', 'opus', or 'haiku' instead.",
            )

    # Check if model is in registry
    model_info = config.models.get(model)
    if model_info:
        warning = None
        if model_info.status == ModelStatus.DEPRECATED:
            from obra.messages import get_message

            warning = get_message("warning.deprecation.model", old=model)
        elif model_info.status == ModelStatus.RESTRICTED:
            warning = model_info.note or f"Model '{model}' may have access restrictions."
        elif model_info.status == ModelStatus.DOCUMENTED:
            warning = f"Model '{model}' is documented but not tested with Obra."

        return ValidationResult(
            valid=True,
            model_id=model,
            status=model_info.status,
            warning=warning,
        )

    # Model not in registry - allow but warn (supports future models)
    return ValidationResult(
        valid=True,
        model_id=model,
        warning=f"Model '{model}' is not in Obra's tested model list. It may or may not work.",
    )


def get_cli_args(provider: str, model: str | None) -> list[str]:
    """Get CLI arguments for a provider and model.

    Args:
        provider: Provider name
        model: Model identifier (None for default)

    Returns:
        List of CLI arguments (e.g., ["--model", "sonnet"])

    Example:
        >>> get_cli_args("anthropic", "opus")
        ['--model', 'opus']
        >>> get_cli_args("anthropic", None)
        ['--model', 'opus']  # default
        >>> get_cli_args("openai", None)
        ['--model', 'gpt-5.4']  # default
    """
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return []

    # Use default if no model specified
    effective_model = model or config.default_model

    if effective_model:
        return [config.flag, effective_model]

    return []  # No model flag (auto-select)


def resolve_alias(provider: str, model: str) -> str:
    """Resolve a model alias to its canonical form.

    Args:
        provider: Provider name
        model: Model identifier (possibly an alias)

    Returns:
        Canonical model ID (or original if not an alias)

    Example:
        >>> resolve_alias("anthropic", "sonnet")
        'claude-sonnet-4-6'
        >>> resolve_alias("anthropic", "unknown-model")
        'unknown-model'
    """
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return model

    model_info = config.models.get(model)
    if model_info and model_info.resolves_to:
        return model_info.resolves_to

    return model


def get_default_model(provider: str) -> str | None:
    """Get the default model for a provider.

    Args:
        provider: Provider name

    Returns:
        Default model ID or None if auto-select

    Example:
        >>> get_default_model("anthropic")
        'opus'
        >>> get_default_model("openai")
        None  # auto-select
    """
    config = MODEL_REGISTRY.get(provider)
    return config.default_model if config else None
