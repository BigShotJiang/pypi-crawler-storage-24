"""Session closeout message builder.

This module provides state-aware closeout messages for session termination,
including celebration banners for full mission completion and ASCII fallback
for Windows CMD/older PowerShell compatibility.

Usage:
    from obra.display.closeout import build_closeout_message, CloseoutContext, TerminationState

    ctx = CloseoutContext(
        state=TerminationState.COMPLETED,
        session_id="abc123",
        objective="Add feature X",
        ...
    )
    build_closeout_message(ctx, console, verbosity=1)
"""

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

from rich.console import Console

from obra.display.charset import get_unicode_support, glyphs
from obra.messages.registry import get_message
from obra.utils.numeric import _safe_int, _safe_numeric

logger = logging.getLogger(__name__)


class TerminationState(str, Enum):
    """Session termination states for closeout messaging."""

    COMPLETED = "completed"
    ESCALATED = "escalated"
    INTERRUPTED = "interrupted"
    FAILED = "failed"
    EXPIRED = "expired"
    ABANDONED = "abandoned"


@dataclass
class CloseoutContext:
    """Data for building closeout message."""

    state: TerminationState
    session_id: str
    objective: str = ""
    work_summary: list[str] | None = None
    items_completed: int = 0
    items_total: int = 0
    quality_score: float | None = 0.0
    quality_status: str = "finalized"
    duration_seconds: float = 0.0  # This invocation
    total_duration_seconds: float = 0.0  # Cumulative across all invocations
    invocation_count: int = 1  # Number of run/resume calls
    files_created: list[str] | None = None
    files_modified: list[str] | None = None
    git_branch: str = ""
    git_commit_hash: str = ""
    termination_reason: str = ""
    warnings: list[str] | None = None
    terminal_phase: str = ""
    suppress_interrupt_hint: bool = False
    # Epic completion tracking (for celebration)
    epics_completed: int = 0
    epics_total: int = 0
    stories_completed: int = 0
    stories_total: int = 0
    tasks_completed: int = 0
    tasks_total: int = 0
    # FEAT-CLOSEOUT-SKIP-SUMMARY: Pending skip records for display
    pending_skips: list[dict[str, str]] | None = None


# State-specific configuration
# Banner text is generated dynamically via get_message('status.session.*')
STATE_CONFIG = {
    TerminationState.COMPLETED: {
        "banner_key": "status.session.complete",
        "glyph": "success",
        "style": "bold green",
    },
    TerminationState.ESCALATED: {
        "banner_key": "status.session.escalated",
        "glyph": "warning",
        "style": "bold yellow",
    },
    TerminationState.INTERRUPTED: {
        "banner_key": "status.session.paused",
        "glyph": "paused",
        "style": "bold cyan",
    },
    TerminationState.FAILED: {
        "banner_key": "status.session.failed",
        "glyph": "failure",
        "style": "bold red",
    },
    TerminationState.EXPIRED: {
        "banner_key": "status.session.expired",
        "glyph": "timeout",
        "style": "dim",
    },
    TerminationState.ABANDONED: {
        "banner_key": "status.session.abandoned",
        "glyph": "failure",
        "style": "dim",
    },
}


# Recovery message key mappings for next steps commands
# Maps logical action to message key (without 'recovery.' prefix)
_RECOVERY_KEYS = {
    "session.show": "recovery.session.show",
    "session.resume": "recovery.session.resume",
    "session.continue": "recovery.session.continue",
    "session.repair": "recovery.session.repair",
    "session.reset_review": "recovery.session.reset_review",
}


def _build_next_step(key_or_template: str, short_id: str, objective: str = "") -> str:
    """Build a next step command from a key or template.

    Args:
        key_or_template: Either a recovery message key (e.g., 'session.show')
                         or a raw template string
        short_id: Session short ID for placeholder substitution
        objective: Objective text for placeholder substitution

    Returns:
        Formatted command string
    """
    if key_or_template in _RECOVERY_KEYS:
        return get_message(_RECOVERY_KEYS[key_or_template], short_id=short_id)
    # For non-recovery commands, format as template
    return key_or_template.format(sid=short_id, objective=objective[:30] if objective else "...")


# State-specific next steps
# Each entry is (label, key_or_template) where key_or_template is either:
# - A recovery key like 'session.show' (looked up via get_message)
# - A raw command template like 'git diff HEAD~1'
NEXT_STEPS: dict[TerminationState, list[tuple[str, str]]] = {
    TerminationState.COMPLETED: [
        ("Review changes", "git diff HEAD~1"),
        ("View session", "session.show"),
        ("Continue", 'obra run --continue-from {sid} "Next task..."'),
    ],
    TerminationState.ESCALATED: [
        ("View breakpoint", "session.show"),
        ("Resume session", "session.resume"),
        ("Reset review", "session.reset_review"),
    ],
    TerminationState.INTERRUPTED: [
        ("Resume session", "session.resume"),
        ("View progress", "session.show"),
    ],
    TerminationState.FAILED: [
        ("View error", "session.show"),
        ("Repair session", "session.repair"),
        ("Retry", "session.resume"),
    ],
    TerminationState.EXPIRED: [
        ("View session", "session.show"),
        ("Start fresh", 'obra run "{objective}"'),
    ],
    TerminationState.ABANDONED: [
        ("View session", "session.show"),
        ("Start fresh", 'obra run "{objective}"'),
    ],
}


def _format_duration(seconds: float) -> str:
    """Format duration as human-readable string.

    Args:
        seconds: Duration in seconds.

    Returns:
        Formatted string like "45s", "1m 30s", or "2h 15m".
    """
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    if minutes < 60:
        return f"{minutes}m {secs}s"
    hours = minutes // 60
    mins = minutes % 60
    return f"{hours}h {mins}m"


def _format_duration_with_invocations(
    total_seconds: float,
    invocation_count: int,
) -> str:
    """Format duration with invocation count if multiple sessions.

    Args:
        total_seconds: Total duration in seconds.
        invocation_count: Number of invocations (run + resumes).

    Returns:
        Duration string, with "(across N sessions)" suffix if count > 1.
    """
    duration_str = _format_duration(total_seconds)
    if invocation_count > 1:
        return f"{duration_str} (across {invocation_count} sessions)"
    return duration_str


def _should_celebrate(ctx: CloseoutContext) -> bool:
    """Determine if this completion deserves full celebration banner.

    Triggers celebration when:
    - Session completed successfully
    - All epics are completed (epics_completed == epics_total)
    - At least one epic exists
    - Quality score meets threshold (>= 70)
    - Celebration mode is not disabled in config

    Args:
        ctx: Closeout context with session data.

    Returns:
        True if celebration banner should be shown.
    """
    # Check config for celebration_mode
    try:
        from obra.config import load_config

        config = load_config()
        if not config.get("display", {}).get("celebration_mode", True):
            return False
    except Exception:
        pass  # Default to allowing celebration if config unavailable

    quality_score = float(ctx.quality_score or 0.0)
    if ctx.state != TerminationState.COMPLETED or quality_score < 70:
        return False
    if ctx.epics_total > 0:
        return ctx.epics_completed == ctx.epics_total
    if ctx.stories_total > 0:
        return ctx.stories_completed == ctx.stories_total
    return False


def resolve_closeout_banner_mode(ctx: CloseoutContext) -> str:
    """Resolve which closeout banner mode should be rendered."""
    return "celebration" if _should_celebrate(ctx) else "standard"


def _render_pending_sections(ctx: CloseoutContext, console: Console) -> None:
    """Render warnings and pending skip summary sections.

    Shared between celebration and standard closeout paths to ensure
    skip/warning visibility regardless of banner mode.
    """
    if ctx.warnings:
        console.print()
        for warning in ctx.warnings[:3]:
            console.print(f"  [yellow]{glyphs.warning} {warning}[/yellow]")

    if ctx.pending_skips:
        console.print()
        count = len(ctx.pending_skips)
        console.print(f"  [bold yellow]Skipped ({count} pending):[/bold yellow]")
        for skip in ctx.pending_skips[:5]:
            reason = skip.get("reason", "unknown")
            desc = skip.get("description", "")
            console.print(f"    {glyphs.warning} {desc} [dim]({reason})[/dim]")
        if count > 5:
            console.print(f"    [dim]... and {count - 5} more[/dim]")
        console.print("    [dim]Run: obra cleanup --interactive[/dim]")


def _build_celebration_banner(
    ctx: CloseoutContext,
    console: Console,
    verbosity: int = 1,
) -> None:
    """Build celebration banner for full mission completion.

    Called when all epics completed successfully. Uses double-line borders
    to visually distinguish from partial session completion.

    Args:
        ctx: Closeout context with session data.
        console: Rich console for output.
        verbosity: Output detail level (0=quiet, 1=progress, 2=detail).
    """
    short_id = ctx.session_id.split("-")[0] if "-" in ctx.session_id else ctx.session_id

    # Double-line banner (=) vs single-line (-) signals full mission
    if get_unicode_support():
        border = "\u2550" * 60  # ═
        success_icon = "\u2713"  # ✓
        tl, tr, bl, br = "\u250c", "\u2510", "\u2514", "\u2518"  # ┌┐└┘
        h, v = "\u2500", "\u2502"  # ─│
    else:
        border = "=" * 60
        success_icon = "[ok]"
        tl, tr, bl, br = "+", "+", "+", "+"
        h, v = "-", "|"

    # Celebration header
    mission_text = get_message("status.celebration.mission_complete")
    console.print()
    console.print(f"[bold green]{border}[/bold green]")
    console.print()
    console.print(
        f"[bold green]{success_icon}  {mission_text}  {success_icon}[/bold green]",
        justify="center",
    )
    console.print()
    epic_word = "epic" if ctx.epics_total == 1 else "epics"
    console.print(
        f"[green]All {ctx.epics_total} {epic_word} finished successfully[/green]",
        justify="center",
    )
    console.print()
    console.print(f"[bold green]{border}[/bold green]")

    if verbosity == 0:  # QUIET
        console.print(f"\n[dim]Session: {short_id}[/dim]")
        return

    # Objective
    console.print()
    if ctx.objective:
        obj_display = ctx.objective[:60] + "..." if len(ctx.objective) > 60 else ctx.objective
        console.print(f"  [bold]Objective:[/bold] {obj_display}")

    # Stats table
    console.print()
    epic_str = f"{ctx.epics_completed} Epic{'s' if ctx.epics_completed != 1 else ''}"
    story_str = f"{ctx.stories_completed} Stor{'ies' if ctx.stories_completed != 1 else 'y'}"
    task_str = f"{ctx.tasks_completed} Task{'s' if ctx.tasks_completed != 1 else ''}"
    quality_str = f"{float(ctx.quality_score or 0.0):.0f}/100"

    # Table with box drawing
    col_w = 12
    table_content = f" {epic_str:^{col_w}} {v} {story_str:^{col_w}} {v} {task_str:^{col_w}} {v} {quality_str:^{col_w}} "
    table_width = len(table_content)
    table_border = h * table_width

    console.print(f"  {tl}{table_border}{tr}")
    console.print(f"  {v}{table_content}{v}")
    console.print(f"  {bl}{table_border}{br}")

    # Duration and files
    console.print()
    if ctx.total_duration_seconds > 0:
        duration_display = _format_duration_with_invocations(
            ctx.total_duration_seconds, ctx.invocation_count
        )
        console.print(f"  Duration: {duration_display}")
    elif ctx.duration_seconds > 0:
        console.print(f"  Duration: {_format_duration(ctx.duration_seconds)}")

    files_created = ctx.files_created or []
    files_modified = ctx.files_modified or []
    total_files = len(files_created) + len(files_modified)
    if total_files > 0:
        console.print(
            f"  Files: [green]+{len(files_created)} created[/green], [yellow]~{len(files_modified)} modified[/yellow]"
        )

    # Git info
    if ctx.git_branch or ctx.git_commit_hash:
        git_parts = []
        if ctx.git_branch:
            git_parts.append(f"Branch: {ctx.git_branch}")
        if ctx.git_commit_hash:
            git_parts.append(f"Commit: {ctx.git_commit_hash[:7]}")
        console.print(f"  Git: {', '.join(git_parts)}")

    # Warnings and pending skips (shared with standard closeout)
    _render_pending_sections(ctx, console)

    # Next steps
    console.print()
    console.print("  [bold]Next steps:[/bold]")
    console.print("    [dim]git diff HEAD~1[/dim]                    [dim]# Review changes[/dim]")
    session_show_cmd = get_message("recovery.session.show", short_id=short_id)
    console.print(f"    [dim]{session_show_cmd}[/dim]        [dim]# View details[/dim]")

    # Footer
    console.print()
    console.print(f"[dim]{'-' * 60}[/dim]")
    console.print(f"[dim]Session: {short_id}[/dim]")


def build_closeout_message(
    ctx: CloseoutContext,
    console: Console,
    verbosity: int = 1,
) -> None:
    """Build and print closeout message based on termination state.

    Args:
        ctx: Closeout context with session data.
        console: Rich console for output.
        verbosity: Output detail level (0=quiet, 1=progress, 2=detail).
    """
    # Check for full mission completion - use celebration banner
    if _should_celebrate(ctx):
        _build_celebration_banner(ctx, console, verbosity)
        return

    # Standard closeout for partial completion or non-success states
    config = STATE_CONFIG[ctx.state]
    glyph = getattr(glyphs, config["glyph"])
    short_id = ctx.session_id.split("-")[0] if "-" in ctx.session_id else ctx.session_id

    # Banner
    console.print()
    banner_text = get_message(config["banner_key"])
    console.print(f"{glyph} {banner_text}", style=config["style"])

    if verbosity == 0:  # QUIET
        if ctx.state == TerminationState.INTERRUPTED and not ctx.suppress_interrupt_hint:
            from obra.display.recovery_hints import build_interrupt_recovery_hints

            console.print()
            console.print(glyphs.divider)
            for line in build_interrupt_recovery_hints(ctx.session_id or "").splitlines():
                if line:
                    console.print(f"[dim]{line}[/dim]")
                else:
                    console.print()
            return
        console.print(f"[dim]Session: {short_id}[/dim]")
        return

    # PROGRESS level and above
    console.print()

    # Objective echo
    if ctx.objective:
        obj_display = ctx.objective[:70] + "..." if len(ctx.objective) > 70 else ctx.objective
        console.print(f"  [bold]Objective:[/bold] {obj_display}")

    # Work summary (DETAIL only)
    if verbosity >= 2 and ctx.work_summary:
        console.print()
        console.print("  [bold]Summary:[/bold]")
        for item in ctx.work_summary[:3]:
            console.print(f"    {glyphs.tree_mid} {item}")

    # Files changed
    files_created = ctx.files_created or []
    files_modified = ctx.files_modified or []
    total_files = len(files_created) + len(files_modified)

    if total_files > 0:
        console.print()
        console.print(f"  [bold]Files ({total_files}):[/bold]")
        if verbosity >= 2:
            # Show file list at DETAIL
            for f in files_created[:5]:
                console.print(f"    [green]+ {f}[/green]")
            for f in files_modified[:5]:
                console.print(f"    [yellow]~ {f}[/yellow]")
            remaining = total_files - min(5, len(files_created)) - min(5, len(files_modified))
            if remaining > 0:
                console.print(f"    [dim]... and {remaining} more[/dim]")
        else:
            # Summary at PROGRESS
            console.print(
                f"    [green]+{len(files_created)} created[/green], [yellow]~{len(files_modified)} modified[/yellow]"
            )

    # Metrics line
    console.print()
    metrics_parts = []
    if ctx.state == TerminationState.INTERRUPTED or ctx.quality_status == "not_finalized":
        metrics_parts.append("Quality: not finalized")
    else:
        quality_score = float(ctx.quality_score or 0.0)
        if quality_score > 0:
            metrics_parts.append(f"Quality: {quality_score:.0f}/100")
    if ctx.total_duration_seconds > 0:
        duration_display = _format_duration_with_invocations(
            ctx.total_duration_seconds, ctx.invocation_count
        )
        metrics_parts.append(f"Duration: {duration_display}")
    elif ctx.duration_seconds > 0:
        metrics_parts.append(f"Duration: {_format_duration(ctx.duration_seconds)}")
    if ctx.items_completed > 0:
        if ctx.items_total > 0:
            metrics_parts.append(f"Items: {ctx.items_completed}/{ctx.items_total}")
        else:
            metrics_parts.append(f"Items: {ctx.items_completed}")

    if metrics_parts:
        console.print(f"  {' | '.join(metrics_parts)}")

    # Git status
    if ctx.git_branch or ctx.git_commit_hash:
        git_info = []
        if ctx.git_branch:
            git_info.append(f"Branch: {ctx.git_branch}")
        if ctx.git_commit_hash:
            git_info.append(f"Commit: {ctx.git_commit_hash[:7]}")
        console.print(f"  [dim]Git: {', '.join(git_info)}[/dim]")
    elif ctx.state == TerminationState.ESCALATED:
        console.print(f"  [yellow]{glyphs.warning} Changes NOT committed (escalated)[/yellow]")

    # Warnings and pending skips (shared with celebration closeout)
    _render_pending_sections(ctx, console)

    # Termination reason for non-success
    if ctx.termination_reason and ctx.state != TerminationState.COMPLETED:
        console.print()
        console.print(f"  [dim]Reason: {ctx.termination_reason}[/dim]")

    if ctx.state == TerminationState.INTERRUPTED:
        if not ctx.suppress_interrupt_hint:
            from obra.display.recovery_hints import build_interrupt_recovery_hints

            console.print()
            console.print(glyphs.divider)
            for line in build_interrupt_recovery_hints(ctx.session_id or "").splitlines():
                if line:
                    console.print(f"[dim]{line}[/dim]")
                else:
                    console.print()
        return

    # Next steps
    steps = NEXT_STEPS.get(ctx.state, [])
    if steps:
        console.print()
        console.print("  [bold]Next steps:[/bold]")
        for label, key_or_template in steps[:3]:
            cmd_formatted = _build_next_step(key_or_template, short_id, ctx.objective or "")
            console.print(f"    [dim]{cmd_formatted}[/dim]  [dim]# {label}[/dim]")

    # Footer
    console.print()
    console.print(glyphs.divider)
    console.print(f"[dim]Session: {short_id}[/dim]")


def _extract_completion_context(
    result: Any,
) -> tuple[int, Any, Any, bool, str]:
    items_completed = 0
    total_iterations: Any = "N/A"
    quality_score: Any = "N/A"
    was_escalated = False
    terminal_phase = ""

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        summary = result.session_summary
        items_completed = int(summary.get("items_completed", 0) or 0)
        total_iterations = summary.get("total_iterations", "N/A")
        quality_score = summary.get("quality_score", "N/A")
        was_escalated = bool(summary.get("was_escalated", False))
        terminal_phase = summary.get("terminal_phase", "")
    elif hasattr(result, "items_completed"):
        items_completed = int(getattr(result, "items_completed", 0) or 0)
        total_iterations = getattr(result, "total_iterations", "N/A")
        quality_score = getattr(result, "quality_score", "N/A")

    result_was_escalated = getattr(result, "was_escalated", None)
    if isinstance(result_was_escalated, bool):
        was_escalated = result_was_escalated

    result_terminal_phase = getattr(result, "terminal_phase", None)
    if isinstance(result_terminal_phase, str) and result_terminal_phase:
        terminal_phase = result_terminal_phase

    return (
        items_completed,
        total_iterations,
        quality_score,
        was_escalated,
        terminal_phase,
    )


def _map_to_termination_state(
    result: Any,
    *,
    was_interrupted: bool = False,
) -> TerminationState:
    """Map result to TerminationState for closeout message."""
    if was_interrupted:
        return TerminationState.INTERRUPTED

    was_escalated = getattr(result, "was_escalated", None)
    if was_escalated is True:
        return TerminationState.ESCALATED

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        if result.session_summary.get("was_escalated"):
            return TerminationState.ESCALATED

    status = getattr(result, "status", None)
    if status is not None:
        status_str = str(status).lower()
        if "failed" in status_str:
            return TerminationState.FAILED
        if "expired" in status_str:
            return TerminationState.EXPIRED
        if "abandoned" in status_str:
            return TerminationState.ABANDONED
        if "escalated" in status_str:
            return TerminationState.ESCALATED

    return TerminationState.COMPLETED


def _build_closeout_context(
    result: Any,
    session_id: str | None,
    objective: str = "",
    *,
    was_interrupted: bool = False,
) -> CloseoutContext:
    """Build CloseoutContext from result for closeout message."""
    (
        items_completed,
        _total_iterations,
        quality_score,
        _was_escalated,
        terminal_phase,
    ) = _extract_completion_context(result)

    if isinstance(quality_score, (int, float)):
        if quality_score <= 1.0:
            quality_score = quality_score * 100
    else:
        quality_score = 0.0

    result_objective = getattr(result, "objective", "") or objective
    work_summary = getattr(result, "work_summary", []) or []
    duration_seconds = _safe_numeric(getattr(result, "duration_seconds", 0.0))
    total_duration_seconds = _safe_numeric(getattr(result, "total_duration_seconds", 0.0))
    invocation_count = _safe_int(getattr(result, "invocation_count", 1), default=1)
    files_created = getattr(result, "files_created", []) or []
    files_modified = getattr(result, "files_modified", []) or []
    git_branch = getattr(result, "git_branch", "") or ""
    git_commit_hash = getattr(result, "git_commit_hash", "") or ""
    termination_reason = getattr(result, "termination_reason", "") or ""
    warnings = getattr(result, "warnings", []) or []
    epics_completed = _safe_int(getattr(result, "epics_completed", 0))
    epics_total = _safe_int(getattr(result, "epics_total", 0))
    stories_completed = _safe_int(getattr(result, "stories_completed", 0))
    stories_total = _safe_int(getattr(result, "stories_total", 0))
    tasks_completed = _safe_int(getattr(result, "tasks_completed", 0))
    tasks_total = _safe_int(getattr(result, "tasks_total", 0))

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        summary = result.session_summary
        if not result_objective:
            result_objective = summary.get("objective", objective)
        if not items_completed:
            items_completed = summary.get("items_completed", 0)

    state = _map_to_termination_state(result, was_interrupted=was_interrupted)
    quality_status = "not_finalized" if state == TerminationState.INTERRUPTED else "finalized"
    if state == TerminationState.INTERRUPTED:
        quality_score = None

    plan_final = getattr(result, "plan_final", []) or []
    if isinstance(plan_final, list):
        counts = {"epic": 0, "story": 0, "task": 0}
        for item in plan_final:
            if not isinstance(item, dict):
                continue
            item_type = item.get("item_type")
            if item_type in counts:
                counts[item_type] += 1
        if epics_total == 0:
            epics_total = counts["epic"]
        if stories_total == 0:
            stories_total = counts["story"]
        if tasks_total == 0:
            tasks_total = counts["task"]

    if state == TerminationState.COMPLETED:
        if epics_total > 0 and epics_completed == 0:
            epics_completed = epics_total
        if stories_total > 0 and stories_completed == 0:
            stories_completed = stories_total
        if tasks_total > 0 and tasks_completed == 0:
            tasks_completed = tasks_total
    elif tasks_completed == 0:
        tasks_completed = items_completed

    items_total = tasks_total if tasks_total > 0 else 0

    # FEAT-CLOSEOUT-SKIP-SUMMARY: Attach pending skips for closeout display
    pending_skips: list[dict[str, str]] | None = None
    try:
        from obra.config import Config

        cfg = Config.load()
        show_summary = (
            cfg.get("orchestration", {})
            .get("skip_tracking", {})
            .get("closeout_summary", True)
        )
        if show_summary:
            from obra.execution.skip_record import SkipStatus, list_skip_records

            pending = list_skip_records(status=SkipStatus.PENDING)
            if session_id:
                pending = [s for s in pending if s.session_id == session_id]
            if pending:
                pending_skips = [
                    {
                        "id": s.task_id,
                        "description": s.description[:80],
                        "reason": s.reason.value,
                    }
                    for s in pending
                ]
    except Exception:
        logger.debug("Skip summary population failed during closeout", exc_info=True)

    return CloseoutContext(
        state=state,
        session_id=session_id or "",
        objective=result_objective,
        work_summary=work_summary if work_summary else None,
        items_completed=items_completed,
        items_total=items_total,
        quality_score=quality_score,
        quality_status=quality_status,
        duration_seconds=duration_seconds,
        total_duration_seconds=total_duration_seconds,
        invocation_count=invocation_count,
        files_created=files_created if files_created else None,
        files_modified=files_modified if files_modified else None,
        git_branch=git_branch,
        git_commit_hash=git_commit_hash,
        termination_reason=termination_reason,
        warnings=warnings if warnings else None,
        terminal_phase=terminal_phase,
        epics_completed=epics_completed,
        epics_total=epics_total,
        stories_completed=stories_completed,
        stories_total=stories_total,
        tasks_completed=tasks_completed or items_completed,
        tasks_total=tasks_total,
        pending_skips=pending_skips,
    )


def _get_orchestrator_closeout_progress(orchestrator: Any | None) -> dict[str, Any]:
    """Best-effort read of orchestrator progress metrics for closeout reconciliation."""
    if orchestrator is None:
        return {}
    get_progress = getattr(orchestrator, "get_closeout_progress_snapshot", None)
    if not callable(get_progress):
        return {}
    try:
        progress = get_progress()
    except Exception as exc:
        logger.debug("Failed to read closeout progress snapshot: %s", exc)
        return {}
    return progress if isinstance(progress, dict) else {}


def _merge_closeout_progress(ctx: CloseoutContext, progress: dict[str, Any]) -> None:
    """Merge orchestrator progress data into closeout context when missing."""
    if not progress:
        return
    progress_tasks_completed = _safe_int(
        progress.get("tasks_completed"),
        default=_safe_int(progress.get("items_completed"), default=0),
    )
    progress_tasks_total = _safe_int(progress.get("tasks_total"), default=0)
    if ctx.tasks_completed <= 0 and progress_tasks_completed > 0:
        ctx.tasks_completed = progress_tasks_completed
    if ctx.tasks_total <= 0 and progress_tasks_total > 0:
        ctx.tasks_total = progress_tasks_total
    if ctx.items_completed <= 0 and progress_tasks_completed > 0:
        ctx.items_completed = progress_tasks_completed
    if ctx.items_total <= 0 and progress_tasks_total > 0:
        ctx.items_total = progress_tasks_total
    # P0-3: Merge epic/story counters from orchestrator plan state
    progress_epics_completed = _safe_int(progress.get("epics_completed"), default=0)
    progress_epics_total = _safe_int(progress.get("epics_total"), default=0)
    progress_stories_completed = _safe_int(progress.get("stories_completed"), default=0)
    progress_stories_total = _safe_int(progress.get("stories_total"), default=0)
    if ctx.epics_completed <= 0 and progress_epics_completed > 0:
        ctx.epics_completed = progress_epics_completed
    if ctx.epics_total <= 0 and progress_epics_total > 0:
        ctx.epics_total = progress_epics_total
    if ctx.stories_completed <= 0 and progress_stories_completed > 0:
        ctx.stories_completed = progress_stories_completed
    if ctx.stories_total <= 0 and progress_stories_total > 0:
        ctx.stories_total = progress_stories_total
    if not ctx.terminal_phase:
        phase = progress.get("last_phase")
        if isinstance(phase, str) and phase.strip():
            ctx.terminal_phase = phase.strip()


def _build_interrupted_closeout_context(
    *,
    orchestrator: Any | None,
    session_id: str,
    objective: str,
    suppress_interrupt_hint: bool,
) -> CloseoutContext:
    """Build interrupted closeout context with best-effort progress reconciliation."""
    ctx = CloseoutContext(
        state=TerminationState.INTERRUPTED,
        session_id=session_id,
        objective=objective,
        quality_score=None,
        quality_status="not_finalized",
        suppress_interrupt_hint=suppress_interrupt_hint,
    )
    _merge_closeout_progress(ctx, _get_orchestrator_closeout_progress(orchestrator))
    return ctx


def _log_closeout_rendered(orchestrator: Any | None, ctx: CloseoutContext) -> None:
    """Emit closeout telemetry marker with the rendered banner mode."""
    if orchestrator is None:
        return
    log_closeout = getattr(orchestrator, "log_closeout_rendered", None)
    if not callable(log_closeout):
        return
    try:
        _merge_closeout_progress(ctx, _get_orchestrator_closeout_progress(orchestrator))
        quality_status = (ctx.quality_status or "").strip().lower()
        if ctx.state == TerminationState.INTERRUPTED:
            quality_status = "not_finalized"
        elif quality_status not in {"finalized", "not_finalized"}:
            quality_status = "finalized"
        if quality_status == "not_finalized":
            quality_score: float | None = None
        else:
            quality_score = float(ctx.quality_score or 0.0)
        log_closeout(
            resolve_closeout_banner_mode(ctx),
            state=ctx.state.value,
            quality_score=quality_score,
            quality_status=quality_status,
            epics_completed=int(ctx.epics_completed),
            epics_total=int(ctx.epics_total),
            stories_completed=int(ctx.stories_completed),
            stories_total=int(ctx.stories_total),
            tasks_completed=int(ctx.tasks_completed),
            tasks_total=int(ctx.tasks_total),
        )
    except Exception as exc:
        logger.debug("Failed to log closeout_rendered event: %s", exc)


def _format_completion_message(terminal_phase: str, was_escalated: bool) -> str:
    phase = (terminal_phase or "").lower()
    if was_escalated:
        return {
            "derivation": "Plan creation stopped",
            "refinement": "Plan refinement stopped",
            "execution": "Execution stopped",
            "review": "Review failed",
            "story0": "Environment prep stopped",
            "completed": "Session escalated",
        }.get(phase, "Session escalated")
    return {
        "derivation": "Plan created",
        "refinement": "Plan refined",
        "execution": "Execution complete",
        "review": "Review passed",
        "story0": "Environment prepared",
        "completed": "Session complete",
    }.get(phase, "Session complete")


def _print_git_file_summary(console: Console, work_dir: str) -> None:
    console.print(f"\n[dim]Project: {work_dir}[/dim]")
    try:
        import subprocess

        git_result = subprocess.run(
            ["git", "status", "--porcelain"],
            check=False,
            cwd=work_dir,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if git_result.returncode != 0:
            return
        lines = [line for line in git_result.stdout.splitlines() if line.strip()]
        # Git status format requires at least 2 chars (XY status codes) - protocol constant
        created = sum(
            1
            for line in lines
            if len(line) >= 2 and line[:2] in ("??", "A ", "AM", "R ", "RM", "C ", "CM")
        )
        modified = sum(
            1 for line in lines if len(line) >= 2 and (line[0] == "M" or line[1] == "M")
        )
        console.print(f"[dim]Files: {created} created, {modified} modified[/dim]")
    except Exception:
        pass  # Non-git or git unavailable - skip file counts
