"""MiscEmitter — miscellaneous progress events.

Owns LLM invocation events, parallel batch events, refinement scope summary,
error/warning display, decomposition notices, and interactive guard notices.

Shared state read/written via EmitterContext:
    _llm_state  (written by llm_started/streaming/completed via set_llm_state)

Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

import time
from typing import TYPE_CHECKING

from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext


class MiscEmitter:
    """Emits LLM invocation, parallel batch, error/warning, and decomposition events.

    Zero dedicated state — all shared infrastructure (print, spinner,
    utilities) is accessed via self._ctx.  _llm_state updates go directly
    to self._ctx._llm_state (with validation inline).
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

    # ------------------------------------------------------------------ #
    # LLM invocation events                                              #
    # ------------------------------------------------------------------ #

    def llm_started(self, purpose: str) -> None:
        """Emit event when an LLM invocation starts.

        Args:
            purpose: Description of what the LLM is being asked to do
        """
        self._ctx._llm_state = "waiting"
        self._ctx._llm_call_start_time = time.perf_counter()
        self._ctx.start_spinner(reason="llm")

        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return

        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}LLM invocation: {purpose}", style="yellow")

    def llm_streaming(self, chunk: str) -> None:
        """Emit LLM response chunk during streaming.

        Args:
            chunk: Text chunk from the streaming LLM response
        """
        self._ctx._llm_state = "streaming"

        if not self._ctx.config.stream:
            return

        # Stream output with [LLM] prefix
        # Don't add timestamp per chunk (would be noisy)
        if self._ctx._is_tty:
            self._ctx.console.print(f"  [LLM] {chunk}", end="", style="blue")
        else:
            # Line-by-line for non-TTY (no streaming animation)
            self._ctx.console.print(f"  [LLM] {chunk}")

    def llm_completed(self, summary: str, tokens: int = 0) -> None:
        """Emit event when an LLM invocation completes.

        Args:
            summary: Summary of the LLM response
            tokens: Token count for the response
        """
        self._ctx.stop_spinner(reason="llm")

        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            self._ctx._llm_state = "idle"
            self._ctx._llm_call_start_time = None
            return

        timestamp = self._ctx._timestamp()
        token_info = f" ({tokens} tokens)" if tokens > 0 else ""
        self._ctx._print(f"{timestamp}LLM complete{token_info}: {summary}", style="green")

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
            self._ctx._print(f"[DEBUG] Token count: {tokens}", style="dim")

        self._ctx._llm_state = "idle"
        self._ctx._llm_call_start_time = None

    # ------------------------------------------------------------------ #
    # Parallel batch events                                              #
    # ------------------------------------------------------------------ #

    def parallel_batch_started(
        self, stage: str, *, workers: int, batches: int, items: int
    ) -> None:
        """Emit a console banner when parallel batch processing begins.

        Args:
            stage: Stage name (e.g. "examine", "revise").
            workers: Number of parallel workers.
            batches: Number of batches dispatched.
            items: Total plan items across all batches.
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._ctx._print(
            f"  Parallel {stage}: {workers} workers, {batches} batches, {items} items",
            style="cyan",
        )

    def examine_batch_progress(
        self,
        *,
        batch_index: int,
        batch_size: int,
        batches_done: int,
        batches_total: int,
        elapsed_ms: float,
        status: str,
        phase: str = "examine",
    ) -> None:
        """Render per-batch progress as each parallel batch completes.

        Provides real-time visibility into batch execution at PROGRESS+
        verbosity. At DETAIL+, includes elapsed time per batch.

        Args:
            batch_index: Zero-based index of the completed batch.
            batch_size: Number of items in this batch.
            batches_done: Total batches completed so far.
            batches_total: Total number of batches.
            elapsed_ms: Wall-clock time since parallel dispatch started.
            status: Batch outcome ("success" or "error").
            phase: Processing phase ("examine" or "revise").
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if batches_total <= 1:
            return

        from obra.display.charset import glyphs

        symbol = glyphs.success if status == "success" else glyphs.failure
        style = "green" if status == "success" else "red"
        remaining = batches_total - batches_done

        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._ctx._timestamp()
            elapsed_s = elapsed_ms / 1000
            self._ctx._print(
                f"{timestamp}  {symbol} {phase.capitalize()} batch "
                f"{batches_done}/{batches_total}: "
                f"{batch_size} items ({elapsed_s:.1f}s)"
                + (f" | {remaining} running" if remaining > 0 else ""),
                style=style,
            )
        else:
            self._ctx._print(
                f"    {symbol} Batch {batches_done}/{batches_total}: "
                f"{batch_size} items — {status}",
                style=style,
            )

    def parallel_batch_completed(
        self,
        stage: str,
        *,
        wall_clock_ms: float,
        speedup_ratio: float,
        batches_failed: int,
        batches_total: int,
        batch_statuses: list[str] | None = None,
    ) -> None:
        """Emit a console summary when parallel batch processing completes.

        Args:
            stage: Stage name (e.g. "examine", "revise").
            wall_clock_ms: Total wall-clock time in milliseconds.
            speedup_ratio: Ratio of sequential total to wall clock.
            batches_failed: Number of batches that failed.
            batches_total: Total number of batches.
            batch_statuses: Per-batch outcome codes (e.g. ["success",
                "template_fallback", "success"]). Shown at DETAIL verbosity.
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        secs = wall_clock_ms / 1000
        if batches_failed > 0:
            self._ctx._print(
                f"  Parallel {stage} done: {secs:.1f}s, {speedup_ratio:.1f}x speedup, "
                f"{batches_failed}/{batches_total} batches failed",
                style="yellow",
            )
        else:
            self._ctx._print(
                f"  Parallel {stage} done: {secs:.1f}s, {speedup_ratio:.1f}x speedup",
                style="green",
            )
        # Show per-batch reason codes at DETAIL verbosity when failures exist.
        if (
            batch_statuses
            and batches_failed > 0
            and self._ctx.config.verbosity >= VerbosityLevel.DETAIL
        ):
            codes = ", ".join(
                f"B{i}:{s}" for i, s in enumerate(batch_statuses)
            )
            self._ctx._print(f"    Batch outcomes: {codes}", style="dim")

    def parallel_batch_fallback(self, stage: str, *, error: str) -> None:
        """Emit a console warning when parallel processing fails entirely.

        Args:
            stage: Stage name (e.g. "examine", "revise").
            error: Error description.
        """
        self._ctx._print(
            f"  Parallel {stage} failed: {error}",
            style="bold red",
        )

    def refinement_scope_summary(
        self,
        cycle: int,
        *,
        scope_items: int,
        total_items: int,
        scope_mode: str,
        blocking_count: int,
        prev_blocking_count: int | None = None,
    ) -> None:
        """Emit a one-line refinement scope summary each examine/revise cycle.

        Args:
            cycle: Current refinement cycle number (1-based).
            scope_items: Items in examination scope this cycle.
            total_items: Total plan items.
            scope_mode: Scope mode (e.g. "strict", "scoped", "full").
            blocking_count: Current blocking issue count.
            prev_blocking_count: Previous cycle's blocking count (for trend).
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        trend = ""
        if prev_blocking_count is not None:
            if blocking_count < prev_blocking_count:
                trend = f" (down from {prev_blocking_count})"
            elif blocking_count > prev_blocking_count:
                trend = f" (up from {prev_blocking_count})"
            else:
                trend = " (unchanged)"
        scope_label = f"{scope_items}/{total_items}" if scope_items < total_items else "full"
        self._ctx._print(
            f"  Cycle {cycle}: scope {scope_label} ({scope_mode}), "
            f"blocking {blocking_count}{trend}",
            style="cyan",
        )

    # ------------------------------------------------------------------ #
    # Error / warning / decomposition                                    #
    # ------------------------------------------------------------------ #

    def error(
        self,
        message: str,
        hint: str | None = None,
        phase: str | None = None,
        affected_items: list | None = None,
        stack_trace: str | None = None,
        raw_response: dict | None = None,
    ) -> None:
        """Display error with detail based on verbosity level.

        Args:
            message: Error message
            hint: Recovery hint (shown at all levels)
            phase: Current phase when error occurred (shown at PROGRESS+)
            affected_items: Plan items affected by error (shown at DETAIL+)
            stack_trace: Full stack trace (shown at DEBUG only)
            raw_response: Raw server/LLM response (shown at DEBUG only)
        """
        timestamp = self._ctx._timestamp()

        # Level 0 (QUIET): Basic error + hint
        self._ctx._print(f"Error: {message}", style="bold red")
        if hint:
            self._ctx._print(f"Hint: {hint}", style="yellow")

        # Level 1 (PROGRESS): + timestamp + phase context
        if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS:
            if timestamp:
                self._ctx._print(f"{timestamp}Error occurred", style="dim")
            if phase:
                self._ctx._print(f"Phase: {phase}", style="dim")

        # Level 2 (DETAIL): + affected items
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._ctx._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "untitled")
                self._ctx._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._ctx._print("[DEBUG] Stack trace:", style="dim")
                for line in str(stack_trace).splitlines():
                    self._ctx._print(line, style="dim")
            if raw_response:
                self._ctx._print("[DEBUG] Raw response:", style="dim")
                self._ctx._print(str(raw_response), style="dim")

    def warning(self, message: str) -> None:
        """Display a warning message."""
        timestamp = self._ctx._timestamp()
        if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS and timestamp:
            self._ctx._print(f"{timestamp}Warning", style="dim")
        self._ctx._print(f"Warning: {message}", style="yellow")

    def decomposition_warning(
        self,
        elapsed_s: int,
        warning_threshold_s: int,
        duration_threshold_s: int | None = None,
    ) -> None:
        """Emit warning when execution nears decomposition threshold."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._ctx._timestamp()
        if duration_threshold_s is not None and duration_threshold_s > 0:
            message = (
                f"[decompose] Long-running task: {elapsed_s}s; "
                f"will decompose at {duration_threshold_s}s if still running."
            )
        else:
            message = (
                f"[decompose] Long-running task: {elapsed_s}s "
                f"(warning at {warning_threshold_s}s)."
            )
        self._ctx._print(
            f"{timestamp}{message}",
            style="yellow",
        )

    def decomposition_triggered(self) -> None:
        """Emit notice when adaptive decomposition is triggered."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}-> Task running longer than expected; decomposing into subtasks...",
            style="yellow",
        )

    def interactive_guard_notice(
        self,
        message: str,
        affected_items: list[dict] | None = None,
        stack_trace: str | None = None,
        raw_response: str | None = None,
    ) -> None:
        """Display an interactive guard notice."""
        timestamp = self._ctx._timestamp()
        if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS and timestamp:
            self._ctx._print(f"{timestamp}Interactive guard", style="dim")
        self._ctx._print(f"Interactive guard: {message}", style="yellow")

        # Level 2 (DETAIL): + affected items + partial results
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._ctx._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "unknown")
                self._ctx._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._ctx._print("[DEBUG] Stack trace:", style="dim")
                for line in stack_trace.split("\n"):
                    if line.strip():
                        self._ctx._print(f"  {line}", style="dim")
            if raw_response:
                self._ctx._print("[DEBUG] Raw response:", style="dim")
                self._ctx._print(str(raw_response), style="dim")
