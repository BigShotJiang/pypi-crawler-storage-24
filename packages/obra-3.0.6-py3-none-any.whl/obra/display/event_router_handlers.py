"""Family handlers for progress event routing."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from obra.display.observability import ProgressEmitter


@dataclass(frozen=True)
class EventRouteContext:
    """Shared routing context for progress-event family handlers."""

    progress_emitter: ProgressEmitter
    action: str
    payload: dict[str, Any]


# Sub-events already represented by structured handlers (e.g., [Preflight] messages,
# dependency scan table). Suppress at all verbosity levels to avoid duplicate noise.
_SUPPRESSED_PROGRESS_EVENTS: set[str] = {
    "automation_mode_selected",
    "story0_dependency_resolution_mode",
    "story0_prereq_reclassified",
    "dependency_detect",
    "dependency_present",
    "dependency_prompt",
    "prompt_skipped_reason",
    "dependency_execute",
    "dependency_verify",
    "dependency_report",
    "dependency_mission_summary",
    "invocation_recorded",
    "story0_dependency_resolution_summary",
}


def dispatch_progress_event(context: EventRouteContext) -> bool:
    """Dispatch a progress event through named event families."""
    for family_handler in _EVENT_FAMILY_HANDLERS:
        if family_handler(context):
            return True
    return False


def is_suppressed_progress_event(action: str) -> bool:
    """Return whether the action should stay silent at every verbosity."""
    return action in _SUPPRESSED_PROGRESS_EVENTS


def _route_lifecycle_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "phase_started":
        phase = payload.get("phase", "UNKNOWN")
        progress_emitter.phase_started(phase, payload.get("context"))
        return True
    if action == "phase_completed":
        phase = payload.get("phase", "UNKNOWN")
        duration_ms = payload.get("duration_ms", 0)
        result = payload.get("result")
        progress_emitter.phase_completed(phase, result, duration_ms)
        if phase == "DERIVATION" and isinstance(result, dict):
            item_count = result.get("item_count")
            plan_version = result.get("plan_version")
            if isinstance(item_count, int) and item_count > 0:
                progress_emitter.set_total_tasks(
                    item_count,
                    plan_version=(
                        plan_version if isinstance(plan_version, int) else None
                    ),
                )
            items = result.get("items")
            if isinstance(items, list):
                progress_emitter.set_plan_items(items)
        return True
    if action == "plan_total":
        total = payload.get("total") or payload.get("total_tasks")
        plan_version = payload.get("plan_version")
        if isinstance(total, int):
            progress_emitter.set_total_tasks(
                total,
                plan_version=plan_version if isinstance(plan_version, int) else None,
            )
        return True
    if action == "llm_started":
        progress_emitter.llm_started(payload.get("purpose", "LLM invocation"))
        return True
    if action == "llm_streaming":
        progress_emitter.llm_streaming(payload.get("chunk", ""))
        return True
    if action == "llm_completed":
        progress_emitter.llm_completed(
            payload.get("summary", ""),
            payload.get("tokens", 0),
        )
        return True
    if action == "stage_started":
        progress_emitter.stage_started(
            payload.get("stage", "unknown"),
            payload.get("context"),
        )
        return True
    if action == "planning_started":
        progress_emitter.planning_started(str(payload.get("objective", "")))
        return True
    if action == "planning_stage_started":
        progress_emitter.planning_stage_started(
            str(payload.get("stage", "unknown")),
            str(payload.get("user_label", "")),
        )
        return True
    if action == "workflow_derivation_stage_started":
        progress_emitter.planning_stage_started(
            str(payload.get("stage", "unknown")),
            str(payload.get("label", payload.get("user_label", ""))),
        )
        return True
    if action == "planning_stage_completed":
        duration_s = payload.get("duration_s", 0.0)
        summary = payload.get("summary")
        progress_emitter.planning_stage_completed(
            str(payload.get("stage", "unknown")),
            str(payload.get("user_label", "")),
            float(duration_s) if isinstance(duration_s, (int, float)) else 0.0,
            str(summary) if summary else None,
        )
        return True
    if action == "workflow_derivation_stage_completed":
        duration_s = payload.get("duration_s", 0.0)
        summary = payload.get("summary")
        progress_emitter.planning_stage_completed(
            str(payload.get("stage", "unknown")),
            str(payload.get("label", payload.get("user_label", ""))),
            float(duration_s) if isinstance(duration_s, (int, float)) else 0.0,
            str(summary) if summary else None,
        )
        return True
    if action == "stage_completed":
        progress_emitter.stage_completed(
            payload.get("stage", "unknown"),
            payload.get("result"),
            payload.get("duration_ms", 0),
        )
        return True
    if action == "stage_failed":
        progress_emitter.stage_failed(
            payload.get("stage", "unknown"),
            str(payload.get("error", "unknown error")),
            payload.get("duration_ms", 0),
            payload.get("timeout_s"),
        )
        return True
    if action == "stage_heartbeat":
        progress_emitter.stage_heartbeat(
            payload.get("stage", "unknown"),
            int(payload.get("elapsed_s", payload.get("elapsed", 0))),
        )
        return True
    return False


def _route_derivation_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "derivation_step_heartbeat":
        return True
    if action in ("epic_derivation_recovery", "epic_serialization_recovery"):
        return True
    if action == "derivation_step_started":
        progress_emitter.derivation_step_started(
            payload.get("step", 1),
            payload.get("step_name", "unknown"),
        )
        return True
    if action == "epic_derivation_started":
        progress_emitter.epic_derivation_started(
            int(payload.get("epic_index", 1)),
            int(payload.get("epic_count", 1)),
            str(payload.get("epic_id", "E1")),
            str(payload.get("epic_title", "Untitled")),
        )
        return True
    if action == "epic_derivation_completed":
        epic_title = payload.get("epic_title")
        progress_emitter.epic_derivation_completed(
            int(payload.get("epic_index", 1)),
            int(payload.get("epic_count", 1)),
            str(payload.get("epic_id", "E1")),
            str(epic_title) if epic_title is not None else None,
            int(payload.get("stories_derived", 0)),
            int(payload.get("tasks_derived", 0)),
        )
        return True
    if action == "epic_derivation_heartbeat":
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        progress_emitter.epic_derivation_heartbeat(
            int(payload.get("epic_index", 1)),
            int(payload.get("epic_count", 1)),
            str(payload.get("epic_title", "Untitled")),
            int(payload.get("items_so_far", 0)),
            int(elapsed_s) if isinstance(elapsed_s, (int, float)) else 0,
        )
        return True
    if action == "epic_serialization_batch_started":
        progress_emitter.epic_serialization_batch_started(
            int(payload.get("epic_count", 1)),
            int(payload.get("max_concurrent", 4)),
        )
        return True
    if action == "epic_serialization_completed":
        progress_emitter.epic_serialization_completed(
            int(payload.get("epic_index", 1)),
            int(payload.get("epic_count", 1)),
            str(payload.get("epic_id", "E1")),
            str(payload.get("epic_title", "Untitled")),
            int(payload.get("items_serialized", 0)),
        )
        return True
    if action == "derivation_step_completed":
        progress_emitter.derivation_step_completed(
            payload.get("step", 1),
            payload.get("step_name", "unknown"),
            payload.get("duration_ms", 0),
            payload.get("items_produced", 0),
            payload.get("prose"),
            payload.get("raw_json"),
        )
        return True
    if action == "derivation_step_failed":
        progress_emitter.derivation_step_failed(
            payload.get("step", 1),
            payload.get("step_name", "unknown"),
            payload.get("error", "unknown error"),
            payload.get("duration_ms", 0),
        )
        return True
    if action == "derivation_stall_warning":
        progress_emitter.derivation_stall_warning(
            payload.get("step", 1),
            payload.get("step_name", "unknown"),
            payload.get("no_output_seconds", 0),
        )
        return True
    if action == "derivation_streaming_heartbeat":
        progress_emitter.derivation_streaming_heartbeat(
            payload.get("step", 1),
            payload.get("elapsed_seconds", 0),
        )
        return True
    if action == "derivation_validation_started":
        progress_emitter.derivation_validation_started(
            payload.get("pass", 1),
            payload.get("max_passes", 1),
        )
        return True
    if action == "derivation_validation_completed":
        progress_emitter.derivation_validation_completed(
            payload.get("pass", 1),
            payload.get("violations", 0),
            payload.get("passed", False),
        )
        return True
    if action == "stage_summary":
        return True
    return False


def _route_review_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "item_started":
        progress_emitter.item_started(payload.get("item", {}))
        return True
    if action == "item_completed":
        progress_emitter.item_completed(
            payload.get("item", {}),
            payload.get("result"),
        )
        return True
    if action == "item_skipped":
        progress_emitter.item_skipped(payload.get("item", {}))
        return True
    if action in ("item_heartbeat", "heartbeat"):
        item_id = payload.get("item_id") or payload.get("item", {}).get("id")
        if not item_id:
            return True
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        file_count = payload.get("file_count", payload.get("files_changed", 0))
        liveness = payload.get("liveness_indicators") or payload.get("liveness")
        progress_emitter.item_heartbeat(
            str(item_id),
            int(elapsed_s) if isinstance(elapsed_s, (int, float)) else 0,
            int(file_count) if isinstance(file_count, (int, float)) else 0,
            liveness if isinstance(liveness, dict) else None,
        )
        return True
    if action == "review":
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.set_review_context(
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return True
    if action == "file_event":
        filepath = payload.get("filepath") or payload.get("path")
        event_type = payload.get("event_type")
        if filepath and event_type:
            progress_emitter.file_event(
                filepath,
                event_type,
                payload.get("line_count"),
            )
        return True
    if action == "review_loop_started":
        agent_count = payload.get("agent_count")
        parallel = payload.get("parallel")
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.review_loop_started(
            int(payload.get("attempt", 1)),
            int(payload.get("max_attempts", 0)),
            agent_count=(
                int(agent_count) if isinstance(agent_count, (int, float)) else None
            ),
            parallel=bool(parallel) if isinstance(parallel, bool) else None,
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return True
    if action == "review_agent_started":
        agent_name = payload.get("agent_name") or payload.get("agent")
        if agent_name:
            progress_emitter.review_agent_started(str(agent_name))
        return True
    if action == "review_agent_completed":
        agent_name = payload.get("agent_name") or payload.get("agent")
        if not agent_name:
            return True
        status = str(payload.get("status", "")).lower()
        passed = payload.get("passed")
        if passed is None:
            passed = status in ("complete", "pass", "passed")
        details = payload.get("details") or payload.get("error_message")
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.review_agent_completed(
            str(agent_name),
            bool(passed),
            details,
            status=status or None,
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return True
    if action == "review_no_fixes":
        item_id = payload.get("item_id")
        progress_emitter.review_no_fixes(str(item_id) if item_id else None)
        return True
    if action == "fix_started":
        issue_count = payload.get("issue_count")
        if issue_count is not None:
            progress_emitter.fix_started(int(issue_count))
        return True
    if action == "fix_completed":
        progress_emitter.fix_completed(
            int(payload.get("fixed", 0)),
            int(payload.get("failed", 0)),
            int(payload.get("skipped", 0)),
        )
        return True
    if action == "fix_cycle_cap_reached":
        item_id = payload.get("item_id", "unknown")
        fix_cycles = payload.get("fix_cycles", "?")
        quality_score = payload.get("quality_score", "?")
        has_high_severity = payload.get("has_high_severity", False)
        resolution = (
            "high-severity blockers remain; escalation policy will decide next action"
            if has_high_severity
            else "accepting"
        )
        progress_emitter.warning(
            f"Fix cycle cap reached for {item_id} after {fix_cycles} cycles "
            f"(score {quality_score}) — {resolution}"
        )
        return True
    if action == "stabilization_auto_accept":
        raw_threshold = payload.get("threshold")
        raw_threshold_ratio = payload.get("threshold_ratio")
        progress_emitter.stabilization_auto_accept(
            item_id=str(payload.get("item_id")) if payload.get("item_id") else "unknown",
            quality_score=(
                float(payload.get("quality_score"))
                if isinstance(payload.get("quality_score"), (int, float))
                else 0.0
            ),
            fix_cycles=(
                int(payload.get("fix_cycles"))
                if isinstance(payload.get("fix_cycles"), (int, float))
                else 0
            ),
            reason=(
                str(payload.get("reason"))
                if payload.get("reason")
                else "only_deferred_non_critical_remain"
            ),
            threshold=(
                int(raw_threshold) if isinstance(raw_threshold, (int, float)) else None
            ),
            threshold_ratio=(
                float(raw_threshold_ratio)
                if isinstance(raw_threshold_ratio, (int, float))
                else None
            ),
        )
        return True
    if action == "review_filter_applied":
        progress_emitter.review_filter_applied(
            removed_count=int(payload.get("removed_count", 0)),
            adjusted_count=int(payload.get("adjusted_count", 0)),
            kept_count=int(payload.get("kept_count", 0)),
            enriched_count=int(payload.get("enriched_count", 0)),
            item_id=(
                str(payload.get("item_id"))
                if payload.get("item_id") is not None
                else None
            ),
            review_cycle_id=(
                str(payload.get("review_cycle_id"))
                if payload.get("review_cycle_id") is not None
                else None
            ),
        )
        return True
    if action == "scorecard_available":
        _route_scorecard_available(progress_emitter, payload)
        return True
    if action == "scorecard_warning":
        message = payload.get("message")
        if message:
            progress_emitter.scorecard_warning(str(message))
        return True
    if action == "review_indeterminate":
        item_id = payload.get("item_id")
        reason = payload.get("decision_reason")
        progress_emitter.review_indeterminate(
            item_id=str(item_id) if item_id else None,
            reason=str(reason) if reason else None,
        )
        return True
    return False


def _route_session_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "session_completed":
        progress_emitter.session_completed(
            int(payload.get("items_completed"))
            if isinstance(payload.get("items_completed"), (int, float))
            else 0,
            float(payload.get("quality_score"))
            if isinstance(payload.get("quality_score"), (int, float))
            else 0.0,
            str(payload.get("session_summary")) if payload.get("session_summary") else "",
            was_escalated=bool(payload.get("was_escalated", False)),
        )
        return True
    if action == "plan_snapshot":
        plan_items = payload.get("plan_items")
        if isinstance(plan_items, list):
            source = payload.get("source")
            progress_emitter.update_plan_snapshot(
                plan_items,
                source=str(source) if source is not None else None,
                session_id=payload.get("session_id"),
                mode=payload.get("mode"),
            )
        return True
    if action == "refinement_batch_completed":
        batch_index = payload.get("batch_index", 0)
        batch_size = payload.get("batch_size", 0)
        batches_done = payload.get("batches_done", 0)
        batches_total = payload.get("batches_total", 0)
        elapsed_ms = payload.get("elapsed_ms", 0)
        progress_emitter.examine_batch_progress(
            batch_index=(
                int(batch_index) if isinstance(batch_index, (int, float)) else 0
            ),
            batch_size=int(batch_size) if isinstance(batch_size, (int, float)) else 0,
            batches_done=(
                int(batches_done) if isinstance(batches_done, (int, float)) else 0
            ),
            batches_total=(
                int(batches_total) if isinstance(batches_total, (int, float)) else 0
            ),
            elapsed_ms=(
                float(elapsed_ms) if isinstance(elapsed_ms, (int, float)) else 0.0
            ),
            status=str(payload.get("status", "success")),
            phase=str(payload.get("phase", "examine")),
        )
        return True
    if action == "revision_batch_progress":
        from obra.display import print_info

        print_info(
            "Revision batch "
            f"{payload.get('batch_index', 0)}/{payload.get('total_batches', 0)}: "
            f"{payload.get('items_revised', 0)} items processed"
        )
        return True
    if action == "execute":
        plan_items = payload.get("plan_items")
        if isinstance(plan_items, list):
            progress_emitter.update_plan_snapshot(
                plan_items,
                source="execute",
                session_id=payload.get("session_id"),
                mode="tracker_sync",
            )
        return True
    if action == "story0_started":
        progress_emitter.story0_started()
        return True
    if action == "story0_prerequisite_status":
        reason = payload.get("reason")
        progress_emitter.story0_prerequisite_status(
            str(payload.get("category", "")),
            str(payload.get("name", "")),
            str(payload.get("status", "")),
            str(reason) if reason else None,
        )
        return True
    if action == "story0_message":
        message = payload.get("message", "")
        if message:
            progress_emitter.story0_message(str(message))
        return True
    if action == "story0_completed":
        progress_emitter.story0_completed(
            int(payload.get("blocking_failures", 0)),
            int(payload.get("non_blocking_warnings", 0)),
        )
        return True
    if action == "story0_blocked":
        failures_summary = payload.get("failures_summary", "")
        if failures_summary:
            progress_emitter.story0_blocked(str(failures_summary))
        return True
    if action == "debug_tokens":
        source = payload.get("source")
        progress_emitter.debug_tokens(
            int(payload.get("total", 0)),
            int(payload.get("input", 0)),
            int(payload.get("output", 0)),
            str(source) if source else None,
        )
        return True
    if action == "debug_quality":
        message = payload.get("message", "")
        if message:
            progress_emitter.debug_quality(str(message))
        return True
    return False


def _route_verification_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "code_verify_started":
        item_id = payload.get("item_id")
        progress_emitter.code_verify_started(str(item_id) if item_id else None)
        return True
    if action == "code_verify_completed":
        tools_used = payload.get("tools_used", [])
        if not isinstance(tools_used, list):
            tools_used = []
        item_id = payload.get("item_id")
        progress_emitter.code_verify_completed(
            status=str(payload.get("status", "inconclusive")),
            tools_used=[str(tool) for tool in tools_used if str(tool).strip()],
            pass_count=(
                int(payload.get("pass_count"))
                if isinstance(payload.get("pass_count"), (int, float))
                else 0
            ),
            fail_count=(
                int(payload.get("fail_count"))
                if isinstance(payload.get("fail_count"), (int, float))
                else 0
            ),
            inconclusive_count=(
                int(payload.get("inconclusive_count"))
                if isinstance(payload.get("inconclusive_count"), (int, float))
                else 0
            ),
            item_id=str(item_id) if item_id else None,
        )
        return True
    if action == "verification_preflight_started":
        progress_emitter.verification_preflight_started(
            str(
                payload.get("message")
                or "Verification tools missing → running preflight"
            )
        )
        return True
    if action == "verification_preflight_installing":
        progress_emitter.verification_preflight_installing(
            str(payload.get("message") or "Installing verification tools")
        )
        return True
    if action == "verification_preflight_completed":
        progress_emitter.verification_preflight_completed(
            str(payload.get("message") or "Verification preflight complete")
        )
        return True
    return False


def _route_alignment_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "story_review_started":
        progress_emitter.story_review_started(
            payload.get("story_id", ""),
            payload.get("story_title", ""),
            payload.get("story_index", 0),
            payload.get("total_stories", 0),
            payload.get("task_count", 0),
        )
        return True
    if action == "story_review_batch_started":
        progress_emitter.story_review_batch_started(
            int(payload.get("story_count", 0)),
            int(payload.get("max_concurrent", 4)),
        )
        return True
    if action == "story_review_completed":
        issues = payload.get("issues", [])
        progress_emitter.story_review_completed(
            payload.get("story_id", ""),
            payload.get("story_title", ""),
            payload.get("story_index", 0),
            payload.get("total_stories", 0),
            payload.get("changes_required", False),
            payload.get("issue_count", 0),
            payload.get("duration_s", 0.0),
        )
        if issues:
            progress_emitter.review_issues_found(
                payload.get("story_id", ""),
                payload.get("story_title", ""),
                issues,
            )
        return True
    if action == "intent_alignment_started":
        progress_emitter.intent_alignment_started(
            payload.get("epic_count", 0),
            payload.get("story_count", 0),
        )
        return True
    if action == "intent_story_batch_started":
        progress_emitter.intent_story_batch_started(
            int(payload.get("story_count", 0)),
            int(payload.get("max_concurrent", 4)),
        )
        return True
    if action == "intent_story_assessed":
        progress_emitter.intent_story_assessed(
            payload.get("story_id", ""),
            payload.get("story_title", ""),
            payload.get("story_index", 0),
            payload.get("total_stories", 0),
            payload.get("status", "ok"),
            payload.get("note", ""),
        )
        return True
    if action == "intent_story_added":
        progress_emitter.intent_story_added(
            payload.get("title", ""),
            payload.get("parent_id"),
        )
        return True
    if action == "intent_gap_detection_started":
        progress_emitter.intent_gap_detection_started(payload.get("story_count", 0))
        return True
    if action == "intent_gap_detection_completed":
        progress_emitter.intent_gap_detection_completed(
            payload.get("gaps_found", False),
            payload.get("missing_count", 0),
            payload.get("stories_to_add", 0),
            payload.get("duration_s", 0.0),
        )
        return True
    if action == "intent_alignment_completed":
        progress_emitter.intent_alignment_completed(
            payload.get("coverage_status", ""),
            payload.get("changes_required", False),
            payload.get("missing_count", 0),
            payload.get("scope_creep_count", 0),
            payload.get("stories_added", 0),
            payload.get("stories_removed", 0),
            payload.get("duration_s", 0.0),
        )
        return True
    if action == "intent_alignment_fixes_applied":
        progress_emitter.intent_alignment_fixes_applied(
            payload.get("stories_added", []),
            payload.get("stories_removed", []),
        )
        return True
    return False


def _route_error_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "error":
        progress_emitter.error(
            payload.get("message", "Unknown error"),
            payload.get("hint"),
            payload.get("phase"),
            payload.get("affected_items"),
            payload.get("stack_trace"),
            payload.get("raw_response"),
        )
        return True
    if action in (
        "interactive_guard_triggered",
        "interactive_guard_rollback",
        "interactive_guard_retry",
    ):
        message = payload.get("message")
        if not message:
            message = "Interactive guard event recorded."
        progress_emitter.interactive_guard_notice(message)
        return True
    return False


def _route_scorecard_available(
    progress_emitter: ProgressEmitter,
    payload: dict[str, Any],
) -> None:
    component_scores = payload.get("component_scores_normalized")
    issue_counts = payload.get("issue_counts")
    legacy_scores = payload.get("scores") or {}
    score_units = str(payload.get("score_units", "")).strip().lower()
    total = payload.get("total")
    threshold = payload.get("threshold")
    item_id = payload.get("item_id")
    review_cycle_id = payload.get("review_cycle_id")
    scorecard_source = payload.get("scorecard_source")
    filtered_issue_count = payload.get("filtered_issue_count")
    review_filter_applied = bool(payload.get("review_filter_applied", False))
    scorecard_status = payload.get("status")
    decision_state = payload.get("decision_state")
    failed_agents = payload.get("failed_agents")
    degraded = payload.get("degraded")
    total_agents = payload.get("total_agents")
    if total is None and "compiled_score" in payload:
        total = round(float(payload.get("compiled_score", 0)) * 100)
    if threshold is None and "threshold_ratio" in payload:
        threshold = round(float(payload.get("threshold_ratio", 0)) * 100)

    normalized_scores: dict[str, int] = {}
    if isinstance(component_scores, dict):
        for name, value in component_scores.items():
            try:
                normalized_scores[str(name)] = round(float(value))
            except (TypeError, ValueError):
                continue

    parsed_issue_counts: dict[str, int] = {}
    if isinstance(issue_counts, dict):
        for name, value in issue_counts.items():
            try:
                parsed_issue_counts[str(name)] = int(value)
            except (TypeError, ValueError):
                continue

    if isinstance(legacy_scores, dict):
        if not normalized_scores and score_units in {"normalized_100", "percent_100"}:
            for name, value in legacy_scores.items():
                try:
                    normalized_scores[str(name)] = round(float(value))
                except (TypeError, ValueError):
                    continue
        elif not normalized_scores and score_units in {"ratio_0_1", "ratio"}:
            for name, value in legacy_scores.items():
                try:
                    normalized_scores[str(name)] = round(float(value) * 100)
                except (TypeError, ValueError):
                    continue
        elif not normalized_scores and not score_units:
            numeric_values: list[float] = []
            for value in legacy_scores.values():
                try:
                    numeric_values.append(float(value))
                except (TypeError, ValueError):
                    numeric_values = []
                    break
            if numeric_values and all(0.0 <= value <= 1.0 for value in numeric_values):
                has_fractional_score = any(
                    value not in (0.0, 1.0) for value in numeric_values
                )
                if has_fractional_score:
                    for name, value in legacy_scores.items():
                        try:
                            normalized_scores[str(name)] = round(float(value) * 100)
                        except (TypeError, ValueError):
                            continue
        elif not parsed_issue_counts:
            for name, value in legacy_scores.items():
                try:
                    parsed_issue_counts[str(name)] = int(value)
                except (TypeError, ValueError):
                    continue

    if total is None or threshold is None:
        return

    progress_emitter.scorecard_available(
        normalized_scores,
        int(total),
        int(threshold),
        item_id=str(item_id) if item_id else None,
        review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        issue_counts=parsed_issue_counts or None,
        scorecard_source=str(scorecard_source) if scorecard_source else None,
        filtered_issue_count=(
            int(filtered_issue_count)
            if isinstance(filtered_issue_count, (int, float))
            else None
        ),
        review_filter_applied=review_filter_applied,
        status=str(scorecard_status) if scorecard_status else None,
        decision_state=str(decision_state) if decision_state else None,
        failed_agents=(
            int(failed_agents) if isinstance(failed_agents, (int, float)) else None
        ),
        degraded=bool(degraded) if degraded is not None else None,
        total_agents=(
            int(total_agents) if isinstance(total_agents, (int, float)) else None
        ),
        skipped_agents=(
            int(payload.get("skipped_agents"))
            if isinstance(payload.get("skipped_agents"), (int, float))
            else None
        ),
    )


_EVENT_FAMILY_HANDLERS = (
    _route_lifecycle_event,
    _route_derivation_event,
    _route_review_event,
    _route_session_event,
    _route_verification_event,
    _route_alignment_event,
    _route_error_event,
)


__all__ = [
    "EventRouteContext",
    "dispatch_progress_event",
    "is_suppressed_progress_event",
]
