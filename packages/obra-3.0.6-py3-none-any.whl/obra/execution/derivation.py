"""Derivation engine for breaking down objectives into implementation plans.

This module provides the DerivationEngine class that uses LLM invocation
to transform high-level objectives into structured implementation plans.

The engine:
    1. Gathers project context (files, structure, README)
    2. Builds a derivation prompt with context and constraints
    3. Invokes LLM with optional extended thinking
    4. Parses structured output into plan items

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/hybrid/handlers/derive.py (handler layer)
    - obra/llm/invoker.py (LLM invocation)
    - src/derivation/engine.py (CLI implementation reference)
"""

import json
import logging
import os
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_derivation_epic_item_rederive_threshold,
    get_derivation_epic_output_token_limit,
    get_derivation_preview_config,
    get_derivation_serialize_max_concurrent,
    get_derivation_step3_tier,
    get_derivation_story_range,
    get_derivation_strict_story_range,
    get_derivation_strict_task_range,
    get_derivation_task_range,
)

# ISSUE-DERIVE-001: Removed get_derivation_step_timeout import.
# Post-hoc timeout checks cannot detect actual stalls (only duration after completion).
# Real stall detection is handled by MonitoringThread during subprocess execution.
from obra.core.interrupts import interrupt_requested
from obra.execution.derivation_pipeline import (
    DerivationContextBuilder,
    DerivationPromptBuilder,
    DerivationSerializationService,
)
from obra.exceptions import DerivationStallError, ObraError

# DEPRECATED: Import from obra.exploration.detection directly
from obra.exploration.detection import (
    EXPLORATION_LOOKBACK_MINUTES,
    detect_recent_exploration,
)
from obra.hybrid.json_utils import parse_planning_json_response
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.prompts.derive.derivation import (
    build_derivation_prompt,
    build_four_phase_guidance,
    build_refinement_prompt,
    build_step1_epics_only_prompt,
    build_step1_epics_template,
    build_step2_per_epic_prompt,
    build_step2_per_epic_template,
    build_step2_prompt,
    build_step2_repair_prompt,
    build_step2_repair_template,
    build_step3_per_epic_prompt,
    build_step3_per_epic_prompt_strict,
    build_step3_prompt,
    get_pattern_guidance,
)
from obra.workflow.derivation.domain_metadata import (
    classify_work_type_from_metadata,
    resolve_domain_derivation_metadata,
)

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker

logger = logging.getLogger(__name__)

ITEM_COUNT_WARNING_THRESHOLDS = (25, 50, 100, 200, 500, 1000)

# DEPRECATED: Use get_derivation_preview_config() from obra.config.loaders
# These constants are kept for backwards compatibility only
_preview_config = get_derivation_preview_config()
README_PREVIEW_LIMIT = _preview_config["readme_limit"]
RAW_RESPONSE_PREVIEW_LIMIT = _preview_config["raw_response_limit"]
RAW_RESPONSE_WARN_LIMIT = _preview_config["raw_response_warn_limit"]

COMPOUND_VIOLATION_MARKER = "Title contains compound action word"

# DEPRECATED: Use get_derivation_epic_item_rederive_threshold() from obra.config.loaders
EPIC_ITEM_REDERIVE_THRESHOLD = get_derivation_epic_item_rederive_threshold()

EPIC_OUTPUT_TOKEN_LIMIT = get_derivation_epic_output_token_limit()

# S7.T5: Max depth limit for hierarchical derivation
# When a derived item would exceed this depth, it is created as a sibling
# of its parent instead of as a child. This prevents unbounded nesting
# while preserving context inheritance.
MAX_DERIVATION_DEPTH = 3

# SIZING_GUIDANCE is now imported from obra.prompts.derive.derivation

# Work phases (4-phase workflow)
VALID_PHASES = ["explore", "plan", "implement", "commit"]

# Work types that benefit from exploration phase
WORK_TYPES_NEEDING_EXPLORATION = [
    "feature_implementation",
    "refactoring",
    "integration",
]

# Phase-to-agent mapping (used when LLM doesn't specify agent)
# Aligned with Claude Code 4-phase workflow: Explore -> Plan -> Implement -> Commit
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",  # Use Explore subagent for codebase research
    "plan": None,  # Planning is orchestrator's job
    "implement": None,  # Normal Claude Code execution
    "commit": None,  # Finalization (test, commit, docs)
}


@dataclass
class DerivationResult:
    """Result from plan derivation.

    Attributes:
        plan_items: List of derived plan items
        raw_response: Raw LLM response for debugging
        work_type: Detected work type
        duration_seconds: Time taken for derivation
        first_pass_duration_seconds: Duration of first validation passes (hierarchical)
        total_pass_duration_seconds: Total duration across validation passes (hierarchical)
        pass_count: Total validation passes executed (hierarchical)
        leaf_total: Number of leaf items validated (hierarchical)
        leaf_compliant: Number of compliant leaf items (hierarchical)
        tokens_used: Estimated tokens used
        success: Whether derivation succeeded
        error_message: Error message if failed
    """

    plan_items: list[dict[str, Any]] = field(default_factory=list)
    raw_response: str = ""
    work_type: str = "general"
    duration_seconds: float = 0.0
    first_pass_duration_seconds: float | None = None
    total_pass_duration_seconds: float | None = None
    pass_count: int | None = None
    leaf_total: int | None = None
    leaf_compliant: int | None = None
    tokens_used: int = 0
    success: bool = True
    error_message: str = ""

    @property
    def item_count(self) -> int:
        """Number of derived plan items."""
        return len(self.plan_items)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "plan_items": self.plan_items,
            "raw_response": self.raw_response,
            "work_type": self.work_type,
            "duration_seconds": self.duration_seconds,
            "first_pass_duration_seconds": self.first_pass_duration_seconds,
            "total_pass_duration_seconds": self.total_pass_duration_seconds,
            "pass_count": self.pass_count,
            "leaf_total": self.leaf_total,
            "leaf_compliant": self.leaf_compliant,
            "tokens_used": self.tokens_used,
            "success": self.success,
            "error_message": self.error_message,
            "item_count": self.item_count,
        }


class DerivationEngine:
    """Engine for deriving implementation plans from objectives.

    Uses LLM invocation to break down high-level objectives into
    structured plan items (tasks/stories) with proper sequencing
    and dependencies.

    Example:
        >>> from obra.llm.invoker import LLMInvoker
        >>> invoker = LLMInvoker()
        >>> engine = DerivationEngine(
        ...     working_dir=Path("/path/to/project"),
        ...     llm_invoker=invoker,
        ... )
        >>> result = engine.derive("Add user authentication")
        >>> for item in result.plan_items:
        ...     print(f"{item['id']}: {item['title']}")

    Thread-safety:
        Thread-safe through LLMInvoker's thread safety guarantees.

    Related:
        - obra/hybrid/handlers/derive.py (handler layer)
        - obra/llm/invoker.py (LLM invocation)
    """

    def __init__(
        self,
        working_dir: Path,
        llm_invoker: Optional["LLMInvoker"] = None,
        thinking_enabled: bool = True,
        reasoning_level: str = "high",
        max_items: int = 20,
        domain: Any | None = None,
    ) -> None:
        """Initialize DerivationEngine.

        Args:
            working_dir: Working directory for file access
            llm_invoker: LLMInvoker instance for LLM calls
            thinking_enabled: Whether to use extended thinking
            reasoning_level: Reasoning level (off, minimal, standard, high, maximum)
            max_items: Advisory target for plan item count (prompt guidance only; no truncation)
        """
        self._working_dir = working_dir
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._reasoning_level = reasoning_level
        self._max_items = max_items
        self._domain = domain
        self._strategic_prompt: str | None = None
        self._intent_markdown: str | None = None
        self._exploration_context: str | None = None
        self._context_builder = DerivationContextBuilder(self)
        self._prompt_builder = DerivationPromptBuilder(self)
        self._serialization = DerivationSerializationService(self)

        logger.debug(
            f"DerivationEngine initialized: working_dir={working_dir}, "
            f"thinking_enabled={thinking_enabled}, reasoning_level={reasoning_level}"
        )

    def derive(
        self,
        objective: str,
        project_context: dict[str, Any] | None = None,
        constraints: dict[str, Any] | None = None,
        provider: str = "anthropic",
        strategic_prompt: str | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> DerivationResult:
        """Derive implementation plan from objective using unified 3-step pipeline.

        The unified pipeline breaks derivation into three sequential steps:
        1. Structure: Derive high-level Epics and Stories (prose)
        2. Tasks: Add task-level detail to each story (prose)
        3. Serialize: Convert complete prose plan to structured JSON

        Args:
            objective: Task objective to plan for
            project_context: Optional project context (languages, frameworks)
            constraints: Optional derivation constraints
            provider: LLM provider to use
            strategic_prompt: Optional strategic guidance prompt
            intent_markdown: Optional intent markdown for context
            exploration_context: Optional exploration context markdown
            progress_callback: Optional callback for progress events

        Returns:
            DerivationResult with plan items and metadata

        Example:
            >>> result = engine.derive(
            ...     "Add user authentication",
            ...     project_context={"languages": ["python"]},
            ...     constraints={"max_items": 10},
            ... )
        """
        start_time = time.time()
        self._strategic_prompt = strategic_prompt
        self._intent_markdown = intent_markdown
        self._exploration_context = exploration_context
        emit_progress = progress_callback

        def _emit(action: str, payload: dict[str, Any]) -> None:
            if not emit_progress:
                return
            try:
                emit_progress(action, payload)
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Progress callback failed: %s", exc)

        try:
            # Detect work type
            work_type = self._detect_work_type(objective)

            # Gather local context
            context = self._gather_context(project_context or {})

            # Format context for prompt
            context_str = self._build_context_section(context)
            constraints_str = self._render_constraints(constraints)

            # Use unified 3-step derivation pipeline
            logger.info("Using unified 3-step derivation pipeline")
            plan_items, tokens_used = self._derive_multi_step_plan(
                objective=objective,
                project_context=context_str,
                constraints=constraints_str,
                provider=provider,
                progress_callback=_emit,
                validation_intensity=validation_intensity,
            )

            raw_response = json.dumps({"plan_items": plan_items})
            duration = time.time() - start_time

            logger.info(
                f"Derivation completed: {len(plan_items)} items, "
                f"{duration:.2f}s, work_type={work_type}"
            )

            return DerivationResult(
                plan_items=plan_items,
                raw_response=raw_response,
                work_type=work_type,
                duration_seconds=duration,
                tokens_used=tokens_used,
                success=True,
            )

        except Exception as exc:
            duration = time.time() - start_time
            logger.exception("Derivation failed")

            # Structured logging for pipeline failure (S5.T1)
            error_extra: dict[str, Any] = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            }

            # Extract step info if DerivationStallError
            if isinstance(exc, DerivationStallError):
                error_extra["failed_at_step"] = exc.step
                error_extra["step_name"] = exc.step_name
            else:
                # Generic failure - step unknown
                error_extra["failed_at_step"] = 0
                error_extra["step_name"] = "unknown"

            logger.exception(
                "derivation_pipeline_failed",
                extra=error_extra,
            )

            return DerivationResult(
                success=False,
                error_message=str(exc),
                duration_seconds=duration,
            )

    def _detect_work_type(self, objective: str) -> str:
        """Detect work type from objective text.

        Args:
            objective: Task objective

        Returns:
            Work type string
        """
        metadata = resolve_domain_derivation_metadata(self._domain)
        work_type = classify_work_type_from_metadata(objective, metadata)
        logger.debug("Detected work type using domain metadata: %s", work_type)
        return work_type

    @staticmethod
    def _render_constraints(constraints: dict[str, Any] | str | None) -> str:
        return DerivationContextBuilder.render_constraints(constraints)

    @staticmethod
    def _validate_step1_epics(content: dict, min_epics: int) -> tuple[bool, str | None]:
        return DerivationSerializationService.validate_step1_epics(content, min_epics)

    def _gather_context(self, project_context: dict[str, Any]) -> dict[str, Any]:
        return self._context_builder.gather_context(project_context)

    def _summarize_structure(self) -> list[str]:
        return self._context_builder.summarize_structure()

    def _build_prompt(
        self,
        objective: str,
        context: dict[str, Any],
        constraints: dict[str, Any],
        work_type: str,
    ) -> str:
        return self._prompt_builder.build_prompt(objective, context, constraints, work_type)

    def _build_context_section(self, context: dict[str, Any]) -> str:
        return self._context_builder.build_context_section(context)

    def _resolve_hierarchy_config(self, constraints: dict[str, Any] | None) -> dict[str, Any]:
        return self._prompt_builder.resolve_hierarchy_config(constraints)

    def _get_pattern_guidance(self, work_type: str) -> str:
        return self._prompt_builder.get_pattern_guidance(work_type)

    def _invoke_llm(
        self,
        prompt: str,
        provider: str,
        _work_type: str,
        response_format: str = "text",
    ) -> tuple[str, int]:
        """Invoke LLM to generate plan.

        Uses extended thinking (high reasoning_level) for supported models to
        improve plan quality. Falls back gracefully for models without extended
        thinking support.

        Args:
            prompt: Derivation prompt
            provider: LLM provider name
            work_type: Detected work type
            response_format: Expected response format ("text" or "json")

        Returns:
            Tuple of (raw_response, tokens_used)
        """
        if self._llm_invoker is None:
            logger.warning("No LLM invoker configured, returning placeholder")
            return self._placeholder_response(), 0

        # Determine reasoning level based on model capability
        reasoning_level = None
        if self._thinking_enabled:
            # Check if model supports extended thinking
            effective_reasoning_level = self._resolve_reasoning_level(provider)
            if effective_reasoning_level:
                reasoning_level = effective_reasoning_level
                logger.debug(
                    "Using %s reasoning level for derivation (provider=%s)",
                    reasoning_level,
                    provider,
                )

        # Invoke LLM
        result = self._llm_invoker.invoke(
            prompt=prompt,
            provider=provider,
            reasoning_level=reasoning_level,
            response_format=response_format,
        )

        # Log thinking token usage if available
        if result.thinking_tokens > 0:
            logger.debug(
                "Derivation used %d thinking tokens (total: %d tokens)",
                result.thinking_tokens,
                result.tokens_used,
            )

        return result.content, result.tokens_used

    def _build_step1_prompt(self, objective: str, constraints: str, context: str) -> str:
        return self._prompt_builder.build_step1_prompt(objective, constraints, context)

    def _build_step2_prompt(self, objective: str, prose_from_step_1: str) -> str:
        return self._prompt_builder.build_step2_prompt(objective, prose_from_step_1)

    def _build_step3_prompt(self, prose_from_step_2: str) -> str:
        return self._prompt_builder.build_step3_prompt(prose_from_step_2)

    def _normalize_epics(self, epics_data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return self._serialization.normalize_epics(epics_data)

    def _parse_epics_from_prose(self, epics_prose: str) -> list[dict[str, Any]]:
        return self._serialization.parse_epics_from_prose(epics_prose)

    @staticmethod
    def _extract_epics_from_prose(epics_prose: str) -> list[dict[str, Any]]:
        return DerivationSerializationService.extract_epics_from_prose(epics_prose)

    @staticmethod
    def _render_epics_prose(epics: list[dict[str, Any]]) -> str:
        return DerivationSerializationService.render_epics_prose(epics)

    @staticmethod
    def _extract_epic_story_task_titles(
        epic_detail_prose: str, epic_id: str
    ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
        return DerivationSerializationService.extract_epic_story_task_titles(
            epic_detail_prose,
            epic_id,
        )

    @staticmethod
    def _build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        return DerivationSerializationService.build_partial_plan_items(
            epic_id,
            epic_title,
            stories,
            tasks,
        )

    @staticmethod
    def _estimate_output_tokens(text: str) -> int:
        return DerivationSerializationService.estimate_output_tokens(text)

    @staticmethod
    def _validate_epic_prose(content: str, epic_id: str) -> tuple[bool, str | None]:
        return DerivationSerializationService.validate_epic_prose(content, epic_id)

    @staticmethod
    def _count_epic_story_task_ids(epic_detail_prose: str, epic_id: str) -> tuple[int, int]:
        return DerivationSerializationService.count_epic_story_task_ids(
            epic_detail_prose,
            epic_id,
        )

    @staticmethod
    def _count_epic_items(epic_detail_prose: str, epic_id: str | None = None) -> int:
        return DerivationSerializationService.count_epic_items(epic_detail_prose, epic_id)

    @staticmethod
    def _extract_reason_codes_for_epic(
        epic_detail_prose: str,
        epic_id: str,
        *,
        status: str = "",
        item_count: int | None = None,
        output_tokens: int | None = None,
    ) -> list[str]:
        return DerivationSerializationService.extract_reason_codes_for_epic(
            epic_detail_prose,
            epic_id,
            status=status,
            item_count=item_count,
            output_tokens=output_tokens,
        )

    @staticmethod
    def _write_epic_failure_artifact(
        working_dir: Path,
        *,
        epic_id: str,
        story_count: int,
        task_count: int,
        reason_codes: list[str],
        retry_metadata: dict[str, Any],
        output_preview: str,
    ) -> str | None:
        return DerivationSerializationService.write_epic_failure_artifact(
            working_dir,
            epic_id=epic_id,
            story_count=story_count,
            task_count=task_count,
            reason_codes=reason_codes,
            retry_metadata=retry_metadata,
            output_preview=output_preview,
        )

    def _merge_epic_details(self, epics_prose: str, all_epic_details: list[str]) -> str:
        return self._serialization.merge_epic_details(epics_prose, all_epic_details)

    def _serialize_per_epic(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        return self._serialization.serialize_per_epic(
            all_epic_details=all_epic_details,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
        )

    def _derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        return self._serialization.derive_per_epic(
            objective=objective,
            epics_prose=epics_prose,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
            intent_markdown=intent_markdown,
            exploration_context=exploration_context,
        )

    def _derive_multi_step_plan(
        self,
        objective: str,
        project_context: str,
        constraints: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> tuple[list[dict[str, Any]], int]:
        return self._serialization.derive_multi_step_plan(
            objective=objective,
            project_context=project_context,
            constraints=constraints,
            provider=provider,
            progress_callback=progress_callback,
            validation_intensity=validation_intensity,
        )

    def _parse_flat_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        return self._serialization.parse_flat_response_via_pipeline(prompt, provider)

    def _normalize_flat_plan_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return self._serialization.normalize_flat_plan_items(items)

    def _parse_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        return self._serialization.parse_response_via_pipeline(prompt, provider)

    def _normalize_hierarchical_plan_items(
        self, items: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        return self._serialization.normalize_hierarchical_plan_items(items)

    def _validate_plan_items(self, plan_items: list[dict[str, Any]]) -> list[str]:
        return self._serialization.validate_plan_items(plan_items)

    def _resolve_reasoning_level(self, provider: str) -> str | None:
        """Resolve the effective reasoning level for derivation.

        Checks if the model supports extended thinking and returns the
        appropriate reasoning level. Falls back gracefully for unsupported
        models.

        For supported models (Claude Opus/Sonnet), uses the configured
        reasoning_level (default: "high") to enable deep reasoning.

        For unsupported models (Haiku, other providers), returns None to
        disable extended thinking and avoid API errors.

        Args:
            provider: LLM provider name

        Returns:
            Reasoning level string ("high", "standard", etc.) or None if
            extended thinking is not supported/enabled.
        """
        if not self._thinking_enabled:
            return None

        # Check model capability if provider advertises support probing
        if self._llm_invoker is None:
            return None

        try:
            llm_provider = self._llm_invoker._get_provider(provider)
            if llm_provider is not None:
                # Get model name - either from invoker default or provider default
                model = llm_provider.default_model

                # Check if model supports extended thinking
                if hasattr(llm_provider, "supports_extended_thinking"):
                    if llm_provider.supports_extended_thinking(model):
                        logger.debug(
                            "Model %s supports extended thinking, using level=%s",
                            model,
                            self._reasoning_level,
                        )
                        return self._reasoning_level
                    logger.debug(
                        "Model %s does not support extended thinking, disabling",
                        model,
                    )
                    return None
        except Exception as e:
            logger.warning(
                "Failed to check extended thinking support: %s. "
                "Falling back to configured reasoning_level=%s",
                e,
                self._reasoning_level,
            )
            # Fall through to default behavior

        # For other providers or if capability check fails, use configured level
        # This maintains backward compatibility
        return self._reasoning_level

    def _placeholder_response(self) -> str:
        """Generate placeholder response when no LLM available.

        Returns:
            Placeholder JSON response
        """
        return json.dumps(
            {
                "plan_items": [
                    {
                        "id": "T1",
                        "item_type": "task",
                        "title": "Placeholder task",
                        "description": "LLM invoker not configured - configure via obra/llm/invoker.py",
                        "acceptance_criteria": ["LLM invocation implemented"],
                        "dependencies": [],
                        "work_phase": "implement",
                    }
                ]
            }
        )

    def _parse_response_legacy(self, raw_response: str) -> list[dict[str, Any]]:
        """Parse LLM response into plan items.

        DEPRECATED: Use _parse_response_via_pipeline instead for preamble-safe parsing.
        Kept for backward compatibility with tests.

        Args:
            raw_response: Raw LLM response

        Returns:
            List of plan item dictionaries
        """
        try:
            response = raw_response.strip()

            # Check for empty response
            if not response:
                # FIX-GRACEFUL-INTERRUPT-001: Check if empty due to interrupt
                if interrupt_requested():
                    logger.info("Empty response due to user interrupt")
                    msg = "Operation interrupted by user"
                    raise KeyboardInterrupt(msg)
                logger.error("Received empty response from LLM")
                return self._create_diagnostic_fallback(
                    "Empty response",
                    "LLM returned empty content. Check LLM provider configuration and API key.",
                    raw_response,
                )

            # Handle markdown code blocks
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])
            response = response.strip()

            # Parse JSON
            data = json.loads(response)

            # Extract plan_items
            if isinstance(data, dict) and "plan_items" in data:
                items = data["plan_items"]
            elif isinstance(data, list):
                items = data
            else:
                logger.warning("Unexpected response format")
                items = [data]

            # Validate and normalize items
            normalized = []
            for i, item in enumerate(items):
                # Coerce item_type to supported values
                raw_item_type = item.get("item_type", "task")
                item_type = (
                    raw_item_type if raw_item_type in {"task", "subtask", "milestone"} else "task"
                )

                # Extract work_phase with validation (default to "implement")
                raw_work_phase = item.get("work_phase", "implement")
                work_phase = raw_work_phase if raw_work_phase in VALID_PHASES else "implement"

                # Extract suggested_agent or derive from work_phase
                raw_suggested_agent = item.get("suggested_agent")
                suggested_agent = (
                    raw_suggested_agent
                    if raw_suggested_agent is not None
                    else PHASE_TO_AGENT.get(work_phase)
                )

                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item_type,
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", "") or item.get("title", "Untitled"),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                    "work_phase": work_phase,
                    "suggested_agent": suggested_agent,
                }
                normalized.append(normalized_item)

            self._log_item_count_warning(len(normalized))

        except json.JSONDecodeError as e:
            logger.exception(
                "Failed to parse plan JSON. Raw response (first 500 chars): %s",
                raw_response[:500],
            )
            return self._create_diagnostic_fallback(
                f"JSON parse error: {e!s}",
                self._generate_parse_error_diagnostic(e, raw_response),
                raw_response,
            )
        else:
            return normalized

    # Alias for backward compatibility with tests
    _parse_response = _parse_response_legacy

    def _log_item_count_warning(self, item_count: int) -> None:
        self._serialization.log_item_count_warning(item_count)

    def _create_diagnostic_fallback(
        self, error_type: str, diagnostic: str, raw_response: str
    ) -> list[dict[str, Any]]:
        return self._serialization.create_diagnostic_fallback(
            error_type,
            diagnostic,
            raw_response,
        )

    def _generate_parse_error_diagnostic(
        self, error: json.JSONDecodeError, raw_response: str
    ) -> str:
        """Generate detailed diagnostic for JSON parse errors.

        Args:
            error: JSONDecodeError exception
            raw_response: Raw LLM response

        Returns:
            Diagnostic message
        """
        diagnostics = []

        # Check for common issues
        if not raw_response:
            diagnostics.append("• Response is completely empty")
        elif raw_response.strip().startswith("<"):
            diagnostics.append("• Response appears to be HTML/XML, not JSON")
        elif "error" in raw_response.lower() and "rate" in raw_response.lower():
            diagnostics.append("• Response may indicate rate limiting")
        elif "error" in raw_response.lower() and "auth" in raw_response.lower():
            diagnostics.append("• Response may indicate authentication failure")
        elif not raw_response.strip().startswith(("{", "[")):
            diagnostics.append(
                f"• Response starts with unexpected character: '{raw_response[0] if raw_response else 'N/A'}'"
            )

        # Add JSON error details
        diagnostics.append(f"• JSON error at line {error.lineno}, column {error.colno}")
        diagnostics.append(f"• Error message: {error.msg}")

        # Check response length
        if len(raw_response) > RAW_RESPONSE_WARN_LIMIT:
            diagnostics.append(
                f"• Response is very large ({len(raw_response)} chars) - may have exceeded output limits"
            )

        return "\n".join(diagnostics) if diagnostics else "No specific diagnostic available"


__all__ = [
    "EXPLORATION_LOOKBACK_MINUTES",
    "MAX_DERIVATION_DEPTH",
    "PHASE_TO_AGENT",
    "VALID_PHASES",
    "WORK_TYPES_NEEDING_EXPLORATION",
    "WORK_TYPE_KEYWORDS",
    "DerivationEngine",
    "DerivationResult",
    "detect_recent_exploration",
]
