"""Plan serialization and per-epic derivation helpers for the pipeline facade."""

from __future__ import annotations

import json
import logging
import re
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_derivation_serialize_max_concurrent,
    get_derivation_step3_tier,
    get_derivation_story_range,
    get_derivation_strict_story_range,
    get_derivation_strict_task_range,
    get_derivation_task_range,
)
from obra.exceptions import ObraError
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.prompts.derive.derivation import (
    build_step2_per_epic_prompt,
    build_step2_per_epic_template,
    build_step2_repair_prompt,
    build_step2_repair_template,
    build_step3_per_epic_prompt,
    build_step3_per_epic_prompt_strict,
)

logger = logging.getLogger(__name__)

VALID_PHASES = ["explore", "plan", "implement", "commit"]
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",
    "plan": None,
    "implement": None,
    "commit": None,
}


class PlanSerializer:
    """Own per-epic derivation and plan-item serialization helpers."""

    def __init__(
        self,
        owner: Any,
        validator: Any,
        *,
        resolve_runtime_attr: Callable[[str, Any], Any],
        epic_limits: Callable[[], tuple[int, int]],
    ) -> None:
        self._owner = owner
        self._validator = validator
        self._resolve_runtime_attr = resolve_runtime_attr
        self._epic_limits = epic_limits

    @staticmethod
    def build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        """Build minimal plan items for partial plan snapshots."""
        plan_items: list[dict[str, Any]] = [
            {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "parent_id": None,
                "depth": 0,
                "order": 0,
            }
        ]

        task_map: dict[str, list[dict[str, str]]] = {}
        for task in tasks:
            task_id = task.get("id", "")
            story_id = task_id.split(".T", 1)[0] if ".T" in task_id else ""
            if story_id:
                task_map.setdefault(story_id, []).append(task)

        for story_index, story in enumerate(stories, start=1):
            story_id = story.get("id", "")
            story_title = story.get("title", "")
            if not story_id:
                continue
            plan_items.append(
                {
                    "id": story_id,
                    "item_type": "story",
                    "title": story_title,
                    "parent_id": epic_id,
                    "depth": 1,
                    "order": story_index,
                }
            )
            for task_index, task in enumerate(task_map.get(story_id, []), start=1):
                task_id = task.get("id", "")
                task_title = task.get("title", "")
                if not task_id:
                    continue
                plan_items.append(
                    {
                        "id": task_id,
                        "item_type": "task",
                        "title": task_title,
                        "parent_id": story_id,
                        "depth": 2,
                        "order": task_index,
                    }
                )

        return plan_items

    @staticmethod
    def merge_epic_details(epics_prose: str, all_epic_details: list[str]) -> str:
        """Merge epic-only prose with per-epic story/task details."""
        merged = [epics_prose.strip()]
        if all_epic_details:
            merged.append("")
            for detail in all_epic_details:
                merged.append(detail.strip())
                merged.append("")
        return "\n".join(merged).strip()

    def serialize_per_epic(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Serialize each epic's stories/tasks to JSON in parallel, then merge."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        max_workers = get_derivation_serialize_max_concurrent()
        epic_count = len(parsed_epics)

        if progress_callback:
            progress_callback(
                "epic_serialization_batch_started",
                {
                    "epic_count": epic_count,
                    "max_concurrent": max_workers,
                },
            )

        def serialize_one(
            args: tuple[int, dict[str, Any], str],
        ) -> tuple[int, dict[str, Any], list[dict[str, Any]], int]:
            i, epic, epic_prose = args
            epic_id = epic.get("id", f"E{i + 1}")
            epic_title = epic.get("title", "Untitled")

            epic_item: dict[str, Any] = {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "description": epic.get("description", ""),
                "acceptance_criteria": [],
                "dependencies": [],
                "parent_id": None,
                "depth": 0,
                "work_phase": "implement",
                "suggested_agent": None,
            }

            prompt = build_step3_per_epic_prompt(epic_prose, epic_id)
            epic_items = self._owner._parse_flat_response_via_pipeline(prompt, provider)

            if epic_items:
                if progress_callback:
                    progress_callback(
                        "epic_serialization_recovery",
                        {
                            "epic_id": epic_id,
                            "attempt_stage": "initial",
                            "status": "success",
                            "outcome": "completed",
                            "is_retry": False,
                        },
                    )
                tokens_est = len(prompt) // 4 + len(json.dumps(epic_items)) // 4
                return (i, epic_item, epic_items, tokens_est)

            story_count, task_count = self._validator.count_epic_story_task_ids(epic_prose, epic_id)
            if progress_callback:
                progress_callback(
                    "epic_serialization_recovery",
                    {
                        "epic_id": epic_id,
                        "attempt_stage": "initial",
                        "status": "template_fallback",
                        "stories_expected": story_count,
                        "tasks_expected": task_count,
                        "outcome": "retry",
                        "is_retry": False,
                    },
                )

            logger.warning(
                "Epic %s Step 3 initial attempt failed, retrying with strict prompt (expected %d stories, %d tasks)",
                epic_id,
                story_count,
                task_count,
            )
            strict_prompt = build_step3_per_epic_prompt_strict(
                epic_prose,
                epic_id,
                expected_story_count=story_count,
                expected_task_count=task_count,
            )
            epic_items = self._owner._parse_flat_response_via_pipeline(strict_prompt, provider)

            if epic_items:
                if progress_callback:
                    progress_callback(
                        "epic_serialization_recovery",
                        {
                            "epic_id": epic_id,
                            "attempt_stage": "strict_retry",
                            "status": "success",
                            "outcome": "completed",
                            "is_retry": True,
                        },
                    )
                tokens_est = (
                    len(prompt) + len(strict_prompt)
                ) // 4 + len(json.dumps(epic_items)) // 4
                return (i, epic_item, epic_items, tokens_est)

            if progress_callback:
                progress_callback(
                    "epic_serialization_recovery",
                    {
                        "epic_id": epic_id,
                        "attempt_stage": "strict_retry",
                        "status": "template_fallback",
                        "stories_expected": story_count,
                        "tasks_expected": task_count,
                        "outcome": "failed",
                        "is_retry": True,
                    },
                )

            preview = re.sub(r"\s+", " ", epic_prose).strip()[:240]
            artifact_path = self._validator.write_epic_failure_artifact(
                Path(self._owner._working_dir),
                epic_id=epic_id,
                story_count=story_count,
                task_count=task_count,
                reason_codes=["step3_template_fallback"],
                retry_metadata={
                    "initial_status": "template_fallback",
                    "retry_status": "template_fallback",
                    "attempt_stage": "strict_retry",
                },
                output_preview=preview,
            )
            msg = (
                f"No stories/tasks parsed for {epic_id} during per-epic serialization "
                f"(expected {story_count} stories, {task_count} tasks). "
                f"Both standard and strict retry failed."
            )
            if artifact_path:
                msg += f" Artifact: {artifact_path}"
            raise ValueError(msg)

        work = [
            (i, epic, prose)
            for i, (epic, prose) in enumerate(zip(parsed_epics, all_epic_details, strict=False))
        ]
        results: list[tuple[int, dict[str, Any], list[dict[str, Any]], int]] = []
        errors: list[tuple[int, str, Exception]] = []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(serialize_one, w): w for w in work}
            for future in as_completed(futures):
                i, epic, _ = futures[future]
                epic_id = epic.get("id", f"E{i + 1}")
                epic_title = epic.get("title", "Untitled")
                try:
                    result = future.result()
                    results.append(result)
                    if progress_callback:
                        progress_callback(
                            "epic_serialization_completed",
                            {
                                "epic_index": i + 1,
                                "epic_count": epic_count,
                                "epic_id": epic_id,
                                "epic_title": epic_title,
                                "items_serialized": len(result[2]) + 1,
                            },
                        )
                    logger.debug(
                        "Epic %s serialized: %d items, ~%d tokens",
                        epic_id,
                        len(result[2]) + 1,
                        result[3],
                    )
                except Exception as exc:
                    logger.warning("Epic %s serialization failed: %s", epic_id, exc)
                    errors.append((i, epic_id, exc))

        if errors:
            details = "; ".join(f"{epic_id}: {err}" for _, epic_id, err in errors[:3])
            raise ObraError(
                f"{len(errors)}/{epic_count} epics failed serialization. "
                f"Aborting to avoid incomplete plan. {details}"
            )

        results.sort(key=lambda x: x[0])
        all_plan_items: list[dict[str, Any]] = []
        total_tokens = 0
        for _, epic_item, epic_items, tokens in results:
            all_plan_items.append(epic_item)
            all_plan_items.extend(epic_items)
            total_tokens += tokens

        return all_plan_items, total_tokens

    def derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        """Derive stories + tasks per-epic with cumulative global context."""
        import threading

        all_epic_details: list[str] = []
        total_tokens = 0

        resolve_tier = self._resolve_runtime_attr("resolve_tier_config", resolve_tier_config)
        pipeline_cls = self._resolve_runtime_attr("TemplateEditPipeline", TemplateEditPipeline)
        item_limit, token_limit = self._epic_limits()

        tier_config = resolve_tier("high", role="orchestrator")
        llm_config = {
            "provider": provider,
            "model": tier_config.get("model", ""),
            "reasoning_level": tier_config.get("reasoning_level", "off"),
            "auth": tier_config.get("auth", "oauth"),
        }
        story_range = get_derivation_story_range()
        task_range = get_derivation_task_range()
        strict_story_range = get_derivation_strict_story_range()
        strict_task_range = get_derivation_strict_task_range()

        for i, epic in enumerate(parsed_epics):
            epic_id = epic.get("id", f"E{i + 1}")
            epic_title = epic.get("title", "Untitled")

            if progress_callback:
                progress_callback(
                    "epic_derivation_started",
                    {
                        "epic_index": i + 1,
                        "epic_count": len(parsed_epics),
                        "epic_id": epic_id,
                        "epic_title": epic_title,
                    },
                )

            heartbeat_stop = threading.Event()
            heartbeat_thread: threading.Thread | None = None
            if progress_callback:
                start_ts = time.perf_counter()

                def _heartbeat(
                    _stop: threading.Event = heartbeat_stop,
                    _start: float = start_ts,
                    _idx: int = i,
                    _title: str = epic_title,
                ) -> None:
                    while not _stop.wait(30.0):
                        elapsed = int(time.perf_counter() - _start)
                        progress_callback(
                            "epic_derivation_heartbeat",
                            {
                                "epic_index": _idx + 1,
                                "epic_count": len(parsed_epics),
                                "epic_title": _title,
                                "items_so_far": 0,
                                "elapsed_s": elapsed,
                            },
                        )

                heartbeat_thread = threading.Thread(target=_heartbeat, daemon=True)
                heartbeat_thread.start()

            try:
                prompt = build_step2_per_epic_prompt(
                    objective=objective,
                    all_epics_prose=epics_prose,
                    completed_epic_details=all_epic_details,
                    target_epic=epic.get("prose", ""),
                    target_epic_id=epic_id,
                    intent_markdown=intent_markdown,
                    exploration_context=exploration_context,
                    story_range=story_range,
                    task_range=task_range,
                    strict=False,
                )

                pipeline = pipeline_cls(
                    working_dir=self._owner._working_dir,
                    action_name="derivation_per_epic",
                    output_format="text",
                )
                template_content = build_step2_per_epic_template(
                    target_epic_id=epic_id,
                    story_range=story_range,
                    task_range=task_range,
                )

                epic_detail_prose, meta = pipeline.execute(
                    base_prompt=prompt,
                    template_content=template_content,
                    validator=lambda content, _eid=epic_id: self._validator.validate_epic_prose(
                        content,
                        _eid,
                    ),
                    fallback_fn=lambda: "",
                    llm_config=llm_config,
                )

                status = str(meta.get("status", ""))
                story_count, task_count = self._validator.count_epic_story_task_ids(
                    epic_detail_prose,
                    epic_id,
                )
                item_count = story_count + task_count
                output_tokens = self._validator.estimate_output_tokens(epic_detail_prose)
                reason_codes = self._validator.extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                    status=status,
                    item_count=item_count,
                    output_tokens=output_tokens,
                )
                if progress_callback:
                    progress_callback(
                        "epic_derivation_recovery",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "attempt_stage": "initial",
                            "status": status,
                            "reason_codes": reason_codes,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "continue",
                            "is_retry": False,
                        },
                    )

                retry_stage = "initial"
                retry_status = status
                retry_meta: dict[str, Any] = {}

                branch_a_repair = story_count > 0 and task_count == 0
                branch_b_strict = story_count == 0 or status in {
                    "template_fallback",
                    "template_error",
                    "validation_failed",
                }
                branch_c_strict = (
                    story_count > 0
                    and task_count > 0
                    and (item_count > item_limit or output_tokens > token_limit)
                )

                if branch_a_repair:
                    retry_stage = "targeted_repair"
                    stories, tasks = self._validator.extract_epic_story_task_titles(
                        epic_detail_prose,
                        epic_id,
                    )
                    task_story_ids = {task["id"].split(".T", 1)[0] for task in tasks if task.get("id")}
                    missing_story_ids = [
                        story["id"]
                        for story in stories
                        if story.get("id") not in task_story_ids
                    ]
                    repair_prompt = build_step2_repair_prompt(
                        objective=objective,
                        target_epic_id=epic_id,
                        incomplete_output=epic_detail_prose,
                        missing_stories=missing_story_ids
                        or [story["id"] for story in stories if story.get("id")],
                    )
                    repair_template = build_step2_repair_template(
                        target_epic_id=epic_id,
                        existing_stories=stories,
                    )
                    repair_pipeline = pipeline_cls(
                        working_dir=self._owner._working_dir,
                        action_name="derivation_per_epic",
                        output_format="text",
                    )
                    epic_detail_prose, retry_meta = repair_pipeline.execute(
                        base_prompt=repair_prompt,
                        template_content=repair_template,
                        validator=lambda content, _eid=epic_id: self._validator.validate_epic_prose(
                            content,
                            _eid,
                        ),
                        fallback_fn=lambda: "",
                        llm_config=llm_config,
                    )
                    retry_status = str(retry_meta.get("status", ""))
                    story_count, task_count = self._validator.count_epic_story_task_ids(
                        epic_detail_prose,
                        epic_id,
                    )
                    item_count = story_count + task_count
                    output_tokens = self._validator.estimate_output_tokens(epic_detail_prose)
                elif branch_b_strict or branch_c_strict:
                    retry_stage = "strict_retry"
                    retry_prompt = build_step2_per_epic_prompt(
                        objective=objective,
                        all_epics_prose=epics_prose,
                        completed_epic_details=all_epic_details,
                        target_epic=epic.get("prose", ""),
                        target_epic_id=epic_id,
                        intent_markdown=intent_markdown,
                        exploration_context=exploration_context,
                        story_range=strict_story_range,
                        task_range=strict_task_range,
                        strict=True,
                    )
                    strict_template = build_step2_per_epic_template(
                        target_epic_id=epic_id,
                        story_range=strict_story_range,
                        task_range=strict_task_range,
                    )
                    strict_pipeline = pipeline_cls(
                        working_dir=self._owner._working_dir,
                        action_name="derivation_per_epic",
                        output_format="text",
                    )
                    epic_detail_prose, retry_meta = strict_pipeline.execute(
                        base_prompt=retry_prompt,
                        template_content=strict_template,
                        validator=lambda content, _eid=epic_id: self._validator.validate_epic_prose(
                            content,
                            _eid,
                        ),
                        fallback_fn=lambda: "",
                        llm_config=llm_config,
                    )
                    retry_status = str(retry_meta.get("status", ""))
                    story_count, task_count = self._validator.count_epic_story_task_ids(
                        epic_detail_prose,
                        epic_id,
                    )
                    item_count = story_count + task_count
                    output_tokens = self._validator.estimate_output_tokens(epic_detail_prose)
                    if item_count > item_limit or output_tokens > token_limit:
                        logger.warning(
                            "Epic %s still oversized after strict retry (%d items, ~%d tokens).",
                            epic_id,
                            item_count,
                            output_tokens,
                        )

                reason_codes = self._validator.extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                    status=retry_status,
                    item_count=item_count,
                    output_tokens=output_tokens,
                )
                failed_recovery = any(
                    code in reason_codes
                    for code in [
                        "template_fallback",
                        "no_stories",
                        "no_tasks",
                        "no_tasks_for_story",
                        "wrong_epic_ids",
                        "orphan_tasks",
                    ]
                )

                if progress_callback:
                    progress_callback(
                        "epic_derivation_recovery",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "attempt_stage": retry_stage,
                            "status": retry_status,
                            "reason_codes": reason_codes,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "failed" if failed_recovery else "completed",
                            "is_retry": retry_stage != "initial",
                        },
                    )

                if failed_recovery:
                    preview = re.sub(r"\s+", " ", epic_detail_prose).strip()[:240]
                    artifact_path = self._validator.write_epic_failure_artifact(
                        Path(self._owner._working_dir),
                        epic_id=epic_id,
                        story_count=story_count,
                        task_count=task_count,
                        reason_codes=reason_codes,
                        retry_metadata={
                            "initial_status": status,
                            "retry_status": retry_status,
                            "attempt_stage": retry_stage,
                            "meta": retry_meta,
                        },
                        output_preview=preview,
                    )
                    msg = (
                        f"Epic {epic_id} derivation failed "
                        f"(stage={retry_stage}, status={retry_status}, stories={story_count}, "
                        f"tasks={task_count}, reasons={','.join(reason_codes) or 'unknown'}). "
                        f"Preview: {preview or '<empty>'}"
                    )
                    if artifact_path:
                        msg += f". Artifact: {artifact_path}"
                    raise ObraError(msg)

                all_epic_details.append(epic_detail_prose)
                total_tokens += len(prompt) // 4 + len(epic_detail_prose) // 4

                if progress_callback:
                    stories, tasks = self._validator.extract_epic_story_task_titles(
                        epic_detail_prose,
                        epic_id,
                    )
                    if stories:
                        progress_callback(
                            "plan_snapshot",
                            {
                                "source": "derive",
                                "mode": "partial",
                                "plan_items": self.build_partial_plan_items(
                                    epic_id,
                                    epic_title,
                                    stories,
                                    tasks,
                                ),
                            },
                        )
                    progress_callback(
                        "epic_derivation_completed",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "epic_title": epic_title,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "completed",
                            "reason_codes": self._validator.extract_reason_codes_for_epic(
                                epic_detail_prose,
                                epic_id,
                            ),
                        },
                    )

            finally:
                if heartbeat_thread:
                    heartbeat_stop.set()
                    heartbeat_thread.join(timeout=5)

        return self.merge_epic_details(epics_prose, all_epic_details), all_epic_details, total_tokens

    def parse_flat_response_via_pipeline(
        self,
        prompt: str,
        provider: str,
    ) -> list[dict[str, Any]]:
        """Parse flat derivation response using TemplateEditPipeline."""
        pipeline_cls = self._resolve_runtime_attr("TemplateEditPipeline", TemplateEditPipeline)
        resolve_tier = self._resolve_runtime_attr("resolve_tier_config", resolve_tier_config)
        pipeline = pipeline_cls(
            working_dir=self._owner._working_dir,
            action_name="derivation_flat",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                "Derive plan items as an array. Each item must have:\n"
                '- id: string (e.g., "E1", "E1.S1", "E1.S1.T1")\n'
                "- title: string (concise action description)\n"
                '- item_type: "epic", "story", or "task"\n'
                "- description: string (detailed explanation)\n"
                "- acceptance_criteria: list of strings\n"
                "- dependencies: list of item IDs this depends on"
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            if len(plan_items) == 0:
                return (False, "plan_items must not be empty")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "title", "item_type", "description"):
                    if req_field not in item:
                        return (False, f"Item {idx} missing required field: {req_field}")
            return (True, None)

        step3_tier = get_derivation_step3_tier()
        tier_config = resolve_tier(step3_tier, role="orchestrator")
        llm_config = {
            "provider": tier_config["provider"],
            "model": tier_config["model"],
            "reasoning_level": tier_config.get("reasoning_level", self._owner._reasoning_level),
            "auth": tier_config.get("auth_method", "oauth"),
        }

        logger.debug(
            "Step 3 serialization using tier=%s, provider=%s, model=%s",
            step3_tier,
            llm_config["provider"],
            llm_config["model"],
        )

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=lambda: {"plan_items": []},
            llm_config=llm_config,
            allow_unchanged=False,
        )

        if metadata.get("status") in ("template_fallback", "template_error", "validation_failed"):
            logger.warning(
                "Flat derivation parsing failed after %d attempts (status=%s), using fallback",
                metadata.get("attempts", 0),
                metadata.get("status"),
            )
            return []

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return []
        return self.normalize_flat_plan_items(plan_items)

    def normalize_flat_plan_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize flat plan items to ensure required fields and correct values."""
        normalized: list[dict[str, Any]] = []
        stories_by_id: dict[str, dict[str, Any]] = {}

        for item in items:
            if not isinstance(item, dict):
                continue

            item_id = item.get("id", "")
            item_type = item.get("item_type", "task")
            title = item.get("title", "Untitled")
            description = item.get("description", "") or title

            acceptance = item.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                acceptance = [acceptance] if acceptance else []

            deps = item.get("dependencies", [])
            if not isinstance(deps, list):
                deps = [deps] if deps else []

            if item_type == "epic":
                depth = 0
            elif item_type == "story":
                depth = 1
            else:
                depth = 2

            parent_id = item.get("parent_id")
            if item_type == "epic":
                parent_id = None
            elif item_type == "story" and not parent_id:
                parent_id = "E1"
            elif item_type == "task" and not parent_id:
                if "." in item_id:
                    parent_id = item_id.rsplit(".", 1)[0]
                elif stories_by_id:
                    parent_id = next(iter(stories_by_id.keys()), "S1")
                else:
                    parent_id = "S1"

            raw_phase = item.get("work_phase", "implement")
            work_phase = raw_phase if raw_phase in VALID_PHASES else "implement"
            raw_agent = item.get("suggested_agent")
            suggested_agent = raw_agent if raw_agent is not None else PHASE_TO_AGENT.get(work_phase)

            normalized_item = {
                "id": item_id or f"T{len(normalized) + 1}",
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": acceptance,
                "dependencies": deps,
                "parent_id": parent_id,
                "depth": depth,
                "work_phase": work_phase,
                "suggested_agent": suggested_agent,
            }

            normalized.append(normalized_item)
            if item_type == "story":
                stories_by_id[normalized_item["id"]] = normalized_item

        return normalized

    def parse_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        """Parse hierarchical derivation response using TemplateEditPipeline."""
        pipeline_cls = self._resolve_runtime_attr("TemplateEditPipeline", TemplateEditPipeline)
        pipeline = pipeline_cls(
            working_dir=self._owner._working_dir,
            action_name="derivation_hierarchical",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                "Derive plan items with full hierarchy. Each item needs:\n"
                '- id: string (e.g., "T1", "E1", "E1.S1", "E1.S1.T1")\n'
                '- item_type: "epic", "story", "task", "subtask", or "milestone"\n'
                "- title: string (concise action description)\n"
                "- description: string (detailed explanation)\n"
                "- acceptance_criteria: list of strings\n"
                "- dependencies: list of item IDs this depends on\n"
                '- work_phase: "explore", "plan", "implement", or "commit" (default: implement)'
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "item_type", "title"):
                    if req_field not in item:
                        return (False, f"Item {idx} missing required field: {req_field}")
            return (True, None)

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_schema,
            validator=validator,
            fallback_fn=lambda: {"plan_items": None},
            llm_config={
                "provider": provider,
                "model": None,
                "reasoning_level": self._owner._reasoning_level,
                "auth": "oauth",
            },
        )

        if metadata.get("status") == "template_fallback":
            logger.warning(
                "Hierarchical derivation parsing failed after %d attempts, using diagnostic fallback",
                metadata.get("attempts", 0),
            )
            return self._validator.create_diagnostic_fallback(
                "Pipeline parse failed",
                "Template edit parsing failed after retries",
                "",
            )

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return self._validator.create_diagnostic_fallback(
                "Invalid plan_items type",
                f"Expected list, got {type(plan_items).__name__}",
                "",
            )

        return self._validator.normalize_hierarchical_plan_items(plan_items)
