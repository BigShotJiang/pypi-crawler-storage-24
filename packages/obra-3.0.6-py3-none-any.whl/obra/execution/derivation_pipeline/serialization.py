"""Serialization facade for the derivation engine pipeline."""

from __future__ import annotations

import json
import logging
import sys
import time
from collections.abc import Callable
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_derivation_epic_item_rederive_threshold,
    get_derivation_epic_output_token_limit,
    get_derivation_preview_config,
)
from obra.exceptions import ObraError
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.prompts.derive.derivation import (
    build_refinement_prompt,
    build_step1_epics_template,
)

from ._epic_parser import EpicParser
from ._plan_serializer import PlanSerializer
from ._plan_validator import PlanValidator

logger = logging.getLogger(__name__)

_preview_config = get_derivation_preview_config()
RAW_RESPONSE_PREVIEW_LIMIT = _preview_config["raw_response_limit"]
ITEM_COUNT_WARNING_THRESHOLDS = (25, 50, 100, 200, 500, 1000)

EPIC_ITEM_REDERIVE_THRESHOLD = get_derivation_epic_item_rederive_threshold()
EPIC_OUTPUT_TOKEN_LIMIT = get_derivation_epic_output_token_limit()

VALID_PHASES = ["explore", "plan", "implement", "commit"]
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",
    "plan": None,
    "implement": None,
    "commit": None,
}


def _engine_attr(name: str, default: Any) -> Any:
    module = sys.modules.get("obra.execution.derivation")
    if module is None:
        return default
    return getattr(module, name, default)


def _epic_limits() -> tuple[int, int]:
    return (
        int(_engine_attr("EPIC_ITEM_REDERIVE_THRESHOLD", EPIC_ITEM_REDERIVE_THRESHOLD)),
        int(_engine_attr("EPIC_OUTPUT_TOKEN_LIMIT", EPIC_OUTPUT_TOKEN_LIMIT)),
    )


_EPIC_PARSER = EpicParser()
_PLAN_VALIDATOR = PlanValidator(
    raw_response_preview_limit=RAW_RESPONSE_PREVIEW_LIMIT,
    item_count_warning_thresholds=ITEM_COUNT_WARNING_THRESHOLDS,
    epic_limits=_epic_limits,
    valid_phases=VALID_PHASES,
    phase_to_agent=PHASE_TO_AGENT,
)


class DerivationSerializationService:
    """Stable engine-facing facade over parser, serializer, and validator owners."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner
        self._parser = _EPIC_PARSER
        self._validator = _PLAN_VALIDATOR
        self._serializer = PlanSerializer(
            owner,
            self._validator,
            resolve_runtime_attr=_engine_attr,
            epic_limits=_epic_limits,
        )

    @staticmethod
    def validate_step1_epics(content: dict, min_epics: int) -> tuple[bool, str | None]:
        return _EPIC_PARSER.validate_step1_epics(content, min_epics)

    @staticmethod
    def normalize_epics(epics_data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return _EPIC_PARSER.normalize_epics(epics_data)

    def parse_epics_from_prose(self, epics_prose: str) -> list[dict[str, Any]]:
        return self._parser.parse_epics_from_prose(epics_prose)

    @staticmethod
    def extract_epics_from_prose(epics_prose: str) -> list[dict[str, Any]]:
        return _EPIC_PARSER.extract_epics_from_prose(epics_prose)

    @staticmethod
    def render_epics_prose(epics: list[dict[str, Any]]) -> str:
        return _EPIC_PARSER.render_epics_prose(epics)

    @staticmethod
    def extract_epic_story_task_titles(
        epic_detail_prose: str,
        epic_id: str,
    ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
        return _PLAN_VALIDATOR.extract_epic_story_task_titles(epic_detail_prose, epic_id)

    @staticmethod
    def build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        return PlanSerializer.build_partial_plan_items(epic_id, epic_title, stories, tasks)

    @staticmethod
    def estimate_output_tokens(text: str) -> int:
        return _PLAN_VALIDATOR.estimate_output_tokens(text)

    @staticmethod
    def validate_epic_prose(content: str, epic_id: str) -> tuple[bool, str | None]:
        return _PLAN_VALIDATOR.validate_epic_prose(content, epic_id)

    @staticmethod
    def count_epic_story_task_ids(epic_detail_prose: str, epic_id: str) -> tuple[int, int]:
        return _PLAN_VALIDATOR.count_epic_story_task_ids(epic_detail_prose, epic_id)

    @staticmethod
    def count_epic_items(epic_detail_prose: str, epic_id: str | None = None) -> int:
        return _PLAN_VALIDATOR.count_epic_items(epic_detail_prose, epic_id)

    @staticmethod
    def extract_reason_codes_for_epic(
        epic_detail_prose: str,
        epic_id: str,
        *,
        status: str = "",
        item_count: int | None = None,
        output_tokens: int | None = None,
    ) -> list[str]:
        return _PLAN_VALIDATOR.extract_reason_codes_for_epic(
            epic_detail_prose,
            epic_id,
            status=status,
            item_count=item_count,
            output_tokens=output_tokens,
        )

    @staticmethod
    def write_epic_failure_artifact(
        working_dir,
        *,
        epic_id: str,
        story_count: int,
        task_count: int,
        reason_codes: list[str],
        retry_metadata: dict[str, Any],
        output_preview: str,
    ) -> str | None:
        return _PLAN_VALIDATOR.write_epic_failure_artifact(
            working_dir,
            epic_id=epic_id,
            story_count=story_count,
            task_count=task_count,
            reason_codes=reason_codes,
            retry_metadata=retry_metadata,
            output_preview=output_preview,
        )

    def merge_epic_details(self, epics_prose: str, all_epic_details: list[str]) -> str:
        return self._serializer.merge_epic_details(epics_prose, all_epic_details)

    def serialize_per_epic(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        return self._serializer.serialize_per_epic(
            all_epic_details=all_epic_details,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
        )

    def derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        return self._serializer.derive_per_epic(
            objective=objective,
            epics_prose=epics_prose,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
            intent_markdown=intent_markdown,
            exploration_context=exploration_context,
        )

    def derive_multi_step_plan(
        self,
        objective: str,
        project_context: str,
        constraints: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> tuple[list[dict[str, Any]], int]:
        """Derive implementation plan using the stable facade orchestration flow."""
        import threading

        pipeline_start = time.perf_counter()
        total_tokens = 0
        step_tokens: dict[str, dict[str, int]] = {}

        logger.info(
            "derivation_pipeline_started",
            extra={"objective_length": len(objective)},
        )

        if progress_callback:
            progress_callback("derivation_step_started", {"step": 1, "step_name": "structure"})

        step1_start = time.perf_counter()
        heartbeat_stop = threading.Event()
        heartbeat_thread: threading.Thread | None = None
        if progress_callback:
            heartbeat_start = time.perf_counter()

            def _step1_heartbeat(
                _stop: threading.Event = heartbeat_stop,
                _start: float = heartbeat_start,
            ) -> None:
                while not _stop.wait(30.0):
                    progress_callback(
                        "derivation_step_heartbeat",
                        {
                            "step": 1,
                            "step_name": "structure",
                            "elapsed_s": int(time.perf_counter() - _start),
                        },
                    )

            heartbeat_thread = threading.Thread(target=_step1_heartbeat, daemon=True)
            heartbeat_thread.start()

        tokens1 = 0
        parsed_epics: list[dict[str, Any]] = []
        epics_prose = ""
        prose_step1 = ""
        items_step1 = 0
        try:
            resolve_tier = _engine_attr("resolve_tier_config", resolve_tier_config)
            pipeline_cls = _engine_attr("TemplateEditPipeline", TemplateEditPipeline)
            tier_config = resolve_tier(
                tier="fast",
                role="orchestrator",
                override_provider=provider,
            )
            llm_config = {
                "provider": provider,
                "model": tier_config.get("model"),
                "thinking_enabled": self._owner._thinking_enabled,
            }

            story_range = "3-6"
            template = build_step1_epics_template(story_range)
            min_epics = int(story_range.split("-")[0])

            def validator(content: dict) -> tuple[bool, str | None]:
                return self.validate_step1_epics(content, min_epics)

            base_prompt = self._owner._build_step1_prompt(
                objective=objective,
                constraints=constraints,
                context=project_context,
            )
            pipeline = pipeline_cls(
                working_dir=self._owner._working_dir,
                action_name="derivation_step1",
                output_format="json",
            )
            data, metadata = pipeline.execute(
                base_prompt=base_prompt,
                template_content=template,
                validator=validator,
                fallback_fn=lambda: {"epics": []},
                llm_config=llm_config,
            )

            parsed_epics = self.normalize_epics(data.get("epics", []))
            epics_prose = self.render_epics_prose(parsed_epics) if parsed_epics else ""
            prose_step1 = epics_prose
            items_step1 = len(parsed_epics)
            tokens1 = metadata.get("tokens", 0)
            total_tokens += tokens1
        finally:
            if heartbeat_thread:
                heartbeat_stop.set()
                heartbeat_thread.join(timeout=5)

        step1_duration_ms = int((time.perf_counter() - step1_start) * 1000)
        step_tokens["structure"] = {"total_tokens": tokens1}

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 1,
                    "step_name": "structure",
                    "duration_ms": step1_duration_ms,
                    "items_produced": items_step1,
                    "prose": prose_step1,
                },
            )

        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 1,
                "step_name": "structure",
                "duration_ms": step1_duration_ms,
                "tokens": tokens1,
                "items_produced": items_step1,
            },
        )
        logger.debug("Step 1 (structure) completed: %d tokens", tokens1)

        if progress_callback:
            progress_callback("derivation_step_started", {"step": 2, "step_name": "tasks"})

        step2_start = time.perf_counter()
        epic_count = len(parsed_epics)
        use_per_epic = epic_count > 2
        if not parsed_epics:
            logger.warning(
                "No epics parsed from Step 1 JSON; using phased derivation with default epic scaffolding"
            )
            use_per_epic = False

        logger.info(
            "Complexity routing: %d epics -> %s mode",
            epic_count,
            "per-epic" if use_per_epic else "one-shot",
        )

        all_epic_details: list[str] = []
        if use_per_epic:
            prose_step2, all_epic_details, tokens2 = self._owner._derive_per_epic(
                objective=objective,
                epics_prose=epics_prose,
                parsed_epics=parsed_epics,
                provider=provider,
                progress_callback=progress_callback,
                intent_markdown=self._owner._intent_markdown,
                exploration_context=self._owner._exploration_context,
            )
        else:
            step2_prompt = self._owner._build_step2_prompt(
                objective=objective,
                prose_from_step_1=epics_prose,
            )
            prose_step2, tokens2 = self._owner._invoke_llm(
                prompt=step2_prompt,
                provider=provider,
                _work_type="feature_implementation",
            )
        total_tokens += tokens2

        step2_duration_ms = int((time.perf_counter() - step2_start) * 1000)
        items_step2 = prose_step2.count(".T")
        step_tokens["tasks"] = {"total_tokens": tokens2}

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 2,
                    "step_name": "tasks",
                    "duration_ms": step2_duration_ms,
                    "items_produced": items_step2,
                    "prose": prose_step2,
                },
            )

        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 2,
                "step_name": "tasks",
                "duration_ms": step2_duration_ms,
                "tokens": tokens2,
                "items_produced": items_step2,
            },
        )
        logger.debug("Step 2 (tasks) completed: %d tokens", tokens2)

        convergence_failures: list[dict[str, Any]] = []
        if parsed_epics:
            if all_epic_details:
                if len(all_epic_details) != len(parsed_epics):
                    convergence_failures.append(
                        {
                            "epic_id": "unknown",
                            "reason_codes": ["missing_epic_details"],
                            "stories": len(all_epic_details),
                            "tasks": 0,
                        }
                    )
                for epic, epic_detail in zip(parsed_epics, all_epic_details, strict=False):
                    epic_id = str(epic.get("id", "")).strip()
                    if not epic_id:
                        continue
                    stories, tasks = self.count_epic_story_task_ids(epic_detail, epic_id)
                    reason_codes = self.extract_reason_codes_for_epic(epic_detail, epic_id)
                    structural_reasons = [
                        code
                        for code in reason_codes
                        if code
                        in {
                            "no_stories",
                            "no_tasks",
                            "no_tasks_for_story",
                            "wrong_epic_ids",
                            "orphan_tasks",
                        }
                    ]
                    if structural_reasons:
                        convergence_failures.append(
                            {
                                "epic_id": epic_id,
                                "reason_codes": structural_reasons,
                                "stories": stories,
                                "tasks": tasks,
                            }
                        )
            else:
                for epic in parsed_epics:
                    epic_id = str(epic.get("id", "")).strip()
                    if not epic_id:
                        continue
                    stories, tasks = self.count_epic_story_task_ids(prose_step2, epic_id)
                    reason_codes = self.extract_reason_codes_for_epic(prose_step2, epic_id)
                    structural_reasons = [
                        code
                        for code in reason_codes
                        if code
                        in {
                            "no_stories",
                            "no_tasks",
                            "no_tasks_for_story",
                            "wrong_epic_ids",
                            "orphan_tasks",
                        }
                    ]
                    if structural_reasons:
                        convergence_failures.append(
                            {
                                "epic_id": epic_id,
                                "reason_codes": structural_reasons,
                                "stories": stories,
                                "tasks": tasks,
                            }
                        )

        if convergence_failures:
            if progress_callback:
                progress_callback(
                    "derivation_convergence_failed",
                    {
                        "step": 2,
                        "step_name": "tasks",
                        "failures": convergence_failures,
                    },
                )
            failure = convergence_failures[0]
            raise ObraError(
                "Step 2 convergence failed before serialization for "
                f"{failure['epic_id']} (stories={failure['stories']}, tasks={failure['tasks']}, "
                f"reasons={','.join(failure['reason_codes'])})."
            )

        if progress_callback:
            progress_callback("derivation_step_started", {"step": 3, "step_name": "serialize"})

        step3_start = time.perf_counter()
        if all_epic_details and parsed_epics:
            plan_items, tokens3 = self._owner._serialize_per_epic(
                all_epic_details=all_epic_details,
                parsed_epics=parsed_epics,
                provider=provider,
                progress_callback=progress_callback,
            )
        else:
            step3_prompt = self._owner._build_step3_prompt(prose_from_step_2=prose_step2)
            plan_items = self._owner._parse_flat_response_via_pipeline(step3_prompt, provider)
            tokens3 = len(step3_prompt) // 4 + len(json.dumps(plan_items)) // 4

        total_tokens += tokens3
        step3_duration_ms = int((time.perf_counter() - step3_start) * 1000)
        items_step3 = len(plan_items)
        step_tokens["serialize"] = {"total_tokens": tokens3}

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 3,
                    "step_name": "serialize",
                    "duration_ms": step3_duration_ms,
                    "items_produced": items_step3,
                    "raw_json": json.dumps(plan_items),
                },
            )

        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 3,
                "step_name": "serialize",
                "duration_ms": step3_duration_ms,
                "tokens": tokens3,
                "items_produced": items_step3,
            },
        )

        if validation_intensity == "none":
            logger.debug("Validation skipped (intensity=none)")
        else:
            max_passes = 2 if validation_intensity == "thorough" else 1
            pass_count = 0
            violations = self._owner._validate_plan_items(plan_items)

            while violations and pass_count < max_passes:
                pass_count += 1
                if progress_callback:
                    progress_callback(
                        "derivation_validation_started",
                        {"pass": pass_count, "max_passes": max_passes},
                    )

                logger.info(
                    "Plan validation failed (pass %d/%d): %d violations",
                    pass_count,
                    max_passes,
                    len(violations),
                )
                logger.debug("Violations: %s", violations)

                refinement_prompt = build_refinement_prompt(prose_step2, violations)
                try:
                    plan_items = self._owner._parse_flat_response_via_pipeline(
                        refinement_prompt,
                        provider,
                    )
                    tokens_refine = len(refinement_prompt) // 4 + len(json.dumps(plan_items)) // 4
                    total_tokens += tokens_refine
                    logger.debug(
                        "Refinement pass %d: estimated %d tokens",
                        pass_count,
                        tokens_refine,
                    )

                    violations = self._owner._validate_plan_items(plan_items)
                    if progress_callback:
                        progress_callback(
                            "derivation_validation_completed",
                            {
                                "pass": pass_count,
                                "violations": len(violations),
                                "passed": len(violations) == 0,
                            },
                        )
                    if not violations:
                        logger.info(
                            "Plan validation passed after %d refinement pass(es)",
                            pass_count,
                        )
                        break
                except Exception as exc:
                    logger.warning("Refinement pass %d failed: %s", pass_count, exc)
                    break

            if violations:
                logger.warning(
                    "Plan validation failed after %d pass(es), using best-effort plan with %d violations",
                    max_passes,
                    len(violations),
                )

        logger.info(
            "Multi-step derivation completed: %d items, %d total tokens",
            len(plan_items),
            total_tokens,
        )
        pipeline_duration_ms = int((time.perf_counter() - pipeline_start) * 1000)
        logger.info(
            "derivation_pipeline_completed",
            extra={
                "total_duration_ms": pipeline_duration_ms,
                "total_tokens": total_tokens,
                "item_count": len(plan_items),
                "step_tokens": step_tokens,
            },
        )

        return plan_items, total_tokens

    def parse_flat_response_via_pipeline(
        self,
        prompt: str,
        provider: str,
    ) -> list[dict[str, Any]]:
        return self._serializer.parse_flat_response_via_pipeline(prompt, provider)

    def normalize_flat_plan_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return self._serializer.normalize_flat_plan_items(items)

    def parse_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        return self._serializer.parse_response_via_pipeline(prompt, provider)

    def normalize_hierarchical_plan_items(
        self,
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        return self._validator.normalize_hierarchical_plan_items(items)

    def validate_plan_items(self, plan_items: list[dict[str, Any]]) -> list[str]:
        return self._validator.validate_plan_items(plan_items)
