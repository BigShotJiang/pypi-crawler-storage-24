"""Typed runtime-state ownership for HybridOrchestrator."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from obra.hybrid.dispatch.context import ExecutionState
from obra.hybrid.server_protocol import ReportContext


@dataclass
class HybridRuntimeState:
    """Own mutable session/bootstrap/reporting state for the orchestrator."""

    session_id: str | None = None
    objective: str | None = None
    domain_resolution: dict[str, Any] | None = None
    planning_mode: str | None = None
    bypass_modes: list[str] = field(default_factory=list)
    bypass_modes_validated: bool = False
    session_display_context: Any | None = None
    skip_completed_items: list[str] = field(default_factory=list)
    skipped_item_ids: set[str] = field(default_factory=set)
    resume_completed_item_ids: set[str] | None = None
    verification_tools: dict[str, Any] | None = None
    verification_preflight_attempted: bool = False
    last_item_id: str | None = None
    last_userplan_id: str | None = None
    last_userplan_version: int | None = None
    preserved_plan_items: list[dict[str, Any]] = field(default_factory=list)
    derive_from_step: int | None = None
    last_derivation_plan_items: list[dict[str, Any]] = field(default_factory=list)
    tasks_total: int = 0

    def build_report_context(
        self,
        *,
        last_action_payload: dict[str, Any],
        fix_result_history: list[dict[str, Any]],
        supported_review_agents: set[str],
    ) -> ReportContext:
        """Build the reporting snapshot consumed by ServerProtocol."""
        return ReportContext(
            session_id=self.session_id or "",
            last_action_payload=last_action_payload,
            last_item_id=self.last_item_id,
            preserved_plan_items=self.preserved_plan_items,
            derive_from_step=self.derive_from_step,
            last_userplan_id=self.last_userplan_id,
            last_userplan_version=self.last_userplan_version,
            fix_result_history=fix_result_history,
            supported_review_agents=supported_review_agents,
        )


class DispatchRuntimeBindings:
    """Adapt runtime owners into the ExecutionState protocol expected by dispatch."""

    def __init__(
        self,
        *,
        runtime_state: HybridRuntimeState,
        session_guard: Any | None,
        working_dir: Path,
        invocation: Any,
        refinement: Any,
        server_protocol: Any,
        emit_progress: Callable[..., None],
        is_skip_tracking_enabled: Callable[[str], bool],
        defaults_json: bool,
        should_prompt_for_defaults: Callable[[], bool],
    ) -> None:
        self._runtime_state = runtime_state
        self._session_guard = session_guard
        self._working_dir = working_dir
        self._invocation = invocation
        self._refinement = refinement
        self._server_protocol = server_protocol
        self._emit_progress = emit_progress
        self._is_skip_tracking_enabled = is_skip_tracking_enabled
        self._defaults_json = defaults_json
        self._should_prompt_for_defaults = should_prompt_for_defaults

    def get_items_completed(self) -> int:
        return self._invocation.items_completed_this_invocation

    def increment_items_completed(self) -> None:
        self._invocation.items_completed_this_invocation += 1

    def get_verification_tools(self) -> dict[str, Any] | None:
        return self._runtime_state.verification_tools

    def set_verification_tools(self, value: dict[str, Any] | None) -> None:
        self._runtime_state.verification_tools = value

    def get_verification_preflight_attempted(self) -> bool:
        return self._runtime_state.verification_preflight_attempted

    def set_verification_preflight_attempted(self, value: bool) -> None:
        self._runtime_state.verification_preflight_attempted = value

    def get_was_interrupted(self) -> bool:
        return self._invocation.was_interrupted

    def set_was_interrupted(self, value: bool) -> None:
        self._invocation.was_interrupted = value

    def get_last_item_id(self) -> str | None:
        return self._runtime_state.last_item_id

    def set_last_item_id(self, value: str | None) -> None:
        self._runtime_state.last_item_id = value

    def get_last_userplan_id(self) -> str | None:
        return self._runtime_state.last_userplan_id

    def set_last_userplan_id(self, value: str | None) -> None:
        self._runtime_state.last_userplan_id = value

    def get_last_userplan_version(self) -> int | None:
        return self._runtime_state.last_userplan_version

    def set_last_userplan_version(self, value: int | None) -> None:
        self._runtime_state.last_userplan_version = value

    def get_derive_from_step(self) -> int | None:
        return self._runtime_state.derive_from_step

    def set_derive_from_step(self, value: int | None) -> None:
        self._runtime_state.derive_from_step = value

    def get_preserved_plan_items(self) -> list[dict[str, Any]]:
        return self._runtime_state.preserved_plan_items

    def set_preserved_plan_items(self, value: list[dict[str, Any]] | None) -> None:
        self._runtime_state.preserved_plan_items = value or []

    def get_last_derivation_plan_items(self) -> list[dict[str, Any]]:
        return self._runtime_state.last_derivation_plan_items

    def set_last_derivation_plan_items(
        self, value: list[dict[str, Any]] | None
    ) -> None:
        self._runtime_state.last_derivation_plan_items = value or []

    def get_tasks_total(self) -> int:
        return self._runtime_state.tasks_total

    def set_tasks_total(self, value: int | None) -> None:
        self._runtime_state.tasks_total = value or 0

    def get_refinement_cycle_count(self) -> int:
        return self._refinement.cycle_count

    def set_refinement_cycle_count(self, value: int) -> None:
        self._refinement.cycle_count = value

    def get_refinement_start_time(self) -> float | None:
        return self._refinement.start_time

    def set_refinement_start_time(self, value: float | None) -> None:
        self._refinement.start_time = value

    def get_refinement_last_blocking_count(self) -> int | None:
        return self._refinement.last_blocking_count

    def set_refinement_last_blocking_count(self, value: int | None) -> None:
        self._refinement.last_blocking_count = value or 0

    def to_execution_state(self) -> ExecutionState:
        """Build the dispatch-facing execution-state protocol object."""
        return ExecutionState(
            session_guard=self._session_guard,
            objective=self._runtime_state.objective,
            working_dir=self._working_dir,
            get_items_completed=self.get_items_completed,
            increment_items_completed=self.increment_items_completed,
            skip_completed_items=self._runtime_state.skip_completed_items,
            resume_completed_item_ids=self._runtime_state.resume_completed_item_ids,
            skipped_item_ids=self._runtime_state.skipped_item_ids,
            locally_started_items=self._server_protocol._locally_started_items,
            locally_completed_items=self._server_protocol._locally_completed_items,
            get_verification_tools=self.get_verification_tools,
            set_verification_tools=self.set_verification_tools,
            get_verification_preflight_attempted=self.get_verification_preflight_attempted,
            set_verification_preflight_attempted=self.set_verification_preflight_attempted,
            get_was_interrupted=self.get_was_interrupted,
            set_was_interrupted=self.set_was_interrupted,
            get_last_item_id=self.get_last_item_id,
            set_last_item_id=self.set_last_item_id,
            get_last_userplan_id=self.get_last_userplan_id,
            set_last_userplan_id=self.set_last_userplan_id,
            get_last_userplan_version=self.get_last_userplan_version,
            set_last_userplan_version=self.set_last_userplan_version,
            get_derive_from_step=self.get_derive_from_step,
            set_derive_from_step=self.set_derive_from_step,
            get_preserved_plan_items=self.get_preserved_plan_items,
            set_preserved_plan_items=self.set_preserved_plan_items,
            get_last_derivation_plan_items=self.get_last_derivation_plan_items,
            set_last_derivation_plan_items=self.set_last_derivation_plan_items,
            get_tasks_total=self.get_tasks_total,
            set_tasks_total=self.set_tasks_total,
            get_refinement_cycle_count=self.get_refinement_cycle_count,
            set_refinement_cycle_count=self.set_refinement_cycle_count,
            get_refinement_start_time=self.get_refinement_start_time,
            set_refinement_start_time=self.set_refinement_start_time,
            get_refinement_last_blocking_count=self.get_refinement_last_blocking_count,
            set_refinement_last_blocking_count=self.set_refinement_last_blocking_count,
            is_skip_tracking_enabled=self._is_skip_tracking_enabled,
            emit_progress=self._emit_progress,
            defaults_json=self._defaults_json,
            should_prompt_for_defaults=self._should_prompt_for_defaults,
        )
