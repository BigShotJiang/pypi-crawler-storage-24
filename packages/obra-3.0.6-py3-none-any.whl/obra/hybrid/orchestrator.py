"""Hybrid Orchestrator for EPIC-HYBRID-001.

This module provides the client-side orchestration logic for the Unified Hybrid Architecture.
It connects to the server, dispatches actions to appropriate handlers, and manages the
orchestration loop.

Design Principle (from PRD):
    - Server owns the brain (decisions, orchestration logic)
    - Client owns the hands (execution, code access)

The HybridOrchestrator:
    1. Starts a session with the server
    2. Receives action instructions from the server
    3. Dispatches to appropriate handlers (derive, examine, revise, execute, review, fix)
    4. Reports results back to the server
    5. Repeats until completion or escalation

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 3
    - obra/api/protocol.py
    - obra/hybrid/handlers/*.py
"""

from __future__ import annotations

import logging
import os
import sys
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from pydantic import BaseModel

if TYPE_CHECKING:
    from obra.hybrid.dispatch.dispatcher import _ResolvedItemOutcome
    from obra.hybrid.dispatch.handler_factory import HandlerFactory

from obra.api import APIClient
from obra.api.protocol import (
    DEFAULT_REPORT_REVIEW_AGENT_TYPES,
    ActionType,
    CompletionNotice,
    EscalationDecision,
    EscalationNotice,
    ResumeContext,
    ServerAction,
    SessionPhase,
)
from obra.config import (
    get_watchdog_enabled,
    get_watchdog_max_silent_seconds,
    get_watchdog_stall_timeout,
)
from obra.constants import (
    HYBRID_POLLING_BACKOFF_MULTIPLIER,
    HYBRID_POLLING_BASE_DELAY_S,
    HYBRID_POLLING_MAX_DELAY_S,
)
from obra.constants import (
    MAX_POLLING_RETRIES as DEFAULT_MAX_POLLING_RETRIES,
)

# FEAT-PROCESS-LIFECYCLE-001: Process lifecycle management for subprocess cleanup
from obra.core.process_registry import (
    ProcessRegistry,
    create_process_registry_from_config,
)
from obra.display import console, print_info, print_warning
from obra.display.observability import ObservabilityConfig, ProgressEmitter
from obra.escalation.config import EscalationConfig
from obra.escalation.manager import EscalationManager
from obra.exceptions import (
    APIError,
    ConfigurationError,
    ConnectionError,
    ErrorContext,
    OrchestratorError,
)
from obra.hybrid.contract_validator import SessionContractValidator

# ISSUE-SAAS-042: Use HybridEventLogger for observability
# This is the SaaS-spec logger - always available in published package
from obra.hybrid.dispatch.dispatcher import ActionDispatcher
from obra.hybrid.error_handler import ErrorHandler
from obra.hybrid.event_logger import HybridEventLogger
from obra.hybrid.git_ops import GitOperations
from obra.hybrid.health_monitor import HealthMonitor
from obra.hybrid.llm_setup import LLMConfigurator
from obra.hybrid.plan_merger import PlanMerger
from obra.hybrid.progress_tracker import ProgressTracker
from obra.hybrid.project_context import ProjectContextBuilder
from obra.hybrid.runtime_bootstrap import (
    SessionDisplayContext,
    build_dispatcher,
    build_dispatcher_handler_factory,
    build_execution_state,
    build_handler_factory,
    build_observability_context,
    build_phase_control,
    resolve_from_config_bootstrap,
)
from obra.hybrid.runtime_state import HybridRuntimeState
from obra.hybrid.server_protocol import ServerProtocol

# FEAT-SESSION-GUARD-001: Session runtime guard (zombie prevention)
from obra.hybrid.session_guard import SessionGuard
from obra.messages import get_message

# Production logger for detailed derivation metrics and quality observability
from obra.observability.production_logger import ProductionLogger
from obra.review.config import ReviewConfig
from obra.utils.obra_home import get_runtime_dir

logger = logging.getLogger(__name__)

DEFAULT_MAX_USERPLAN_STEPS_LOGGED = 200
DEFAULT_MAX_DERIVED_ITEMS_LOGGED = 200
DEFAULT_MAX_PLAN_TITLE_LEN = 300
PLAN_SNAPSHOT_DIRNAME = "plan_snapshots"

# ISSUE-CLI-012: Maximum polling retry attempts before circuit breaker triggers
# Set to 5 per industry best practices (AWS, Google Cloud, Stripe all use 3-5)
# Observed behavior showed 7 attempts before manual termination
MAX_POLLING_RETRIES = DEFAULT_MAX_POLLING_RETRIES

# Bypass mode severity classification.
# Safety overrides relax quality gates or validation — these warrant a prominent Warning.
# All other modes (workflow modifiers, continuation optimizations) are informational.
_SAFETY_OVERRIDE_MODES: frozenset[str] = frozenset({
    "planning_permissive",
    "permissive_planning",
    "permissive",
    "skip_quality_check",
    "skip_tier_check",
    "skip_complexity_check",
})

_PERMISSIVE_PLANNING_MODES: frozenset[str] = frozenset({
    "planning_permissive",
    "permissive_planning",
    "permissive",
})



# ---------------------------------------------------------------------------
# Value objects — group logically related __init__ attributes
# ---------------------------------------------------------------------------


@dataclass
class TraceContext:
    """Telemetry trace identifiers for the current session."""

    trace_id: str | None = None
    pipeline_start_time: float | None = None
    pipeline_span_id: str | None = None
    phase_span_id: str | None = None
    component: str = "hybrid_client"


@dataclass
class InvocationState:
    """Per-invocation mutable counters and identifiers."""

    was_interrupted: bool = False
    items_completed_this_invocation: int = 0
    invocation_id: str | None = None
    invocation_index: int | None = None
    invocation_start_time: float | None = None

    def reset(self) -> None:
        """Reset all fields to their defaults."""
        self.was_interrupted = False
        self.items_completed_this_invocation = 0
        self.invocation_id = None
        self.invocation_index = None
        self.invocation_start_time = None


@dataclass
class WatchdogState:
    """Watchdog timer configuration and runtime state."""

    enabled: bool = False
    stall_timeout: float = 300.0
    max_silent_seconds: float = 600.0
    last_event_time: float = field(default_factory=time.time)
    handler_active: bool = False
    last_action_payload: dict[str, Any] = field(default_factory=dict)


@dataclass
class RefinementState:
    """Refinement-loop cycle counters and parallel batch metrics."""

    cycle_count: int = 0
    start_time: float | None = None
    last_blocking_count: int = 0
    parallel_examine_speedups: list[float] = field(default_factory=list)
    parallel_examine_stragglers: list[float] = field(default_factory=list)
    parallel_examine_metrics_by_cycle: dict[int, dict[str, float]] = field(
        default_factory=dict
    )
    parallel_revise_speedups: list[float] = field(default_factory=list)
    parallel_max_straggler: float = 1.0


# P0-2: Module-level callback for force-quit terminal event emission.
# Set when an orchestrator session starts; called by CLI before os._exit().
# os._exit() bypasses atexit handlers, so this explicit hook is required.
_force_quit_terminal_callback: Callable[[], None] | None = None


def emit_force_quit_terminal_event() -> None:
    """Emit session_interrupted event before os._exit() force-quit.

    Called by the CLI signal handler immediately before os._exit(130).
    The atexit handler does NOT fire on os._exit(), so this explicit
    call is the only way to ensure dashboard reconciliation.
    """
    global _force_quit_terminal_callback
    if _force_quit_terminal_callback is not None:
        try:
            _force_quit_terminal_callback()
        except Exception:
            pass  # Best-effort — must not block force-quit


class HybridOrchestrator:
    """Client-side orchestrator for Obra hybrid architecture.

    ## Architecture

    This orchestrator implements the **client-side** of the Obra SaaS hybrid
    architecture (ADR-035):

    - **Server**: Provides orchestration decisions, action instructions, and validation
    - **Client**: Builds prompts locally, executes LLM/agents, reports results

    ## Handler Responsibilities

    Each handler (`DeriveHandler`, `ExamineHandler`, etc.) implements client-side logic:
    1. Receives action request from server (objective, plan items, issues, etc.)
    2. Builds prompts entirely client-side
    3. Gathers tactical context locally (files, git, errors)
    4. Invokes LLM or agent locally
    5. Reports results back to server for validation

    Note: The marker-based prompt enrichment described in ADR-035 is an aspirational
    design. The current implementation builds prompts entirely client-side.

    ## Privacy Model

    Tactical context (file contents, git messages, errors) stays client-side.
    Server never receives file contents or local project details.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md
    """

    def __init__(
        self,
        client: APIClient,
        working_dir: Path | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        review_config: ReviewConfig | None = None,
        defaults_json: bool = False,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        """Initialize HybridOrchestrator.

        Args:
            client: APIClient for server communication
            working_dir: Working directory for file operations
            on_progress: Optional callback for progress updates (action, payload)
            on_escalation: Optional callback for handling escalations
            on_stream: Optional callback for LLM streaming chunks (event_type, content)
            review_config: Review configuration (selection/modifiers/output)
            defaults_json: Whether to output JSON defaults
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
        """
        self._client = client
        # GIT-HARD-001 S2.T3: Track if working_dir was explicitly provided (for Inbox exemption)
        self._working_dir_explicit = working_dir is not None
        self._working_dir = working_dir or Path.cwd()
        self._runtime_state = HybridRuntimeState(
            session_display_context=SessionDisplayContext()
        )
        self._trace = TraceContext()
        self._project_id: str | None = None
        self._project_name: str | None = None
        self._on_progress = on_progress
        self._on_escalation = on_escalation
        self._on_stream = on_stream
        self._bypass_notice_keys: set[str] = set()  # Dedupe bypass warnings per phase/session
        self._session_start_contract_warnings: list[str] = []
        self._defaults_json = defaults_json
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        # REFACTOR-SERVER-PROTOCOL-001 S1.T0: All dedup state and resume timestamp
        # moved to ServerProtocol. Tier 2 (item/phase) sets are exposed via delegation
        # properties below; Tier 1 (event-ID) sets are exclusively on ServerProtocol.
        self._config: dict[str, Any] | None = None
        self._domain: Any = None
        try:
            from obra.domains.loader import load_domain

            self._domain = load_domain("software")
        except Exception:
            self._domain = None

        # REFACTOR-SERVER-PROTOCOL-001 S0.T3: ServerProtocol created here;
        # _progress_cursor is a delegation property (see below the class init block).
        # Callbacks use lambdas so test patches on orchestrator attributes are picked up
        # at call time (e.g. patch.object(orchestrator, "_log_session_event") works).
        self._server_protocol = ServerProtocol(
            session_id=self._session_id or "",
            request_fn=lambda *a, **kw: self._request_with_observability(*a, **kw),
            emit_progress=self._emit_progress,
            log_session_event=lambda *a, **kw: self._log_session_event(*a, **kw),
            on_progress=(
                (lambda *a, **kw: self._on_progress(*a, **kw))
                if self._on_progress is not None
                else None
            ),
            progress_emitter=self._progress_emitter,
            config=self._config,
            # REFACTOR-SERVER-PROTOCOL-001 S2.T5: injectable callables for payload builders
            normalize_plan_items_fn=lambda items: self._normalize_plan_items_for_api(items),
            summarize_plan_items_fn=lambda items: self._summarize_plan_items(items),
            merge_rederivation_fn=lambda **kw: self._merge_plan_items_for_rederivation(**kw),
            update_userplan_steps_fn=lambda **kw: self._client.update_userplan_steps_status_batch(**kw),
            # Plan snapshot lambdas so test mocks on orchestrator methods are honoured
            read_plan_snapshot_fn=lambda sid: self._read_plan_snapshot(sid),
            write_plan_snapshot_fn=lambda **kw: self._write_plan_snapshot(**kw),
        )

        # Handler registry - pre-allocated so tests can pre-populate before factory init.
        # Passed as handlers_cache to HandlerFactory so both share the same dict object.
        self._handlers: dict[ActionType | tuple[ActionType, str], Any] = {}

        # Runtime collaborators are prepared explicitly before use and rebuilt when
        # session-start state changes.
        self._handler_factory: HandlerFactory | None = None

        # Action dispatcher is prepared explicitly alongside the handler factory.
        self._dispatcher: ActionDispatcher | None = None

        # LLM config - set by from_config() or defaults to None
        self._llm_config: dict[str, Any] | None = None

        # Phase tracking for observability (S3.T3)
        self._current_phase: SessionPhase | None = None
        self._phase_start_time: float | None = None

        # Polling failure tracking for diagnostics
        self._polling_failure_count: int = 0
        self._imported_plan_context: dict[str, Any] | None = None

        # P1-2: Track in-flight client requests for shutdown reconciliation
        self._inflight_client_requests: set[str] = set()

        # Session-level fix result accumulator for escalation summary context.
        # Populated by _report_fix_result; included in escalation_decision events.
        self._fix_result_history: list[dict[str, Any]] = []

        # Escalation lifecycle management (REFACTOR-ESCALATION-001)
        self._escalation_manager = EscalationManager(
            log_session_event=self._log_session_event,
            progress_emitter=self._progress_emitter,
            on_escalation=self._on_escalation,
            config=EscalationConfig.from_config(self._config or {}),
            fix_result_history=self._fix_result_history,
        )

        # FEAT-SESSION-CLOSEOUT-001: Invocation tracking for cumulative runtime
        self._invocation = InvocationState()

        # Refinement cycle tracking and parallelization telemetry
        self._refinement = RefinementState()

        # REFACTOR-PLAN-MERGE-001: Plan merging module delegation
        self._plan_merger = PlanMerger(
            working_dir=self._working_dir,
            llm_config=self._llm_config or {},
            progress_emitter=self._progress_emitter,
            log_event=self._log_session_event,
            trace_id=self._trace.trace_id,
        )
        self._project_context_builder = ProjectContextBuilder(
            working_dir=self._working_dir,
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        self._contract_validator = SessionContractValidator(
            logger=logger,
            safety_override_modes=_SAFETY_OVERRIDE_MODES,
            console=console,
            # Resolve through module globals at call time so tests patching
            # obra.hybrid.orchestrator.print_warning/print_info still intercept.
            print_warning=lambda message: print_warning(message),
            print_info=lambda message: print_info(message),
        )

        # S0.T7: Track verification tools for mid-session Story 0 injection
        # If FIX needs verification tools and none are available, re-run Story 0
        # ISSUE-SAAS-042: Initialize HybridEventLogger for observability
        # This is the SaaS-spec logger - always available in published package
        self._event_logger = HybridEventLogger()
        self._event_logger.set_component(self._trace.component)

        # Production logger for detailed derivation/quality metrics
        # Writes to resolved runtime logs/production.jsonl with structured events
        self._production_logger: ProductionLogger | None = None

        # FEAT-REFINEMENT-PARALLEL-001 S3.T4: C9 dependency validation cache.
        # Stores SHA256 of the dependency graph to skip redundant validation.
        self._c9_graph_hash: str | None = None

        # Review configuration for handler creation
        # Use from_cli_and_config to respect feature gates (quality_automation.agents.*)
        self._review_config = review_config or ReviewConfig.from_cli_and_config(
            project_path=Path(self._working_dir) if self._working_dir else None
        )
        self._server_review_agent_types: set[str] = set(
            DEFAULT_REPORT_REVIEW_AGENT_TYPES
        )

        # FEAT-PROCESS-LIFECYCLE-001: Process registry for subprocess cleanup
        # Set by from_config() based on orchestration.process_cleanup config
        self._process_registry: ProcessRegistry | None = None

        # ISSUE-HYBRID-003: Session watchdog for stall detection
        self._watchdog = WatchdogState(
            enabled=get_watchdog_enabled(),
            stall_timeout=get_watchdog_stall_timeout(),
            max_silent_seconds=get_watchdog_max_silent_seconds(),
            last_event_time=time.time(),
        )

        # FEAT-RESILIENCE-P2-001: Graceful degradation tracking
        self._degraded_mode = False

        # FEAT-SESSION-GUARD-001: Session runtime guard (zombie prevention)
        self._session_guard: SessionGuard | None = None

        # REFACTOR-ORCH-EXTRACT-001: Git operations extracted module
        self._git_ops = GitOperations(
            working_dir=self._working_dir,
            session_id_getter=lambda: self._session_id,
            get_session_files=lambda field: self._get_session_files(field),
            llm_config_getter=lambda: self._llm_config,
            working_dir_explicit=self._working_dir_explicit,
            domain=lambda: self._domain,
        )

        # REFACTOR-ORCH-EXTRACT-001: Health monitoring extracted module
        self._health_monitor = HealthMonitor(
            watchdog=self._watchdog,
            session_guard_getter=lambda: self._session_guard,
            config_getter=lambda: self._config,
            event_logger_getter=lambda: self._event_logger,
            session_id_getter=lambda: self._session_id,
            working_dir_getter=lambda: self._working_dir,
            invocation=self._invocation,
            current_phase_getter=lambda: self._current_phase,
        )

        # REFACTOR-ORCH-EXTRACT-001: Error and interrupt handling extracted module
        self._error_handler = ErrorHandler(
            invocation=self._invocation,
            trace=self._trace,
            watchdog=self._watchdog,
            refinement=self._refinement,
            event_logger=self._event_logger,
            session_id_getter=lambda: self._session_id,
            project_id_getter=lambda: self._project_id,
            current_phase_getter=lambda: self._current_phase,
            current_phase_setter=lambda v: setattr(self, "_current_phase", v),
            phase_start_time_getter=lambda: self._phase_start_time,
            phase_start_time_setter=lambda v: setattr(self, "_phase_start_time", v),
            was_escalated_getter=lambda: self._was_escalated,
            last_item_id_getter=lambda: self._last_item_id,
            polling_failure_count_getter=lambda: self._polling_failure_count,
            degraded_mode_getter=lambda: self._degraded_mode,
            tasks_total_getter=lambda: self._tasks_total,
            fix_result_history_getter=lambda: self._fix_result_history,
            locally_completed_phases=self._server_protocol._locally_completed_phases,
            emit_progress=self._emit_progress,
            session_completed_logged_getter=lambda: self._session_completed_logged,
            session_interrupted_logged_getter=lambda: self._session_interrupted_logged,
            session_interrupted_logged_setter=lambda v: setattr(self._event_logger, "session_interrupted_logged", v),
        )

        # REFACTOR-ORCH-EXTRACT-001: Progress and phase tracking extracted module
        self._progress_tracker = ProgressTracker(
            invocation=self._invocation,
            trace=self._trace,
            refinement=self._refinement,
            event_logger=self._event_logger,
            current_phase_getter=lambda: self._current_phase,
            current_phase_setter=lambda v: setattr(self, "_current_phase", v),
            phase_start_time_getter=lambda: self._phase_start_time,
            phase_start_time_setter=lambda v: setattr(self, "_phase_start_time", v),
            last_derivation_plan_items_getter=lambda: self._last_derivation_plan_items,
            last_item_id_getter=lambda: self._last_item_id,
            locally_completed_items=self._server_protocol._locally_completed_items,
            locally_completed_phases=self._server_protocol._locally_completed_phases,
            locally_started_phases=self._server_protocol._locally_started_phases,
            tasks_total_getter=lambda: self._tasks_total,
            was_escalated_getter=lambda: self._was_escalated,
            emit_progress=self._emit_progress,
            log_session_event=lambda evt, **kw: self._log_session_event(evt, **kw),
        )

        # REFACTOR-ORCH-EXTRACT-001: LLM configuration extracted module
        self._llm_configurator = LLMConfigurator(
            llm_config_getter=lambda: self._llm_config,
            server_review_agent_types=self._server_review_agent_types,
            working_dir=self._working_dir,
            build_error_context=lambda **kw: self._build_error_context(**kw),
            session_display_getter=lambda: self._session_display_context,
        )

        logger.debug(f"HybridOrchestrator initialized for {self._working_dir}")

    @property
    def _was_escalated(self) -> bool:
        """Whether this session ever experienced an escalation (permanent flag).

        Delegates to EscalationManager.was_escalated which tracks the
        permanent ``_ever_escalated`` flag in the state machine.
        """
        return self._escalation_manager.was_escalated

    @property
    def _progress_cursor(self) -> str | None:
        """Delegation property — progress cursor lives on ServerProtocol."""
        return self._server_protocol._progress_cursor

    @_progress_cursor.setter
    def _progress_cursor(self, value: str | None) -> None:
        self._server_protocol._progress_cursor = value

    @property
    def _session_id(self) -> str | None:
        return self._runtime_state.session_id

    @_session_id.setter
    def _session_id(self, value: str | None) -> None:
        self._runtime_state.session_id = value

    @property
    def _objective(self) -> str | None:
        return self._runtime_state.objective

    @_objective.setter
    def _objective(self, value: str | None) -> None:
        self._runtime_state.objective = value

    @property
    def _domain_resolution(self) -> dict[str, Any] | None:
        return self._runtime_state.domain_resolution

    @_domain_resolution.setter
    def _domain_resolution(self, value: dict[str, Any] | None) -> None:
        self._runtime_state.domain_resolution = value

    @property
    def _planning_mode(self) -> str | None:
        return self._runtime_state.planning_mode

    @_planning_mode.setter
    def _planning_mode(self, value: str | None) -> None:
        self._runtime_state.planning_mode = value

    @property
    def _bypass_modes(self) -> list[str]:
        return self._runtime_state.bypass_modes

    @_bypass_modes.setter
    def _bypass_modes(self, value: list[str] | None) -> None:
        self._runtime_state.bypass_modes = list(value or [])

    @property
    def _bypass_modes_validated(self) -> bool:
        return self._runtime_state.bypass_modes_validated

    @_bypass_modes_validated.setter
    def _bypass_modes_validated(self, value: bool) -> None:
        self._runtime_state.bypass_modes_validated = value

    @property
    def _session_display_context(self) -> SessionDisplayContext:
        context = self._runtime_state.session_display_context
        if isinstance(context, SessionDisplayContext):
            return context
        fresh = SessionDisplayContext()
        self._runtime_state.session_display_context = fresh
        return fresh

    @_session_display_context.setter
    def _session_display_context(self, value: SessionDisplayContext) -> None:
        self._runtime_state.session_display_context = value

    @property
    def _skip_completed_items(self) -> list[str]:
        return self._runtime_state.skip_completed_items

    @_skip_completed_items.setter
    def _skip_completed_items(self, value: list[str] | None) -> None:
        self._runtime_state.skip_completed_items = list(value or [])

    @property
    def _skipped_item_ids(self) -> set[str]:
        return self._runtime_state.skipped_item_ids

    @_skipped_item_ids.setter
    def _skipped_item_ids(self, value: set[str] | None) -> None:
        self._runtime_state.skipped_item_ids = set(value or set())

    @property
    def _resume_completed_item_ids(self) -> set[str] | None:
        return self._runtime_state.resume_completed_item_ids

    @_resume_completed_item_ids.setter
    def _resume_completed_item_ids(self, value: set[str] | None) -> None:
        self._runtime_state.resume_completed_item_ids = (
            set(value) if value is not None else None
        )

    @property
    def _verification_tools(self) -> dict[str, Any] | None:
        return self._runtime_state.verification_tools

    @_verification_tools.setter
    def _verification_tools(self, value: dict[str, Any] | None) -> None:
        self._runtime_state.verification_tools = value

    @property
    def _verification_preflight_attempted(self) -> bool:
        return self._runtime_state.verification_preflight_attempted

    @_verification_preflight_attempted.setter
    def _verification_preflight_attempted(self, value: bool) -> None:
        self._runtime_state.verification_preflight_attempted = value

    @property
    def _last_item_id(self) -> str | None:
        return self._runtime_state.last_item_id

    @_last_item_id.setter
    def _last_item_id(self, value: str | None) -> None:
        self._runtime_state.last_item_id = value

    @property
    def _last_userplan_id(self) -> str | None:
        return self._runtime_state.last_userplan_id

    @_last_userplan_id.setter
    def _last_userplan_id(self, value: str | None) -> None:
        self._runtime_state.last_userplan_id = value

    @property
    def _last_userplan_version(self) -> int | None:
        return self._runtime_state.last_userplan_version

    @_last_userplan_version.setter
    def _last_userplan_version(self, value: int | None) -> None:
        self._runtime_state.last_userplan_version = value

    @property
    def _preserved_plan_items(self) -> list[dict[str, Any]]:
        return self._runtime_state.preserved_plan_items

    @_preserved_plan_items.setter
    def _preserved_plan_items(self, value: list[dict[str, Any]] | None) -> None:
        self._runtime_state.preserved_plan_items = list(value or [])

    @property
    def _derive_from_step(self) -> int | None:
        return self._runtime_state.derive_from_step

    @_derive_from_step.setter
    def _derive_from_step(self, value: int | None) -> None:
        self._runtime_state.derive_from_step = value

    @property
    def _last_derivation_plan_items(self) -> list[dict[str, Any]]:
        return self._runtime_state.last_derivation_plan_items

    @_last_derivation_plan_items.setter
    def _last_derivation_plan_items(
        self, value: list[dict[str, Any]] | None
    ) -> None:
        self._runtime_state.last_derivation_plan_items = list(value or [])

    @property
    def _tasks_total(self) -> int:
        return self._runtime_state.tasks_total

    @_tasks_total.setter
    def _tasks_total(self, value: int | None) -> None:
        self._runtime_state.tasks_total = value or 0

    # REFACTOR-SERVER-PROTOCOL-001 S1.T0: Tier 2 dedup sets — sets live on
    # ServerProtocol; delegation properties expose them for orchestrator handler
    # and phase management methods (lines 4386/4390/4439, 2696/2743/2765).
    # Also test files (test_telemetry_lifecycle.py, test_saas_progress_events.py).

    @property
    def _locally_completed_items(self) -> set[str]:
        """Delegation property — set lives on ServerProtocol."""
        return self._server_protocol._locally_completed_items

    @property
    def _locally_started_items(self) -> set[str]:
        """Delegation property — set lives on ServerProtocol."""
        return self._server_protocol._locally_started_items

    @property
    def _locally_completed_phases(self) -> set[str]:
        """Delegation property — set lives on ServerProtocol."""
        return self._server_protocol._locally_completed_phases

    @property
    def _locally_started_phases(self) -> set[str]:
        """Delegation property — set lives on ServerProtocol."""
        return self._server_protocol._locally_started_phases


    def _build_error_context(
        self, phase: str | None = None, action: str | None = None
    ) -> ErrorContext:
        return self._error_handler._build_error_context(phase, action)

    def get_crash_snapshot(self) -> dict[str, Any]:
        return self._error_handler.get_crash_snapshot()

    def get_last_server_action_redacted(self) -> dict[str, Any]:
        return self._error_handler.get_last_server_action_redacted()

    def _get_termination_type(self) -> str:
        return self._error_handler._get_termination_type()

    def _record_invocation(
        self,
        invocation_id: str,
        started_at: float,
        duration_seconds: float,
        termination: str,
        phase_reached: str,
        items_completed: int,
    ) -> None:
        """Record an invocation to session metadata.

        FEAT-SESSION-CLOSEOUT-001: Tracks invocation history for cumulative runtime.

        Args:
            invocation_id: Unique identifier for this invocation
            started_at: Unix timestamp when invocation started
            duration_seconds: Duration of this invocation in seconds
            termination: Termination type (completed, escalated, interrupted, error)
            phase_reached: Phase reached when invocation ended
            items_completed: Number of items completed in this invocation
        """
        if not self._session_id:
            logger.debug("Cannot record invocation: no session_id")
            return

        try:
            # Build invocation record
            invocation_record = {
                "invocation_id": invocation_id,
                "started_at": datetime.fromtimestamp(started_at, tz=UTC).isoformat(),
                "ended_at": datetime.now(UTC).isoformat(),
                "duration_seconds": duration_seconds,
                "termination": termination,
                "phase_reached": phase_reached,
                "items_completed": items_completed,
            }

            # Update session metadata via API
            # Note: The server-side coordinator will handle the metadata update
            # We emit this as an event for the server to process
            self._emit_progress(
                "invocation_recorded",
                {
                    "invocation": invocation_record,
                    "duration_seconds": duration_seconds,
                },
            )
            logger.debug(
                f"Recorded invocation {invocation_id}: {termination}, "
                f"{duration_seconds:.1f}s, {items_completed} items"
            )
        except Exception as e:
            # Don't fail the session if recording fails
            logger.warning(f"Failed to record invocation: {e}")

    def _get_session_files(self, field: str) -> list[str]:
        """Get list of files created or modified during this session.

        FEAT-SESSION-CLOSEOUT-001 S4.T1: Extract session files for closeout display.

        Args:
            field: Either "added" (created files) or "modified" (modified files).

        Returns:
            Sorted list of file paths, or empty list if unavailable.
        """
        from obra.hybrid.handlers.execute import ExecuteHandler

        execute_handler = self._handlers.get(ActionType.EXECUTE)
        if isinstance(execute_handler, ExecuteHandler):
            changes = execute_handler.get_session_file_changes()
            return sorted(getattr(changes, field))
        return []

    def _run_git_command(self, args: list[str]) -> str:
        return self._git_ops._run_git_command(args)

    def _commit_orphaned_changes(self) -> str:
        return self._git_ops._commit_orphaned_changes()

    def _extract_work_summary(self) -> list[str]:
        return self._progress_tracker._extract_work_summary()

    @staticmethod
    def _count_task_items(plan_items: list[dict[str, Any]] | None) -> int:
        return ProgressTracker._count_task_items(plan_items)

    def get_closeout_progress_snapshot(self) -> dict[str, Any]:
        return self._progress_tracker.get_closeout_progress_snapshot()

    def _build_session_interrupted_payload(self, *, reason: str) -> dict[str, Any]:
        return self._error_handler._build_session_interrupted_payload(reason=reason)

    def _resolve_interrupt_reason(self, *, fallback: str) -> str:
        return self._error_handler._resolve_interrupt_reason(fallback=fallback)

    def _finalize_active_phase_for_interrupt(self, *, reason: str) -> None:
        return self._error_handler._finalize_active_phase_for_interrupt(reason=reason)

    def _emit_session_interrupted(self, *, reason: str) -> None:
        return self._error_handler._emit_session_interrupted(reason=reason)

    def create_monitoring_context(
        self,
        task_id: str | None = None,
        liveness_interval: int = 180,
    ) -> dict[str, Any] | None:
        return self._health_monitor.create_monitoring_context(task_id, liveness_interval)

    # REFACTOR-TELEMETRY-002 S2.T1: Delegation properties for terminal-event flags.
    # State lives in _event_logger; these properties provide backward-compatible
    # attribute access so flow files and tests can still read/write them directly.

    @property
    def _session_completed_logged(self) -> bool:
        return self._event_logger.session_completed_logged

    @_session_completed_logged.setter
    def _session_completed_logged(self, value: bool) -> None:
        self._event_logger.session_completed_logged = value

    @property
    def _session_interrupted_logged(self) -> bool:
        return self._event_logger.session_interrupted_logged

    @_session_interrupted_logged.setter
    def _session_interrupted_logged(self, value: bool) -> None:
        self._event_logger.session_interrupted_logged = value

    def _log_session_event(self, event_type: str, **kwargs) -> None:
        """Log hybrid session event for observability (ISSUE-SAAS-042).

        Thin wrapper around HybridEventLogger — context enrichment (trace_id,
        component, project, invocation) is now auto-injected by the logger via
        set_session_context() / set_trace_context() / set_project().

        Args:
            event_type: Event type (session_started, derivation_started, etc.)
            **kwargs: Event-specific data
        """
        # ISSUE-015: Pop session_id from kwargs to avoid collision with positional arg
        kwargs.pop("session_id", None)
        session_id = self._session_id or ""

        try:
            self._event_logger.log_event(event_type, session_id=session_id, **kwargs)
            # ISSUE-HYBRID-003: Update last event time for watchdog
            self._watchdog.last_event_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to log hybrid event '{event_type}': {e}")

    def _prepare_runtime_collaborators(self, *, force_rebuild: bool = False) -> None:
        """Prepare explicit runtime collaborators for the current session state."""
        if force_rebuild or self._handler_factory is None:
            self._handler_factory = build_handler_factory(
                working_dir=self._working_dir,
                llm_config=self._llm_config,
                domain=self._domain,
                config=self._config,
                session_id=self._session_id,
                trace_id=self._trace.trace_id,
                phase_span_id=self._trace.phase_span_id,
                on_stream=self._on_stream,
                on_progress=self._on_progress,
                observability_config=self._observability_config,
                progress_emitter=self._progress_emitter,
                production_logger=self._production_logger,
                review_config=self._review_config,
                client=self._client,
                planning_mode=self._planning_mode,
                bypass_modes=self._bypass_modes,
                work_type_override=getattr(self, "_work_type_override", None),
                process_registry=self._process_registry,
                objective=self._objective,
                log_session_event=self._log_session_event,
                get_role_llm_config=self._get_role_llm_config,
                get_review_config=self._get_review_config,
                create_monitoring_context=self.create_monitoring_context,
                handlers_cache=self._handlers,
            )

        if force_rebuild or self._dispatcher is None:
            self._dispatcher = self._build_dispatcher()

    def _resolve_item_terminal_outcome(
        self,
        current_item: dict[str, Any],
        handler_result: dict[str, Any],
        item_error: Exception | None,
    ) -> _ResolvedItemOutcome:
        """Delegation wrapper — logic lives in ActionDispatcher._resolve_item_terminal_outcome.

        Kept for test backward compatibility: test_interrupts_causality.py calls this
        method directly on the orchestrator (6 call sites).
        """
        self._prepare_runtime_collaborators()
        return self._dispatcher._resolve_item_terminal_outcome(
            current_item, handler_result, item_error
        )

    def _atexit_session_terminal_event(self) -> None:
        """Safety net: emit session_interrupted if session ended without terminal event.

        Registered via atexit.register() to cover force-quit (second Ctrl+C)
        and other abrupt exits where the finally block doesn't complete.

        P0-2: Includes tasks_completed, tasks_total, and last_phase for
        dashboard reconciliation so sessions don't show as "still running".
        """
        try:
            self._emit_session_interrupted(reason="atexit_safety_net")
        except Exception:
            pass  # Best-effort — atexit handlers must not raise

    def _force_quit_session_terminal_event(self) -> None:
        """Emit an interruption terminal event for second Ctrl+C force-quit."""
        try:
            self._emit_session_interrupted(
                reason=self._resolve_interrupt_reason(fallback="sigint_force")
            )
        except Exception:
            pass

    def log_closeout_rendered(
        self,
        banner_mode: str,
        *,
        state: str,
        quality_score: float | None,
        quality_status: str,
        epics_completed: int,
        epics_total: int,
        stories_completed: int,
        stories_total: int,
        tasks_completed: int,
        tasks_total: int,
    ) -> None:
        """Record closeout rendering details for telemetry correlation.

        Args:
            banner_mode: Banner variant used by CLI closeout rendering.
            state: Session termination state shown in closeout.
        """
        self._event_logger.log_closeout_rendered(
            banner_mode,
            state=state,
            quality_score=quality_score,
            quality_status=quality_status,
            epics_completed=epics_completed,
            epics_total=epics_total,
            stories_completed=stories_completed,
            stories_total=stories_total,
            tasks_completed=tasks_completed,
            tasks_total=tasks_total,
        )

    def _cleanup_story0_containers(self) -> None:
        """Cleanup Story 0 Docker containers on session completion."""
        if not self._session_id:
            return
        try:
            from obra.config.loaders import load_layered_config
            from obra.hybrid.handlers.story0 import cleanup_containers

            config = self._config
            if config is None:
                config, _, _ = load_layered_config(include_defaults=True)
                self._config = config
            if not config.get("story0", {}).get("docker", {}).get("cleanup_on_complete", True):
                return
            cleanup_containers(self._session_id)
        except Exception as exc:
            logger.debug("Story 0 cleanup failed: %s", exc)

    def _get_straggler_alert_threshold(self) -> float:
        return self._health_monitor._get_straggler_alert_threshold()

    def _check_stall(self) -> None:
        return self._health_monitor._check_stall()

    def _check_cli_cache_health(self, check_type: str = "pre_session") -> None:
        return self._health_monitor._check_cli_cache_health(check_type)

    def _with_graceful_degradation(
        self,
        operation_name: str,
        operation: Callable[[], Any],
        default_result: Any,
    ) -> Any:
        """Execute operation with graceful degradation on failure.

        FEAT-RESILIENCE-P2-001: Graceful degradation wrapper for non-critical operations.
        Use this for operations like metrics emission and optional logging where failures
        should not abort the session.

        Args:
            operation_name: Name of the operation for logging
            operation: Callable that performs the operation
            default_result: Value to return if operation fails

        Returns:
            Result of operation if successful, otherwise default_result

        Example:
            >>> result = self._with_graceful_degradation(
            ...     "emit_metrics",
            ...     lambda: self._emit_quality_metrics(scores),
            ...     default_result=None
            ... )
        """
        try:
            return operation()
        except Exception as e:
            logger.warning("Operation %s failed in degraded mode: %s", operation_name, str(e))
            self._degraded_mode = True
            return default_result

    def _request_with_observability(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        response_schema: type[BaseModel] | None = None,
    ) -> dict[str, Any]:
        """Make API request with observability timing events."""
        request_id = uuid.uuid4().hex
        start_time = time.time()
        start_monotonic = time.perf_counter()
        start_dt = datetime.now(UTC)
        start_iso = start_dt.isoformat()
        parent_span_id = self._event_logger.subphase_span_id or self._trace.phase_span_id or self._trace.pipeline_span_id
        self._log_session_event(
            "client_request_started",
            request_id=request_id,
            endpoint=endpoint,
            method=method,
            client_request_start_ts=start_iso,
            span_id=self._trace.pipeline_span_id,
            parent_span_id=parent_span_id,
        )
        self._inflight_client_requests.add(request_id)
        try:
            response = self._client._request(
                method,
                endpoint,
                json=json,
                response_schema=response_schema,
                request_id=request_id,
                client_request_start_ts=start_time,
            )
            status = "success"
            return cast(dict[str, Any], response)
        except Exception as e:
            status = "error"
            error_message = str(e)
            # Compute response_ts from start_dt + monotonic duration to avoid
            # wall-clock sensitivity (NTP adjustments can invert timestamps).
            duration_s = time.perf_counter() - start_monotonic
            response_ts = (start_dt + timedelta(seconds=duration_s)).isoformat()
            self._log_session_event(
                "client_request_completed",
                request_id=request_id,
                endpoint=endpoint,
                method=method,
                client_request_start_ts=start_iso,
                client_response_ts=response_ts,
                duration_ms=max(0, int(duration_s * 1000)),
                status=status,
                error_class=type(e).__name__,
                error_message=error_message,
                span_id=self._trace.pipeline_span_id,
                parent_span_id=parent_span_id,
            )
            self._inflight_client_requests.discard(request_id)
            # Attach error context to ObraError instances for debugging
            from obra.exceptions import ObraError

            if isinstance(e, ObraError) and not getattr(e, "error_context", None):
                e.error_context = self._build_error_context(action=endpoint)
            raise
        finally:
            if status == "success":
                # Compute response_ts from start_dt + monotonic duration to
                # guarantee response_ts >= start_ts regardless of clock skew.
                duration_s = time.perf_counter() - start_monotonic
                response_ts = (start_dt + timedelta(seconds=duration_s)).isoformat()
                self._log_session_event(
                    "client_request_completed",
                    request_id=request_id,
                    endpoint=endpoint,
                    method=method,
                    client_request_start_ts=start_iso,
                    client_response_ts=response_ts,
                    duration_ms=max(0, int(duration_s * 1000)),
                    status=status,
                    span_id=self._trace.pipeline_span_id,
                    parent_span_id=parent_span_id,
                )
                self._inflight_client_requests.discard(request_id)

    @classmethod
    def from_config(
        cls,
        client: APIClient | None = None,
        working_dir: Path | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        domain: str | None = None,
        domain_resolution: dict[str, Any] | None = None,
        impl_provider: str | None = None,
        impl_model: str | None = None,
        reasoning_level: str | None = None,
        review_config: ReviewConfig | None = None,
        bypass_modes: list[str] | None = None,
        defaults_json: bool = False,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        skip_git_check: bool | None = None,
        auto_init_git: bool | None = None,
        planning_mode: str | None = None,
        config_override: dict[str, Any] | None = None,
        session_display: SessionDisplayContext | None = None,
        preflight_results: dict[str, Any] | None = None,
        effective_map: dict[str, Any] | None = None,
        verbose: int = 0,
    ) -> HybridOrchestrator:
        """Create HybridOrchestrator from configuration.

        Loads APIClient from ~/.obra/config-layers/01-user.yaml.

        Args:
            client: Optional pre-authenticated APIClient override
            working_dir: Working directory for file operations
            on_progress: Optional progress callback
            on_escalation: Optional escalation callback
            on_stream: Optional streaming callback for LLM output
            domain: Optional domain module override
            impl_provider: Optional implementation provider override (S5.T1)
            impl_model: Optional implementation model override (S5.T1)
            reasoning_level: Optional reasoning level override (S5.T1)
            review_config: Optional review configuration to pass to handlers
            bypass_modes: Optional list of validation modes to bypass
            defaults_json: Whether to output JSON defaults
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            skip_git_check: Optional CLI flag to skip git validation (overrides config)
            auto_init_git: Optional CLI flag to auto-init git (overrides config)
            planning_mode: Optional planning mode override (auto, quick, standard, thorough)
            config_override: Optional config dict to replace the loaded config (e.g. story0 overrides)
            session_display: Optional typed session-display context for CLI banner data
            preflight_results: Legacy preflight results input for session display
            effective_map: Legacy effective-map input retained for compatibility
            verbose: Legacy verbosity input for session display

        Returns:
            Configured HybridOrchestrator

        Raises:
            ConfigurationError: If configuration is invalid or missing
        """
        _ = effective_map

        if client is None:
            try:
                client = APIClient.from_config()
            except ConfigurationError:
                raise
            except Exception as e:
                msg = f"Failed to create API client: {e}"
                raise ConfigurationError(msg) from e

        orchestrator = cls(
            client=client,
            working_dir=working_dir,
            on_progress=on_progress,
            on_escalation=on_escalation,
            on_stream=on_stream,
            review_config=review_config,
            defaults_json=defaults_json,
            observability_config=observability_config,
            progress_emitter=progress_emitter,
        )

        bootstrap = resolve_from_config_bootstrap(
            working_dir=working_dir,
            domain=domain,
            domain_resolution=domain_resolution,
            impl_provider=impl_provider,
            impl_model=impl_model,
            reasoning_level=reasoning_level,
            bypass_modes=bypass_modes,
            skip_git_check=skip_git_check,
            auto_init_git=auto_init_git,
            planning_mode=planning_mode,
            config_override=config_override,
            session_display=session_display,
            preflight_results=preflight_results,
            verbose=verbose,
        )

        # S5.T2: Store resolved config for handler creation
        orchestrator._llm_config = bootstrap.llm_config
        orchestrator._bypass_modes = bootstrap.bypass_modes
        orchestrator._planning_mode = bootstrap.planning_mode
        orchestrator._config = bootstrap.config
        # Re-inject real config into EscalationManager and ServerProtocol, which
        # both received None (→ {}) at __init__ time before config was loaded.
        orchestrator._escalation_manager._config = EscalationConfig.from_config(
            orchestrator._config
        )
        orchestrator._server_protocol._config = orchestrator._config
        orchestrator._domain = bootstrap.domain
        orchestrator._domain_resolution = bootstrap.domain_resolution
        orchestrator._session_display_context = bootstrap.session_display_context
        orchestrator.startup()
        return orchestrator

    def startup(self) -> None:
        """Run side-effect initialization (signal handlers, cleanup, atexit).

        Separated from from_config() so construction and initialization are
        distinct lifecycle phases. Called automatically by from_config() before
        returning, so existing callers do not need to change.
        """
        story0_config = self._config.get("story0", {}) if self._config else {}
        if story0_config.get("docker", {}).get("orphan_check_on_start", True):
            try:
                from obra.hybrid.handlers.story0 import check_orphaned_containers

                check_orphaned_containers(is_tty=sys.stdin.isatty())
            except Exception as exc:
                logger.debug("Story 0 orphan check failed: %s", exc)

        self._process_registry = create_process_registry_from_config(self._config or {})
        if self._process_registry:
            self._process_registry.install_signal_handlers()
            self._process_registry.register_atexit()
            logger.debug("ProcessRegistry initialized for subprocess lifecycle management")

    @property
    def client(self) -> APIClient:
        """Get the API client."""
        return self._client

    @property
    def working_dir(self) -> Path:
        """Get the working directory."""
        return self._working_dir

    @property
    def session_id(self) -> str | None:
        """Get the current session ID."""
        return self._session_id

    @property
    def degraded_mode(self) -> bool:
        """Check if orchestrator is running in degraded mode.

        Returns:
            True if non-critical operations have failed and degraded mode is active.
        """
        return self._degraded_mode

    def is_online(self) -> bool:
        """Check if the server is reachable.

        Returns:
            True if server is reachable, False otherwise.
        """
        try:
            self._client.health_check()
            return True
        except APIError as e:
            if e.status_code == HTTPStatus.UNAUTHORIZED.value:
                logger.warning("Health check failed: Authentication invalid (401) - %s", e)
            elif e.status_code == HTTPStatus.FORBIDDEN.value:
                logger.warning("Health check failed: Access forbidden (403) - %s", e)
            else:
                logger.warning(
                    "Health check failed: API error (status %s) - %s",
                    e.status_code or "unknown",
                    e,
                )
            return False
        except Exception as e:
            logger.warning(
                "Health check failed: %s - %s",
                type(e).__name__,
                e,
            )
            return False

    def _refresh_server_review_capabilities(self, version_info: Any) -> None:
        self._llm_configurator._refresh_server_review_capabilities(version_info)
        self._server_review_agent_types = self._llm_configurator._server_review_agent_types

    def _ordered_supported_review_agents(self) -> list[str]:
        return self._llm_configurator._ordered_supported_review_agents()

    def _ensure_online(self) -> None:
        """Ensure server is reachable.

        Raises:
            ConnectionError: If server is not reachable
            APIError: If client version is unsupported by server policy
        """
        if not self.is_online():
            raise ConnectionError()
        # Fail fast on incompatible client versions before session bootstrap.
        version_info = self._client.assert_client_version_supported()
        self._refresh_server_review_capabilities(version_info)

    def _hash_working_dir(self) -> str:
        return self._git_ops._hash_working_dir()

    def _resolve_quality_policy_mode(self) -> str | None:
        return self._llm_configurator._resolve_quality_policy_mode()

    def _build_effective_llm_map(self) -> dict[str, dict[str, str]]:
        return self._llm_configurator._build_effective_llm_map()

    def _run_provider_preflight(
        self, effective_map: dict[str, dict[str, str]]
    ) -> dict[str, dict[str, str | None]]:
        return self._llm_configurator._run_provider_preflight(effective_map)

    @property
    def effective_llm_map(self) -> dict[str, dict[str, str]]:
        """The effective LLM map built during session initialization."""
        return getattr(self, "_effective_llm_map", {})

    @property
    def preflight_results(self) -> dict[str, dict[str, str | None]]:
        """Provider preflight check results."""
        return getattr(self, "_preflight_results", {})

    def _emit_runtime_banner(self) -> None:
        """Emit a one-line banner showing backend target and log file paths.

        Helps operators verify whether the session is hitting the emulator
        or production, and where to find telemetry files.
        """
        import os

        runtime_dir = get_runtime_dir()
        hybrid_log = runtime_dir / "logs" / "hybrid.jsonl"
        production_log = runtime_dir / "logs" / "production.jsonl"
        api_url = os.environ.get("OBRA_API_BASE_URL", "")
        backend = api_url if api_url else "production"

        console.print(f"Backend: [cyan]{backend}[/cyan]")
        console.print(
            f"Logs: [dim]{hybrid_log}[/dim]  |  [dim]{production_log}[/dim]"
        )

    def _emit_llm_pipeline_banner(
        self,
        effective_map: dict[str, dict[str, str]],
        server_validation: dict[str, dict[str, Any]],
    ) -> None:
        return self._llm_configurator._emit_llm_pipeline_banner(effective_map, server_validation)

    def _get_role_llm_config(self, action: ActionType) -> dict[str, Any]:
        return self._llm_configurator._get_role_llm_config(action)

    def _get_review_config(self) -> dict[str, Any] | None:
        return self._llm_configurator._get_review_config()

    def _get_project_context(self) -> dict[str, Any]:
        """Gather minimal project context (no code content)."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.build()

    def _build_imported_plan_workflow_artifact_refs(self) -> list[dict[str, Any]]:
        """Translate imported-plan workflow identity into canonical workflow refs."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.build_imported_plan_workflow_artifact_refs()

    def _build_imported_plan_execution_input_refs(self) -> list[dict[str, Any]]:
        """Translate imported-plan execution input metadata into canonical refs."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.build_imported_plan_execution_input_refs()

    def _build_pipeline_config_execution_input_refs(
        self,
        pipeline_config: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        """Infer execution-input refs from active pipeline runner configuration."""
        return self._project_context_builder.build_pipeline_config_execution_input_refs(
            pipeline_config
        )

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Emit progress update.

        Args:
            action: Action being performed
            payload: Action payload
        """
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as e:
                logger.warning(
                    f"Progress callback failed for action '{action}': {e}",
                    exc_info=True,
                )

    def _handle_session_timeout_warning(self, runtime_hours: float, warning_count: int) -> bool:
        return self._health_monitor._handle_session_timeout_warning(runtime_hours, warning_count)

    def _update_session_guard(self) -> None:
        return self._health_monitor._update_session_guard()

    def _display_bypass_notices(self, server_action: ServerAction) -> None:
        """Render bypass-related warnings for the current action."""
        self._contract_validator.display_bypass_notices(
            server_action,
            current_phase=self._current_phase.value if self._current_phase else None,
            bypass_notice_keys=self._bypass_notice_keys,
            session_id=self._session_id,
            is_skip_tracking_enabled=self._is_skip_tracking_enabled,
            validate_bypass_modes_applied=self._validate_bypass_modes_applied,
        )

    def _validate_bypass_modes_applied(self, server_action: ServerAction) -> list[str]:
        """Check if requested bypass modes were acknowledged by server.

        Warns user if any requested modes were not activated. This helps detect
        bugs where CLI flags are parsed but not transmitted to the server.

        Args:
            server_action: Server response containing bypass_modes_active

        Returns:
            List of modes that were requested but not activated
        """
        # Only validate once per session
        if getattr(self, "_bypass_modes_validated", False):
            return []
        self._bypass_modes_validated = True

        return self._contract_validator.validate_bypass_modes_applied(
            server_action,
            requested_bypass_modes=self._bypass_modes,
        )

    def _extract_session_start_contract_warnings(self, metadata: Any) -> list[str]:
        """Extract server-reported SessionStart contract warnings from metadata."""
        return self._contract_validator.extract_session_start_contract_warnings(metadata)

    def _emit_session_start_contract_warnings(self, warnings: list[str]) -> None:
        """Display prominent SessionStart contract warnings."""
        self._contract_validator.emit_session_start_contract_warnings(warnings)

    def _append_session_start_contract_warnings(
        self, notice: CompletionNotice
    ) -> CompletionNotice:
        """Attach and re-emit SessionStart contract warnings at session end."""
        return self._contract_validator.append_session_start_contract_warnings(
            notice,
            self._session_start_contract_warnings,
        )

    def _is_skip_tracking_enabled(self, source_key: str) -> bool:
        config = self._config or {}
        skip_config = config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get(source_key, True)
        )

    def _should_prompt_for_defaults(self) -> bool:
        """Determine if we should prompt the user for defaults confirmation."""
        if self._defaults_json:
            return False

        return (
            sys.stdin.isatty()
            and os.environ.get("CI") != "true"
            and os.environ.get("OBRA_HEADLESS") != "1"
            and os.environ.get("OBRA_UNATTENDED") != "1"
        )

    def _process_proposed_defaults(
        self,
        proposed_defaults: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Delegation wrapper — logic lives in ActionDispatcher._process_proposed_defaults.

        Kept for test backward compatibility: test_defaults_flow.py calls this method
        directly on the orchestrator (2 call sites).
        """
        self._prepare_runtime_collaborators()
        return self._dispatcher._process_proposed_defaults(proposed_defaults)

    def _poll_with_backoff(
        self,
        poll_count: int,
        base_delay: float = HYBRID_POLLING_BASE_DELAY_S,
        max_delay: float = HYBRID_POLLING_MAX_DELAY_S,
        multiplier: float = HYBRID_POLLING_BACKOFF_MULTIPLIER,
    ) -> float:
        """Delegation wrapper — logic lives in ServerProtocol.poll_with_backoff."""
        return self._server_protocol.poll_with_backoff(
            poll_count,
            base_delay=base_delay,
            max_delay=max_delay,
            multiplier=multiplier,
        )

    def _action_to_phase(self, action: ActionType) -> SessionPhase | None:
        return self._progress_tracker._action_to_phase(action)

    def _progress_snapshot(self, action: ActionType | None) -> dict[str, Any]:
        return self._progress_tracker._progress_snapshot(action)

    def _detect_progress(
        self,
        before: dict[str, Any],
        next_action: ActionType | None,
        result: dict[str, Any],
    ) -> bool:
        return self._progress_tracker._detect_progress(before, next_action, result)

    def _emit_phase_event(self, action: ActionType) -> None:
        return self._progress_tracker._emit_phase_event(action)

    def _git_preflight(self) -> None:
        return self._git_ops._git_preflight()

    def _merge_plan_items_for_rederivation(
        self,
        preserved_items: list[dict[str, Any]],
        newly_derived_items: list[dict[str, Any]],
        from_step: int | None,
    ) -> list[dict[str, Any]]:
        """Merge preserved plan items with newly derived items for --from-step re-derivation."""
        return self._plan_merger.merge_plan_items_for_rederivation(
            preserved_items, newly_derived_items, from_step,
        )

    @staticmethod
    def _compute_dependency_graph_hash(plan_items: list[dict[str, Any]]) -> str:
        """Compute SHA256 of the dependency graph for C9 validation caching."""
        return PlanMerger.compute_dependency_graph_hash(plan_items)

    def _merge_revision_batch(
        self,
        base_items: list[dict[str, Any]],
        revised_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Merge revised batch items into a full plan snapshot by ID."""
        return PlanMerger.merge_revision_batch(base_items, revised_items)

    # ------------------------------------------------------------------
    # FEAT-REFINEMENT-PARALLEL-001: Parallel batch fan-out
    # ------------------------------------------------------------------

    def _handle_parallel_examine_batches(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Fan out examination batches to parallel ExamineHandler workers."""
        result = self._plan_merger.handle_parallel_examine_batches(
            payload,
            role_llm_config=self._get_role_llm_config(ActionType.EXAMINE),
            refinement_cycle_count=self._refinement.cycle_count,
            straggler_threshold=self._get_straggler_alert_threshold(),
        )
        # Sync metrics back for backward compatibility with tests that read _parallel_* attrs.
        self._refinement.parallel_examine_speedups = list(self._plan_merger.metrics.examine_speedups)
        self._refinement.parallel_examine_stragglers = list(self._plan_merger.metrics.examine_stragglers)
        self._refinement.parallel_examine_metrics_by_cycle = dict(self._plan_merger.metrics.examine_metrics_by_cycle)
        self._refinement.parallel_max_straggler = self._plan_merger.metrics.max_straggler
        return result

    def _merge_examine_batch_results(
        self,
        batch_results: list[dict[str, Any]],
        payload: dict[str, Any],
        batch_errors: list[tuple[int, Exception]] | None = None,
    ) -> dict[str, Any]:
        """Merge and deduplicate issues from parallel examine batches."""
        return self._plan_merger.merge_examine_batch_results(batch_results, payload, batch_errors)

    @staticmethod
    def _issue_dedupe_key(issue: dict[str, Any]) -> str | None:
        """Build a stable composite key for issue deduplication."""
        return PlanMerger.issue_dedupe_key(issue)

    @classmethod
    def _count_effective_blocking_issues(
        cls,
        issues: list[Any],
        bypass_modes_active: list[str] | None,
    ) -> int:
        """Count blocking issues using coordinator-equivalent bypass semantics."""
        return PlanMerger.count_effective_blocking_issues(issues, bypass_modes_active)

    # ------------------------------------------------------------------
    # FEAT-REFINEMENT-PARALLEL-001: Parallel revision batch fan-out
    # ------------------------------------------------------------------

    def _handle_parallel_revise_batches(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Fan out revision batches to parallel ReviseHandler workers."""
        # Cross-phase sync: push orchestrator examine metrics into PlanMerger before revise
        # so the parallelization_cycle_summary telemetry can read cycle-matched examine data.
        self._plan_merger.metrics.examine_metrics_by_cycle = self._refinement.parallel_examine_metrics_by_cycle
        self._plan_merger.metrics.examine_speedups = list(self._refinement.parallel_examine_speedups)
        self._plan_merger.metrics.examine_stragglers = list(self._refinement.parallel_examine_stragglers)
        result = self._plan_merger.handle_parallel_revise_batches(
            payload,
            role_llm_config=self._get_role_llm_config(ActionType.REVISE),
            refinement_cycle_count=self._refinement.cycle_count,
            c9_graph_hash=self._c9_graph_hash,
            straggler_threshold=self._get_straggler_alert_threshold(),
        )
        # Write back state from result.
        self._c9_graph_hash = result.get("c9_graph_hash", self._c9_graph_hash)
        self._refinement.parallel_revise_speedups = list(self._plan_merger.metrics.revise_speedups)
        self._refinement.parallel_max_straggler = self._plan_merger.metrics.max_straggler
        return result

    def _get_log_viewer_int(self, env_var: str, default: int) -> int:
        """Read an int from env for log viewer payload caps."""
        try:
            return max(0, int(os.environ.get(env_var, default)))
        except (TypeError, ValueError):
            return default

    def _write_plan_snapshot(
        self,
        *,
        session_id: str,
        userplan_id: str | None = None,
        userplan_version: int | None = None,
        userplan_steps: list[dict[str, Any]] | None = None,
        derived_plan_items: list[dict[str, Any]] | None = None,
    ) -> str | None:
        """Delegation wrapper — logic lives in ServerProtocol._write_plan_snapshot.

        Kept as an orchestrator method so test mocks on orchestrator._write_plan_snapshot
        are picked up by the write_plan_snapshot_fn lambda wired to ServerProtocol.
        """
        return self._server_protocol._write_plan_snapshot(
            session_id=session_id,
            userplan_id=userplan_id,
            userplan_version=userplan_version,
            userplan_steps=userplan_steps,
            derived_plan_items=derived_plan_items,
        )

    def _get_derived_plan_api_keys(self) -> set[str]:
        """Return allowed DerivedPlan item keys based on schema."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.get_derived_plan_api_keys()

    def _normalize_plan_items_for_api(
        self,
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Drop unsupported keys before sending DerivedPlan payload to server."""
        if not items:
            return items

        normalized: list[dict[str, Any]] = []
        dropped_keys_by_id: dict[str, list[str]] = {}
        dropped_key_counts: dict[str, int] = {}
        allowed_keys = self._get_derived_plan_api_keys()

        for idx, item in enumerate(items, start=1):
            if not isinstance(item, dict):
                logger.warning("DerivedPlan item %s is not a dict; passing through unchanged", idx)
                normalized.append(item)
                continue
            extra_keys = set(item.keys()) - allowed_keys
            if extra_keys:
                item_id = item.get("id") or f"item-{idx}"
                dropped_keys_by_id[item_id] = sorted(extra_keys)
                for key in extra_keys:
                    dropped_key_counts[key] = dropped_key_counts.get(key, 0) + 1
            normalized.append({key: item[key] for key in item if key in allowed_keys})

        if dropped_keys_by_id:
            logger.warning(
                "Dropped unsupported DerivedPlan item keys before report_derivation: %s",
                dropped_keys_by_id,
            )
            log_event = getattr(self, "_log_event", None)
            if log_event:
                try:
                    log_event(
                        "derived_plan_item_keys_dropped",
                        session_id=self._session_id,
                        trace_id=self._trace.trace_id,
                        parent_span_id=self._trace.phase_span_id,
                        items_with_dropped_keys=len(dropped_keys_by_id),
                        dropped_key_counts=dropped_key_counts,
                    )
                except Exception as exc:
                    logger.debug("Failed to log derived plan key drops: %s", exc)
            if self._production_logger:
                self._production_logger.log_event(
                    "derived_plan_item_keys_dropped",
                    work_unit_id="derivation",
                    items_with_dropped_keys=len(dropped_keys_by_id),
                    dropped_key_counts=dropped_key_counts,
                )

        return normalized

    def _read_plan_snapshot(self, session_id: str) -> dict[str, Any]:
        """Delegation wrapper — logic lives in ServerProtocol._read_plan_snapshot.

        Kept as an orchestrator method so test mocks on orchestrator._read_plan_snapshot
        are picked up by the read_plan_snapshot_fn lambda wired to ServerProtocol.
        """
        return self._server_protocol._read_plan_snapshot(session_id)

    def _resolve_project_name(self, project_id: str | None) -> str | None:
        """Resolve project name for logging if available."""
        if not project_id:
            return None
        try:
            project = self._client.get_project(project_id)
            if isinstance(project, dict):
                name = project.get("name") or project.get("project_name")
                if isinstance(name, str) and name.strip():
                    return name.strip()
        except Exception:
            logger.debug("Failed to resolve project name for %s", project_id, exc_info=True)
        return None

    def _summarize_plan_items(
        self, items: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], bool]:
        """Return a capped summary of derived plan items for logging."""
        max_items = self._get_log_viewer_int(
            "OBRA_LOG_VIEWER_MAX_DERIVED_ITEMS",
            DEFAULT_MAX_DERIVED_ITEMS_LOGGED,
        )
        max_title_len = self._get_log_viewer_int(
            "OBRA_LOG_VIEWER_MAX_TITLE_LEN",
            DEFAULT_MAX_PLAN_TITLE_LEN,
        )
        summarized: list[dict[str, Any]] = []
        for item in items[:max_items]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title", "")).strip()
            if len(title) > max_title_len:
                title = f"{title[:max_title_len]}..."
            context = item.get("context") if isinstance(item.get("context"), dict) else {}
            summarized.append(
                {
                    "id": item.get("id"),
                    "title": title,
                    "source_step_id": item.get("source_step_id"),
                    "userplan_step_index": (
                        context.get("userplan_step_index") if context else None
                    ),
                    "level": item.get("level"),
                    "parent_id": item.get("parent_id"),
                    "depth": item.get("depth"),
                    "path": item.get("path") or item.get("ancestry"),
                    "order": item.get("order") or item.get("index"),
                }
            )
        truncated = len(items) > max_items
        return summarized, truncated

    def _get_handler(
        self,
        action: ActionType,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        """Get handler for action type.

        Lazily imports and instantiates handlers.

        Args:
            action: Action type

        Returns:
            Handler instance

        Raises:
            OrchestratorError: If handler not found
            ConfigurationError: If llm_config is invalid or missing required keys
        """
        self._prepare_runtime_collaborators()
        return self._handler_factory.get_handler(action, payload)

    def _build_dispatcher(self) -> ActionDispatcher:
        """Construct an ActionDispatcher wired to current orchestrator state."""
        return build_dispatcher(
            observability=build_observability_context(
                runtime_state=self._runtime_state,
                trace=self._trace,
                production_logger=self._production_logger,
                progress_emitter=self._progress_emitter,
                log_session_event=self._log_session_event,
                get_log_viewer_int=self._get_log_viewer_int,
            ),
            phase_control=build_phase_control(
                current_phase_getter=lambda: self._current_phase,
                current_phase_setter=lambda p: setattr(self, "_current_phase", p),
                event_logger=self._event_logger,
                phase_start_time_getter=lambda: self._phase_start_time,
                phase_start_time_setter=lambda t: setattr(self, "_phase_start_time", t),
            ),
            execution_state=build_execution_state(
                runtime_state=self._runtime_state,
                session_guard=self._session_guard,
                working_dir=self._working_dir,
                invocation=self._invocation,
                refinement=self._refinement,
                server_protocol=self._server_protocol,
                emit_progress=self._emit_progress,
                is_skip_tracking_enabled=self._is_skip_tracking_enabled,
                defaults_json=self._defaults_json,
                should_prompt_for_defaults=self._should_prompt_for_defaults,
            ),
            handler_factory=build_dispatcher_handler_factory(
                get_handler=self._get_handler,
                request_with_observability=self._request_with_observability,
                handle_parallel_examine_batches=self._handle_parallel_examine_batches,
                handle_parallel_revise_batches=self._handle_parallel_revise_batches,
                ordered_supported_review_agents=self._ordered_supported_review_agents,
                write_plan_snapshot=self._write_plan_snapshot,
            ),
        )

    def _handle_action(self, server_action: ServerAction) -> dict[str, Any]:
        """Handle a server action by dispatching to appropriate handler.

        Args:
            server_action: Server action to handle

        Returns:
            Result to report back to server

        Raises:
            OrchestratorError: If action handling fails
        """
        action = server_action.action
        payload = server_action.payload
        self._watchdog.last_action_payload = payload  # Store for _report_result access

        logger.info(f"Handling action: {action.value} (iteration {server_action.iteration})")

        # S3.T3: Emit phase transition events
        # (Structured phase_started/phase_completed events replace the old bare
        # action-name emit that produced "unhandled progress event" debug noise.)
        self._emit_phase_event(action)

        # Handle special actions
        if action == ActionType.COMPLETE:
            completion_notice = CompletionNotice.from_payload(payload)
            return {"completed": True, "notice": completion_notice}

        if action == ActionType.ESCALATE:
            escalation_notice = EscalationNotice.from_payload(
                payload,
                metadata=(
                    server_action.metadata
                    if isinstance(server_action.metadata, dict)
                    else {}
                ),
            )
            return self._handle_escalation(escalation_notice)

        if action == ActionType.ERROR:
            error_msg = server_action.error_message or "Unknown server error"
            error_code = server_action.error_code or "UNKNOWN"
            msg = f"Server error [{error_code}]: {error_msg}"
            # Add recovery hint for server errors (often 500 errors from Cloud Functions)
            if self._session_id:
                short_id = self._session_id.split("-")[0]
                msg += f"\n\nTry: {get_message('recovery.session.repair', short_id=short_id)}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id or "",
                error_context=self._build_error_context(action="poll_session"),
            )

        if action == ActionType.WAIT:
            # Server is processing async, wait and poll
            return {"waiting": True}

        # Get handler for action
        handler = self._get_handler(action, payload)

        # ISSUE-HYBRID-003: Mark handler as active for watchdog
        # This prevents stall detection during handler execution
        self._watchdog.handler_active = True
        try:
            return self._dispatch_handler(handler, action, payload, server_action)
        finally:
            self._watchdog.handler_active = False

    def _dispatch_handler(
        self,
        handler: Any,
        action: ActionType,
        payload: dict[str, Any],
        server_action: ServerAction | None = None,
    ) -> dict[str, Any]:
        """Dispatch request to the appropriate handler (ISSUE-HYBRID-003 refactor).

        Extracted from _handle_action to enable try/finally for handler tracking.

        Args:
            handler: Handler instance for the action
            action: Action type
            payload: Server action payload
            server_action: Original server action envelope (optional, for metadata access)

        Returns:
            Handler result dict
        """
        self._prepare_runtime_collaborators()
        self._dispatcher._obs.phase_span_id = self._trace.phase_span_id
        self._dispatcher._obs.pipeline_span_id = self._trace.pipeline_span_id
        self._dispatcher._obs.session_id = self._session_id
        return self._dispatcher.dispatch(handler, action, payload, server_action)


    def _derive_blocking_count(self, notice: EscalationNotice) -> int:
        """Derive blocking issue count — delegates to EscalationManager."""
        return self._escalation_manager.derive_blocking_count(notice)

    def _handle_escalation(self, notice: EscalationNotice) -> dict[str, Any]:
        """Handle escalation — delegates to EscalationManager.

        Returns backward-compatible dict consumed by ``_report_result``
        (keys: escalation_id, decision, reason).
        """
        outcome = self._escalation_manager.handle(notice)
        return {
            "escalation_id": outcome.escalation_id,
            "decision": outcome.decision,
            "reason": outcome.decision_reason,
        }

    def _report_result(
        self,
        action: ActionType,
        result: dict[str, Any],
    ) -> ServerAction:
        """Report action result to server.

        Args:
            action: Action that was handled
            result: Result from handler

        Returns:
            Next server action
        """
        if not self._session_id:
            msg = "No active session"
            raise OrchestratorError(
                msg,
                error_context=self._build_error_context(action="report_result"),
            )

        # Validate supported action types before entering try block (TRY301)
        supported_actions = {
            ActionType.DERIVE,
            ActionType.INTENT,
            ActionType.STORY0,
            ActionType.STORY_PREFLIGHT,
            ActionType.EXAMINE,
            ActionType.REVISE,
            ActionType.EXECUTE,
            ActionType.REVIEW,
            ActionType.FIX,
            ActionType.ESCALATE,
            ActionType.VALIDATOR,  # FEAT-SENSECHECK-PIPELINE-001
            ActionType.PIPELINE_STAGE,
        }
        if action not in supported_actions:
            msg = f"Cannot report result for action: {action.value}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id,
                error_context=self._build_error_context(action="report_result"),
            )

        try:
            # REFACTOR-SERVER-PROTOCOL-001 S2.T5: All 11 ActionType branches delegated
            # to ServerProtocol.report_result() via per-ActionType payload builders.
            ctx = self._runtime_state.build_report_context(
                last_action_payload=self._watchdog.last_action_payload,
                fix_result_history=self._fix_result_history,
                supported_review_agents=set(self._ordered_supported_review_agents()),
            )
            server_action = self._server_protocol.report_result(
                action,
                result,
                context=ctx,
                current_phase=(
                    self._current_phase.value if self._current_phase else None
                ),
                phase_span_id=self._trace.phase_span_id,
                subphase_span_id=self._event_logger.subphase_span_id,
            )
            self._display_bypass_notices(server_action)
            return server_action

        except APIError:
            raise
        except Exception as e:
            msg = f"Failed to report result: {e}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id,
                error_context=self._build_error_context(action="report_result"),
            ) from e

    def _parse_polling_action_response(
        self,
        response: dict[str, Any],
        iteration: int,
    ) -> ServerAction:
        """Delegation wrapper — logic lives in ServerProtocol.parse_polling_response."""
        # Keep ServerProtocol in sync with orchestrator session_id (test compat:
        # tests may set orchestrator._session_id directly without calling set_session_id)
        if self._server_protocol._session_id != (self._session_id or ""):
            self._server_protocol.set_session_id(self._session_id or "")
        return self._server_protocol.parse_polling_response(response, iteration)

    def _get_session_action_endpoint(self) -> str:
        """Delegation wrapper — logic lives in ServerProtocol.get_session_action_endpoint."""
        return self._server_protocol.get_session_action_endpoint()

    def _handle_progress_events_from_response(self, response: dict[str, Any]) -> None:
        """Delegation wrapper — logic lives in ServerProtocol.handle_progress_events.

        Kept for test compatibility: test_saas_progress_events.py calls this method
        directly to exercise progress event routing.
        """
        self._server_protocol.handle_progress_events(
            response,
            current_phase=self._current_phase.value if self._current_phase else None,
            phase_span_id=self._trace.phase_span_id,
            subphase_span_id=self._event_logger.subphase_span_id,
        )

    def derive(
        self,
        objective: str,
        working_dir: Path | None = None,
        project_id: str | None = None,
        max_iterations: int | None = None,
        plan_id: str | None = None,
        plan_only: bool = False,
        bypass_modes: list[str] | None = None,
        skip_completed_items: list[str] | None = None,
        userplan_id: str | None = None,
        from_step: int | None = None,
        work_type: str | None = None,
        workflow_derivation_request: dict[str, Any] | None = None,
    ) -> CompletionNotice:
        """Start a new derivation session.

        This is the main entry point for the hybrid orchestration loop.
        It creates a new session, derives a plan, refines it, executes
        the plan items, runs quality review, and completes the session.

        Args:
            objective: Task objective to plan and execute
            working_dir: Working directory (overrides instance default)
            project_id: Optional project ID override
            llm_provider: LLM provider to use
            max_iterations: Maximum orchestration loop iterations (None = use config)
            plan_id: Optional reference to uploaded plan (for plan import workflow)
            plan_only: If True, stop before execution once plan is ready (default: False)
            skip_completed_items: List of task titles to skip (for --continue-from recovery)
            userplan_id: Optional UserPlan ID (for plan file import - S2.T3)
            from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
            work_type: Manual work type override (bypasses auto-detection when provided)
            workflow_derivation_request: Optional workflow-derivation envelope
                materialized from objective and imported plan context.

        Returns:
            CompletionNotice with session summary

        Raises:
            ConnectionError: If server is not reachable
            OrchestratorError: If orchestration fails
        """
        from obra.hybrid.flows.derive import DeriveFlow
        flow = DeriveFlow(
            self,
            objective=objective,
            working_dir=working_dir,
            project_id=project_id,
            max_iterations=max_iterations,
            plan_id=plan_id,
            plan_only=plan_only,
            bypass_modes=bypass_modes,
            skip_completed_items=skip_completed_items,
            userplan_id=userplan_id,
            from_step=from_step,
            work_type=work_type,
            workflow_derivation_request=workflow_derivation_request,
        )
        return flow.run()

    def resume(
        self,
        session_id: str,
        *,
        resume_target: str | None = None,
    ) -> CompletionNotice:
        """Resume an interrupted session.

        Args:
            session_id: Session ID to resume
            resume_target: Optional lifecycle-aware phase target override

        Returns:
            CompletionNotice with session summary

        Raises:
            ConnectionError: If server is not reachable
            OrchestratorError: If session cannot be resumed
        """
        from obra.hybrid.flows.resume import ResumeFlow

        flow = ResumeFlow(
            self,
            session_id=session_id,
            resume_target=resume_target,
        )
        return flow.run()

    def get_status(self, session_id: str | None = None) -> ResumeContext:
        """Get session status.

        Args:
            session_id: Session ID to check (defaults to current session)

        Returns:
            ResumeContext with session status

        Raises:
            OrchestratorError: If no session ID provided and no active session
        """
        sid = session_id or self._session_id
        if not sid:
            msg = "No session ID provided"
            raise OrchestratorError(
                msg,
                recovery="Provide a session ID or start a new session with 'obra derive'",
            )

        try:
            response = self._request_with_observability("GET", f"session/{sid}")
            return ResumeContext.from_dict(response)
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND.value:
                msg = f"Session not found: {sid}"
                raise OrchestratorError(
                    msg,
                    recovery="The session may have expired.",
                ) from e
            raise


__all__ = [
    "ConnectionError",
    "HybridOrchestrator",
    "OrchestratorError",
    "emit_force_quit_terminal_event",
]
