"""Dependency installation subsystem extracted from Story 0 handler."""

from __future__ import annotations

import logging
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.loaders import get_story0_timeout
from obra.hybrid.install_target import InstallTargetManager
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.models.story0_state import PrerequisiteStatus

logger = logging.getLogger(__name__)

# Duplicated from story0.py to avoid circular import.
MANIFEST_TYPE_MAP = {
    "python": "pyproject.toml",
    "node": "package.json",
    "rust": "Cargo.toml",
    "go": "go.mod",
    "ruby": "Gemfile",
}


class DependencyInstaller:
    """Handles dependency detection and installation for Story 0 preflight."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        story0_config: dict[str, Any],
        llm_config: dict[str, Any],
        install_target: InstallTargetManager,
        objective: str,
        automation_mode_effective: str,
        emit_progress: Callable[[str], None],
        emit_decision_event: Callable[[str, dict[str, Any]], None],
    ) -> None:
        self._working_dir = working_dir
        self._config = config
        self._story0_config = story0_config
        self._llm_config = llm_config
        self._install_target = install_target
        self._objective = objective
        self._automation_mode_effective = automation_mode_effective
        self._emit_progress = emit_progress
        self._emit_decision_event = emit_decision_event
        self.installs_by_source: dict[str, list[str]] = {"manifest": [], "inferred": []}

    def _installer_registry(
        self,
    ) -> dict[str, Callable[[dict[str, Any]], tuple[str, str]]]:
        return {
            "pyproject.toml": self.install_dependency,
            "requirements-dev.txt": self.install_dependency,
            "package.json": self.install_dependency,
            "Cargo.toml": self.install_dependency,
            "go.mod": self.install_dependency,
            "Gemfile": self.install_dependency,
        }

    def _detect_manifest(self, registry: dict[str, Callable[..., Any]]) -> str | None:
        for manifest in registry:
            if (self._working_dir / manifest).exists():
                return manifest
        return None

    def install_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        registry = self._installer_registry()
        manifest = self._detect_manifest(registry)
        if not manifest:
            return (
                PrerequisiteStatus.FAILED.value,
                "No supported manifest found for auto-installation.",
            )

        raw_name = str(prereq.get("name") or "").strip()
        source = str(prereq.get("source") or "MANIFEST").upper()
        ecosystem = self._ecosystem_from_manifest(manifest)

        prereq_with_manifest = dict(prereq)
        prereq_with_manifest.setdefault("manifest_type", manifest)
        allowed, reason = self._should_install(prereq_with_manifest, source)
        if not allowed:
            detail = reason or "Install blocked by policy"
            self._emit_progress(f"[Preflight] Skipped: {raw_name} ({detail})")
            self._emit_decision_event(
                "package_skipped",
                {
                    "mode": self._automation_mode_effective,
                    "ecosystem": ecosystem,
                    "packages": [raw_name] if raw_name else None,
                    "target": self._story0_config.get("install_target"),
                    "reason": detail,
                },
            )
            return (PrerequisiteStatus.SKIPPED.value, detail)

        # Handle requirements file installs (no retry logic needed)
        if manifest == "requirements-dev.txt":
            manager = self._install_target.get_package_manager(
                ecosystem,
                self._story0_config.get("package_manager_preference", {}).get(ecosystem, "auto"),
                self._working_dir,
            )
            env_path = None
            if ecosystem == "python":
                toolchains = self._install_target.detect_toolchain(self._working_dir)
                python_toolchain = toolchains.get("python")
                env_path = python_toolchain.env_path if python_toolchain else None
            base_cmd = self._install_target.build_install_command(
                ecosystem,
                [],
                self._story0_config.get("install_target", "project_local"),
                manager,
                env_path,
            )
            cmd = [*base_cmd, "-r", "requirements-dev.txt"]
            status, detail = self._run_install(cmd)
        else:
            # Single package install with LLM retry on failure
            status, detail = self.install_with_llm_retry(
                raw_name=raw_name,
                ecosystem=ecosystem,
                max_retries=3,
            )

        if status == PrerequisiteStatus.INSTALLED.value:
            source_key = "manifest" if source == "MANIFEST" else "inferred"
            self.installs_by_source.setdefault(source_key, []).append(raw_name)
            self._emit_progress(f"[Preflight] Installed from {source_key}: {raw_name}")
            self._emit_decision_event(
                "package_installed",
                {
                    "mode": self._automation_mode_effective,
                    "ecosystem": ecosystem,
                    "packages": [raw_name] if raw_name else None,
                    "target": self._story0_config.get("install_target"),
                    "reason": "",
                },
            )
        return status, detail

    def _ecosystem_from_manifest(self, manifest: str | None) -> str:
        if not manifest:
            return "python"
        if manifest in ("pyproject.toml", "requirements-dev.txt", "requirements.txt"):
            return "python"
        if manifest == "package.json":
            return "node"
        if manifest == "Cargo.toml":
            return "rust"
        if manifest == "go.mod":
            return "go"
        if manifest == "Gemfile":
            return "ruby"
        return "python"

    def _should_install(self, prereq: dict[str, Any], source: str) -> tuple[bool, str]:
        install_policy = self._story0_config.get("install_policy", "manifest_then_inferred")
        allow_inferred = self._story0_config.get("allow_inferred_installs", True)
        mode = self._config.get("automation_mode", "auto_safe")
        normalized_source = source.upper()

        if install_policy == "manifest_only" and normalized_source != "MANIFEST":
            return (
                False,
                f"policy={install_policy}. Hint: Use automation_mode=auto_full to allow "
                "unrestricted installs.",
            )
        if install_policy == "manifest_then_inferred":
            if normalized_source == "INFERRED" and not allow_inferred:
                return (
                    False,
                    "inferred installs disabled. Hint: Use automation_mode=auto_full to "
                    "allow inferred installs.",
                )
        if install_policy not in (
            "manifest_only",
            "manifest_then_inferred",
            "manifest_or_inferred",
        ):
            return False, f"unsupported install policy: {install_policy}"

        if normalized_source == "INFERRED":
            self._emit_decision_event(
                "policy_applied",
                {
                    "mode": self._automation_mode_effective,
                    "ecosystem": prereq.get("ecosystem"),
                    "packages": [prereq.get("name")] if prereq.get("name") else None,
                    "target": self._story0_config.get("install_target"),
                    "reason": f"policy={install_policy}",
                },
            )

        if normalized_source == "INFERRED":
            ecosystem = str(prereq.get("ecosystem") or "").strip().lower()
            if not ecosystem:
                ecosystem = self._ecosystem_from_manifest(prereq.get("manifest_type"))
            if mode != "auto_full":
                allowed, kind = self._is_in_allowlist(str(prereq.get("name") or ""), ecosystem)
                if not allowed:
                    return (
                        False,
                        f"{prereq.get('name')} not in allowlist. Hint: Add to "
                        f"inferred_install_allowlist.{ecosystem} or use auto_full mode.",
                    )
                if mode == "auto_safe" and kind == "runtime":
                    if not self._objective_mentions_package(str(prereq.get("name") or "")):
                        return (
                            False,
                            "runtime install blocked in auto_safe mode. Hint: Use "
                            "automation_mode=auto_full to allow runtime installs.",
                        )
        return True, ""

    def _is_in_allowlist(self, package: str, ecosystem: str) -> tuple[bool, str]:
        allowlist = self._config.get("inferred_install_allowlist", {})
        if not isinstance(allowlist, dict) or not allowlist:
            return True, "both"
        entries = []
        entries.extend(allowlist.get("_common", []))
        entries.extend(allowlist.get(ecosystem, []))
        package_lower = package.lower()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name") or "").lower()
            if name and name == package_lower:
                kind = str(entry.get("kind") or "both").lower()
                if kind not in {"dev", "runtime", "both"}:
                    kind = "both"
                return True, kind
        return False, "unknown"

    def _objective_mentions_package(self, package: str) -> bool:
        if not package:
            return False
        objective_text = self._objective.lower()
        return package.lower() in objective_text

    def detect_existing_manifests(self) -> list[str]:
        manifest_names = set(MANIFEST_TYPE_MAP.values())
        manifest_names.update(
            [
                "requirements.txt",
                "requirements-dev.txt",
                "Pipfile",
                "Pipfile.lock",
                "poetry.lock",
                "uv.lock",
            ]
        )
        if not self._working_dir.exists():
            return []
        found: list[str] = []
        for name in sorted(manifest_names):
            for path in self._working_dir.rglob(name):
                if not path.is_file():
                    continue
                try:
                    found.append(str(path.relative_to(self._working_dir)))
                except ValueError:
                    found.append(str(path))
        return found

    def _install_python_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["python", "-m", "pip", "install", name]
        return self._run_install(cmd)

    def _install_requirements_dev(self, prereq: dict[str, Any]) -> tuple[str, str]:
        cmd = ["python", "-m", "pip", "install", "-r", "requirements-dev.txt"]
        return self._run_install(cmd)

    def _install_node_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["npm", "install", name]
        return self._run_install(cmd)

    def _install_rust_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["cargo", "add", name]
        return self._run_install(cmd)

    def _install_go_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["go", "get", name]
        return self._run_install(cmd)

    def _install_ruby_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["bundle", "add", name]
        return self._run_install(cmd)

    def install_with_llm_retry(
        self,
        raw_name: str,
        ecosystem: str,
        max_retries: int = 3,
    ) -> tuple[str, str]:
        """Install a package with LLM-assisted retry on failure.

        Flow:
        1. Pattern-match normalize the original name -> pip install
        2. If fails: LLM analyzes error -> suggests fix -> pip install (no pattern matching)
        3. Repeat up to max_retries times
        4. Return failure after max_retries

        Args:
            raw_name: Original package name from LLM inference
            ecosystem: Target ecosystem (python, node, etc.)
            max_retries: Maximum LLM retry attempts (default 3)

        Returns:
            Tuple of (status, detail)
        """
        if not raw_name:
            return (PrerequisiteStatus.FAILED.value, "Missing package name")

        # Build install command helper
        def build_cmd(package_name: str) -> tuple[list[str], str]:
            """Build command and return (cmd, manager) for telemetry."""
            mgr = self._install_target.get_package_manager(
                ecosystem,
                self._story0_config.get("package_manager_preference", {}).get(ecosystem, "auto"),
                self._working_dir,
            )
            env_path = None
            if ecosystem == "python":
                toolchains = self._install_target.detect_toolchain(self._working_dir)
                python_toolchain = toolchains.get("python")
                env_path = python_toolchain.env_path if python_toolchain else None
            cmd = self._install_target.build_install_command(
                ecosystem,
                [package_name],
                self._story0_config.get("install_target", "project_local"),
                mgr,
                env_path,
            )
            return cmd, mgr

        # Attempt 1: Pattern-match normalization on original name
        normalized_name = self._install_target.normalize_inferred_package_name(raw_name)
        if not normalized_name:
            return (
                PrerequisiteStatus.FAILED.value,
                f"Empty package name after normalization: {raw_name}",
            )

        cmd, resolved_manager = build_cmd(normalized_name)

        # Executable preflight: verify command target exists before running
        exe_ok, exe_detail = self._install_target.verify_command_executable(cmd)
        logger.info(
            "Install preflight: ecosystem=%s, manager=%s, executable_ok=%s, detail=%s, command=%s",
            ecosystem, resolved_manager, exe_ok, exe_detail, cmd,
        )
        if not exe_ok:
            detail = (
                f"Install command executable missing: {exe_detail}. "
                f"Resolved manager={resolved_manager!r} for ecosystem={ecosystem!r}."
            )
            logger.warning("Install preflight failed: %s", detail)
            return (PrerequisiteStatus.FAILED.value, detail)

        status, error = self._run_install(cmd)

        if status == PrerequisiteStatus.INSTALLED.value:
            return (status, error)

        # Track attempt history for LLM context
        attempts: list[dict[str, str]] = [{"package": normalized_name, "error": error}]

        # LLM retry loop (no pattern matching on LLM suggestions)
        for retry_num in range(max_retries):
            llm_suggestion = self._llm_fix_package_name(
                raw_name=raw_name,
                ecosystem=ecosystem,
                attempts=attempts,
            )

            if llm_suggestion is None:
                # LLM unavailable, skip retries
                logger.warning("LLM unavailable for install retry, giving up")
                break

            if llm_suggestion.upper() == "SKIP":
                # LLM determined this is not installable
                detail = f"LLM determined not pip-installable: {raw_name}"
                self._emit_progress(f"[Preflight] Skipped: {raw_name} ({detail})")
                return (PrerequisiteStatus.SKIPPED.value, detail)

            # Try LLM's suggestion (no pattern matching)
            self._emit_progress(
                f"[Preflight] Retry {retry_num + 1}/{max_retries}: trying '{llm_suggestion}' for '{raw_name}'"
            )
            cmd, _ = build_cmd(llm_suggestion)
            exe_ok, exe_detail = self._install_target.verify_command_executable(cmd)
            if not exe_ok:
                error = f"Install command executable missing: {exe_detail}"
                logger.warning("Retry preflight failed: %s", error)
                attempts.append({"package": llm_suggestion, "error": error})
                continue
            status, error = self._run_install(cmd)

            if status == PrerequisiteStatus.INSTALLED.value:
                return (status, error)

            attempts.append({"package": llm_suggestion, "error": error})

        # All retries exhausted
        return (PrerequisiteStatus.FAILED.value, error)

    def _llm_fix_package_name(
        self,
        raw_name: str,
        ecosystem: str,
        attempts: list[dict[str, str]],
    ) -> str | None:
        """Ask LLM to fix a failed package install.

        Args:
            raw_name: Original package name from inference
            ecosystem: Target ecosystem
            attempts: List of {"package": name, "error": error_msg} for prior attempts

        Returns:
            Suggested package name, "SKIP" if not installable, or None if LLM unavailable
        """
        if not self._llm_config:
            return None

        # Build attempt history for context
        history_lines = []
        for i, attempt in enumerate(attempts, 1):
            history_lines.append(
                f"Attempt {i}: '{attempt['package']}'\n"
                f"Error: {attempt['error'][:500]}"  # Truncate long errors
            )
        history = "\n\n".join(history_lines)

        prompt = f"""A package install failed. Analyze the errors and suggest the correct package name.

Original requested package: "{raw_name}"
Ecosystem: {ecosystem}

{history}

Instructions:
- If this is a language runtime (Python, Node.js, Go, etc.), respond with just: SKIP
- If this is a stdlib module that can't be pip-installed (tkinter, sqlite3), respond with just: SKIP
- If you can determine the correct package name, respond with just the package name (nothing else)
- If you're unsure, respond with just: SKIP

Your response (package name or SKIP):"""

        try:
            pipeline = TemplateEditPipeline(
                working_dir=self._working_dir,
                action_name="story0_install_fix",
            )

            # Simple text response, no JSON structure needed
            result, _meta = pipeline.execute(
                base_prompt=prompt,
                template_content={"suggestion": ""},
                validator=lambda d: (False, "Response must be a JSON object")
                if not isinstance(d, dict)
                else (bool(d.get("suggestion")), "Missing suggestion"),
                fallback_fn=lambda: {"suggestion": "SKIP"},
                llm_config=self._llm_config,
                max_retries=1,  # Fast, single attempt
            )

            suggestion = str(result.get("suggestion", "")).strip()
            if not suggestion:
                return "SKIP"

            # Clean up response (LLM might add quotes or extra text)
            suggestion = suggestion.strip("\"'` \n")
            if " " in suggestion and suggestion.upper() != "SKIP":
                # Multi-word response that isn't SKIP - probably explanation, skip it
                logger.debug("LLM returned multi-word response, treating as SKIP: %s", suggestion)
                return "SKIP"

            return suggestion

        except Exception as exc:
            logger.warning("LLM install fix failed: %s", exc)
            return None

    def _run_install(self, cmd: list[str]) -> tuple[str, str]:
        timeout_seconds = get_story0_timeout()
        logger.info("Running install command: %s", " ".join(cmd))
        try:
            result = subprocess.run(
                cmd,
                cwd=self._working_dir,
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
                check=False,
            )
        except FileNotFoundError:
            detail = f"Executable not found: {cmd[0]!r}"
            logger.warning("Install failed — %s (full command: %s)", detail, cmd)
            return (PrerequisiteStatus.FAILED.value, detail)
        except OSError as exc:
            detail = f"OS error running {cmd[0]!r}: {exc}"
            logger.warning("Install failed — %s", detail)
            return (PrerequisiteStatus.FAILED.value, detail)
        output = result.stdout.strip() or result.stderr.strip()
        if result.returncode == 0:
            return (PrerequisiteStatus.INSTALLED.value, output)
        return (PrerequisiteStatus.FAILED.value, output)
