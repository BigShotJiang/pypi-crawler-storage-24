"""Manifest-generation flow extracted from Story0Handler."""

from __future__ import annotations

import json
import logging
import os
import tomllib
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING, Any

from obra.config.loaders import get_story0_llm_schema_timeout

if TYPE_CHECKING:
    from obra.hybrid.handlers.story0 import Story0Handler

logger = logging.getLogger(__name__)


def handle_inbox_project(
    handler: "Story0Handler",
    objective: str,
    *,
    template_edit_pipeline_cls: type[Any],
    minimal_manifest_templates: dict[str, str],
) -> Path | None:
    """Create inbox scaffolding and manifests using the existing handler helpers."""
    emitter = handler._event_emitter
    prompt_for_env_setup = handler._story0_config.get("prompt_for_env_setup", False)
    if prompt_for_env_setup and not handler._is_tty:
        emitter.progress("Inbox project requires interactive confirmation. Run in TTY mode.")
        return None

    prompt = (
        "Analyze this objective and determine the most appropriate project type. "
        "What type of project best fits this objective? Explain your reasoning.\n\n"
        f"Objective: {objective}\n\n"
        'Return JSON: {"project_type": "<freeform - your determination>", '
        '"reasoning": "...", "suggested_structure": {...}, '
        '"manifest_type": "<appropriate manifest for this project type>"}'
    )
    pipeline = template_edit_pipeline_cls(
        working_dir=handler._working_dir,
        action_name="story0_inbox",
    )
    template_schema = {
        "project_type": "",
        "reasoning": "",
        "suggested_structure": {},
        "manifest_type": "",
        "_instructions": "Fill project_type, reasoning, suggested_structure, manifest_type.",
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        if not isinstance(data, dict):
            return False, "Response must be a JSON object"
        required = [
            "project_type",
            "reasoning",
            "suggested_structure",
            "manifest_type",
        ]
        for key in required:
            if key not in data:
                return False, f"Missing {key}"
        if not isinstance(data.get("suggested_structure"), (dict, list)):
            return False, "suggested_structure must be dict or list"
        return True, None

    def fallback() -> dict[str, Any]:
        return {}

    if not handler._llm_config:
        emitter.progress("LLM config missing; cannot set up inbox project.")
        return None

    result, _meta = pipeline.execute(
        base_prompt=prompt,
        template_content=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config=handler._llm_config,
    )

    if not result:
        emitter.progress("Inbox project analysis failed.")
        return None

    project_type = result.get("project_type", "unknown")
    reasoning = result.get("reasoning", "")
    structure = result.get("suggested_structure", {})

    if prompt_for_env_setup and handler._is_tty:
        response = handler._prompt_text(
            "Based on objective analysis:\n"
            f"  Project type: {project_type}\n"
            f"  Reasoning: {reasoning}\n"
            f"  Structure: {structure}\n\n"
            "Create this project? [Y/n/customize] ",
            default="y",
        )
        if response is None:
            return None
        response = response.strip().lower() or "y"
        if response.startswith("n"):
            return None
        if response.startswith("c"):
            project_type = handler._prompt_text("Project type: ", default=project_type) or project_type
            structure_text = handler._prompt_text(
                "Structure JSON (blank to keep suggested): ",
                default="",
            )
            if structure_text:
                try:
                    structure = json.loads(structure_text)
                except json.JSONDecodeError:
                    emitter.progress("Invalid structure JSON; using suggested structure.")

    handler._working_dir.mkdir(parents=True, exist_ok=True)
    handler._create_structure(structure)

    manifests, _manifest_meta = handler._generate_manifests_llm(objective)
    manifest_source = "LLM-generated"
    if not manifests:
        emitter.progress("[Preflight] LLM manifest generation failed, using fallback")
        manifests = handler._generate_fallback_manifests()
        manifest_source = "fallback"

    validated: list[dict[str, Any]] = []
    for manifest in manifests:
        if not isinstance(manifest, dict):
            continue
        manifest_type = str(manifest.get("type") or "").strip()
        manifest_path = str(manifest.get("path") or ".").strip() or "."
        contents = manifest.get("contents")
        if not manifest_type or contents is None:
            emitter.progress("[Preflight] Skipped: manifest missing required fields")
            continue

        contents_text = str(contents)
        is_valid, reason = handler._validate_manifest_contents(manifest_type, contents_text)
        if not is_valid:
            emitter.progress(f"[Preflight] Manifest invalid ({manifest_type}): {reason}")
            repaired = handler._repair_manifest_llm(manifest_type, contents_text, reason)
            if repaired is not None:
                repaired_valid, repaired_reason = handler._validate_manifest_contents(
                    manifest_type, repaired
                )
                if repaired_valid:
                    contents_text = repaired
                else:
                    emitter.progress(
                        f"[Preflight] Manifest repair failed ({manifest_type}): {repaired_reason}"
                    )
                    contents_text = minimal_manifest_templates.get(manifest_type, contents_text)
            else:
                contents_text = minimal_manifest_templates.get(manifest_type, contents_text)

        validated.append(
            {
                "type": manifest_type,
                "path": manifest_path,
                "contents": contents_text,
                "rationale": manifest.get("rationale", ""),
            }
        )

    created_manifests: list[str] = []
    for manifest in validated:
        current_manifest_type = manifest["type"]
        manifest_path = str(manifest.get("path") or ".").strip() or "."
        path_obj = Path(manifest_path)
        if path_obj.is_absolute() or ".." in path_obj.parts:
            emitter.progress(f"[Preflight] Skipped: invalid manifest path {manifest_path}")
            continue

        target_dir = (
            handler._working_dir if manifest_path in (".", "./") else handler._working_dir / path_obj
        )
        target_dir.mkdir(parents=True, exist_ok=True)

        ecosystem = handler._manifest_ecosystem(current_manifest_type)
        if ecosystem and handler._has_conflict_markers(target_dir, ecosystem):
            rel_dir = (
                target_dir.relative_to(handler._working_dir)
                if target_dir != handler._working_dir
                else Path()
            )
            emitter.progress(
                f"[Preflight] Skipped: {rel_dir} contains existing ecosystem config"
            )
            continue

        target_path = target_dir / current_manifest_type
        if target_path.exists() and handler._story0_config.get("never_overwrite_manifest", True):
            rel_path = (
                target_path.relative_to(handler._working_dir)
                if target_path.exists()
                else target_path
            )
            emitter.progress(
                f"[Preflight] Skipped: {rel_path} exists; never_overwrite_manifest=true"
            )
            continue

        target_path.write_text(manifest["contents"], encoding="utf-8")
        rel_path = (
            target_path.relative_to(handler._working_dir) if target_path.exists() else target_path
        )
        emitter.progress(f"[Preflight] Manifest created: {rel_path} ({manifest_source})")
        created_manifests.append(str(rel_path))

    if created_manifests:
        handler._env_setup_performed = True
        handler._generated_manifest_paths = created_manifests
        handler._generated_manifest_type = validated[0]["type"] if len(validated) == 1 else None
        emitter.decision_event(
            "manifest_generated",
            {
                "packages": created_manifests,
                "target": str(handler._working_dir),
            },
        )

    return handler._working_dir


def generate_manifests_llm(
    handler: "Story0Handler",
    objective: str,
    *,
    template_edit_pipeline_cls: type[Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Generate manifests via TemplateEditPipeline using handler state."""
    if not handler._llm_config:
        return [], {"status": "missing_llm"}

    tooling_info: dict[str, Any] = {}
    try:
        tooling_info = handler._tooling_discovery.discover()
    except Exception as exc:
        logger.debug("Tooling discovery failed for manifests: %s", exc)

    repo_structure = handler._describe_repo_structure()
    from obra.prompts.story0.prerequisites import build_story0_manifest_prompt

    prompt = build_story0_manifest_prompt(objective, tooling_info, repo_structure)

    pipeline = template_edit_pipeline_cls(
        working_dir=handler._working_dir,
        action_name="story0_manifest",
        max_retries=2,
    )
    template_schema = {
        "manifests": [],
        "_instructions": (
            "Populate manifests array with entries containing type, path, contents, rationale."
        ),
    }

    def validator(data: dict) -> tuple[bool, str | None]:
        if not isinstance(data, dict):
            return False, "Response must be a JSON object"
        if "manifests" in data and isinstance(data.get("manifests"), list):
            return True, None
        if "manifest_type" in data or "manifest_contents" in data:
            return True, None
        return False, "Missing manifests array"

    def fallback() -> dict[str, Any]:
        return {}

    result, meta = pipeline.execute(
        base_prompt=prompt,
        template_content=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config=handler._llm_config,
    )

    manifests = handler._normalize_manifest_response(result)
    return manifests, meta


def normalize_manifest_response(result: Any) -> list[dict[str, Any]]:
    """Normalize TemplateEditPipeline manifest responses."""
    if isinstance(result, dict):
        if isinstance(result.get("manifests"), list):
            return [entry for entry in result.get("manifests", []) if isinstance(entry, dict)]
        legacy_type = result.get("manifest_type")
        legacy_contents = result.get("manifest_contents") or result.get("contents")
        if legacy_type and legacy_contents:
            return [
                {
                    "type": legacy_type,
                    "path": ".",
                    "contents": legacy_contents,
                    "rationale": "legacy response",
                }
            ]
    return []


def describe_repo_structure(handler: "Story0Handler") -> list[str]:
    """Return a bounded repo snapshot for manifest prompting."""
    ignore = {
        ".git",
        ".obra",
        ".venv",
        "venv",
        ".conda",
        "__pycache__",
        "node_modules",
    }
    entries: list[str] = []
    for root, dirs, files in os.walk(handler._working_dir):
        dirs[:] = [d for d in dirs if d not in ignore]
        rel_root = Path(root).relative_to(handler._working_dir)
        if rel_root != Path():
            entries.append(f"{rel_root}/")
        for filename in files:
            rel_path = (rel_root / filename) if rel_root != Path() else Path(filename)
            entries.append(str(rel_path))
        if len(entries) >= 200:
            break
    return entries[:200]


def generate_fallback_manifests(
    handler: "Story0Handler",
    *,
    manifest_type_map: dict[str, str],
    minimal_manifest_templates: dict[str, str],
) -> list[dict[str, Any]]:
    """Generate fallback manifests based on detected file extensions."""
    counts: defaultdict[str, int] = defaultdict(int)
    ext_map = {
        "python": {".py"},
        "node": {".js", ".ts", ".jsx", ".tsx"},
        "rust": {".rs"},
        "go": {".go"},
        "ruby": {".rb"},
    }
    for path in handler._working_dir.rglob("*"):
        if not path.is_file():
            continue
        if any(
            part in {".git", ".obra", ".venv", "venv", ".conda", "node_modules"}
            for part in path.parts
        ):
            continue
        ext = path.suffix.lower()
        for ecosystem, extensions in ext_map.items():
            if ext in extensions:
                counts[ecosystem] += 1
                break

    selected = None
    if counts:
        selected = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[0][0]

    manifest_type = manifest_type_map.get(
        selected or "",
        handler._story0_config.get("default_manifest_type", "pyproject.toml"),
    )
    if manifest_type is None:
        manifest_type = "pyproject.toml"
    contents = minimal_manifest_templates.get(
        manifest_type,
        minimal_manifest_templates["pyproject.toml"],
    )
    return [
        {
            "type": manifest_type,
            "path": ".",
            "contents": contents,
            "rationale": "fallback",
        }
    ]


def validate_manifest_contents(manifest_type: str, contents: str) -> tuple[bool, str]:
    """Validate generated manifest contents for the supported ecosystems."""
    if manifest_type == "pyproject.toml":
        try:
            data = tomllib.loads(contents)
        except Exception as exc:
            return False, f"Invalid TOML: {exc}"
        project = data.get("project")
        if not isinstance(project, dict) or not project.get("name"):
            return False, "Missing [project].name"
        return True, ""
    if manifest_type == "package.json":
        try:
            data = json.loads(contents)
        except json.JSONDecodeError as exc:
            return False, f"Invalid JSON: {exc}"
        if not isinstance(data, dict) or not data.get("name") or not data.get("version"):
            return False, "Missing name/version"
        return True, ""
    if manifest_type == "Cargo.toml":
        try:
            data = tomllib.loads(contents)
        except Exception as exc:
            return False, f"Invalid TOML: {exc}"
        package = data.get("package")
        if not isinstance(package, dict) or not package.get("name"):
            return False, "Missing [package].name"
        return True, ""
    if manifest_type == "go.mod":
        if "module " not in contents:
            return False, "Missing module declaration"
        return True, ""
    if manifest_type == "Gemfile":
        if "source" not in contents:
            return False, "Missing source declaration"
        return True, ""
    return True, ""


def manifest_ecosystem(
    manifest_type: str,
    *,
    manifest_type_map: dict[str, str],
) -> str | None:
    """Map a manifest filename back to its ecosystem key."""
    for ecosystem, manifest in manifest_type_map.items():
        if manifest == manifest_type:
            return ecosystem
    return None


def repair_manifest_llm(
    handler: "Story0Handler",
    manifest_type: str,
    contents: str,
    reason: str,
) -> str | None:
    """Repair invalid manifest content via run_llm_subprocess."""
    if not handler._llm_config:
        return None
    prompt = (
        "Fix the manifest to satisfy validation requirements.\n"
        f"Manifest type: {manifest_type}\n"
        f"Validation error: {reason}\n\n"
        "Return ONLY the corrected manifest contents, no JSON, no markdown.\n\n"
        f"Current contents:\n{contents}\n"
    )
    try:
        from obra.config.llm import DEFAULT_REASONING_LEVEL
        from obra.llm import LLMSubprocessConfig, run_llm_subprocess

        provider = handler._llm_config.get("provider", "anthropic")
        model = handler._llm_config.get("model", "default")
        reasoning_level = handler._llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
        auth_method = handler._llm_config.get("auth_method", "oauth")

        config = LLMSubprocessConfig(
            prompt=prompt,
            cwd=handler._working_dir,
            provider=provider,
            model=model,
            reasoning_level=reasoning_level,
            mode="text",
            auth_method=auth_method,
            timeout_s=get_story0_llm_schema_timeout(),
            skip_git_check=True,
            streaming=False,
            call_site="story0_manifest_repair",
            run_id=handler._session_id,
        )
        result = run_llm_subprocess(config)
        if not result.success:
            logger.warning("Manifest repair failed: %s", result.error)
            return None
        return result.output.strip()
    except Exception as exc:
        logger.warning("Manifest repair error: %s", exc)
        return None
