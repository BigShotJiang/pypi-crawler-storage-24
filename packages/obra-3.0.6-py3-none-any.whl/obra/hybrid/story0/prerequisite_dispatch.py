"""Prerequisite dispatch helpers extracted from Story0Handler."""

from __future__ import annotations

import contextlib
import json
import os
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from getpass import getpass
from pathlib import Path
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from obra.models.story0_state import PrerequisiteCategory, PrerequisiteStatus

if TYPE_CHECKING:
    from obra.hybrid.handlers.story0 import Story0Handler
    from obra.hybrid.install_target import InstallTargetManager
    from obra.hybrid.story0.install_subsystem import DependencyInstaller
    from obra.hybrid.story0.service_manager import ServiceManager


class PrerequisiteDispatcher:
    """Owns prerequisite routing and handler execution."""

    def __init__(
        self,
        owner: "Story0Handler",
        installer: "DependencyInstaller",
        service_manager: "ServiceManager",
        install_target: "InstallTargetManager",
        working_dir: Path,
        story0_config: dict[str, Any],
        is_tty: bool,
        get_automation_mode: Callable[[], str | None],
        mocked_credentials: list[str],
        coerce_prereq: Callable[[dict[str, Any]], Any],
        prompt_text: Callable[[str, str | None], str | None],
        emit_progress: Callable[[str], None],
        emit_prereq_progress: Callable[[dict[str, Any], str], None],
        emit_prereq_status: Callable[[Any, str, str | None], None],
        get_capability_checks: Callable[[], dict[str, Any]],
    ) -> None:
        self._owner = owner
        self._installer = installer
        self._service_manager = service_manager
        self._install_target = install_target
        self._working_dir = working_dir
        self._story0_config = story0_config
        self._is_tty = is_tty
        self._get_automation_mode = get_automation_mode
        self._mocked_credentials = mocked_credentials
        self._coerce_prereq = coerce_prereq
        self._prompt_text = prompt_text
        self._emit_progress = emit_progress
        self._emit_prereq_progress = emit_prereq_progress
        self._emit_prereq_status = emit_prereq_status
        self._get_capability_checks = get_capability_checks
        self._active_overrides: set[str] = set()

    def _legacy_override(self, attr_name: str, method_name: str) -> Callable[..., Any] | None:
        if attr_name in self._active_overrides:
            return None
        candidate = getattr(self._owner, attr_name, None)
        if not callable(candidate):
            return None
        if (
            getattr(candidate, "__self__", None) is self
            and getattr(candidate, "__func__", None) is getattr(type(self), method_name)
        ):
            return None
        return candidate

    def resolve_handler(self, category: PrerequisiteCategory):
        override = self._legacy_override("_resolve_handler", "resolve_handler")
        if override is not None:
            self._active_overrides.add("_resolve_handler")
            try:
                return override(category)
            finally:
                self._active_overrides.discard("_resolve_handler")
        if category == PrerequisiteCategory.AUTO:
            return self._owner._handle_auto
        if category == PrerequisiteCategory.AUTO_CONFIRM:
            return self._owner._handle_auto_confirm
        if category == PrerequisiteCategory.CREDENTIAL:
            return self._owner._handle_credential
        if category == PrerequisiteCategory.SERVICE:
            return self._service_manager.handle_service
        if category == PrerequisiteCategory.USER_ACTION:
            return self._owner._handle_user_action
        if category == PrerequisiteCategory.ACCOUNT:
            return self._owner._handle_account
        if category == PrerequisiteCategory.LOCAL_CAPABILITY:
            return self._owner._handle_local_capability
        return self._owner._handle_auto

    def resolve_ecosystem(self, prereq: dict[str, Any]) -> str | None:
        llm_ecosystem = prereq.get("ecosystem")
        if llm_ecosystem:
            return llm_ecosystem

        toolchains = self._install_target.detect_toolchain(self._working_dir)
        if toolchains:
            return next(iter(toolchains))
        return None

    def handle_auto(self, prereq: dict[str, Any]) -> tuple[str, str]:
        override = self._legacy_override("_handle_auto", "handle_auto")
        if override is not None:
            self._active_overrides.add("_handle_auto")
            try:
                return override(prereq)
            finally:
                self._active_overrides.discard("_handle_auto")
        manifest = self._installer._detect_manifest(self._installer._installer_registry())
        if not manifest:
            ecosystem = self.resolve_ecosystem(prereq)
            if ecosystem is None:
                return (
                    PrerequisiteStatus.FAILED.value,
                    f"Cannot determine ecosystem for '{prereq.get('name', '?')}'. "
                    "No manifest found, toolchain detection found nothing, and "
                    "the LLM did not specify an ecosystem. Add a manifest file "
                    "to the project or re-run so the LLM can re-derive.",
                )
            self._emit_progress(f"[Preflight] No manifest found, using {ecosystem} toolchain")

            env_creation_policy = self._story0_config.get("env_creation", "when_missing")
            manager_preference = (
                self._story0_config.get("package_manager_preference", {}).get(ecosystem, "auto")
            )
            try:
                self._install_target.create_environment(
                    ecosystem,
                    self._working_dir,
                    env_creation_policy,
                    manager_preference,
                )
            except Exception as exc:
                return (
                    PrerequisiteStatus.FAILED.value,
                    f"Environment creation failed: {exc}",
                )

            package_name = prereq.get("name", prereq.get("id", ""))
            return self._installer.install_with_llm_retry(package_name, ecosystem)

        reason = prereq.get("reason", "")
        self._emit_prereq_progress(prereq, "Installing")
        self._emit_progress(f"Installing {prereq.get('name')}: {reason}")
        try:
            return self._installer.install_dependency(prereq)
        except subprocess.TimeoutExpired:
            return (PrerequisiteStatus.FAILED.value, "Install timed out")
        except Exception as exc:
            return (PrerequisiteStatus.FAILED.value, str(exc))

    def handle_auto_confirm(self, prereq: dict[str, Any]) -> tuple[str, str]:
        override = self._legacy_override("_handle_auto_confirm", "handle_auto_confirm")
        if override is not None:
            self._active_overrides.add("_handle_auto_confirm")
            try:
                return override(prereq)
            finally:
                self._active_overrides.discard("_handle_auto_confirm")
        reason = prereq.get("reason", "")
        name = prereq.get("name", "unknown")
        source = prereq.get("source", "UNKNOWN")

        if not self._is_tty:
            self._emit_progress(f"Auto-approved (non-interactive mode): {name} - {reason}")
            return self._owner._handle_auto(prereq)
        if self._story0_config.get("auto_approve"):
            self._emit_progress(f"Auto-approved (auto-approve enabled): {name} - {reason}")
            return self._owner._handle_auto(prereq)

        self._emit_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Awaiting user confirmation",
        )

        if not self._owner._genie_hint_shown:
            self._owner._genie_hint_shown = True
            self._emit_progress(
                "[dim]Tip: For fewer prompts, try 'Genie Mode' via `obra config` -> Personas. "
                "It auto-approves these decisions (best for sandboxed environments).[/dim]"
            )

        prompt = f"{name}\nSource: {source}\nReason: {reason}\nProceed with {name}? [Y/n] "
        response = self._prompt_text(prompt, "y")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        if response.lower().startswith("n"):
            return (PrerequisiteStatus.SKIPPED.value, "User declined")
        return self._owner._handle_auto(prereq)

    def handle_local_capability(self, prereq: dict[str, Any]) -> tuple[str, str]:
        override = self._legacy_override("_handle_local_capability", "handle_local_capability")
        if override is not None:
            self._active_overrides.add("_handle_local_capability")
            try:
                return override(prereq)
            finally:
                self._active_overrides.discard("_handle_local_capability")
        capability_checks = self._get_capability_checks()
        prereq_name = prereq.get("name", "")
        name_lower = prereq_name.lower()

        matched_cap: str | None = None
        matched_config: dict[str, Any] | None = None
        for cap_name, cap_config in capability_checks.items():
            indicators = cap_config.get("indicators", [])
            if any(indicator.lower() in name_lower for indicator in indicators):
                matched_cap = cap_name
                matched_config = cap_config
                break

        if matched_cap is None or matched_config is None:
            from obra.hybrid.capability_probes import probe_prerequisite

            probe_result = probe_prerequisite(prereq_name)
            if probe_result is not None:
                return (
                    PrerequisiteStatus(probe_result.status).value
                    if probe_result.status in ("installed", "missing")
                    else PrerequisiteStatus.FAILED.value,
                    probe_result.detail,
                )

            depres_config = self._story0_config.get("dependency_resolution", {})
            unknown_behavior = depres_config.get("unknown_behavior", "unverified_non_blocking")
            if unknown_behavior == "fail":
                return (
                    PrerequisiteStatus.FAILED.value,
                    f"No capability check configured for '{prereq_name}' "
                    f"(policy: unknown_behavior=fail)",
                )
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"No capability check configured for '{prereq_name}'; "
                f"treated as unverified (policy: unknown_behavior={unknown_behavior})",
            )

        if matched_config.get("always_available", False):
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"{matched_cap} is always available on local machines",
            )

        platform_checks = self.resolve_platform_check(matched_config)
        command_checks = platform_checks.get("commands", matched_config.get("commands", []))
        normalized_commands: list[list[str]] = []
        if isinstance(command_checks, list):
            for command in command_checks:
                if isinstance(command, str) and command.strip():
                    normalized_commands.append([command.strip()])
                elif isinstance(command, list):
                    parts = [str(part).strip() for part in command if str(part).strip()]
                    if parts:
                        normalized_commands.append(parts)

        command_failures: list[str] = []
        for command_parts in normalized_commands:
            executable = command_parts[0]
            if not shutil.which(executable):
                command_failures.append(f"{executable}: not found")
                continue
            try:
                result = subprocess.run(
                    command_parts,
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
                if result.returncode == 0:
                    return (
                        PrerequisiteStatus.INSTALLED.value,
                        f"{matched_cap} detected via command: {' '.join(command_parts)}",
                    )
                command_failures.append(f"{' '.join(command_parts)}: exit {result.returncode}")
            except (OSError, subprocess.SubprocessError) as exc:
                command_failures.append(f"{' '.join(command_parts)}: {exc}")

        if platform_checks.get("always_available", False):
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"{matched_cap} is always available on {sys.platform}",
            )

        env_vars = platform_checks.get("env_vars", [])
        for env_var in env_vars:
            value = os.environ.get(env_var)
            if value:
                return (
                    PrerequisiteStatus.INSTALLED.value,
                    f"{matched_cap} detected via {env_var}={value}",
                )

        if command_failures:
            return (
                PrerequisiteStatus.FAILED.value,
                f"{matched_cap} not detected. Checked commands: {command_failures}.",
            )

        return (
            PrerequisiteStatus.FAILED.value,
            f"{matched_cap} not detected. Checked env vars: {env_vars}. Platform: {sys.platform}.",
        )

    @staticmethod
    def resolve_platform_check(cap_config: dict[str, Any]) -> dict[str, Any]:
        platforms = cap_config.get("platforms", {})
        if platforms and sys.platform in platforms:
            return platforms[sys.platform]
        fallback = cap_config.get("fallback")
        if fallback:
            return fallback
        if "env_vars" in cap_config:
            return {"env_vars": cap_config["env_vars"]}
        return {}

    def handle_credential(self, prereq: dict[str, Any]) -> tuple[str, str]:
        override = self._legacy_override("_handle_credential", "handle_credential")
        if override is not None:
            self._active_overrides.add("_handle_credential")
            try:
                return override(prereq)
            finally:
                self._active_overrides.discard("_handle_credential")
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")

        if self._story0_config.get("mock_credentials"):
            mock_value = self._owner._create_mock_credential(name)
            os.environ[name] = mock_value
            self._mocked_credentials.append(name)
            return (
                PrerequisiteStatus.MOCKED.value,
                self._story0_config.get("default_mock_level", "fixture"),
            )

        if not self._is_tty:
            return (
                PrerequisiteStatus.FAILED.value,
                "Credential required: "
                f"{name}\nNeeded for: {reason}\n\n"
                "Running in non-interactive mode. Either:\n"
                f"  1. Set {name} environment variable before running\n"
                "  2. Run with --mock-credentials flag\n"
                "  3. Run interactively (TTY required)",
            )

        self._emit_progress(f"{name} not found in environment.\nNeeded for: {reason}")
        self._emit_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Credential input required",
        )
        choice = self._prompt_text(
            "[1] Enter value [2] Mock for testing [3] Skip: ",
            "3",
        )
        if choice is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        choice = choice.strip() or "3"
        if choice == "1":
            value = getpass(f"Enter value for {name}: ")
            if value:
                os.environ[name] = value
                return (PrerequisiteStatus.INSTALLED.value, "Set from user input")
            return (PrerequisiteStatus.SKIPPED.value, "No value provided")
        if choice == "2":
            mock_value = self._owner._create_mock_credential(name)
            os.environ[name] = mock_value
            self._mocked_credentials.append(name)
            return (
                PrerequisiteStatus.MOCKED.value,
                self._story0_config.get("default_mock_level", "fixture"),
            )
        return (PrerequisiteStatus.SKIPPED.value, "User skipped")

    def handle_user_action(self, prereq: dict[str, Any]) -> tuple[str, str]:
        override = self._legacy_override("_handle_user_action", "handle_user_action")
        if override is not None:
            self._active_overrides.add("_handle_user_action")
            try:
                return override(prereq)
            finally:
                self._active_overrides.discard("_handle_user_action")
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")

        if self._story0_config.get("mock_credentials"):
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"User action mocked (simulation mode): {name}",
            )

        if self._get_automation_mode() == "auto_full":
            self._emit_progress(
                f"[Preflight] Auto-skipped manual action (auto_full mode): {name}"
            )
            return (
                PrerequisiteStatus.SKIPPED.value,
                f"Skipped manual action in auto_full mode: {name}",
            )

        if not self._is_tty:
            return (
                PrerequisiteStatus.FAILED.value,
                f"Manual action required: {reason}. Cannot proceed in non-interactive mode.",
            )

        self._emit_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Waiting for manual action",
        )
        prompt = (
            f"{name}\n\nRequired action: {reason}\n\n"
            "Please complete this action manually, then press Enter to continue..."
        )
        response = self._prompt_text(prompt, "")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        return (PrerequisiteStatus.INSTALLED.value, "User confirmed completion")

    def handle_account(self, prereq: dict[str, Any]) -> tuple[str, str]:
        override = self._legacy_override("_handle_account", "handle_account")
        if override is not None:
            self._active_overrides.add("_handle_account")
            try:
                return override(prereq)
            finally:
                self._active_overrides.discard("_handle_account")
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")
        url = prereq.get("url")

        if self._story0_config.get("mock_credentials"):
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"Account mocked (simulation mode): {name}",
            )

        if self._get_automation_mode() == "auto_full":
            self._emit_progress(
                f"[Preflight] Auto-skipped account setup (auto_full mode): {name}"
            )
            return (
                PrerequisiteStatus.SKIPPED.value,
                f"Skipped account setup in auto_full mode: {name}",
            )

        if not self._is_tty:
            url_hint = (
                f" Create account at {url} before running in non-interactive mode."
                if url
                else " Create account before running in non-interactive mode."
            )
            return (
                PrerequisiteStatus.FAILED.value,
                f"External account required: {name}.{url_hint}",
            )

        self._emit_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Waiting for account setup",
        )
        message = f"{name} account required\n\nReason: {reason}"
        if url:
            message += f"\nSign up at: {url}"
        message += "\nPress Enter when account is created..."
        response = self._prompt_text(message, "")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        return (PrerequisiteStatus.INSTALLED.value, "Account created")

    def create_mock_credential(self, name: str) -> str:
        override = self._legacy_override("_create_mock_credential", "create_mock_credential")
        if override is not None:
            self._active_overrides.add("_create_mock_credential")
            try:
                return override(name)
            finally:
                self._active_overrides.discard("_create_mock_credential")
        mock_value = f"mock-{name.lower()}-value"
        source_path = Path("obra") / "mocks" / f"{name.lower()}.json"
        fixture_dir = self._working_dir / ".obra" / "mocks"
        fixture_dir.mkdir(parents=True, exist_ok=True)
        fixture_path = fixture_dir / f"{name}.json"
        payload = {
            "name": name,
            "mock_type": self._story0_config.get("default_mock_level", "fixture"),
            "created_at": datetime.now(UTC).isoformat(),
            "mock_value": mock_value,
        }
        if source_path.exists():
            with contextlib.suppress(json.JSONDecodeError):
                payload.update(json.loads(source_path.read_text(encoding="utf-8")))
        fixture_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return mock_value
