"""Manual-action batching extracted from Story0Handler."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from obra.models.story0_state import Prerequisite, PrerequisiteCategory, PrerequisiteStatus

if TYPE_CHECKING:
    from obra.hybrid.handlers.story0 import Story0Handler


def handle_manual_items_batched(
    handler: "Story0Handler",
    manual_items: list[tuple[Prerequisite, dict[str, Any]]],
    manual_behavior: str,
    completed: list[str],
    failed: list[str],
    skipped: list[str],
    blocking_failures: list[str],
    non_blocking_failures: list[str],
    failures: list[tuple[dict[str, Any], str]],
) -> None:
    """Process manual prerequisites with the existing batched policies."""
    emitter = handler._event_emitter
    dispatcher = handler._prereq_dispatcher
    has_blocking = any(
        handler._is_blocking(entry.category)
        for entry, _ in manual_items
    )

    if manual_behavior == "abort_if_blocking" and has_blocking:
        for prereq_entry, prereq in manual_items:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            category = prereq_entry.category
            status = PrerequisiteStatus.FAILED.value
            detail = (
                f"Blocking manual action required (policy: abort_if_blocking): "
                f"{prereq_entry.name}"
            )
            handler._record_prereq_outcome(
                prereq_entry, prereq, prereq_id, category,
                status, detail,
                completed, failed, skipped,
                blocking_failures, non_blocking_failures, failures,
            )
        return

    if manual_behavior == "continue_with_warnings":
        for prereq_entry, prereq in manual_items:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            category = prereq_entry.category
            emitter.progress(
                f"[Preflight] Skipping manual item (policy: continue_with_warnings): "
                f"{prereq_entry.name}"
            )
            status = PrerequisiteStatus.SKIPPED.value
            detail = (
                f"Skipped manual action (policy: continue_with_warnings): "
                f"{prereq_entry.name}"
            )
            handler._record_prereq_outcome(
                prereq_entry, prereq, prereq_id, category,
                status, detail,
                completed, failed, skipped,
                blocking_failures, non_blocking_failures, failures,
            )
        return

    credential_items: list[tuple[Prerequisite, dict[str, Any]]] = []
    batch_items: list[tuple[Prerequisite, dict[str, Any]]] = []

    for prereq_entry, prereq in manual_items:
        if prereq_entry.category == PrerequisiteCategory.CREDENTIAL:
            credential_items.append((prereq_entry, prereq))
        else:
            batch_items.append((prereq_entry, prereq))

    for prereq_entry, prereq in credential_items:
        prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
        category = prereq_entry.category
        resolved_handler = dispatcher.resolve_handler(category)
        emitter.prereq_progress(prereq, "Processing")
        status, detail = resolved_handler(prereq)
        handler._record_prereq_outcome(
            prereq_entry, prereq, prereq_id, category,
            status, detail,
            completed, failed, skipped,
            blocking_failures, non_blocking_failures, failures,
        )

    if not batch_items:
        return

    emitter.progress(
        f"[Preflight] {len(batch_items)} manual action(s) remaining:"
    )
    for prereq_entry, prereq in batch_items:
        reason = prereq.get("reason", "")
        emitter.progress(f"  - {prereq_entry.name}: {reason}")

    if handler._automation_mode_effective == "auto_full":
        for prereq_entry, prereq in batch_items:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            category = prereq_entry.category
            emitter.progress(
                f"[Preflight] Auto-skipped manual action (auto_full mode): "
                f"{prereq_entry.name}"
            )
            status = PrerequisiteStatus.SKIPPED.value
            detail = f"Skipped manual action in auto_full mode: {prereq_entry.name}"
            handler._record_prereq_outcome(
                prereq_entry, prereq, prereq_id, category,
                status, detail,
                completed, failed, skipped,
                blocking_failures, non_blocking_failures, failures,
            )
        return

    if handler._story0_config.get("mock_credentials"):
        for prereq_entry, prereq in batch_items:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            category = prereq_entry.category
            status = PrerequisiteStatus.INSTALLED.value
            detail = f"Manual action mocked (simulation mode): {prereq_entry.name}"
            handler._record_prereq_outcome(
                prereq_entry, prereq, prereq_id, category,
                status, detail,
                completed, failed, skipped,
                blocking_failures, non_blocking_failures, failures,
            )
        return

    if not handler._is_tty:
        for prereq_entry, prereq in batch_items:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            category = prereq_entry.category
            status = PrerequisiteStatus.FAILED.value
            detail = (
                f"Manual action required: {prereq.get('reason', '')}. "
                "Cannot proceed in non-interactive mode."
            )
            handler._record_prereq_outcome(
                prereq_entry, prereq, prereq_id, category,
                status, detail,
                completed, failed, skipped,
                blocking_failures, non_blocking_failures, failures,
            )
        return

    response = handler._prompt_text(
        "Complete these actions, then press Enter to continue "
        "(or X to abort): ",
        default="",
    )
    if response is not None and response.strip().upper() == "X":
        for prereq_entry, prereq in batch_items:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            category = prereq_entry.category
            status = PrerequisiteStatus.FAILED.value
            detail = "User aborted manual actions"
            handler._record_prereq_outcome(
                prereq_entry, prereq, prereq_id, category,
                status, detail,
                completed, failed, skipped,
                blocking_failures, non_blocking_failures, failures,
            )
        return

    for prereq_entry, prereq in batch_items:
        prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
        category = prereq_entry.category
        status = PrerequisiteStatus.INSTALLED.value
        detail = "User confirmed completion (batched prompt)"
        handler._record_prereq_outcome(
            prereq_entry, prereq, prereq_id, category,
            status, detail,
            completed, failed, skipped,
            blocking_failures, non_blocking_failures, failures,
        )
