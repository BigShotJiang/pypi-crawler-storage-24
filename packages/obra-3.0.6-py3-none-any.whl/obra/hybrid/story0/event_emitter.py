"""Event emission helpers extracted from Story0Handler."""

from __future__ import annotations

import contextlib
from collections.abc import Callable
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from obra.models.story0_state import Prerequisite, PrerequisiteCategory, PrerequisiteSource

if TYPE_CHECKING:
    from obra.hybrid.handlers.story0 import Story0Handler


class Story0EventEmitter:
    """Owns Story 0 progress and event emission."""

    def __init__(
        self,
        owner: "Story0Handler",
        get_on_progress: Callable[[], Callable[[str, dict[str, Any]], None] | None],
        print_info_fn: Callable[[str], None],
        get_log_decisions: Callable[[], bool],
        get_automation_mode: Callable[[], str | None],
    ) -> None:
        self._owner = owner
        self._get_on_progress = get_on_progress
        self._print_info = print_info_fn
        self._get_log_decisions = get_log_decisions
        self._get_automation_mode = get_automation_mode
        self._registered_aliases: dict[str, Callable[..., Any]] = {}

    def register_alias(self, attr_name: str, callback: Callable[..., Any]) -> None:
        self._registered_aliases[attr_name] = callback

    def _legacy_override(self, attr_name: str, method_name: str) -> Callable[..., Any] | None:
        candidate = getattr(self._owner, attr_name, None)
        if not callable(candidate):
            return None
        if self._registered_aliases.get(attr_name) is candidate:
            return None
        if (
            getattr(candidate, "__self__", None) is self
            and getattr(candidate, "__func__", None) is getattr(type(self), method_name)
        ):
            return None
        return candidate

    def prereq_progress(self, prereq: dict[str, Any], status: str) -> None:
        override = self._legacy_override("_emit_prereq_progress", "prereq_progress")
        if override is not None:
            override(prereq, status)
            return
        name = prereq.get("name", "unknown")
        source = prereq.get("source", "")
        reason = prereq.get("reason", "")
        if source == PrerequisiteSource.INFERRED.value:
            self.progress(f"[INFERRED] {status} {name}: {reason}")
        elif source == PrerequisiteSource.MANIFEST.value:
            self.progress(f"[MANIFEST] {status} {name}")
        else:
            self.progress(f"{status} {name}: {reason}")

    def summary(
        self,
        prereq_state: list[Prerequisite],
        mocked_credentials: list[str],
    ) -> None:
        override = self._legacy_override("_emit_summary", "summary")
        if override is not None:
            override()
            return
        manifest_count = sum(
            1
            for prereq in prereq_state
            if prereq.source == PrerequisiteSource.MANIFEST
            and prereq.status.value == "installed"
        )
        inferred_count = sum(
            1
            for prereq in prereq_state
            if prereq.source == PrerequisiteSource.INFERRED
            and prereq.status.value == "installed"
        )
        services = [
            prereq.name
            for prereq in prereq_state
            if prereq.category == PrerequisiteCategory.SERVICE
            and prereq.status.value == "installed"
        ]
        self.progress(
            "Environment preparation complete:\n"
            f"  Manifest dependencies: {manifest_count} installed\n"
            f"  Inferred dependencies: {inferred_count} installed\n"
            f"  Mocked credentials: {mocked_credentials}\n"
            f"  Services started: {services}"
        )

    def progress(self, message: str) -> None:
        override = self._legacy_override("_emit_progress", "progress")
        if override is not None:
            override(message)
            return
        on_progress = self._get_on_progress()
        if on_progress:
            try:
                on_progress("story0_message", {"message": message})
                return
            except Exception:
                pass
        self._print_info(message)

    def story0_event(self, event_type: str, data: dict[str, Any]) -> None:
        override = self._legacy_override("_emit_story0_event", "story0_event")
        if override is not None:
            override(event_type, data)
            return
        on_progress = self._get_on_progress()
        if on_progress:
            try:
                on_progress(event_type, data)
                return
            except Exception:
                pass

    def story0_started(self) -> None:
        override = self._legacy_override("_emit_story0_started", "story0_started")
        if override is not None:
            override()
            return
        self.story0_event("story0_started", {})

    def story0_completed(
        self,
        blocking_failures: int,
        non_blocking_warnings: int,
    ) -> None:
        override = self._legacy_override("_emit_story0_completed", "story0_completed")
        if override is not None:
            override(blocking_failures, non_blocking_warnings)
            return
        self.story0_event(
            "story0_completed",
            {
                "blocking_failures": blocking_failures,
                "non_blocking_warnings": non_blocking_warnings,
            },
        )

    def story0_blocked(self, failures_summary: str) -> None:
        override = self._legacy_override("_emit_story0_blocked", "story0_blocked")
        if override is not None:
            override(failures_summary)
            return
        self.story0_event("story0_blocked", {"failures_summary": failures_summary})

    def story0_prereq_status(
        self,
        prereq: Prerequisite,
        status: str,
        reason: str | None = None,
    ) -> None:
        override = self._legacy_override("_emit_story0_prereq_status", "story0_prereq_status")
        if override is not None:
            override(prereq, status, reason)
            return
        category_label = {
            PrerequisiteCategory.AUTO: "Dependencies",
            PrerequisiteCategory.AUTO_CONFIRM: "Dependencies",
            PrerequisiteCategory.CREDENTIAL: "Credentials",
            PrerequisiteCategory.SERVICE: "Services",
            PrerequisiteCategory.USER_ACTION: "Manual Actions",
            PrerequisiteCategory.ACCOUNT: "Manual Actions",
        }.get(prereq.category, "Prerequisites")
        self.story0_event(
            "story0_prerequisite_status",
            {
                "category": category_label,
                "name": prereq.name,
                "status": status,
                "reason": reason,
            },
        )

    def decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        override = self._legacy_override("_emit_decision_event", "decision_event")
        if override is not None:
            override(event_type, data)
            return
        on_progress = self._get_on_progress()
        if not on_progress or not self._get_log_decisions():
            return
        payload = {
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
        }
        payload.update(data)
        payload.setdefault("mode", self._get_automation_mode())
        payload.setdefault("ecosystem", data.get("ecosystem"))
        payload.setdefault("packages", data.get("packages"))
        payload.setdefault("target", data.get("target"))
        payload.setdefault("reason", data.get("reason"))
        with contextlib.suppress(Exception):
            on_progress(event_type, payload)
