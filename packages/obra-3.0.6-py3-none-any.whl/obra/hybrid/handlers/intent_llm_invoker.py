"""Intent LLM invocation helpers."""

from __future__ import annotations

import json
import logging
import sys
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config import (
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
    get_llm_api_timeout,
)
from obra.config.loaders import get_intent_bypass_sandbox
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display.observability import VerbosityLevel, get_runtime_verbosity
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.models import EnrichmentLevel
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)


def build_intent_template_schema(objective: str) -> dict[str, Any]:
    """Build the template-edit schema for intent generation."""
    return {
        "problem_statement": objective,
        "assumptions": [],
        "requirements": [],
        "constraints": [],
        "acceptance_criteria": [],
        "non_goals": [],
        "risks": [],
        "_instructions": (
            "Fill in all intent fields. "
            "problem_statement: string describing the problem. "
            "assumptions: array of assumption strings. "
            "requirements: array of requirement strings. "
            "constraints: array of constraint strings. "
            "acceptance_criteria: array of success criteria. "
            "non_goals: array of out-of-scope items. "
            "risks: array of risk descriptions."
        ),
    }


def validate_intent_template(data: dict[str, Any]) -> tuple[bool, str | None]:
    """Validate intent template-edit output."""
    if not isinstance(data, dict):
        return False, "Response must be a JSON object"

    required_fields = {
        "problem_statement",
        "assumptions",
        "requirements",
        "constraints",
        "acceptance_criteria",
        "non_goals",
        "risks",
    }
    if not required_fields.issubset(data.keys()):
        missing = required_fields - data.keys()
        return False, f"Missing fields: {', '.join(missing)}"

    if not isinstance(data["problem_statement"], str) or not data["problem_statement"].strip():
        return False, "problem_statement must be non-empty string"

    for field in [
        "assumptions",
        "requirements",
        "constraints",
        "acceptance_criteria",
        "non_goals",
        "risks",
    ]:
        if not isinstance(data[field], list):
            return False, f"{field} must be a list"

    return True, None


def build_intent_fallback(objective: str) -> dict[str, Any]:
    """Return minimal fallback intent data."""
    return {
        "problem_statement": objective,
        "assumptions": [],
        "requirements": [],
        "constraints": [],
        "acceptance_criteria": ["Implementation complete and verified"],
        "non_goals": [],
        "risks": [],
    }


def classify_cli_error_response(response: str) -> tuple[bool, str | None]:
    """Detect CLI error text returned as a successful stdout payload."""
    if not response:
        return False, None

    lowered = response.lower().strip()
    first_line = lowered.split("\n")[0] if lowered else ""
    cli_error_starts = (
        "error:",
        "error -",
        "failed:",
        "exception:",
        "traceback (most recent call last)",
        "fatal:",
        "panic:",
    )
    for pattern in cli_error_starts:
        if first_line.startswith(pattern) or lowered.startswith(pattern):
            return True, f"cli_error_start:{pattern.rstrip(':')}"

    if len(response) < 500:
        error_patterns = (
            "command not found",
            "no such file or directory",
            "permission denied",
            "connection refused",
            "timeout expired",
            "modulenotfounderror",
            "importerror",
        )
        for pattern in error_patterns:
            if pattern in lowered:
                return True, f"cli_error_pattern:{pattern}"

    return False, None


class StageHeartbeatThread(threading.Thread):
    """Background thread that emits stage heartbeat events."""

    def __init__(
        self,
        stage: str,
        interval: int,
        initial_delay: int,
        emit_progress: Callable[[str, dict[str, Any]], None],
        log_event: Callable[..., None] | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._stage = stage
        self._interval = max(1, int(interval))
        self._initial_delay = max(0, int(initial_delay))
        self._emit_progress = emit_progress
        self._log_event = log_event
        self._stop_event = threading.Event()
        self._start_time = time.time()
        self._alive_count = 0

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        self._stop_event.wait(self._initial_delay)
        last_liveness_check = time.time()

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            self._emit_progress("stage_heartbeat", {"stage": self._stage, "elapsed_s": elapsed})

            current_time = time.time()
            if self._log_event and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S:
                self._alive_count += 1
                self._log_event(
                    "stage_liveness_check",
                    stage=self._stage,
                    status="active",
                    alive_count=self._alive_count,
                    elapsed_seconds=elapsed,
                )
                last_liveness_check = current_time

            self._stop_event.wait(self._interval)


class IntentLLMInvoker:
    """Encapsulate raw and template-edit LLM invocation for intent generation."""

    def __init__(
        self,
        *,
        working_dir: Path,
        llm_config: dict[str, Any],
        emit_progress: Callable[[str, dict[str, Any]], None],
        on_stream: Callable[[str, str], None] | None,
        log_event: Callable[..., None] | None,
        trace_id: str | None,
        parent_span_id: str | None,
        monitoring_context: dict[str, Any] | None,
        production_logger: Any | None,
        cli_error_classifier: Callable[[str], tuple[bool, str | None]] | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._emit_progress = emit_progress
        self._on_stream = on_stream
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context
        self._production_logger = production_logger
        self._cli_error_classifier = cli_error_classifier or classify_cli_error_response

    def invoke_raw(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        reasoning_level: str,
        auth_method: str = "oauth",
    ) -> str:
        """Invoke an LLM and return the raw response."""
        logger.debug(
            "Invoking LLM for intent: provider=%s model=%s thinking=%s",
            provider,
            model,
            reasoning_level,
        )

        def stream_chunk(chunk: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", chunk)

        heartbeat_thread: StageHeartbeatThread | None = None
        start = time.time()
        try:
            stage_context = {
                "provider": provider,
                "model": model,
                "reasoning_level": reasoning_level,
            }
            self._emit_progress(
                "planning_stage_started",
                {"stage": "intent_generation", "user_label": "Generating intent"},
            )
            self._emit_progress(
                "stage_started",
                {"stage": "intent_generation", "context": stage_context},
            )

            codex_config = self._llm_config.get("codex", {})
            if isinstance(codex_config, dict):
                bypass_sandbox = get_intent_bypass_sandbox()
                approval_mode = codex_config.get("approval_mode")
            else:
                bypass_sandbox = get_intent_bypass_sandbox()
                approval_mode = None

            timeout_s = get_llm_api_timeout()
            interval = get_heartbeat_interval()
            initial_delay = get_heartbeat_initial_delay()
            inline_heartbeat = sys.stdin.isatty() and get_runtime_verbosity() == VerbosityLevel.PROGRESS
            if inline_heartbeat:
                interval = 1
                initial_delay = min(1, initial_delay)

            heartbeat_thread = StageHeartbeatThread(
                stage="intent_generation",
                interval=interval,
                initial_delay=initial_delay,
                emit_progress=self._emit_progress,
                log_event=self._log_event,
            )
            heartbeat_thread.start()

            response = str(
                invoke_llm_via_cli(
                    prompt=prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    reasoning_level=reasoning_level,
                    auth_method=auth_method,
                    on_stream=stream_chunk if self._on_stream else None,
                    timeout_s=timeout_s,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="intent_generation",
                    monitoring_context=self._monitoring_context,
                    skip_git_check=self._llm_config.get("git", {}).get("skip_check", True),
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                )
            )
            duration_ms = int((time.time() - start) * 1000)
            self._emit_progress(
                "stage_completed",
                {
                    "stage": "intent_generation",
                    "duration_ms": duration_ms,
                    "result": {"response_chars": len(response)},
                },
            )
            self._emit_progress(
                "planning_stage_completed",
                {
                    "stage": "intent_generation",
                    "user_label": "Generating intent",
                    "duration_s": duration_ms / 1000.0,
                },
            )
            heartbeat_thread.stop()

            is_cli_error, error_type = self._cli_error_classifier(response)
            if is_cli_error:
                logger.warning(
                    "LLM CLI returned error response (type=%s): %s",
                    error_type,
                    response[:300],
                )
                return f"CLI_ERROR: {error_type} - {response[:200]}"

            return response
        except Exception as exc:
            duration_ms = int((time.time() - start) * 1000)
            self._emit_progress(
                "stage_failed",
                {
                    "stage": "intent_generation",
                    "error": str(exc),
                    "duration_ms": duration_ms,
                    "timeout_s": get_llm_api_timeout(),
                },
            )
            logger.exception("LLM invocation failed for intent generation")
            return json.dumps(build_intent_fallback("Error generating intent"))
        finally:
            if heartbeat_thread is not None:
                heartbeat_thread.stop()

    def invoke_with_template(
        self,
        prompt: str,
        objective: str,
        *,
        provider: str,
        model: str,
        reasoning_level: str,
        auth_method: str = "oauth",
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Invoke an LLM through TemplateEditPipeline."""
        logger.debug(
            "Invoking LLM for intent via template: provider=%s model=%s thinking=%s",
            provider,
            model,
            reasoning_level,
        )
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="intent",
            on_stream=None,
            log_event=self._log_event,
            production_logger=self._production_logger,
            max_retries=3,
        )
        intent_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=build_intent_template_schema(objective),
            validator=validate_intent_template,
            fallback_fn=lambda: build_intent_fallback(objective),
            llm_config={
                "provider": provider,
                "model": model,
                "reasoning_level": reasoning_level,
                "auth": auth_method,
            },
        )
        if metadata["status"] in {"template_success", "template_retry_success"}:
            return intent_data, EnrichmentLevel.FULL
        return intent_data, EnrichmentLevel.NONE
