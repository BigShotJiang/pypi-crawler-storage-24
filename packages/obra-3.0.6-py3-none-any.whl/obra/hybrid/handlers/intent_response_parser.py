"""Intent response parsing utilities."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from obra.constants import INTENT_INTERROGATIVE_RATIO_THRESHOLD
from obra.hybrid.json_utils import extract_json_payload, is_garbage_response
from obra.intent.models import EnrichmentLevel

logger = logging.getLogger(__name__)


class IntentResponseParser:
    """Parse raw intent-generation responses into structured intent data."""

    def parse(
        self,
        raw_response: str,
        objective: str,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Parse LLM response using graceful degradation."""
        response_to_parse = raw_response.strip() if raw_response else ""

        is_garbage, garbage_reason = is_garbage_response(response_to_parse, return_reason=True)
        if is_garbage:
            logger.warning(
                "Detected garbage response (reason=%s), using fallback. Response preview: %s",
                garbage_reason,
                response_to_parse[:200] if response_to_parse else "<empty>",
            )
            return self.tier4_fallback(objective), EnrichmentLevel.NONE

        markdown_result = self.tier2_markdown_sections(response_to_parse, objective)
        if markdown_result is not None:
            logger.debug("Tier 1 (markdown sections) succeeded")
            return markdown_result, EnrichmentLevel.FULL

        direct_json_result = self.tier1_direct_json(response_to_parse, objective)
        if direct_json_result is not None:
            logger.debug("Tier 2 (direct JSON - legacy) succeeded")
            return direct_json_result, EnrichmentLevel.FULL

        extracted_json_result = self.tier2_extract_json(response_to_parse, objective)
        if extracted_json_result is not None:
            logger.debug("Tier 3 (extract JSON payload - legacy) succeeded")
            return extracted_json_result, EnrichmentLevel.FULL

        prose_result = self.tier3_prose_extraction(response_to_parse, objective)
        if prose_result is not None:
            logger.debug("Tier 4 (prose extraction) succeeded")
            return prose_result, EnrichmentLevel.PROSE

        logger.warning("All parsing tiers failed, using Tier 5 fallback")
        return self.tier4_fallback(objective), EnrichmentLevel.NONE

    def tier2_markdown_sections(
        self,
        raw_response: str,
        objective: str,
    ) -> dict[str, Any] | None:
        """Parse markdown sections format."""
        try:
            response = raw_response.strip()
            if "##" not in response:
                return None

            sections = {
                "problem_statement": r"##\s*(?:Problem\s*Statement|Problem|Overview)",
                "assumptions": r"##\s*Assumptions?",
                "requirements": r"##\s*Requirements?",
                "acceptance_criteria": r"##\s*(?:Acceptance\s*Criteria|Success\s*Criteria)",
                "non_goals": r"##\s*(?:Non[- ]?Goals|Out[- ]of[- ]Scope)",
            }

            data: dict[str, Any] = {}
            found_any = False

            for field, pattern in sections.items():
                match = re.search(pattern, response, re.IGNORECASE)
                if not match:
                    continue

                found_any = True
                start = match.end()
                next_section = re.search(r"\n##\s", response[start:])
                end = start + next_section.start() if next_section else len(response)
                content = response[start:end].strip()

                if field in (
                    "assumptions",
                    "requirements",
                    "acceptance_criteria",
                    "non_goals",
                ):
                    items = []
                    for line in content.split("\n"):
                        stripped_line = line.strip()
                        if stripped_line.startswith(("-", "*", "•")):
                            item = stripped_line.lstrip("-*• ").strip()
                            if item:
                                items.append(item)
                        elif (
                            stripped_line
                            and stripped_line[0].isdigit()
                            and (". " in stripped_line or ") " in stripped_line)
                        ):
                            item = re.sub(r"^\d+[.)]\s*", "", stripped_line).strip()
                            if item:
                                items.append(item)
                    data[field] = items
                else:
                    data[field] = content

            if not found_any or ("problem_statement" not in data and len(data) < 2):
                return None

            return self.extract_intent_fields(data, objective)
        except (AttributeError, KeyError):
            return None

    def tier1_direct_json(
        self,
        raw_response: str,
        objective: str,
    ) -> dict[str, Any] | None:
        """Parse direct JSON responses, including fenced code blocks."""
        try:
            response = raw_response.strip()
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            data = json.loads(response)
            return self.extract_intent_fields(data, objective)
        except json.JSONDecodeError:
            return None

    def tier2_extract_json(
        self,
        raw_response: str,
        objective: str,
    ) -> dict[str, Any] | None:
        """Extract embedded JSON payloads from mixed prose."""
        payload = extract_json_payload(raw_response)
        if payload is None:
            return None

        try:
            data = json.loads(payload)
            return self.extract_intent_fields(data, objective)
        except json.JSONDecodeError:
            return None

    def tier3_prose_extraction(
        self,
        raw_response: str,
        _objective: str,
    ) -> dict[str, Any] | None:
        """Extract intent from declarative natural-language prose."""
        text = raw_response.strip()
        if not text:
            return None

        if self.is_interrogative(text):
            logger.debug("Tier 3 rejected: response is predominantly interrogative")
            return None

        lines = [line.strip() for line in text.split("\n") if line.strip()]
        if not lines:
            return None

        problem_statement = lines[0]
        if problem_statement.startswith("#"):
            problem_statement = problem_statement.lstrip("#").strip()

        if problem_statement.endswith("?"):
            logger.debug("Tier 3 rejected: problem statement is a question")
            return None

        requirements = []
        for line in lines[1:]:
            if line.startswith(("-", "*", "•")):
                item = line.lstrip("-*• ").strip()
                if item and len(item) > 3:
                    requirements.append(item)
            elif len(line) > 2 and line[0].isdigit():
                item = line.lstrip("0123456789.)(").strip()
                if item and len(item) > 3:
                    requirements.append(item)

        if problem_statement and (requirements or len(problem_statement) > 20):
            return {
                "problem_statement": problem_statement[:500],
                "assumptions": [],
                "requirements": requirements[:10],
                "acceptance_criteria": ["Implementation complete and verified"],
                "non_goals": [],
            }

        return None

    def is_interrogative(self, text: str) -> bool:
        """Return True when the text is predominantly questions."""
        question_count = text.count("?")
        sentence_count = text.count(".") + text.count("!") + question_count
        if sentence_count == 0:
            return question_count > 0
        return question_count / sentence_count > INTENT_INTERROGATIVE_RATIO_THRESHOLD

    def tier4_fallback(self, objective: str) -> dict[str, Any]:
        """Return a minimal fallback intent."""
        return {
            "problem_statement": objective,
            "assumptions": [],
            "requirements": [],
            "acceptance_criteria": ["Implementation complete and verified"],
            "non_goals": [],
        }

    def extract_intent_fields(self, data: dict[str, Any], objective: str) -> dict[str, Any]:
        """Extract canonical intent fields from parsed data."""
        return {
            "problem_statement": data.get("problem_statement", objective),
            "assumptions": data.get("assumptions", []),
            "requirements": data.get("requirements", []),
            "constraints": data.get("constraints", []),
            "acceptance_criteria": data.get("acceptance_criteria", []),
            "non_goals": data.get("non_goals", []),
            "risks": data.get("risks", []),
        }
