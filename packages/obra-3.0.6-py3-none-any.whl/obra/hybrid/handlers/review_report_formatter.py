"""Review output formatting helpers."""

from __future__ import annotations

import json
from collections.abc import Callable, Sequence
from typing import Any

from obra.api.protocol_core import AgentReportStatus
from obra.display import console
from obra.review.config import ALLOWED_AGENTS, ReviewConfig


class ReviewReportFormatter:
    """Format review output and CLI-facing messages."""

    def __init__(
        self,
        *,
        config: ReviewConfig,
        log_info: Callable[[str], None],
        log_warning: Callable[[str], None],
        log_error: Callable[[str], None],
        session_review_cycle_getter: Callable[[], int],
    ) -> None:
        self._config = config
        self._log_info = log_info
        self._log_warning = log_warning
        self._log_error = log_error
        self._session_review_cycle_getter = session_review_cycle_getter

    def build_completion_message(
        self,
        agent: str,
        status: str,
        issue_count: int,
        elapsed_seconds: float,
        error_message: Any,
    ) -> tuple[str, Callable[[str], None]]:
        """Return formatted completion message and logger based on status."""
        elapsed_text = f"{elapsed_seconds:.1f}s"
        findings_label = "finding" if issue_count == 1 else "findings"

        if status == AgentReportStatus.COMPLETE.value:
            return (
                f"[{agent}] done ({elapsed_text}) - {issue_count} {findings_label}",
                self._log_info,
            )
        if status == AgentReportStatus.TIMEOUT.value:
            return f"[{agent}] timed out after {elapsed_text}", self._log_warning
        if status == AgentReportStatus.ERROR.value:
            detail = str(error_message) if error_message else "error"
            return f"[{agent}] error after {elapsed_text}: {detail}", self._log_error
        return f"[{agent}] {status} after {elapsed_text}", self._log_warning

    def resolve_output_format(self, request_format: str | None) -> str:
        """Resolve effective output format using config override or request payload."""
        if self._config.output_format:
            return str(self._config.output_format)

        if request_format:
            normalized = str(request_format).strip().lower()
            if normalized in ("text", "json"):
                return normalized

        return "text"

    def emit_json_output(
        self,
        *,
        agent_runs: Sequence[dict[str, Any]],
        agent_reports: Sequence[dict[str, Any]],
        complexity_tier: str | None,
        total_elapsed_ms: int,
    ) -> dict[str, Any]:
        """Build and optionally print structured JSON review output."""
        payload = self.build_json_output(
            agent_runs=agent_runs,
            agent_reports=agent_reports,
            complexity_tier=complexity_tier,
            total_elapsed_ms=total_elapsed_ms,
        )
        if not self._config.quiet:
            console.print(json.dumps(payload, sort_keys=True), markup=False, highlight=False)
        return payload

    def build_json_output(
        self,
        *,
        agent_runs: Sequence[dict[str, Any]],
        agent_reports: Sequence[dict[str, Any]],
        complexity_tier: str | None,
        total_elapsed_ms: int,
    ) -> dict[str, Any]:
        """Construct JSON-friendly review summary for `--review-format=json`."""
        agents_output: list[dict[str, Any]] = []
        for run in agent_runs:
            agent_entry = {
                "agent": run.get("agent"),
                "status": run.get("status", "unknown"),
                "issue_count": int(run.get("issue_count", 0)),
                "elapsed_ms": int(run.get("elapsed_ms", 0)),
            }
            if run.get("error"):
                agent_entry["error"] = run["error"]
            agents_output.append(agent_entry)

        findings_by_agent: dict[str, Any] = {}
        for report in agent_reports:
            agent_name = str(report.get("agent_type") or report.get("agent") or "").strip()
            if not agent_name:
                continue

            issues = report.get("issues", [])
            issues_list = issues if isinstance(issues, list) else []
            priorities: dict[str, int] = {"p1": 0, "p2": 0, "p3": 0}
            for issue in issues_list:
                if not isinstance(issue, dict):
                    continue
                priority_value = issue.get("priority")
                if priority_value is None:
                    continue

                key = str(priority_value).lower()
                if key in priorities:
                    priorities[key] += 1
                elif key.startswith("p") and key[1:].isdigit():
                    priorities[key] = priorities.get(key, 0) + 1

            findings_by_agent[agent_name] = {
                "issue_count": len(issues_list),
                "priorities": priorities,
            }

        failed_agents = [
            run
            for run in agent_runs
            if run.get("status")
            in (AgentReportStatus.ERROR.value, AgentReportStatus.TIMEOUT.value)
        ]
        totals = {
            "agents": len(agent_runs),
            "issue_count": sum(run.get("issue_count", 0) for run in agent_runs),
            "failed_agents": len(failed_agents),
            "elapsed_ms": total_elapsed_ms,
        }
        return {
            "agents_run": agents_output,
            "complexity_tier": (complexity_tier or "unknown").lower(),
            "findings_by_agent": findings_by_agent,
            "totals": totals,
        }

    def should_show_full_review_hint(
        self,
        agent_runs: Sequence[dict[str, Any]],
        complexity_tier: str | None,
    ) -> bool:
        """Return True when the run is minimal enough to suggest full review."""
        if self._config.quiet:
            return False
        if self._config.full_review or self._config.explicit_agents is not None:
            return False
        if self._session_review_cycle_getter() != 1:
            return False
        if not agent_runs:
            return False

        normalized_tier = (complexity_tier or "").lower()
        if normalized_tier == "simple":
            return True
        if len(agent_runs) == 1:
            return True
        return len(agent_runs) < len(ALLOWED_AGENTS)
