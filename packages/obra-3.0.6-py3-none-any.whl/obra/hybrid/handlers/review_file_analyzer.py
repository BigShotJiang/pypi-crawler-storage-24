"""Review file-analysis helpers."""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from obra.api.protocol import AgentType, ReviewRequest
from obra.review.constants import (
    COMPLEXITY_THRESHOLDS,
    has_security_pattern,
    has_test_pattern,
)
from obra.utils.file_tracker import FileStateTracker

logger = logging.getLogger(__name__)


class FileComplexityAnalyzer:
    """Analyze review scope and choose review agents from file-change signals."""

    def __init__(
        self,
        *,
        working_dir: Path,
        file_tracker: FileStateTracker,
        review_request_getter: Callable[[], ReviewRequest | None],
    ) -> None:
        self._working_dir = working_dir
        self._file_tracker = file_tracker
        self._review_request_getter = review_request_getter

    def get_changed_files(self) -> list[str] | None:
        """Return review-scope files, preferring request-scoped paths."""
        review_request = self._review_request_getter()
        if (
            review_request is not None
            and review_request.changed_files is not None
            and len(review_request.changed_files) > 0
        ):
            return [str(path) for path in review_request.changed_files if str(path).strip()]

        try:
            files = self._file_tracker.get_all_files()
            logger.debug("FileStateTracker found %d files in %s", len(files), self._working_dir)
            return files
        except OSError as exc:
            logger.debug("Failed to scan files: %s", exc)
            return None

    def get_all_files_for_complexity(self) -> list[str] | None:
        """Return all trackable files for local complexity detection."""
        try:
            files = self._file_tracker.get_all_files()
            logger.debug("Complexity scan found %d files in %s", len(files), self._working_dir)
            return files
        except OSError as exc:
            logger.debug("Failed complexity scan: %s", exc)
            return None

    def count_lines_added(self, files: list[str] | None) -> int:
        """Count total lines across provided files."""
        if not files:
            return 0
        return self._file_tracker.count_lines(files)

    def has_security_sensitive_files(self, files: Sequence[str] | None) -> bool:
        """Return True when any file matches known security-sensitive patterns."""
        if not files:
            return False
        return any(has_security_pattern(path) for path in files)

    def has_test_files(self, files: Sequence[str] | None) -> bool:
        """Return True when any file path points to a test file or directory."""
        if not files:
            return False
        return any(has_test_pattern(path) for path in files)

    def detect_complexity(self) -> dict[str, Any]:
        """Select review agents using local change signals and shared thresholds."""
        changed_files = self.get_all_files_for_complexity()

        if changed_files is None:
            return {
                "agents": [
                    AgentType.CODE_QUALITY.value,
                    AgentType.SECURITY.value,
                    AgentType.TESTING.value,
                    AgentType.DOCS.value,
                    AgentType.TEST_EXECUTION.value,
                ],
                "complexity": "complex",
                "changed_files": None,
                "lines_added": 0,
                "files_changed": None,
            }

        lines_added = self.count_lines_added(changed_files)
        files_changed = len(changed_files)
        simple_threshold = COMPLEXITY_THRESHOLDS["simple"]
        medium_threshold = COMPLEXITY_THRESHOLDS["medium"]

        if (
            files_changed <= simple_threshold["max_files"]
            and lines_added <= simple_threshold["max_lines"]
        ):
            complexity = "simple"
            agents = [AgentType.CODE_QUALITY.value]
        elif (
            files_changed <= medium_threshold["max_files"]
            and lines_added <= medium_threshold["max_lines"]
        ):
            complexity = "medium"
            agents = [AgentType.CODE_QUALITY.value, AgentType.SECURITY.value]
        else:
            complexity = "complex"
            agents = [
                AgentType.CODE_QUALITY.value,
                AgentType.SECURITY.value,
                AgentType.TESTING.value,
                AgentType.DOCS.value,
                AgentType.TEST_EXECUTION.value,
            ]

        if self.has_security_sensitive_files(changed_files) and AgentType.SECURITY.value not in agents:
            agents.insert(0, AgentType.SECURITY.value)

        if self.has_test_files(changed_files) and AgentType.TESTING.value not in agents:
            agents.append(AgentType.TESTING.value)

        return {
            "agents": agents,
            "complexity": complexity,
            "changed_files": changed_files,
            "lines_added": lines_added,
            "files_changed": files_changed,
        }
