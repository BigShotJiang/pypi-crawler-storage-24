"""Shared helper logic for the review handler."""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.review.config import ReviewConfig
from obra.review.verdict import _normalize_priority

logger = logging.getLogger(__name__)


def emit_skip_record(
    *,
    working_dir: Path,
    item_id: str,
    agent_type: str,
    status: str,
    error_message: str | None,
    log_event: Callable[..., None] | None,
    trace_id: str | None,
) -> None:
    """Emit a skip record for a skipped or errored review agent."""
    try:
        from obra.execution.skip_record import (
            SkipReason,
            SkipSource,
            create_skip_record,
        )

        reason = (
            SkipReason.QUALITY_THRESHOLD
            if status == "skipped"
            else SkipReason.TRANSIENT_EXHAUSTED
        )
        description = f"Review agent '{agent_type}' {status}"
        if error_message:
            description = f"{description}: {error_message}"
        source_context: dict[str, Any] = {"agent_type": agent_type, "phase": "review"}
        if error_message:
            source_context["error_type"] = (
                error_message.split(":")[0].strip() if ":" in error_message else status
            )
        create_skip_record(
            session_id=trace_id or "",
            task_id=item_id,
            source=SkipSource.QUALITY_LOOP,
            reason=reason,
            description=description,
            source_context=source_context,
            base_dir=str(working_dir),
            log_event=log_event,
            trace_id=trace_id,
        )
    except Exception:
        logger.debug("Failed to emit SkipRecord for review agent %s", agent_type, exc_info=True)


def build_intent_context(*, working_dir: Path, config: ReviewConfig) -> str | None:
    """Build a compact intent summary for review prompts."""
    if not config.intent_context_enabled:
        return None

    try:
        from obra.intent.models import EnrichmentLevel
        from obra.intent.storage import IntentStorage
    except Exception as exc:
        logger.debug("Intent context unavailable: %s", exc)
        return None

    storage = IntentStorage()
    project_id = storage.get_project_id(working_dir)
    intent = storage.load_active(project_id)
    if not intent or getattr(intent, "enrichment_level", None) == EnrichmentLevel.NONE:
        return None

    max_items = config.intent_context_max_items
    max_item_chars = config.intent_context_max_item_chars
    max_chars = config.intent_context_max_chars

    def trim_item(value: str) -> str | None:
        text = str(value or "").strip()
        if not text:
            return None
        if len(text) > max_item_chars:
            text = text[: max_item_chars - 3].rstrip() + "..."
        return text

    def trim_list(values: list[str]) -> list[str]:
        trimmed: list[str] = []
        for value in values:
            item = trim_item(value)
            if item:
                trimmed.append(item)
            if len(trimmed) >= max_items:
                break
        return trimmed

    lines: list[str] = ["# Intent Summary (Review Context)"]

    problem = trim_item(getattr(intent, "problem_statement", ""))
    if problem:
        lines.append(f"Problem: {problem}")

    stories = getattr(intent, "user_stories", []) or []
    if stories:
        lines.extend(["", "User Stories:"])
        for story in stories[:max_items]:
            verification_method = getattr(story, "verification_method", "unknown")
            verification_label = (
                verification_method.value
                if hasattr(verification_method, "value")
                else str(verification_method)
            )
            lines.append(
                f"- {story.id}: As a {story.role}, I want {story.action} ({verification_label})"
            )

            proof_command = trim_item(getattr(story, "proof_command", ""))
            if proof_command:
                lines.append(f"  Proof: `{proof_command}`")

            manual_steps = getattr(story, "manual_steps", None) or []
            manual_summary = trim_item("; ".join(manual_steps[:3]))
            if manual_summary:
                lines.append(f"  Manual verification: {manual_summary}")

    for heading, attr in (
        ("Acceptance Criteria:", "acceptance_criteria"),
        ("Constraints:", "constraints"),
        ("Non-goals:", "non_goals"),
    ):
        items = trim_list(getattr(intent, attr, []) or [])
        if items:
            lines.extend(["", heading, *[f"- {item}" for item in items]])

    if len(lines) == 1:
        return None

    summary = "\n".join(lines)
    if len(summary) > max_chars:
        summary = summary[: max_chars - 3].rstrip() + "..."
    return summary


def apply_execution_scope(
    *,
    agent_reports: list[dict[str, Any]],
    changed_files: list[str] | None,
) -> None:
    """Apply same-cycle scope filtering to review issues."""
    if not changed_files:
        return

    normalized_scope = {str(path).strip() for path in changed_files if str(path).strip()}
    if not normalized_scope:
        return

    for report in agent_reports:
        issues = report.get("issues")
        if not isinstance(issues, list):
            continue
        for issue in issues:
            if not isinstance(issue, dict):
                continue
            file_path = str(issue.get("file_path") or "").strip()
            if not file_path or file_path in normalized_scope:
                continue

            priority = _normalize_priority(issue.get("priority"))
            metadata = issue.get("metadata")
            if not isinstance(metadata, dict):
                metadata = {}
            metadata["outside_changed_scope"] = True

            if priority in ("P0", "P1"):
                normalized_scope.add(file_path)
                metadata["same_cycle_scope_included"] = True
            else:
                metadata["blocking_eligible"] = False
                metadata["same_cycle_scope_included"] = False

            issue["metadata"] = metadata
