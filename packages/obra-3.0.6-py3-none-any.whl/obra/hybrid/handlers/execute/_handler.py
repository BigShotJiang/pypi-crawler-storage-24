"""Execute handler for Hybrid Orchestrator.

This module handles the EXECUTE action from the server. It executes a plan item
by deploying an implementation agent (Claude Code, etc.).

The execution process:
    1. Receive ExecutionRequest with plan item to execute
    2. Prepare execution context (files, dependencies)
    3. Deploy implementation agent
    4. Collect execution results (files changed, tests, etc.)
    5. Return ExecutionResult to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import logging
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.api.protocol import ExecutionRequest, ExecutionStatus
from obra.config.loaders import (
    get_execute_parallel_workers,
    load_layered_config,
)
from obra.core.interrupts import interrupt_requested
from obra.hybrid.handlers.execute._agent_executor import AgentExecutor
from obra.hybrid.handlers.execute._file_tracker import ExecutionFileTracker
from obra.hybrid.handlers.execute._recovery import ExecutionRecovery
from obra.hybrid.handlers.execute._verification import ExecutionVerifier
from obra.hybrid.handlers.execute_monitoring import (  # noqa: F401
    ExecuteHandlerProtocol,
    FileChangeSet,
    FileChangeTracker,
    HeartbeatThread,
    _MonitoringEventAdapter,
)
from obra.display import print_error, print_info, print_warning
from obra.display.observability import (
    ObservabilityConfig,
    ProgressEmitter,
    VerbosityLevel,
)
from obra.hybrid.handlers.base import ObservabilityContextMixin
from obra.hybrid.prompt_enricher import PromptEnricher

logger = logging.getLogger(__name__)

# Type alias for streaming callback
StreamCallback = Callable[[str, str], None] | None


class ExecuteHandler(ObservabilityContextMixin):
    """Handler for EXECUTE action.

    Executes a plan item using an implementation agent (e.g., Claude Code CLI).
    Returns execution results including files changed and test results.

    ## Architecture Context (ADR-035)

    This handler implements the unified hybrid architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with execution instructions
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends ExecutionRequest with base_prompt containing execution instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes implementation agent (e.g., Claude Code CLI) via subprocess
    4. Client runs tests locally and reports results back to server

    ## IP Protection

    Strategic execution patterns (best practices, quality standards) stay on server.
    This protects Obra's proprietary implementation guidance from client-side inspection.

    ## Privacy Protection

    Tactical context (file contents, git messages, errors) never sent to server.
    Only execution results (summary, files changed, test results) is transmitted.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md

    Example:
        >>> handler = ExecuteHandler(Path("/path/to/project"))
        >>> request = ExecutionRequest(
        ...     plan_items=[{"id": "T1", "title": "Create models", ...}],
        ...     execution_index=0
        ... )
        >>> result = handler.handle(request)
        >>> print(result["status"])
    """

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, str] | None = None,
        session_id: str | None = None,
        log_file: Path | None = None,
        trace_id: str | None = None,
        log_event: Any | None = None,
        parent_span_id: str | None = None,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        on_stream: StreamCallback = None,
        process_registry: Any | None = None,
        monitoring_context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize ExecuteHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: Optional LLM configuration (S6.T1)
            session_id: Optional session ID for trace correlation
            log_file: Optional log file path for event emission
            trace_id: Optional trace ID for distributed tracing
            log_event: Optional event logging callback
            parent_span_id: Optional parent span ID for tracing
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            on_stream: Optional callback for LLM streaming output (event_type, chunk)
            process_registry: Optional ProcessRegistry for subprocess lifecycle management
                             (FEAT-PROCESS-LIFECYCLE-001)
            monitoring_context: Optional monitoring context for liveness checks
        """
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._session_id = session_id
        self._log_file = log_file
        self._trace_id = trace_id
        self._log_event = log_event
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._on_stream = on_stream
        self._process_registry = process_registry
        self._monitoring_context = dict(monitoring_context) if monitoring_context else None
        if self._monitoring_context is not None:
            if "production_logger" not in self._monitoring_context:
                self._monitoring_context["production_logger"] = _MonitoringEventAdapter(
                    self._log_event
                )
            if "session_id" not in self._monitoring_context and self._session_id:
                self._monitoring_context["session_id"] = self._session_id
        self._file_tracker = ExecutionFileTracker(working_dir)
        self._verifier = ExecutionVerifier(working_dir, self._llm_config)
        self._recovery = ExecutionRecovery(working_dir)
        self._execution_start_time: float | None = None
        self._parallel_requested = os.environ.get("OBRA_PARALLEL_EXECUTION", "").lower() in (
            "1",
            "true",
        )
        self._parallel_enabled = False
        self._parallel_max_workers = 1
        self._parallel_logged = False
        if self._parallel_requested:
            try:
                from obra.config.loaders import load_layered_config

                config, _, _ = load_layered_config(include_defaults=True)
                parallel_cfg = config.get("execution", {}).get("parallel", {})
                self._parallel_enabled = bool(parallel_cfg.get("enabled", False))
                self._parallel_max_workers = get_execute_parallel_workers()
            except Exception as exc:
                logger.debug("Failed to load parallel execution config: %s", exc)

    # -- Protocol proxy methods (ExecuteHandlerProtocol compatibility) --
    # execute_monitoring.py's FileChangeTracker and HeartbeatThread call these
    # via self._handler._method(). They delegate to ExecutionFileTracker.

    def _get_file_changes(self) -> FileChangeSet:
        return self._file_tracker.get_file_changes()

    def _count_file_changes(self) -> int:
        return self._file_tracker.count_file_changes()

    def _count_lines(self, filepath: str) -> int | None:
        return self._file_tracker.count_lines(filepath)

    def get_session_file_changes(self) -> FileChangeSet:
        """Get file changes since session started (used by orchestrator)."""
        return self._file_tracker.get_session_file_changes()

    def handle(self, request: ExecutionRequest) -> dict[str, Any]:
        """Handle EXECUTE action.

        Args:
            request: ExecutionRequest from server with base_prompt

        Returns:
            Dict with item_id, status, summary, files_changed, etc.

        Raises:
            ValueError: If request.base_prompt is None (server must provide base_prompt)
        """
        if not request.current_item:
            logger.error("No current item to execute")
            return {
                "item_id": "",
                "status": ExecutionStatus.FAILURE.value,
                "summary": "No item to execute",
                "files_changed": 0,
                "tests_passed": False,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

        # Validate base_prompt (server-side prompting required)
        if request.base_prompt is None:
            error_msg = (
                "ExecutionRequest.base_prompt is None. Server must provide base prompt (ADR-035)."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        if self._parallel_requested and not self._parallel_logged:
            self._parallel_logged = True
            if self._parallel_enabled:
                logger.info(
                    "Parallel execution enabled (max_workers=%d)",
                    self._parallel_max_workers,
                )
            else:
                logger.info("Parallel execution requested but disabled by config.")

        item = request.current_item
        item_id = str(item.get("id", "unknown"))
        title = str(item.get("title", "Untitled"))

        logger.info(f"Executing item {item_id}: {title}")
        show_exec_info = self._progress_emitter is None
        if self._observability_config and self._observability_config.verbosity >= VerbosityLevel.DETAIL:
            show_exec_info = True
        if show_exec_info:
            print_info(f"Executing: {item_id} - {title}")

        # Skip container items (non-leaf nodes) in hierarchical plans
        if request.plan_items and self._has_children(item_id, request.plan_items):
            logger.info("Skipping non-leaf container item: %s", item_id)
            # Update baseline snapshot even for skipped items
            self._file_tracker.update_task_baseline()
            return {
                "item_id": item_id,
                "status": ExecutionStatus.SUCCESS.value,
                "summary": f"Skipped container item: {title}",
                "files_changed": 0,
                "tests_passed": True,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

        # Imported plans may contain trigger-only tasks whose work is performed
        # by pipeline stages outside the implementation agent path.
        no_op_result = self._build_explicit_no_op_result(item)
        if no_op_result is not None:
            logger.info("Skipping implementation agent for explicit no-op item: %s", item_id)
            self._file_tracker.update_task_baseline()
            return no_op_result

        ancestor_context = self._build_ancestor_context(item, request.plan_items)
        base_prompt = request.base_prompt
        if ancestor_context:
            base_prompt = f"{base_prompt}\n\n## Ancestor Context\n{ancestor_context}\n"
        item_context_block = self._build_item_context(item)
        if item_context_block:
            base_prompt = f"{base_prompt}\n\n{item_context_block}"
        base_prompt = self._inject_verification_notes(base_prompt, item)

        # Enrich base prompt with local tactical context
        enricher = PromptEnricher(self._working_dir)
        enriched_prompt = enricher.enrich(base_prompt)

        # Execute via implementation agent
        result = self._execute_item(item, enriched_prompt, request)

        # Log result
        status = result.get("status", ExecutionStatus.FAILURE.value)
        if status == ExecutionStatus.SUCCESS.value:
            print_info(f"  Completed: {result.get('summary', 'Success')}")
        elif status == ExecutionStatus.PARTIAL.value:
            print_warning(f"  Partial: {result.get('summary', 'Partial completion')}")
        elif interrupt_requested():
            print_info("  Interrupted — will retry on resume")
        else:
            print_error(f"  Failed: {result.get('summary', 'Execution failed')}")

        return result

    @staticmethod
    def _build_explicit_no_op_result(item: dict[str, Any]) -> dict[str, Any] | None:
        """Return a synthetic success result for explicitly no-op tasks."""
        context = item.get("context", {})
        if not isinstance(context, dict):
            return None

        execution_mode = str(context.get("execution_mode", "")).strip().lower()
        if execution_mode != "no_op_success":
            return None

        item_id = str(item.get("id", "unknown"))
        title = str(item.get("title", "Untitled"))
        summary = str(
            context.get("execution_summary")
            or f"No implementation step required for {title}; externalized workflow execution completed."
        ).strip()

        return {
            "item_id": item_id,
            "status": ExecutionStatus.SUCCESS.value,
            "summary": summary,
            "files_changed": 0,
            "tests_passed": True,
            "test_count": 0,
            "coverage_delta": 0.0,
        }

    def _has_children(self, item_id: str, plan_items: list[dict[str, Any]]) -> bool:
        """Check if a plan item has children in the plan."""
        return any(candidate.get("parent_id") == item_id for candidate in plan_items)

    @staticmethod
    def _inject_verification_notes(base_prompt: str, item: dict[str, Any]) -> str:
        """Append warning context for V1/V2 verification notes on the current task."""
        verification_notes = item.get("context", {}).get("verification_notes", [])
        if not isinstance(verification_notes, list) or not verification_notes:
            return base_prompt

        note_lines: list[str] = []
        for note in verification_notes:
            if not isinstance(note, dict):
                continue
            severity = str(note.get("severity", "P2"))
            check = str(note.get("check", "C?"))
            description = str(note.get("description", "")).strip()
            if not description:
                continue
            note_lines.append(f"  - [{severity}/{check}] {description}")

        if not note_lines:
            return base_prompt

        warning_block = "WARNING: Verification notes for this task:\n" + "\n".join(note_lines)
        return f"{base_prompt}\n\n{warning_block}\n"

    @staticmethod
    def _build_item_context(item: dict[str, Any]) -> str:
        """Format the current item's acceptance criteria for inclusion in the execution prompt.

        The ancestor context provides parent-level criteria and sibling awareness,
        but the current item's own acceptance criteria are not included there.
        This method closes that gap so the LLM knows what success looks like
        for the specific task it's executing.
        """
        criteria = item.get("acceptance_criteria", [])
        if not isinstance(criteria, list) or not criteria:
            return ""

        lines = ["## Current Task Requirements"]
        for criterion in criteria:
            text = str(criterion).strip()
            if text:
                lines.append(f"- {text}")

        if len(lines) == 1:
            return ""

        return "\n".join(lines)

    def _build_ancestor_context(
        self,
        item: dict[str, Any],
        plan_items: list[dict[str, Any]],
        max_chars: int = 1500,
    ) -> str:
        """Build ancestor context chain for a plan item, including sibling awareness.

        The executor LLM receives this context to understand:
        1. The hierarchy (Epic → Story) with acceptance criteria
        2. What other tasks exist in the same story (sibling awareness)

        Sibling awareness helps the executor understand what work preceded it
        and what will follow, enabling better coordination without explicit
        dependencies in the task description.
        """
        if not plan_items:
            return ""

        id_map = {candidate.get("id"): candidate for candidate in plan_items if candidate.get("id")}
        chain: list[dict[str, Any]] = []
        current = item
        seen: set[str] = set()

        while current.get("parent_id"):
            parent_id = current.get("parent_id")
            if not parent_id or parent_id in seen:
                break
            seen.add(parent_id)
            parent = id_map.get(parent_id)
            if not parent:
                break
            chain.append(parent)
            current = parent

        if not chain:
            return ""

        chain.reverse()
        lines: list[str] = []
        for ancestor in chain:
            label = str(ancestor.get("item_type", "parent")).upper()
            title = ancestor.get("title", "Untitled")
            lines.append(f"{label}: {title}")
            criteria = ancestor.get("acceptance_criteria", [])
            if criteria:
                criteria_text = "; ".join(str(c) for c in criteria)
                lines.append(f"Acceptance: {criteria_text}")

        # Add sibling task awareness
        item_id = item.get("id")
        parent_id = item.get("parent_id")
        if parent_id:
            # Find all tasks with the same parent (siblings + self)
            siblings = [p for p in plan_items if p.get("parent_id") == parent_id]
            # Sort by ID for consistent ordering (E1.S1.T1, E1.S1.T2, etc.)
            siblings.sort(key=lambda x: x.get("id", ""))

            if len(siblings) > 1:  # Only show if there are actual siblings
                lines.append("")
                lines.append("Tasks in this story:")
                for sib in siblings:
                    sib_id = sib.get("id", "")
                    sib_title = sib.get("title", "Untitled")
                    if sib_id == item_id:
                        lines.append(f"  - {sib_id}: {sib_title}  <-- current")
                    else:
                        lines.append(f"  - {sib_id}: {sib_title}")

        context = "\n".join(lines)
        if len(context) > max_chars:
            context = context[: max_chars - 3].rstrip() + "..."
        return context

    def _execute_item(
        self, item: dict[str, Any], enriched_prompt: str, request: ExecutionRequest
    ) -> dict[str, Any]:
        """Execute a single plan item.

        Args:
            item: Plan item to execute
            enriched_prompt: Enriched execution prompt from server
            request: ExecutionRequest payload with full plan context

        Returns:
            Execution result dictionary
        """
        item_id = item.get("id", "unknown")
        title = item.get("title", "Untitled")

        # Try to deploy implementation agent with enriched prompt
        try:
            before_state = self._file_tracker.capture_file_state()
            result = self._deploy_agent(enriched_prompt, request)
            files_modified = self._file_tracker.detect_modifications(before_state)
            boundary_check = self._file_tracker.validate_project_boundary(files_modified)
            if boundary_check["has_violations"]:
                logger.warning(
                    "Execution boundary violation for %s: %s",
                    item_id,
                    boundary_check["violations"],
                )
                return {
                    "item_id": item_id,
                    "status": ExecutionStatus.FAILURE.value,
                    "summary": (
                        "Execution wrote files outside the target directory. "
                        f"Violations: {', '.join(boundary_check['violations'])}"
                    ),
                    "files_changed": 0,
                    "changed_file_paths": [],
                    "tests_passed": False,
                    "test_count": 0,
                    "coverage_delta": 0.0,
                }

            # Count files changed (would be from git diff in production)
            files_changed = result.get("files_changed", 0)

            status = result.get("status", ExecutionStatus.SUCCESS.value)
            if status == ExecutionStatus.FAILURE.value:
                tests_passed, test_count = False, 0
            elif status == ExecutionStatus.PARTIAL.value and result.get("decomposition_suggested"):
                tests_passed, test_count = False, 0
            else:
                # Run tests if present
                tests_passed, test_count = self._verifier.run_tests()

            verification_tools = self._verifier.discover_verification_tools()
            result_payload = {
                "item_id": item_id,
                "status": status,
                "summary": result.get("summary", f"Executed: {title}"),
                "files_changed": files_changed,
                "changed_file_paths": files_modified,
                "tests_passed": tests_passed,
                "test_count": test_count,
                "coverage_delta": 0.0,  # Would be calculated from coverage reports
            }
            if verification_tools:
                result_payload["verification_tools"] = verification_tools
            if result.get("error"):
                result_payload["error"] = result.get("error")
            if result.get("failure_class"):
                result_payload["failure_class"] = result.get("failure_class")
            if result.get("retry_count") is not None:
                result_payload["retry_count"] = result.get("retry_count")
            if result.get("retryable") is not None:
                result_payload["retryable"] = bool(result.get("retryable"))
            if result.get("request_id"):
                result_payload["request_id"] = result.get("request_id")
            if result.get("decomposition_suggested") is not None:
                result_payload["decomposition_suggested"] = bool(
                    result.get("decomposition_suggested")
                )
                result_payload["decomposition_reason"] = result.get("decomposition_reason")
                result_payload["partial_work_summary"] = result.get("partial_work_summary")

            return result_payload

        except Exception as e:
            logger.exception(f"Execution failed for {item_id}: {e}")
            return {
                "item_id": item_id,
                "status": ExecutionStatus.FAILURE.value,
                "summary": f"Execution failed: {e!s}",
                "files_changed": 0,
                "changed_file_paths": [],
                "tests_passed": False,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

    def _deploy_agent(self, prompt: str, request: ExecutionRequest) -> dict[str, Any]:
        """Deploy implementation agent via subprocess.

        Delegates to AgentExecutor for the full subprocess orchestration loop.

        Args:
            prompt: Execution prompt
            request: ExecutionRequest payload with plan items

        Returns:
            Agent result dictionary with status, summary, files_changed
        """
        executor = AgentExecutor(
            llm_config=self._llm_config,
            working_dir=self._working_dir,
            session_id=self._session_id,
            log_file=self._log_file,
            trace_id=self._trace_id,
            log_event=self._log_event,
            parent_span_id=self._parent_span_id,
            observability_config=self._observability_config,
            progress_emitter=self._progress_emitter,
            on_stream=self._on_stream,
            process_registry=self._process_registry,
            monitoring_context=self._monitoring_context,
            file_tracker=self._file_tracker,
            verifier=self._verifier,
            recovery=self._recovery,
            handler=self,
        )
        return executor.deploy(prompt, request)


__all__ = ["ExecuteHandler"]
