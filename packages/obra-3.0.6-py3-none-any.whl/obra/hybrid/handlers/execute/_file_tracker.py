"""File tracking for the execute handler.

Manages file change detection, project boundary validation, and two-level
baseline tracking (session vs task) for the execution lifecycle.
"""

import logging
import os
from pathlib import Path
from typing import Any

from obra.hybrid.handlers.execute_monitoring import FileChangeSet
from obra.utils.file_tracker import FileSnapshot, FileStateTracker

logger = logging.getLogger(__name__)


class ExecutionFileTracker:
    """Track file changes during execution.

    Wraps FileStateTracker and manages two-level baselines:
    - session_baseline: Immutable snapshot at init (for closeout summaries)
    - task_baseline: Updated after each task (for per-task new vs modified)
    """

    def __init__(self, working_dir: Path) -> None:
        self._working_dir = working_dir
        self._tracker = FileStateTracker(working_dir)
        initial_snapshot = self._tracker.snapshot()
        self._session_baseline = initial_snapshot
        self._task_baseline = initial_snapshot

    def capture_file_state(self) -> FileSnapshot:
        """Capture current file state for diff detection."""
        return self._tracker.snapshot()

    def detect_modifications(self, before_state: FileSnapshot) -> list[str]:
        """Detect files modified since before_state was captured."""
        changes = self._tracker.diff(before_state)
        return changes.all_changed_files

    def validate_project_boundary(self, files_modified: list[str]) -> dict[str, Any]:
        """Validate all modifications are within project directory."""
        if not files_modified:
            return {"has_violations": False, "violations": []}

        project_root = Path(os.path.abspath(self._working_dir))
        violations: list[str] = []

        for file_path in files_modified:
            try:
                candidate = Path(file_path)
                normalized = candidate if candidate.is_absolute() else project_root / candidate
                Path(os.path.abspath(normalized)).relative_to(project_root)
            except ValueError:
                violations.append(file_path)
                logger.exception("Project boundary violation")

        if violations:
            logger.error(
                "Execute handler modified %d file(s) outside project: %s",
                len(violations),
                violations,
            )

        return {"has_violations": bool(violations), "violations": violations}

    def get_file_changes(self) -> FileChangeSet:
        """Get file changes since last task completed.

        Compares current state against task baseline to properly differentiate
        between added and modified files within the current task.

        Returns:
            FileChangeSet with added, modified files and total count
        """
        try:
            changes = self._tracker.diff(self._task_baseline)
            total_count = len(changes.added) + len(changes.modified)
            logger.debug(
                f"FileStateTracker: {len(changes.added)} added, {len(changes.modified)} modified"
            )
            return FileChangeSet(
                added=set(changes.added),
                modified=set(changes.modified),
                count=total_count,
            )
        except OSError as e:
            logger.warning(f"File tracking failed: {e}")
            return FileChangeSet(added=set(), modified=set(), count=0)

    def count_file_changes(self) -> int:
        """Count files in working directory using FileStateTracker.

        Uses git-independent file tracking. Respects IGNORE_DIRS patterns
        to exclude infrastructure files (.obra/, node_modules/, etc.).

        Returns:
            Number of trackable files in working directory.
            Returns 0 only if directory is truly empty or an error occurs.
        """
        try:
            files = self._tracker.get_all_files()
            file_count = len(files)
            logger.debug(f"FileStateTracker found {file_count} files in {self._working_dir}")
            return file_count
        except OSError as e:
            logger.warning(f"File tracking failed: {e}")
            return 0

    def count_lines(self, filepath: str) -> int | None:
        """Count lines in a file, handling binary files gracefully.

        Args:
            filepath: Relative path to file from working directory

        Returns:
            Number of lines in the file, or None if file is binary or unreadable
        """
        try:
            file_path = self._working_dir / filepath

            # Read file and count lines
            with file_path.open(encoding="utf-8") as f:
                return sum(1 for _ in f)

        except UnicodeDecodeError:
            # Binary file - return None
            logger.debug(f"Binary file detected: {filepath}")
            return None
        except FileNotFoundError:
            logger.debug(f"File not found: {filepath}")
            return None
        except Exception as e:
            logger.debug(f"Failed to count lines in {filepath}: {e}")
            return None

    def get_session_file_changes(self) -> FileChangeSet:
        """Get file changes since session started.

        Compares current state against session baseline (captured at handler init)
        to get the complete picture of files created/modified across all tasks.

        Used by orchestrator for closeout summaries.

        Returns:
            FileChangeSet with added, modified files and total count
        """
        try:
            changes = self._tracker.diff(self._session_baseline)
            total_count = len(changes.added) + len(changes.modified)
            logger.debug(
                f"Session file changes: {len(changes.added)} added, {len(changes.modified)} modified"
            )
            return FileChangeSet(
                added=set(changes.added),
                modified=set(changes.modified),
                count=total_count,
            )
        except OSError as e:
            logger.warning(f"Session file tracking failed: {e}")
            return FileChangeSet(added=set(), modified=set(), count=0)

    def build_partial_work_summary(
        self,
        max_chars: int,
    ) -> tuple[str | None, int]:
        """Build a partial work summary for decomposition responses."""
        changes = self._tracker.diff(self._task_baseline)
        changed_files = changes.added + changes.modified
        if not changed_files:
            return None, 0

        after_snapshot = self._tracker.snapshot()
        size_delta = 0
        for path in changed_files:
            after_state = after_snapshot.files.get(path)
            if not after_state:
                continue
            before_state = self._task_baseline.files.get(path)
            before_size = before_state.size if before_state else 0
            size_delta += after_state.size - before_size

        lines_added = self._tracker.count_lines(changed_files)
        file_list = ", ".join(changed_files)
        summary = (
            f"Files modified: {len(changed_files)} ({file_list}). "
            f"Lines added: {lines_added}. "
            f"Size delta: {size_delta} bytes."
        )

        if max_chars > 0 and len(summary) > max_chars:
            summary = summary[: max_chars - 3].rstrip() + "..."

        return summary, len(changed_files)

    def update_task_baseline(self) -> None:
        """Update the task baseline to current state.

        Called after successful task execution to ensure subsequent tasks
        correctly identify files as 'modified' rather than 'new'.
        """
        self._task_baseline = self._tracker.snapshot()
