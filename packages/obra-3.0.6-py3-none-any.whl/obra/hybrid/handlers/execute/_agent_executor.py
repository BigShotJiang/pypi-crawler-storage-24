"""Agent executor for the execute handler.

Encapsulates the full LLM subprocess orchestration loop: config resolution,
subprocess invocation, retry logic, heartbeat setup, watchdog/liveness
monitoring, zero-output validation, deliverable validation, interactive
guard, and rollback handling.
"""

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from obra.api.protocol import ExecutionRequest, ExecutionStatus
from obra.config import (
    get_agent_execution_timeout,
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
)
from obra.config.loaders import (
    get_execute_zero_output_retry_max,
    get_interactive_guard_retry_max,
    get_interactive_guard_rollback_codes,
    get_interactive_guard_rollback_enabled,
    load_layered_config,
)
from obra.display.observability import (
    ObservabilityConfig,
    ProgressEmitter,
)
from obra.hybrid.handlers.execute._file_tracker import ExecutionFileTracker
from obra.hybrid.handlers.execute._recovery import ExecutionRecovery
from obra.hybrid.handlers.execute._verification import ExecutionVerifier
from obra.hybrid.handlers.execute_decomposition import (
    resolve_execute_decomposition_policy,
)
from obra.hybrid.handlers.execute_monitoring import (
    FileChangeTracker,
    HeartbeatThread,
    _MonitoringEventAdapter,
)
from obra.llm.interactive_guard import (
    extract_interactive_failure,
    sanitize_interactive_line,
)
from obra.messages import get_message
from obra.monitoring.hang_investigator import HangClassification, HangInvestigator
from obra.monitoring.liveness_monitor import LivenessMonitor, LivenessStatus
from obra.observability.production_logger import get_production_logger
from obra.prompts.fragments.recovery import (
    build_interactive_recovery_banner,
    build_zero_output_recovery_banner,
)
from obra.simulation_controls import (
    consume_adaptive_decomposition_execution_failure,
    get_adaptive_decomposition_execute_duration_control,
)
from obra.utils.workspace_rollback import WorkspaceRollbackStore

logger = logging.getLogger(__name__)

# Type alias for streaming callback
StreamCallback = Callable[[str, str], None] | None


@dataclass
class ExecuteConfigContext:
    """Resolved execute-time config forwarded to the subprocess runner."""

    provider: str
    model: str
    reasoning_level: str
    auth_method: str
    skip_git_check: bool
    bypass_sandbox: bool
    approval_mode: str | None


@dataclass
class ExecuteRuntimeContext:
    """Bootstrap state shared across retries within one deploy call."""

    config: ExecuteConfigContext
    start_head: str | None
    decomposition_policy: Any
    decomposition_enabled: bool
    duration_threshold_s: float
    warning_threshold_s: float
    summary_max_chars: int
    forced_warning_after_s: float | None
    forced_trigger_after_s: float | None
    watchdog_poll_s: float
    decomposition_task_id: str
    cancellation_event: threading.Event
    watchdog_stop_event: threading.Event
    liveness_monitor: LivenessMonitor | None
    liveness_config: dict[str, Any] | None
    decomposition_logger: Any | None
    item_id: str
    rollback_enabled: bool
    rollback_codes: list[str]
    retry_max: int
    rollback_store: WorkspaceRollbackStore | None
    rollback_snapshot: Any | None


@dataclass
class ExecuteMonitoringHandles:
    """Runtime-owned monitoring resources that require explicit teardown."""

    heartbeat_thread: HeartbeatThread | None = None
    heartbeat_stop_event: threading.Event | None = None
    watchdog_thread: threading.Thread | None = None


@dataclass
class ExecuteLoopState:
    """Mutable retry state for one deploy loop."""

    current_prompt: str
    attempt: int
    retry_max: int
    zero_output_attempt: int
    zero_output_retry_max: int


class AgentExecutor:
    """Orchestrates LLM subprocess deployment for the execute handler.

    Encapsulates the full subprocess lifecycle: config resolution, invocation,
    retry loop, heartbeat threading, watchdog/liveness monitoring, zero-output
    validation, deliverable validation, interactive guard, and rollback.

    All dependencies are injected via the constructor — no back-references
    to ExecuteHandler are needed.
    """

    def __init__(
        self,
        *,
        llm_config: dict[str, str],
        working_dir: Path,
        session_id: str | None,
        log_file: Path | None,
        trace_id: str | None,
        log_event: Any | None,
        parent_span_id: str | None,
        observability_config: ObservabilityConfig | None,
        progress_emitter: ProgressEmitter | None,
        on_stream: StreamCallback,
        process_registry: Any | None,
        monitoring_context: dict[str, Any] | None,
        file_tracker: ExecutionFileTracker,
        verifier: ExecutionVerifier,
        recovery: ExecutionRecovery,
        handler: Any,
    ) -> None:
        self._llm_config = llm_config
        self._working_dir = working_dir
        self._session_id = session_id
        self._log_file = log_file
        self._trace_id = trace_id
        self._log_event = log_event
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._on_stream = on_stream
        self._process_registry = process_registry
        self._monitoring_context = monitoring_context
        self._file_tracker = file_tracker
        self._verifier = verifier
        self._recovery = recovery
        self._handler = handler  # needed by HeartbeatThread (ExecuteHandlerProtocol)
        self._execution_start_time: float | None = None

    def deploy(self, prompt: str, request: ExecutionRequest) -> dict[str, Any]:
        """Deploy implementation agent via subprocess."""
        from obra.llm.subprocess_runner import run_llm_subprocess

        logger.debug("Deploying implementation agent")
        runtime = self._prepare_runtime_context(request)
        monitoring = self._start_runtime_monitors(runtime)

        try:
            stream_adapter = self._build_stream_adapter()
            loop_state = ExecuteLoopState(
                current_prompt=prompt,
                attempt=0,
                retry_max=runtime.retry_max,
                zero_output_attempt=0,
                zero_output_retry_max=get_execute_zero_output_retry_max(),
            )
            while True:
                scripted_failure = self._build_scripted_failure_result()
                if scripted_failure is not None:
                    return scripted_failure

                result = run_llm_subprocess(
                    self._build_subprocess_config(
                        runtime,
                        loop_state.current_prompt,
                        stream_adapter,
                    )
                )
                duration_partial = self._maybe_build_duration_partial_result(runtime, result)
                if duration_partial is not None:
                    return duration_partial
                if result.success:
                    success_result = self._evaluate_success_result(
                        runtime,
                        prompt,
                        loop_state,
                    )
                    if success_result is not None:
                        return success_result
                    continue

                failure_result = self._evaluate_failure_result(
                    runtime,
                    prompt,
                    result,
                    loop_state,
                )
                if failure_result is not None:
                    return failure_result

        except Exception as e:
            logger.exception(f"Agent deployment failed: {e}")
            return {
                "status": ExecutionStatus.FAILURE.value,
                "summary": f"Deployment failed: {e!s}",
                "files_changed": 0,
                "failure_class": "deployment_failed",
            }
        finally:
            self._stop_runtime_monitors(runtime, monitoring)
            self._execution_start_time = None

    def _prepare_runtime_context(self, request: ExecutionRequest) -> ExecuteRuntimeContext:
        """Resolve bootstrap state that must survive the entire deploy loop."""
        start_head = self._recovery.get_head_sha()
        self._execution_start_time = time.monotonic()
        decomposition_policy = resolve_execute_decomposition_policy()
        forced_warning_after_s, forced_trigger_after_s = self._resolve_simulation_thresholds()
        duration_threshold_s = decomposition_policy.duration_threshold_s
        warning_threshold_s = decomposition_policy.warning_threshold_s
        liveness_monitor, liveness_config = self._build_liveness_monitor(
            request,
            decomposition_policy.enabled,
        )
        rollback_enabled = get_interactive_guard_rollback_enabled()
        rollback_store, rollback_snapshot = self._build_rollback_context(rollback_enabled)
        return ExecuteRuntimeContext(
            config=self._resolve_execute_config(),
            start_head=start_head,
            decomposition_policy=decomposition_policy,
            decomposition_enabled=decomposition_policy.enabled,
            duration_threshold_s=duration_threshold_s,
            warning_threshold_s=warning_threshold_s,
            summary_max_chars=decomposition_policy.summary_max_chars,
            forced_warning_after_s=forced_warning_after_s,
            forced_trigger_after_s=forced_trigger_after_s,
            watchdog_poll_s=self._resolve_watchdog_poll_s(
                forced_warning_after_s,
                forced_trigger_after_s,
                warning_threshold_s,
                duration_threshold_s,
            ),
            decomposition_task_id=self._resolve_decomposition_task_id(request),
            cancellation_event=threading.Event(),
            watchdog_stop_event=threading.Event(),
            liveness_monitor=liveness_monitor,
            liveness_config=liveness_config,
            decomposition_logger=self._build_decomposition_logger(decomposition_policy.enabled),
            item_id=str((request.current_item or {}).get("id", "unknown")),
            rollback_enabled=rollback_enabled,
            rollback_codes=get_interactive_guard_rollback_codes(),
            retry_max=max(0, get_interactive_guard_retry_max()),
            rollback_store=rollback_store,
            rollback_snapshot=rollback_snapshot,
        )

    def _resolve_simulation_thresholds(self) -> tuple[float | None, float | None]:
        """Resolve optional simulation-only decomposition thresholds."""
        simulation_duration_control = get_adaptive_decomposition_execute_duration_control()
        forced_trigger_after_s = simulation_duration_control.get("trigger_after_s")
        if forced_trigger_after_s is not None:
            forced_trigger_after_s = float(forced_trigger_after_s)
        forced_warning_after_s = simulation_duration_control.get("warning_after_s")
        if forced_warning_after_s is not None:
            forced_warning_after_s = float(forced_warning_after_s)
        return forced_warning_after_s, forced_trigger_after_s

    def _resolve_execute_config(self) -> ExecuteConfigContext:
        """Resolve the execute-mode provider/model/auth bootstrap contract."""
        bypass_sandbox = False
        approval_mode: str | None = None
        from obra.config.llm import DEFAULT_REASONING_LEVEL

        if self._llm_config:
            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            reasoning_level = self._llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")
            if provider == "openai":
                git_config: dict[str, Any] = cast(dict, self._llm_config.get("git", {}))
                skip_git_check = git_config.get("skip_check", True)
                codex_config: dict[str, Any] = cast(dict, self._llm_config.get("codex", {}))
                bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
                approval_mode = codex_config.get("approval_mode")
            else:
                skip_git_check = False
        else:
            provider = "anthropic"
            model = "default"
            reasoning_level = DEFAULT_REASONING_LEVEL
            auth_method = "oauth"
            skip_git_check = False

        return ExecuteConfigContext(
            provider=provider,
            model=model,
            reasoning_level=reasoning_level,
            auth_method=auth_method,
            skip_git_check=skip_git_check,
            bypass_sandbox=bypass_sandbox,
            approval_mode=approval_mode,
        )

    @staticmethod
    def _resolve_watchdog_poll_s(
        forced_warning_after_s: float | None,
        forced_trigger_after_s: float | None,
        warning_threshold_s: float,
        duration_threshold_s: float,
    ) -> float:
        """Pick a watchdog poll interval based on the earliest active threshold."""
        watchdog_poll_s = 30.0
        watchdog_thresholds = [
            threshold
            for threshold in (
                forced_warning_after_s,
                forced_trigger_after_s,
                warning_threshold_s,
                duration_threshold_s,
            )
            if threshold is not None and threshold > 0
        ]
        if watchdog_thresholds:
            smallest_threshold_s = min(watchdog_thresholds)
            watchdog_poll_s = min(30.0, max(0.05, smallest_threshold_s / 5.0))
        return watchdog_poll_s

    @staticmethod
    def _resolve_decomposition_task_id(request: ExecutionRequest) -> str:
        """Resolve the task id used in decomposition telemetry."""
        if request.current_item:
            return str(request.current_item.get("id", "execution"))
        return "execution"

    def _build_decomposition_logger(self, decomposition_enabled: bool) -> Any | None:
        """Build the production logger used by execute decomposition."""
        if not decomposition_enabled:
            return None
        try:
            return get_production_logger(session_id=self._session_id)
        except Exception as exc:
            logger.debug("Failed to init production logger for decomposition: %s", exc)
            return None

    def _build_liveness_monitor(
        self,
        request: ExecutionRequest,
        decomposition_enabled: bool,
    ) -> tuple[LivenessMonitor | None, dict[str, Any] | None]:
        """Build the liveness monitor used by duration-triggered decomposition."""
        if not decomposition_enabled:
            return None, None
        try:
            liveness_config, _, _ = load_layered_config(include_defaults=True)
        except Exception as exc:
            logger.debug("Failed to load liveness config: %s", exc)
            return None, None
        if not liveness_config:
            return None, None

        task_seed = "0"
        if request.current_item:
            task_seed = str(request.current_item.get("id", "0"))
        task_id = abs(hash(f"{self._session_id}:{task_seed}")) % 1_000_000
        liveness_monitor = LivenessMonitor(
            task_id=task_id,
            config=liveness_config,
            workspace_path=self._working_dir,
            production_logger=self._resolve_monitoring_production_logger(),
            log_path=self._log_file,
            state_manager=None,
            process_pid=None,
        )
        liveness_monitor.capture_baseline()
        return liveness_monitor, liveness_config

    def _resolve_monitoring_production_logger(self) -> Any:
        """Resolve the production logger used by monitoring helpers."""
        if self._monitoring_context:
            production_logger = self._monitoring_context.get("production_logger")
            if production_logger is not None:
                return production_logger
        return _MonitoringEventAdapter(self._log_event)

    def _build_rollback_context(
        self,
        rollback_enabled: bool,
    ) -> tuple[WorkspaceRollbackStore | None, Any | None]:
        """Capture rollback state for interactive guard recovery."""
        if not rollback_enabled:
            return None, None
        rollback_store = WorkspaceRollbackStore(
            self._working_dir,
            run_id=self._session_id or "execute",
        )
        return rollback_store, rollback_store.capture()

    def _start_runtime_monitors(
        self,
        runtime: ExecuteRuntimeContext,
    ) -> ExecuteMonitoringHandles:
        """Start heartbeat and watchdog resources for the current deploy."""
        handles = ExecuteMonitoringHandles()
        if self._progress_emitter and self._observability_config:
            base_interval = get_heartbeat_interval()
            verbosity = self._observability_config.verbosity
            inline_heartbeat = False
            if hasattr(self._progress_emitter, "use_inline_heartbeat"):
                inline_heartbeat = bool(self._progress_emitter.use_inline_heartbeat())
            if verbosity == 0:
                scaled_interval = base_interval * 3
            elif verbosity == 1:
                scaled_interval = 1 if inline_heartbeat else base_interval
            else:
                scaled_interval = int(base_interval * 0.5)
            initial_delay = get_heartbeat_initial_delay()
            handles.heartbeat_stop_event = threading.Event()
            handles.heartbeat_thread = HeartbeatThread(
                item_id=runtime.item_id,
                emitter=self._progress_emitter,
                file_tracker=FileChangeTracker(self._handler),
                handler=self._handler,
                interval=scaled_interval,
                initial_delay=initial_delay,
                stop_event=handles.heartbeat_stop_event,
                log_event=self._log_event,
                session_id=self._session_id,
                trace_id=self._trace_id,
            )
            handles.heartbeat_thread.start()
            logger.debug(
                "Started heartbeat thread: interval=%ss, initial_delay=%ss, verbosity=%s",
                scaled_interval,
                initial_delay,
                verbosity,
            )

        if runtime.decomposition_enabled and runtime.duration_threshold_s > 0:
            handles.watchdog_thread = threading.Thread(
                target=self._duration_watchdog,
                args=(
                    runtime.watchdog_stop_event,
                    runtime.cancellation_event,
                    runtime.watchdog_poll_s,
                    runtime.forced_warning_after_s,
                    runtime.forced_trigger_after_s,
                    runtime.warning_threshold_s,
                    runtime.duration_threshold_s,
                    runtime.decomposition_task_id,
                    runtime.decomposition_logger,
                    runtime.liveness_monitor,
                    runtime.liveness_config,
                ),
                daemon=True,
                name="decomposition-watchdog",
            )
            handles.watchdog_thread.start()
        return handles

    def _stop_runtime_monitors(
        self,
        runtime: ExecuteRuntimeContext,
        monitoring: ExecuteMonitoringHandles,
    ) -> None:
        """Stop heartbeat and watchdog resources created by deploy()."""
        if monitoring.heartbeat_thread and monitoring.heartbeat_stop_event:
            logger.debug("Stopping heartbeat thread")
            monitoring.heartbeat_thread.stop()
        if monitoring.watchdog_thread:
            runtime.watchdog_stop_event.set()
            monitoring.watchdog_thread.join(timeout=2)

    def _build_scripted_failure_result(self) -> dict[str, Any] | None:
        """Return a scripted failure payload when simulation controls request one."""
        scripted_failure = consume_adaptive_decomposition_execution_failure()
        if scripted_failure is None:
            return None
        failure_summary = str(scripted_failure.get("summary", "") or "").strip()
        failure_class = str(
            scripted_failure.get("failure_class", "deployment_failed") or ""
        ).strip()
        failure_reason_code = str(
            scripted_failure.get("failure_reason_code", failure_class) or ""
        ).strip()
        return {
            "status": ExecutionStatus.FAILURE.value,
            "summary": failure_summary or "Simulated execution failure.",
            "error": failure_summary or "Simulated execution failure.",
            "files_changed": 0,
            "failure_class": failure_class or "deployment_failed",
            "failure_reason_code": failure_reason_code or "deployment_failed",
        }

    def _build_subprocess_config(
        self,
        runtime: ExecuteRuntimeContext,
        current_prompt: str,
        stream_adapter: Callable[[str], None],
    ) -> Any:
        """Build the shared subprocess-runner config for one execute attempt."""
        from obra.llm.subprocess_runner import LLMSubprocessConfig

        return LLMSubprocessConfig(
            prompt=current_prompt,
            cwd=self._working_dir,
            provider=runtime.config.provider,
            model=runtime.config.model,
            reasoning_level=runtime.config.reasoning_level,
            auth_method=runtime.config.auth_method,
            timeout_s=get_agent_execution_timeout(),
            skip_git_check=runtime.config.skip_git_check,
            bypass_sandbox=runtime.config.bypass_sandbox,
            approval_mode=runtime.config.approval_mode,
            retry_enabled=True,
            streaming=True,
            stream_idle_timeout_s=runtime.decomposition_policy.execute_stream_idle_s,
            on_stream=stream_adapter if self._on_stream else None,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            call_site="execute",
            monitoring_context=self._monitoring_context,
            session_id=self._session_id,
            run_id=self._session_id,
            process_registry=self._process_registry,
            mode="execute",
            cancellation_event=(
                runtime.cancellation_event if runtime.decomposition_enabled else None
            ),
        )

    def _maybe_build_duration_partial_result(
        self,
        runtime: ExecuteRuntimeContext,
        result: Any,
    ) -> dict[str, Any] | None:
        """Return the partial-work payload when duration decomposition fires."""
        forced_duration_triggered = False
        if (
            runtime.decomposition_enabled
            and runtime.forced_trigger_after_s is not None
            and runtime.forced_trigger_after_s > 0
            and self._execution_start_time is not None
        ):
            elapsed = time.monotonic() - self._execution_start_time
            if elapsed >= runtime.forced_trigger_after_s:
                runtime.cancellation_event.set()
                forced_duration_triggered = True

        if forced_duration_triggered or result.cancelled or (
            runtime.decomposition_enabled and runtime.cancellation_event.is_set()
        ):
            return self._build_duration_partial_result(
                runtime.decomposition_logger,
                runtime.decomposition_task_id,
                runtime.duration_threshold_s,
                runtime.summary_max_chars,
            )
        return None

    def _evaluate_success_result(
        self,
        runtime: ExecuteRuntimeContext,
        prompt: str,
        loop_state: ExecuteLoopState,
    ) -> dict[str, Any] | None:
        """Evaluate a successful subprocess attempt and decide whether to retry."""
        files_changed = self._file_tracker.count_file_changes()
        if files_changed == 0:
            current_head = self._recovery.get_head_sha()
            if runtime.start_head and current_head and current_head != runtime.start_head:
                logger.debug(
                    "Git operation detected: HEAD changed from %s to %s",
                    runtime.start_head[:8],
                    current_head[:8],
                )
                self._file_tracker.update_task_baseline()
                return {
                    "status": ExecutionStatus.SUCCESS.value,
                    "summary": "Task executed successfully (repository updated)",
                    "files_changed": 0,
                }

            if ExecutionRecovery.is_infrastructure_task(runtime.item_id):
                logger.info(
                    "Infrastructure task %s produced only .obra/ artifacts (expected behavior for intent reconciliation tasks)",
                    runtime.item_id,
                )
                self._file_tracker.update_task_baseline()
                return {
                    "status": ExecutionStatus.SUCCESS.value,
                    "summary": "Infrastructure task completed (artifacts updated)",
                    "files_changed": 0,
                }

            if loop_state.zero_output_attempt < loop_state.zero_output_retry_max:
                loop_state.zero_output_attempt += 1
                logger.warning(
                    "Zero-output detected: retrying with augmented prompt (%d/%d). working_dir=%s",
                    loop_state.zero_output_attempt,
                    loop_state.zero_output_retry_max,
                    self._working_dir,
                )
                if self._log_event:
                    self._log_event(
                        "zero_output_retry",
                        attempt=loop_state.zero_output_attempt,
                        retry_max=loop_state.zero_output_retry_max,
                        working_dir=str(self._working_dir),
                        item_id=runtime.item_id,
                        session_id=self._session_id,
                        trace_id=self._trace_id,
                        message=(
                            f"Zero-output retry ({loop_state.zero_output_attempt}/{loop_state.zero_output_retry_max})"
                        ),
                    )
                if self._progress_emitter:
                    self._progress_emitter.warning(
                        f"No files written — retrying ({loop_state.zero_output_attempt}/{loop_state.zero_output_retry_max})"
                    )
                recovery_banner = build_zero_output_recovery_banner(str(self._working_dir))
                loop_state.current_prompt = f"{recovery_banner}\n\n{prompt}"
                return None

            logger.warning(
                "Zero-output detected: LLM exited successfully but no files changed. working_dir=%s",
                self._working_dir,
            )
            return {
                "status": ExecutionStatus.FAILURE.value,
                "summary": (
                    "Execution completed but no files were written to the target directory. "
                    "Likely causes: (1) Working directory not writable or path mismatch, "
                    "(2) LLM decided no changes were needed (check review findings), "
                    f"(3) Provider CLI misconfigured ({get_message('recovery.config.doctor')}), "
                    "(4) Task prompt too vague for actionable output. "
                    "Check provider CLI logs and retry with more specific instructions."
                ),
                "files_changed": 0,
                "failure_class": "zero_output",
            }

        changed_files = self._file_tracker.get_file_changes()
        all_changed = changed_files.added | changed_files.modified
        valid_files, validation_warnings = self._verifier.validate_deliverables(all_changed)
        for warning in validation_warnings:
            logger.warning("Deliverable validation: %s", warning)

        if len(valid_files) == 0 and len(all_changed) > 0:
            logger.warning(
                "Deliverable validation failed: %d files changed but none passed validation. working_dir=%s",
                len(all_changed),
                self._working_dir,
            )
            return {
                "status": ExecutionStatus.FAILURE.value,
                "summary": (
                    f"Execution created {len(all_changed)} file(s) but none are valid deliverables. "
                    + "; ".join(validation_warnings)
                    + " Check .obra/config.yaml validation settings if this is unexpected."
                ),
                "files_changed": 0,
                "failure_class": "invalid_deliverables",
            }

        self._file_tracker.update_task_baseline()
        return {
            "status": ExecutionStatus.SUCCESS.value,
            "summary": "Task executed successfully",
            "files_changed": len(valid_files),
        }

    def _evaluate_failure_result(
        self,
        runtime: ExecuteRuntimeContext,
        prompt: str,
        result: Any,
        loop_state: ExecuteLoopState,
    ) -> dict[str, Any] | None:
        """Evaluate a failed subprocess attempt and decide whether to retry."""
        error_message = result.error or "Unknown error"
        if result.failure_class and "failure_class=" not in error_message:
            error_message = f"{error_message} (failure_class={result.failure_class})"
        if result.error_details and result.error_details.request_id:
            if "request_id=" not in error_message:
                error_message = (
                    f"{error_message} (request_id={result.error_details.request_id})"
                )
        if result.retry_count and "retries=" not in error_message:
            error_message = f"{error_message} (retries={result.retry_count})"

        matched_code, matched_line = self._recovery.match_rollback_code(
            error_message,
            runtime.rollback_codes,
        )
        interactive_failure = result.interactive_failure
        if not interactive_failure:
            interactive_failure = extract_interactive_failure(error_message, None)
        sanitized_line = sanitize_interactive_line(
            interactive_failure.line if interactive_failure else None
        )

        if interactive_failure:
            message = "Interactive guard blocked an interactive prompt."
            if sanitized_line:
                message = f"{message} ({sanitized_line.line})"
            if self._log_event:
                self._log_event(
                    "interactive_guard_triggered",
                    code=interactive_failure.code,
                    pattern_id=interactive_failure.pattern_id,
                    matched_line=sanitized_line.line if sanitized_line else "",
                    line_redacted=(sanitized_line.redacted if sanitized_line else False),
                    line_truncated=(sanitized_line.truncated if sanitized_line else False),
                    source=interactive_failure.source,
                    handler="execute",
                    attempt=loop_state.attempt,
                    attempt_number=loop_state.attempt + 1,
                    retry_max=runtime.retry_max,
                    rollback_enabled=runtime.rollback_enabled,
                    rollback_code_matched=bool(matched_code),
                    will_retry=bool(
                        matched_code
                        and runtime.rollback_enabled
                        and loop_state.attempt < runtime.retry_max
                    ),
                    message=message,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                )
            logger.warning(
                "Interactive guard triggered in execute: code=%s attempt=%d/%d line=%s",
                interactive_failure.code,
                loop_state.attempt,
                runtime.retry_max,
                sanitized_line.line if sanitized_line else "",
            )
            if self._progress_emitter:
                self._progress_emitter.interactive_guard_notice(message)

        if (
            runtime.rollback_enabled
            and runtime.rollback_store
            and runtime.rollback_snapshot
            and matched_code
        ):
            runtime.rollback_store.restore(runtime.rollback_snapshot)
            if self._log_event:
                changes = runtime.rollback_snapshot.changes
                self._log_event(
                    "interactive_guard_rollback",
                    code=matched_code,
                    pattern_id=(interactive_failure.pattern_id if interactive_failure else None),
                    matched_line=sanitized_line.line if sanitized_line else "",
                    line_redacted=(sanitized_line.redacted if sanitized_line else False),
                    line_truncated=(sanitized_line.truncated if sanitized_line else False),
                    source=(interactive_failure.source if interactive_failure else None),
                    handler="execute",
                    attempt=loop_state.attempt,
                    attempt_number=loop_state.attempt + 1,
                    retry_max=runtime.retry_max,
                    added_count=len(changes.added) if changes else 0,
                    modified_count=len(changes.modified) if changes else 0,
                    deleted_count=len(changes.deleted) if changes else 0,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                    message="Workspace rolled back after interactive prompt.",
                )
            if self._progress_emitter:
                self._progress_emitter.interactive_guard_notice(
                    "Interactive guard triggered; workspace rolled back."
                )
            if loop_state.attempt < runtime.retry_max:
                recovery_banner = build_interactive_recovery_banner(
                    interactive_failure.line if interactive_failure else matched_line
                )
                loop_state.current_prompt = f"{recovery_banner}\n\n{prompt}"
                if self._log_event:
                    self._log_event(
                        "interactive_guard_retry",
                        code=matched_code,
                        pattern_id=(interactive_failure.pattern_id if interactive_failure else None),
                        matched_line=(sanitized_line.line if sanitized_line else ""),
                        line_redacted=(sanitized_line.redacted if sanitized_line else False),
                        line_truncated=(sanitized_line.truncated if sanitized_line else False),
                        source=(interactive_failure.source if interactive_failure else None),
                        handler="execute",
                        attempt=loop_state.attempt + 1,
                        attempt_number=loop_state.attempt + 2,
                        retry_max=runtime.retry_max,
                        session_id=self._session_id,
                        trace_id=self._trace_id,
                        message=f"Retrying after interactive guard ({loop_state.attempt + 1}/{runtime.retry_max}).",
                    )
                if self._progress_emitter:
                    self._progress_emitter.interactive_guard_notice(
                        f"Retrying after interactive guard ({loop_state.attempt + 1}/{runtime.retry_max})."
                    )
                loop_state.attempt += 1
                return None

        failure_payload: dict[str, Any] = {
            "status": ExecutionStatus.FAILURE.value,
            "summary": f"Execution failed: {error_message}",
            "files_changed": 0,
            "error": result.error or "Unknown error",
            "failure_class": result.failure_class or "execution_failed",
            "retry_count": int(result.retry_count or 0),
        }
        if result.error_details and result.error_details.request_id:
            failure_payload["request_id"] = result.error_details.request_id
        return failure_payload

    def _build_stream_adapter(self) -> Callable[[str], None]:
        """Build a stream adapter that bridges subprocess output to on_stream callback."""
        def stream_adapter(line: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", line.rstrip("\n"))
        return stream_adapter

    def _investigate_liveness(
        self,
        liveness_config: dict[str, Any] | None,
    ) -> bool:
        """Investigate whether the agent process is actually hung."""
        if not liveness_config:
            return False
        if not self._process_registry:
            return False
        tracked = self._process_registry.tracked_pids
        if not tracked:
            return False
        pid = tracked[-1]
        production_logger = None
        if self._monitoring_context:
            production_logger = self._monitoring_context.get("production_logger")
        if production_logger is None:
            production_logger = _MonitoringEventAdapter(self._log_event)
        investigator = HangInvestigator(
            pid=pid,
            config=liveness_config,
            workspace_path=self._working_dir,
            production_logger=production_logger,
            task_id=abs(hash(f"{self._session_id}:{pid}")) % 1_000_000,
        )
        evidence = investigator.investigate(session_id=self._session_id)
        return evidence.classification != HangClassification.REAL_HANG

    def _liveness_allows_decomposition(
        self,
        liveness_monitor: LivenessMonitor | None,
        liveness_config: dict[str, Any] | None,
    ) -> bool:
        """Check whether liveness status permits decomposition."""
        status: LivenessStatus | None = None
        investigation_not_hung: bool | None = None
        if self._monitoring_context:
            monitor_thread = self._monitoring_context.get("monitor_thread")
            if monitor_thread is not None and hasattr(
                monitor_thread, "get_last_liveness_status"
            ):
                status = monitor_thread.get_last_liveness_status()
                investigation_not_hung = monitor_thread.get_last_investigation_not_hung()
        if status is None and liveness_monitor:
            status = liveness_monitor.check_liveness(session_id=self._session_id)
            if status == LivenessStatus.INVESTIGATE:
                investigation_not_hung = self._investigate_liveness(liveness_config)

        if status == LivenessStatus.ALIVE:
            return True
        if status == LivenessStatus.INVESTIGATE and investigation_not_hung:
            return True
        return False

    def _duration_watchdog(
        self,
        watchdog_stop_event: threading.Event,
        cancellation_event: threading.Event,
        watchdog_poll_s: float,
        forced_warning_after_s: float | None,
        forced_trigger_after_s: float | None,
        warning_threshold_s: float,
        duration_threshold_s: float,
        decomposition_task_id: str,
        decomposition_logger: Any | None,
        liveness_monitor: LivenessMonitor | None,
        liveness_config: dict[str, Any] | None,
    ) -> None:
        """Watchdog thread target that monitors execution duration."""
        warning_emitted = False
        while not watchdog_stop_event.is_set() and not cancellation_event.is_set():
            if watchdog_stop_event.wait(timeout=watchdog_poll_s):
                break
            if self._execution_start_time is None:
                continue
            elapsed = time.monotonic() - self._execution_start_time
            if (
                not warning_emitted
                and (
                    (
                        forced_warning_after_s is not None
                        and forced_warning_after_s >= 0
                        and elapsed >= forced_warning_after_s
                    )
                    or (
                        warning_threshold_s > 0
                        and elapsed >= warning_threshold_s
                    )
                )
            ):
                warning_emitted = True
                if self._progress_emitter:
                    self._progress_emitter.decomposition_warning(
                        int(elapsed),
                        warning_threshold_s,
                        duration_threshold_s,
                    )
                if decomposition_logger:
                    decomposition_logger.log_decomposition_warning(
                        task_id=decomposition_task_id,
                        elapsed_s=int(elapsed),
                        threshold_s=warning_threshold_s,
                    )
            if (
                forced_trigger_after_s is not None
                and forced_trigger_after_s > 0
                and elapsed >= forced_trigger_after_s
            ):
                if self._progress_emitter:
                    self._progress_emitter.decomposition_triggered()
                if decomposition_logger:
                    decomposition_logger.log_decomposition_triggered(
                        task_id=decomposition_task_id,
                        elapsed_s=int(elapsed),
                        threshold_s=duration_threshold_s,
                    )
                cancellation_event.set()
                break
            if duration_threshold_s > 0 and elapsed >= duration_threshold_s:
                if self._liveness_allows_decomposition(liveness_monitor, liveness_config):
                    if self._progress_emitter:
                        self._progress_emitter.decomposition_triggered()
                    if decomposition_logger:
                        decomposition_logger.log_decomposition_triggered(
                            task_id=decomposition_task_id,
                            elapsed_s=int(elapsed),
                            threshold_s=duration_threshold_s,
                        )
                    cancellation_event.set()
                break

    def _build_duration_partial_result(
        self,
        decomposition_logger: Any | None,
        decomposition_task_id: str,
        duration_threshold_s: float,
        summary_max_chars: int,
    ) -> dict[str, Any]:
        """Build a partial result dict for duration-threshold decomposition."""
        if decomposition_logger:
            elapsed = 0
            if self._execution_start_time is not None:
                elapsed = int(time.monotonic() - self._execution_start_time)
            decomposition_logger.log_decomposition_complete(
                task_id=decomposition_task_id,
                elapsed_s=elapsed,
                threshold_s=duration_threshold_s,
            )
        summary, files_changed = self._file_tracker.build_partial_work_summary(summary_max_chars)
        return {
            "status": ExecutionStatus.PARTIAL.value,
            "summary": "Execution cancelled after duration threshold",
            "files_changed": files_changed,
            "decomposition_suggested": True,
            "decomposition_reason": "duration_threshold",
            "partial_work_summary": summary,
        }
