"""Verification and deliverable validation for the execute handler.

Handles test discovery, test execution, and deliverable validation
(file size, extension checks) for executed tasks.
"""

import logging
import shlex
import subprocess
from pathlib import Path
from typing import Any

from obra.config import get_llm_api_timeout
from obra.validation.verification_tools import resolve_verification_tools

logger = logging.getLogger(__name__)


class ExecutionVerifier:
    """Verify execution results via tests and deliverable validation.

    Args:
        working_dir: Working directory for file access
        llm_config: LLM configuration dict (needed by ToolingDiscovery)
    """

    def __init__(self, working_dir: Path, llm_config: dict[str, str]) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config

    def run_tests(self) -> tuple[bool, int]:
        """Run project tests.

        Returns:
            Tuple of (tests_passed, test_count)
        """
        from obra.config.loaders import (
            get_verification_discovery_enabled,
            get_verification_force_refresh,
            load_layered_config,
        )
        from obra.hybrid.tooling_discovery import ToolingDiscovery

        test_command = None
        try:
            config, _, _ = load_layered_config(include_defaults=True)
            tools = config.get("fix", {}).get("verification", {}).get("tools", [])
            if isinstance(tools, list):
                for tool in tools:
                    if isinstance(tool, dict) and tool.get("category") == "tests":
                        test_command = tool.get("command")
                        break
        except Exception as exc:
            logger.debug(f"Failed to load verification tools config: {exc}")

        if not test_command and get_verification_discovery_enabled():
            discovery = ToolingDiscovery(self._working_dir, self._llm_config)
            tooling = discovery.discover(force_refresh=get_verification_force_refresh())
            test_command = (
                tooling.get("verification", {}).get("test", {}).get("command")
                if isinstance(tooling, dict)
                else None
            )

        if not test_command:
            return True, 0

        try:
            formatted = test_command.format(files="", paths="")
            cmd = shlex.split(formatted)
        except ValueError as exc:
            logger.warning("Invalid test command format: %s", exc)
            return True, 0

        try:
            logger.debug(f"Running tests with command: {formatted}")
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                timeout=get_llm_api_timeout(),
                cwd=self._working_dir,
            )
            passed = result.returncode == 0
            output = result.stdout.decode("utf-8", errors="ignore")
            test_count = output.count("passed") + output.count("PASS")
            return passed, max(test_count, 1 if passed else 0)
        except subprocess.TimeoutExpired:
            logger.warning("Test timeout with command: %s", formatted)
        except FileNotFoundError:
            logger.warning("Test command not found: %s", formatted)
        except Exception as exc:
            logger.debug(f"Test runner failed: {exc}")

        # No tests found or run
        return True, 0  # Assume success if no tests

    def discover_verification_tools(self) -> dict[str, Any]:
        """Discover verification tools for server-side FIX enforcement.

        Returns:
            Dict with available tools, missing tools, and discovery source
        """
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            return resolve_verification_tools(
                self._working_dir,
                self._llm_config,
                config,
                prefer_existing=False,
            )
        except Exception as exc:
            logger.warning("Failed to discover verification tools: %s", exc)
            return {}

    def validate_deliverables(self, paths: set[str]) -> tuple[set[str], list[str]]:
        """Validate that paths contain meaningful deliverables.

        BUG-a377298b: Enhanced validation to catch silent failures.

        Args:
            paths: Set of file paths (already filtered for infrastructure)

        Returns:
            Tuple of (valid_paths, validation_warnings)
            - valid_paths: Files that pass all validation checks
            - validation_warnings: List of warning messages for failed checks
        """
        config = self._get_validation_config()
        min_size = config["min_file_size"]
        expected_extensions = config["expected_extensions"]

        valid_paths: set[str] = set()
        warnings: list[str] = []

        empty_files: list[str] = []
        wrong_extension_files: list[str] = []

        for path in paths:
            # Check meaningful content
            if not self._has_meaningful_content(path, min_size):
                empty_files.append(path)
                continue

            # Check expected extensions (if configured)
            if not self._matches_expected_extensions(path, expected_extensions):
                wrong_extension_files.append(path)
                continue

            valid_paths.add(path)

        # Build warnings
        if empty_files:
            warnings.append(
                f"{len(empty_files)} file(s) have no meaningful content (<{min_size} bytes): "
                f"{', '.join(empty_files[:3])}{'...' if len(empty_files) > 3 else ''}"
            )

        if wrong_extension_files and expected_extensions:
            warnings.append(
                f"{len(wrong_extension_files)} file(s) don't match expected extensions "
                f"{expected_extensions}: {', '.join(wrong_extension_files[:3])}"
                f"{'...' if len(wrong_extension_files) > 3 else ''}"
            )

        return valid_paths, warnings

    def _get_validation_config(self) -> dict[str, Any]:
        """Load deliverable validation config from .obra/config.yaml.

        Returns:
            Dict with validation settings:
                - min_file_size: Minimum bytes for meaningful content (default: 10)
                - expected_extensions: Optional list of expected file extensions
        """
        defaults = {
            "min_file_size": 10,
            "expected_extensions": None,  # None means any extension is valid
        }

        config_path = self._working_dir / ".obra" / "config.yaml"
        if not config_path.exists():
            return defaults

        try:
            import yaml

            with config_path.open(encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

            validation = config.get("validation", {})
            if not isinstance(validation, dict):
                return defaults

            return {
                "min_file_size": validation.get("min_file_size", defaults["min_file_size"]),
                "expected_extensions": validation.get("expected_extensions"),
            }
        except Exception as e:
            logger.debug(f"Failed to load validation config: {e}")
            return defaults

    def _has_meaningful_content(self, filepath: str, min_size: int = 10) -> bool:
        """Check if a file has meaningful content (not empty or trivially small).

        Args:
            filepath: Relative path to file from working directory
            min_size: Minimum file size in bytes to be considered meaningful

        Returns:
            True if file exists and has at least min_size bytes
        """
        try:
            file_path = self._working_dir / filepath
            if not file_path.exists() or not file_path.is_file():
                return False
            return file_path.stat().st_size >= min_size
        except Exception as e:
            logger.debug(f"Failed to check file size for {filepath}: {e}")
            return False

    def _matches_expected_extensions(
        self, filepath: str, expected_extensions: list[str] | None
    ) -> bool:
        """Check if file matches expected extensions (if configured).

        Args:
            filepath: File path to check
            expected_extensions: List of expected extensions (e.g., [".py", ".ts"])
                               If None, any extension is valid.

        Returns:
            True if no expected_extensions configured, or file matches one
        """
        if not expected_extensions:
            return True  # No restriction configured

        normalized = filepath.lower()
        return any(normalized.endswith(ext.lower()) for ext in expected_extensions)
