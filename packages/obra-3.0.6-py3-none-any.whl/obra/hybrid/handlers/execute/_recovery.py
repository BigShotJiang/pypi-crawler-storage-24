"""Recovery utilities for the execute handler.

Handles rollback code matching, git state capture, and infrastructure
task identification for the execution lifecycle.
"""

import logging
import subprocess
from pathlib import Path

from obra.config.loaders import get_timeout

logger = logging.getLogger(__name__)


class ExecutionRecovery:
    """Recovery and rollback utilities for execution.

    Args:
        working_dir: Working directory for git operations
    """

    def __init__(self, working_dir: Path) -> None:
        self._working_dir = working_dir

    def match_rollback_code(
        self,
        error_message: str,
        rollback_codes: list[str],
    ) -> tuple[str | None, str | None]:
        """Extract rollback code and matched line from error message."""
        for code in rollback_codes:
            if error_message.startswith(code):
                remainder = error_message[len(code) :].lstrip(": ").strip()
                if not remainder:
                    return code, ""
                parts = remainder.split(":", 1)
                if len(parts) == 2:
                    return code, parts[1].strip()
                return code, remainder.strip()
        return None, None

    def is_git_repository(self) -> bool:
        """Check if working directory is within a git repository.

        ISSUE-SAAS-049: Smart git detection following pattern from cli_runner.py.

        Returns:
            True if working directory is inside a git repository, False otherwise.
        """
        path = self._working_dir.resolve()
        if (path / ".git").exists():
            return True
        return any((parent / ".git").exists() for parent in path.parents)

    def get_head_sha(self) -> str | None:
        """Get current HEAD commit SHA.

        ISSUE-SAAS-050: Used to detect git operations that modify repository
        state without changing working tree files (e.g., git commit).

        Returns:
            The current HEAD commit SHA, or None if not a git repository
            or if an error occurs.
        """
        if not self.is_git_repository():
            return None
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self._working_dir,
                capture_output=True,
                text=True,
                timeout=int(get_timeout("handler", "subprocess_s")),
                check=False,
            )
            return result.stdout.strip() if result.returncode == 0 else None
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None
        except Exception as e:
            logger.debug(f"Failed to get HEAD SHA: {e}")
            return None

    @staticmethod
    def is_infrastructure_task(item_id: str) -> bool:
        """Check if task ID indicates an infrastructure-focused task.

        Infrastructure tasks are expected to only produce .obra/ artifacts
        (e.g., intent documents, reconciliation records) rather than
        code deliverables. They should be exempt from zero-output validation.

        Task ID prefixes:
            IR: Intent Reconciliation - documents intent changes

        Args:
            item_id: Task/item identifier (e.g., "IR1", "S1", "S1.T1")

        Returns:
            True if task is infrastructure-focused (should skip zero-output check)
        """
        if not item_id:
            return False

        # Infrastructure task prefixes
        infrastructure_prefixes = ("IR",)  # Intent Reconciliation

        # Check if item_id starts with any infrastructure prefix
        upper_id = item_id.upper()
        return any(upper_id.startswith(prefix) for prefix in infrastructure_prefixes)
