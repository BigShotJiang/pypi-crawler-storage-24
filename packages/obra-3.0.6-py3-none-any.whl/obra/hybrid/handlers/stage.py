"""Stage handler for custom pipeline stages.

This module handles the PIPELINE_STAGE action from the server. It executes
custom review agents at configurable trigger points in the orchestration flow.

The stage execution process:
    1. Receive PipelineStageRequest with stage config and content
    2. Resolve agent via AgentRegistry (built-in or plug-in)
    3. Prepare input based on input_type
    4. Execute agent with timeout
    5. Parse result for verdict and issues
    6. Return PipelineStageResult to server

Related:
    - docs/design/prds/DYNAMIC_PIPELINE_PRD.md
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
    - functions/src/pipeline/stage_executor.py
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.agents.base import BaseAgent
from obra.agents.registry import get_registry
from obra.api.protocol import AgentType, PipelineStageRequest, PipelineStageResult
from obra.hybrid.stage_runner_agent_adapter import BuiltinAgentStageRunner
from obra.hybrid.stage_runner_command import CommandStageRunner
from obra.hybrid.stage_runner_loader import register_configured_stage_runners
from obra.hybrid.stage_runner_registry import StageRunnerRegistry

logger = logging.getLogger(__name__)


class StageHandler:
    """Handler for PIPELINE_STAGE action.

    Executes custom pipeline stages by deploying configured runners at
    trigger points in the orchestration flow. Built-in review runners are
    registered on the canonical extension-runner path.

    Example:
        >>> handler = StageHandler(Path("/path/to/project"), llm_config=llm_config)
        >>> request = PipelineStageRequest(
        ...     stage_name="plan_validation",
        ...     trigger="after_derivation",
        ...     runner_id="sense_check",
        ...     input_type="derived_plan",
        ...     content={"plan_items": [...]},
        ...     iteration=0,
        ...     max_iterations=3,
        ...     timeout_s=300
        ... )
        >>> result = handler.handle(request)
        >>> print(result.verdict)  # "sound" or "issues"
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        domain: Any = None,
        log_event: Callable[..., None] | None = None,
        runner_registry: StageRunnerRegistry | None = None,
    ) -> None:
        """Initialize StageHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: Optional LLM configuration dict for agent analysis
            domain: Optional domain module for prompt/filter specialization
            log_event: Optional callback for logging stage events
        """
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._domain = domain
        self._log_event = log_event
        self._runner_registry = runner_registry or StageRunnerRegistry()
        self._runner_registry.register_runner_kind(
            "command_runner",
            lambda _request: CommandStageRunner(self._working_dir),
        )
        self._register_builtin_stage_runners()
        register_configured_stage_runners(self._runner_registry)
        logger.info("StageHandler initialized with StageRunnerRegistry")

    def handle(self, request: PipelineStageRequest) -> PipelineStageResult:
        """Handle PIPELINE_STAGE action.

        Resolves and executes the configured canonical stage runner.

        Args:
            request: PipelineStageRequest from server

        Returns:
            PipelineStageResult with canonical stage-runner fields

        Raises:
            ValueError: If agent resolution or input preparation fails
        """
        start_time = time.time()

        # Log stage start
        self._log_stage_event(
            "stage_start",
            stage_name=request.stage_name,
            trigger=request.trigger,
            runner_id=request.runner_id,
            runner_kind=request.runner_kind,
            iteration=request.iteration,
        )

        try:
            logger.info(
                "Executing stage runner '%s' (%s) for stage '%s' "
                "(execution_id=%s iteration %s/%s)",
                request.runner_id,
                request.runner_kind,
                request.stage_name,
                request.stage_execution_id,
                request.iteration,
                request.max_iterations,
            )

            runner = self._runner_registry.resolve(request)
            raw_result = runner.execute(request)
            if isinstance(raw_result, dict):
                result = PipelineStageResult.from_dict(raw_result)
            else:
                result = raw_result
            if not result.stage_name:
                result.stage_name = request.stage_name
            if not result.stage_execution_id:
                result.stage_execution_id = request.stage_execution_id
            result.iteration = request.iteration if result.iteration == 0 else result.iteration
            if not result.runner_id:
                result.runner_id = request.runner_id
            if not result.runner_version:
                result.runner_version = request.runner_version
            if not result.runner_selector:
                result.runner_selector = request.runner_selector

            issue_count = len(result.findings or result.issues)

            # Log stage complete
            self._log_stage_event(
                "stage_complete",
                stage_name=request.stage_name,
                runner_id=request.runner_id,
                execution_status=result.execution_status,
                outcome=result.outcome,
                verdict=result.verdict,
                issue_count=issue_count,
                stage_output_artifact_count=len(result.stage_output_artifacts),
                duration_s=result.duration_s or (time.time() - start_time),
            )

            return result

        except Exception as e:
            duration_s = time.time() - start_time
            logger.exception(f"Stage execution failed: {e}")

            # Log stage error
            self._log_stage_event(
                "stage_error",
                stage_name=request.stage_name,
                runner_id=request.runner_id,
                error=str(e),
            )

            # Re-raise to let orchestrator handle escalation
            raise

    def _resolve_agent(self, agent_name: str) -> BaseAgent:
        """Resolve agent by name via AgentRegistry.

        Attempts to resolve agent_name by:
        1. First trying built-in agents via AgentType lookup
        2. Then falling back to AgentRegistry for plug-in agents (future)

        Args:
            agent_name: Agent name or ID (e.g., "sense_check", "compliance-agent")

        Returns:
            BaseAgent instance ready for execution

        Raises:
            ValueError: If agent_name not found in registry
        """
        registry = get_registry()

        # Try to resolve as built-in agent via AgentType
        try:
            agent_type = AgentType(agent_name)
            logger.debug(f"Resolved '{agent_name}' as built-in agent: {agent_type}")

            # Use create_agent which handles lazy loading
            agent = registry.create_agent(
                agent_type,
                working_dir=self._working_dir,
                llm_config=self._llm_config,
                log_event=self._log_event,
                domain=self._domain,
            )

            if agent is None:
                msg = (
                    f"Failed to create agent '{agent_name}'. "
                    f"Available agents: {[a.value for a in AgentType]}"
                )
                raise ValueError(msg)

            logger.info(f"Resolved built-in agent '{agent_name}' to {agent.__class__.__name__}")
            return agent

        except ValueError as e:
            # Not a built-in agent, treat as plug-in ID
            logger.debug(f"'{agent_name}' is not a built-in agent, checking plug-in registry")

            # Note: Current AgentRegistry only supports AgentType enum agents
            # Plug-in agent support would require registry enhancements
            agent_class = registry.get_agent_by_name(agent_name)

            if agent_class is None:
                msg = (
                    f"Agent '{agent_name}' not found in registry. "
                    f"Available built-in agents: {[a.value for a in AgentType]}"
                )
                raise ValueError(msg) from e

            # Instantiate agent with working_dir and llm_config
            agent = agent_class(
                working_dir=self._working_dir,
                llm_config=self._llm_config,
                domain=self._domain,
            )

            logger.info(f"Resolved plug-in agent '{agent_name}' to {agent_class.__name__}")
            return agent

    def _register_builtin_stage_runners(self) -> None:
        """Register built-in review agents as canonical extension runners."""
        for agent_type in AgentType:
            runner_id = agent_type.value
            self._runner_registry.register_extension_runner(
                runner_id,
                lambda _request, runner_id=runner_id: BuiltinAgentStageRunner(
                    self._working_dir,
                    agent_factory=self._resolve_agent,
                    llm_config=self._llm_config,
                    domain=self._domain,
                    log_event=self._log_event,
                ),
            )

    def _prepare_input(self, input_type: str, content: dict[str, Any]) -> dict[str, Any]:
        """Prepare input for agent based on input_type.

        Transforms the raw content dict into the structure expected by the agent
        for the given input_type.

        Args:
            input_type: Type of input content
            content: Raw content from server

        Returns:
            Prepared input dict for agent.analyze()

        Raises:
            ValueError: If input_type is unknown
        """
        if input_type == "intent_document":
            return {
                "objective": content.get("objective"),
                "context": content.get("context"),
            }

        if input_type == "derived_plan":
            return {
                "plan_items": content.get("plan_items", []),
                "metadata": content.get("metadata", {}),
            }

        if input_type == "plan_step":
            return {
                "step_id": content.get("step_id"),
                "step_definition": content.get("definition"),
            }

        if input_type == "step_result":
            return {
                "step_id": content.get("step_id"),
                "result": content.get("result"),
                "files_changed": content.get("files_changed", []),
            }

        if input_type == "implementation":
            return {
                "files_changed": content.get("files_changed", []),
                "diffs": content.get("diffs", {}),
            }

        if input_type == "review_reports":
            return {
                "agent_reports": content.get("agent_reports", []),
            }

        msg = f"Unknown input_type: {input_type}"
        raise ValueError(msg)

    def _log_stage_event(self, event_type: str, **kwargs: Any) -> None:
        """Log stage event via callback if configured.

        Args:
            event_type: Event type (stage_start, stage_complete, stage_error)
            **kwargs: Event-specific data
        """
        if self._log_event is None:
            return

        event_data = {
            "event": event_type,
            **kwargs,
        }

        try:
            self._log_event(**event_data)
        except Exception as e:
            logger.warning(f"Failed to log stage event: {e}")
