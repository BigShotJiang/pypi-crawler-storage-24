"""Shell-level pass-policy coordination for FixHandler."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


class FixPassPolicy:
    """Owns shell-level pass-policy decisions still coordinated by FixHandler."""

    def __init__(
        self,
        *,
        attempt_tracker: Any,
        dispatcher: Any,
        display: Any,
        progress_emitter: Any | None,
        log_event: Any | None,
        trace_id: str | None,
        parent_span_id: str | None,
    ) -> None:
        self._attempt_tracker = attempt_tracker
        self._dispatcher = dispatcher
        self._display = display
        self._progress_emitter = progress_emitter
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id

    def apply_convergence_guard(
        self,
        issues: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Suppress issues that exceeded the convergence reapply limit."""
        convergence_skipped: list[dict[str, Any]] = []
        surviving_issues: list[dict[str, Any]] = []

        for issue in issues:
            self._attempt_tracker.record_cycle_application(issue)
            if self._attempt_tracker.should_suppress_convergence(issue):
                convergence_skipped.append(
                    self._attempt_tracker.build_convergence_skip(issue)
                )
            else:
                surviving_issues.append(issue)

        if convergence_skipped:
            logger.info(
                "Convergence guard suppressed %d/%d issues",
                len(convergence_skipped),
                len(issues),
            )
            self._display.print_convergence_warnings(
                convergence_skipped,
                self._attempt_tracker.get_cycle_reapply_counts(),
            )

        return surviving_issues, convergence_skipped

    @staticmethod
    def compute_force_individual(
        fix_history: str,
        *,
        split_on_retry_fn: Callable[[], bool],
    ) -> bool:
        """Disable batching on retry when configured to split retries."""
        return bool(fix_history) and split_on_retry_fn()

    def resolve_ordered_ids(
        self,
        execution_order: list[str] | None,
        issues: list[dict[str, Any]],
    ) -> list[str]:
        """Resolve issue execution order while keeping dispatcher ownership."""
        return execution_order or self._dispatcher.order_by_priority(issues)

    @staticmethod
    def handle_issue_result(
        issue_id: str | None,
        result: dict[str, Any],
        issue: dict[str, Any] | None,
        *,
        record_fix_failure_fn: Callable[[dict[str, Any]], None],
        emit_fix_result_line_fn: Callable[..., tuple[int, int, int]],
    ) -> tuple[int, int, int]:
        """Emit result accounting and record failure history when needed."""
        status = str(result.get("status", "")).lower()
        deltas = emit_fix_result_line_fn(issue_id=issue_id, result=result, issue=issue)
        if issue and (status in {"failed", "inconclusive"} or deltas[1] > 0):
            record_fix_failure_fn(issue)
        return deltas

    def build_convergence_only_response(
        self,
        convergence_skipped: list[dict[str, Any]],
        *,
        item_id: str | None,
    ) -> dict[str, Any]:
        """Build the final response when every issue is convergence-suppressed."""
        logger.info(
            "All %d issues suppressed by convergence guard — accepting current state",
            len(convergence_skipped),
        )
        if self._progress_emitter:
            self._progress_emitter.fix_completed(
                fixed=0,
                failed=0,
                skipped=len(convergence_skipped),
            )
        if self._log_event:
            self._log_event(
                "fix_completed",
                item_id=item_id,
                fixed=0,
                failed=0,
                skipped=len(convergence_skipped),
                fixed_count=0,
                failed_count=0,
                skipped_count=len(convergence_skipped),
                convergence_suppressed_count=len(convergence_skipped),
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        return {
            "fix_results": list(convergence_skipped),
            "fixed_count": 0,
            "failed_count": 0,
            "skipped_count": len(convergence_skipped),
            "item_id": item_id,
        }

    @staticmethod
    def merge_convergence_results(
        pass_result: dict[str, Any],
        convergence_skipped: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Merge convergence-suppressed issues back into final pass totals."""
        if not convergence_skipped:
            return pass_result

        merged_results = list(pass_result["fix_results"]) + list(convergence_skipped)
        return {
            "fix_results": merged_results,
            "fixed_count": pass_result["fixed_count"],
            "failed_count": pass_result["failed_count"],
            "skipped_count": pass_result["skipped_count"] + len(convergence_skipped),
            "item_id": pass_result.get("item_id"),
        }
