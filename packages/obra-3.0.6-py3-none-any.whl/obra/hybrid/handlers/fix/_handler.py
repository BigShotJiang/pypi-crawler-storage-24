"""Fix handler for Hybrid Orchestrator.

This module handles the FIX action from the server. It attempts to fix issues
found during review by deploying an implementation agent with specific fix instructions.

The fix process:
    1. Receive FixRequest with issues to fix and execution order
    2. For each issue in order:
       - Build fix prompt with issue details
       - Deploy implementation agent
       - Verify the fix
    3. Return FixResults to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import logging
import os
import subprocess
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.api.protocol import FixRequest
from obra.config.loaders import (
    get_fix_batching_enabled,
    get_fix_batching_max_size,
    get_fix_batching_split_on_retry,
    get_fix_batching_weight_aware,
    get_fix_handler_parallel_enabled,
    get_fix_handler_parallel_workers,  # noqa: F401 — kept for test patchability
    load_layered_config,
)
from obra.display import print_info
from obra.display.observability import (
    ObservabilityConfig,
    ProgressEmitter,
)
from obra.hybrid.handlers.base import ObservabilityContextMixin
from obra.hybrid.handlers.fix._agent_deployer import AgentDeployer, FileChangeSet
from obra.hybrid.handlers.fix._attempt_tracker import FixAttemptTracker
from obra.hybrid.handlers.fix._batch_dispatch import BatchDispatcher
from obra.hybrid.handlers.fix._display import FixDisplay
from obra.hybrid.handlers.fix._helpers import FixHelpers
from obra.hybrid.handlers.fix._issue_normalization import IssueNormalizer
from obra.hybrid.handlers.fix._pass_policy import FixPassPolicy
from obra.hybrid.handlers.fix._request_context import RequestContextPreparer
from obra.hybrid.handlers.fix._result_emitter import ResultEmitter
from obra.hybrid.handlers.fix._scope_validator import ScopeValidator
from obra.hybrid.handlers.fix._results import FixPassResults
from obra.hybrid.handlers.fix._test_gap import (
    TestGapResolver,
    normalize_target_paths,
    resolve_issue_intent,
)
from obra.hybrid.handlers.fix._tool_manager import VerificationToolManager
from obra.hybrid.handlers.fix._verification import VerificationPipeline
from obra.hybrid.install_target import InstallTargetManager
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.utils.file_tracker import FileSnapshot, FileStateTracker

logger = logging.getLogger(__name__)

# Type alias for streaming callback
StreamCallback = Callable[[str, str], None] | None


class FixHandler(ObservabilityContextMixin):
    """Handler for FIX action.

    Attempts to fix issues found during review by deploying implementation
    agents with targeted fix instructions.

    ## Architecture Context (ADR-035)

    This handler implements the two-tier prompting architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with fix guidance
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends FixRequest with base_prompt containing fix instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes implementation agent locally to apply fixes
    4. Client verifies fixes locally (tests, lint, security checks)
    5. Client reports fix results back to server for validation

    ## IP Protection

    Strategic fix patterns (security best practices, quality standards) stay on server.
    This protects Obra's proprietary fix guidance from client-side inspection.

    ## Privacy Protection

    Tactical context (code to fix, file contents, git messages) never sent to server.
    Only fix results (status, files modified, verification outcome) is transmitted.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md

    Example:
        >>> handler = FixHandler(Path("/path/to/project"))
        >>> request = FixRequest(
        ...     issues_to_fix=[{"id": "SEC-001", "description": "SQL injection"}],
        ...     execution_order=["SEC-001"]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["fix_results"])
    """

    DOC_FIX_TIMEOUT_S = 120
    _LOW_ATTRIBUTION_CONFIDENCE = {"low", "none", "unknown"}

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None = None,
        domain: Any = None,
        session_id: str | None = None,
        log_file: Path | None = None,
        trace_id: str | None = None,
        log_event: Any | None = None,
        parent_span_id: str | None = None,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        on_stream: StreamCallback = None,
        process_registry: Any | None = None,
    ) -> None:
        """Initialize FixHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: LLM configuration for agent deployment
            domain: Optional domain module for prompt/filter specialization
            session_id: Optional session ID for trace correlation
            log_file: Optional log file path for event emission
            trace_id: Optional trace ID for distributed tracing
            log_event: Optional event logging callback
            parent_span_id: Optional parent span ID for tracing
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            on_stream: Optional callback for LLM streaming output (event_type, chunk)
            process_registry: Optional ProcessRegistry for subprocess lifecycle management
                             (FEAT-PROCESS-LIFECYCLE-001)
        """
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._domain = domain
        self._session_id = session_id
        self._log_file = log_file
        self._trace_id = trace_id
        self._log_event = log_event
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._on_stream = on_stream
        self._process_registry = process_registry
        self._file_tracker = FileStateTracker(working_dir)
        self._verification_tools: list[dict[str, Any]] | None = None
        self._refactor_mode: bool = False
        # VerificationPipeline — constructed lazily in handle() after tools are loaded.
        # Also lazily initialised by the _verify_fix shim when called directly (tests).
        self._verification: VerificationPipeline | None = None
        self._install_target = InstallTargetManager()
        try:
            self._config, _, _ = load_layered_config(include_defaults=True)
        except Exception:
            self._config = {}
        self._log_decisions = bool(self._config.get("story0", {}).get("log_decisions", True))
        self._on_progress: Callable[[str, dict[str, Any]], None] | None = None
        # S2: FixAttemptTracker — constructed in __init__ (persists across handle() calls)
        self._attempt_tracker = FixAttemptTracker(
            config=self._config,
            session_id=self._session_id,
            working_dir=self._working_dir,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )
        # S2: VerificationToolManager — constructed lazily in handle()
        self._tool_manager: VerificationToolManager | None = None
        # S4: Extracted modules
        self._test_gap = TestGapResolver(
            working_dir=self._working_dir,
            config=self._config,
            llm_config=self._llm_config,
            session_id=self._session_id,
        )
        self._normalizer = IssueNormalizer(
            session_id=self._session_id,
            config=self._config,
        )
        self._display = FixDisplay(
            progress_emitter=self._progress_emitter,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            config=self._config,
            on_progress=self._on_progress,
            log_decisions=self._log_decisions,
        )
        self._helpers = FixHelpers(
            working_dir=self._working_dir,
            config=self._config,
            file_tracker=self._file_tracker,
            test_gap_resolver=self._test_gap,
        )
        self._dispatcher = BatchDispatcher(
            config=self._config,
            llm_config=self._llm_config,
            progress_emitter=self._progress_emitter,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            test_gap_resolver=self._test_gap,
        )
        # S3: AgentDeployer — constructed in __init__ with pre-computed observability env.
        # S4: Uses self._helpers callbacks for filter_infrastructure_files and count_lines.
        observability_env = self._get_observability_env()
        self._deployer = AgentDeployer(
            working_dir=self._working_dir,
            llm_config=self._llm_config,
            session_id=self._session_id,
            log_file=self._log_file,
            trace_id=self._trace_id,
            log_event=self._log_event,
            parent_span_id=self._parent_span_id,
            observability_config=self._observability_config,
            progress_emitter=self._progress_emitter,
            on_stream=self._on_stream,
            process_registry=self._process_registry,
            config=self._config,
            observability_env=observability_env,
            filter_infrastructure_files=self._helpers.filter_infrastructure_files,
            count_lines=self._helpers.count_lines,
        )
        self._scope_validator = ScopeValidator(
            working_dir=self._working_dir,
            file_tracker=self._file_tracker,
            config=self._config,
            progress_emitter=self._progress_emitter,
            log_event=self._log_event,
        )
        self._result_emitter = ResultEmitter(
            display=self._display,
            verification=self._verification,
            progress_emitter=self._progress_emitter,
            log_event=self._log_event,
        )
        self._pass_policy = FixPassPolicy(
            attempt_tracker=self._attempt_tracker,
            dispatcher=self._dispatcher,
            display=self._display,
            progress_emitter=self._progress_emitter,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )
        self._request_context = RequestContextPreparer(
            working_dir=self._working_dir,
            config=self._config,
            llm_config=self._llm_config,
            domain=getattr(self, "_domain", None),
            session_id=self._session_id,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

    def __setattr__(self, name: str, value: object) -> None:
        """Propagate key observability attributes to sub-modules when updated.

        Tests frequently replace _progress_emitter and _log_event after construction.
        Keeping sub-module references in sync ensures telemetry flows correctly.
        """
        super().__setattr__(name, value)
        # After sub-modules are wired, keep them in sync
        if name == "_progress_emitter":
            if "_dispatcher" in self.__dict__:
                self._dispatcher._progress_emitter = value
            if "_display" in self.__dict__:
                self._display._progress_emitter = value
            if "_scope_validator" in self.__dict__:
                self._scope_validator._progress_emitter = value
            if "_result_emitter" in self.__dict__:
                self._result_emitter._progress_emitter = value
            if "_pass_policy" in self.__dict__:
                self._pass_policy._progress_emitter = value
        elif name == "_log_event":
            if "_dispatcher" in self.__dict__:
                self._dispatcher._log_event = value
            if "_display" in self.__dict__:
                self._display._log_event = value
            if "_scope_validator" in self.__dict__:
                self._scope_validator._log_event = value
            if "_result_emitter" in self.__dict__:
                self._result_emitter._log_event = value
            if "_pass_policy" in self.__dict__:
                self._pass_policy._log_event = value
        elif name == "_on_progress":
            if "_display" in self.__dict__:
                self._display._on_progress = value
        elif name == "_log_decisions":
            if "_display" in self.__dict__:
                self._display._log_decisions = value
        elif name == "_verification":
            if "_result_emitter" in self.__dict__:
                self._result_emitter._verification = value

    def handle(self, request: FixRequest) -> dict[str, Any]:
        """Handle FIX action.

        Args:
            request: FixRequest from server with base_prompt

        Returns:
            Dict with fix_results list and item_id

        Raises:
            ValueError: If request.base_prompt is None (server must provide base_prompt)
        """
        # Trace incoming request data
        logger.debug(
            f"FixRequest received: issues_to_fix={len(request.issues_to_fix)}, "
            f"issue_details={len(request.issue_details)}, "
            f"base_prompt_len={len(request.base_prompt or '')}"
        )
        self._refactor_mode = bool(request.refactor_mode)
        # EPIC-FIX-CONTEXT-001 S2: Fresh-fix resets client-side attempt counters
        # so previously-exhausted issues get a clean retry. Without this, the
        # convergence guard's fresh-fix request is defeated by stale counters
        # that cause _should_skip_issue() to skip immediately.
        if request.fresh_fix:
            logger.info(
                "Fresh fix requested — resetting per-issue and per-file "
                "attempt counters"
            )
            self._attempt_tracker.reset()
        prep_result = self._request_context.prepare(
            request,
            progress_emitter=self._progress_emitter,
            log_event=self._log_event,
            emit_progress_fn=self._emit_progress,
            normalize_issues_fn=self._normalize_issues,
            attempt_issue_details_hydration_fn=self._attempt_issue_details_hydration,
            get_reapplied_ids_fn=self._attempt_tracker.get_reapplied_ids,
            build_tool_manager_fn=self._build_tool_manager,
            load_verification_tools_fn=self._load_verification_tools,
            apply_convergence_guard_fn=self._pass_policy.apply_convergence_guard,
            build_convergence_only_response_fn=self._pass_policy.build_convergence_only_response,
            compute_force_individual_fn=lambda fix_history: self._pass_policy.compute_force_individual(
                fix_history,
                split_on_retry_fn=get_fix_batching_split_on_retry,
            ),
            capture_file_state_fn=self._scope_validator.capture_file_state,
            prompt_enricher_cls=PromptEnricher,
            test_gap_classifier=self._is_test_gap_issue,
            test_gap_target_resolver=self._get_test_gap_target_paths,
            issue_intent_resolver=self._resolve_issue_intent,
            run_tests_fn=self._run_tests,
            run_lint_fn=self._run_lint,
        )
        if prep_result.early_response is not None:
            return prep_result.early_response
        prepared = prep_result.prepared
        if prepared is None:
            raise RuntimeError("Request preparation returned no context")

        self._tool_manager = prepared.tool_manager
        self._verification_tools = prepared.verification_tools
        self._verification = prepared.verification_pipeline

        pass_result = self._run_fix_pass(
            issues=prepared.issues,
            execution_order=prepared.execution_order,
            enriched_prompt=prepared.enriched_prompt,
            item_id=prepared.item_id,
            force_individual=prepared.force_individual,
            refactor_mode=self._refactor_mode,
        )
        merged_result = self._pass_policy.merge_convergence_results(
            pass_result,
            prepared.convergence_skipped,
        )

        # FIX-HYBRID-042: Check scope and abort if hard cap exceeded
        if not self._check_fix_scope(prepared.overall_before_state):
            # Scope exceeded — changes reverted, mark all as failed
            merged_result["fixed_count"] = 0
            merged_result["failed_count"] = len(merged_result["fix_results"])
            merged_result["skipped_count"] = 0
            for fr in merged_result["fix_results"]:
                fr["status"] = "scope_exceeded"

        if self._progress_emitter:
            self._progress_emitter.fix_completed(
                fixed=merged_result["fixed_count"],
                failed=merged_result["failed_count"],
                skipped=merged_result["skipped_count"],
            )
        if self._log_event:
            self._log_event(
                "fix_completed",
                item_id=prepared.item_id,
                fixed=merged_result["fixed_count"],
                failed=merged_result["failed_count"],
                skipped=merged_result["skipped_count"],
                fixed_count=merged_result["fixed_count"],
                failed_count=merged_result["failed_count"],
                skipped_count=merged_result["skipped_count"],
                convergence_suppressed_count=len(prepared.convergence_skipped),
                reapply_counts=self._attempt_tracker.get_cycle_reapply_counts(),
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        return merged_result

    def _emit_progress(self, message: str) -> None:
        """Delegation shim — see ResultEmitter.emit_progress."""
        return self._result_emitter.emit_progress(message)

    def _emit_decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Delegation shim — see ResultEmitter.emit_decision_event."""
        return self._result_emitter.emit_decision_event(event_type, data)

    def _run_fix_pass(
        self,
        *,
        issues: list[dict[str, Any]],
        execution_order: list[str] | None,
        enriched_prompt: str,
        item_id: str | None,
        force_individual: bool = False,
        refactor_mode: bool = False,
    ) -> dict[str, Any]:
        """Run a single fix pass over the current issue list.

        Args:
            issues: List of issue dicts to fix
            execution_order: Optional ordering of issue IDs
            enriched_prompt: Enriched base prompt from server
            item_id: Plan item being fixed
            force_individual: When True, skip batching and fix each issue individually.
                Triggered on retry (FIX-LOOP-RESILIENCE-001) to isolate failures.
            refactor_mode: Enables architectural redesign scope in fix prompts.
        """
        logger.info(f"Fixing {len(issues)} issues")
        print_info(f"Fixing {len(issues)} issues")

        issue_map = {
            issue.get("id") or issue.get("canonical_id") or f"issue-{i}": issue
            for i, issue in enumerate(issues)
        }

        ordered_ids = self._pass_policy.resolve_ordered_ids(execution_order, issues)
        self._result_emitter.print_issue_index(issues, ordered_ids)

        results = FixPassResults.empty()
        issue_counter = 0

        def on_issue_result(
            issue_id: str | None,
            result: dict[str, Any],
            issue: dict[str, Any] | None,
        ) -> tuple[int, int, int]:
            return self._pass_policy.handle_issue_result(
                issue_id,
                result,
                issue,
                record_fix_failure_fn=self._record_fix_failure,
                emit_fix_result_line_fn=self._emit_fix_result_line,
            )

        if refactor_mode:
            fix_batch_fn = lambda batch, prompt: self._fix_batch(  # noqa: E731
                batch,
                prompt,
                refactor_mode=True,
            )
            fix_issue_fn = lambda issue, prompt: self._fix_issue(  # noqa: E731
                issue,
                prompt,
                refactor_mode=True,
            )
        else:
            fix_batch_fn = self._fix_batch
            fix_issue_fn = self._fix_issue

        if get_fix_batching_enabled() and not force_individual:
            max_batch = get_fix_batching_max_size()
            batches = self._group_issues_by_file(issues, ordered_ids)

            individual_batches, parallelizable_batches = self._dispatcher.classify_batches(
                batches, max_batch
            )

            # Weight-aware rebalancing: sort heaviest-first
            if get_fix_batching_weight_aware() and len(parallelizable_batches) >= 2:
                parallelizable_batches = self._dispatcher.rebalance(parallelizable_batches)

            use_parallel = (
                get_fix_handler_parallel_enabled()
                and len(parallelizable_batches) >= 2
            )

            processed_issue_ids: set[str] = set()

            if use_parallel:
                batch_results, processed = self._dispatcher.dispatch_parallel(
                    batches=parallelizable_batches,
                    execute_worker_fn=self._execute_batch_parallel_worker,
                    on_issue_result=on_issue_result,
                    issue_map=issue_map,
                    enriched_prompt=enriched_prompt,
                )
                results = results.combine(batch_results)
                processed_issue_ids |= processed
            else:
                # Sequential path for parallelizable batches
                batch_results, processed = self._dispatcher.dispatch_sequential(
                    batches=parallelizable_batches,
                    fix_batch_fn=fix_batch_fn,
                    on_issue_result=on_issue_result,
                    issue_map=issue_map,
                    enriched_prompt=enriched_prompt,
                    print_batch_progress_fn=lambda b, bi, t: self._result_emitter.print_batch_progress(
                        b, batch_index=bi, total_batches=t
                    ),
                    total_batches=len(batches),
                )
                results = results.combine(batch_results)
                processed_issue_ids |= processed

            # Handle type-1 batches (individual / no file_path) sequentially
            indiv_results, indiv_processed, issue_counter = (
                self._dispatcher.dispatch_individual_batches(
                    batches=individual_batches,
                    fix_issue_fn=fix_issue_fn,
                    should_skip_fn=self._should_skip_issue,
                    build_skip_fn=self._build_skip_result,
                    on_issue_result=on_issue_result,
                    print_issue_progress_fn=self._print_issue_progress,
                    issues=issues,
                    issue_counter=issue_counter,
                    enriched_prompt=enriched_prompt,
                )
            )
            results = results.combine(indiv_results)
            processed_issue_ids |= indiv_processed

            # Handle leftover issues not covered by any batch
            leftover_results, issue_counter = self._dispatcher.dispatch_leftover_issues(
                ordered_ids=ordered_ids,
                processed_ids=processed_issue_ids,
                issue_map=issue_map,
                fix_issue_fn=fix_issue_fn,
                should_skip_fn=self._should_skip_issue,
                build_skip_fn=self._build_skip_result,
                on_issue_result=on_issue_result,
                print_issue_progress_fn=self._print_issue_progress,
                issues=issues,
                issue_counter=issue_counter,
                enriched_prompt=enriched_prompt,
            )
            results = results.combine(leftover_results)
        else:
            # Non-batching sequential loop
            results, issue_counter = self._dispatcher.dispatch_linear(
                ordered_ids=ordered_ids,
                issue_map=issue_map,
                fix_issue_fn=fix_issue_fn,
                should_skip_fn=self._should_skip_issue,
                build_skip_fn=self._build_skip_result,
                on_issue_result=on_issue_result,
                print_issue_progress_fn=self._print_issue_progress,
                issues=issues,
                enriched_prompt=enriched_prompt,
            )

        logger.debug(
            "Fix complete: %s fixed, %s failed, %s skipped",
            results.fixed_count,
            results.failed_count,
            results.skipped_count,
        )
        if not self._progress_emitter:
            self._result_emitter.print_fix_summary(
                fixed_count=results.fixed_count,
                failed_count=results.failed_count,
                skipped_count=results.skipped_count,
            )

        return {
            "fix_results": list(results.fix_results),
            "fixed_count": results.fixed_count,
            "failed_count": results.failed_count,
            "skipped_count": results.skipped_count,
            "item_id": item_id,
        }

    @staticmethod
    def _resolve_fix_result_severity(
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> str:
        """Delegation shim — see ResultEmitter.resolve_fix_result_severity."""
        return ResultEmitter.resolve_fix_result_severity(result, issue)

    def _emit_fix_result_line(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> tuple[int, int, int]:
        """Delegation shim — see ResultEmitter.emit_fix_result_line."""
        return self._result_emitter.emit_fix_result_line(issue_id=issue_id, result=result, issue=issue)

    def _emit_fix_result_event(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        status: str,
    ) -> None:
        """Delegation shim — see ResultEmitter.emit_fix_result_event."""
        return self._result_emitter.emit_fix_result_event(issue_id=issue_id, result=result, status=status)

    # ------------------------------------------------------------------
    # ISSUE-HYBRID-044: Per-fingerprint fix attempt limit
    # FIX-HYBRID-048: File-level failure tracking
    # S2: Shims — delegate to FixAttemptTracker. Kept for backward compatibility
    # with tests that access these methods directly on FixHandler.
    # ------------------------------------------------------------------

    @property
    def _fix_attempt_history(self) -> dict[str, int]:
        """Compatibility bridge — returns tracker's attempt history dict."""
        return self._attempt_tracker._fix_attempt_history

    def _should_skip_issue(self, issue: dict[str, Any]) -> bool:
        """Compatibility shim — delegates to FixAttemptTracker."""
        return self._attempt_tracker.should_skip(issue)

    def _record_fix_failure(self, issue: dict[str, Any]) -> None:
        """Compatibility shim — delegates to FixAttemptTracker."""
        self._attempt_tracker.record_failure(issue)

    def _build_skip_result(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Compatibility shim — delegates to FixAttemptTracker."""
        return self._attempt_tracker.build_skip(issue)

    def _normalize_issues(
        self,
        issues: list[Any],
        issue_details: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Delegation shim — see _issue_normalization.IssueNormalizer.normalize_issues."""
        return self._normalizer.normalize_issues(issues, issue_details)

    def _attempt_issue_details_hydration(self, request: FixRequest) -> bool:
        """Delegation shim — see _issue_normalization.IssueNormalizer.attempt_issue_details_hydration."""
        return self._normalizer.attempt_issue_details_hydration(request)

    @staticmethod
    def _extract_issue_details_from_reports(
        agent_reports: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Delegation shim — see _issue_normalization.IssueNormalizer.extract_issue_details_from_reports."""
        return IssueNormalizer.extract_issue_details_from_reports(agent_reports)

    def _count_line_delta(self, before_lines: list[str], after_lines: list[str]) -> int:
        """Delegation shim — see ScopeValidator.count_line_delta."""
        return ScopeValidator.count_line_delta(before_lines, after_lines)

    def _measure_diff_lines(self, files_modified: list[str], before_state: FileSnapshot | None = None) -> int:
        """Delegation shim — see ScopeValidator.measure_diff_lines."""
        return self._scope_validator.measure_diff_lines(files_modified, before_state)

    def _check_fix_scope(self, before_state: FileSnapshot) -> bool:
        """Delegation shim — see ScopeValidator.check_fix_scope."""
        return self._scope_validator.check_fix_scope(before_state)

    def _revert_modifications(self, files_modified: list[str]) -> None:
        """Delegation shim — see ScopeValidator.revert_modifications."""
        return self._scope_validator.revert_modifications(files_modified)

    def _order_by_priority(self, issues: list[dict[str, Any]]) -> list[str]:
        """Delegation shim — see _batch_dispatch.BatchDispatcher.order_by_priority."""
        return self._dispatcher.order_by_priority(issues)

    def _group_issues_by_file(
        self,
        issues: list[dict[str, Any]],
        ordered_ids: list[str],
    ) -> list[dict[str, Any]]:
        """Delegation shim — see _batch_dispatch.BatchDispatcher.group_issues_by_file.

        CRITICAL: tests patch this method on the handler — keep the shim.
        """
        return self._dispatcher.group_issues_by_file(issues, ordered_ids)

    @staticmethod
    def _estimate_batch_weight(batch: dict[str, Any]) -> int:
        """Delegation shim — see _batch_dispatch.BatchDispatcher.estimate_batch_weight."""
        return BatchDispatcher.estimate_batch_weight(batch)

    @staticmethod
    def _rebalance_batches_by_weight(
        batches: list[tuple[int, dict[str, Any]]],
        estimate_fn: Callable[[dict[str, Any]], int],  # noqa: ARG004 — kept for API compatibility
    ) -> list[tuple[int, dict[str, Any]]]:
        """Delegation shim — see _batch_dispatch.BatchDispatcher.rebalance.

        Note: estimate_fn is ignored; BatchDispatcher.rebalance uses estimate_batch_weight internally.
        """
        return BatchDispatcher.rebalance(batches)

    def _build_batch_prompt(
        self,
        batch: dict[str, Any],
        base_prompt: str,
        refactor_mode: bool = False,
    ) -> str:
        """Delegation shim — see _batch_dispatch.BatchDispatcher.build_batch_prompt."""
        return self._dispatcher.build_batch_prompt(
            batch,
            base_prompt,
            refactor_mode=refactor_mode,
        )

    def _build_tool_manager(self) -> VerificationToolManager:
        """Construct and store the verification tool manager for this handle() call."""
        self._tool_manager = VerificationToolManager(
            working_dir=self._working_dir,
            config=self._config,
            install_target=self._install_target,
            llm_config=self._llm_config,
            progress_emitter=self._progress_emitter,
            on_progress=self._on_progress,
            log_decisions=self._log_decisions,
        )
        return self._tool_manager

    def _load_verification_tools(self) -> list[dict[str, Any]]:
        """Compatibility shim — delegates to VerificationToolManager.

        Kept so tests can monkeypatch FixHandler._load_verification_tools.
        In handle(), self._tool_manager is always constructed before this is
        called, so the shim delegates to it. Outside of handle() (tests calling
        directly), constructs a temporary manager.
        """
        if self._tool_manager is not None:
            return self._tool_manager.load_tools()
        # Fallback: construct temporary manager (tests calling before handle())
        tmp = VerificationToolManager(
            working_dir=self._working_dir,
            config=self._config,
            install_target=self._install_target,
            llm_config=self._llm_config,
        )
        return tmp.load_tools()

    def _resolve_issue_timeout(self, issue: dict[str, Any]) -> int:
        """Delegation shim — see _issue_normalization.IssueNormalizer.resolve_issue_timeout."""
        return self._normalizer.resolve_issue_timeout(issue)

    def _is_documentation_issue(self, issue: dict[str, Any]) -> bool:
        """Delegation shim — see _issue_normalization.IssueNormalizer.is_documentation_issue."""
        return self._normalizer.is_documentation_issue(issue)

    @staticmethod
    def _normalize_target_paths(target_paths: Any) -> list[str]:
        """Delegation shim — see _test_gap.normalize_target_paths."""
        return normalize_target_paths(target_paths)

    @staticmethod
    def _resolve_issue_intent(issue: dict[str, Any]) -> tuple[str, str, str]:
        """Delegation shim — see _test_gap.resolve_issue_intent."""
        return resolve_issue_intent(issue)

    def _is_test_gap_issue(self, issue: dict[str, Any]) -> bool:
        """Delegation shim — see _test_gap.TestGapResolver.is_test_gap."""
        return self._test_gap.is_test_gap(issue)

    def _get_test_gap_target_paths(self, issue: dict[str, Any]) -> list[str]:
        """Delegation shim — see _test_gap.TestGapResolver.get_target_paths."""
        return self._test_gap.get_target_paths(issue)

    def _collect_test_gap_candidates(self, issue: dict[str, Any]) -> list[str]:
        """Delegation shim — see _test_gap.TestGapResolver.collect_candidates."""
        return self._test_gap.collect_candidates(issue)

    def _infer_test_gap_target(
        self, issue: dict[str, Any]
    ) -> tuple[str | None, float | None, str | None]:
        """Delegation shim — see _test_gap.TestGapResolver.infer_target."""
        return self._test_gap.infer_target(issue)

    def _ensure_test_gap_target(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Delegation shim — see _test_gap.TestGapResolver.resolve."""
        return self._test_gap.resolve(issue)

    def _build_patch_summary(self, files_modified: list[str]) -> dict[str, Any]:
        """Delegation shim — see _helpers.FixHelpers.build_patch_summary."""
        return self._helpers.build_patch_summary(files_modified)

    def _read_file_for_fix(
        self,
        file_path: str,
        line_number: int | str | None = None,
        context_lines: int = 50,
    ) -> str | None:
        """Delegation shim — see _test_gap.TestGapResolver.read_file_for_fix."""
        return self._test_gap.read_file_for_fix(file_path, line_number, context_lines)

    def _build_issue_specific_prompt(
        self,
        issue: dict[str, Any],
        base_prompt: str,
        refactor_mode: bool = False,
    ) -> str:
        """Delegation shim — see _helpers.FixHelpers.build_issue_specific_prompt."""
        return self._helpers.build_issue_specific_prompt(
            issue,
            base_prompt,
            refactor_mode=refactor_mode,
        )

    def _fix_issue(
        self,
        issue: dict[str, Any],
        enriched_prompt: str,
        refactor_mode: bool = False,
    ) -> dict[str, Any]:
        """Fix a single issue.

        Args:
            issue: Issue dictionary with id, description, suggestion, etc.
            enriched_prompt: Enriched fix prompt from server

        Returns:
            FixResult dictionary
        """
        issue_id = issue.get("id", "unknown")
        canonical_id = issue.get("canonical_id") or issue_id
        description = issue.get("description", "")

        logger.debug(
            f"Fixing issue {issue_id}: file={issue.get('file_path')}, "
            f"line={issue.get('line_number')}, keys={list(issue.keys())}"
        )

        logger.info(f"Fixing issue {issue_id}: {description[:50]}...")

        try:
            timeout_s = self._resolve_issue_timeout(issue)
            if self._is_documentation_issue(issue):
                logger.info(
                    "Using reduced timeout for documentation issue %s: %ss",
                    issue_id,
                    timeout_s,
                )

            if self._is_test_gap_issue(issue):
                issue = self._ensure_test_gap_target(issue)
                if not issue.get("target_test_file"):
                    error_message = issue.get("metadata", {}).get(
                        "inference_error",
                        "Missing target test file for test-gap issue",
                    )
                    return {
                        "issue_id": issue_id,
                        "canonical_id": canonical_id,
                        "status": "failed",
                        "reason": "target_test_file_missing",
                        "files_modified": [],
                        "verification": {
                            "error": error_message,
                            "test_gap_target_missing": True,
                        },
                        "verification_issues": [],
                        "summary": f"Failed to fix {issue_id}: {error_message}",
                        "approach_summary": f"Agent failed to produce changes: {error_message}",
                    }

            # Capture file state before execution for modification detection
            before_state = self._scope_validator.capture_file_state()

            # FIX-REVIEW-LOOP-001: Build issue-specific prompt with full context
            # Previously, the enriched_prompt was used directly without issue details,
            # causing the LLM to not know what it needed to fix.
            if refactor_mode:
                issue_prompt = self._build_issue_specific_prompt(
                    issue,
                    enriched_prompt,
                    refactor_mode=True,
                )
            else:
                issue_prompt = self._build_issue_specific_prompt(issue, enriched_prompt)

            # Deploy implementation agent to fix with issue-specific prompt
            result = self._deploy_agent(issue_prompt, timeout_s=timeout_s)

            # Detect actual file modifications during execution
            files_modified = self._scope_validator.detect_modifications(before_state)

            # Verify the fix (pass actual files_modified from tracker)
            # FIX-REVIEW-LOOP-003: Pass tracked files instead of relying on agent_result
            verification = self._verify_fix(issue, result, files_modified=files_modified)
            verification["patch_summary"] = self._build_patch_summary(files_modified)

            # Validate project boundary (post-execution safety net)
            boundary_check = self._scope_validator.validate_project_boundary(files_modified)
            verification["boundary_valid"] = not boundary_check["has_violations"]
            if boundary_check["has_violations"]:
                logger.warning(
                    f"Project boundary violation for issue {issue_id}: "
                    f"{boundary_check['violations']}"
                )
                verification["boundary_violations"] = boundary_check["violations"]

            # Determine status based on verification
            verification_outcome = str(
                verification.get("verification_outcome") or ""
            ).strip().lower()

            # BUG-SCHEMA-001: Use "applied" not "fixed" to match server schema.
            if verification_outcome == "passed" or verification.get("all_passed", False):
                status = "applied"
            elif verification_outcome == "inconclusive":
                status = "inconclusive"
            elif verification.get("partial", False):
                status = "applied"  # Partial fix still counts
            else:
                status = "failed"
            reason = (
                verification.get("verification_reason_code")
                or verification.get("failure_reason")
                or "verification_passed"
            )
            if status == "applied" and verification.get("partial", False):
                reason = "verification_partial"

            # BUG-SCHEMA-002: Add summary for orchestrator (orchestrator.py:791)
            status_phrase = (
                "Applied fix for"
                if status == "applied"
                else "Fix inconclusive for"
                if status == "inconclusive"
                else "Failed to fix"
            )
            summary = result.get(
                "summary",
                f"{status_phrase} issue {issue_id}",
            )

            files_list = ", ".join(files_modified) if files_modified else "none"
            approach_summary = f"{summary[:200]} | files: {files_list}"

            return {
                "issue_id": issue_id,
                "canonical_id": canonical_id,
                "status": status,
                "reason": reason,
                "verification_outcome": verification.get("verification_outcome"),
                "verification_scope": verification.get("verification_scope"),
                "attribution_confidence": verification.get("attribution_confidence"),
                "files_modified": files_modified,
                "verification": verification,
                "verification_issues": verification.get("promoted_issues", []),
                "summary": summary,
                "approach_summary": approach_summary,
            }

        except Exception as e:
            logger.exception(f"Failed to fix issue {issue_id}: {e}")
            return {
                "issue_id": issue_id,
                "canonical_id": canonical_id,
                "status": "failed",
                "reason": "handler_exception",
                "files_modified": [],
                "verification": {"error": str(e)},
                "verification_issues": [],
                "summary": f"Failed to fix issue {issue_id}: {e!s}",  # BUG-SCHEMA-002
                "approach_summary": f"Agent failed to produce changes: {e!s}",
            }

    def _fix_batch(
        self,
        batch: dict[str, Any],
        enriched_prompt: str,
        refactor_mode: bool = False,
    ) -> list[dict[str, Any]]:
        """Fix multiple issues in a single LLM call.

        Args:
            batch: Batch dict with 'file_path' and 'issues' keys
            enriched_prompt: Enriched base prompt from server

        Returns:
            List of FixResult dictionaries (one per issue)
        """
        issues = batch["issues"]
        file_path = batch["file_path"]

        logger.info(f"Batch fixing {len(issues)} issues in {file_path}")
        print_info(f"Batch fixing {len(issues)} issues in {file_path}")

        try:
            if refactor_mode:
                batch_prompt = self._build_batch_prompt(
                    batch,
                    enriched_prompt,
                    refactor_mode=True,
                )
            else:
                batch_prompt = self._build_batch_prompt(batch, enriched_prompt)
            before_state = self._scope_validator.capture_file_state()

            result = self._deployer.deploy(batch_prompt)
            files_modified = self._scope_validator.detect_modifications(before_state)

            # Verify each issue individually (pass actual files_modified from tracker)
            # FIX-REVIEW-LOOP-003: Pass tracked files instead of relying on agent_result
            fix_results = []
            for issue in issues:
                verification = self._verify_fix(issue, result, files_modified=files_modified)
                verification["patch_summary"] = self._build_patch_summary(files_modified)
                verification_outcome = str(
                    verification.get("verification_outcome") or ""
                ).strip().lower()
                if verification_outcome == "passed" or verification.get("all_passed", False):
                    status = "applied"
                elif verification_outcome == "inconclusive":
                    status = "inconclusive"
                else:
                    status = "failed"
                reason = (
                    verification.get("verification_reason_code")
                    or verification.get("failure_reason")
                    or "verification_passed"
                )
                issue_id = issue.get("id") or ""
                status_phrase = (
                    "Applied fix for"
                    if status == "applied"
                    else "Inconclusive fix for"
                    if status == "inconclusive"
                    else "Failed to fix"
                )
                batch_summary = f"{status_phrase} {issue_id} in {file_path}"
                files_list = ", ".join(files_modified) if files_modified else "none"
                batch_approach = f"{batch_summary} | files: {files_list}"

                fix_results.append(
                    {
                        "issue_id": issue_id,
                        "canonical_id": issue.get("canonical_id") or issue_id,
                        "status": status,
                        "reason": reason,
                        "verification_outcome": verification.get("verification_outcome"),
                        "verification_scope": verification.get("verification_scope"),
                        "attribution_confidence": verification.get("attribution_confidence"),
                        "files_modified": files_modified,
                        "verification": verification,
                        "verification_issues": verification.get("promoted_issues", []),
                        "batch_id": f"{file_path}:{len(issues)}",
                        "summary": batch_summary,
                        "approach_summary": batch_approach,
                    }
                )
            return fix_results

        except Exception as e:
            logger.exception(f"Batch fix failed for {file_path}: {e}")
            # Fallback: fix issues individually
            if refactor_mode:
                return [
                    self._fix_issue(
                        issue,
                        enriched_prompt,
                        refactor_mode=True,
                    )
                    for issue in issues
                ]
            return [self._fix_issue(issue, enriched_prompt) for issue in issues]

    def _execute_batch_parallel_worker(
        self,
        batch: dict[str, Any],
        enriched_prompt: str,
    ) -> list[dict[str, Any]]:
        """Execute a single batch with isolated file tracking for parallel-safe execution.

        REFACTOR-PARALLEL-MODULE-001: Duplicates core _fix_batch logic but uses
        an isolated FileStateTracker to prevent cross-contamination between
        concurrent workers. Does NOT call _record_fix_failure or _emit_fix_result_line;
        those are deferred to the single-threaded merge phase.

        Thread-safety assumptions:
        - _build_batch_prompt: read-only, safe for concurrent access
        - _deploy_agent: spawns independent subprocess, safe
        - Worker-local VerificationPipeline: isolated state, no shared mutation
        - _build_patch_summary: read-only, safe

        Args:
            batch: Batch dict with 'file_path' and 'issues' keys
            enriched_prompt: Enriched base prompt from server

        Returns:
            List of FixResult dictionaries (one per issue)
        """
        issues = batch["issues"]
        file_path = batch["file_path"]

        logger.info(f"[parallel] Batch fixing {len(issues)} issues in {file_path}")

        try:
            if self._refactor_mode:
                batch_prompt = self._build_batch_prompt(
                    batch,
                    enriched_prompt,
                    refactor_mode=True,
                )
            else:
                batch_prompt = self._build_batch_prompt(batch, enriched_prompt)

            # Worker-local AgentDeployer — isolated _file_tracker prevents heartbeat
            # cross-contamination between concurrent workers (thread-isolation pattern).
            worker_deployer = AgentDeployer(
                working_dir=self._working_dir,
                llm_config=self._llm_config,
                session_id=self._session_id,
                log_file=self._log_file,
                trace_id=self._trace_id,
                log_event=self._log_event,
                parent_span_id=self._parent_span_id,
                observability_config=self._observability_config,
                progress_emitter=self._progress_emitter,
                on_stream=self._on_stream,
                process_registry=self._process_registry,
                config=self._config,
                observability_env=self._deployer._observability_env,
                filter_infrastructure_files=self._filter_infrastructure_files,
                count_lines=self._count_lines,
            )

            # Isolated file tracker — prevents files_modified cross-contamination
            # between concurrent workers sharing the same working directory.
            isolated_tracker = FileStateTracker(self._working_dir)
            before_state = isolated_tracker.snapshot()

            result = worker_deployer.deploy(batch_prompt)

            changes = isolated_tracker.diff(before_state)
            files_modified = changes.all_changed_files

            # Worker-local VerificationPipeline — isolated state (own _verification_target_snapshot
            # and _last_verification_run_metadata) prevents cross-contamination between workers.
            worker_verification = VerificationPipeline(
                working_dir=self._working_dir,
                verification_tools=self._verification_tools or [],
                config=self._config,
                domain=getattr(self, "_domain", None),
                session_id=self._session_id,
                log_event=self._log_event,
                progress_emitter=self._progress_emitter,
                test_gap_classifier=self._is_test_gap_issue,
                test_gap_target_resolver=self._get_test_gap_target_paths,
                issue_intent_resolver=self._resolve_issue_intent,
            )

            fix_results: list[dict[str, Any]] = []
            for issue in issues:
                verification = worker_verification.verify_fix(issue, result, files_modified=files_modified)
                verification["patch_summary"] = self._build_patch_summary(files_modified)
                verification_outcome = str(
                    verification.get("verification_outcome") or ""
                ).strip().lower()
                if verification_outcome == "passed" or verification.get("all_passed", False):
                    status = "applied"
                elif verification_outcome == "inconclusive":
                    status = "inconclusive"
                else:
                    status = "failed"
                reason = (
                    verification.get("verification_reason_code")
                    or verification.get("failure_reason")
                    or "verification_passed"
                )
                issue_id = issue.get("id") or ""
                status_phrase = (
                    "Applied fix for"
                    if status == "applied"
                    else "Inconclusive fix for"
                    if status == "inconclusive"
                    else "Failed to fix"
                )
                batch_summary = f"{status_phrase} {issue_id} in {file_path}"
                files_list = ", ".join(files_modified) if files_modified else "none"
                batch_approach = f"{batch_summary} | files: {files_list}"

                fix_results.append(
                    {
                        "issue_id": issue_id,
                        "canonical_id": issue.get("canonical_id") or issue_id,
                        "status": status,
                        "reason": reason,
                        "verification_outcome": verification.get("verification_outcome"),
                        "verification_scope": verification.get("verification_scope"),
                        "attribution_confidence": verification.get("attribution_confidence"),
                        "files_modified": files_modified,
                        "verification": verification,
                        "verification_issues": verification.get("promoted_issues", []),
                        "batch_id": f"{file_path}:{len(issues)}",
                        "summary": batch_summary,
                        "approach_summary": batch_approach,
                    }
                )
            return fix_results

        except Exception as e:
            logger.exception(f"[parallel] Batch fix failed for {file_path}: {e}")
            # Return error results for all issues in batch — do NOT fall back to
            # individual fixing (which would use shared self._file_tracker).
            return [
                {
                    "issue_id": issue.get("id") or "",
                    "canonical_id": issue.get("canonical_id") or issue.get("id") or "",
                    "status": "failed",
                    "reason": "parallel_batch_error",
                    "files_modified": [],
                    "verification": {"error": str(e)},
                    "verification_issues": [],
                    "summary": f"Parallel batch error for {file_path}: {e}",
                    "approach_summary": f"Parallel worker failed: {e}",
                }
                for issue in issues
            ]


    def _verify_fix(
        self,
        issue: dict[str, Any],
        agent_result: dict[str, Any],
        files_modified: list[str] | None = None,
    ) -> dict[str, Any]:
        """Compatibility shim — delegates to VerificationPipeline.verify_fix().

        Lazily constructs VerificationPipeline if handle() has not been called yet
        (e.g., in unit tests that call _verify_fix directly).
        """
        if self._verification is None:
            self._verification = VerificationPipeline(
                working_dir=self._working_dir,
                verification_tools=self._verification_tools or [],
                config=self._config,
                domain=getattr(self, "_domain", None),
                session_id=self._session_id,
                log_event=self._log_event,
                progress_emitter=self._progress_emitter,
                test_gap_classifier=self._is_test_gap_issue,
                test_gap_target_resolver=self._get_test_gap_target_paths,
                issue_intent_resolver=self._resolve_issue_intent,
                run_tests_fn=self._run_tests,
                run_lint_fn=self._run_lint,
            )
        return self._verification.verify_fix(issue, agent_result, files_modified=files_modified)

    def _deploy_agent(self, prompt: str, *, timeout_s: int | None = None) -> dict[str, Any]:
        """Compatibility shim — delegates to AgentDeployer.deploy().

        ISSUE-EXEC-003: AgentDeployer.deploy() uses mode="execute" to prevent
        the --print flag from being added, allowing file writes.

        Kept so tests can call or monkeypatch FixHandler._deploy_agent.
        """
        return self._deployer.deploy(prompt, timeout_s=timeout_s)

    def _ensure_verification(self) -> None:
        """Lazily construct VerificationPipeline if not yet initialised."""
        if self._verification is None:
            self._verification = VerificationPipeline(
                working_dir=self._working_dir,
                verification_tools=self._verification_tools or [],
                config=self._config,
                domain=getattr(self, "_domain", None),
                session_id=self._session_id,
                log_event=self._log_event,
                progress_emitter=self._progress_emitter,
                test_gap_classifier=self._is_test_gap_issue,
                test_gap_target_resolver=self._get_test_gap_target_paths,
                issue_intent_resolver=self._resolve_issue_intent,
                run_tests_fn=self._run_tests,
                run_lint_fn=self._run_lint,
            )

    def _run_tests(
        self,
        modified_files: list[str] | None = None,
        canonical_id: str | None = None,
    ) -> tuple[bool | None, str, str, str]:
        """Compatibility shim — delegates to VerificationPipeline._run_tests."""
        self._ensure_verification()
        return self._verification._run_tests(  # type: ignore[union-attr]
            modified_files=modified_files, canonical_id=canonical_id
        )

    def _run_tests_for_target(
        self,
        target_file: str,
        modified_files: list[str] | None = None,
        canonical_id: str | None = None,
    ) -> tuple[bool | None, str, str, str]:
        """Compatibility shim — delegates to VerificationPipeline._run_tests_for_target."""
        self._ensure_verification()
        return self._verification._run_tests_for_target(  # type: ignore[union-attr]
            target_file, modified_files=modified_files, canonical_id=canonical_id
        )

    def _run_lint(
        self,
        modified_files: list[str] | None = None,
    ) -> tuple[bool | None, str, str, str]:
        """Compatibility shim — delegates to VerificationPipeline._run_lint."""
        self._ensure_verification()
        return self._verification._run_lint(  # type: ignore[union-attr]
            modified_files=modified_files
        )

    def _run_security_check(self) -> bool | None:
        """Compatibility shim — delegates to VerificationPipeline._run_security_check."""
        self._ensure_verification()
        return self._verification._run_security_check()  # type: ignore[union-attr]

    def _capture_file_state(self) -> FileSnapshot:
        """Delegation shim — see ScopeValidator.capture_file_state."""
        return self._scope_validator.capture_file_state()

    def _detect_modifications(self, before_state: FileSnapshot) -> list[str]:
        """Delegation shim — see ScopeValidator.detect_modifications."""
        return self._scope_validator.detect_modifications(before_state)

    def _validate_project_boundary(self, files_modified: list[str]) -> dict[str, Any]:
        """Delegation shim — see ScopeValidator.validate_project_boundary."""
        return self._scope_validator.validate_project_boundary(files_modified)

    def _find_related_test_files(
        self,
        modified_files: list[str],
        patterns: list[str] | None = None,
    ) -> list[str]:
        """Delegation shim — see _test_gap.TestGapResolver.find_related_test_files."""
        return self._test_gap.find_related_test_files(modified_files, patterns)

    @staticmethod
    def _is_infrastructure_file(path: str) -> bool:
        """Delegation shim — see _helpers.FixHelpers.is_infrastructure_file."""
        return FixHelpers.is_infrastructure_file(path)

    def _filter_infrastructure_files(self, paths: set[str]) -> set[str]:
        """Delegation shim — see _helpers.FixHelpers.filter_infrastructure_files."""
        return self._helpers.filter_infrastructure_files(paths)

    def _print_issue_index(self, issues: list[dict[str, Any]], ordered_ids: list[str]) -> None:
        """Delegation shim — see ResultEmitter.print_issue_index."""
        return self._result_emitter.print_issue_index(issues, ordered_ids)

    def _print_issue_progress(self, issue: dict[str, Any], index: int, total: int) -> None:
        """Delegation shim — see ResultEmitter.print_issue_progress."""
        return self._result_emitter.print_issue_progress(issue, index, total)

    def _print_batch_progress(
        self,
        batch: dict[str, Any],
        *,
        batch_index: int,
        total_batches: int,
    ) -> None:
        """Delegation shim — see ResultEmitter.print_batch_progress."""
        return self._result_emitter.print_batch_progress(batch, batch_index=batch_index, total_batches=total_batches)

    @staticmethod
    def _format_issue_summary(issue: dict[str, Any]) -> str:
        """Delegation shim — see ResultEmitter.format_issue_summary."""
        return ResultEmitter.format_issue_summary(issue)

    @staticmethod
    def _format_failure_reason(result: dict[str, Any]) -> str | None:
        """Delegation shim — see ResultEmitter.format_failure_reason."""
        return ResultEmitter.format_failure_reason(result)

    def _print_fix_summary(
        self,
        *,
        fixed_count: int,
        failed_count: int,
        skipped_count: int,
    ) -> None:
        """Delegation shim — see ResultEmitter.print_fix_summary."""
        return self._result_emitter.print_fix_summary(
            fixed_count=fixed_count,
            failed_count=failed_count,
            skipped_count=skipped_count,
        )

    def _get_validation_config(self) -> dict[str, Any]:
        """Delegation shim — see _helpers.FixHelpers.get_validation_config."""
        return self._helpers.get_validation_config()

    def _has_meaningful_content(self, filepath: str, min_size: int = 10) -> bool:
        """Delegation shim — see _helpers.FixHelpers.has_meaningful_content."""
        return self._helpers.has_meaningful_content(filepath, min_size)

    def _matches_expected_extensions(
        self, filepath: str, expected_extensions: list[str] | None
    ) -> bool:
        """Delegation shim — see _helpers.FixHelpers.matches_expected_extensions."""
        return FixHelpers.matches_expected_extensions(filepath, expected_extensions)

    def _validate_deliverables(self, paths: set[str]) -> tuple[set[str], list[str]]:
        """Delegation shim — see _helpers.FixHelpers.validate_deliverables."""
        return self._helpers.validate_deliverables(paths)

    def _count_file_changes(self) -> int:
        """Delegation shim — see _helpers.FixHelpers.count_file_changes."""
        return self._helpers.count_file_changes()

    def _get_file_changes(self) -> FileChangeSet:
        """Delegation shim — see _helpers.FixHelpers.get_file_changes."""
        return self._helpers.get_file_changes()

    def _count_lines(self, filepath: str) -> int | None:
        """Delegation shim — see _helpers.FixHelpers.count_lines."""
        return self._helpers.count_lines(filepath)


__all__ = ["FixHandler"]
