"""Agent deployer for FixHandler.

Provides classes for deploying implementation agents during fix operations:
- FileChangeSet: Represents a set of file changes
- FileChangeTracker: Tracks file changes using FileStateTracker (decoupled from FixHandler)
- HeartbeatThread: Background thread emitting heartbeats during agent execution
- AgentDeployer: Deploys implementation agents (wraps _deploy_agent logic)

Related:
    - obra/hybrid/handlers/fix/_handler.py
    - docs/design/briefs/FIX_HANDLER_DECOMPOSITION_BRIEF.md
"""

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.config import (
    get_agent_execution_timeout,
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
    get_timeout,
)
from obra.config.loaders import (
    get_interactive_guard_retry_max,
    get_interactive_guard_rollback_codes,
    get_interactive_guard_rollback_enabled,
)
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display.observability import ObservabilityConfig, ProgressEmitter, VerbosityLevel
from obra.llm.interactive_guard import (
    extract_interactive_failure,
    sanitize_interactive_line,
)
from obra.prompts.fragments.recovery import build_interactive_recovery_banner
from obra.utils.file_tracker import FileStateTracker
from obra.utils.workspace_rollback import WorkspaceRollbackStore

logger = logging.getLogger(__name__)

# Type alias for streaming callback
StreamCallback = Callable[[str, str], None] | None


@dataclass
class FileChangeSet:
    """Represents a set of file changes detected in the working directory."""

    added: set[str]
    modified: set[str]
    count: int


class FileChangeTracker:
    """Tracks file changes between polls using FileStateTracker.

    FIX-FILE-TRACKING-001: Uses hash-based file tracking instead of git status.
    Git doesn't track changes to untracked files, so files created in one fix
    cycle and modified in subsequent cycles were always showing as "added".
    Now properly detects modifications by comparing against initial snapshot.
    """

    def __init__(
        self,
        file_tracker: FileStateTracker,
        filter_fn: Callable[[set[str]], set[str]],
    ) -> None:
        self._file_tracker = file_tracker
        self._filter_fn = filter_fn
        # Capture initial state when tracker is created
        self._initial_snapshot = self._file_tracker.snapshot()
        # Track what we've already reported to avoid duplicates
        self._reported_added: set[str] = set()
        self._reported_modified: set[str] = set()

    def poll(self) -> FileChangeSet:
        """Poll for new file changes since last poll.

        Compares current state against initial snapshot (not git status).
        This correctly detects modifications to files that were created
        during the fix cycle but not yet committed to git.
        """
        # Get changes compared to initial state
        changes = self._file_tracker.diff(self._initial_snapshot)

        # Convert to sets for comparison
        current_added = set(changes.added)
        current_modified = set(changes.modified)

        # Filter infrastructure files
        current_added = self._filter_fn(current_added)
        current_modified = self._filter_fn(current_modified)

        # Find newly detected changes (not yet reported)
        new_added = current_added - self._reported_added
        new_modified = current_modified - self._reported_modified

        # Update what we've reported
        self._reported_added.update(new_added)
        self._reported_modified.update(new_modified)

        new_count = len(new_added) + len(new_modified)
        return FileChangeSet(added=new_added, modified=new_modified, count=new_count)

    def get_total_count(self) -> int:
        """Get total count of all tracked file changes.

        Returns the cumulative count of added + modified files detected
        since the tracker was initialized.
        """
        return len(self._reported_added) + len(self._reported_modified)


class HeartbeatThread(threading.Thread):
    """Background thread that emits heartbeat messages during long-running execution.

    Additionally, it emits liveness_check events via log_event callback.
    """

    def __init__(
        self,
        item_id: str,
        emitter: ProgressEmitter,
        file_tracker: FileChangeTracker,
        working_dir: Path,
        count_lines_fn: Callable[[str], int | None],
        interval: int,
        initial_delay: int,
        stop_event: threading.Event,
        log_event: Callable[..., None] | None = None,
        session_id: str | None = None,
        trace_id: str | None = None,
    ) -> None:
        """Initialize HeartbeatThread.

        Args:
            item_id: ID of the plan item being executed
            emitter: ProgressEmitter for output
            file_tracker: FileChangeTracker for detecting file changes
            working_dir: Working directory for log file detection
            count_lines_fn: Callback for counting lines in a file
            interval: Base interval between heartbeats (seconds)
            initial_delay: Delay before first heartbeat (seconds)
            stop_event: Event to signal thread should stop
            log_event: Optional callback for emitting liveness_check events
            session_id: Optional session ID for trace correlation
            trace_id: Optional trace ID for distributed tracing
        """
        super().__init__(daemon=True)
        self._item_id = item_id
        self._emitter = emitter
        self._file_tracker = file_tracker
        self._working_dir = working_dir
        self._count_lines_fn = count_lines_fn
        self._interval = interval
        self._initial_delay = initial_delay
        self._stop_event = stop_event
        self._log_event = log_event
        self._session_id = session_id
        self._trace_id = trace_id
        self._start_time = time.time()
        self._alive_count = 0

    def run(self) -> None:
        """Main thread loop - emits heartbeats and file events until stopped.

        Every 180 seconds, emits liveness_check event via log_event callback.
        """
        self._stop_event.wait(self._initial_delay)

        # Track last liveness check time
        last_liveness_check = time.time()

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            file_count = self._get_file_count()

            # S4.T1: Get liveness indicators at DETAIL verbosity level
            liveness_indicators = None
            if self._emitter.config.verbosity >= VerbosityLevel.DETAIL:
                liveness_indicators = self._get_liveness_indicators()

            # Emit heartbeat with liveness indicators at DETAIL level
            self._emitter.item_heartbeat(self._item_id, elapsed, file_count, liveness_indicators)

            # S3.T1: Emit liveness_check event every LIVENESS_CHECK_INTERVAL_S
            current_time = time.time()
            if (
                self._log_event
                and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S
            ):
                indicators = self._get_liveness_indicators()
                # Calculate status: "active" if any indicator is True, else "idle"
                status = "active" if any(indicators.values()) else "idle"
                self._alive_count += 1

                self._log_event(
                    "liveness_check",
                    status=status,
                    alive_count=self._alive_count,
                    indicators=indicators,
                    elapsed_seconds=elapsed,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                )
                last_liveness_check = current_time

            changes = self._file_tracker.poll()
            if changes.count > 0:
                for filepath in changes.added:
                    line_count = self._count_lines_fn(filepath)
                    self._emitter.file_event(filepath, "new", line_count)
                for filepath in changes.modified:
                    line_count = self._count_lines_fn(filepath)
                    self._emitter.file_event(filepath, "modified", line_count)
            self._stop_event.wait(self._interval)

    def _get_file_count(self) -> int:
        """Get current count of changed files.

        FIX-FILE-TRACKING-001: Uses FileChangeTracker instead of git commands.
        """
        return self._file_tracker.get_total_count()

    def _get_liveness_indicators(self) -> dict[str, bool]:
        """Get liveness indicators showing agent activity.

        Returns a dict with boolean indicators for:
        - files: Files being modified in workspace
        - log: Log files being written to
        - proc: Process is running
        - cpu: CPU activity (requires psutil, graceful degradation)
        - db: Database updates (placeholder for future implementation)

        Returns:
            Dict mapping indicator names to boolean active status
        """
        indicators = {
            "files": False,
            "log": False,
            "proc": True,  # If we're in heartbeat loop, process is running
            "cpu": False,  # Requires psutil, graceful degradation
            "db": False,  # Placeholder - would need StateManager integration
        }

        # Check if files have been modified
        file_count = self._get_file_count()
        indicators["files"] = file_count > 0

        # Check if log files have been written to recently
        # Look for .log or .jsonl files modified in the last interval
        try:
            working_dir = self._working_dir
            current_time = time.time()
            log_activity = False

            # Check common log file patterns
            for pattern in ["*.log", "*.jsonl"]:
                for log_file in working_dir.glob(f"**/{pattern}"):
                    if log_file.is_file():
                        # Check if modified within last interval (+ some buffer)
                        mtime = log_file.stat().st_mtime
                        if current_time - mtime < (self._interval * 2):
                            log_activity = True
                            break
                if log_activity:
                    break

            indicators["log"] = log_activity
        except Exception:
            # If log checking fails, just report False
            pass

        # S3.T2: Check CPU activity via psutil (optional dependency)
        try:
            import psutil  # type: ignore[import-untyped]

            # Get CPU usage over a short interval
            # cpu_percent() with interval returns average CPU usage over that period
            # Using 0.1 seconds to avoid blocking the heartbeat thread
            cpu_percent = psutil.cpu_percent(interval=0.1)
            # Consider CPU active if usage is above 5% (low threshold for any activity)
            indicators["cpu"] = cpu_percent > 5.0
        except ImportError:
            # psutil not available - graceful degradation
            pass
        except Exception:
            # Any other error - graceful degradation
            pass

        return indicators

    def stop(self) -> None:
        """Signal the thread to stop and wait for it to exit."""
        self._stop_event.set()
        self.join(timeout=get_timeout("handler", "thread_join_s"))


class AgentDeployer:
    """Deploys implementation agents to apply fixes via subprocess.

    Encapsulates the agent deployment logic extracted from FixHandler._deploy_agent,
    including heartbeat thread management, interactive guard handling, and workspace
    rollback on failure.

    Construction:
        Created per-fix-handler in FixHandler.__init__ with callbacks for
        filter_infrastructure_files and count_lines. Worker-local instances
        are created in _execute_batch_parallel_worker for thread isolation.
    """

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any],
        session_id: str | None,
        log_file: Path | None,
        trace_id: str | None,
        log_event: Any | None,
        parent_span_id: str | None,
        observability_config: ObservabilityConfig | None,
        progress_emitter: ProgressEmitter | None,
        on_stream: StreamCallback,
        process_registry: Any | None,
        config: dict[str, Any],
        observability_env: dict[str, str],
        filter_infrastructure_files: Callable[[set[str]], set[str]],
        count_lines: Callable[[str], int | None],
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._session_id = session_id
        self._log_file = log_file
        self._trace_id = trace_id
        self._log_event = log_event
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._on_stream = on_stream
        self._process_registry = process_registry
        self._config = config
        self._observability_env = observability_env
        self._filter_infrastructure_files = filter_infrastructure_files
        self._count_lines_fn = count_lines
        self._file_tracker = FileStateTracker(working_dir)

    def deploy(self, prompt: str, *, timeout_s: int | None = None) -> dict[str, Any]:
        """Deploy implementation agent to apply fix via subprocess.

        Delegates to unified LLM subprocess runner for command building,
        execution, retry logic, and error handling.

        Args:
            prompt: Fix prompt
            timeout_s: Optional timeout override in seconds

        Returns:
            Agent result dictionary with status, summary, files_modified
        """
        from obra.llm.subprocess_runner import LLMSubprocessConfig, run_llm_subprocess

        logger.debug("Deploying implementation agent for fix")

        # Extract provider and model from config
        bypass_sandbox = False
        approval_mode: str | None = None
        from obra.config.llm import DEFAULT_REASONING_LEVEL

        if self._llm_config:
            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            reasoning_level = self._llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")
            # BUG-e100a87e: skip_git_check only applies to OpenAI Codex
            # For other providers, always False
            if provider == "openai":
                git_config: dict[str, Any] = self._llm_config.get("git", {})
                skip_git_check = git_config.get("skip_check", True)  # Default True for OpenAI
                # BUG-a377298b: Extract codex config to pass approval_mode
                # Without this, Codex may use approval_policy=never which forces read-only sandbox
                codex_config: dict[str, Any] = self._llm_config.get("codex", {})
                bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
                approval_mode = codex_config.get("approval_mode")
            else:
                skip_git_check = False  # Not applicable to non-OpenAI providers
        else:
            # Fallback to defaults if no config
            provider = "anthropic"
            model = "default"
            reasoning_level = DEFAULT_REASONING_LEVEL
            auth_method = "oauth"
            skip_git_check = False

        timeout_s = timeout_s or get_agent_execution_timeout()
        error_message: str | None = None

        # S3.T0/S3.T1: Set up heartbeat thread if progress emitter is available
        heartbeat_thread: HeartbeatThread | None = None
        stop_event: threading.Event | None = None

        if self._progress_emitter and self._observability_config:
            # Calculate scaled interval based on verbosity
            # QUIET (0): 3x base, PROGRESS (1): 1x base, DETAIL (2+): 0.5x base
            base_interval = get_heartbeat_interval()
            verbosity = self._observability_config.verbosity

            if verbosity == 0:  # QUIET
                scaled_interval = base_interval * 3
            elif verbosity == 1:  # PROGRESS
                scaled_interval = base_interval
            else:  # DETAIL (2+)
                scaled_interval = int(base_interval * 0.5)

            # Get initial delay
            initial_delay = get_heartbeat_initial_delay()

            # Create file change tracker
            file_tracker = FileChangeTracker(self._file_tracker, self._filter_infrastructure_files)

            # Create and start heartbeat thread
            stop_event = threading.Event()
            item_id = "fix"
            # S3.T4: Pass log_event, session_id, trace_id to HeartbeatThread
            heartbeat_thread = HeartbeatThread(
                item_id=item_id,
                emitter=self._progress_emitter,
                file_tracker=file_tracker,
                working_dir=self._working_dir,
                count_lines_fn=self._count_lines_fn,
                interval=scaled_interval,
                initial_delay=initial_delay,
                stop_event=stop_event,
                log_event=self._log_event,
                session_id=self._session_id,
                trace_id=self._trace_id,
            )
            heartbeat_thread.start()
            logger.debug(
                f"Started heartbeat thread: interval={scaled_interval}s, "
                f"initial_delay={initial_delay}s, verbosity={verbosity}"
            )

        rollback_enabled = get_interactive_guard_rollback_enabled()
        rollback_codes = get_interactive_guard_rollback_codes()
        retry_max = max(0, get_interactive_guard_retry_max())
        rollback_store = None
        rollback_snapshot = None

        if rollback_enabled:
            rollback_store = WorkspaceRollbackStore(
                self._working_dir,
                run_id=self._session_id or "fix",
            )
            rollback_snapshot = rollback_store.capture()

        try:
            # Adapter for on_stream callback: subprocess_runner expects (line),
            # but fix.py's self._on_stream expects (event_type, line)
            def stream_adapter(line: str) -> None:
                if self._on_stream:
                    self._on_stream("llm_streaming", line.rstrip("\n"))

            attempt = 0
            current_prompt = prompt
            last_error_message: str | None = None
            while True:
                # Build configuration for shared subprocess runner
                # FIX-BATCH-STALL-001: Disable stream idle timeout for fix operations.
                # When fixing multiple issues in a large file, the LLM may be silent for
                # extended periods during file editing. The overall timeout_s still applies.
                config = LLMSubprocessConfig(
                    prompt=current_prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    reasoning_level=reasoning_level,
                    auth_method=auth_method,
                    timeout_s=timeout_s,
                    stream_idle_timeout_s=0,  # Disable idle timeout for file editing
                    skip_git_check=skip_git_check,
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                    retry_enabled=True,
                    streaming=True,  # Fix handler always uses streaming
                    on_stream=stream_adapter if self._on_stream else None,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="fix",
                    monitoring_context=None,  # Monitoring context not currently supported
                    session_id=self._session_id,
                    run_id=self._session_id,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                    mode="execute",  # ISSUE-EXEC-003: Execute mode - no --print, allows file writes
                )

                # Execute via shared subprocess runner
                result = run_llm_subprocess(config)

                # Check result
                if result.success:
                    return {
                        "status": "success",
                        "summary": "Fix applied successfully",
                        "files_modified": [],  # Would parse git diff in production
                    }
                # Execution failed
                error_message = result.error or "Unknown error"
                if result.failure_class and "failure_class=" not in error_message:
                    error_message = f"{error_message} (failure_class={result.failure_class})"
                if result.error_details and result.error_details.request_id:
                    if "request_id=" not in error_message:
                        error_message = (
                            f"{error_message} (request_id={result.error_details.request_id})"
                        )
                if result.retry_count and "retries=" not in error_message:
                    error_message = f"{error_message} (retries={result.retry_count})"
                if last_error_message == error_message and attempt >= 1:
                    logger.warning(
                        "Stopping fix retry due to identical failure payload: %s",
                        error_message,
                    )
                    return {
                        "status": "failed",
                        "summary": f"Fix failed: {error_message}",
                        "files_modified": [],
                    }
                last_error_message = error_message
                matched_code, matched_line = self._match_rollback_code(
                    error_message,
                    rollback_codes,
                )
                interactive_failure = result.interactive_failure
                if not interactive_failure:
                    interactive_failure = extract_interactive_failure(error_message, None)
                sanitized_line = sanitize_interactive_line(
                    interactive_failure.line if interactive_failure else None
                )
                if interactive_failure:
                    message = "Interactive guard blocked an interactive prompt."
                    if sanitized_line:
                        message = f"{message} ({sanitized_line.line})"
                    if self._log_event:
                        self._log_event(
                            "interactive_guard_triggered",
                            code=interactive_failure.code,
                            pattern_id=interactive_failure.pattern_id,
                            matched_line=sanitized_line.line if sanitized_line else "",
                            line_redacted=(sanitized_line.redacted if sanitized_line else False),
                            line_truncated=(sanitized_line.truncated if sanitized_line else False),
                            source=interactive_failure.source,
                            handler="fix",
                            attempt=attempt,
                            attempt_number=attempt + 1,
                            retry_max=retry_max,
                            rollback_enabled=rollback_enabled,
                            rollback_code_matched=bool(matched_code),
                            will_retry=bool(
                                matched_code and rollback_enabled and attempt < retry_max
                            ),
                            message=message,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                        )
                    logger.warning(
                        "Interactive guard triggered in fix: code=%s attempt=%d/%d line=%s",
                        interactive_failure.code,
                        attempt,
                        retry_max,
                        sanitized_line.line if sanitized_line else "",
                    )
                    if self._progress_emitter:
                        self._progress_emitter.interactive_guard_notice(message)
                if rollback_enabled and rollback_store and rollback_snapshot and matched_code:
                    rollback_store.restore(rollback_snapshot)
                    if self._log_event:
                        changes = rollback_snapshot.changes
                        self._log_event(
                            "interactive_guard_rollback",
                            code=matched_code,
                            pattern_id=(
                                interactive_failure.pattern_id if interactive_failure else None
                            ),
                            matched_line=sanitized_line.line if sanitized_line else "",
                            line_redacted=(sanitized_line.redacted if sanitized_line else False),
                            line_truncated=(sanitized_line.truncated if sanitized_line else False),
                            source=(interactive_failure.source if interactive_failure else None),
                            handler="fix",
                            attempt=attempt,
                            attempt_number=attempt + 1,
                            retry_max=retry_max,
                            added_count=len(changes.added) if changes else 0,
                            modified_count=len(changes.modified) if changes else 0,
                            deleted_count=len(changes.deleted) if changes else 0,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            message="Workspace rolled back after interactive prompt.",
                        )
                    if self._progress_emitter:
                        self._progress_emitter.interactive_guard_notice(
                            "Interactive guard triggered; workspace rolled back."
                        )
                    if attempt < retry_max:
                        recovery_banner = build_interactive_recovery_banner(
                            interactive_failure.line if interactive_failure else matched_line
                        )
                        current_prompt = f"{recovery_banner}\n\n{prompt}"
                        if self._log_event:
                            self._log_event(
                                "interactive_guard_retry",
                                code=matched_code,
                                pattern_id=(
                                    interactive_failure.pattern_id if interactive_failure else None
                                ),
                                matched_line=(sanitized_line.line if sanitized_line else ""),
                                line_redacted=(
                                    sanitized_line.redacted if sanitized_line else False
                                ),
                                line_truncated=(
                                    sanitized_line.truncated if sanitized_line else False
                                ),
                                source=(
                                    interactive_failure.source if interactive_failure else None
                                ),
                                handler="fix",
                                attempt=attempt + 1,
                                attempt_number=attempt + 2,
                                retry_max=retry_max,
                                session_id=self._session_id,
                                trace_id=self._trace_id,
                                message=f"Retrying after interactive guard ({attempt + 1}/{retry_max}).",
                            )
                        if self._progress_emitter:
                            self._progress_emitter.interactive_guard_notice(
                                f"Retrying after interactive guard ({attempt + 1}/{retry_max})."
                            )
                        attempt += 1
                        continue
                return {
                    "status": "failed",
                    "summary": f"Fix failed: {error_message}",
                    "files_modified": [],
                }

        except Exception as e:
            logger.exception(f"Fix agent deployment failed: {e}")
            error_message = str(e)
            return {
                "status": "failed",
                "summary": f"Deployment failed: {e!s}",
                "files_modified": [],
            }
        finally:
            # S3.T0: Stop heartbeat thread if it was started
            if heartbeat_thread and stop_event:
                logger.debug("Stopping heartbeat thread")
                heartbeat_thread.stop()

    @staticmethod
    def _match_rollback_code(
        error_message: str,
        rollback_codes: list[str],
    ) -> tuple[str | None, str | None]:
        """Extract rollback code and matched line from error message."""
        for code in rollback_codes:
            if error_message.startswith(code):
                remainder = error_message[len(code):].lstrip(": ").strip()
                if not remainder:
                    return code, ""
                parts = remainder.split(":", 1)
                if len(parts) == 2:
                    return code, parts[1].strip()
                return code, remainder.strip()
        return None, None


__all__ = ["AgentDeployer", "FileChangeSet", "FileChangeTracker", "HeartbeatThread"]
