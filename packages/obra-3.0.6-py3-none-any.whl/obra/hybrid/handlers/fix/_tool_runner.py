"""Verification tool execution helpers."""

from __future__ import annotations

import os
import re
import shlex
import subprocess
from pathlib import Path
from typing import Any

from obra.config import DEFAULT_NETWORK_TIMEOUT


class VerificationToolRunner:
    """Run scoped or unscoped verification tools and capture metadata."""

    def __init__(
        self,
        working_dir: Path,
        subprocess_runner: Any | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._subprocess_runner = subprocess_runner
        self.last_run_metadata: dict[str, Any] | None = None

    def run_tool(
        self,
        tool_config: dict[str, Any],
        *,
        files: list[str] | None = None,
    ) -> tuple[bool | None, str, str, str]:
        """Execute a single verification tool command."""
        command = tool_config.get("command")
        raw_files = files or []
        resolved_files, scope_resolution = self.normalize_targets(raw_files)
        if not command:
            self.last_run_metadata = self.build_run_metadata(
                tool_config,
                formatted_command="",
                files=resolved_files,
            )
            self.last_run_metadata["scope_resolution"] = scope_resolution
            self.last_run_metadata["execution_status"] = "unavailable"
            return None, "", "", ""

        files_arg = " ".join(shlex.quote(target) for target in resolved_files)
        scope_type = tool_config.get("scope_type", "unscoped")
        has_placeholders = "{files}" in command or "{paths}" in command
        if scope_type == "scoped" and has_placeholders and not files_arg.strip():
            run_metadata = self.build_run_metadata(
                tool_config,
                formatted_command="",
                files=resolved_files,
            )
            run_metadata["scope_resolution"] = scope_resolution
            run_metadata["execution_status"] = (
                "skipped_no_files" if not raw_files else "scope_resolution_failed"
            )
            self.last_run_metadata = run_metadata
            return None, "", tool_config.get("name", ""), tool_config.get("parser", "")

        formatted = command.format(files=files_arg, paths=files_arg)
        formatted_stripped = formatted.strip()
        if has_placeholders and formatted_stripped == command.split("{")[0].strip():
            run_metadata = self.build_run_metadata(
                tool_config,
                formatted_command=formatted,
                files=resolved_files,
            )
            run_metadata["scope_resolution"] = scope_resolution
            run_metadata["execution_status"] = "skipped_empty_target"
            self.last_run_metadata = run_metadata
            return None, "", tool_config.get("name", ""), tool_config.get("parser", "")

        run_metadata = self.build_run_metadata(
            tool_config,
            formatted_command=formatted,
            files=resolved_files,
        )
        run_metadata["scope_resolution"] = scope_resolution
        try:
            cmd = shlex.split(formatted)
        except ValueError:
            run_metadata["execution_status"] = "error"
            self.last_run_metadata = run_metadata
            return None, "", "", ""

        timeout_s = tool_config.get("timeout_s", DEFAULT_NETWORK_TIMEOUT)
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH", "")
        working_dir_str = str(self._working_dir)
        if working_dir_str not in existing_pythonpath.split(os.pathsep):
            env["PYTHONPATH"] = (
                f"{working_dir_str}{os.pathsep}{existing_pythonpath}"
                if existing_pythonpath
                else working_dir_str
            )

        try:
            runner = self._subprocess_runner or subprocess.run
            result = runner(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout_s,
                cwd=self._working_dir,
                env=env,
            )
            output = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
            run_metadata["execution_status"] = "passed" if result.returncode == 0 else "failed"
            if output:
                run_metadata["output_excerpt"] = output.strip()[:800]
            self.last_run_metadata = run_metadata
            return (
                result.returncode == 0,
                output.strip(),
                tool_config.get("name", ""),
                tool_config.get("parser", ""),
            )
        except FileNotFoundError:
            run_metadata["execution_status"] = "unavailable"
            self.last_run_metadata = run_metadata
            return None, "", tool_config.get("name", ""), tool_config.get("parser", "")
        except subprocess.TimeoutExpired:
            run_metadata["execution_status"] = "timeout"
            self.last_run_metadata = run_metadata
            return False, "", tool_config.get("name", ""), tool_config.get("parser", "")
        except Exception:
            run_metadata["execution_status"] = "error"
            self.last_run_metadata = run_metadata
            return False, "", tool_config.get("name", ""), tool_config.get("parser", "")

    def normalize_targets(self, files: list[str]) -> tuple[list[str], dict[str, int]]:
        """Canonicalize verification targets for scoped command interpolation."""
        workspace_root = self._working_dir.resolve()
        normalized: list[str] = []
        seen: set[str] = set()
        dropped = 0

        for raw_target in files:
            cleaned = self.clean_target(str(raw_target))
            if not cleaned:
                dropped += 1
                continue

            path_part = cleaned
            selector = ""
            if "::" in cleaned:
                path_part, selector = cleaned.split("::", 1)
                selector = selector.strip()

            path_part = re.sub(r":\d+(?::\d+)?$", "", path_part.strip())
            if not path_part:
                dropped += 1
                continue

            normalized_target = path_part
            if self.looks_like_path(path_part):
                candidate = Path(path_part).expanduser()
                resolved = (
                    candidate.resolve(strict=False)
                    if candidate.is_absolute()
                    else (workspace_root / candidate).resolve(strict=False)
                )
                try:
                    relative = resolved.relative_to(workspace_root)
                except ValueError:
                    dropped += 1
                    continue
                normalized_target = relative.as_posix()

            if selector:
                normalized_target = f"{normalized_target}::{selector}"
            if normalized_target and normalized_target not in seen:
                normalized.append(normalized_target)
                seen.add(normalized_target)

        return normalized, {
            "input_count": len(files),
            "normalized_count": len(normalized),
            "dropped_count": dropped,
        }

    def build_run_metadata(
        self,
        tool: dict[str, Any],
        *,
        formatted_command: str,
        files: list[str],
    ) -> dict[str, Any]:
        """Build run metadata dict for a verification tool invocation."""
        normalized_tool = self.normalize_tool(tool, default_source="runtime")
        scope_type = str(normalized_tool.get("scope_type") or "unscoped")
        discovery_source = str(normalized_tool.get("discovery_source", "runtime")).lower()
        low_certainty_source = discovery_source in {"fallback_default", "auto"}
        if scope_type == "scoped" and files and not low_certainty_source:
            attribution_confidence = "high"
        elif scope_type == "scoped":
            attribution_confidence = "medium"
        else:
            attribution_confidence = "low"

        return {
            "tool": str(normalized_tool.get("name", "") or "unknown"),
            "category": str(normalized_tool.get("category", "") or ""),
            "command": formatted_command or str(normalized_tool.get("command", "") or ""),
            "target_files": files or self.coerce_string_list(normalized_tool.get("target_files")),
            "scope_type": scope_type,
            "discovery_source": str(normalized_tool.get("discovery_source", "runtime")),
            "attribution_confidence": attribution_confidence,
        }

    def normalize_tool(
        self,
        tool: dict[str, Any],
        *,
        default_source: str,
    ) -> dict[str, Any]:
        """Normalize a verification tool dict and infer defaults."""
        normalized = dict(tool)
        command = str(tool.get("command", "") or "").strip()
        scope_type = str(tool.get("scope_type", "") or "").strip().lower()
        if scope_type not in {"scoped", "unscoped"}:
            scope_type = self.infer_scope_type(command)

        patterns = self.coerce_string_list(tool.get("patterns", []))
        target_files = self.coerce_string_list(tool.get("target_files", tool.get("targets", patterns)))
        discovery_source = str(tool.get("discovery_source") or default_source).strip() or default_source

        normalized["command"] = command
        normalized["patterns"] = patterns
        normalized["target_files"] = target_files
        normalized["scope_type"] = scope_type
        normalized["discovery_source"] = discovery_source
        return normalized

    @staticmethod
    def clean_target(raw_target: str) -> str:
        """Normalize basic formatting wrappers around verification targets."""
        target = str(raw_target or "").strip()
        if not target:
            return ""
        if target.startswith("- ") or target.startswith("* "):
            target = target[2:].strip()

        markdown_match = re.match(r"^\[[^\]]+\]\(([^)]+)\)$", target)
        if markdown_match:
            target = markdown_match.group(1).strip()

        for left, right in (("`", "`"), ('"', '"'), ("'", "'"), ("(", ")")):
            if len(target) >= 2 and target.startswith(left) and target.endswith(right):
                target = target[1:-1].strip()

        return target.rstrip(",.;")

    @staticmethod
    def looks_like_path(target: str) -> bool:
        """Return True when a verification target likely refers to a filesystem path."""
        if not target:
            return False
        if target.startswith(("/", "./", "../", "~")):
            return True
        if "/" in target or "\\" in target:
            return True
        return "." in Path(target).name

    @staticmethod
    def coerce_string_list(value: Any) -> list[str]:
        """Coerce a value to a list of non-empty strings."""
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list):
            return []
        normalized: list[str] = []
        for entry in value:
            if isinstance(entry, str):
                cleaned = entry.strip()
                if cleaned:
                    normalized.append(cleaned)
        return normalized

    @staticmethod
    def infer_scope_type(command: str) -> str:
        """Infer scope type from command template."""
        normalized = " ".join(command.strip().split())
        if not normalized:
            return "unscoped"
        if "{files}" in normalized or "{paths}" in normalized:
            return "scoped"

        repo_wide_tokens = {".", "./", "./...", "...", "--all", "--all-files", "--all-targets"}
        parts = normalized.split()
        if any(token in repo_wide_tokens for token in parts):
            return "unscoped"
        return "unscoped"
