"""Verification outcome classification helpers."""

from __future__ import annotations

from typing import Any


class VerificationOutcomeClassifier:
    """Classify verification results and build reporting metadata."""

    def classify(
        self,
        *,
        verification: dict[str, Any],
        ran_tool_checks: bool,
    ) -> tuple[str, str, str, str]:
        """Classify the overall verification outcome."""
        verification_runs = verification.get("verification_runs", {})
        run_values = list(verification_runs.values()) if isinstance(verification_runs, dict) else []
        failed_runs = [
            run for run in run_values if str(run.get("execution_status", "")).lower() == "failed"
        ]
        attributable_failed_runs = [
            run
            for run in failed_runs
            if str(run.get("scope_type", "")).lower() == "scoped"
            and str(run.get("attribution_confidence", "")).lower() == "high"
        ]
        unscoped_failed_runs = [
            run for run in failed_runs if str(run.get("scope_type", "")).lower() != "scoped"
        ]
        zero_test_discovery_markers = (
            "ran 0 tests",
            "no tests ran",
            "no tests found",
            "collected 0 items",
            "no test files",
            "test discovery found 0",
        )
        has_zero_test_discovery = any(
            any(marker in str(run.get("output_excerpt", "")).lower() for marker in zero_test_discovery_markers)
            for run in run_values
        )

        if not verification.get("agent_succeeded"):
            return "failed", "agent_failed", "scoped", "high"
        if verification.get("target_test_file_modified") is False:
            return "failed", "target_file_unmodified", "scoped", "high"
        if has_zero_test_discovery:
            return "failed", "test_discovery_empty", "unscoped", "high"
        if attributable_failed_runs:
            return "failed", "scoped_verification_failed", "scoped", "high"
        if failed_runs:
            if unscoped_failed_runs:
                return "inconclusive", "unscoped_command", "unscoped", "low"
            return "inconclusive", "non_attributable_failure", "scoped", "low"
        if not ran_tool_checks:
            return "inconclusive", "no_verification_tools", "unscoped", "none"
        if verification.get("all_passed"):
            scoped_runs = [
                run for run in run_values if str(run.get("scope_type", "")).lower() == "scoped"
            ]
            if scoped_runs:
                return "passed", "verification_passed", "scoped", "high"
            return "passed", "verification_passed", "unscoped", "medium"
        return "inconclusive", "verification_inconclusive", "unscoped", "low"

    def capture_run(
        self,
        last_run_metadata: dict[str, Any] | None,
        *,
        check: str,
        passed: bool | None,
        fallback_tool: str,
    ) -> dict[str, Any]:
        """Build a verification run record from the last run metadata."""
        metadata = dict(last_run_metadata or {})
        metadata.setdefault("tool", fallback_tool)
        metadata.setdefault("category", check)
        metadata.setdefault("command", "")
        metadata.setdefault("target_files", [])
        metadata.setdefault("scope_type", "unscoped")
        metadata.setdefault("discovery_source", "runtime")
        metadata.setdefault("attribution_confidence", "none")
        if passed is True:
            metadata["execution_status"] = "passed"
        elif passed is False:
            metadata["execution_status"] = "failed"
        else:
            metadata["execution_status"] = metadata.get("execution_status", "unavailable")
        return metadata

    def match_rollback_code(
        self,
        error_message: str,
        rollback_codes: list[str],
    ) -> tuple[str | None, str | None]:
        """Extract rollback code and matched line from an error message."""
        for code in rollback_codes:
            if error_message.startswith(code):
                remainder = error_message[len(code):].lstrip(": ").strip()
                if not remainder:
                    return code, ""
                parts = remainder.split(":", 1)
                if len(parts) == 2:
                    return code, parts[1].strip()
                return code, remainder.strip()
        return None, None

    @staticmethod
    def summarize_lint_output(output: str) -> str | None:
        """Summarize lint output for short, user-friendly display."""
        if not output:
            return None
        for line in output.splitlines():
            stripped = line.strip()
            if stripped:
                if len(stripped) > 160:
                    return f"{stripped[:157]}..."
                return stripped
        return None

    @staticmethod
    def build_promoted_defect_issue(
        issue: dict[str, Any],
        *,
        output: str,
    ) -> dict[str, Any]:
        """Build a promoted defect issue from a failed test-gap verification."""
        issue_id = issue.get("id", "unknown")
        file_path = issue.get("file_path") or issue.get("file")
        line_number = issue.get("line_number") or issue.get("line")
        priority = issue.get("priority", "P1")
        description = (
            "Promotion: tests failed after coverage-gap fix. "
            "Update production code to satisfy the test expectations."
        )
        return {
            "id": f"{issue_id}-PROMO",
            "priority": priority,
            "description": description,
            "category": issue.get("category", "testing"),
            "file_path": file_path,
            "line_number": line_number,
            "issue_kind": "defect",
            "resolution_path": "code_and_tests",
            "verification_scope": "tests",
            "metadata": {
                "promoted_from": issue_id,
                "promotion_reason": "tests_failed",
                "promotion_output": output[:800],
                "promotion_attempted": True,
            },
        }
