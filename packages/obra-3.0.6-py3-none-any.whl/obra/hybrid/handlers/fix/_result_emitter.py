"""Result emission for fix handler.

Delegates fix-result display, progress, and decision events
to FixDisplay and emitters.
"""

from typing import Any

from obra.hybrid.handlers.fix._display import FixDisplay
from obra.hybrid.handlers.fix._verification import VerificationPipeline


class ResultEmitter:
    """Emits fix results, progress, and decision events.

    Extracted from FixHandler to isolate result-emission/display
    concerns from the main fix orchestration loop.
    """

    def __init__(
        self,
        display: FixDisplay,
        verification: VerificationPipeline | None,
        progress_emitter: Any | None,
        log_event: Any | None,
    ) -> None:
        self._display = display
        self._verification = verification
        self._progress_emitter = progress_emitter
        self._log_event = log_event

    def emit_progress(self, message: str) -> None:
        """Delegation shim — see _display.FixDisplay.emit_progress."""
        return self._display.emit_progress(message)

    def emit_decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Delegation shim — see _display.FixDisplay.emit_decision_event."""
        return self._display.emit_decision_event(event_type, data)

    @staticmethod
    def resolve_fix_result_severity(
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> str:
        """Delegation shim — see _display.FixDisplay.resolve_fix_result_severity."""
        return FixDisplay.resolve_fix_result_severity(result, issue)

    def emit_fix_result_line(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> tuple[int, int, int]:
        """Delegation shim — see _display.FixDisplay.emit_fix_result_line."""
        return self._display.emit_fix_result_line(issue_id=issue_id, result=result, issue=issue)

    def emit_fix_result_event(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        status: str,
    ) -> None:
        """Delegation shim — see _display.FixDisplay.emit_fix_result_event."""
        return self._display.emit_fix_result_event(issue_id=issue_id, result=result, status=status)

    def print_issue_index(self, issues: list[dict[str, Any]], ordered_ids: list[str]) -> None:
        """Delegation shim — see _display.FixDisplay.print_issue_index."""
        return self._display.print_issue_index(issues, ordered_ids)

    def print_issue_progress(self, issue: dict[str, Any], index: int, total: int) -> None:
        """Delegation shim — see _display.FixDisplay.print_issue_progress."""
        return self._display.print_issue_progress(issue, index, total)

    def print_batch_progress(
        self,
        batch: dict[str, Any],
        *,
        batch_index: int,
        total_batches: int,
    ) -> None:
        """Delegation shim — see _display.FixDisplay.print_batch_progress."""
        return self._display.print_batch_progress(batch, batch_index=batch_index, total_batches=total_batches)

    @staticmethod
    def format_issue_summary(issue: dict[str, Any]) -> str:
        """Delegation shim — see _display.FixDisplay.format_issue_summary."""
        return FixDisplay.format_issue_summary(issue)

    @staticmethod
    def format_failure_reason(result: dict[str, Any]) -> str | None:
        """Delegation shim — see _display.FixDisplay.format_failure_reason."""
        return FixDisplay.format_failure_reason(result)

    def print_fix_summary(
        self,
        *,
        fixed_count: int,
        failed_count: int,
        skipped_count: int,
    ) -> None:
        """Delegation shim — see _display.FixDisplay.print_fix_summary."""
        last_lint_summary = (
            self._verification._last_lint_summary if self._verification is not None else None
        )
        lint_repeat_count = (
            self._verification._lint_repeat_count if self._verification is not None else 0
        )
        self._display.print_fix_summary(
            fixed_count=fixed_count,
            failed_count=failed_count,
            skipped_count=skipped_count,
            last_lint_summary=last_lint_summary,
            lint_repeat_count=lint_repeat_count,
        )
