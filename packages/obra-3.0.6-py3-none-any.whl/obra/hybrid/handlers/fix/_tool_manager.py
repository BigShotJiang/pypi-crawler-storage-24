"""Verification Tool Manager for FixHandler.

Manages discovery, loading, caching, and installation of verification tools.
"""

import contextlib
import logging
import subprocess
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.config import DEFAULT_NETWORK_TIMEOUT
from obra.display import print_info
from obra.display.observability import ProgressEmitter
from obra.hybrid.install_target import InstallTargetManager
from obra.validation.verification_tools import detect_installed_verification_categories

logger = logging.getLogger(__name__)


class VerificationToolManager:
    """Manages verification tool discovery, loading, caching, and installation."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        install_target: InstallTargetManager,
        llm_config: dict[str, Any],
        *,
        progress_emitter: ProgressEmitter | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        log_decisions: bool = True,
    ) -> None:
        self._working_dir = working_dir
        self._config = config
        self._install_target = install_target
        self._llm_config = llm_config
        self._progress_emitter = progress_emitter
        self._on_progress = on_progress
        self._log_decisions = log_decisions
        self._verification_tools: list[dict[str, Any]] | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_tools(self) -> list[dict[str, Any]]:
        """Load and cache verification tools."""
        return self._load_verification_tools()

    def get_tools(self) -> list[dict[str, Any]]:
        """Return cached tools (empty list if not yet loaded)."""
        return self._verification_tools or []

    def set_tools(self, tools: list[dict[str, Any]]) -> None:
        """Set verification tools directly (for auto-install flow)."""
        self._verification_tools = tools

    def install_if_needed(self, tool: str, ecosystem: str) -> bool:
        """Install a verification tool if allowed by policy."""
        return self._install_verification_tool(tool, ecosystem)

    def get_default_tools(self, installed_tools: list[str]) -> list[dict[str, Any]]:
        """Get default verification tool configs for installed packages."""
        return self._get_default_verification_tools(installed_tools)

    # ------------------------------------------------------------------
    # Emit helpers (mirror of FixHandler._emit_progress / _emit_decision_event)
    # ------------------------------------------------------------------

    def _emit_progress(self, message: str) -> None:
        if self._progress_emitter:
            self._progress_emitter.warning(message)
        else:
            print_info(message)

    def _emit_decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        if not self._on_progress or not self._log_decisions:
            return
        payload = {
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "mode": data.get("mode", self._config.get("automation_mode", "auto_safe")),
            "ecosystem": data.get("ecosystem"),
            "packages": data.get("packages"),
            "target": data.get("target"),
            "reason": data.get("reason"),
        }
        with contextlib.suppress(Exception):
            self._on_progress(event_type, payload)

    # ------------------------------------------------------------------
    # Tool loading
    # ------------------------------------------------------------------

    def _load_verification_tools(self) -> list[dict[str, Any]]:
        if self._verification_tools is not None:
            return self._verification_tools
        try:
            from obra.config.loaders import (
                get_verification_discovery_enabled,
                get_verification_force_refresh,
                load_layered_config,
            )
            from obra.hybrid.tooling_discovery import ToolingDiscovery

            config, _, _ = load_layered_config(include_defaults=True)
            tools = config.get("fix", {}).get("verification", {}).get("tools", [])
            if isinstance(tools, list) and tools:
                self._verification_tools = [
                    self._normalize_verification_tool(tool, default_source="config")
                    for tool in tools
                    if isinstance(tool, dict)
                ]
                return self._verification_tools

            if get_verification_discovery_enabled():
                discovery = ToolingDiscovery(self._working_dir, self._llm_config)
                tooling = discovery.discover(force_refresh=get_verification_force_refresh())
                self._verification_tools = self._convert_discovery_to_tools(tooling)
            else:
                self._verification_tools = []
            if not self._verification_tools:
                installed = detect_installed_verification_categories()
                if installed:
                    category_to_tool = {
                        "tests": "pytest",
                        "lint": "ruff",
                        "typecheck": "mypy",
                    }
                    tool_names = [
                        category_to_tool[category]
                        for category in installed
                        if category in category_to_tool
                    ]
                    if tool_names:
                        self._verification_tools = self._get_default_verification_tools(tool_names)
            self._verification_tools = [
                self._normalize_verification_tool(tool, default_source="auto")
                for tool in self._verification_tools
                if isinstance(tool, dict)
            ]
        except Exception as exc:
            logger.warning("Failed to load verification tools config: %s", exc)
            self._verification_tools = []
        return self._verification_tools

    def _get_default_verification_tools(self, installed_tools: list[str]) -> list[dict[str, Any]]:
        """Get default verification tool configs for installed packages.

        Used when auto-install succeeds but discovery doesn't find tool commands
        (e.g., new projects without pytest.ini or pyproject.toml [tool.pytest]).
        """
        defaults: dict[str, dict[str, Any]] = {
            "pytest": {
                "name": "tests",
                "category": "tests",
                "command": "pytest {files}",
                "parser": "llm",
                "patterns": ["test_*.py", "*_test.py"],
                "scope_type": "scoped",
                "target_files": ["test_*.py", "*_test.py"],
                "discovery_source": "fallback_default",
            },
            "ruff": {
                "name": "lint",
                "category": "lint",
                "command": "ruff check {files}",
                "parser": "llm",
                "patterns": ["*.py"],
                "scope_type": "scoped",
                "target_files": ["*.py"],
                "discovery_source": "fallback_default",
            },
            "mypy": {
                "name": "typecheck",
                "category": "typecheck",
                "command": "mypy {files}",
                "parser": "llm",
                "patterns": ["*.py"],
                "scope_type": "scoped",
                "target_files": ["*.py"],
                "discovery_source": "fallback_default",
            },
        }
        tools = []
        for tool_name in installed_tools:
            if tool_name in defaults:
                tools.append(defaults[tool_name])
        return tools

    # ------------------------------------------------------------------
    # Tool installation
    # ------------------------------------------------------------------

    def _install_verification_tool(self, tool: str, ecosystem: str) -> bool:
        auto_install = self._config.get("fix", {}).get("verification", {}).get("auto_install", True)
        mode = self._config.get("automation_mode", "auto_safe")
        if not auto_install:
            logger.info("[FIX] Auto-install disabled (automation_mode=%s)", mode)
            return False

        allowed, reason = self._should_install_tool(tool, "INFERRED", ecosystem)
        if not allowed:
            self._emit_progress(f"[FIX] Skipped: {tool} ({reason})")
            self._emit_decision_event(
                "package_skipped",
                {
                    "mode": self._config.get("automation_mode", "auto_safe"),
                    "ecosystem": ecosystem,
                    "packages": [tool],
                    "target": self._config.get("fix", {})
                    .get("verification", {})
                    .get("install_target", "project_local"),
                    "reason": reason,
                },
            )
            return False

        in_allowlist = self._is_tool_allowed(tool, ecosystem)
        if mode != "auto_full" and not in_allowlist:
            reason = (
                f"{tool} not in allowlist. Hint: Add to inferred_install_allowlist."
                f"{ecosystem} or use auto_full mode."
            )
            self._emit_progress(f"[FIX] Skipped: {tool} ({reason})")
            self._emit_decision_event(
                "package_skipped",
                {
                    "mode": mode,
                    "ecosystem": ecosystem,
                    "packages": [tool],
                    "target": self._config.get("fix", {})
                    .get("verification", {})
                    .get("install_target", "project_local"),
                    "reason": reason,
                },
            )
            return False

        preference = (
            self._config.get("story0", {})
            .get("package_manager_preference", {})
            .get(ecosystem, "auto")
        )
        target = (
            self._config.get("fix", {})
            .get("verification", {})
            .get("install_target", "project_local")
        )

        manager = self._install_target.get_package_manager(ecosystem, preference, self._working_dir)
        env_path = None
        if ecosystem == "python":
            toolchains = self._install_target.detect_toolchain(self._working_dir)
            python_toolchain = toolchains.get("python")
            env_path = python_toolchain.env_path if python_toolchain else None
        env_info_str = f"env={env_path}" if env_path else "env=none"
        self._emit_progress(f"[FIX] Install target: {target} (manager={manager}, {env_info_str})")

        cmd = self._install_target.build_install_command(
            ecosystem,
            [tool],
            target,
            manager,
            env_path,
        )

        timeout_s = (
            self._config.get("fix", {})
            .get("verification", {})
            .get("install_timeout_s", DEFAULT_NETWORK_TIMEOUT)
        )
        try:
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout_s,
                cwd=self._working_dir,
            )
        except subprocess.TimeoutExpired:
            self._emit_progress(f"[FIX] Install timed out: {tool}")
            return False

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or "Unknown error"
            self._emit_progress(f"[FIX] Install failed: {tool}\n{detail}")
            return False

        self._emit_progress(
            f"[FIX] Installed: {tool} (ecosystem={ecosystem}, allowlist={in_allowlist})"
        )
        self._emit_decision_event(
            "package_installed",
            {
                "mode": mode,
                "ecosystem": ecosystem,
                "packages": [tool],
                "target": target,
                "reason": "",
            },
        )
        return True

    def _is_tool_allowed(self, tool: str, ecosystem: str) -> bool:
        allowlist = self._config.get("inferred_install_allowlist", {})
        if not isinstance(allowlist, dict) or not allowlist:
            return True
        entries = []
        entries.extend(allowlist.get("_common", []))
        entries.extend(allowlist.get(ecosystem, []))
        tool_lower = tool.lower()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if str(entry.get("name") or "").lower() == tool_lower:
                return True
        return False

    def _should_install_tool(self, tool: str, source: str, ecosystem: str) -> tuple[bool, str]:
        policy = (
            self._config.get("fix", {})
            .get("verification", {})
            .get("install_policy", "manifest_then_inferred")
        )
        normalized_source = source.upper()

        if normalized_source == "INFERRED":
            self._emit_decision_event(
                "policy_applied",
                {
                    "mode": self._config.get("automation_mode", "auto_safe"),
                    "ecosystem": ecosystem,
                    "packages": [tool],
                    "target": self._config.get("fix", {})
                    .get("verification", {})
                    .get("install_target", "project_local"),
                    "reason": f"policy={policy}",
                },
            )

        if policy == "manifest_only" and normalized_source != "MANIFEST":
            logger.warning("[FIX] Blocked by policy: %s does not allow inferred installs", policy)
            self._emit_progress(
                f"[FIX] Blocked by policy: {policy} does not allow inferred installs"
            )
            return (
                False,
                "blocked by manifest_only policy. Hint: Use automation_mode=auto_full "
                "to allow inferred installs.",
            )
        if policy not in (
            "manifest_only",
            "manifest_then_inferred",
            "manifest_or_inferred",
        ):
            return False, f"unsupported install policy: {policy}"

        if normalized_source == "INFERRED" and policy == "manifest_then_inferred":
            return True, ""

        return True, ""

    # ------------------------------------------------------------------
    # Static helpers (also live on VerificationPipeline for verify methods)
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_discovery_to_tools(tooling: dict[str, Any]) -> list[dict[str, Any]]:
        if not tooling:
            return []
        tools: list[dict[str, Any]] = []
        verification = tooling.get("verification", {})
        test = verification.get("test", {})
        lint = verification.get("lint", {})
        typecheck = verification.get("typecheck", {})

        if isinstance(test, dict) and test.get("command"):
            tools.append(
                {
                    "name": "tests",
                    "category": "tests",
                    "command": test.get("command"),
                    "parser": "llm",
                    "patterns": test.get("patterns") or [],
                    "scope_type": test.get("scope_type"),
                    "target_files": test.get("target_files") or test.get("patterns") or [],
                    "discovery_source": test.get("discovery_source")
                    or tooling.get("_meta", {}).get("source")
                    or tooling.get("_meta", {}).get("discovery_method")
                    or "discovery",
                }
            )
        if isinstance(lint, dict) and lint.get("command"):
            tools.append(
                {
                    "name": "lint",
                    "category": "lint",
                    "command": lint.get("command"),
                    "parser": "llm",
                    "patterns": lint.get("patterns") or [],
                    "scope_type": lint.get("scope_type"),
                    "target_files": lint.get("target_files") or lint.get("patterns") or [],
                    "discovery_source": lint.get("discovery_source")
                    or tooling.get("_meta", {}).get("source")
                    or tooling.get("_meta", {}).get("discovery_method")
                    or "discovery",
                }
            )
        if isinstance(typecheck, dict) and typecheck.get("command"):
            tools.append(
                {
                    "name": "typecheck",
                    "category": "typecheck",
                    "command": typecheck.get("command"),
                    "parser": "llm",
                    "patterns": typecheck.get("patterns") or [],
                    "scope_type": typecheck.get("scope_type"),
                    "target_files": typecheck.get("target_files")
                    or typecheck.get("patterns")
                    or [],
                    "discovery_source": typecheck.get("discovery_source")
                    or tooling.get("_meta", {}).get("source")
                    or tooling.get("_meta", {}).get("discovery_method")
                    or "discovery",
                }
            )
        return tools

    @staticmethod
    def _coerce_string_list(value: Any) -> list[str]:
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list):
            return []
        normalized: list[str] = []
        for entry in value:
            if isinstance(entry, str):
                cleaned = entry.strip()
                if cleaned:
                    normalized.append(cleaned)
        return normalized

    @staticmethod
    def _infer_verification_scope_type(command: str) -> str:
        normalized = " ".join(command.strip().split())
        if not normalized:
            return "unscoped"
        if "{files}" in normalized or "{paths}" in normalized:
            return "scoped"

        repo_wide_tokens = {
            ".",
            "./",
            "./...",
            "...",
            "--all",
            "--all-files",
            "--all-targets",
        }
        parts = normalized.split()
        if any(token in repo_wide_tokens for token in parts):
            return "unscoped"
        return "unscoped"

    def _normalize_verification_tool(
        self,
        tool: dict[str, Any],
        *,
        default_source: str,
    ) -> dict[str, Any]:
        normalized = dict(tool)
        command = str(tool.get("command", "") or "").strip()
        scope_type = str(tool.get("scope_type", "") or "").strip().lower()
        if scope_type not in {"scoped", "unscoped"}:
            scope_type = self._infer_verification_scope_type(command)

        patterns = self._coerce_string_list(tool.get("patterns", []))
        target_files = self._coerce_string_list(
            tool.get("target_files", tool.get("targets", patterns))
        )
        discovery_source = str(tool.get("discovery_source") or default_source).strip()
        if not discovery_source:
            discovery_source = default_source

        normalized["command"] = command
        normalized["patterns"] = patterns
        normalized["target_files"] = target_files
        normalized["scope_type"] = scope_type
        normalized["discovery_source"] = discovery_source
        return normalized
