"""Scope validation for fix handler.

Validates that fix agent modifications stay within acceptable
boundaries (file count, diff line caps, project directory).
"""

import logging
import os
import subprocess
from collections.abc import Callable
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from obra.display.observability import ProgressEmitter
from obra.utils.file_tracker import FileSnapshot, FileStateTracker

logger = logging.getLogger(__name__)


class ScopeValidator:
    """Validates fix scope against config limits and project boundaries.

    Extracted from FixHandler to isolate scope-measurement and reversion
    concerns from the main fix orchestration loop.
    """

    def __init__(
        self,
        working_dir: Path,
        file_tracker: FileStateTracker,
        config: dict[str, Any],
        progress_emitter: ProgressEmitter | None,
        log_event: Callable[..., Any] | None,
    ) -> None:
        self._working_dir = working_dir
        self._file_tracker = file_tracker
        self._config = config
        self._progress_emitter = progress_emitter
        self._log_event = log_event

    def capture_file_state(self) -> FileSnapshot:
        """Capture current file state for diff detection.

        Uses FileStateTracker to create a snapshot of all files.
        ISSUE-REVIEW-AGENTS-002: Replaces git-based tracking.

        Returns:
            FileSnapshot with current state of all tracked files
        """
        return self._file_tracker.snapshot()

    def detect_modifications(self, before_state: FileSnapshot) -> list[str]:
        """Detect files modified since before_state was captured.

        Uses FileStateTracker to compare current state against snapshot.
        ISSUE-REVIEW-AGENTS-002: Replaces git-based tracking.

        Args:
            before_state: FileSnapshot from capture_file_state() before execution

        Returns:
            Sorted list of file paths that changed during execution
        """
        changes = self._file_tracker.diff(before_state)
        return changes.all_changed_files

    def validate_project_boundary(self, files_modified: list[str]) -> dict[str, Any]:
        """Validate all modifications are within project directory.

        Post-execution safety net that checks if the fix agent modified any
        files outside the project working directory. This prevents filesystem
        escape while allowing modification of any file within the project.

        Args:
            files_modified: Files that were modified by the fix agent

        Returns:
            Dict with:
                - has_violations: True if any files are outside project boundary
                - violations: List of file paths that violated the boundary
        """
        if not files_modified:
            return {"has_violations": False, "violations": []}

        project_root = Path(os.path.abspath(self._working_dir))
        violations: list[str] = []

        for file_path in files_modified:
            try:
                candidate = Path(file_path)
                normalized = candidate if candidate.is_absolute() else project_root / candidate
                Path(os.path.abspath(normalized)).relative_to(project_root)
            except ValueError:
                # File is outside project directory
                violations.append(file_path)
                logger.exception("Project boundary violation")

        if violations:
            logger.error(
                f"Fix agent modified {len(violations)} file(s) outside project: {violations}"
            )

        return {"has_violations": bool(violations), "violations": violations}

    def check_fix_scope(self, before_state: FileSnapshot) -> bool:
        """Check fix scope against config limits. Returns True if scope is acceptable.

        FIX-HYBRID-042: Enforces hard caps by reverting changes when exceeded.
        FIX-HYBRID-050: Uses diff-based line metric; warning threshold enforces.
        """
        files_modified = self.detect_modifications(before_state)
        if not files_modified:
            return True

        file_count = len(files_modified)
        diff_lines = self.measure_diff_lines(files_modified, before_state)

        # Load scope limits from config
        scope_cfg = self._config.get("fix", {}).get("verification", {}).get("scope", {})
        warn_diff_lines = int(scope_cfg.get("warn_diff_lines", 200))
        warn_files = int(scope_cfg.get("warn_files", 10))
        hard_cap_diff_lines = int(scope_cfg.get("hard_cap_diff_lines", 500))
        hard_cap_files = int(scope_cfg.get("hard_cap_files", 30))

        # Hard cap check — revert changes if exceeded
        if diff_lines > hard_cap_diff_lines or file_count > hard_cap_files:
            message = (
                f"Fix scope exceeded hard cap: {file_count} files, "
                f"{diff_lines} diff lines (caps: {hard_cap_files} files, "
                f"{hard_cap_diff_lines} diff lines). Reverting changes."
            )
            logger.warning(message)
            if self._progress_emitter:
                self._progress_emitter.warning(message)
            if self._log_event:
                self._log_event(
                    "fix_scope_exceeded",
                    file_count=file_count,
                    diff_lines=diff_lines,
                    hard_cap_diff_lines=hard_cap_diff_lines,
                    hard_cap_files=hard_cap_files,
                )
            self.revert_modifications(files_modified)
            return False

        # Warning check — enforces by reverting (FIX-HYBRID-050)
        if file_count > warn_files or diff_lines > warn_diff_lines:
            message = (
                f"Fix scope excessive: {file_count} files, "
                f"{diff_lines} diff lines changed (limits: {warn_files} files, "
                f"{warn_diff_lines} diff lines). Reverting changes."
            )
            logger.warning(message)
            if self._progress_emitter:
                self._progress_emitter.warning(message)
            if self._log_event:
                self._log_event(
                    "fix_scope_warning",
                    file_count=file_count,
                    diff_lines=diff_lines,
                    enforced=True,
                )
            self.revert_modifications(files_modified)
            return False
        return True

    def measure_diff_lines(
        self,
        files_modified: list[str],
        before_state: FileSnapshot | None = None,
    ) -> int:
        """Measure actual lines changed (added + removed) via git diff.

        FIX-HYBRID-050: Uses diff-based metric instead of total file size.
        Falls back to snapshot-aware line diffs if git is unavailable.
        """
        try:
            result = subprocess.run(
                ["git", "diff", "--numstat", "--", *files_modified],
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=10,
            )
            if result.returncode != 0:
                raise RuntimeError(result.stderr)
            diff_lines = 0
            for line in result.stdout.strip().splitlines():
                parts = line.split("\t")
                if len(parts) >= 2 and parts[0] != "-":
                    diff_lines += int(parts[0]) + int(parts[1])
            return diff_lines
        except Exception as exc:
            logger.debug("git diff unavailable, falling back to snapshot diff: %s", exc)
            if before_state is not None:
                diff_lines = 0
                for rel_path in files_modified:
                    before_file = before_state.files.get(rel_path)
                    before_lines = list(before_file.text_lines) if before_file and before_file.text_lines else []
                    full_after = self._working_dir / rel_path
                    after_lines: list[str] = []
                    if full_after.exists():
                        try:
                            after_lines = full_after.read_text(encoding="utf-8").splitlines()
                        except Exception:
                            after_lines = []
                    diff_lines += self.count_line_delta(before_lines, after_lines)
                return diff_lines
            total = 0
            for rel_path in files_modified:
                full_path = self._working_dir / rel_path
                try:
                    total += len(full_path.read_text(encoding="utf-8").splitlines())
                except Exception:
                    continue
            return total

    @staticmethod
    def count_line_delta(
        before_lines: list[str],
        after_lines: list[str],
    ) -> int:
        """Count added + removed lines between two text snapshots."""
        matcher = SequenceMatcher(a=before_lines, b=after_lines)
        diff_lines = 0
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "equal":
                continue
            if tag in {"replace", "delete"}:
                diff_lines += i2 - i1
            if tag in {"replace", "insert"}:
                diff_lines += j2 - j1
        return diff_lines

    def revert_modifications(self, files_modified: list[str]) -> None:
        """Revert modified files using git checkout."""
        try:
            result = subprocess.run(
                ["git", "checkout", "--", *files_modified],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self._working_dir,
            )
            if result.returncode == 0:
                logger.info("Reverted %d files after scope exceeded", len(files_modified))
            else:
                logger.warning("git checkout failed: %s", result.stderr.strip())
        except Exception as exc:
            logger.warning("Could not revert files: %s", exc)
