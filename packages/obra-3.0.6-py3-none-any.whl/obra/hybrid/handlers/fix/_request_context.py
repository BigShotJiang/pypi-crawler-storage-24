"""Request preparation and pre-pass assembly for FixHandler."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.api.protocol import FixRequest
from obra.config.loaders import get_verification_required
from obra.hybrid.handlers.fix._tool_manager import VerificationToolManager
from obra.hybrid.handlers.fix._verification import VerificationPipeline
from obra.utils.file_tracker import FileSnapshot

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class PreparedFixContext:
    """Prepared request context consumed by FixHandler.handle()."""

    issues: list[dict[str, Any]]
    item_id: str | None
    execution_order: list[str] | None
    convergence_skipped: list[dict[str, Any]]
    tool_manager: VerificationToolManager
    verification_tools: list[dict[str, Any]]
    verification_pipeline: VerificationPipeline
    enriched_prompt: str
    overall_before_state: FileSnapshot
    force_individual: bool


@dataclass(slots=True)
class RequestPreparationResult:
    """Either an early response or a prepared request context."""

    early_response: dict[str, Any] | None = None
    prepared: PreparedFixContext | None = None


class RequestContextPreparer:
    """Builds the prepared-request contract that FixHandler.handle() consumes."""

    def __init__(
        self,
        *,
        working_dir: Path,
        config: dict[str, Any],
        llm_config: dict[str, Any],
        domain: Any | None,
        session_id: str | None,
        trace_id: str | None,
        parent_span_id: str | None,
    ) -> None:
        self._working_dir = working_dir
        self._config = config
        self._llm_config = llm_config
        self._domain = domain
        self._session_id = session_id
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id

    def prepare(
        self,
        request: FixRequest,
        *,
        progress_emitter: Any | None,
        log_event: Any | None,
        emit_progress_fn: Any,
        normalize_issues_fn: Any,
        attempt_issue_details_hydration_fn: Any,
        get_reapplied_ids_fn: Any,
        build_tool_manager_fn: Any,
        load_verification_tools_fn: Any,
        apply_convergence_guard_fn: Any,
        build_convergence_only_response_fn: Any,
        compute_force_individual_fn: Any,
        capture_file_state_fn: Any,
        prompt_enricher_cls: type[Any],
        test_gap_classifier: Any,
        test_gap_target_resolver: Any,
        issue_intent_resolver: Any,
        run_tests_fn: Any,
        run_lint_fn: Any,
    ) -> RequestPreparationResult:
        """Prepare and validate request context before the fix pass starts."""
        item_id = request.item_id
        execution_order = request.execution_order

        if not request.issues_to_fix:
            logger.info("FIX action received with 0 issues — skipping")
            if log_event:
                log_event(
                    "fix_skipped_no_issues",
                    item_id=item_id,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )
            return RequestPreparationResult(
                early_response={
                    "fix_results": [],
                    "fixed_count": 0,
                    "failed_count": 0,
                    "skipped_count": 0,
                }
            )

        if request.issues_to_fix and not request.issue_details:
            if attempt_issue_details_hydration_fn(request):
                logger.info(
                    "Hydrated %s issue details from scorecard",
                    len(request.issue_details),
                )

        if request.issue_details:
            for i, detail in enumerate(request.issue_details[:3]):
                logger.debug(
                    "issue_details[%s]: id=%s, priority=%s, file_path=%s",
                    i,
                    detail.get("id"),
                    detail.get("priority"),
                    detail.get("file_path"),
                )
        else:
            logger.warning("FixRequest received with empty issue_details")

        issues = normalize_issues_fn(request.issues_to_fix, request.issue_details)
        reapplied_ids = get_reapplied_ids_fn(issues)
        if progress_emitter:
            progress_emitter.fix_started(len(issues))
        if log_event:
            log_event(
                "fix_started",
                item_id=item_id,
                issue_count=len(issues),
                reapplied_canonical_ids=reapplied_ids,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

        issues, convergence_skipped = apply_convergence_guard_fn(issues)
        if not issues:
            return RequestPreparationResult(
                early_response=build_convergence_only_response_fn(
                    convergence_skipped,
                    item_id=item_id,
                )
            )

        if request.issues_to_fix and not request.issue_details:
            if not all(isinstance(issue, dict) for issue in request.issues_to_fix):
                message = (
                    "Fix aborted: issue_details missing and could not be hydrated from scorecard. "
                    "Re-running review to regenerate issue details."
                )
                logger.warning(message)
                if progress_emitter:
                    progress_emitter.warning(message)
                failed_results = [
                    {
                        "issue_id": issue.get("id", "unknown"),
                        "status": "failed",
                        "summary": message,
                    }
                    for issue in issues
                ]
                return RequestPreparationResult(
                    early_response={
                        "fix_results": failed_results,
                        "fixed_count": 0,
                        "failed_count": len(failed_results),
                        "skipped_count": 0,
                        "item_id": item_id,
                    }
                )

        if not issues:
            logger.info("No issues to fix")
            return RequestPreparationResult(
                early_response={
                    "fix_results": [],
                    "fixed_count": 0,
                    "failed_count": 0,
                    "skipped_count": 0,
                    "item_id": item_id,
                }
            )

        tool_manager = build_tool_manager_fn()
        tools = load_verification_tools_fn()
        if not tools:
            auto_install = (
                self._config.get("fix", {})
                .get("verification", {})
                .get("auto_install", True)
            )
            mode = self._config.get("automation_mode", "auto_safe")
            if auto_install:
                emit_progress_fn("[FIX] Auto-install triggered: verification tools missing")
                installed_tools: list[str] = []
                for tool, ecosystem in [
                    ("pytest", "python"),
                    ("ruff", "python"),
                    ("mypy", "python"),
                ]:
                    if tool_manager.install_if_needed(tool, ecosystem):
                        installed_tools.append(tool)
                if installed_tools:
                    tools = tool_manager.get_default_tools(installed_tools)
                    tool_manager.set_tools(tools)
                    if not tools:
                        tools = load_verification_tools_fn()
            else:
                emit_progress_fn(
                    f"[FIX] Auto-install disabled (automation_mode={mode})"
                )

            verification_required = get_verification_required()
            if not tools and verification_required and not auto_install:
                message = (
                    "FIX blocked: No verification tools available "
                    "(fix.verification.required=true). Configure tools via "
                    "fix.verification.tools or enable discovery."
                )
                logger.warning(
                    "Verification tools required but not available - blocking FIX phase."
                )
                if progress_emitter:
                    progress_emitter.warning(message)
                failed_results = [
                    {
                        "issue_id": issue.get("id", "unknown"),
                        "status": "failed",
                        "summary": message,
                    }
                    for issue in issues
                ]
                return RequestPreparationResult(
                    early_response={
                        "fix_results": failed_results,
                        "fixed_count": 0,
                        "failed_count": len(failed_results),
                        "skipped_count": 0,
                        "item_id": item_id,
                    }
                )
            if not tools:
                logger.warning(
                    "No verification tools available but proceeding (auto-install attempted). "
                    "Fix results will not be verified."
                )

        if request.base_prompt is None:
            error_msg = (
                "FixRequest.base_prompt is None. Server must provide base prompt (ADR-035)."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        fix_history = request.fix_history or ""
        base_prompt = self._build_base_prompt(request, fix_history)
        enricher = prompt_enricher_cls(self._working_dir)
        enriched_prompt = enricher.enrich(base_prompt)
        overall_before_state = capture_file_state_fn()
        force_individual = compute_force_individual_fn(fix_history)
        verification_pipeline = VerificationPipeline(
            working_dir=self._working_dir,
            verification_tools=tools,
            config=self._config,
            domain=self._domain,
            session_id=self._session_id,
            log_event=log_event,
            progress_emitter=progress_emitter,
            test_gap_classifier=test_gap_classifier,
            test_gap_target_resolver=test_gap_target_resolver,
            issue_intent_resolver=issue_intent_resolver,
            run_tests_fn=run_tests_fn,
            run_lint_fn=run_lint_fn,
        )

        return RequestPreparationResult(
            prepared=PreparedFixContext(
                issues=issues,
                item_id=item_id,
                execution_order=execution_order,
                convergence_skipped=convergence_skipped,
                tool_manager=tool_manager,
                verification_tools=tools,
                verification_pipeline=verification_pipeline,
                enriched_prompt=enriched_prompt,
                overall_before_state=overall_before_state,
                force_individual=force_individual,
            )
        )

    @staticmethod
    def _build_base_prompt(request: FixRequest, fix_history: str) -> str:
        """Build the enriched base prompt before PromptEnricher runs."""
        if fix_history:
            history_block = (
                "## Previous Attempts\n"
                f"{fix_history}\n\n"
                "Do not repeat approaches that failed previously.\n\n"
            )
            base_prompt = history_block + (request.base_prompt or "")
        else:
            base_prompt = request.base_prompt or ""

        context_sections: list[str] = []

        if request.fix_attempt > 0:
            budget_lines = [
                "## Fix Budget",
                f"This is attempt {request.fix_attempt} of {request.max_fix_attempts}.",
            ]
            if request.fix_attempt >= request.max_fix_attempts:
                budget_lines.append(
                    "This is the FINAL attempt. Be conservative and choose the safest approach."
                )
            context_sections.append("\n".join(budget_lines) + "\n")

        item_ctx = request.item_context
        if item_ctx and item_ctx.get("title"):
            task_lines = [
                "## Original Task",
                f"Title: {item_ctx['title']}",
                f"Description: {item_ctx.get('description', '')}",
            ]
            criteria = item_ctx.get("acceptance_criteria", [])
            if criteria:
                task_lines.append("Acceptance Criteria:")
                for criterion in criteria:
                    task_lines.append(f"- {criterion}")
            task_lines.append("")
            task_lines.append("Ensure fixes preserve the original task intent.")
            context_sections.append("\n".join(task_lines) + "\n")

        siblings = request.sibling_issues[:10] if request.sibling_issues else []
        if siblings:
            sibling_lines = [
                "## Other Blocking Issues",
                "These issues also block this item (not in your current fix set):",
            ]
            for sibling in siblings:
                sibling_lines.append(
                    f"- {sibling.get('id', '')}: {sibling.get('description', '')} "
                    f"({sibling.get('file_path', '')})"
                )
            sibling_lines.append("")
            sibling_lines.append(
                "Avoid changes that would conflict with fixing these issues."
            )
            context_sections.append("\n".join(sibling_lines) + "\n")

        if context_sections:
            return "\n".join(context_sections) + "\n" + base_prompt
        return base_prompt
