"""Issue normalization for FixHandler.

Extracted from fix/_handler.py (S4 of REFACTOR-FIX-HANDLER-001).
Owns: issue dict normalization, hydration from server, intent resolution.
"""

from __future__ import annotations

import logging
from typing import Any

from obra.hybrid.handlers.fix._test_gap import normalize_target_paths, resolve_issue_intent

logger = logging.getLogger(__name__)

# Re-export for callers that imported from handler shims.
__all__ = [
    "IssueNormalizer",
    "normalize_target_paths",
    "resolve_issue_intent",
]

# Documentation-issue timeout cap (mirrors FixHandler.DOC_FIX_TIMEOUT_S).
_DOC_FIX_TIMEOUT_S = 120


class IssueNormalizer:
    """Normalize raw issue lists and hydrate with server data."""

    def __init__(
        self,
        session_id: str | None,
        config: dict[str, Any],
    ) -> None:
        self._session_id = session_id
        self._config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def normalize_issues(
        self,
        issues: list[Any],
        issue_details: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Normalize issues to dict format.

        ISSUE-SAAS-009: Server may return issues as List[str].
        FIX-PRIORITY-LOSS-001: If issue_details is provided, use those directly.
        """
        if issue_details:
            logger.debug("Normalizing %d issues from issue_details", len(issue_details))
            normalized: list[dict[str, Any]] = []
            for i, detail in enumerate(issue_details):
                if isinstance(detail, dict):
                    logger.debug(
                        "issue_details[%d]: id=%s, keys=%s",
                        i,
                        detail.get("id"),
                        list(detail.keys()),
                    )
                    if "id" not in detail:
                        detail = dict(detail)
                        detail["id"] = detail.get("canonical_id") or f"issue-{i}"
                    normalized.append(detail)
                else:
                    logger.warning(
                        "Unexpected issue_details format at index %d: %s",
                        i,
                        type(detail),
                    )
            if normalized:
                return normalized
        else:
            logger.warning(
                "_normalize_issues: issue_details is empty, "
                "falling back to legacy normalization (%d items)",
                len(issues),
            )

        normalized = []
        for i, issue in enumerate(issues):
            if isinstance(issue, str):
                normalized.append(
                    {
                        "id": issue,
                        "description": issue,
                        "priority": "P2",
                    }
                )
            elif isinstance(issue, dict):
                if "id" not in issue:
                    issue = dict(issue)
                    issue["id"] = issue.get("canonical_id") or f"issue-{i}"
                normalized.append(issue)
            else:
                logger.warning("Unknown issue format at index %d: %s", i, type(issue))
                normalized.append(
                    {
                        "id": f"issue-{i}",
                        "description": str(issue),
                        "priority": "P2",
                    }
                )
        return normalized

    def attempt_issue_details_hydration(self, request: Any) -> bool:
        """Try to hydrate request.issue_details from the server scorecard."""
        if not self._session_id or not request.item_id:
            logger.warning("Cannot hydrate issue_details: session_id or item_id missing")
            return False

        try:
            from obra.api import APIClient

            client = APIClient.from_config()
            response = client.get_quality_scorecard(self._session_id, request.item_id)
            scorecard = response.get("scorecard", {})
        except Exception as e:
            logger.warning("Failed to fetch scorecard for issue_details hydration: %s", e)
            return False

        agent_reports = scorecard.get("agent_reports", [])
        if not isinstance(agent_reports, list):
            logger.warning("Unexpected scorecard agent_reports shape: %s", type(agent_reports))
            return False

        issue_details = self.extract_issue_details_from_reports(agent_reports)
        if not issue_details:
            return False

        target_ids = {
            issue.get("id") if isinstance(issue, dict) else issue
            for issue in request.issues_to_fix
        }
        target_ids = {issue_id for issue_id in target_ids if issue_id}
        if target_ids:
            issue_details = [
                detail for detail in issue_details if detail.get("id") in target_ids
            ]

        if not issue_details:
            return False

        request.issue_details = issue_details
        return True

    @staticmethod
    def extract_issue_details_from_reports(
        agent_reports: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Extract issue dicts from agent report list."""
        details: list[dict[str, Any]] = []
        for report in agent_reports:
            issues = report.get("issues", [])
            if not isinstance(issues, list):
                continue
            for issue in issues:
                if isinstance(issue, dict) and "id" in issue:
                    details.append(issue)
        return details

    def resolve_issue_timeout(self, issue: dict[str, Any]) -> int:
        """Resolve execution timeout for an issue (shorter for docs)."""
        from obra.config import get_agent_execution_timeout

        base_timeout = get_agent_execution_timeout()
        if self.is_documentation_issue(issue):
            return min(base_timeout, _DOC_FIX_TIMEOUT_S)
        return base_timeout

    def is_documentation_issue(self, issue: dict[str, Any]) -> bool:
        """Return True if the issue is documentation-related."""
        issue_id = str(issue.get("id", "")).upper()
        if issue_id.startswith("DOC-"):
            return True
        for key in ("category", "dimension", "type"):
            value = issue.get(key)
            if value and str(value).lower() in {"documentation", "docs", "doc"}:
                return True
        return False
