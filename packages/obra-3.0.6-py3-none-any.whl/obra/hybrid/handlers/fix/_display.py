"""Display helpers for FixHandler.

Extracted from fix/_handler.py (S4 of REFACTOR-FIX-HANDLER-001).
Owns: progress emission, result line formatting, issue index printing.
"""

from __future__ import annotations

import contextlib
import logging
from datetime import UTC, datetime
from typing import Any, Callable

from obra.api.protocol_core import FixStatus
from obra.display import console, print_error, print_info, print_warning
from obra.display.observability import ProgressEmitter

logger = logging.getLogger(__name__)

__all__ = ["FixDisplay"]


class FixDisplay:
    """Display and telemetry helpers for FixHandler."""

    def __init__(
        self,
        progress_emitter: ProgressEmitter | None,
        log_event: Any | None,
        trace_id: str | None,
        parent_span_id: str | None,
        config: dict[str, Any],
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        log_decisions: bool = True,
    ) -> None:
        self._progress_emitter = progress_emitter
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._config = config
        self._on_progress = on_progress
        self._log_decisions = log_decisions

    # ------------------------------------------------------------------
    # Progress emission
    # ------------------------------------------------------------------

    def emit_progress(self, message: str) -> None:
        """Emit a progress message via emitter or print."""
        if self._progress_emitter:
            self._progress_emitter.warning(message)
        else:
            print_info(message)

    def emit_decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Emit a decision event to the on_progress callback if enabled."""
        if not self._on_progress or not self._log_decisions:
            return
        payload = {
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "mode": data.get("mode", self._config.get("automation_mode", "auto_safe")),
            "ecosystem": data.get("ecosystem"),
            "packages": data.get("packages"),
            "target": data.get("target"),
            "reason": data.get("reason"),
        }
        with contextlib.suppress(Exception):
            self._on_progress(event_type, payload)

    # ------------------------------------------------------------------
    # Fix result lines
    # ------------------------------------------------------------------

    @staticmethod
    def resolve_fix_result_severity(
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> str:
        """Map fix result status to a severity string."""
        status = str(result.get("status", FixStatus.FAILED.value)).strip().lower()
        if status == FixStatus.FAILED.value:
            return "error"
        if status == FixStatus.SKIPPED.value:
            return "warning"
        if status == FixStatus.INCONCLUSIVE.value:
            priority = str(
                (issue or {}).get("priority") or (issue or {}).get("severity") or ""
            ).upper()
            return "warning" if priority in {"P0", "P1"} else "info"
        return "info"

    def emit_fix_result_line(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> tuple[int, int, int]:
        """Emit a per-issue result line and return (fixed_delta, failed_delta, skipped_delta)."""
        status = str(result.get("status", FixStatus.FAILED.value)).strip().lower()
        self.emit_fix_result_event(issue_id=issue_id, result=result, status=status)
        if status in {"fixed", FixStatus.APPLIED.value}:
            print_info(f"  Fixed: {issue_id}")
            return 1, 0, 0

        if status == FixStatus.SKIPPED.value:
            print_warning(f"  Skipped: {issue_id}")
            return 0, 0, 1

        reason = self.format_failure_reason(result) or str(result.get("reason", "")).strip()
        detail = f" ({reason})" if reason else ""
        if status == FixStatus.INCONCLUSIVE.value:
            message = f"  Inconclusive: {issue_id}{detail}"
            severity = self.resolve_fix_result_severity(result, issue)
            if severity == "warning":
                print_warning(message)
            else:
                print_info(message)
            return 0, 0, 1

        print_error(f"  Failed: {issue_id}{detail}")
        return 0, 1, 0

    def emit_fix_result_event(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        status: str,
    ) -> None:
        """Emit a telemetry event for a per-issue fix result."""
        if not self._log_event:
            return

        verification = (
            result.get("verification")
            if isinstance(result.get("verification"), dict)
            else {}
        )
        verification_runs = (
            verification.get("verification_runs", {})
            if isinstance(verification, dict)
            else {}
        )
        failed_verification_runs: list[dict[str, Any]] = []
        if isinstance(verification_runs, dict):
            for check_name, run in verification_runs.items():
                if not isinstance(run, dict):
                    continue
                if str(run.get("execution_status", "")).lower() != "failed":
                    continue
                entry: dict[str, Any] = {
                    "check": check_name,
                    "tool": run.get("tool"),
                    "scope_type": run.get("scope_type"),
                    "attribution_confidence": run.get("attribution_confidence"),
                    "command": run.get("command"),
                }
                output_excerpt = run.get("output_excerpt")
                if output_excerpt:
                    entry["output_excerpt"] = str(output_excerpt)[:400]
                failed_verification_runs.append(entry)

        self._log_event(
            "fix_issue_result",
            issue_id=issue_id,
            canonical_id=result.get("canonical_id"),
            status=status,
            reason=result.get("reason"),
            verification_outcome=result.get("verification_outcome"),
            verification_reason_code=verification.get("verification_reason_code"),
            verification_scope=result.get("verification_scope"),
            attribution_confidence=result.get("attribution_confidence"),
            target_test_file_modified=verification.get("target_test_file_modified"),
            failed_verification_runs=failed_verification_runs,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

    # ------------------------------------------------------------------
    # Issue index / progress printing
    # ------------------------------------------------------------------

    def print_issue_index(
        self, issues: list[dict[str, Any]], ordered_ids: list[str]
    ) -> None:
        """Print a concise issue index."""
        if not issues:
            return
        issue_map = {
            issue.get("id") or issue.get("canonical_id") or f"issue-{i}": issue
            for i, issue in enumerate(issues)
        }
        print_info(f"Issue index ({len(issues)}):")
        for issue_id in ordered_ids:
            issue = issue_map.get(issue_id, {"id": issue_id})
            summary = self.format_issue_summary(issue)
            console.print(f"  - {summary}", style="dim")

    def print_issue_progress(
        self, issue: dict[str, Any], index: int, total: int
    ) -> None:
        """Print a per-issue progress line."""
        summary = self.format_issue_summary(issue)
        print_info(f"Fixing issue {index}/{total}: {summary}")

    def print_batch_progress(
        self,
        batch: dict[str, Any],
        *,
        batch_index: int,
        total_batches: int,
    ) -> None:
        """Print batch progress with file context and issue IDs."""
        file_path = batch.get("file_path") or "unknown"
        issues = batch.get("issues", [])
        issue_ids = [issue.get("id", "unknown") for issue in issues]
        issue_list = ", ".join(issue_ids)
        print_info(
            f"Fixing batch {batch_index}/{total_batches} in {file_path} "
            f"({len(issues)} issues: {issue_list})"
        )
        for issue in issues:
            summary = self.format_issue_summary(issue)
            console.print(f"  - {summary}", style="dim")

    @staticmethod
    def format_issue_summary(issue: dict[str, Any]) -> str:
        """Format a concise issue summary for CLI output."""
        issue_id = issue.get("id", "unknown")
        priority = issue.get("priority") or issue.get("severity")
        id_part = f"{issue_id} ({priority})" if priority else issue_id
        file_path = issue.get("file_path") or issue.get("file")
        line_number = issue.get("line_number") or issue.get("line")
        location = ""
        if file_path and line_number:
            location = f"{file_path}:{line_number}"
        elif file_path:
            location = file_path
        description = (
            issue.get("description")
            or issue.get("title")
            or issue.get("summary")
            or issue.get("category")
            or ""
        )
        description = " ".join(str(description).split())
        if len(description) > 140:
            description = f"{description[:137]}..."
        if location and description:
            return f"{id_part} {location} - {description}"
        if location:
            return f"{id_part} {location}"
        if description:
            return f"{id_part} - {description}"
        return id_part

    @staticmethod
    def format_failure_reason(result: dict[str, Any]) -> str | None:
        """Derive a concise failure reason from fix verification."""
        verification = result.get("verification") or {}
        if isinstance(verification, dict):
            reason_code = str(verification.get("verification_reason_code", "")).strip()
            if reason_code:
                return reason_code
            if verification.get("error"):
                return str(verification.get("error"))
            if verification.get("boundary_valid") is False:
                return "project boundary violation"
            if verification.get("lint_passed") is False:
                return "lint failed"
            if verification.get("tests_passed") is False:
                return "tests failed"
            if verification.get("security_check_passed") is False:
                return "security check failed"
        return None

    @staticmethod
    def print_convergence_warnings(
        convergence_skipped: list[dict[str, Any]],
        reapply_counts: dict[str, int],
    ) -> None:
        """Print warnings for canonical IDs suppressed by convergence guard.

        SESSION-92257c4c: Makes non-convergence visible in CLI output.
        """
        for skip_result in convergence_skipped:
            canonical_id = skip_result.get("canonical_id") or skip_result.get("issue_id", "?")
            count = reapply_counts.get(canonical_id, 0)
            ordinal = {2: "2nd", 3: "3rd"}.get(count, f"{count}th")
            print_warning(f"  {canonical_id}: re-applied ({ordinal} time) — suppressed by convergence guard")

    def print_fix_summary(
        self,
        *,
        fixed_count: int,
        failed_count: int,
        skipped_count: int,
        last_lint_summary: str | None = None,
        lint_repeat_count: int = 0,
    ) -> None:
        """Print a concise fix summary with last lint blocker if available."""
        detail = ""
        if failed_count and last_lint_summary:
            repeat_note = ""
            if lint_repeat_count:
                repeat_note = f" (repeated {lint_repeat_count + 1}x)"
            detail = f" Last blocker: lint {last_lint_summary}{repeat_note}."
        print_info(
            f"Fix summary: {fixed_count} fixed, {failed_count} failed, "
            f"{skipped_count} skipped.{detail}"
        )
