"""Verification pipeline for fix-handler execution checks."""

from __future__ import annotations

import fnmatch
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.display.observability import ProgressEmitter
from obra.hybrid.handlers.fix._outcome_classifier import VerificationOutcomeClassifier
from obra.hybrid.handlers.fix._tool_runner import VerificationToolRunner

logger = logging.getLogger(__name__)


class VerificationPipeline:
    """Run fix verification and classify the result."""

    def __init__(
        self,
        working_dir: Path,
        verification_tools: list[dict[str, Any]],
        config: dict[str, Any],
        domain: Any | None,
        session_id: str | None,
        log_event: Any | None,
        progress_emitter: ProgressEmitter | None,
        test_gap_classifier: Callable[[dict[str, Any]], bool] | None,
        test_gap_target_resolver: Callable[[dict[str, Any]], list[str]] | None,
        issue_intent_resolver: Callable[[dict[str, Any]], tuple[str, str, str]] | None,
        run_tests_fn: Callable[..., tuple[bool | None, str, str, str]] | None = None,
        run_lint_fn: Callable[..., tuple[bool | None, str, str, str]] | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._verification_tools = verification_tools
        self._config = config
        self._domain = domain
        self._session_id = session_id
        self._log_event = log_event
        self._progress_emitter = progress_emitter
        self._test_gap_classifier = test_gap_classifier
        self._test_gap_target_resolver = test_gap_target_resolver
        self._issue_intent_resolver = issue_intent_resolver
        self._run_tests_fn = run_tests_fn
        self._run_lint_fn = run_lint_fn
        self._tool_runner = VerificationToolRunner(self._working_dir)
        self._outcome_classifier = VerificationOutcomeClassifier()

        self._last_verification_run_metadata: dict[str, Any] | None = None
        self._verification_target_snapshot: dict[str, list[str]] = {}
        self._last_lint_output: str | None = None
        self._last_lint_summary: str | None = None
        self._lint_repeat_count = 0
        self._run_verification_tool = self._build_run_verification_tool_delegate()
        self._normalize_verification_targets = self._tool_runner.normalize_targets
        self._clean_verification_target = self._tool_runner.clean_target
        self._looks_like_path_target = self._tool_runner.looks_like_path
        self._normalize_verification_tool = self._tool_runner.normalize_tool
        self._coerce_string_list = self._tool_runner.coerce_string_list
        self._infer_verification_scope_type = self._tool_runner.infer_scope_type
        self._build_verification_run_metadata = self._tool_runner.build_run_metadata
        self._capture_verification_run = (
            lambda **kwargs: self._outcome_classifier.capture_run(
                self._last_verification_run_metadata,
                **kwargs,
            )
        )
        self._classify_verification_outcome = self._outcome_classifier.classify
        self._match_rollback_code = self._outcome_classifier.match_rollback_code
        self._summarize_lint_output = self._outcome_classifier.summarize_lint_output
        self._build_promoted_defect_issue = self._outcome_classifier.build_promoted_defect_issue

    def _build_run_verification_tool_delegate(self) -> Callable[..., tuple[bool | None, str, str, str]]:
        """Build a delegate that syncs runner metadata back to the pipeline."""

        def run_verification_tool(
            tool: dict[str, Any],
            files: list[str] | None = None,
        ) -> tuple[bool | None, str, str, str]:
            result = self._tool_runner.run_tool(tool, files=files)
            self._last_verification_run_metadata = self._tool_runner.last_run_metadata
            return result

        return run_verification_tool

    def verify_fix(
        self,
        issue: dict[str, Any],
        agent_result: dict[str, Any],
        files_modified: list[str] | None = None,
    ) -> dict[str, Any]:
        """Verify that the fix resolved the issue.

        Args:
            issue: Original issue dict.
            agent_result: Result from fix agent deployment.
            files_modified: Actual files modified during fix (from file tracker).
                If not provided, falls back to agent_result (legacy behaviour).

        Returns:
            Verification results dictionary.
        """
        actual_modified = (
            files_modified if files_modified is not None else agent_result.get("files_modified", [])
        )

        verification: dict[str, Any] = {
            "agent_succeeded": agent_result.get("status") == "success",
            "files_modified": bool(actual_modified),
            "verification_runs": {},
        }

        logger.info(f"Verifying fix for issue {issue.get('id')}")
        logger.info(f"Agent status: {agent_result.get('status')}")
        logger.info(f"Files modified: {actual_modified}")

        modified_files = actual_modified
        is_test_gap = self._is_test_gap(issue)

        if is_test_gap and modified_files:
            target_paths = self._get_test_gap_targets(issue)
            if target_paths:
                target_file_touched = any(
                    any(path in f or f.endswith(path) or path.endswith(f) for path in target_paths)
                    for f in modified_files
                )
                verification["target_test_file_modified"] = target_file_touched
                if not target_file_touched:
                    logger.warning(
                        "Target test files %s not in modified files: %s",
                        target_paths,
                        modified_files,
                    )

        category = issue.get("category", "").lower()
        logger.info(f"Issue category: {category}")

        checks_to_run = self._resolve_checks_to_run(
            issue=issue,
            category=category,
            is_test_gap=is_test_gap,
        )

        promoted_issues: list[dict[str, Any]] = []
        verification_runs: dict[str, dict[str, Any]] = {}

        for check in checks_to_run:
            if check == "security":
                result = self._run_security_check()
                security_scope = "scoped" if modified_files else "unscoped"
                verification_runs["security"] = {
                    "tool": "security_scan",
                    "category": "security",
                    "command": "security_scan",
                    "target_files": list(modified_files),
                    "scope_type": security_scope,
                    "discovery_source": "runtime",
                    "attribution_confidence": "high" if security_scope == "scoped" else "medium",
                    "execution_status": (
                        "passed" if result is True else "failed" if result is False else "unavailable"
                    ),
                }
                if result is not None:
                    verification["security_check_passed"] = result
                    logger.info(f"Security check result: {result}")
            elif check == "tests":
                if is_test_gap:
                    metadata = (
                        issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
                    )
                    test_name = issue.get("test_name") or metadata.get("test_name")
                    target_test_file = issue.get("target_test_file")
                    if not target_test_file:
                        target_paths = self._get_test_gap_targets(issue)
                        target_test_file = target_paths[0] if target_paths else None
                    passed, output, tool_name, _parser = self._run_tests_for_target(
                        target_test_file,
                        test_name,
                    )
                else:
                    canonical_id = str(
                        issue.get("canonical_id") or issue.get("id") or ""
                    ).strip() or None
                    _run_tests = self._run_tests_fn if self._run_tests_fn is not None else self._run_tests
                    passed, output, tool_name, _parser = _run_tests(
                        modified_files=modified_files,
                        canonical_id=canonical_id,
                    )
                tests_run = self._capture_verification_run(
                    check="tests",
                    passed=passed,
                    fallback_tool=tool_name or "tests",
                )
                if output:
                    tests_run["output_excerpt"] = output[:800]
                verification_runs["tests"] = tests_run
                if passed is not None:
                    verification["tests_passed"] = passed
                    logger.info(f"Tests result: {passed}")
                    if passed is False and output:
                        verification.setdefault(
                            "last_tool_error",
                            {"tool": tool_name or "tests", "output": output[:800]},
                        )
                    if passed is False and is_test_gap:
                        issue_kind, resolution_path, _scope = self._resolve_intent(issue)
                        issue_metadata = (
                            issue.get("metadata", {})
                            if isinstance(issue.get("metadata"), dict)
                            else {}
                        )
                        already_promoted = bool(
                            issue_metadata.get("promotion_attempted")
                            or issue_metadata.get("promoted_from")
                            or str(issue.get("id", "")).endswith("-PROMO")
                        )
                        if (
                            issue_kind == "coverage_gap"
                            and resolution_path == "tests_only"
                            and not already_promoted
                        ):
                            promoted_issues.append(
                                self._build_promoted_defect_issue(issue, output=output or "")
                            )
            elif check == "lint":
                # FIX-REVIEW-LOOP-003: Lint modified files + issue source file
                lint_scope = list(modified_files) if modified_files else []
                issue_file = issue.get("file_path") or issue.get("file")
                if issue_file and issue_file not in lint_scope:
                    lint_scope.append(issue_file)
                _run_lint = self._run_lint_fn if self._run_lint_fn is not None else self._run_lint
                passed, output, tool_name, _parser = _run_lint(
                    modified_files=lint_scope or None
                )
                lint_run = self._capture_verification_run(
                    check="lint",
                    passed=passed,
                    fallback_tool=tool_name or "lint",
                )
                if output:
                    lint_run["output_excerpt"] = output[:800]
                verification_runs["lint"] = lint_run
                if passed is not None:
                    verification["lint_passed"] = passed
                    logger.info(f"Lint result: {passed}")
                    if passed is False and output:
                        verification.setdefault(
                            "last_tool_error",
                            {"tool": tool_name or "lint", "output": output[:800]},
                        )

        verification["verification_runs"] = verification_runs

        required_checks = ["agent_succeeded"]
        for check_key in ["tests_passed", "security_check_passed", "lint_passed"]:
            if check_key in verification:
                required_checks.append(check_key)

        if "target_test_file_modified" in verification:
            required_checks.append("target_test_file_modified")

        ran_tool_checks = any(
            key in verification for key in ["tests_passed", "security_check_passed", "lint_passed"]
        )
        if not ran_tool_checks:
            logger.warning(
                "No verification tools available - passing by default. "
                "Configure tools via fix.verification.tools or enable discovery."
            )
            if "target_test_file_modified" in verification:
                verification["all_passed"] = all(
                    verification.get(k, False) for k in required_checks
                )
            else:
                verification["all_passed"] = bool(verification.get("agent_succeeded"))
        else:
            verification["all_passed"] = all(verification.get(k, False) for k in required_checks)

        if not verification.get("all_passed"):
            if not verification.get("agent_succeeded"):
                verification["failure_reason"] = "agent_failed"
            elif verification.get("target_test_file_modified") is False:
                verification["failure_reason"] = "target_test_file_not_modified"
            elif verification.get("last_tool_error"):
                verification["failure_reason"] = "verification_failed"

        outcome, reason_code, scope_type, attribution_confidence = (
            self._classify_verification_outcome(
                verification=verification,
                ran_tool_checks=ran_tool_checks,
            )
        )
        verification["verification_outcome"] = outcome
        verification["verification_reason_code"] = reason_code
        verification["verification_scope"] = scope_type
        verification["attribution_confidence"] = attribution_confidence
        if outcome == "failed":
            verification["failure_reason"] = reason_code
        elif outcome == "inconclusive":
            verification["failure_reason"] = reason_code

        verification["new_issues"] = list(promoted_issues)
        if promoted_issues:
            verification["promoted_issues"] = promoted_issues

        logger.info(
            f"Verification complete: required_checks={required_checks}, "
            f"results={[verification.get(k) for k in required_checks]}, "
            f"all_passed={verification['all_passed']}"
        )
        return verification

    def _is_test_gap(self, issue: dict[str, Any]) -> bool:
        """Invoke test_gap_classifier callback; default False if not injected."""
        if self._test_gap_classifier is not None:
            return self._test_gap_classifier(issue)
        # Fallback: inline logic matching FixHandler._is_test_gap_issue
        issue_type = str(issue.get("issue_type", "")).lower()
        if issue_type == "test_gap":
            return True
        issue_id = str(issue.get("id", "")).upper()
        if issue_id.startswith("TEST-"):
            return True
        category = str(issue.get("category") or issue.get("dimension") or "").lower()
        if category in {"testing", "test_coverage", "test_quality", "edge_cases"}:
            return True
        issue_kind, resolution_path, _vs = self._resolve_intent(issue)
        return issue_kind == "coverage_gap" and resolution_path == "tests_only"

    def _get_test_gap_targets(self, issue: dict[str, Any]) -> list[str]:
        """Invoke test_gap_target_resolver callback; default [] if not injected."""
        if self._test_gap_target_resolver is not None:
            return self._test_gap_target_resolver(issue)
        return []

    def _resolve_intent(self, issue: dict[str, Any]) -> tuple[str, str, str]:
        """Invoke issue_intent_resolver callback; default values if not injected."""
        if self._issue_intent_resolver is not None:
            return self._issue_intent_resolver(issue)
        # Fallback: inline logic matching FixHandler._resolve_issue_intent
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        issue_kind = (issue.get("issue_kind") or metadata.get("issue_kind") or "defect").lower()
        resolution_path = (
            issue.get("resolution_path") or metadata.get("resolution_path") or "code_and_tests"
        ).lower()
        verification_scope = (
            issue.get("verification_scope") or metadata.get("verification_scope") or "auto"
        ).lower()
        return issue_kind, resolution_path, verification_scope

    def _resolve_checks_to_run(
        self,
        *,
        issue: dict[str, Any],
        category: str,
        is_test_gap: bool,
    ) -> list[str]:
        """Select verification checks, honoring explicit issue verification scope."""
        if is_test_gap:
            return ["tests"]

        _issue_kind, _resolution_path, verification_scope = self._resolve_intent(issue)
        if verification_scope == "tests":
            return ["tests"]
        if verification_scope == "lint":
            return ["lint"]
        if verification_scope == "security":
            return ["security"]

        if category == "security":
            return ["security"]
        if category == "testing":
            return ["tests"]
        if category == "code_quality":
            return ["lint"]

        logger.info("Unknown category - running all verification checks")
        return ["tests", "lint"]  # Skip security for perf

    def _run_security_check(self) -> bool | None:
        """Run security check. Returns True/False/None (None = tool unavailable)."""
        try:
            from obra.agents.security import SecurityAgent

            logger.info("Running security verification scan")
            agent = SecurityAgent(working_dir=self._working_dir, domain=self._domain)
            result = agent.analyze(
                item_id="fix-verification",
                changed_files=None,
                timeout_ms=30000,
            )
            critical_issues = [
                issue for issue in result.issues if issue.priority.value in ["P0", "P1"]
            ]
            if critical_issues:
                logger.warning(
                    f"Security verification failed: {len(critical_issues)} critical issues found"
                )
                for issue in critical_issues[:3]:
                    logger.warning(
                        f"  - {issue.priority.value} {issue.title} in {issue.file_path or 'unknown'}"
                    )
                return False
            logger.info(
                f"Security verification passed: {len(result.issues)} total issues, "
                f"0 critical (P0/P1)"
            )
            return True
        except ImportError as e:
            logger.warning(f"SecurityAgent not available - skipping security verification: {e}")
            return None
        except Exception as e:
            logger.error(f"Security check failed with error: {e}", exc_info=True)
            return False

    def _run_tests(
        self,
        modified_files: list[str] | None = None,
        canonical_id: str | None = None,
    ) -> tuple[bool | None, str, str, str]:
        """Run tests to verify a fix."""
        if not modified_files:
            logger.info("No files modified - skipping test verification")
            self._last_verification_run_metadata = {
                "tool": "tests",
                "category": "tests",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "skipped",
            }
            return True, "", "", ""

        tools = self._get_verification_tools_for_category("tests")
        if not tools:
            logger.info("No verification tools configured for tests - skipping")
            self._last_verification_run_metadata = {
                "tool": "tests",
                "category": "tests",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "unavailable",
            }
            return None, "", "", ""

        tool = tools[0]
        patterns = tool.get("patterns") if isinstance(tool, dict) else None

        focused_test_paths: list[str] = []
        if canonical_id and canonical_id in self._verification_target_snapshot:
            focused_test_paths = self._verification_target_snapshot[canonical_id]
            logger.info(
                "P1-3: Reusing snapshotted verification targets for %s: %s",
                canonical_id,
                focused_test_paths,
            )
        else:
            focused_test_paths = self._find_related_test_files(
                modified_files, patterns=patterns
            )
            if canonical_id and focused_test_paths:
                self._verification_target_snapshot[canonical_id] = focused_test_paths
                logger.info(
                    "P1-3: Snapshotted verification targets for %s: %s",
                    canonical_id,
                    focused_test_paths,
                )

        if focused_test_paths:
            return self._run_verification_tool(tool, files=focused_test_paths)
        logger.info("No focused test paths available - running full test command")
        return self._run_verification_tool(tool)

    def _run_tests_for_target(
        self,
        target_test_file: str | None,
        test_name: str | None,
    ) -> tuple[bool | None, str, str, str]:
        """Run tests targeting a specific test file or test name."""
        tools = self._get_verification_tools_for_category("tests")
        if not tools:
            logger.info("No verification tools configured for tests - skipping")
            self._last_verification_run_metadata = {
                "tool": "tests",
                "category": "tests",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "unavailable",
            }
            return None, "", "", ""

        tool = tools[0]
        if target_test_file or test_name:
            if test_name and target_test_file:
                target = f"{target_test_file}::{test_name}"
            else:
                target = target_test_file or test_name or ""
            if target:
                return self._run_verification_tool(tool, files=[target])

        return self._run_verification_tool(tool)

    def _find_related_test_files(
        self,
        modified_files: list[str],
        patterns: list[str] | None = None,
    ) -> list[str]:
        """Find test files related to the modified files."""
        default_patterns = [
            "test_*",
            "*_test.*",
            "*.test.*",
            "*.spec.*",
        ]
        test_patterns = patterns or default_patterns
        test_files = []
        for filepath in modified_files:
            path = Path(filepath)
            if any(fnmatch.fnmatch(path.name, pattern) for pattern in test_patterns):
                test_files.append(filepath)
                continue
            if any(part in {"tests", "test", "__tests__", "spec"} for part in path.parts):
                test_files.append(filepath)
                continue

            candidate_names = []
            for pattern in test_patterns:
                if "*" not in pattern:
                    continue
                candidate = pattern.replace("*", path.stem)
                candidate_names.append(candidate)

            candidate_paths = []
            for candidate in candidate_names:
                candidate_paths.extend(
                    [
                        path.parent / candidate,
                        path.parent / "tests" / candidate,
                        path.parent / "test" / candidate,
                        path.parent / "__tests__" / candidate,
                        path.parent / "spec" / candidate,
                        path.parent.parent / "tests" / candidate,
                    ]
                )

            for test_path in candidate_paths:
                full_path = self._working_dir / test_path
                if full_path.exists():
                    test_files.append(str(test_path))
                    logger.info(f"Found related test file: {test_path}")
                    break

        _test_dirs = {"tests", "test", "__tests__", "spec"}
        best_by_stem: dict[str, str] = {}
        for tf in test_files:
            tf_path = Path(tf)
            stem = tf_path.stem
            in_test_dir = any(part in _test_dirs for part in tf_path.parts)
            existing = best_by_stem.get(stem)
            if existing is None:
                best_by_stem[stem] = tf
            elif in_test_dir and not any(
                part in _test_dirs for part in Path(existing).parts
            ):
                best_by_stem[stem] = tf
        return list(best_by_stem.values())

    def _run_lint(
        self, modified_files: list[str] | None = None
    ) -> tuple[bool | None, str, str, str]:
        """Run lint verification for the modified files."""
        if not modified_files:
            logger.info("No files modified - skipping lint verification")
            self._last_verification_run_metadata = {
                "tool": "lint",
                "category": "lint",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "skipped",
            }
            return True, "", "", ""

        tools = self._get_verification_tools_for_category("lint")
        if not tools:
            logger.info("No verification tools configured for lint - skipping")
            self._last_verification_run_metadata = {
                "tool": "lint",
                "category": "lint",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "unavailable",
            }
            return None, "", "", ""

        tool = tools[0]
        return self._run_verification_tool(tool, files=modified_files)

    def _get_verification_tools_for_category(self, category: str) -> list[dict[str, Any]]:
        """Filter verification tools by category."""
        return [tool for tool in self._verification_tools if tool.get("category") == category]
