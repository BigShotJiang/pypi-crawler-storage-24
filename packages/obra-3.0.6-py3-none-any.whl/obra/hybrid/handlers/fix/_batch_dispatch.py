"""Batch dispatch for FixHandler.

Extracted from fix/_handler.py (S4 of REFACTOR-FIX-HANDLER-001).
Owns: issue priority ordering, batch grouping, batch classification,
      weight-aware rebalancing, prompt building, and all dispatch loops.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from obra.hybrid.handlers.fix._results import FixPassResults, IssueFixResult

if TYPE_CHECKING:
    from obra.display.observability import ProgressEmitter
    from obra.hybrid.handlers.fix._test_gap import TestGapResolver

logger = logging.getLogger(__name__)

__all__ = ["BatchDispatcher"]


class BatchDispatcher:
    """Groups issues into batches and dispatches them (parallel or sequential)."""

    def __init__(
        self,
        config: dict[str, Any],
        llm_config: dict[str, Any],
        progress_emitter: ProgressEmitter | None,
        log_event: Any | None,
        trace_id: str | None,
        parent_span_id: str | None,
        test_gap_resolver: TestGapResolver,
    ) -> None:
        self._config = config
        self._llm_config = llm_config
        self._progress_emitter = progress_emitter
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._test_gap = test_gap_resolver

    # ------------------------------------------------------------------
    # Priority ordering
    # ------------------------------------------------------------------

    def order_by_priority(self, issues: list[dict[str, Any]]) -> list[str]:
        """Return issue IDs sorted by priority (P0 first)."""
        from obra.config.loaders import get_priority_order

        priority_order = get_priority_order()

        def get_priority_rank(issue: dict[str, Any]) -> int:
            priority = issue.get("priority", "P3")
            return priority_order.get(priority, 4)

        sorted_issues = sorted(issues, key=get_priority_rank)
        return [issue.get("id", f"issue-{i}") for i, issue in enumerate(sorted_issues)]

    # ------------------------------------------------------------------
    # Batch grouping & classification
    # ------------------------------------------------------------------

    def group_issues_by_file(
        self,
        issues: list[dict[str, Any]],
        ordered_ids: list[str],
    ) -> list[dict[str, Any]]:
        """Group issues by file path for batch fixing."""
        issue_map = {
            issue.get("id") or issue.get("canonical_id") or f"issue-{i}": issue
            for i, issue in enumerate(issues)
        }
        batches: dict[str | None, list] = defaultdict(list)

        for issue_id in ordered_ids:
            issue = issue_map.get(issue_id)
            if issue:
                if self._test_gap.is_test_gap(issue):
                    target_paths = self._test_gap.get_target_paths(issue)
                    file_path = target_paths[0] if target_paths else None
                else:
                    file_path = issue.get("file_path") or issue.get("file")
                batches[file_path].append(issue)

        result = [{"file_path": fp, "issues": batch} for fp, batch in batches.items()]
        batched_count = sum(len(b["issues"]) for b in result)
        if batched_count < len(issues):
            missing_ids = set(issue_map.keys()) - {
                issue.get("id", "") for b in result for issue in b["issues"]
            }
            logger.warning(
                "Batch grouping dropped %d of %d issues (ID mismatch). Missing: %s",
                len(issues) - batched_count,
                len(issues),
                sorted(missing_ids),
            )
        return result

    def classify_batches(
        self,
        batches: list[dict[str, Any]],
        max_batch: int,
    ) -> tuple[list[tuple[int, dict[str, Any]]], list[tuple[int, dict[str, Any]]]]:
        """Classify pre-grouped batches into individual and parallelizable lists.

        Returns:
            (individual_batches, parallelizable_batches) — each a list of
            (batch_index, batch_dict) tuples.
        """
        individual: list[tuple[int, dict[str, Any]]] = []
        parallelizable: list[tuple[int, dict[str, Any]]] = []

        for batch_index, batch in enumerate(batches, start=1):
            if batch["file_path"] is None or len(batch["issues"]) == 1:
                individual.append((batch_index, batch))
            elif len(batch["issues"]) > max_batch:
                # Expand over-sized batches into sub-batches
                for i in range(0, len(batch["issues"]), max_batch):
                    sub_batch = {
                        "file_path": batch["file_path"],
                        "issues": batch["issues"][i : i + max_batch],
                    }
                    parallelizable.append((batch_index, sub_batch))
            else:
                parallelizable.append((batch_index, batch))

        return individual, parallelizable

    # ------------------------------------------------------------------
    # Weight-aware rebalancing
    # ------------------------------------------------------------------

    @staticmethod
    def estimate_batch_weight(batch: dict[str, Any]) -> int:
        """Estimate LLM processing weight for a batch (floor 100)."""
        weight = 0
        for issue in batch.get("issues", []):
            weight += len(issue.get("description", ""))
            weight += len(str(issue.get("error_message", "")))
            weight += len(str(issue.get("message", "")))
        return max(weight, 100)

    @staticmethod
    def rebalance(
        batches: list[tuple[int, dict[str, Any]]],
    ) -> list[tuple[int, dict[str, Any]]]:
        """Reorder batches heaviest-first to reduce the parallel straggler ratio."""
        return sorted(
            batches,
            key=lambda pair: BatchDispatcher.estimate_batch_weight(pair[1]),
            reverse=True,
        )

    # ------------------------------------------------------------------
    # Batch prompt building
    # ------------------------------------------------------------------

    def build_batch_prompt(
        self,
        batch: dict[str, Any],
        base_prompt: str,
        refactor_mode: bool = False,
    ) -> str:
        """Build prompt for fixing multiple issues in the same file.

        FIX-REVIEW-LOOP-002: Includes actual file contents for the fix agent.
        """
        import contextlib

        from obra.prompts.fix.context import (
            build_batch_fix_context,
            build_test_gap_batch_context,
        )

        file_path = batch["file_path"]
        issues = batch["issues"]
        is_test_gap_batch = bool(issues) and all(
            self._test_gap.is_test_gap(issue) for issue in issues
        )

        if is_test_gap_batch:
            test_file_contents = None
            if file_path:
                test_file_contents = self._test_gap.read_file_for_fix(
                    file_path, None, context_lines=100
                )
                if not test_file_contents:
                    logger.warning(
                        "Could not read test file %s for batch fix context", file_path
                    )

            source_contexts: dict[str, str] = {}
            for issue in issues:
                source_path = issue.get("file_path") or issue.get("file")
                line_number = issue.get("line_number") or issue.get("line")
                if source_path:
                    source_contents = self._test_gap.read_file_for_fix(
                        source_path, line_number
                    )
                    if source_contents:
                        source_contexts[issue.get("id", "")] = source_contents

            context = build_test_gap_batch_context(
                file_path or "unknown",
                issues,
                test_file_contents,
                source_contexts,
            )
            return context + base_prompt

        # Regular batch: include file contents
        file_contents = None
        if file_path:
            line_numbers = []
            for issue in issues:
                line_num = issue.get("line_number") or issue.get("line")
                if line_num:
                    with contextlib.suppress(ValueError, TypeError):
                        line_numbers.append(int(line_num))
            target_line = min(line_numbers) if line_numbers else None
            file_contents = self._test_gap.read_file_for_fix(
                file_path, target_line, context_lines=100
            )
            if not file_contents:
                logger.warning(
                    "Could not read file %s for batch fix context", file_path
                )

        context = build_batch_fix_context(
            file_path,
            issues,
            file_contents,
            refactor_mode=refactor_mode,
        )
        return context + base_prompt

    # ------------------------------------------------------------------
    # Dispatch loops
    # ------------------------------------------------------------------

    def dispatch_parallel(
        self,
        batches: list[tuple[int, dict[str, Any]]],
        *,
        execute_worker_fn: Callable[[dict[str, Any], str], list[dict[str, Any]]],
        on_issue_result: Callable[
            [str | None, dict[str, Any], dict[str, Any] | None], tuple[int, int, int]
        ],
        issue_map: dict[str, dict[str, Any]],
        enriched_prompt: str,
    ) -> tuple[FixPassResults, set[str]]:
        """Run parallelizable batches concurrently.

        Args:
            batches: List of (batch_index, batch_dict) tuples.
            execute_worker_fn: Called per batch; returns list of per-issue result dicts.
            on_issue_result: Called per issue result; handles failure recording +
                             emitting display lines; returns (fixed, failed, skipped) deltas.
            issue_map: Maps issue_id → issue dict.
            enriched_prompt: Base prompt passed to each worker.

        Returns:
            (FixPassResults, set_of_processed_issue_ids)
        """
        from obra.config.loaders import (
            get_fix_handler_parallel_workers,
            get_parallel_worker_delay_s,
        )
        from obra.hybrid.parallel import ParallelExecutor, ParallelResult

        provider = self._llm_config.get("provider", "anthropic")
        n_workers = get_fix_handler_parallel_workers()
        n_batches = len(batches)
        n_items = sum(len(b["issues"]) for _, b in batches)

        def _on_parallel_complete(
            pr: ParallelResult[list[dict[str, Any]]],
        ) -> None:
            batch_statuses = [r.status for r in pr.results]
            if self._progress_emitter:
                self._progress_emitter.parallel_batch_completed(
                    "fix",
                    wall_clock_ms=pr.wall_clock_ms,
                    speedup_ratio=pr.speedup_ratio,
                    batches_failed=pr.items_failed,
                    batches_total=pr.items_total,
                    batch_statuses=batch_statuses,
                )
            if self._log_event:
                self._log_event(
                    "fix_parallel_completed",
                    wall_clock_ms=pr.wall_clock_ms,
                    worker_count=pr.worker_count,
                    items_total=pr.items_total,
                    items_succeeded=pr.items_succeeded,
                    items_failed=pr.items_failed,
                    speedup_ratio=pr.speedup_ratio,
                    straggler_ratio=pr.straggler_ratio,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )

        executor = ParallelExecutor(
            max_workers=n_workers,
            worker_delay_s=get_parallel_worker_delay_s(provider),
            label="fix-batch",
            on_execution_complete=_on_parallel_complete,
        )

        logger.info("Parallel fix dispatch: %d batches, max_workers=%d", n_batches, n_workers)

        if self._progress_emitter:
            self._progress_emitter.parallel_batch_started(
                "fix",
                workers=n_workers,
                batches=n_batches,
                items=n_items,
            )
        if self._log_event:
            batch_weights = [self.estimate_batch_weight(b) for _, b in batches]
            self._log_event(
                "fix_parallel_started",
                workers=n_workers,
                batches=n_batches,
                items=n_items,
                total_batch_weight=sum(batch_weights),
                max_batch_weight=max(batch_weights) if batch_weights else 0,
                min_batch_weight=min(batch_weights) if batch_weights else 0,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

        # Build worker list with closure capture to avoid late-binding.
        items: list[tuple[str, Callable[[], list[dict[str, Any]]]]] = []
        for bi, b in batches:
            def _make_worker(
                _batch: dict[str, Any] = b,
            ) -> list[dict[str, Any]]:
                return execute_worker_fn(_batch, enriched_prompt)

            items.append((f"batch-{bi}:{b['file_path']}", _make_worker))

        parallel_result: ParallelResult[list[dict[str, Any]]] = executor.execute(items)

        logger.info(
            "Parallel fix complete: %d/%d succeeded, wall=%.1fms, speedup=%.2fx",
            parallel_result.items_succeeded,
            parallel_result.items_total,
            parallel_result.wall_clock_ms,
            parallel_result.speedup_ratio,
        )

        # Single-threaded merge phase.
        results = FixPassResults.empty()
        processed_ids: set[str] = set()

        for worker_result in parallel_result.results:
            _, p_batch = batches[worker_result.index]
            if worker_result.status == "success" and worker_result.result:
                batch_results = worker_result.result
            else:
                error_msg = (
                    str(worker_result.error) if worker_result.error else "Worker failed"
                )
                batch_results = [
                    {
                        "issue_id": iss.get("id") or "",
                        "canonical_id": (iss.get("canonical_id") or iss.get("id") or ""),
                        "status": "failed",
                        "reason": "parallel_worker_error",
                        "files_modified": [],
                        "verification": {"error": error_msg},
                        "verification_issues": [],
                        "summary": f"Worker error: {error_msg}",
                        "approach_summary": f"Parallel worker error: {error_msg}",
                    }
                    for iss in p_batch["issues"]
                ]

            for result in batch_results:
                issue_id = result.get("issue_id")
                processed_ids.add(issue_id or "")
                issue = issue_map.get(issue_id or "")
                deltas = on_issue_result(issue_id, result, issue)
                results = results.merge(
                    IssueFixResult(
                        issue_id=issue_id or "",
                        status=str(result.get("status", "failed")),
                        result=result,
                        issue=issue,
                    ),
                    deltas,
                )

        return results, processed_ids

    def dispatch_sequential(
        self,
        batches: list[tuple[int, dict[str, Any]]],
        *,
        fix_batch_fn: Callable[[dict[str, Any], str], list[dict[str, Any]]],
        on_issue_result: Callable[
            [str | None, dict[str, Any], dict[str, Any] | None], tuple[int, int, int]
        ],
        issue_map: dict[str, dict[str, Any]],
        enriched_prompt: str,
        print_batch_progress_fn: Callable[[dict[str, Any], int, int], None],
        total_batches: int,
    ) -> tuple[FixPassResults, set[str]]:
        """Run parallelizable batches sequentially (parallel disabled or <2 batches).

        Args:
            batches: List of (batch_index, batch_dict) tuples.
            fix_batch_fn: Called per batch; returns per-issue result dicts.
            on_issue_result: Called per issue result.
            issue_map: Maps issue_id → issue dict.
            enriched_prompt: Base prompt.
            print_batch_progress_fn: Called before each batch (batch, index, total).
            total_batches: Total batch count for progress display.

        Returns:
            (FixPassResults, set_of_processed_issue_ids)
        """
        results = FixPassResults.empty()
        processed_ids: set[str] = set()

        for batch_index, batch in batches:
            print_batch_progress_fn(batch, batch_index, total_batches)
            batch_fix_results = fix_batch_fn(batch, enriched_prompt)

            for result in batch_fix_results:
                issue_id = result.get("issue_id")
                processed_ids.add(issue_id or "")
                issue = issue_map.get(issue_id or "")
                deltas = on_issue_result(issue_id, result, issue)
                results = results.merge(
                    IssueFixResult(
                        issue_id=issue_id or "",
                        status=str(result.get("status", "failed")),
                        result=result,
                        issue=issue,
                    ),
                    deltas,
                )

        return results, processed_ids

    def dispatch_individual_batches(
        self,
        batches: list[tuple[int, dict[str, Any]]],
        *,
        fix_issue_fn: Callable[[dict[str, Any], str], dict[str, Any]],
        on_issue_result: Callable[
            [str | None, dict[str, Any], dict[str, Any] | None], tuple[int, int, int]
        ],
        print_issue_progress_fn: Callable[[dict[str, Any], int, int], None],
        issues: list[dict[str, Any]],
        issue_counter: int,
        enriched_prompt: str,
        should_skip_fn: Callable[[dict[str, Any]], bool],
        build_skip_fn: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> tuple[FixPassResults, set[str], int]:
        """Run type-1 (individual / no file_path) batches sequentially.

        Args:
            batches: List of (batch_index, batch_dict) individual-type tuples.
            fix_issue_fn: Callable that fixes a single issue.
            on_issue_result: Called per issue result.
            print_issue_progress_fn: Called before fixing each issue (issue, idx, total).
            issues: Full issue list (for total count display).
            issue_counter: Starting counter value (usually 0 or from prior dispatch).
            enriched_prompt: Base prompt.
            should_skip_fn: Returns True if the issue should be skipped.
            build_skip_fn: Returns a skip result dict for a skipped issue.

        Returns:
            (FixPassResults, set_of_processed_issue_ids, final_issue_counter)
        """
        results = FixPassResults.empty()
        processed_ids: set[str] = set()

        for _batch_index, batch in batches:
            for issue in batch["issues"]:
                issue_counter += 1
                print_issue_progress_fn(issue, issue_counter, len(issues))
                # ISSUE-HYBRID-044: Skip issues that exceeded max fix attempts
                if should_skip_fn(issue):
                    result = build_skip_fn(issue)
                else:
                    result = fix_issue_fn(issue, enriched_prompt)

                issue_id = issue.get("id")
                processed_ids.add(issue.get("id", ""))
                deltas = on_issue_result(issue_id, result, issue)
                results = results.merge(
                    IssueFixResult(
                        issue_id=issue_id or "",
                        status=str(result.get("status", "failed")),
                        result=result,
                        issue=issue,
                    ),
                    deltas,
                )

        return results, processed_ids, issue_counter

    def dispatch_linear(
        self,
        ordered_ids: list[str],
        *,
        issue_map: dict[str, dict[str, Any]],
        fix_issue_fn: Callable[[dict[str, Any], str], dict[str, Any]],
        should_skip_fn: Callable[[dict[str, Any]], bool],
        build_skip_fn: Callable[[dict[str, Any]], dict[str, Any]],
        on_issue_result: Callable[
            [str | None, dict[str, Any], dict[str, Any] | None], tuple[int, int, int]
        ],
        print_issue_progress_fn: Callable[[dict[str, Any], int, int], None],
        issues: list[dict[str, Any]],
        enriched_prompt: str,
    ) -> tuple[FixPassResults, int]:
        """Run all issues sequentially (batching disabled or force_individual).

        Args:
            ordered_ids: Issue IDs in execution order.
            issue_map: Maps issue_id → issue dict.
            fix_issue_fn: Callable to fix a single issue.
            should_skip_fn: Returns True if issue should be skipped.
            build_skip_fn: Returns skip result dict.
            on_issue_result: Called per issue result.
            print_issue_progress_fn: Progress display.
            issues: Full issue list (for total count).
            enriched_prompt: Base prompt.

        Returns:
            (FixPassResults, final_issue_counter)
        """
        results = FixPassResults.empty()
        issue_counter = 0
        idx = 0

        while idx < len(ordered_ids):
            issue_id = ordered_ids[idx]
            issue = issue_map.get(issue_id)
            if not issue:
                logger.warning("Issue %s not found in issue map, skipping", issue_id)
                results = results.merge(
                    IssueFixResult(
                        issue_id=issue_id,
                        status="skipped",
                        result={"issue_id": issue_id, "status": "skipped"},
                        issue=None,
                    ),
                    (0, 0, 1),
                )
                idx += 1
                continue

            issue_counter += 1
            print_issue_progress_fn(issue, issue_counter, len(issues))
            # ISSUE-HYBRID-044: Skip issues that exceeded max fix attempts
            if should_skip_fn(issue):
                result = build_skip_fn(issue)
            else:
                result = fix_issue_fn(issue, enriched_prompt)
            deltas = on_issue_result(issue_id, result, issue)
            results = results.merge(
                IssueFixResult(
                    issue_id=issue_id,
                    status=str(result.get("status", "failed")),
                    result=result,
                    issue=issue,
                ),
                deltas,
            )
            idx += 1

        return results, issue_counter

    def dispatch_leftover_issues(
        self,
        ordered_ids: list[str],
        processed_ids: set[str],
        issue_map: dict[str, dict[str, Any]],
        *,
        fix_issue_fn: Callable[[dict[str, Any], str], dict[str, Any]],
        should_skip_fn: Callable[[dict[str, Any]], bool],
        build_skip_fn: Callable[[dict[str, Any]], dict[str, Any]],
        on_issue_result: Callable[
            [str | None, dict[str, Any], dict[str, Any] | None], tuple[int, int, int]
        ],
        print_issue_progress_fn: Callable[[dict[str, Any], int, int], None],
        issues: list[dict[str, Any]],
        issue_counter: int,
        enriched_prompt: str,
    ) -> tuple[FixPassResults, int]:
        """Fix issues not covered by any batch (ID-mismatch fallback).

        Args:
            ordered_ids: Full list of issue IDs in execution order.
            processed_ids: IDs already processed by batch dispatch.
            issue_map: Maps issue_id → issue dict.
            fix_issue_fn: Called to fix a single issue.
            should_skip_fn: Returns True if issue should be skipped.
            build_skip_fn: Returns skip result dict.
            on_issue_result: Called per result; handles failure recording + display.
            print_issue_progress_fn: Progress display.
            issues: Full issue list (for total count).
            issue_counter: Starting counter (from prior dispatch).
            enriched_prompt: Base prompt.

        Returns:
            (FixPassResults, final_issue_counter)
        """
        results = FixPassResults.empty()

        for issue_id in ordered_ids:
            if issue_id in processed_ids:
                continue
            issue = issue_map.get(issue_id)
            if not issue:
                logger.warning("Issue %s not found in issue map, skipping", issue_id)
                results = results.merge(
                    IssueFixResult(
                        issue_id=issue_id,
                        status="skipped",
                        result={"issue_id": issue_id, "status": "skipped"},
                        issue=None,
                    ),
                    (0, 0, 1),
                )
                continue

            issue_counter += 1
            print_issue_progress_fn(issue, issue_counter, len(issues))
            # ISSUE-HYBRID-044: Skip issues that exceeded max fix attempts
            if should_skip_fn(issue):
                result = build_skip_fn(issue)
            else:
                result = fix_issue_fn(issue, enriched_prompt)
            deltas = on_issue_result(issue_id, result, issue)
            results = results.merge(
                IssueFixResult(
                    issue_id=issue_id,
                    status=str(result.get("status", "failed")),
                    result=result,
                    issue=issue,
                ),
                deltas,
            )

        return results, issue_counter
