"""Fix attempt tracking for FixHandler.

Tracks per-issue and per-file fix attempt counts to prevent infinite retry loops.

Addresses:
- ISSUE-HYBRID-044: Per-fingerprint fix attempt limit
- FIX-HYBRID-048: File-level failure tracking
- SESSION-92257c4c: Cross-cycle convergence guard
"""

import logging
from pathlib import Path
from typing import Any

from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record

logger = logging.getLogger(__name__)


class FixAttemptTracker:
    """Tracks fix attempts per issue and per file to enforce retry limits.

    Also tracks cross-cycle canonical ID reapplication to detect non-converging
    fix loops (SESSION-92257c4c).
    """

    def __init__(
        self,
        config: dict[str, Any],
        session_id: str | None,
        working_dir: Path,
        log_event: Any | None,
        trace_id: str | None,
    ) -> None:
        self._config = config
        self._session_id = session_id
        self._working_dir = working_dir
        self._log_event = log_event
        self._trace_id = trace_id
        self._fix_attempt_history: dict[str, int] = {}
        self._file_failure_history: dict[str, int] = {}
        # Cross-cycle tracking: canonical_id → total times applied across cycles
        self._cycle_reapply_counts: dict[str, int] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def should_skip(self, issue: dict[str, Any]) -> bool:
        """Check if issue has exceeded max fix attempts."""
        return self._should_skip_issue(issue)

    def should_suppress_convergence(self, issue: dict[str, Any]) -> bool:
        """Check if issue has exceeded cross-cycle reapplication limit."""
        canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
        max_reapply = int(
            self._config.get("fix", {}).get("convergence", {}).get("max_reapply", 2)
        )
        return self._cycle_reapply_counts.get(canonical_id, 0) >= max_reapply

    def record_cycle_application(self, issue: dict[str, Any]) -> None:
        """Record that a canonical issue is being applied in a new fix cycle."""
        canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
        self._cycle_reapply_counts[canonical_id] = (
            self._cycle_reapply_counts.get(canonical_id, 0) + 1
        )

    def get_reapplied_ids(self, issues: list[dict[str, Any]]) -> list[str]:
        """Return canonical IDs from issues that have been applied in prior cycles."""
        reapplied = []
        for issue in issues:
            canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
            if self._cycle_reapply_counts.get(canonical_id, 0) > 0:
                reapplied.append(canonical_id)
        return reapplied

    def get_cycle_reapply_counts(self) -> dict[str, int]:
        """Return the cross-cycle reapplication counts for all tracked canonical IDs."""
        return dict(self._cycle_reapply_counts)

    def record_failure(self, issue: dict[str, Any]) -> None:
        """Increment failure counter for a canonical issue and its file."""
        self._record_fix_failure(issue)

    def build_skip(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Build a skip result for an issue that exceeded max attempts."""
        return self._build_skip_result(issue)

    def build_convergence_skip(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Build a skip result for an issue suppressed by convergence guard."""
        issue_id = issue.get("id", "unknown")
        canonical_id = issue.get("canonical_id") or issue_id
        count = self._cycle_reapply_counts.get(canonical_id, 0)
        max_reapply = int(
            self._config.get("fix", {}).get("convergence", {}).get("max_reapply", 2)
        )

        create_skip_record(
            session_id=self._session_id or "",
            task_id=canonical_id,
            source=SkipSource.QUALITY_LOOP,
            reason=SkipReason.DIMINISHING_RETURNS,
            description=(
                f"Fix suppressed by convergence guard: {canonical_id} "
                f"applied {count}x (limit {max_reapply})"
            ),
            source_context={
                "canonical_id": canonical_id,
                "cycle_reapply_count": count,
                "max_reapply": max_reapply,
                "issue_id": issue_id,
                "phase": "fix",
                "error_type": "convergence_limit_reached",
            },
            base_dir=self._working_dir,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        logger.info(
            "Convergence guard: suppressing %s after %d reapplications (limit %d)",
            canonical_id,
            count,
            max_reapply,
        )

        return {
            "issue_id": issue_id,
            "canonical_id": canonical_id,
            "status": "skipped",
            "reason": "convergence_limit_reached",
            "files_modified": [],
            "verification": {},
            "verification_issues": [],
            "summary": (
                f"Suppressed {issue_id}: convergence limit reached "
                f"({count} reapplications)"
            ),
        }

    def reset(self) -> None:
        """Clear per-cycle attempt history (called on fresh_fix).

        Note: _cycle_reapply_counts is NOT reset — it tracks across the full
        item lifecycle to detect non-convergence.
        """
        self._fix_attempt_history = {}
        self._file_failure_history = {}

    # ------------------------------------------------------------------
    # Implementation
    # ------------------------------------------------------------------

    def _should_skip_issue(self, issue: dict[str, Any]) -> bool:
        """Check if an issue has exceeded max fix attempts.

        Checks both per-canonical-ID limit and per-file cumulative limit.
        The file-level check (FIX-HYBRID-048) catches re-fingerprinted
        variants of previously failed issues that get new canonical IDs.
        """
        canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
        max_attempts = int(
            self._config.get("fix", {}).get("max_attempts_per_issue", 2)
        )
        if self._fix_attempt_history.get(canonical_id, 0) >= max_attempts:
            return True
        # FIX-HYBRID-048: File-level exhaustion — catches re-fingerprinted issues
        file_path = issue.get("file_path") or issue.get("file") or ""
        if file_path:
            max_file_failures = int(
                self._config.get("fix", {}).get("max_failures_per_file", 4)
            )
            if self._file_failure_history.get(file_path, 0) >= max_file_failures:
                return True
        return False

    def _record_fix_failure(self, issue: dict[str, Any]) -> None:
        """Increment failure counter for a canonical issue and its file."""
        canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
        self._fix_attempt_history[canonical_id] = (
            self._fix_attempt_history.get(canonical_id, 0) + 1
        )
        # FIX-HYBRID-048: Track file-level failures
        file_path = issue.get("file_path") or issue.get("file") or ""
        if file_path:
            self._file_failure_history[file_path] = (
                self._file_failure_history.get(file_path, 0) + 1
            )

    def _build_skip_result(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Build a skip result for an issue that exceeded max attempts."""
        issue_id = issue.get("id", "unknown")
        canonical_id = issue.get("canonical_id") or issue_id
        description = issue.get("description", "")
        count = self._fix_attempt_history.get(canonical_id, 0)

        # Emit skip record for cleanup tracking
        # P1-2: Include diagnostic enrichment fields for post-session analysis
        create_skip_record(
            session_id=self._session_id or "",
            task_id=canonical_id,
            source=SkipSource.QUALITY_LOOP,
            reason=SkipReason.DIMINISHING_RETURNS,
            description=(
                f"Fix skipped after {count} consecutive failures: "
                f"{description[:120]}"
            ),
            source_context={
                "canonical_id": canonical_id,
                "attempt_count": count,
                "issue_id": issue_id,
                "phase": "fix",
                "error_type": "scoped_verification_failed",
            },
            base_dir=self._working_dir,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        logger.info(
            "ISSUE-HYBRID-044: Skipping %s after %d failed attempts",
            canonical_id,
            count,
        )

        return {
            "issue_id": issue_id,
            "canonical_id": canonical_id,
            "status": "skipped",
            "reason": "max_fix_attempts_exceeded",
            "files_modified": [],
            "verification": {},
            "verification_issues": [],
            "summary": (
                f"Skipped issue {issue_id}: exceeded {count} fix attempts"
            ),
        }
