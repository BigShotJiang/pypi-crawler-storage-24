"""Test-gap resolution for FixHandler.

Extracted from fix/_handler.py (S4 of REFACTOR-FIX-HANDLER-001).
Owns: test-gap classification, target inference, and file reading for fix context.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Module-level helpers (extracted from FixHandler staticmethods)
# ---------------------------------------------------------------------------


def resolve_issue_intent(issue: dict[str, Any]) -> tuple[str, str, str]:
    """Extract issue_kind, resolution_path, verification_scope from an issue dict."""
    metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
    issue_kind = (issue.get("issue_kind") or metadata.get("issue_kind") or "defect").lower()
    resolution_path = (
        issue.get("resolution_path") or metadata.get("resolution_path") or "code_and_tests"
    ).lower()
    verification_scope = (
        issue.get("verification_scope") or metadata.get("verification_scope") or "auto"
    ).lower()
    return issue_kind, resolution_path, verification_scope


def normalize_target_paths(target_paths: Any) -> list[str]:
    """Normalize target_paths to a flat list of non-empty strings."""
    if not target_paths:
        return []
    if isinstance(target_paths, list):
        return [str(path).strip() for path in target_paths if str(path).strip()]
    if isinstance(target_paths, str):
        return [path.strip() for path in target_paths.split(",") if path.strip()]
    return []


# ---------------------------------------------------------------------------
# TestGapResolver
# ---------------------------------------------------------------------------


class TestGapResolver:
    """Resolve test-gap issues: classify, find targets, infer targets, read files."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        llm_config: dict[str, Any] | None = None,
        session_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._config = config
        self._llm_config = llm_config or {}
        self._session_id = session_id

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def is_test_gap(self, issue: dict[str, Any]) -> bool:
        """Return True if the issue is a test-gap issue."""
        issue_type = str(issue.get("issue_type", "")).lower()
        if issue_type == "test_gap":
            return True
        category = str(issue.get("category") or issue.get("dimension") or "").lower()
        if category in {"testing", "test_coverage", "test_quality", "edge_cases"}:
            return True
        issue_kind, resolution_path, _ = resolve_issue_intent(issue)
        return issue_kind == "coverage_gap" and resolution_path == "tests_only"

    def get_target_paths(self, issue: dict[str, Any]) -> list[str]:
        """Return test target paths for a test-gap issue."""
        target_paths = normalize_target_paths(issue.get("target_paths"))
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        if not target_paths:
            target_paths = normalize_target_paths(metadata.get("target_paths"))
        target_test_file = (
            issue.get("target_test_file") or metadata.get("target_test_file") or ""
        )
        if target_test_file and target_test_file not in target_paths:
            target_paths.insert(0, target_test_file)
        return target_paths

    def resolve(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Ensure the issue has a target_test_file; enriches in-place and returns it."""
        target_paths = self.get_target_paths(issue)
        if target_paths:
            issue["target_test_file"] = target_paths[0]
            issue["target_paths"] = target_paths
            return issue

        target, confidence, rationale = self.infer_target(issue)
        threshold = self._get_confidence_threshold()
        if target and confidence is not None and confidence >= threshold:
            issue["target_test_file"] = target
            issue["target_paths"] = [target]
            issue.setdefault("metadata", {})["inference_confidence"] = confidence
            issue["metadata"]["inference_rationale"] = rationale or ""
            return issue

        if confidence is None:
            reason = "Inference failed"
        else:
            reason = rationale or "Inference confidence below threshold"
        issue.setdefault("metadata", {})["inference_error"] = reason
        return issue

    def read_file_for_fix(
        self,
        file_path: str,
        line_number: int | str | None = None,
        context_lines: int = 50,
    ) -> str | None:
        """Read file contents with line numbers for inclusion in a fix prompt.

        FIX-REVIEW-LOOP-002: The fix agent needs to see actual file contents.
        """
        try:
            full_path = self._working_dir / file_path
            if not full_path.exists():
                logger.warning("File not found for fix context: %s", full_path)
                return None

            content = full_path.read_text(encoding="utf-8", errors="replace")
            lines = content.splitlines()

            if line_number:
                try:
                    target_line = int(line_number)
                    start = max(0, target_line - context_lines - 1)
                    end = min(len(lines), target_line + context_lines)
                    lines = lines[start:end]
                    line_offset = start + 1
                except (ValueError, TypeError):
                    line_offset = 1
            else:
                if len(lines) > 300:
                    head = lines[:200]
                    tail = lines[-50:]
                    lines = [
                        *head,
                        "",
                        f"... ({len(lines) - 250} lines omitted) ...",
                        "",
                        *tail,
                    ]
                line_offset = 1

            numbered_lines = []
            for i, line in enumerate(lines):
                if "lines omitted" in line:
                    numbered_lines.append(line)
                else:
                    line_num = line_offset + i
                    numbered_lines.append(f"{line_num:>4}: {line}")

            return "\n".join(numbered_lines)

        except Exception as e:
            logger.warning("Failed to read file %s for fix context: %s", file_path, e)
            return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def collect_candidates(self, issue: dict[str, Any]) -> list[str]:
        """Collect candidate test file paths for LLM inference."""
        from obra.config.loaders import get_fix_test_gap_inference_max_candidates

        max_candidates = get_fix_test_gap_inference_max_candidates()
        source_path = issue.get("file_path") or issue.get("file") or ""
        candidates: list[str] = []

        if source_path:
            candidates.extend(self.find_related_test_files([source_path]))

        if len(candidates) < max_candidates:
            test_roots = [
                self._working_dir / "tests",
                self._working_dir / "test",
                self._working_dir / "__tests__",
                self._working_dir / "spec",
                self._working_dir / "obra" / "tests",
            ]
            patterns = ["test_*.py", "*_test.py", "*.test.py", "*.spec.py"]
            for root in test_roots:
                if not root.exists():
                    continue
                for pattern in patterns:
                    for path in root.rglob(pattern):
                        rel_path = str(path.relative_to(self._working_dir))
                        if rel_path not in candidates:
                            candidates.append(rel_path)
                        if len(candidates) >= max_candidates:
                            break
                    if len(candidates) >= max_candidates:
                        break
                if len(candidates) >= max_candidates:
                    break

        return candidates[:max_candidates]

    def infer_target(
        self, issue: dict[str, Any]
    ) -> tuple[str | None, float | None, str | None]:
        """Use LLM to infer the target test file for a test-gap issue."""
        from obra.config.loaders import (
            get_fix_llm_test_gap_timeout,
            get_fix_test_gap_inference_enabled,
        )
        from obra.prompts.fix.context import build_test_gap_inference_prompt

        if not self._llm_config:
            return None, None, "LLM config missing for test-gap inference"

        if not get_fix_test_gap_inference_enabled():
            return None, None, "Test-gap inference disabled by config"

        candidates = self.collect_candidates(issue)
        prompt = build_test_gap_inference_prompt(issue, candidates)

        try:
            from obra.config.llm import DEFAULT_REASONING_LEVEL
            from obra.llm import LLMSubprocessConfig, run_llm_subprocess

            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            reasoning_level = self._llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")

            config = LLMSubprocessConfig(
                prompt=prompt,
                cwd=self._working_dir,
                provider=provider,
                model=model,
                reasoning_level=reasoning_level,
                mode="text",
                auth_method=auth_method,
                timeout_s=get_fix_llm_test_gap_timeout(),
                skip_git_check=True,
                streaming=False,
                call_site="fix_test_gap_infer",
                run_id=self._session_id,
            )
            result = run_llm_subprocess(config)
            if not result.success:
                error_message = result.error or "LLM inference failed"
                if result.failure_class and "failure_class=" not in error_message:
                    error_message = f"{error_message} (failure_class={result.failure_class})"
                if result.error_details and result.error_details.request_id:
                    if "request_id=" not in error_message:
                        error_message = (
                            f"{error_message} (request_id={result.error_details.request_id})"
                        )
                if result.retry_count and "retries=" not in error_message:
                    error_message = f"{error_message} (retries={result.retry_count})"
                return None, None, error_message

            response_text = result.output.strip()
            payload = json.loads(response_text)
            if not isinstance(payload, dict):
                return None, None, "Inference response was not JSON object"

            target = str(payload.get("target_test_file", "")).strip()
            confidence = payload.get("confidence")
            rationale = payload.get("rationale") or ""
            if not target:
                return None, None, "Inference returned empty target_test_file"
            try:
                confidence_val = float(confidence) if confidence is not None else None
            except (TypeError, ValueError):
                confidence_val = None
            return target, confidence_val, str(rationale)
        except Exception as exc:
            return None, None, f"Test-gap inference error: {exc}"

    def find_related_test_files(
        self,
        modified_files: list[str],
        patterns: list[str] | None = None,
    ) -> list[str]:
        """Find test files related to the given source files."""
        import fnmatch

        default_patterns = [
            "test_*",
            "*_test.*",
            "*.test.*",
            "*.spec.*",
        ]
        test_patterns = patterns or default_patterns
        test_files = []
        for filepath in modified_files:
            path = Path(filepath)
            if any(fnmatch.fnmatch(path.name, pattern) for pattern in test_patterns):
                test_files.append(filepath)
                continue
            if any(part in {"tests", "test", "__tests__", "spec"} for part in path.parts):
                test_files.append(filepath)
                continue

            candidate_names = []
            for pattern in test_patterns:
                if "*" not in pattern:
                    continue
                candidate = pattern.replace("*", path.stem)
                candidate_names.append(candidate)

            candidate_paths = []
            for candidate in candidate_names:
                candidate_paths.extend(
                    [
                        path.parent / candidate,
                        path.parent / "tests" / candidate,
                        path.parent / "test" / candidate,
                        path.parent / "__tests__" / candidate,
                        path.parent / "spec" / candidate,
                        path.parent.parent / "tests" / candidate,
                    ]
                )

            for test_path in candidate_paths:
                full_path = self._working_dir / test_path
                if full_path.exists():
                    test_files.append(str(test_path))
                    logger.info("Found related test file: %s", test_path)
                    break

        # FIX-HYBRID-051: Deduplicate by stem, preferring test-directory files.
        _test_dirs = {"tests", "test", "__tests__", "spec"}
        best_by_stem: dict[str, str] = {}
        for tf in test_files:
            tf_path = Path(tf)
            stem = tf_path.stem
            in_test_dir = any(part in _test_dirs for part in tf_path.parts)
            existing = best_by_stem.get(stem)
            if existing is None:
                best_by_stem[stem] = tf
            elif in_test_dir and not any(
                part in _test_dirs for part in Path(existing).parts
            ):
                best_by_stem[stem] = tf
        return list(best_by_stem.values())

    def _get_confidence_threshold(self) -> float:
        from obra.config.loaders import get_fix_test_gap_inference_confidence_threshold

        return get_fix_test_gap_inference_confidence_threshold()


__all__ = ["TestGapResolver", "normalize_target_paths", "resolve_issue_intent"]
