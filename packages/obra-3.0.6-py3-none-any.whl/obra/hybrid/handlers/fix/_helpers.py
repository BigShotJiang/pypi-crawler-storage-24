"""Infrastructure helpers for FixHandler.

Extracted from fix/_handler.py (S4 of REFACTOR-FIX-HANDLER-001).
Owns: file-infrastructure checks, patch summary, deliverable validation,
      issue-specific prompt building, and file counting.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from obra.hybrid.handlers.fix._agent_deployer import FileChangeSet
    from obra.hybrid.handlers.fix._test_gap import TestGapResolver
    from obra.utils.file_tracker import FileStateTracker

logger = logging.getLogger(__name__)

__all__ = ["FixHelpers"]


class FixHelpers:
    """Infrastructure, file, and prompt helpers for FixHandler."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        file_tracker: FileStateTracker,
        test_gap_resolver: TestGapResolver,
    ) -> None:
        self._working_dir = working_dir
        self._config = config
        self._file_tracker = file_tracker
        self._test_gap = test_gap_resolver

    # ------------------------------------------------------------------
    # Infrastructure file detection
    # ------------------------------------------------------------------

    @staticmethod
    def is_infrastructure_file(path: str) -> bool:
        """Return True if path is an infrastructure/artifact file.

        BUG-a377298b: Expanded to cover all .obra/ contents.
        """
        normalized = path.replace("\\", "/").lower()
        if normalized.startswith(".obra/") or normalized == ".obra":
            return True
        if normalized.startswith(".obra-prompt-"):
            return True
        infrastructure_patterns = (
            ".git/",
            ".github/",
            ".vscode/",
            ".idea/",
            "__pycache__/",
            "node_modules/",
            "dist/",
            "build/",
            "vendor/",
            "target/",
            ".gradle/",
            ".cargo/",
            "bin/",
            "obj/",
            ".pytest_cache/",
            ".mypy_cache/",
            ".ruff_cache/",
        )
        return any(normalized.startswith(pattern) for pattern in infrastructure_patterns)

    def filter_infrastructure_files(self, paths: set[str]) -> set[str]:
        """Filter out infrastructure files from a set of paths."""
        return {path for path in paths if not self.is_infrastructure_file(path)}

    # ------------------------------------------------------------------
    # Patch summary
    # ------------------------------------------------------------------

    def build_patch_summary(self, files_modified: list[str]) -> dict[str, Any]:
        """Build a summary of lines added/removed via git diff."""
        summary: dict[str, Any] = {
            "files": files_modified,
            "file_count": len(files_modified),
            "line_changes": [],
        }
        if not files_modified:
            return summary

        git_dir = self._working_dir / ".git"
        if not git_dir.exists():
            return summary

        try:
            cmd = ["git", "diff", "--numstat", "--", *files_modified]
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
            )
            if result.returncode != 0:
                return summary
            for line in (result.stdout or "").splitlines():
                parts = line.split("\t")
                if len(parts) >= 3:
                    added, removed, path = parts[0], parts[1], parts[2]
                    line_changes = cast(list, summary["line_changes"])
                    line_changes.append({"path": path, "added": added, "removed": removed})
        except Exception as exc:
            logger.debug("Failed to build patch summary: %s", exc)
        return summary

    # ------------------------------------------------------------------
    # File counting / tracking
    # ------------------------------------------------------------------

    def count_file_changes(self) -> int:
        """Count trackable files in the working directory."""
        try:
            files = self._file_tracker.get_all_files()
            count = len(files)
            logger.debug("FileStateTracker found %d files in %s", count, self._working_dir)
            return count
        except OSError as e:
            logger.warning("File tracking failed: %s", e)
            return 0

    def get_file_changes(self) -> FileChangeSet:
        """Return a FileChangeSet with the current file count."""
        from obra.hybrid.handlers.fix._agent_deployer import FileChangeSet

        try:
            files = self._file_tracker.get_all_files()
            return FileChangeSet(added=set(), modified=set(), count=len(files))
        except OSError as e:
            logger.warning("File tracking failed: %s", e)
            return FileChangeSet(added=set(), modified=set(), count=0)

    def count_lines(self, filepath: str) -> int | None:
        """Count lines in a file, handling binary files gracefully."""
        try:
            file_path = self._working_dir / filepath
            with file_path.open(encoding="utf-8") as f:
                return sum(1 for _ in f)
        except UnicodeDecodeError:
            logger.debug("Binary file detected: %s", filepath)
            return None
        except FileNotFoundError:
            logger.debug("File not found: %s", filepath)
            return None
        except Exception as e:
            logger.debug("Failed to count lines in %s: %s", filepath, e)
            return None

    # ------------------------------------------------------------------
    # Deliverable validation
    # ------------------------------------------------------------------

    def get_validation_config(self) -> dict[str, Any]:
        """Load deliverable validation config from .obra/config.yaml."""
        defaults: dict[str, Any] = {
            "min_file_size": 10,
            "expected_extensions": None,
        }
        config_path = self._working_dir / ".obra" / "config.yaml"
        if not config_path.exists():
            return defaults
        try:
            import yaml

            with config_path.open(encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            validation = config.get("validation", {})
            if not isinstance(validation, dict):
                return defaults
            return {
                "min_file_size": validation.get("min_file_size", defaults["min_file_size"]),
                "expected_extensions": validation.get("expected_extensions"),
            }
        except Exception as e:
            logger.debug("Failed to load validation config: %s", e)
            return defaults

    def has_meaningful_content(self, filepath: str, min_size: int = 10) -> bool:
        """Return True if the file exists and has at least min_size bytes."""
        try:
            file_path = self._working_dir / filepath
            if not file_path.exists() or not file_path.is_file():
                return False
            return file_path.stat().st_size >= min_size
        except Exception as e:
            logger.debug("Failed to check file size for %s: %s", filepath, e)
            return False

    @staticmethod
    def matches_expected_extensions(
        filepath: str, expected_extensions: list[str] | None
    ) -> bool:
        """Return True if no expected_extensions set, or file extension matches."""
        if not expected_extensions:
            return True
        normalized = filepath.lower()
        return any(normalized.endswith(ext.lower()) for ext in expected_extensions)

    def validate_deliverables(self, paths: set[str]) -> tuple[set[str], list[str]]:
        """Validate that paths contain meaningful deliverables."""
        config = self.get_validation_config()
        min_size = config["min_file_size"]
        expected_extensions = config["expected_extensions"]

        valid_paths: set[str] = set()
        warnings: list[str] = []
        empty_files: list[str] = []
        wrong_extension_files: list[str] = []

        for path in paths:
            if not self.has_meaningful_content(path, min_size):
                empty_files.append(path)
                continue
            if not self.matches_expected_extensions(path, expected_extensions):
                wrong_extension_files.append(path)
                continue
            valid_paths.add(path)

        if empty_files:
            warnings.append(
                f"{len(empty_files)} file(s) have no meaningful content (<{min_size} bytes): "
                f"{', '.join(empty_files[:3])}{'...' if len(empty_files) > 3 else ''}"
            )
        if wrong_extension_files and expected_extensions:
            warnings.append(
                f"{len(wrong_extension_files)} file(s) don't match expected extensions "
                f"{expected_extensions}: {', '.join(wrong_extension_files[:3])}"
                f"{'...' if len(wrong_extension_files) > 3 else ''}"
            )
        return valid_paths, warnings

    # ------------------------------------------------------------------
    # Issue-specific prompt building
    # ------------------------------------------------------------------

    def build_issue_specific_prompt(
        self,
        issue: dict[str, Any],
        base_prompt: str,
        refactor_mode: bool = False,
    ) -> str:
        """Build a prompt with specific issue context prepended.

        FIX-REVIEW-LOOP-001/002: Include issue details and file contents.
        """
        from obra.prompts.fix.context import (
            build_issue_specific_context,
            build_test_gap_issue_context,
        )

        issue_id = issue.get("id", "unknown")
        file_path = issue.get("file_path") or issue.get("file", "")
        line_number = issue.get("line_number") or issue.get("line", "")
        category = issue.get("category") or issue.get("dimension", "")

        logger.debug(
            "Building prompt for %s: file=%s, line=%s, category=%s",
            issue_id,
            file_path,
            line_number,
            category,
        )

        if self._test_gap.is_test_gap(issue):
            issue = self._test_gap.resolve(issue)
            target_test_file = issue.get("target_test_file") or ""

            source_contents = None
            if file_path:
                source_contents = self._test_gap.read_file_for_fix(file_path, line_number)
                if not source_contents:
                    logger.warning(
                        "Could not read source file %s for test gap context", file_path
                    )

            test_contents = None
            if target_test_file:
                test_contents = self._test_gap.read_file_for_fix(
                    target_test_file, None, context_lines=100
                )
                if not test_contents:
                    logger.warning(
                        "Could not read test file %s for test gap context", target_test_file
                    )

            context = build_test_gap_issue_context(issue, source_contents, test_contents)
            return context + base_prompt

        file_contents = None
        if file_path:
            file_contents = self._test_gap.read_file_for_fix(file_path, line_number)
            if not file_contents:
                logger.warning(
                    "Could not read file %s for fix context - "
                    "fix agent may create new file instead of editing",
                    file_path,
                )

        context = build_issue_specific_context(
            issue,
            file_contents,
            refactor_mode=refactor_mode,
        )
        return context + base_prompt
