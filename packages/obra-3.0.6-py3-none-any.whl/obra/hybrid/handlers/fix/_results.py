"""Fix pass result accumulators.

Provides immutable result containers for tracking fix pass outcomes.
FixPassResults replaces the 6 duplicated counter aggregation sites in
_run_fix_pass with a single merge() call.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class IssueFixResult:
    """Result for a single issue fix attempt.

    Attributes:
        issue_id: The issue identifier.
        status: One of 'applied', 'failed', 'skipped', 'inconclusive',
            'scope_exceeded'. Note: 'applied' is correct per BUG-SCHEMA-001.
        result: The full result dict for this issue.
        issue: The original issue dict, or None if unavailable.
    """

    issue_id: str
    status: str
    result: dict[str, Any]
    issue: dict[str, Any] | None


@dataclass(frozen=True)
class FixPassResults:
    """Immutable accumulator for fix pass results.

    Use empty() to start a new accumulator, then chain merge() calls
    for each issue result. combine() merges two accumulators (e.g.
    from different fix passes).

    Attributes:
        fix_results: Tuple of raw result dicts (one per issue).
        fixed_count: Number of successfully fixed issues.
        failed_count: Number of failed issues.
        skipped_count: Number of skipped issues.
    """

    fix_results: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    fixed_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0

    @classmethod
    def empty(cls) -> FixPassResults:
        """Return a zero-count accumulator."""
        return cls(fix_results=(), fixed_count=0, failed_count=0, skipped_count=0)

    def merge(
        self,
        issue_result: IssueFixResult,
        deltas: tuple[int, int, int],
    ) -> FixPassResults:
        """Return a new accumulator with issue_result appended and counts updated.

        Args:
            issue_result: The result for a single issue.
            deltas: (fixed_delta, failed_delta, skipped_delta) from
                _emit_fix_result_line(). Preserves existing count derivation.

        Returns:
            A new FixPassResults with the issue appended and counts incremented.
        """
        fixed_delta, failed_delta, skipped_delta = deltas
        return FixPassResults(
            fix_results=(*self.fix_results, issue_result.result),
            fixed_count=self.fixed_count + fixed_delta,
            failed_count=self.failed_count + failed_delta,
            skipped_count=self.skipped_count + skipped_delta,
        )

    def combine(self, other: FixPassResults) -> FixPassResults:
        """Return a new accumulator merging both result sets and summing counts.

        Args:
            other: Another FixPassResults to merge with this one.

        Returns:
            A new FixPassResults combining both accumulators.
        """
        return FixPassResults(
            fix_results=self.fix_results + other.fix_results,
            fixed_count=self.fixed_count + other.fixed_count,
            failed_count=self.failed_count + other.failed_count,
            skipped_count=self.skipped_count + other.skipped_count,
        )
