"""Story 0 execution handler for environment preparation."""

from __future__ import annotations

import contextlib
import fnmatch
import hashlib
import json
import logging
import os
import subprocess
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from obra.config.loaders import get_story0_capability_checks, get_story0_timeout
from obra.display import print_info
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.hybrid.install_target import InstallTargetManager
from obra.hybrid.story0.event_emitter import Story0EventEmitter
from obra.hybrid.story0.install_subsystem import DependencyInstaller
from obra.hybrid.story0.manifest_generation import (
    describe_repo_structure as describe_story0_repo_structure,
    generate_fallback_manifests as generate_story0_fallback_manifests,
    generate_manifests_llm as generate_story0_manifests_llm,
    handle_inbox_project as handle_story0_inbox_project,
    manifest_ecosystem as story0_manifest_ecosystem,
    normalize_manifest_response as normalize_story0_manifest_response,
    repair_manifest_llm as repair_story0_manifest_llm,
    validate_manifest_contents as validate_story0_manifest_contents,
)
from obra.hybrid.story0.manual_actions import handle_manual_items_batched
from obra.hybrid.story0.prerequisite_dispatch import PrerequisiteDispatcher
from obra.hybrid.story0.resolver_flow import handle_with_dependency_resolver
from obra.hybrid.story0.service_manager import (
    ServiceManager,
    check_orphaned_containers,
    cleanup_containers,
)
from obra.hybrid.story0.verification_installer import VerificationInstaller
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.hybrid.tooling_discovery import ToolingDiscovery
from obra.models.story0_state import (
    Prerequisite,
    PrerequisiteCategory,
    PrerequisiteSource,
    PrerequisiteStatus,
    Story0State,
    Story0Status,
    load_story0_state,
)

logger = logging.getLogger(__name__)

MANIFEST_TYPE_MAP = {
    "python": "pyproject.toml",
    "node": "package.json",
    "rust": "Cargo.toml",
    "go": "go.mod",
    "ruby": "Gemfile",
}

MINIMAL_MANIFEST_TEMPLATES = {
    "pyproject.toml": ('[project]\nname = "obra-project"\nversion = "0.1.0"\n'),
    "package.json": json.dumps({"name": "obra-project", "version": "0.1.0"}, indent=2),
    "Cargo.toml": '[package]\nname = "obra_project"\nversion = "0.1.0"\n',
    "go.mod": "module obra_project\n\ngo 1.21\n",
    "Gemfile": 'source "https://rubygems.org"\n',
}
def is_effectively_empty(directory: Path, markers: list[str]) -> bool:
    if not directory.exists():
        return True
    for item in directory.iterdir():
        if any(fnmatch.fnmatch(item.name, marker) for marker in markers):
            continue
        return False
    return True
@dataclass
class Story0Result:
    """Result payload for Story 0 execution."""

    status: str
    completed: list[str]
    failed: list[str]
    skipped: list[str]
    blocking_failures: list[str]
    non_blocking_failures: list[str]
    state_path: Path
    verification_tools: dict[str, Any]
    mocked_credentials: list[str]
class Story0Handler:
    """Execute Story 0 environment preparation prerequisites."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        on_progress: Callable[[str, dict[str, Any]], None] | None,
        session_id: str,
        objective: str,
        is_tty: bool = True,
        llm_config: dict[str, Any] | None = None,
    ) -> None:
        self._working_dir = Path(working_dir)
        self._config = config
        self._story0_config = dict(config.get("story0", {}))
        self._on_progress = on_progress
        self._session_id = session_id
        self._objective = objective
        self._is_tty = is_tty
        self._llm_config = llm_config or config.get("llm", {}) or {}
        self._tooling_discovery = ToolingDiscovery(self._working_dir, self._llm_config)
        self._install_target = InstallTargetManager()
        self._state_path = self._working_dir / ".obra" / "story0_state.yaml"
        self._mocked_credentials: list[str] = []
        self._prereq_state: list[Prerequisite] = []
        self._env_setup_performed = False
        self._generated_manifest_paths: list[str] = []
        self._generated_manifest_type: str | None = None
        self._automation_mode_requested = config.get("automation_mode")
        self._automation_mode_effective = self._automation_mode_requested
        self._log_decisions = bool(self._story0_config.get("log_decisions", True))
        self._genie_hint_shown = False  # Track if we've shown the Genie mode hint
        self._dependency_manifest_dict: dict[str, Any] | None = None
        self._event_emitter = Story0EventEmitter(
            owner=self, get_on_progress=lambda: self._on_progress, print_info_fn=print_info,
            get_log_decisions=lambda: self._log_decisions,
            get_automation_mode=lambda: self._automation_mode_effective,
        )
        self._emit_prereq_progress = self._event_emitter.prereq_progress
        self._emit_progress = self._event_emitter.progress
        self._emit_summary = lambda: self._event_emitter.summary(self._prereq_state, self._mocked_credentials)
        self._emit_story0_started = self._event_emitter.story0_started
        self._emit_story0_completed = self._event_emitter.story0_completed
        self._emit_decision_event = self._event_emitter.decision_event
        self._event_emitter.register_alias("_emit_prereq_progress", self._emit_prereq_progress)
        self._event_emitter.register_alias("_emit_summary", self._emit_summary)
        self._event_emitter.register_alias("_emit_progress", self._emit_progress)
        self._event_emitter.register_alias("_emit_story0_started", self._emit_story0_started)
        self._event_emitter.register_alias("_emit_story0_completed", self._emit_story0_completed)
        self._event_emitter.register_alias("_emit_decision_event", self._emit_decision_event)
        # Collaborators — each owns a focused subsystem
        self._installer = DependencyInstaller(
            working_dir=self._working_dir,
            config=self._config,
            story0_config=self._story0_config,
            llm_config=self._llm_config,
            install_target=self._install_target,
            objective=self._objective,
            automation_mode_effective=self._automation_mode_effective or "auto_safe",
            emit_progress=lambda message: self._emit_progress(message),
            emit_decision_event=lambda event_type, data: self._emit_decision_event(event_type, data),
        )
        self._service_manager = ServiceManager(
            working_dir=self._working_dir, story0_config=self._story0_config,
            session_id=self._session_id, emit_progress=lambda message: self._emit_progress(message),
        )
        self._prereq_dispatcher = PrerequisiteDispatcher(
            owner=self,
            installer=self._installer,
            service_manager=self._service_manager,
            install_target=self._install_target,
            working_dir=self._working_dir,
            story0_config=self._story0_config,
            is_tty=self._is_tty,
            get_automation_mode=lambda: self._automation_mode_effective,
            mocked_credentials=self._mocked_credentials,
            coerce_prereq=self._coerce_prereq,
            prompt_text=lambda prompt, default=None: self._prompt_text(prompt, default),
            emit_progress=lambda message: self._event_emitter.progress(message),
            emit_prereq_progress=lambda prereq, status: self._event_emitter.prereq_progress(prereq, status),
            emit_prereq_status=(
                lambda prereq, status, reason=None: self._event_emitter.story0_prereq_status(prereq, status, reason)
            ),
            get_capability_checks=lambda: get_story0_capability_checks(),
        )
        self._resolve_handler = self._prereq_dispatcher.resolve_handler
        self._resolve_ecosystem = self._prereq_dispatcher.resolve_ecosystem
        self._handle_auto = self._prereq_dispatcher.handle_auto
        self._handle_auto_confirm = self._prereq_dispatcher.handle_auto_confirm
        self._handle_local_capability = self._prereq_dispatcher.handle_local_capability
        self._handle_credential = self._prereq_dispatcher.handle_credential
        self._handle_user_action = self._prereq_dispatcher.handle_user_action
        self._handle_account = self._prereq_dispatcher.handle_account
        self._create_mock_credential = self._prereq_dispatcher.create_mock_credential
        self._verifier = VerificationInstaller(
            working_dir=self._working_dir, config=self._config, llm_config=self._llm_config,
            tooling_discovery=self._tooling_discovery, is_tty=self._is_tty,
            emit_progress=lambda message: self._emit_progress(message),
            emit_story0_event=lambda event_type, data: self._event_emitter.story0_event(event_type, data),
            prompt_text_fn=lambda prompt, default=None: self._prompt_text(prompt, default),
        )

    def handle(
        self,
        prerequisites: list[dict[str, Any]],
        resume_reason: str | None = None,
        missing_tools: list[str] | None = None,
    ) -> Story0Result:
        """Run Story 0 environment preparation."""
        mode = self._config.get("automation_mode", "auto_safe")
        if mode == "guided" and not self._is_tty:
            self._emit_progress(
                "[Preflight] Guided mode requested but no TTY available. "
                "Falling back to auto_safe behavior."
            )
            self._automation_mode_requested = "guided"
            self._automation_mode_effective = "auto_safe"
            mode = "auto_safe"
            self._story0_config.update(
                {
                    "auto_env_setup": True,
                    "prompt_for_env_setup": False,
                    "install_policy": "manifest_then_inferred",
                    "allow_inferred_installs": True,
                    "auto_approve": False,
                    "install_target": "project_local",
                    "env_creation": "when_missing",
                }
            )
        else:
            self._automation_mode_effective = mode
        self._emit_progress(f"[Preflight] Automation mode: {mode}")
        install_policy = self._story0_config.get("install_policy", "manifest_or_inferred")
        auto_approve = self._story0_config.get("auto_approve", False)
        self._emit_progress(
            f"[Preflight] Mode: {mode}, install_policy: {install_policy}, "
            f"auto_approve: {auto_approve}"
        )
        install_execution_enabled = mode != "off"
        self._emit_progress(
            "[Preflight] Dependency resolver: active (legacy install path removed), "
            f"install_execution={'enabled' if install_execution_enabled else 'disabled (off mode)'}"
        )
        self._emit_decision_event(
            "automation_mode_selected",
            {
                "mode": mode,
            },
        )
        self._emit_decision_event(
            "story0_dependency_resolution_mode",
            {
                "mode": mode,
                "resolver_path": "resolver_only",
                "legacy_path_used": False,
                "legacy_path_available": False,
                "install_execution_enabled": install_execution_enabled,
            },
        )
        self._emit_story0_started()
        if resume_reason == "verification_tools_missing":
            state = self._load_state()
            if state:
                self._apply_state(state)
            verification_tools, _installed = self._verifier.run_verification_preflight(
                missing_tools,
            )
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )
        self._emit_progress(f"[Preflight] Install policy: {self._story0_config.get('install_policy')}")
        ecosystems = self._detect_ecosystems()
        if ecosystems:
            self._emit_progress("[Preflight] Detected ecosystems: " + ", ".join(ecosystems))
        state = self._load_state()
        if state:
            # Validate objective_hash for non-COMPLETE states before applying.
            # COMPLETE states have their own validation path below (with richer messaging).
            if state.status != Story0Status.COMPLETE:
                current_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
                if state.objective_hash != current_hash:
                    self._emit_progress(
                        "Preflight state from different objective — starting fresh"
                    )
                    state = None
            if state is not None:
                self._apply_state(state)
                if state.mocked_credentials:
                    self._check_mock_upgrades(state)
                    refreshed = self._load_state()
                    if refreshed:
                        refresh_hash = hashlib.sha256(
                            self._objective.encode()
                        ).hexdigest()[:16]
                        if refreshed.objective_hash == refresh_hash:
                            state = refreshed
                            self._apply_state(state)
        verification_tools = self._discover_verification_tools()
        if state and state.status == Story0Status.COMPLETE:
            current_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
            if state.objective_hash != current_hash:
                self._emit_progress(
                    "Objective changed since preflight completed.\n"
                    f"  Previous: {state.objective_hash[:8]}...\n"
                    f"  Current:  {current_hash[:8]}...\n"
                    "Prerequisites may need updating. Recommend: obra run --resume <id> --from environment"
                )
                state = None
                self._reset_state_cache()
            else:
                valid, _failures = self._quick_validate()
                if valid:
                    self._emit_progress(
                        "Preflight already validated from a previous run.\n"
                        "No setup changes detected, so this step is skipped and execution continues."
                    )
                    self._emit_story0_completed(0, 0)
                    return self._finalize_result(
                        status="complete",
                        completed=[],
                        failed=[],
                        skipped=[],
                        blocking_failures=[],
                        non_blocking_failures=[],
                        verification_tools=verification_tools,
                    )
                state = None
                self._reset_state_cache()
        markers = self._story0_config.get(
            "allowed_empty_markers",
            [".git", ".obra", "README*", ".gitignore"],
        )
        auto_env_setup = self._story0_config.get("auto_env_setup", True)
        if not self._working_dir.exists() or (
            auto_env_setup and is_effectively_empty(self._working_dir, markers)
        ):
            if auto_env_setup and not self._handle_inbox_project(self._objective):
                self._emit_story0_completed(1, 0)
                return self._finalize_result(
                    status="failed",
                    completed=[],
                    failed=["inbox_project"],
                    skipped=[],
                    blocking_failures=["inbox_project"],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )
        elif auto_env_setup and mode == "auto_full":
            existing_manifests = self._installer.detect_existing_manifests()
            if existing_manifests:
                self._emit_progress(
                    "[Preflight] Skipped environment setup: existing manifests found "
                    f"({len(existing_manifests)})"
                )
            elif not self._handle_inbox_project(self._objective):
                self._emit_story0_completed(1, 0)
                return self._finalize_result(
                    status="failed",
                    completed=[],
                    failed=["inbox_project"],
                    skipped=[],
                    blocking_failures=["inbox_project"],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )
        elif auto_env_setup:
            self._emit_progress(
                "[Preflight] Manifest not generated (populated repo). "
                "Hint: Use automation_mode=auto_full to generate in any repo."
            )
        if not prerequisites:
            message = (
                "Preflight found no prerequisites for this objective.\n"
                "Setup is skipped because no dependencies, credentials, or services are required."
            )
            self._emit_progress(message)
            self._save_state(status=Story0Status.COMPLETE)
            self._emit_story0_completed(0, 0)
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )
        # Story0 now always routes dependency and install handling through the
        # dependency resolver protocol. The legacy direct install loop is retired.
        return self._handle_with_dependency_resolver(
            prerequisites, state, verification_tools,
        )

    def _handle_with_dependency_resolver(
        self,
        prerequisites: list[dict[str, Any]],
        state: Story0State | None,
        verification_tools: dict[str, Any],
    ) -> Story0Result:
        """Resolve Story0 prerequisites via the extracted resolver flow."""
        return handle_with_dependency_resolver(
            self,
            prerequisites=prerequisites,
            state=state,
            verification_tools=verification_tools,
            create_skip_record_fn=create_skip_record,
        )

    def _map_story0_detail_to_reason(self, detail: str) -> SkipReason:
        detail_lower = (detail or "").lower()
        if "input timeout" in detail_lower:
            return SkipReason.USER_TIMEOUT
        if "user declined" in detail_lower:
            return SkipReason.USER_DECLINED
        if "no value provided" in detail_lower:
            return SkipReason.USER_DECLINED
        if "user skipped" in detail_lower:
            return SkipReason.USER_DECLINED
        if "automation mode" in detail_lower:
            return SkipReason.SCOPE_BOUNDARY
        if "llm determined" in detail_lower:
            return SkipReason.EXTERNAL_DEPENDENCY
        return SkipReason.UNKNOWN

    def _is_skip_tracking_enabled(self) -> bool:
        skip_config = self._config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get("story0", True)
        )

    def _record_prereq_outcome(
        self,
        prereq_entry: Prerequisite,
        prereq: dict[str, Any],
        prereq_id: str,
        category: PrerequisiteCategory,
        status: str,
        detail: str,
        completed: list[str],
        failed: list[str],
        skipped: list[str],
        blocking_failures: list[str],
        non_blocking_failures: list[str],
        failures: list[tuple[dict[str, Any], str]],
    ) -> None:
        """Record the outcome of processing a single prerequisite.

        Shared by both automatable and manual item processing paths.
        """

        def _append_unique(values: list[str], value: str) -> None:
            if value not in values:
                values.append(value)

        if status in (
            PrerequisiteStatus.INSTALLED.value,
            PrerequisiteStatus.MOCKED.value,
        ):
            _append_unique(completed, prereq_id)
        elif status == PrerequisiteStatus.SKIPPED.value:
            _append_unique(skipped, prereq_id)
            if self._is_skip_tracking_enabled():
                create_skip_record(
                    session_id=self._session_id or "",
                    task_id=prereq_id,
                    source=SkipSource.STORY0,
                    reason=self._map_story0_detail_to_reason(detail),
                    description=f"Prerequisite {prereq.get('name', 'unknown')}: {detail}",
                    source_context={
                        "prereq_category": prereq.get("category"),
                        "prereq_name": prereq.get("name"),
                        "detail": detail,
                    },
                )
        else:
            _append_unique(failed, prereq_id)
            failures.append((prereq, detail))
            if self._is_blocking(category):
                _append_unique(blocking_failures, prereq_id)
            else:
                _append_unique(non_blocking_failures, prereq_id)

        prereq_entry.status = PrerequisiteStatus(status)
        if status == PrerequisiteStatus.MOCKED.value:
            prereq_entry.mock_type = self._story0_config.get("default_mock_level")
        if (
            status == PrerequisiteStatus.INSTALLED.value
            and category == PrerequisiteCategory.SERVICE
        ):
            prereq_entry.container_name = prereq.get("container_name")
            prereq_entry.port = prereq.get("port")
        self._update_prereq_state(prereq_entry)
        self._save_state(status=Story0Status.PARTIAL)

    def _handle_manual_items_batched(
        self,
        manual_items: list[tuple[Prerequisite, dict[str, Any]]],
        manual_behavior: str,
        completed: list[str],
        failed: list[str],
        skipped: list[str],
        blocking_failures: list[str],
        non_blocking_failures: list[str],
        failures: list[tuple[dict[str, Any], str]],
    ) -> None:
        """Process manual prerequisites via the extracted batching flow."""
        handle_manual_items_batched(
            self,
            manual_items=manual_items,
            manual_behavior=manual_behavior,
            completed=completed,
            failed=failed,
            skipped=skipped,
            blocking_failures=blocking_failures,
            non_blocking_failures=non_blocking_failures,
            failures=failures,
        )

    def _normalize_categories(
        self, prereq_entry: Prerequisite, raw_prereq: dict[str, Any]
    ) -> Prerequisite:
        """Normalize prerequisite categories for guided mode and capability detection.

        Four rules:
        1. Guided mode + INFERRED + AUTO -> AUTO_CONFIRM (forces user confirmation)
        2. Runtime/toolchain prerequisites -> LOCAL_CAPABILITY
        3. SERVICE matching a capability indicator -> LOCAL_CAPABILITY
        4. auto_full mode + USER_ACTION -> AUTO (route through auto-install path)
        """
        mode = self._config.get("automation_mode", "auto_safe")

        # Rule 1: In guided mode, INFERRED AUTO deps require confirmation
        if (
            mode == "guided"
            and prereq_entry.source == PrerequisiteSource.INFERRED
            and prereq_entry.category == PrerequisiteCategory.AUTO
        ):
            old_cat = prereq_entry.category
            prereq_entry.category = PrerequisiteCategory.AUTO_CONFIRM
            logger.debug(
                "[Preflight] Normalized %s: %s -> %s (guided mode)",
                prereq_entry.name,
                old_cat.value,
                prereq_entry.category.value,
            )

        # Rule 2: Runtime/toolchain prerequisites are local capabilities.
        if self._is_runtime_capability_prereq(prereq_entry, raw_prereq):
            if prereq_entry.category != PrerequisiteCategory.LOCAL_CAPABILITY:
                old_cat = prereq_entry.category
                prereq_entry.category = PrerequisiteCategory.LOCAL_CAPABILITY
                logger.debug(
                    "[Preflight] Re-classified %s: %s -> LOCAL_CAPABILITY (runtime/toolchain)",
                    prereq_entry.name,
                    old_cat.value,
                )

        # Rule 3: SERVICE prereqs matching capability indicators -> LOCAL_CAPABILITY
        if prereq_entry.category == PrerequisiteCategory.SERVICE:
            capability_checks = get_story0_capability_checks()
            name_lower = prereq_entry.name.lower()
            for cap_name, cap_config in capability_checks.items():
                indicators = cap_config.get("indicators", [])
                if any(indicator.lower() in name_lower for indicator in indicators):
                    logger.debug(
                        "[Preflight] Re-classified %s: SERVICE -> LOCAL_CAPABILITY (matches %s indicator)",
                        prereq_entry.name,
                        cap_name,
                    )
                    prereq_entry.category = PrerequisiteCategory.LOCAL_CAPABILITY
                    break

        # Rule 4: In auto_full mode, USER_ACTION prereqs route through auto-install
        if (
            mode == "auto_full"
            and prereq_entry.category == PrerequisiteCategory.USER_ACTION
        ):
            logger.debug(
                "[Preflight] Normalized %s: USER_ACTION -> AUTO (auto_full mode)",
                prereq_entry.name,
            )
            prereq_entry.category = PrerequisiteCategory.AUTO

        return prereq_entry

    @staticmethod
    def _is_runtime_capability_prereq(
        prereq_entry: Prerequisite,
        raw_prereq: dict[str, Any],
    ) -> bool:
        """Return True when prerequisite describes local runtime/toolchain availability."""
        raw_name = str(raw_prereq.get("name", "")).lower()
        raw_id = str(raw_prereq.get("id", "")).lower()
        text = " ".join(
            part
            for part in (
                prereq_entry.name.lower(),
                prereq_entry.id.lower(),
                raw_name,
                raw_id,
                str(raw_prereq.get("reason", "")).lower(),
            )
            if part
        )

        runtime_markers = ("interpreter", "runtime", "toolchain", "executable", "binary")
        runtime_ids = {
            "python",
            "python3",
            "node",
            "nodejs",
            "go",
            "rust",
            "cargo",
            "java",
            "javac",
            "dotnet",
        }
        runtime_keywords = ("python", "python3", "node", "go", "rust", "java", "dotnet")

        has_runtime_keyword = any(keyword in text for keyword in runtime_keywords)
        if not has_runtime_keyword:
            return False

        if prereq_entry.id.lower() in runtime_ids or raw_id in runtime_ids:
            return True

        return any(marker in text for marker in runtime_markers)

    def _handle_inbox_project(self, objective: str) -> Path | None:
        return handle_story0_inbox_project(
            self,
            objective,
            template_edit_pipeline_cls=TemplateEditPipeline,
            minimal_manifest_templates=MINIMAL_MANIFEST_TEMPLATES,
        )

    def _generate_manifests_llm(
        self, objective: str
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        return generate_story0_manifests_llm(
            self,
            objective,
            template_edit_pipeline_cls=TemplateEditPipeline,
        )

    def _normalize_manifest_response(self, result: Any) -> list[dict[str, Any]]:
        return normalize_story0_manifest_response(result)

    def _describe_repo_structure(self) -> list[str]:
        return describe_story0_repo_structure(self)

    def _generate_fallback_manifests(self) -> list[dict[str, Any]]:
        return generate_story0_fallback_manifests(
            self,
            manifest_type_map=MANIFEST_TYPE_MAP,
            minimal_manifest_templates=MINIMAL_MANIFEST_TEMPLATES,
        )

    def _detect_ecosystems(self) -> list[str]:
        ecosystems: set[str] = set()
        for manifest in self._installer.detect_existing_manifests():
            name = Path(manifest).name
            for ecosystem, manifest_type in MANIFEST_TYPE_MAP.items():
                if name == manifest_type:
                    ecosystems.add(ecosystem)
        if ecosystems:
            return sorted(ecosystems)

        ext_map = {
            "python": {".py"},
            "node": {".js", ".ts", ".jsx", ".tsx"},
            "rust": {".rs"},
            "go": {".go"},
            "ruby": {".rb"},
        }
        for path in self._working_dir.rglob("*"):
            if not path.is_file():
                continue
            ext = path.suffix.lower()
            for ecosystem, extensions in ext_map.items():
                if ext in extensions:
                    ecosystems.add(ecosystem)
        return sorted(ecosystems)

    def _validate_manifest_contents(self, manifest_type: str, contents: str) -> tuple[bool, str]:
        return validate_story0_manifest_contents(manifest_type, contents)

    def _repair_manifest_llm(self, manifest_type: str, contents: str, reason: str) -> str | None:
        return repair_story0_manifest_llm(self, manifest_type, contents, reason)

    def _manifest_ecosystem(self, manifest_type: str) -> str | None:
        return story0_manifest_ecosystem(
            manifest_type,
            manifest_type_map=MANIFEST_TYPE_MAP,
        )

    def _has_conflict_markers(self, target_dir: Path, ecosystem: str) -> bool:
        markers = self._config.get("ecosystem_conflict_markers", {}).get(ecosystem, [])
        return any((target_dir / marker).exists() for marker in markers)

    def _build_failure_summary(self, failures: list[tuple[dict[str, Any], str]]) -> str:
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for prereq, _detail in failures:
            category = prereq.get("category", "UNKNOWN")
            grouped[str(category)].append(prereq)

        def _lines(title: str, items: list[dict[str, Any]]) -> list[str]:
            if not items:
                return []
            lines = [title + ":"]
            for item in items:
                name = item.get("name", "unknown")
                reason = item.get("reason", "")
                lines.append(f"  - {name} - {reason}")
            return lines

        sections = []
        sections += _lines(
            "Missing credentials (cannot auto-resolve)",
            grouped.get(PrerequisiteCategory.CREDENTIAL.value, []),
        )
        sections += _lines(
            "Services unavailable",
            grouped.get(PrerequisiteCategory.SERVICE.value, []),
        )
        sections += _lines(
            "Manual actions required",
            grouped.get(PrerequisiteCategory.USER_ACTION.value, []),
        )
        sections += _lines(
            "External accounts required",
            grouped.get(PrerequisiteCategory.ACCOUNT.value, []),
        )
        summary = [
            "[Preflight] Environment preparation failed (non-interactive mode)",
            "",
        ]
        summary += sections
        summary += [
            "",
            "To proceed:",
            "  1. Set required environment variables, OR",
            '  2. Run interactively: obra run "..." (TTY required), OR',
            '  3. Use mocks: obra run "..." --mock-credentials',
        ]
        return "\n".join(summary)

    def _save_state(self, status: Story0Status) -> None:
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            objective_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
            manifest_hash = self._compute_manifest_hash()
            payload = Story0State(
                status=status,
                objective_hash=objective_hash,
                manifest_hash=manifest_hash,
                prerequisites=self._prereq_state,
                containers=self._service_manager.containers,
                mocked_credentials=self._mocked_credentials,
                automation_mode_effective=self._automation_mode_effective,
                automation_mode_requested=self._automation_mode_requested,
                env_setup_performed=self._env_setup_performed,
                generated_manifest_type=self._generated_manifest_type,
                generated_manifest_paths=self._generated_manifest_paths,
                installs_by_source=self._installer.installs_by_source,
                verification_tools=self._verifier.verification_tools_state,
                completed_at=(datetime.now(UTC) if status == Story0Status.COMPLETE else None),
                dependency_manifest=self._dependency_manifest_dict,
            )
            self._state_path.write_text(
                yaml.safe_dump(payload.model_dump(mode="json"), sort_keys=False),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Failed to save preflight state: %s", exc)

    def _load_state(self) -> Story0State | None:
        if not self._state_path.exists():
            return None
        try:
            state = load_story0_state(self._state_path)
            if state.status == Story0Status.FAILED and state.reason == "state_corrupted":
                self._emit_progress(
                    "Previous environment state corrupted. Re-analyzing prerequisites..."
                )
                return None
            return state
        except OSError as exc:
            logger.warning("Failed to load preflight state: %s", exc)
            return None

    def _apply_state(self, state: Story0State) -> None:
        self._prereq_state = list(state.prerequisites)
        self._service_manager.containers = list(state.containers)
        self._mocked_credentials[:] = list(state.mocked_credentials)
        # automation_mode_effective and automation_mode_requested intentionally
        # NOT restored — current session config is authoritative for policy.
        if (
            state.automation_mode_effective
            and state.automation_mode_effective != self._automation_mode_effective
        ):
            logger.info(
                "Story0 state had automation_mode_effective=%s, "
                "current session uses %s — keeping current session config",
                state.automation_mode_effective,
                self._automation_mode_effective,
            )
        self._env_setup_performed = state.env_setup_performed
        self._generated_manifest_type = state.generated_manifest_type
        self._generated_manifest_paths = list(state.generated_manifest_paths)
        self._installer.installs_by_source = dict(state.installs_by_source)
        self._verifier.verification_tools_state = dict(state.verification_tools)
        self._dependency_manifest_dict = state.dependency_manifest

    def _reset_state_cache(self) -> None:
        self._prereq_state = []
        self._service_manager.containers = []
        self._mocked_credentials.clear()
        self._env_setup_performed = False
        self._generated_manifest_type = None
        self._generated_manifest_paths = []
        self._installer.installs_by_source = {"manifest": [], "inferred": []}
        self._verifier.verification_tools_state = {}

    def _update_prereq_state(self, entry: Prerequisite) -> None:
        for index, existing in enumerate(self._prereq_state):
            if existing.id == entry.id or existing.name == entry.name:
                self._prereq_state[index] = entry
                return
        self._prereq_state.append(entry)

    def _quick_validate(self) -> tuple[bool, list[str]]:
        state = self._load_state()
        if state is None or state.status != Story0Status.COMPLETE:
            early_failures = ["State incomplete or corrupted"]
            self._emit_progress(
                "Environment validation failed:\n"
                f"  - {early_failures[0]}\n"
                "Recommend: obra run --resume <id> --from story-0"
            )
            return False, early_failures

        failures: list[str] = []

        # Check if automation mode upgraded (e.g., off -> auto_full)
        # If current mode is more capable, re-run Story 0 to apply installs
        mode_order = {"off": 0, "guided": 1, "auto_safe": 2, "auto_full": 3}
        stored_mode = state.automation_mode_effective or "off"
        current_mode = self._automation_mode_effective
        stored_level = mode_order.get(stored_mode, 0)
        current_level = mode_order.get(current_mode, 2)
        if current_level > stored_level:
            failures.append(f"Automation mode upgraded ({stored_mode} -> {current_mode})")

        if state.manifest_hash:
            current_hash = self._compute_manifest_hash()
            if not current_hash or current_hash != state.manifest_hash:
                failures.append("Manifest changed since preflight")

        for prereq in state.prerequisites:
            if (
                prereq.category == PrerequisiteCategory.SERVICE
                and prereq.status == PrerequisiteStatus.INSTALLED
            ):
                if not prereq.port:
                    failures.append(f"Service {prereq.name} missing port info")
                elif not self._service_manager.check_tcp("127.0.0.1", prereq.port):
                    failures.append(f"Service {prereq.name} not reachable on port {prereq.port}")
            if (
                prereq.category == PrerequisiteCategory.CREDENTIAL
                and prereq.status in (PrerequisiteStatus.INSTALLED, PrerequisiteStatus.MOCKED)
                and not os.environ.get(prereq.name)
            ):
                failures.append(f"Credential missing: {prereq.name}")

        for container in state.containers:
            name = str(container.get("container_name") or "") or str(container.get("name") or "")
            if name and not self._service_manager.is_container_running(name):
                failures.append(f"Docker container not running: {name}")

        if failures:
            lines = ["Environment validation failed:"]
            lines += [f"  - {reason}" for reason in failures]
            lines.append("Recommend: obra run --resume <id> --from story-0")
            self._emit_progress("\n".join(lines))
            return False, failures

        return True, []

    def _check_mock_upgrades(self, state: Story0State) -> None:
        if not self._is_tty:
            return
        if not state.mocked_credentials:
            return

        updated = False
        fixture_dir = self._working_dir / ".obra" / "mocks"
        for cred_name in list(state.mocked_credentials):
            env_value = os.environ.get(cred_name)
            if not env_value:
                continue
            fixture_path = fixture_dir / f"{cred_name}.json"
            mock_value = None
            if fixture_path.exists():
                try:
                    payload = json.loads(fixture_path.read_text(encoding="utf-8"))
                    mock_value = payload.get("mock_value")
                except json.JSONDecodeError:
                    mock_value = None
            if mock_value is not None and env_value == mock_value:
                continue

            response = self._prompt_text(
                f"{cred_name} was mocked but real value now detected in environment.\n"
                "Upgrade to real credential? [Y/n] ",
                default="y",
            )
            if response is None or response.strip().lower().startswith("n"):
                continue

            for prereq in state.prerequisites:
                if cred_name in (prereq.name, prereq.id):
                    prereq.status = PrerequisiteStatus.INSTALLED
            state.mocked_credentials = [
                name for name in state.mocked_credentials if name != cred_name
            ]
            if fixture_path.exists():
                try:
                    payload = json.loads(fixture_path.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    payload = {}
            else:
                payload = {}
            payload["upgraded_at"] = datetime.now(UTC).isoformat()
            fixture_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            updated = True

        if updated:
            self._apply_state(state)
            self._save_state(status=state.status)

    def _prompt_text(self, prompt: str, default: str | None = None) -> str | None:
        if not self._is_tty:
            return default
        print_info(prompt)

        from obra.display.prompting import prompt_input_with_timeout

        timeout_seconds = get_story0_timeout()
        value = prompt_input_with_timeout(
            "", timeout=timeout_seconds, default=default,
        )
        return value or default

    @staticmethod
    def _build_dependency_resolution_stats(manifest: Any) -> dict[str, Any]:
        status_counts: dict[str, int] = defaultdict(int)
        ecosystem_status_counts: dict[str, dict[str, int]] = defaultdict(
            lambda: defaultdict(int)
        )

        for entry in manifest.entries:
            status_counts[entry.status] += 1
            ecosystem_status_counts[entry.ecosystem][entry.status] += 1

        return {
            "status_counts": dict(status_counts),
            "ecosystems": {
                ecosystem: dict(counts)
                for ecosystem, counts in ecosystem_status_counts.items()
            },
        }

    def _compute_manifest_hash(self) -> str | None:
        manifest_candidates = ["pyproject.toml", "package.json"]
        for filename in manifest_candidates:
            path = self._working_dir / filename
            if path.exists():
                content = path.read_bytes()
                return hashlib.sha256(content).hexdigest()
        return None

    def _create_manifest(self, manifest_type: str, project_type: str) -> None:
        if not manifest_type:
            return
        manifest_path = self._working_dir / manifest_type
        if manifest_path.exists():
            if self._story0_config.get("never_overwrite_manifest", True):
                self._emit_progress(
                    f"[Preflight] Skipped: {manifest_path.name} exists; never_overwrite_manifest=true"
                )
                return
        if manifest_type == "package.json":
            payload = {"name": project_type or "obra-project", "version": "0.1.0"}
            manifest_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        elif manifest_type == "pyproject.toml":
            manifest_path.write_text(
                '[project]\nname = "obra-project"\nversion = "0.1.0"\n',
                encoding="utf-8",
            )
        elif manifest_type == "Cargo.toml":
            manifest_path.write_text(
                '[package]\nname = "obra_project"\nversion = "0.1.0"\n',
                encoding="utf-8",
            )
        elif manifest_type == "go.mod":
            manifest_path.write_text("module obra_project\n\ngo 1.21\n", encoding="utf-8")
        elif manifest_type == "Gemfile":
            manifest_path.write_text('source "https://rubygems.org"\n', encoding="utf-8")
        else:
            manifest_path.write_text("", encoding="utf-8")

    def _collect_implied_directories(self, structure: Any, base: Path) -> set[Path]:
        directories: set[Path] = set()
        if isinstance(structure, dict):
            for key, value in structure.items():
                path = base / str(key)
                if isinstance(value, (dict, list)):
                    directories.add(path)
                    directories.update(self._collect_implied_directories(value, path))
                    continue
                directories.update(parent for parent in path.parents if parent != base and base in parent.parents)
        elif isinstance(structure, list):
            for item in structure:
                directories.update(self._collect_implied_directories(item, base))
        return directories

    def _ensure_directory(self, path: Path) -> None:
        if path.exists() and not path.is_dir():
            path.unlink()
        path.mkdir(parents=True, exist_ok=True)

    def _create_structure(
        self,
        structure: Any,
        base: Path | None = None,
        implied_directories: set[Path] | None = None,
    ) -> None:
        base = base or self._working_dir
        if implied_directories is None:
            implied_directories = self._collect_implied_directories(structure, base)
        if isinstance(structure, dict):
            for key, value in structure.items():
                path = base / str(key)
                if isinstance(value, (dict, list)) or path in implied_directories:
                    self._ensure_directory(path)
                    if isinstance(value, (dict, list)):
                        self._create_structure(value, path, implied_directories)
                else:
                    self._ensure_directory(path.parent)
                    if not path.exists():
                        path.touch()
        elif isinstance(structure, list):
            for item in structure:
                self._create_structure(item, base, implied_directories)

    def _coerce_prereq(self, prereq: dict[str, Any]) -> Prerequisite:
        category = prereq.get("category", PrerequisiteCategory.AUTO)
        source = prereq.get("source", PrerequisiteSource.INFERRED)
        try:
            category = PrerequisiteCategory(category)
        except ValueError:
            category = PrerequisiteCategory.AUTO
        try:
            source = PrerequisiteSource(source)
        except ValueError:
            source = PrerequisiteSource.INFERRED
        return Prerequisite(
            id=str(prereq.get("id") or prereq.get("name") or "unknown"),
            category=category,
            name=str(prereq.get("name") or "unknown"),
            source=source,
            reason=str(prereq.get("reason") or ""),
            status=PrerequisiteStatus.PENDING,
            ecosystem=prereq.get("ecosystem"),
        )

    def _is_blocking(self, category: PrerequisiteCategory) -> bool:
        # In mock_credentials mode, service, credential, and local capability
        # failures are non-blocking since the user is running in simulation mode
        if self._story0_config.get("mock_credentials") and category in (
            PrerequisiteCategory.CREDENTIAL,
            PrerequisiteCategory.SERVICE,
            PrerequisiteCategory.LOCAL_CAPABILITY,
        ):
            return False
        return category in (
            PrerequisiteCategory.CREDENTIAL,
            PrerequisiteCategory.SERVICE,
            PrerequisiteCategory.USER_ACTION,
            PrerequisiteCategory.ACCOUNT,
            PrerequisiteCategory.LOCAL_CAPABILITY,
        )

    def _finalize_result(
        self,
        status: str,
        completed: list[str],
        failed: list[str],
        skipped: list[str],
        blocking_failures: list[str],
        non_blocking_failures: list[str],
        verification_tools: dict[str, Any],
    ) -> Story0Result:
        verification_tools = self._sanitize_verification_tools(verification_tools)
        self._verifier.verification_tools_state = verification_tools
        if status == Story0Status.COMPLETE.value:
            self._save_state(status=Story0Status.COMPLETE)
        elif status == Story0Status.FAILED.value:
            self._save_state(status=Story0Status.FAILED)
        else:
            self._save_state(status=Story0Status.PARTIAL)
        return Story0Result(
            status=status,
            completed=completed,
            failed=failed,
            skipped=skipped,
            blocking_failures=blocking_failures,
            non_blocking_failures=non_blocking_failures,
            state_path=self._state_path,
            verification_tools=verification_tools,
            mocked_credentials=self._mocked_credentials,
        )

    @staticmethod
    def _sanitize_verification_tools(
        verification_tools: dict[str, Any],
    ) -> dict[str, Any]:
        if not isinstance(verification_tools, dict):
            return {}
        allowed_keys = {"available", "missing", "source"}
        return {key: value for key, value in verification_tools.items() if key in allowed_keys}

    def _discover_verification_tools(
        self,
        force_refresh: bool | None = None,
    ) -> dict[str, Any]:
        """Backward-compatible shim for verification tool discovery."""
        return self._verifier.discover_verification_tools(force_refresh=force_refresh)

    # _run_verification_preflight and related methods moved to
    # obra.hybrid.story0.verification_installer



__all__ = [
    "Story0Handler",
    "Story0Result",
    "check_orphaned_containers",
    "cleanup_containers",
]
