"""Intent generation handler for Hybrid Orchestrator.

This module handles intent generation from user objectives using LLM.
It classifies the input type and generates a structured intent with
problem statement, assumptions, requirements, acceptance criteria, and non-goals.

The intent generation process:
    1. Classify input type (vague_nl, rich_nl, prd, prose_plan, structured_plan)
    2. For vague inputs: invoke LLM to expand into structured intent
    3. For rich inputs: parse directly or use LLM for extraction
    4. Return IntentModel with all required fields

Architecture (ADR-035):
    - Client-side LLM invocation (privacy-preserving)
    - Two-tier prompting: strategic prompts can come from server or local templates
    - Intent stored locally in ~/.obra/intents/{project}/

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - docs/decisions/ADR-035-unified-hybrid-architecture.md
    - obra/intent/models.py
    - obra/intent/storage.py
"""

import json
import logging
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from obra.config.llm import resolve_tier_config
from obra.hybrid.handlers.intent_llm_invoker import (
    IntentLLMInvoker,
    classify_cli_error_response,
)
from obra.hybrid.handlers.intent_response_parser import IntentResponseParser
from obra.intent.detection import detect_input_type
from obra.intent.models import EnrichmentLevel, InputType, IntentMode, IntentModel
from obra.intent.token_budget import (
    check_token_budget,
    chunk_text_by_tokens,
    estimate_tokens,
)
from obra.llm.cli_runner import invoke_llm_via_cli  # Compatibility patch surface for tests

logger = logging.getLogger(__name__)


class IntentHandler:
    """Handler for intent generation from user objectives.

    Takes a user objective (vague or detailed) and generates a structured
    intent using LLM. The intent captures problem statement, assumptions,
    requirements, acceptance criteria, and explicit non-goals.

    ## Client-Side LLM (ADR-035)

    Intent generation happens client-side to preserve privacy. User objectives
    and project context never leave the local machine during intent generation.

    ## Input Classification

    The handler classifies inputs into:
    - vague_nl: Short, underspecified ("add auth")
    - rich_nl: Detailed description with requirements
    - prd: Product requirements document (file)
    - prose_plan: Unstructured plan document (file)
    - structured_plan: MACHINE_PLAN JSON/YAML (file)

    Example:
        >>> handler = IntentHandler(Path("/path/to/project"))
        >>> intent = handler.generate("add user authentication")
        >>> print(intent.problem_statement)
    """

    def __init__(
        self,
        working_dir: Path,
        project: str | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
        production_logger: Any | None = None,
    ) -> None:
        """Initialize IntentHandler.

        Args:
            working_dir: Working directory for file access
            project: Optional project identifier (defaults to working_dir name)
            on_stream: Optional callback for LLM streaming chunks
            llm_config: Optional LLM configuration
            log_event: Optional logger for hybrid events
            trace_id: Optional trace ID for monitoring
            parent_span_id: Optional parent span ID for monitoring
        """
        self._working_dir = working_dir
        self._project = project or working_dir.name
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context
        self._production_logger = production_logger
        self._parser = IntentResponseParser()
        self._invoker = IntentLLMInvoker(
            working_dir=self._working_dir,
            llm_config=self._llm_config,
            emit_progress=self._emit_progress,
            on_stream=self._on_stream,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            monitoring_context=self._monitoring_context,
            production_logger=self._production_logger,
            cli_error_classifier=classify_cli_error_response,
        )
        self._invoke_llm = self._invoker.invoke_raw
        self._invoke_llm_with_template = self._invoker.invoke_with_template
        self._parse_intent_response = self._parser.parse
        self._is_interrogative = self._parser.is_interrogative
        self._tier4_fallback = self._parser.tier4_fallback

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as exc:
                logger.debug("Intent progress callback failed: %s", exc)
        if self._log_event:
            try:
                self._log_event(f"progress_{action}", **payload)
            except Exception as exc:
                logger.debug("Intent progress log failed: %s", exc)

    def generate(
        self,
        objective: str,
        *,
        mode: IntentMode = IntentMode.FULL,
        input_type: InputType | None = None,
        base_prompt: str | None = None,
        force_empty: bool = False,
        force_existing: bool = False,
        detect_project_state_flag: bool = False,
        userplan_id: str | None = None,
        userplan_version: int | None = None,
    ) -> IntentModel:
        """Generate a structured intent from user objective.

        Args:
            objective: User objective (natural language)
            mode: Intent generation mode (light or full)
            input_type: Optional pre-classified input type (auto-detects if None)
            base_prompt: Optional base prompt from server (two-tier prompting)
            force_empty: Force EMPTY project state (new/minimal project)
            force_existing: Force EXISTING project state (established codebase)
            detect_project_state_flag: Enable detection for PRD/plan inputs (skipped by default)
            userplan_id: Optional UserPlan ID to link this intent to
            userplan_version: Optional UserPlan version this intent is derived for

        Returns:
            IntentModel with structured intent data

        Raises:
            ValueError: If objective is empty or invalid

        Example:
            >>> handler = IntentHandler(Path.cwd())
            >>> intent = handler.generate("add authentication system")
            >>> print(intent.requirements)
            ['User can register', 'User can login', ...]
        """
        if not objective or not objective.strip():
            msg = "Objective cannot be empty"
            raise ValueError(msg)

        objective = objective.strip()
        logger.info("Generating intent for objective: %s...", objective[:50])

        if mode == IntentMode.LIGHT:
            return self.generate_light(objective)

        # Check token budget before processing (TOKEN-BUDGET-001)
        budget_result = check_token_budget(
            objective,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        if budget_result.warning:
            logger.warning(
                "Input approaching token budget limit: %d tokens (%.1f%% of %d budget)",
                budget_result.estimated_tokens,
                budget_result.estimated_tokens / budget_result.budget * 100,
                budget_result.budget,
            )

        # Handle inputs that exceed budget
        if not budget_result.within_budget:
            logger.warning(
                "Input exceeds token budget by %d tokens. Processing may be chunked or truncated.",
                budget_result.exceeds_by,
            )
            # Emit token budget exceeded event
            if self._log_event:
                self._log_event(
                    "token_budget_exceeded",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    estimated_tokens=budget_result.estimated_tokens,
                    budget=budget_result.budget,
                    exceeds_by=budget_result.exceeds_by,
                    objective_length=len(objective),
                )

        # Classify input type
        detected_type = input_type or detect_input_type(objective)
        logger.debug("Detected input type: %s", detected_type)

        # Emit input_type_classified event (S4.T2)
        if self._log_event:
            self._log_event(
                "input_type_classified",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                detected_type=detected_type.value,
                objective_length=len(objective),
            )

        # Detect project state (FEAT-AUTO-INTENT-002 S1)
        from obra.config import (
            get_project_detection_empty_threshold,
            get_project_detection_enabled,
            get_project_detection_existing_threshold,
        )
        from obra.intent.detection import ProjectState, detect_project_state

        project_state_result = None

        # Determine if detection should run
        should_detect = False
        if detected_type in {InputType.VAGUE_NL, InputType.RICH_NL}:
            # Always detect for natural language inputs
            should_detect = True
        elif detected_type in {InputType.PRD, InputType.PROSE_PLAN}:
            # For PRD/plan, only detect if flag is set
            should_detect = detect_project_state_flag
        # STRUCTURED_PLAN: never detect (not applicable)

        # Run detection if enabled and applicable
        if should_detect and get_project_detection_enabled():
            # Determine force state
            force_state = None
            if force_empty:
                force_state = ProjectState.EMPTY
            elif force_existing:
                force_state = ProjectState.EXISTING

            # Get thresholds from config
            empty_threshold = get_project_detection_empty_threshold()
            existing_threshold = get_project_detection_existing_threshold()

            # Run detection
            project_state_result = detect_project_state(
                project_dir=self._working_dir,
                empty_threshold=empty_threshold,
                existing_threshold=existing_threshold,
                llm_config=self._llm_config,
                force_state=force_state,
            )

            logger.info(
                "Project state detected: %s (via %s)",
                project_state_result.state.value,
                project_state_result.method,
            )

            # Emit project_state_detected event (S4.T1)
            if self._log_event:
                self._log_event(
                    "project_state_detected",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    state=project_state_result.state.value,
                    method=project_state_result.method,
                    file_count=project_state_result.file_count,
                    empty_threshold=empty_threshold,
                    existing_threshold=existing_threshold,
                )

        # Generate intent based on input type
        # All generation methods return (intent_data, enrichment_level) tuple
        if detected_type == InputType.VAGUE_NL:
            intent_data, enrichment_level = self._generate_from_vague_nl(objective, base_prompt)
        elif detected_type == InputType.RICH_NL:
            intent_data, enrichment_level = self._generate_from_rich_nl(objective, base_prompt)
        elif detected_type == InputType.PRD:
            intent_data, enrichment_level = self._generate_from_prd(objective, base_prompt)
        elif detected_type == InputType.PROSE_PLAN:
            intent_data, enrichment_level = self._generate_from_prose_plan(objective, base_prompt)
        elif detected_type == InputType.STRUCTURED_PLAN:
            intent_data, enrichment_level = self._generate_from_structured_plan(objective)
        else:
            # Fallback to vague_nl handling
            intent_data, enrichment_level = self._generate_from_vague_nl(objective, base_prompt)

        # Create IntentModel
        slug = IntentModel.slugify(intent_data.get("problem_statement", objective))
        intent_id = IntentModel.generate_id(slug)

        intent = IntentModel(
            id=intent_id,
            project=self._project,
            slug=slug,
            created=datetime.now(UTC).isoformat(),
            input_type=detected_type,
            problem_statement=intent_data["problem_statement"],
            assumptions=intent_data.get("assumptions", []),
            requirements=intent_data.get("requirements", []),
            constraints=intent_data.get("constraints", []),
            acceptance_criteria=intent_data.get("acceptance_criteria", []),
            non_goals=intent_data.get("non_goals", []),
            risks=intent_data.get("risks", []),
            raw_objective=objective,
            enrichment_level=enrichment_level,
            intent_mode=mode,
            userplan_id=userplan_id,
            userplan_version=userplan_version,
        )

        logger.info("Generated intent: %s", intent.id)
        return intent

    def generate_light(self, objective: str) -> IntentModel:
        """Generate a minimal intent without LLM enrichment."""
        if not objective or not objective.strip():
            msg = "Objective cannot be empty"
            raise ValueError(msg)

        objective = objective.strip()
        slug = IntentModel.slugify(objective)
        intent_id = IntentModel.generate_id(slug)

        return IntentModel(
            id=intent_id,
            project=self._project,
            slug=slug,
            created=datetime.now(UTC).isoformat(),
            input_type=InputType.VAGUE_NL,
            problem_statement=objective,
            assumptions=[],
            requirements=[objective],
            constraints=[],
            acceptance_criteria=["Objective completed successfully"],
            non_goals=[],
            risks=[],
            raw_objective=objective,
            enrichment_level=EnrichmentLevel.NONE,
            intent_mode=IntentMode.LIGHT,
        )

    def _generate_from_vague_nl(
        self,
        objective: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from vague natural language input using LLM.

        Args:
            objective: Vague user objective
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)
        """
        # Import prompt template here to avoid circular import
        from obra.prompts.intent.generation import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            objective,
            input_type=InputType.VAGUE_NL,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")

        # Template edit pattern (FEAT-TEMPLATE-JSON-001)
        return self._invoke_llm_with_template(
            prompt,
            objective,
            provider=tier_config["provider"],
            model=tier_config["model"],
            reasoning_level=tier_config["reasoning_level"],
            auth_method=tier_config["auth_method"],
        )

    def _generate_from_rich_nl(
        self,
        objective: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from rich natural language input.

        For rich NL, we use LLM to extract structure from the detailed input.

        Args:
            objective: Rich user objective with details
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)
        """
        # Import prompt template here
        from obra.prompts.intent.generation import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            objective,
            input_type=InputType.RICH_NL,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")

        # Template edit pattern (FEAT-TEMPLATE-JSON-001)
        return self._invoke_llm_with_template(
            prompt,
            objective,
            provider=tier_config["provider"],
            model=tier_config["model"],
            reasoning_level=tier_config["reasoning_level"],
            auth_method=tier_config["auth_method"],
        )

    def _generate_from_prd(
        self,
        prd_path: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from PRD file.

        Args:
            prd_path: Path to PRD file
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)

        Raises:
            FileNotFoundError: If PRD file doesn't exist
            ValueError: If PRD file is empty or unreadable
        """
        # Resolve path relative to working directory
        file_path = Path(prd_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"PRD file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read PRD content
        try:
            prd_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read PRD file: {e}"
            raise ValueError(msg) from e

        if not prd_content.strip():
            msg = f"PRD file is empty: {file_path}"
            raise ValueError(msg)

        logger.info(
            "Extracting intent from PRD: %s (%d chars)",
            file_path.name,
            len(prd_content),
        )

        # Check token budget for PRD content (TOKEN-BUDGET-001)
        budget_result = check_token_budget(
            prd_content,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        if not budget_result.within_budget:
            logger.warning(
                "PRD content exceeds token budget (%d tokens > %d budget). "
                "Chunking content for processing.",
                budget_result.estimated_tokens,
                budget_result.budget,
            )
            # Log event for observability
            if self._log_event:
                self._log_event(
                    "prd_token_budget_exceeded",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    file_path=str(file_path),
                    estimated_tokens=budget_result.estimated_tokens,
                    budget=budget_result.budget,
                    exceeds_by=budget_result.exceeds_by,
                )
            # Process in chunks and merge results
            return self._generate_from_chunked_content(prd_content, InputType.PRD, base_prompt)

        # Import prompt template
        from obra.prompts.intent.generation import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            prd_content,
            input_type=InputType.PRD,
        )

        tier_config = resolve_tier_config(tier="medium", role="orchestrator")

        # Template edit pattern (FEAT-TEMPLATE-JSON-001)
        return self._invoke_llm_with_template(
            prompt,
            prd_content[:100],  # Use first 100 chars for fallback
            provider=tier_config["provider"],
            model=tier_config["model"],
            reasoning_level=tier_config["reasoning_level"],
            auth_method=tier_config["auth_method"],
        )

    def _generate_from_prose_plan(
        self,
        plan_path: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from prose plan file.

        Args:
            plan_path: Path to prose plan file
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)

        Raises:
            FileNotFoundError: If plan file doesn't exist
            ValueError: If plan file is empty or unreadable
        """
        # Resolve path relative to working directory
        file_path = Path(plan_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"Plan file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read plan content
        try:
            plan_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read plan file: {e}"
            raise ValueError(msg) from e

        if not plan_content.strip():
            msg = f"Plan file is empty: {file_path}"
            raise ValueError(msg)

        logger.info(
            "Extracting intent from prose plan: %s (%d chars)",
            file_path.name,
            len(plan_content),
        )

        # Check token budget for plan content (TOKEN-BUDGET-001)
        budget_result = check_token_budget(
            plan_content,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        if not budget_result.within_budget:
            logger.warning(
                "Prose plan content exceeds token budget (%d tokens > %d budget). "
                "Chunking content for processing.",
                budget_result.estimated_tokens,
                budget_result.budget,
            )
            # Log event for observability
            if self._log_event:
                self._log_event(
                    "prose_plan_token_budget_exceeded",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    file_path=str(file_path),
                    estimated_tokens=budget_result.estimated_tokens,
                    budget=budget_result.budget,
                    exceeds_by=budget_result.exceeds_by,
                )
            # Process in chunks and merge results
            return self._generate_from_chunked_content(
                plan_content, InputType.PROSE_PLAN, base_prompt
            )

        # Import prompt template
        from obra.prompts.intent.generation import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            plan_content,
            input_type=InputType.PROSE_PLAN,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")

        # Template edit pattern (FEAT-TEMPLATE-JSON-001)
        return self._invoke_llm_with_template(
            prompt,
            plan_content[:100],  # Use first 100 chars for fallback
            provider=tier_config["provider"],
            model=tier_config["model"],
            reasoning_level=tier_config["reasoning_level"],
            auth_method=tier_config["auth_method"],
        )

    def _generate_from_structured_plan(
        self,
        plan_path: str,
        base_prompt: str | None = None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from structured plan file using LLM.

        Uses LLM to synthesize and enrich intent from MACHINE_PLAN structure,
        providing better problem statements and identifying implicit requirements
        beyond what mechanical extraction could provide.

        Args:
            plan_path: Path to structured MACHINE_PLAN file
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)

        Raises:
            FileNotFoundError: If plan file doesn't exist
            ValueError: If file is not a valid MACHINE_PLAN
        """
        # Resolve path relative to working directory
        file_path = Path(plan_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"Plan file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read and parse plan file
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read plan file: {e}"
            raise ValueError(msg) from e

        # Parse JSON or YAML to validate structure
        try:
            if file_path.suffix == ".json":
                data = json.loads(content)
            else:  # YAML
                data = yaml.safe_load(content)
        except Exception as e:
            msg = f"Failed to parse plan file: {e}"
            raise ValueError(msg) from e

        # Validate structure
        from obra.intent.detection import is_valid_machine_plan

        if not is_valid_machine_plan(data):
            msg = f"Invalid MACHINE_PLAN structure in: {file_path}"
            raise ValueError(msg)

        logger.info(
            "Generating intent via LLM from structured plan: %s",
            file_path.name,
        )

        # Import prompt template
        from obra.prompts.intent.generation import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            content,
            input_type=InputType.STRUCTURED_PLAN,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")

        # Template edit pattern (FEAT-TEMPLATE-JSON-001)
        return self._invoke_llm_with_template(
            prompt,
            content[:100],  # Use first 100 chars for fallback
            provider=tier_config["provider"],
            model=tier_config["model"],
            reasoning_level=tier_config["reasoning_level"],
            auth_method=tier_config["auth_method"],
        )

    def _generate_from_chunked_content(
        self,
        content: str,
        input_type: InputType,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from content that exceeds token budget by processing chunks.

        Splits large content into manageable chunks, processes each chunk separately,
        and merges the results into a unified intent. Uses a synthesis step to
        combine partial intents from each chunk.

        Args:
            content: Full content to process (exceeds token budget)
            input_type: Type of input (PRD, PROSE_PLAN, etc.)
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (merged_intent_data, enrichment_level)

        Note:
            This method is called when input exceeds INTENT_TOKEN_BUDGET.
            It chunks the content and processes each chunk separately,
            then synthesizes a unified intent from the partial results.
        """
        from obra.prompts.intent.generation import build_intent_generation_prompt

        # Chunk the content
        chunks = chunk_text_by_tokens(content)
        num_chunks = len(chunks)

        logger.info(
            "Processing large %s input in %d chunks for intent extraction",
            input_type.value,
            num_chunks,
        )

        # Log chunking event
        if self._log_event:
            self._log_event(
                "intent_chunked_processing_started",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                input_type=input_type.value,
                num_chunks=num_chunks,
                chunk_tokens=[estimate_tokens(c) for c in chunks],
                total_tokens=estimate_tokens(content),
            )

        # Process each chunk
        partial_intents: list[dict[str, Any]] = []
        tier_config = resolve_tier_config(tier="fast", role="orchestrator")

        for i, chunk in enumerate(chunks):
            logger.info(
                "Processing chunk %d/%d (~%d tokens)",
                i + 1,
                num_chunks,
                estimate_tokens(chunk),
            )

            # Build prompt for this chunk with context about chunking
            chunk_context = (
                f"[NOTE: This is chunk {i + 1} of {num_chunks} from a large document. "
                f"Extract all relevant intent information from this section.]\n\n"
            )
            chunk_content = chunk_context + chunk

            prompt = base_prompt or build_intent_generation_prompt(
                chunk_content,
                input_type=input_type,
            )

            try:
                raw_response = self._invoke_llm(
                    prompt,
                    provider=tier_config["provider"],
                    model=tier_config["model"],
                    reasoning_level=tier_config["reasoning_level"],
                    auth_method=tier_config["auth_method"],
                )

                # Parse response
                intent_data, _ = self._parse_intent_response(raw_response, chunk[:100])
                partial_intents.append(intent_data)

            except Exception as e:
                logger.warning(
                    "Failed to process chunk %d/%d: %s",
                    i + 1,
                    num_chunks,
                    str(e),
                )
                # Continue with other chunks

        if not partial_intents:
            logger.error("All chunks failed to process")
            return self._tier4_fallback(content[:200]), EnrichmentLevel.NONE

        # Merge partial intents
        merged_intent = self._merge_partial_intents(partial_intents)

        # Log completion
        if self._log_event:
            self._log_event(
                "intent_chunked_processing_completed",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                input_type=input_type.value,
                num_chunks=num_chunks,
                chunks_processed=len(partial_intents),
                merged_requirements=len(merged_intent.get("requirements", [])),
            )

        logger.info(
            "Merged intent from %d chunks: %d requirements, %d assumptions",
            len(partial_intents),
            len(merged_intent.get("requirements", [])),
            len(merged_intent.get("assumptions", [])),
        )

        return merged_intent, EnrichmentLevel.FULL

    def _merge_partial_intents(
        self,
        partial_intents: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Merge multiple partial intents from chunked processing.

        Combines partial intent data from multiple chunks into a unified intent.
        Uses the first non-empty problem statement and deduplicates list fields.

        Args:
            partial_intents: List of partial intent dicts from chunks

        Returns:
            Merged intent dict with combined fields
        """
        if not partial_intents:
            return {
                "problem_statement": "",
                "assumptions": [],
                "requirements": [],
                "acceptance_criteria": [],
                "non_goals": [],
            }

        # Use first non-empty problem statement (usually most comprehensive)
        problem_statement = ""
        for intent in partial_intents:
            ps = intent.get("problem_statement", "")
            if ps and len(ps) > len(problem_statement):
                problem_statement = ps

        # Merge list fields with deduplication
        def merge_list_field(field_name: str) -> list[str]:
            seen: set[str] = set()
            merged: list[str] = []
            for intent in partial_intents:
                items = intent.get(field_name, [])
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, str):
                            # Normalize for deduplication
                            normalized = item.strip().lower()
                            if normalized and normalized not in seen:
                                seen.add(normalized)
                                merged.append(item.strip())
            return merged

        return {
            "problem_statement": problem_statement,
            "assumptions": merge_list_field("assumptions"),
            "requirements": merge_list_field("requirements"),
            "constraints": merge_list_field("constraints"),
            "acceptance_criteria": merge_list_field("acceptance_criteria"),
            "non_goals": merge_list_field("non_goals"),
            "risks": merge_list_field("risks"),
        }


__all__ = ["IntentHandler"]
