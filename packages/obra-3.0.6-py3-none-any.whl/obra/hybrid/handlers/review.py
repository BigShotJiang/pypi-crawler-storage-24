"""Review handler for hybrid orchestrator actions."""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any, cast

from obra.agents import AgentDeployer
from obra.api.protocol import AgentType, ReviewRequest
from obra.config import get_review_agent_timeout
from obra.config.loaders import (
    get_quality_threshold,
    get_review_agents_max_workers,
    get_review_agents_parallel,
)
from obra.display import print_error, print_info, print_warning
from obra.display.observability import ProgressEmitter
from obra.hybrid.handlers.review_file_analyzer import FileComplexityAnalyzer
from obra.hybrid.handlers.review_report_formatter import ReviewReportFormatter
from obra.hybrid.handlers.review_runtime_support import (
    apply_execution_scope,
    build_intent_context,
    emit_skip_record,
)
from obra.review.config import ALLOWED_AGENTS, ReviewConfig
from obra.review.verdict import (
    _calculate_compiled_score,
    _normalize_priority,
    compute_verdict,
)
from obra.security import PromptSanitizer
from obra.utils.file_tracker import FileStateTracker

logger = logging.getLogger(__name__)


class ReviewHandler:
    """Deploy review agents and aggregate their findings."""

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        domain: Any = None,
        review_config: ReviewConfig | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._domain = domain

        parallel_enabled = get_review_agents_parallel()
        max_workers = get_review_agents_max_workers()
        self._parallel_enabled = parallel_enabled

        self._deployer = AgentDeployer(
            working_dir,
            llm_config=llm_config,
            domain=self._domain,
            parallel=parallel_enabled,
            max_workers=max_workers,
        )
        logger.info(
            f"AgentDeployer initialized: parallel={parallel_enabled}, max_workers={max_workers}"
        )

        self._sanitizer = PromptSanitizer()
        self._file_tracker = FileStateTracker(working_dir)
        # Use from_cli_and_config to respect feature gates (quality_automation.agents.*)
        # ISSUE-REVIEW-AGENTS-001: Plain ReviewConfig() bypasses feature gate loading
        self._config = review_config or ReviewConfig.from_cli_and_config(project_path=working_dir)
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._progress_emitter = progress_emitter
        self._review_request: ReviewRequest | None = None
        self._iteration_counter: dict[str, int] = {}
        self._session_review_cycle = 0
        self._file_analyzer = FileComplexityAnalyzer(
            working_dir=self._working_dir,
            file_tracker=self._file_tracker,
            review_request_getter=lambda: self._review_request,
        )
        self._formatter = ReviewReportFormatter(
            config=self._config,
            log_info=self._log_info,
            log_warning=self._log_warning,
            log_error=self._log_error,
            session_review_cycle_getter=lambda: self._session_review_cycle,
        )
        self._get_changed_files = self._file_analyzer.get_changed_files
        self._get_all_files_for_complexity = self._file_analyzer.get_all_files_for_complexity
        self._count_lines_added = self._file_analyzer.count_lines_added
        self._has_security_sensitive_files = self._file_analyzer.has_security_sensitive_files
        self._has_test_files = self._file_analyzer.has_test_files
        self._detect_complexity = self._file_analyzer.detect_complexity
        self._build_completion_message = self._formatter.build_completion_message
        self._resolve_output_format = self._formatter.resolve_output_format
        self._emit_json_output = self._formatter.emit_json_output
        self._build_json_output = self._formatter.build_json_output
        self._should_show_full_review_hint = self._formatter.should_show_full_review_hint

    def _log_info(self, message: str) -> None:
        """Print info messages unless quiet mode is enabled."""
        if not self._config.quiet:
            print_info(message)

    def _log_warning(self, message: str) -> None:
        """Print warning messages unless quiet mode is enabled."""
        if not self._config.quiet:
            print_warning(message)

    def _log_error(self, message: str) -> None:
        """Print error messages unless quiet mode is enabled."""
        if not self._config.quiet:
            print_error(message)

    def _emit_skip_record(
        self,
        item_id: str,
        agent_type: str,
        status: str,
        error_message: str | None,
    ) -> None:
        emit_skip_record(
            working_dir=getattr(self, "_working_dir", Path.cwd()),
            item_id=item_id,
            agent_type=agent_type,
            status=status,
            error_message=error_message,
            log_event=getattr(self, "_log_event", None),
            trace_id=getattr(self, "_trace_id", None),
        )

    def handle(self, request: ReviewRequest) -> dict[str, Any]:
        """Handle REVIEW action.

        Falls back to local complexity detection when the server does not provide
        agents to run. Emits per-agent progress, counts, and a summary with tier metadata.

        Args:
            request: ReviewRequest from server

        Returns:
            Dict with agent_reports list, total issue counts, and failed agent count.
        """
        item_id = str(request.item_id or "").strip()
        if not item_id:
            error_message = (
                "Review request missing item_id; refusing to run review without item context."
            )
            logger.error(error_message)
            if self._log_event:
                self._log_event(
                    "review_input_invalid",
                    reason_code="missing_item_id",
                    error_message=error_message,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )
            raise ValueError(error_message)
        request.item_id = item_id

        logger.info(f"Starting review for item: {request.item_id}")
        self._review_request = request
        self._session_review_cycle += 1
        # Track iteration count per item_id
        if not hasattr(self, "_iteration_counter"):
            self._iteration_counter = {}
        item_key = request.item_id or ""
        self._iteration_counter[item_key] = self._iteration_counter.get(item_key, 0) + 1
        current_iteration = self._iteration_counter[item_key]

        output_format = self._resolve_output_format(request.format)
        is_json_output = output_format == "json"
        emit_text_output = not is_json_output

        if emit_text_output:
            mode = "parallel" if self._parallel_enabled else "series"
            self._log_info(f"Running review agents in {mode} for: {request.item_id}")

        agent_reports: list[dict[str, Any]] = []
        agent_runs: list[dict[str, Any]] = []
        json_output: dict[str, Any] | None = None
        complexity_tier: str | None = request.complexity

        if self._config.skip_review:
            if emit_text_output:
                self._log_info("Review skipped by configuration")

            if is_json_output:
                json_output = self._emit_json_output(
                    agent_runs=agent_runs,
                    agent_reports=agent_reports,
                    complexity_tier=complexity_tier,
                    total_elapsed_ms=0,
                )

            result: dict[str, Any] = {
                "item_id": request.item_id,
                "agent_reports": agent_reports,
                "total_issues": 0,
                "failed_agents": 0,
            }
            if json_output is not None:
                result["review_output"] = json_output
            return result

        agents_from_request = request.agents_to_run or []
        selection: dict[str, Any] | None = None
        changed_files: list[str] | None = None

        if agents_from_request:
            changed_files = self._get_changed_files()
            logger.info("Using server-provided review agents: %s", agents_from_request)
        else:
            selection = self._detect_complexity()
            changed_files = selection.get("changed_files")
            complexity_tier = complexity_tier or selection.get("complexity")
            logger.info(
                "Using local review agent selection (%s): %s",
                selection.get("complexity", "unknown"),
                selection["agents"],
            )

        resolved_agents = self._config.resolve_agents(
            detected_agents=selection["agents"] if selection else None,
            server_agents=agents_from_request,
        )
        if logger.isEnabledFor(logging.DEBUG):
            baseline_agents = agents_from_request or (selection["agents"] if selection else [])
            removed_agents = [agent for agent in baseline_agents if agent not in resolved_agents]
            added_agents = [agent for agent in resolved_agents if agent not in baseline_agents]
            logger.debug(
                "Review agents resolved: %s (baseline=%s, added=%s, removed=%s, "
                "full_review=%s, skip_review=%s, explicit_agents=%s)",
                resolved_agents,
                baseline_agents,
                added_agents,
                removed_agents,
                self._config.full_review,
                self._config.skip_review,
                self._config.explicit_agents,
            )

        if not resolved_agents:
            if emit_text_output:
                self._log_info("No review agents selected after configuration overrides")

            if is_json_output:
                json_output = self._emit_json_output(
                    agent_runs=agent_runs,
                    agent_reports=agent_reports,
                    complexity_tier=complexity_tier,
                    total_elapsed_ms=0,
                )

            result = {
                "item_id": request.item_id,
                "agent_reports": agent_reports,
                "total_issues": 0,
                "failed_agents": 0,
            }
            if json_output is not None:
                result["review_output"] = json_output
            return result

        max_review_attempts = self._config.max_review_attempts or 3
        # Ensure display ceiling is never below current iteration so
        # telemetry/UI never shows "attempt 2 of 1".
        effective_max = max(max_review_attempts, current_iteration)
        if self._progress_emitter:
            self._progress_emitter.review_loop_started(
                attempt=current_iteration,
                max_attempts=effective_max,
                agent_count=len(resolved_agents),
                parallel=self._parallel_enabled,
                item_id=request.item_id,
                review_cycle_id=request.review_cycle_id,
            )
        if self._log_event:
            self._log_event(
                "review_loop_started",
                item_id=request.item_id,
                review_cycle_id=request.review_cycle_id,
                attempt=current_iteration,
                iteration=current_iteration,
                max_attempts=effective_max,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

        files_for_agents = changed_files or None
        intent_context = self._build_intent_context()

        # Convert agent names to AgentType objects, filtering invalid ones
        agent_types = []
        for agent_name in resolved_agents:
            try:
                agent_types.append(AgentType(agent_name))
            except ValueError:
                logger.warning(f"Unknown agent type: {agent_name}, skipping")

        # Run agents (sequentially or in parallel based on config)
        # FEAT-RESILIENCE-P2-001: Graceful degradation for review agent failures
        try:
            results = self._deployer.run_agents(
                agents=agent_types,
                item_id=request.item_id,
                changed_files=files_for_agents,
                timeout_ms=None,  # Use per-agent budgets
                budgets=request.agent_budgets,
                intent_context=intent_context,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
            if not isinstance(results, list):
                # Test compatibility: older/degraded deployers may only expose run_agent().
                results = [
                    self._deployer.run_agent(
                        agent_type=agent_type,
                        item_id=request.item_id,
                        changed_files=files_for_agents,
                        timeout_ms=self._resolve_timeout_ms(
                            agent_type.value, request.agent_budgets.get(agent_type.value, {})
                        ),
                        intent_context=intent_context,
                        log_event=self._log_event,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                    )
                    for agent_type in agent_types
                ]
        except Exception as e:
            # FEAT-RESILIENCE-P2-001: If review agents fail completely, skip review and continue session
            logger.warning("Review agent failed, skipping review: %s", str(e))

            # Rule 26: Emit SkipRecords for all requested agents on total failure
            for agent_type in agent_types:
                self._emit_skip_record(
                    item_id=request.item_id,
                    agent_type=agent_type.value,
                    status="error",
                    error_message=str(e),
                )

            # Get default quality threshold from config
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            default_threshold = config.get("review", {}).get("default_quality_threshold", 0.7)

            # Return skipped review result
            if emit_text_output:
                self._log_warning(f"Review skipped due to agent failure: {e!s}")

            return {
                "item_id": request.item_id,
                "agent_reports": [],
                "total_issues": 0,
                "failed_agents": 0,
                "status": "skipped",
                "skip_reason": str(e),
                "quality_score": default_threshold,
            }

        # Process results to build agent_reports and agent_runs
        for agent_result in results:
            # Convert AgentResult to dict for agent_reports
            report = agent_result.to_dict()
            agent_reports.append(report)

            # Build agent_runs entry
            status = str(agent_result.status).lower()
            issue_count = len(agent_result.issues)
            elapsed_ms = agent_result.execution_time_ms
            error_message = agent_result.error

            agent_runs.append(
                {
                    "agent": agent_result.agent_type.value,
                    "status": status,
                    "issue_count": issue_count,
                    "elapsed_ms": elapsed_ms,
                    "error": error_message or None,
                }
            )

            # Rule 26: Emit SkipRecords for skipped or errored review agents.
            if status in ("skipped", "error", "timeout"):
                # SESSION-92257c4c: Surface skip reason from agent metadata
                # so console output explains *why* the agent was skipped (e.g.,
                # "no_files_after_filter") instead of showing bare "skipped".
                skip_reason = (agent_result.metadata or {}).get("skip_reason", "")
                skip_classification = (agent_result.metadata or {}).get(
                    "skip_classification", ""
                )
                diagnostic_msg = error_message or ""
                if not diagnostic_msg and skip_reason:
                    diagnostic_msg = skip_reason
                    if skip_classification:
                        diagnostic_msg = f"{skip_reason} ({skip_classification})"

                self._emit_skip_record(
                    item_id=request.item_id,
                    agent_type=agent_result.agent_type.value,
                    status=status,
                    error_message=diagnostic_msg or error_message,
                )
                if elapsed_ms == 0 and status == "skipped":
                    logger.warning(
                        "Review agent %s skipped in 0ms — reason: %s",
                        agent_result.agent_type.value,
                        diagnostic_msg or "unknown (no skip_reason in metadata)",
                    )

            # Emit progress events (post-execution for thread safety)
            if self._progress_emitter:
                self._progress_emitter.review_agent_started(agent_result.agent_type.value)
                # SESSION-92257c4c: Include skip reason in details so console
                # shows "skipped (no_files_after_filter)" instead of bare "skipped"
                display_details = error_message
                if not display_details and status == "skipped":
                    skip_reason = (agent_result.metadata or {}).get("skip_reason", "")
                    if skip_reason:
                        display_details = skip_reason
                self._progress_emitter.review_agent_completed(
                    agent_result.agent_type.value,
                    passed=status == "complete",
                    details=display_details,
                    status=status,
                )

            # Build and emit completion message
            elapsed_seconds = elapsed_ms / 1000.0
            completion_message, log_fn = self._build_completion_message(
                agent_result.agent_type.value,
                status,
                issue_count,
                elapsed_seconds,
                error_message,
            )
            if emit_text_output:
                log_fn(completion_message)

        # P1-6: Capture raw (pre-filter) score before scope filtering
        p0 = p1 = p2 = p3 = 0
        for _rpt in agent_reports:
            _issues = _rpt.get("issues", [])
            if not isinstance(_issues, list):
                continue
            for _iss in _issues:
                if not isinstance(_iss, dict):
                    continue
                _pri = _normalize_priority(_iss.get("priority"))
                if _pri == "P0":
                    p0 += 1
                elif _pri == "P1":
                    p1 += 1
                elif _pri == "P2":
                    p2 += 1
                else:
                    p3 += 1
        raw_score = round(_calculate_compiled_score(p0, p1, p2, p3) * 100)
        raw_threshold = round(get_quality_threshold() * 100)

        self._apply_execution_scope(agent_reports, changed_files)

        # Unified verdict: all scoring, agent-health, and pass/fail logic
        verdict = compute_verdict(
            agent_runs=agent_runs,
            agent_reports=agent_reports,
            raw_score_override=raw_score,
            raw_threshold_override=raw_threshold,
        )

        if verdict.raw_below_threshold and verdict.score >= verdict.threshold and not verdict.degraded:
            logger.warning(
                "Review filter adjusted score from %d to %d but raw score %d is below "
                "threshold %d — entering fix cycle.",
                verdict.raw_score, verdict.score, verdict.raw_score, verdict.threshold,
            )

        # Scorecard summaries are emitted by the server to avoid client/server drift.
        if self._log_event:
            total_elapsed_ms = sum(run["elapsed_ms"] for run in agent_runs)
            self._log_event(
                "review_loop_completed",
                stage="pre_filter",
                item_id=request.item_id,
                total_issues=verdict.total_issues,
                failed_agents=verdict.agents_failed,
                degraded=verdict.degraded,
                total_elapsed_ms=total_elapsed_ms,
                # Score disambiguation: this is the pre-filter score before the
                # server's review filter adjusts findings. The post-filter score
                # appears in review_score_finalized.
                score=verdict.score,
                pre_filter_score=verdict.score,
                preliminary_score=verdict.score,
                score_source="client_pre_filter",
                max_score=100,
                threshold=verdict.threshold,
                pre_filter_threshold=verdict.threshold,
                threshold_purpose="pre_filter",
                passed=verdict.passed,
                pre_filter_passed=verdict.passed,
                findings_count=verdict.total_issues,
                fix_needed=verdict.fix_needed,
                iteration=current_iteration,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                agents_ran=verdict.agents_ran,
                agents_skipped=verdict.agents_skipped,
                all_skipped=verdict.all_skipped,
                raw_below_threshold=verdict.raw_below_threshold,
            )
        complexity_display = (complexity_tier or "unknown").lower()
        agent_count = len(agent_runs)
        summary_line = (
            f"Review summary ({agent_count} {'agent' if agent_count == 1 else 'agents'}, "
            f"complexity={complexity_display}): "
            f"{verdict.total_issues} {'finding' if verdict.total_issues == 1 else 'findings'}"
        )

        if emit_text_output:
            if verdict.degraded:
                if verdict.all_skipped:
                    summary_line = (
                        f"{summary_line}, review unavailable "
                        "[DEGRADED: all agents skipped]"
                    )
                else:
                    summary_line = (
                        f"{summary_line}, {verdict.agents_failed} failed "
                        f"[DEGRADED: {verdict.degraded_reason}]"
                    )
                self._log_warning(summary_line)
            else:
                self._log_info(summary_line)

            if self._should_show_full_review_hint(agent_runs, complexity_display):
                self._log_info("Run with --full-review for comprehensive analysis.")

            if verdict.total_issues == 0 and not verdict.degraded and agent_runs:
                self._log_info("No fix required (0 findings).")

        logger.info(
            "Review complete: %s agents ran, %s failed, %s total issues (complexity=%s)",
            verdict.agents_ran,
            verdict.agents_failed,
            verdict.total_issues,
            complexity_display,
        )

        if self._progress_emitter and verdict.total_issues == 0 and not verdict.degraded and agent_runs:
            self._progress_emitter.review_no_fixes(request.item_id)

        if is_json_output:
            total_elapsed_ms = sum(run["elapsed_ms"] for run in agent_runs)
            json_output = self._emit_json_output(
                agent_runs=agent_runs,
                agent_reports=agent_reports,
                complexity_tier=complexity_display,
                total_elapsed_ms=total_elapsed_ms,
            )

        result: dict[str, Any] = {
            "item_id": request.item_id,
            "agent_reports": agent_reports,
            "total_issues": verdict.total_issues,
            "failed_agents": verdict.agents_failed,
            # P1-6: Include raw score so server-side filter cannot flip verdict
            "raw_score": verdict.raw_score,
            "raw_below_threshold": verdict.raw_below_threshold,
            "score": verdict.score,
            "passed": verdict.passed,
            "threshold": verdict.threshold,
        }
        if verdict.degraded:
            result["degraded"] = True
            result["degraded_reason"] = verdict.degraded_reason
        if json_output is not None:
            result["review_output"] = json_output
        return result

    def _resolve_timeout_ms(self, agent_name: str, budget: dict[str, Any] | None) -> int:
        """Resolve timeout in milliseconds using config override or agent budget."""
        if self._config.timeout_seconds is not None:
            return int(self._config.timeout_seconds * 1000)

        timeout_ms = None
        if isinstance(budget, dict):
            timeout_ms = budget.get("timeout_ms")

        if isinstance(timeout_ms, (int, float)) and timeout_ms > 0:
            return int(timeout_ms)

        logger.debug(
            "Using default timeout for %s agent (config unset, budget invalid): %s",
            agent_name,
            timeout_ms,
        )
        return get_review_agent_timeout() * 1000

    def _deploy_agent(
        self,
        item_id: str,
        agent_type: AgentType,
        changed_files: list[str] | None,
        timeout_ms: int | None = None,
        intent_context: str | None = None,
    ) -> dict[str, Any]:
        """Deploy a review agent using AgentDeployer.

        Args:
            item_id: Plan item ID being reviewed
            agent_type: Type of review agent
            timeout_ms: Timeout in milliseconds (None = use config default)

        Returns:
            Agent report dictionary
        """
        # Resolve timeout from config if not provided
        if timeout_ms is None:
            timeout_ms = get_review_agent_timeout() * 1000

        logger.debug(f"Deploying {agent_type.value} agent for {item_id}")

        # Use the deployer to run the agent
        result = self._deployer.run_agent(
            agent_type=agent_type,
            item_id=item_id,
            changed_files=changed_files,
            timeout_ms=timeout_ms,
            intent_context=intent_context,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        # Convert AgentResult to dict for API serialization
        report = cast(dict[str, Any], result.to_dict())
        report["item_id"] = item_id

        return report

    def _build_intent_context(self) -> str | None:
        return build_intent_context(working_dir=self._working_dir, config=self._config)

    def _apply_execution_scope(
        self,
        agent_reports: list[dict[str, Any]],
        changed_files: list[str] | None,
    ) -> None:
        apply_execution_scope(agent_reports=agent_reports, changed_files=changed_files)


__all__ = ["ReviewHandler"]
