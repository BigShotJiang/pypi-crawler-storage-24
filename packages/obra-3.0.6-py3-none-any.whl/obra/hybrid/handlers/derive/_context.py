"""DerivationContext: pipeline state carrier for DeriveHandler._execute_derivation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.hybrid.derivation.mission_complexity import PreFilterResult, SizingGuidance
    from obra.hybrid.handlers.derive._handler import LLMInvocationParams
    from obra.intent.intent_enricher import IntentEnricher
    from obra.intent.models import EnrichmentLevel, InputType, IntentModel


@dataclass
class DerivationContext:
    """Mutable pipeline state carrier for a single derivation run.

    Replaces the shared local variables and instance variables used across
    _execute_derivation's pipeline stages. Each field is written by one stage
    and read by subsequent stages.
    """

    # --- Input classification ---
    input_type: InputType | None = None
    """InputType enum; written at pipeline entry, read by intent generation and scaffolding."""

    work_type: str | None = None
    """Work type string; written by work type detection, read by exploration and metrics."""

    workflow_derivation_request: dict[str, Any] | None = None
    """Raw workflow-derivation request envelope carried from the server action."""

    normalized_inputs: dict[str, Any] | None = None
    """Normalized mission + artifact input contract produced during D1."""

    domain_derivation_metadata: dict[str, Any] = field(default_factory=dict)
    """Resolved domain framing metadata produced during D2."""

    # --- Sizing / pre-filter ---
    pre_filter_result: PreFilterResult | None = None
    """Written by pre-filter stage, read by sizing gate; replaces self._pre_filter_result."""

    sizing_guidance: SizingGuidance | None = None
    """Written by sizing stage, read by closeout injection, hierarchical derivation, and prompt
    enrichment; replaces self._sizing_guidance instance variable."""

    # --- Intent ---
    intent_content: str | None = None
    """Written by intent generation stage, read by prompt enrichment and intent alignment."""

    intent_enrichment: EnrichmentLevel | None = None
    """Written by _generate_and_save_intent, read by fallback path guard."""

    intent_model: IntentModel | None = None
    """Written by intent generation or _load_active_intent, read by sizing gate, scaffolded
    enrichment, and review."""

    # --- Scaffolding ---
    scaffolded_active: bool = False
    """Written by scaffolding decision, read by review stage and LLM config resolution."""

    scaffolded_run: bool = False
    """Written by scaffolded enrichment, read by fallback path guard."""

    planner: IntentEnricher | None = None
    """IntentEnricher instance, written by scaffolding stage, read by review and LLM config
    resolution."""

    # --- Exploration ---
    exploration_markdown: str | None = None
    """Written by exploration stage, read by prompt enrichment and hierarchical derivation."""

    # --- Prompt ---
    enriched_prompt: str | None = None
    """Written by prompt enrichment stage, read by LLM derivation."""

    # --- LLM derivation outputs ---
    plan_items: list[dict[str, Any]] = field(default_factory=list)
    """Written by LLM derivation, mutated by sanitization, alignment, closeout, and
    post-processing."""

    raw_response: str = ""
    """Written by LLM derivation."""

    parse_info: dict[str, Any] = field(default_factory=dict)
    """Written by LLM derivation."""

    derivation_result: Any | None = None
    """Written by hierarchical derivation, read by metrics emission."""

    derived_workflow_artifact: dict[str, Any] | None = None
    """Candidate W2 artifact emitted by workflow derivation."""

    baseline_evaluation: dict[str, Any] | None = None
    """Baseline workflow evaluation summary emitted during W-to-W2 synthesis."""

    validation_report: dict[str, Any] | None = None
    """Workflow validation outcome for the candidate W2."""

    operator_review_points: list[dict[str, Any]] = field(default_factory=list)
    """Pending operator-review checkpoints for the candidate W2."""

    result_bundle: dict[str, Any] | None = None
    """Full workflow-derivation bundle payload reported beside plan_items."""

    last_derivation_llm: LLMInvocationParams | None = None
    """LLMInvocationParams written by LLM config resolution; replaces self._last_derivation_llm.
    Also kept on DeriveHandler for backward compatibility."""

    # --- Post-processing ---
    repair_history: list[dict[str, Any]] = field(default_factory=list)
    """Written by auto-repair, included in result."""

    # --- Timing ---
    stage_timings: dict[str, float] = field(default_factory=dict)
    """Accumulated by scaffolding, sizing, and derive stages."""
