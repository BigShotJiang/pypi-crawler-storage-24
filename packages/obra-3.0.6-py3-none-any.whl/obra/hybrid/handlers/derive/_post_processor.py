"""PlanPostProcessor: plan post-processing stages for derivation pipeline.

Extracts four pipeline stages from DeriveHandler:
- repair(): auto-repair blocking integrity violations via TemplateEditPipeline
- assign_source_steps(): assign source_step_id to plan items (rule-based or LLM)
- _map_via_llm(): LLM-based multi-story step mapping (private helper)
- apply_parallelization(): annotate items with parallel_group / parallelizable
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.loaders import (
    get_derive_llm_timeout,
    get_plan_integrity_auto_repair_max_attempts,
    get_plan_integrity_auto_repair_timeout_s,
)
from obra.hybrid.derivation.parallelization import ParallelizationAnalyzer
from obra.hybrid.json_utils import extract_json_payload
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.observability.production_logger import ProductionLogger
from obra.orchestration.plan_integrity import ViolationSeverity, validate_plan_integrity
from obra.prompts.derive.exploration import build_task_classification_prompt
from obra.prompts.derive.plan_repair import build_plan_repair_prompt

logger = logging.getLogger(__name__)


class PlanPostProcessor:
    """Post-processing pipeline stages applied after plan derivation.

    Owns four concerns:
    - repair(): bounded auto-repair of blocking integrity violations.
    - assign_source_steps(): assign source_step_id (rule-based or LLM).
    - apply_parallelization(): annotate items with parallel_group / parallelizable.
    - _map_via_llm(): LLM-based classification helper (private).

    All methods are pure transformations on plan item lists.
    No I/O beyond logging and optional progress callbacks.
    """

    def __init__(
        self,
        config: dict[str, Any],
        llm_config: dict[str, Any],
        working_dir: Path,
        log_event: Callable[..., None] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        production_logger: ProductionLogger | None = None,
    ) -> None:
        """Initialise PlanPostProcessor.

        Args:
            config: Loaded layered config dict (read once by DeriveHandler.__init__).
            llm_config: LLM configuration dict (provider, model, auth, etc.).
            working_dir: Project working directory for LLM invocations.
            log_event: Optional event logger.
            on_progress: Optional progress callback for repair_failed events.
            trace_id: Optional trace ID for observability.
            parent_span_id: Optional parent span ID for observability.
            production_logger: Optional production logger for parallelization metrics.
        """
        self._config = config
        self._llm_config = llm_config
        self._working_dir = working_dir
        self._log_event = log_event
        self._on_progress = on_progress
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._production_logger = production_logger

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def repair(
        self,
        plan_items: list[dict[str, Any]],
        violations: list[Any],
        *,
        last_derivation_llm: Any | None = None,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Attempt bounded auto-repair for blocking integrity violations.

        Args:
            plan_items: Current plan items.
            violations: List of PlanViolation objects (BLOCKING severity).
            last_derivation_llm: Optional LLMInvocationParams from the last derivation
                call. When provided, its provider/model/reasoning_level are used for
                the repair LLM; otherwise falls back to self._llm_config.

        Returns:
            Tuple of (repaired_plan_items, repair_attempt_history).
        """
        if not violations:
            return plan_items, []

        def _violation_labels(items: list[Any]) -> list[str]:
            labels: list[str] = []
            for violation in items:
                code = str(getattr(getattr(violation, "code", ""), "value", "")).strip()
                if not code:
                    code = "UNKNOWN"
                labels.append(code)
            return labels

        max_attempts = max(1, get_plan_integrity_auto_repair_max_attempts())
        timeout_s = max(1, get_plan_integrity_auto_repair_timeout_s())
        repair_attempt_history: list[dict[str, Any]] = []

        resolved_llm = self._resolve_derive_llm_config()
        llm_config: dict[str, Any] = {
            "provider": (
                last_derivation_llm.provider
                if last_derivation_llm is not None
                else resolved_llm.get("provider", "anthropic")
            ),
            "model": (
                last_derivation_llm.model
                if last_derivation_llm is not None
                else resolved_llm.get("model", "sonnet")
            ),
            "reasoning_level": (
                last_derivation_llm.reasoning_level
                if last_derivation_llm is not None
                else resolved_llm.get("reasoning_level", "low")
            ),
            "auth": (
                last_derivation_llm.auth_method
                if last_derivation_llm is not None
                else resolved_llm.get("auth_method", "oauth")
            ),
        }

        # Preserve optional runtime toggles used by TemplateEditPipeline.execute().
        for passthrough_key in (
            "allowed_tools",
            "approval_mode",
            "bypass_sandbox",
            "skip_git_check",
            "codex",
            "git",
        ):
            if passthrough_key in self._llm_config:
                llm_config[passthrough_key] = self._llm_config[passthrough_key]

        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="plan_integrity_repair",
            on_stream=None,
            log_event=self._log_event,
            production_logger=self._production_logger,
        )

        current_plan_items = list(plan_items)
        current_blocking = list(violations)

        for attempt in range(1, max_attempts + 1):
            repair_prompt = build_plan_repair_prompt(
                current_plan_items,
                current_blocking,
            )
            template_schema = {
                "plan_items": current_plan_items,
                "_instructions": (
                    "Return repaired plan_items as a JSON array in the plan_items field."
                ),
            }

            def _validator(data: dict[str, Any]) -> tuple[bool, str | None]:
                if not isinstance(data, dict):
                    return False, "Result must be a JSON object."
                repaired_items = data.get("plan_items")
                if not isinstance(repaired_items, list):
                    return False, "Missing or invalid plan_items array."
                if not all(isinstance(item, dict) for item in repaired_items):
                    return False, "plan_items must contain only objects."
                return True, None

            def _fallback(_items: list[dict[str, Any]] = current_plan_items) -> dict[str, Any]:
                return {"plan_items": _items}

            try:
                result, _metadata = pipeline.execute(
                    base_prompt=repair_prompt,
                    template_content=template_schema,
                    validator=_validator,
                    fallback_fn=_fallback,
                    llm_config=llm_config,
                    timeout_s=timeout_s,
                    allow_unchanged=False,
                )
            except Exception as exc:
                logger.warning(
                    "Plan integrity auto-repair attempt %d failed: %s",
                    attempt,
                    exc,
                )
                remaining_labels = _violation_labels(current_blocking)
                repair_attempt_history.append(
                    {
                        "attempt": attempt,
                        "outcome": "error",
                        "remaining_violations": remaining_labels,
                    }
                )
                continue

            candidate_plan = current_plan_items
            if isinstance(result, dict) and isinstance(result.get("plan_items"), list):
                candidate_plan = [item for item in result["plan_items"] if isinstance(item, dict)]

            all_violations = validate_plan_integrity(candidate_plan)
            remaining_blocking = [
                violation
                for violation in all_violations
                if violation.severity == ViolationSeverity.BLOCKING
            ]
            remaining_labels = _violation_labels(remaining_blocking)
            if not remaining_blocking:
                repair_attempt_history.append(
                    {
                        "attempt": attempt,
                        "outcome": "repaired",
                        "remaining_violations": [],
                    }
                )
                logger.info("Plan auto-repaired after %d attempt(s)", attempt)
                return candidate_plan, repair_attempt_history

            repair_attempt_history.append(
                {
                    "attempt": attempt,
                    "outcome": "still_violated",
                    "remaining_violations": remaining_labels,
                }
            )
            current_plan_items = candidate_plan
            current_blocking = remaining_blocking

        remaining_labels = _violation_labels(current_blocking)
        logger.warning(
            "Plan integrity auto-repair exhausted after %d attempts: %s",
            max_attempts,
            remaining_labels,
        )
        if self._on_progress:
            try:
                self._on_progress(
                    "plan_integrity_repair_failed",
                    {
                        "attempts": max_attempts,
                        "remaining_violations": remaining_labels,
                    },
                )
            except Exception as exc:
                logger.debug("Progress callback failed: %s", exc)
        return current_plan_items, repair_attempt_history

    def assign_source_steps(
        self,
        items: list[dict[str, Any]],
        userplan_steps: list[dict[str, Any]] | None,
        default_step_id: str | None,
    ) -> list[dict[str, Any]]:
        """Assign source_step_id to all items via system logic.

        Single-story: Rule-based (instant, deterministic).
        Multi-story: LLM-based classification (1-3s, accurate).

        Args:
            items: Sanitized plan items (may have source_step_id from LLM or defaults).
            userplan_steps: List of UserPlan steps with id, index, title, description.
            default_step_id: Default step ID to use as fallback.

        Returns:
            Items with source_step_id assigned.
        """
        if not userplan_steps or len(userplan_steps) == 1:
            # Single-story: All tasks belong to single step (rule-based, instant)
            existing_step_ids = [
                step_id
                for item in items
                if isinstance((step_id := item.get("source_step_id")), str) and step_id
            ]
            step_id = (
                default_step_id
                or (userplan_steps[0]["id"] if userplan_steps else None)
                or (existing_step_ids[0] if existing_step_ids else None)
            )
            if not step_id:
                msg = "No UserPlan step available for source_step_id assignment"
                raise ValueError(msg)

            assigned_count = 0
            for item in items:
                if not item.get("source_step_id"):
                    item["source_step_id"] = step_id
                    assigned_count += 1

            logger.info(
                "Resolved source_step_id for %d/%d items using single-step fallback %s",
                assigned_count,
                len(items),
                step_id,
            )
            return items

        # Multi-story: Use LLM to classify tasks to steps
        fallback_step_id = default_step_id or userplan_steps[0]["id"]
        return self._map_via_llm(
            items=items,
            userplan_steps=userplan_steps,
            default_step_id=fallback_step_id,
        )

    def apply_parallelization(
        self,
        plan_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Apply parallelization analysis to plan items.

        Analyzes dependencies between plan items and assigns parallel groups.
        Items in the same group have no interdependencies and can execute
        concurrently.

        Args:
            plan_items: List of plan item dictionaries.

        Returns:
            Plan items with parallelizable and parallel_group fields added.
        """
        if not plan_items:
            return plan_items

        try:
            analyzer = ParallelizationAnalyzer()
            result = analyzer.analyze(plan_items)

            # Update each item with parallelization info
            for item in plan_items:
                item_id = item.get("id", "")
                if item_id in result.item_groups:
                    group_id = result.item_groups[item_id]
                    item["parallel_group"] = group_id

                    # Item is parallelizable if its group has multiple items
                    group_size = len(result.parallel_groups.get(group_id, []))
                    item["parallelizable"] = group_size > 1
                else:
                    # Item wasn't in analysis (e.g., no id) - mark as non-parallelizable
                    item["parallelizable"] = False
                    item["parallel_group"] = None

            # Log parallelization summary (telemetry only — user-facing message
            # suppressed while execution.parallel.enabled is false to avoid
            # advertising a capability that isn't active yet)
            if result.parallelizable_count > 0:
                logger.info(
                    "Parallelization analysis: %d items parallelizable across %d groups, "
                    "estimated %.1f%% speedup",
                    result.parallelizable_count,
                    result.group_count,
                    result.estimated_speedup_pct,
                )

            # Log event for observability
            if self._log_event:
                try:
                    self._log_event(
                        "parallelization_analyzed",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        item_count=len(plan_items),
                        group_count=result.group_count,
                        parallelizable_count=result.parallelizable_count,
                        estimated_speedup_pct=result.estimated_speedup_pct,
                    )
                except Exception as e:
                    logger.debug("Failed to log parallelization event: %s", e)

            # Log parallelization analysis to production logger (FEAT-USERPLAN-002 S3)
            if self._production_logger and result.parallelizable_count > 0:
                self._production_logger.log_parallelization_analyzed(
                    work_unit_id="derivation",
                    parallelizable_count=result.parallelizable_count,
                    group_count=result.group_count,
                    estimated_speedup_pct=result.estimated_speedup_pct,
                )

        except Exception as e:
            # Parallelization analysis failure should not block derivation
            logger.warning("Parallelization analysis failed (non-blocking): %s", e)
            # Mark all items as non-parallelizable as fallback
            for item in plan_items:
                item["parallelizable"] = False
                item["parallel_group"] = None

        return plan_items

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _map_via_llm(
        self,
        items: list[dict[str, Any]],
        userplan_steps: list[dict[str, Any]],
        default_step_id: str,
    ) -> list[dict[str, Any]]:
        """Use LLM to classify tasks to UserPlan steps.

        Args:
            items: Plan items to classify.
            userplan_steps: UserPlan steps to map to.
            default_step_id: Fallback if classification fails.

        Returns:
            Items with source_step_id assigned via classification.
        """
        # Build classification prompt via prompt library
        prompt = build_task_classification_prompt(userplan_steps, items)

        # Configuration-driven
        mapping_config = self._config.get("orchestration.derivation.source_step_mapping", {})
        if not mapping_config.get("enabled", True):
            # Mapping disabled, use defaults
            logger.info(
                "Multi-story mapping disabled by config, using default step %s",
                default_step_id,
            )
            for item in items:
                item["source_step_id"] = default_step_id
            return items

        timeout_s = mapping_config.get("timeout_s", get_derive_llm_timeout())

        try:
            # Use fast model (simple classification)
            response = invoke_llm_via_cli(
                prompt=prompt,
                provider=self._llm_config["provider"],
                model=self._llm_config["fast_model"],
                reasoning_level="low",
                timeout_s=timeout_s,
                auth_method=self._llm_config["auth_method"],
                cwd=self._working_dir,
            )

            # Parse and apply
            json_str = extract_json_payload(response)
            if json_str is None:
                json_str = "{}"
            mapping_data = json.loads(json_str)
            mappings = mapping_data.get("mappings", [])
            mapping_dict = {m["task_id"]: m["step_id"] for m in mappings}

            applied_count = 0
            for item in items:
                if item["id"] in mapping_dict:
                    item["source_step_id"] = mapping_dict[item["id"]]
                    applied_count += 1

            logger.info(
                "Mapped %d/%d items to %d UserPlan steps (LLM classification)",
                applied_count,
                len(items),
                len(userplan_steps),
            )

        except Exception as e:
            logger.warning(
                "Multi-story mapping failed: %s. Using default step %s",
                e,
                default_step_id,
            )
            # Fallback: assign all to default
            for item in items:
                if item.get("source_step_id") is None:
                    item["source_step_id"] = default_step_id

        return items

    def _resolve_derive_llm_config(self) -> dict[str, Any]:
        """Resolve base LLM config for derive using role crosswalk with overrides."""
        resolved: dict[str, Any] = {}
        try:
            from obra.config.llm import resolve_role_llm_config

            resolved = resolve_role_llm_config("derive")
        except Exception as exc:
            logger.debug("Failed to resolve derive role config; using local overrides: %s", exc)
            resolved = {}

        merged = resolved.copy()
        for key, value in (self._llm_config or {}).items():
            if value is not None:
                merged[key] = value
        return merged
