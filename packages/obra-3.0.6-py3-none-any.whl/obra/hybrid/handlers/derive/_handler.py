"""Derive handler for Hybrid Orchestrator.

This module handles the DERIVE action from the server. It takes an objective
and derives an implementation plan using the local LLM invocation.

The derivation process:
    1. Receive DeriveRequest with objective and context
    2. Gather local project context (files, structure, etc.)
    3. Invoke LLM to generate plan
    4. Parse structured output into plan items
    5. Return DerivedPlan to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
    - obra/execution/derivation.py (DerivationEngine for LLM inference)
"""

# pylint: disable=too-many-instance-attributes,too-many-arguments,too-many-positional-arguments
# pylint: disable=too-many-locals,too-many-branches,too-many-return-statements,too-many-statements
# pylint: disable=duplicate-code,broad-exception-caught,too-few-public-methods

import contextlib
import logging
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
from typing import Any

from obra.api.protocol import DeriveRequest
from obra.config import get_heartbeat_initial_delay, get_heartbeat_interval
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display import VerbosityLevel, print_info
from obra.display.observability import ObservabilityConfig
from obra.exceptions import DerivationStallError
from obra.execution.derivation import (
    MAX_DERIVATION_DEPTH,
)
from obra.execution.derivation_metrics import (
    emit_derivation_duration_metric,
    emit_derivation_metrics,
    emit_derivation_overhead_metric,
    emit_leaf_compliance_metric,
)
from obra.exploration.cache import ExplorationCache
from obra.exploration.decision import should_auto_explore
from obra.exploration.models import (
    ExplorationDecision,
)
from obra.hybrid.derivation.mission_complexity import (
    PlanningMode,
    SizingGuidance,
)
from obra.hybrid.handlers.derive._closeout import CloseoutInjector
from obra.hybrid.handlers.derive._context import DerivationContext
from obra.hybrid.handlers.derive._intent_alignment import IntentAlignmentReviewer
from obra.hybrid.handlers.derive._intent_runtime import IntentRuntime
from obra.hybrid.handlers.derive._llm_resolution import DeriveLLMResolver
from obra.hybrid.handlers.derive._post_processor import PlanPostProcessor
from obra.hybrid.handlers.derive._quality_gate import QualityGateRunner
from obra.hybrid.handlers.derive._sanitizer import PlanSanitizer
from obra.hybrid.handlers.derive._workflow_runtime import WorkflowDerivationRuntime
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.intent.intent_enricher import IntentEnricher
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.detection import detect_input_type
from obra.intent.models import EnrichmentLevel, InputType, IntentMode, IntentModel
from obra.observability.production_logger import ProductionLogger
from obra.orchestration.plan_integrity import (
    ViolationSeverity,
    validate_plan_integrity,
)

logger = logging.getLogger(__name__)


@dataclass
class LLMInvocationParams:
    """Parameters for LLM invocation.

    Groups LLM-specific parameters to reduce argument count in _invoke_llm.
    """

    provider: str
    model: str
    reasoning_level: str
    auth_method: str = "oauth"
    timeout_s: int | None = None


class StageHeartbeatThread(threading.Thread):
    """Background thread that emits stage heartbeat events."""

    def __init__(
        self,
        stage: str,
        interval: int,
        initial_delay: int,
        emit_progress: Callable[[str, dict[str, Any]], None],
        log_event: Callable[..., None] | None = None,
        session_id: str | None = None,
        trace_id: str | None = None,
        telemetry_interval: int | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._stage = stage
        self._interval = max(1, int(interval))
        self._initial_delay = max(0, int(initial_delay))
        self._emit_progress = emit_progress
        self._log_event = log_event
        self._session_id = session_id
        self._trace_id = trace_id
        self._stop_event = threading.Event()
        self._start_time = time.time()
        self._alive_count = 0
        # When display interval (e.g. 1s for TTY) differs from the configured
        # telemetry interval (e.g. 60s), gate log writes at the telemetry rate
        # to avoid flooding hybrid.jsonl with high-frequency heartbeats.
        self._telemetry_interval = max(1, int(telemetry_interval)) if telemetry_interval else None

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        self._stop_event.wait(self._initial_delay)
        last_liveness_check = time.time()
        last_telemetry_emit = 0.0

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            current_time = time.time()
            # When telemetry_interval is set, only include the emit_telemetry
            # flag at the telemetry rate to prevent flooding hybrid.jsonl.
            emit_telemetry = True
            if self._telemetry_interval and (current_time - last_telemetry_emit) < self._telemetry_interval:
                emit_telemetry = False
            self._emit_progress(
                "stage_heartbeat",
                {"stage": self._stage, "elapsed_s": elapsed, "_emit_telemetry": emit_telemetry},
            )
            if emit_telemetry:
                last_telemetry_emit = current_time
            if (
                self._log_event
                and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S
            ):
                self._alive_count += 1
                self._log_event(
                    "stage_liveness_check",
                    stage=self._stage,
                    status="active",
                    alive_count=self._alive_count,
                    elapsed_seconds=elapsed,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                )
                last_liveness_check = current_time

            self._stop_event.wait(self._interval)


class DeriveHandler:
    """Handler for DERIVE action.

    Derives an implementation plan from the objective using LLM.
    The plan is structured as a list of plan items (epics/stories/tasks).

    ## Architecture Context (ADR-035)

    This handler implements the two-tier prompting architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with CLIENT_CONTEXT_MARKER
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends DeriveRequest with base_prompt containing strategic instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes LLM with enriched prompt locally
    4. Client reports plan items and raw response back to server

    ## IP Protection

    Strategic prompt engineering (system patterns, quality standards) stays on server.
    This protects Obra's proprietary prompt engineering IP from client-side inspection.

    ## Privacy Protection

    Tactical context (file contents, git messages, errors) never sent to server.
    Only LLM response summary (plan items) is transmitted.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md

    Example:
        >>> handler = DeriveHandler(Path("/path/to/project"))
        >>> request = DeriveRequest(objective="Add user authentication", userplan_id="UP-xxx-auth")
        >>> result = handler.handle(request)
        >>> print(result["plan_items"])
    """

    def __init__(
        self,
        working_dir: Path,
        on_stream: Callable[[str, str], None] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        domain: Any = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
        observability_config: ObservabilityConfig | None = None,
        bypass_modes: list[str] | None = None,
        api_client: Any | None = None,
        work_type_override: str | None = None,
        production_logger: ProductionLogger | None = None,
        planning_mode: str | None = None,
    ) -> None:
        """Initialize DeriveHandler.

        Args:
            working_dir: Working directory for file access
            on_stream: Optional callback for LLM streaming chunks (S3.T6)
            on_progress: Optional callback for progress events
            llm_config: Optional LLM configuration (S4.T2)
            domain: Optional domain module for prompt/filter specialization
            log_event: Optional logger for hybrid events (ISSUE-OBS-002)
            monitoring_context: Optional monitoring context for liveness checks
                (ISSUE-CLI-016/017 fix)
            observability_config: Optional observability configuration for progress visibility
            bypass_modes: List of bypass mode strings (e.g., "skip_quality_check")
            api_client: Optional APIClient for UserPlan operations (quality gate)
            work_type_override: Manual work type override (bypasses auto-detection)
            production_logger: Optional production logger for structured event logging
            planning_mode: Planning mode override ('auto', 'quick', 'standard', 'thorough')
        """
        self._initialize_core_state(
            working_dir=working_dir,
            on_stream=on_stream,
            on_progress=on_progress,
            llm_config=llm_config,
            domain=domain,
            log_event=log_event,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            monitoring_context=monitoring_context,
            observability_config=observability_config,
            bypass_modes=bypass_modes,
            api_client=api_client,
            work_type_override=work_type_override,
            production_logger=production_logger,
        )
        self._exploration_cache = self._build_exploration_cache()
        self._planning_mode = self._resolve_planning_mode(planning_mode)
        self._config = self._load_handler_config()
        self._initialize_runtime_components()

    def _initialize_core_state(
        self,
        *,
        working_dir: Path,
        on_stream: Callable[[str, str], None] | None,
        on_progress: Callable[[str, dict[str, Any]], None] | None,
        llm_config: dict[str, Any] | None,
        domain: Any,
        log_event: Callable[..., None] | None,
        trace_id: str | None,
        parent_span_id: str | None,
        monitoring_context: dict[str, Any] | None,
        observability_config: ObservabilityConfig | None,
        bypass_modes: list[str] | None,
        api_client: Any | None,
        work_type_override: str | None,
        production_logger: ProductionLogger | None,
    ) -> None:
        self._working_dir = working_dir
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._llm_config = llm_config or {}
        self._domain = domain
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context
        self._observability_config = observability_config
        self._bypass_modes = bypass_modes or []
        self._api_client = api_client
        self._work_type_override = work_type_override
        self._production_logger = production_logger
        self._skip_intent = "skip_intent" in self._bypass_modes
        self._review_intent = "review_intent" in self._bypass_modes
        self._force_scaffolded = "scaffolded" in self._bypass_modes
        self._skip_scaffolded = "no_scaffolded" in self._bypass_modes
        self._skip_quality_check = "skip_quality_check" in self._bypass_modes
        self._last_derivation_llm: LLMInvocationParams | None = None
        self._config: dict[str, Any] = {}

    def _build_exploration_cache(self) -> ExplorationCache:
        return ExplorationCache(
            self._working_dir,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

    def _resolve_planning_mode(self, planning_mode: str | None) -> PlanningMode:
        effective_planning_mode = planning_mode
        if effective_planning_mode is None:
            try:
                from obra.config.loaders import load_layered_config

                config, _, _ = load_layered_config(include_defaults=True)
                planning_config = config.get("orchestration", {}).get("planning", {})
                config_mode = planning_config.get("mode", "auto")
                if config_mode and config_mode.lower() != "auto":
                    effective_planning_mode = config_mode
                    logger.debug("Planning mode from config: %s", config_mode)
            except Exception as exc:
                logger.debug("Failed to read planning config: %s", exc)
        return self._parse_planning_mode(effective_planning_mode)

    def _load_handler_config(self) -> dict[str, Any]:
        try:
            from obra.config.loaders import load_layered_config

            config, _, warnings = load_layered_config(include_defaults=True)
            for warning in warnings:
                logger.warning("Config warning: %s", warning)
            return config
        except Exception as exc:
            logger.warning("Failed to load config layers: %s", exc)
            return {}

    def _initialize_runtime_components(self) -> None:
        from obra.hybrid.derivation.pre_filter import PreFilter
        from obra.hybrid.derivation.sizing_gate import SizingGate

        self._pre_filter = PreFilter(self._config)
        self._sizing_gate = SizingGate(self._config, domain=self._domain)
        self._sanitizer = PlanSanitizer(config=self._config)
        self._quality_gate = QualityGateRunner(
            config=self._config,
            api_client=self._api_client,
            bypass_modes=self._bypass_modes,
            on_progress=self._emit_progress,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            observability_config=self._observability_config,
            monitoring_context=self._monitoring_context,
            llm_config=self._llm_config,
            working_dir=self._working_dir,
            production_logger=self._production_logger,
        )
        self._intent_alignment = IntentAlignmentReviewer(
            working_dir=self._working_dir,
            config=self._config,
            llm_config=self._llm_config,
            on_stream=self._on_stream,
            on_progress=self._emit_progress,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            bypass_modes=self._bypass_modes,
            monitoring_context=self._monitoring_context,
        )
        self._closeout = CloseoutInjector(
            config=self._config,
            working_dir=self._working_dir,
            log_event=self._log_event,
            bypass_modes=self._bypass_modes,
            work_type_override=self._work_type_override,
            sanitizer=self._sanitizer,
            domain=self._domain,
        )
        self._post_processor = PlanPostProcessor(
            config=self._config,
            llm_config=self._llm_config,
            working_dir=self._working_dir,
            log_event=self._log_event,
            on_progress=self._emit_progress,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            production_logger=self._production_logger,
        )
        self._intent_runtime = IntentRuntime(self)
        self._workflow_runtime = WorkflowDerivationRuntime(self)
        self._llm_resolver = DeriveLLMResolver(self)

    def _build_stream_adapter(self, event_type: str) -> Callable[[str], None] | None:
        """Adapt two-argument handler streaming callbacks to one-argument hooks."""
        if not self._on_stream:
            return None
        return lambda chunk: self._on_stream(event_type, chunk)

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        # Strip internal control flags before forwarding to callbacks.
        emit_telemetry = payload.pop("_emit_telemetry", True)
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as exc:
                logger.debug("Progress callback failed: %s", exc)
        if self._log_event and emit_telemetry:
            try:
                self._log_event(f"progress_{action}", **payload)
                if action in {"epic_derivation_recovery", "epic_derivation_completed"}:
                    self._log_event(
                        "derivation_recovery_telemetry",
                        event=action,
                        epic_id=payload.get("epic_id"),
                        attempt_stage=payload.get("attempt_stage"),
                        is_retry=payload.get("is_retry", False),
                        reason_codes=payload.get("reason_codes"),
                        outcome=payload.get("outcome"),
                    )
            except Exception as exc:
                logger.debug("Progress log event failed: %s", exc)

    def _start_stage_heartbeat(self, stage: str) -> StageHeartbeatThread | None:
        if not self._on_progress and not self._log_event:
            return None
        interval = get_heartbeat_interval()
        initial_delay = get_heartbeat_initial_delay()
        stdout_is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
        stdin_is_tty = hasattr(sys.stdin, "isatty") and sys.stdin.isatty()
        inline_heartbeat = bool(
            self._observability_config
            and self._observability_config.verbosity >= VerbosityLevel.PROGRESS
            and (stdout_is_tty or stdin_is_tty)
        )
        telemetry_interval = None
        if inline_heartbeat:
            # Keep configured interval as the telemetry emission rate so
            # hybrid.jsonl isn't flooded with 1/s heartbeats during TTY sessions.
            telemetry_interval = get_heartbeat_interval()
            interval = 1
            initial_delay = min(1, initial_delay)
        thread = StageHeartbeatThread(
            stage=stage,
            interval=interval,
            initial_delay=initial_delay,
            emit_progress=self._emit_progress,
            log_event=self._log_event,
            session_id=(
                self._monitoring_context.get("session_id")
                if isinstance(self._monitoring_context, dict)
                else None
            ),
            trace_id=self._trace_id,
            telemetry_interval=telemetry_interval,
        )
        thread.start()
        return thread

    def _run_async(self, coroutine: Any) -> Any:
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            new_loop = asyncio.new_event_loop()
            try:
                return new_loop.run_until_complete(coroutine)
            finally:
                new_loop.close()

        return loop.run_until_complete(coroutine)

    def _build_sizing_pipeline(self, action_name: str) -> TemplateEditPipeline:
        # max_retries defaults from handlers.template_edit.max_retries config
        return TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name=action_name,
            write_scope="safe_output_only",
            on_stream=None,
            log_event=self._log_event,
            production_logger=self._production_logger,
        )

    def _emit_stage_started(self, stage: str, context: dict[str, Any] | None = None) -> None:
        payload = {"stage": stage, "context": context or {}}
        self._emit_progress("stage_started", payload)

    def _emit_planning_started(self, objective: str) -> None:
        self._emit_progress("planning_started", {"objective": objective})

    def _emit_planning_stage_started(self, stage: str, user_label: str) -> None:
        self._emit_progress(
            "planning_stage_started",
            {"stage": stage, "user_label": user_label},
        )

    def _emit_planning_stage_completed(
        self,
        stage: str,
        user_label: str,
        duration_s: float,
        summary: str | None = None,
    ) -> None:
        payload = {
            "stage": stage,
            "user_label": user_label,
            "duration_s": duration_s,
        }
        if summary:
            payload["summary"] = summary
        self._emit_progress("planning_stage_completed", payload)

    def _emit_detail_info(self, message: str) -> None:
        if (
            self._observability_config
            and self._observability_config.verbosity >= VerbosityLevel.DETAIL
        ):
            print_info(message)

    def _is_skip_tracking_enabled(self, source_key: str) -> bool:
        skip_config = self._config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get(source_key, True)
        )

    def _run_clarification_loop(self, userplan: Any) -> None:
        """Delegation shim — delegates to QualityGateRunner._clarify().

        Kept so tests can call or monkeypatch DeriveHandler._run_clarification_loop.
        The _config is injected into the quality gate so skip-tracking config
        set after construction is respected.
        """
        self._quality_gate._config = self._config
        self._quality_gate._clarify(userplan)

    def _get_skip_session_id(self) -> str:
        if isinstance(self._monitoring_context, dict):
            session_id = self._monitoring_context.get("session_id")
            if session_id:
                return str(session_id)
        return ""

    def _emit_stage_completed(
        self,
        stage: str,
        duration_ms: int,
        result: dict[str, Any] | None = None,
    ) -> None:
        payload = {"stage": stage, "duration_ms": duration_ms, "result": result or {}}
        self._emit_progress("stage_completed", payload)

    def _emit_stage_failed(
        self,
        stage: str,
        error: str,
        duration_ms: int,
        timeout_s: int | None = None,
    ) -> None:
        payload = {
            "stage": stage,
            "error": error,
            "duration_ms": duration_ms,
            "timeout_s": timeout_s,
        }
        self._emit_progress("stage_failed", payload)

    def _emit_stage_summary(self, stage_timings: dict[str, float]) -> None:
        if not stage_timings:
            return
        summary_parts = [f"{stage} {duration:.1f}s" for stage, duration in stage_timings.items()]
        print_info("Stage timings: " + " | ".join(summary_parts))
        self._emit_progress("stage_summary", {"stages": stage_timings})

    def _parse_planning_mode(self, mode_str: str | None) -> PlanningMode:
        """Parse planning mode string to enum.

        Args:
            mode_str: Mode string ('auto', 'light', 'thorough') or None
                      Legacy values 'quick' and 'standard' are mapped to 'light'

        Returns:
            PlanningMode enum value, defaults to AUTO if None or invalid
        """
        if mode_str is None:
            return PlanningMode.AUTO

        mode_lower = mode_str.lower().strip()
        mode_map = {
            "auto": PlanningMode.AUTO,
            "light": PlanningMode.LIGHT,
            "thorough": PlanningMode.THOROUGH,
            # Legacy mappings for backwards compatibility
            "quick": PlanningMode.LIGHT,
            "standard": PlanningMode.LIGHT,
        }

        if mode_lower in mode_map:
            return mode_map[mode_lower]

        logger.warning("Invalid planning_mode '%s', defaulting to AUTO", mode_str)
        return PlanningMode.AUTO

    def handle(self, request: DeriveRequest) -> dict[str, Any]:
        """Handle DERIVE action.

        Args:
            request: DeriveRequest from server with base_prompt

        Returns:
            Dict with plan_items and raw_response

        Raises:
            ValueError: If request.userplan_id is missing (required for derivation)
            ValueError: If request.base_prompt is None (server must provide base_prompt)
            QualityGateError: If UserPlan quality score is below threshold
        """
        # Validate userplan_id is present (required for derivation linkage)
        if not request.userplan_id:
            error_msg = "userplan_id is required for derivation"
            logger.error(error_msg)
            raise ValueError(error_msg)

        logger.info("Deriving plan for: %s...", request.objective[:50])
        logger.info("Using userplan_id: %s", request.userplan_id)
        self._emit_detail_info(f"Deriving plan for: {request.objective[:50]}...")

        # Log derivation started (FEAT-USERPLAN-002 S3)
        derivation_start_time = perf_counter()
        if self._production_logger:
            self._production_logger.log_derivation_started(
                work_unit_id=request.userplan_id,
                objective=request.objective,
            )

        try:
            return self._execute_derivation(request, derivation_start_time)
        except DerivationStallError as e:
            # Log stall error with recovery suggestion
            duration_ms = (perf_counter() - derivation_start_time) * 1000
            logger.exception(
                "Derivation stalled at step %d (%s) after %.0fs. %s",
                e.step,
                e.step_name,
                e.elapsed_seconds,
                e.recovery,
            )
            if self._production_logger:
                self._production_logger.log_derivation_failed(
                    work_unit_id=request.userplan_id,
                    error=str(e),
                    duration_ms=duration_ms,
                )
            raise
        except Exception as e:
            # Log derivation failed (FEAT-USERPLAN-002 S3)
            duration_ms = (perf_counter() - derivation_start_time) * 1000
            if self._production_logger:
                self._production_logger.log_derivation_failed(
                    work_unit_id=request.userplan_id,
                    error=str(e),
                    duration_ms=duration_ms,
                )
            raise

    def _execute_derivation(
        self, request: DeriveRequest, derivation_start_time: float
    ) -> dict[str, Any]:
        """Execute the derivation pipeline.

        Orchestrates three extracted stage modules in sequence:
        1. Intent stage  (_execute_intent) — intent generation, sizing, scaffolding
        2. Context stage  (_execute_context) — exploration, prompt enrichment, LLM config
        3. LLM stage      (_execute_llm)    — plan derivation via LLM

        Post-derivation processing (alignment, review, closeout, integrity,
        parallelization, metrics) remains inline.
        """
        from obra.hybrid.handlers.derive._execute_context import gather_derivation_context
        from obra.hybrid.handlers.derive._execute_intent import (
            check_intent_fallback_path,
            execute_intent_stage,
        )
        from obra.hybrid.handlers.derive._execute_llm import run_llm_derivation

        self._emit_planning_started(request.objective)
        # Quality Gate Check: Assess UserPlan quality before derivation
        self._quality_gate.run(request.userplan_id)

        ctx = DerivationContext()
        ctx.workflow_derivation_request = request.workflow_derivation_request

        # Detect and log input type
        ctx.input_type = detect_input_type(request.objective)
        logger.info("Detected input type: %s", ctx.input_type.value)

        sizing_enabled = bool(
            self._config.get("derivation", {}).get("sizing", {}).get("enabled", False)
        )

        if sizing_enabled:
            pre_filter_pipeline = self._build_sizing_pipeline("sizing_pre_filter")
            ctx.pre_filter_result = self._run_async(
                self._pre_filter.classify(request.objective, pre_filter_pipeline)
            )
            if self._log_event:
                self._log_event(
                    "sizing_pre_filter",
                    is_trivial=ctx.pre_filter_result.is_trivial,
                    reason=ctx.pre_filter_result.reason,
                    method=ctx.pre_filter_result.method,
                )

        # ---- Stage 1: Intent generation, sizing gate, scaffolding ----
        execute_intent_stage(self, ctx, request)

        # FIX-DERIVE-HANG-001: Early exit when intent enrichment failed completely.
        fallback_result = check_intent_fallback_path(
            self, ctx, request, derivation_start_time
        )
        if fallback_result is not None:
            return fallback_result

        # ---- Stage 2: Context gathering, exploration, prompt enrichment, LLM config ----
        gather_derivation_context(self, ctx, request)

        # ---- Stage 3: LLM derivation ----
        run_llm_derivation(self, ctx, request)

        # ---- Post-derivation: alignment, review, closeout, integrity ----
        return self._run_post_derivation(ctx, request, derivation_start_time)

    def _run_post_derivation(
        self,
        ctx: DerivationContext,
        request: DeriveRequest,
        derivation_start_time: float,
    ) -> dict[str, Any]:
        """Run post-derivation processing: alignment, review, closeout, integrity, metrics.

        Returns the final result dict for the derivation pipeline.
        """
        from obra.hybrid.handlers.derive._execute_context import discover_verification_tools
        from obra.hybrid.handlers.derive._scaffolded_review import (
            run_scaffolded_review,
        )
        from obra.hybrid.handlers.derive._story0_derivation import (
            maybe_derive_story0_prerequisites,
        )

        self._apply_intent_alignment(ctx)
        run_scaffolded_review(self, ctx, request)
        self._finalize_plan_items(ctx, request)
        derivation_duration = self._emit_post_derivation_metrics(
            ctx, request, derivation_start_time
        )
        story0_prerequisites = maybe_derive_story0_prerequisites(self, ctx, request)
        verification_tools = discover_verification_tools(self)
        self._sizing_guidance = ctx.sizing_guidance
        self._pre_filter_result = ctx.pre_filter_result
        return {
            "plan_items": ctx.plan_items,
            "raw_response": ctx.raw_response,
            "work_type": ctx.work_type,  # Include work_type for storage/analytics
            "verification_tools": verification_tools,  # S0.T7
            "story0_prerequisites": story0_prerequisites,
            "normalized_inputs": ctx.normalized_inputs,
            "derived_workflow_artifact": ctx.derived_workflow_artifact,
            "baseline_evaluation": ctx.baseline_evaluation,
            "validation_report": ctx.validation_report,
            "operator_review_points": ctx.operator_review_points,
            "result_bundle": ctx.result_bundle,
            "plan_repair_attempt_history": ctx.repair_history,
            # P2-1: Active compute duration for telemetry disambiguation.
            "active_duration_ms": int(derivation_duration * 1000),
        }

    def _apply_intent_alignment(self, ctx: DerivationContext) -> None:
        alignment_result = self._intent_alignment.review(
            ctx.plan_items,
            ctx.intent_content,
        )
        if alignment_result and alignment_result.changes_required:
            ctx.plan_items = self._intent_alignment.apply_fixes(
                ctx.plan_items,
                alignment_result,
            )

    def _finalize_plan_items(
        self,
        ctx: DerivationContext,
        request: DeriveRequest,
    ) -> None:
        ctx.plan_items = self._closeout.inject(
            ctx.plan_items,
            objective=request.objective,
            project_context=request.project_context,
            userplan_steps=request.userplan_steps,
            sizing_guidance=ctx.sizing_guidance,
        )
        self._repair_integrity_violations(ctx)
        ctx.plan_items = self._post_processor.apply_parallelization(ctx.plan_items)
        logger.info("Derived %s plan items", len(ctx.plan_items))
        self._emit_detail_info(f"Derived {len(ctx.plan_items)} plan items")
        default_step = request.userplan_steps[0]["id"] if request.userplan_steps else None
        ctx.plan_items = self._post_processor.assign_source_steps(
            items=ctx.plan_items,
            userplan_steps=request.userplan_steps,
            default_step_id=default_step,
        )

    def _repair_integrity_violations(self, ctx: DerivationContext) -> None:
        integrity_violations = validate_plan_integrity(ctx.plan_items)
        for violation in integrity_violations:
            if violation.severity != ViolationSeverity.BLOCKING:
                logger.warning(
                    "Plan integrity warning [%s]: %s",
                    violation.code.value,
                    violation.message,
                )
        blocking_violations = [
            violation
            for violation in integrity_violations
            if violation.severity == ViolationSeverity.BLOCKING
        ]
        if not blocking_violations:
            return
        ctx.plan_items, ctx.repair_history = self._post_processor.repair(
            ctx.plan_items,
            blocking_violations,
            last_derivation_llm=ctx.last_derivation_llm,
        )
        remaining_blocking = [
            violation
            for violation in validate_plan_integrity(ctx.plan_items)
            if violation.severity == ViolationSeverity.BLOCKING
        ]
        if remaining_blocking:
            logger.warning(
                "Blocking plan integrity violations remain after auto-repair: %s",
                [violation.code.value for violation in remaining_blocking],
            )

    def _emit_post_derivation_metrics(
        self,
        ctx: DerivationContext,
        request: DeriveRequest,
        derivation_start_time: float,
    ) -> float:
        source_type = ctx.input_type.value if ctx.input_type else "unknown"
        self._emit_derivation_metrics(
            plan_items=ctx.plan_items,
            work_type=ctx.work_type,
            source_type=source_type,
            hierarchy_enabled=self._sanitizer.is_hierarchical_enabled(),
            derivation_result=ctx.derivation_result,
        )
        derivation_duration = perf_counter() - derivation_start_time
        emit_derivation_duration_metric(
            duration_seconds=derivation_duration,
            source_type=ctx.work_type,
            plan_item_count=len(ctx.plan_items),
            success=True,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )
        if self._production_logger:
            self._production_logger.log_derivation_complete(
                work_unit_id=request.userplan_id,
                item_count=len(ctx.plan_items),
                duration_ms=derivation_duration * 1000,
                work_type=ctx.work_type,
            )
        self._emit_stage_summary(ctx.stage_timings)
        return derivation_duration

    def _normalize_workflow_derivation_inputs(
        self,
        request: DeriveRequest,
    ) -> dict[str, Any] | None:
        return self._workflow_runtime.normalize_workflow_derivation_inputs(request)

    def _resolve_workflow_domain_framing(
        self,
        normalized_inputs: dict[str, Any],
    ) -> dict[str, Any]:
        return self._workflow_runtime.resolve_workflow_domain_framing(normalized_inputs)

    def _derive_workflow_candidate(
        self,
        *,
        request: DeriveRequest,
        ctx: DerivationContext,
    ) -> tuple[
        list[dict[str, Any]],
        str,
        dict[str, Any],
        Any,
        dict[str, Any] | None,
        dict[str, Any] | None,
        dict[str, Any] | None,
        list[dict[str, Any]],
        dict[str, Any] | None,
    ]:
        return self._workflow_runtime.derive_workflow_candidate(request=request, ctx=ctx)

    # ------------------------------------------------------------------
    # Backward-compatible delegation shims.
    #
    # The implementations now live in the stage modules (_execute_intent,
    # _execute_context, _execute_llm). These thin shims preserve the
    # instance-method signatures that tests and external callers rely on.
    # ------------------------------------------------------------------

    def _detect_primary_manifest(self) -> tuple[str, Path | None]:
        from obra.hybrid.handlers.derive._execute_context import detect_primary_manifest
        return detect_primary_manifest(self)

    def _extract_manifest_dependencies(
        self, manifest_type: str, manifest_path: Path | None
    ) -> list[str]:
        from obra.hybrid.handlers.derive._execute_context import extract_manifest_dependencies
        return extract_manifest_dependencies(self, manifest_type, manifest_path)

    def _discover_verification_tools(self) -> dict[str, Any]:
        from obra.hybrid.handlers.derive._execute_context import discover_verification_tools
        return discover_verification_tools(self)

    def _generate_and_save_intent(
        self,
        objective: str,
        input_type: InputType,
        *,
        mode: IntentMode = IntentMode.FULL,
    ) -> tuple[str | None, EnrichmentLevel | None, IntentModel | None]:
        from obra.hybrid.handlers.derive._execute_intent import _generate_and_save_intent
        return _generate_and_save_intent(self, objective, input_type, mode=mode)

    def _load_active_intent(self) -> IntentModel | None:
        from obra.hybrid.handlers.derive._execute_intent import _load_active_intent
        return _load_active_intent(self)

    def _load_active_intent_content(self) -> str | None:
        from obra.hybrid.handlers.derive._execute_intent import _load_active_intent_content
        return _load_active_intent_content(self)

    def _emit_derivation_metrics(
        self,
        plan_items: list[dict[str, Any]],
        work_type: str,
        source_type: str,
        hierarchy_enabled: bool,
        derivation_result: Any | None = None,
    ) -> None:
        """Emit derivation metrics for observability.

        Emits metrics tracking:
        - Derivation depth distribution (histogram of max depths reached)
        - Warning when max depth approaches limit
        - Tree width (number of tasks at each depth level)

        Args:
            plan_items: List of derived plan item dictionaries
            work_type: Detected work type for source labeling
            source_type: Origin of the plan for source labeling
            hierarchy_enabled: Whether hierarchical derivation was enabled
            derivation_result: Optional derivation result for pass metrics
        """
        labels = {
            "work_type": work_type or "unknown",
            "source_type": source_type or "unknown",
            "hierarchy_enabled": str(hierarchy_enabled).lower(),
        }
        try:
            emit_derivation_metrics(
                plan_items=plan_items,
                source_type=work_type,
                max_depth_limit=MAX_DERIVATION_DEPTH,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        except Exception as e:
            # Log warning but don't fail derivation for metrics emission failure
            logger.warning("Failed to emit derivation metrics: %s", e)
            if self._log_event:
                with contextlib.suppress(Exception):
                    self._log_event(
                        "derivation_metrics_failed",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        error=str(e),
                    )

        if not derivation_result:
            return

        try:
            emit_derivation_overhead_metric(
                total_seconds=derivation_result.total_pass_duration_seconds,
                first_pass_seconds=derivation_result.first_pass_duration_seconds,
                labels=labels,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
            emit_leaf_compliance_metric(
                leaf_total=derivation_result.leaf_total,
                leaf_compliant=derivation_result.leaf_compliant,
                labels=labels,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        except Exception as e:
            logger.warning("Failed to emit derivation pass metrics: %s", e)
            if self._log_event:
                with contextlib.suppress(Exception):
                    self._log_event(
                        "derivation_metrics_failed",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        error=str(e),
                    )

    def _validate_intent_enrichment(self, intent: Any) -> None:
        self._intent_runtime.validate_intent_enrichment(intent)

    def _check_intent_quality(self, intent: Any, objective: str | None = None) -> None:
        self._intent_runtime.check_intent_quality(intent, objective)

    def _load_intent_quality_config(self) -> tuple[bool, float, list[str], list[str]]:
        return self._intent_runtime.load_intent_quality_config()

    def _assess_intent_quality(
        self,
        intent: Any,
        required_fields: list[str],
        non_empty_fields: list[str],
    ) -> tuple[float, list[str]]:
        return self._intent_runtime.assess_intent_quality(
            intent,
            required_fields,
            non_empty_fields,
        )

    def _format_intent_for_prompt(self, intent: Any) -> str:
        return self._intent_runtime.format_intent_for_prompt(intent)

    def _emit_intent_summary(self, intent: Any, enrichment_level: EnrichmentLevel | None) -> None:
        self._intent_runtime.emit_intent_summary(intent, enrichment_level)

    @staticmethod
    def _format_intent_summary_lines(
        intent: Any,
        *,
        max_items: int,
        enrichment_level: EnrichmentLevel | None,
    ) -> list[str]:
        return IntentRuntime.format_intent_summary_lines(
            intent,
            max_items=max_items,
            enrichment_level=enrichment_level,
        )

    @staticmethod
    def _extract_user_story_refs(text: str) -> list[str]:
        return IntentRuntime.extract_user_story_refs(text)

    def _prompt_intent_approval(self, intent: Any) -> bool:
        return self._intent_runtime.prompt_intent_approval(intent)

    def _emit_exploration_message(self, decision: ExplorationDecision) -> None:
        from obra.hybrid.handlers.derive._execute_context import emit_exploration_message
        emit_exploration_message(self, decision)

    def _log_exploration_decision(self, decision: ExplorationDecision) -> None:
        from obra.hybrid.handlers.derive._execute_context import log_exploration_decision
        log_exploration_decision(self, decision)

    def _get_file_count(self, max_count: int = 500) -> int:
        from obra.hybrid.handlers.derive._execute_context import get_file_count
        return get_file_count(self, max_count)

    def _invoke_llm(self, prompt: str, llm_params: LLMInvocationParams) -> str:
        from obra.hybrid.handlers.derive._execute_llm import invoke_llm
        return invoke_llm(self, prompt, llm_params)

    def _derive_single_shot(
        self,
        *,
        request: DeriveRequest,
        provider: str,
        model: str,
        reasoning_level: str | None,
        auth_method: str,
        timeout_s: int | None,
        strategic_prompt: str,
        sizing_guidance: SizingGuidance | None = None,
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any], Any]:
        from obra.hybrid.handlers.derive._execute_llm import derive_single_shot
        return derive_single_shot(
            self,
            request=request,
            provider=provider,
            model=model,
            reasoning_level=reasoning_level,
            auth_method=auth_method,
            timeout_s=timeout_s,
            strategic_prompt=strategic_prompt,
            sizing_guidance=sizing_guidance,
        )

    def _derive_hierarchical_plan(
        self,
        *,
        request: DeriveRequest,
        provider: str,
        model: str,
        reasoning_level: str,
        auth_method: str,
        timeout_s: int | None,
        strategic_prompt: str,
        intent_markdown: str | None,
        exploration_context: str | None,
        sizing_guidance: SizingGuidance | None = None,
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any], Any]:
        from obra.hybrid.handlers.derive._execute_llm import derive_hierarchical_plan
        return derive_hierarchical_plan(
            self,
            request=request,
            provider=provider,
            model=model,
            reasoning_level=reasoning_level,
            auth_method=auth_method,
            timeout_s=timeout_s,
            strategic_prompt=strategic_prompt,
            intent_markdown=intent_markdown,
            exploration_context=exploration_context,
            sizing_guidance=sizing_guidance,
        )

    def _fallback_with_extraction(
        self, raw_response: str, parse_info: dict[str, Any], objective: str | None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        from obra.hybrid.handlers.derive._execute_llm import fallback_with_extraction
        return fallback_with_extraction(self, raw_response, parse_info, objective)

    def _build_composite_fallback(self, objective: str | None) -> list[dict[str, Any]]:
        from obra.hybrid.handlers.derive._execute_llm import build_composite_fallback
        return build_composite_fallback(self, objective)

    def _coerce_list_to_epics(
        self, items: list[Any], *, objective: str | None, parse_info: dict[str, Any],
    ) -> tuple[list[Any], dict[str, Any]]:
        from obra.hybrid.handlers.derive._execute_llm import coerce_list_to_epics
        return coerce_list_to_epics(self, items, objective=objective, parse_info=parse_info)

    def _flatten_epic_tree(self, epics: list[dict[str, Any]]) -> list[dict[str, Any]]:
        from obra.hybrid.handlers.derive._execute_llm import flatten_epic_tree
        return flatten_epic_tree(self, epics)

    def _flatten_story_tree(
        self, stories: list[dict[str, Any]], parent_id: str | None = None, depth: int = 0,
    ) -> list[dict[str, Any]]:
        from obra.hybrid.handlers.derive._execute_llm import flatten_story_tree
        return flatten_story_tree(self, stories, parent_id=parent_id, depth=depth)

    def _resolve_scaffolded_stage_llm(
        self, stage_config: dict[str, Any], provider: str,
    ) -> tuple[str, str, str, str, int, int]:
        from obra.hybrid.handlers.derive._execute_llm import resolve_scaffolded_stage_llm
        return resolve_scaffolded_stage_llm(self, stage_config, provider)

    def _resolve_derive_llm_config(self) -> dict[str, Any]:
        from obra.hybrid.handlers.derive._execute_llm import resolve_derive_llm_config
        return resolve_derive_llm_config(self)

    def _log_parse_event(
        self, *, action: str, provider: str, model: str, parse_info: dict[str, Any],
    ) -> None:
        from obra.hybrid.handlers.derive._execute_llm import log_parse_event
        log_parse_event(self, action=action, provider=provider, model=model, parse_info=parse_info)

    def _log_retry_event(
        self, *, action: str, provider: str, model: str, attempt: int, reason: str,
    ) -> None:
        from obra.hybrid.handlers.derive._execute_llm import log_retry_event
        log_retry_event(self, action=action, provider=provider, model=model, attempt=attempt, reason=reason)


__all__ = [
    "DeriveHandler",
    "IntentEnricher",
    "PromptEnricher",
    "should_auto_explore",
]
