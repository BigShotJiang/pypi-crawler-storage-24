"""Quality gate runner for DeriveHandler pipeline.

Extracts the quality gate lifecycle from DeriveHandler:
enabled check → assess → store → clarification loop.
"""

# pylint: disable=broad-exception-caught

import asyncio
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.display import VerbosityLevel, print_info, print_warning
from obra.display.observability import ObservabilityConfig
from obra.exceptions import QualityGateError
from obra.execution.quality import (
    AssessmentConfig,
    QualityAssessment,
    assess_user_plan_quality_with_timeout,
    get_threshold_for_userplan,
)
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.hybrid.quality.clarification import ClarificationLoop
from obra.observability.production_logger import ProductionLogger
from obra.review.metrics import emit_quality_gate_metrics
from obra.schemas.clarification_schema import TerminalReason
from obra.schemas.userplan_schema import QualityStatus, SourceType, UserPlan

logger = logging.getLogger(__name__)


class QualityGateRunner:
    """Runs the quality gate lifecycle for a UserPlan before derivation.

    Encapsulates: enabled check → assess → store → clarification loop.
    Constructed per-action by DeriveHandler; no singleton state across actions.
    """

    def __init__(
        self,
        config: dict[str, Any],
        api_client: Any | None,
        bypass_modes: list[str],
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        observability_config: ObservabilityConfig | None = None,
        monitoring_context: dict[str, Any] | None = None,
        llm_config: dict[str, Any] | None = None,
        working_dir: Path | None = None,
        production_logger: ProductionLogger | None = None,
    ) -> None:
        """Initialize QualityGateRunner.

        Args:
            config: Loaded layered config dict (read once from DeriveHandler.__init__).
            api_client: APIClient for UserPlan operations (get/update).
            bypass_modes: Active bypass mode strings (e.g. ['skip_quality_check']).
            on_progress: Progress emission callback (DeriveHandler._emit_progress).
            log_event: Event logging callback.
            trace_id: Trace ID for telemetry correlation.
            parent_span_id: Parent span ID for telemetry correlation.
            observability_config: Verbosity config for _emit_debug fallback.
            monitoring_context: Monitoring context dict (provides session_id for skip tracking).
            llm_config: LLM configuration for assessment (provider, model, auth_method).
            working_dir: Working directory passed to AssessmentConfig (oauth mode).
            production_logger: Production logger for quality/clarification events.
        """
        self._config = config
        self._api_client = api_client
        self._bypass_modes = bypass_modes
        self._on_progress = on_progress
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._monitoring_context = monitoring_context
        self._llm_config = llm_config or {}
        self._working_dir = working_dir
        self._production_logger = production_logger
        self._skip_quality_check = "skip_quality_check" in bypass_modes

    # --- Skip tracking helpers (copied from DeriveHandler) ---

    def _is_skip_tracking_enabled(self, source_key: str) -> bool:
        skip_config = self._config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get(source_key, True)
        )

    def _get_skip_session_id(self) -> str:
        if isinstance(self._monitoring_context, dict):
            session_id = self._monitoring_context.get("session_id")
            if session_id:
                return str(session_id)
        return ""

    # --- Internal helpers ---

    def _emit_debug(self, message: str) -> None:
        if self._on_progress:
            self._on_progress("debug_quality", {"message": message})
            return
        if (
            self._observability_config
            and self._observability_config.verbosity >= VerbosityLevel.DETAIL
        ):
            print_info(message)

    def _is_enabled(self) -> bool:
        """Check if quality gate is enabled via config flag.

        Reads features.userplan.quality_gate.enabled from self._config.
        Defaults to True (preserves existing behaviour).
        """
        try:
            features = self._config.get("features", {})
            userplan = features.get("userplan", {})
            quality_gate = userplan.get("quality_gate", {})
            return bool(quality_gate.get("enabled", True))
        except Exception as e:
            logger.warning(
                "Failed to read quality gate config flag, defaulting to enabled: %s", e
            )
            return True

    # --- Public API ---

    def run(self, userplan_id: str) -> None:
        """Run quality gate check on UserPlan before derivation.

        Fetches the UserPlan, assesses its quality, and raises QualityGateError
        if the score is below threshold. Stores quality assessment results in
        the UserPlan record. Runs clarification loop on passing plans.

        The quality gate can be disabled via:
        - Config flag: features.userplan.quality_gate.enabled = false
        - Bypass mode: --skip-quality-check CLI flag

        Args:
            userplan_id: ID of the UserPlan to assess.

        Raises:
            QualityGateError: If quality score is below threshold.
        """
        # Check if quality gate is disabled via config flag
        if not self._is_enabled():
            logger.info(
                "Quality gate disabled via config (features.userplan.quality_gate.enabled)"
            )
            self._emit_debug("Quality gate disabled (config flag)")
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="config_disabled",
                )
            return

        # Skip quality check if bypass mode is enabled
        if self._skip_quality_check:
            logger.info("Quality gate check skipped (skip_quality_check bypass mode)")
            self._emit_debug("Quality assessment skipped (--skip-quality-check)")
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="bypass_mode",
                )
            if self._is_skip_tracking_enabled("user_bypass"):
                create_skip_record(
                    session_id=self._get_skip_session_id(),
                    task_id=f"userplan-{userplan_id}",
                    source=SkipSource.USER_BYPASS,
                    reason=SkipReason.BYPASS_FLAG,
                    description="Quality gate skipped due to --skip-quality-check",
                    source_context={"bypass_modes": list(self._bypass_modes)},
                )
                logger.info("Run 'obra skips list' to review skipped items")
            # Store SKIPPED status in UserPlan record
            if self._api_client is not None:
                try:
                    self._api_client.update_userplan_quality(
                        userplan_id=userplan_id,
                        quality_score=None,
                        quality_status=QualityStatus.SKIPPED.value,
                        quality_hints=None,
                        quality_threshold=None,
                    )
                    logger.info("Stored SKIPPED quality status for UserPlan: %s", userplan_id)
                except Exception as e:
                    logger.warning(
                        "Failed to store SKIPPED quality status for %s: %s", userplan_id, e
                    )
            return

        # Skip if no API client available (quality gate requires server communication)
        if self._api_client is None:
            logger.warning(
                "Quality gate check skipped: no API client available. "
                "Quality assessment requires server communication."
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="no_api_client",
                )
            return

        logger.info("Running quality gate check for UserPlan: %s", userplan_id)
        self._emit_debug("Assessing plan quality...")

        # Fetch UserPlan from server
        try:
            userplan_data = self._api_client.get_userplan(userplan_id)
            if userplan_data is None:
                logger.warning("UserPlan not found: %s. Skipping quality gate.", userplan_id)
                if self._log_event:
                    self._log_event(
                        "quality_gate_skipped",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        userplan_id=userplan_id,
                        reason="userplan_not_found",
                    )
                return
        except Exception as e:
            logger.warning(
                "Failed to fetch UserPlan %s: %s. Skipping quality gate.",
                userplan_id,
                e,
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="fetch_error",
                    error=str(e),
                )
            return

        # Parse UserPlan data into model
        try:
            user_plan = UserPlan(**userplan_data)
        except Exception as e:
            logger.warning(
                "Failed to parse UserPlan %s: %s. Skipping quality gate.",
                userplan_id,
                e,
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="parse_error",
                    error=str(e),
                )
            return

        # ISSUE-HYBRID-004: Skip quality gate for SourceType.INTENT placeholders
        # These are minimal containers created from raw objectives - intent enrichment
        # and derivation create the real plan. Checking placeholder quality is meaningless.
        if user_plan.source and user_plan.source.type == SourceType.INTENT:
            logger.info(
                "Skipping quality gate for INTENT-source UserPlan %s (placeholder)",
                userplan_id,
            )
            self._emit_debug(
                "Quality gate skipped for placeholder plan (intent enrichment will validate)"
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="intent_source_placeholder",
                )
            return

        # Check if already assessed and passed
        if user_plan.quality_status == QualityStatus.PASSED:
            logger.info(
                "UserPlan %s already passed quality gate (score=%.2f, threshold=%.2f)",
                userplan_id,
                user_plan.quality_score or 0.0,
                user_plan.quality_threshold,
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_cached",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    score=user_plan.quality_score,
                    threshold=user_plan.quality_threshold,
                    status="passed",
                )
            return

        # Run quality assessment
        assessment = self._assess(user_plan)

        # Log quality assessment result
        logger.info(
            "Quality assessment complete for %s: score=%.2f, threshold=%.2f, status=%s",
            userplan_id,
            assessment.score if assessment.score is not None else 0.0,
            assessment.threshold,
            assessment.status.value,
        )
        if self._log_event:
            self._log_event(
                "quality_assessment_complete",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                userplan_id=userplan_id,
                score=assessment.score,
                threshold=assessment.threshold,
                status=assessment.status.value,
                hints_count=len(assessment.hints),
                duration_seconds=assessment.duration_seconds,
            )

        # Log quality assessment to production logger (FEAT-USERPLAN-002 S3)
        if self._production_logger:
            self._production_logger.log_quality_assessment(
                work_unit_id=userplan_id,
                quality_score=assessment.score or 0.0,
                status=assessment.status.value,
                threshold=assessment.threshold,
                hints_count=len(assessment.hints),
            )

        # Store quality assessment results in UserPlan
        self._store(userplan_id, assessment)

        # Emit quality gate metrics for observability
        is_generated = user_plan.source.generated if user_plan.source else False
        is_blocked = assessment.status == QualityStatus.FAILED
        emit_quality_gate_metrics(
            score=assessment.score,
            blocked=is_blocked,
            source_type=user_plan.source.type if user_plan.source else None,
            threshold=assessment.threshold,
            userplan_id=userplan_id,
            is_generated=is_generated,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        # Block derivation if quality gate failed
        if assessment.status == QualityStatus.FAILED:
            score = assessment.score if assessment.score is not None else 0.0
            msg = (
                f"Quality gate failed for UserPlan {userplan_id}. "
                f"Score: {score:.2f}, Required: {assessment.threshold:.2f}"
            )
            print_warning(msg)
            if assessment.hints:
                print_warning("Improvement suggestions:")
                for hint in assessment.hints[:5]:
                    print_warning(f"  - {hint}")
            raise QualityGateError(
                message=msg,
                score=score,
                threshold=assessment.threshold,
                hints=assessment.hints,
                userplan_id=userplan_id,
            )

        # Quality gate passed
        score_str = f"{assessment.score:.2f}" if assessment.score else "N/A"
        threshold_str = f"{assessment.threshold:.2f}"
        self._emit_debug(
            f"Quality gate passed (score: {score_str}, threshold: {threshold_str})"
        )

        # Run clarification loop post-quality-gate (FEAT-USERPLAN-002)
        # The loop refines acceptable plans; it doesn't block derivation
        self._clarify(user_plan)

    def _assess(self, user_plan: UserPlan) -> QualityAssessment:
        """Assess the quality of a UserPlan.

        Uses the appropriate threshold based on the UserPlan source:
        - Relaxed threshold (0.4) for Obra-generated plans (source.generated=True)
        - Standard threshold (0.6) for user-provided plans

        Args:
            user_plan: UserPlan to assess.

        Returns:
            QualityAssessment with score, status, and hints.
        """
        # Import LLMInvoker here to avoid circular imports
        from obra.llm.invoker import LLMInvoker

        # Determine appropriate threshold based on UserPlan source
        threshold = get_threshold_for_userplan(user_plan)

        # Log threshold selection for observability
        is_generated = user_plan.source.generated if user_plan.source else False
        logger.info(
            "Quality gate using %s threshold %.2f for UserPlan %s",
            "relaxed" if is_generated else "standard",
            threshold,
            user_plan.id,
        )

        # Configure assessment
        # ISSUE-SIM-002: Pass auth_method and working_dir to enable OAuth mode
        auth_method = self._llm_config.get("auth_method", "oauth")
        config = AssessmentConfig(
            thinking_enabled=True,
            reasoning_level=self._llm_config.get("reasoning_level", "medium"),
            provider=self._llm_config.get("provider", "anthropic"),
            model=self._llm_config.get("model", "sonnet"),
            auth_method=auth_method,
            working_dir=str(self._working_dir) if self._working_dir else None,
        )

        # Create LLM invoker for assessment (only needed for api_key mode)
        # OAuth mode uses CLI runner which handles auth internally
        llm_invoker = None
        if auth_method != "oauth":
            try:
                llm_invoker = LLMInvoker()
            except Exception as e:
                logger.warning("Failed to create LLM invoker: %s. Returning NOT_ASSESSED.", e)
                return QualityAssessment(
                    status=QualityStatus.NOT_ASSESSED,
                    threshold=threshold,
                    error_message=str(e),
                )

        # Run assessment (synchronous wrapper for async function)
        # Uses assess_user_plan_quality_with_timeout to enforce timeout
        # See ISSUE-HYBRID-002: Quality assessment LLM call hangs indefinitely
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        try:
            assessment = loop.run_until_complete(
                assess_user_plan_quality_with_timeout(
                    user_plan=user_plan,
                    llm_invoker=llm_invoker,
                    threshold=threshold,
                    config=config,
                    # Uses AUTO_ASSESSOR_TIMEOUT_S by default (15 minutes)
                )
            )
        except Exception as e:
            logger.exception("Quality assessment failed")
            assessment = QualityAssessment(
                status=QualityStatus.NOT_ASSESSED,
                threshold=threshold,
                error_message=str(e),
            )

        return assessment

    def _store(self, userplan_id: str, assessment: QualityAssessment) -> None:
        """Store quality assessment results in UserPlan record.

        Args:
            userplan_id: ID of the UserPlan to update.
            assessment: Quality assessment results.
        """
        if self._api_client is None:
            logger.warning("Cannot store quality results: no API client available")
            return

        try:
            self._api_client.update_userplan_quality(
                userplan_id=userplan_id,
                quality_score=assessment.score,
                quality_status=assessment.status.value,
                quality_hints=assessment.hints if assessment.hints else None,
                quality_threshold=assessment.threshold,
            )
            logger.info("Stored quality assessment results for UserPlan: %s", userplan_id)
        except Exception as e:
            logger.warning("Failed to store quality results for %s: %s", userplan_id, e)
            if self._log_event:
                self._log_event(
                    "quality_results_store_failed",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    error=str(e),
                )

    def _clarify(self, user_plan: UserPlan) -> None:
        """Run clarification loop to refine UserPlan quality.

        The clarification loop runs AFTER the quality gate passes. It provides
        iterative refinement for acceptable plans through field-level feedback.

        The loop terminates when:
        - Quality reaches target (clarification.loop.target_quality)
        - Max iterations reached (clarification.loop.max_iterations)
        - Diminishing returns (delta < clarification.loop.quality_delta_threshold)
        - No improvements identified

        Args:
            user_plan: The UserPlan to refine.

        Note:
            This is non-blocking - clarification failures are logged but do not
            prevent derivation from proceeding.
        """
        try:
            clarification_loop = ClarificationLoop()

            # Skip if loop is disabled (ClarificationLoop checks config internally)
            if not clarification_loop.enabled:
                logger.info("Clarification loop disabled")
                return

            logger.info("Running clarification loop for UserPlan: %s", user_plan.id)
            self._emit_debug("Refining plan quality...")

            # Run the loop
            result = clarification_loop.run(user_plan)

            if (
                result.final_terminal_reason != TerminalReason.THRESHOLD_REACHED
                and self._is_skip_tracking_enabled("quality_loop")
            ):
                terminal_map = {
                    TerminalReason.MAX_ITERATIONS: SkipReason.MAX_ITERATIONS,
                    TerminalReason.DIMINISHING_RETURNS: SkipReason.DIMINISHING_RETURNS,
                    TerminalReason.NO_IMPROVEMENTS: SkipReason.NO_IMPROVEMENTS,
                }
                mapped_reason = terminal_map.get(
                    result.final_terminal_reason, SkipReason.UNKNOWN
                )
                create_skip_record(
                    session_id=self._get_skip_session_id(),
                    task_id=result.userplan_id,
                    source=SkipSource.QUALITY_LOOP,
                    reason=mapped_reason,
                    description=f"Quality loop terminated: {result.final_terminal_reason.value}",
                    source_context={
                        "terminal_reason": result.final_terminal_reason.value,
                        "initial_quality": result.initial_quality,
                        "last_score": result.final_quality,
                        "threshold": clarification_loop.target_quality,
                        "iterations_run": result.iterations_run,
                    },
                )
                logger.info("Run 'obra skips list' to review skipped items")

            # Log result
            logger.info(
                "Clarification complete: %s improved %.2f -> %.2f (+%.3f) in %d iterations (%s)",
                user_plan.id,
                result.initial_quality,
                result.final_quality,
                result.total_improvement,
                result.iterations_run,
                result.final_terminal_reason.value,
            )

            # Emit event for observability
            if self._log_event:
                self._log_event(
                    "clarification_complete",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=user_plan.id,
                    initial_quality=result.initial_quality,
                    final_quality=result.final_quality,
                    total_improvement=result.total_improvement,
                    iterations_run=result.iterations_run,
                    terminal_reason=result.final_terminal_reason.value,
                    fields_improved=result.fields_improved_count,
                    fields_auto_filled=result.fields_auto_filled,
                )

            # Log clarification iterations to production logger (FEAT-USERPLAN-002 S3)
            if self._production_logger:
                for iteration in result.iterations:
                    self._production_logger.log_clarification_iteration(
                        work_unit_id=user_plan.id,
                        iteration=iteration.iteration,
                        quality_before=iteration.quality_before,
                        quality_after=iteration.quality_after,
                        terminal=iteration.terminal,
                        terminal_reason=(
                            iteration.terminal_reason.value
                            if iteration.terminal_reason
                            else None
                        ),
                        fields_improved=len(iteration.fields_improved),
                    )

            # Report improvement if significant
            if result.total_improvement > 0.01:
                self._emit_debug(
                    f"Quality refined: {result.initial_quality:.2f} -> "
                    f"{result.final_quality:.2f} "
                    f"(+{result.total_improvement:.1%}) in {result.iterations_run} iteration(s)"
                )

        except Exception as e:
            # Non-blocking - log warning but continue with derivation
            logger.warning(
                "Clarification loop failed for %s: %s. Continuing with derivation.",
                user_plan.id,
                e,
            )
            if self._log_event:
                self._log_event(
                    "clarification_error",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=user_plan.id,
                    error=str(e),
                )
