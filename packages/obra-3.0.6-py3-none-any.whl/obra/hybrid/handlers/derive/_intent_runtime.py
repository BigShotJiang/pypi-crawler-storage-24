"""Intent runtime helpers owned by the derive handler package."""

from __future__ import annotations

import hashlib
import logging
from typing import Any

from obra.config.loaders import get_derive_raw_response_log_preview
from obra.display import VerbosityLevel, console, print_info, print_warning
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.execution.userplan_metrics import emit_intent_generation_metric
from obra.intent.models import EnrichmentLevel, InputType, IntentMode, IntentModel

logger = logging.getLogger(__name__)


class IntentRuntime:
    """Owns derive-intent generation, formatting, and quality helpers."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner

    def generate_and_save_intent(
        self,
        objective: str,
        input_type: InputType,
        *,
        mode: IntentMode = IntentMode.FULL,
    ) -> tuple[str | None, EnrichmentLevel | None, IntentModel | None]:
        """Generate and persist intent for the objective."""
        from obra.hybrid.handlers.intent import IntentHandler
        from obra.intent.storage import IntentStorage

        try:
            storage = IntentStorage()
            project = storage.get_project_id(self._owner._working_dir)
            intent_handler = IntentHandler(
                working_dir=self._owner._working_dir,
                project=project,
                on_stream=self._owner._on_stream,
                on_progress=self._owner._on_progress,
                llm_config=self._owner._llm_config,
                log_event=self._owner._log_event,
                trace_id=self._owner._trace_id,
                parent_span_id=self._owner._parent_span_id,
                monitoring_context=self._owner._monitoring_context,
                production_logger=self._owner._production_logger,
            )

            logger.info("Generating intent for objective (type: %s)", input_type.value)
            print_info("Generating intent for objective...")

            intent = intent_handler.generate(objective, input_type=input_type, mode=mode)
            intent_path = storage.save(intent)
            logger.info("Saved intent to %s", intent_path)
            print_info(f"Intent saved: {intent.id}")

            enrichment_level = intent.enrichment_level
            if enrichment_level and self._owner._on_stream:
                self._owner._on_stream(
                    "intent_enrichment",
                    f"enrichment_level={enrichment_level.value}, path={intent_path}",
                )
            if self._owner._log_event:
                intent_markdown = self.format_intent_for_prompt(intent)
                self._owner._log_event(
                    "intent_generated",
                    session_id=None,
                    trace_id=self._owner._trace_id,
                    parent_span_id=self._owner._parent_span_id,
                    intent_id=intent.id,
                    enrichment_level=(enrichment_level.value if enrichment_level else "none"),
                    intent_path=str(intent_path),
                    intent_markdown=intent_markdown,
                )

            emit_intent_generation_metric(
                source_type=input_type.value if input_type else "unknown",
                success=True,
                intent_id=intent.id,
                enrichment_level=enrichment_level.value if enrichment_level else None,
                log_event=self._owner._log_event,
                trace_id=self._owner._trace_id,
            )

            self.validate_intent_enrichment(intent)
            self.emit_intent_summary(intent, enrichment_level)
        except Exception as exc:
            error_type = type(exc).__name__
            objective_length = len(objective) if objective else 0
            objective_hash = (
                hashlib.sha256(objective.encode("utf-8")).hexdigest() if objective else "unknown"
            )
            logger.warning(
                "Intent generation failed (non-blocking), continuing with derivation. Error: %s (%s), input_type=%s, objective_length=%d chars",
                exc,
                error_type,
                input_type.value if input_type else "unknown",
                objective_length,
            )

            if self._owner._log_event:
                self._owner._log_event(
                    "intent_generation_failed",
                    session_id=None,
                    trace_id=self._owner._trace_id,
                    parent_span_id=self._owner._parent_span_id,
                    error_type=error_type,
                    error_message=str(exc)[: get_derive_raw_response_log_preview()],
                    input_type=input_type.value if input_type else "unknown",
                    objective_length=objective_length,
                    recoverable=True,
                )

            emit_intent_generation_metric(
                source_type=input_type.value if input_type else "unknown",
                success=False,
                log_event=self._owner._log_event,
                trace_id=self._owner._trace_id,
            )

            if self._owner._is_skip_tracking_enabled("derive_handler"):
                create_skip_record(
                    session_id=self._owner._get_skip_session_id(),
                    task_id=f"intent-{objective_hash[:8]}",
                    source=SkipSource.DERIVE_HANDLER,
                    reason=SkipReason.EXTERNAL_DEPENDENCY,
                    description="Intent generation failed, proceeding without intent",
                    source_context={
                        "error_type": error_type,
                        "error_message": str(exc),
                        "objective_hash": objective_hash,
                    },
                )
                logger.info("Run 'obra skips list' to review skipped items")

            return None, None, None

        if self._owner._review_intent and not self.prompt_intent_approval(intent):
            logger.info("Intent not approved, aborting derive")
            raise ValueError("Intent review: User declined to proceed")

        return self.format_intent_for_prompt(intent), enrichment_level, intent

    def load_active_intent(self) -> IntentModel | None:
        """Load the active intent model for the current project."""
        from obra.intent.storage import IntentStorage

        try:
            storage = IntentStorage()
            project = storage.get_project_id(self._owner._working_dir)
            intent = storage.load_active(project)
            if intent:
                logger.debug("Loaded active intent: %s", intent.id)
                return intent
        except Exception as exc:
            logger.debug("Failed to load active intent: %s", exc)
        return None

    def load_active_intent_content(self) -> str | None:
        """Load active intent content for prompt injection."""
        intent = self.load_active_intent()
        if not intent:
            return None
        return self.format_intent_for_prompt(intent)

    @staticmethod
    def validate_intent_enrichment(intent: Any) -> None:
        """Validate intent enrichment level and warn if incomplete."""
        enrichment_level = intent.enrichment_level
        if enrichment_level == EnrichmentLevel.NONE:
            logger.warning(
                "Intent has minimal enrichment (NONE) - derivation may be incomplete. Consider providing a more detailed objective."
            )
            print_warning(
                "Intent enrichment: minimal (using fallback). Consider providing more details in your objective."
            )
        elif enrichment_level == EnrichmentLevel.PROSE:
            logger.info(
                "Intent extracted from prose response. Some structured fields may be incomplete."
            )
            print_info(
                "Intent enrichment: extracted from prose. Structured requirements may need manual refinement."
            )
        elif enrichment_level == EnrichmentLevel.FULL:
            logger.debug("Intent has full enrichment from structured response")
        elif enrichment_level is None:
            logger.debug("Intent has no enrichment level metadata (pre-S3 intent)")

    def check_intent_quality(self, intent: Any, objective: str | None = None) -> None:
        """Check enriched intent quality and reject if insufficient."""
        from obra.exceptions import IntentQualityError

        enabled, min_score, required_fields, non_empty_fields = self.load_intent_quality_config()
        if not enabled:
            logger.debug("Intent quality check disabled via config")
            return

        score, hints = self.assess_intent_quality(intent, required_fields, non_empty_fields)
        logger.info(
            "Intent quality check: score=%.2f, threshold=%.2f, intent_id=%s",
            score,
            min_score,
            intent.id,
        )

        if score < min_score:
            logger.warning(
                "Intent quality below threshold: score=%.2f < %.2f, hints=%s",
                score,
                min_score,
                hints,
            )
            if self._owner._log_event:
                self._owner._log_event(
                    "intent_quality_failed",
                    session_id=None,
                    trace_id=self._owner._trace_id,
                    parent_span_id=self._owner._parent_span_id,
                    intent_id=intent.id,
                    score=score,
                    threshold=min_score,
                    hints=hints,
                )
            raise IntentQualityError(
                message=f"Enriched intent quality too low: {score:.2f} < {min_score:.2f}",
                intent_id=intent.id,
                score=score,
                threshold=min_score,
                hints=hints,
            )

        logger.debug("Intent quality check passed: score=%.2f >= %.2f", score, min_score)

    def load_intent_quality_config(self) -> tuple[bool, float, list[str], list[str]]:
        """Load intent quality config from the handler config."""
        try:
            intent_cfg = (
                self._owner._config.get("features", {}).get("intent", {}).get("quality_check", {})
            )
            enabled = intent_cfg.get("enabled", True)
            min_score = intent_cfg.get("min_score", 0.5)
            required_fields = intent_cfg.get(
                "required_fields",
                ["problem_statement", "requirements"],
            )
            non_empty_fields = intent_cfg.get("non_empty_fields", ["problem_statement"])
            return enabled, min_score, required_fields, non_empty_fields
        except Exception:
            return True, 0.5, ["problem_statement", "requirements"], ["problem_statement"]

    @staticmethod
    def assess_intent_quality(
        intent: Any,
        required_fields: list[str],
        non_empty_fields: list[str],
    ) -> tuple[float, list[str]]:
        """Assess intent quality based on field presence and content."""
        hints: list[str] = []
        score_components: list[float] = []

        for field in required_fields:
            value = getattr(intent, field, None)
            if value is None:
                hints.append(f"Missing required field: {field}")
                score_components.append(0.0)
            elif isinstance(value, list) and len(value) == 0:
                hints.append(f"Empty list for field: {field}")
                score_components.append(0.3)
            elif isinstance(value, str) and len(value.strip()) == 0:
                hints.append(f"Empty string for field: {field}")
                score_components.append(0.3)
            else:
                score_components.append(1.0)

        for field in non_empty_fields:
            if field in required_fields:
                continue
            value = getattr(intent, field, None)
            if value is None or (isinstance(value, str) and len(value.strip()) == 0):
                hints.append(f"Field should have content: {field}")
                score_components.append(0.5)
            else:
                score_components.append(1.0)

        optional_fields = ["constraints", "assumptions", "acceptance_criteria", "risks"]
        populated_optional = sum(
            1
            for field in optional_fields
            if getattr(intent, field, None)
            and (
                not isinstance(getattr(intent, field), list)
                or len(getattr(intent, field)) > 0
            )
        )
        if populated_optional >= 2:
            score_components.append(1.0)
        elif populated_optional >= 1:
            score_components.append(0.7)

        if not score_components:
            return 0.5, hints

        score = sum(score_components) / len(score_components)
        return round(score, 2), hints

    @staticmethod
    def format_intent_for_prompt(intent: Any) -> str:
        """Format the intent model for prompt injection."""
        sections = [f"# Intent: {intent.problem_statement}", ""]

        if intent.assumptions:
            sections.append("## Assumptions")
            sections.extend(f"- {assumption}" for assumption in intent.assumptions)
            sections.append("")

        if intent.requirements:
            sections.append("## Requirements")
            sections.extend(f"- {requirement}" for requirement in intent.requirements)
            sections.append("")

        if intent.constraints:
            sections.append("## Constraints")
            sections.extend(f"- {constraint}" for constraint in intent.constraints)
            sections.append("")

        if intent.acceptance_criteria:
            sections.append("## Acceptance Criteria")
            sections.extend(f"- {criterion}" for criterion in intent.acceptance_criteria)
            sections.append("")

        if intent.non_goals:
            sections.append("## Non-Goals")
            sections.extend(f"- {non_goal}" for non_goal in intent.non_goals)
            sections.append("")

        if intent.risks:
            sections.append("## Risks")
            sections.extend(f"- {risk}" for risk in intent.risks)
            sections.append("")

        if intent.context_amendments:
            sections.append("## Context Amendments")
            sections.extend(f"- {amendment}" for amendment in intent.context_amendments)
            sections.append("")

        if hasattr(intent, "user_stories") and intent.user_stories:
            sections.append("## User Stories (Behavioral Outcomes)")
            sections.append("")
            sections.append("Each derived item should trace to one or more user stories.")
            sections.append("Include user_story_ids in your output to link items to stories.")
            sections.append("")
            for story in intent.user_stories:
                verification_value = (
                    story.verification_method.value
                    if hasattr(story.verification_method, "value")
                    else story.verification_method
                )
                sections.append(
                    f"- **{story.id}** ({verification_value}): As a {story.role}, I want {story.action}, so that {story.outcome}"
                )
            sections.append("")

        return "\n".join(sections)

    def emit_intent_summary(
        self,
        intent: Any,
        enrichment_level: EnrichmentLevel | None,
    ) -> None:
        """Emit a concise, human-readable intent summary to the console."""
        verbosity = (
            self._owner._observability_config.verbosity
            if self._owner._observability_config
            else VerbosityLevel.PROGRESS
        )
        if verbosity < VerbosityLevel.PROGRESS:
            return
        max_items = 6 if verbosity >= VerbosityLevel.DETAIL else 3
        summary_lines = self.format_intent_summary_lines(
            intent,
            max_items=max_items,
            enrichment_level=enrichment_level,
        )
        if not summary_lines:
            return
        self._owner._emit_planning_stage_completed(
            "intent_summary",
            "Intent summary",
            0.0,
            summary="\n".join(summary_lines),
        )

    @staticmethod
    def format_intent_summary_lines(
        intent: Any,
        *,
        max_items: int,
        enrichment_level: EnrichmentLevel | None,
    ) -> list[str]:
        """Format intent into compact summary lines."""
        lines: list[str] = []
        enrichment = enrichment_level.value if enrichment_level else "unknown"
        lines.append(f"Intent summary (enrichment: {enrichment})")

        problem = getattr(intent, "problem_statement", None)
        if isinstance(problem, str) and problem.strip():
            problem_text = " ".join(problem.split())
            if len(problem_text) > 120:
                problem_text = problem_text[:120] + "..."
            lines.append(f"  Problem: {problem_text}")

        def _format_section(label: str, items: Any) -> None:
            if not isinstance(items, list) or not items:
                return
            total = len(items)
            shown = items[:max_items]
            rendered: list[str] = []
            for item in shown:
                text = " ".join(str(item).split())
                if len(text) > 80:
                    text = text[:80] + "..."
                if text:
                    rendered.append(text)
            if rendered:
                suffix = f" (+{total - max_items} more)" if total > max_items else ""
                lines.append(f"  {label} ({total}): " + "; ".join(rendered) + suffix)

        _format_section("Requirements", getattr(intent, "requirements", None))
        _format_section("Constraints", getattr(intent, "constraints", None))
        _format_section("Acceptance", getattr(intent, "acceptance_criteria", None))
        _format_section("Non-goals", getattr(intent, "non_goals", None))
        _format_section("Assumptions", getattr(intent, "assumptions", None))
        _format_section("Risks", getattr(intent, "risks", None))
        return lines

    @staticmethod
    def extract_user_story_refs(text: str) -> list[str]:
        """Extract user story references from text using regex."""
        import re

        return sorted(set(re.findall(r"US-\d+", text)))

    def prompt_intent_approval(self, intent: Any) -> bool:
        """Display intent and prompt user for approval."""
        from obra.display.prompting import prompt_input

        print_info("\n=== Generated Intent ===\n")
        print_info(self.format_intent_for_prompt(intent))
        print_info("\n" + "=" * 50 + "\n")
        console.print("Proceed with this intent? [Y/n]: ", end="", markup=False, highlight=False)
        try:
            response = prompt_input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            return False
        return response in {"", "y", "yes"}
