"""Scaffolded review stage for DeriveHandler post-derivation processing."""

from __future__ import annotations

import logging
from time import perf_counter
from typing import TYPE_CHECKING, Any

from obra.exceptions import QualityGateError
from obra.planning.enrichment_review import EnrichmentPlanReviewer

if TYPE_CHECKING:
    from obra.api.protocol import DeriveRequest
    from obra.hybrid.handlers.derive._context import DerivationContext
    from obra.hybrid.handlers.derive._handler import DeriveHandler

logger = logging.getLogger(__name__)


def run_scaffolded_review(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
) -> None:
    """Run scaffolded plan review when intent scaffolding is active."""
    if not (ctx.scaffolded_active and ctx.intent_content):
        handler._emit_planning_stage_started("revise", "Refining plan")
        handler._emit_planning_stage_completed(
            "revise",
            "Refining plan",
            0.0,
            summary=(
                "No derive-stage revision needed downstream validation may still "
                "request refinement"
            ),
        )
        return

    reviewer = EnrichmentPlanReviewer(
        handler._working_dir,
        llm_config=handler._llm_config,
        on_stream=handler._on_stream,
        on_progress=handler._emit_progress,
        log_event=handler._log_event,
        trace_id=handler._trace_id,
        parent_span_id=handler._parent_span_id,
    )
    review_start = perf_counter()
    review_heartbeat = None
    try:
        review_stage_config = (
            ctx.planner.get_stage_config("revise") if ctx.planner else {}
        )
        handler._emit_planning_stage_started("revise", "Refining plan")
        handler._emit_stage_started("revise", review_stage_config or {})
        review_heartbeat = handler._start_stage_heartbeat("revise")
        review_result = reviewer.review(
            request.objective,
            intent_markdown=ctx.intent_content,
            plan_items=ctx.plan_items,
            intent_id=ctx.intent_model.id if ctx.intent_model else None,
        )
        complete_review_stage(handler, ctx, request, review_result, review_start)
    except Exception as exc:
        review_duration_ms = int((perf_counter() - review_start) * 1000)
        handler._emit_stage_failed("revise", str(exc), review_duration_ms, None)
        logger.warning("Scaffolded review failed: %s", exc)
    finally:
        if review_heartbeat:
            review_heartbeat.stop()


def complete_review_stage(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
    review_result: Any,
    review_start: float,
) -> None:
    """Finalize revise-stage telemetry and apply returned plan updates."""
    review_duration_ms = int((perf_counter() - review_start) * 1000)
    ctx.stage_timings["revise"] = review_duration_ms / 1000.0
    handler._emit_stage_completed(
        "revise",
        review_duration_ms,
        result={
            "changes_required": bool(review_result and review_result.changes_required),
        },
    )
    summary = (
        "Plan refined"
        if review_result and review_result.changes_required
        else "No refinement needed"
    )
    handler._emit_planning_stage_completed(
        "revise",
        "Refining plan",
        review_duration_ms / 1000.0,
        summary=summary,
    )
    if review_result and review_result.changes_required:
        apply_review_changes(handler, ctx, request, review_result)


def apply_review_changes(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
    review_result: Any,
) -> None:
    """Validate and apply scaffolded review output to the plan."""
    strict_mode = (
        handler._config.get("derivation", {})
        .get("review_gate", {})
        .get("strict", True)
    )
    if not review_result.plan_items:
        if strict_mode:
            raise QualityGateError(
                message="Review requires changes but returned no plan items",
                score=0.0,
                threshold=1.0,
                hints=[
                    "Review detected issues but couldn't generate fixes",
                    "Run with --permissive to proceed with original plan",
                ],
            )
        logger.warning(
            "Scaffolded review requested changes but returned no plan items"
        )
        return

    if handler._sanitizer.is_hierarchical_enabled():
        valid, violations = handler._sanitizer.validate_hierarchy(
            review_result.plan_items
        )
        if not valid:
            if strict_mode:
                raise QualityGateError(
                    message=(
                        "Review requires changes but returned invalid plan hierarchy"
                    ),
                    score=0.0,
                    threshold=1.0,
                    hints=violations[:5],
                )
            logger.warning(
                "Scaffolded review returned invalid hierarchy; keeping original plan: %s",
                "; ".join(violations[:10]),
            )
            return

    ctx.plan_items = handler._sanitizer.sanitize(
        review_result.plan_items,
        userplan_steps=request.userplan_steps,
    )
