"""Context-gathering stage for DeriveHandler._execute_derivation.

Extracted from _handler.py (Task 0.1, REFACTOR-SCHEMAS-P7-001).

This module owns the context-discovery sub-pipeline: work-type detection,
auto-exploration, prompt enrichment, and LLM config resolution. It writes
``ctx.normalized_inputs``, ``ctx.domain_derivation_metadata``, ``ctx.work_type``,
``ctx.exploration_markdown``, ``ctx.enriched_prompt``, and
``ctx.last_derivation_llm``.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from time import perf_counter
from typing import TYPE_CHECKING, Any

from obra.display import print_info, print_warning
from obra.execution.derivation import detect_recent_exploration
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.exploration.config import get_exploration_config
from obra.exploration.decision import detect_work_type
from obra.exploration.models import ExplorationDecision
from obra.exploration.runner import run_exploration
from obra.prompts.derive.derivation import build_sizing_guidance_block

if TYPE_CHECKING:
    from obra.api.protocol import DeriveRequest
    from obra.hybrid.handlers.derive._context import DerivationContext
    from obra.hybrid.handlers.derive._handler import DeriveHandler

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Supporting helpers
# ---------------------------------------------------------------------------


def detect_primary_manifest(handler: DeriveHandler) -> tuple[str, Path | None]:
    """Detect the primary package manifest in the working directory."""
    manifest_candidates = [
        "pyproject.toml",
        "package.json",
        "Cargo.toml",
        "go.mod",
        "Gemfile",
        "requirements.txt",
    ]
    for filename in manifest_candidates:
        root_path = handler._working_dir / filename
        if root_path.exists():
            return filename, root_path
        for path in handler._working_dir.rglob(filename):
            if path.is_file():
                return filename, path
    return "none", None


def extract_manifest_dependencies(
    handler: DeriveHandler,
    manifest_type: str,
    manifest_path: Path | None,
) -> list[str]:
    """Extract dependency names from a package manifest."""
    if not manifest_path or not manifest_path.exists():
        return []

    def normalize_dep(value: str) -> str:
        trimmed = value.strip()
        if not trimmed:
            return ""
        trimmed = trimmed.split(";")[0]
        trimmed = trimmed.split("[", 1)[0]
        for token in ["==", ">=", "<=", "~=", ">", "<", "!="]:
            if token in trimmed:
                trimmed = trimmed.split(token, 1)[0]
        return trimmed.strip()

    deps: list[str] = []
    try:
        if manifest_type == "pyproject.toml":
            import tomllib

            data = tomllib.loads(manifest_path.read_text(encoding="utf-8"))
            project = data.get("project", {})
            deps.extend(project.get("dependencies", []) or [])
            optional = project.get("optional-dependencies", {}) or {}
            for items in optional.values():
                deps.extend(items or [])
            poetry = data.get("tool", {}).get("poetry", {})
            for group in ("dependencies", "dev-dependencies"):
                for name in poetry.get(group, {}) or {}:
                    deps.append(name)
        elif manifest_type == "package.json":
            payload = json.loads(manifest_path.read_text(encoding="utf-8"))
            for key in ("dependencies", "devDependencies", "optionalDependencies"):
                deps.extend((payload.get(key) or {}).keys())
        elif manifest_type == "requirements.txt":
            for line in manifest_path.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith(("#", "-")):
                    continue
                deps.append(stripped)
    except Exception as exc:
        logger.debug("Failed to parse manifest %s: %s", manifest_path, exc)

    seen: set[str] = set()
    normalized: list[str] = []
    for dep in deps:
        if not isinstance(dep, str):
            continue
        name = normalize_dep(dep)
        if not name or name in seen:
            continue
        seen.add(name)
        normalized.append(name)
    return normalized


def discover_verification_tools(handler: DeriveHandler) -> dict[str, Any]:
    """Discover verification tools for server-side FIX enforcement.

    S0.T7: Client reports verification tools during derivation.
    Server persists this on session and checks before returning FIX actions.

    Returns:
        Dict with available tools, missing tools, and discovery source
    """
    try:
        from obra.config.loaders import (
            get_verification_discovery_enabled,
            get_verification_force_refresh,
            load_layered_config,
        )
        from obra.hybrid.tooling_discovery import ToolingDiscovery

        config, _, _ = load_layered_config(include_defaults=True)
        configured_tools = config.get("fix", {}).get("verification", {}).get("tools", [])

        if isinstance(configured_tools, list) and configured_tools:
            # Use configured tools
            available = [t.get("category", t.get("name", "unknown")) for t in configured_tools]
            return {
                "available": available,
                "missing": [],
                "source": "config",
            }

        if get_verification_discovery_enabled():
            # Use tooling discovery
            discovery = ToolingDiscovery(handler._working_dir, handler._llm_config)
            tooling = discovery.discover(force_refresh=get_verification_force_refresh())

            available = []
            missing = []
            verification = tooling.get("verification", {})
            for category in ["test", "lint", "typecheck"]:
                tool_config = verification.get(category, {})
                if isinstance(tool_config, dict) and tool_config.get("command"):
                    # Map category names: test -> tests (to match fix handler expectations)
                    cat_name = "tests" if category == "test" else category
                    available.append(cat_name)
                else:
                    cat_name = "tests" if category == "test" else category
                    missing.append(cat_name)

            return {
                "available": available,
                "missing": missing,
                "source": "discovery",
            }

        # Discovery disabled, no configured tools
        return {
            "available": [],
            "missing": ["tests", "lint", "typecheck"],
            "source": "none",
        }

    except Exception as exc:
        logger.warning("Failed to discover verification tools: %s", exc)
        return {
            "available": [],
            "missing": [],
            "source": "error",
        }


def get_file_count(handler: DeriveHandler, max_count: int = 500) -> int:
    """Count source and config files in working directory.

    Counts common source/config file types. Uses iterative walking with
    early exit to avoid hanging on large directories.

    Args:
        handler: The DeriveHandler instance.
        max_count: Stop counting after this many files (default 500).

    Returns:
        Count of relevant files in working directory (capped at max_count).
    """
    if not handler._working_dir or not handler._working_dir.exists():
        return 0

    relevant_extensions = {
        ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java",
        ".rb", ".php", ".cs", ".cpp", ".c", ".h", ".hpp",
        ".yaml", ".yml", ".json", ".toml",
    }

    from obra.intent.detection import EXCLUDED_DIRS

    count = 0
    try:
        dirs_to_process = [handler._working_dir]
        while dirs_to_process and count < max_count:
            current_dir = dirs_to_process.pop()
            try:
                for item in current_dir.iterdir():
                    if item.is_dir():
                        if item.name not in EXCLUDED_DIRS:
                            dirs_to_process.append(item)
                    elif item.is_file() and item.suffix in relevant_extensions:
                        count += 1
                        if count >= max_count:
                            break
            except (PermissionError, OSError):
                continue
    except (OSError, PermissionError):
        pass

    return count


def emit_exploration_message(handler: DeriveHandler, decision: ExplorationDecision) -> None:
    """Emit user-facing exploration messaging when helpful."""
    if decision.should_explore:
        return

    if decision.skip_reason == "empty_project":
        return

    warning_messages = {
        "config_disabled": (
            "Exploration skipped: disabled via config "
            "(set orchestration.exploration.enabled=true to enable)."
        ),
        "skip_explore": "Exploration skipped: --skip-explore was provided.",
        "no_working_dir": (
            "Exploration skipped: no working directory configured. "
            "Run inside the project directory or pass --dir."
        ),
    }
    warning_message = (
        warning_messages.get(decision.skip_reason) if decision.skip_reason else None
    )
    if warning_message:
        print_warning(warning_message)
        return

    print_info(f"Exploration skipped: {decision.reason}.")


def log_exploration_decision(handler: DeriveHandler, decision: ExplorationDecision) -> None:
    """Log exploration decision for observability."""
    if decision.should_explore:
        logger.info("Auto-exploration triggered: %s", decision.reason)
    else:
        logger.debug("Auto-exploration skipped: %s", decision.reason)

    if handler._log_event:
        try:
            handler._log_event(
                "exploration_decision",
                should_explore=decision.should_explore,
                reason=decision.reason,
                complexity_score=decision.complexity_score,
                work_type=decision.work_type,
                recent_exploration=decision.recent_exploration,
                has_explicit_paths=decision.has_explicit_paths,
                trace_id=handler._trace_id,
                parent_span_id=handler._parent_span_id,
            )
        except TypeError:
            logger.debug(
                "Exploration decision logging skipped: incompatible log_event signature"
            )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def gather_derivation_context(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
) -> None:
    """Gather context needed for the LLM derivation stage.

    Mutates *ctx* in place — writes ``normalized_inputs``,
    ``domain_derivation_metadata``, ``work_type``, ``exploration_markdown``,
    ``enriched_prompt``, and ``last_derivation_llm``.

    Args:
        handler: The DeriveHandler instance.
        ctx: Mutable pipeline state carrier.
        request: The incoming DeriveRequest.
    """
    from obra.config.llm import DEFAULT_REASONING_LEVEL
    from obra.config.loaders import get_workflow_derivation_llm_config
    from obra.hybrid.handlers import derive as derive_package
    from obra.hybrid.handlers.derive import _handler as derive_handler_module

    from ._handler import LLMInvocationParams

    # Validate base_prompt (server-side prompting required)
    if request.base_prompt is None:
        error_msg = (
            "DeriveRequest.base_prompt is None. Server must provide base prompt (ADR-035)."
        )
        logger.error(error_msg)
        raise ValueError(error_msg)

    normalized_inputs = handler._workflow_runtime.normalize_workflow_derivation_inputs(request)
    if normalized_inputs is not None:
        ctx.normalized_inputs = normalized_inputs
        ctx.domain_derivation_metadata = (
            handler._workflow_runtime.resolve_workflow_domain_framing(normalized_inputs)
        )

    ctx.work_type = detect_work_type(
        request.objective,
        domain=handler._domain,
        work_type_keywords=(
            handler._domain.get_derivation_keywords()
            if handler._domain is not None
            else None
        ),
        work_type_override=handler._work_type_override,
    )
    exploration_config = get_exploration_config()
    lookback_minutes = int(exploration_config["skip"]["recent_exploration_hours"]) * 60
    exploration_state = detect_recent_exploration(
        handler._working_dir,
        lookback_minutes=lookback_minutes,
    )

    # Auto-exploration: conditionally explore codebase before derivation (ADR-055)
    decision = derive_handler_module.should_auto_explore(
        objective=request.objective,
        work_type=ctx.work_type,
        exploration_state=exploration_state,
        working_dir=handler._working_dir,
        complexity_score=request.complexity_score,
        exploration_config=exploration_config,
        bypass_modes=handler._bypass_modes,
    )
    # Skip tracking for skip_explore bypass
    if decision.skip_reason == "skip_explore" and handler._is_skip_tracking_enabled(
        "user_bypass"
    ):
        create_skip_record(
            session_id=handler._get_skip_session_id(),
            task_id="exploration",
            source=SkipSource.USER_BYPASS,
            reason=SkipReason.BYPASS_FLAG,
            description="Exploration skipped due to --skip-explore",
            source_context={"bypass_modes": list(handler._bypass_modes)},
        )
        logger.info("Run 'obra skips list' to review skipped items")
    log_exploration_decision(handler, decision)
    emit_exploration_message(handler, decision)

    if decision.should_explore:
        # Check cache first (FR-8, ADR-055)
        cached_context = handler._exploration_cache.get(
            objective=request.objective,
            work_type=ctx.work_type,
        )
        if cached_context is not None:
            exploration_context = cached_context
        else:
            # Cache miss - run exploration
            derive_config = resolve_derive_llm_config(handler)
            exploration_context = run_exploration(
                objective=request.objective,
                work_type=ctx.work_type,
                working_dir=handler._working_dir,
                derive_llm_config=derive_config,
                log_event=handler._log_event,
                trace_id=handler._trace_id,
                parent_span_id=handler._parent_span_id,
            )
            # Cache successful exploration
            handler._exploration_cache.put(
                objective=request.objective,
                work_type=ctx.work_type,
                context=exploration_context,
            )

        if exploration_context.success:
            ctx.exploration_markdown = exploration_context.to_markdown()

    # Enrich base prompt with local tactical context, intent, and exploration (S2.T2, ADR-055)
    enricher = derive_package.PromptEnricher(handler._working_dir)
    ctx.enriched_prompt = enricher.enrich(
        request.base_prompt,
        intent=ctx.intent_content,
        exploration_context=ctx.exploration_markdown,
    )
    if ctx.sizing_guidance:
        sizing_block = build_sizing_guidance_block(ctx.sizing_guidance)
        ctx.enriched_prompt = f"{ctx.enriched_prompt}\n\n{sizing_block}".strip()

    # --- Resolve LLM config for the derive stage ---
    stage_timeout_s: int | None = None
    max_passes: int | None = None
    if ctx.normalized_inputs is not None:
        workflow_llm = get_workflow_derivation_llm_config()
        provider = workflow_llm["provider"]
        model = workflow_llm["model"]
        reasoning_level = workflow_llm.get("reasoning_level", DEFAULT_REASONING_LEVEL)
        auth_method = "oauth"
        max_passes = int(workflow_llm["max_retries"])
        stage_timeout_s = int(workflow_llm["timeout_s"])
    elif ctx.scaffolded_active and ctx.planner is not None:
        stage_config = ctx.planner.get_stage_config("derive")
        (
            provider,
            model,
            reasoning_level,
            auth_method,
            max_passes,
            stage_timeout_s,
        ) = handler._resolve_scaffolded_stage_llm(stage_config, request.llm_provider)
    else:
        resolved = handler._resolve_derive_llm_config()
        provider = resolved["provider"]
        model = resolved["model"]
        reasoning_level = resolved.get("reasoning_level", DEFAULT_REASONING_LEVEL)
        auth_method = resolved.get("auth_method", "oauth")

    handler._last_derivation_llm = LLMInvocationParams(
        provider=provider,
        model=model,
        reasoning_level=reasoning_level or DEFAULT_REASONING_LEVEL,
        auth_method=auth_method,
        timeout_s=stage_timeout_s,
    )
    ctx.last_derivation_llm = handler._last_derivation_llm
    from obra.hybrid.handlers import derive as derive_package
    from obra.hybrid.handlers.derive import _handler as derive_handler_module
