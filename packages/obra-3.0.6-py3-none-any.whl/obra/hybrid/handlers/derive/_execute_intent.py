"""Intent stage for DeriveHandler._execute_derivation.

Extracted from _handler.py (Task 0.0, REFACTOR-SCHEMAS-P7-001).

This module owns the intent generation, quality assessment, formatting,
and approval sub-pipeline. It writes ``ctx.intent_model``,
``ctx.intent_content``, ``ctx.intent_enrichment``, ``ctx.planner``,
``ctx.scaffolded_active``, and ``ctx.scaffolded_run``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from obra.display import print_warning
from obra.intent.detection import detect_input_type
from obra.intent.models import EnrichmentLevel, IntentMode

if TYPE_CHECKING:
    from obra.api.protocol import DeriveRequest
    from obra.hybrid.handlers.derive._context import DerivationContext
    from obra.hybrid.handlers.derive._handler import DeriveHandler

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Supporting helpers (module-level replacements for DeriveHandler instance methods)
# ---------------------------------------------------------------------------


def _generate_and_save_intent(
    handler: DeriveHandler,
    objective: str,
    input_type: Any,
    *,
    mode: IntentMode = IntentMode.FULL,
) -> tuple[str | None, EnrichmentLevel | None, Any]:
    """Delegate to IntentRuntime.generate_and_save_intent."""
    return handler._intent_runtime.generate_and_save_intent(
        objective,
        input_type,
        mode=mode,
    )


def _load_active_intent(handler: DeriveHandler) -> Any:
    """Delegate to IntentRuntime.load_active_intent."""
    return handler._intent_runtime.load_active_intent()


def _load_active_intent_content(handler: DeriveHandler) -> str | None:
    """Delegate to IntentRuntime.load_active_intent_content."""
    return handler._intent_runtime.load_active_intent_content()


def _check_intent_quality(handler: DeriveHandler, intent: Any, objective: str | None = None) -> None:
    """Delegate to IntentRuntime.check_intent_quality."""
    handler._intent_runtime.check_intent_quality(intent, objective)


def _assess_intent_quality(
    handler: DeriveHandler,
    intent: Any,
    required_fields: list[str],
    non_empty_fields: list[str],
) -> tuple[float, list[str]]:
    """Delegate to IntentRuntime.assess_intent_quality."""
    return handler._intent_runtime.assess_intent_quality(
        intent,
        required_fields,
        non_empty_fields,
    )


def _load_intent_quality_config(handler: DeriveHandler) -> tuple[bool, float, list[str], list[str]]:
    """Delegate to IntentRuntime.load_intent_quality_config."""
    return handler._intent_runtime.load_intent_quality_config()


def _validate_intent_enrichment(handler: DeriveHandler, intent: Any) -> None:
    """Delegate to IntentRuntime.validate_intent_enrichment."""
    handler._intent_runtime.validate_intent_enrichment(intent)


def _format_intent_for_prompt(handler: DeriveHandler, intent: Any) -> str:
    """Delegate to IntentRuntime.format_intent_for_prompt."""
    return handler._intent_runtime.format_intent_for_prompt(intent)


def _emit_intent_summary(
    handler: DeriveHandler,
    intent: Any,
    enrichment_level: EnrichmentLevel | None,
) -> None:
    """Delegate to IntentRuntime.emit_intent_summary."""
    handler._intent_runtime.emit_intent_summary(intent, enrichment_level)


def _format_intent_summary_lines(
    intent: Any,
    *,
    max_items: int,
    enrichment_level: EnrichmentLevel | None,
) -> list[str]:
    """Static delegate to IntentRuntime.format_intent_summary_lines."""
    from obra.hybrid.handlers.derive._intent_runtime import IntentRuntime

    return IntentRuntime.format_intent_summary_lines(
        intent,
        max_items=max_items,
        enrichment_level=enrichment_level,
    )


def _extract_user_story_refs(text: str) -> list[str]:
    """Static delegate to IntentRuntime.extract_user_story_refs."""
    from obra.hybrid.handlers.derive._intent_runtime import IntentRuntime

    return IntentRuntime.extract_user_story_refs(text)


def _prompt_intent_approval(handler: DeriveHandler, intent: Any) -> bool:
    """Delegate to IntentRuntime.prompt_intent_approval."""
    return handler._intent_runtime.prompt_intent_approval(intent)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def execute_intent_stage(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
) -> None:
    """Execute the intent generation/loading stage of the derivation pipeline.

    Mutates *ctx* in place — writes ``intent_model``, ``intent_content``,
    ``intent_enrichment``, ``planner``, ``scaffolded_active``, ``scaffolded_run``,
    and ``stage_timings``.

    Args:
        handler: The DeriveHandler instance (provides config, services, etc.)
        ctx: Mutable pipeline state carrier.
        request: The incoming DeriveRequest.
    """
    from obra.hybrid.handlers import derive as derive_package
    from obra.utils.terminal import is_headless

    # Generate and save intent for all input types (S2.T1)
    # Intent is now generated via LLM for all source types, not just unstructured inputs.
    # This ensures consistent Intent model population regardless of whether input is
    # unstructured text or a structured YAML plan file (machine_plan_import).
    if request.intent_ready:
        ctx.intent_model = handler._load_active_intent()
        if ctx.intent_model is None:
            logger.warning("Intent-ready derivation: no active intent found")
        else:
            validator_constraints: list[str] = []
            if isinstance(request.constraints, dict):
                raw_constraints = request.constraints.get("validator_constraints")
                if isinstance(raw_constraints, list):
                    validator_constraints = [str(c) for c in raw_constraints if c]
            if validator_constraints:
                ctx.intent_model.constraints = list(
                    dict.fromkeys(ctx.intent_model.constraints + validator_constraints)
                )
                from obra.intent.storage import IntentStorage

                storage = IntentStorage()
                storage.save(ctx.intent_model)
            ctx.intent_content = handler._format_intent_for_prompt(ctx.intent_model)
    elif not handler._skip_intent:
        intent_mode = IntentMode.FULL
        if ctx.pre_filter_result and ctx.pre_filter_result.is_trivial:
            intent_mode = IntentMode.LIGHT
        sizing_enabled = bool(
            handler._config.get("derivation", {}).get("sizing", {}).get("enabled", False)
        )
        if sizing_enabled and handler._log_event:
            handler._log_event(
                "intent_mode_selected",
                mode=intent_mode.value,
                reason=(
                    "pre_filter_trivial"
                    if intent_mode == IntentMode.LIGHT
                    else "pre_filter_uncertain"
                ),
            )

        ctx.intent_content, ctx.intent_enrichment, ctx.intent_model = (
            handler._generate_and_save_intent(
                request.objective,
                ctx.input_type,
                mode=intent_mode,
            )
        )

        # ISSUE-HYBRID-004: Check intent quality after enrichment
        # If enriched intent is still poor quality, reject with guidance
        if ctx.intent_model is not None:
            handler._check_intent_quality(ctx.intent_model)

    # --- Sizing gate (runs between intent and scaffolding) ---
    _run_sizing_gate(handler, ctx)

    # Load active intent for prompt injection (S2.T2)
    if ctx.intent_model is None:
        ctx.intent_model = handler._load_active_intent()
    if ctx.intent_content is None and ctx.intent_model is not None:
        ctx.intent_content = handler._format_intent_for_prompt(ctx.intent_model)

    if ctx.intent_model is None:
        logger.debug("Scaffolding skipped: intent_model is None")
    if ctx.intent_model is not None and not request.intent_ready:
        ctx.planner = derive_package.IntentEnricher(
            handler._working_dir,
            llm_config=handler._llm_config,
            on_stream=handler._on_stream,
            on_progress=handler._on_progress,
            log_event=handler._log_event,
            trace_id=handler._trace_id,
            parent_span_id=handler._parent_span_id,
        )
        ctx.scaffolded_active = ctx.planner.should_run(
            ctx.input_type,
            force=handler._force_scaffolded,
            skip=handler._skip_scaffolded,
        )
        logger.debug(
            "Scaffolding decision: active=%s, enabled=%s, force=%s, skip=%s",
            ctx.scaffolded_active,
            ctx.planner.is_enabled(),
            handler._force_scaffolded,
            handler._skip_scaffolded,
        )
        if ctx.scaffolded_active:
            try:
                # Get skip flags from sizing guidance (FEAT-SIZING-GATE-001)
                skip_analogues = (
                    ctx.sizing_guidance.skip_analogues if ctx.sizing_guidance else False
                )
                skip_brief = (
                    ctx.sizing_guidance.skip_brief if ctx.sizing_guidance else False
                )
                ctx.intent_model, diff_path = ctx.planner.run(
                    request.objective,
                    ctx.intent_model,
                    interactive=not is_headless(),
                    skip_analogues=skip_analogues,
                    skip_brief=skip_brief,
                )
                ctx.intent_content = _format_intent_for_prompt(handler, ctx.intent_model)
                ctx.scaffolded_run = True
                if ctx.planner:
                    for result in ctx.planner.get_last_stage_results():
                        base_name = result.name.split("_pass_")[0]
                        ctx.stage_timings[base_name] = (
                            ctx.stage_timings.get(base_name, 0.0) + result.duration_s
                        )
                if diff_path and handler._on_stream:
                    handler._on_stream(
                        "scaffolded_intent",
                        f"diff_path={diff_path}",
                    )
            except Exception as exc:
                logger.warning("Scaffolded intent enrichment failed: %s", exc)


def check_intent_fallback_path(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
    derivation_start_time: float,
) -> dict[str, Any] | None:
    """Check if intent enrichment failed and return a fallback result if so.

    FIX-DERIVE-HANG-001: Skip LLM derivation when intent enrichment failed
    completely. When enrichment is NONE, the LLM returned garbage and we're
    using a minimal fallback. Attempting LLM derivation with minimal context is
    likely to fail or produce poor results. Return composite fallback directly
    to avoid cascading failures and potential hangs.

    Returns:
        A result dict if the fallback path was taken, else ``None``.
    """
    from time import perf_counter

    from obra.hybrid.handlers.derive._execute_context import discover_verification_tools
    from obra.hybrid.handlers.derive._execute_llm import build_composite_fallback

    if ctx.intent_enrichment == EnrichmentLevel.NONE and not ctx.scaffolded_run:
        logger.warning(
            "Skipping LLM derivation due to NONE intent enrichment - using composite fallback"
        )
        print_warning("Intent enrichment failed. Using simplified single-task plan.")
        fallback_plan_items = build_composite_fallback(handler, request.objective)
        fallback_plan_items = handler._sanitizer.sanitize(
            fallback_plan_items,
            userplan_steps=request.userplan_steps,
        )
        composite_plan_items = handler._closeout.inject(
            fallback_plan_items,
            objective=request.objective,
            project_context=request.project_context,
            userplan_steps=request.userplan_steps,
            sizing_guidance=ctx.sizing_guidance,
        )
        # Log derivation complete for fallback path (FEAT-USERPLAN-002 S3)
        if handler._production_logger:
            duration_ms = (perf_counter() - derivation_start_time) * 1000
            handler._production_logger.log_derivation_complete(
                work_unit_id=request.userplan_id,
                item_count=len(composite_plan_items),
                duration_ms=duration_ms,
                work_type="fallback",
            )
        # S0.T7: Include verification tools in fallback path
        verification_tools = discover_verification_tools(handler)
        return {
            "plan_items": composite_plan_items,
            "raw_response": "",
            "verification_tools": verification_tools,  # S0.T7
            "plan_repair_attempt_history": [],
        }
    return None


# ---------------------------------------------------------------------------
# Internal: sizing gate (called within intent stage)
# ---------------------------------------------------------------------------


def _run_sizing_gate(handler: DeriveHandler, ctx: DerivationContext) -> None:
    """Run the sizing gate between intent and scaffolding.

    This was originally inline in ``_execute_derivation``. Extracted here because
    it sits between intent generation and the scaffolding decision, logically part
    of the intent stage.
    """
    from time import perf_counter

    from obra.hybrid.derivation.mission_complexity import SizeClass, SizingGuidance

    sizing_enabled = bool(
        handler._config.get("derivation", {}).get("sizing", {}).get("enabled", False)
    )

    if sizing_enabled:
        if ctx.pre_filter_result and ctx.pre_filter_result.is_trivial:
            trivial_guidance = (
                handler._config.get("derivation", {})
                .get("sizing", {})
                .get("guidance", {})
                .get("trivial", {})
            )
            ctx.sizing_guidance = SizingGuidance(
                size_class=SizeClass.TRIVIAL,
                description=str(trivial_guidance.get("description", "")),
                scope=str(trivial_guidance.get("scope", "")),
                use_single_shot=bool(trivial_guidance.get("use_single_shot", True)),
                rationale="pre-filter trivial",
                method="pre_filter",
            )
        elif ctx.intent_model is not None:
            sizing_pipeline = handler._build_sizing_pipeline("sizing_gate")
            handler._emit_progress(
                "planning_stage_started",
                {"stage": "sizing_gate", "user_label": "Sizing complexity"},
            )
            sizing_start = perf_counter()
            ctx.sizing_guidance = handler._run_async(
                handler._sizing_gate.assess(ctx.intent_model, sizing_pipeline)
            )
            sizing_duration = perf_counter() - sizing_start
            summary = None
            if ctx.sizing_guidance:
                summary = (
                    "Sizing gate: "
                    f"{ctx.sizing_guidance.size_class.value} → "
                    f"planning mode {ctx.sizing_guidance.planning_mode.value}"
                )
            handler._emit_progress(
                "planning_stage_completed",
                {
                    "stage": "sizing_gate",
                    "user_label": "Sizing complexity",
                    "duration_s": sizing_duration,
                    "summary": summary,
                },
            )
        else:
            logger.warning("Sizing gate skipped: intent model unavailable")

        if ctx.sizing_guidance and handler._log_event:
            handler._log_event(
                "sizing_gate_result",
                size_class=ctx.sizing_guidance.size_class.value,
                rationale=ctx.sizing_guidance.rationale,
                method=ctx.sizing_guidance.method,
            )

    # Log sizing-based routing (FEAT-SIZING-GATE-001)
    # Routing is now driven by LLM sizing gate, not heuristic
    if ctx.sizing_guidance:
        logger.info(
            "Sizing gate: %s -> %s mode",
            ctx.sizing_guidance.size_class.value,
            ctx.sizing_guidance.planning_mode.value,
        )
        handler._emit_detail_info(
            f"Planning mode: {ctx.sizing_guidance.planning_mode.value} "
            f"(size: {ctx.sizing_guidance.size_class.value})"
        )
        if handler._log_event:
            handler._log_event(
                "sizing_routing",
                size_class=ctx.sizing_guidance.size_class.value,
                planning_mode=ctx.sizing_guidance.planning_mode.value,
                skip_analogues=ctx.sizing_guidance.skip_analogues,
                skip_brief=ctx.sizing_guidance.skip_brief,
                validation_intensity=ctx.sizing_guidance.validation_intensity,
                rationale=ctx.sizing_guidance.rationale,
            )
