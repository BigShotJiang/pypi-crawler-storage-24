"""LLM invocation and response parsing for DeriveHandler._execute_derivation.

Extracted from _handler.py (Task 0.2, REFACTOR-SCHEMAS-P7-001).

This module owns LLM invocation, single-shot and hierarchical plan derivation,
fallback/extraction logic, response flattening, LLM config resolution, and
parse/retry event logging.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from time import perf_counter

from obra.config.llm import DEFAULT_REASONING_LEVEL
from obra.hybrid.derivation.cli_invoker import CLIInvoker, CLIInvokerConfig
from obra.hybrid.derivation.mission_complexity import SizingGuidance
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.llm.cli_runner import invoke_llm_via_cli

if TYPE_CHECKING:
    from obra.api.protocol import DeriveRequest
    from obra.hybrid.handlers.derive._context import DerivationContext
    from obra.hybrid.handlers.derive._handler import DeriveHandler, LLMInvocationParams

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Main entry point: LLM derivation dispatch
# ---------------------------------------------------------------------------


def run_llm_derivation(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
) -> None:
    """Run the LLM derivation stage (stage 3 of the pipeline).

    Determines derivation mode (single-shot vs three-step), dispatches to the
    appropriate LLM derivation function, and emits stage events and timings.
    Mutates *ctx* in place.

    Args:
        handler: The DeriveHandler instance.
        ctx: Mutable pipeline state carrier.
        request: The incoming DeriveRequest.
    """
    llm_params = ctx.last_derivation_llm
    provider = llm_params.provider if llm_params else ""
    model = llm_params.model if llm_params else ""
    reasoning_level = llm_params.reasoning_level if llm_params else DEFAULT_REASONING_LEVEL
    auth_method = llm_params.auth_method if llm_params else "oauth"
    stage_timeout_s = llm_params.timeout_s if llm_params else None

    hierarchical_enabled = handler._sanitizer.is_hierarchical_enabled()
    use_single_shot = bool(ctx.sizing_guidance and ctx.sizing_guidance.use_single_shot)
    derivation_mode = (
        "single_shot" if use_single_shot or not hierarchical_enabled else "three_step"
    )
    if ctx.sizing_guidance and handler._log_event:
        handler._log_event(
            "derivation_mode",
            mode=derivation_mode,
            size_class=ctx.sizing_guidance.size_class.value,
        )

    if derivation_mode == "three_step":
        handler._emit_detail_info("Running derive stage... (unified 3-step pipeline)")
    else:
        handler._emit_detail_info("Running derive stage... (single-shot pipeline)")
    logger.info(
        "Derive stage config: provider=%s model=%s thinking=%s timeout_s=%s plan_hierarchy=%s",
        provider,
        model,
        reasoning_level or DEFAULT_REASONING_LEVEL,
        stage_timeout_s,
        hierarchical_enabled,
    )

    stage_context = {
        "provider": provider,
        "model": model,
        "reasoning_level": reasoning_level or DEFAULT_REASONING_LEVEL,
        "timeout_s": stage_timeout_s,
        "plan_hierarchy": hierarchical_enabled,
        "objective": request.objective if request else "",
    }
    handler._emit_planning_stage_started("derive", "Detailing plan")
    handler._emit_stage_started("derive", stage_context)
    derive_start = perf_counter()
    heartbeat_thread = handler._start_stage_heartbeat("derive")

    try:
        if ctx.normalized_inputs is not None:
            (
                ctx.plan_items,
                ctx.raw_response,
                ctx.parse_info,
                ctx.derivation_result,
                ctx.derived_workflow_artifact,
                ctx.baseline_evaluation,
                ctx.validation_report,
                ctx.operator_review_points,
                ctx.result_bundle,
            ) = handler._derive_workflow_candidate(
                request=request,
                ctx=ctx,
            )
            ctx.plan_items = handler._sanitizer.sanitize(
                ctx.plan_items, userplan_steps=request.userplan_steps
            )
        elif derivation_mode == "three_step":
            (
                ctx.plan_items,
                ctx.raw_response,
                ctx.parse_info,
                ctx.derivation_result,
            ) = handler._derive_hierarchical_plan(
                request=request,
                provider=provider,
                model=model,
                reasoning_level=reasoning_level,
                auth_method=auth_method,
                timeout_s=stage_timeout_s,
                strategic_prompt=ctx.enriched_prompt,
                intent_markdown=ctx.intent_content,
                exploration_context=ctx.exploration_markdown,
                sizing_guidance=ctx.sizing_guidance,
            )
            ctx.plan_items = handler._sanitizer.sanitize(
                ctx.plan_items, userplan_steps=request.userplan_steps
            )
            handler._log_parse_event(
                action="derive",
                provider=provider,
                model=model,
                parse_info=ctx.parse_info,
            )
        else:
            (
                ctx.plan_items,
                ctx.raw_response,
                ctx.parse_info,
                ctx.derivation_result,
            ) = handler._derive_single_shot(
                request=request,
                provider=provider,
                model=model,
                reasoning_level=reasoning_level,
                auth_method=auth_method,
                timeout_s=stage_timeout_s,
                strategic_prompt=ctx.enriched_prompt,
                sizing_guidance=ctx.sizing_guidance,
            )
    except Exception as exc:
        duration_ms = int((perf_counter() - derive_start) * 1000)
        if heartbeat_thread:
            heartbeat_thread.stop()
        handler._emit_stage_failed("derive", str(exc), duration_ms, stage_timeout_s)
        raise
    finally:
        if heartbeat_thread:
            heartbeat_thread.stop()

    derive_duration_ms = int((perf_counter() - derive_start) * 1000)
    ctx.stage_timings["derive"] = derive_duration_ms / 1000.0

    # Count items by type for completion summary
    epic_count = sum(1 for item in ctx.plan_items if item.get("item_type") == "epic")
    story_count = sum(1 for item in ctx.plan_items if item.get("item_type") == "story")
    task_count = sum(1 for item in ctx.plan_items if item.get("item_type") == "task")

    handler._emit_stage_completed(
        "derive",
        derive_duration_ms,
        result={
            "item_count": len(ctx.plan_items),
            "epic_count": epic_count,
            "story_count": story_count,
            "task_count": task_count,
        },
    )
    handler._emit_planning_stage_completed(
        "derive",
        "Detailing plan",
        derive_duration_ms / 1000.0,
        summary=f"Plan complete: {epic_count} Epics, {story_count} Stories, {task_count} Tasks",
    )

    # Emit plan snapshot immediately after derive (before validation stages)
    # This allows the UI to show the derived plan while validation runs
    handler._emit_progress(
        "plan_snapshot",
        {
            "source": "derive",
            "plan_items": ctx.plan_items,
            "plan_items_count": len(ctx.plan_items),
        },
    )


# ---------------------------------------------------------------------------
# LLM invocation
# ---------------------------------------------------------------------------


def invoke_llm(
    handler: DeriveHandler,
    prompt: str,
    llm_params: LLMInvocationParams,
) -> str:
    """Invoke LLM to generate plan.

    Args:
        handler: The DeriveHandler instance.
        prompt: Derivation prompt.
        llm_params: LLM invocation parameters (provider, model, reasoning_level, etc.)

    Returns:
        Raw LLM response.
    """
    logger.debug(
        "Invoking LLM via CLI: provider=%s model=%s thinking=%s auth=%s",
        llm_params.provider,
        llm_params.model,
        llm_params.reasoning_level,
        llm_params.auth_method,
    )

    def _stream(chunk: str) -> None:
        if handler._on_stream:
            handler._on_stream("llm_streaming", chunk)

    try:
        codex_config = cast(dict, handler._llm_config.get("codex", {}))
        bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
        approval_mode = codex_config.get("approval_mode")
        return str(
            invoke_llm_via_cli(
                prompt=prompt,
                cwd=handler._working_dir,
                provider=llm_params.provider,
                model=llm_params.model,
                reasoning_level=llm_params.reasoning_level,
                auth_method=llm_params.auth_method,
                on_stream=_stream if handler._on_stream else None,
                timeout_s=llm_params.timeout_s,
                log_event=handler._log_event,
                trace_id=handler._trace_id,
                parent_span_id=handler._parent_span_id,
                call_site="derive",
                monitoring_context=handler._monitoring_context,  # ISSUE-CLI-016/017 fix
                skip_git_check=handler._llm_config.get("git", {}).get(
                    "skip_check", True
                ),  # ISSUE-REVIEW-AGENTS-002: Default True
                bypass_sandbox=bypass_sandbox,
                approval_mode=approval_mode,
            )
        )
    except Exception as e:
        logger.exception("LLM invocation failed")
        msg = f"LLM invocation failed: {e!s}"
        raise RuntimeError(msg) from e


# ---------------------------------------------------------------------------
# Single-shot derivation
# ---------------------------------------------------------------------------


def derive_single_shot(
    handler: DeriveHandler,
    *,
    request: DeriveRequest,
    provider: str,
    model: str,
    reasoning_level: str | None,
    auth_method: str,
    timeout_s: int | None,
    strategic_prompt: str,
    sizing_guidance: SizingGuidance | None = None,
) -> tuple[list[dict[str, Any]], str, dict[str, Any], Any]:
    """Derive plan items using a single template edit call."""
    # max_retries defaults from handlers.template_edit.max_retries config
    pipeline = TemplateEditPipeline(
        working_dir=handler._working_dir,
        action_name="derive_single_shot",
        write_scope="safe_output_only",
        on_stream=None,
        log_event=handler._log_event,
        production_logger=handler._production_logger,
    )

    template_schema = {
        "epics": [],
        "_instructions": (
            "Add derivation plan to epics array. Each epic contains:\n"
            '- id (string): Epic identifier (e.g., "epic-1")\n'
            '- item_type (string): Must be "epic"\n'
            "- title (string): Epic title\n"
            "- description (string): Epic description\n"
            "- acceptance_criteria (array of strings): Success criteria\n"
            "- dependencies (array of strings): Epic IDs this depends on\n"
            "- stories (array of story objects): Child stories\n\n"
            "Each story contains:\n"
            '- id (string): Story identifier (e.g., "epic-1-story-1")\n'
            '- item_type (string): Must be "story"\n'
            "- title (string): Story title\n"
            "- description (string): Story description\n"
            "- acceptance_criteria (array of strings): Success criteria\n"
            "- dependencies (array of strings): Story IDs this depends on\n"
            "- tasks (array of task objects): Child tasks\n\n"
            "Each task contains:\n"
            '- id (string): Task identifier (e.g., "epic-1-story-1-task-1")\n'
            '- item_type (string): Must be "task"\n'
            "- title (string): Task title\n"
            "- description (string): Task description\n"
            "- acceptance_criteria (array of strings): Success criteria\n"
            "- dependencies (array of strings): Task IDs this depends on"
        ),
    }

    def validate_plan(data: dict) -> tuple[bool, str | None]:
        if "epics" not in data:
            return (False, "Missing epics field")

        if not isinstance(data["epics"], list):
            return (False, "epics field must be an array")

        required_epic_fields = {
            "id",
            "item_type",
            "title",
            "description",
            "acceptance_criteria",
            "dependencies",
            "stories",
        }
        required_story_fields = {
            "id",
            "item_type",
            "title",
            "description",
            "acceptance_criteria",
            "dependencies",
            "tasks",
        }
        required_task_fields = {
            "id",
            "item_type",
            "title",
            "description",
            "acceptance_criteria",
            "dependencies",
        }

        for i, epic in enumerate(data["epics"]):
            if not isinstance(epic, dict):
                return (False, f"Epic {i} is not an object")
            if not required_epic_fields.issubset(epic.keys()):
                missing = required_epic_fields - epic.keys()
                return (False, f"Epic {i} missing fields: {missing}")
            if epic.get("item_type") != "epic":
                return (
                    False,
                    f"Epic {i} has invalid item_type: {epic.get('item_type')}",
                )

            if not isinstance(epic.get("stories"), list):
                return (False, f"Epic {i} stories field must be an array")

            for j, story in enumerate(epic["stories"]):
                if not isinstance(story, dict):
                    return (False, f"Epic {i} Story {j} is not an object")
                if not required_story_fields.issubset(story.keys()):
                    missing = required_story_fields - story.keys()
                    return (False, f"Epic {i} Story {j} missing fields: {missing}")
                if story.get("item_type") != "story":
                    return (
                        False,
                        f"Epic {i} Story {j} has invalid item_type: {story.get('item_type')}",
                    )

                if not isinstance(story.get("tasks"), list):
                    return (
                        False,
                        f"Epic {i} Story {j} tasks field must be an array",
                    )

                for k, task in enumerate(story["tasks"]):
                    if not isinstance(task, dict):
                        return (
                            False,
                            f"Epic {i} Story {j} Task {k} is not an object",
                        )
                    if not required_task_fields.issubset(task.keys()):
                        missing = required_task_fields - task.keys()
                        return (
                            False,
                            f"Epic {i} Story {j} Task {k} missing fields: {missing}",
                        )
                    if task.get("item_type") != "task":
                        return (
                            False,
                            f"Epic {i} Story {j} Task {k} has invalid item_type: {task.get('item_type')}",
                        )

        return (True, None)

    def fallback() -> list:
        return build_composite_fallback(handler, objective=request.objective)

    llm_config = {
        "provider": provider,
        "model": model,
        "reasoning_level": reasoning_level,
        "auth": auth_method,
    }

    epics_data, metadata = pipeline.execute(
        base_prompt=strategic_prompt,
        template_content=template_schema,
        validator=validate_plan,
        fallback_fn=fallback,
        llm_config=llm_config,
        timeout_s=timeout_s,
        allow_unchanged=False,
    )

    if isinstance(epics_data, list) and epics_data and isinstance(epics_data[0], dict):
        plan_items = epics_data
    elif isinstance(epics_data, dict):
        flat_plan_items = epics_data.get("plan_items")
        if (
            isinstance(flat_plan_items, list)
            and flat_plan_items
            and isinstance(flat_plan_items[0], dict)
        ):
            plan_items = flat_plan_items
        elif "epics" in epics_data:
            plan_items = []
            for epic in epics_data.get("epics", []):
                # Extract user_story_ids from structured field or text fallback
                user_story_ids = []
                if "user_story_ids" in epic and isinstance(epic["user_story_ids"], list):
                    user_story_ids = epic["user_story_ids"]
                else:
                    # Fallback: scan description and acceptance_criteria
                    text_to_scan = epic.get("description", "")
                    if isinstance(epic.get("acceptance_criteria"), list):
                        text_to_scan += " " + " ".join(epic["acceptance_criteria"])
                    user_story_ids = extract_user_story_refs(text_to_scan)

                epic_item: dict[str, Any] = {
                    "id": epic["id"],
                    "item_type": epic["item_type"],
                    "title": epic["title"],
                    "description": epic["description"],
                    "acceptance_criteria": epic["acceptance_criteria"],
                    "dependencies": epic["dependencies"],
                    "parent_id": None,
                    "depth": 0,
                }
                # Only add context with user_story_ids if non-empty
                if user_story_ids:
                    epic_item["context"] = {"user_story_ids": user_story_ids}
                plan_items.append(epic_item)

                for story in epic.get("stories", []):
                    # Extract user_story_ids from structured field or text fallback
                    story_user_story_ids = []
                    if "user_story_ids" in story and isinstance(story["user_story_ids"], list):
                        story_user_story_ids = story["user_story_ids"]
                    else:
                        # Fallback: scan description and acceptance_criteria
                        story_text = story.get("description", "")
                        if isinstance(story.get("acceptance_criteria"), list):
                            story_text += " " + " ".join(story["acceptance_criteria"])
                        story_user_story_ids = extract_user_story_refs(story_text)

                    story_item: dict[str, Any] = {
                        "id": story["id"],
                        "item_type": story["item_type"],
                        "title": story["title"],
                        "description": story["description"],
                        "acceptance_criteria": story["acceptance_criteria"],
                        "dependencies": story["dependencies"],
                        "parent_id": epic["id"],
                        "depth": 1,
                    }
                    # Only add context with user_story_ids if non-empty
                    if story_user_story_ids:
                        story_item["context"] = {"user_story_ids": story_user_story_ids}
                    plan_items.append(story_item)

                    for task in story.get("tasks", []):
                        # Extract user_story_ids from structured field or text fallback
                        task_user_story_ids = []
                        if "user_story_ids" in task and isinstance(task["user_story_ids"], list):
                            task_user_story_ids = task["user_story_ids"]
                        else:
                            # Fallback: scan description and acceptance_criteria
                            task_text = task.get("description", "")
                            if isinstance(task.get("acceptance_criteria"), list):
                                task_text += " " + " ".join(task["acceptance_criteria"])
                            task_user_story_ids = extract_user_story_refs(task_text)

                        task_item: dict[str, Any] = {
                            "id": task["id"],
                            "item_type": task["item_type"],
                            "title": task["title"],
                            "description": task["description"],
                            "acceptance_criteria": task["acceptance_criteria"],
                            "dependencies": task["dependencies"],
                            "parent_id": story["id"],
                            "depth": 2,
                        }
                        # Only add context with user_story_ids if non-empty
                        if task_user_story_ids:
                            task_item["context"] = {"user_story_ids": task_user_story_ids}
                        plan_items.append(task_item)
        else:
            plan_items = fallback()
    else:
        plan_items = fallback()

    plan_items = handler._sanitizer.sanitize(plan_items, userplan_steps=request.userplan_steps)

    return plan_items, "", metadata, None


# ---------------------------------------------------------------------------
# Hierarchical derivation
# ---------------------------------------------------------------------------


def derive_hierarchical_plan(
    handler: DeriveHandler,
    *,
    request: DeriveRequest,
    provider: str,
    model: str,
    reasoning_level: str,
    auth_method: str,
    timeout_s: int | None,
    strategic_prompt: str,
    intent_markdown: str | None,
    exploration_context: str | None,
    sizing_guidance: SizingGuidance | None = None,
) -> tuple[list[dict[str, Any]], str, dict[str, Any], Any]:
    """Derive hierarchical plan items using the CLI-backed derivation engine."""
    from obra.execution.derivation import DerivationEngine

    codex_config = cast(dict, handler._llm_config.get("codex", {}))
    bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
    approval_mode = codex_config.get("approval_mode")

    # BUG-DERIVE-STALL-001: Adapt two-argument on_stream callback to single-argument
    # DeriveHandler._on_stream expects (stage, chunk) but subprocess_runner expects (line)
    def stream_adapter(line: str) -> None:
        if handler._on_stream:
            handler._on_stream("derive_streaming", line)

    invoker_config = CLIInvokerConfig(
        cwd=Path(handler._working_dir),
        model=model,
        auth_method=auth_method,
        reasoning_level=reasoning_level,
        timeout_s=timeout_s,
        on_stream=stream_adapter if handler._on_stream else None,
        log_event=handler._log_event,
        trace_id=handler._trace_id,
        parent_span_id=handler._parent_span_id,
        skip_git_check=handler._llm_config.get("git", {}).get("skip_check", True),
        bypass_sandbox=bypass_sandbox,
        approval_mode=approval_mode,
        monitoring_context=handler._monitoring_context,
    )
    engine = DerivationEngine(
        working_dir=Path(handler._working_dir),
        llm_invoker=cast(Any, CLIInvoker(invoker_config)),
        thinking_enabled=bool(reasoning_level),
        reasoning_level=reasoning_level,
        domain=handler._domain,
    )
    # Get validation_intensity from sizing guidance (FEAT-SIZING-GATE-001)
    validation_intensity = (
        sizing_guidance.validation_intensity if sizing_guidance else "light"
    )
    merged_constraints: dict[str, Any] = {}
    if isinstance(request.constraints, dict):
        merged_constraints.update(request.constraints)
    merged_constraints.setdefault("hierarchy", {"enabled": True})

    result = engine.derive(
        objective=request.objective,
        project_context=request.project_context or {},
        constraints=merged_constraints,
        provider=provider,
        strategic_prompt=strategic_prompt,
        intent_markdown=intent_markdown,
        exploration_context=exploration_context,
        progress_callback=handler._emit_progress,
        validation_intensity=validation_intensity,
    )
    if not result.success:
        raise RuntimeError(result.error_message or "Hierarchical derivation failed")
    parse_info = {
        "status": "hierarchical_engine",
        "response_length": len(result.raw_response),
    }
    return result.plan_items, result.raw_response, parse_info, result


# ---------------------------------------------------------------------------
# Fallback / extraction
# ---------------------------------------------------------------------------


def fallback_with_extraction(
    handler: DeriveHandler,
    raw_response: str,
    parse_info: dict[str, Any],
    objective: str | None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Return composite fallback task when JSON parsing fails.

    FIX-DERIVE-HANG-001: Removed LLM extraction fallback.

    Previously this method attempted LLM-based structure extraction using a
    "fast" tier model, which could hang for up to 600s (default timeout).
    The extraction had low success probability since it used a weaker model
    to extract structure from a response that a better model failed to produce.

    Now returns composite fallback directly - deterministic, instant, no network call.
    The composite fallback (single task with objective) works well for LLM agents
    who can decompose during execution.
    """
    # Log that we're using composite fallback (for observability)
    parse_info["extraction_attempted"] = False
    parse_info["extraction_succeeded"] = False
    parse_info["status"] = "composite_fallback"

    logger.info("JSON parsing failed - using composite fallback (extraction disabled)")
    return build_composite_fallback(handler, objective), parse_info


def build_composite_fallback(handler: DeriveHandler, objective: str | None) -> list[dict[str, Any]]:
    """Return a single composite task when structure recovery fails."""
    objective_text = (objective or "").strip() or "Implement the requested objective"
    return [
        {
            "id": "T1",
            "item_type": "task",
            "title": "Implement objective",
            "description": objective_text,
            "acceptance_criteria": [
                "Objective is implemented end-to-end",
                "Quality gates (tests, lint, type checks) updated as needed",
            ],
            "dependencies": [],
        }
    ]


# ---------------------------------------------------------------------------
# Response coercion / flattening
# ---------------------------------------------------------------------------


def coerce_list_to_epics(
    handler: DeriveHandler,
    items: list[Any],
    *,
    objective: str | None,
    parse_info: dict[str, Any],
) -> tuple[list[Any], dict[str, Any]]:
    """Coerce flat list responses into epic/story hierarchy when required."""
    if not items:
        return items, parse_info

    if not handler._sanitizer.is_hierarchical_enabled():
        return items, parse_info

    def _is_epic(candidate: Any) -> bool:
        return isinstance(candidate, dict) and (
            candidate.get("item_type") == "epic" or "stories" in candidate
        )

    def _is_story(candidate: Any) -> bool:
        return isinstance(candidate, dict) and (
            candidate.get("item_type") == "story" or "tasks" in candidate
        )

    if any(_is_epic(item) for item in items):
        return items, parse_info

    objective_title = (objective or "").strip() or "Implementation"
    epic_stub = {
        "id": "E1",
        "item_type": "epic",
        "title": objective_title,
        "description": objective_title,
    }

    if any(_is_story(item) for item in items):
        parse_info["coerced_list"] = "stories"
        return [{**epic_stub, "stories": items}], parse_info

    parse_info["coerced_list"] = "tasks"
    story = {
        "id": "S1",
        "item_type": "story",
        "title": "Implementation plan",
        "description": "Implement the objective in focused tasks.",
        "tasks": items,
    }
    return [{**epic_stub, "stories": [story]}], parse_info


def flatten_epic_tree(handler: DeriveHandler, epics: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Flatten epics -> stories -> tasks -> subtasks into plan_items."""
    items: list[dict[str, Any]] = []
    for epic_idx, epic in enumerate(epics, start=1):
        if not isinstance(epic, dict):
            continue
        epic_id = epic.get("id", f"E{epic_idx}")
        epic_title = epic.get("title", f"Epic {epic_idx}")
        epic_desc = epic.get("description", epic_title) or epic_title
        items.append(
            {
                "id": epic_id,
                "item_type": epic.get("item_type", "epic"),
                "title": epic_title,
                "description": epic_desc,
                "acceptance_criteria": epic.get("acceptance_criteria", []),
                "dependencies": epic.get("dependencies", []),
                "parent_id": None,
                "depth": 0,
            }
        )
        stories = epic.get("stories", [])
        if not isinstance(stories, list):
            continue
        items.extend(flatten_story_tree(handler, stories, parent_id=epic_id, depth=1))
    return items


def flatten_story_tree(
    handler: DeriveHandler,
    stories: list[dict[str, Any]],
    parent_id: str | None = None,
    depth: int = 0,
) -> list[dict[str, Any]]:
    """Flatten story -> task -> subtask hierarchy into plan_items."""
    items: list[dict[str, Any]] = []
    for story_idx, story in enumerate(stories, start=1):
        if not isinstance(story, dict):
            continue
        story_id = story.get("id", f"S{story_idx}")
        story_title = story.get("title", f"Story {story_idx}")
        story_desc = story.get("description", story_title) or story_title
        items.append(
            {
                "id": story_id,
                "item_type": story.get("item_type", "story"),
                "title": story_title,
                "description": story_desc,
                "acceptance_criteria": story.get("acceptance_criteria", []),
                "dependencies": story.get("dependencies", []),
                "parent_id": parent_id,
                "depth": depth,
            }
        )
        tasks = story.get("tasks", [])
        if not isinstance(tasks, list):
            continue
        for task_idx, task in enumerate(tasks, start=1):
            if not isinstance(task, dict):
                continue
            task_id = task.get("id", f"{story_id}.T{task_idx}")
            task_title = task.get("title", f"Task {story_id}.{task_idx}")
            task_desc = task.get("description", task_title) or task_title
            items.append(
                {
                    "id": task_id,
                    "item_type": task.get("item_type", "task"),
                    "title": task_title,
                    "description": task_desc,
                    "acceptance_criteria": task.get("acceptance_criteria", []),
                    "dependencies": task.get("dependencies", []),
                    "parent_id": story_id,
                    "depth": depth + 1,
                }
            )
            subtasks = task.get("subtasks", [])
            if not isinstance(subtasks, list):
                continue
            for sub_idx, subtask in enumerate(subtasks, start=1):
                if not isinstance(subtask, dict):
                    continue
                sub_id = subtask.get("id", f"{task_id}.{sub_idx}")
                sub_title = subtask.get("title", f"Subtask {sub_id}")
                sub_desc = subtask.get("description", sub_title) or sub_title
                items.append(
                    {
                        "id": sub_id,
                        "item_type": subtask.get("item_type", "subtask"),
                        "title": sub_title,
                        "description": sub_desc,
                        "acceptance_criteria": subtask.get("acceptance_criteria", []),
                        "dependencies": subtask.get("dependencies", []),
                        "parent_id": task_id,
                        "depth": depth + 2,
                    }
                )
    return items


# ---------------------------------------------------------------------------
# LLM config resolution
# ---------------------------------------------------------------------------


def resolve_scaffolded_stage_llm(
    handler: DeriveHandler,
    stage_config: dict[str, Any],
    provider: str,
) -> tuple[str, str, str, str, int, int]:
    """Delegate to DeriveLLMResolver.resolve_scaffolded_stage_llm."""
    return handler._llm_resolver.resolve_scaffolded_stage_llm(stage_config, provider)


def resolve_derive_llm_config(handler: DeriveHandler) -> dict[str, Any]:
    """Delegate to DeriveLLMResolver.resolve_derive_llm_config."""
    return handler._llm_resolver.resolve_derive_llm_config()


# ---------------------------------------------------------------------------
# Parse/retry event logging
# ---------------------------------------------------------------------------


def log_parse_event(
    handler: DeriveHandler,
    *,
    action: str,
    provider: str,
    model: str,
    parse_info: dict[str, Any],
) -> None:
    """Log a hybrid parse result event."""
    if not handler._log_event:
        return
    try:
        handler._log_event(
            "hybrid_parse_result",
            action=action,
            provider=provider,
            model=model,
            status=parse_info.get("status"),
            used_extraction=parse_info.get("used_extraction", False),
            extraction_attempted=parse_info.get("extraction_attempted", False),
            extraction_succeeded=parse_info.get("extraction_succeeded", False),
            retried=parse_info.get("retried", False),
            response_length=parse_info.get("response_length", 0),
        )
    except Exception as e:
        logger.debug("Failed to log hybrid parse event: %s", e)


def log_retry_event(
    handler: DeriveHandler,
    *,
    action: str,
    provider: str,
    model: str,
    attempt: int,
    reason: str,
) -> None:
    """Log a hybrid parse retry event."""
    if not handler._log_event:
        return
    try:
        handler._log_event(
            "hybrid_parse_retry",
            action=action,
            provider=provider,
            model=model,
            attempt=attempt,
            reason=reason,
        )
    except Exception as e:
        logger.debug("Failed to log hybrid retry event: %s", e)


# ---------------------------------------------------------------------------
# User story ref extraction (used by single-shot flattening)
# ---------------------------------------------------------------------------


def extract_user_story_refs(text: str) -> list[str]:
    """Static delegate to IntentRuntime.extract_user_story_refs."""
    from obra.hybrid.handlers.derive._intent_runtime import IntentRuntime

    return IntentRuntime.extract_user_story_refs(text)
