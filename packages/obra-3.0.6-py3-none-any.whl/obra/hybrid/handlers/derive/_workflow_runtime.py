"""Workflow-derivation runtime helpers for the derive handler."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from obra.api.protocol import DeriveRequest
from obra.hybrid.handlers.derive._context import DerivationContext
from obra.workflow.derivation import (
    build_execution_plan_view,
    derive_or_enhance_workflow,
    resolve_domain_derivation_metadata,
)
from obra.workflow.derivation_contract import normalize_derivation_request


def _handler_attr(name: str, default: Any) -> Any:
    module = sys.modules.get("obra.hybrid.handlers.derive._handler")
    if module is None:
        return default
    return getattr(module, name, default)


class WorkflowDerivationRuntime:
    """Owns workflow derivation normalization and candidate generation."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner

    def normalize_workflow_derivation_inputs(
        self,
        request: DeriveRequest,
    ) -> dict[str, Any] | None:
        workflow_request = request.workflow_derivation_request
        if not isinstance(workflow_request, dict):
            return None

        self._owner._emit_progress(
            "workflow_derivation_stage_started",
            {"stage": "D1", "label": "Intake and normalization"},
        )
        normalized = normalize_derivation_request(
            workflow_request,
            objective=request.objective,
            domain_id=(
                getattr(self._owner._domain, "name", "")
                or (
                    request.project_context.get("domain")
                    if isinstance(request.project_context, dict)
                    else ""
                )
            ),
        )
        payload = normalized.to_dict()
        self._owner._emit_progress(
            "workflow_derivation_stage_completed",
            {
                "stage": "D1",
                "label": "Intake and normalization",
                "domain_id": payload["domain_id"],
                "provenance_by_field": payload["provenance_by_field"],
            },
        )
        return payload

    def resolve_workflow_domain_framing(
        self,
        normalized_inputs: dict[str, Any],
    ) -> dict[str, Any]:
        self._owner._emit_progress(
            "workflow_derivation_stage_started",
            {"stage": "D2", "label": "Domain framing"},
        )
        metadata = resolve_domain_derivation_metadata(
            self._owner._domain,
            domain_id=str(normalized_inputs.get("domain_id", "") or ""),
        ).to_dict()
        self._owner._emit_progress(
            "workflow_derivation_stage_completed",
            {
                "stage": "D2",
                "label": "Domain framing",
                "domain_id": metadata["domain_id"],
                "fallback_work_type": metadata["fallback_work_type"],
                "quality_dimensions": [
                    dimension.get("id")
                    for dimension in metadata.get("quality_dimensions", [])
                ],
            },
        )
        return metadata

    def derive_workflow_candidate(
        self,
        *,
        request: DeriveRequest,
        ctx: DerivationContext,
    ) -> tuple[
        list[dict[str, Any]],
        str,
        dict[str, Any],
        Any,
        dict[str, Any] | None,
        dict[str, Any] | None,
        dict[str, Any] | None,
        list[dict[str, Any]],
        dict[str, Any] | None,
    ]:
        """Derive candidate W2 and convert it into the execution-facing plan view."""
        derive_workflow = _handler_attr("derive_or_enhance_workflow", derive_or_enhance_workflow)
        bundle = derive_workflow(
            normalized_inputs=ctx.normalized_inputs or {},
            domain_metadata=ctx.domain_derivation_metadata or {},
            working_dir=Path(self._owner._working_dir),
            strategic_prompt=None,
            intent_markdown=ctx.intent_content,
            exploration_context=ctx.exploration_markdown,
            on_stream=self._owner._build_stream_adapter("llm_streaming"),
            log_event=self._owner._log_event,
            production_logger=self._owner._production_logger,
        )
        plan_items = build_execution_plan_view(
            result_bundle=bundle,
            userplan_id=request.userplan_id,
            userplan_steps=request.userplan_steps,
        )
        bundle_payload = bundle.to_dict()
        artifact_payload = bundle_payload.get("derived_workflow_artifact")
        raw_response = json.dumps(bundle_payload, ensure_ascii=False, default=str)
        parse_info = {
            "status": "workflow_derivation",
            "response_length": len(raw_response),
            "plan_items_count": len(plan_items),
        }
        return (
            plan_items,
            raw_response,
            parse_info,
            None,
            artifact_payload,
            bundle.baseline_evaluation.to_dict(),
            bundle.validation_report.to_dict(),
            list(bundle.operator_review_points),
            bundle_payload,
        )
