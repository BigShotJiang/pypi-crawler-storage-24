"""Story 0 prerequisite derivation stage for DeriveHandler."""

from __future__ import annotations

import logging
from time import perf_counter
from typing import TYPE_CHECKING, Any

from obra.config.llm import DEFAULT_REASONING_LEVEL, resolve_action_llm_config
from obra.config.loaders import get_story0_model_tier
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.models.story0_state import PrerequisiteCategory, PrerequisiteSource
from obra.prompts.story0.prerequisites import build_story0_derivation_prompt

if TYPE_CHECKING:
    from obra.api.protocol import DeriveRequest
    from obra.hybrid.handlers.derive._context import DerivationContext
    from obra.hybrid.handlers.derive._handler import DeriveHandler

logger = logging.getLogger(__name__)


def maybe_derive_story0_prerequisites(
    handler: DeriveHandler,
    ctx: DerivationContext,
    request: DeriveRequest,
) -> list[dict[str, Any]]:
    """Optionally derive Story 0 prerequisites from the finalized plan."""
    if request.skip_story0:
        return []

    try:
        from obra.config.loaders import load_layered_config

        config, _, _ = load_layered_config(include_defaults=True)
        story0_config = config.get("story0", {})
    except Exception as exc:
        logger.warning("Failed to load Story 0 config: %s", exc)
        story0_config = {}

    if not story0_config.get("enabled", True):
        return []

    story0_start = perf_counter()
    try:
        story0_prerequisites = derive_story0(
            handler,
            ctx.plan_items,
            request.objective,
        )
        elapsed_ms = int((perf_counter() - story0_start) * 1000)
        logger.info(
            "Story 0 derivation completed in %dms, found %d prerequisites",
            elapsed_ms,
            len(story0_prerequisites),
        )
        return story0_prerequisites
    except Exception as exc:
        logger.warning(
            "Story 0 derivation failed: %s, proceeding with empty prerequisites",
            exc,
        )
        return []


def derive_story0(
    handler: DeriveHandler,
    plan_items: list[dict[str, Any]],
    objective: str,
) -> list[dict[str, Any]]:
    """Derive Story 0 prerequisites from the final plan items."""
    manifest_type, manifest_path = handler._detect_primary_manifest()
    existing_deps = handler._extract_manifest_dependencies(
        manifest_type,
        manifest_path,
    )

    prompt = build_story0_derivation_prompt(
        plan={"plan_items": plan_items},
        objective=objective,
        manifest_type=manifest_type,
        existing_deps=existing_deps,
        working_dir=str(handler._working_dir),
    )

    story0_tier = get_story0_model_tier()
    story0_llm_config = resolve_action_llm_config("derive", model_tier=story0_tier)
    story0_llm = {
        "provider": story0_llm_config.get("provider", "anthropic"),
        "model": story0_llm_config.get("model", "opus"),
        "reasoning_level": story0_llm_config.get(
            "reasoning_level",
            DEFAULT_REASONING_LEVEL,
        ),
        "auth": story0_llm_config.get("auth_method", "oauth"),
    }

    pipeline = TemplateEditPipeline(
        working_dir=handler._working_dir,
        action_name="story0_derivation",
        write_scope="safe_output_only",
        on_stream=None,
        log_event=handler._log_event,
        production_logger=handler._production_logger,
    )

    allowed_categories = {category.value for category in PrerequisiteCategory}
    allowed_sources = {source.value for source in PrerequisiteSource}
    template_schema = {
        "prerequisites": [],
        "_instructions": (
            "Populate prerequisites with required fields:\n"
            "- id (string)\n"
            "- name (string)\n"
            f"- category (one of {sorted(allowed_categories)})\n"
            f"- source (one of {sorted(allowed_sources)})\n"
            "- reason (string)\n"
            "Return empty prerequisites list if none are needed."
        ),
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        if not isinstance(data, dict):
            return False, "Result must be an object"
        prerequisites = data.get("prerequisites")
        if not isinstance(prerequisites, list):
            return False, "Missing or invalid prerequisites list"
        for idx, entry in enumerate(prerequisites):
            if not isinstance(entry, dict):
                return False, f"Prerequisite {idx} must be an object"
            for key in ("id", "name", "category", "source", "reason"):
                value = entry.get(key)
                if not isinstance(value, str) or not value.strip():
                    return False, f"Prerequisite {idx} missing {key}"
            raw_category = entry.get("category", "").strip().upper()
            raw_source = entry.get("source", "").strip().upper()
            if raw_category not in allowed_categories:
                return False, f"Prerequisite {idx} invalid category {raw_category}"
            if raw_source not in allowed_sources:
                return False, f"Prerequisite {idx} invalid source {raw_source}"
            entry["category"] = raw_category
            entry["source"] = raw_source
        return True, None

    def fallback() -> dict[str, Any]:
        return {"prerequisites": []}

    data, _meta = pipeline.execute(
        base_prompt=prompt,
        template_content=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config=story0_llm,
    )

    prerequisites = data.get("prerequisites", []) if isinstance(data, dict) else []
    if not isinstance(prerequisites, list):
        logger.warning("Story 0 prerequisites is not a list")
        return []

    manifest_count = sum(
        1 for item in prerequisites if item.get("source") == "MANIFEST"
    )
    inferred_count = sum(
        1 for item in prerequisites if item.get("source") == "INFERRED"
    )
    logger.info(
        "Story 0 prerequisites parsed: %d total (%d manifest, %d inferred)",
        len(prerequisites),
        manifest_count,
        inferred_count,
    )
    return prerequisites
