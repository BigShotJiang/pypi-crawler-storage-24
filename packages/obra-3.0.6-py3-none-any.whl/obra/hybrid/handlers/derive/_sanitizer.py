"""PlanSanitizer: plan item normalization and hierarchy validation for derivation."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any

from obra.execution.derivation import MAX_DERIVATION_DEPTH

logger = logging.getLogger(__name__)


class PlanSanitizer:
    """Normalises plan items and validates hierarchy.

    Owns four concerns:
    - sanitize(): coerce item_type, fill required fields, propagate parent context,
      enforce depth limits, strip container dependency edges.
    - _propagate_context(): context inheritance from parent to child (used by sanitize).
    - validate_hierarchy(): structural validation of epic/story/task/subtask relationships.
    - is_hierarchical_enabled(): config flag reader for hierarchical derivation mode.

    Constructor receives the loaded config dict (read once by DeriveHandler.__init__).
    No side effects or I/O beyond logging.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        """Initialise PlanSanitizer.

        Args:
            config: Loaded layered config dict (from load_layered_config).
        """
        self._config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sanitize(
        self,
        plan_items: list[dict[str, Any]],
        *,
        parent_item: dict[str, Any] | None = None,
        max_depth: int | None = None,
        userplan_steps: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Ensure plan items conform to server schema and propagate context.

        Coerces item_type to allowed enum, drops unknown keys, fills required fields
        with safe defaults, and propagates context from parent to children.

        Hierarchical derivation features (controlled by config flag
        features.userplan.hierarchical_derivation.enabled):

        When hierarchical derivation is ENABLED (default):
        - Context propagation (S7.T4):
          - If parent_item is provided, copies context values for keys in inherited_keys
          - Sets child's depth = parent.depth + 1
          - Sets child's parent_id = parent.id
          - Populates derivation metadata (derived_by, derived_at, version)
        - Depth limiting (S7.T5):
          - When an item would exceed max_depth, it is created as a sibling instead
          - Sibling items still inherit context from the parent
          - Logs when depth limit triggers sibling creation

        When hierarchical derivation is DISABLED:
        - Plan items are treated as a flat list
        - No parent_id relationships (all items are top-level)
        - All items have depth=0
        - No context propagation between items
        - No depth limiting applied

        Args:
            plan_items: List of plan item dictionaries from LLM
            parent_item: Optional parent item for context propagation
            max_depth: Maximum allowed depth (defaults to MAX_DERIVATION_DEPTH)
            userplan_steps: Optional UserPlan steps for source_step_id assignment

        Returns:
            Sanitized list of plan items with proper context inheritance
        """
        allowed_item_types = {"epic", "story", "task", "subtask", "milestone"}
        sanitized: list[dict[str, Any]] = []
        derivation_timestamp = datetime.now(UTC).isoformat()

        # Check if hierarchical derivation is enabled
        hierarchical_enabled = self.is_hierarchical_enabled()
        if hierarchical_enabled:
            logger.info("Hierarchical derivation mode: ENABLED (parent/child relationships active)")
        else:
            logger.info(
                "Hierarchical derivation mode: DISABLED (flat list, no parent/child relationships)"
            )

        # Use configured max depth if not provided (only relevant when hierarchical is enabled)
        if max_depth is None:
            max_depth = MAX_DERIVATION_DEPTH

        # Extract parent context for inheritance (only used when hierarchical is enabled)
        parent_depth = 0
        parent_id: str | None = None
        parent_parent_id: str | None = None  # S7.T5: grandparent for sibling creation
        parent_inherited_keys: list[str] = []
        parent_context: dict[str, Any] = {}

        if parent_item and hierarchical_enabled:
            parent_depth = parent_item.get("depth", 0)
            parent_id = parent_item.get("id")
            parent_parent_id = parent_item.get("parent_id")  # S7.T5: track grandparent
            parent_inherited_keys = parent_item.get("inherited_keys", [])
            parent_context = parent_item.get("context", {})

        step_ids: set[str] = set()
        step_index_by_id: dict[str, int] = {}
        default_step_id: str | None = None
        if userplan_steps:
            for step in userplan_steps:
                step_id = step.get("id")
                index = step.get("index")
                if not step_id or index is None:
                    continue
                step_ids.add(step_id)
                step_index_by_id[step_id] = int(index)
            if userplan_steps and isinstance(userplan_steps[0], dict):
                default_step_id = userplan_steps[0].get("id")

        for idx, item in enumerate(plan_items):
            item_type = item.get("item_type", "task")
            if item_type not in allowed_item_types:
                item_type = "task"

            title = item.get("title", "Untitled")
            description = item.get("description") or title
            context = item.get("context") or {}
            dependencies = item.get("dependencies", [])
            if not isinstance(dependencies, list):
                dependencies = [dependencies]

            # Initialize hierarchy fields with defaults for non-hierarchical mode
            item_parent_id: str | None = None
            item_depth = 0
            inherited_keys: list[str] = []
            inherited_context: dict[str, Any] = {}
            depth_limit_triggered = False

            if hierarchical_enabled:
                # Calculate depth and parent_id
                # If this item already has parent_id set (from LLM), use its depth + 1
                # Otherwise, if we have a parent_item, use parent_depth + 1
                item_parent_id = item.get("parent_id", parent_id)
                if item_parent_id is not None:
                    item_depth = item.get("depth", parent_depth + 1)
                else:
                    item_depth = item.get("depth", 0)

                # S7.T5: Enforce depth limit - create as sibling if would exceed max
                if item_depth > max_depth:
                    depth_limit_triggered = True
                    original_depth = item_depth
                    original_parent_id = item_parent_id

                    # Create as sibling of parent (use grandparent as parent)
                    item_parent_id = parent_parent_id
                    item_depth = parent_depth  # Same level as parent

                    logger.info(
                        "Depth limit triggered for item '%s': "
                        "would be depth=%d (max=%d), creating as sibling at depth=%d "
                        "(parent_id changed from '%s' to '%s')",
                        title,
                        original_depth,
                        max_depth,
                        item_depth,
                        original_parent_id,
                        item_parent_id,
                    )

                # Propagate context from parent (S7.T4)
                # Context is still inherited even when depth limit triggers sibling creation
                inherited_keys, inherited_context = self._propagate_context(
                    parent_context=parent_context,
                    parent_inherited_keys=parent_inherited_keys,
                )

            source_step_id = item.get("source_step_id")
            if not source_step_id and default_step_id:
                source_step_id = default_step_id
                logger.debug(
                    "Plan item %s using default source_step_id: %s",
                    item.get("id", f"T{idx + 1}"),
                    default_step_id,
                )
            if source_step_id and step_ids and source_step_id not in step_ids:
                logger.warning(
                    "Plan item %s has source_step_id not in UserPlan steps: %s",
                    item.get("id", f"T{idx + 1}"),
                    source_step_id,
                )
            if not source_step_id and userplan_steps:
                msg = (
                    "source_step_id is required for all derived plan items; "
                    "no UserPlan step metadata available to default"
                )
                raise ValueError(msg)

            step_index = None
            if isinstance(source_step_id, str) and ":S" in source_step_id:
                try:
                    step_index = int(source_step_id.split(":S")[-1])
                except ValueError:
                    step_index = None
            if step_index is None and isinstance(source_step_id, str):
                step_index = step_index_by_id.get(source_step_id)
            if step_index is not None and "userplan_step_index" not in context:
                context["userplan_step_index"] = step_index

            sanitized_item = {
                "id": item.get("id", f"T{idx + 1}"),
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": item.get("acceptance_criteria", []),
                "dependencies": dependencies,
                "context": context,
                "source_step_id": source_step_id,
                # Hierarchy fields (S7.T4) - empty/zero when hierarchical is disabled
                "parent_id": item_parent_id,
                "depth": item_depth,
                "inherited_keys": inherited_keys,
                "inherited_context": inherited_context,
                # Derivation metadata (S7.T3)
                "derived_by": item.get("derived_by", "hybrid-derive-handler"),
                "derived_at": item.get("derived_at", derivation_timestamp),
                "version": item.get("version", 1),
            }

            # S7.T5: Add marker when depth limit was applied (only in hierarchical mode)
            if depth_limit_triggered:
                sanitized_item["depth_limit_applied"] = True

            sanitized.append(sanitized_item)

        # Post-pass: strip container (epic/story) IDs from task/subtask dependencies.
        # LLMs sometimes conflate parent_id (structural containment) with dependencies
        # (execution ordering), producing unresolvable deps like E1.S1.T1 -> E1.S1.
        container_ids = {
            str(item.get("id", "")).strip()
            for item in sanitized
            if str(item.get("item_type", "")).strip().lower() in {"epic", "story"}
            and str(item.get("id", "")).strip()
        }
        if container_ids:
            stripped_count = 0
            for item in sanitized:
                raw_deps = item.get("dependencies", [])
                if not isinstance(raw_deps, list) or not raw_deps:
                    continue
                clean_deps = [d for d in raw_deps if d not in container_ids]
                if len(clean_deps) < len(raw_deps):
                    removed = set(raw_deps) - set(clean_deps)
                    logger.warning(
                        "Stripped container dependencies from %s: %s "
                        "(parent_id should be used for containment, not dependencies)",
                        item.get("id", "?"),
                        sorted(removed),
                    )
                    item["dependencies"] = clean_deps
                    stripped_count += len(removed)
            if stripped_count:
                logger.info(
                    "Stripped %d container dependency edges from plan items",
                    stripped_count,
                )

        return sanitized

    def validate_hierarchy(
        self,
        plan_items: list[dict[str, Any]],
    ) -> tuple[bool, list[str]]:
        """Validate epic/story/task/subtask parent-child structure.

        Args:
            plan_items: List of plan item dicts to validate.

        Returns:
            Tuple of (valid, violations) where valid is False if any violations found.
        """
        if not plan_items:
            return False, ["plan_items is empty"]

        items_by_id: dict[str, dict[str, Any]] = {}
        types_by_id: dict[str, str] = {}
        errors: list[str] = []

        for idx, item in enumerate(plan_items, start=1):
            if not isinstance(item, dict):
                errors.append(f"item {idx} is not a dict")
                continue
            item_id = str(item.get("id", "")).strip()
            if not item_id:
                errors.append(f"item {idx} missing id")
                continue
            item_type = str(item.get("item_type", "")).strip().lower()
            if not item_type:
                errors.append(f"{item_id} missing item_type")
                continue
            items_by_id[item_id] = item
            types_by_id[item_id] = item_type
        for item_id, item in items_by_id.items():
            item_type = types_by_id.get(item_id, "")
            parent_raw = item.get("parent_id")
            parent_id = str(parent_raw).strip() if parent_raw else ""
            parent_type = types_by_id.get(parent_id, "")
            if parent_id and parent_id not in items_by_id:
                errors.append(f"{item_id} parent_id not found: {parent_id}")

            if item_type == "epic":
                if parent_id:
                    errors.append(f"{item_id} epic has parent_id {parent_id}")
            elif item_type == "story":
                if not parent_id:
                    errors.append(f"{item_id} story missing epic parent")
                elif parent_type != "epic":
                    errors.append(f"{item_id} story parent is not epic: {parent_id}")
            elif item_type == "task":
                if not parent_id:
                    errors.append(f"{item_id} task missing story parent")
                elif parent_type != "story":
                    errors.append(f"{item_id} task parent is not story: {parent_id}")
            elif item_type == "subtask":
                if not parent_id:
                    errors.append(f"{item_id} subtask missing task parent")
                elif parent_type != "task":
                    errors.append(f"{item_id} subtask parent is not task: {parent_id}")
            else:
                errors.append(f"{item_id} unknown item_type: {item_type}")

        return not errors, errors

    def is_hierarchical_enabled(self) -> bool:
        """Check if hierarchical derivation is enabled via config flag.

        Reads features.userplan.hierarchical_derivation.enabled from the config
        dict passed at construction time. Defaults to True if not set (preserves
        existing behaviour).

        Returns:
            True if hierarchical derivation is enabled, False if disabled via config.
        """
        try:
            features = self._config.get("features", {})
            userplan = features.get("userplan", {})
            hierarchical_derivation = userplan.get("hierarchical_derivation", {})
            return hierarchical_derivation.get("enabled", True)
        except Exception as e:
            logger.warning(
                "Failed to read hierarchical derivation config flag, defaulting to enabled: %s",
                e,
            )
            return True

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _propagate_context(
        self,
        parent_context: dict[str, Any],
        parent_inherited_keys: list[str],
    ) -> tuple[list[str], dict[str, Any]]:
        """Propagate context from parent to child item.

        Context propagation follows these rules (S7.T4):
        1. Only copies keys explicitly listed in parent's inherited_keys
        2. Handles missing keys gracefully (skip, don't error)
        3. Merges with any existing context on the child (child values take precedence)

        Args:
            parent_context: Parent item's context dictionary
            parent_inherited_keys: List of keys that should be inherited from parent

        Returns:
            Tuple of (inherited_keys, inherited_context):
            - inherited_keys: List of keys that were actually inherited
            - inherited_context: Full snapshot of inherited parent context for audit
        """
        if not parent_context or not parent_inherited_keys:
            return [], {}

        inherited_keys: list[str] = []
        inherited_context: dict[str, Any] = {}

        for key in parent_inherited_keys:
            # Handle missing keys gracefully - skip if not present
            if key in parent_context:
                inherited_context[key] = parent_context[key]
                inherited_keys.append(key)
            else:
                logger.debug(
                    "Key '%s' in inherited_keys not found in parent context, skipping",
                    key,
                )

        # Note: child_context takes precedence, but we don't merge here
        # The context field remains separate from inherited_context
        # inherited_context is purely for audit trail of what was inherited

        return inherited_keys, inherited_context
