"""LLM resolution helpers for derive/scaffolded planning."""

from __future__ import annotations

import logging
import sys
from typing import Any, cast

from obra.config.llm import resolve_action_llm_config
from obra.config.loaders import get_enrichment_stage_timeout_s
from obra.exceptions import ConfigurationError

logger = logging.getLogger(__name__)


def _handler_attr(name: str, default: Any) -> Any:
    module = sys.modules.get("obra.hybrid.handlers.derive._handler")
    if module is None:
        return default
    return getattr(module, name, default)


class DeriveLLMResolver:
    """Owns derive-stage LLM resolution for scaffolded planning."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner

    @staticmethod
    def resolve_scaffolded_stage_llm(
        stage_config: dict[str, Any],
        provider: str,
    ) -> tuple[str, str, str, str, int, int]:
        resolve_action = _handler_attr("resolve_action_llm_config", resolve_action_llm_config)
        resolve_timeout = _handler_attr(
            "get_enrichment_stage_timeout_s",
            get_enrichment_stage_timeout_s,
        )
        model_tier = stage_config.get("model_tier")
        if not model_tier:
            raise ConfigurationError(
                "planning.enrichment.stages.derive.model_tier is required",
                "Set model_tier for the derive stage in config.",
            )
        if "reasoning_level" not in stage_config:
            raise ConfigurationError(
                "planning.enrichment.stages.derive.reasoning_level is required",
                "Set reasoning_level for the derive stage in config.",
            )
        if "max_passes" not in stage_config:
            raise ConfigurationError(
                "planning.enrichment.stages.derive.max_passes is required",
                "Set max_passes for the derive stage in config.",
            )

        resolved = resolve_action(
            "derive",
            model_tier=model_tier,
            override_reasoning_level=stage_config.get("reasoning_level"),
        )
        max_passes_raw = stage_config.get("max_passes")
        if max_passes_raw is None:
            raise ConfigurationError(
                "planning.enrichment.stages.derive.max_passes is required",
                "Set max_passes for the derive stage in config.",
            )
        max_passes = int(cast(int | str, max_passes_raw))
        timeout_s = resolve_timeout("derive", stage_config)
        return (
            resolved.get("provider", provider),
            resolved["model"],
            resolved["reasoning_level"],
            resolved["auth_method"],
            max_passes,
            timeout_s,
        )

    def resolve_derive_llm_config(self) -> dict[str, Any]:
        """Resolve base LLM config for derive using role crosswalk with overrides."""
        resolved: dict[str, Any] = {}
        try:
            from obra.config.llm import resolve_role_llm_config

            resolved = resolve_role_llm_config("derive")
        except Exception as exc:
            logger.debug("Failed to resolve derive role config; using local overrides: %s", exc)
            resolved = {}

        merged = resolved.copy()
        for key, value in (self._owner._llm_config or {}).items():
            if value is not None:
                merged[key] = value
        return merged
