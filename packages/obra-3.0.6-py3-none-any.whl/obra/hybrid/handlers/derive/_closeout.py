"""CloseoutInjector: close-out story injection for derivation pipeline."""

from __future__ import annotations

import logging
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.llm import get_project_planning_config
from obra.exploration.decision import detect_work_type
from obra.hybrid.derivation.mission_complexity import SizingGuidance
from obra.hybrid.handlers.derive._sanitizer import PlanSanitizer
from obra.workflow.tiered_resolver import TieredResolver

logger = logging.getLogger(__name__)


class CloseoutInjector:
    """Appends a close-out story (epic + story + tasks) to the derived plan.

    Determines whether to inject a close-out story, resolves the appropriate
    template from the tiered resolver, evaluates conditional tasks, sanitizes
    generated items via PlanSanitizer, and appends them to plan_items.

    Constructor receives all dependencies; no I/O beyond logging.
    """

    def __init__(
        self,
        config: dict[str, Any],
        working_dir: Path,
        log_event: Callable[..., None] | None = None,
        bypass_modes: list[str] | None = None,
        work_type_override: str | None = None,
        sanitizer: PlanSanitizer | None = None,
        domain: Any = None,
    ) -> None:
        """Initialise CloseoutInjector.

        Args:
            config: Loaded layered config dict (read once by DeriveHandler.__init__).
            working_dir: Project working directory (for template resolution and type-check detection).
            log_event: Optional event logger.
            bypass_modes: List of bypass mode strings (e.g. 'no_closeout').
            work_type_override: Manual work type override for detect_work_type().
            sanitizer: PlanSanitizer instance for sanitizing generated items.
            domain: Optional domain module for closeout template specialization.
        """
        self._config = config
        self._working_dir = working_dir
        self._log_event = log_event
        self._bypass_modes: list[str] = bypass_modes or []
        self._work_type_override = work_type_override
        self._sanitizer = sanitizer or PlanSanitizer(config=config)
        self._domain = domain

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def inject(
        self,
        plan_items: list[dict[str, Any]],
        *,
        objective: str,
        project_context: dict[str, Any] | None,
        userplan_steps: list[dict[str, Any]] | None,
        sizing_guidance: SizingGuidance | None = None,
    ) -> list[dict[str, Any]]:
        """Append a close-out story with tasks resolved from tiered templates.

        Args:
            plan_items: Current plan items (will not be mutated).
            objective: User objective string.
            project_context: Project context dict (may be None).
            userplan_steps: UserPlan steps for sanitizer.
            sizing_guidance: Optional sizing guidance for size-based suppression.

        Returns:
            Plan items with close-out story appended, or original list if suppressed.
        """
        if "no_closeout" in self._bypass_modes:
            logger.info("Skipping close-out injection due to no_closeout bypass mode")
            return plan_items

        ctx = project_context or {}

        # Size-based suppression: skip close-out for small objectives
        if sizing_guidance:
            min_size_str = (
                self._config.get("derivation", {})
                .get("hierarchy", {})
                .get("story", {})
                .get("closeout_min_size", "moderate")
            )
            size_order = {
                "trivial": 0,
                "simple": 1,
                "moderate": 2,
                "complex": 3,
            }
            current_size = sizing_guidance.size_class.value.lower()
            min_size = min_size_str.lower()
            if size_order.get(current_size, 2) < size_order.get(min_size, 2):
                logger.info(
                    "Skipping close-out injection: objective size '%s' below threshold '%s'",
                    current_size,
                    min_size,
                )
                return plan_items

        resolution = self._resolve_template(ctx)
        if not resolution:
            return plan_items

        closeout_context = self._build_context(objective, ctx)
        epic_id = self._next_epic_id(plan_items)
        story_id = f"{epic_id}.S1"
        injected: list[dict[str, Any]] = []
        task_index = 0
        story_criteria: list[str] = []

        # Compute terminal leaf tasks from prior epics so close-out depends on them
        terminal_task_ids = self.find_terminal_leaves(plan_items)

        for task in resolution.template.tasks:
            if task.conditional and not self._evaluate_condition(
                task.conditional, closeout_context
            ):
                continue

            verify = task.verify
            if verify:
                story_criteria.append(verify)

            # First close-out task depends on terminal tasks of prior epics;
            # subsequent close-out tasks chain sequentially.
            if task_index == 0:
                task_deps = list(terminal_task_ids)
            else:
                task_deps = [f"{story_id}.T{task_index - 1}"]

            injected.append(
                {
                    "id": f"{story_id}.T{task_index}",
                    "item_type": "task",
                    "title": task.desc,
                    "description": task.desc,
                    "acceptance_criteria": [verify] if verify else [],
                    "dependencies": task_deps,
                    "context": {
                        "closeout_domain": resolution.template.domain,
                        "template_source_tiers": resolution.source_tiers,
                        # Conditional is already evaluated at injection time —
                        # tasks that failed evaluation are excluded above.
                        # Emitting the raw condition string here misleads the
                        # examine/revise LLM into treating it as a runtime
                        # skip flag, which triggers oscillation (see GH-xxxx).
                        "conditional": None,
                    },
                }
            )
            task_index += 1

        if not injected:
            logger.info("No close-out tasks added after conditional evaluation")
            return plan_items

        epic_item = {
            "id": epic_id,
            "item_type": "epic",
            "title": "Close-out & Verification",
            "description": "Final verification steps for mission completion.",
            "acceptance_criteria": ["Close-out verification completed"],
            "dependencies": [],
            "context": {
                "user_visible": True,
                "closeout_domain": resolution.template.domain,
                "template_source_tiers": resolution.source_tiers,
            },
        }

        story_item = {
            "id": story_id,
            "item_type": "story",
            "title": "Close-out verification",
            "description": "Verify mission completion and required checks.",
            "acceptance_criteria": story_criteria or ["Verification completed"],
            "dependencies": [],
            "parent_id": epic_id,
            "context": {
                "user_visible": True,
                "closeout_domain": resolution.template.domain,
                "template_source_tiers": resolution.source_tiers,
            },
        }

        sanitized_epic = self._sanitizer.sanitize(
            [epic_item],
            userplan_steps=userplan_steps,
        )
        if not sanitized_epic:
            return plan_items
        epic = sanitized_epic[0]

        sanitized_story = self._sanitizer.sanitize(
            [story_item],
            parent_item=epic,
            userplan_steps=userplan_steps,
        )
        if not sanitized_story:
            return plan_items
        story = sanitized_story[0]

        sanitized_tasks = self._sanitizer.sanitize(
            injected,
            parent_item=story,
            userplan_steps=userplan_steps,
        )

        logger.info(
            "Injected %d close-out tasks from %s template (tiers: %s)",
            len(injected),
            resolution.template.domain,
            ", ".join(resolution.source_tiers),
        )
        return [*plan_items, epic, story, *sanitized_tasks]

    @staticmethod
    def find_terminal_leaves(plan_items: list[dict[str, Any]]) -> list[str]:
        """Find terminal leaf tasks (last executable task per epic) in the plan.

        Terminal tasks are tasks/subtasks that no other task/subtask depends on
        within each epic. These represent the final work items that must complete
        before close-out can begin.

        Args:
            plan_items: List of plan item dicts.

        Returns:
            Sorted list of terminal task IDs.
        """
        executable_types = {"task", "subtask"}
        # Collect all executable items grouped by their epic
        epic_tasks: dict[str, list[str]] = {}
        item_type_map: dict[str, str] = {}
        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id", "")).strip()
            item_type = str(item.get("item_type", "")).strip().lower()
            if not item_id:
                continue
            item_type_map[item_id] = item_type
            if item_type not in executable_types:
                continue
            # Determine epic from hierarchical ID (E1.S1.T1 -> E1)
            epic_id = item_id.split(".")[0] if "." in item_id else ""
            if epic_id:
                epic_tasks.setdefault(epic_id, []).append(item_id)

        if not epic_tasks:
            return []

        # Build set of task IDs that are depended on by other tasks
        depended_on: set[str] = set()
        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("item_type", "")).strip().lower()
            if item_type not in executable_types:
                continue
            for dep in item.get("dependencies", []):
                dep_id = str(dep).strip()
                if dep_id and item_type_map.get(dep_id) in executable_types:
                    depended_on.add(dep_id)

        # Terminal tasks = executable tasks not depended on by any other task
        terminal_ids: list[str] = []
        for epic_id in sorted(epic_tasks):
            tasks = epic_tasks[epic_id]
            terminals = [t for t in tasks if t not in depended_on]
            if terminals:
                terminal_ids.extend(terminals)
            elif tasks:
                # Fallback: if all tasks are depended on (cycle), use the last task
                terminal_ids.append(tasks[-1])

        return sorted(terminal_ids)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _resolve_template(self, project_context: dict[str, Any]) -> Any | None:
        """Resolve close-out template using TieredResolver."""
        try:
            project_path = Path(self._working_dir)
        except TypeError:
            project_path = self._working_dir

        domain = project_context.get("domain")
        if not domain:
            planning_config = get_project_planning_config(project_path)
            domain = planning_config.get("domain")
        if not domain:
            domain = self._domain.closeout_key if self._domain else "software-dev"

        obra_root = self._get_obra_root()
        resolver = TieredResolver(project_path=project_path, obra_path=obra_root)
        return resolver.resolve_closeout(domain)

    def _build_context(
        self, objective: str, project_context: dict[str, Any]
    ) -> dict[str, Any]:
        """Build context for evaluating close-out conditionals."""
        work_type = detect_work_type(
            objective,
            work_type_keywords=(
                self._domain.get_derivation_keywords()
                if self._domain is not None
                else None
            ),
            work_type_override=self._work_type_override,
        )

        has_user_facing_changes = project_context.get("has_user_facing_changes")
        if has_user_facing_changes is None:
            has_user_facing_changes = work_type not in ("refactoring",)

        type_checks_enabled = project_context.get("type_checks_enabled")
        if type_checks_enabled is None:
            type_checks_enabled = self._is_type_checks_enabled()

        planning_config = get_project_planning_config(self._working_dir)
        domain = (
            project_context.get("domain")
            or planning_config.get("domain")
            or (self._domain.closeout_key if self._domain else "software-dev")
        )

        return {
            "work_type": work_type,
            "has_user_facing_changes": bool(has_user_facing_changes),
            "type_checks_enabled": bool(type_checks_enabled),
            "domain": domain,
        }

    def _evaluate_condition(self, condition: str, context: dict[str, Any]) -> bool:
        """Evaluate conditional flags for close-out tasks."""
        condition_map = {
            "type_checks_enabled": bool(context.get("type_checks_enabled")),
            "has_user_facing_changes": bool(context.get("has_user_facing_changes")),
        }
        if condition not in condition_map:
            logger.debug("Unknown close-out condition '%s' - defaulting to include", condition)
            return True
        return condition_map[condition]

    def _is_type_checks_enabled(self) -> bool:
        """Detect whether type checks are configured for the project."""
        candidates = [
            self._working_dir / "mypy.ini",
            self._working_dir / "setup.cfg",
            self._working_dir / "pyproject.toml",
        ]

        for path in candidates:
            if not path.exists():
                continue
            if path.name in {"pyproject.toml", "setup.cfg"}:
                try:
                    content = path.read_text(encoding="utf-8")
                    if "tool.mypy" in content or "[mypy]" in content:
                        return True
                except OSError:
                    continue
            else:
                return True

        return False

    def _next_story_id(self, plan_items: list[dict[str, Any]]) -> str:
        """Compute the next sequential story ID based on existing items."""
        max_story = 0
        pattern = re.compile(r"^S(?P<story>\d+)")

        for item in plan_items:
            item_id = str(item.get("id", ""))
            match = pattern.match(item_id)
            if match:
                try:
                    story_num = int(match.group("story"))
                except ValueError:
                    continue
                max_story = max(max_story, story_num)

        return f"S{max_story + 1}"

    def _next_epic_id(self, plan_items: list[dict[str, Any]]) -> str:
        """Compute the next sequential epic ID based on existing items."""
        max_epic = 0
        pattern = re.compile(r"^E(?P<epic>\d+)$")

        for item in plan_items:
            item_id = str(item.get("id", ""))
            match = pattern.match(item_id)
            if match:
                try:
                    epic_num = int(match.group("epic"))
                except ValueError:
                    continue
                max_epic = max(max_epic, epic_num)

        return f"E{max_epic + 1}"

    def _get_obra_root(self) -> Path:
        """Resolve repository root for bundled templates."""
        return Path(__file__).resolve().parents[3]
