"""IntentAlignmentReviewer for DeriveHandler pipeline.

Extracts the intent alignment review lifecycle from DeriveHandler:
skip check → per-story parallel assessment → gap detection → result.
"""

# pylint: disable=broad-exception-caught

import logging
import re
import uuid
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from time import perf_counter
from typing import Any

from obra.config.llm import resolve_action_llm_config
from obra.config.loaders import get_intent_alignment_max_concurrent
from obra.exceptions import QualityGateError
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.planning.intent_alignment import (
    GapDetectionResult,
    IntentAlignmentResult,
    StoryAssessment,
    run_gap_detection,
    run_story_intent_review,
)

logger = logging.getLogger(__name__)


class IntentAlignmentReviewer:
    """Runs the intent alignment review lifecycle for a derived plan.

    Encapsulates: skip check → parallel per-story assessment →
    gap detection → fix application (add/remove stories).
    Constructed per-action by DeriveHandler; no singleton state across actions.
    """

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        llm_config: dict[str, Any],
        on_stream: Callable[[str, str], None] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        bypass_modes: list[str] | None = None,
        monitoring_context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize IntentAlignmentReviewer.

        Args:
            working_dir: Working directory (required by run_story_intent_review
                and run_gap_detection).
            config: Loaded layered config dict (read once from DeriveHandler.__init__).
            llm_config: LLM configuration for per-story assessment calls.
            on_stream: Optional callback for LLM streaming chunks.
            on_progress: Progress emission callback (DeriveHandler._emit_progress).
            log_event: Event logging callback.
            trace_id: Trace ID for telemetry correlation.
            parent_span_id: Parent span ID for telemetry correlation.
            bypass_modes: Active bypass mode strings (e.g. ['skip_intent']).
            monitoring_context: Monitoring context dict (provides session_id for
                skip tracking).
        """
        self._working_dir = working_dir
        self._config = config
        self._llm_config = llm_config
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._bypass_modes = bypass_modes or []
        self._monitoring_context = monitoring_context
        self._skip_intent = "skip_intent" in self._bypass_modes

    # --- Skip tracking helpers (copied from DeriveHandler) ---

    def _is_skip_tracking_enabled(self, source_key: str) -> bool:
        skip_config = self._config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get(source_key, True)
        )

    def _get_skip_session_id(self) -> str:
        if isinstance(self._monitoring_context, dict):
            session_id = self._monitoring_context.get("session_id")
            if session_id:
                return str(session_id)
        return ""

    # --- Internal emit helpers ---

    def _emit(self, action: str, payload: dict[str, Any]) -> None:
        """Emit a progress event via the on_progress callback."""
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as exc:
                logger.debug("Progress callback failed: %s", exc)

    def _emit_stage_started(self, stage: str, context: dict[str, Any] | None = None) -> None:
        self._emit("stage_started", {"stage": stage, "context": context or {}})

    def _emit_stage_completed(
        self,
        stage: str,
        duration_ms: int,
        result: dict[str, Any] | None = None,
    ) -> None:
        self._emit("stage_completed", {"stage": stage, "duration_ms": duration_ms, "result": result or {}})

    # --- Public API ---

    def review(
        self,
        plan_items: list[dict[str, Any]],
        intent_content: str | None,
    ) -> IntentAlignmentResult | None:
        """Run epic/story intent alignment review after derivation.

        Returns the alignment result so caller can apply fixes
        (stories_to_add, stories_to_remove). Returns None if the review
        is skipped or disabled.

        Args:
            plan_items: Derived plan items to review.
            intent_content: Intent markdown string (may be None if not available).

        Returns:
            IntentAlignmentResult or None if skipped.
        """
        if self._skip_intent:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="skip_intent",
                )
            if self._is_skip_tracking_enabled("user_bypass"):
                create_skip_record(
                    session_id=self._get_skip_session_id(),
                    task_id="intent-alignment",
                    source=SkipSource.USER_BYPASS,
                    reason=SkipReason.BYPASS_FLAG,
                    description="Intent alignment skipped due to --skip-intent",
                    source_context={"bypass_modes": list(self._bypass_modes)},
                )
                logger.info("Run 'obra skips list' to review skipped items")
            return None

        if not plan_items:
            return None

        if intent_content is None:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="intent_missing",
                )
            return None

        # Read intent alignment config from self._config (loaded once at construction)
        try:
            enabled = (
                self._config.get("features", {})
                .get("userplan", {})
                .get("intent_alignment", {})
                .get("enabled", True)
            )
            alignment_config = self._config.get("planning", {}).get("intent_alignment", {}) or {}
            block_on_fail = alignment_config.get("block_on_fail", False)
        except Exception as exc:
            logger.warning("Intent alignment config read failed; skipping: %s", exc)
            return None

        if not enabled:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="config_disabled",
                )
            return None

        epics = []
        stories = []
        for item in plan_items:
            entry = {
                "id": item.get("id"),
                "title": item.get("title"),
                "description": item.get("description"),
                "acceptance_criteria": item.get("acceptance_criteria", []),
            }
            if item.get("item_type") == "epic":
                epics.append(entry)
            elif item.get("item_type") == "story":
                stories.append(entry)

        if not epics and not stories:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="no_epics_or_stories",
                )
            return None

        objective = ""
        for line in intent_content.splitlines():
            if line.startswith("# Intent:"):
                objective = line.split(":", 1)[-1].strip()
                break

        # Emit stage started for intent alignment
        self._emit_stage_started(
            "intent_alignment",
            {"epic_count": len(epics), "story_count": len(stories)},
        )
        # Emit detailed progress for UI
        self._emit("intent_alignment_started", {"epic_count": len(epics), "story_count": len(stories)})
        alignment_start = perf_counter()

        model_tier = alignment_config.get("model_tier")
        reasoning_level = alignment_config.get("reasoning_level")
        max_passes = int(alignment_config.get("max_passes", 1))
        timeout_s = int(alignment_config.get("timeout_s", 600))

        if not model_tier or not reasoning_level:
            logger.warning("Intent alignment missing model_tier or reasoning_level")
            return None

        resolved = resolve_action_llm_config(
            "derive",
            model_tier=model_tier,
            override_reasoning_level=reasoning_level,
        )

        # Build epic lookup for parent titles
        epic_titles = {e["id"]: e["title"] for e in epics}

        # Build story lookup with parent epic info
        story_parent_map: dict[str, str | None] = {}
        for item in plan_items:
            if item.get("item_type") == "story":
                story_parent_map[item.get("id", "")] = item.get("parent_id")

        # Per-story intent review loop
        total_stories = len(stories)
        story_assessments: list[StoryAssessment] = []
        stories_to_remove: list[str] = []

        max_workers = get_intent_alignment_max_concurrent()
        if total_stories > 0:
            self._emit(
                "intent_story_batch_started",
                {
                    "story_count": total_stories,
                    "max_concurrent": max_workers,
                },
            )

        def assess_one(
            args: tuple[int, dict[str, Any]],
        ) -> tuple[int, StoryAssessment, float]:
            idx, story = args
            story_id = story["id"]
            parent_id = story_parent_map.get(story_id)
            epic_title = epic_titles.get(parent_id) if parent_id else None
            story_start = perf_counter()

            assessment = run_story_intent_review(
                working_dir=self._working_dir,
                objective=objective or "Objective unavailable",
                intent_markdown=intent_content,
                story=story,
                epic_title=epic_title,
                llm_config=self._llm_config,
                resolved_config=resolved,
                timeout_s=timeout_s,
                max_passes=max_passes,
                on_stream=self._on_stream,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

            story_duration_s = perf_counter() - story_start
            return (idx, assessment, story_duration_s)

        work = [(idx, story) for idx, story in enumerate(stories, start=1)]
        results: list[tuple[int, StoryAssessment, float]] = []
        errors: list[tuple[int, str, Exception]] = []

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Rate limiting handled by LLMConcurrencyGovernor (FEAT-LLM-GOVERNOR-001)
            futures: dict[Any, Any] = {}
            for _idx_w, w in enumerate(work):
                futures[executor.submit(assess_one, w)] = w
            for future in as_completed(futures):
                work_item = futures[future]
                idx, story = work_item[0], work_item[1]
                story_id = story["id"]
                story_title = story["title"]

                try:
                    result_idx, assessment, story_duration_s = future.result()
                    results.append((result_idx, assessment, story_duration_s))
                except Exception as exc:
                    logger.warning("Story %s intent review failed: %s", story_id, exc)
                    errors.append((idx, story_id, exc))
                    assessment = StoryAssessment(
                        story_id=story_id,
                        status="ok",
                        note=f"Review failed: {exc}",
                    )
                    results.append((idx, assessment, 0.0))

                # Emit per-story progress event immediately after each story
                self._emit(
                    "intent_story_assessed",
                    {
                        "story_id": story_id,
                        "story_title": story_title,
                        "story_index": idx,
                        "total_stories": total_stories,
                        "status": results[-1][1].status,
                        "note": results[-1][1].note,
                        "duration_s": results[-1][2],
                    },
                )

        if errors:
            logger.warning(
                "%d/%d stories failed intent check: %s",
                len(errors),
                total_stories,
                [e[1] for e in errors],
            )

        results.sort(key=lambda x: x[0])
        story_assessments = [r[1] for r in results]
        stories_to_remove = [
            assessment.story_id
            for assessment in story_assessments
            if assessment.status == "scope_creep"
        ]

        # Gap detection: find requirements not covered by any story
        # Only check stories that weren't flagged as scope_creep
        valid_stories = [s for s in stories if s["id"] not in stories_to_remove]

        self._emit("intent_gap_detection_started", {"story_count": len(valid_stories)})

        gap_start = perf_counter()
        try:
            gap_result = run_gap_detection(
                working_dir=self._working_dir,
                objective=objective or "Objective unavailable",
                intent_markdown=intent_content,
                stories=valid_stories,
                llm_config=self._llm_config,
                resolved_config=resolved,
                timeout_s=timeout_s,
                max_passes=max_passes,
                on_stream=self._on_stream,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        except Exception as exc:
            logger.warning("Gap detection failed: %s", exc)
            gap_result = GapDetectionResult(
                gaps_found=False,
                missing_requirements=[],
                stories_to_add=[],
                duration_s=perf_counter() - gap_start,
            )

        self._emit(
            "intent_gap_detection_completed",
            {
                "gaps_found": gap_result.gaps_found,
                "missing_count": len(gap_result.missing_requirements),
                "stories_to_add": len(gap_result.stories_to_add),
                "duration_s": gap_result.duration_s,
            },
        )

        alignment_duration_ms = int((perf_counter() - alignment_start) * 1000)

        # Determine overall coverage status
        scope_creep_count = len(stories_to_remove)
        missing_count = len(gap_result.missing_requirements)

        if scope_creep_count > 0 and scope_creep_count >= len(stories):
            coverage_status = "fail"
        elif scope_creep_count > 0 or missing_count > 0:
            coverage_status = "warn"
        else:
            coverage_status = "pass"

        changes_required = scope_creep_count > 0 or gap_result.gaps_found

        # Build result with gap detection data
        result = IntentAlignmentResult(
            changes_required=changes_required,
            coverage_status=coverage_status,
            story_assessments=story_assessments,
            missing_requirements=gap_result.missing_requirements,
            stories_to_add=gap_result.stories_to_add,
            stories_to_remove=stories_to_remove,
            notes=[],
            raw_response="",
            duration_s=alignment_duration_ms / 1000.0,
        )

        self._emit_stage_completed(
            "intent_alignment",
            alignment_duration_ms,
            result={
                "coverage_status": result.coverage_status,
                "changes_required": result.changes_required,
            },
        )

        # Emit stories to add from gap detection
        for story_data in result.stories_to_add:
            self._emit(
                "intent_story_added",
                {
                    "title": story_data.get("title", "Untitled"),
                    "parent_id": story_data.get("parent_id"),
                },
            )

        # Emit summary
        self._emit(
            "intent_alignment_completed",
            {
                "coverage_status": result.coverage_status,
                "changes_required": result.changes_required,
                "missing_count": missing_count,
                "scope_creep_count": scope_creep_count,
                "stories_added": len(result.stories_to_add),
                "stories_removed": len(stories_to_remove),
                "duration_s": alignment_duration_ms / 1000.0,
            },
        )

        if self._log_event:
            self._log_event(
                "intent_alignment_complete",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                coverage_status=result.coverage_status,
                missing_requirements=result.missing_requirements,
                story_assessments=[
                    {"id": a.story_id, "status": a.status, "note": a.note}
                    for a in result.story_assessments
                ],
                stories_to_add=[s.get("title") for s in result.stories_to_add],
                stories_to_remove=result.stories_to_remove,
                notes=[],
            )

        if block_on_fail and result.coverage_status == "fail":
            hints = [f"Story {sid} is scope creep" for sid in stories_to_remove]
            hints.extend(result.missing_requirements)
            raise QualityGateError(
                message="Intent alignment failed: scope creep or missing coverage",
                score=0.0,
                threshold=1.0,
                hints=hints,
            )

        return result

    def apply_fixes(
        self,
        plan_items: list[dict[str, Any]],
        alignment_result: IntentAlignmentResult,
    ) -> list[dict[str, Any]]:
        """Apply intent alignment fixes to plan items.

        Adds missing stories and removes scope creep stories.
        Emits progress events showing what was changed.

        Args:
            plan_items: Current list of plan items.
            alignment_result: Result from review() containing changes to apply.

        Returns:
            Updated plan items with fixes applied.
        """
        updated_items = list(plan_items)
        added_titles = []
        removed_ids = []

        # Remove scope creep stories
        if alignment_result.stories_to_remove:
            remove_set = set(alignment_result.stories_to_remove)
            updated_items = [item for item in updated_items if item.get("id") not in remove_set]
            # Remove tasks/subtasks orphaned by removed stories.
            removed_task_ids = {
                item.get("id")
                for item in updated_items
                if item.get("item_type") == "task" and item.get("parent_id") in remove_set
            }
            if removed_task_ids:
                updated_items = [
                    item
                    for item in updated_items
                    if item.get("parent_id") not in remove_set
                    and item.get("id") not in removed_task_ids
                ]
                updated_items = [
                    item for item in updated_items if item.get("parent_id") not in removed_task_ids
                ]
            removed_ids = list(remove_set & {item.get("id") for item in plan_items})
            if removed_ids:
                logger.info("Removed %d scope creep stories: %s", len(removed_ids), removed_ids)

            # FIX-HYBRID-037: Sanitize dangling references to removed items.
            # When stories are pruned, task descriptions/dependencies may still
            # reference the removed IDs, causing P0 examine issues and scope re-growth.
            all_removed_ids = remove_set | removed_task_ids
            if all_removed_ids:
                # Build regex matching any removed ID (e.g., E3.S4, E3.S4.T1)
                escaped_ids = sorted(
                    (re.escape(rid) for rid in all_removed_ids if rid), key=len, reverse=True
                )
                if escaped_ids:
                    removed_id_pattern = re.compile(
                        r"\b(" + "|".join(escaped_ids) + r")\b"
                    )
                    for item in updated_items:
                        # Strip removed IDs from dependencies array
                        deps = item.get("dependencies")
                        if isinstance(deps, list):
                            cleaned_deps = [d for d in deps if d not in all_removed_ids]
                            if len(cleaned_deps) != len(deps):
                                item["dependencies"] = cleaned_deps

                        # Strip removed ID references from description text
                        desc = item.get("description", "")
                        if desc and removed_id_pattern.search(desc):
                            item["description"] = removed_id_pattern.sub("[removed]", desc)

                        # Strip from acceptance_criteria
                        ac = item.get("acceptance_criteria")
                        if isinstance(ac, list):
                            item["acceptance_criteria"] = [
                                removed_id_pattern.sub("[removed]", c) if isinstance(c, str) else c
                                for c in ac
                            ]
                    logger.info(
                        "Sanitized dangling references to %d removed IDs in remaining plan items",
                        len(all_removed_ids),
                    )

        # Add missing stories
        if alignment_result.stories_to_add:
            default_epic_id = next(
                (item.get("id") for item in updated_items if item.get("item_type") == "epic"),
                None,
            )
            depth_by_id: dict[str, int] = {}
            for existing_item in updated_items:
                existing_id = str(existing_item.get("id", "")).strip()
                if not existing_id:
                    continue
                try:
                    parsed_depth = int(existing_item.get("depth"))
                except (TypeError, ValueError):
                    continue
                depth_by_id[existing_id] = parsed_depth

            # Build map of epic_id -> max story number for hierarchical ID generation
            story_count_by_epic: dict[str, int] = {}
            for item in updated_items:
                if item.get("item_type") == "story":
                    item_id = item.get("id", "")
                    item_parent = item.get("parent_id", "")
                    match = re.match(r"^(E\d+)\.S(\d+)$", item_id)
                    if match and match.group(1) == item_parent:
                        num = int(match.group(2))
                        story_count_by_epic[item_parent] = max(
                            story_count_by_epic.get(item_parent, 0), num
                        )

            for story_data in alignment_result.stories_to_add:
                parent_id = story_data.get("parent_id") or default_epic_id
                # Generate hierarchical ID (E{n}.S{m}) when parent is a standard epic
                story_id = story_data.get("id")
                if not story_id:
                    if parent_id and re.match(r"^E\d+$", parent_id):
                        next_num = story_count_by_epic.get(parent_id, 0) + 1
                        story_count_by_epic[parent_id] = next_num
                        story_id = f"{parent_id}.S{next_num}"
                    else:
                        story_id = f"story-{uuid.uuid4().hex[:8]}"
                normalized_parent_id = str(parent_id).strip() if parent_id is not None else ""
                if normalized_parent_id:
                    parent_depth = depth_by_id.get(normalized_parent_id, 0)
                    story_depth = parent_depth + 1
                else:
                    story_depth = 1
                new_story = {
                    "id": story_id,
                    "item_type": "story",
                    "title": story_data.get("title", "Untitled Story"),
                    "description": story_data.get("description", ""),
                    "parent_id": parent_id,
                    "depth": story_depth,
                    "acceptance_criteria": story_data.get("acceptance_criteria", []),
                    "status": "pending",
                }
                updated_items.append(new_story)
                depth_by_id[str(story_id)] = story_depth
                added_titles.append(new_story["title"])
                logger.info(
                    "Added story: %s (parent: %s)",
                    new_story["title"],
                    new_story.get("parent_id"),
                )

        # Emit progress event showing fixes applied
        if added_titles or removed_ids:
            self._emit(
                "intent_alignment_fixes_applied",
                {
                    "stories_added": added_titles,
                    "stories_removed": removed_ids,
                },
            )

        return updated_items
