"""DeriveFlow: session lifecycle runner for derive() sessions."""

from __future__ import annotations

import atexit
import logging
import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

import obra.hybrid.orchestrator as _orch_module
from obra.api.protocol import (
    ActionType,
    CompletionNotice,
    ServerAction,
    SessionStart,
)
from obra.config import get_max_iterations
from obra.display import console, print_info, print_warning
from obra.exceptions import APIError, OrchestratorError
from obra.hybrid.flows.loop_runner import LoopConfig, run_orchestration_loop
from obra.hybrid.orchestrator import MAX_POLLING_RETRIES
from obra.messages import get_message
from obra.observability.production_logger import get_production_logger

if TYPE_CHECKING:
    from obra.hybrid.orchestrator import HybridOrchestrator

logger = logging.getLogger(__name__)


class DeriveFlow:
    """Session lifecycle runner for derive() sessions.

    Extracted from HybridOrchestrator.derive() — no behavioral changes.
    Encapsulates the full derive session lifecycle: parameter setup,
    preflight, session creation, and the main orchestration loop.
    """

    def __init__(
        self,
        orchestrator: HybridOrchestrator,
        objective: str,
        working_dir: Path | None,
        project_id: str | None,
        max_iterations: int | None,
        plan_id: str | None,
        plan_only: bool,
        bypass_modes: list[str] | None,
        skip_completed_items: list[str] | None,
        userplan_id: str | None,
        from_step: int | None,
        work_type: str | None,
        workflow_derivation_request: dict[str, Any] | None,
    ) -> None:
        self._orch = orchestrator
        self._objective = objective
        self._working_dir = working_dir
        self._project_id = project_id
        self._max_iterations: int = max_iterations if max_iterations is not None else 0
        self._plan_id = plan_id
        self._plan_only = plan_only
        self._bypass_modes = bypass_modes
        self._skip_completed_items = skip_completed_items
        self._userplan_id = userplan_id
        self._from_step = from_step
        self._work_type = work_type
        self._workflow_derivation_request = workflow_derivation_request

    def run(self) -> CompletionNotice:
        """Execute the derive session lifecycle: setup → preflight → create session → orchestration loop."""
        self._setup_parameters()
        project_context, project_hash, client_version = self._run_preflight()
        server_action = self._create_session(project_context, project_hash, client_version)
        return self._orchestration_loop(server_action)

    def _setup_parameters(self) -> None:
        if self._bypass_modes is not None:
            self._orch._bypass_modes = self._bypass_modes

        # Reset dispatcher so it gets rebuilt with fresh session state on first dispatch.
        self._orch._dispatcher = None

        self._orch._objective = self._objective

        # Store skip_completed_items for --continue-from recovery
        self._orch._skip_completed_items = self._skip_completed_items or []

        # Store from_step for incremental re-derivation
        self._orch._derive_from_step = self._from_step

        # Store work_type override for DeriveHandler
        self._orch._work_type_override = self._work_type

        # FIX-PROJID-002: CLI must provide validated project_id - no auto-detection
        # If project_id is None here, CLI validation was bypassed (direct API call)
        if self._project_id is None:
            msg = (
                "project_id is required. CLI must validate project_id against server "
                "before calling orchestrator. Use 'obra projects select' to set a default."
            )
            raise OrchestratorError(
                msg, recovery="Run 'obra projects list' to see available projects"
            )

        self._orch._project_id = self._project_id
        self._orch._project_name = self._orch._resolve_project_name(self._project_id)

        # Resolve max_iterations from config if not provided
        if self._max_iterations == 0:
            self._max_iterations = get_max_iterations()

        # Update working dir if provided
        if self._working_dir:
            self._orch._working_dir = self._working_dir

    def _run_preflight(self) -> tuple[dict, str, str]:
        # S2.T1: Run git preflight check before starting session
        # GIT-HARD-001: Validate git repository before orchestration begins
        self._orch._git_preflight()

        # Ensure we can reach the server
        self._orch._ensure_online()

        # Gather project context
        project_context = self._orch._get_project_context()
        project_hash = self._orch._hash_working_dir()

        # Get client version
        try:
            from obra import __version__ as client_version
        except ImportError:
            client_version = "0.0.0-dev"

        # Initialize trace context for end-to-end observability
        if not self._orch._trace.trace_id:
            self._orch._trace.trace_id = uuid.uuid4().hex
        self._orch._trace.pipeline_span_id = uuid.uuid4().hex
        self._orch._trace.pipeline_start_time = time.time()
        try:
            self._orch._client.set_trace_context(self._orch._trace.trace_id, span_id=self._orch._trace.pipeline_span_id)
        except Exception:
            logger.debug("Failed to set trace context on API client", exc_info=True)
        self._orch._event_logger.set_trace_context(self._orch._trace.trace_id, span_id=self._orch._trace.pipeline_span_id)

        # Set project context for all subsequent log events
        if self._project_id:
            self._orch._event_logger.set_project(self._project_id, self._orch._project_name)

        # Log pipeline start for end-to-end timing
        self._orch._log_session_event(
            "pipeline_started",
            objective=self._objective[:200] if len(self._objective) > 200 else self._objective,
            working_dir=str(self._orch._working_dir),
            project_id=self._project_id,
            project_name=self._orch._project_name,
            client_version=client_version,
            span_id=self._orch._trace.pipeline_span_id,
        )
        self._orch._log_session_event("resource_snapshot", snapshot_type="pipeline_start")

        # CLI-CACHE-MONITOR-001: Check CLI cache health before session
        self._orch._check_cli_cache_health("pre_session")

        # Start session
        print_info("Starting session...")
        logger.info(f"Starting session: {self._objective}")

        # Build effective LLM map from role-based config resolution
        effective_map = self._orch._build_effective_llm_map()
        self._orch._effective_llm_map = effective_map

        # Run provider preflight checks
        self._orch._preflight_results = self._orch._run_provider_preflight(effective_map)

        return project_context, project_hash, client_version

    def _register_lifecycle_hooks(self) -> None:
        # P0-2: Register atexit handler for terminal event safety net
        # Covers force-quit (second Ctrl+C) where finally block doesn't complete
        atexit.register(self._orch._atexit_session_terminal_event)
        # P0-2: Set module-level callback so CLI can emit before os._exit()
        _orch_module._force_quit_terminal_callback = (
            self._orch._force_quit_session_terminal_event
        )

    def _create_session(self, project_context: dict, project_hash: str, client_version: str) -> ServerAction:
        resolved_domain = getattr(self._orch, "_domain", None)
        domain_name = getattr(resolved_domain, "name", None)
        if not isinstance(domain_name, str) or not domain_name.strip():
            msg = "Hybrid derive flow requires an explicit resolved domain before session creation."
            raise OrchestratorError(msg)
        try:
            response = self._orch._request_with_observability(
                "POST",
                "hybrid_orchestrate",
                json=SessionStart(
                    objective=self._objective,
                    project_hash=project_hash,
                    working_dir=str(self._orch._working_dir),
                    project_id=self._project_id,
                    project_context=project_context,
                    client_version=client_version,
                effective_llm_map=self._orch._effective_llm_map,
                plan_id=self._plan_id,
                userplan_id=self._userplan_id,
                plan_only=self._plan_only,
                bypass_modes=self._bypass_modes or self._orch._bypass_modes,
                from_step=self._from_step,
                quality_policy_mode=self._orch._resolve_quality_policy_mode(),
                    domain=domain_name,
                    domain_resolution_state=self._orch._domain_resolution,
                    workflow_derivation_request=self._workflow_derivation_request,
                ).to_dict(),
            )
        except APIError as e:
            msg = f"Failed to start session: {e}"
            raise OrchestratorError(
                msg,
                recovery="Check your authentication with 'obra whoami'",
                error_context=self._orch._build_error_context(action="start_session"),
            ) from e

        # Parse server response
        server_action = ServerAction.from_dict(response)
        self._orch._session_id = server_action.session_id
        self._orch._server_protocol.set_session_id(self._orch._session_id)
        if self._orch._progress_emitter:
            self._orch._progress_emitter.set_session_id(self._orch._session_id)

        self._register_lifecycle_hooks()

        # ISSUE-OBS-004: Set work_unit_id for event correlation
        # This enables work_unit_id to appear in all subsequent events in hybrid.jsonl
        self._orch._event_logger.set_work_unit(self._orch._session_id)
        self._orch._event_logger.set_session_context(self._orch._session_id)

        # Initialize production logger with session_id for detailed metrics
        # Writes derivation/quality metrics to resolved runtime logs/production.jsonl
        self._orch._production_logger = get_production_logger(session_id=self._orch._session_id)
        # FIX-HYBRID-053: Wire production logger into event logger for forwarding
        if self._orch._production_logger:
            self._orch._event_logger._production_logger = self._orch._production_logger

        # FEAT-SESSION-CLOSEOUT-001: Initialize invocation tracking
        self._orch._invocation.invocation_id = str(uuid.uuid4())
        self._orch._invocation.invocation_index = 1
        self._orch._invocation.invocation_start_time = time.time()
        self._orch._invocation.items_completed_this_invocation = 0
        self._orch._invocation.was_interrupted = False
        self._orch._event_logger.set_session_context(
            self._orch._session_id, self._orch._invocation.invocation_id, self._orch._invocation.invocation_index
        )
        self._orch._prepare_runtime_collaborators(force_rebuild=True)

        # Start session console logging for feedback system
        try:
            from obra.feedback import start_session_logging

            start_session_logging(self._orch._session_id)
            logger.debug(f"Session console logging started: {self._orch._session_id}")
        except Exception as e:
            # Don't fail orchestration if session logging fails
            logger.warning(f"Failed to start session console logging: {e}")

        self._orch._display_bypass_notices(server_action)

        # Extract and store server-side LLM validation results
        server_validation = server_action.metadata.get("llm_validation", {})
        self._orch._server_validation = server_validation

        # Fail-fast on tier mismatch unless --skip-tier-check is active
        skip_tier_check = "skip_tier_check" in (
            self._bypass_modes or self._orch._bypass_modes or []
        )
        mismatches: list[str] = []
        for stage, val in server_validation.items():
            if val.get("status") == "tier_mismatch":
                client_tier = self._orch._effective_llm_map.get(stage, {}).get("tier", "unknown")
                server_tier = val.get("server_tier", "unknown")
                mismatches.append(
                    f"  {stage}: client={client_tier}, server={server_tier}"
                )
                logger.warning(
                    "Server tier mismatch for %s: client=%s, server=%s",
                    stage,
                    client_tier,
                    server_tier,
                )

        if mismatches and not skip_tier_check:
            mismatch_detail = "\n".join(mismatches)
            raise OrchestratorError(
                f"Server tier mismatch detected:\n{mismatch_detail}\n\n"
                "Quality policy would use incorrect tiers. "
                "Fix: Update your config or model registry. "
                "Run 'obra config show llm' to inspect.\n"
                "Bypass: Use --skip-tier-check to proceed anyway.",
                session_id=self._orch._session_id,
                error_context=self._orch._build_error_context(action="tier_validation"),
            )

        project_notice = server_action.metadata.get("project_notice")
        if project_notice:
            print_info(project_notice)
        project_warning = server_action.metadata.get("project_warning")
        if project_warning:
            print_warning(project_warning)

        self._orch._session_start_contract_warnings = self._orch._extract_session_start_contract_warnings(
            server_action.metadata
        )
        self._orch._emit_session_start_contract_warnings(self._orch._session_start_contract_warnings)

        if server_action.is_error():
            raise OrchestratorError(
                server_action.error_message or "Failed to start session",
                session_id=self._orch._session_id,
                error_context=self._orch._build_error_context(action="start_session"),
            )

        logger.info(f"Session started: {self._orch._session_id}")
        console.print(f"Session: [cyan]{self._orch._session_id}[/cyan]")
        print_info("Pipeline: starting")

        # ISSUE-OBS-002: Log session_started event for observability
        quality_tier = self._orch._effective_llm_map.get("execute", {}).get("tier", "medium")
        self._orch._log_session_event(
            "session_started",
            objective=self._objective,
            working_dir=str(self._orch._working_dir),
            plan_id=self._plan_id,
            project_id=self._project_id,
            project_name=self._orch._project_name,
            client_version=client_version,
            quality_tier=quality_tier,
        )

        # Emit runtime environment banner (log paths + backend target)
        self._orch._emit_runtime_banner()

        # Emit full LLM Pipeline Models banner (post-session, with server validation)
        self._orch._emit_llm_pipeline_banner(self._orch._effective_llm_map, server_validation)

        # FEAT-SESSION-GUARD-001: Start session guard for zombie prevention
        # SessionGuard is accessed via _orch_module so test patches on
        # obra.hybrid.orchestrator.SessionGuard remain effective.
        self._orch._session_guard = _orch_module.SessionGuard(
            session_id=self._orch._session_id or "unknown",
            working_dir=self._orch._working_dir,
            on_warning=self._orch._handle_session_timeout_warning,
        )
        self._orch._session_guard.start()

        return server_action

    def _build_completion_notice(
        self,
        *,
        session_summary: str,
        items_completed: int,
        total_iterations: int,
        quality_score: float,
        result: dict[str, Any] | None = None,
        plan_only: bool = False,
        plan_final: list[dict[str, Any]] | None = None,
        work_summary_override: list[str] | None = None,
    ) -> CompletionNotice:
        terminal_phase = self._orch._current_phase.value if self._orch._current_phase else "unknown"
        duration_s = (
            time.time() - self._orch._invocation.invocation_start_time
            if self._orch._invocation.invocation_start_time
            else 0.0
        )
        work_summary = (
            work_summary_override
            if work_summary_override is not None
            else self._orch._extract_work_summary()
        )
        if plan_final is not None:
            # plan_final provided directly (plan-only path): compute hierarchy counts from it
            epics_total = sum(1 for item in plan_final if item.get("item_type") == "epic")
            stories_total = sum(1 for item in plan_final if item.get("item_type") == "story")
            tasks_total = sum(1 for item in plan_final if item.get("item_type") == "task")
        else:
            # fall back to result dict values (raw-dict completion path)
            plan_final = result.get("plan_final", []) if result else []
            epics_total = result.get("epics_total", 0) if result else 0
            stories_total = result.get("stories_total", 0) if result else 0
            tasks_total = result.get("tasks_total", 0) if result else 0
        return CompletionNotice(
            session_summary=session_summary,
            items_completed=items_completed,
            total_iterations=total_iterations,
            quality_score=quality_score,
            was_escalated=self._orch._was_escalated,
            terminal_phase=terminal_phase,
            objective=self._orch._objective or "",
            work_summary=work_summary,
            duration_seconds=duration_s,
            total_duration_seconds=(
                result.get("total_duration_seconds", duration_s) if result else duration_s
            ),
            invocation_count=(result.get("invocation_count", 1) if result else 1),
            files_created=[] if plan_only else self._orch._get_session_files("added"),
            files_modified=[] if plan_only else self._orch._get_session_files("modified"),
            git_branch=self._orch._run_git_command(["rev-parse", "--abbrev-ref", "HEAD"]),
            git_commit_hash="" if plan_only else self._orch._run_git_command(["rev-parse", "--short", "HEAD"]),
            termination_reason=(result.get("termination_reason", "") if result else ""),
            warnings=(result.get("warnings", []) if result else []),
            plan_final=plan_final,
            epics_completed=0 if plan_only else (result.get("epics_completed", 0) if result else 0),
            epics_total=epics_total,
            stories_completed=0 if plan_only else (result.get("stories_completed", 0) if result else 0),
            stories_total=stories_total,
            tasks_completed=0 if plan_only else (result.get("tasks_completed", 0) if result else 0),
            tasks_total=tasks_total,
        )

    def _handle_plan_only_exit(self, result: dict[str, Any], action_to_report: ActionType, iteration: int) -> CompletionNotice:
        if action_to_report == ActionType.REVISE:
            plan_summary = result.get("changes_summary", "Plan revised")
            items_count = len(result.get("plan_items", []))
        elif action_to_report == ActionType.EXAMINE:
            issues_count = len(result.get("issues", []))
            plan_summary = f"Plan examined with {issues_count} issue(s)"
            items_count = 0
        else:
            plan_summary = "Plan-only mode: stopping before execution"
            items_count = len(result.get("plan_items", []))

        # FEAT-SESSION-CLOSEOUT-001 S4.T4: Populate enhanced closeout fields
        plan_final = result.get("plan_items", [])
        if not isinstance(plan_final, list):
            plan_final = []
        plan_final = [item for item in plan_final if isinstance(item, dict)]

        notice = self._build_completion_notice(
            session_summary=f"Plan-only mode: {plan_summary}",
            items_completed=0,
            total_iterations=iteration,
            quality_score=0.0,
            plan_only=True,
            plan_final=plan_final,
            work_summary_override=[f"Plan derived with {items_count} item(s)"],
        )

        logger.info(f"Plan-only session completed: {self._orch._session_id}")
        self._orch._log_session_event(
            "session_completed",
            plan_only=True,
            plan_items_count=items_count,
            total_iterations=iteration,
        )
        self._orch._event_logger.log_pipeline_completed(self._orch._trace.pipeline_start_time, self._orch._trace.pipeline_span_id)
        self._orch._cleanup_story0_containers()
        return self._orch._append_session_start_contract_warnings(notice)

    def _handle_waiting(self, server_action: ServerAction, poll_count: int, iteration: int) -> tuple[ServerAction, int]:
        self._orch._poll_with_backoff(poll_count)
        poll_count += 1
        # ISSUE-HYBRID-003: Check for stalls during polling
        self._orch._check_stall()
        # Poll server for updated action
        # ISSUE-009 Bug #3: Use query param format (not path param)
        # Cloud Functions routing: get_session_action?session_id={id}
        try:
            response = self._orch._request_with_observability(
                "GET",
                self._orch._get_session_action_endpoint(),
            )
            # ISSUE-CLI-023: Extract and route progress events to client
            self._orch._server_protocol.handle_progress_events(
                response,
                current_phase=self._orch._current_phase.value if self._orch._current_phase else None,
                phase_span_id=self._orch._trace.phase_span_id,
                subphase_span_id=self._orch._event_logger.subphase_span_id,
            )
            server_action = self._orch._server_protocol.parse_polling_response(
                response,
                iteration,
            )
            self._orch._display_bypass_notices(server_action)
            # Reset failure count on successful poll
            self._orch._polling_failure_count = 0
        except APIError as e:
            # Increment failure counter
            self._orch._polling_failure_count += 1

            # ISSUE-CLI-012: Fast-fail on non-retryable errors (404, 401, 403)
            # These errors indicate endpoint doesn't exist or auth failure
            if hasattr(e, "status_code") and e.status_code in (404, 401, 403):
                logger.exception(
                    f"Polling endpoint returned non-retryable error {e.status_code}. "
                    f"Session: {self._orch._session_id}, "
                    f"Endpoint likely does not exist or auth failed. "
                    f"Error: {e}"
                )
                msg = (
                    f"Polling endpoint failed with non-retryable error (HTTP {e.status_code}). "
                    f"The get_session_action?session_id={self._orch._session_id} endpoint may not exist or requires authentication. "
                    f"Original error: {e}"
                )
                short_id = self._orch._session_id.split("-")[0] if self._orch._session_id else ""
                raise OrchestratorError(
                    msg,
                    session_id=self._orch._session_id,
                    recovery=f"Check server logs for endpoint availability. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                    error_context=self._orch._build_error_context(action="derive"),
                ) from e

            # Log warning on each failure
            logger.warning(
                f"Polling backoff exception (attempt {self._orch._polling_failure_count}): {e}"
            )

            # After 5 consecutive failures, log error with diagnostics
            if self._orch._polling_failure_count >= 5:
                logger.exception(
                    f"Polling endpoint failed {self._orch._polling_failure_count} consecutive times. "
                    f"Session: {self._orch._session_id}, "
                    f"Poll count: {poll_count}, "
                    f"Iteration: {iteration}, "
                    f"Last error: {e}"
                )

            # ISSUE-CLI-012: Circuit breaker - exit after max retries
            if self._orch._polling_failure_count >= MAX_POLLING_RETRIES:
                logger.exception(
                    f"Polling circuit breaker triggered after {MAX_POLLING_RETRIES} consecutive failures. "
                    f"Session: {self._orch._session_id}, "
                    f"Last error: {e}"
                )
                short_id = self._orch._session_id.split("-")[0] if self._orch._session_id else ""
                msg = (
                    f"Polling endpoint failed after {MAX_POLLING_RETRIES} consecutive attempts. "
                    f"Session: {self._orch._session_id}. "
                    f"This may indicate the endpoint does not exist or the server is not responding. "
                    f"Last error: {e}"
                    f"\n\nTry: {get_message('recovery.session.repair', short_id=short_id)}"
                )
                raise OrchestratorError(
                    msg,
                    session_id=self._orch._session_id,
                    recovery=f"Check server logs for endpoint availability. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                    error_context=self._orch._build_error_context(action="derive"),
                ) from e

            # Continue with current action if polling endpoint not available
        return server_action, poll_count

    def _handle_completion(self, result: dict[str, Any], iteration: int) -> CompletionNotice:
        notice = result.get("notice")
        if isinstance(notice, CompletionNotice):
            if not notice.terminal_phase:
                notice.terminal_phase = (
                    self._orch._current_phase.value if self._orch._current_phase else "unknown"
                )
            if self._orch._was_escalated and not notice.was_escalated:
                notice.was_escalated = True
            logger.info(f"Session completed: {self._orch._session_id}")
            # ISSUE-OBS-002: Log session_completed event
            # P0-3: Include escalation and fix-failure context so
            # production telemetry captures *why* a session ended.
            session_completed_kwargs: dict[str, Any] = {
                "items_completed": notice.items_completed,
                "tasks_total": self._orch._tasks_total,
                "total_iterations": notice.total_iterations,
                "quality_score": notice.quality_score,
                "was_escalated": self._orch._was_escalated,
            }
            if self._orch._fix_result_history:
                failed = [
                    fr for fr in self._orch._fix_result_history
                    if fr.get("status") == "failed"
                ]
                session_completed_kwargs["fix_failure_summary"] = {
                    "total_attempts": len(self._orch._fix_result_history),
                    "failed": len(failed),
                    "unresolved_canonical_ids": sorted({
                        str(fr.get("canonical_id") or fr.get("issue_id") or "")
                        for fr in failed
                        if fr.get("canonical_id") or fr.get("issue_id")
                    }),
                }
            # HYBRID-090: Emit parallelization session summary to production telemetry
            if self._orch._refinement.parallel_examine_speedups or self._orch._refinement.parallel_revise_speedups:
                avg_examine = (
                    round(sum(self._orch._refinement.parallel_examine_speedups) / len(self._orch._refinement.parallel_examine_speedups), 2)
                    if self._orch._refinement.parallel_examine_speedups else 0.0
                )
                avg_revise = (
                    round(sum(self._orch._refinement.parallel_revise_speedups) / len(self._orch._refinement.parallel_revise_speedups), 2)
                    if self._orch._refinement.parallel_revise_speedups else 0.0
                )
                if self._orch._production_logger:
                    self._orch._production_logger.log_event(
                        "parallelization_session_summary",
                        session_id=self._orch._session_id,
                        cycles_completed=len(self._orch._refinement.parallel_examine_speedups),
                        avg_examine_speedup=avg_examine,
                        avg_revise_speedup=avg_revise,
                        max_straggler_ratio=self._orch._refinement.parallel_max_straggler,
                    )
            self._orch._log_session_event(
                "session_completed",
                **session_completed_kwargs,
            )
            # FIX-COMPLETION-001: Emit progress event for celebration message
            # FIX-ESCALATION-COMPLETION-001: Include was_escalated to skip celebration
            self._orch._emit_progress(
                "session_completed",
                {
                    "items_completed": notice.items_completed,
                    "total_iterations": notice.total_iterations,
                    "quality_score": notice.quality_score,
                    "session_summary": notice.session_summary,
                    "was_escalated": self._orch._was_escalated,
                },
            )
            self._orch._commit_orphaned_changes()
            self._orch._event_logger.log_pipeline_completed(self._orch._trace.pipeline_start_time, self._orch._trace.pipeline_span_id)
            self._orch._cleanup_story0_containers()
            return self._orch._append_session_start_contract_warnings(notice)
        # Create notice from result if not already
        # FEAT-SESSION-CLOSEOUT-001 S4.T4: Populate enhanced closeout fields
        self._orch._commit_orphaned_changes()
        notice = self._build_completion_notice(
            session_summary=result.get("session_summary", ""),
            items_completed=result.get("items_completed", 0),
            total_iterations=result.get("total_iterations", iteration),
            quality_score=result.get("quality_score", 0.0),
            result=result,
        )
        # ISSUE-OBS-002: Log session_completed event for alternate completion path
        # P0-3: Enrich with escalation + fix-failure context
        alt_completed_kwargs: dict[str, Any] = {
            "items_completed": notice.items_completed,
            "total_iterations": notice.total_iterations,
            "quality_score": notice.quality_score,
            "was_escalated": self._orch._was_escalated,
        }
        if self._orch._fix_result_history:
            failed = [
                fr for fr in self._orch._fix_result_history
                if fr.get("status") == "failed"
            ]
            alt_completed_kwargs["fix_failure_summary"] = {
                "total_attempts": len(self._orch._fix_result_history),
                "failed": len(failed),
                "unresolved_canonical_ids": sorted({
                    str(fr.get("canonical_id") or fr.get("issue_id") or "")
                    for fr in failed
                    if fr.get("canonical_id") or fr.get("issue_id")
                }),
            }
        self._orch._log_session_event(
            "session_completed",
            **alt_completed_kwargs,
        )
        # FIX-COMPLETION-001: Emit progress event for celebration message
        # FIX-ESCALATION-COMPLETION-001: Include was_escalated to skip celebration
        self._orch._emit_progress(
            "session_completed",
            {
                "items_completed": notice.items_completed,
                "total_iterations": notice.total_iterations,
                "quality_score": notice.quality_score,
                "session_summary": notice.session_summary,
                "was_escalated": self._orch._was_escalated,
            },
        )
        self._orch._event_logger.log_pipeline_completed(self._orch._trace.pipeline_start_time, self._orch._trace.pipeline_span_id)
        self._orch._cleanup_story0_containers()
        return self._orch._append_session_start_contract_warnings(notice)

    def _cleanup(self) -> None:
        # (1) SessionGuard stop and None assignment
        if self._orch._session_guard:
            self._orch._session_guard.stop()
            self._orch._session_guard = None

        # (2) HTTP client close
        # ISSUE-HYBRID-035: Close HTTP session to release CLOSE_WAIT sockets
        if hasattr(self._orch._client, "close"):
            try:
                self._orch._client.close()
            except Exception:
                logger.debug("HTTP client close failed", exc_info=True)

        # (3) Fix failure summary emission
        if self._orch._progress_emitter and self._orch._fix_result_history:
            failed = [
                fr for fr in self._orch._fix_result_history
                if fr.get("status") == "failed"
            ]
            if failed:
                self._orch._progress_emitter.escalation_summary(
                    reason="session_end",
                    fix_attempts=len(self._orch._fix_result_history),
                    fix_results=failed[-5:],
                )

        # (4) Orphan request reconciliation
        # P1-2: Reconcile orphaned client requests
        for request_id in list(self._orch._inflight_client_requests):
            try:
                self._orch._log_session_event(
                    "client_request_interrupted",
                    request_id=request_id,
                    reason="session_shutdown",
                )
            except Exception:
                pass
        self._orch._inflight_client_requests.clear()

        # (5) Session interrupted safety net
        # ISSUE-HYBRID-063: Emit session_interrupted if session ended
        # without a completion event (covers Ctrl+C during LLM calls)
        # P0-2/P0-3: Include tasks_total, last_phase, and fix-failure context
        # ISSUE-HYBRID-073: Skip if already emitted (sigint path fired first)
        try:
            self._orch._emit_session_interrupted(
                reason=self._orch._resolve_interrupt_reason(fallback="session_shutdown")
            )
        except Exception:
            pass  # Best-effort — logging should never fail the finally block

        # (6) Invocation recording
        # FEAT-SESSION-CLOSEOUT-001: Record invocation for cumulative runtime tracking
        if self._orch._invocation.invocation_id and self._orch._invocation.invocation_start_time:
            duration = time.time() - self._orch._invocation.invocation_start_time
            phase_reached = self._orch._current_phase.value if self._orch._current_phase else "unknown"
            self._orch._record_invocation(
                invocation_id=self._orch._invocation.invocation_id,
                started_at=self._orch._invocation.invocation_start_time,
                duration_seconds=duration,
                termination=self._orch._get_termination_type(),
                phase_reached=phase_reached,
                items_completed=self._orch._invocation.items_completed_this_invocation,
            )

        # Lifecycle hook teardown: atexit handler self-gates via completion/interruption flags.
        # Reset module-level force-quit callback to prevent stale references.
        _orch_module._force_quit_terminal_callback = None

    def _handle_exception(self, exc: Exception) -> None:
        error_message = str(exc)
        error_class = type(exc).__name__
        self._orch._log_session_event(
            "pipeline_failed",
            failure_stage=(self._orch._current_phase.value if self._orch._current_phase else "unknown"),
            error_code="ORCHESTRATOR_ERROR",
            error_class=error_class,
            error_message=error_message,
            span_id=self._orch._trace.pipeline_span_id,
        )
        if self._orch._current_phase:
            self._orch._log_session_event(
                "phase_failed",
                phase=self._orch._current_phase.value,
                failure_stage="orchestration_loop",
                error_code="ORCHESTRATOR_ERROR",
                error_class=error_class,
                error_message=error_message,
                span_id=self._orch._trace.phase_span_id,
                parent_span_id=self._orch._trace.pipeline_span_id,
            )
        # ISSUE-OBS-003: Emit session_failed to properly close session lifecycle
        self._orch._log_session_event(
            "session_failed",
            error_code="ORCHESTRATOR_ERROR",
            error_class=error_class,
            error_message=error_message,
            phase=self._orch._current_phase.value if self._orch._current_phase else "unknown",
        )
        self._orch._cleanup_story0_containers()

    def _orchestration_loop(self, server_action: ServerAction) -> CompletionNotice:
        return run_orchestration_loop(
            self._orch,
            server_action,
            LoopConfig(
                max_iterations=self._max_iterations,
                enable_session_guard_timeout=True,
                enable_report_as_transform=True,
                enable_skip_tracking=True,
                on_plan_only_exit=self._handle_plan_only_exit if self._plan_only else None,
            ),
            callbacks=self,
        )
