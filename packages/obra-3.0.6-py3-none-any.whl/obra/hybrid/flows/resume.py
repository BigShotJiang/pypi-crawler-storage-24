"""ResumeFlow: session lifecycle runner for resume() sessions."""

from __future__ import annotations

import atexit
import logging
import time
import uuid
from datetime import UTC, datetime
from http import HTTPStatus
from typing import TYPE_CHECKING, Any

import obra.hybrid.orchestrator as _orch_module
from obra.api.protocol import (
    ActionType,
    CompletionNotice,
    ResumeContext,
    ServerAction,
    SessionPhase,
    SessionStatus,
)
from obra.config import get_max_iterations
from obra.display import console, print_info
from obra.exceptions import APIError, OrchestratorError, SessionCompletedInfo
from obra.hybrid.flows.loop_runner import LoopConfig, run_orchestration_loop
from obra.hybrid.orchestrator import MAX_POLLING_RETRIES
from obra.messages import get_message
from obra.observability.production_logger import get_production_logger

if TYPE_CHECKING:
    from obra.hybrid.orchestrator import HybridOrchestrator

logger = logging.getLogger(__name__)


class ResumeFlow:
    """Session lifecycle runner for resume() sessions.

    Extracted from HybridOrchestrator.resume() — no behavioral changes.
    Encapsulates the full resume session lifecycle: trace setup,
    session recovery, action acquisition, and the main orchestration loop.
    """

    def __init__(
        self,
        orchestrator: HybridOrchestrator,
        session_id: str,
        *,
        resume_target: str | None = None,
    ) -> None:
        self._orch = orchestrator
        self._session_id = session_id
        self._resume_target = resume_target

    def run(self) -> CompletionNotice:
        """Execute the resume session lifecycle: trace setup → session recovery → action acquisition → orchestration loop."""
        self._setup_trace_context()
        self._recover_session()
        server_action = self._acquire_resume_action()
        return self._orchestration_loop(server_action)

    def _setup_trace_context(self) -> None:
        self._orch._ensure_online()

        # ISSUE-HYBRID-023: Mark resume start time to skip historical progress events
        self._orch._server_protocol.set_resume_timestamp(datetime.now(UTC).isoformat())

        # Initialize trace context for resumed run
        if not self._orch._trace.trace_id:
            self._orch._trace.trace_id = uuid.uuid4().hex
        self._orch._trace.pipeline_span_id = uuid.uuid4().hex
        self._orch._trace.pipeline_start_time = time.time()
        try:
            self._orch._client.set_trace_context(
                self._orch._trace.trace_id, span_id=self._orch._trace.pipeline_span_id
            )
        except Exception:
            logger.debug("Failed to set trace context on API client", exc_info=True)
        self._orch._event_logger.set_trace_context(
            self._orch._trace.trace_id, span_id=self._orch._trace.pipeline_span_id
        )

        self._orch._log_session_event(
            "pipeline_started",
            objective="resume_session",
            working_dir=str(self._orch._working_dir),
            resumed_session_id=self._session_id,
            span_id=self._orch._trace.pipeline_span_id,
        )
        self._orch._log_session_event("resource_snapshot", snapshot_type="pipeline_start")

        # CLI-CACHE-MONITOR-001: Check CLI cache health before session
        self._orch._check_cli_cache_health("pre_session")

    def _recover_session(self) -> None:
        # Get session state (supports short IDs - ISSUE-SAAS-044 fix)
        try:
            response = self._orch._client.get_session(self._session_id)
            resume_payload: dict[str, Any] = {}
            if isinstance(response, dict):
                resume_payload.update(response)
                nested_context = response.get("resume_context")
                if isinstance(nested_context, dict):
                    resume_payload.update(nested_context)
            resume_context = ResumeContext.from_dict(resume_payload)
            self._orch._objective = (
                response.get("objective") if isinstance(response, dict) else None
            )
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND.value:
                msg = f"Session not found: {self._session_id}"
                raise OrchestratorError(
                    msg,
                    recovery="The session may have expired. Start a new session with 'obra derive'",
                    error_context=self._orch._build_error_context(action="resume"),
                ) from e
            raise

        if not resume_context.can_resume:
            # Build detailed message with status, reason, and recovery guidance
            status = response.get("status", resume_context.status.value)
            escalation_reason = response.get("escalation_reason")

            def _is_unknown(value: str) -> bool:
                normalized = value.strip().lower()
                return normalized in {
                    "unknown",
                    "unknown state",
                    "unknown action",
                    "unknown status",
                }

            # Get progress info from plan if available
            progress_info = ""
            try:
                plan_data = self._orch._client.get_session_plan(self._session_id)
                completed = plan_data.get("completed_count", 0)
                total = plan_data.get("total_count", 0)
                if total > 0:
                    progress_info = f"Progress: {completed}/{total} tasks completed"
            except Exception:
                pass  # Progress info is optional

            # Build message parts
            if status == SessionStatus.COMPLETED.value:
                error_parts = ["Session is completed and cannot be resumed."]
            else:
                error_parts = [f"Session cannot be resumed (status: {status})"]

            if escalation_reason:
                error_parts.append(f"Reason: {escalation_reason}")
            if resume_context.last_successful_step and not _is_unknown(
                resume_context.last_successful_step
            ):
                error_parts.append(f"Last step: {resume_context.last_successful_step}")
            if resume_context.pending_action and not _is_unknown(resume_context.pending_action):
                error_parts.append(f"Pending action: {resume_context.pending_action}")
            if resume_context.awaiting_message and not _is_unknown(
                resume_context.awaiting_message
            ):
                error_parts.append(f"Awaiting: {resume_context.awaiting_message}")
            if progress_info:
                error_parts.append(progress_info)

            error_message = "\n".join(error_parts)

            # Build recovery suggestion
            short_id = (
                self._session_id[:8] if len(self._session_id) > 8 else self._session_id
            )
            recovery_lines = []
            if resume_context.resume_instructions:
                recovery_lines.append(resume_context.resume_instructions)
            if status in (SessionStatus.ESCALATED.value, SessionStatus.COMPLETED.value):
                recovery_lines.append(
                    "To continue from the last checkpoint (reuses prior outputs):"
                )
                recovery_lines.append(f"  obra run --continue-from {short_id}")
            else:
                recovery_lines.append("Check session status:")
                recovery_lines.append(f"  obra status --session-id {short_id}")
            recovery_lines.append("To start fresh:")
            recovery_lines.append('  obra run "<objective>"')
            if status == SessionStatus.COMPLETED.value:
                recovery_lines.append(
                    "If this was unexpected, check session status or contact support with the session ID."
                )
            recovery = "\n".join(recovery_lines)

            error_cls = (
                SessionCompletedInfo
                if status == SessionStatus.COMPLETED.value
                else OrchestratorError
            )
            raise error_cls(
                error_message,
                session_id=self._session_id,
                recovery=recovery,
                error_context=self._orch._build_error_context(action="resume"),
            )

        # Use full session ID from response (in case short ID was provided)
        full_session_id = response.get("session_id", self._session_id)
        self._orch._session_id = full_session_id
        self._orch._server_protocol.set_session_id(self._orch._session_id)
        if self._orch._progress_emitter:
            self._orch._progress_emitter.set_session_id(self._orch._session_id)

        # P0-2: Register atexit handler for terminal event safety net (resume flow)
        # Covers force-quit (second Ctrl+C) where finally block doesn't complete
        atexit.register(self._orch._atexit_session_terminal_event)
        # P0-2: Set module-level callback so CLI can emit before os._exit()
        _orch_module._force_quit_terminal_callback = (
            self._orch._force_quit_session_terminal_event
        )

        # ISSUE-OBS-004: Set work_unit_id for event correlation in resume flow
        self._orch._event_logger.set_work_unit(self._orch._session_id)
        self._orch._event_logger.set_session_context(self._orch._session_id)

        # Set project context for log events (from session or auto-detect from working_dir)
        project_id = response.get("project_id")
        if not project_id and self._orch._working_dir:
            try:
                from obra.intent.storage import IntentStorage

                storage = IntentStorage()
                project_id = storage.get_project_id(self._orch._working_dir)
                logger.debug("Auto-detected project_id from working_dir: %s", project_id)
            except Exception as e:
                logger.debug("Could not auto-detect project_id: %s", e)

        if project_id:
            project_name = response.get("project_name") or self._orch._resolve_project_name(
                project_id
            )
            self._orch._project_id = project_id
            self._orch._project_name = project_name
            self._orch._event_logger.set_project(project_id, project_name)

        # Initialize production logger with session_id for detailed metrics (resume flow)
        self._orch._production_logger = get_production_logger(
            session_id=self._orch._session_id
        )
        # FIX-HYBRID-053: Wire production logger into event logger for forwarding
        if self._orch._production_logger:
            self._orch._event_logger._production_logger = self._orch._production_logger

        resume_invocation_count = 0
        if isinstance(response, dict):
            try:
                resume_invocation_count = max(
                    0,
                    int(response.get("invocation_count", 0) or 0),
                )
            except (TypeError, ValueError):
                resume_invocation_count = 0

        # FEAT-SESSION-CLOSEOUT-001: Initialize invocation tracking
        self._orch._invocation.invocation_id = str(uuid.uuid4())
        self._orch._invocation.invocation_index = (
            resume_invocation_count + 1 if resume_invocation_count else 1
        )
        self._orch._invocation.invocation_start_time = time.time()
        self._orch._invocation.items_completed_this_invocation = 0
        self._orch._invocation.was_interrupted = False
        self._orch._event_logger.set_session_context(
            self._orch._session_id, self._orch._invocation.invocation_id, self._orch._invocation.invocation_index
        )
        self._orch._prepare_runtime_collaborators(force_rebuild=True)

        console.print(f"Resuming session: [cyan]{self._orch._session_id}[/cyan]")
        print_info(f"  Last step: {resume_context.last_successful_step}")

        self._orch._log_session_event(
            "session_resumed",
            resumed_from=resume_context.last_successful_step,
            resumed_from_phase=(
                resume_context.current_phase.value if resume_context.current_phase else None
            ),
        )

        # R1-FIX: Restore tracker state from server-side plan on resume.
        # get_session_plan() returns items with per-item status (completed/pending/…).
        # Feeding them through the full update_plan_snapshot path populates:
        #   _plan_status  → enables story/epic completion detection
        #   _task_tracker_done (via set_plan_items) → fixes counter & Next queue
        #   _completed_stories / _completed_epics  → prevents duplicate milestones
        self._orch._resume_completed_item_ids: set[str] = set()
        if self._orch._progress_emitter:
            try:
                plan_data = self._orch._client.get_session_plan(self._orch._session_id)
                resume_plan_items = plan_data.get("plan_items", [])
                if resume_plan_items:
                    self._orch._progress_emitter.update_plan_snapshot(
                        resume_plan_items,
                        source="resume",
                        session_id=self._orch._session_id,
                    )
                    # Cache completed item IDs for the R2 duplicate-execution guard.
                    for pi in resume_plan_items:
                        if isinstance(pi, dict):
                            pi_status = str(pi.get("status", "")).strip().lower()
                            pi_id = str(
                                pi.get("id") or pi.get("item_id") or ""
                            ).strip()
                            if pi_id and pi_status in ("completed", "complete", "done", "skipped"):
                                self._orch._resume_completed_item_ids.add(pi_id)
                    # SESSION-92257c4c: Set tasks_total from resume plan so
                    # interruption telemetry doesn't report tasks_total=0.
                    from obra.hybrid.dispatch.dispatcher import count_task_items

                    task_count = count_task_items(resume_plan_items)
                    if task_count > 0:
                        self._orch._tasks_total = task_count
                    logger.info(
                        "Resume: restored tracker state from plan (%d items, %d completed, %d tasks)",
                        len(resume_plan_items),
                        len(self._orch._resume_completed_item_ids),
                        task_count,
                    )
                    # SESSION-92257c4c: Display previously completed items so
                    # the user sees where the session is resuming from.
                    completed_count = len(self._orch._resume_completed_item_ids)
                    if completed_count > 0 and task_count > 0:
                        # Show abbreviated item IDs (first 5, then "...")
                        completed_ids = sorted(self._orch._resume_completed_item_ids)
                        if len(completed_ids) <= 5:
                            id_list = ", ".join(completed_ids)
                        else:
                            id_list = ", ".join(completed_ids[:5]) + f" … +{len(completed_ids) - 5} more"
                        print_info(
                            f"  Previously completed: {id_list} ({completed_count}/{task_count})"
                        )
                        print_info(
                            f"  Invocation: {self._orch._invocation.invocation_id}"
                        )
            except Exception:
                logger.debug("Resume: could not restore plan state", exc_info=True)

        # R6-FIX: Restore pipeline banner checkmarks for phases completed before resume.
        if self._orch._progress_emitter and resume_context.current_phase:
            self._orch._progress_emitter.restore_pipeline_checkmarks(
                resume_context.current_phase.value,
            )

        self._session_response = response
        self._resume_context = resume_context

    def _acquire_resume_action(self) -> ServerAction:
        # Request resume from server
        try:
            resume_request: dict[str, Any] = {"session_id": self._orch._session_id}
            if self._orch._bypass_modes:
                resume_request["bypass_modes"] = self._orch._bypass_modes
            if self._resume_target:
                resume_request["resume_target"] = self._resume_target
            response = self._orch._request_with_observability(
                "POST",
                "resume",
                json=resume_request,
            )
        except APIError as e:
            response_preview = ""
            if e.response_body:
                response_preview = str(e.response_body).strip()
                if len(response_preview) > 300:
                    response_preview = f"{response_preview[:300]}..."
            recovery_lines = [e.recovery]
            if response_preview:
                recovery_lines.append(f"Server response: {response_preview}")
            if self._orch._trace.trace_id:
                recovery_lines.append(f"Trace ID: {self._orch._trace.trace_id}")
            recovery = "\n".join(recovery_lines)
            msg = f"Failed to resume session: {e}"
            raise OrchestratorError(
                msg,
                session_id=self._session_id,
                recovery=recovery,
                error_context=self._orch._build_error_context(action="resume"),
            ) from e

        if not isinstance(response, dict):
            msg = "Resume response invalid (expected object)."
            raise OrchestratorError(
                msg,
                session_id=self._session_id,
                recovery=f"Check session status:\n  obra status --session-id {self._session_id[:8]}",
                error_context=self._orch._build_error_context(action="resume"),
            )

        allowed_keys = {
            "action",
            "session_id",
            "iteration",
            "payload",
            "metadata",
            "bypass_modes_active",
            "error_code",
            "error_message",
            "timestamp",
            "rationale",
        }
        if "action" not in response:
            try:
                poll_response = self._orch._request_with_observability(
                    "GET",
                    self._orch._get_session_action_endpoint(),
                )
            except Exception as e:
                poll_response = None
                poll_error: Exception | None = e
            else:
                poll_error = None

            if isinstance(poll_response, dict):
                self._orch._server_protocol.handle_progress_events(
                    poll_response,
                    current_phase=(
                        self._orch._current_phase.value if self._orch._current_phase else None
                    ),
                    phase_span_id=self._orch._trace.phase_span_id,
                    subphase_span_id=self._orch._event_logger.subphase_span_id,
                )
                if "action" in poll_response and "session_id" in poll_response:
                    sanitized_response = {
                        key: value
                        for key, value in poll_response.items()
                        if key in allowed_keys
                    }
                    try:
                        server_action = ServerAction.from_dict(sanitized_response)
                        self._orch._display_bypass_notices(server_action)
                    except ValueError as e:
                        poll_error = e
                else:
                    try:
                        server_action = self._orch._server_protocol.parse_polling_response(
                            poll_response,
                            iteration=0,
                        )
                        self._orch._display_bypass_notices(server_action)
                    except Exception as e:
                        poll_error = e
            else:
                poll_error = poll_error or OrchestratorError(
                    "Resume polling response invalid (expected object).",
                    session_id=self._session_id,
                )

            if poll_error is not None:
                recovered_action: ServerAction | None = None
                if self._resume_context.current_phase == SessionPhase.REVIEW:
                    try:
                        events_payload = self._orch._client.get_session_events(
                            session_id=self._orch._session_id,
                            limit=50,
                        )
                        events = events_payload.get("events", [])
                    except Exception:
                        events = []
                    item_id = None
                    if isinstance(events, list):
                        for event in reversed(events):
                            if not isinstance(event, dict):
                                continue
                            event_type = event.get("event_type") or event.get("type")
                            if event_type not in ("item_completed", "item_started"):
                                continue
                            item = event.get("item")
                            if isinstance(item, dict):
                                item_id = item.get("id") or item.get("item_id")
                            if not item_id:
                                item_id = event.get("item_id")
                            if item_id:
                                break
                    if item_id:
                        recovered_action = ServerAction.from_dict(
                            {
                                "action": ActionType.REVIEW.value,
                                "session_id": self._orch._session_id,
                                "iteration": response.get("iteration", 0),
                                "payload": {"item_id": item_id},
                            }
                        )

                if recovered_action is not None:
                    server_action = recovered_action
                else:
                    status_value = response.get("status", self._resume_context.status.value)
                    if not isinstance(status_value, str):
                        status_value = str(status_value)
                    short_id = (
                        self._session_id[:8] if len(self._session_id) > 8 else self._session_id
                    )
                    recovery_lines = []
                    if self._resume_context.resume_instructions:
                        recovery_lines.append(self._resume_context.resume_instructions)
                    if status_value in ("escalated", "completed"):
                        recovery_lines.append("To continue from the last checkpoint:")
                        recovery_lines.append(f"  obra run --continue-from {short_id}")
                    else:
                        recovery_lines.append("Check session status:")
                        recovery_lines.append(f"  obra status --session-id {short_id}")
                    recovery_lines.append("To start fresh:")
                    recovery_lines.append('  obra run "<objective>"')
                    msg = f"Resume response missing required action (status: {status_value})."
                    raise OrchestratorError(
                        msg,
                        session_id=self._session_id,
                        recovery="\n".join(recovery_lines),
                    ) from poll_error
        else:
            sanitized_response = {
                key: value for key, value in response.items() if key in allowed_keys
            }
            try:
                server_action = ServerAction.from_dict(sanitized_response)
                self._orch._display_bypass_notices(server_action)
            except ValueError as e:
                short_id = (
                    self._session_id[:8] if len(self._session_id) > 8 else self._session_id
                )
                msg = f"Resume response invalid: {e}"
                raise OrchestratorError(
                    msg,
                    session_id=self._session_id,
                    recovery=f"Check session status:\n  obra status --session-id {short_id}",
                ) from e

        # Restore _last_item_id for REVIEW action if not in payload
        # This enables the fallback at line ~1982 when server doesn't include item_id
        if server_action.action == ActionType.REVIEW and not server_action.payload.get("item_id"):
            item_id = None
            # Try 1: Get from session events
            try:
                events_payload = self._orch._client.get_session_events(
                    session_id=self._orch._session_id,
                    limit=50,
                )
                events = events_payload.get("events", [])
            except Exception:
                events = []
            if isinstance(events, list):
                for event in reversed(events):
                    if not isinstance(event, dict):
                        continue
                    event_type = event.get("event_type") or event.get("type")
                    if event_type not in ("item_completed", "item_started"):
                        continue
                    item = event.get("item")
                    if isinstance(item, dict):
                        item_id = item.get("id") or item.get("item_id")
                    if not item_id:
                        item_id = event.get("item_id")
                    if item_id:
                        break

            # Try 2: Get from session plan (last completed or in_progress item)
            if not item_id:
                try:
                    plan_data = self._orch._client.get_session_plan(self._orch._session_id)
                    plan_items = plan_data.get("plan_items", [])
                    # Find the last completed or in_progress item
                    for plan_item in reversed(plan_items):
                        if isinstance(plan_item, dict):
                            status = plan_item.get("status", "")
                            if status in ("completed", "in_progress"):
                                item_id = plan_item.get("id") or plan_item.get("item_id")
                                if item_id:
                                    logger.debug(
                                        "Restored item_id from session plan: %s",
                                        item_id,
                                    )
                                    break
                except Exception:
                    pass

            if item_id:
                self._orch._last_item_id = item_id
                logger.debug("Restored _last_item_id from recovery: %s", item_id)

        return server_action

    def _handle_completion(self, result: dict[str, Any], iteration: int) -> CompletionNotice:
        notice = result.get("notice")
        if isinstance(notice, CompletionNotice):
            if not notice.terminal_phase:
                notice.terminal_phase = (
                    self._orch._current_phase.value
                    if self._orch._current_phase
                    else "unknown"
                )
            if self._orch._was_escalated and not notice.was_escalated:
                notice.was_escalated = True
            self._orch._log_session_event(
                "session_completed",
                items_completed=notice.items_completed,
                tasks_total=self._orch._tasks_total,
                total_iterations=notice.total_iterations,
                quality_score=notice.quality_score,
            )
            self._orch._emit_progress(
                "session_completed",
                {
                    "items_completed": notice.items_completed,
                    "total_iterations": notice.total_iterations,
                    "quality_score": notice.quality_score,
                    "session_summary": notice.session_summary,
                    "was_escalated": self._orch._was_escalated,
                },
            )
            self._orch._commit_orphaned_changes()
            self._orch._event_logger.log_pipeline_completed(self._orch._trace.pipeline_start_time, self._orch._trace.pipeline_span_id)
            self._orch._cleanup_story0_containers()
            return self._orch._append_session_start_contract_warnings(notice)
        self._orch._log_session_event(
            "session_completed",
            items_completed=result.get("items_completed", 0),
            tasks_total=self._orch._tasks_total,
            total_iterations=result.get("total_iterations", iteration),
            quality_score=result.get("quality_score", 0.0),
        )
        self._orch._emit_progress(
            "session_completed",
            {
                "items_completed": result.get("items_completed", 0),
                "total_iterations": result.get("total_iterations", iteration),
                "quality_score": result.get("quality_score", 0.0),
                "session_summary": result.get("session_summary", ""),
                "was_escalated": self._orch._was_escalated,
            },
        )
        self._orch._commit_orphaned_changes()
        self._orch._event_logger.log_pipeline_completed(self._orch._trace.pipeline_start_time, self._orch._trace.pipeline_span_id)
        self._orch._cleanup_story0_containers()
        return self._orch._append_session_start_contract_warnings(
            self._build_completion_notice(
                session_summary=result.get("session_summary", ""),
                items_completed=result.get("items_completed", 0),
                total_iterations=result.get("total_iterations", iteration),
                quality_score=result.get("quality_score", 0.0),
                result=result,
            )
        )

    def _handle_waiting(
        self, server_action: ServerAction, poll_count: int, iteration: int
    ) -> tuple[ServerAction, int]:
        self._orch._poll_with_backoff(poll_count)
        poll_count += 1
        # ISSUE-HYBRID-003: Check for stalls during polling
        self._orch._check_stall()
        # Poll server for updated action
        # ISSUE-009 Bug #3: Use query param format (not path param)
        # Cloud Functions routing: get_session_action?session_id={id}
        try:
            response = self._orch._request_with_observability(
                "GET",
                self._orch._get_session_action_endpoint(),
            )
            self._orch._server_protocol.handle_progress_events(
                response,
                current_phase=(
                    self._orch._current_phase.value
                    if self._orch._current_phase
                    else None
                ),
                phase_span_id=self._orch._trace.phase_span_id,
                subphase_span_id=self._orch._event_logger.subphase_span_id,
            )
            server_action = self._orch._server_protocol.parse_polling_response(
                response,
                iteration=iteration,
            )
            # Reset failure count on successful poll
            self._orch._polling_failure_count = 0
        except APIError as e:
            # Increment failure counter
            self._orch._polling_failure_count += 1

            # ISSUE-CLI-012: Fast-fail on non-retryable errors (404, 401, 403)
            if hasattr(e, "status_code") and e.status_code in (
                404,
                401,
                403,
            ):
                logger.exception(
                    f"Resume polling endpoint returned non-retryable error {e.status_code}. "
                    f"Session: {self._orch._session_id}, Error: {e}"
                )
                msg = (
                    f"Resume polling endpoint failed with non-retryable error (HTTP {e.status_code}). "
                    f"Original error: {e}"
                )
                short_id = (
                    self._orch._session_id.split("-")[0]
                    if self._orch._session_id
                    else ""
                )
                raise OrchestratorError(
                    msg,
                    session_id=self._orch._session_id,
                    recovery=f"Check server logs. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                ) from e

            # ISSUE-CLI-012: Circuit breaker - exit after max retries
            if self._orch._polling_failure_count >= MAX_POLLING_RETRIES:
                logger.exception(
                    f"Resume polling circuit breaker triggered after {MAX_POLLING_RETRIES} failures. "
                    f"Session: {self._orch._session_id}, Last error: {e}"
                )
                short_id = (
                    self._orch._session_id.split("-")[0]
                    if self._orch._session_id
                    else ""
                )
                msg = (
                    f"Resume polling failed after {MAX_POLLING_RETRIES} attempts. "
                    f"Last error: {e}"
                )
                raise OrchestratorError(
                    msg,
                    session_id=self._orch._session_id,
                    recovery=f"Check server status. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
                ) from e

            # If polling endpoint not available, continue with current action
            logger.warning(
                f"Resume polling attempt {self._orch._polling_failure_count} failed: {e}"
            )
        return server_action, poll_count

    def _build_completion_notice(
        self,
        *,
        session_summary: str,
        items_completed: int,
        total_iterations: int,
        quality_score: float,
        result: dict[str, Any],
    ) -> CompletionNotice:
        # FEAT-SESSION-CLOSEOUT-001 S4.T4: Populate enhanced closeout fields
        resume_duration_s = (
            time.time() - self._orch._invocation.invocation_start_time
            if self._orch._invocation.invocation_start_time
            else 0.0
        )
        return CompletionNotice(
            session_summary=session_summary,
            items_completed=items_completed,
            total_iterations=total_iterations,
            quality_score=quality_score,
            was_escalated=self._orch._was_escalated,
            terminal_phase=(
                self._orch._current_phase.value
                if self._orch._current_phase
                else "unknown"
            ),
            # Enhanced closeout fields
            objective=self._orch._objective or "",
            work_summary=self._orch._extract_work_summary(),
            duration_seconds=resume_duration_s,
            total_duration_seconds=result.get("total_duration_seconds", resume_duration_s),
            invocation_count=result.get("invocation_count", 1),
            files_created=self._orch._get_session_files("added"),
            files_modified=self._orch._get_session_files("modified"),
            git_branch=self._orch._run_git_command(["rev-parse", "--abbrev-ref", "HEAD"]),
            git_commit_hash=self._orch._run_git_command(["rev-parse", "--short", "HEAD"]),
            termination_reason=result.get("termination_reason", ""),
            warnings=result.get("warnings", []),
            plan_final=result.get("plan_final", []),
            epics_completed=result.get("epics_completed", 0),
            epics_total=result.get("epics_total", 0),
            stories_completed=result.get("stories_completed", 0),
            stories_total=result.get("stories_total", 0),
            tasks_completed=result.get("tasks_completed", 0),
            tasks_total=result.get("tasks_total", 0),
        )

    def _handle_exception(self, exc: Exception) -> None:
        error_message = str(exc)
        error_class = type(exc).__name__
        self._orch._log_session_event(
            "pipeline_failed",
            failure_stage=(
                self._orch._current_phase.value if self._orch._current_phase else "unknown"
            ),
            error_code="ORCHESTRATOR_ERROR",
            error_class=error_class,
            error_message=error_message,
            span_id=self._orch._trace.pipeline_span_id,
        )
        if self._orch._current_phase:
            self._orch._log_session_event(
                "phase_failed",
                phase=self._orch._current_phase.value,
                failure_stage="resume_loop",
                error_code="ORCHESTRATOR_ERROR",
                error_class=error_class,
                error_message=error_message,
                span_id=self._orch._trace.phase_span_id,
                parent_span_id=self._orch._trace.pipeline_span_id,
            )
        # ISSUE-OBS-003: Emit session_failed to properly close session lifecycle
        self._orch._log_session_event(
            "session_failed",
            error_code="ORCHESTRATOR_ERROR",
            error_class=error_class,
            error_message=error_message,
            phase=self._orch._current_phase.value if self._orch._current_phase else "unknown",
        )
        self._orch._cleanup_story0_containers()

    def _cleanup(self) -> None:
        # Emit fix failure summary if any fixes failed during session
        if self._orch._progress_emitter and self._orch._fix_result_history:
            failed = [
                fr for fr in self._orch._fix_result_history
                if fr.get("status") == "failed"
            ]
            if failed:
                self._orch._progress_emitter.escalation_summary(
                    reason="session_end",
                    fix_attempts=len(self._orch._fix_result_history),
                    fix_results=failed[-5:],
                )

        # P1-2: Reconcile orphaned client requests
        for request_id in list(self._orch._inflight_client_requests):
            try:
                self._orch._log_session_event(
                    "client_request_interrupted",
                    request_id=request_id,
                    reason="session_shutdown",
                )
            except Exception:
                pass
        self._orch._inflight_client_requests.clear()

        # ISSUE-HYBRID-063: Emit session_interrupted if session ended
        # without a completion event (covers Ctrl+C during LLM calls)
        # P0-2/P0-3: Include tasks_total, last_phase, and fix-failure context
        # ISSUE-HYBRID-073: Skip if already emitted (sigint path fired first)
        try:
            self._orch._emit_session_interrupted(
                reason=self._orch._resolve_interrupt_reason(fallback="session_shutdown")
            )
        except Exception:
            pass  # Best-effort — logging should never fail the finally block

        # FEAT-SESSION-CLOSEOUT-001: Record invocation for cumulative runtime tracking
        if self._orch._invocation.invocation_id and self._orch._invocation.invocation_start_time:
            duration = time.time() - self._orch._invocation.invocation_start_time
            phase_reached = (
                self._orch._current_phase.value if self._orch._current_phase else "unknown"
            )
            self._orch._record_invocation(
                invocation_id=self._orch._invocation.invocation_id,
                started_at=self._orch._invocation.invocation_start_time,
                duration_seconds=duration,
                termination=self._orch._get_termination_type(),
                phase_reached=phase_reached,
                items_completed=self._orch._invocation.items_completed_this_invocation,
            )

    def _orchestration_loop(self, server_action: ServerAction) -> CompletionNotice:
        return run_orchestration_loop(
            self._orch,
            server_action,
            LoopConfig(
                max_iterations=get_max_iterations(),
                enable_session_guard_timeout=True,
                enable_report_as_transform=True,
                enable_skip_tracking=True,
            ),
            callbacks=self,
        )
