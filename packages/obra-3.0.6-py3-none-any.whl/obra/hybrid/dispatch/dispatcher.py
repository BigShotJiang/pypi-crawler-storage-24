"""ActionDispatcher extracted from HybridOrchestrator._dispatch_handler.

Routes server action types to private handler methods through four
context protocol dataclasses, replacing the 29-attribute direct coupling
between the dispatcher and the orchestrator.
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable
from typing import Any, cast

from obra.api.protocol import (
    ActionType,
    DeriveRequest,
    ExecutionRequest,
    ExecutionStatus,
    FixRequest,
    IntentRequest,
    PipelineStageRequest,
    ReviewRequest,
    ServerAction,
    StoryPreflightRequest,
)
from obra.core.interrupts import GracefulInterrupt, interrupt_requested
from obra.display import console, print_warning
from obra.display.observability import VerbosityLevel
from obra.exceptions import OrchestratorError
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.hybrid.dispatch.context import (
    ExecutionState,
    HandlerFactoryProtocol,
    ObservabilityContext,
    PhaseControl,
)
from obra.hybrid.dispatch.dispatcher_support import (
    ResolvedItemOutcome,
    count_task_items,
    inject_defaults_into_prompt,
    summarize_userplan_steps,
)
from obra.hybrid.dispatch.item_skip import ItemSkipManager
from obra.hybrid.dispatch.refinement_guard import RefinementGuard
from obra.hybrid.dispatch.verification_tools import build_fix_handler_tools
from obra.hybrid.plan_merger import PlanMerger
from obra.hybrid.tooling_discovery import ToolingDiscovery

logger = logging.getLogger(__name__)

class ActionDispatcher:
    """Routes server actions to handler methods through context protocols.

    Extracted from HybridOrchestrator._dispatch_handler. All orchestrator
    attribute access is mediated through four context protocol objects.
    """

    def __init__(
        self,
        observability: ObservabilityContext,
        phase_control: PhaseControl,
        execution_state: ExecutionState,
        handler_factory: HandlerFactoryProtocol,
    ) -> None:
        self._obs = observability
        self._phase = phase_control
        self._state = execution_state
        self._factory = handler_factory
        self._refinement_guard = RefinementGuard(
            production_logger=self._obs.production_logger,
            session_id=self._obs.session_id,
            get_refinement_cycle_count=self._state.get_refinement_cycle_count,
        )
        self._skip_manager = ItemSkipManager(
            execution_state=self._state,
            phase_control=self._phase,
            observability=self._obs,
        )

    # ------------------------------------------------------------------
    # Subphase lifecycle helper
    # ------------------------------------------------------------------

    def _invoke_with_subphase(
        self,
        subphase_name: str,
        handler: Any,
        handler_call: Callable[[], Any],
    ) -> dict[str, Any]:
        """Execute handler_call within subphase lifecycle management.

        Sets handler._parent_span_id if the attribute exists, starts and
        completes the subphase, and emits phase_failed on error.
        """
        start = self._phase.start_subphase(subphase_name)
        if hasattr(handler, "_parent_span_id"):
            handler._parent_span_id = self._phase.subphase_span_id_getter()
        try:
            result = handler_call()
        except Exception as e:
            self._phase.complete_subphase(
                subphase_name, start, status="error", error_message=str(e)
            )
            current_phase = self._phase.get_current_phase()
            if current_phase:
                self._obs.log_session_event(
                    "phase_failed",
                    phase=current_phase.value,
                    failure_stage=subphase_name,
                    error_code="HANDLER_ERROR",
                    error_class=type(e).__name__,
                    error_message=str(e),
                    span_id=self._obs.phase_span_id,
                    parent_span_id=self._obs.pipeline_span_id,
                )
            raise
        self._phase.complete_subphase(subphase_name, start)
        return result

    def _load_tooling_discovery_cache(self) -> dict[str, Any] | None:
        """Load ToolingDiscovery cache for verification tool command resolution."""
        try:
            return ToolingDiscovery(self._state.working_dir, {}).load_cache()
        except Exception as exc:
            logger.debug("Failed to load ToolingDiscovery cache: %s", exc)
            return None

    def _log_phase_failed(
        self,
        *,
        failure_stage: str,
        error_code: str,
        error: Exception,
    ) -> None:
        """Emit a phase_failed session event when a phase is active."""
        current_phase = self._phase.get_current_phase()
        if not current_phase:
            return
        self._obs.log_session_event(
            "phase_failed",
            phase=current_phase.value,
            failure_stage=failure_stage,
            error_code=error_code,
            error_class=type(error).__name__,
            error_message=str(error),
            span_id=self._obs.phase_span_id,
            parent_span_id=self._obs.pipeline_span_id,
        )

    def _configure_fix_handler_verification_tools(
        self,
        fix_handler: Any,
        *,
        source_label: str,
    ) -> None:
        """Pass discovered verification tools to FixHandler paths."""
        verification_tools = self._state.get_verification_tools()
        if not verification_tools or not hasattr(fix_handler, "_verification_tools"):
            return

        available_tools = verification_tools.get("available", [])
        if not available_tools:
            return

        discovery_data = self._load_tooling_discovery_cache()
        tool_configs = build_fix_handler_tools(
            available_tools,
            discovery_data=discovery_data,
        )
        if not tool_configs:
            return

        fix_handler._verification_tools = tool_configs
        logger.info(
            "Passed %d verification tools to FixHandler (%s): %s",
            len(tool_configs),
            source_label,
            [tool["name"] for tool in tool_configs],
        )

    def _handle_execute_fix_compat(
        self,
        payload: dict[str, Any],
        *,
        subphase_start: float,
    ) -> dict[str, Any]:
        """Handle legacy EXECUTE payloads that carry fix data."""
        fix_handler = self._factory.get_handler(ActionType.FIX)
        if hasattr(fix_handler, "_parent_span_id"):
            fix_handler._parent_span_id = self._phase.subphase_span_id_getter()
        self._configure_fix_handler_verification_tools(
            fix_handler,
            source_label="compat path",
        )

        fix_req = FixRequest.from_payload(payload)
        try:
            fix_result = cast(dict[str, Any], fix_handler.handle(fix_req))
        except Exception as error:
            self._phase.complete_subphase(
                "execute",
                subphase_start,
                status="error",
                error_message=str(error),
            )
            self._log_phase_failed(
                failure_stage="execute",
                error_code="HANDLER_ERROR",
                error=error,
            )
            raise

        fix_result["_report_as"] = ActionType.FIX.value
        self._phase.complete_subphase("execute", subphase_start)
        return fix_result

    # ------------------------------------------------------------------
    # Main dispatch entry point
    # ------------------------------------------------------------------

    def dispatch(
        self,
        handler: Any,
        action: ActionType,
        payload: dict[str, Any],
        server_action: ServerAction | None = None,
    ) -> dict[str, Any]:
        """Route action to the appropriate private handler method.

        Updates the session guard heartbeat on every call so the
        session-*.json stays fresh during long refinement cycles.
        """
        # ISSUE-HYBRID-033: Update heartbeat on every handler dispatch.
        if self._state.session_guard:
            self._state.session_guard.update(
                items_completed=self._state.get_items_completed(),
                phase=(
                    self._phase.get_current_phase().value
                    if self._phase.get_current_phase()
                    else "unknown"
                ),
            )

        if action == ActionType.INTENT:
            return self._dispatch_intent(handler, payload)
        if action == ActionType.DERIVE:
            return self._dispatch_derive(handler, payload)
        if action == ActionType.STORY0:
            return self._dispatch_story0(handler, payload)
        if action == ActionType.STORY_PREFLIGHT:
            return self._dispatch_story_preflight(handler, payload)
        if action == ActionType.EXAMINE:
            return self._dispatch_examine(handler, payload, server_action)
        if action == ActionType.REVISE:
            return self._dispatch_revise(handler, payload, server_action)
        if action == ActionType.EXECUTE:
            return self._dispatch_execute(handler, payload)
        if action == ActionType.REVIEW:
            return self._dispatch_review(handler, payload)
        if action == ActionType.PIPELINE_STAGE:
            return self._dispatch_pipeline_stage(handler, payload)
        if action == ActionType.FIX:
            return self._dispatch_fix(handler, payload)
        if action == ActionType.VALIDATOR:
            return self._dispatch_validator(handler, payload)
        msg = f"Unhandled action: {action.value}"
        raise OrchestratorError(
            msg,
            session_id=self._obs.session_id or "",
        )

    # ------------------------------------------------------------------
    # Individual action dispatch methods
    # ------------------------------------------------------------------

    def _dispatch_intent(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        intent_req = IntentRequest.from_payload(payload)
        self._state.set_last_userplan_id(intent_req.userplan_id)
        self._state.set_last_userplan_version(intent_req.userplan_version)
        self._state.set_derive_from_step(intent_req.from_step)
        return cast(
            dict[str, Any],
            self._invoke_with_subphase(
                "intent", handler, lambda: handler.handle(intent_req)
            ),
        )

    def _dispatch_derive(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        derive_req = DeriveRequest.from_payload(payload)
        # Store userplan info for DerivedPlan reporting
        self._state.set_last_userplan_id(derive_req.userplan_id)
        self._state.set_last_userplan_version(derive_req.userplan_version)
        # Store preserved plan items for --from-step re-derivation merge
        self._state.set_preserved_plan_items(derive_req.plan_items_reference)
        self._state.set_derive_from_step(derive_req.from_step)
        subphase_start = self._phase.start_subphase("derive")
        if hasattr(handler, "_parent_span_id"):
            handler._parent_span_id = self._phase.subphase_span_id_getter()
        summarized_steps, steps_truncated = summarize_userplan_steps(
            derive_req.userplan_steps,
            self._obs.get_log_viewer_int,
        )
        snapshot_ref = self._factory.write_plan_snapshot(
            session_id=self._obs.session_id or "",
            userplan_id=derive_req.userplan_id,
            userplan_version=derive_req.userplan_version,
            userplan_steps=derive_req.userplan_steps,
        )
        self._obs.log_session_event(
            "userplan_snapshot",
            userplan_id=derive_req.userplan_id,
            userplan_version=derive_req.userplan_version,
            userplan_steps_count=len(derive_req.userplan_steps),
            userplan_steps=summarized_steps,
            truncated=steps_truncated,
            plan_snapshot_ref=snapshot_ref,
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )
        # ISSUE-OBS-002: Log derivation_started event
        self._obs.log_session_event(
            "derivation_started",
            objective=derive_req.objective,
            plan_id=getattr(derive_req, "plan_id", None),
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )
        try:
            result = cast(dict[str, Any], handler.handle(derive_req))
        except Exception as e:
            self._phase.complete_subphase(
                "derive", subphase_start, status="error", error_message=str(e)
            )
            current_phase = self._phase.get_current_phase()
            if current_phase:
                self._obs.log_session_event(
                    "phase_failed",
                    phase=current_phase.value,
                    failure_stage="derive",
                    error_code="HANDLER_ERROR",
                    error_class=type(e).__name__,
                    error_message=str(e),
                    span_id=self._obs.phase_span_id,
                    parent_span_id=self._obs.pipeline_span_id,
                )
            raise
        # ISSUE-OBS-002: Log derivation_complete event
        self._obs.log_session_event(
            "derivation_complete",
            plan_items_count=len(result.get("plan_items", [])),
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )
        # FIX-TRACKER-001: Store plan items for phase_completed event
        self._state.set_last_derivation_plan_items(result.get("plan_items", []))
        # P0-2: Track total tasks for terminal event context
        self._state.set_tasks_total(
            count_task_items(self._state.get_last_derivation_plan_items())
        )
        self._phase.complete_subphase(
            "derive",
            subphase_start,
            active_duration_ms=result.get("active_duration_ms"),
        )
        return result

    def _dispatch_story0(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        story0_prerequisites = payload.get("story0_prerequisites", [])
        objective = payload.get("objective") or self._state.objective or ""
        if hasattr(handler, "_objective") and objective:
            handler._objective = objective  # type: ignore[attr-defined]
        result = handler.handle(
            story0_prerequisites,
            resume_reason=payload.get("story0_resume_reason"),
            missing_tools=payload.get("missing_tools"),
        )
        # S0.T7: Store verification tools for mid-session FIX checks
        if result.verification_tools:
            self._state.set_verification_tools(result.verification_tools)
            logger.info(
                "Story 0 returned verification_tools: %s",
                result.verification_tools,
            )
        if payload.get("story0_resume_reason") == "verification_tools_missing":
            self._state.set_verification_preflight_attempted(True)
            logger.info("Verification preflight attempted flag set to True")

        completed_prereqs = list(getattr(result, "completed", []) or [])
        failed_prereqs = list(getattr(result, "failed", []) or [])
        skipped_prereqs = list(getattr(result, "skipped", []) or [])
        blocking_failures = list(getattr(result, "blocking_failures", []) or [])
        non_blocking_failures = list(getattr(result, "non_blocking_failures", []) or [])
        mocked_credentials = list(getattr(result, "mocked_credentials", []) or [])
        verification_tools = getattr(result, "verification_tools", {}) or {}

        completed_ids = {str(item).strip() for item in completed_prereqs if str(item).strip()}
        failed_ids = {str(item).strip() for item in failed_prereqs if str(item).strip()}
        skipped_ids = {str(item).strip() for item in skipped_prereqs if str(item).strip()}

        normalized_prereqs: list[dict[str, Any]] = []
        if isinstance(story0_prerequisites, list):
            for prereq in story0_prerequisites:
                if not isinstance(prereq, dict):
                    continue
                prereq_id = str(prereq.get("id") or prereq.get("name") or "").strip()
                prereq_name = str(prereq.get("name") or prereq_id or "unknown").strip()
                lookup_keys = [key for key in (prereq_id, prereq_name) if key]
                if any(key in completed_ids for key in lookup_keys):
                    prereq_status = "installed"
                elif any(key in failed_ids for key in lookup_keys):
                    prereq_status = "failed"
                elif any(key in skipped_ids for key in lookup_keys):
                    prereq_status = "skipped"
                else:
                    prereq_status = "pending"
                normalized_prereqs.append(
                    {
                        "id": prereq_id or prereq_name,
                        "name": prereq_name,
                        "category": str(prereq.get("category", "")).upper(),
                        "source": str(prereq.get("source", "")).upper(),
                        "ecosystem": str(prereq.get("ecosystem", "")),
                        "reason": str(prereq.get("reason", "")),
                        "status": prereq_status,
                    }
                )

        def _dedupe(values: list[str]) -> list[str]:
            ordered: list[str] = []
            seen: set[str] = set()
            for value in values:
                item = str(value).strip()
                if not item or item in seen:
                    continue
                seen.add(item)
                ordered.append(item)
            return ordered

        installed_manifest = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "installed" and prereq.get("source") == "MANIFEST"
            ]
        )
        installed_inferred = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "installed" and prereq.get("source") == "INFERRED"
            ]
        )
        failed_prereq_names = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "failed"
            ]
        )
        skipped_prereq_names = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "skipped"
            ]
        )
        # Compute counts from normalized_prereqs (single source of truth)
        actual_installed = [p for p in normalized_prereqs if p.get("status") == "installed"]
        actual_failed = [p for p in normalized_prereqs if p.get("status") == "failed"]
        actual_skipped = [p for p in normalized_prereqs if p.get("status") == "skipped"]

        # Enrich failure lists with {id, name} pairs instead of opaque IDs
        prereq_name_map = {p.get("id", ""): p.get("name", "") for p in normalized_prereqs}
        enriched_blocking = [
            {"id": fid, "name": prereq_name_map.get(fid, fid)}
            for fid in blocking_failures
        ]
        enriched_non_blocking = [
            {"id": fid, "name": prereq_name_map.get(fid, fid)}
            for fid in non_blocking_failures
        ]

        self._obs.log_session_event(
            "story0_snapshot",
            status=result.status,
            prerequisites=normalized_prereqs,
            prerequisites_total=len(normalized_prereqs),
            installed_count=len(actual_installed),
            failed_count=len(actual_failed),
            skipped_count=len(actual_skipped),
            installed_manifest=installed_manifest,
            installed_inferred=installed_inferred,
            failed_prereqs=failed_prereq_names,
            skipped_prereqs=skipped_prereq_names,
            blocking_failures=enriched_blocking,
            non_blocking_failures=enriched_non_blocking,
            mocked_credentials=mocked_credentials,
            verification_tools=verification_tools,
        )
        return {
            "status": result.status,
            "completed_prereqs": completed_prereqs,
            "failed_prereqs": failed_prereqs,
            "blocking_failures": blocking_failures,
            "non_blocking_failures": non_blocking_failures,
            "verification_tools": verification_tools,
            "mocked_credentials": mocked_credentials,
        }

    def _dispatch_story_preflight(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        preflight_req = StoryPreflightRequest.from_payload(payload)
        preflight = handler.handle(
            story_item=preflight_req.story_item,
            plan_items=preflight_req.plan_items,
            exploration_context=preflight_req.exploration_context,
        )
        if hasattr(preflight, "to_dict"):
            result_dict = cast(dict[str, Any], preflight.to_dict())
        elif isinstance(preflight, dict):
            result_dict = dict(preflight)
        else:
            raise OrchestratorError(
                "Story preflight handler returned invalid payload",
                session_id=self._obs.session_id or "",
            )
        result_dict["story_id"] = str(preflight_req.story_item.get("id", "")).strip()
        return result_dict

    def _dispatch_examine(
        self,
        handler: Any,
        payload: dict[str, Any],
        server_action: ServerAction | None,
    ) -> dict[str, Any]:
        # Track refinement cycles (examine action count, NOT logical iteration)
        self._state.set_refinement_cycle_count(
            self._state.get_refinement_cycle_count() + 1
        )
        if self._state.get_refinement_start_time() is None:
            self._state.set_refinement_start_time(time.time())
        # Inject refinement cycle info from server action envelope
        if server_action is not None:
            payload.setdefault("iteration", server_action.iteration)
            payload.setdefault(
                "max_iterations",
                server_action.metadata.get("max_refinement_iterations"),
            )

        guard_result = self._refinement_guard.check_iteration_limit(
            action="examine",
            iteration=cast(int | None, payload.get("iteration")),
            effective_max=(
                server_action.metadata.get("effective_max_refinement_iterations")
                if server_action is not None
                else None
            ),
            fallback_max=cast(int | None, payload.get("max_iterations")),
        )
        if guard_result is not None:
            return guard_result

        # FEAT-REFINEMENT-PARALLEL-001: All EXAMINE actions route through
        # parallel batch fan-out.
        subphase_start = self._phase.start_subphase("examine")
        batch_count = len(payload.get("batches", []))
        # ISSUE-HYBRID-034: Structured telemetry for examine start
        if self._obs.production_logger:
            self._obs.production_logger.log_event(
                "examine_start",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                plan_items=sum(
                    len(b.get("plan_items", []))
                    for b in payload.get("batches", [])
                ),
                iteration=payload.get("iteration"),
                max_iterations=payload.get("max_iterations"),
                batch_count=batch_count,
            )
        try:
            result = self._factory.handle_parallel_examine_batches(payload)
        except Exception as e:
            self._phase.complete_subphase(
                "examine", subphase_start, status="error", error_message=str(e)
            )
            if self._obs.progress_emitter:
                self._obs.progress_emitter.parallel_batch_fallback(
                    "examine", error=str(e),
                )
            if self._obs.production_logger:
                self._obs.production_logger.log_event(
                    "examine_failed",
                    session_id=self._obs.session_id,
                    examine_action_count=self._state.get_refinement_cycle_count(),
                    batch_count=batch_count,
                    error_class=type(e).__name__,
                    error_message=str(e),
                )
            self._log_phase_failed(
                failure_stage="examine",
                error_code="HANDLER_ERROR",
                error=e,
            )
            raise
        self._phase.complete_subphase("examine", subphase_start)
        # ISSUE-HYBRID-034: Structured telemetry for examine complete
        issues = result.get("issues", []) if isinstance(result, dict) else []
        blocking_count = PlanMerger.count_effective_blocking_issues(
            issues,
            server_action.bypass_modes_active if server_action is not None else None,
        )
        if self._obs.production_logger:
            self._obs.production_logger.log_event(
                "examine_complete",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                issue_count=len(issues),
                blocking_count=blocking_count,
                batch_count=batch_count,
            )
        # Refinement scope summary for CLI visibility
        scope_items = sum(
            len(b.get("plan_items", []))
            for b in payload.get("batches", [])
        )
        total_items = len(payload.get("full_plan_items", payload.get("plan_items", [])))
        if self._obs.progress_emitter:
            self._obs.progress_emitter.refinement_scope_summary(
                cycle=self._state.get_refinement_cycle_count(),
                scope_items=scope_items or total_items,
                total_items=total_items or scope_items,
                scope_mode=payload.get("scope_mode", "full"),
                blocking_count=blocking_count,
                prev_blocking_count=(
                    self._state.get_refinement_last_blocking_count()
                    if self._state.get_refinement_cycle_count() > 1
                    else None
                ),
            )
        self._state.set_refinement_last_blocking_count(blocking_count)
        return result

    def _dispatch_revise(
        self,
        handler: Any,
        payload: dict[str, Any],
        server_action: ServerAction | None,
    ) -> dict[str, Any]:
        guard_result = self._refinement_guard.check_iteration_limit(
            action="revise",
            iteration=server_action.iteration if server_action is not None else None,
            effective_max=(
                server_action.metadata.get("effective_max_refinement_iterations")
                if server_action is not None
                else None
            ),
            fallback_max=(
                server_action.metadata.get("max_refinement_iterations")
                if server_action is not None
                else None
            ),
            unchanged_plan_items=cast(
                list[dict[str, Any]],
                payload.get("full_plan_items", []),
            ),
        )
        if guard_result is not None:
            return guard_result

        # FEAT-REFINEMENT-PARALLEL-001: All REVISE actions route through
        # parallel batch fan-out.
        subphase_start = self._phase.start_subphase("revise")
        batch_count = len(payload.get("batches", []))
        # ISSUE-HYBRID-034: Structured telemetry for revise start
        if self._obs.production_logger:
            self._obs.production_logger.log_event(
                "revise_start",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                batch_count=batch_count,
                issue_count=sum(
                    len(b.get("issues", []))
                    for b in payload.get("batches", [])
                ),
            )

        # Process proposed defaults once and inject into each batch's
        # base_prompt before parallel fan-out.
        proposed_defaults = payload.get("proposed_defaults") or []
        try:
            if proposed_defaults:
                confirmed_defaults = self._process_proposed_defaults(proposed_defaults)
                for batch_dict in payload.get("batches", []):
                    batch_dict["base_prompt"] = inject_defaults_into_prompt(
                        batch_dict.get("base_prompt", ""),
                        confirmed_defaults,
                    )
                    batch_dict["proposed_defaults"] = confirmed_defaults
        except OrchestratorError:
            self._phase.complete_subphase(
                "revise",
                subphase_start,
                status="error",
                error_message="defaults confirmation aborted",
            )
            raise

        try:
            result = self._factory.handle_parallel_revise_batches(payload)
        except Exception as e:
            self._phase.complete_subphase(
                "revise", subphase_start, status="error", error_message=str(e)
            )
            if self._obs.progress_emitter:
                self._obs.progress_emitter.parallel_batch_fallback(
                    "revise", error=str(e),
                )
            if self._obs.production_logger:
                self._obs.production_logger.log_event(
                    "revise_failed",
                    session_id=self._obs.session_id,
                    examine_action_count=self._state.get_refinement_cycle_count(),
                    batch_count=batch_count,
                    error_class=type(e).__name__,
                    error_message=str(e),
                )
            self._log_phase_failed(
                failure_stage="revise",
                error_code="HANDLER_ERROR",
                error=e,
            )
            raise

        if (
            self._obs.progress_emitter
            and self._obs.progress_emitter.config.verbosity >= VerbosityLevel.DETAIL
        ):
            if batch_count > 1:
                self._obs.progress_emitter._print(
                    f"  Parallel REVISE: {batch_count} batches", style="cyan"
                )
            else:
                self._obs.progress_emitter._print(
                    "  REVISE: sequential (single batch)", style="dim"
                )

        # Skip tracking on consolidated result.
        if self._state.is_skip_tracking_enabled("revision"):
            deferred = result.get("deferred_issues")
            created = 0
            # Build issue map from all batches for lookup.
            all_issues: dict[str, dict[str, Any]] = {}
            for batch_dict in payload.get("batches", []):
                for issue in batch_dict.get("issues", []):
                    issue_id = str(issue.get("id", "")).strip()
                    if issue_id:
                        all_issues[issue_id] = issue

            if isinstance(deferred, list):
                for item in deferred:
                    if not isinstance(item, dict):
                        continue
                    issue_id = str(item.get("id", "")).strip()
                    if not issue_id:
                        continue
                    reason_text = (
                        str(item.get("reason", "")).strip() or "Deferred by revision"
                    )
                    source_issue = all_issues.get(issue_id, {})
                    priority = str(source_issue.get("priority", "")).upper()
                    create_skip_record(
                        session_id=self._obs.session_id or "",
                        task_id=issue_id,
                        source=SkipSource.REVISION,
                        reason=SkipReason.DEFERRED_CONCERN,
                        description=f"Deferred concern: {reason_text}",
                        source_context={
                            "priority": priority,
                            "issue": source_issue,
                            "deferred_reason": reason_text,
                        },
                    )
                    created += 1
            if created > 0:
                logger.info("Run 'obra skips list' to review skipped items")

        self._phase.complete_subphase("revise", subphase_start)
        # ISSUE-HYBRID-034: Structured telemetry for revise complete
        if self._obs.production_logger:
            revised_plan_items = (
                result.get("plan_items", []) if isinstance(result, dict) else []
            )
            revised_plan_item_count = len(revised_plan_items)
            changed_item_count = PlanMerger.count_plan_item_changes(
                payload.get("full_plan_items", []),
                revised_plan_items,
            )
            self._obs.production_logger.log_event(
                "revise_complete",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                batch_count=batch_count,
                items_updated=revised_plan_item_count,
                revised_plan_item_count=revised_plan_item_count,
                changed_item_count=changed_item_count,
            )
        return result

    def _dispatch_execute(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        execute_req = ExecutionRequest.from_payload(payload)
        subphase_start = self._phase.start_subphase("execute")
        if hasattr(handler, "_parent_span_id"):
            handler._parent_span_id = self._phase.subphase_span_id_getter()
        if execute_req.current_item and execute_req.current_item.get("id"):
            self._state.set_last_item_id(execute_req.current_item.get("id"))

        skip_result: dict[str, Any] | None = None
        if execute_req.current_item:
            skip_result = self._skip_manager.check_completed_item_skip(
                execute_req.current_item
            )
            if skip_result is None:
                skip_result = self._skip_manager.check_resume_duplicate_skip(
                    execute_req.current_item
                )
            if skip_result is None and execute_req.plan_items:
                skip_result = self._skip_manager.check_container_skip(
                    execute_req.current_item,
                    cast(list[dict[str, Any]], execute_req.plan_items),
                )
        if skip_result is not None:
            self._phase.complete_subphase("execute", subphase_start, status="skipped")
            return skip_result

        # Compatibility: some server versions return ActionType.EXECUTE with fix payload
        # (item_id + issues_to_fix) instead of ActionType.FIX.
        if execute_req.current_item is None and payload.get("issues_to_fix"):
            return self._handle_execute_fix_compat(
                payload,
                subphase_start=subphase_start,
            )

        # S3.T5: Emit item_started event
        if execute_req.current_item:
            exec_ctx = execute_req.execution_context
            should_emit = True
            current_item_id = execute_req.current_item.get("id")

            # Dedupe using execution_context if available
            if exec_ctx:
                ctx_key = (
                    f"{exec_ctx.get('item_id')}:"
                    f"{exec_ctx.get('iteration')}:"
                    f"{exec_ctx.get('attempt')}"
                )
                if ctx_key in self._state.locally_started_items:
                    should_emit = False
                    # SESSION-92257c4c: Emit item_restarted instead of
                    # silently dropping the duplicate item_started.
                    logger.debug(
                        "Duplicate item_started detected — emitting item_restarted: %s",
                        ctx_key,
                    )
                    self._obs.log_session_event(
                        "item_restarted",
                        item=execute_req.current_item,
                        item_id=current_item_id,
                        reason="post_review_fix",
                        execution_context=exec_ctx,
                        span_id=self._phase.subphase_span_id_getter(),
                        parent_span_id=self._obs.phase_span_id,
                    )
                else:
                    self._state.locally_started_items.add(ctx_key)

            if should_emit:
                self._state.emit_progress(
                    "item_started",
                    {
                        "item": execute_req.current_item,
                        "item_id": current_item_id,
                        "execution_context": exec_ctx,
                    },
                )
                # ISSUE-OBS-002: Log item_started to production logger
                self._obs.log_session_event(
                    "item_started",
                    item=execute_req.current_item,
                    item_id=current_item_id,
                    span_id=self._phase.subphase_span_id_getter(),
                    parent_span_id=self._obs.phase_span_id,
                )

        # P1-1: Wrap execute in try/finally to guarantee item_completed pairs
        result: dict[str, Any] = {}
        item_error: Exception | None = None
        subphase_status = "success"
        subphase_error_message: str | None = None
        try:
            result = cast(dict[str, Any], handler.handle(execute_req))
        except Exception as e:
            item_error = e
            self._phase.complete_subphase(
                "execute", subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage="execute",
                error_code="HANDLER_ERROR",
                error=e,
            )
        finally:
            # P1-1: Always emit item_completed when item_started was emitted
            if execute_req.current_item:
                item_id = execute_req.current_item.get("id")
                if item_id:
                    self._state.locally_completed_items.add(str(item_id))
                resolved_outcome = self._resolve_item_terminal_outcome(
                    execute_req.current_item,
                    result,
                    item_error,
                )
                item_status = resolved_outcome.status
                item_result = resolved_outcome.result_payload
                files_changed = resolved_outcome.files_changed
                no_op = resolved_outcome.no_op
                empty_response = resolved_outcome.empty_response
                is_interrupted = resolved_outcome.interrupted
                if item_status == ExecutionStatus.SUCCESS.value:
                    subphase_status = "success"
                    subphase_error_message = None
                elif item_status == ExecutionStatus.PARTIAL.value:
                    subphase_status = "partial"
                    subphase_error_message = None
                elif is_interrupted:
                    subphase_status = "interrupted"
                    subphase_error_message = (
                        str(
                            item_result.get("summary")
                            or item_result.get("error")
                            or ""
                        ).strip()
                        or "Execution interrupted"
                    )
                else:
                    subphase_status = "error"
                    subphase_error_message = (
                        str(
                            item_result.get("summary")
                            or item_result.get("error")
                            or ""
                        ).strip()
                        or "Execution failed"
                    )

                # Ensure report_execution receives the normalized terminal result.
                result = dict(item_result)
                if resolved_outcome.counts_as_completed:
                    # FEAT-SESSION-CLOSEOUT-001: Increment only on true success.
                    self._state.increment_items_completed()

                self._state.emit_progress(
                    "item_completed",
                    {
                        "item": execute_req.current_item,
                        "item_id": item_id,
                        "status": item_status,
                        "terminal_reason": resolved_outcome.terminal_reason,
                        "result": item_result,
                    },
                )

                # ISSUE-OBS-002: Log item_completed to production logger
                self._obs.log_session_event(
                    "item_completed",
                    item=execute_req.current_item,
                    item_id=item_id,
                    status=item_status,
                    terminal_reason=resolved_outcome.terminal_reason,
                    files_changed=files_changed,
                    no_op=no_op,
                    empty_response=empty_response,
                    interrupted=is_interrupted,
                    span_id=self._phase.subphase_span_id_getter(),
                    parent_span_id=self._obs.phase_span_id,
                )

        if item_error is not None:
            if isinstance(item_error, GracefulInterrupt):
                self._state.set_was_interrupted(True)
            raise item_error

        self._phase.complete_subphase(
            "execute",
            subphase_start,
            status=subphase_status,
            error_message=subphase_error_message,
        )
        return result

    def _dispatch_review(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        review_payload = dict(payload)
        if not review_payload.get("item_id") and self._state.get_last_item_id():
            review_payload["item_id"] = self._state.get_last_item_id()

        candidate_agents = review_payload.get("agents_to_run")
        if not candidate_agents:
            legacy_agents = review_payload.get("review_agents")
            if isinstance(legacy_agents, list):
                candidate_agents = legacy_agents
        if isinstance(candidate_agents, list):
            sanitized_agents, dropped_agents = self._sanitize_review_agents_for_server(
                candidate_agents
            )
        else:
            sanitized_agents, dropped_agents = self._sanitize_review_agents_for_server(None)

        if dropped_agents:
            logger.warning(
                "Dropped unsupported review agents for current server contract: %s",
                sorted(set(dropped_agents)),
            )
        review_payload["agents_to_run"] = sanitized_agents

        review_req = ReviewRequest.from_payload(review_payload)
        if review_req.item_id:
            self._state.set_last_item_id(review_req.item_id)

        # Synthesize review_cycle_id when the server omits it.
        if not review_req.review_cycle_id and review_req.item_id:
            iteration = getattr(handler, "_iteration_counter", {}).get(
                review_req.item_id, 0
            )
            review_req.review_cycle_id = f"{review_req.item_id}:{iteration}"

        # Skip review for items that were skipped (containers or previously completed)
        if review_req.item_id and review_req.item_id in self._state.skipped_item_ids:
            logger.info("Skipping review for skipped item: %s", review_req.item_id)
            subphase_start = self._phase.start_subphase("review")
            self._phase.complete_subphase("review", subphase_start, status="skipped")
            return {
                "item_id": review_req.item_id,
                "agent_reports": [
                    {
                        "agent_type": "code_quality",
                        "status": "pass",
                        "scores": {"code_quality": 1.0},
                        "issues": [],
                    }
                ],
                "iteration": 0,
            }

        return cast(
            dict[str, Any],
            self._invoke_with_subphase(
                "review", handler, lambda: handler.handle(review_req)
            ),
        )

    def _dispatch_pipeline_stage(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        # Parse pipeline stage request from payload
        stage_req = PipelineStageRequest.from_payload(payload)
        loop_state = (
            stage_req.context.loop_state
            if isinstance(stage_req.context.loop_state, dict)
            else {}
        )
        current_iteration = loop_state.get("current_iteration", stage_req.iteration)
        max_iterations = loop_state.get("max_iterations", stage_req.max_iterations)

        logger.info(
            "Executing pipeline stage '%s' runner='%s' execution_id='%s' "
            "at trigger '%s' (iteration %s/%s)",
            stage_req.stage_name,
            stage_req.runner_id,
            stage_req.stage_execution_id,
            stage_req.trigger,
            current_iteration,
            max_iterations,
        )

        subphase_name = f"stage_{stage_req.stage_name}"
        subphase_start = self._phase.start_subphase(subphase_name)
        if hasattr(handler, "_parent_span_id"):
            handler._parent_span_id = self._phase.subphase_span_id_getter()

        try:
            result = handler.handle(stage_req)
            result_dict = result.to_dict()
            self._phase.complete_subphase(subphase_name, subphase_start)
            return result_dict
        except Exception as e:
            self._phase.complete_subphase(
                subphase_name, subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage=subphase_name,
                error_code="STAGE_ERROR",
                error=e,
            )
            raise

    def _dispatch_fix(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        fix_payload = payload
        if not payload.get("item_id") and self._state.get_last_item_id():
            fix_payload = dict(payload)
            fix_payload["item_id"] = self._state.get_last_item_id()
        fix_req = FixRequest.from_payload(fix_payload)
        if fix_req.item_id:
            self._state.set_last_item_id(fix_req.item_id)

        # S0.T7: Check verification tools before FIX
        available_tools = (self._state.get_verification_tools() or {}).get("available", [])
        missing_tools = (self._state.get_verification_tools() or {}).get("missing", [])
        if not available_tools and not self._state.get_verification_preflight_attempted():
            logger.info(
                "Verification tools missing before FIX - injecting Story 0 preflight"
            )
            self._state.emit_progress(
                "verification_preflight_triggered",
                {
                    "message": (
                        "Verification tools missing. "
                        "Running Story 0 preflight to install required tooling."
                    ),
                    "missing_tools": missing_tools,
                },
            )
            # R5-FIX: Save/restore phase around Story0 injection
            saved_phase = self._phase.get_current_phase()
            saved_phase_start = self._phase.get_phase_start_time()

            # Run Story 0 with verification_tools_missing reason
            story0_handler = self._factory.get_handler(ActionType.STORY0)
            story0_result = self.dispatch(
                story0_handler,
                ActionType.STORY0,
                {
                    "story0_prerequisites": [],
                    "objective": self._state.objective or "",
                    "story0_resume_reason": "verification_tools_missing",
                    "missing_tools": missing_tools,
                },
            )

            # Restore phase so the FIX handler continues in REVIEW context.
            self._phase.set_current_phase(saved_phase)
            self._phase.set_phase_start_time(saved_phase_start)
            # Update verification tools from Story 0 result
            if story0_result and story0_result.get("verification_tools"):
                self._state.set_verification_tools(story0_result["verification_tools"])
                available_tools = self._state.get_verification_tools().get("available", [])
                # Report to server so session.verification_tools is updated
                try:
                    self._factory.request_with_observability(
                        "POST",
                        "report_story0",
                        json={
                            "session_id": self._obs.session_id,
                            "status": story0_result.get("status", "complete"),
                            "completed_prereqs": [],
                            "failed_prereqs": [],
                            "blocking_failures": [],
                            "non_blocking_failures": [],
                            "verification_tools": self._state.get_verification_tools(),
                            "mocked_credentials": [],
                        },
                    )
                    logger.info(
                        "Reported injected Story 0 verification_tools to server: %s",
                        self._state.get_verification_tools(),
                    )
                except Exception as e:
                    logger.warning("Failed to report Story 0 to server: %s", e)
            if not available_tools:
                logger.warning(
                    "Verification tools still missing after preflight - proceeding without"
                )
                self._state.emit_progress(
                    "verification_preflight_incomplete",
                    {
                        "message": (
                            "Verification tools still missing after preflight. "
                            "Proceeding with FIX but verification may be limited."
                        ),
                    },
                )

        subphase_start = self._phase.start_subphase("fix")
        if hasattr(handler, "_parent_span_id"):
            handler._parent_span_id = self._phase.subphase_span_id_getter()

        # Pass orchestrator's verification_tools to FixHandler
        self._configure_fix_handler_verification_tools(
            handler,
            source_label="from Story 0",
        )

        try:
            result = cast(dict[str, Any], handler.handle(fix_req))
        except Exception as e:
            self._phase.complete_subphase(
                "fix", subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage="fix",
                error_code="HANDLER_ERROR",
                error=e,
            )
            raise
        self._phase.complete_subphase("fix", subphase_start)
        return result

    def _dispatch_validator(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        # FEAT-SENSECHECK-PIPELINE-001: Handle validator requests from server
        from obra.api.protocol import ValidatorRequest

        validator_req = ValidatorRequest.from_payload(payload)
        subphase_name = f"validator_{validator_req.stage}"
        subphase_start = self._phase.start_subphase(subphase_name)
        if hasattr(handler, "_parent_span_id"):
            handler._parent_span_id = self._phase.subphase_span_id_getter()

        try:
            result = handler.handle(validator_req)
            result_dict = result.to_dict()
            self._phase.complete_subphase(subphase_name, subphase_start)
            return result_dict
        except Exception as e:
            self._phase.complete_subphase(
                subphase_name, subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage=subphase_name,
                error_code="VALIDATOR_ERROR",
                error=e,
            )
            raise

    # ------------------------------------------------------------------
    # Helper methods moved from orchestrator.py
    # ------------------------------------------------------------------

    def _sanitize_review_agents_for_server(
        self, candidate_agents: list[str] | None
    ) -> tuple[list[str], list[str]]:
        """Filter review agents to those accepted by the current server."""
        supported = set(self._factory.ordered_supported_review_agents())
        if not candidate_agents:
            return self._factory.ordered_supported_review_agents(), []

        sanitized: list[str] = []
        dropped: list[str] = []
        seen: set[str] = set()

        for agent in candidate_agents:
            normalized = str(agent).strip()
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            if normalized in supported:
                sanitized.append(normalized)
            else:
                dropped.append(normalized)

        if sanitized:
            return sanitized, dropped
        return self._factory.ordered_supported_review_agents(), dropped

    def _process_proposed_defaults(
        self,
        proposed_defaults: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Render and optionally collect confirmation for proposed defaults."""
        if not proposed_defaults:
            return []

        console.print()
        console.print("[bold]Proposed defaults detected[/bold]")

        if self._state.defaults_json:
            console.print(
                json.dumps({"proposed_defaults": proposed_defaults}, indent=2)
            )
            msg = "Defaults exported via --defaults-json; rerun interactively to confirm."
            raise OrchestratorError(
                msg,
                session_id=self._obs.session_id or "",
            )

        should_prompt = self._state.should_prompt_for_defaults()
        if not should_prompt:
            print_warning(
                "Non-interactive environment detected; auto-accepting proposed defaults."
            )

        confirmed: list[dict[str, Any]] = []
        for default in proposed_defaults:
            value = default.get("proposed_value", "")
            issue_id = default.get("issue_id", "unknown")
            description = default.get("description", "")
            confidence = default.get("confidence", 0.0)

            console.print()
            console.print(f"  [bold]Issue {issue_id}[/bold]: {description or value}")
            if description and value != description:
                console.print(f"  [cyan]Proposed[/cyan]: {value}")
            console.print(f"  [dim]Confidence: {confidence:.0%}[/dim]")

            if should_prompt:
                try:
                    from obra.display.prompting import prompt_input

                    user_input = prompt_input(
                        "[bold yellow]?[/bold yellow] Accept, override, or 'skip': ",
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    user_input = ""

                if user_input.lower() == "skip":
                    continue
                if user_input:
                    default = {
                        **default,
                        "proposed_value": user_input,
                        "rationale": (
                            f"User override: {default.get('rationale', 'custom default')}"
                        ),
                    }

            confirmed.append(default)

        return confirmed

    def _resolve_item_terminal_outcome(
        self,
        current_item: dict[str, Any],
        handler_result: dict[str, Any],
        item_error: Exception | None,
    ) -> ResolvedItemOutcome:
        """Resolve a single authoritative terminal outcome for execute item events."""
        if item_error is None:
            resolved_result: dict[str, Any] = dict(handler_result)
        else:
            resolved_result = {
                "status": ExecutionStatus.FAILURE.value,
                "error": str(item_error),
            }

        status_raw = str(resolved_result.get("status", "")).strip().lower()
        status = status_raw or ExecutionStatus.FAILURE.value
        if status in {"failed", "error"}:
            status = ExecutionStatus.FAILURE.value
        if status not in {
            ExecutionStatus.SUCCESS.value,
            ExecutionStatus.FAILURE.value,
            ExecutionStatus.PARTIAL.value,
        }:
            status = ExecutionStatus.FAILURE.value

        interrupted = (
            isinstance(item_error, GracefulInterrupt)
            or bool(resolved_result.get("interrupted", False))
            or interrupt_requested()
        )
        if interrupted:
            status = ExecutionStatus.FAILURE.value
            resolved_result["interrupted"] = True
            resolved_result.setdefault("failure_class", "interrupted")
            terminal_reason = "interrupted"
        elif item_error is not None:
            status = ExecutionStatus.FAILURE.value
            resolved_result.setdefault("failure_class", "handler_exception")
            terminal_reason = "handler_exception"
        elif status == ExecutionStatus.SUCCESS.value:
            terminal_reason = "success"
        elif status == ExecutionStatus.PARTIAL.value:
            terminal_reason = "partial"
        else:
            terminal_reason = "failure"

        try:
            files_changed = int(resolved_result.get("files_changed", 0))
        except (TypeError, ValueError):
            files_changed = 0
        resolved_result["files_changed"] = files_changed

        explicit_empty_response = (
            str(resolved_result.get("failure_class", "")).strip().lower()
            == "empty_response"
        )

        item_item_type = (
            current_item.get("item_type", "") or current_item.get("type", "")
        ).lower()
        is_code_task = item_item_type not in (
            "verification",
            "validation",
            "lint",
            "check",
        )
        no_op = (
            item_error is None
            and status == ExecutionStatus.SUCCESS.value
            and files_changed == 0
            and is_code_task
        )

        if explicit_empty_response and not interrupted:
            status = ExecutionStatus.FAILURE.value
            terminal_reason = "empty_response"
            resolved_result["status"] = status
            resolved_result.setdefault(
                "summary",
                (
                    "Execution returned no actionable output. "
                    "Marked as retriable failure for re-queue."
                ),
            )
            resolved_result.setdefault("failure_class", "empty_response")
            resolved_result.setdefault("retryable", True)
            empty_response = True
            no_op = False
        else:
            empty_response = no_op and not str(
                resolved_result.get("summary", "")
            ).strip()
        if empty_response and not explicit_empty_response and not interrupted:
            logger.warning(
                "Execution completed with empty response for item %s; converting to failure",
                current_item.get("id", "unknown"),
            )
            status = ExecutionStatus.FAILURE.value
            terminal_reason = "empty_response"
            resolved_result["status"] = status
            resolved_result["summary"] = (
                "Execution returned no actionable output. "
                "Marked as retriable failure for re-queue."
            )
            resolved_result["failure_class"] = "empty_response"
            resolved_result["retryable"] = True
            no_op = False

        resolved_result["status"] = status
        return ResolvedItemOutcome(
            status=status,
            result_payload=resolved_result,
            files_changed=files_changed,
            no_op=no_op,
            empty_response=empty_response,
            interrupted=interrupted,
            terminal_reason=terminal_reason,
            counts_as_completed=(status == ExecutionStatus.SUCCESS.value),
        )
