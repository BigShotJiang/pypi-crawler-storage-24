"""Context protocol dataclasses for ActionDispatcher.

These dataclasses replace the 29-attribute direct coupling between
the dispatcher and the orchestrator, enabling clean extraction.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


@dataclass
class ObservabilityContext:
    """Observability handles: logging, spans, progress emission."""

    session_id: str | None
    phase_span_id: str | None
    pipeline_span_id: str | None
    production_logger: Any | None  # ProductionLogger | None
    progress_emitter: Any | None  # ProgressEmitter | None
    log_session_event: Callable[..., None]
    get_log_viewer_int: Callable[[str, int], int]
    """Wraps orchestrator._get_log_viewer_int; used by _summarize_userplan_steps."""


@dataclass
class PhaseControl:
    """Phase and subphase lifecycle management."""

    get_current_phase: Callable[[], Any | None]
    set_current_phase: Callable[[Any | None], None]
    start_subphase: Callable[[str], float]
    complete_subphase: Callable[..., None]
    subphase_span_id_getter: Callable[[], str | None]
    get_phase_start_time: Callable[[], float | None]
    set_phase_start_time: Callable[[float | None], None]


@dataclass
class ExecutionState:
    """Mutable execution state shared between orchestrator and dispatcher.

    Mutable references (sets, lists) are passed directly so mutations
    are visible bidirectionally.
    """

    session_guard: Any | None
    objective: str | None
    working_dir: Path

    # Item completion counters
    get_items_completed: Callable[[], int]
    increment_items_completed: Callable[[], None]

    # Item tracking collections — mutable references shared with orchestrator
    skip_completed_items: list[str]  # list[str] per orchestrator.__init__
    resume_completed_item_ids: set[str] | None
    skipped_item_ids: set[str]
    locally_started_items: set[str]  # actual set from server_protocol._locally_started_items
    locally_completed_items: set[str]  # actual set from server_protocol._locally_completed_items

    # Verification tools — use getter/setter callables so dispatcher updates
    # propagate back to the orchestrator's _verification_tools attribute.
    get_verification_tools: Callable[[], "dict[str, Any] | None"]
    set_verification_tools: Callable[["dict[str, Any] | None"], None]
    get_verification_preflight_attempted: Callable[[], bool]
    set_verification_preflight_attempted: Callable[[bool], None]

    # Interrupt / state flags
    get_was_interrupted: Callable[[], bool]
    set_was_interrupted: Callable[[bool], None]

    # Last item tracking
    get_last_item_id: Callable[[], str | None]
    set_last_item_id: Callable[[str | None], None]
    get_last_userplan_id: Callable[[], str | None]
    set_last_userplan_id: Callable[[str | None], None]
    get_last_userplan_version: Callable[[], int | None]
    set_last_userplan_version: Callable[[int | None], None]

    # Derivation state
    get_derive_from_step: Callable[[], str | None]
    set_derive_from_step: Callable[[str | None], None]
    get_preserved_plan_items: Callable[[], list | None]
    set_preserved_plan_items: Callable[[list | None], None]
    get_last_derivation_plan_items: Callable[[], list | None]
    set_last_derivation_plan_items: Callable[[list | None], None]

    # Task totals
    get_tasks_total: Callable[[], int | None]
    set_tasks_total: Callable[[int | None], None]

    # Refinement cycle state
    get_refinement_cycle_count: Callable[[], int]
    set_refinement_cycle_count: Callable[[int], None]
    get_refinement_start_time: Callable[[], float | None]
    set_refinement_start_time: Callable[[float | None], None]
    get_refinement_last_blocking_count: Callable[[], int | None]
    set_refinement_last_blocking_count: Callable[[int | None], None]

    # Skip tracking
    is_skip_tracking_enabled: Callable[[str], bool]

    # Progress emission
    emit_progress: Callable[..., None]

    # Defaults prompt state
    defaults_json: bool  # used by _process_proposed_defaults
    should_prompt_for_defaults: Callable[[], bool]
    """Wraps orchestrator._should_prompt_for_defaults; used by _process_proposed_defaults."""


@dataclass
class HandlerFactoryProtocol:
    """Protocol for handler creation and request execution."""

    get_handler: Callable[..., Any]
    request_with_observability: Callable[..., Any]
    handle_parallel_examine_batches: Callable[..., dict]
    handle_parallel_revise_batches: Callable[..., dict]
    ordered_supported_review_agents: Callable[[], list[str]]
    """Wraps orchestrator._ordered_supported_review_agents; used by _sanitize_review_agents_for_server."""
    write_plan_snapshot: Callable[..., "str | None"]
    """Wraps orchestrator._write_plan_snapshot; used by _dispatch_derive."""
