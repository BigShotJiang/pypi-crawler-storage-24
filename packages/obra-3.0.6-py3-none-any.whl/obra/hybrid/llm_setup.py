"""LLM configuration for HybridOrchestrator.

Extracted from obra/hybrid/orchestrator.py as part of REFACTOR-ORCH-EXTRACT-001.
Handles LLM provider configuration, preflight checks, review capabilities, and
effective LLM map construction.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.api.protocol import (
    DEFAULT_REPORT_REVIEW_AGENT_TYPES,
    DEFAULT_REVIEW_AGENTS,
    ActionType,
    AgentType,
)
from obra.config.llm import resolve_action_llm_config, resolve_role_llm_config
from obra.display import console
from obra.exceptions import OrchestratorError
from obra.hybrid.runtime_bootstrap import SessionDisplayContext
from obra.model_registry import resolve_quality_tier

logger = logging.getLogger(__name__)

PreflightResults = dict[str, dict[str, str | None]]

# ADR-069: Action-to-role mapping for role-based LLM configuration
# This maps each ActionType to a handler role name used for LLM config resolution.
# Planning actions (derive, examine, revise) use "orchestrator" profile by default.
# Execution actions (execute, fix) use "implementation" profile by default.
# See: docs/decisions/ADR-069-role-based-llm-configuration.md
ACTION_TO_ROLE: dict[ActionType, str] = {
    ActionType.DERIVE: "derive",
    ActionType.INTENT: "derive",
    ActionType.STORY0: "derive",
    ActionType.STORY_PREFLIGHT: "validator",
    ActionType.EXAMINE: "examine",
    ActionType.REVISE: "revise",
    ActionType.EXECUTE: "execute",
    ActionType.FIX: "fix",
    ActionType.REVIEW: "review",
    ActionType.VALIDATOR: "validator",
}


class LLMConfigurator:
    """LLM configuration extracted from HybridOrchestrator.

    Handles server review capability refresh, quality policy resolution,
    effective LLM map construction, provider preflight checks, and
    role-based LLM config resolution.
    Receives shared state via constructor injection.
    """

    def __init__(
        self,
        llm_config_getter: Callable[[], dict[str, Any] | None],
        server_review_agent_types: set[str],
        working_dir: Path,
        build_error_context: Callable[..., Any],
        session_display_getter: Callable[[], SessionDisplayContext],
    ) -> None:
        self._llm_config_getter = llm_config_getter
        self._server_review_agent_types = server_review_agent_types
        self._working_dir = working_dir
        self._build_error_context = build_error_context
        self._session_display_getter = session_display_getter

    @property
    def _llm_config(self) -> dict[str, Any] | None:
        return self._llm_config_getter()

    def _refresh_server_review_capabilities(self, version_info: Any) -> None:
        """Refresh server-supported review agent types from version metadata."""
        fallback = set(DEFAULT_REPORT_REVIEW_AGENT_TYPES)
        if not isinstance(version_info, dict):
            self._server_review_agent_types = fallback
            return

        raw_agent_types: Any = None
        capabilities = version_info.get("capabilities", {})
        if isinstance(capabilities, dict):
            report_review = capabilities.get("report_review", {})
            if isinstance(report_review, dict):
                raw_agent_types = report_review.get("agent_types")

        if not isinstance(raw_agent_types, list):
            self._server_review_agent_types = fallback
            return

        valid_types = {agent.value for agent in AgentType if agent != AgentType.CODE_VERIFY}
        normalized = {
            str(agent).strip()
            for agent in raw_agent_types
            if isinstance(agent, str) and str(agent).strip() in valid_types
        }
        self._server_review_agent_types = normalized or fallback

    def _ordered_supported_review_agents(self) -> list[str]:
        """Return server-supported review agents in stable protocol order."""
        ordered = [
            agent
            for agent in DEFAULT_REVIEW_AGENTS
            if agent in self._server_review_agent_types
        ]
        if ordered:
            return ordered
        return list(DEFAULT_REPORT_REVIEW_AGENT_TYPES)

    def _resolve_quality_policy_mode(self) -> str | None:
        """Resolve quality policy mode from config for SessionStart payload.

        Returns None when mode is 'auto' (default) to keep payload minimal
        for backward compatibility with older servers.

        Returns:
            Policy mode string if not auto, None otherwise
        """
        from obra.config.loaders import get_quality_policy_mode

        mode = get_quality_policy_mode()
        return mode if mode != "auto" else None

    def _build_effective_llm_map(self) -> dict[str, dict[str, str]]:
        """Build the effective LLM map from tier-aware config resolution.

        For each pipeline stage, resolves provider/model/tier/reasoning_level
        using the handler-level model_tier config when available, falling back
        to role-based profile resolution (ADR-069). This must match the
        resolution path used by _get_role_llm_config() so preflight and
        runtime agree.

        Agent overrides are included only when they differ from their
        parent review stage.

        Returns:
            Dict keyed by stage/agent name with provider, model, tier, reasoning_level.
        """
        from obra.config.loaders import (
            get_derive_model_tier,
            get_examine_model_tier,
            get_fix_model_tier,
            get_review_model_tier,
            get_revise_model_tier,
        )

        _tier_getters: dict[str, Callable[[], str]] = {
            "derive": get_derive_model_tier,
            "examine": get_examine_model_tier,
            "revise": get_revise_model_tier,
            "review": get_review_model_tier,
            "fix": get_fix_model_tier,
        }

        effective_map: dict[str, dict[str, str]] = {}

        # Resolve per-stage config using tier-aware resolution
        stages = ["derive", "examine", "revise", "execute", "fix", "review"]
        for stage in stages:
            tier_getter = _tier_getters.get(stage)
            if tier_getter is not None:
                handler_tier = tier_getter()
                config = resolve_action_llm_config(stage, model_tier=handler_tier)
            else:
                config = resolve_role_llm_config(stage)
            provider = config.get("provider", "anthropic")
            model = config.get("model", "")
            tier = resolve_quality_tier(provider, model)
            thinking = config.get("reasoning_level", "medium")
            effective_map[stage] = {
                "provider": provider,
                "model": model,
                "tier": tier,
                "reasoning_level": thinking,
            }

        # Check agent overrides for review agents
        review_entry = effective_map.get("review", {})
        agent_names = ["sense_check", "code_quality", "test_execution"]
        for agent in agent_names:
            try:
                agent_config = resolve_action_llm_config(agent)
                agent_provider = agent_config.get("provider", "anthropic")
                agent_model = agent_config.get("model", "")
                # Only include if different from parent review stage
                if (
                    agent_provider != review_entry.get("provider")
                    or agent_model != review_entry.get("model")
                ):
                    agent_tier = resolve_quality_tier(agent_provider, agent_model)
                    agent_thinking = agent_config.get("reasoning_level", "medium")
                    effective_map[agent] = {
                        "provider": agent_provider,
                        "model": agent_model,
                        "tier": agent_tier,
                        "reasoning_level": agent_thinking,
                    }
            except Exception:
                # Agent config resolution failure is non-fatal
                logger.debug("Skipping agent override for %s", agent)

        return effective_map

    def _run_provider_preflight(
        self, effective_map: dict[str, dict[str, str]]
    ) -> dict[str, dict[str, str | None]]:
        """Run preflight checks for unique providers and provider+model pairs.

        Args:
            effective_map: The effective LLM map.

        Returns:
            Dict keyed by provider name with status and error info.

        Raises:
            OrchestratorError: If any provider fails preflight checks.
        """
        llm_config = self._llm_config
        auth_method = "oauth"
        run_model_probe = isinstance(llm_config, dict)
        if run_model_probe and isinstance(llm_config, dict):
            auth_method = str(llm_config.get("auth_method", "oauth"))
        results, failures = collect_provider_preflight_results(
            effective_map,
            working_dir=self._working_dir,
            auth_method=auth_method,
            run_model_probe=run_model_probe,
        )

        if failures:
            raise OrchestratorError(
                f"Provider preflight failed: {', '.join(failures)}",
                error_context=self._build_error_context(action="provider_preflight"),
            )

        return results

    def _emit_llm_pipeline_banner(
        self,
        effective_map: dict[str, dict[str, str]],
        server_validation: dict[str, dict[str, Any]],
    ) -> None:
        """Emit the full LLM Pipeline Models banner post-session.

        Called after server validation completes so all indicators have real data.
        Uses the typed session-display context for CLI preflight results and
        the server validation from the session start response.
        """
        import os

        from obra.config.loaders import get_quality_policy_mode
        from obra.display.session_banner import _format_llm_banner, _format_quality_policy_lines

        session_display = self._session_display_getter()
        preflight_results = session_display.preflight_results
        verbose = session_display.verbose

        console.print()
        console.print("LLM Pipeline Models")
        banner_lines = _format_llm_banner(
            effective_map, preflight_results, server_validation, verbose
        )
        for line in banner_lines:
            console.print(line)

        # Quality policy: show model tier and effective policy tier

        impl_tier = effective_map.get("execute", {}).get("tier", "medium")
        try:
            policy_mode = get_quality_policy_mode()
        except Exception:
            policy_mode = "auto"

        effective_tier = impl_tier if policy_mode == "auto" else policy_mode

        for line in _format_quality_policy_lines(impl_tier, policy_mode):
            console.print(f"[dim]{line}[/dim]")

        # Tier behavior note
        suppress_tier_info = os.environ.get(
            "OBRA_SUPPRESS_TIER_INFO", ""
        ).lower() in ("1", "true")
        if effective_tier == "fast" and not suppress_tier_info:
            console.print(
                "[dim]Note: Fast quality policy - relaxed quality gates "
                "(1 iteration, auto-permissive)[/dim]"
            )
            if verbose > 0:
                console.print(
                    "[dim]  Compared to medium tier: 3 iterations, P1 issues block[/dim]"
                )
                console.print(
                    "[dim]  Compared to high tier: 5 iterations, strict quality gates[/dim]"
                )

    def _get_role_llm_config(self, action: ActionType) -> dict[str, Any]:
        """Get LLM config for a handler action using tier-aware resolution.

        This method implements ADR-069 role-based LLM configuration, allowing
        different handlers to use different LLM settings based on configuration.

        Resolution order:
        1. handlers.<role>.model_tier config → resolve_action_llm_config (tier path)
        2. llm.roles.<role> → resolve_role_llm_config (profile path)
        3. Default mapping (derive->orchestrator, execute->implementation)
        4. Fallback to stored _llm_config (backward compatibility)

        Args:
            action: The ActionType for which to resolve config

        Returns:
            Resolved LLM config dict with provider, model, reasoning_level, etc.

        See:
            docs/decisions/ADR-069-role-based-llm-configuration.md
        """
        role = ACTION_TO_ROLE.get(action)
        if role is None:
            logger.warning(
                "No role mapping for action %s, using stored llm_config",
                action.value,
            )
            return self._llm_config or {}

        # Check for handler-level model_tier config (tier-aware resolution).
        # Stages with a handlers.<role>.model_tier config entry use tier-based
        # resolution; stages without (e.g. execute) use profile-based.
        from obra.config.loaders import (
            get_derive_model_tier,
            get_examine_model_tier,
            get_fix_model_tier,
            get_review_model_tier,
            get_revise_model_tier,
        )

        _tier_getters: dict[str, Callable[[], str]] = {
            "derive": get_derive_model_tier,
            "examine": get_examine_model_tier,
            "revise": get_revise_model_tier,
            "review": get_review_model_tier,
            "fix": get_fix_model_tier,
        }
        tier_getter = _tier_getters.get(role)
        if tier_getter is not None:
            tier = tier_getter()
            resolved = resolve_action_llm_config(role, model_tier=tier)
        else:
            # No tier config — fall back to role/profile resolution
            resolved = resolve_role_llm_config(role)

        # Merge with any session-level overrides from _llm_config
        # (e.g., CLI flags like --provider, --model)
        llm_config = self._llm_config
        if llm_config:
            # Git and codex configs are session-level, not role-level
            for key in ("git", "codex"):
                if key in llm_config and key not in resolved:
                    resolved[key] = llm_config[key]

        logger.debug(
            "Resolved LLM config for action %s (role=%s): provider=%s, model=%s",
            action.value,
            role,
            resolved.get("provider"),
            resolved.get("model"),
        )

        return resolved

    def _get_review_config(self) -> dict[str, Any] | None:
        """Get LLM config for review agents.

        Uses config-wired model_tier (handlers.review.model_tier, default: high)
        with implementation role tier resolution.

        Returns:
            LLM config dict if available, None otherwise.
        """
        from obra.config.loaders import get_review_model_tier

        tier = get_review_model_tier()
        tier_config = resolve_action_llm_config("review", model_tier=tier)

        # Merge with session-level overrides (git, codex)
        resolved = {
            "provider": tier_config.get("provider", "anthropic"),
            "model": tier_config.get("model"),
            "auth_method": tier_config.get("auth_method", "oauth"),
            "reasoning_level": tier_config.get("reasoning_level", "medium"),
        }
        llm_config = self._llm_config
        if llm_config:
            for key in ("git", "codex"):
                if key in llm_config and key not in resolved:
                    resolved[key] = llm_config[key]

        logger.debug(
            "Resolved review config: tier=%s, provider=%s, model=%s",
            tier,
            resolved.get("provider"),
            resolved.get("model"),
        )

        return resolved


def collect_provider_preflight_results(
    effective_map: dict[str, dict[str, str]],
    *,
    working_dir: Path,
    auth_method: str = "oauth",
    run_model_probe: bool = True,
) -> tuple[PreflightResults, list[str]]:
    """Collect provider/model preflight results without deciding failure policy."""
    from obra.config.providers import (
        validate_provider_model_ready,
        validate_provider_ready,
    )
    from obra.exceptions import ConfigurationError

    providers = {entry["provider"] for entry in effective_map.values()}
    provider_model_pairs = {
        (entry["provider"], entry.get("model", ""))
        for entry in effective_map.values()
    }
    results: PreflightResults = {}
    failures: list[str] = []

    for provider in sorted(providers):
        try:
            validate_provider_ready(provider)
            results[provider] = {"status": "ok", "error": None}
        except (ConfigurationError, Exception) as exc:
            results[provider] = {"status": "failed", "error": str(exc)}
            failures.append(f"{provider} ({exc})")

    if run_model_probe:
        for provider, model in sorted(provider_model_pairs):
            try:
                validate_provider_model_ready(
                    provider,
                    model,
                    auth_method=auth_method,
                    cwd=working_dir,
                )
            except (ConfigurationError, Exception) as exc:
                results[provider] = {"status": "failed", "error": str(exc)}
                failures.append(f"{provider}:{model} ({exc})")

    return results, failures
