"""Typed runtime-bootstrap ownership for HybridOrchestrator."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from obra.exceptions import ConfigurationError
from obra.hybrid.dispatch.context import (
    ExecutionState,
    HandlerFactoryProtocol,
    ObservabilityContext,
    PhaseControl,
)
from obra.hybrid.dispatch.dispatcher import ActionDispatcher
from obra.hybrid.dispatch.handler_factory import HandlerFactory
from obra.hybrid.runtime_state import DispatchRuntimeBindings, HybridRuntimeState


@dataclass(frozen=True)
class SessionDisplayContext:
    """Typed CLI-to-orchestrator display/bootstrap context."""

    preflight_results: dict[str, dict[str, str | None]] = field(default_factory=dict)
    verbose: int = 0

    @classmethod
    def from_legacy(
        cls,
        *,
        preflight_results: dict[str, Any] | None = None,
        verbose: int = 0,
    ) -> "SessionDisplayContext":
        """Build the typed context from legacy loose parameters."""
        return cls(
            preflight_results=preflight_results or {},
            verbose=verbose,
        )


@dataclass(frozen=True)
class FromConfigBootstrap:
    """Resolved runtime/bootstrap inputs for HybridOrchestrator.from_config()."""

    llm_config: dict[str, Any]
    config: dict[str, Any]
    domain: Any
    domain_resolution: dict[str, Any]
    bypass_modes: list[str]
    planning_mode: str | None
    session_display_context: SessionDisplayContext


def resolve_from_config_bootstrap(
    *,
    working_dir: Path | None,
    domain: str | None,
    domain_resolution: dict[str, Any] | None,
    impl_provider: str | None,
    impl_model: str | None,
    reasoning_level: str | None,
    bypass_modes: list[str] | None,
    skip_git_check: bool | None,
    auto_init_git: bool | None,
    planning_mode: str | None,
    config_override: dict[str, Any] | None,
    session_display: SessionDisplayContext | None,
    preflight_results: dict[str, Any] | None,
    verbose: int,
) -> FromConfigBootstrap:
    """Resolve the configuration/bootstrap state for ``from_config``."""
    from obra.config import resolve_llm_config
    from obra.config.llm import resolve_orchestration_domain
    from obra.config.loaders import load_layered_config
    from obra.domains.loader import (
        DomainNotFoundError,
        DomainValidationError,
        load_domain,
    )
    from obra.domains.resolution import DomainResolutionResult, require_resolved_domain

    llm_config = resolve_llm_config(
        role="implementation",
        override_provider=impl_provider,
        override_model=impl_model,
        override_reasoning_level=reasoning_level,
        override_skip_git_check=skip_git_check,
        override_auto_init_git=auto_init_git,
    )

    config, _, _ = load_layered_config(include_defaults=True)
    if config_override is not None:
        config = config_override

    resolved_domain = (
        DomainResolutionResult.from_dict(domain_resolution)
        if isinstance(domain_resolution, dict)
        else resolve_orchestration_domain(
            domain,
            project_path=working_dir,
            config=config,
        )
    )
    if isinstance(resolved_domain, str):
        resolved_domain = DomainResolutionResult(
            status="explicit",
            domain_id=resolved_domain,
            source="legacy_mock",
        )

    try:
        resolved_domain_name = require_resolved_domain(
            resolved_domain,
            context="Hybrid orchestrator startup",
        )
    except ValueError as exc:
        raise ConfigurationError(str(exc)) from exc

    try:
        resolved_domain_impl = load_domain(resolved_domain_name)
    except (DomainNotFoundError, DomainValidationError) as exc:
        msg = f"Invalid domain '{resolved_domain_name}': {exc}"
        raise ConfigurationError(msg) from exc

    return FromConfigBootstrap(
        llm_config=llm_config,
        config=config,
        domain=resolved_domain_impl,
        domain_resolution=resolved_domain.to_dict(),
        bypass_modes=list(bypass_modes or []),
        planning_mode=planning_mode,
        session_display_context=(
            session_display
            or SessionDisplayContext.from_legacy(
                preflight_results=preflight_results,
                verbose=verbose,
            )
        ),
    )


def build_handler_factory(
    *,
    working_dir: Path,
    llm_config: dict[str, Any] | None,
    domain: Any | None,
    config: dict[str, Any] | None,
    session_id: str | None,
    trace_id: str | None,
    phase_span_id: str | None,
    on_stream: Any,
    on_progress: Any,
    observability_config: Any,
    progress_emitter: Any,
    production_logger: Any,
    review_config: Any,
    client: Any,
    planning_mode: str | None,
    bypass_modes: list[str] | None,
    work_type_override: str | None,
    process_registry: Any,
    objective: str | None,
    log_session_event: Any,
    get_role_llm_config: Any,
    get_review_config: Any,
    create_monitoring_context: Any,
    handlers_cache: dict[Any, Any],
) -> HandlerFactory:
    """Construct a HandlerFactory from explicit runtime inputs."""
    return HandlerFactory(
        working_dir=working_dir,
        llm_config=llm_config,
        domain=domain,
        config=config,
        session_id=session_id,
        trace_id=trace_id,
        phase_span_id=phase_span_id,
        on_stream=on_stream,
        on_progress=on_progress,
        observability_config=observability_config,
        progress_emitter=progress_emitter,
        production_logger=production_logger,
        review_config=review_config,
        client=client,
        planning_mode=planning_mode,
        bypass_modes=bypass_modes,
        work_type_override=work_type_override,
        process_registry=process_registry,
        objective=objective,
        log_session_event=log_session_event,
        get_role_llm_config=get_role_llm_config,
        get_review_config=get_review_config,
        create_monitoring_context=create_monitoring_context,
        handlers_cache=handlers_cache,
    )


def build_dispatcher(
    *,
    observability: ObservabilityContext,
    phase_control: PhaseControl,
    execution_state: ExecutionState,
    handler_factory: HandlerFactoryProtocol,
) -> ActionDispatcher:
    """Construct an ActionDispatcher from explicit runtime inputs."""
    return ActionDispatcher(
        observability=observability,
        phase_control=phase_control,
        execution_state=execution_state,
        handler_factory=handler_factory,
    )


def build_observability_context(
    *,
    runtime_state: HybridRuntimeState,
    trace: Any,
    production_logger: Any,
    progress_emitter: Any,
    log_session_event: Any,
    get_log_viewer_int: Any,
) -> ObservabilityContext:
    """Construct dispatcher observability context from runtime owners."""
    return ObservabilityContext(
        session_id=runtime_state.session_id,
        phase_span_id=trace.phase_span_id,
        pipeline_span_id=trace.pipeline_span_id,
        production_logger=production_logger,
        progress_emitter=progress_emitter,
        log_session_event=log_session_event,
        get_log_viewer_int=get_log_viewer_int,
    )


def build_phase_control(
    *,
    current_phase_getter: Any,
    current_phase_setter: Any,
    event_logger: Any,
    phase_start_time_getter: Any,
    phase_start_time_setter: Any,
) -> PhaseControl:
    """Construct dispatcher phase-control context from runtime owners."""
    return PhaseControl(
        get_current_phase=current_phase_getter,
        set_current_phase=current_phase_setter,
        start_subphase=event_logger.start_subphase,
        complete_subphase=event_logger.complete_subphase,
        subphase_span_id_getter=lambda: event_logger.subphase_span_id,
        get_phase_start_time=phase_start_time_getter,
        set_phase_start_time=phase_start_time_setter,
    )


def build_execution_state(
    *,
    runtime_state: HybridRuntimeState,
    session_guard: Any,
    working_dir: Path,
    invocation: Any,
    refinement: Any,
    server_protocol: Any,
    emit_progress: Any,
    is_skip_tracking_enabled: Any,
    defaults_json: bool,
    should_prompt_for_defaults: Any,
) -> ExecutionState:
    """Construct dispatcher execution-state context from runtime owners."""
    bindings = DispatchRuntimeBindings(
        runtime_state=runtime_state,
        session_guard=session_guard,
        working_dir=working_dir,
        invocation=invocation,
        refinement=refinement,
        server_protocol=server_protocol,
        emit_progress=emit_progress,
        is_skip_tracking_enabled=is_skip_tracking_enabled,
        defaults_json=defaults_json,
        should_prompt_for_defaults=should_prompt_for_defaults,
    )
    return bindings.to_execution_state()


def build_dispatcher_handler_factory(
    *,
    get_handler: Any,
    request_with_observability: Any,
    handle_parallel_examine_batches: Any,
    handle_parallel_revise_batches: Any,
    ordered_supported_review_agents: Any,
    write_plan_snapshot: Any,
) -> HandlerFactoryProtocol:
    """Construct dispatcher handler-factory protocol from explicit callables."""
    return HandlerFactoryProtocol(
        get_handler=get_handler,
        request_with_observability=request_with_observability,
        handle_parallel_examine_batches=handle_parallel_examine_batches,
        handle_parallel_revise_batches=handle_parallel_revise_batches,
        ordered_supported_review_agents=ordered_supported_review_agents,
        write_plan_snapshot=write_plan_snapshot,
    )
