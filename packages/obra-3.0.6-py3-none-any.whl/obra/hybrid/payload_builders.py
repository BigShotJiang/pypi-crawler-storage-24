"""Payload builder helpers for ServerProtocol."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from obra.api.protocol import (
    DerivedPlan,
    ExaminationReport,
    ExecutionResult,
    ExecutionStatus,
    FixReport,
    PipelineStageResult,
    RevisedPlan,
    UserDecision,
    UserDecisionChoice,
)
from obra.exceptions import OrchestratorError
from obra.workflow.lifecycle import canonicalize_workflow_lifecycle_payload

if TYPE_CHECKING:
    from obra.hybrid.server_protocol import ReportContext, ServerProtocol

logger = logging.getLogger(__name__)


def build_intent_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    intent_payload: dict[str, Any] = {
        "session_id": context.session_id,
        "intent": result.get("intent", {}),
        "intent_enrichment": result.get("intent_enrichment"),
    }
    if context.derive_from_step is not None:
        intent_payload["from_step"] = context.derive_from_step
    return ("report_intent", intent_payload)


def build_story0_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    vtools = result.get("verification_tools")
    logger.info("Reporting Story 0 to server with verification_tools: %s", vtools)
    story0_payload: dict[str, Any] = {
        "session_id": context.session_id,
        "status": result.get("status", "complete"),
        "completed_prereqs": result.get("completed_prereqs", []),
        "failed_prereqs": result.get("failed_prereqs", []),
        "blocking_failures": result.get("blocking_failures", []),
        "non_blocking_failures": result.get("non_blocking_failures", []),
        "verification_tools": vtools,
        "mocked_credentials": result.get("mocked_credentials", []),
    }
    if protocol._progress_cursor:
        story0_payload["progress_cursor"] = protocol._progress_cursor
    return ("report_story0", story0_payload)


def build_story_preflight_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    return (
        "report_validator",
        {"session_id": context.session_id, "stage": "story_preflight", **result},
    )


def build_examine_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    return (
        "report_examination",
        ExaminationReport(
            session_id=context.session_id,
            iteration=result.get("iteration", 0),
            issues=result.get("issues", []),
            thinking_budget_used=result.get("thinking_budget_used", 0),
            thinking_fallback=result.get("thinking_fallback", False),
            raw_response=result.get("raw_response", ""),
        ).to_dict(),
    )


def build_execute_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    item_id = result.get("item_id") or context.last_item_id or ""
    if not item_id:
        logger.warning("Missing item_id for report_execution; using 'unknown' to satisfy schema.")
        item_id = "unknown"
    return (
        "report_execution",
        ExecutionResult(
            session_id=context.session_id,
            item_id=item_id,
            status=ExecutionStatus(result.get("status", "failure")),
            summary=result.get("summary", ""),
            files_changed=result.get("files_changed", 0),
            changed_file_paths=result.get("changed_file_paths", []),
            tests_passed=result.get("tests_passed", False),
            test_count=result.get("test_count", 0),
            coverage_delta=result.get("coverage_delta", 0.0),
            verification_tools=result.get("verification_tools"),
            decomposition_suggested=result.get("decomposition_suggested", False),
            decomposition_reason=result.get("decomposition_reason"),
            failure_reason_code=result.get("failure_reason_code") or result.get("failure_class"),
            partial_work_summary=result.get("partial_work_summary"),
            progress_cursor=protocol._progress_cursor,
        ).to_dict(),
    )


def build_escalate_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    return (
        "user_decision",
        UserDecision(
            session_id=context.session_id,
            escalation_id=result.get("escalation_id", ""),
            decision=UserDecisionChoice(result.get("decision", "force_complete")),
            reason=result.get("reason", ""),
        ).to_dict(),
    )


def build_validator_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    validator_payload: dict[str, Any] = {"session_id": context.session_id, **result}
    if protocol._progress_cursor:
        validator_payload["progress_cursor"] = protocol._progress_cursor
    return ("report_validator", validator_payload)


def build_pipeline_stage_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    stage_payload = PipelineStageResult.from_dict(result).to_dict()
    stage_payload["session_id"] = context.session_id
    if protocol._progress_cursor:
        stage_payload["progress_cursor"] = protocol._progress_cursor
    return ("report_pipeline_stage", stage_payload)


def extract_workflow_lifecycle_source(
    protocol: "ServerProtocol",
    result: dict[str, Any],
) -> dict[str, Any]:
    candidates = [
        ((result.get("result_bundle") or {}).get("workflow_lifecycle")),
        (((result.get("validation_report") or {}).get("details") or {}).get("lifecycle")),
        (
            (
                ((result.get("derived_workflow_artifact") or {}).get("metadata") or {}).get(
                    "workflow_definition"
                )
                or {}
            ).get("lifecycle")
        ),
        (((result.get("derived_workflow_artifact") or {}).get("workflow_definition") or {}).get("lifecycle")),
    ]
    for candidate in candidates:
        accepted = canonicalize_workflow_lifecycle_payload(candidate)
        if accepted:
            return accepted
    return {}


def build_workflow_lifecycle_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    accepted = extract_workflow_lifecycle_source(protocol, result)
    operator_review_points = result.get("operator_review_points") or []
    operator_review_required = bool(operator_review_points)
    capability_states = (
        accepted.get("capability_states")
        if isinstance(accepted.get("capability_states"), dict)
        else {}
    )
    story0_state = str(capability_states.get("story0") or "skipped")
    review_state = str(capability_states.get("review") or "skipped")
    wait_resume_state = str(capability_states.get("wait_resume") or "skipped")
    story0_required = story0_state in {"active", "compatibility_path"}
    review_required = review_state in {"active", "compatibility_path"}
    wait_resume_supported = wait_resume_state != "skipped"
    selected_path = (
        "operator_review_hold"
        if operator_review_required
        else (
            "story0_compatibility"
            if story0_state == "compatibility_path"
            else (
                "story0"
                if story0_required
                else (
                    "execution_review_compatibility"
                    if review_state == "compatibility_path"
                    else ("execution_review" if review_required else "direct_execution")
                )
            )
        )
    )
    decisions = {
        "selected_path": selected_path,
        "next_action": "wait" if operator_review_required else ("story0" if story0_required else "execution"),
        "resume_target": "derivation" if operator_review_required else ("story0" if story0_required else "execution"),
        "story0_required": story0_required,
        "review_required": review_required,
        "operator_review_required": operator_review_required,
        "operator_review_pending": operator_review_required,
        "wait_resume_supported": wait_resume_supported,
    }
    legacy_phase_normalization = {
        "story0_phase_mode": story0_state or "skipped",
        "review_phase_mode": review_state or "skipped",
        "wait_resume_phase_mode": wait_resume_state or "skipped",
        "uses_legacy_story0_phase": story0_state in {"active", "compatibility_path"},
        "uses_legacy_review_phase": review_state in {"active", "compatibility_path"},
    }
    return {
        "workflow_lifecycle": accepted,
        "lifecycle_decisions": decisions,
        "legacy_phase_normalization": legacy_phase_normalization,
    }


def build_derive_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    if not context.last_userplan_id or context.last_userplan_version is None:
        msg = "Cannot report derivation: userplan_id and userplan_version required"
        raise OrchestratorError(msg, session_id=context.session_id)

    newly_derived_items = result.get("plan_items", [])
    if protocol._merge_rederivation_fn is not None:
        final_plan_items = protocol._merge_rederivation_fn(
            preserved_items=context.preserved_plan_items or [],
            newly_derived_items=newly_derived_items,
            from_step=context.derive_from_step,
        )
    else:
        final_plan_items = newly_derived_items

    if protocol._normalize_plan_items_fn is not None:
        final_plan_items_for_api = protocol._normalize_plan_items_fn(final_plan_items)
    else:
        final_plan_items_for_api = final_plan_items

    if protocol._summarize_plan_items_fn is not None:
        summarized_items, items_truncated = protocol._summarize_plan_items_fn(final_plan_items)
    else:
        summarized_items, items_truncated = final_plan_items, False

    read_snap = protocol._read_plan_snapshot_fn or protocol._read_plan_snapshot
    write_snap = protocol._write_plan_snapshot_fn or protocol._write_plan_snapshot
    snapshot_ref = write_snap(
        session_id=context.session_id,
        userplan_id=context.last_userplan_id,
        userplan_version=context.last_userplan_version,
        userplan_steps=read_snap(context.session_id).get("userplan_steps"),
        derived_plan_items=final_plan_items,
    )
    protocol._log_session_event(
        "derived_plan_snapshot",
        source="derive",
        userplan_id=context.last_userplan_id,
        userplan_version=context.last_userplan_version,
        plan_items_count=len(final_plan_items),
        plan_items=summarized_items,
        truncated=items_truncated,
        plan_snapshot_ref=snapshot_ref,
    )
    protocol._emit_progress(
        "plan_snapshot",
        {
            "session_id": context.session_id,
            "source": "derive",
            "plan_items": final_plan_items,
            "plan_items_count": len(final_plan_items),
            "plan_snapshot_ref": snapshot_ref,
        },
    )

    lifecycle_payload = build_workflow_lifecycle_payload(protocol, result)
    payload = DerivedPlan(
        session_id=context.session_id,
        userplan_id=context.last_userplan_id,
        userplan_version=context.last_userplan_version,
        plan_items=final_plan_items_for_api,
        raw_response=result.get("raw_response", ""),
        work_type=result.get("work_type"),
        verification_tools=result.get("verification_tools"),
        story0_prerequisites=result.get("story0_prerequisites"),
        normalized_inputs=result.get("normalized_inputs"),
        derived_workflow_artifact=result.get("derived_workflow_artifact"),
        baseline_evaluation=result.get("baseline_evaluation"),
        validation_report=result.get("validation_report"),
        operator_review_points=result.get("operator_review_points"),
        result_bundle=result.get("result_bundle"),
        workflow_lifecycle=lifecycle_payload["workflow_lifecycle"] or None,
        lifecycle_decisions=lifecycle_payload["lifecycle_decisions"] or None,
        legacy_phase_normalization=lifecycle_payload["legacy_phase_normalization"] or None,
    ).to_dict()

    if context.derive_from_step is not None and protocol._update_userplan_steps_fn is not None:
        try:
            total_steps = len(final_plan_items)
            if total_steps > 0 and context.derive_from_step <= total_steps:
                step_indices = list(range(context.derive_from_step, total_steps + 1))
                protocol._update_userplan_steps_fn(
                    userplan_id=context.last_userplan_id,
                    step_indices=step_indices,
                    derivation_status="derived",
                )
                logger.info(
                    "Marked steps %s as DERIVED for UserPlan %s",
                    step_indices,
                    context.last_userplan_id,
                )
        except Exception as status_err:
            logger.warning(
                "Failed to update step statuses to DERIVED: %s",
                status_err,
                exc_info=True,
            )

    return ("report_derivation", payload)


def build_review_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    agent_reports = result.get("agent_reports", [])
    item_id = result.get("item_id") or context.last_item_id or ""
    if not item_id:
        logger.warning("Missing item_id for report_review; using 'unknown' to satisfy schema.")
        item_id = "unknown"

    status_mapping = {
        "complete": "pass",
        "timeout": "warning",
        "error": "fail",
        "skipped": "warning",
        "pending": "warning",
    }
    mapped_reports = []
    for report in agent_reports:
        mapped_report = dict(report)
        client_status = str(mapped_report.get("status", "complete")).strip().lower()
        mapped_status = status_mapping.get(client_status)
        if mapped_status is None:
            logger.warning(
                "Unmapped agent status %r for agent_type=%s; defaulting to 'fail'",
                client_status,
                mapped_report.get("agent_type", "unknown"),
            )
            mapped_status = "fail"
        mapped_report["status"] = mapped_status
        mapped_report["client_status"] = client_status
        mapped_reports.append(mapped_report)

    supported_agents = context.supported_review_agents or set()
    filtered_reports: list[dict[str, Any]] = []
    dropped_agent_types: list[str] = []
    for report in mapped_reports:
        agent_type = str(report.get("agent_type", "")).strip()
        if agent_type and agent_type in supported_agents:
            filtered_reports.append(report)
        else:
            dropped_agent_types.append(agent_type or "<missing>")
    if dropped_agent_types:
        logger.warning(
            "Dropping unsupported report_review agent types: %s",
            sorted(set(dropped_agent_types)),
        )
    mapped_reports = filtered_reports

    if not mapped_reports:
        synthetic_agent = (
            "code_quality"
            if "code_quality" in supported_agents
            else next(iter(supported_agents), "code_quality")
        )
        logger.info(
            "Review skipped: injecting synthetic pass report for session %s",
            context.session_id,
        )
        mapped_reports = [
            {
                "agent_type": synthetic_agent,
                "status": "pass",
                "client_status": "complete",
                "scores": {synthetic_agent: 1.0},
                "issues": [],
                "metadata": {
                    "review_bypass_reason": "client_review_skipped_or_no_reports",
                    "synthetic_report": True,
                },
            }
        ]

    review_payload: dict[str, Any] = {
        "session_id": context.session_id,
        "item_id": item_id,
        "agent_reports": mapped_reports,
        "iteration": result.get("iteration", 0),
    }
    if protocol._progress_cursor:
        review_payload["progress_cursor"] = protocol._progress_cursor
    return ("report_review", review_payload)


def build_revise_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    from obra.hybrid.plan_merger import PlanMerger

    revised_items = result.get("plan_items", [])
    if protocol._normalize_plan_items_fn is not None:
        revised_items_for_api = protocol._normalize_plan_items_fn(revised_items)
    else:
        revised_items_for_api = revised_items

    batch_index_raw = context.last_action_payload.get("batch_index", 0)
    total_batches_raw = context.last_action_payload.get("total_batches", 0)
    try:
        batch_index = int(batch_index_raw)
    except (TypeError, ValueError):
        batch_index = 0
    try:
        total_batches = int(total_batches_raw)
    except (TypeError, ValueError):
        total_batches = 0
    batch_index = max(batch_index, 0)
    total_batches = max(total_batches, 1)
    is_final_or_single = total_batches <= 1 or batch_index >= total_batches - 1

    cache_session_id = getattr(protocol, "_revision_plan_cache_session_id", None)
    cache_items = getattr(protocol, "_revision_plan_cache", None)
    if cache_session_id != context.session_id or batch_index == 0 or cache_items is None:
        read_snap = protocol._read_plan_snapshot_fn or protocol._read_plan_snapshot
        snapshot = read_snap(context.session_id)
        cache_items = snapshot.get("derived_plan_items") or []
        if not isinstance(cache_items, list):
            cache_items = []
        protocol._revision_plan_cache = cache_items
        protocol._revision_plan_cache_session_id = context.session_id

    if protocol._revision_plan_cache:
        merged_plan_items = PlanMerger.merge_revision_batch(
            protocol._revision_plan_cache,
            revised_items,
        )
    else:
        merged_plan_items = list(revised_items)

    protocol._revision_plan_cache = merged_plan_items
    full_plan_items = merged_plan_items
    authoritative_snapshot_payload: dict[str, Any] | None = None

    if is_final_or_single:
        protocol._revision_plan_cache = None
        protocol._revision_plan_cache_session_id = None
        read_snap = protocol._read_plan_snapshot_fn or protocol._read_plan_snapshot
        write_snap = protocol._write_plan_snapshot_fn or protocol._write_plan_snapshot
        snapshot_ref = write_snap(
            session_id=context.session_id,
            userplan_steps=read_snap(context.session_id).get("userplan_steps"),
            derived_plan_items=full_plan_items,
        )
        if protocol._summarize_plan_items_fn is not None:
            summarized_items, items_truncated = protocol._summarize_plan_items_fn(full_plan_items)
        else:
            summarized_items, items_truncated = full_plan_items, False
        protocol._log_session_event(
            "derived_plan_snapshot",
            source="revise",
            plan_items_count=len(full_plan_items),
            plan_items=summarized_items,
            truncated=items_truncated,
            plan_snapshot_ref=snapshot_ref,
        )
        authoritative_snapshot_payload = {
            "session_id": context.session_id,
            "source": "revise",
            "plan_items": full_plan_items,
            "plan_items_count": len(full_plan_items),
            "plan_snapshot_ref": snapshot_ref,
            "mode": "authoritative",
        }
    else:
        if protocol._summarize_plan_items_fn is not None:
            summarized_items, items_truncated = protocol._summarize_plan_items_fn(revised_items)
        else:
            summarized_items, items_truncated = revised_items, False
        protocol._log_session_event(
            "derived_plan_snapshot",
            source="revise",
            plan_items_count=len(revised_items),
            plan_items=summarized_items,
            truncated=items_truncated,
        )
        protocol._emit_progress(
            "revision_batch_progress",
            {
                "batch_index": batch_index + 1,
                "total_batches": total_batches,
                "items_revised": len(revised_items),
            },
        )

    revise_payload = RevisedPlan(
        session_id=context.session_id,
        plan_items=revised_items_for_api,
        addressed_issues=result.get("addressed_issues", []),
        deferred_issues=result.get("deferred_issues", []),
        changes_summary=result.get("changes_summary", ""),
        raw_response=result.get("raw_response", ""),
        revision_failure_class=(
            "valid_output_no_file_edit" if result.get("batches_failed_count", 0) > 0 else None
        ),
        no_changes=not revised_items_for_api,
    ).to_dict()

    if authoritative_snapshot_payload is not None:
        protocol._emit_progress("plan_snapshot", authoritative_snapshot_payload)

    return ("report_revision", revise_payload)


def build_fix_payload(
    protocol: "ServerProtocol",
    result: dict[str, Any],
    context: "ReportContext",
) -> tuple[str, dict[str, Any]]:
    from obra.config.loaders import get_failure_context_max_chars

    fix_results = result.get("fix_results", [])
    item_id = result.get("item_id") or context.last_item_id or ""
    filtered_details = []
    dropped = 0
    max_ctx_chars = get_failure_context_max_chars()

    for fix_result in fix_results:
        canonical_id = str(fix_result.get("canonical_id") or fix_result.get("issue_id") or "").strip()
        issue_id = str(fix_result.get("issue_id") or canonical_id).strip()
        if not canonical_id:
            dropped += 1
            continue
        detail: dict[str, Any] = {
            "issue_id": issue_id,
            "canonical_id": canonical_id,
            "status": fix_result.get("status", ""),
            "reason": fix_result.get("reason", ""),
            "summary": fix_result.get("summary", ""),
            "approach_summary": fix_result.get("approach_summary", ""),
        }
        verification = (
            fix_result.get("verification")
            if isinstance(fix_result.get("verification"), dict)
            else {}
        )
        for field_name in ("verification_outcome", "verification_scope", "attribution_confidence"):
            field_value = fix_result.get(field_name)
            if not field_value and verification:
                field_value = verification.get(field_name)
            if field_value:
                detail[field_name] = str(field_value)
        if isinstance(verification, dict) and detail["status"] == "failed":
            last_error = verification.get("last_tool_error", {})
            failure_reason = verification.get("failure_reason", "")
            if last_error or failure_reason:
                error_output = str(last_error.get("output", ""))[:max_ctx_chars]
                detail["failure_context"] = {
                    "tool": last_error.get("tool", ""),
                    "output": error_output,
                    "failure_reason": failure_reason,
                }
        filtered_details.append(detail)

    if dropped:
        logger.warning("Dropped %d fix_details without canonical_id before report_fix.", dropped)

    fixes_applied = sum(1 for detail in filtered_details if detail.get("status") == "applied")
    fixes_failed = sum(1 for detail in filtered_details if detail.get("status") == "failed")

    fix_result_history = context.fix_result_history
    if fix_result_history is not None:
        for detail in filtered_details:
            fix_result_history.append(
                {
                    "issue_id": detail.get("canonical_id", detail.get("id", "")),
                    "status": detail.get("status", "unknown"),
                    "reason": detail.get("reason", ""),
                    "verification_scope": detail.get("verification_scope", ""),
                    "verification_command": (
                        detail.get("failure_context", {}).get("tool", "")
                        if isinstance(detail.get("failure_context"), dict)
                        else ""
                    ),
                }
            )
        if protocol._progress_emitter:
            applied = sum(1 for item in fix_result_history if item.get("status") == "applied")
            failed = sum(1 for item in fix_result_history if item.get("status") == "failed")
            protocol._progress_emitter.review_fix_progress(
                item_id=item_id,
                changes_applied=applied,
                changes_failed=failed,
            )

    fix_payload = FixReport(
        session_id=context.session_id,
        item_id=item_id,
        fixes_applied=fixes_applied,
        fixes_failed=fixes_failed,
        fix_details=filtered_details,
        progress_cursor=protocol._progress_cursor,
    ).to_dict()
    return ("report_fix", fix_payload)
