"""Server communication protocol adapter.

Sits between orchestrator business logic and API client HTTP transport.
Handles payload shaping, response parsing, progress event routing, and
polling backoff.
"""

from __future__ import annotations

import logging
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, ClassVar
from urllib.parse import urlencode

from obra.api.protocol import (
    ActionType,
    ServerAction,
)
from obra.constants import (
    HYBRID_POLLING_BACKOFF_MULTIPLIER,
    HYBRID_POLLING_BASE_DELAY_S,
    HYBRID_POLLING_MAX_DELAY_S,
)
from obra.exceptions import OrchestratorError
from obra.hybrid import payload_builders, progress_handler

logger = logging.getLogger(__name__)

@dataclass(frozen=False)
class ReportContext:
    """Per-call context snapshot for ServerProtocol.report_result().

    Captures all orchestrator state needed by payload builders, avoiding
    back-references to the orchestrator during server communication.
    """

    session_id: str
    last_action_payload: dict[str, Any]
    last_item_id: str | None = None
    preserved_plan_items: list[dict[str, Any]] | None = None
    derive_from_step: int | None = None
    last_userplan_id: str | None = None
    last_userplan_version: int | None = None
    fix_result_history: list[dict[str, Any]] | None = field(default=None)
    supported_review_agents: set[str] | None = None


class ServerProtocol:
    """Protocol adapter for server communication.

    Encapsulates all logic for:
    - Polling backoff
    - Response sanitization and endpoint URL construction
    - Progress event routing and deduplication
    - Per-ActionType payload building and report submission
    """

    _PAYLOAD_BUILDERS: ClassVar[dict[ActionType, str]] = {
        ActionType.DERIVE: "_build_derive_payload",
        ActionType.INTENT: "_build_intent_payload",
        ActionType.STORY0: "_build_story0_payload",
        ActionType.STORY_PREFLIGHT: "_build_story_preflight_payload",
        ActionType.EXAMINE: "_build_examine_payload",
        ActionType.REVISE: "_build_revise_payload",
        ActionType.EXECUTE: "_build_execute_payload",
        ActionType.REVIEW: "_build_review_payload",
        ActionType.FIX: "_build_fix_payload",
        ActionType.ESCALATE: "_build_escalate_payload",
        ActionType.VALIDATOR: "_build_validator_payload",
        ActionType.PIPELINE_STAGE: "_build_pipeline_stage_payload",
    }

    def __init__(
        self,
        *,
        session_id: str,
        request_fn: Callable,
        emit_progress: Callable,
        log_session_event: Callable,
        on_progress: Callable | None,
        progress_emitter: Any | None,
        config: dict[str, Any] | None = None,
        normalize_plan_items_fn: Callable | None = None,
        summarize_plan_items_fn: Callable | None = None,
        merge_rederivation_fn: Callable | None = None,
        update_userplan_steps_fn: Callable | None = None,
        read_plan_snapshot_fn: Callable | None = None,
        write_plan_snapshot_fn: Callable | None = None,
    ) -> None:
        self._session_id = session_id
        self._request_fn = request_fn
        self._emit_progress = emit_progress
        self._log_session_event = log_session_event
        self._on_progress = on_progress
        self._progress_emitter = progress_emitter
        self._config = config
        # Injectable callables for payload builders (wired from orchestrator)
        self._normalize_plan_items_fn = normalize_plan_items_fn
        self._summarize_plan_items_fn = summarize_plan_items_fn
        self._merge_rederivation_fn = merge_rederivation_fn
        self._update_userplan_steps_fn = update_userplan_steps_fn
        # Plan snapshot callables — wired via orchestrator lambdas so test mocks
        # on orchestrator._read_plan_snapshot / _write_plan_snapshot are respected
        self._read_plan_snapshot_fn = read_plan_snapshot_fn
        self._write_plan_snapshot_fn = write_plan_snapshot_fn

        # Incremental polling cursor — string token used in URL query params
        self._progress_cursor: str | None = None

        # ISSUE-HYBRID-023: Skip historical progress events on resume
        # Set to ISO timestamp when resume() starts; events before this are skipped
        self._resume_start_timestamp: str | None = None

        # Tier 1 — Event-ID dedup (exclusive to handle_progress_events)
        self._processed_event_ids: set[str] = set()
        self._processed_event_ids_queue: deque[str] = deque()
        self._processed_event_ids_max: int = 1000  # LRU capacity

        # Tier 2 — Item/phase dedup (also accessed by orchestrator handler and
        # phase management methods via delegation properties)
        # Track locally-completed items to prevent duplicate item_completed emissions
        self._locally_completed_items: set[str] = set()
        # Track started items by execution context to prevent spurious emissions
        # Key format: "{item_id}:{iteration}:{attempt}"
        self._locally_started_items: set[str] = set()
        # Track locally-completed phases to prevent duplicate phase_completed emissions
        self._locally_completed_phases: set[str] = set()
        # Track locally-started phases to prevent duplicate phase_started emissions
        self._locally_started_phases: set[str] = set()

    @property
    def session_id(self) -> str:
        """Read-only session identifier."""
        return self._session_id

    def set_session_id(self, session_id: str) -> None:
        """Update session_id after session start (orchestrator syncs this)."""
        self._session_id = session_id

    def set_resume_timestamp(self, timestamp: str) -> None:
        """Record the resume start timestamp for filtering historical progress events."""
        self._resume_start_timestamp = timestamp

    def poll_with_backoff(
        self,
        poll_count: int,
        base_delay: float = HYBRID_POLLING_BASE_DELAY_S,
        max_delay: float = HYBRID_POLLING_MAX_DELAY_S,
        multiplier: float = HYBRID_POLLING_BACKOFF_MULTIPLIER,
    ) -> float:
        """Calculate and execute exponential backoff delay for polling.

        Implements exponential backoff: delay = base_delay * (multiplier ^ poll_count)
        capped at max_delay.

        Args:
            poll_count: Current poll iteration (0-indexed)
            base_delay: Initial delay in seconds
            max_delay: Maximum delay in seconds
            multiplier: Exponential multiplier

        Returns:
            The actual delay used in seconds
        """
        delay = min(base_delay * (multiplier**poll_count), max_delay)
        time.sleep(delay)
        logger.debug(f"Polling wait: {delay:.1f}s (poll #{poll_count + 1})")
        return delay

    def sanitize_server_action_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """Drop non-ServerAction fields from API responses."""
        allowed_keys = {
            "action",
            "session_id",
            "iteration",
            "payload",
            "metadata",
            "bypass_modes_active",
            "error_code",
            "error_message",
            "timestamp",
            "rationale",
        }
        return {key: value for key, value in response.items() if key in allowed_keys}

    def get_session_action_endpoint(self) -> str:
        """Build get_session_action endpoint with optional progress cursor."""
        if not self._session_id:
            return "get_session_action"

        params: dict[str, str] = {"session_id": self._session_id}
        if self._progress_cursor:
            params["progress_cursor"] = self._progress_cursor
        return f"get_session_action?{urlencode(params)}"

    def handle_progress_events(
        self,
        response: dict[str, Any],
        *,
        current_phase: str | None = None,
        phase_span_id: str | None = None,
        subphase_span_id: str | None = None,
    ) -> None:
        """Extract and route progress events from server response to progress callback."""
        progress_handler.handle_progress_events(
            self,
            response,
            current_phase=current_phase,
            phase_span_id=phase_span_id,
            subphase_span_id=subphase_span_id,
        )

    def parse_polling_response(
        self,
        response: dict[str, Any],
        iteration: int,
    ) -> ServerAction:
        """Parse polling responses from get_session_action into ServerAction.

        Supports both full ServerAction payloads and the polling shape:
        {action, reason, confidence, status}.
        """
        if "session_id" in response:
            sanitized = self.sanitize_server_action_response(response)
            return ServerAction.from_dict(sanitized)

        if "action" in response and "status" in response:
            logger.info(
                "Polling response missing session_id; adapting to ServerAction "
                "(action=%s, status=%s).",
                response.get("action"),
                response.get("status"),
            )
            action_value = str(response.get("action", ActionType.WAIT.value)).strip().lower()
            adapted_payload: dict[str, Any] = {
                "status": str(response.get("status") or ""),
                "polling": response,
            }
            if response.get("reason") is not None:
                adapted_payload["reason"] = response.get("reason")
            if response.get("confidence") is not None:
                adapted_payload["confidence"] = response.get("confidence")
            for field_name in (
                "pending_manual",
                "resume",
                "workflow_lifecycle",
                "lifecycle_decisions",
                "legacy_phase_normalization",
                "metadata",
            ):
                value = response.get(field_name)
                if value is not None:
                    adapted_payload[field_name] = value
            if action_value == ActionType.ESCALATE.value:
                raw_details = response.get("escalation_details", {})
                escalation_details = raw_details if isinstance(raw_details, dict) else {}
                adapted_payload = {
                    "polling": response,
                    "reason": response.get("reason", "blocked"),
                    "reason_code": response.get("reason_code", ""),
                    "reason_text": response.get("reason_text", response.get("reason", "")),
                    "blocking_issues": response.get("blocking_issues", []),
                    "invariant_errors": response.get("invariant_errors", []),
                    "repair_attempt_history": response.get("repair_attempt_history", []),
                    "iteration_history": response.get("iteration_history", []),
                    "options": response.get("options", []),
                    "convergence_diagnostic": response.get("convergence_diagnostic", {}),
                    "escalation_id": response.get("escalation_id", ""),
                    "escalation_details": escalation_details,
                }
            adapted = {
                "action": response.get("action", ActionType.WAIT.value),
                "session_id": self._session_id or "",
                "iteration": iteration,
                "payload": adapted_payload,
                "metadata": {"polling_adapted": True},
            }
            return ServerAction.from_dict(adapted)

        msg = f"Unexpected polling response shape: {response}"
        raise OrchestratorError(
            msg,
            session_id=self._session_id or "unknown",
        )

    # ------------------------------------------------------------------
    # S2: report_result() envelope and per-ActionType payload builders
    # ------------------------------------------------------------------

    def report_result(
        self,
        action: ActionType,
        result: dict[str, Any],
        *,
        context: "ReportContext",
        current_phase: str | None = None,
        phase_span_id: str | None = None,
        subphase_span_id: str | None = None,
    ) -> ServerAction:
        """Submit action result to server and return the next ServerAction.

        Dispatches to a per-ActionType payload builder, submits via request_fn,
        routes progress events, sanitizes the response, and constructs a ServerAction.
        """
        builder_name = self._PAYLOAD_BUILDERS[action]
        builder = getattr(self, builder_name)
        endpoint, payload = builder(result, context)
        response = self._request_fn("POST", endpoint, json=payload)
        if isinstance(response, dict):
            self.handle_progress_events(
                response,
                current_phase=current_phase,
                phase_span_id=phase_span_id,
                subphase_span_id=subphase_span_id,
            )
            response = self.sanitize_server_action_response(response)
        return ServerAction.from_dict(response)

    # -- Plan snapshot helpers (moved from orchestrator; PLAN_SNAPSHOT_DIRNAME
    #    re-defined as module constant above to avoid circular import) -----------

    def _plan_snapshot_dir(self):
        """Return the directory for plan snapshot reference files."""
        return progress_handler.plan_snapshot_dir(self)

    def _write_plan_snapshot(
        self,
        *,
        session_id: str,
        userplan_id: str | None = None,
        userplan_version: int | None = None,
        userplan_steps: list[dict[str, Any]] | None = None,
        derived_plan_items: list[dict[str, Any]] | None = None,
    ) -> str | None:
        """Write a full plan snapshot reference file for the viewer."""
        return progress_handler.write_plan_snapshot(
            self,
            session_id=session_id,
            userplan_id=userplan_id,
            userplan_version=userplan_version,
            userplan_steps=userplan_steps,
            derived_plan_items=derived_plan_items,
        )

    def _read_plan_snapshot(self, session_id: str) -> dict[str, Any]:
        """Read an existing plan snapshot file if present."""
        return progress_handler.read_plan_snapshot(self, session_id)

    # -- Per-ActionType payload builders ---------------------------------------

    def _build_intent_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.INTENT -> report_intent."""
        return payload_builders.build_intent_payload(self, result, context)

    def _build_story0_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.STORY0 -> report_story0."""
        return payload_builders.build_story0_payload(self, result, context)

    def _build_story_preflight_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.STORY_PREFLIGHT -> report_validator."""
        return payload_builders.build_story_preflight_payload(self, result, context)

    def _build_examine_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.EXAMINE -> report_examination."""
        return payload_builders.build_examine_payload(self, result, context)

    def _build_execute_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.EXECUTE -> report_execution."""
        return payload_builders.build_execute_payload(self, result, context)

    def _build_escalate_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.ESCALATE -> user_decision."""
        return payload_builders.build_escalate_payload(self, result, context)

    def _build_validator_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.VALIDATOR -> report_validator."""
        return payload_builders.build_validator_payload(self, result, context)

    def _build_pipeline_stage_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.PIPELINE_STAGE -> report_pipeline_stage."""
        return payload_builders.build_pipeline_stage_payload(self, result, context)

    @staticmethod
    def _extract_workflow_lifecycle_source(result: dict[str, Any]) -> dict[str, Any]:
        """Extract accepted workflow lifecycle metadata from derive outputs."""
        return payload_builders.extract_workflow_lifecycle_source(self, result)

    @staticmethod
    def _build_workflow_lifecycle_payload(result: dict[str, Any]) -> dict[str, dict[str, Any]]:
        """Build the canonical workflow lifecycle payload parts for DerivedPlan transport."""
        return payload_builders.build_workflow_lifecycle_payload(self, result)

    def _build_derive_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.DERIVE -> report_derivation."""
        return payload_builders.build_derive_payload(self, result, context)

    def _build_review_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.REVIEW -> report_review."""
        return payload_builders.build_review_payload(self, result, context)

    def _build_revise_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.REVISE -> report_revision."""
        return payload_builders.build_revise_payload(self, result, context)

    def _build_fix_payload(
        self,
        result: dict[str, Any],
        context: "ReportContext",
    ) -> tuple[str, dict[str, Any]]:
        """Build payload for ActionType.FIX -> report_fix."""
        return payload_builders.build_fix_payload(self, result, context)
