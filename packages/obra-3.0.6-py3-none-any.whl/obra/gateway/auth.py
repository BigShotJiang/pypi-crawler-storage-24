"""Bearer token authentication for the gateway server."""

from __future__ import annotations

import asyncio
import hmac
import secrets
from typing import Callable

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

_bearer_scheme = HTTPBearer()


def verify_token(credentials: HTTPAuthorizationCredentials, expected_token: str) -> bool:
    """Verify bearer token using constant-time comparison.

    Args:
        credentials: The HTTP authorization credentials.
        expected_token: The expected token to compare against.

    Returns:
        True if token matches, False otherwise.
    """
    return hmac.compare_digest(credentials.credentials, expected_token)


def get_auth_dependency(token: str) -> Callable:
    """Create a FastAPI dependency that validates bearer token auth.

    Args:
        token: The expected bearer token.

    Returns:
        A FastAPI Depends callable that raises 401 on invalid/missing tokens.
    """

    async def _verify(
        request: Request,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
    ) -> HTTPAuthorizationCredentials:
        browser_rig_faults_enabled = bool(
            getattr(request.app.state, "workflow_studio_browser_faults_enabled", False)
        )
        rig_fault_state = getattr(request.app.state, "workflow_studio_browser_fault_state", None)
        if (
            browser_rig_faults_enabled
            and isinstance(rig_fault_state, dict)
            and request.url.path.startswith("/api/")
        ):
            http_delay_ms = max(0, int(rig_fault_state.get("http_delay_ms", 0) or 0))
            if http_delay_ms > 0:
                await asyncio.sleep(http_delay_ms / 1000)

            unauthorized_remaining = max(
                0,
                int(rig_fault_state.get("unauthorized_requests_remaining", 0) or 0),
            )
            unauthorized_path_prefix = str(
                rig_fault_state.get("unauthorized_path_prefix", "") or ""
            ).strip()
            matches_unauthorized_path = (
                not unauthorized_path_prefix
                or request.url.path.startswith(unauthorized_path_prefix)
            )
            if unauthorized_remaining > 0 and matches_unauthorized_path:
                rig_fault_state["unauthorized_requests_remaining"] = (
                    unauthorized_remaining - 1
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication failed",
                )
        if not verify_token(credentials, token):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or missing authentication token",
            )
        return credentials

    return _verify


def generate_token() -> str:
    """Generate a cryptographically secure URL-safe token.

    Returns:
        A 32-byte URL-safe token string.
    """
    return secrets.token_urlsafe(32)
