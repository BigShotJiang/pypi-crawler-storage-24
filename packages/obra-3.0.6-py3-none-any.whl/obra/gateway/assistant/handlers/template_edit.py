"""Template edit action handlers — propose and execute template mutations."""

from __future__ import annotations

import copy
import difflib
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext


def _resolve_template_content(
    workflow: dict[str, Any],
    stage_id: str | None,
    template_role: str,
) -> str | None:
    """Extract current template content from the workflow.

    For stage-level templates, locates the stage by *stage_id* and reads
    the binding matching *template_role*.  For workflow-level templates
    (stage_id is None), reads from the top-level workflow_definition.
    """
    defn = workflow.get("workflow_definition", {})

    if stage_id is None:
        # Workflow-level template (e.g., workflow description or top-level prompt)
        templates = defn.get("templates", {})
        return templates.get(template_role)

    # Stage-level template
    stages = defn.get("stages", [])
    stage = next((s for s in stages if s.get("stage_id") == stage_id), None)
    if stage is None:
        return None

    # Check template_bindings first, then inline template fields
    for binding in stage.get("template_bindings", []):
        if binding.get("role") == template_role:
            return binding.get("content", "")

    # Fallback: inline template field (e.g., stage_prompt, input_template)
    return stage.get(template_role)


def _apply_template_to_workflow(
    workflow: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
) -> dict[str, Any]:
    """Return a copy of *workflow* with the target template replaced."""
    candidate = copy.deepcopy(workflow)
    defn = candidate.get("workflow_definition", {})

    if stage_id is None:
        templates = defn.setdefault("templates", {})
        templates[template_role] = proposed_content
        return candidate

    stages = defn.get("stages", [])
    stage = next((s for s in stages if s.get("stage_id") == stage_id), None)
    if stage is None:
        return candidate

    # Update template_bindings if the role exists there
    for binding in stage.get("template_bindings", []):
        if binding.get("role") == template_role:
            binding["content"] = proposed_content
            return candidate

    # Fallback: set inline template field
    stage[template_role] = proposed_content
    return candidate


def propose(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose a template edit and return a diff preview."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str | None = inputs.get("stage_id")
    template_role: str = inputs.get("template_role", "")
    proposed_content: str = inputs.get("proposed_content", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    current_content = _resolve_template_content(workflow, stage_id, template_role)
    if current_content is None:
        current_content = ""

    # Compute unified diff
    before_lines = current_content.splitlines(keepends=True)
    after_lines = proposed_content.splitlines(keepends=True)
    diff_lines = list(
        difflib.unified_diff(
            before_lines,
            after_lines,
            fromfile=f"{template_role} (current)",
            tofile=f"{template_role} (proposed)",
        )
    )

    return {
        "outcome": "proposal",
        "action_type": "propose_template_edit",
        "preview_type": "diff",
        "diff": diff_lines,
        "before_content": current_content,
        "after_content": proposed_content,
        "workflow_id": wf_id,
        "stage_id": stage_id,
        "template_role": template_role,
    }


def execute(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed template edit."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str | None = inputs.get("stage_id")
    template_role: str = inputs.get("template_role", "")
    proposed_content: str = inputs.get("proposed_content", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    # Build candidate with the proposed content applied
    candidate = _apply_template_to_workflow(
        workflow, stage_id, template_role, proposed_content
    )

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )

    outcome = result.get("outcome", "")

    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }

    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }

    # accepted
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
        "stage_id": stage_id,
        "template_role": template_role,
    }
