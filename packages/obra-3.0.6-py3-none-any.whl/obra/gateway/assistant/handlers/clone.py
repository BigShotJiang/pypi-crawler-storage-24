"""Clone-and-adapt handler — clone a workflow with targeted modifications."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext


def _stage_title(stage: dict[str, Any]) -> str:
    return stage.get("title", stage.get("stage_id", ""))


def propose_adaptation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose cloning a workflow with adapted definition."""
    source_workflow_id: str = inputs.get("source_workflow_id", "")
    adapted_definition: dict[str, Any] = inputs.get("adapted_definition", {})

    source = ctx.repository.get_workflow(source_workflow_id)
    if source is None:
        return {"outcome": "invalid", "detail": f"Source workflow not found: {source_workflow_id}"}

    source_title = source.get("title", "")
    source_stages = (
        source.get("workflow_definition", {}).get("stages", [])
    )
    adapted_stages = adapted_definition.get("stages", [])

    # Build adaptation summary comparing source to adapted
    source_titles = {_stage_title(s) for s in source_stages}
    adapted_titles = {_stage_title(s) for s in adapted_stages}
    added = sorted(adapted_titles - source_titles)
    removed = sorted(source_titles - adapted_titles)
    # Stages with same title but possibly different content
    changed_titles = sorted(adapted_titles & source_titles)

    adaptation_summary: dict[str, Any] = {
        "source_stage_count": len(source_stages),
        "adapted_stage_count": len(adapted_stages),
        "added_stages": added,
        "removed_stages": removed,
        "retained_stages": changed_titles,
    }

    return {
        "outcome": "proposal",
        "action_type": "clone_and_adapt",
        "preview_type": "scaffold",
        "adapted_definition": adapted_definition,
        "source_workflow_id": source_workflow_id,
        "source_title": source_title,
        "adaptation_summary": adaptation_summary,
    }


def execute_adaptation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Execute: create a new workflow from the adapted definition. Original is not mutated."""
    adapted_definition: dict[str, Any] = inputs.get("adapted_definition", {})
    domain_id: str = inputs.get("domain_id", adapted_definition.get("domain_id", ""))

    payload: dict[str, Any] = {
        "title": adapted_definition.get("title", ""),
        "domain_id": domain_id,
        "workflow_definition": adapted_definition,
    }

    # POST — no expected_revision_id needed (new workflow, not mutating source)
    result = ctx.action_service.create_workflow(payload)

    workflow_data = result.get("workflow", {})
    new_workflow_id = workflow_data.get("workflow_id", "")
    revision_ref = result.get("resulting_revision_ref", {})

    return {
        "outcome": "applied",
        "workflow_id": new_workflow_id,
        "resulting_revision_ref": revision_ref,
    }
