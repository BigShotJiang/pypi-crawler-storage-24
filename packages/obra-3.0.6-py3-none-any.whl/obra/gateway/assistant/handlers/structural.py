"""Structural workflow change handlers — propose and execute stage/connection mutations."""

from __future__ import annotations

import copy
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_stages(workflow: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the stages list from a workflow dict."""
    return workflow.get("workflow_definition", {}).get("stages", [])


def _find_stage(stages: list[dict[str, Any]], stage_id: str) -> dict[str, Any] | None:
    """Find a stage by its stage_id."""
    return next((s for s in stages if s.get("stage_id") == stage_id), None)


def _stage_title(stage: dict[str, Any]) -> str:
    return stage.get("title", stage.get("stage_id", ""))


# ---------------------------------------------------------------------------
# Propose handlers
# ---------------------------------------------------------------------------


def propose_insert(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose inserting a new stage into the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    after_stage_id: str | None = inputs.get("after_stage_id")
    stage_definition: dict[str, Any] = inputs.get("stage_definition", {})

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)

    # Compute insertion position
    if after_stage_id is None:
        insertion_index = 0
    else:
        idx = next(
            (i for i, s in enumerate(stages) if s.get("stage_id") == after_stage_id),
            None,
        )
        if idx is None:
            return {"outcome": "invalid", "detail": f"Stage not found: {after_stage_id}"}
        insertion_index = idx + 1

    # Surrounding context
    prev_title = _stage_title(stages[insertion_index - 1]) if insertion_index > 0 else None
    next_title = _stage_title(stages[insertion_index]) if insertion_index < len(stages) else None

    return {
        "outcome": "proposal",
        "action_type": "propose_stage_insert",
        "preview_type": "scaffold",
        "proposed_stage": stage_definition,
        "insertion_index": insertion_index,
        "surrounding_stages": {
            "previous": prev_title,
            "next": next_title,
        },
        "workflow_id": wf_id,
    }


def execute_insert(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage insert."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    after_stage_id: str | None = inputs.get("after_stage_id")
    stage_definition: dict[str, Any] = inputs.get("stage_definition", {})
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    stages = candidate.get("workflow_definition", {}).get("stages", [])

    if after_stage_id is None:
        insertion_index = 0
    else:
        idx = next(
            (i for i, s in enumerate(stages) if s.get("stage_id") == after_stage_id),
            None,
        )
        if idx is None:
            return {"outcome": "invalid", "detail": f"Stage not found: {after_stage_id}"}
        insertion_index = idx + 1

    stages.insert(insertion_index, stage_definition)

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_remove(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose removing a stage from the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str = inputs.get("stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    target = _find_stage(stages, stage_id)
    if target is None:
        return {"outcome": "invalid", "detail": f"Stage not found: {stage_id}"}

    # Affected connections: stages that depend on or are depended upon by this stage
    affected_connections: list[dict[str, str]] = []
    for s in stages:
        if stage_id in s.get("depends_on", []):
            affected_connections.append({
                "stage_id": s.get("stage_id", ""),
                "title": _stage_title(s),
                "relationship": "depends_on_removed",
            })

    return {
        "outcome": "proposal",
        "action_type": "propose_stage_remove",
        "preview_type": "diff",
        "removed_stage": {
            "stage_id": stage_id,
            "title": _stage_title(target),
        },
        "affected_connections": affected_connections,
        "workflow_id": wf_id,
    }


def execute_remove(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage removal."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str = inputs.get("stage_id", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    stages = candidate.get("workflow_definition", {}).get("stages", [])

    # Remove the target stage
    candidate["workflow_definition"]["stages"] = [
        s for s in stages if s.get("stage_id") != stage_id
    ]

    # Clean up depends_on references
    for s in candidate["workflow_definition"]["stages"]:
        deps = s.get("depends_on", [])
        if stage_id in deps:
            s["depends_on"] = [d for d in deps if d != stage_id]

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_reorder(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose reordering stages in the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    ordered_stage_ids: list[str] = inputs.get("ordered_stage_ids", [])

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    stage_map = {s.get("stage_id", ""): s for s in stages}

    before_order = [
        {"stage_id": s.get("stage_id", ""), "title": _stage_title(s)}
        for s in stages
    ]

    after_order = []
    for sid in ordered_stage_ids:
        stage = stage_map.get(sid)
        if stage:
            after_order.append({"stage_id": sid, "title": _stage_title(stage)})

    return {
        "outcome": "proposal",
        "action_type": "propose_stage_reorder",
        "preview_type": "diff",
        "before_order": before_order,
        "after_order": after_order,
        "workflow_id": wf_id,
    }


def execute_reorder(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage reorder."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    ordered_stage_ids: list[str] = inputs.get("ordered_stage_ids", [])
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    stages = candidate.get("workflow_definition", {}).get("stages", [])
    stage_map = {s.get("stage_id", ""): s for s in stages}

    reordered = [stage_map[sid] for sid in ordered_stage_ids if sid in stage_map]
    candidate["workflow_definition"]["stages"] = reordered

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_connect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose adding a connection (dependency edge) between two stages."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    source = _find_stage(stages, source_stage_id)
    target = _find_stage(stages, target_stage_id)

    if source is None:
        return {"outcome": "invalid", "detail": f"Source stage not found: {source_stage_id}"}
    if target is None:
        return {"outcome": "invalid", "detail": f"Target stage not found: {target_stage_id}"}

    return {
        "outcome": "proposal",
        "action_type": "propose_connection_add",
        "preview_type": "diff",
        "edge_added": {
            "source_stage_id": source_stage_id,
            "source_title": _stage_title(source),
            "target_stage_id": target_stage_id,
            "target_title": _stage_title(target),
        },
        "workflow_id": wf_id,
    }


def execute_connect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed connection add."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    stages = candidate.get("workflow_definition", {}).get("stages", [])
    target = _find_stage(stages, target_stage_id)
    if target is None:
        return {"outcome": "invalid", "detail": f"Target stage not found: {target_stage_id}"}

    deps = target.setdefault("depends_on", [])
    if source_stage_id not in deps:
        deps.append(source_stage_id)

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_disconnect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose removing a connection (dependency edge) between two stages."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    source = _find_stage(stages, source_stage_id)
    target = _find_stage(stages, target_stage_id)

    if source is None:
        return {"outcome": "invalid", "detail": f"Source stage not found: {source_stage_id}"}
    if target is None:
        return {"outcome": "invalid", "detail": f"Target stage not found: {target_stage_id}"}

    return {
        "outcome": "proposal",
        "action_type": "propose_connection_remove",
        "preview_type": "diff",
        "edge_removed": {
            "source_stage_id": source_stage_id,
            "source_title": _stage_title(source),
            "target_stage_id": target_stage_id,
            "target_title": _stage_title(target),
        },
        "workflow_id": wf_id,
    }


def execute_disconnect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed connection removal."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    stages = candidate.get("workflow_definition", {}).get("stages", [])
    target = _find_stage(stages, target_stage_id)
    if target is None:
        return {"outcome": "invalid", "detail": f"Target stage not found: {target_stage_id}"}

    deps = target.get("depends_on", [])
    target["depends_on"] = [d for d in deps if d != source_stage_id]

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


# ---------------------------------------------------------------------------
# Shared apply result mapper
# ---------------------------------------------------------------------------


def _apply_result(result: dict[str, Any], wf_id: str) -> dict[str, Any]:
    """Map the action service result to a handler response."""
    outcome = result.get("outcome", "")

    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }

    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }

    # accepted
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
    }
