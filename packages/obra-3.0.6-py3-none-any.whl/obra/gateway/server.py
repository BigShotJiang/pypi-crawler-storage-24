"""Gateway server — FastAPI application bridging HTTP/WebSocket clients to HybridOrchestrator."""

from __future__ import annotations

import ipaddress
import logging
import threading
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from obra import __version__
from obra.config.loaders import get_gateway_config
from obra.gateway.auth import generate_token, get_auth_dependency
from obra.gateway.security.client_ip import extract_client_ip_from_request
from obra.gateway.security.rate_limit import TokenBucketRateLimiter
from obra.gateway.session_manager import SessionManager

logger = logging.getLogger(__name__)


def _is_loopback_host(host: str) -> bool:
    """Return True when the provided host resolves to loopback."""
    normalized = host.strip().lower()
    if normalized in {"localhost", "::1"}:
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _print_startup_banner(host: str, port: int, token: str) -> None:
    """Print Rich-formatted startup banner."""
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    token_hint = token[:4] + "***" if len(token) > 4 else "***"

    lines = [
        f"[bold]Obra Gateway[/bold] v{__version__}",
        "",
        f"  Listening:  [cyan]http://{host}:{port}[/cyan]",
        f"  Auth token: [yellow]{token_hint}[/yellow]",
        "",
        "[dim]Endpoints:[/dim]",
        "  GET    /api/workflows             Workflow inspection",
        "  GET    /api/artifacts             Artifact inspection",
        "  GET    /api/runners               Runner lookup",
        "  POST   /api/workflow-derivations  Guided derivation control plane",
        "  GET    /api/workflow-runs         Workflow-run control plane",
        "  WS     /api/events/stream         Workflow Studio event stream",
        "  [dim]Legacy coexistence:[/dim]",
        "  POST   /v1/sessions              Session compatibility route",
        "  GET    /v1/sessions              Session compatibility route",
        "  GET    /v1/sessions/{id}         Session compatibility route",
        "  GET    /v1/sessions/{id}/events  Legacy SSE event stream",
        "  POST   /v1/sessions/{id}/cancel  Session compatibility route",
        "  POST   /v1/sessions/{id}/escalation  Session compatibility route",
        "  WS     /v1/ws                    Legacy WebSocket transport",
        "  GET    /health                   Health check",
        "  GET    /logs/                    Log viewer UI",
        "  GET    /logs/api/stream          Log viewer stream (SSE)",
    ]

    console.print()
    console.print(Panel("\n".join(lines), border_style="green"))
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()


class GatewayServer:
    """FastAPI-based gateway server for HTTP/SSE and WebSocket access to Obra sessions.

    Args:
        config: Gateway configuration dict from get_gateway_config().
    """

    def __init__(self, config: dict[str, Any]) -> None:
        merged_config = get_gateway_config()
        merged_config.update(config)
        self._config = merged_config

        # Resolve auth token
        self._token: str = self._config.get("auth_token") or generate_token()

        # Session manager (created early so lifespan can reference it)
        self._session_manager = SessionManager(
            max_sessions=self._config.get("max_sessions", 5),
            escalation_timeout_s=self._config.get("escalation_timeout_s", 300.0),
        )

        # Lifespan with shutdown cleanup
        session_mgr = self._session_manager

        @asynccontextmanager
        async def _lifespan(app: FastAPI):  # type: ignore[type-arg]
            from obra.observability.log_viewer.server import (
                _load_ui_html,
                build_session_index,
                default_hybrid_log_path,
                default_production_log_path,
            )

            app.state.log_hybrid_path = default_hybrid_log_path()
            app.state.log_production_path = default_production_log_path()
            app.state.log_ui_bytes = _load_ui_html()
            app.state.log_session_index = build_session_index(
                app.state.log_hybrid_path,
                app.state.log_production_path,
            )
            app.state.logs_auth_sessions = {}
            app.state.logs_auth_lock = threading.Lock()
            app.state.logs_stream_lock = threading.Lock()
            app.state.logs_stream_clients_total = 0
            app.state.logs_stream_clients_by_ip = {}

            yield
            # Shutdown: cancel all running sessions
            for record in session_mgr.list_sessions():
                if record.status == "running":
                    try:
                        session_mgr.cancel_session(record.session_id)
                    except Exception:
                        logger.warning("Failed to cancel session %s on shutdown", record.session_id)

        # Build FastAPI app (auth added per-router, not globally, so /health stays open)
        self._auth_dep = get_auth_dependency(self._token)
        self._app = FastAPI(
            title="Obra Gateway",
            version=__version__,
            lifespan=_lifespan,
        )

        # CORS middleware
        if self._config.get("enable_cors", False):
            origins = self._config.get("cors_origins", ["*"])
            credentials = self._config.get("cors_allow_credentials", True)
            if credentials and "*" in origins:
                logger.warning(
                    "CORS: credentials=True with wildcard origin is insecure; forcing credentials=False"
                )
                credentials = False
            self._app.add_middleware(
                CORSMiddleware,
                allow_origins=origins,
                allow_credentials=credentials,
                allow_methods=["*"],
                allow_headers=["*"],
            )

        # Attach session manager to app state
        self._app.state.session_manager = self._session_manager
        self._app.state.assistant_repository = None
        self._app.state.gateway_token = self._token
        self._app.state.gateway_config = dict(self._config)
        self._app.state.trusted_proxy_cidrs = list(self._config.get("trusted_proxy_cidrs", []))
        self._app.state.enable_app_rate_limit = bool(self._config.get("enable_app_rate_limit", True))

        if self._app.state.enable_app_rate_limit:
            self._app.state.rest_rate_limiter = TokenBucketRateLimiter(
                rate_per_minute=int(self._config.get("rest_rate_limit_per_minute", 120)),
                burst=int(self._config.get("rest_rate_limit_burst", 60)),
            )
            self._app.state.ws_rate_limiter = TokenBucketRateLimiter(
                rate_per_minute=int(self._config.get("ws_rate_limit_per_minute", 240)),
                burst=int(self._config.get("ws_rate_limit_burst", 120)),
            )
        else:
            self._app.state.rest_rate_limiter = None
            self._app.state.ws_rate_limiter = None

        # Register routes
        self._register_routes()

        @self._app.middleware("http")
        async def _rest_rate_limit_middleware(request: Request, call_next: Any) -> Any:
            limiter = request.app.state.rest_rate_limiter
            if limiter is not None and (
                request.url.path.startswith("/v1/") or request.url.path.startswith("/api/")
            ):
                client_ip = extract_client_ip_from_request(
                    request,
                    request.app.state.trusted_proxy_cidrs,
                )
                if not limiter.allow(client_ip):
                    return JSONResponse(
                        status_code=429,
                        content={"detail": "Rate limit exceeded"},
                    )
            return await call_next(request)

        # Health endpoint (no auth required)
        @self._app.get("/health", include_in_schema=True)
        async def health() -> dict[str, Any]:
            return {"status": "ok"}

        @self._app.get(
            "/v1/health/details",
            include_in_schema=True,
            dependencies=[Depends(self._auth_dep)],
        )
        async def health_details() -> dict[str, Any]:
            running = sum(
                1 for s in self._session_manager.list_sessions() if s.status == "running"
            )
            return {
                "active_sessions": running,
                "version": __version__,
            }

    def _register_routes(self) -> None:
        """Register all route modules."""
        from obra.gateway.routes.assistant import router as assistant_router
        from obra.gateway.routes.artifacts import router as artifacts_router
        from obra.gateway.routes.escalations import router as escalations_router
        from obra.gateway.routes.events import router as events_router
        from obra.gateway.routes.logs import router as logs_router
        from obra.gateway.routes.runners import router as runners_router
        from obra.gateway.routes.sessions import router as sessions_router
        from obra.gateway.routes.template_assets import router as template_assets_router
        from obra.gateway.routes.workflow_events import router as workflow_events_router
        from obra.gateway.routes.workflow_derivations import (
            router as workflow_derivations_router,
        )
        from obra.gateway.routes.knowledge import router as knowledge_router
        from obra.gateway.routes.workflow_replay import router as workflow_replay_router
        from obra.gateway.routes.workflow_runs import router as workflow_runs_router
        from obra.gateway.routes.workflows import router as workflows_router
        from obra.gateway.routes.ws import router as ws_router

        auth = [Depends(self._auth_dep)]
        self._app.include_router(assistant_router, dependencies=auth)
        self._app.include_router(knowledge_router, dependencies=auth)
        self._app.include_router(sessions_router, dependencies=auth)
        self._app.include_router(events_router, dependencies=auth)
        self._app.include_router(escalations_router, dependencies=auth)
        self._app.include_router(workflows_router, dependencies=auth)
        self._app.include_router(artifacts_router, dependencies=auth)
        self._app.include_router(template_assets_router, dependencies=auth)
        self._app.include_router(runners_router, dependencies=auth)
        self._app.include_router(workflow_derivations_router, dependencies=auth)
        self._app.include_router(workflow_runs_router, dependencies=auth)
        self._app.include_router(workflow_events_router)
        self._app.include_router(workflow_replay_router, dependencies=auth)
        self._app.include_router(logs_router)
        # WS router handles its own auth via first-message pattern
        self._app.include_router(ws_router)

    @property
    def app(self) -> FastAPI:
        """The FastAPI application instance."""
        return self._app

    @property
    def token(self) -> str:
        """The auth token (for display/logging)."""
        return self._token

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """Start the gateway server.

        Args:
            host: Override bind address.
            port: Override port number.
        """
        import uvicorn

        bind_host = host or self._config.get("host", "127.0.0.1")
        bind_port = port or self._config.get("port", 18790)
        allow_public_bind = bool(self._config.get("allow_public_bind", False))
        public_bind_tls_terminated = bool(self._config.get("public_bind_tls_terminated", False))

        if not _is_loopback_host(bind_host):
            if not allow_public_bind:
                msg = (
                    f"Refusing non-loopback bind host '{bind_host}'. "
                    "Set gateway.allow_public_bind=true and "
                    "gateway.public_bind_tls_terminated=true only when running behind "
                    "TLS-terminating edge infrastructure."
                )
                raise RuntimeError(msg)
            if not public_bind_tls_terminated:
                msg = (
                    "Refusing public bind without TLS termination acknowledgement. "
                    "Set gateway.public_bind_tls_terminated=true only when a trusted "
                    "reverse proxy/WAF terminates TLS."
                )
                raise RuntimeError(msg)

        _print_startup_banner(bind_host, bind_port, self._token)
        uvicorn.run(
            self._app,
            host=bind_host,
            port=bind_port,
            ws_max_size=int(self._config.get("ws_max_message_bytes", 1_048_576)),
        )
