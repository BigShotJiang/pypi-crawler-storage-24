"""Prompt builders for assistant diagnostics and brainstorming."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any


OBRA_STUDIO_PREAMBLE = """\
You are the Studio Assistant for Obra Workflow Studio.

## About Obra
Obra is a cloud-native AI orchestration platform for autonomous software development
and business process automation. Users design multi-stage workflows in Studio, then
run them. Each workflow is a directed graph of stages; each stage has a template
(the instruction set), inputs, outputs, and quality gates.

## About Workflow Studio
Workflow Studio is the visual authoring environment. Users can:
- Create and edit workflow definitions (stages, connections, templates)
- Run workflows and inspect run results (per-stage outputs, failures)
- Switch between a visual canvas editor and an advanced JSON editor
- Manage workflow revisions (drafts, published versions)

## Your Role
- Help users understand, design, debug, and improve their workflows.
- When a workflow is loaded, reference its actual stages, connections, and templates.
- Give specific, actionable advice — never generic platitudes.
- When proposing changes, name the exact stage, template, or input to modify.
- Speak in clear business language; explain technical concepts when relevant.
- You can see the user's current screen context (route, selected nodes, workflow state).
"""


def _summarize_workflow(
    workflow: dict[str, Any],
    selected_stage_id: str | None = None,
    assistant_config: dict[str, Any] | None = None,
) -> str:
    """Build a concise text summary of the current workflow definition."""
    name = workflow.get("name") or workflow.get("title") or workflow.get("workflow_id", "Untitled")
    summary = workflow.get("summary") or workflow.get("description") or ""
    domain = workflow.get("domain") or workflow.get("business_domain") or ""
    status = workflow.get("status") or "unknown"

    stages = workflow.get("stages") or workflow.get("definition", {}).get("stages") or []
    edges = workflow.get("edges") or workflow.get("definition", {}).get("edges") or []

    lines = [
        f"Workflow: {name}",
        f"Status: {status}",
    ]
    if domain:
        lines.append(f"Domain: {domain}")
    if summary:
        lines.append(f"Summary: {summary}")

    # Build stage_id -> title lookup
    stage_title_map: dict[str, str] = {}
    for stage in stages:
        sid = stage.get("stage_id") or stage.get("id") or "?"
        stage_title_map[sid] = stage.get("title") or stage.get("name") or sid

    if stages:
        lines.append(f"Stages ({len(stages)}):")
        for stage in stages:
            stage_id = stage.get("stage_id") or stage.get("id") or "?"
            title = stage.get("title") or stage.get("name") or stage_id
            template_role = stage.get("template_role") or stage.get("type") or ""
            line = f"  - {title} ({stage_id})"
            if template_role:
                line += f" [{template_role}]"
            if selected_stage_id and stage_id == selected_stage_id:
                line = f"  → {title} ({stage_id})"
                if template_role:
                    line += f" [{template_role}]"
                line += " [SELECTED]"
            lines.append(line)

            # Per-stage enrichment
            purpose = stage.get("purpose") or stage.get("description")
            if purpose:
                lines.append(f"    Purpose: {purpose}")
            depends_on = stage.get("depends_on") or []
            if depends_on:
                dep_titles = [stage_title_map.get(d, d) for d in depends_on]
                lines.append(f"    Depends on: {', '.join(dep_titles)}")
            runner = stage.get("runner")
            if isinstance(runner, dict) and runner.get("runner_id"):
                version = runner.get("version", "?")
                lines.append(f"    Runner: {runner['runner_id']} v{version}")
            quality_loop = stage.get("quality_loop")
            if isinstance(quality_loop, dict):
                enabled = quality_loop.get("enabled", False)
                rules = quality_loop.get("quality_gates") or quality_loop.get("rules") or []
                lines.append(
                    f"    Quality loop: {'enabled' if enabled else 'disabled'}, "
                    f"{len(rules)} rules"
                )

        # Dependency chain fragment
        has_deps = any(
            stage.get("depends_on")
            for stage in stages
        )
        if has_deps:
            lines.append("Dependency chain:")
            rendered = 0
            max_chain = assistant_config.get(
                "stage_detail_max_dependency_chain_stages", 20
            ) if assistant_config is not None else 20
            for stage in stages:
                if rendered >= max_chain:
                    break
                stage_id = stage.get("stage_id") or stage.get("id") or "?"
                title = stage_title_map.get(stage_id, stage_id)
                deps = stage.get("depends_on") or []
                if not deps:
                    lines.append(f"  Start → {title}")
                elif len(deps) == 1:
                    up_title = stage_title_map.get(deps[0], deps[0])
                    lines.append(f"  {up_title} → {title}")
                else:
                    up_titles = [stage_title_map.get(d, d) for d in deps]
                    lines.append(f"  {', '.join(up_titles)} → {title} (join)")
                rendered += 1

    if edges:
        lines.append(f"Connections ({len(edges)}):")
        for edge in edges:
            src = edge.get("source") or edge.get("source_stage_id") or "?"
            tgt = edge.get("target") or edge.get("target_stage_id") or "?"
            lines.append(f"  - {src} → {tgt}")

    return "\n".join(lines)


def _summarize_run(run: dict[str, Any]) -> str:
    """Build a concise summary of the latest run."""
    run_id = run.get("run_id") or run.get("id") or "?"
    run_status = run.get("status") or "unknown"
    failure_stage = run.get("failure_stage_id") or ""
    lines = [
        f"Latest run: {run_id} — status: {run_status}",
    ]
    if failure_stage:
        lines.append(f"Failure stage: {failure_stage}")
    stage_outputs = run.get("stage_outputs")
    if isinstance(stage_outputs, dict) and stage_outputs:
        lines.append("Stage outputs:")
        for stage_id, output in stage_outputs.items():
            text = str(output)[:200]
            lines.append(f"  {stage_id}: {text}")
    return "\n".join(lines)


def _format_relative_time(timestamp_str: str) -> str | None:
    """Format a timestamp as relative time (e.g. '5s ago', '2m ago')."""
    try:
        ts = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        delta = now - ts
        total_seconds = int(delta.total_seconds())
        if total_seconds < 0:
            return None
        if total_seconds < 60:
            return f"{total_seconds}s ago"
        total_minutes = total_seconds // 60
        if total_minutes < 60:
            return f"{total_minutes}m ago"
        total_hours = total_minutes // 60
        return f"{total_hours}h ago"
    except (ValueError, TypeError):
        return None


def _summarize_ui_context(ui_context: dict[str, Any]) -> str:
    """Summarize what the user is currently looking at."""
    parts: list[str] = []
    route = ui_context.get("current_route")
    if route:
        parts.append(f"Current page: {route}")
    selected = ui_context.get("selected_nodes")
    if selected:
        parts.append(f"Selected nodes: {', '.join(str(n) for n in selected)}")

    # Editor state
    editor_surface = ui_context.get("editor_surface")
    editor_mode = ui_context.get("editor_mode")
    if editor_surface:
        parts.append(f"Editor: {editor_surface} mode ({editor_mode})")

    if ui_context.get("dirty"):
        parts.append("Unsaved changes: yes")

    stage_count = ui_context.get("stage_count")
    if stage_count is not None:
        parts.append(f"Stage count: {stage_count}")

    last_change_kind = ui_context.get("last_change_kind")
    if last_change_kind:
        line = f"Last change: {last_change_kind}"
        last_change_summary = ui_context.get("last_change_summary")
        if last_change_summary:
            line += f" — {last_change_summary}"
        parts.append(line)

    # Validation
    if ui_context.get("has_validation_errors"):
        error_count = ui_context.get("validation_error_count", 0)
        parts.append(f"Validation issues ({error_count}):")
        for issue in ui_context.get("validation_issues", []):
            stage_id = issue.get("stage_id", "?")
            message = issue.get("message", "")
            severity = issue.get("severity", "")
            line = f"  - Stage {stage_id}: {message} ({severity})"
            repair = issue.get("repair_action_id")
            if repair is not None:
                line += f" [repair: {repair}]"
            parts.append(line)

    # Conflict / save
    if ui_context.get("has_conflict"):
        parts.append("Conflict detected")

    last_save = ui_context.get("last_save_status")
    if last_save:
        parts.append(f"Last save: {last_save}")

    # Recent interactions
    recent = ui_context.get("recent_interactions")
    if isinstance(recent, list) and recent:
        skipped = max(0, len(recent) - 10)
        if skipped:
            parts.append(f"Recent user activity: (...{skipped} earlier actions)")
        else:
            parts.append("Recent user activity:")
        for event in recent[-10:]:
            action = event.get("action", "?")
            line = f"  - {action}"
            target = event.get("target")
            if target is not None:
                line += f" on {target}"
            detail = event.get("detail")
            if detail is not None:
                line += f" ({detail})"
            ts = event.get("timestamp")
            if ts:
                rel = _format_relative_time(str(ts))
                if rel:
                    line += f" [{rel}]"
            parts.append(line)

    return "\n".join(parts) if parts else ""


def _summarize_graph_structure(ui_context: dict[str, Any]) -> str:
    """Summarize graph topology and available actions from semantic projection."""
    projection = ui_context.get("semantic_projection")
    if not projection or not isinstance(projection, dict):
        return ""

    parts: list[str] = []

    stages = projection.get("stages")
    if isinstance(stages, dict) and stages:
        parts.append("## Graph Structure")
        for stage_id, stage_data in stages.items():
            if not isinstance(stage_data, dict):
                continue
            role = stage_data.get("role", "?")
            status = stage_data.get("status", "?")
            line = f"  - {stage_id} ({role}, {status})"
            upstream = stage_data.get("upstream_ids", [])
            if upstream:
                line += f" <- upstream: {', '.join(str(u) for u in upstream)}"
            downstream = stage_data.get("downstream_ids", [])
            if downstream:
                line += f" -> downstream: {', '.join(str(d) for d in downstream)}"
            parts.append(line)

    actions = projection.get("available_actions")
    if isinstance(actions, list) and actions:
        parts.append("## Available Actions")
        for action in actions:
            if not isinstance(action, dict):
                continue
            action_id = action.get("action_id", "?")
            enabled = action.get("enabled", False)
            line = f"  - {action_id}: {'enabled' if enabled else 'disabled'}"
            reason = action.get("disabled_reason")
            if reason and not enabled:
                line += f" ({reason})"
            parts.append(line)

    interaction = projection.get("interaction_state")
    if isinstance(interaction, dict):
        mode = interaction.get("mode", "idle")
        if mode != "idle":
            line = f"User is currently: {mode}"
            preview = interaction.get("preview_message")
            if preview:
                line += f" — {preview}"
            parts.append(line)

    return "\n".join(parts) if parts else ""


def _build_proactive_guidance(ui_context: dict[str, Any]) -> str:
    """Generate proactive guidance hints based on current context signals."""
    hints: list[str] = []

    if ui_context.get("has_conflict"):
        hints.append(
            "The user has a revision conflict. Prioritize helping them understand "
            "what changed and whether to reapply their draft or reload the newer version."
        )

    if ui_context.get("has_validation_errors"):
        count = ui_context.get("validation_error_count", 0)
        hints.append(
            f"The workflow has {count} validation issue{'s' if count != 1 else ''}. "
            "If the user asks a general question, mention the issues proactively and "
            "offer to help fix them. Reference specific stage IDs and issue messages."
        )

    if ui_context.get("dirty"):
        last_save = ui_context.get("last_save_status")
        if last_save == "error":
            hints.append(
                "The last save attempt failed. If relevant, suggest retrying or "
                "checking for issues before saving again."
            )

    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        interaction = projection.get("interaction_state", {})
        if isinstance(interaction, dict) and interaction.get("mode") == "connect_select_target":
            hints.append(
                "The user is in the middle of connecting two stages. Keep responses "
                "brief and relevant to the connection action."
            )

    return "\n".join(hints) if hints else ""


_STRATEGY_PREAMBLES = {
    "diagnostic": (
        "Identify the root cause by tracing the execution timeline. "
        "Attribute issues to specific stages."
    ),
    "brainstorming": (
        "You are helping design a new workflow. Do not immediately generate a workflow. "
        "Start by asking 3-5 clarifying questions covering the expected input format and "
        "source, desired output and audience, review or approval requirements, intermediate "
        "quality gates, and error handling. Ask one round at a time and only propose a "
        "structured outline after the user confirms understanding."
    ),
    "error_resolution": (
        "Address each validation issue with specific fix instructions. "
        "Order by severity (fail > revise > warn)."
    ),
    "design_guidance": (
        "Ask 3-5 clarifying questions about requirements before suggesting structure."
    ),
    "connection_guidance": (
        "Guide the user through establishing the dependency chain between stages."
    ),
    "readiness_assessment": (
        "Summarize what was just saved and suggest next steps: run, derive, or add quality gates."
    ),
    "contextual": "",
}


def _strategy_preamble(strategies: list[str]) -> str:
    """Return a tone instruction paragraph for the primary strategy."""
    if not strategies:
        return ""
    primary = strategies[0]
    return _STRATEGY_PREAMBLES.get(primary, "")


def _apply_strategy_adjustments(
    budget: "PromptBudget",  # noqa: F821
    strategies: list[str],
    resolved_context: dict[str, Any] | None = None,
) -> None:
    """Modify section priorities based on active strategies."""
    for strategy in strategies:
        if strategy == "diagnostic":
            budget.update_priority("latest_run", 2)
            budget.update_priority("graph_structure", 10)
        elif strategy == "error_resolution":
            budget.update_priority("selected_stage", 2)
        elif strategy == "design_guidance":
            budget.update_priority("knowledge_docs", 3)
        elif strategy == "connection_guidance":
            budget.update_priority("graph_structure", 2)
        elif strategy == "readiness_assessment":
            budget.update_priority("recent_changes", 3)


_OUTCOME_VERBS = {
    "proposal": "proposed",
    "applied": "accepted and applied",
    "rejected": "rejected by user",
    "reverted": "reverted",
    "conflict": "conflicted",
}


def _build_conversation_history(
    turn_history: list[dict[str, Any]],
    assistant_config: dict[str, Any],
) -> str:
    """Summarize prior proposal outcomes for re-proposal suppression."""
    if not turn_history:
        return ""

    max_turns = assistant_config.get("conversation_history_max_proposal_turns", 10)
    preview_chars = assistant_config.get("conversation_history_message_preview_chars", 80)

    # Filter to proposal turns (non-advice outcomes)
    proposals = [
        t for t in turn_history
        if t.get("outcome") and t["outcome"] != "advice"
    ]
    if not proposals:
        return ""

    lines = ["## Conversation History"]

    if len(proposals) > max_turns:
        earlier = proposals[:-max_turns]
        applied_count = sum(1 for t in earlier if t.get("outcome") == "applied")
        rejected_count = sum(1 for t in earlier if t.get("outcome") == "rejected")
        other_count = len(earlier) - applied_count - rejected_count
        parts = []
        if applied_count:
            parts.append(f"{applied_count} applied")
        if rejected_count:
            parts.append(f"{rejected_count} rejected")
        if other_count:
            parts.append(f"{other_count} other")
        lines.append(f"{len(earlier)} earlier proposals were {'/'.join(parts)}")
        proposals = proposals[-max_turns:]

    for i, turn in enumerate(proposals, 1):
        outcome = turn.get("outcome", "?")
        verb = _OUTCOME_VERBS.get(outcome, outcome)
        message = turn.get("message", "")[:preview_chars]
        lines.append(f"Turn {i}: {verb} — {message}")

    lines.append(
        "Do not re-propose changes that were rejected unless the user explicitly asks."
    )

    return "\n".join(lines)


def _build_recent_changes(ui_context: dict[str, Any]) -> str:
    """Render recent save/validate diff summary as human-readable text."""
    diff_summary = ui_context.get("last_diff_summary")
    if not diff_summary or not isinstance(diff_summary, dict):
        return ""

    change_type = diff_summary.get("change_type", "unknown")
    stages_added = diff_summary.get("stages_added", 0)
    stages_removed = diff_summary.get("stages_removed", 0)
    connections_changed = diff_summary.get("connections_changed", 0)

    lines = [
        "## Recent Changes",
        f"Last save: {change_type} change — {stages_added} stages added, "
        f"{stages_removed} removed, {connections_changed} connections changed.",
    ]

    validation_outcome = diff_summary.get("validation_outcome")
    if validation_outcome is not None:
        blocking_count = diff_summary.get("blocking_issue_count", 0)
        lines.append(
            f"Validation: {validation_outcome}, {blocking_count} blocking issues."
        )

    return "\n".join(lines)


def _build_revision_history(revisions: list[dict[str, Any]]) -> str:
    """Render compact revision history for temporal awareness."""
    if not revisions:
        return ""

    lines = ["## Revision History"]
    for rev in revisions:
        rev_id = rev.get("revision_id") or rev.get("id") or "?"
        change_type = rev.get("change_type") or "unknown"
        stage_count = rev.get("stage_count", "?")
        validation = rev.get("validation_outcome") or rev.get("status") or "?"

        timestamp = rev.get("created_at") or rev.get("timestamp") or ""
        rel_time = ""
        if timestamp:
            rel = _format_relative_time(str(timestamp))
            if rel:
                rel_time = f" ({rel})"

        lines.append(
            f"Revision {rev_id}{rel_time}: {change_type}, "
            f"validation {validation}, {stage_count} stages"
        )

    return "\n".join(lines)


def _build_execution_timeline(timeline: list[dict[str, Any]]) -> str:
    """Render run replay events as a narrative timeline."""
    if not timeline:
        return ""

    lines = ["## Execution Timeline"]
    prev_timestamp = None

    for entry in timeline:
        stage_id = entry.get("stage_id") or "?"
        event_type = entry.get("event_type") or "?"
        timestamp = entry.get("timestamp") or ""

        duration_str = ""
        if prev_timestamp and timestamp:
            try:
                ts = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
                prev_ts = datetime.fromisoformat(str(prev_timestamp).replace("Z", "+00:00"))
                delta = ts - prev_ts
                secs = delta.total_seconds()
                if secs >= 0:
                    duration_str = f" (+{secs:.1f}s)"
            except (ValueError, TypeError):
                pass

        lines.append(f"  {stage_id}: {event_type}{duration_str}")
        if timestamp:
            prev_timestamp = timestamp

    return "\n".join(lines)


def _build_knowledge_section(documents: list[dict[str, Any]]) -> str:
    """Render knowledge reference documents for assistant context."""
    if not documents:
        return ""

    lines = ["## Reference Documents"]
    for doc in documents:
        name = doc.get("name", "Untitled")
        scope = doc.get("scope", "org-wide")
        description = doc.get("description", "")
        content = doc.get("content_text", "")

        lines.append(f"### {name} ({scope})")
        if description:
            lines.append(description)
        if content:
            lines.append(content)
        lines.append("---")

    return "\n".join(lines)


def _build_selected_stage_section(
    ui_context: dict[str, Any],
    workflow: dict[str, Any] | None,
    resolved_context: dict[str, Any] | None = None,
) -> str:
    """Build a focused section for the currently selected stage."""
    selected = ui_context.get("selected_nodes")
    if not selected or not workflow:
        return ""

    selected_stage_id = selected[0]
    stages = workflow.get("stages") or workflow.get("definition", {}).get("stages") or []

    # Find the selected stage
    stage = None
    for s in stages:
        sid = s.get("stage_id") or s.get("id") or ""
        if sid == selected_stage_id:
            stage = s
            break

    if stage is None:
        return ""

    title = stage.get("title") or stage.get("name") or selected_stage_id
    lines = [f"## Selected Stage: {title}"]

    # Purpose
    purpose = stage.get("purpose") or stage.get("description")
    if purpose:
        lines.append(f"Purpose: {purpose}")

    # Dependencies — resolve titles
    depends_on = stage.get("depends_on") or []
    if depends_on:
        dep_titles = []
        for dep_id in depends_on:
            dep_title = dep_id
            for s in stages:
                sid = s.get("stage_id") or s.get("id") or ""
                if sid == dep_id:
                    dep_title = s.get("title") or s.get("name") or dep_id
                    break
            dep_titles.append(dep_title)
        lines.append(f"Depends on: {', '.join(dep_titles)}")

    # Runner
    runner = stage.get("runner")
    if isinstance(runner, dict) and runner.get("runner_id"):
        version = runner.get("version", "?")
        lines.append(f"Runner: {runner['runner_id']} v{version}")

    # Quality loop
    quality_loop = stage.get("quality_loop")
    if isinstance(quality_loop, dict):
        enabled = quality_loop.get("enabled", False)
        rules = quality_loop.get("quality_gates") or quality_loop.get("rules") or []
        lines.append(
            f"Quality loop: {'enabled' if enabled else 'disabled'}, {len(rules)} rules"
        )

    # Validation issues for this stage
    validation_issues = ui_context.get("validation_issues", [])
    stage_issues = [
        i for i in validation_issues
        if i.get("stage_id") == selected_stage_id
    ]
    if stage_issues:
        lines.append(f"Validation issues ({len(stage_issues)}):")
        for issue in stage_issues:
            severity = issue.get("severity", "?")
            message = issue.get("message", "")
            lines.append(f"  - {message} ({severity})")

    # Semantic projection info
    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        stage_semantics = projection.get("stages", {}).get(selected_stage_id)
        if isinstance(stage_semantics, dict):
            role = stage_semantics.get("role")
            if role:
                lines.append(f"Semantic role: {role}")
            upstream = stage_semantics.get("upstream_ids", [])
            if upstream:
                lines.append(f"Upstream: {', '.join(str(u) for u in upstream)}")
            downstream = stage_semantics.get("downstream_ids", [])
            if downstream:
                lines.append(f"Downstream: {', '.join(str(d) for d in downstream)}")

    # Template content for selected stage
    if resolved_context:
        template_assets = resolved_context.get("template_assets", {})
        template_content = template_assets.get(selected_stage_id)
        if template_content:
            lines.append(f"### Template Content\n{template_content}")

    return "\n".join(lines)


def build_contextual_system_prompt(
    resolved_context: dict[str, Any],
    assistant_config: dict[str, Any] | None = None,
    strategies: list[str] | None = None,
) -> str:
    """Build a rich system prompt incorporating all available context.

    Uses PromptBudget for token-aware assembly when assistant_config is provided.
    """
    from obra.gateway.workflow_studio.prompt_budget import PromptBudget

    if assistant_config is None:
        assistant_config = {
            "prompt_budget_tokens": 8000,
            "chars_per_token": 4,
            "section_priorities": {
                "preamble": 1, "selected_stage": 2, "workflow_definition": 3,
                "knowledge_docs": 4, "conversation_history": 5, "latest_run": 6,
                "ui_state": 7, "graph_structure": 7, "proactive_guidance": 7,
                "recent_changes": 8, "interaction_log": 9, "revision_history": 10,
            },
        }

    if strategies is None:
        strategies = resolved_context.get("strategies", ["contextual"])

    priorities = assistant_config.get("section_priorities", {})
    budget = PromptBudget(
        total_budget=assistant_config.get("prompt_budget_tokens", 8000),
        chars_per_token=assistant_config.get("chars_per_token", 4),
    )

    # Preamble — always highest priority
    safety_mode = resolved_context.get("safety_mode", "advisory")
    safety_text = (
        "You may only give advice and propose changes — never execute actions directly."
        if safety_mode == "advisory"
        else "You may propose changes with previews for the user to accept."
        if safety_mode == "guided"
        else "You may propose and execute changes with user awareness."
    )
    strategy_text = _strategy_preamble(strategies)
    preamble = OBRA_STUDIO_PREAMBLE.strip()
    if strategy_text:
        preamble += f"\n\n## Strategy Focus\n{strategy_text}"
    preamble += (
        f"\n\n## Safety Mode: {safety_mode}\n"
        f"The user is in '{safety_mode}' mode. {safety_text}"
    )
    budget.add_section("preamble", preamble, priorities.get("preamble", 1))

    # Determine selected stage ID for marking in workflow summary
    workflow = resolved_context.get("workflow")
    ui_context = resolved_context.get("ui_context")
    selected_stage_id: str | None = None
    if ui_context and isinstance(ui_context, dict):
        selected_nodes = ui_context.get("selected_nodes")
        if selected_nodes:
            selected_stage_id = selected_nodes[0]

    # Selected stage section — priority 2 (highest after preamble)
    if ui_context and isinstance(ui_context, dict) and workflow:
        selected_section = _build_selected_stage_section(ui_context, workflow, resolved_context)
        if selected_section:
            budget.add_section(
                "selected_stage",
                selected_section,
                priorities.get("selected_stage", 2),
            )

    # Workflow definition
    if workflow and isinstance(workflow, dict):
        budget.add_section(
            "workflow_definition",
            "## Current Workflow\n" + _summarize_workflow(
                workflow,
                selected_stage_id=selected_stage_id,
                assistant_config=assistant_config,
            ),
            priorities.get("workflow_definition", 3),
        )

    # Latest run
    latest_run = resolved_context.get("latest_run")
    if latest_run and isinstance(latest_run, dict):
        budget.add_section(
            "latest_run",
            "## Latest Run\n" + _summarize_run(latest_run),
            priorities.get("latest_run", 6),
        )

    # UI context sections
    if ui_context and isinstance(ui_context, dict):
        ui_summary = _summarize_ui_context(ui_context)
        if ui_summary:
            budget.add_section(
                "ui_state",
                "## User's Current View\n" + ui_summary,
                priorities.get("ui_state", 7),
            )

        graph_summary = _summarize_graph_structure(ui_context)
        if graph_summary:
            budget.add_section(
                "graph_structure",
                graph_summary,
                priorities.get("graph_structure", 7),
            )

        guidance = _build_proactive_guidance(ui_context)
        if guidance:
            budget.add_section(
                "proactive_guidance",
                "## Contextual Guidance\n" + guidance,
                priorities.get("proactive_guidance", 7),
            )

        # Recent changes (diff summary)
        recent_changes = _build_recent_changes(ui_context)
        if recent_changes:
            budget.add_section(
                "recent_changes",
                recent_changes,
                priorities.get("recent_changes", 8),
            )

    # Conversation history
    turn_history = resolved_context.get("turn_history", [])
    if turn_history:
        history_section = _build_conversation_history(turn_history, assistant_config)
        if history_section:
            budget.add_section(
                "conversation_history",
                history_section,
                priorities.get("conversation_history", 5),
            )

    # Revision history
    revision_history = resolved_context.get("revision_history", [])
    if revision_history:
        rev_section = _build_revision_history(revision_history)
        if rev_section:
            budget.add_section(
                "revision_history",
                rev_section,
                priorities.get("revision_history", 10),
            )

    # Execution timeline (run replay for failed/cancelled runs)
    run_timeline = resolved_context.get("run_timeline", [])
    if run_timeline:
        timeline_section = _build_execution_timeline(run_timeline)
        if timeline_section:
            budget.add_section(
                "execution_timeline",
                timeline_section,
                priorities.get("execution_timeline", 3),
            )

    # Knowledge documents
    knowledge_docs = resolved_context.get("knowledge_documents", [])
    if knowledge_docs:
        knowledge_section = _build_knowledge_section(knowledge_docs)
        if knowledge_section:
            budget.add_section(
                "knowledge_docs",
                knowledge_section,
                priorities.get("knowledge_docs", 4),
            )

    # Apply strategy-based priority adjustments
    _apply_strategy_adjustments(budget, strategies, resolved_context)

    assembled_text, manifest = budget.assemble()
    manifest.strategy = strategies[0] if strategies else "contextual"
    resolved_context["context_manifest"] = manifest
    return assembled_text


def build_diagnostic_system_prompt(
    run_status: str,
    failure_stage_id: str | None,
    stage_outputs: dict[str, str],
) -> str:
    """Build a diagnostic system prompt tailored to run health."""
    mode = "failure diagnosis" if run_status in {"failed", "cancelled"} or failure_stage_id else "quality review"
    failure_line = (
        f"Failure stage: {failure_stage_id}."
        if failure_stage_id
        else "Failure stage: not explicitly identified."
    )
    return (
        OBRA_STUDIO_PREAMBLE
        + f"\n## Diagnostic Mode: {mode}\n"
        f"Run status: {run_status}.\n"
        f"{failure_line}\n"
        "Identify the exact failure point by stage when possible. Attribute issues to the "
        "specific stage, template, input contract, or handoff that caused them. Translate "
        "technical errors into business-language explanations. Propose targeted fixes that name "
        "the specific workflow change to make, such as a template edit, stage reorder, input "
        "correction, or quality-gate adjustment. Never give generic advice.\n"
        f"Stage output summary: {json.dumps(stage_outputs, sort_keys=True)}"
    )


def build_brainstorming_system_prompt() -> str:
    """Build a brainstorming system prompt that forces clarifying questions first."""
    return (
        OBRA_STUDIO_PREAMBLE
        + "\n## Mode: Workflow Design\n"
        "You are helping design a new workflow. Do not immediately generate a workflow. "
        "Start by asking 3-5 clarifying questions covering the expected input format and "
        "source, desired output and audience, review or approval requirements, intermediate "
        "quality gates, and error handling. Ask one round at a time and only propose a "
        "structured outline after the user confirms understanding."
    )
