"""Artifact projections for Workflow Studio Stage A."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from obra.gateway.workflow_studio.data_access import WorkflowStudioRunBundle


def build_artifact_detail(
    bundle: WorkflowStudioRunBundle,
    artifact: dict[str, Any],
) -> dict[str, Any]:
    """Build canonical artifact detail."""
    artifact_id = str(artifact.get("artifact_id") or "")
    references = _coerce_dict_list(artifact.get("references"))
    references.extend(_template_asset_references(bundle, artifact))
    upstream_refs, downstream_refs = _partition_references(artifact_id, references, bundle)
    provenance = {
        "created_at": artifact.get("created_at"),
        "producer_kind": artifact.get("producer_kind"),
        "producer_id": artifact.get("producer_id"),
        "operation_kind": artifact.get("operation_kind"),
        "workflow_execution_id": artifact.get("workflow_execution_id"),
        "attempt_id": artifact.get("attempt_id"),
        "trace_id": artifact.get("trace_id"),
        "prompt_id": artifact.get("prompt_id"),
        "prompt_version": artifact.get("prompt_version"),
    }
    return {
        "resource_type": "artifact",
        "artifact_id": artifact_id,
        "artifact_type": artifact.get("artifact_type"),
        "version": artifact.get("version"),
        "domain_id": artifact.get("domain_id"),
        "title": artifact.get("title"),
        "description": artifact.get("description"),
        "lifecycle": artifact.get("lifecycle"),
        "editability": artifact.get("editability"),
        "runtime_metadata": dict(artifact.get("runtime_metadata") or {}),
        "metadata": dict(artifact.get("metadata") or {}),
        "references": references,
        "upstream_refs": upstream_refs,
        "downstream_refs": downstream_refs,
        "provenance": provenance,
        "producer_run_id": bundle.record.workflow_run_id,
    }


def build_artifact_summary(artifact: dict[str, Any]) -> dict[str, Any]:
    """Build list-friendly artifact summary."""
    return {
        "artifact_id": artifact.get("artifact_id"),
        "artifact_type": artifact.get("artifact_type"),
        "version": artifact.get("version"),
        "domain_id": artifact.get("domain_id"),
        "title": artifact.get("title"),
        "lifecycle": artifact.get("lifecycle"),
    }


def resolve_artifact_content(
    bundle: WorkflowStudioRunBundle,
    artifact_id: str,
) -> str | None:
    """Resolve artifact content from the producing stage's materialized asset path."""
    artifact = next(
        (
            candidate
            for candidate in bundle.workflow_artifacts
            if str(candidate.get("artifact_id") or "") == artifact_id
        ),
        None,
    )
    if artifact is None:
        return None

    runtime_metadata = (
        artifact.get("runtime_metadata")
        if isinstance(artifact.get("runtime_metadata"), dict)
        else {}
    )
    stage_name = str(runtime_metadata.get("stage_name") or "").strip()
    if not stage_name:
        return None

    stage = next(
        (
            candidate
            for candidate in bundle.pipeline_stages
            if str(candidate.get("stage_name") or candidate.get("trigger") or "").strip() == stage_name
        ),
        None,
    )
    if stage is None:
        return None

    binding = _select_artifact_binding(stage, artifact_id)
    if binding is None:
        return None

    materialized_path = str(binding.get("materialized_path") or "").strip()
    if not materialized_path:
        return None

    relative_path = Path(materialized_path)
    if relative_path.is_absolute() or ".." in relative_path.parts:
        return None

    working_dir_raw = str(bundle.record.request_context.get("working_dir") or "").strip()
    if not working_dir_raw:
        return None

    working_dir = Path(working_dir_raw).expanduser().resolve(strict=False)
    artifact_path = (working_dir / relative_path).resolve(strict=False)
    if not artifact_path.is_relative_to(working_dir):
        return None

    try:
        return artifact_path.read_text(encoding="utf-8")
    except (FileNotFoundError, IsADirectoryError, OSError, UnicodeDecodeError):
        return None


def _partition_references(
    artifact_id: str,
    references: list[dict[str, Any]],
    bundle: WorkflowStudioRunBundle,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    upstream_refs = list(references)
    downstream_refs: list[dict[str, Any]] = []
    for candidate in bundle.workflow_artifacts:
        for reference in _coerce_dict_list(candidate.get("references")):
            if str(reference.get("target_artifact_id") or "") == artifact_id:
                downstream_refs.append(
                    {
                        "source_artifact_id": candidate.get("artifact_id"),
                        "source_artifact_type": candidate.get("artifact_type"),
                        **reference,
                    }
                )
    return upstream_refs, downstream_refs


def _template_asset_references(
    bundle: WorkflowStudioRunBundle,
    artifact: dict[str, Any],
) -> list[dict[str, Any]]:
    producer_kind = str(artifact.get("producer_kind") or "").strip().lower()
    artifact_type = str(artifact.get("artifact_type") or "").strip().lower()
    if producer_kind != "runtime" and artifact_type not in {"workflow_execution", "stage_output"}:
        return []

    existing_pairs = {
        (
            str(reference.get("target_artifact_type") or ""),
            str(reference.get("target_artifact_id") or ""),
            str(reference.get("relationship_type") or ""),
        )
        for reference in _coerce_dict_list(artifact.get("references"))
    }

    template_refs: list[dict[str, Any]] = []
    for stage in bundle.pipeline_stages:
        stage_name = str(stage.get("stage_name") or stage.get("trigger") or "")
        stage_execution_id = str(stage.get("stage_execution_id") or "")
        for binding in _coerce_dict_list(stage.get("resolved_stage_asset_bindings")):
            artifact_ref = (
                binding.get("artifact_ref")
                if isinstance(binding.get("artifact_ref"), dict)
                else {}
            )
            asset_id = str(
                artifact_ref.get("target_artifact_id")
                or binding.get("materialized_path")
                or ""
            )
            if not asset_id:
                continue
            identity = ("stage_asset", asset_id, "uses_template_asset")
            if identity in existing_pairs:
                continue
            existing_pairs.add(identity)
            template_refs.append(
                {
                    "target_artifact_type": "stage_asset",
                    "target_artifact_id": asset_id,
                    "target_version_selector": artifact_ref.get("target_version_selector"),
                    "relationship_type": "uses_template_asset",
                    "metadata": {
                        "source": "resolved_stage_asset_binding",
                        "stage_name": stage_name,
                        "stage_execution_id": stage_execution_id,
                        "binding_role": binding.get("binding_role"),
                        "binding_scope": binding.get("binding_scope"),
                        "materialized_path": binding.get("materialized_path"),
                        **dict(artifact_ref.get("metadata") or {}),
                    },
                }
            )
    return template_refs


def _coerce_dict_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]


def _select_artifact_binding(
    stage: dict[str, Any],
    artifact_id: str,
) -> dict[str, Any] | None:
    bindings = _coerce_dict_list(stage.get("resolved_stage_asset_bindings"))
    for binding in bindings:
        artifact_ref = binding.get("artifact_ref") if isinstance(binding.get("artifact_ref"), dict) else {}
        if str(artifact_ref.get("target_artifact_id") or "").strip() == artifact_id:
            return binding
    return next(
        (
            binding
            for binding in bindings
            if str(binding.get("materialized_path") or "").strip()
        ),
        None,
    )
