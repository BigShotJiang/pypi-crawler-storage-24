"""Assistant LLM provider resolution helpers."""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable


def _build_stub_response(user_message: str, resolved_context: dict[str, Any] | None = None) -> str:
    workflow = (resolved_context or {}).get("workflow")
    latest_run = (resolved_context or {}).get("latest_run")
    if latest_run and latest_run.get("status") in {"failed", "cancelled"}:
        stage_id = latest_run.get("failure_stage_id") or "the failing stage"
        return (
            f"I traced the failure to {stage_id}. Start by reviewing that stage's template and "
            f"the input handed into it, then retry with a narrower payload.\n\n"
            f"Original request: {user_message}"
        )
    if workflow and isinstance(workflow, dict):
        workflow_name = workflow.get("name") or workflow.get("title") or workflow.get("workflow_id")
        return (
            f"I've reviewed {workflow_name}. Based on your request, I recommend validating the "
            f"stage handoffs, runner inputs, and quality gates before applying changes."
        )
    return (
        "I can help design the workflow, but I need a little more context about the inputs, "
        "outputs, and review criteria before suggesting concrete structure."
    )


async def call_assistant_llm(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    model_id: str | None = None,
    **kwargs: Any,
) -> str:
    """Call the configured assistant LLM provider or fall back to a deterministic stub."""
    llm_provider = provider or (
        getattr(app_state, "assistant_llm_provider", None) if app_state is not None else None
    )
    if llm_provider is None:
        return _build_stub_response(user_message, resolved_context=resolved_context)

    call_kwargs: dict[str, Any] = {
        "system_prompt": system_prompt,
        "user_message": user_message,
        "resolved_context": resolved_context,
        **kwargs,
    }
    if model_id is not None:
        call_kwargs["model_id"] = model_id

    result = llm_provider(**call_kwargs)
    if inspect.isawaitable(result):
        result = await result
    return str(result).strip()


def call_assistant_llm_sync(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    **kwargs: Any,
) -> str:
    """Synchronous bridge for broker handlers executed from a worker thread."""
    return asyncio.run(
        call_assistant_llm(
            system_prompt,
            user_message,
            app_state=app_state,
            provider=provider,
            resolved_context=resolved_context,
            **kwargs,
        )
    )
