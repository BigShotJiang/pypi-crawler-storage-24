"""Context assembler for assistant conversation turns."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from obra.gateway.workflow_studio.repository import WorkflowStudioRepository


class UIState(BaseModel):
    """Typed UI state fields matching client EditorContext interface."""

    editor_surface: str | None = None
    editor_mode: str | None = None
    dirty: bool = False
    stage_count: int = 0
    last_change_kind: str | None = None
    last_change_summary: str | None = None
    has_validation_errors: bool = False
    validation_error_count: int = 0
    validation_error_stages: list[str] = []
    validation_issues: list[dict[str, Any]] = []
    has_conflict: bool = False
    last_save_status: str | None = None
    semantic_projection: dict[str, Any] | None = None
    recent_interactions: list[dict[str, Any]] | None = None
    last_diff_summary: dict[str, Any] | None = None
    screenshot: str | None = None


class ContextAttachment(BaseModel):
    """Client-supplied context for a conversation turn."""

    project_id: str
    safety_mode: str = "advisory"
    working_dir: str | None = None
    workflow_id: str | None = None
    revision_id: str | None = None
    selected_nodes: list[str] | None = None
    current_route: str | None = None
    ui_state: dict[str, Any] | None = None

    def resolve_ui_state(self) -> UIState:
        """Parse ui_state dict into typed UIState with defaults."""
        if self.ui_state is None:
            return UIState()
        return UIState.model_validate(self.ui_state)


class AssistantContextAssembler:
    """Resolves Studio context for an assistant conversation turn.

    Reads from the existing WorkflowStudioRepository to populate workflow
    and run context alongside client-supplied UI state.
    """

    def __init__(
        self,
        repository: WorkflowStudioRepository,
        project_root: Any | None = None,
    ) -> None:
        self._repository = repository
        self._project_root = project_root

    def resolve(self, context: ContextAttachment) -> dict[str, Any]:
        """Resolve full context from a client-supplied attachment.

        Returns a dict with keys: project_id, workflow, latest_run,
        ui_context, safety_mode.
        """
        resolved_workflow: dict[str, Any] | None = None
        resolved_latest_run: dict[str, Any] | None = None

        if context.workflow_id is not None:
            try:
                resolved_workflow = self._repository.get_workflow(context.workflow_id)
            except Exception:
                resolved_workflow = None

            if resolved_workflow is not None:
                try:
                    all_runs = self._repository.list_runs()
                    matching_runs = [
                        r for r in all_runs
                        if r.get("workflow_id") == context.workflow_id
                    ]
                    if matching_runs:
                        resolved_latest_run = matching_runs[0]
                except Exception:
                    resolved_latest_run = None

        ui_context: dict[str, Any] = {}
        if context.selected_nodes is not None:
            ui_context["selected_nodes"] = context.selected_nodes
        if context.current_route is not None:
            ui_context["current_route"] = context.current_route
        if context.ui_state is not None:
            ui_context.update(context.ui_state)

        # Revision history
        revision_history: list[dict[str, Any]] = []
        if context.workflow_id is not None and resolved_workflow is not None:
            try:
                from obra.config.loaders import get_gateway_assistant_config
                ac = get_gateway_assistant_config()
                max_revisions = ac.get("revision_history_max_revisions", 5)
                revisions = self._repository.list_workflow_revisions(context.workflow_id)
                revision_history = revisions[-max_revisions:]
            except Exception:
                revision_history = []

        # Run timeline (for failed/cancelled runs)
        run_timeline: list[dict[str, Any]] = []
        if resolved_latest_run and isinstance(resolved_latest_run, dict):
            run_status = str(resolved_latest_run.get("status") or "")
            if run_status in {"failed", "cancelled"}:
                run_id = resolved_latest_run.get("run_id") or resolved_latest_run.get("id")
                if run_id:
                    try:
                        from obra.config.loaders import get_gateway_assistant_config as _get_ac
                        _ac = _get_ac()
                        max_events = _ac.get("run_timeline_max_events", 10)
                        replay = self._repository.get_run_replay(run_id)
                        if replay and isinstance(replay, dict):
                            run_timeline = (replay.get("entries") or [])[-max_events:]
                    except Exception:
                        run_timeline = []

        # Template assets
        template_assets: dict[str, str] = {}
        if resolved_workflow is not None:
            stages = (
                resolved_workflow.get("stages")
                or resolved_workflow.get("definition", {}).get("stages")
                or []
            )
            for stage in stages:
                bindings = stage.get("template_asset_bindings") or []
                stage_id = stage.get("stage_id") or stage.get("id") or ""
                for binding in bindings:
                    asset_id = binding.get("asset_id") or binding.get("template_id")
                    if asset_id:
                        try:
                            content = self._repository.get_template_asset(asset_id)
                            if content:
                                template_assets[stage_id] = content
                        except Exception:
                            pass

        # Knowledge documents
        knowledge_documents: list[dict[str, Any]] = []
        if self._project_root is not None:
            try:
                from obra.config.loaders import get_gateway_assistant_config as _get_kac
                from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository

                kac = _get_kac()
                krepo = KnowledgeRepository(
                    self._project_root,
                    max_document_bytes=kac["knowledge_max_document_bytes"],
                    max_total_bytes=kac["knowledge_max_total_bytes"],
                )
                # Org-wide docs
                for doc in krepo.list_documents(scope="org-wide"):
                    try:
                        _, content_text = krepo.get_document(doc["id"])
                        knowledge_documents.append({
                            "name": doc.get("name", ""),
                            "scope": doc.get("scope", "org-wide"),
                            "description": doc.get("description"),
                            "content_text": content_text,
                        })
                    except Exception:
                        pass
                # Workflow-specific docs
                if context.workflow_id:
                    for doc in krepo.list_documents(scope="workflow", workflow_id=context.workflow_id):
                        try:
                            _, content_text = krepo.get_document(doc["id"])
                            knowledge_documents.append({
                                "name": doc.get("name", ""),
                                "scope": doc.get("scope", "workflow"),
                                "description": doc.get("description"),
                                "content_text": content_text,
                            })
                        except Exception:
                            pass
            except Exception:
                knowledge_documents = []

        return {
            "project_id": context.project_id,
            "working_dir": context.working_dir,
            "workflow": resolved_workflow,
            "latest_run": resolved_latest_run,
            "ui_context": ui_context,
            "safety_mode": context.safety_mode,
            "revision_history": revision_history,
            "run_timeline": run_timeline,
            "template_assets": template_assets,
            "knowledge_documents": knowledge_documents,
        }
