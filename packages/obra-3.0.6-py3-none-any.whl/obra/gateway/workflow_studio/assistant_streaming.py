"""Streamed assistant response generator (SSE)."""

from __future__ import annotations

import asyncio
import json
from dataclasses import asdict
from typing import Any, AsyncIterator

from obra.gateway.workflow_studio.assistant_llm import call_assistant_llm
from obra.gateway.workflow_studio.assistant_repository import (
    AssistantRepository,
    AssistantThread,
    AssistantTurn,
)


def _sse(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


async def stream_assistant_response(
    thread: AssistantThread,
    user_turn: AssistantTurn,
    resolved_context: dict[str, Any],
    repository: AssistantRepository,
    *,
    system_prompt: str | None = None,
    app_state: Any | None = None,
) -> AsyncIterator[str]:
    """Yield SSE events for a streamed assistant response."""
    turn_id = user_turn.turn_id

    try:
        yield _sse("status", {"phase": "resolving_context", "turn_id": turn_id})

        strategy = "contextual"
        if isinstance(resolved_context.get("strategies"), list) and resolved_context["strategies"]:
            strategy = resolved_context["strategies"][0]

        # Emit context manifest for transparency
        manifest = resolved_context.get("context_manifest")
        if manifest is not None:
            manifest_dict = manifest.to_dict() if hasattr(manifest, "to_dict") else manifest
            yield _sse("context_manifest", manifest_dict)

        yield _sse("status", {"phase": "generating", "turn_id": turn_id, "strategy": strategy})

        model_id = resolved_context.get("model_id")
        full_message = await call_assistant_llm(
            system_prompt or "You are the Studio Assistant for Obra Workflow Studio.",
            user_turn.message,
            app_state=app_state,
            resolved_context=resolved_context,
            model_id=model_id,
        )
        if not full_message.strip():
            raise RuntimeError("assistant returned empty content")

        chunk_size = 40
        for i in range(0, len(full_message), chunk_size):
            chunk = full_message[i : i + chunk_size]
            yield _sse("token", {"text": chunk})
            await asyncio.sleep(0)

        assistant_turn = repository.append_turn(
            thread.thread_id,
            role="assistant",
            message=full_message,
            outcome="advice",
        )

        yield _sse("done", {"turn": asdict(assistant_turn)})

    except Exception as exc:
        yield _sse(
            "error",
            {
                "error": "generation_failed",
                "detail": str(exc),
                "turn_id": turn_id,
            },
        )
