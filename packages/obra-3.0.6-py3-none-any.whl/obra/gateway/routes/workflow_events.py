"""Canonical Workflow Studio event-stream routes."""

from __future__ import annotations

import asyncio
import contextlib
import json
from typing import Any, AsyncIterator

from fastapi import APIRouter, HTTPException, Query, Request, WebSocket, WebSocketDisconnect, status
from fastapi.security import HTTPAuthorizationCredentials
from starlette.responses import StreamingResponse
from websockets.exceptions import ConnectionClosed

from obra.gateway.auth import verify_token
from obra.gateway.security.client_ip import extract_client_ip_from_websocket
from obra.gateway.workflow_studio.events import build_event_envelope

router = APIRouter(tags=["workflow-studio"])


def _event_stream_transport_state(app: Any) -> dict[str, Any] | None:
    state = getattr(app.state, "workflow_event_stream_transport_state", None)
    return state if isinstance(state, dict) else None


def _register_event_stream_socket(ws: WebSocket) -> None:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return
    connections = state.get("connections")
    if isinstance(connections, set):
        connections.add(ws)


def _unregister_event_stream_socket(ws: WebSocket) -> None:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return
    connections = state.get("connections")
    if isinstance(connections, set):
        connections.discard(ws)


def _event_stream_transport_enabled(ws: WebSocket) -> bool:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return True
    return bool(state.get("enabled", True))


def _event_stream_send_delay_s(ws: WebSocket) -> float:
    state = _event_stream_transport_state(ws.app)
    if state is None:
        return 0.0
    delay_ms = max(0, int(state.get("ws_send_delay_ms", 0) or 0))
    return delay_ms / 1000


def _ensure_http_auth(request: Request) -> None:
    auth_header = request.headers.get("Authorization", "")
    scheme, _, credentials = auth_header.partition(" ")
    creds = HTTPAuthorizationCredentials(
        scheme=scheme or "Bearer",
        credentials=credentials,
    )
    expected_token = request.app.state.gateway_token
    if not verify_token(creds, expected_token):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication failed")


async def _event_generator(
    resource_id: str,
    request: Request,
    filter_names: set[str] | None = None,
    after_sequence: int | None = None,
    *,
    resource_type: str = "workflow_run",
) -> AsyncIterator[str]:
    session_manager = request.app.state.session_manager
    try:
        if resource_type == "workflow_derivation":
            record = session_manager.get_session_by_derivation_id(resource_id)
            event_bus = record.event_bus
        elif resource_type == "workflow":
            record = None
            event_bus = session_manager.get_workflow_event_bus(resource_id)
        else:
            record = session_manager.get_session(resource_id)
            event_bus = record.event_bus
    except Exception as exc:
        detail = (
            "Workflow derivation not found"
            if resource_type == "workflow_derivation"
            else ("Workflow not found" if resource_type == "workflow" else "Workflow run not found")
        )
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=detail) from exc

    async for event in event_bus.subscribe(
        after_sequence=after_sequence,
    ):
        payload = build_event_envelope(
            event,
            run_id=(record.workflow_run_id if record is not None else resource_id),
            record=record,
            resource_type=resource_type,
        )
        if filter_names and str(payload.get("event_name")) not in filter_names:
            continue
        yield f"data: {json.dumps(payload)}\n\n"

    yield "data: [DONE]\n\n"


@router.get("/api/workflow-runs/{run_id}/events")
async def stream_workflow_run_events(
    run_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    _ensure_http_auth(request)
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    return StreamingResponse(
        _event_generator(run_id, request, filter_names, after_sequence),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.get("/api/workflow-derivations/{derivation_id}/events")
async def stream_workflow_derivation_events(
    derivation_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    _ensure_http_auth(request)
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    return StreamingResponse(
        _event_generator(
            derivation_id,
            request,
            filter_names,
            after_sequence,
            resource_type="workflow_derivation",
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.get("/api/workflows/{workflow_id}/events")
async def stream_workflow_events(
    workflow_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event names"),
    after_sequence: int | None = Query(default=None, ge=0),
) -> StreamingResponse:
    _ensure_http_auth(request)
    filter_names = {value.strip() for value in filter.split(",")} if filter else None
    return StreamingResponse(
        _event_generator(
            workflow_id,
            request,
            filter_names,
            after_sequence,
            resource_type="workflow",
        ),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@router.websocket("/api/events/stream")
async def workflow_event_stream(ws: WebSocket) -> None:
    await ws.accept()
    _register_event_stream_socket(ws)
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    trusted_proxy_cidrs = list(gateway_config.get("trusted_proxy_cidrs", []))
    client_ip = extract_client_ip_from_websocket(ws, trusted_proxy_cidrs)
    ws.scope["gateway_client_ip"] = client_ip
    subscription_tasks: dict[str, asyncio.Task[None]] = {}

    try:
        if not _event_stream_transport_enabled(ws):
            await ws.close(code=1013, reason="Workflow event stream temporarily unavailable")
            return

        auth_raw = await ws.receive_text()
        auth_data = json.loads(auth_raw)
        if auth_data.get("type") != "auth" or "token" not in auth_data:
            await ws.send_text(json.dumps({"type": "error", "detail": "Authentication required"}))
            await ws.close(code=4001)
            return

        from fastapi.security import HTTPAuthorizationCredentials

        expected_token = ws.app.state.gateway_token
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials=auth_data["token"],
        )
        if not verify_token(credentials, expected_token):
            await ws.send_text(json.dumps({"type": "error", "detail": "Authentication failed"}))
            await ws.close(code=4001)
            return

        send_lock = asyncio.Lock()

        async def _replace_subscription(subscription: dict[str, Any]) -> None:
            key = _subscription_key(subscription)
            existing = subscription_tasks.pop(key, None)
            if existing is not None:
                await _cancel_subscription(existing)

            session_manager = ws.app.state.session_manager
            record, event_bus, run_ref = _resolve_event_bus(
                session_manager,
                subscription["resource_type"],
                subscription["resource_id"],
            )
            subscription_tasks[key] = asyncio.create_task(
                _stream_subscription(
                    ws,
                    subscription=subscription,
                    send_lock=send_lock,
                    event_bus=event_bus,
                    record=record,
                    run_ref=run_ref,
                )
            )

        async def _remove_subscription(subscription: dict[str, Any]) -> None:
            task = subscription_tasks.pop(_subscription_key(subscription), None)
            if task is not None:
                await _cancel_subscription(task)

        subscribe_raw = await ws.receive_text()
        control_type, subscriptions = _parse_subscription_message(
            subscribe_raw,
            query_params=ws.query_params,
        )
        if control_type != "subscribe" or not subscriptions:
            await ws.send_text(
                json.dumps(
                    {
                        "type": "error",
                        "detail": "run_id, derivation_id, or workflow_id is required",
                    }
                )
            )
            await ws.close(code=4400)
            return

        try:
            for subscription in subscriptions:
                await _replace_subscription(subscription)
        except Exception as exc:
            await ws.send_text(json.dumps({"type": "error", "detail": str(exc)}))
            await ws.close(code=4400)
            return

        if _message_declares_type(subscribe_raw):
            await _send_control_message(
                ws,
                send_lock,
                {
                    "type": "subscribed",
                    "subscriptions": [_subscription_payload(item) for item in subscriptions],
                },
            )

        while True:
            control_raw = await ws.receive_text()
            control_type, subscriptions = _parse_subscription_message(control_raw)
            if control_type == "ping":
                await _send_control_message(ws, send_lock, {"type": "pong"})
                continue
            if not subscriptions:
                await _send_control_message(
                    ws,
                    send_lock,
                    {"type": "error", "detail": "No subscriptions supplied"},
                )
                continue
            try:
                if control_type == "subscribe":
                    for subscription in subscriptions:
                        await _replace_subscription(subscription)
                    await _send_control_message(
                        ws,
                        send_lock,
                        {
                            "type": "subscribed",
                            "subscriptions": [
                                _subscription_payload(item) for item in subscriptions
                            ],
                        },
                    )
                elif control_type == "unsubscribe":
                    for subscription in subscriptions:
                        await _remove_subscription(subscription)
                    await _send_control_message(
                        ws,
                        send_lock,
                        {
                            "type": "unsubscribed",
                            "subscriptions": [
                                _subscription_payload(item) for item in subscriptions
                            ],
                        },
                    )
            except Exception as exc:
                await _send_control_message(
                    ws,
                    send_lock,
                    {"type": "error", "detail": str(exc)},
                )
    except (WebSocketDisconnect, ConnectionClosed):
        pass
    finally:
        _unregister_event_stream_socket(ws)
        for task in subscription_tasks.values():
            await _cancel_subscription(task)


def _message_declares_type(raw_message: str) -> bool:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError:
        return False
    return isinstance(payload, dict) and isinstance(payload.get("type"), str)


def _parse_subscription_message(
    raw_message: str,
    *,
    query_params: Any | None = None,
) -> tuple[str, list[dict[str, Any]]]:
    try:
        payload = json.loads(raw_message)
    except json.JSONDecodeError as exc:
        raise ValueError("Invalid event-stream control message") from exc

    if not isinstance(payload, dict):
        raise ValueError("Control message must be a JSON object")

    control_type = str(payload.get("type") or "subscribe").strip().lower()
    if control_type == "ping":
        return "ping", []
    if control_type not in {"subscribe", "unsubscribe"}:
        raise ValueError(f"Unsupported control message type: {control_type}")

    subscriptions = _normalize_subscriptions(payload, query_params=query_params)
    return control_type, subscriptions


def _normalize_subscriptions(
    payload: dict[str, Any],
    *,
    query_params: Any | None = None,
) -> list[dict[str, Any]]:
    if isinstance(payload.get("subscriptions"), list):
        subscriptions = [
            _parse_subscription_payload(item)
            for item in payload["subscriptions"]
            if isinstance(item, dict)
        ]
    else:
        subscriptions = [_parse_subscription_payload(payload, query_params=query_params)]
    return [item for item in subscriptions if item is not None]


def _parse_subscription_payload(
    payload: dict[str, Any],
    *,
    query_params: Any | None = None,
) -> dict[str, Any] | None:
    run_id = str(payload.get("run_id") or _query_value(query_params, "run_id") or "").strip()
    derivation_id = str(
        payload.get("derivation_id") or _query_value(query_params, "derivation_id") or ""
    ).strip()
    workflow_id = str(
        payload.get("workflow_id") or _query_value(query_params, "workflow_id") or ""
    ).strip()
    provided = [
        ("workflow_run", run_id),
        ("workflow_derivation", derivation_id),
        ("workflow", workflow_id),
    ]
    selected = [(resource_type, resource_id) for resource_type, resource_id in provided if resource_id]
    if not selected:
        return None
    if len(selected) > 1:
        raise ValueError("Exactly one of run_id, derivation_id, or workflow_id is allowed")

    resource_type, resource_id = selected[0]
    return {
        "resource_type": resource_type,
        "resource_id": resource_id,
        "after_sequence": _normalize_after_sequence(payload.get("after_sequence")),
        "filter_names": _normalize_filter_names(payload.get("filter")),
    }


def _normalize_after_sequence(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip():
        return int(value)
    return None


def _normalize_filter_names(value: Any) -> set[str] | None:
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",")]
    elif isinstance(value, list):
        items = [str(item).strip() for item in value]
    else:
        return None
    normalized = {item for item in items if item}
    return normalized or None


def _query_value(query_params: Any | None, key: str) -> str | None:
    if query_params is None:
        return None
    getter = getattr(query_params, "get", None)
    if callable(getter):
        value = getter(key)
        if value is not None:
            return str(value)
    return None


def _resolve_event_bus(
    session_manager: Any,
    resource_type: str,
    resource_id: str,
) -> tuple[Any | None, Any, str]:
    if resource_type == "workflow_derivation":
        record = session_manager.get_session_by_derivation_id(resource_id)
        return record, record.event_bus, record.workflow_run_id
    if resource_type == "workflow":
        return None, session_manager.get_workflow_event_bus(resource_id), resource_id
    record = session_manager.get_session(resource_id)
    return record, record.event_bus, record.workflow_run_id


async def _stream_subscription(
    ws: WebSocket,
    *,
    subscription: dict[str, Any],
    send_lock: asyncio.Lock,
    event_bus: Any,
    record: Any,
    run_ref: str,
) -> None:
    async for event in event_bus.subscribe(after_sequence=subscription.get("after_sequence")):
        payload = build_event_envelope(
            event,
            run_id=run_ref,
            record=record,
            resource_type=subscription["resource_type"],
        )
        filter_names = subscription.get("filter_names")
        if filter_names and str(payload.get("event_name")) not in filter_names:
            continue
        payload.update(
            {
                "stream_resource_type": subscription["resource_type"],
                "stream_resource_id": subscription["resource_id"],
                "subscription_id": _subscription_key(subscription),
            }
        )
        await _send_control_message(ws, send_lock, payload)


def _subscription_key(subscription: dict[str, Any]) -> str:
    return f"{subscription['resource_type']}:{subscription['resource_id']}"


def _subscription_payload(subscription: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "subscription_id": _subscription_key(subscription),
        "resource_type": subscription["resource_type"],
        "resource_id": subscription["resource_id"],
    }
    if subscription.get("after_sequence") is not None:
        payload["after_sequence"] = subscription["after_sequence"]
    if subscription.get("filter_names"):
        payload["filter"] = sorted(subscription["filter_names"])
    return payload


async def _send_control_message(
    ws: WebSocket,
    send_lock: asyncio.Lock,
    payload: dict[str, Any],
) -> None:
    async with send_lock:
        delay_s = _event_stream_send_delay_s(ws)
        if delay_s > 0:
            await asyncio.sleep(delay_s)
        await ws.send_text(json.dumps(payload))


async def _cancel_subscription(task: asyncio.Task[None]) -> None:
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task
