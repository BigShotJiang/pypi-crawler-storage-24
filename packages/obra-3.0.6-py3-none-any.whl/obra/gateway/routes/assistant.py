"""Assistant thread management routes."""

from __future__ import annotations

import asyncio
from dataclasses import asdict
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from obra.gateway.session_manager import _validate_working_dir
from obra.gateway.workflow_studio.assistant_context import (
    AssistantContextAssembler,
    ContextAttachment,
)
from obra.gateway.workflow_studio.assistant_llm import call_assistant_llm_sync
from obra.gateway.workflow_studio.assistant_prompts import (
    build_brainstorming_system_prompt,
    build_contextual_system_prompt,
    build_diagnostic_system_prompt,
)
from obra.gateway.workflow_studio.assistant_repository import AssistantRepository
from obra.gateway.workflow_studio.assistant_streaming import stream_assistant_response
from obra.gateway.workflow_studio.file_checkpoint import AlreadyRevertedError, restore_checkpoint
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.safety import enforce_no_actions, enforce_safety_mode
from obra.gateway.workflow_studio.workflow_actions import WorkflowActionService

router = APIRouter(prefix="/api/assistant", tags=["assistant"])


class CreateThreadRequest(BaseModel):
    """Create a new assistant thread."""

    project_id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1, max_length=200)


class UpdateThreadRequest(BaseModel):
    """Update mutable thread fields."""

    name: str | None = Field(default=None, max_length=200)
    archived: bool | None = None
    safety_mode: str | None = None


class SubmitTurnRequest(BaseModel):
    """Submit a user turn to the assistant."""

    message: str = Field(..., min_length=1, max_length=50000)
    context: ContextAttachment
    model_id: str | None = None


class ExecuteActionRequest(BaseModel):
    """Execute an assistant action."""

    thread_id: str = Field(..., min_length=1)
    turn_id: str = Field(..., min_length=1)
    safety_mode: str = Field(..., min_length=1)
    action_inputs: dict[str, Any] = Field(default_factory=dict)
    workflow_id: str | None = None
    expected_revision_id: str | None = None
    working_dir: str | None = None


class RevertActionRequest(BaseModel):
    """Revert a checkpoint-backed assistant file action."""

    safety_mode: str = Field(..., min_length=1)
    working_dir: str | None = None


def _get_action_broker(request: Request):
    """Build an ActionBroker from the current request context."""
    from obra.gateway.assistant.action_broker import ActionBroker
    from obra.gateway.assistant.audit import ActionAuditStore

    repository = WorkflowStudioRepository.from_request(request)
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    action_service = WorkflowActionService(client_factory=client_factory)

    audit_store = getattr(request.app.state, "action_audit_store", None)
    if audit_store is None:
        audit_store = ActionAuditStore()
        request.app.state.action_audit_store = audit_store

    return ActionBroker(
        repository=repository,
        action_service=action_service,
        audit_store=audit_store,
    )


def _resolve_assistant_project_root(
    request: Request,
    *,
    project_id: str,
    working_dir: str | None,
) -> Path:
    gateway_config = getattr(request.app.state, "gateway_config", {})
    allowed_base = Path(
        str(gateway_config.get("allowed_working_dir_base", "~/obra-projects"))
    ).expanduser()
    if working_dir:
        return _validate_working_dir(working_dir, allowed_base)
    return _validate_working_dir(str(allowed_base / project_id), allowed_base)


def _select_strategy(
    resolved_context: dict[str, Any],
    user_message: str,
) -> list[str]:
    """Examine context signals and return a list of active strategy names."""
    from obra.config.loaders import get_gateway_assistant_config

    assistant_config = get_gateway_assistant_config()
    strategies: list[str] = []

    latest_run = resolved_context.get("latest_run")
    workflow = resolved_context.get("workflow")
    ui_context = resolved_context.get("ui_context") or {}

    # 1. Diagnostic — failed/cancelled run
    if isinstance(latest_run, dict):
        run_status = str(latest_run.get("status") or "unknown")
        failure_stage_id = latest_run.get("failure_stage_id")
        if failure_stage_id is None:
            blocking_summary = latest_run.get("blocking_summary", {})
            if isinstance(blocking_summary, dict):
                failure_stage_id = blocking_summary.get("failure_stage_id")
        if run_status in {"failed", "cancelled"} or failure_stage_id:
            strategies.append("diagnostic")

    # 2. Brainstorming — no workflow
    if workflow is None:
        return ["brainstorming"]

    # 3. Error resolution — validation errors present
    if ui_context.get("has_validation_errors"):
        strategies.append("error_resolution")

    # 4. Design guidance — create mode with few stages
    max_stages = assistant_config.get("strategy_design_guidance_max_stages", 3)
    if ui_context.get("editor_mode") == "create" and ui_context.get("stage_count", 0) < max_stages:
        strategies.append("design_guidance")

    # 5. Connection guidance — all stages isolated
    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        proj_stages = projection.get("stages", {})
        if isinstance(proj_stages, dict) and proj_stages:
            all_isolated = all(
                (isinstance(s, dict) and s.get("role") == "isolated")
                for s in proj_stages.values()
            )
            if all_isolated:
                strategies.append("connection_guidance")

        # 6. Interaction help — non-idle interaction mode
        interaction = projection.get("interaction_state")
        if isinstance(interaction, dict) and interaction.get("mode") != "idle":
            strategies.append("interaction_help")

    # 7. Readiness assessment — clean save, no errors
    if (
        ui_context.get("last_save_status") == "success"
        and not ui_context.get("has_validation_errors")
    ):
        strategies.append("readiness_assessment")

    # 8. Contextual is always the default fallback
    strategies.append("contextual")
    return strategies


def _build_system_prompt_for_turn(
    resolved_context: dict[str, Any],
    user_message: str,
) -> str:
    from obra.config.loaders import get_gateway_assistant_config
    from obra.gateway.workflow_studio.assistant_prompts import _apply_strategy_adjustments

    assistant_config = get_gateway_assistant_config()
    strategies = _select_strategy(resolved_context, user_message)
    resolved_context["strategies"] = strategies

    # Brainstorming branch — separate prompt builder
    if "brainstorming" in strategies:
        return build_brainstorming_system_prompt()

    # All other strategies go through budget-aware contextual prompt
    return build_contextual_system_prompt(
        resolved_context,
        assistant_config=assistant_config,
        strategies=strategies,
    )


@router.post("/threads")
async def create_thread(body: CreateThreadRequest, request: Request) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.create_thread(body.project_id, body.name)
    return {"thread": asdict(thread)}


@router.get("/threads")
async def list_threads(
    request: Request,
    project_id: str,
    archived: bool = False,
) -> dict:
    repository = AssistantRepository.from_request(request)
    threads = repository.list_threads(project_id, archived=archived)
    return {"threads": [asdict(t) for t in threads]}


@router.get("/threads/{thread_id}")
async def get_thread(thread_id: str, request: Request) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    turns = repository.list_turns(thread_id)
    return {"thread": asdict(thread), "turns": [asdict(t) for t in turns]}


@router.patch("/threads/{thread_id}")
async def update_thread(
    thread_id: str,
    body: UpdateThreadRequest,
    request: Request,
) -> dict:
    repository = AssistantRepository.from_request(request)
    thread = repository.update_thread(
        thread_id,
        name=body.name,
        archived=body.archived,
        safety_mode=body.safety_mode,
    )
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    return {"thread": asdict(thread)}


@router.post("/threads/{thread_id}/turns")
async def submit_turn(
    thread_id: str,
    body: SubmitTurnRequest,
    request: Request,
) -> StreamingResponse:
    repository = AssistantRepository.from_request(request)
    thread = repository.get_thread(thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )

    enforce_safety_mode(body.context.safety_mode)

    user_turn = repository.append_turn(
        thread_id,
        role="user",
        message=body.message,
        context=body.context.model_dump(),
    )

    ws_repository = WorkflowStudioRepository.from_request(request)
    project_root = _resolve_assistant_project_root(
        request, project_id=thread.project_id, working_dir=body.context.working_dir,
    )
    assembler = AssistantContextAssembler(ws_repository, project_root=project_root)
    resolved_context = assembler.resolve(body.context)

    # Screenshot
    if body.context.ui_state and isinstance(body.context.ui_state.get("screenshot"), str):
        screenshot = body.context.ui_state["screenshot"]
        if screenshot.startswith("data:image/"):
            resolved_context["screenshot"] = screenshot

    # Model ID — resolve and persist per thread
    resolved_model_id = body.model_id or thread.model_id
    if not resolved_model_id:
        resolved_model_id = _ac.get("model_default_model")
    if resolved_model_id:
        resolved_context["model_id"] = resolved_model_id
        if body.model_id and body.model_id != thread.model_id:
            repository.update_thread(thread_id, model_id=body.model_id)

    # Conversation continuity — add turn history for re-proposal suppression
    from obra.config.loaders import get_gateway_assistant_config as _get_ac
    _ac = _get_ac()
    all_turns = repository.list_turns(thread_id)
    max_proposal_turns = _ac.get("conversation_history_max_proposal_turns", 10)
    proposal_turns = [
        asdict(t) for t in all_turns
        if t.outcome is not None and t.outcome != "advice"
    ][-max_proposal_turns:]
    resolved_context["turn_history"] = proposal_turns
    resolved_context["all_turns"] = [asdict(t) for t in all_turns]

    system_prompt = _build_system_prompt_for_turn(resolved_context, body.message)

    return StreamingResponse(
        stream_assistant_response(
            thread,
            user_turn,
            resolved_context,
            repository,
            system_prompt=system_prompt,
            app_state=request.app.state,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/models")
async def list_models(request: Request) -> dict:
    """List available LLM models with health status."""
    from obra.config.loaders import get_gateway_assistant_config

    config = get_gateway_assistant_config()
    cache = getattr(request.app.state, "assistant_model_health_cache", None)
    if cache is not None:
        return {"models": cache}

    models = []
    try:
        from obra.config.providers import LLM_PROVIDERS, check_provider_status
        from obra.config.llm import MODEL_SHORTCUTS

        for provider_name in LLM_PROVIDERS:
            try:
                provider_status = check_provider_status(provider_name)
                is_available = provider_status.available
            except Exception:
                is_available = False

            # List models for this provider from shortcuts
            for alias, full_id in MODEL_SHORTCUTS.items():
                # Infer provider from model ID
                from obra.config.llm import infer_provider_from_model
                inferred = infer_provider_from_model(full_id)
                if inferred != provider_name:
                    continue
                models.append({
                    "model_id": alias,
                    "full_model_id": full_id,
                    "provider": provider_name,
                    "display_name": f"{alias.replace('-', ' ').title()} ({provider_name})",
                    "status": "available" if is_available else "unavailable",
                })
    except ImportError:
        pass

    request.app.state.assistant_model_health_cache = models
    return {"models": models}


@router.post("/models/refresh")
async def refresh_models(request: Request) -> dict:
    """Clear model health cache and re-probe."""
    request.app.state.assistant_model_health_cache = None
    return await list_models(request)


@router.post("/actions/{action_id}/execute")
async def execute_action(
    action_id: str,
    body: ExecuteActionRequest,
    request: Request,
) -> dict:
    from obra.gateway.assistant.action_broker import (
        ActionInputError,
        ActionNotFoundError,
        SafetyModeInsufficientError,
    )

    enforce_no_actions(body.safety_mode, action_requested=True)

    assistant_repository = AssistantRepository.from_request(request)
    thread = assistant_repository.get_thread(body.thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    project_root = _resolve_assistant_project_root(
        request,
        project_id=thread.project_id,
        working_dir=body.working_dir,
    )
    turn_index = next(
        (
            index
            for index, turn in enumerate(assistant_repository.list_turns(body.thread_id))
            if turn.turn_id == body.turn_id
        ),
        0,
    )

    broker = _get_action_broker(request)
    try:
        result = await asyncio.to_thread(
            broker.execute,
            action_id=action_id,
            inputs=body.action_inputs,
            safety_mode=body.safety_mode,
            thread_id=body.thread_id,
            turn_id=body.turn_id,
            user_id="current-user",
            correlation={"turn_index": turn_index},
            project_root=project_root,
            llm_call=lambda system_prompt, user_message, **kwargs: call_assistant_llm_sync(
                system_prompt,
                user_message,
                app_state=request.app.state,
                **kwargs,
            ),
        )
    except ActionNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Action not found: {action_id}",
        )
    except SafetyModeInsufficientError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "safety_mode_insufficient",
                "current_mode": exc.current_mode,
                "required_mode": exc.required_mode,
            },
        )
    except ActionInputError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        )

    return asdict(result)


@router.get("/threads/{thread_id}/audit")
async def get_thread_audit(thread_id: str, request: Request) -> list:
    audit_store = getattr(request.app.state, "action_audit_store", None)
    if audit_store is None:
        return []
    records = audit_store.list_by_thread(thread_id)
    return [asdict(r) for r in records]


@router.post("/actions/{audit_id}/revert")
async def revert_action(
    audit_id: str,
    body: RevertActionRequest,
    request: Request,
) -> dict[str, Any]:
    from obra.gateway.assistant.audit import ActionAuditStore

    enforce_no_actions(body.safety_mode, action_requested=True)

    audit_store = getattr(request.app.state, "action_audit_store", None)
    if audit_store is None:
        audit_store = ActionAuditStore()
        request.app.state.action_audit_store = audit_store

    audit_record = audit_store.get(audit_id)
    if audit_record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "audit_not_found"},
        )

    checkpoint_id = audit_record.correlation.get("checkpoint_id")
    if checkpoint_id is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "no_checkpoint",
                "message": "This action has no associated file checkpoint",
            },
        )

    assistant_repository = AssistantRepository.from_request(request)
    thread = assistant_repository.get_thread(audit_record.thread_id)
    if thread is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Thread not found",
        )
    project_root = _resolve_assistant_project_root(
        request,
        project_id=thread.project_id,
        working_dir=body.working_dir,
    )
    try:
        checkpoint = restore_checkpoint(project_root, checkpoint_id)
    except AlreadyRevertedError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": "already_reverted"},
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "checkpoint_not_found"},
        )

    return {
        "status": "reverted",
        "checkpoint_id": checkpoint_id,
        "files_restored": [
            f"{checkpoint.target_directory}/{relative_path}".replace("//", "/")
            for relative_path in checkpoint.files_before
        ],
        "correlation": {
            "action_id": "revert_file_action",
            "audit_id": audit_id,
            "checkpoint_id": checkpoint_id,
        },
    }
