"""WebSocket transport — bidirectional protocol for interactive clients."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import asdict
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from websockets.exceptions import ConnectionClosed

from obra import __version__
from obra.api.protocol import EscalationDecision, UserDecisionChoice
from obra.gateway.auth import verify_token
from obra.gateway.event_bus import SessionEventBus
from obra.gateway.protocol import (
    _SUPPORTED_METHODS,
    EventFrame,
    HelloFrame,
    ResponseFrame,
    parse_frame,
    serialize_frame,
)
from obra.gateway.security.client_ip import extract_client_ip_from_websocket
from obra.gateway.session_manager import (
    SessionEvictedError,
    SessionLimitError,
    SessionNotFoundError,
)

logger = logging.getLogger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# Connection Manager
# ---------------------------------------------------------------------------


class ConnectionManager:
    """Tracks WebSocket connections and their session subscriptions."""

    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()
        self.subscriptions: dict[str, set[WebSocket]] = {}
        self._subscription_tasks: dict[tuple[str, int], asyncio.Task[None]] = {}
        self._seq_counters: dict[tuple[str, int], int] = {}
        self._connection_ips: dict[int, str] = {}
        self._connections_per_ip: dict[str, int] = {}

    def connect(
        self,
        ws: WebSocket,
        client_ip: str,
        max_total: int,
        max_per_ip: int,
    ) -> tuple[bool, str | None]:
        if len(self.connections) >= max_total:
            return False, "Too many WebSocket connections"
        if self._connections_per_ip.get(client_ip, 0) >= max_per_ip:
            return False, "Too many WebSocket connections from this IP"

        self.connections.add(ws)
        key = id(ws)
        self._connection_ips[key] = client_ip
        self._connections_per_ip[client_ip] = self._connections_per_ip.get(client_ip, 0) + 1
        return True, None

    def disconnect(self, ws: WebSocket) -> None:
        self.connections.discard(ws)
        key = id(ws)
        client_ip = self._connection_ips.pop(key, None)
        if client_ip is not None:
            remaining = self._connections_per_ip.get(client_ip, 0) - 1
            if remaining > 0:
                self._connections_per_ip[client_ip] = remaining
            else:
                self._connections_per_ip.pop(client_ip, None)
        # Clean up all subscriptions for this connection
        for session_id in list(self.subscriptions):
            self._remove_subscription(session_id, ws)

    def subscribe(self, session_id: str, ws: WebSocket, event_bus: SessionEventBus) -> None:
        """Subscribe a WebSocket to a session's event stream."""
        if session_id not in self.subscriptions:
            self.subscriptions[session_id] = set()
        self.subscriptions[session_id].add(ws)

        key = (session_id, id(ws))
        self._seq_counters[key] = 0
        task = asyncio.create_task(self._broadcast_events(session_id, ws, event_bus))
        self._subscription_tasks[key] = task

    def unsubscribe(self, session_id: str, ws: WebSocket) -> None:
        """Unsubscribe a WebSocket from a session's event stream."""
        self._remove_subscription(session_id, ws)

    def _remove_subscription(self, session_id: str, ws: WebSocket) -> None:
        """Remove a subscription and cancel its broadcast task."""
        if session_id in self.subscriptions:
            self.subscriptions[session_id].discard(ws)
            if not self.subscriptions[session_id]:
                del self.subscriptions[session_id]

        key = (session_id, id(ws))
        task = self._subscription_tasks.pop(key, None)
        if task and not task.done():
            task.cancel()
        self._seq_counters.pop(key, None)

    async def _broadcast_events(
        self, session_id: str, ws: WebSocket, event_bus: SessionEventBus
    ) -> None:
        """Consume events from an event bus and forward to the subscribed WebSocket."""
        key = (session_id, id(ws))
        try:
            async for event in event_bus.consume():
                seq = self._seq_counters.get(key, 0)
                frame = EventFrame(
                    event=event.get("event_type", "unknown"),
                    payload=event.get("payload", {}),
                    session_id=session_id,
                    seq=seq,
                )
                self._seq_counters[key] = seq + 1

                try:
                    await ws.send_text(serialize_frame(frame))
                except (WebSocketDisconnect, ConnectionClosed, RuntimeError):
                    # Client disconnected — clean up silently
                    self._remove_subscription(session_id, ws)
                    return

                # Auto-unsubscribe on terminal events
                event_type = event.get("event_type", "")
                if event_type in ("session_completed", "session_error"):
                    self._remove_subscription(session_id, ws)
                    return

        except asyncio.CancelledError:
            pass


# Module-level connection manager (shared across the WS route)
_manager = ConnectionManager()


# ---------------------------------------------------------------------------
# WebSocket Endpoint
# ---------------------------------------------------------------------------


@router.websocket("/v1/ws")
async def websocket_endpoint(ws: WebSocket) -> None:
    """WebSocket endpoint for bidirectional gateway communication."""
    await ws.accept()
    gateway_config = getattr(ws.app.state, "gateway_config", {})
    ws_auth_timeout_s = float(gateway_config.get("ws_auth_timeout_s", 5.0))
    trusted_proxy_cidrs = list(gateway_config.get("trusted_proxy_cidrs", []))
    max_total_connections = int(gateway_config.get("max_ws_connections_total", 200))
    max_connections_per_ip = int(gateway_config.get("max_ws_connections_per_ip", 20))

    client_ip = extract_client_ip_from_websocket(ws, trusted_proxy_cidrs)
    ws.scope["gateway_client_ip"] = client_ip
    accepted, error = _manager.connect(
        ws=ws,
        client_ip=client_ip,
        max_total=max_total_connections,
        max_per_ip=max_connections_per_ip,
    )
    if not accepted:
        await _close_with_error(ws, error or "Too many WebSocket connections", 4003)
        return

    try:
        # Step 1: Authenticate — first message must be {type: "auth", token: "..."}
        try:
            auth_raw = await asyncio.wait_for(ws.receive_text(), timeout=ws_auth_timeout_s)
            auth_data = json.loads(auth_raw)
        except asyncio.TimeoutError:
            await _close_with_error(ws, "Authentication timeout", 4001)
            return
        except (json.JSONDecodeError, WebSocketDisconnect):
            await _close_with_error(ws, "Invalid authentication frame", 4001)
            return

        if auth_data.get("type") != "auth" or "token" not in auth_data:
            await _close_with_error(
                ws,
                "First message must be {type: 'auth', token: '...'}",
                4001,
            )
            return

        # Verify token against the app-level expected token
        from fastapi.security import HTTPAuthorizationCredentials

        expected_token = ws.app.state.gateway_token
        creds = HTTPAuthorizationCredentials(scheme="Bearer", credentials=auth_data["token"])
        if not verify_token(creds, expected_token):
            await _close_with_error(ws, "Authentication failed", 4001)
            return

        # Step 2: Send HelloFrame
        sm = ws.app.state.session_manager
        sessions_snapshot = [
            {
                "session_id": r.session_id,
                "status": r.status,
                "objective": r.objective,
                "project_id": r.project_id,
            }
            for r in sm.list_sessions()
        ]
        hello = HelloFrame(
            server_version=__version__,
            methods=_SUPPORTED_METHODS,
            sessions=sessions_snapshot,
        )
        await ws.send_text(serialize_frame(hello))

        # Step 3: Process request frames
        while True:
            raw = await ws.receive_text()
            try:
                req = parse_frame(raw)
            except ValueError as exc:
                error_resp = json.dumps({"type": "error", "detail": str(exc)})
                await ws.send_text(error_resp)
                continue

            response = await _dispatch(req, ws)
            await ws.send_text(serialize_frame(response))

    except (WebSocketDisconnect, ConnectionClosed):
        pass
    finally:
        _manager.disconnect(ws)


# ---------------------------------------------------------------------------
# Message Dispatch
# ---------------------------------------------------------------------------


async def _dispatch(req: Any, ws: WebSocket) -> ResponseFrame:
    """Route a request frame to the appropriate handler."""
    sm = ws.app.state.session_manager
    method = req.method
    params = req.params
    req_id = req.id
    ws_limiter = getattr(ws.app.state, "ws_rate_limiter", None)
    if ws_limiter is not None:
        client_ip = str(ws.scope.get("gateway_client_ip", "0.0.0.0"))
        if not ws_limiter.allow(client_ip):
            return ResponseFrame(id=req_id, ok=False, error="Rate limit exceeded")

    try:
        if method == "create_session":
            payload = _handle_create_session(params, sm)
        elif method == "list_sessions":
            payload = _handle_list_sessions(sm)
        elif method == "get_session":
            payload = _handle_get_session(params, sm)
        elif method == "cancel_session":
            payload = _handle_cancel_session(params, sm)
        elif method == "subscribe":
            payload = _handle_subscribe(params, sm, ws)
        elif method == "unsubscribe":
            payload = _handle_unsubscribe(params, ws)
        elif method == "escalation_decision":
            payload = _handle_escalation_decision(params, sm)
        else:
            return ResponseFrame(id=req_id, ok=False, error=f"Unknown method: {method}")
        return ResponseFrame(id=req_id, ok=True, payload=payload)
    except SessionEvictedError:
        return ResponseFrame(id=req_id, ok=False, error="Session evicted")
    except SessionNotFoundError:
        return ResponseFrame(id=req_id, ok=False, error="Session not found")
    except SessionLimitError:
        return ResponseFrame(id=req_id, ok=False, error="Session limit reached")
    except Exception:
        logger.exception("Error handling WS method %s", method)
        return ResponseFrame(id=req_id, ok=False, error="Internal error")


# ---------------------------------------------------------------------------
# Handler Implementations
# ---------------------------------------------------------------------------


def _handle_create_session(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Create a new orchestration session."""
    objective = params.get("objective", "")
    project_id = params.get("project_id", "")
    working_dir = params.get("working_dir", ".")

    if not isinstance(objective, str):
        objective = str(objective)
    if not isinstance(project_id, str):
        project_id = str(project_id)
    if not isinstance(working_dir, str):
        working_dir = str(working_dir)

    if len(objective) > 10_000:
        return {"error": "objective exceeds maximum length"}
    if len(project_id) > 256:
        return {"error": "project_id exceeds maximum length"}
    if len(working_dir) > 4096:
        return {"error": "working_dir exceeds maximum length"}

    try:
        session_id = sm.create_session(
            objective=objective,
            project_id=project_id,
            working_dir=working_dir,
        )
    except ValueError:
        return {"error": "Working directory not allowed"}

    return {"session_id": session_id, "status": "created"}


def _handle_list_sessions(sm: Any) -> dict[str, Any]:
    """List all sessions."""
    records = sm.list_sessions()
    return {
        "sessions": [
            {
                "session_id": r.session_id,
                "status": r.status,
                "objective": r.objective,
                "created_at": r.created_at.isoformat(),
                "project_id": r.project_id,
            }
            for r in records
        ]
    }


def _handle_get_session(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Get session details."""
    session_id = params.get("session_id", "")
    r = sm.get_session(session_id)
    completion = None
    if r.completion_notice is not None:
        completion = asdict(r.completion_notice)
    return {
        "session_id": r.session_id,
        "status": r.status,
        "objective": r.objective,
        "created_at": r.created_at.isoformat(),
        "project_id": r.project_id,
        "completion_notice": completion,
        "error": r.error,
    }


def _handle_cancel_session(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Cancel a running session."""
    session_id = params.get("session_id", "")
    sm.cancel_session(session_id)
    return {"session_id": session_id, "status": "cancelling"}


def _handle_subscribe(params: dict[str, Any], sm: Any, ws: WebSocket) -> dict[str, Any]:
    """Subscribe to a session's event stream."""
    session_id = params.get("session_id", "")
    event_bus = sm.get_event_bus(session_id)
    _manager.subscribe(session_id, ws, event_bus)
    return {"session_id": session_id, "subscribed": True}


def _handle_unsubscribe(params: dict[str, Any], ws: WebSocket) -> dict[str, Any]:
    """Unsubscribe from a session's event stream."""
    session_id = params.get("session_id", "")
    _manager.unsubscribe(session_id, ws)
    return {"session_id": session_id, "unsubscribed": True}


def _handle_escalation_decision(params: dict[str, Any], sm: Any) -> dict[str, Any]:
    """Resolve a pending escalation."""
    session_id = params.get("session_id", "")
    choice_str = params.get("choice", "force_complete")
    was_timeout = params.get("was_timeout", False)

    event_bus = sm.get_event_bus(session_id)
    decision = EscalationDecision(
        choice=UserDecisionChoice(choice_str),
        was_timeout=was_timeout,
    )
    resolved = event_bus.resolve_escalation(decision)

    if not resolved:
        return {"session_id": session_id, "escalation_resolved": False, "error": "No pending escalation"}

    return {"session_id": session_id, "escalation_resolved": True}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _close_with_error(ws: WebSocket, detail: str, code: int) -> None:
    """Send error message and close the WebSocket."""
    try:
        await ws.send_text(json.dumps({"type": "error", "detail": detail}))
        await ws.close(code=code)
    except Exception:
        pass
