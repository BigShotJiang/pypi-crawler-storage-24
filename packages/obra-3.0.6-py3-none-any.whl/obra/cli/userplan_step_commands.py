"""Step-oriented UserPlan CLI command handlers."""

from __future__ import annotations

import logging
from typing import Any

import typer
from rich.table import Table

from obra.cli.userplan_display import (
    render_step_context_update,
    render_step_context_view,
)
from obra.cli.userplan_shared import (
    build_json_formatter,
    ensure_authenticated,
    get_api_client,
    output_json_error,
)
from obra.cli.userplan_support import (
    build_step_context_payload,
    parse_step_identifier,
)
from obra.display import console, handle_encoding_errors, print_error, print_info, print_success
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError
from obra.messages import get_message

logger = logging.getLogger(__name__)


@handle_encoding_errors
def userplan_steps(
    userplan_id: str = typer.Argument(..., help="UserPlan ID to display steps for"),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show step descriptions in addition to titles",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Display all steps in a UserPlan with derivation status."""
    from obra.schemas.userplan_schema import DerivationStatus
    from obra.utils.json_output import serialize_step

    try:
        ensure_authenticated(format_output=format_output, allow_json_error=True)

        client = get_api_client()
        userplan = client.get_userplan(userplan_id)

        if not userplan:
            if format_output == "json":
                output_json_error(f"UserPlan not found: {userplan_id}", "NOT_FOUND")
                raise typer.Exit(1)
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        if not steps:
            if format_output == "json":
                formatter = build_json_formatter()
                formatter.output_success(
                    data={
                        "steps": [],
                        "summary": {
                            "total": 0,
                            "derived": 0,
                            "deriving": 0,
                            "stale": 0,
                            "pending": 0,
                        },
                    },
                    ids={"userplan_id": userplan_id},
                )
                return
            print_info(f"UserPlan {userplan_id} has no steps")
            raise typer.Exit(0)

        total_steps = len(steps)
        derived_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.DERIVED.value
        )
        deriving_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.DERIVING.value
        )
        stale_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.STALE.value
        )
        not_derived_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.NOT_DERIVED.value
        )

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "steps": [serialize_step(s) for s in steps],
                    "summary": {
                        "total": total_steps,
                        "derived": derived_count,
                        "deriving": deriving_count,
                        "stale": stale_count,
                        "pending": not_derived_count,
                    },
                },
                ids={
                    "userplan_id": userplan_id,
                    "step_ids": ",".join(s.get("id", "") for s in steps),
                },
            )
            return

        console.print()
        console.print(f"[bold cyan]Steps for UserPlan: {userplan_id}[/bold cyan]")
        console.print()

        console.print(
            f"[bold]Total:[/bold] {total_steps} steps | "
            f"[green]Derived: {derived_count}[/green] | "
            f"[yellow]Deriving: {deriving_count}[/yellow] | "
            f"[red]Stale: {stale_count}[/red] | "
            f"[dim]Pending: {not_derived_count}[/dim]"
        )
        console.print()

        table = Table(show_header=True, header_style="bold")
        table.add_column("#", style="cyan", justify="right", width=3)
        table.add_column("Step ID", style="dim", width=30)
        table.add_column("Title", width=40)
        table.add_column("Status", width=12)
        table.add_column("Deps", width=10)

        def status_style(status_value: str) -> str:
            if status_value == DerivationStatus.DERIVED.value:
                return "[green]derived[/green]"
            if status_value == DerivationStatus.DERIVING.value:
                return "[yellow]deriving[/yellow]"
            if status_value == DerivationStatus.STALE.value:
                return "[red]stale[/red]"
            return "[dim]pending[/dim]"

        for step in steps:
            step_index = str(step.get("index", "?"))
            step_id = step.get("id", "N/A")
            step_title = step.get("title", "Untitled")
            if len(step_title) > 38:
                step_title = step_title[:35] + "..."

            derivation_status = step.get("derivation_status", DerivationStatus.NOT_DERIVED.value)
            styled_status = status_style(derivation_status)
            step_idx = step.get("index", 1)
            deps = f"S{step_idx - 1}" if step_idx > 1 else "-"

            table.add_row(step_index, step_id, step_title, styled_status, deps)

        console.print(table)

        if verbose:
            console.print()
            console.print("[bold]Step Descriptions:[/bold]")
            console.print("-" * 60)

            for step in steps:
                step_index = step.get("index", "?")
                step_title = step.get("title", "Untitled")
                description = step.get("description", "No description")
                derivation_status = step.get(
                    "derivation_status", DerivationStatus.NOT_DERIVED.value
                )
                styled_status = status_style(derivation_status)

                console.print()
                console.print(f"[cyan]{step_index}. {step_title}[/cyan] {styled_status}")

                desc_lines = description.split("\n")
                for line in desc_lines[:10]:
                    console.print(f"   {line}")
                if len(desc_lines) > 10:
                    console.print(f"   [dim]... {len(desc_lines) - 10} more lines[/dim]")

        console.print()
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print(f"TOTAL_STEPS={total_steps}")
        console.print(f"DERIVED_STEPS={derived_count}")
        console.print(f"DERIVING_STEPS={deriving_count}")
        console.print(f"STALE_STEPS={stale_count}")
        console.print(f"PENDING_STEPS={not_derived_count}")
        console.print()

        if stale_count > 0:
            console.print(
                f"[yellow]Hint:[/yellow] Some steps are stale. "
                f"Re-derive with: [cyan]obra derive --userplan {userplan_id} --from-step N[/cyan]"
            )
        elif not_derived_count > 0 and derived_count == 0:
            console.print(
                f"[dim]Next:[/dim] Derive plan with: [cyan]obra derive --userplan {userplan_id}[/cyan]"
            )
        elif not_derived_count > 0:
            first_pending = next(
                (
                    s
                    for s in steps
                    if s.get("derivation_status") == DerivationStatus.NOT_DERIVED.value
                ),
                None,
            )
            if first_pending:
                console.print(
                    f"[dim]Next:[/dim] Continue derivation from step {first_pending.get('index')}"
                )

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan steps command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan steps command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan steps command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan steps command: %s", exc)
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_step_add(
    userplan_id: str = typer.Argument(..., help="UserPlan ID to add step to"),
    title: str = typer.Option(
        ...,
        "--title",
        "-t",
        help="Step title (required)",
    ),
    description: str = typer.Option(
        ...,
        "--description",
        "-d",
        help="Step description (required)",
    ),
    index: int | None = typer.Option(
        None,
        "--index",
        "-i",
        help="Position to insert step (1-based, default: append to end)",
    ),
    deliverables: str | None = typer.Option(None, "--deliverables", help="Comma-separated list of deliverables"),
    requirements: str | None = typer.Option(None, "--requirements", help="Comma-separated list of requirements"),
    tech_stack: str | None = typer.Option(None, "--tech-stack", help="Comma-separated list of technologies"),
    format_output: str = typer.Option("text", "--format", "-f", help="Output format: text, json"),
) -> None:
    """Add a new step to a UserPlan."""
    try:
        ensure_authenticated()

        if not title.strip():
            if format_output == "json":
                output_json_error("Title cannot be empty", "VALIDATION_ERROR")
                raise typer.Exit(1)
            print_error("Title cannot be empty")
            raise typer.Exit(1)

        if not description.strip():
            if format_output == "json":
                output_json_error("Description cannot be empty", "VALIDATION_ERROR")
                raise typer.Exit(1)
            print_error("Description cannot be empty")
            raise typer.Exit(1)

        if index is not None and index < 1:
            if format_output == "json":
                output_json_error("Index must be >= 1 (1-based indexing)", "VALIDATION_ERROR")
                raise typer.Exit(1)
            print_error("Index must be >= 1 (1-based indexing)")
            raise typer.Exit(1)

        context: dict[str, Any] | None = None
        if deliverables or requirements or tech_stack:
            context = {}
            if deliverables:
                context["deliverables"] = [d.strip() for d in deliverables.split(",") if d.strip()]
            if requirements:
                context["requirements"] = [r.strip() for r in requirements.split(",") if r.strip()]
            if tech_stack:
                context["tech_stack"] = [t.strip() for t in tech_stack.split(",") if t.strip()]

        client = get_api_client()

        if format_output != "json":
            console.print()
            print_info(f"Adding step to UserPlan: {userplan_id}")

        result = client.add_userplan_step(
            userplan_id=userplan_id,
            title=title.strip(),
            description=description.strip(),
            index=index,
            context=context,
        )

        added_step = result.get("added_step", result.get("step", {}))
        step_index = added_step.get("index", index or "?")
        step_id = added_step.get("id", "N/A")

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "step": {
                        "id": step_id,
                        "index": step_index,
                        "title": title.strip(),
                        "description": description.strip(),
                        "context": context,
                    },
                },
                ids={"step_id": str(step_id), "userplan_id": userplan_id},
            )
            return

        console.print()
        print_success(f"Added step {step_index}: {title}")
        console.print()
        console.print(f"  [cyan]Step ID:[/cyan] {step_id}")
        console.print(f"  [cyan]Index:[/cyan] {step_index}")
        console.print(f"  [cyan]Title:[/cyan] {title}")
        if context:
            console.print(f"  [cyan]Context:[/cyan] {len(context)} fields set")
        console.print()

        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"STEP_ID={step_id}")
        console.print(f"STEP_INDEX={step_index}")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print()

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan step add command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan step add command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan step add command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan step add command: %s", exc)
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_step_remove(
    userplan_id: str = typer.Argument(..., help="UserPlan ID containing the step"),
    step_id: str = typer.Argument(..., help="Step index (number) or full step ID to remove"),
    force: bool = typer.Option(False, "--force", help="Skip confirmation prompt"),
    format_output: str = typer.Option("text", "--format", "-f", help="Output format: text, json"),
) -> None:
    """Remove a step from a UserPlan."""
    try:
        ensure_authenticated()

        step_index = parse_step_identifier(step_id)
        client = get_api_client()

        userplan = client.get_userplan(userplan_id)
        if not userplan:
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        if step_index > len(steps):
            print_error(f"Step index {step_index} out of range (UserPlan has {len(steps)} steps)")
            raise typer.Exit(1)

        target_step = steps[step_index - 1]
        step_title = target_step.get("title", "Untitled")

        console.print()
        console.print("[bold]Step to remove:[/bold]")
        console.print(f"  Index: {step_index}")
        console.print(f"  Title: {step_title}")
        console.print()

        if not force:
            console.print("[yellow]Warning:[/yellow] This operation cannot be undone.")
            console.print()
            confirm = typer.confirm(get_message("prompt.confirm.remove_step"))
            if not confirm:
                print_info("Operation cancelled")
                raise typer.Exit(0)

        if format_output != "json":
            print_info(f"Removing step {step_index} from UserPlan: {userplan_id}")

        result = client.remove_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
        )

        remaining_steps = len(result.get("steps", []))

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "removed_step": {
                        "index": step_index,
                        "title": step_title,
                    },
                    "remaining_steps": remaining_steps,
                },
                ids={"userplan_id": userplan_id},
            )
            return

        console.print()
        print_success(f"Removed step {step_index}: {step_title}")
        console.print(f"  [dim]Remaining steps: {remaining_steps}[/dim]")
        console.print()

        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"REMOVED_STEP_INDEX={step_index}")
        console.print(f"REMOVED_STEP_TITLE={step_title}")
        console.print(f"REMAINING_STEPS={remaining_steps}")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print()

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan step remove command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan step remove command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan step remove command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan step remove command: %s", exc)
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_step_update(
    userplan_id: str = typer.Argument(..., help="UserPlan ID containing the step"),
    step_id: str = typer.Argument(..., help="Step index (number) or full step ID to update"),
    title: str | None = typer.Option(None, "--title", "-t", help="New step title"),
    description: str | None = typer.Option(None, "--description", "-d", help="New step description"),
    cascade: bool = typer.Option(False, "--cascade", "-c", help="Mark subsequent steps as stale (for re-derivation)"),
    format_output: str = typer.Option("text", "--format", "-f", help="Output format: text, json"),
) -> None:
    """Update a step's title or description."""
    try:
        ensure_authenticated()

        if title is None and description is None:
            print_error("At least one of --title or --description must be provided")
            raise typer.Exit(1)

        step_index = parse_step_identifier(step_id)
        client = get_api_client()

        console.print()
        if format_output != "json":
            print_info(f"Updating step {step_index} in UserPlan: {userplan_id}")

        result = client.update_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
            title=title.strip() if title else None,
            description=description.strip() if description else None,
            cascade=cascade,
        )

        updated_step = result.get("updated_step", result.get("step", {}))
        cascaded_steps = result.get("cascaded_steps", [])

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "step": {
                        "index": step_index,
                        "title": title.strip() if title else updated_step.get("title"),
                        "description": (
                            description.strip() if description else updated_step.get("description")
                        ),
                        "derivation_status": "stale",
                    },
                    "cascaded_steps": cascaded_steps,
                },
                ids={
                    "userplan_id": userplan_id,
                    "step_index": str(step_index),
                },
            )
            return

        console.print()
        print_success(f"Updated step {step_index}")
        console.print()

        if title:
            console.print(f"  [cyan]Title:[/cyan] {title}")
        if description:
            desc_preview = description[:50] + "..." if len(description) > 50 else description
            console.print(f"  [cyan]Description:[/cyan] {desc_preview}")

        console.print("  [cyan]Derivation status:[/cyan] stale")
        if cascade and cascaded_steps:
            console.print(f"  [cyan]Cascaded steps:[/cyan] {cascaded_steps}")
        console.print()

        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"STEP_INDEX={step_index}")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print("DERIVATION_STATUS=stale")
        if cascaded_steps:
            console.print(f"CASCADED_STEPS={','.join(map(str, cascaded_steps))}")
        console.print()

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan step update command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan step update command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan step update command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan step update command: %s", exc)
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_step_context(
    userplan_id: str = typer.Argument(..., help="UserPlan ID containing the step"),
    step_id: str = typer.Argument(..., help="Step index (number) or full step ID"),
    deliverables: str | None = typer.Option(None, "--deliverables", help="Set deliverables (comma-separated list, use '' to clear)"),
    success_criteria: str | None = typer.Option(None, "--success-criteria", help="Set success criteria"),
    requirements: str | None = typer.Option(None, "--requirements", help="Set requirements (comma-separated list, use '' to clear)"),
    tech_stack: str | None = typer.Option(None, "--tech-stack", help="Set tech stack (comma-separated list, use '' to clear)"),
    constraints: str | None = typer.Option(None, "--constraints", help="Set constraints (comma-separated list, use '' to clear)"),
    assumptions: str | None = typer.Option(None, "--assumptions", help="Set assumptions (comma-separated list, use '' to clear)"),
    format_output: str = typer.Option("text", "--format", "-f", help="Output format: text, json"),
) -> None:
    """View or update a step's context."""
    try:
        ensure_authenticated()

        step_index = parse_step_identifier(step_id)
        client = get_api_client()

        is_update = any(
            value is not None
            for value in [
                deliverables,
                success_criteria,
                requirements,
                tech_stack,
                constraints,
                assumptions,
            ]
        )

        if is_update:
            context = build_step_context_payload(
                deliverables=deliverables,
                success_criteria=success_criteria,
                requirements=requirements,
                tech_stack=tech_stack,
                constraints=constraints,
                assumptions=assumptions,
            )

            if format_output != "json":
                console.print()
                print_info(f"Updating context for step {step_index} in UserPlan: {userplan_id}")

            client.update_userplan_step_context(
                userplan_id=userplan_id,
                step_index=step_index,
                context=context,
            )

            if format_output == "json":
                formatter = build_json_formatter()
                formatter.output_success(
                    data={
                        "context": context,
                        "fields_updated": list(context.keys()),
                    },
                    ids={"step_index": str(step_index), "userplan_id": userplan_id},
                )
                return

            render_step_context_update(
                userplan_id=userplan_id,
                step_index=step_index,
                context=context,
            )
            return

        userplan = client.get_userplan(userplan_id)
        if not userplan:
            if format_output == "json":
                output_json_error(f"UserPlan not found: {userplan_id}", "NOT_FOUND")
                raise typer.Exit(1)
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        if step_index > len(steps):
            if format_output == "json":
                output_json_error(
                    f"Step index {step_index} out of range (UserPlan has {len(steps)} steps)",
                    "OUT_OF_RANGE",
                )
                raise typer.Exit(1)
            print_error(f"Step index {step_index} out of range (UserPlan has {len(steps)} steps)")
            raise typer.Exit(1)

        step = steps[step_index - 1]
        step_title = step.get("title", "Untitled")
        step_context = step.get("context") or {}

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "step_index": step_index,
                    "step_title": step_title,
                    "context": step_context,
                    "has_context": bool(step_context),
                },
                ids={"step_index": str(step_index), "userplan_id": userplan_id},
            )
            return

        render_step_context_view(
            userplan_id=userplan_id,
            step_index=step_index,
            step_title=step_title,
            step_context=step_context,
        )

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan step context command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan step context command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan step context command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan step context command: %s", exc)
        raise typer.Exit(1) from exc
