"""Run/derive lifecycle commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""

import logging
import os
import re
import sys
from datetime import UTC, datetime
from http import HTTPStatus
from pathlib import Path
from typing import Any, Callable, cast

import click
import typer
import yaml  # type: ignore[import-untyped]

from obra import __version__
from obra.api.protocol import (
    ActionType,
    EscalationDecision,
    EscalationNotice,
    EscalationReason,
    UserDecisionChoice,
)
from obra.cli._shared import (
    _resolve_command_verbosity,
    require_terms_accepted,
    setup_logging,
)
from obra.cli.feedback import offer_bug_report
from obra.cli.interrupt import (
    _manager as _interrupt_manager,
)
from obra.cli.interrupt import (
    _print_session_resume_hints,
)
from obra.cli.run_support.command_surface import (
    VALID_WORK_TYPES,
    prepare_derive_invocation,
    prepare_run_invocation,
)
from obra.config import (
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_REASONING_LEVEL,
    REASONING_LEVELS,
    infer_provider_from_model,
    load_config,
)
from obra.core.interrupts import (
    GracefulInterrupt,
    clear_interrupt_request,
    defer_interrupts,
)
from obra.display import (
    EscalationRenderer,
    ObservabilityConfig,
    ProgressEmitter,
    console,
    glyphs,
    handle_encoding_errors,
    print_banner,
    print_error,
    print_info,
    print_success,
    print_warning,
    set_runtime_verbosity,
)
from obra.display.closeout import (
    _build_closeout_context,
    _build_interrupted_closeout_context,
    _extract_completion_context,
    _log_closeout_rendered,
    _print_git_file_summary,
    build_closeout_message,
)
from obra.display.errors import display_error, display_obra_error
from obra.display.event_router import (
    _route_progress_event,
)
from obra.display.session_banner import (
    _format_environment_label,
    _format_git_status,
    _format_run_mode,
    _resolve_project_display,
    _summarize_config_layers,
)
from obra.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ObraError,
)
from obra.exceptions import (
    ConnectionError as ObraConnectionError,
)
from obra.feedback.session_logger import (
    rename_session_logging,
    start_session_logging,
    stop_session_logging,
)
from obra.messages import get_message
from obra.model_registry import resolve_quality_tier
from obra.review.config import ALLOWED_AGENTS, ReviewConfig, ReviewConfigCLIInputs
from obra.session.working_dir import (
    resolve_working_dir_selection as _resolve_working_dir_selection,
)
from obra.utils.terminal import is_headless as _is_headless

logger = logging.getLogger(__name__)

MAX_OBJECTIVE_PREVIEW = 160


def _infer_heartbeat_phase(
    orchestrator: Any | None,
    action: str,
    payload: dict[str, Any],
) -> str | None:
    """Compatibility wrapper for heartbeat phase inference."""
    from obra.cli.run_support.heartbeat import _infer_heartbeat_phase as support_impl

    return support_impl(orchestrator, action, payload)


def _refresh_local_session_heartbeat(
    orchestrator: Any | None,
    action: str,
    payload: dict[str, Any],
) -> None:
    """Compatibility wrapper for heartbeat refresh handling."""
    from obra.cli.run_support.heartbeat import _refresh_local_session_heartbeat as support_impl

    support_impl(orchestrator, action, payload)


def _build_escalation_callback() -> Callable[[EscalationNotice], EscalationDecision]:
    """Compatibility wrapper for the interactive escalation callback."""
    from obra.cli.run_support.escalation import _build_escalation_callback as support_impl

    return support_impl()



@handle_encoding_errors
@require_terms_accepted
def run_objective(
    ctx: typer.Context,
    objective: str | None = typer.Argument(None, help="What you want Obra to accomplish"),
    working_dir: str | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
    ),
    project_id: str | None = typer.Option(
        None,
        "--project",
        help="Project ID override (optional)",
    ),
    domain: str | None = typer.Option(
        None,
        "--domain",
        help="Domain module name (e.g., software, business)",
    ),
    resume_session: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume an existing session by ID",
    ),
    continue_from: str | None = typer.Option(
        None,
        "--continue-from",
        "-c",
        help=(
            "Continue from a failed/escalated session (creates new session, skips completed tasks; "
            "uses original objective unless overridden)"
        ),
    ),
    resume_from: str | None = typer.Option(
        None,
        "--from",
        help=(
            "Resume from a specific phase: environment/preflight (rerun setup), "
            "derivation/plan (skip preflight validation), execution (resume execution)."
        ),
        show_choices=True,
        click_type=click.Choice(
            ["environment", "preflight", "story-0", "derivation", "plan", "execution"],
            case_sensitive=False,
        ),
    ),
    rerun_setup: bool = typer.Option(
        False,
        "--rerun-setup",
        help="Re-run preflight environment setup (alias for --from environment)",
    ),
    plan_id: str | None = typer.Option(
        None,
        "--plan-id",
        help=(
            "Use an uploaded plan by ID (from 'obra plans upload'). "
            "Requires local YAML at docs/development/{PLAN_ID}_MACHINE_PLAN.json."
        ),
    ),
    plan_file: Path | None = typer.Option(
        None,
        "--plan-file",
        help="Upload and use a plan file in one step",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Implementation model (e.g., opus, gpt-5.2, gemini-2.5-flash)",
    ),
    fast_model: str | None = typer.Option(
        None,
        "--fast-model",
        help="Fast tier model override (used for extraction and quick validation)",
    ),
    high_model: str | None = typer.Option(
        None,
        "--high-model",
        help="High tier model override (used for complex reasoning)",
    ),
    impl_provider: str | None = typer.Option(
        None,
        "--impl-provider",
        "-p",
        help="Implementation provider (anthropic, openai, google). Requires provider CLI (claude/codex/gemini).",
    ),
    reasoning_level: str | None = typer.Option(
        None,
        "--reasoning-level",
        "-t",
        help="Thinking/reasoning level (off, low, medium, high, maximum)",
    ),
    no_extended_thinking: bool = typer.Option(
        False,
        "--no-extended-thinking",
        help="Disable extended thinking for derivation (equivalent to --reasoning-level off)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    progress_json: bool = typer.Option(
        False,
        "--progress-json",
        help="Emit progress events as JSON lines to stdout",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        "-s",
        help="Enable real-time LLM output streaming",
    ),
    plan_only: bool = typer.Option(
        False,
        "--plan-only",
        help="Create plan without executing (client-side exit after planning)",
    ),
    permissive: bool = typer.Option(
        False,
        "--permissive",
        help="Bypass P1 planning blockers (proceed with warnings)",
    ),
    defaults_json: bool = typer.Option(
        False,
        "--defaults-json",
        help="Print proposed defaults as JSON and exit when refinement is blocked",
    ),
    no_closeout: bool = typer.Option(
        False,
        "--no-closeout",
        help="Skip close-out story injection",
    ),
    skip_intent: bool = typer.Option(
        False,
        "--skip-intent",
        help="Skip intent generation for vague objectives (S2.T3)",
    ),
    review_intent: bool = typer.Option(
        False,
        "--review-intent",
        help="Display generated intent and prompt for approval before derive (S2.T4)",
    ),
    enrich: bool = typer.Option(
        False,
        "--enrich",
        help="Force intent enrichment (requires planning.enrichment.enabled)",
    ),
    no_enrich: bool = typer.Option(
        False,
        "--no-enrich",
        help="Skip intent enrichment even when enabled",
    ),
    isolated: bool | None = typer.Option(
        None,
        "--isolated",
        help="Run agent in isolated environment (prevents reading host CLI config)",
    ),
    no_isolated: bool | None = typer.Option(
        None,
        "--no-isolated",
        help="Disable isolation (use host CLI config, even in CI)",
    ),
    full_review: bool = typer.Option(
        False,
        "--full-review",
        help="Run all review agents (overrides auto-detection)",
    ),
    skip_review: bool = typer.Option(
        False,
        "--skip-review",
        help="Skip the review phase entirely",
    ),
    review_agents: str | None = typer.Option(
        None,
        "--review-agents",
        help=f"Comma-separated review agents to run ({', '.join(ALLOWED_AGENTS)})",
    ),
    with_security: bool = typer.Option(
        False,
        "--with-security",
        help="Add the security review agent",
    ),
    with_testing: bool = typer.Option(
        False,
        "--with-testing",
        help="Add the testing review agent",
    ),
    with_docs: bool = typer.Option(
        False,
        "--with-docs",
        help="Add the docs review agent",
    ),
    with_code_quality: bool = typer.Option(
        False,
        "--with-code-quality",
        help="Add the code_quality review agent",
    ),
    no_security: bool = typer.Option(
        False,
        "--no-security",
        help="Remove the security review agent",
    ),
    no_testing: bool = typer.Option(
        False,
        "--no-testing",
        help="Remove the testing review agent",
    ),
    no_docs: bool = typer.Option(
        False,
        "--no-docs",
        help="Remove the docs review agent",
    ),
    no_code_quality: bool = typer.Option(
        False,
        "--no-code-quality",
        help="Remove the code_quality review agent",
    ),
    review_format: str | None = typer.Option(
        None,
        "--review-format",
        help="Review output format (text or json)",
        show_choices=True,
    ),
    review_quiet: bool = typer.Option(
        False,
        "--review-quiet",
        help="Suppress review output",
    ),
    review_summary_only: bool = typer.Option(
        False,
        "--review-summary-only",
        help="Show only review summary counts",
    ),
    fail_on_p1: bool = typer.Option(
        False,
        "--fail-on-p1",
        help="Exit with status 1 when P1 findings are present",
    ),
    fail_on_p2: bool = typer.Option(
        False,
        "--fail-on-p2",
        help="Exit with status 1 when P1 or P2 findings are present",
    ),
    review_timeout: int | None = typer.Option(
        None,
        "--review-timeout",
        min=1,
        help="Per-agent review timeout in seconds",
    ),
    auto_report: bool = typer.Option(
        False,
        "--auto-report",
        help="Automatically submit bug reports on failure (no prompt, for CI/CD)",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Auto-approve all confirmation prompts",
    ),
    mock_credentials: bool = typer.Option(
        False,
        "--mock-credentials",
        help="Automatically mock all required credentials",
    ),
    skip_git_check: bool = typer.Option(
        False,
        "--skip-git-check",
        help="Skip git repository validation (GIT-HARD-001)",
    ),
    auto_init_git: bool = typer.Option(
        False,
        "--auto-init-git",
        help="Auto-initialize git repository if not present (GIT-HARD-001)",
    ),
    skip_quality_check: bool = typer.Option(
        False,
        "--skip-quality-check",
        help="Skip UserPlan quality assessment (for debugging, testing, or high-confidence plans)",
    ),
    skip_complexity_check: bool = typer.Option(
        False,
        "--skip-complexity-check",
        help="Skip complexity estimation for derived plan items (for faster derivation)",
    ),
    parallel: bool = typer.Option(
        False,
        "--parallel",
        help="Enable parallel execution of independent plan items (uses parallel_group assignments)",
    ),
    skip_tier_check: bool = typer.Option(
        False,
        "--skip-tier-check",
        help="Skip server tier mismatch validation (proceed despite client/server tier disagreement)",
    ),
    skip_explore: bool = typer.Option(
        False,
        "--skip-explore",
        help="Skip automatic codebase exploration before derivation (FEAT-AUTO-EXPLORE-001)",
    ),
    force_explore: bool = typer.Option(
        False,
        "--force-explore",
        help="Force codebase exploration even for simple objectives (FEAT-AUTO-EXPLORE-001)",
    ),
    plan_mode: str | None = typer.Option(
        None,
        "--plan-mode",
        help="Planning mode: auto (default), quick, standard, or thorough",
    ),
    local: bool = typer.Option(
        False,
        "--local",
        help="Use local Firebase emulator instead of production (requires emulators running)",
    ),
) -> None:
    """Run AI-orchestrated workflow for an objective.

    LLM fast path:
        1. obra models        # Discover provider/model names
        2. obra help domains  # Discover installed domains
        3. obra help run      # Review flags
        4. obra run --domain <domain> "objective"

    Examples:
        obra run "Add user authentication"
        obra run "Fix the failing tests" --dir /my/project
        obra run "Refactor payment module" --stream -vv
        obra run --domain software "Implement feature X" --model opus
        obra run --domain business "Review invoice workflow" --model gemini-2.5-flash
        obra run "Improve tests" --impl-provider openai --model gpt-5.2
        obra run "Complex refactor" --reasoning-level high
        obra run --plan-only "Design API endpoints"
        obra run "Test feature" --isolated  # Isolated session
        obra run --continue-from abc123  # Continue from failed session
        obra run --resume abc123 --from story-0  # Re-run preflight setup, then resume
        obra run "Quick fix" --no-extended-thinking  # Disable extended thinking
        obra run "Multi-task feature" --parallel  # Enable parallel execution
        obra run "Test feature" --local  # Use local Firebase emulator

    Environment Variables:
        OBRA_MODEL          Default model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        OBRA_FAST_MODEL     Fast tier override (e.g., haiku, gpt-5.1-codex-mini)
        OBRA_HIGH_MODEL     High tier override (e.g., opus, gpt-5.2)
        OBRA_PROVIDER       Default provider (anthropic, openai, google)
        OBRA_REASONING_LEVEL Default reasoning level (off, low, medium, high, maximum)
        OBRA_ISOLATED       Enable/disable isolation (true/false)

    Domain Resolution:
        `obra run` needs an explicit resolved domain from --domain, project
        config, or layered config. If none resolve, the run fails before
        session creation. Use `obra help domains` to inspect available domains.

    Precedence: CLI flags > environment variables > config file
    """
    verbose = _resolve_command_verbosity(ctx, verbose)

    # Display startup banner
    print_banner()
    console.print("📺 Logs: run 'obra logs viewer' for live session logs", style="cyan")
    console.print()

    _run_derive(
        **prepare_run_invocation(
            objective=objective,
            working_dir=working_dir,
            project_id=project_id,
            domain=domain,
            resume_session=resume_session,
            continue_from=continue_from,
            resume_from=resume_from,
            rerun_setup=rerun_setup,
            plan_id=plan_id,
            plan_file=plan_file,
            model=model,
            fast_model=fast_model,
            high_model=high_model,
            impl_provider=impl_provider,
            reasoning_level=reasoning_level,
            no_extended_thinking=no_extended_thinking,
            verbose=verbose,
            stream=stream,
            plan_only=plan_only,
            permissive=permissive,
            defaults_json=defaults_json,
            no_closeout=no_closeout,
            skip_intent=skip_intent,
            review_intent=review_intent,
            enrich=enrich,
            no_enrich=no_enrich,
            isolated=isolated,
            no_isolated=no_isolated,
            full_review=full_review,
            skip_review=skip_review,
            review_agents=review_agents,
            with_security=with_security,
            with_testing=with_testing,
            with_docs=with_docs,
            with_code_quality=with_code_quality,
            no_security=no_security,
            no_testing=no_testing,
            no_docs=no_docs,
            no_code_quality=no_code_quality,
            review_format=review_format,
            review_quiet=review_quiet,
            review_summary_only=review_summary_only,
            fail_on_p1=fail_on_p1,
            fail_on_p2=fail_on_p2,
            review_timeout=review_timeout,
            auto_report=auto_report,
            yes=yes,
            mock_credentials=mock_credentials,
            skip_git_check=skip_git_check,
            auto_init_git=auto_init_git,
            skip_quality_check=skip_quality_check,
            skip_complexity_check=skip_complexity_check,
            parallel=parallel,
            skip_tier_check=skip_tier_check,
            skip_explore=skip_explore,
            force_explore=force_explore,
            plan_mode=plan_mode,
            local=local,
        )
    )



def _should_isolate(
    isolated: bool | None = None,
    no_isolated: bool | None = None,
) -> bool:
    """Determine whether to run in isolated mode.

    Resolution precedence (highest to lowest):
    1. CLI flags: --isolated (True) or --no-isolated (False)
    2. Environment variable: OBRA_ISOLATED=true/false
    3. CI environment: CI=true enables isolation automatically
    4. Config file: ~/.obra/config-layers/01-user.yaml agent.isolated_mode
    5. Default: True (isolation enabled for reproducibility)

    Args:
        isolated: CLI --isolated flag value (True if flag present)
        no_isolated: CLI --no-isolated flag value (True if flag present)

    Returns:
        True if isolation should be enabled, False otherwise
    """
    # Priority 1: CLI flags (--isolated or --no-isolated)
    if isolated:
        return True
    if no_isolated:
        return False

    # Priority 2: Environment variable OBRA_ISOLATED
    env_isolated = os.environ.get("OBRA_ISOLATED", "").lower()
    if env_isolated in ("true", "1", "yes"):
        return True
    if env_isolated in ("false", "0", "no"):
        return False

    # Priority 3: CI environment auto-enable
    # Common CI environment variables: CI, GITHUB_ACTIONS, GITLAB_CI, CIRCLECI, etc.
    ci_env = os.environ.get("CI", "").lower()
    if ci_env in ("true", "1", "yes"):
        return True

    # Priority 4: Config file (agent.isolated_mode)
    from obra.config import get_isolated_mode

    config_isolated = get_isolated_mode()
    if config_isolated is True:
        return True
    if config_isolated is False:
        return False

    # Priority 5: Default (isolation enabled for reproducibility)
    return True


def _update_llm_config_with_notification(
    role: str,
    provider: str,
    auth_method: str,
    model: str = "default",
    reasoning_level: str = "medium",
) -> None:
    """Update LLM config and display tier auto-update notification if provider changed.

    This helper demonstrates the proper pattern for calling set_llm_config() and
    displaying the tier auto-update notification (FEAT-LLM-TIERS-SPLIT-001).

    When a role's provider changes, tiers are automatically updated to match the new
    provider's model names. The notification should be displayed to inform the user.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai, google, ollama)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)
        reasoning_level: Abstract reasoning level (off, low, medium, high, maximum)

    Example:
        >>> _update_llm_config_with_notification("orchestrator", "openai", "oauth")
        # If provider changed, displays: "Updated orchestrator tiers to match OpenAI: ..."
    """
    from obra.config import set_llm_config

    notification = set_llm_config(role, provider, auth_method, model, reasoning_level)
    if notification:
        console.print()
        console.print(f"[cyan]ℹ[/cyan]  {notification}")
        console.print()

def _parse_review_agents_csv(review_agents: str | None) -> list[str] | None:
    """Compatibility wrapper for review-agent CSV parsing."""
    from obra.cli.run_support.derive_inputs import _parse_review_agents_csv as support_impl

    return support_impl(review_agents)

def _load_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Compatibility wrapper for planning-config loading."""
    from obra.cli.run_support.derive_inputs import _load_planning_config as support_impl

    return support_impl(project_path)

def _normalize_objective_preview(objective: str, max_len: int = MAX_OBJECTIVE_PREVIEW) -> str:
    """Return a single-line objective preview with optional truncation marker."""
    collapsed = re.sub(r"\s+", " ", objective).strip()
    if len(collapsed) <= max_len:
        return collapsed
    trimmed = collapsed[: max_len - 3].rstrip()
    return f"{trimmed}... (truncated)"


def _validate_project_id_against_server(
    client: Any,
    project_id: str,
    source: str,
) -> str:
    """Compatibility wrapper for project-id validation."""
    from obra.cli.run_support.derive_inputs import _validate_project_id_against_server as support_impl

    return support_impl(client, project_id, source)

def _resolve_and_validate_project_id(
    client: Any,
    cli_project_id: str | None,
) -> str:
    """Compatibility wrapper for project-id resolution."""
    from obra.cli.run_support.derive_inputs import _resolve_and_validate_project_id as support_impl

    return support_impl(client, cli_project_id)


def _build_review_config_from_cli(
    *,
    full_review: bool,
    skip_review: bool,
    review_agents: str | None,
    with_security: bool,
    with_testing: bool,
    with_docs: bool,
    with_code_quality: bool,
    no_security: bool,
    no_testing: bool,
    no_docs: bool,
    no_code_quality: bool,
    review_format: str | None,
    review_quiet: bool,
    review_summary_only: bool,
    fail_on_p1: bool,
    fail_on_p2: bool,
    review_timeout: int | None,
    project_path: Path | None = None,
) -> ReviewConfig:
    """Compatibility wrapper for review-config resolution."""
    from obra.cli.run_support.derive_inputs import _build_review_config_from_cli as support_impl

    return support_impl(
        full_review=full_review,
        skip_review=skip_review,
        review_agents=review_agents,
        with_security=with_security,
        with_testing=with_testing,
        with_docs=with_docs,
        with_code_quality=with_code_quality,
        no_security=no_security,
        no_testing=no_testing,
        no_docs=no_docs,
        no_code_quality=no_code_quality,
        review_format=review_format,
        review_quiet=review_quiet,
        review_summary_only=review_summary_only,
        fail_on_p1=fail_on_p1,
        fail_on_p2=fail_on_p2,
        review_timeout=review_timeout,
        project_path=project_path,
    )

def _detect_input_quality_issues(objective: str) -> list[str]:
    """Compatibility wrapper for objective-quality heuristics."""
    from obra.cli.run_support.derive_inputs import _detect_input_quality_issues as support_impl

    return support_impl(objective)


def _show_input_quality_warning(issues: list[str]) -> None:
    """Compatibility wrapper for input-quality warnings."""
    from obra.cli.run_support.derive_inputs import _show_input_quality_warning as support_impl

    support_impl(issues)


def _plan_search_paths(plan_id: str, base_dir: Path) -> list[Path]:
    """Compatibility wrapper for plan search-path resolution."""
    from obra.cli.run_support.planning_context import _plan_search_paths as support_impl

    return support_impl(plan_id, base_dir)


def _format_plan_search_paths(plan_id: str, base_dir: Path) -> list[str]:
    """Compatibility wrapper for formatted plan search paths."""
    from obra.cli.run_support.planning_context import _format_plan_search_paths as support_impl

    return support_impl(plan_id, base_dir)


def _extract_plan_context(plan_data: Any, source: str) -> dict[str, Any]:
    """Compatibility wrapper for plan-context extraction."""
    from obra.cli.run_support.planning_context import _extract_plan_context as support_impl

    return support_impl(plan_data, source)


def _load_plan_context_from_file(plan_path: Path) -> dict[str, Any]:
    """Compatibility wrapper for loading plan context from disk."""
    from obra.cli.run_support.planning_context import _load_plan_context_from_file as support_impl

    return support_impl(plan_path)


def _install_imported_plan_handler(
    orchestrator: Any,
    plan_context: dict[str, Any] | None,
) -> None:
    """Compatibility wrapper for imported-plan handler installation."""
    from obra.cli.run_support.planning_context import _install_imported_plan_handler as support_impl

    support_impl(orchestrator, plan_context)


def _print_plan_lookup_error(plan_id: str, base_dir: Path) -> None:
    """Compatibility wrapper for missing-plan lookup errors."""
    from obra.cli.run_support.planning_context import _print_plan_lookup_error as support_impl

    support_impl(plan_id, base_dir)


def _find_plan_yaml(plan_id: str, base_dir: Path | None = None) -> Path | None:
    """Compatibility wrapper for plan-file discovery."""
    from obra.cli.run_support.planning_context import _find_plan_yaml as support_impl

    return support_impl(plan_id, base_dir)


def _run_derive(
    objective: str | None,
    working_dir: Path | None = None,
    project_id: str | None = None,
    domain: str | None = None,
    resume_session: str | None = None,
    continue_from: str | None = None,
    resume_from: str | None = None,
    rerun_setup: bool = False,
    plan_id: str | None = None,
    plan_file: Path | None = None,
    model: str | None = None,
    fast_model: str | None = None,
    high_model: str | None = None,
    impl_provider: str | None = None,
    reasoning_level: str | None = None,
    verbose: int = 0,
    stream: bool = False,
    plan_only: bool = False,
    permissive: bool = False,
    defaults_json: bool = False,
    no_closeout: bool = False,
    skip_intent: bool = False,
    review_intent: bool = False,
    enrich: bool = False,
    no_enrich: bool = False,
    isolated: bool | None = None,
    no_isolated: bool | None = None,
    full_review: bool = False,
    skip_review: bool = False,
    review_agents: str | None = None,
    with_security: bool = False,
    with_testing: bool = False,
    with_docs: bool = False,
    with_code_quality: bool = False,
    no_security: bool = False,
    no_testing: bool = False,
    no_docs: bool = False,
    no_code_quality: bool = False,
    review_format: str | None = None,
    review_quiet: bool = False,
    review_summary_only: bool = False,
    fail_on_p1: bool = False,
    fail_on_p2: bool = False,
    review_timeout: int | None = None,
    auto_report: bool = False,
    yes: bool = False,
    mock_credentials: bool = False,
    skip_git_check: bool = False,
    auto_init_git: bool = False,
    skip_quality_check: bool = False,
    skip_complexity_check: bool = False,
    parallel: bool = False,
    skip_tier_check: bool = False,
    from_step: int | None = None,
    cascade: bool = False,
    work_type: str | None = None,
    skip_explore: bool = False,
    force_explore: bool = False,
    plan_mode: str | None = None,
) -> None:
    """Compatibility wrapper for the extracted run/derive session flow."""
    from obra.cli.run_support.session_flow import run_derive as support_impl

    support_impl(
        objective=objective,
        working_dir=working_dir,
        project_id=project_id,
        domain=domain,
        resume_session=resume_session,
        continue_from=continue_from,
        resume_from=resume_from,
        rerun_setup=rerun_setup,
        plan_id=plan_id,
        plan_file=plan_file,
        model=model,
        fast_model=fast_model,
        high_model=high_model,
        impl_provider=impl_provider,
        reasoning_level=reasoning_level,
        verbose=verbose,
        stream=stream,
        plan_only=plan_only,
        permissive=permissive,
        defaults_json=defaults_json,
        no_closeout=no_closeout,
        skip_intent=skip_intent,
        review_intent=review_intent,
        enrich=enrich,
        no_enrich=no_enrich,
        isolated=isolated,
        no_isolated=no_isolated,
        full_review=full_review,
        skip_review=skip_review,
        review_agents=review_agents,
        with_security=with_security,
        with_testing=with_testing,
        with_docs=with_docs,
        with_code_quality=with_code_quality,
        no_security=no_security,
        no_testing=no_testing,
        no_docs=no_docs,
        no_code_quality=no_code_quality,
        review_format=review_format,
        review_quiet=review_quiet,
        review_summary_only=review_summary_only,
        fail_on_p1=fail_on_p1,
        fail_on_p2=fail_on_p2,
        review_timeout=review_timeout,
        auto_report=auto_report,
        yes=yes,
        mock_credentials=mock_credentials,
        skip_git_check=skip_git_check,
        auto_init_git=auto_init_git,
        skip_quality_check=skip_quality_check,
        skip_complexity_check=skip_complexity_check,
        parallel=parallel,
        skip_tier_check=skip_tier_check,
        from_step=from_step,
        cascade=cascade,
        work_type=work_type,
        skip_explore=skip_explore,
        force_explore=force_explore,
        plan_mode=plan_mode,
    )



# =============================================================================
# Derive Command (FEAT-AUTO-INTENT-001 S3.T0, S3.T1)
# =============================================================================



@handle_encoding_errors
@require_terms_accepted
def derive(
    ctx: typer.Context,
    objective: str | None = typer.Argument(
        None,
        help="Objective to derive (uses active intent if not provided)",
    ),
    working_dir: str | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
    ),
    project_id: str | None = typer.Option(
        None,
        "--project",
        help="Project ID override (optional)",
    ),
    domain: str | None = typer.Option(
        None,
        "--domain",
        help="Domain module name (e.g., software, business)",
    ),
    continue_intent: bool = typer.Option(
        False,
        "--continue",
        help="Continue with active intent (explicit flag, S3.T1)",
    ),
    resume_session: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume an existing session by ID",
    ),
    continue_from: str | None = typer.Option(
        None,
        "--continue-from",
        "-c",
        help="Continue from a failed/escalated session (creates new session, skips completed tasks)",
    ),
    plan_id: str | None = typer.Option(
        None,
        "--plan-id",
        help=(
            "Use an uploaded plan by ID (from 'obra plans upload'). "
            "Requires local YAML at docs/development/{PLAN_ID}_MACHINE_PLAN.json."
        ),
    ),
    plan_file: Path | None = typer.Option(
        None,
        "--plan-file",
        help="Upload and use a plan file in one step",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Implementation model (e.g., opus, gpt-5.2, gemini-2.5-flash)",
    ),
    fast_model: str | None = typer.Option(
        None,
        "--fast-model",
        help="Fast tier model override (used for extraction and quick validation)",
    ),
    high_model: str | None = typer.Option(
        None,
        "--high-model",
        help="High tier model override (used for complex reasoning)",
    ),
    impl_provider: str | None = typer.Option(
        None,
        "--impl-provider",
        "-p",
        help="Implementation provider (anthropic, openai, google). Requires provider CLI (claude/codex/gemini).",
    ),
    reasoning_level: str | None = typer.Option(
        None,
        "--reasoning-level",
        "-t",
        help="Thinking/reasoning level (off, low, medium, high, maximum)",
    ),
    no_extended_thinking: bool = typer.Option(
        False,
        "--no-extended-thinking",
        help="Disable extended thinking for derivation (equivalent to --reasoning-level off)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        "-s",
        help="Enable real-time LLM output streaming",
    ),
    plan_only: bool = typer.Option(
        False,
        "--plan-only",
        help="Create plan without executing (client-side exit after planning)",
    ),
    permissive: bool = typer.Option(
        False,
        "--permissive",
        help="Bypass P1 planning blockers (proceed with warnings)",
    ),
    defaults_json: bool = typer.Option(
        False,
        "--defaults-json",
        help="Print proposed defaults as JSON and exit when refinement is blocked",
    ),
    no_closeout: bool = typer.Option(
        False,
        "--no-closeout",
        help="Skip close-out story injection",
    ),
    skip_intent: bool = typer.Option(
        False,
        "--skip-intent",
        help="Skip intent generation for vague objectives (S2.T3)",
    ),
    review_intent: bool = typer.Option(
        False,
        "--review-intent",
        help="Display generated intent and prompt for approval before derive (S2.T4)",
    ),
    _enrich: bool = typer.Option(
        False,
        "--enrich",
        help="Force intent enrichment (requires planning.enrichment.enabled)",
    ),
    _no_enrich: bool = typer.Option(
        False,
        "--no-enrich",
        help="Skip intent enrichment even when enabled",
    ),
    isolated: bool | None = typer.Option(
        None,
        "--isolated",
        help="Run agent in isolated environment (prevents reading host CLI config)",
    ),
    no_isolated: bool | None = typer.Option(
        None,
        "--no-isolated",
        help="Disable isolation (use host CLI config, even in CI)",
    ),
    full_review: bool = typer.Option(
        False,
        "--full-review",
        help="Run all review agents (overrides auto-detection)",
    ),
    skip_review: bool = typer.Option(
        False,
        "--skip-review",
        help="Skip the review phase entirely",
    ),
    review_agents: str | None = typer.Option(
        None,
        "--review-agents",
        help=f"Comma-separated review agents to run ({', '.join(ALLOWED_AGENTS)})",
    ),
    with_security: bool = typer.Option(
        False,
        "--with-security",
        help="Add the security review agent",
    ),
    with_testing: bool = typer.Option(
        False,
        "--with-testing",
        help="Add the testing review agent",
    ),
    with_docs: bool = typer.Option(
        False,
        "--with-docs",
        help="Add the docs review agent",
    ),
    with_code_quality: bool = typer.Option(
        False,
        "--with-code-quality",
        help="Add the code_quality review agent",
    ),
    no_security: bool = typer.Option(
        False,
        "--no-security",
        help="Remove the security review agent",
    ),
    no_testing: bool = typer.Option(
        False,
        "--no-testing",
        help="Remove the testing review agent",
    ),
    no_docs: bool = typer.Option(
        False,
        "--no-docs",
        help="Remove the docs review agent",
    ),
    no_code_quality: bool = typer.Option(
        False,
        "--no-code-quality",
        help="Remove the code_quality review agent",
    ),
    review_format: str | None = typer.Option(
        None,
        "--review-format",
        help="Review output format (text or json)",
        show_choices=True,
    ),
    review_quiet: bool = typer.Option(
        False,
        "--review-quiet",
        help="Suppress review output",
    ),
    review_summary_only: bool = typer.Option(
        False,
        "--review-summary-only",
        help="Show only review summary counts",
    ),
    fail_on_p1: bool = typer.Option(
        False,
        "--fail-on-p1",
        help="Exit with status 1 when P1 findings are present",
    ),
    fail_on_p2: bool = typer.Option(
        False,
        "--fail-on-p2",
        help="Exit with status 1 when P1 or P2 findings are present",
    ),
    review_timeout: int | None = typer.Option(
        None,
        "--review-timeout",
        min=1,
        help="Per-agent review timeout in seconds",
    ),
    auto_report: bool = typer.Option(
        False,
        "--auto-report",
        help="Automatically submit bug reports on failure (no prompt, for CI/CD)",
    ),
    skip_git_check: bool = typer.Option(
        False,
        "--skip-git-check",
        help="Skip git repository validation (GIT-HARD-001)",
    ),
    auto_init_git: bool = typer.Option(
        False,
        "--auto-init-git",
        help="Auto-initialize git repository if not present (GIT-HARD-001)",
    ),
    skip_quality_check: bool = typer.Option(
        False,
        "--skip-quality-check",
        help="Skip UserPlan quality assessment (for debugging, testing, or high-confidence plans)",
    ),
    skip_complexity_check: bool = typer.Option(
        False,
        "--skip-complexity-check",
        help="Skip complexity estimation for derived plan items (for faster derivation)",
    ),
    force_empty: bool = typer.Option(
        False, "--force-empty", help="Force EMPTY project state (new/minimal project)"
    ),
    force_existing: bool = typer.Option(
        False,
        "--force-existing",
        help="Force EXISTING project state (established codebase)",
    ),
    from_step: int | None = typer.Option(
        None,
        "--from-step",
        "-f",
        min=1,
        help="Re-derive from step N onwards (1-indexed). Steps 1 to N-1 retain existing derivation.",
    ),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        help="Mark sibling steps after the edited/re-derived step as STALE for staleness propagation.",
    ),
    work_type: str | None = typer.Option(
        None,
        "--work-type",
        "-w",
        help=(
            f"Override automatic work type detection. "
            f"Valid types: {', '.join(VALID_WORK_TYPES[:-1])}. "
            f"When provided, bypasses auto-detection and uses the specified work type."
        ),
    ),
    skip_explore: bool = typer.Option(
        False,
        "--skip-explore",
        help="Skip automatic codebase exploration before derivation (FEAT-AUTO-EXPLORE-001)",
    ),
    force_explore: bool = typer.Option(
        False,
        "--force-explore",
        help="Force codebase exploration even for simple objectives (FEAT-AUTO-EXPLORE-001)",
    ),
    local: bool = typer.Option(
        False,
        "--local",
        help="Use local Firebase emulator instead of production (requires emulators running)",
    ),
) -> None:
    """Derive execution plan from objective or active intent.

    Obra's derive command creates an execution plan from your objective.
    If you don't provide an objective, it will use the active intent
    for the current project (created via 'obra intent new').

    Examples:
        obra derive "add user authentication"
        obra derive                              # Uses active intent
        obra derive --continue                   # Explicit continue with active intent
        obra derive "refactor API" --plan-only
        obra derive --stream -vv
        obra derive --from-step 3                # Re-derive from step 3 onwards
        obra derive --no-extended-thinking       # Disable extended thinking
        obra derive "add auth" --local           # Use local Firebase emulator

    With active intent:
        obra intent new "add auth"
        obra derive                              # Uses "add auth" intent
        obra derive --continue                   # Explicit form

    Incremental re-derivation:
        obra derive --from-step N                # Re-derive steps N, N+1, N+2, ...
                                                 # Steps 1 to N-1 retain existing derivation
        obra derive --from-step N --cascade      # Re-derive step N and mark steps after N as STALE

    Environment Variables:
        OBRA_MODEL          Default model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        OBRA_FAST_MODEL     Fast tier override (e.g., haiku, gpt-5.1-codex-mini)
        OBRA_HIGH_MODEL     High tier override (e.g., opus, gpt-5.2)
        OBRA_PROVIDER       Default provider (anthropic, openai, google)
        OBRA_REASONING_LEVEL Default reasoning level (off, low, medium, high, maximum)
        OBRA_ISOLATED       Enable/disable isolation (true/false)

    Precedence: CLI flags > environment variables > config file

    Reference: FEAT-AUTO-INTENT-001 S3.T0, S3.T1
    """
    verbose = _resolve_command_verbosity(ctx, verbose)
    _run_derive(
        **prepare_derive_invocation(
            objective=objective,
            working_dir=working_dir,
            project_id=project_id,
            domain=domain,
            continue_intent=continue_intent,
            resume_session=resume_session,
            continue_from=continue_from,
            plan_id=plan_id,
            plan_file=plan_file,
            model=model,
            fast_model=fast_model,
            high_model=high_model,
            impl_provider=impl_provider,
            reasoning_level=reasoning_level,
            no_extended_thinking=no_extended_thinking,
            verbose=verbose,
            stream=stream,
            plan_only=plan_only,
            permissive=permissive,
            defaults_json=defaults_json,
            no_closeout=no_closeout,
            skip_intent=skip_intent,
            review_intent=review_intent,
            isolated=isolated,
            no_isolated=no_isolated,
            full_review=full_review,
            skip_review=skip_review,
            review_agents=review_agents,
            with_security=with_security,
            with_testing=with_testing,
            with_docs=with_docs,
            with_code_quality=with_code_quality,
            no_security=no_security,
            no_testing=no_testing,
            no_docs=no_docs,
            no_code_quality=no_code_quality,
            review_format=review_format,
            review_quiet=review_quiet,
            review_summary_only=review_summary_only,
            fail_on_p1=fail_on_p1,
            fail_on_p2=fail_on_p2,
            review_timeout=review_timeout,
            auto_report=auto_report,
            skip_git_check=skip_git_check,
            auto_init_git=auto_init_git,
            skip_quality_check=skip_quality_check,
            skip_complexity_check=skip_complexity_check,
            force_empty=force_empty,
            force_existing=force_existing,
            from_step=from_step,
            cascade=cascade,
            work_type=work_type,
            skip_explore=skip_explore,
            force_explore=force_explore,
            local=local,
        )
    )




# =============================================================================
# Verify Command
# =============================================================================



@handle_encoding_errors
def verify(
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Attempt automatic verification (best-effort file checks)",
    ),
    intent_id: str | None = typer.Option(
        None,
        "--intent",
        help="Verify specific intent ID (default: active intent)",
    ),
) -> None:
    """Verify completion against active intent acceptance criteria.

    Checks the current project state against the acceptance criteria
    defined in the active intent. Generates a verification report
    and optionally archives the intent if all criteria pass.

    Examples:
        obra verify              # Verify active intent (manual review)
        obra verify --auto       # Attempt automatic verification
        obra verify --intent add-auth  # Verify specific intent
    """
    from pathlib import Path

    from obra.intent.storage import IntentStorage
    from obra.intent.verification import (
        archive_intent,
        save_verification_report,
        verify_completion,
    )

    try:
        storage = IntentStorage()
        working_dir = Path.cwd()
        project = storage.get_project_id(working_dir)

        # Load intent to verify
        if intent_id:
            # Resolve partial ID
            resolved_id = storage.resolve_id(intent_id, project)
            if not resolved_id:
                console.print()
                print_error(f"Intent not found: {intent_id}")
                console.print()
                console.print("  [dim]Use 'obra intent list' to see available intents[/dim]")
                console.print()
                raise typer.Exit(1)
            intent = storage.load(resolved_id, project)
            if not intent:
                console.print()
                print_error(f"Failed to load intent: {resolved_id}")
                console.print()
                raise typer.Exit(1)
        else:
            # Use active intent
            intent = storage.load_active(project)
            if not intent:
                console.print()
                print_error("No active intent to verify")
                console.print()
                console.print("  [dim]Use 'obra intent list' to see available intents[/dim]")
                console.print()
                console.print('  [dim]Or create one with: obra derive "objective"[/dim]')
                console.print()
                raise typer.Exit(1)

        console.print()
        console.print(f"[bold]Verifying Intent:[/bold] {intent.id}")
        console.print(f"[dim]Problem: {intent.problem_statement}[/dim]")
        console.print()

        # Run verification
        report = verify_completion(
            intent,
            project_dir=working_dir if auto else None,
            auto_verify=auto,
        )

        # Save verification report
        report_path = save_verification_report(report)

        # Display results
        status_emoji = {
            "passed": glyphs.success,
            "failed": glyphs.failure,
            "partial": glyphs.warning,
            "skipped": "o",
        }
        emoji = status_emoji.get(report.status.value, "?")

        console.print(f"[bold]Verification Status:[/bold] {emoji} {report.status.value.upper()}")
        console.print()
        console.print(f"  {report.summary}")
        console.print()

        if report.results:
            console.print("[bold]Acceptance Criteria:[/bold]")
            console.print()
            for result in report.results:
                check = (
                    f"[green]{glyphs.success}[/green]"
                    if result.passed
                    else f"[red]{glyphs.failure}[/red]"
                )
                console.print(f"  {check} {result.criterion}")
                if result.notes:
                    console.print(f"    [dim]{result.notes}[/dim]")
            console.print()

        console.print("[bold]Statistics:[/bold]")
        console.print(f"  Total: {report.total_criteria}")
        console.print(f"  Passed: {report.passed_criteria}")
        console.print(f"  Failed: {report.failed_criteria}")
        console.print()

        console.print(f"[dim]Report saved: {report_path}[/dim]")
        console.print()

        # If all criteria passed, offer to archive
        if report.passed:
            console.print("[bold green]All acceptance criteria met![/bold green]")
            console.print()

            # Auto-archive the intent
            if archive_intent(intent.id, project, storage):
                console.print("[dim]Intent archived and marked complete[/dim]")
                console.print()
            else:
                console.print("[dim yellow]Warning: Failed to archive intent[/dim]")
                console.print()
        else:
            console.print(
                "[yellow]Some criteria not yet met. Continue working on this intent.[/yellow]"
            )
            console.print()
            console.print("  [dim]Use: obra derive --continue[/dim]")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Verification failed")
        raise typer.Exit(1) from e



# =============================================================================
# Autonomous Runner
# =============================================================================



@handle_encoding_errors
def auto(
    plan: str = typer.Option(
        ...,
        "--plan",
        "-p",
        help="WORK_ID for the machine plan (e.g., AUTO-RUN-001)",
    ),
    max_stories: int | None = typer.Option(
        None,
        "--max-stories",
        "-m",
        help="Maximum number of stories to execute (default: all)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show execution plan without running stories",
    ),
) -> None:
    """Execute multi-story workplans autonomously.

    The auto-runner executes stories sequentially from MACHINE_PLAN.json
    without continuous LLM attention, solving the completion bias problem.

    Examples:
        obra auto --plan AUTO-RUN-001              # Execute all stories
        obra auto --plan AUTO-RUN-001 --max-stories 2  # Execute 2 stories
        obra auto --plan AUTO-RUN-001 --dry-run    # Show plan only

    Story Execution:
        Each story runs as a separate `obra run` session.
        The runner updates story status in the machine plan after completion.

    Error Handling:
        - Transient errors: Automatic retry (configurable)
        - Breakpoints: Halt execution for human intervention
        - Failed stories: Skip and continue (or escalate based on config)

    Configuration:
        Set in ~/.obra/config-layers/01-user.yaml or config/default_config.yaml:
            auto:
              enabled: true
              retry_count: 3
              retry_delay_seconds: 5
              error_assessor: null  # null=disabled, "fast"=use fast-tier, or model name
              escalate_on_skip: true

    Related Commands:
        - obra run: Execute a single story objective
        - obra derive: Create execution plans from objectives
    """
    import yaml

    from obra.auto.runner import AutoRunner

    # Build plan path
    plan_path = Path.cwd() / "docs" / "development" / f"{plan}_MACHINE_PLAN.json"

    if not plan_path.exists():
        print_error(f"Machine plan not found: {plan_path}")
        print_info("Expected location: docs/development/{WORK_ID}_MACHINE_PLAN.json")
        raise typer.Exit(1)

    if dry_run:
        print_info(f"[DRY-RUN] Autonomous execution plan for {plan}")
        print_info(f"Plan file: {plan_path}")
        print()

    try:
        # Load configuration from default config file
        # Note: obra package uses direct YAML loading, not src.core.config.Config
        config_path = Path(__file__).parent.parent / "config" / "default_config.yaml"
        if not config_path.exists():
            # Fallback for installed package (config not bundled)
            logger.warning(f"Config file not found at {config_path}, using defaults")
            auto_config = {}
        else:
            config = yaml.safe_load(config_path.read_text())
            auto_config = config.get("orchestration", {}).get("auto", {})

        # Extract configuration values
        retry_count = auto_config.get("retry_count", 2)
        retry_delay = auto_config.get("retry_delay_seconds", 30)
        escalate_on_skip = auto_config.get("escalate_on_skip", True)
        error_assessor_config = auto_config.get("error_assessor")

        # Create error assessor if configured
        error_assessor = None
        if error_assessor_config:
            from obra.auto.assessor import ErrorAssessor
            from obra.config import get_llm_config

            # Resolve model name (handle "fast" tier)
            # "fast" maps to haiku for cost-effective error assessment
            model_name = "haiku" if error_assessor_config == "fast" else error_assessor_config

            # Get LLM config from obra.config (client config)
            # This gives us provider, model, auth info for CLI subprocess invocation
            llm_config = get_llm_config()

            # Override model with the assessor-specific model
            if llm_config:
                llm_config = dict(llm_config)  # Make a copy
                llm_config["model"] = model_name
            else:
                # Fallback if no LLM config available
                llm_config = {"provider": "anthropic", "model": model_name}

            error_assessor = ErrorAssessor(enabled=True, llm_config=llm_config)
            logger.info(f"Error assessor enabled with model: {model_name}")

        runner = AutoRunner(
            str(plan_path),
            retry_count=retry_count,
            retry_delay_seconds=retry_delay,
            escalate_on_skip=escalate_on_skip,
            error_assessor=error_assessor,
        )
        exit_code = runner.run(max_stories=max_stories, dry_run=dry_run)

        if exit_code == 0:
            print_success("Autonomous execution completed successfully.")
        else:
            print_error(f"Autonomous execution failed with exit code {exit_code}")
            raise typer.Exit(exit_code)

    except KeyboardInterrupt:
        print_warning("\nAutonomous execution interrupted by user.")
        print_info("Current story state has been saved to plan.")
        raise typer.Exit(0) from None
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Autonomous execution error: {e}")
        logger.exception("Auto-runner failed")
        raise typer.Exit(1) from e
