"""CLI commands for the Obra hybrid orchestration package.

This module provides all CLI commands for the unified obra package:
- Main workflow: obra run "objective" to start orchestrated tasks
- status: Check session status
- run --resume: Resume an interrupted session
- login/logout/whoami: Authentication commands
- config: Configuration management
- docs: Access local documentation
- doctor: Run health checks (includes version and server compatibility)
- plans: Manage plan files (upload, list, delete) for SaaS

Usage:
    $ obra --version
    $ obra run "Add user authentication"
    $ obra run --plan-id abc123 "Execute uploaded plan"
    $ obra run --plan-file plan.yaml "Upload and execute plan"
    $ obra status
    $ obra status <session_id>
    $ obra run --resume <session_id>
    $ obra login
    $ obra logout
    $ obra whoami
    $ obra config
    $ obra docs
    $ obra doctor
    $ obra plans upload path/to/plan.yaml
    $ obra plans list
    $ obra plans delete <plan_id>

Note: For local plan validation, use 'dobra plan validate' instead.

Reference: EPIC-HYBRID-001 Story S10: CLI Commands
          FEAT-PLAN-IMPORT-OBRA-001: Plan File Import
"""

import contextlib
import json
import os

# ISSUE-DOBRA-008: Configure UTF-8 console encoding FIRST, before any imports
# This is the industry-standard solution for Windows console Unicode issues.
import sys
from datetime import UTC, datetime  # noqa: F401
from http import HTTPStatus  # noqa: F401

if hasattr(sys.stdout, "reconfigure") and sys.stdout is not None:
    with contextlib.suppress(Exception):
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
if hasattr(sys.stderr, "reconfigure") and sys.stderr is not None:
    with contextlib.suppress(Exception):
        sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
os.environ.setdefault("PYTHONIOENCODING", "utf-8:backslashreplace")

import logging
import platform
import re  # noqa: F401
import time  # noqa: F401
from pathlib import Path
from typing import Any, Callable, cast  # noqa: F401

import click
import typer
import yaml  # type: ignore[import-untyped]  # noqa: F401
from rich.table import Table

from obra import __version__
from obra.api.protocol import EscalationDecision, EscalationNotice, UserDecisionChoice  # noqa: F401

# Bootstrap safety: validate default_config.yaml exists before heavy imports.
# This fails fast with a clear error if installation is corrupted (S1.T2).
from obra.config.loaders import get_cli_retry_config, validate_default_schema

validate_default_schema()

from obra.cli.feedback import offer_bug_report
from obra.cli.lifecycle import (
    extract_lifecycle_status,
    format_lifecycle_capability_states,
)
from obra.cli_commands import UploadPlanCommand  # noqa: F401
from obra.config import (
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_REASONING_LEVEL,  # noqa: F401
    REASONING_LEVELS,  # noqa: F401
    infer_provider_from_model,  # noqa: F401
    load_config,  # noqa: F401
)
from obra.constants import KIBIBYTE
from obra.core.interrupts import (
    GracefulInterrupt,  # noqa: F401
    clear_interrupt_request,  # noqa: F401
    defer_interrupts,  # noqa: F401
)
from obra.display import (
    EscalationRenderer,
    ObservabilityConfig,  # noqa: F401
    ProgressEmitter,  # noqa: F401
    console,
    err_console,  # noqa: F401
    glyphs,
    handle_encoding_errors,
    print_banner,  # noqa: F401
    print_error,
    print_info,
    print_success,
    print_warning,
    set_runtime_verbosity,  # noqa: F401
)
from obra.display.closeout import (
    _build_closeout_context,  # noqa: F401
    _build_interrupted_closeout_context,  # noqa: F401
    _extract_completion_context,  # noqa: F401
    _log_closeout_rendered,  # noqa: F401
    _print_git_file_summary,  # noqa: F401
    build_closeout_message,  # noqa: F401
)
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import (
    APIError,
    AuthenticationError,  # noqa: F401
    ConfigurationError,
    ObraError,
)
from obra.exceptions import (
    ConnectionError as ObraConnectionError,  # noqa: F401
)
from obra.feedback.session_logger import (
    rename_session_logging,  # noqa: F401
    start_session_logging,  # noqa: F401
    stop_session_logging,  # noqa: F401
)
from obra.messages import get_message
from obra.messages.warnings import build_deprecation_warning  # noqa: F401
from obra.model_registry import resolve_quality_tier
from obra.review.config import ALLOWED_AGENTS, ReviewConfig, ReviewConfigCLIInputs  # noqa: F401
from obra.utils.git_utils import is_git_repository  # noqa: F401
from obra.utils.numeric import _safe_int
from obra.utils.obra_home import (
    legacy_notice_needed,
    mark_legacy_notice_shown,
    resolve_runtime_dir,
)
from obra.utils.terminal import is_headless as _is_headless  # noqa: F401
from obra.version_check import check_for_updates_async, try_auto_update

logger = logging.getLogger(__name__)

from obra.cli._shared import (
    _extract_plan_progress,
    _resolve_command_verbosity,
    require_authenticated_client,
    require_terms_accepted,
    setup_logging,
)
from obra.cli.interrupt import (
    _manager as _interrupt_manager,  # noqa: F401
)
from obra.cli.interrupt import (
    _print_bug_hint,
    _print_session_resume_hints,  # noqa: F401
)
from . import _doctor as doctor_commands
from . import _setup as setup_commands
from . import _status as status_commands

_status_load_local_session_runtime_impl = status_commands._load_local_session_runtime
_doctor_resolve_llm_config_impl = doctor_commands._resolve_doctor_llm_config


def _maybe_print_legacy_runtime_notice() -> None:
    """Emit a one-time notice when legacy runtime path is active."""
    selection = resolve_runtime_dir()
    if not legacy_notice_needed(selection):
        return

    print_warning(
        "Using legacy runtime directory "
        f"{selection.path}. The canonical runtime path is ~/.obra-runtime. "
        "Set OBRA_RUNTIME_DIR to override."
    )
    mark_legacy_notice_shown(selection)


# Enforce UTF-8 mode for consistent cross-platform behavior
os.environ.setdefault("PYTHONUTF8", "1")


# Create Typer app with custom error handling
app = typer.Typer(
    name="obra",
    help="""Obra - AI Orchestration for Autonomous Development

┌────────────────────────────────────────────────────────────────────────────┐
│  🤖 AI ASSISTANTS: Start with `obra briefing quick` for the LLM fast path │
│     Then use `obra models`, `obra help domains`, and `obra help run`      │
└────────────────────────────────────────────────────────────────────────────┘
Plan mode note: Atomic ideas can use `plan_mode=one_step` (see docs/development/backlog/ONE_STEP_PLAN.md) and log validations under `docs/quality/MANUAL_TESTING_LOG.json` so the planner keeps acceptance/tests/docs explicit.
""",
    no_args_is_help=True,  # Show help when no command specified
    rich_markup_mode="rich",
    epilog='Start with `obra briefing quick`, then use `obra models`, `obra help domains`, and `obra help run` before `obra run "<objective>"`.\nEncountered a problem? Run `obra bug "<description>"` to report it.',
)


# =============================================================================
# App Callback (Primary Invocation Pattern)
# =============================================================================


def version_callback(value: bool) -> None:
    """Print version and exit when --version is passed."""
    if value:
        print(f"obra {__version__}")
        raise typer.Exit()


@app.callback()
@handle_encoding_errors
def app_callback(
    ctx: typer.Context,
    _version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Reduce output (quiet mode)",
    ),
    session_config: str | None = typer.Option(
        None,
        "--session-config",
        help="Path to a session config layer file",
    ),
    verbose: int = typer.Option(
        1,
        "--verbose",
        "-v",
        count=True,
        help="Verbosity level (0-3, default=progress; use -v/-vv/-vvv)",
    ),
) -> None:
    """Obra - AI Orchestration for Autonomous Development.

    Run subcommands for specific operations, or use 'obra run' for orchestration.
    """
    ctx.obj = ctx.obj or {}
    if quiet:
        verbose = 0
    ctx.obj["verbose"] = verbose
    if session_config:
        os.environ["OBRA_SESSION_CONFIG"] = session_config
    setup_logging(verbose)

    # Ensure ~/.obra/README.md exists with helpful documentation
    # Only creates if missing, lightweight check
    from obra.utils.obra_home import ensure_obra_home_readme, get_obra_home

    readme_path = get_obra_home() / "README.md"
    if not readme_path.exists():
        try:
            ensure_obra_home_readme()
        except Exception:
            pass  # Non-critical, don't fail CLI startup


# =============================================================================
# Help Command (Industry Standard Pattern)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def help(
    ctx: typer.Context,
    command: str | None = typer.Argument(
        None,
        help="Command to get help for (e.g., 'run', 'status', 'briefing')",
    ),
) -> None:
    """Get help for Obra commands.

    Like `git help`, shows help for main app or specific commands.
    Tier 2: Supports keyword search - if command not found, searches all commands.

    Examples:
        obra help           # Main help
        obra help run       # Help for 'run' command
        obra help briefing  # Help for 'briefing' command
        obra help upload    # Search for commands matching 'upload'
    """

    # Get the underlying Click group from Typer
    click_app = typer.main.get_group(app)

    if command is None:
        # Show main help
        with click.Context(click_app) as click_ctx:
            click.echo(click_app.get_help(click_ctx))
        click.echo(
            "\nNote: default verbosity is PROGRESS (same as -v). Use -q/--quiet for minimal output."
        )
    else:
        if command.lower() == "domains":
            from obra.domains import get_available_domains, load_domain

            console.print()
            console.print("[bold]Available Domains[/bold]")
            console.print()
            for domain_name in get_available_domains():
                domain = load_domain(domain_name)
                console.print(
                    f"  [cyan]{domain.name}[/cyan] - {domain.display_name}: {domain.description}"
                )
                if domain.example_objectives:
                    console.print(
                        f"    Example: obra run --domain {domain.name} "
                        f"\"{domain.example_objectives[0]}\""
                    )
                console.print()
            return

        # Find and show help for specific command
        cmd = click_app.get_command(ctx, command)
        if cmd is None:
            # Tier 2: Command not found - search for matching commands
            # Search for substring matches in command names and descriptions
            matches = []
            search_term = command.lower()

            for cmd_obj in app.registered_commands:
                if not cmd_obj.name:
                    continue

                # Check if search term is in command name
                if search_term in cmd_obj.name.lower():
                    matches.append((cmd_obj.name, "name match"))
                    continue

                # Check if search term is in command description
                if cmd_obj.help and search_term in cmd_obj.help.lower():
                    matches.append((cmd_obj.name, "description match"))

            if matches:
                console.print()
                console.print(f"[yellow]Commands matching '{command}':[/yellow]")
                console.print()
                for cmd_name, _match_type in matches:
                    # Get command to show its help snippet
                    cmd_match = click_app.get_command(ctx, cmd_name)
                    if cmd_match and cmd_match.help:
                        first_line = cmd_match.help.split("\n")[0]
                        console.print(f"  [cyan]obra {cmd_name}[/cyan]")
                        console.print(f"    {first_line}")
                        console.print()
                console.print("[dim]Run 'obra help <command>' for detailed help.[/dim]")
                return

            # No matches found - show error
            print_error(f"Unknown command: {command}")
            print_info("Run 'obra help' to see available commands.")
            raise typer.Exit(1)
        with click.Context(cmd, info_name=command, parent=ctx) as click_ctx:
            click.echo(cmd.get_help(click_ctx))


# =============================================================================
# Procs Command (Process Management)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def procs(
    kill: bool = typer.Option(
        False,
        "--kill",
        "-k",
        help="Kill running processes (not just stale PID files)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Manage Obra background processes and sessions.

    Lists tracked Obra processes (config explorer, etc.) and running sessions.
    Removes stale PID files and optionally kills running processes.

    Examples:
        obra procs             # List processes and sessions
        obra procs --kill      # Kill running processes too
        obra procs -k -f       # Kill without confirmation
    """
    from obra.hybrid.session_guard import find_running_sessions
    from obra.utils.process_guard import cleanup_stale_processes, find_stale_processes

    processes = find_stale_processes()
    sessions = find_running_sessions()

    if not processes and not sessions:
        console.print("[green]No Obra processes or sessions found.[/green]")
        return

    # Show running sessions
    if sessions:
        console.print("\n[bold]Running sessions:[/bold]\n")
        for hb in sessions:
            runtime_h = hb.runtime_seconds / 3600
            progress = (
                f"{hb.items_completed}/{hb.items_total}"
                if hb.items_total
                else str(hb.items_completed)
            )
            warning = ""
            if runtime_h >= 24:
                warning = " [yellow]LONG[/yellow]"
            console.print(
                f"  [cyan]{hb.short_id}[/cyan]: {runtime_h:.1f}h, "
                f"{progress} items, {hb.current_phase} (PID {hb.pid}){warning}"
            )
        console.print()

    # Show other processes
    if processes:
        console.print("[bold]Background processes:[/bold]\n")
        for name, pid, alive in processes:
            status = "[green]running[/green]" if alive else "[dim]stale[/dim]"
            console.print(f"  {name}: PID {pid} ({status})")

        running = [(name, pid) for name, pid, alive in processes if alive]
        stale = [(name, pid) for name, pid, alive in processes if not alive]

        if stale:
            console.print(f"\n[dim]Stale PID files: {len(stale)}[/dim]")
        if running:
            console.print(f"[yellow]Running processes: {len(running)}[/yellow]")

        # Determine what to clean up
        if running and not kill:
            console.print("\n[dim]Use --kill to terminate running processes.[/dim]")
            # Only clean stale
            if stale:
                for name, _pid in stale:
                    console.print(f"  [dim]Removed stale PID file: {name}[/dim]")
                cleanup_stale_processes(kill=False)
                console.print(f"\n[green]Cleaned {len(stale)} stale PID file(s).[/green]")
            return

        # Confirm before killing
        if running and kill and not force:
            console.print()
            if not typer.confirm(f"Kill {len(running)} running process(es)?"):
                console.print("[dim]Cancelled.[/dim]")
                return

        # Do the cleanup
        def on_cleanup(name: str, pid: int) -> None:
            console.print(f"  [green]Cleaned: {name} (PID {pid})[/green]")

        cleaned = cleanup_stale_processes(kill=kill, on_cleanup=on_cleanup)

        if cleaned:
            console.print(f"\n[green]Cleaned {len(cleaned)} process(es).[/green]")
        else:
            console.print("\n[dim]Nothing to clean.[/dim]")


# =============================================================================
# Models Command (Provider/Model Discovery)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def models(
    provider: str | None = typer.Option(
        None,
        "--provider",
        "-p",
        help="Filter to specific provider (anthropic, google, openai, ollama)",
    ),
) -> None:
    """List available LLM providers and models.

    Discovery command for LLM operators: use this to find valid provider/model
    names before running `obra run --model ... --impl-provider ...`. Pair with
    `obra help domains` for domain discovery and `obra help run` for execution
    flags.

    Examples:
        obra models                    # All providers
        obra models --provider openai  # OpenAI models only
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus

    # Filter providers if specified
    providers_to_show = (
        {provider: MODEL_REGISTRY[provider]}
        if provider and provider in MODEL_REGISTRY
        else MODEL_REGISTRY
    )

    if provider and provider not in MODEL_REGISTRY:
        print_error(f"Unknown provider: {provider}")
        print_info(f"Available providers: {', '.join(MODEL_REGISTRY.keys())}")
        raise typer.Exit(1)

    import shutil

    console.print("\n[bold]Available LLM Providers[/bold]\n")

    for _provider_key, config in providers_to_show.items():
        # Check CLI installation status
        cli_installed = shutil.which(config.cli) is not None
        status_icon = (
            f"[green]{glyphs.success}[/green]" if cli_installed else f"[red]{glyphs.failure}[/red]"
        )
        status_text = "installed" if cli_installed else "not installed"

        # Provider header
        console.print(f"[bold cyan]{config.name}[/bold cyan]")
        console.print(f"  CLI: [yellow]{config.cli}[/yellow] {status_icon} {status_text}")
        if config.default_model:
            console.print(f"  Default: [green]{config.default_model}[/green]")
        console.print()

        # Models table
        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        table.add_column("Model", style="cyan")
        table.add_column("Description")
        table.add_column("Status", style="dim")

        for model_id, model_info in config.models.items():
            if model_info.status == ModelStatus.DEPRECATED:
                continue  # Skip deprecated models

            status_str = model_info.status.value
            desc = model_info.description or ""
            if model_info.resolves_to:
                desc = (
                    f"{desc} → {model_info.resolves_to}" if desc else f"→ {model_info.resolves_to}"
                )

            table.add_row(model_id, desc, status_str)

        console.print(table)
        console.print()

    # Usage examples section
    console.print("[bold]Usage Examples[/bold]\n")
    console.print("  [dim]# Discovery path[/dim]")
    console.print("  obra models")
    console.print("  obra help domains")
    console.print("  obra help run")
    console.print()
    console.print("  [dim]# Single provider run[/dim]")
    console.print('  obra run "Add user authentication" --model opus')
    console.print('  obra run "Fix tests" --impl-provider openai --model gpt-5.2')
    console.print()
    console.print("  [dim]# Parallel execution with multiple providers[/dim]")
    console.print('  obra run "Implement feature X" --model sonnet &')
    console.print('  obra run "Review code quality" --impl-provider openai &')
    console.print("  wait  # Wait for all jobs to complete")
    console.print()


# =============================================================================
# Main Workflow Commands
# =============================================================================


def _is_process_alive(pid: int) -> bool:
    """Compatibility wrapper for the extracted status helper."""
    return status_commands._is_process_alive(pid)


def _load_local_session_runtime(session_id: str | None) -> dict[str, Any] | None:
    """Compatibility wrapper for the extracted status helper."""
    return _status_load_local_session_runtime_impl(session_id)


def _resolve_doctor_llm_config() -> dict[str, Any]:
    """Compatibility wrapper for the extracted doctor helper."""
    return _doctor_resolve_llm_config_impl()


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def status(
    ctx: typer.Context,
    session_id: str | None = typer.Argument(
        None,
        help="Session ID to check (defaults to most recent)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (Tier 1: machine-readable format for LLM operators)",
    ),
    show_tasks: bool = typer.Option(
        False,
        "--tasks",
        "-t",
        help="Show inline task progress from the execution plan",
    ),
) -> None:
    """Check the status of a derivation session."""
    status_commands.require_authenticated_client = require_authenticated_client
    status_commands.setup_logging = setup_logging
    status_commands._load_local_session_runtime = _load_local_session_runtime
    return status_commands.status(
        ctx,
        session_id=session_id,
        verbose=verbose,
        json_output=json_output,
        show_tasks=show_tasks,
    )


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def cleanup(
    session_id: str = typer.Option(
        ...,
        "--session-id",
        help="Session ID to clean up Obra-managed containers for",
    ),
) -> None:
    """Clean up Obra-managed containers for a session."""
    try:
        from obra.hybrid.handlers.story0 import cleanup_containers

        cleaned = cleanup_containers(session_id)
        if cleaned:
            print_success(f"Cleaned up {cleaned} Obra-managed containers for session {session_id}")
        else:
            print_info("No Obra-managed containers found for cleanup")
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception("Error cleaning up Story 0 containers: %s", e)
        raise typer.Exit(1) from e


# =============================================================================
# Setup Command (First-Time Onboarding)
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def setup(
    check: bool = typer.Option(
        False,
        "--check",
        help="Check setup status without prompting",
    ),
    skip_validation: bool = typer.Option(
        False,
        "--skip-validation",
        help="Skip environment validation after authentication",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
    device_code: bool = typer.Option(
        False,
        "--device-code",
        help="Use device code flow for headless/remote environments",
    ),
) -> None:
    """First-time setup with terms acceptance, authentication, and provider selection."""
    setup_commands.offer_bug_report = offer_bug_report
    return setup_commands.setup(
        check=check,
        skip_validation=skip_validation,
        timeout=timeout,
        no_browser=no_browser,
        device_code=device_code,
    )

# Authentication commands extracted to obra/cli/auth.py
# Configuration commands extracted to obra/cli/config.py
from obra.cli.config import config_app

app.add_typer(config_app, name="config", rich_help_panel="User Commands")

# Documentation and log viewer commands extracted to obra/cli/docs.py

@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def doctor(
    report: bool = typer.Option(
        False,
        "--report",
        help="Submit diagnostic report if checks fail (for troubleshooting)",
    ),
) -> None:
    """Run health checks on your Obra environment."""
    doctor_commands.offer_bug_report = offer_bug_report
    doctor_commands._resolve_doctor_llm_config = _resolve_doctor_llm_config
    return doctor_commands.doctor(report=report)

# Skip tracking commands extracted to obra/cli/skips.py
# Prompt file management commands extracted to obra/cli/prompts.py
# Gateway server commands extracted to obra/cli/gateway.py


# =============================================================================
# Entry Point
# =============================================================================


def main() -> None:
    """Main entry point for the CLI.

    Tier 2: Includes command typo suggestions for better discoverability.
    """
    # Windows UTF-8 setup BEFORE any output (including --help)
    # This must run before Typer/Rich output anything with Unicode
    if sys.platform == "win32":
        os.environ["PYTHONUTF8"] = "1"
        # Reconfigure stdout/stderr for UTF-8 with fallback for unprintable chars
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    _maybe_print_legacy_runtime_notice()

    # FEAT-CLI-AUTO-UPDATE-001: Auto-upgrade via pipx if behind (synchronous)
    # Returns True if it attempted an update (success or fail).
    # On successful upgrade, try_auto_update() re-execs and never returns.
    auto_updated = try_auto_update()

    # FEAT-CLI-VERSION-NOTIFY-001: Fallback notification when auto-update is off
    if not auto_updated:
        check_for_updates_async()

    # Tier 2: Wrap app() to catch unknown commands and suggest alternatives
    try:
        app()
    except SystemExit as e:
        # Check if this is an unknown command error (exit code 2 from Click)
        if e.code == 2 and len(sys.argv) > 1:
            import difflib

            # Get the command that was attempted
            attempted_cmd = sys.argv[1]

            # Skip if it starts with - (it's a flag, not a command)
            if attempted_cmd.startswith("-"):
                raise

            # Get all available command names
            all_commands = [cmd.name for cmd in app.registered_commands if cmd.name]

            # Find close matches
            suggestions = difflib.get_close_matches(attempted_cmd, all_commands, n=3, cutoff=0.6)

            if suggestions:
                console.print()
                console.print("[yellow]💡 Did you mean:[/yellow]")
                for suggestion in suggestions:
                    console.print(f"   • obra {suggestion}")
                console.print()
                console.print("[dim]Run 'obra --help' for full command list.[/dim]")
                raise SystemExit(2) from e
        raise


if __name__ == "__main__":
    main()
