"""Query-oriented UserPlan CLI command handlers."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import typer
from rich.table import Table

from obra.cli.userplan_shared import (
    build_json_formatter,
    ensure_authenticated,
    get_api_client,
    output_json_error,
)
from obra.config import DEFAULT_MODEL, DEFAULT_PROVIDER, DEFAULT_REASONING_LEVEL
from obra.display import console, handle_encoding_errors, print_error, print_info, print_success
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError

logger = logging.getLogger(__name__)


@handle_encoding_errors
def userplan_add(
    input_source: str = typer.Argument(
        ...,
        help="File path (YAML/JSON) or objective string to create UserPlan from",
    ),
    project_id: str | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Project identifier (defaults to current directory name)",
    ),
    session_id: str | None = typer.Option(
        None,
        "--session",
        "-s",
        help="Session identifier to associate with the UserPlan",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Create a new UserPlan from a file or objective string."""
    from obra.config.llm import get_project_planning_config
    from obra.execution.intake import UserPlanIntake
    from obra.llm.invoker import LLMInvoker

    try:
        working_dir = Path.cwd()
        effective_project_id = project_id or working_dir.name

        input_path = Path(input_source)
        is_file_input = input_path.exists() and input_path.is_file()

        if is_file_input:
            console.print()
            print_info(f"Reading UserPlan from file: {input_path.name}")
            console.print()

            try:
                file_content = input_path.read_text(encoding="utf-8")
            except OSError as exc:
                console.print()
                print_error(f"Failed to read file: {exc}")
                console.print()
                raise typer.Exit(1) from exc

            if not file_content.strip():
                console.print()
                print_error("File is empty")
                console.print()
                raise typer.Exit(1)

            input_text = file_content
        else:
            if not input_source.strip():
                console.print()
                print_error("Objective cannot be empty")
                console.print()
                raise typer.Exit(1)

            console.print()
            print_info(f"Generating UserPlan from objective: {input_source[:60]}...")
            console.print()
            input_text = input_source

        planning_config = get_project_planning_config(working_dir)
        llm_config = {
            "provider": planning_config.get("provider", DEFAULT_PROVIDER),
            "model": planning_config.get("model", DEFAULT_MODEL),
            "reasoning_level": planning_config.get("reasoning_level", DEFAULT_REASONING_LEVEL),
        }

        llm_invoker = LLMInvoker(default_provider=llm_config["provider"])
        intake = UserPlanIntake(
            llm_invoker=llm_invoker,
            thinking_enabled=True,
            reasoning_level=llm_config["reasoning_level"],
            provider=llm_config["provider"],
        )

        result = asyncio.run(
            intake.process(
                input_text=input_text,
                project_id=effective_project_id,
                session_id=session_id,
            )
        )

        userplan = result.userplan
        userplan_source_dict = {
            "type": userplan.source.type.value,
            "path": userplan.source.path or (str(input_path) if is_file_input else None),
            "raw_objective": userplan.source.raw_objective,
            "generated": userplan.source.generated,
        }
        userplan_steps_list = [
            {
                "id": step.id,
                "index": step.index,
                "title": step.title,
                "description": step.description,
                "raw_text": step.raw_text,
                "derivation_status": step.derivation_status.value,
                "context": step.context.model_dump() if step.context else None,
            }
            for step in userplan.steps
        ]

        api_client = get_api_client()
        api_client.create_userplan(
            userplan_id=userplan.id,
            project_id=userplan.project_id,
            source=userplan_source_dict,
            steps=userplan_steps_list,
            session_id=session_id,
            status=userplan.status.value,
            quality_score=userplan.quality_score,
            quality_status=userplan.quality_status.value,
            work_type=userplan.work_type.value if userplan.work_type else None,
            context=userplan.context.model_dump() if userplan.context else None,
            metadata=userplan.metadata,
        )

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "userplan": {
                        "id": userplan.id,
                        "project_id": userplan.project_id,
                        "status": userplan.status.value,
                        "source": {
                            "type": userplan.source.type.value,
                            "generated": userplan.source.generated,
                        },
                        "quality_score": userplan.quality_score,
                        "quality_status": userplan.quality_status.value,
                        "work_type": userplan.work_type.value if userplan.work_type else None,
                        "step_count": len(userplan.steps),
                        "steps": [
                            {
                                "id": step.id,
                                "index": step.index,
                                "title": step.title,
                                "description": step.description,
                                "derivation_status": step.derivation_status.value,
                            }
                            for step in userplan.steps
                        ],
                    },
                    "was_generated": result.was_generated,
                },
                ids={
                    "userplan_id": userplan.id,
                    "project_id": userplan.project_id,
                },
            )
            return

        console.print()
        if result.was_generated:
            print_success(f"Generated and stored UserPlan: {userplan.id}")
        else:
            print_success(f"Stored UserPlan: {userplan.id}")
        console.print()

        console.print(f"  [cyan]ID:[/cyan] {userplan.id}")
        console.print(f"  [cyan]Project:[/cyan] {userplan.project_id}")
        console.print(f"  [cyan]Steps:[/cyan] {len(userplan.steps)}")
        console.print(f"  [cyan]Source:[/cyan] {userplan.source.type.value}")
        if result.was_generated:
            console.print("  [cyan]Generated:[/cyan] Yes")
        console.print()

        console.print("[bold]Steps:[/bold]")
        for step in userplan.steps[:5]:
            console.print(f"  {step.index}. {step.title}")
        if len(userplan.steps) > 5:
            console.print(f"  [dim]... and {len(userplan.steps) - 5} more[/dim]")
        console.print()

        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"USERPLAN_ID={userplan.id}")
        console.print(f"USERPLAN_PROJECT={userplan.project_id}")
        console.print(f"USERPLAN_STEPS={len(userplan.steps)}")
        console.print(f"USERPLAN_GENERATED={str(result.was_generated).lower()}")
        console.print()

        console.print("Next steps:")
        console.print(
            f"  [cyan]obra derive --userplan {userplan.id}[/cyan] - Derive plan from this UserPlan"
        )
        console.print()

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        print_error(f"Failed to store UserPlan: {exc}")
        console.print()
        logger.exception("UserPlan storage failed")
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        console.print()
        display_error(exc, console)
        logger.exception("UserPlan add failed")
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_list(
    project: str | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Filter by project identifier",
    ),
    status: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status (draft, active, completed, archived)",
    ),
    limit: int = typer.Option(
        50,
        "--limit",
        "-n",
        help="Maximum number of UserPlans to list (max: 100)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """List UserPlans."""
    try:
        ensure_authenticated(format_output=format_output, allow_json_error=True)

        client = get_api_client()
        userplans = client.list_userplans(project_id=project, status=status, limit=limit)

        if format_output == "json":
            formatter = build_json_formatter()
            formatter.output_success(
                data={
                    "userplans": [
                        {
                            "id": up.get("id"),
                            "project_id": up.get("project_id"),
                            "status": up.get("status"),
                            "step_count": up.get("step_count", len(up.get("steps", []))),
                            "quality_score": up.get("quality_score"),
                            "quality_status": up.get("quality_status"),
                            "created_at": up.get("created_at"),
                            "updated_at": up.get("updated_at"),
                            "title": (
                                up.get("steps", [{}])[0].get("title", "Untitled")
                                if up.get("steps")
                                else "Untitled"
                            ),
                        }
                        for up in userplans
                    ],
                    "count": len(userplans),
                    "filters": {
                        "project": project,
                        "status": status,
                        "limit": limit,
                    },
                },
                ids={
                    "userplan_ids": ",".join(up.get("id", "") for up in userplans),
                },
            )
            return

        console.print()
        if not userplans:
            print_info("No UserPlans found")
            console.print('\nCreate a UserPlan with: [cyan]obra userplan add "objective"[/cyan]')
            return

        console.print(f"[bold]UserPlans[/bold] ({len(userplans)} total)", style="cyan")
        console.print()

        table = Table()
        table.add_column("ID", style="cyan")
        table.add_column("Title", style="bold")
        table.add_column("Status", style="dim")
        table.add_column("Steps", justify="right")
        table.add_column("Quality", justify="right")
        table.add_column("Created", style="dim")

        for up in userplans:
            userplan_id = up.get("id", "")
            steps = up.get("steps", [])
            title = steps[0].get("title", "Untitled") if steps else "Untitled"
            if len(title) > 40:
                title = title[:37] + "..."
            status_val = up.get("status", "unknown")
            step_count = str(up.get("step_count", len(steps)))
            quality_score = up.get("quality_score")
            quality_str = f"{quality_score:.0%}" if quality_score is not None else "-"
            created_at = up.get("created_at", "N/A")

            if created_at and "T" in str(created_at):
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                    created_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            table.add_row(userplan_id, title, status_val, step_count, quality_str, created_at)

        console.print(table)
        console.print()
        console.print("[dim]Use:[/dim] [cyan]obra userplan show <id>[/cyan] to see full details")

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan list command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan list command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan list command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan list command: %s", exc)
        raise typer.Exit(1) from exc


@handle_encoding_errors
def userplan_show(
    userplan_id: str = typer.Argument(..., help="UserPlan ID to display"),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Display details of a specific UserPlan."""
    try:
        ensure_authenticated(format_output=format_output, allow_json_error=True)

        client = get_api_client()
        userplan = client.get_userplan(userplan_id)

        if not userplan:
            if format_output == "json":
                output_json_error(f"UserPlan not found: {userplan_id}", "NOT_FOUND")
                raise typer.Exit(1)
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        if format_output == "json":
            from obra.utils.json_output import serialize_userplan

            formatter = build_json_formatter()
            formatter.output_success(
                data={"userplan": serialize_userplan(userplan)},
                ids={"userplan_id": userplan.get("id", "")},
            )
            return

        console.print()
        console.print("[bold cyan]UserPlan Details[/bold cyan]")
        console.print("=" * 60)
        console.print()

        console.print(f"[bold]ID:[/bold]         {userplan.get('id', 'N/A')}")
        console.print(f"[bold]Project:[/bold]    {userplan.get('project_id', 'N/A')}")
        console.print(f"[bold]Status:[/bold]     {userplan.get('status', 'N/A')}")

        source = userplan.get("source", {})
        if source:
            source_type = source.get("type", "unknown")
            generated = source.get("generated", False)
            console.print(
                f"[bold]Source:[/bold]     {source_type}" + (" (generated)" if generated else "")
            )

        created_at = userplan.get("created_at", "N/A")
        if created_at and "T" in str(created_at):
            from datetime import datetime

            try:
                dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                created_at = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (ValueError, TypeError):
                pass
        console.print(f"[bold]Created:[/bold]    {created_at}")

        updated_at = userplan.get("updated_at", "N/A")
        if updated_at and "T" in str(updated_at):
            from datetime import datetime

            try:
                dt = datetime.fromisoformat(str(updated_at).replace("Z", "+00:00"))
                updated_at = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (ValueError, TypeError):
                pass
        console.print(f"[bold]Updated:[/bold]    {updated_at}")

        quality_score = userplan.get("quality_score")
        quality_status = userplan.get("quality_status", "not_assessed")
        if quality_score is not None or quality_status != "not_assessed":
            console.print()
            console.print("[bold]Quality Assessment:[/bold]")
            if quality_score is not None:
                console.print(f"  Score:  {quality_score:.0%}")
            console.print(f"  Status: {quality_status}")
            quality_hints = userplan.get("quality_hints", [])
            if quality_hints:
                console.print("  Hints:")
                for hint in quality_hints[:5]:
                    console.print(f"    - {hint}")
                if len(quality_hints) > 5:
                    console.print(f"    [dim]... and {len(quality_hints) - 5} more[/dim]")

        work_type = userplan.get("work_type")
        if work_type:
            console.print(f"[bold]Work Type:[/bold]  {work_type}")

        steps = userplan.get("steps", [])
        if steps:
            console.print()
            console.print(f"[bold]Steps[/bold] ({len(steps)} total)")
            console.print("-" * 40)

            step_table = Table(show_header=True, header_style="bold")
            step_table.add_column("#", style="cyan", justify="right")
            step_table.add_column("Title")
            step_table.add_column("Derivation", style="dim")

            for step in steps:
                step_index = str(step.get("index", "?"))
                step_title = step.get("title", "Untitled")
                if len(step_title) > 50:
                    step_title = step_title[:47] + "..."
                derivation_status = step.get("derivation_status", "not_derived")
                step_table.add_row(step_index, step_title, derivation_status)

            console.print(step_table)

            console.print()
            console.print("[bold]Step Details:[/bold]")
            for step in steps:
                step_index = step.get("index", "?")
                step_title = step.get("title", "Untitled")
                description = step.get("description", "No description")
                console.print()
                console.print(f"  [cyan]{step_index}. {step_title}[/cyan]")
                desc_lines = description.split("\n")
                for line in desc_lines[:5]:
                    console.print(f"     {line}")
                if len(desc_lines) > 5:
                    console.print(f"     [dim]... {len(desc_lines) - 5} more lines[/dim]")

        console.print()
        console.print(f"[dim]Derive with:[/dim] [cyan]obra derive --userplan {userplan_id}[/cyan]")

    except typer.Exit:
        raise
    except APIError as exc:
        if format_output == "json":
            output_json_error(str(exc), "API_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("API error in userplan show command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ConfigurationError as exc:
        if format_output == "json":
            output_json_error(str(exc), "CONFIG_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Configuration error in userplan show command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except ObraError as exc:
        if format_output == "json":
            output_json_error(str(exc), "OBRA_ERROR")
            raise typer.Exit(1) from exc
        display_obra_error(exc, console)
        logger.error("Obra error in userplan show command: %s", exc, exc_info=True)
        raise typer.Exit(1) from exc
    except Exception as exc:
        if format_output == "json":
            output_json_error(str(exc), "UNKNOWN_ERROR")
            raise typer.Exit(1) from exc
        display_error(exc, console)
        logger.exception("Unexpected error in userplan show command: %s", exc)
        raise typer.Exit(1) from exc
