"""Helpers for deterministic seeded review-episode simulations."""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import yaml

from obra.api.protocol import ValidatorRequest

_ALLOWED_SESSION_PATCH_FIELDS = frozenset(
    {
        "current_phase",
        "current_iteration",
        "fix_attempts",
        "review_fix_cycle_count",
        "fix_attempt_fingerprints",
        "fresh_fix_requested",
        "fresh_fix_item_id",
        "plan_revision_attempts",
        "verification_tools",
        "verification_preflight_attempted",
        "verification_preflight_attempts",
        "project_context",
    }
)
_ALLOWED_SCORECARD_FIELDS = frozenset(
    {
        "item_id",
        "iteration",
        "agent_reports",
        "compiled_score",
        "blocking_issues",
        "resolved_issues",
        "tests_required",
        "status",
        "forced_complete",
        "fix_failure_context",
        "issue_registry",
        "blocking_set_history",
        "blocking_set_profile_history",
        "fresh_fix_attempted",
    }
)
_ALLOWED_PENDING_ESCALATION_FIELDS = frozenset(
    {
        "reason_code",
        "reason_text",
        "item_id",
        "iteration",
        "blocking_issue_ids",
    }
)
_SESSION_SNAPSHOT_VERSION = 1
_SEEDED_SESSION_EXPIRY_HOURS = 24
_SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS = (
    "plan_versions",
    "examinations",
    "execution_results",
    "quality_scorecards",
    "workflow_artifacts",
    "progress_events",
)
_SNAPSHOT_DATETIME_FIELDS = frozenset(
    {
        "accepted_at",
        "created_at",
        "derived_at",
        "emitted_at",
        "ended_at",
        "expires_at",
        "failed_at",
        "started_at",
        "timestamp",
        "updated_at",
    }
)


def _fresh_seeded_session_expiry() -> str:
    """Return a fresh session expiry aligned with the local session lease."""
    return (datetime.now(timezone.utc) + timedelta(hours=_SEEDED_SESSION_EXPIRY_HOURS)).isoformat()


def _load_structured_file(path: Path) -> dict[str, Any]:
    """Load a JSON or YAML mapping payload."""
    raw_text = path.read_text(encoding="utf-8")
    suffix = path.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        payload = yaml.safe_load(raw_text)
    else:
        payload = json.loads(raw_text)
    if not isinstance(payload, dict):
        raise ValueError(f"Structured payload must be a mapping: {path}")
    return payload


def _resolve_relative_asset(
    scenario_path: Path | None,
    asset_path: str,
    *,
    field_name: str,
) -> Path:
    """Resolve a scenario-relative asset path."""
    if not asset_path.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    base_dir = scenario_path.parent if scenario_path is not None else Path.cwd()
    resolved = (base_dir / asset_path).expanduser().resolve(strict=False)
    if not resolved.exists():
        raise ValueError(f"{field_name} not found: {resolved}")
    return resolved


def _deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge mappings without mutating inputs."""
    merged = dict(base)
    for key, value in patch.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = _deep_merge(existing, value)
        else:
            merged[key] = value
    return merged


def _serialize_snapshot_value(value: Any) -> Any:
    """Convert Firestore payloads into JSON-safe seed data."""
    if isinstance(value, dict):
        return {str(key): _serialize_snapshot_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_serialize_snapshot_value(item) for item in value]
    if isinstance(value, tuple):
        return [_serialize_snapshot_value(item) for item in value]
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def _restore_snapshot_value(value: Any, *, field_name: str | None = None) -> Any:
    """Convert JSON-safe snapshot data back into Firestore-friendly values."""
    if isinstance(value, dict):
        return {
            str(key): _restore_snapshot_value(item, field_name=str(key))
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_restore_snapshot_value(item) for item in value]
    if (
        field_name in _SNAPSHOT_DATETIME_FIELDS
        and isinstance(value, str)
        and value.strip()
    ):
        normalized = value.replace("Z", "+00:00")
        try:
            return datetime.fromisoformat(normalized)
        except ValueError:
            return value
    return value


def _normalize_session_snapshot(raw_snapshot: Any) -> dict[str, Any]:
    """Validate a replayable session snapshot payload."""
    if raw_snapshot in (None, {}):
        return {}
    if not isinstance(raw_snapshot, dict):
        raise ValueError("Seeded review session snapshot must be a mapping")

    session_id = str(raw_snapshot.get("session_id", "") or "").strip()
    user_id = str(raw_snapshot.get("user_id", "") or "").strip()
    if not session_id:
        raise ValueError("Seeded review session snapshot must include session_id")
    if not user_id:
        raise ValueError("Seeded review session snapshot must include user_id")

    global_session = raw_snapshot.get("global_session")
    user_session = raw_snapshot.get("user_session")
    if not isinstance(global_session, dict) or not global_session:
        raise ValueError("Seeded review session snapshot must include global_session")
    if not isinstance(user_session, dict) or not user_session:
        raise ValueError("Seeded review session snapshot must include user_session")
    project_snapshot = raw_snapshot.get("project_snapshot")
    normalized_project_snapshot: dict[str, Any] = {}
    if project_snapshot not in (None, {}):
        if not isinstance(project_snapshot, dict):
            raise ValueError("Seeded review session snapshot project_snapshot must be a mapping")
        project_id = str(project_snapshot.get("project_id", "") or "").strip()
        project_data = project_snapshot.get("data")
        if not project_id:
            raise ValueError("Seeded review session snapshot project_snapshot must include project_id")
        if not isinstance(project_data, dict) or not project_data:
            raise ValueError("Seeded review session snapshot project_snapshot must include data")
        normalized_project_snapshot = {
            "project_id": project_id,
            "data": _serialize_snapshot_value(dict(project_data)),
        }

    normalized_subcollections: dict[str, list[dict[str, Any]]] = {}
    raw_subcollections = raw_snapshot.get("subcollections") or {}
    if raw_subcollections not in ({}, None) and not isinstance(raw_subcollections, dict):
        raise ValueError("Seeded review session snapshot subcollections must be a mapping")
    for name, entries in dict(raw_subcollections).items():
        if name not in _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS:
            raise ValueError(
                "Seeded review session snapshot contains unsupported subcollection "
                f"{name!r}"
            )
        if not isinstance(entries, list):
            raise ValueError(
                "Seeded review session snapshot subcollections must contain lists of documents"
            )
        normalized_entries: list[dict[str, Any]] = []
        for entry in entries:
            if not isinstance(entry, dict):
                raise ValueError(
                    "Seeded review session snapshot documents must be mappings"
                )
            doc_id = str(entry.get("doc_id", "") or "").strip()
            data = entry.get("data")
            if not doc_id:
                raise ValueError(
                    "Seeded review session snapshot documents must include doc_id"
                )
            if not isinstance(data, dict):
                raise ValueError(
                    "Seeded review session snapshot documents must include mapping data"
                )
            normalized_entries.append(
                {"doc_id": doc_id, "data": _serialize_snapshot_value(data)}
            )
        normalized_subcollections[name] = normalized_entries

    return {
        "snapshot_version": int(
            raw_snapshot.get("snapshot_version", _SESSION_SNAPSHOT_VERSION)
            or _SESSION_SNAPSHOT_VERSION
        ),
        "session_id": session_id,
        "user_id": user_id,
        "project_snapshot": normalized_project_snapshot,
        "global_session": _serialize_snapshot_value(dict(global_session)),
        "user_session": _serialize_snapshot_value(dict(user_session)),
        "subcollections": normalized_subcollections,
    }


def _normalize_session_patch(raw_patch: Any) -> dict[str, Any]:
    """Validate the bounded session patch contract."""
    if raw_patch in (None, {}):
        return {}
    if not isinstance(raw_patch, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode.session_patch must be a mapping"
        )
    unexpected = sorted(set(raw_patch) - _ALLOWED_SESSION_PATCH_FIELDS)
    if unexpected:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.session_patch contains "
            f"unsupported fields: {', '.join(unexpected)}"
        )

    normalized = dict(raw_patch)
    if "current_phase" in normalized:
        value = str(normalized["current_phase"] or "").strip()
        if not value:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch.current_phase "
                "must be a non-empty string"
            )
        normalized["current_phase"] = value
    for field_name in (
        "current_iteration",
        "fix_attempts",
        "review_fix_cycle_count",
        "plan_revision_attempts",
        "verification_preflight_attempts",
    ):
        if field_name not in normalized:
            continue
        value = normalized[field_name]
        if not isinstance(value, int) or value < 0:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch."
                f"{field_name} must be a non-negative integer"
            )
    for field_name in (
        "fresh_fix_requested",
        "verification_preflight_attempted",
    ):
        if field_name in normalized and not isinstance(normalized[field_name], bool):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch."
                f"{field_name} must be a boolean"
            )
    if "fresh_fix_item_id" in normalized:
        normalized["fresh_fix_item_id"] = str(
            normalized["fresh_fix_item_id"] or ""
        ).strip()
    for field_name in (
        "fix_attempt_fingerprints",
        "verification_tools",
        "project_context",
    ):
        if field_name in normalized and not isinstance(normalized[field_name], dict):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.session_patch."
                f"{field_name} must be a mapping"
            )
    return normalized


def _normalize_scorecard_payload(
    raw_entry: Any,
    *,
    scenario_path: Path | None,
    index: int,
) -> dict[str, Any]:
    """Validate one scorecard seed entry."""
    if not isinstance(raw_entry, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards entries must be mappings"
        )
    payload_file = raw_entry.get("payload_file")
    if payload_file is not None:
        if len(raw_entry) != 1:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards entries using "
                "payload_file may not define additional fields"
            )
        if not isinstance(payload_file, str):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[].payload_file "
                "must be a string"
            )
        payload = _load_structured_file(
            _resolve_relative_asset(
                scenario_path,
                payload_file,
                field_name=(
                    "Scenario simulation.seeded_review_episode.scorecards[].payload_file"
                ),
            )
        )
    else:
        payload = dict(raw_entry)

    unexpected = sorted(set(payload) - _ALLOWED_SCORECARD_FIELDS)
    if unexpected:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards contains unsupported "
            f"fields at index {index}: {', '.join(unexpected)}"
        )

    item_id = str(payload.get("item_id", "") or "").strip()
    if not item_id:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards[].item_id must be a "
            "non-empty string"
        )
    iteration = payload.get("iteration")
    if not isinstance(iteration, int) or iteration < 0:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards[].iteration must be "
            "a non-negative integer"
        )

    normalized = dict(payload)
    normalized["item_id"] = item_id
    normalized["iteration"] = iteration
    if "compiled_score" in normalized:
        value = normalized["compiled_score"]
        if not isinstance(value, int | float):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[].compiled_score "
                "must be numeric"
            )
        normalized["compiled_score"] = float(value)
    for field_name in ("blocking_issues", "resolved_issues"):
        value = normalized.get(field_name)
        if value is None:
            continue
        if not isinstance(value, list) or not all(
            isinstance(item, str) and item.strip() for item in value
        ):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[]."
                f"{field_name} must be a list of non-empty strings"
            )
        normalized[field_name] = [item.strip() for item in value]
    for field_name in (
        "agent_reports",
        "fix_failure_context",
        "issue_registry",
        "blocking_set_history",
        "blocking_set_profile_history",
    ):
        value = normalized.get(field_name)
        if value is None:
            continue
        expected_type = list if field_name == "agent_reports" else dict
        if not isinstance(value, expected_type):
            expected_name = "list" if expected_type is list else "mapping"
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[]."
                f"{field_name} must be a {expected_name}"
            )
    for field_name in ("tests_required", "forced_complete", "fresh_fix_attempted"):
        if field_name in normalized and not isinstance(normalized[field_name], bool):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.scorecards[]."
                f"{field_name} must be a boolean"
            )
    if "status" in normalized:
        normalized["status"] = str(normalized["status"] or "").strip()
    return normalized


def _normalize_pending_escalation_fixer(raw_pending: Any) -> dict[str, Any]:
    """Validate an optional pre-dispatched escalation-fixer episode."""
    if raw_pending in (None, {}):
        return {}
    if not isinstance(raw_pending, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode.pending_escalation_fixer "
            "must be a mapping"
        )

    unexpected = sorted(set(raw_pending) - _ALLOWED_PENDING_ESCALATION_FIELDS)
    if unexpected:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.pending_escalation_fixer "
            f"contains unsupported fields: {', '.join(unexpected)}"
        )

    reason_code = str(raw_pending.get("reason_code", "") or "").strip()
    if not reason_code:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.pending_escalation_fixer."
            "reason_code must be a non-empty string"
        )

    normalized: dict[str, Any] = {"reason_code": reason_code}
    reason_text = str(raw_pending.get("reason_text", "") or "").strip()
    if reason_text:
        normalized["reason_text"] = reason_text

    item_id = str(raw_pending.get("item_id", "") or "").strip()
    if item_id:
        normalized["item_id"] = item_id

    if "iteration" in raw_pending:
        iteration = raw_pending.get("iteration")
        if not isinstance(iteration, int) or iteration < 0:
            raise ValueError(
                "Scenario simulation.seeded_review_episode.pending_escalation_fixer."
                "iteration must be a non-negative integer"
            )
        normalized["iteration"] = iteration

    blocking_issue_ids = raw_pending.get("blocking_issue_ids")
    if blocking_issue_ids is not None:
        if not isinstance(blocking_issue_ids, list) or not all(
            isinstance(issue_id, str) and issue_id.strip() for issue_id in blocking_issue_ids
        ):
            raise ValueError(
                "Scenario simulation.seeded_review_episode.pending_escalation_fixer."
                "blocking_issue_ids must be a list of non-empty strings"
            )
        normalized["blocking_issue_ids"] = [
            str(issue_id).strip() for issue_id in blocking_issue_ids
        ]

    return normalized


def normalize_seeded_review_episode(
    raw_scenario: dict[str, Any],
    *,
    scenario_path: Path | None = None,
) -> dict[str, Any]:
    """Normalize the optional seeded review-episode contract."""
    raw_simulation = raw_scenario.get("simulation")
    if raw_simulation in (None, {}):
        return {}
    if not isinstance(raw_simulation, dict):
        raise ValueError("Scenario simulation must be a mapping when provided")

    raw_episode = raw_simulation.get("seeded_review_episode")
    if raw_episode in (None, {}):
        return {}
    if not isinstance(raw_episode, dict):
        raise ValueError(
            "Scenario simulation.seeded_review_episode must be a mapping"
        )

    scorecards_raw = raw_episode.get("scorecards")
    if not isinstance(scorecards_raw, list) or not scorecards_raw:
        raise ValueError(
            "Scenario simulation.seeded_review_episode.scorecards must be a non-empty list"
        )

    scorecards = [
        _normalize_scorecard_payload(
            entry,
            scenario_path=scenario_path,
            index=index,
        )
        for index, entry in enumerate(scorecards_raw)
    ]
    item_ids = sorted(
        {
            str(scorecard["item_id"]).strip()
            for scorecard in scorecards
            if str(scorecard["item_id"]).strip()
        }
    )
    return {
        "session_patch": _normalize_session_patch(raw_episode.get("session_patch")),
        "scorecards": scorecards,
        "item_ids": item_ids,
        "scorecard_count": len(scorecards),
        "pending_escalation_fixer": _normalize_pending_escalation_fixer(
            raw_episode.get("pending_escalation_fixer")
        ),
    }


def _build_project_context_patch(simulation_control: dict[str, Any]) -> dict[str, Any]:
    """Translate simulator controls into resumed-session config state."""
    simulation_patch: dict[str, Any] = {}
    config_patch: dict[str, Any] = {}

    escalation_control = simulation_control.get("escalation_fixer")
    if isinstance(escalation_control, dict) and escalation_control:
        review_config: dict[str, Any] = {"enabled": True}
        for field_name in ("timeout_s", "allowed_routes", "eligible_reason_codes"):
            value = escalation_control.get(field_name)
            if value not in (None, {}, []):
                review_config[field_name] = value
        simulation_patch["escalation_fixer"] = dict(escalation_control)
        config_patch["review"] = {"escalation_fixer": review_config}

    adaptive_control = simulation_control.get("adaptive_decomposition")
    if isinstance(adaptive_control, dict) and adaptive_control:
        simulation_patch["adaptive_decomposition"] = dict(adaptive_control)
        adaptive_config = adaptive_control.get("config")
        if isinstance(adaptive_config, dict) and adaptive_config:
            orchestration = dict(config_patch.get("orchestration") or {})
            orchestration["decomposition"] = dict(adaptive_config)
            config_patch["orchestration"] = orchestration

    if not simulation_patch and not config_patch:
        return {}

    patch: dict[str, Any] = {}
    if simulation_patch:
        patch["simulation"] = simulation_patch
    if config_patch:
        patch["config"] = config_patch
    return patch


def prepare_seeded_review_session_updates(
    *,
    session: Any,
    session_patch: dict[str, Any],
) -> dict[str, Any]:
    """Prepare bounded session updates for a seeded review replay."""
    updates = dict(session_patch)
    project_context_patch = updates.pop("project_context", None)
    if project_context_patch:
        existing_context = dict(getattr(session, "project_context", {}) or {})
        updates["project_context"] = _deep_merge(existing_context, project_context_patch)

    current_phase = str(updates.get("current_phase") or "").strip().lower()
    if current_phase:
        existing_lifecycle_decisions = dict(
            getattr(session, "workflow_lifecycle_decisions", {}) or {}
        )
        existing_lifecycle_decisions["resume_target"] = current_phase
        updates["workflow_lifecycle_decisions"] = existing_lifecycle_decisions

        existing_derivation_state = dict(
            getattr(session, "workflow_derivation_state", {}) or {}
        )
        existing_derivation_state["resume_target"] = current_phase
        updates["workflow_derivation_state"] = existing_derivation_state

    current_status = str(getattr(session, "status", "") or "").strip().lower()
    if current_status and current_status != "active":
        updates["status"] = "active"
    return updates


def build_seeded_review_episode_plan(
    *,
    checkpoint_file: str | Path,
    seeded_review_episode: dict[str, Any],
    simulation_control: dict[str, Any],
    seed_pack: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the late-review hydration plan for a resumed scenario."""
    if not seeded_review_episode:
        return {}

    checkpoint = _load_structured_file(Path(checkpoint_file).expanduser())
    checkpoint_type = str(checkpoint.get("checkpoint_type", "") or "").strip()
    if checkpoint_type != "resume_checkpoint":
        raise ValueError(
            "Seeded review episodes require a resume_checkpoint scenario checkpoint"
        )
    session_id = str(checkpoint.get("session_id", "") or "").strip()
    if not session_id:
        raise ValueError(
            "Seeded review episodes require checkpoint_file.session_id to be set"
        )
    session_snapshot: dict[str, Any] = {}
    if isinstance(seed_pack, dict):
        snapshot_file = str(seed_pack.get("session_snapshot_file", "") or "").strip()
        if snapshot_file:
            session_snapshot = _normalize_session_snapshot(
                _load_structured_file(Path(snapshot_file).expanduser())
            )
            snapshot_session_id = str(session_snapshot.get("session_id", "") or "").strip()
            if snapshot_session_id and snapshot_session_id != session_id:
                raise ValueError(
                    "Seeded review session snapshot session_id does not match "
                    "checkpoint_file.session_id"
                )

    session_patch = dict(seeded_review_episode.get("session_patch") or {})
    project_context_patch = _build_project_context_patch(simulation_control)
    if project_context_patch:
        existing_project_context = dict(session_patch.get("project_context") or {})
        session_patch["project_context"] = _deep_merge(
            existing_project_context,
            project_context_patch,
        )

    return {
        "session_id": session_id,
        "session_snapshot": session_snapshot,
        "session_patch": session_patch,
        "scorecards": list(seeded_review_episode.get("scorecards") or []),
        "item_ids": list(seeded_review_episode.get("item_ids") or []),
        "scorecard_count": int(seeded_review_episode.get("scorecard_count", 0) or 0),
        "pending_escalation_fixer": dict(
            seeded_review_episode.get("pending_escalation_fixer") or {}
        ),
    }


def _resolve_firebase_admin_init_config(
    env: dict[str, str] | None = None,
) -> tuple[Any, dict[str, Any] | None]:
    """Resolve Firebase Admin initialization for emulator-backed CLI helpers."""
    source = env or os.environ
    emulator_host = source.get("FIRESTORE_EMULATOR_HOST", "").strip()
    if not emulator_host:
        return (None, None)

    project_id = (
        source.get("OBRA_FIREBASE_EMULATOR_PROJECT_ID", "").strip()
        or source.get("GOOGLE_CLOUD_PROJECT", "").strip()
        or source.get("GCLOUD_PROJECT", "").strip()
    )
    if not project_id:
        raise RuntimeError(
            "Local Firestore emulator mode requires OBRA_FIREBASE_EMULATOR_PROJECT_ID "
            "or GOOGLE_CLOUD_PROJECT."
        )

    from firebase_admin import credentials as firebase_credentials
    from google.auth.credentials import AnonymousCredentials

    class _EmulatorAdminCredential(firebase_credentials.Base):
        def __init__(self) -> None:
            self._credential = AnonymousCredentials()

        def get_credential(self) -> AnonymousCredentials:
            return self._credential

    return (_EmulatorAdminCredential(), {"projectId": project_id})


class _SeededReviewSessionManager:
    """Minimal Firestore-backed session adapter for local simulation helpers."""

    def __init__(self, user_id: str, db: Any):
        if not user_id:
            raise ValueError("user_id is required for seeded review session access")
        self._user_id = user_id
        self._db = db

    def _global_session_doc(self, session_id: str) -> Any:
        return self._db.collection("sessions").document(session_id)

    def _session_doc(self, session_id: str) -> Any:
        return (
            self._db.collection("users")
            .document(self._user_id)
            .collection("sessions")
            .document(session_id)
        )

    def _quality_scorecards_collection(self, session_id: str) -> Any:
        return self._session_doc(session_id).collection("quality_scorecards")

    def get_session(self, session_id: str) -> Any | None:
        doc = self._global_session_doc(session_id).get()
        if not doc.exists:
            doc = self._session_doc(session_id).get()
            if not doc.exists:
                return None
        return SimpleNamespace(**dict(doc.to_dict() or {}))

    def update_session(self, session_id: str, updates: dict[str, Any]) -> bool:
        doc = self._global_session_doc(session_id).get()
        if not doc.exists:
            doc = self._session_doc(session_id).get()
            if not doc.exists:
                return False

        from firebase_admin import firestore

        payload = dict(updates)
        payload["updated_at"] = firestore.SERVER_TIMESTAMP
        self._session_doc(session_id).update(payload)
        self._global_session_doc(session_id).set(payload, merge=True)
        return True

    def store_quality_scorecard(self, session_id: str, scorecard_payload: dict[str, Any]) -> str:
        from firebase_admin import firestore

        payload = dict(scorecard_payload)
        item_id = str(payload.get("item_id", "") or "").strip()
        iteration = int(payload.get("iteration", 0) or 0)
        doc_id = f"{item_id}_{iteration}"
        payload["created_at"] = firestore.SERVER_TIMESTAMP
        self._quality_scorecards_collection(session_id).document(doc_id).set(payload)
        return doc_id

    def get_all_quality_scorecards(self, session_id: str) -> list[dict[str, Any]]:
        from firebase_admin import firestore

        docs = (
            self._quality_scorecards_collection(session_id)
            .order_by("iteration", direction=firestore.Query.DESCENDING)
            .stream()
        )
        return [dict(doc.to_dict() or {}) for doc in docs]

def _ensure_firestore_initialized():
    """Initialize Firebase Admin against the active emulator project."""
    import firebase_admin

    if not firebase_admin._apps:
        credential, options = _resolve_firebase_admin_init_config()
        firebase_admin.initialize_app(
            credential=credential,
            options=options,
        )

    from firebase_admin import firestore

    return firestore.client()


def capture_seeded_review_session_snapshot(session_id: str) -> dict[str, Any]:
    """Capture the replayable Firestore substrate for a seeded review session."""
    db = _ensure_firestore_initialized()
    normalized_session_id = str(session_id or "").strip()
    if not normalized_session_id:
        raise ValueError("Seeded review session snapshot requires session_id")

    global_doc = db.collection("sessions").document(normalized_session_id).get()
    if not global_doc.exists:
        raise ValueError(
            f"Seeded review episode session not found in emulator: {normalized_session_id}"
        )
    global_payload = dict(global_doc.to_dict() or {})
    user_id = str(global_payload.get("user_id", "") or "").strip()
    if not user_id:
        raise ValueError(
            f"Seeded review episode session {normalized_session_id} is missing user_id"
        )

    session_doc = (
        db.collection("users")
        .document(user_id)
        .collection("sessions")
        .document(normalized_session_id)
    )
    session_snapshot = session_doc.get()
    if not session_snapshot.exists:
        raise ValueError(
            f"Seeded review episode session not found in user scope: {normalized_session_id}"
        )

    subcollections: dict[str, list[dict[str, Any]]] = {}
    for name in _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS:
        docs = []
        for doc in session_doc.collection(name).stream():
            docs.append(
                {
                    "doc_id": doc.id,
                    "data": _serialize_snapshot_value(dict(doc.to_dict() or {})),
                }
            )
        subcollections[name] = sorted(docs, key=lambda entry: entry["doc_id"])

    project_snapshot: dict[str, Any] = {}
    project_id = str(
        (session_snapshot.to_dict() or {}).get("project_id")
        or global_payload.get("project_id")
        or ""
    ).strip()
    if project_id:
        project_doc = (
            db.collection("users")
            .document(user_id)
            .collection("projects")
            .document(project_id)
            .get()
        )
        if project_doc.exists:
            project_snapshot = {
                "project_id": project_id,
                "data": _serialize_snapshot_value(dict(project_doc.to_dict() or {})),
            }

    return _normalize_session_snapshot(
        {
            "snapshot_version": _SESSION_SNAPSHOT_VERSION,
            "session_id": normalized_session_id,
            "user_id": user_id,
            "project_snapshot": project_snapshot,
            "global_session": _serialize_snapshot_value(global_payload),
            "user_session": _serialize_snapshot_value(dict(session_snapshot.to_dict() or {})),
            "subcollections": subcollections,
        }
    )


def restore_seeded_review_session_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Restore a replayable session snapshot into the active emulator."""
    normalized = _normalize_session_snapshot(snapshot)
    if not normalized:
        return {}

    db = _ensure_firestore_initialized()
    session_id = str(normalized["session_id"])
    user_id = str(normalized["user_id"])

    user_doc = db.collection("users").document(user_id)
    if not user_doc.get().exists:
        user_doc.set({"created_at": datetime.now(timezone.utc).isoformat()})

    global_session = dict(normalized["global_session"])
    user_session = dict(normalized["user_session"])
    global_session.setdefault("session_id", session_id)
    global_session.setdefault("user_id", user_id)
    user_session.setdefault("session_id", session_id)
    user_session.setdefault("user_id", user_id)
    refreshed_expires_at = _fresh_seeded_session_expiry()
    global_session["expires_at"] = refreshed_expires_at
    user_session["expires_at"] = refreshed_expires_at

    db.collection("sessions").document(session_id).set(
        _restore_snapshot_value(global_session)
    )
    session_doc = user_doc.collection("sessions").document(session_id)
    session_doc.set(_restore_snapshot_value(user_session))
    project_snapshot = dict(normalized.get("project_snapshot") or {})
    if project_snapshot:
        project_id = str(project_snapshot["project_id"])
        user_doc.collection("projects").document(project_id).set(
            _restore_snapshot_value(dict(project_snapshot["data"]))
        )

    restored_subcollections: dict[str, int] = {}
    for name in _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS:
        collection = session_doc.collection(name)
        for existing_doc in collection.stream():
            existing_doc.reference.delete()
        entries = list((normalized.get("subcollections") or {}).get(name) or [])
        for entry in entries:
            collection.document(str(entry["doc_id"])).set(
                _restore_snapshot_value(dict(entry["data"]))
            )
        restored_subcollections[name] = len(entries)

    return {
        "session_id": session_id,
        "user_id": user_id,
        "project_restored": bool(project_snapshot),
        "restored_subcollections": restored_subcollections,
        "restored_doc_count": sum(restored_subcollections.values()),
    }


def align_seeded_session_to_resume_target(
    *,
    session_id: str,
    resume_target: str,
) -> dict[str, Any]:
    """Align a restored seeded session to the checkpoint resume target."""
    normalized_session_id = str(session_id or "").strip()
    normalized_resume_target = str(resume_target or "").strip().lower()
    if not normalized_session_id or not normalized_resume_target:
        return {}

    db = _ensure_firestore_initialized()
    global_doc = db.collection("sessions").document(normalized_session_id).get()
    if not global_doc.exists:
        raise ValueError(
            f"Seeded review episode session not found in emulator: {normalized_session_id}"
        )
    global_payload = dict(global_doc.to_dict() or {})
    user_id = str(global_payload.get("user_id", "") or "").strip()
    if not user_id:
        raise ValueError(
            f"Seeded review episode session {normalized_session_id} is missing user_id"
        )

    manager = _SeededReviewSessionManager(user_id, db)
    session = manager.get_session(normalized_session_id)
    if session is None:
        raise ValueError(
            f"Seeded review episode session not found in user scope: {normalized_session_id}"
        )

    updates = prepare_seeded_review_session_updates(
        session=session,
        session_patch={"current_phase": normalized_resume_target},
    )
    if updates:
        manager.update_session(normalized_session_id, updates)

    return {
        "session_id": normalized_session_id,
        "resume_target": normalized_resume_target,
        "updated_fields": sorted(updates.keys()),
    }


def _scorecard_to_dict(scorecard: Any) -> dict[str, Any]:
    """Serialize a QualityScorecard-like object into a plain mapping."""
    if hasattr(scorecard, "to_dict"):
        payload = scorecard.to_dict()
        if isinstance(payload, dict):
            return payload
    if isinstance(scorecard, dict):
        return dict(scorecard)
    raise ValueError("Seeded escalation fixer requires a scorecard mapping")


def _extract_issue_details_from_reports(
    agent_reports: list[dict[str, Any]],
    issue_ids: set[str],
) -> list[dict[str, Any]]:
    """Collect canonical issue details from review agent reports."""
    details: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for report in agent_reports:
        if not isinstance(report, dict):
            continue
        issues = report.get("issues")
        if not isinstance(issues, list):
            continue
        for issue in issues:
            if not isinstance(issue, dict):
                continue
            canonical_id = str(issue.get("canonical_id") or issue.get("id") or "").strip()
            if not canonical_id or canonical_id in seen_ids:
                continue
            if issue_ids and canonical_id not in issue_ids:
                continue
            detail = dict(issue)
            detail.setdefault("canonical_id", canonical_id)
            detail.setdefault("id", canonical_id)
            details.append(detail)
            seen_ids.add(canonical_id)
    return details


def _build_registry_issue_details(
    scorecard_payload: dict[str, Any],
    issue_ids: list[str],
) -> list[dict[str, Any]]:
    """Backfill issue details from scorecard issue_registry entries."""
    registry = (
        scorecard_payload.get("issue_registry")
        if isinstance(scorecard_payload.get("issue_registry"), dict)
        else {}
    )
    if not isinstance(registry, dict):
        return []
    details: list[dict[str, Any]] = []
    for issue_id in issue_ids:
        entry = registry.get(issue_id)
        if not isinstance(entry, dict):
            continue
        details.append(
            {
                "canonical_id": issue_id,
                "id": issue_id,
                "description": str(entry.get("description") or ""),
                "file_path": str(entry.get("file_path") or ""),
                "priority": str(entry.get("priority") or "P2"),
                "category": str(entry.get("category") or ""),
                "agent_type": str(entry.get("agent_type") or ""),
            }
        )
    return details


def _resolve_pending_escalation_target(
    scorecards: list[dict[str, Any]],
    pending_config: dict[str, Any],
) -> dict[str, Any]:
    """Pick the scorecard that should own the seeded escalation-fixer episode."""
    target_item_id = str(pending_config.get("item_id", "") or "").strip()
    target_iteration = pending_config.get("iteration")
    candidates = []
    for scorecard in scorecards:
        item_id = str(scorecard.get("item_id", "") or "").strip()
        iteration = int(scorecard.get("iteration", 0) or 0)
        if target_item_id and item_id != target_item_id:
            continue
        if target_iteration is not None and iteration != int(target_iteration):
            continue
        candidates.append(scorecard)
    if not candidates:
        raise ValueError(
            "Seeded pending escalation fixer could not find a matching scorecard"
        )
    return sorted(
        candidates,
        key=lambda payload: (
            int(payload.get("iteration", 0) or 0),
            str(payload.get("item_id", "") or ""),
        ),
    )[-1]


def _prime_pending_escalation_fixer(
    *,
    manager: Any,
    session: Any,
    session_id: str,
    pending_config: dict[str, Any],
) -> dict[str, Any]:
    """Seed a pending escalation-fixer validator dispatch into session state."""
    from prompts.registry import get_prompt, get_prompt_metadata
    from obra.config.loaders import get_escalation_fixer_timeout_s

    target_scorecard = _resolve_pending_escalation_target(
        [_scorecard_to_dict(scorecard) for scorecard in manager.get_all_quality_scorecards(session_id)],
        pending_config,
    )
    item_id = str(target_scorecard.get("item_id", "") or "").strip()
    iteration = int(
        pending_config.get("iteration", target_scorecard.get("iteration", 0)) or 0
    )
    effective_issue_ids = [
        issue_id
        for issue_id in (
            pending_config.get("blocking_issue_ids")
            or target_scorecard.get("blocking_issues")
            or []
        )
        if str(issue_id).strip()
    ]
    resolved_issue_ids = {
        str(issue_id).strip()
        for issue_id in (target_scorecard.get("resolved_issues") or [])
        if str(issue_id).strip()
    }
    effective_issue_ids = [
        issue_id for issue_id in effective_issue_ids if issue_id not in resolved_issue_ids
    ]
    if not effective_issue_ids:
        raise ValueError(
            "Seeded pending escalation fixer requires at least one effective blocking issue"
        )

    agent_reports = target_scorecard.get("agent_reports")
    if not isinstance(agent_reports, list):
        agent_reports = []
    normalized_reports = [
        dict(report) for report in agent_reports if isinstance(report, dict)
    ]
    serialized_reports = _serialize_snapshot_value(normalized_reports)
    serialized_scorecard = _serialize_snapshot_value(target_scorecard)

    issue_details = _extract_issue_details_from_reports(
        normalized_reports,
        set(effective_issue_ids),
    )
    if len(issue_details) < len(effective_issue_ids):
        present_ids = {
            str(detail.get("canonical_id") or detail.get("id") or "").strip()
            for detail in issue_details
        }
        missing_ids = [
            issue_id for issue_id in effective_issue_ids if issue_id not in present_ids
        ]
        issue_details.extend(
            _build_registry_issue_details(target_scorecard, missing_ids)
        )

    reason_code = str(pending_config["reason_code"])
    reason_text = str(
        pending_config.get("reason_text")
        or f"Seeded blocked review episode for {item_id} requested escalation fixer."
    ).strip()
    phase_value = getattr(session, "current_phase", "review")
    phase_name = phase_value.value if hasattr(phase_value, "value") else str(phase_value)
    episode_key = f"review:{reason_code}:{item_id or 'session'}:{iteration}"

    plan = manager.get_latest_plan_version(session_id)
    plan_items = [item.to_dict() for item in plan.plan_items] if plan else []
    original_spec = {
        "session_id": session_id,
        "reason": "blocking_issues_unresolved",
        "reason_code": reason_code,
        "reason_text": reason_text,
        "blocking_issues": issue_details,
        "extra": {
            "item_id": item_id,
            "scope": "task",
            "escalation_origin": "review",
            "quality_score": target_scorecard.get("compiled_score"),
            "review_agent_reports": serialized_reports,
            "review_scorecard": serialized_scorecard,
            "review_effective_issue_ids": effective_issue_ids,
            "review_issue_details": issue_details,
        },
        "plan_items": plan_items,
        "iteration": iteration,
        "bypass_modes_active": list(getattr(session, "bypass_modes", []) or []),
    }
    subject_payload = {
        "session_id": session_id,
        "episode_key": episode_key,
        "phase": phase_name,
        "current_iteration": int(getattr(session, "current_iteration", 0) or 0),
        "reason": original_spec["reason"],
        "reason_code": reason_code,
        "reason_text": reason_text,
        "blocking_issues": issue_details,
        "quality_score": target_scorecard.get("compiled_score"),
        "item_id": item_id,
        "origin": "review",
        "convergence_diagnostic": None,
        "scorecard": serialized_scorecard,
        "agent_reports": serialized_reports,
        "review_effective_issue_ids": effective_issue_ids,
        "review_issue_details": issue_details,
        "plan_items": plan_items,
        "escalation_details": None,
        "revision_issues": None,
    }
    prompt_id = "escalation.fixer"
    prompt_metadata = get_prompt_metadata(prompt_id)
    prompt_version = str(prompt_metadata.get("version", "v1"))
    project_context = (
        getattr(session, "project_context", {})
        if isinstance(getattr(session, "project_context", {}), dict)
        else {}
    )
    session_config = (
        project_context.get("config")
        if isinstance(project_context.get("config"), dict)
        else project_context
    )
    review_cfg = (
        session_config.get("review")
        if isinstance(session_config, dict) and isinstance(session_config.get("review"), dict)
        else {}
    )
    escalation_cfg = (
        review_cfg.get("escalation_fixer")
        if isinstance(review_cfg.get("escalation_fixer"), dict)
        else {}
    )
    timeout_s = int(
        escalation_cfg.get("timeout_s")
        or get_escalation_fixer_timeout_s()
    )
    allowed_routes = escalation_cfg.get("allowed_routes")
    if isinstance(allowed_routes, list):
        normalized_allowed_routes = [
            str(route).strip() for route in allowed_routes if str(route).strip()
        ]
    else:
        normalized_allowed_routes = []
    compiled_prompt = (
        f"{get_prompt(prompt_id).rstrip()}\n\n"
        "## Escalation Context\n"
        f"{json.dumps(subject_payload, indent=2, sort_keys=True)}\n"
    )
    validator_request = ValidatorRequest(
        stage="escalation_fix",
        subject_type="escalation_context",
        subject_payload=subject_payload,
        prompt_id=prompt_id,
        prompt_version=prompt_version,
        compiled_prompt=compiled_prompt,
        timeout_s=timeout_s,
        config={
            "schema_validation": True,
            "allowed_routes": normalized_allowed_routes,
        },
    )
    fixer_invocation_id = str(uuid.uuid4())
    invocation_record = {
        "fixer_invocation_id": fixer_invocation_id,
        "session_id": session_id,
        "item_id": item_id or None,
        "scope": "task",
        "phase": phase_name,
        "episode_key": episode_key,
        "origin_stage": "review",
        "origin_reason_code": reason_code,
        "reason_text": reason_text,
        "pre_fixer_state": {"original_escalation": original_spec},
        "prompt_provenance": {
            "prompt_id": prompt_id,
            "prompt_version": prompt_version,
            "model_provider": None,
            "model_name": None,
            "model_tier": "inherit",
            "timeout_s": timeout_s,
        },
        "fixer_result": {},
        "outcome": {
            "fallback_to_original": False,
            "next_action": "",
            "requires_triage": True,
        },
        "status": "requested",
    }
    pipeline_resume_context = {
        "action": "escalate",
        "validator_stage": "escalation_fix",
        "schema_validation": True,
        "fixer_invocation_id": fixer_invocation_id,
        "episode_key": episode_key,
        "origin": "review",
        "original_escalation": original_spec,
        "validator_request": validator_request.to_dict(),
    }
    manager.update_session(
        session_id,
        {
            "pipeline_resume_context": pipeline_resume_context,
            "escalation_fixer_attempted": True,
            "escalation_fixer_episode_key": episode_key,
            "escalation_fixer_origin_reason_code": reason_code,
            "escalation_fixer_attempt_count": 1,
            "escalation_fixer_invocations": [invocation_record],
        },
    )
    manager.store_progress_event(
        session_id,
        "escalation_fixer_requested",
        {
            "fixer_invocation_id": fixer_invocation_id,
            "episode_key": episode_key,
            "reason_code": reason_code,
        },
    )
    return {
        "session_id": session_id,
        "item_id": item_id,
        "iteration": iteration,
        "reason_code": reason_code,
        "fixer_invocation_id": fixer_invocation_id,
        "episode_key": episode_key,
        "effective_issue_ids": effective_issue_ids,
    }


def apply_seeded_review_episode_plan(plan: dict[str, Any]) -> dict[str, Any]:
    """Apply the hydrated review-episode plan to the local emulator."""
    if not plan:
        return {}

    db = _ensure_firestore_initialized()
    session_id = str(plan.get("session_id", "") or "").strip()
    if not session_id:
        raise ValueError("Seeded review episode plan is missing session_id")

    session_snapshot_summary: dict[str, Any] = {}
    session_snapshot = _normalize_session_snapshot(plan.get("session_snapshot"))
    if session_snapshot:
        session_snapshot_summary = restore_seeded_review_session_snapshot(
            session_snapshot
        )

    global_doc = db.collection("sessions").document(session_id).get()
    if not global_doc.exists:
        raise ValueError(
            f"Seeded review episode session not found in emulator: {session_id}"
        )
    global_payload = global_doc.to_dict() or {}
    user_id = str(global_payload.get("user_id", "") or "").strip()
    if not user_id:
        raise ValueError(
            f"Seeded review episode session {session_id} is missing user_id"
        )

    manager = _SeededReviewSessionManager(user_id, db)
    session = manager.get_session(session_id)
    if session is None:
        raise ValueError(
            f"Seeded review episode session not found in user scope: {session_id}"
        )

    updates = prepare_seeded_review_session_updates(
        session=session,
        session_patch=dict(plan.get("session_patch") or {}),
    )
    if updates:
        manager.update_session(session_id, updates)

    for scorecard_payload in plan.get("scorecards") or []:
        manager.store_quality_scorecard(session_id, dict(scorecard_payload))

    pending_escalation_summary: dict[str, Any] = {}
    pending_escalation_fixer = dict(plan.get("pending_escalation_fixer") or {})
    if pending_escalation_fixer:
        refreshed_session = manager.get_session(session_id)
        if refreshed_session is None:
            raise ValueError(
                f"Seeded review episode session not found after scorecard load: {session_id}"
            )
        pending_escalation_summary = _prime_pending_escalation_fixer(
            manager=manager,
            session=refreshed_session,
            session_id=session_id,
            pending_config=pending_escalation_fixer,
        )

    return {
        "session_id": session_id,
        "user_id": user_id,
        "scorecard_count": len(plan.get("scorecards") or []),
        "item_ids": list(plan.get("item_ids") or []),
        "updated_session_fields": sorted(updates),
        "session_snapshot_restored": bool(session_snapshot_summary),
        "project_restored": bool(session_snapshot_summary.get("project_restored")),
        "restored_subcollections": dict(
            session_snapshot_summary.get("restored_subcollections") or {}
        ),
        "restored_doc_count": int(
            session_snapshot_summary.get("restored_doc_count", 0) or 0
        ),
        "pending_escalation_fixer": pending_escalation_summary,
    }
