"""Escalation helpers for CLI run/resume flows."""

from __future__ import annotations

import sys
from typing import Any, Callable

from obra.api.protocol import (
    EscalationDecision,
    EscalationNotice,
    EscalationReason,
    UserDecisionChoice,
)
from obra.display import EscalationRenderer, console, print_warning
from obra.utils.terminal import is_headless as _is_headless


def _build_escalation_callback() -> Callable[[EscalationNotice], EscalationDecision]:
    """Create interactive escalation callback used by run/resume."""
    captured_is_headless = _is_headless()
    captured_is_interactive = bool(
        getattr(sys.stdin, "isatty", lambda: False)()
        and getattr(sys.stdout, "isatty", lambda: False)()
    )

    def on_escalation(notice: EscalationNotice) -> EscalationDecision:
        from obra.display.spinner import suspend_active_spinner

        with suspend_active_spinner():
            EscalationRenderer(console).render_full(notice)

            reason_value = (
                str(getattr(getattr(notice, "reason", ""), "value", notice.reason) or "")
                .strip()
                .lower()
            )
            reason_code = str(getattr(notice, "reason_code", "") or "").strip().lower()
            notice_extra = notice.extra if isinstance(notice.extra, dict) else {}
            notice_metadata = notice.metadata if isinstance(notice.metadata, dict) else {}

            is_convergence_stalled = (
                reason_value == EscalationReason.CONVERGENCE_STALLED.value
                or "convergence" in reason_code
            )
            item_id = str(notice_extra.get("item_id", "unknown") or "unknown").strip()
            if not item_id:
                item_id = "unknown"

            if captured_is_headless or not captured_is_interactive:
                print_warning(
                    "Non-interactive session detected; defaulting escalation decision to force_complete."
                )
                return EscalationDecision(
                    choice=UserDecisionChoice.FORCE_COMPLETE, was_timeout=True,
                )

            prompt_timeout_s = 300
            default_action_str = "force_complete"
            try:
                from obra.config.loaders import load_layered_config

                cfg, _, _ = load_layered_config()
                escalate_cfg = cfg.get("handlers", {}).get("escalate", {})
                if isinstance(escalate_cfg, dict):
                    raw_timeout = escalate_cfg.get("prompt_timeout_s")
                    if raw_timeout is not None:
                        prompt_timeout_s = int(raw_timeout)
                    raw_action = escalate_cfg.get("default_action")
                    if isinstance(raw_action, str) and raw_action.strip():
                        default_action_str = raw_action.strip()
            except Exception:
                pass

            action_map = {
                "force_complete": UserDecisionChoice.FORCE_COMPLETE,
                "continue_fixing": UserDecisionChoice.CONTINUE_FIXING,
                "skip_issues": UserDecisionChoice.SKIP_ISSUES,
                "abandon": UserDecisionChoice.ABANDON,
            }
            default_decision = action_map.get(default_action_str, UserDecisionChoice.FORCE_COMPLETE)

            def _int_or_none(value: Any) -> int | None:
                try:
                    return int(value)
                except (TypeError, ValueError):
                    return None

            current_iteration = _int_or_none(
                notice_metadata.get("current_iteration", notice_metadata.get("iteration"))
            )
            max_iterations = _int_or_none(
                notice_metadata.get(
                    "effective_max_refinement_iterations",
                    notice_metadata.get("max_refinement_iterations"),
                )
            )

            continue_label = (
                f"\\[C]ontinue fixing {item_id} (refactor mode)"
                if is_convergence_stalled
                else "\\[C]ontinue fixing"
            )

            console.print()
            console.print(
                f"  [bold cyan]{continue_label}[/]"
                "  [bold magenta]\\[S]kip issues + continue[/]"
                "  [bold yellow]\\[F]orce complete & exit[/]"
                "  [bold red]\\[A]bandon[/]"
            )
            if current_iteration is not None or max_iterations is not None:
                current_display = str(current_iteration) if current_iteration is not None else "?"
                max_display = str(max_iterations) if max_iterations is not None else "?"
                console.print(f"  [dim]Budget: iteration {current_display}/{max_display}[/dim]")

            countdown_interval_s = 30

            def _read_with_timeout(timeout: int) -> str | None:
                from obra.display.prompting import prompt_input_with_timeout

                value = prompt_input_with_timeout(
                    "Escalation action (c/s/f/a): ",
                    timeout=timeout,
                    default="c",
                )
                return value.lower() if value else None

            def _select(
                raw_choice: str,
                expected_action: UserDecisionChoice,
            ) -> EscalationDecision:
                console.print(f"  [dim]Selected: {raw_choice} → action={expected_action.value}[/dim]")
                return EscalationDecision(choice=expected_action)

            def _format_remaining(seconds: int) -> str:
                if seconds >= 60:
                    minutes, seconds_remainder = divmod(seconds, 60)
                    return (
                        f"{minutes}m {seconds_remainder}s"
                        if seconds_remainder
                        else f"{minutes}m"
                    )
                return f"{seconds}s"

            remaining_s = prompt_timeout_s
            action_label = default_action_str.replace("_", " ")
            if prompt_timeout_s > 0:
                console.print(
                    f"  [dim](auto-{action_label} in {_format_remaining(remaining_s)})[/dim]"
                )

            while True:
                chunk = (
                    min(countdown_interval_s, remaining_s)
                    if remaining_s > 0
                    else remaining_s
                )
                try:
                    choice = _read_with_timeout(chunk)
                except (EOFError, KeyboardInterrupt, OSError):
                    print_warning("Input unavailable; defaulting to force_complete.")
                    return EscalationDecision(
                        choice=UserDecisionChoice.FORCE_COMPLETE, was_timeout=True,
                    )

                if choice is not None:
                    if choice in {"c", "continue", "continue_fixing"}:
                        return _select(choice, UserDecisionChoice.CONTINUE_FIXING)
                    if choice in {"s", "skip", "skip_issues"}:
                        return _select(choice, UserDecisionChoice.SKIP_ISSUES)
                    if choice in {"f", "force", "force_complete"}:
                        return _select(choice, UserDecisionChoice.FORCE_COMPLETE)
                    if choice in {"a", "abandon", "stop"}:
                        return _select(choice, UserDecisionChoice.ABANDON)
                    print_warning("Invalid choice. Enter c, s, f, or a.")
                    continue

                remaining_s -= chunk
                if remaining_s <= 0:
                    print_warning(
                        f"Escalation prompt timed out after {prompt_timeout_s}s; "
                        f"defaulting to {default_action_str}."
                    )
                    return EscalationDecision(
                        choice=default_decision, was_timeout=True,
                    )
                console.print(
                    f"  [dim](auto-{action_label} in {_format_remaining(remaining_s)})[/dim]"
                )

    return on_escalation
