"""Session execution flow for CLI run/derive commands."""

from __future__ import annotations

import atexit
import importlib
import re
from pathlib import Path
from typing import Any, cast

from obra.cli.run_support.launch_context import (
    resolve_continue_from,
    resolve_launch_context,
    resolve_plan_launch_context,
)
from obra.cli.run_support.launch_request import LaunchRequest, validate_launch_request
from obra.cli.run_support.session_display import (
    build_cli_preflight_state,
    build_session_header_context,
    print_llm_preflight,
    print_session_header,
)


def _normalize_objective_preview(objective: str, max_len: int = 160) -> str:
    """Return a single-line objective preview with optional truncation marker."""
    collapsed = re.sub(r"\s+", " ", objective).strip()
    if len(collapsed) <= max_len:
        return collapsed
    trimmed = collapsed[: max_len - 3].rstrip()
    return f"{trimmed}... (truncated)"


def run_derive(
    objective: str | None,
    working_dir: Path | None = None,
    project_id: str | None = None,
    domain: str | None = None,
    resume_session: str | None = None,
    continue_from: str | None = None,
    resume_from: str | None = None,
    rerun_setup: bool = False,
    plan_id: str | None = None,
    plan_file: Path | None = None,
    model: str | None = None,
    fast_model: str | None = None,
    high_model: str | None = None,
    impl_provider: str | None = None,
    reasoning_level: str | None = None,
    verbose: int = 0,
    stream: bool = False,
    plan_only: bool = False,
    permissive: bool = False,
    defaults_json: bool = False,
    no_closeout: bool = False,
    skip_intent: bool = False,
    review_intent: bool = False,
    enrich: bool = False,
    no_enrich: bool = False,
    isolated: bool | None = None,
    no_isolated: bool | None = None,
    full_review: bool = False,
    skip_review: bool = False,
    review_agents: str | None = None,
    with_security: bool = False,
    with_testing: bool = False,
    with_docs: bool = False,
    with_code_quality: bool = False,
    no_security: bool = False,
    no_testing: bool = False,
    no_docs: bool = False,
    no_code_quality: bool = False,
    review_format: str | None = None,
    review_quiet: bool = False,
    review_summary_only: bool = False,
    fail_on_p1: bool = False,
    fail_on_p2: bool = False,
    review_timeout: int | None = None,
    auto_report: bool = False,
    yes: bool = False,
    mock_credentials: bool = False,
    skip_git_check: bool = False,
    auto_init_git: bool = False,
    skip_quality_check: bool = False,
    skip_complexity_check: bool = False,
    parallel: bool = False,
    skip_tier_check: bool = False,
    from_step: int | None = None,
    cascade: bool = False,
    work_type: str | None = None,
    skip_explore: bool = False,
    force_explore: bool = False,
    plan_mode: str | None = None,
) -> None:
    """Execute the shared run/derive session flow."""
    cli = cast(Any, importlib.import_module("obra.cli.run"))

    cli.setup_logging(verbose)

    session_logger = cli.start_session_logging(
        session_id=resume_session or continue_from or cli.datetime.now(cli.UTC).strftime("%Y%m%d_%H%M%S")
    )
    atexit.register(cli.stop_session_logging)

    cli._interrupt_manager.reset()
    cli._interrupt_manager.install()

    request = LaunchRequest(
        objective=objective,
        working_dir=working_dir,
        project_id=project_id,
        resume_session=resume_session,
        continue_from=continue_from,
        resume_from=resume_from,
        rerun_setup=rerun_setup,
        plan_id=plan_id,
        plan_file=plan_file,
        from_step=from_step,
    )
    validate_launch_request(cli, request)

    continue_from_objective = None
    continue_from_plan_context: dict[str, Any] | None = None
    continue_from_session: dict[str, Any] | None = None
    skip_completed_items: list[str] = []
    continue_resolution = resolve_continue_from(
        cli,
        continue_from=continue_from,
        objective=objective,
        working_dir=working_dir,
        skip_intent_requested=skip_intent,
    )
    skip_completed_items = continue_resolution.skip_completed_items
    continue_from_objective = continue_resolution.objective
    continue_from_plan_context = continue_resolution.plan_context
    continue_from_session = continue_resolution.session_data
    skip_intent = continue_resolution.skip_intent

    objective_override = (
        objective.strip() if isinstance(objective, str) and objective.strip() else None
    )
    if not objective_override:
        objective = continue_from_objective or objective

    from obra.config.resolution import resolve_run_config

    run_config = resolve_run_config(
        cli_model=model,
        cli_fast_model=fast_model,
        cli_high_model=high_model,
        cli_provider=impl_provider,
        cli_reasoning_level=reasoning_level,
    )
    effective_model = run_config.model
    effective_fast_model = run_config.fast_model
    effective_high_model = run_config.high_model
    effective_provider = run_config.provider
    effective_reasoning = run_config.reasoning_level

    if effective_fast_model is not None:
        cli.os.environ["OBRA_FAST_MODEL"] = effective_fast_model
    if effective_high_model is not None:
        cli.os.environ["OBRA_HIGH_MODEL"] = effective_high_model

    if effective_reasoning is not None and effective_reasoning not in cli.REASONING_LEVELS:
        cli.print_error(f"Invalid reasoning level: '{effective_reasoning}'")
        cli.console.print(f"\nValid levels: {', '.join(cli.REASONING_LEVELS)}")
        raise cli.typer.Exit(2)

    if effective_model and not effective_provider:
        detected = cli.infer_provider_from_model(effective_model)
        if detected:
            effective_provider = detected
            if verbose > 0:
                cli.console.print(f"[dim]Detected provider: {detected}[/dim]")
        else:
            cli.print_warning(
                f"Unknown model '{effective_model}', using default provider: {cli.DEFAULT_PROVIDER}"
            )
            effective_provider = cli.DEFAULT_PROVIDER

    if objective is not None:
        quality_issues = cli._detect_input_quality_issues(objective)
        if quality_issues:
            cli._show_input_quality_warning(quality_issues)

    progress_emitter = None
    orchestrator = None
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token
        from obra.config import validate_provider_ready
        from obra.hybrid import HybridOrchestrator

        client = APIClient.from_config()

        launch_context = resolve_launch_context(
            cli,
            client=client,
            working_dir=working_dir,
            project_id=project_id,
            resume_session=resume_session,
            continue_from=continue_from,
            continue_from_session=continue_from_session,
            resume_from=resume_from,
            rerun_setup=rerun_setup,
        )
        project_id = launch_context.project_id
        work_dir = launch_context.work_dir
        session_data = launch_context.session_data
        session_project_id = launch_context.session_project_id
        resume_target = launch_context.resume_target

        review_config = cli._build_review_config_from_cli(
            full_review=full_review,
            skip_review=skip_review,
            review_agents=review_agents,
            with_security=with_security,
            with_testing=with_testing,
            with_docs=with_docs,
            with_code_quality=with_code_quality,
            no_security=no_security,
            no_testing=no_testing,
            no_docs=no_docs,
            no_code_quality=no_code_quality,
            review_format=review_format,
            review_quiet=review_quiet,
            review_summary_only=review_summary_only,
            fail_on_p1=fail_on_p1,
            fail_on_p2=fail_on_p2,
            review_timeout=review_timeout,
            project_path=work_dir,
        )

        planning_config = cli._load_planning_config(work_dir)
        config_permissive = bool(planning_config.get("permissive_mode"))
        if not config_permissive:
            from obra.config.loaders import load_layered_config

            layered_cfg, _, _ = load_layered_config(include_defaults=True)
            config_permissive = bool(layered_cfg.get("review", {}).get("permissive_mode"))
        effective_permissive = permissive or config_permissive
        bypass_modes: list[str] = []
        if effective_permissive:
            bypass_modes.append("planning_permissive")
        if no_closeout:
            bypass_modes.append("no_closeout")
        if skip_intent:
            bypass_modes.append("skip_intent")
        if review_intent:
            bypass_modes.append("review_intent")
        if enrich:
            bypass_modes.append("enrich")
        if no_enrich:
            bypass_modes.append("no_enrich")
        if skip_quality_check:
            bypass_modes.append("skip_quality_check")
        if skip_complexity_check:
            bypass_modes.append("skip_complexity_check")
        if parallel:
            bypass_modes.append("parallel")
        if skip_tier_check:
            bypass_modes.append("skip_tier_check")
        if skip_explore:
            bypass_modes.append("skip_explore")
        if force_explore:
            bypass_modes.append("force_explore")

        from obra.config import get_llm_config

        user_llm_config = get_llm_config()
        impl_config = user_llm_config.get("implementation", {})
        display_provider = effective_provider or impl_config.get(
            "provider", cli.DEFAULT_PROVIDER
        )
        validate_provider_ready(display_provider)

        try:
            ensure_valid_token()
        except cli.AuthenticationError as exc:
            cli.display_obra_error(exc, cli.console)
            raise cli.typer.Exit(1) from exc

        plan_launch_context = resolve_plan_launch_context(
            cli,
            client=client,
            project_id=project_id,
            work_dir=work_dir,
            objective=objective,
            plan_id=plan_id,
            plan_file=plan_file,
            continue_from_plan_context=continue_from_plan_context,
            from_step=from_step,
            cascade=cascade,
            verbose=verbose,
        )
        plan_context = plan_launch_context.plan_context
        effective_plan_id = plan_launch_context.effective_plan_id
        userplan_id = plan_launch_context.userplan_id

        if plan_context is None and objective is not None:
            try:
                from obra.execution.intake import create_userplan_from_objective

                userplan = create_userplan_from_objective(
                    objective=objective,
                    project_id=project_id or "default",
                )
                userplan_id = userplan.id

                userplan_source_dict = {
                    "type": userplan.source.type.value,
                    "path": userplan.source.path,
                    "raw_objective": userplan.source.raw_objective,
                    "generated": userplan.source.generated,
                }
                userplan_steps_list = [
                    {
                        "id": step.id,
                        "index": step.index,
                        "title": step.title,
                        "description": step.description,
                        "raw_text": step.raw_text,
                        "derivation_status": step.derivation_status.value,
                        "context": step.context.model_dump() if step.context else None,
                    }
                    for step in userplan.steps
                ]

                from obra.api import APIClient as UserPlanAPIClient

                userplan_client = UserPlanAPIClient.from_config()
                userplan_client.create_userplan(
                    userplan_id=userplan.id,
                    project_id=userplan.project_id,
                    source=userplan_source_dict,
                    steps=userplan_steps_list,
                    status=userplan.status.value,
                    metadata=userplan.metadata,
                )
                cli.console.print(f"[dim]UserPlan created: {userplan_id}[/dim]")
                cli.logger.info("Created UserPlan %s from objective", userplan_id)

            except cli.typer.Exit:
                raise
            except Exception as exc:
                require_persistence = False
                try:
                    from obra.config.loaders import load_layered_config

                    cfg, _, _ = load_layered_config(include_defaults=True)
                    require_persistence = (
                        cfg.get("features", {})
                        .get("userplan", {})
                        .get("require_persistence", False)
                    )
                except Exception:
                    pass

                if require_persistence:
                    cli.logger.exception("Failed to create UserPlan (persistence required): %s", exc)
                    cli.console.print(
                        f"[red]Error: UserPlan creation failed ({exc})[/red]\n"
                        "[dim]Set features.userplan.require_persistence: false for standalone mode[/dim]"
                    )
                    raise cli.typer.Exit(1) from exc
                cli.logger.warning("Failed to create UserPlan from objective: %s", exc, exc_info=True)
                cli.console.print(f"[dim]Note: UserPlan creation skipped ({exc})[/dim]")

        objective_preview = _normalize_objective_preview(objective or continue_from_objective or "(resuming)")
        session_header = build_session_header_context(
            cli,
            client=client,
            project_id=project_id,
            objective_preview=objective_preview,
            work_dir=work_dir,
            verbose=verbose,
        )
        preflight_state = build_cli_preflight_state(working_dir=work_dir, verbose=verbose)

        cli.console.print()
        print_session_header(
            cli,
            header=session_header,
            work_dir=work_dir,
            resume_session=resume_session,
            effective_plan_id=effective_plan_id,
        )
        print_llm_preflight(cli, preflight_state)

        config = cli.load_config()
        story0_override_config: dict[str, Any] | None = None
        if yes or mock_credentials:
            from obra.config.loaders import load_layered_config

            story0_override_config, _, _ = load_layered_config(include_defaults=True)
            if yes:
                story0_override_config.setdefault("story0", {})["auto_approve"] = True
            if mock_credentials:
                story0_override_config.setdefault("story0", {})["mock_credentials"] = True
        ux_config = config.get("features", {}).get("user_experience", {})
        parallel_config = config.get("execution", {}).get("parallel", {})
        parallel_enabled = bool(parallel_config.get("enabled", False))
        if parallel and not parallel_enabled:
            cli.print_warning(
                "Parallel execution is disabled by config (execution.parallel.enabled: false)."
            )
            parallel = False
            if "parallel" in bypass_modes:
                bypass_modes.remove("parallel")
        elif parallel and parallel_enabled:
            cli.os.environ["OBRA_PARALLEL_EXECUTION"] = "1"
            cli.os.environ["OBRA_PARALLEL_MAX_WORKERS"] = str(parallel_config.get("max_workers", 4))
        dashboard_config = ux_config.get("dashboard", {})
        ux_enabled = bool(ux_config.get("enabled", True))
        dashboard_enabled = bool(dashboard_config.get("enabled", True)) and ux_enabled
        footer_hint_enabled = bool(dashboard_config.get("footer_hint", True))
        task_tracker_enabled = bool(dashboard_config.get("task_tracker", True))
        task_tracker_max_next = dashboard_config.get("task_tracker_max_next", 3)
        if not isinstance(task_tracker_max_next, int):
            try:
                task_tracker_max_next = int(task_tracker_max_next)
            except (TypeError, ValueError):
                task_tracker_max_next = 3

        obs_config = cli.ObservabilityConfig(
            verbosity=verbose,
            stream=stream,
            timestamps=True,
            dashboard_enabled=dashboard_enabled,
            footer_hint_enabled=footer_hint_enabled,
            task_tracker_enabled=task_tracker_enabled,
            task_tracker_max_next=task_tracker_max_next,
        )
        cli.set_runtime_verbosity(verbose)

        progress_emitter = cli.ProgressEmitter(obs_config, cli.console)
        progress_json_value = False
        orchestrator = None
        resolved_domain_override = domain
        if resolved_domain_override is None and continue_from_session is not None:
            session_domain = continue_from_session.get("domain")
            if isinstance(session_domain, str) and session_domain.strip():
                resolved_domain_override = session_domain.strip()
        if resolved_domain_override is None and session_project_id:
            session_domain = session_data.get("domain") if isinstance(session_data, dict) else None
            if isinstance(session_domain, str) and session_domain.strip():
                resolved_domain_override = session_domain.strip()
        if resolved_domain_override is None and isinstance(continue_from_plan_context, dict):
            plan_domain = continue_from_plan_context.get(
                "domain_id",
                continue_from_plan_context.get("domain"),
            )
            if isinstance(plan_domain, str) and plan_domain.strip():
                resolved_domain_override = plan_domain.strip()

        def on_progress(action: str, payload: dict) -> None:
            cli._refresh_local_session_heartbeat(orchestrator, action, payload)
            cli._route_progress_event(
                progress_emitter,
                cli.console,
                verbose,
                action,
                payload,
                progress_json=progress_json_value,
            )

        def on_stream(event_type: str, chunk: str) -> None:
            if event_type == "llm_streaming":
                progress_emitter.llm_streaming(chunk)

        on_escalation = cli._build_escalation_callback()

        orchestrator = HybridOrchestrator.from_config(
            working_dir=work_dir,
            on_progress=on_progress,
            on_escalation=on_escalation,
            on_stream=on_stream if stream else None,
            domain=resolved_domain_override,
            impl_provider=effective_provider,
            impl_model=effective_model,
            reasoning_level=effective_reasoning,
            review_config=review_config,
            bypass_modes=bypass_modes,
            defaults_json=defaults_json,
            observability_config=obs_config,
            progress_emitter=progress_emitter,
            skip_git_check=skip_git_check if skip_git_check else None,
            auto_init_git=auto_init_git if auto_init_git else None,
            planning_mode=plan_mode,
            config_override=story0_override_config,
            session_display=preflight_state.session_display,
        )
        cli._install_imported_plan_handler(orchestrator, plan_context)

        cli._interrupt_manager.orchestrator = orchestrator
        cli._interrupt_manager.session_id = resume_session or "<pending>"
        try:
            with cli.defer_interrupts():
                if resume_session:
                    result = orchestrator.resume(
                        resume_session,
                        resume_target=resume_target,
                    )
                else:
                    assert objective is not None, "objective required for derive"
                    from obra.execution.intake import materialize_workflow_derivation_request

                    resolved_domain_id = domain
                    if not resolved_domain_id:
                        resolved_domain = getattr(orchestrator, "_domain", None)
                        resolved_domain_id = getattr(resolved_domain, "name", None)
                    workflow_derivation_request = materialize_workflow_derivation_request(
                        objective=objective,
                        domain_id=resolved_domain_id,
                        plan_context=plan_context,
                        allow_plan_context_domain=False,
                    )
                    result = orchestrator.derive(
                        objective,
                        plan_id=effective_plan_id,
                        plan_only=plan_only,
                        project_id=project_id,
                        bypass_modes=bypass_modes,
                        skip_completed_items=skip_completed_items,
                        userplan_id=userplan_id,
                        from_step=from_step,
                        work_type=work_type,
                        workflow_derivation_request=workflow_derivation_request,
                    )
                session_id = orchestrator.session_id
                if session_id:
                    progress_emitter.set_session_id(session_id)
                    cli._interrupt_manager.session_id = session_id
                    cli.rename_session_logging(session_id)
        except cli.GracefulInterrupt:
            session_id = orchestrator.session_id
            hint_session_id = cli._interrupt_manager.recovery_hint_session_id
            suppress_interrupt_hint = bool(cli._interrupt_manager.recovery_hint_printed) and bool(
                hint_session_id
            ) and (not session_id or str(hint_session_id) == str(session_id))
            if progress_emitter:
                progress_emitter.halt_spinner()
            closeout_ctx = cli._build_interrupted_closeout_context(
                orchestrator=orchestrator,
                session_id=session_id or "",
                objective=objective or continue_from_objective or "",
                suppress_interrupt_hint=suppress_interrupt_hint,
            )
            cli.build_closeout_message(closeout_ctx, cli.console, verbosity=verbose)
            cli._log_closeout_rendered(orchestrator, closeout_ctx)
            raise cli.typer.Exit(130) from None
        finally:
            cli.clear_interrupt_request()

        if progress_emitter:
            progress_emitter.halt_spinner()

        cli.console.print()
        action = getattr(result, "action", None)
        items_completed = 0
        is_plan_only_completion = bool(plan_only)
        if action == "complete" or action is None:
            (
                items_completed,
                total_iterations,
                quality_score,
                was_escalated,
                terminal_phase,
            ) = cli._extract_completion_context(result)

            cli._print_git_file_summary(cli.console, str(work_dir))

            closeout_ctx = cli._build_closeout_context(
                result,
                session_id=session_id,
                objective=objective or continue_from_objective or "",
            )
            session_summary = getattr(result, "session_summary", None)
            if isinstance(session_summary, str):
                is_plan_only_completion = is_plan_only_completion or session_summary.lower().startswith(
                    "plan-only mode:"
                )
            cli.build_closeout_message(closeout_ctx, cli.console, verbosity=verbose)
            cli._log_closeout_rendered(orchestrator, closeout_ctx)

            if was_escalated:
                raise cli.typer.Exit(1)

            if items_completed == 0 and not is_plan_only_completion:
                cli.offer_bug_report(
                    context="orchestration",
                    command_used="obra derive",
                    objective=objective,
                    failure_reason="0 items completed successfully",
                    auto_report=auto_report,
                    orchestrator=orchestrator,
                )
                raise cli.typer.Exit(1)

        else:
            cli.console.print(f"Session state: {action}")

    except cli.typer.Exit:
        raise
    except cli.ConfigurationError as exc:
        if progress_emitter:
            progress_emitter.halt_spinner()
        cli.display_obra_error(exc, cli.console)
        cli.logger.error("Configuration error in derive command: %s", exc, exc_info=True)
        raise cli.typer.Exit(2) from exc
    except cli.ObraConnectionError as exc:
        if progress_emitter:
            progress_emitter.halt_spinner()
        cli.display_obra_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.error("Connection error in derive command: %s", exc, exc_info=True)
        raise cli.typer.Exit(3) from exc
    except cli.APIError as exc:
        if progress_emitter:
            progress_emitter.halt_spinner()
        cli.display_obra_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.error("API error in derive command: %s", exc, exc_info=True)
        cli.offer_bug_report(
            exc,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise cli.typer.Exit(1) from exc
    except cli.ObraError as exc:
        if progress_emitter:
            progress_emitter.halt_spinner()
        cli.display_obra_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.error("Obra error in derive command: %s", exc, exc_info=True)
        cli.offer_bug_report(
            exc,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise cli.typer.Exit(1) from exc
    except Exception as exc:
        if progress_emitter:
            progress_emitter.halt_spinner()
        cli.display_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.exception("Unexpected error in derive command: %s", exc)
        cli.offer_bug_report(
            exc,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise cli.typer.Exit(1) from exc
    finally:
        cli.stop_session_logging()
