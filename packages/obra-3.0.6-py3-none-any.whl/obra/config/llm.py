"""LLM configuration resolution and CLI building for Obra.

Handles model validation, thinking level mapping, config resolution, and CLI argument
construction for all supported LLM providers (Anthropic, OpenAI, Google).

Example:
    from obra.config.llm import resolve_llm_config, build_llm_args

    config = resolve_llm_config("orchestrator", override_model="sonnet")
    args = build_llm_args(config, mode="text")
"""

import logging
from pathlib import Path
from typing import Any, Callable, cast

import yaml

from obra.domains.resolution import (
    DomainResolutionResult,
    normalize_domain_id,
    resolve_domain_precedence,
    unresolved_domain,
)
from obra.exceptions import ConfigurationError
from obra.model_registry import REASONING_LEVELS, get_reasoning_profile, resolve_quality_tier

from .loaders import (
    get_project_layer_path,
    get_provider_tier_defaults,
    get_role_tier_defaults,
    get_tier_fallbacks,
    get_xhigh_supported_models,
    load_config,
    load_layered_config,
    load_llm_section,
    save_config,
)
from .providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)

# --- Extracted sub-modules (REFACTOR-HIGH-PRIORITY-P10-001 Story 3) -----------
# Re-export all symbols that were moved so existing import paths continue to work.
from obra.config.llm_normalization import (  # noqa: F401
    DEFAULT_REASONING_LEVEL,
    DEFAULT_REASONING_SELECTION,
    DEFAULT_THINKING_BUDGET,
    THINKING_BUDGET_MAX,
    THINKING_BUDGET_MIN,
    _base_llm_defaults,
    _coerce_auth_method,
    _coerce_bool,
    _coerce_model,
    _coerce_optional_reasoning_level,
    _coerce_provider,
    _coerce_reasoning_level,
    _coerce_string_list,
    _coerce_thinking_budget,
    _get_env_tier_override,
    _normalize_reasoning_bounds,
    _normalize_reasoning_config,
    _normalize_role_config,
    _normalize_role_tiers,
    _normalize_tier_entry,
    _normalize_tiers,
    _normalized_llm_config,
)
from obra.config.provider_inference import (  # noqa: F401
    MODEL_PROVIDER_PATTERNS,
    MODEL_PROVIDER_PREFIXES,
    MODEL_SHORTCUTS,
    infer_provider_from_model,
    validate_model,
)
from obra.config.reasoning_selection import (  # noqa: F401
    REASONING_LEVEL_MAP,
    ReasoningSelection,
    _materialize_default_reasoning_level,
    get_anthropic_api_thinking_param,
    get_effective_reasoning_value,
    get_reasoning_level_notes,
    resolve_reasoning_selection,
)

# Module logger
logger = logging.getLogger(__name__)

class _RuntimeRefreshDict(dict[str, Any]):
    """Dictionary facade that refreshes from runtime config on each read.

    This keeps public constants backward-compatible while avoiding import-time
    freezing of layered config data.
    """

    def __init__(self, loader: Callable[[], dict[str, Any]]):
        super().__init__()
        self._loader = loader

    def _refresh(self) -> None:
        super().clear()
        super().update(self._loader())

    def __getitem__(self, key: str) -> Any:
        self._refresh()
        return super().__getitem__(key)

    def get(self, key: str, default: Any = None) -> Any:
        self._refresh()
        return super().get(key, default)

    def items(self):
        self._refresh()
        return super().items()

    def keys(self):
        self._refresh()
        return super().keys()

    def values(self):
        self._refresh()
        return super().values()

    def __contains__(self, key: object) -> bool:
        self._refresh()
        return super().__contains__(key)

    def __iter__(self):
        self._refresh()
        return super().__iter__()

    def __len__(self) -> int:
        self._refresh()
        return super().__len__()

    def copy(self) -> dict[str, Any]:
        self._refresh()
        return dict(super().items())


def _load_runtime_provider_tier_defaults() -> dict[str, dict[str, str]]:
    """Load provider tier defaults from layered runtime config."""
    return get_provider_tier_defaults()


def _load_runtime_tier_fallbacks() -> dict[str, tuple[str, ...]]:
    """Load tier fallback chains from layered runtime config."""
    raw = get_tier_fallbacks()
    return {tier: tuple(fallback_list) for tier, fallback_list in raw.items()}


def _load_runtime_xhigh_supported_models() -> dict[str, set[str]]:
    """Load xhigh-supported model sets from layered runtime config."""
    raw = get_xhigh_supported_models()
    return {provider: set(models) for provider, models in raw.items()}

TIER_NAMES: tuple[str, str, str] = ("fast", "medium", "high")

# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.tier_fallbacks.
# User config can override at ~/.obra/config.yaml.
TIER_FALLBACKS: dict[str, tuple[str, ...]] = cast(
    dict[str, tuple[str, ...]],
    _RuntimeRefreshDict(_load_runtime_tier_fallbacks),
)

# Provider-specific tier defaults (FEAT-LLM-TIERS-SPLIT-001)
# Maps provider name to default tier model assignments
# Source: docs/design/PROVIDER_TIER_DEFAULTS.md and obra/model_registry.py
# Note: Use explicit model names for clarity in UI and logs
# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.provider_defaults.
# User config can override at ~/.obra/config.yaml.
PROVIDER_TIER_DEFAULTS: dict[str, dict[str, str]] = cast(
    dict[str, dict[str, str]],
    _RuntimeRefreshDict(_load_runtime_provider_tier_defaults),
)

# Models that support xhigh/maximum reasoning effort
# Used by get_effective_reasoning_value() for fallback logic
# DEPRECATED: This constant now reads from config. To modify defaults, edit
# obra/config/default_config.yaml under llm.xhigh_supported_models.
# User config can override at ~/.obra/config.yaml.
XHIGH_SUPPORTED_MODELS: dict[str, set[str]] = cast(
    dict[str, set[str]],
    _RuntimeRefreshDict(_load_runtime_xhigh_supported_models),
)


def _load_runtime_role_tier_defaults() -> dict[str, dict[str, dict[str, str]]]:
    """Load role-tier defaults from layered runtime config."""
    return get_role_tier_defaults()


# Role-aware tier defaults: provider -> role -> {fast, medium, high}
# Orchestrator may use higher-capability models than implementation for the same tier.
# When a role's tiers are set to "default" (passthrough), these values are used.
# DEPRECATED as hardcoded constant: Now reads from config llm.role_defaults.
# User config can override at ~/.obra/config-layers/01-user.yaml.
ROLE_TIER_DEFAULTS: dict[str, dict[str, dict[str, str]]] = cast(
    dict[str, dict[str, dict[str, str]]],
    _RuntimeRefreshDict(_load_runtime_role_tier_defaults),
)
from obra.config.tier_resolution import (  # noqa: E402,F401
    get_role_tier_default,
    update_role_tiers_for_provider,
)


def apply_provider_config(
    config: dict[str, Any],
    provider: str,
    *,
    model: str | None = None,
    auth_method: str = "oauth",
    roles: list[str] | None = None,
) -> tuple[dict[str, Any], list[str]]:
    """Apply provider selection to config — single codepath for setup, config CLI, and TUI.

    Merges provider settings into existing config (never replaces the llm section).
    Sets tiers to "default" (passthrough) so they resolve at runtime from
    ROLE_TIER_DEFAULTS for the current provider, making config resilient to
    subsequent provider changes via any codepath.

    Args:
        config: Full config dict (modified in place).
        provider: Provider name (anthropic, openai, google, ollama).
        model: Explicit model override. None means "default" (Let Obra choose).
        auth_method: Auth method (default: oauth).
        roles: Roles to update. None means both orchestrator and implementation.

    Returns:
        Tuple of (updated_config, notification_messages).

    Example:
        >>> config = load_config()
        >>> config, msgs = apply_provider_config(config, "openai")
        >>> save_config(config)
    """
    roles_to_update = roles or ["orchestrator", "implementation"]
    effective_model = model if model else "default"
    notifications: list[str] = []

    # Ensure llm section exists
    if "llm" not in config or not isinstance(config.get("llm"), dict):
        config["llm"] = {}

    for role in roles_to_update:
        # Ensure role section exists
        if role not in config["llm"] or not isinstance(config["llm"].get(role), dict):
            config["llm"][role] = {}

        role_section = config["llm"][role]
        role_section["provider"] = provider
        role_section["auth_method"] = auth_method
        role_section["model"] = effective_model
        # Use "default" tiers — resolved at runtime from ROLE_TIER_DEFAULTS
        # for the current provider. This avoids stale tier models when the
        # provider is later changed via a different codepath (TUI, CLI, etc).
        role_section["tiers"] = {"fast": "default", "medium": "default", "high": "default"}

        provider_display = provider.capitalize()
        notifications.append(f"Set {role} to {provider_display} (model: {effective_model})")

    # OpenAI requires git.skip_check
    if provider == "openai":
        llm_section = config["llm"]
        if "git" not in llm_section or not isinstance(llm_section.get("git"), dict):
            llm_section["git"] = {}
        llm_section["git"]["skip_check"] = True

    return config, notifications


def get_project_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Load planning configuration from project-level config layer.

    Args:
        project_path: Base project path (repo root preferred)

    Returns:
        Dictionary with planning config values (empty if not set)

    Raises:
        ConfigurationError: If the planning section is malformed
    """
    if project_path is None:
        return {}

    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_project_id(project_path)
    config_path = get_project_layer_path(project_id)
    if not config_path.exists():
        return {}

    try:
        with config_path.open(encoding="utf-8") as config_file:
            raw_config = yaml.safe_load(config_file) or {}
    except yaml.YAMLError as exc:
        msg = f"Invalid YAML in {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Fix the YAML syntax in the project config layer and try again.",
        ) from exc
    except OSError as exc:
        msg = f"Unable to read {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Check file permissions for the project config layer and retry.",
        ) from exc

    planning_section = raw_config.get("planning")
    if planning_section is None:
        return {}
    if not isinstance(planning_section, dict):
        logger.warning(
            "Ignoring invalid planning section in %s (expected mapping).",
            config_path,
        )
        return {}

    config: dict[str, Any] = {}
    perm_value = planning_section.get("permissive_mode")
    if perm_value is not None:
        if not isinstance(perm_value, bool):
            logger.warning(
                "Ignoring invalid planning.permissive_mode in %s (expected boolean).",
                config_path,
            )
        else:
            config["permissive_mode"] = perm_value

    domain_value = planning_section.get("domain")
    if domain_value is not None:
        if not isinstance(domain_value, str) or not domain_value.strip():
            logger.warning(
                "Ignoring invalid planning.domain in %s (expected non-empty string).",
                config_path,
            )
        else:
            config["domain"] = domain_value.strip()

    # Backward compatibility: allow top-level domain key if present
    if "domain" not in config and isinstance(raw_config.get("domain"), str):
        domain_top = raw_config["domain"].strip()
        if domain_top:
            config["domain"] = domain_top

    return config


def _extract_domain_name(raw_config: dict[str, Any], *, source_label: str) -> DomainResolutionResult:
    orchestration_section = raw_config.get("orchestration")
    if orchestration_section is not None:
        if not isinstance(orchestration_section, dict):
            return DomainResolutionResult(
                status="invalid",
                source=source_label,
                message=f"Invalid orchestration section in {source_label} (expected mapping).",
            )
        else:
            domain_value = orchestration_section.get("domain")
            if domain_value is not None:
                normalized = normalize_domain_id(domain_value)
                if normalized is None:
                    return DomainResolutionResult(
                        status="invalid",
                        source=f"{source_label}:orchestration.domain",
                        raw_value=str(domain_value),
                        message=f"Invalid orchestration.domain in {source_label} (expected non-empty string).",
                    )
                return DomainResolutionResult(
                    status="configured_default",
                    domain_id=normalized,
                    source=f"{source_label}:orchestration.domain",
                )

    planning_section = raw_config.get("planning")
    if isinstance(planning_section, dict):
        domain_value = planning_section.get("domain")
        if domain_value is not None:
            normalized = normalize_domain_id(domain_value)
            if normalized is None:
                return DomainResolutionResult(
                    status="invalid",
                    source=f"{source_label}:planning.domain",
                    raw_value=str(domain_value),
                    message=f"Invalid planning.domain in {source_label} (expected non-empty string).",
                )
            return DomainResolutionResult(
                status="configured_default",
                domain_id=normalized,
                source=f"{source_label}:planning.domain",
            )
    elif planning_section is not None:
        return DomainResolutionResult(
            status="invalid",
            source=source_label,
            message=f"Invalid planning section in {source_label} (expected mapping).",
        )

    domain_top = raw_config.get("domain")
    if domain_top is not None:
        normalized = normalize_domain_id(domain_top)
        if normalized is None:
            return DomainResolutionResult(
                status="invalid",
                source=f"{source_label}:domain",
                raw_value=str(domain_top),
                message=f"Invalid top-level domain in {source_label} (expected non-empty string).",
            )
        return DomainResolutionResult(
            status="configured_default",
            domain_id=normalized,
            source=f"{source_label}:domain",
        )
    return unresolved_domain(source=source_label)


def get_project_orchestration_domain(project_path: Path | None) -> DomainResolutionResult:
    """Load the project-level runtime domain override, if any."""
    if project_path is None:
        return unresolved_domain(source="project config")

    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_project_id(project_path)
    config_path = get_project_layer_path(project_id)
    if not config_path.exists():
        return unresolved_domain(source="project config")

    try:
        with config_path.open(encoding="utf-8") as config_file:
            raw_config = yaml.safe_load(config_file) or {}
    except yaml.YAMLError as exc:
        msg = f"Invalid YAML in {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Fix the YAML syntax in the project config layer and try again.",
        ) from exc
    except OSError as exc:
        msg = f"Unable to read {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Check file permissions for the project config layer and retry.",
        ) from exc

    return _extract_domain_name(raw_config, source_label=str(config_path))


def resolve_orchestration_domain(
    cli_domain: str | None,
    *,
    project_path: Path | None,
    config: dict[str, Any] | None = None,
) -> DomainResolutionResult:
    """Resolve the effective runtime domain for a session."""
    if cli_domain is not None:
        return resolve_domain_precedence(
            ((cli_domain, "explicit", "cli.domain"),)
        )

    project_domain = get_project_orchestration_domain(project_path)
    if project_domain.status == "invalid":
        return project_domain
    if project_domain.is_resolved:
        return resolve_domain_precedence(
            (
                (
                    project_domain.domain_id,
                    "configured_default",
                    project_domain.source or "project config",
                ),
            )
        )

    layered_config = config
    if layered_config is None:
        layered_config, _, _ = load_layered_config(include_defaults=True)

    config_domain = _extract_domain_name(layered_config, source_label="layered config")
    if config_domain.status == "invalid":
        return config_domain
    if config_domain.is_resolved:
        return resolve_domain_precedence(
            (
                (
                    config_domain.domain_id,
                    "configured_default",
                    config_domain.source or "layered config",
                ),
            )
        )
    return unresolved_domain(
        source="layered config",
        message=(
            "No explicit domain was selected and no explicit configured default domain "
            "was found in project or layered config."
        ),
    )


def resolve_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_reasoning_level: str | None = None,
    override_skip_git_check: bool | None = None,
    override_auto_init_git: bool | None = None,
) -> dict[str, Any]:
    """Resolve LLM configuration for a role with optional overrides.

    Resolution order (highest to lowest priority):
    1. Session overrides (passed as arguments, e.g., CLI flags)
    2. Layered config (user, project, session)
    3. Defaults (anthropic, oauth, default, medium)

    Args:
        role: "orchestrator" or "implementation"
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_auth_method: Optional auth method override (session-only)
        override_reasoning_level: Optional thinking level override (session-only)
        override_skip_git_check: Optional git skip check override (CLI flag)
        override_auto_init_git: Optional git auto init override (CLI flag)

    Returns:
        Resolved config dict with provider, auth_method, model, reasoning_level keys
        and optional parse retry controls.
    """
    if role not in ("orchestrator", "implementation"):
        msg = f"Invalid role: {role}"
        raise ValueError(msg)

    # Get base config from layered config
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    # Load git section from layered config (GIT-HARD-001)
    raw_config, _, _ = load_layered_config()
    raw_llm = load_llm_section(raw_config)
    git_config = raw_llm.get("git", {}) if raw_llm else {}
    codex_config = raw_llm.get("codex", {}) if raw_llm else {}

    approval_mode: str | None = None
    if isinstance(codex_config, dict):
        raw_approval = codex_config.get("approval_mode")
        if isinstance(raw_approval, str) and raw_approval.strip():
            approval_value = raw_approval.strip()
            if approval_value in {"suggest", "auto-edit", "full-auto"}:
                approval_mode = approval_value
            else:
                logger.warning(
                    "Ignoring invalid llm.codex.approval_mode '%s'. "
                    "Expected: suggest, auto-edit, full-auto.",
                    approval_value,
                )

    bypass_sandbox = False
    if isinstance(codex_config, dict):
        bypass_sandbox = _coerce_bool(codex_config.get("bypass_sandbox", False), False)
    enable_features: list[str] = []
    disable_features: list[str] = []
    if isinstance(codex_config, dict):
        enable_features = _coerce_string_list(
            codex_config.get("enable_features"),
            "llm.codex.enable_features",
        )
        disable_features = _coerce_string_list(
            codex_config.get("disable_features"),
            "llm.codex.disable_features",
        )

    conflicting_features = set(enable_features) & set(disable_features)
    if conflicting_features:
        msg = (
            "Invalid Codex feature configuration: the same feature cannot appear in both "
            "llm.codex.enable_features and llm.codex.disable_features. "
            f"Conflicts: {', '.join(sorted(conflicting_features))}"
        )
        raise ConfigurationError(
            msg,
            "Remove overlapping feature names from one list.",
        )

    # Backward compatibility: Check for old llm.codex.skip_git_check config (GIT-HARD-001)
    skip_check = git_config.get("skip_check")
    if skip_check is None:
        # Check old config path: llm.codex.skip_git_check
        codex_config = raw_llm.get("codex", {}) if raw_llm else {}
        old_skip_check = codex_config.get("skip_git_check")
        if old_skip_check is not None:
            skip_check = old_skip_check
            from obra.messages import get_message

            logger.warning(
                get_message(
                    "warning.deprecation.config_key",
                    old="llm.codex.skip_git_check",
                    new="llm.git.skip_check",
                )
            )
        else:
            skip_check = False
    else:
        skip_check = bool(skip_check)

    # Resolve provider: top-level "per-role" means use role-specific provider
    # Role-level "per-tier" means each tier can have its own provider
    raw_top_provider = raw_llm.get("provider") if raw_llm else None
    top_level_provider = llm_config.get("provider", "per-role")
    if not raw_top_provider:
        top_level_provider = "per-role"
    role_level_provider = role_config.get("provider", DEFAULT_PROVIDER)

    if top_level_provider not in ("per-role", "per-tier"):
        # Top-level provider cascades to all roles
        effective_provider = top_level_provider
    elif role_level_provider not in ("per-role", "per-tier"):
        # Role-level provider
        effective_provider = role_level_provider
    else:
        # Provider is "per-tier": look at medium tier to get a default provider
        tier_config = role_config.get("tiers", {})
        tier_entry = tier_config.get("medium", {})
        if isinstance(tier_entry, dict) and "provider" in tier_entry:
            effective_provider = tier_entry["provider"]
        elif isinstance(tier_entry, str):
            # Model name only - infer provider from model
            inferred = infer_provider_from_model(tier_entry)
            effective_provider = inferred if inferred else DEFAULT_PROVIDER
        else:
            effective_provider = DEFAULT_PROVIDER

    # Resolve model: "per-tier", "per-role", and "default" all mean look up
    # from tier config / provider defaults. Only explicit model names cascade.
    # "default" must NOT pass through as a literal — it causes provider CLIs
    # (especially Gemini) to run in auto mode instead of using the configured
    # tier model (e.g., gemini-3-pro-preview for orchestrator medium tier).
    _model_passthrough = ("per-tier", "per-role", "default")
    raw_top_model = raw_llm.get("model") if raw_llm else None
    top_level_model = llm_config.get("model", "per-tier")
    if not raw_top_model:
        top_level_model = "per-tier"
    role_level_model = role_config.get("model", "per-tier")

    provider_defaults = PROVIDER_TIER_DEFAULTS.get(effective_provider, {})

    if top_level_model not in _model_passthrough:
        # Top-level explicit model cascades to all roles
        effective_model = top_level_model
    elif role_level_model not in _model_passthrough:
        # Role-level explicit model
        effective_model = role_level_model
    else:
        # Resolve from tier config - use "medium" as default tier
        tier_config = role_config.get("tiers", {})
        tier_entry = tier_config.get("medium")
        if tier_entry and tier_entry not in _model_passthrough:
            # Tier entry can be a string (model name) or dict (full config)
            if isinstance(tier_entry, str):
                effective_model = tier_entry
            elif isinstance(tier_entry, dict):
                tier_model = tier_entry.get("model", DEFAULT_MODEL)
                if tier_model not in _model_passthrough:
                    effective_model = tier_model
                else:
                    # Try role-aware defaults first, then provider defaults
                    role_default = get_role_tier_default(
                        effective_provider, role, "medium"
                    )
                    effective_model = (
                        role_default
                        if role_default and role_default != "default"
                        else provider_defaults.get("medium", DEFAULT_MODEL)
                    )
            else:
                effective_model = DEFAULT_MODEL
        else:
            # Fall back to role-aware tier defaults, then provider defaults
            role_default = get_role_tier_default(
                effective_provider, role, "medium"
            )
            if role_default and role_default != "default":
                effective_model = role_default
            else:
                effective_model = provider_defaults.get("medium", DEFAULT_MODEL)

    # Start with resolved values
    resolved = {
        "provider": effective_provider,
        "auth_method": role_config.get("auth_method", DEFAULT_AUTH_METHOD),
        "model": effective_model,
        "reasoning_level": role_config.get("reasoning_level", DEFAULT_REASONING_LEVEL),
        "parse_retry_enabled": role_config.get("parse_retry_enabled", True),
        "parse_retry_providers": role_config.get("parse_retry_providers"),
        "parse_retry_models": role_config.get("parse_retry_models"),
        "git": {
            "skip_check": skip_check,
            "auto_init": git_config.get("auto_init", False),
        },
        "codex": {
            "approval_mode": approval_mode,
            "bypass_sandbox": bypass_sandbox,
            "enable_features": enable_features,
            "disable_features": disable_features,
        },
    }

    # Apply overrides (session-only, don't persist)
    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_auth_method:
        if override_auth_method not in LLM_AUTH_METHODS:
            msg = f"Invalid auth method: {override_auth_method}"
            raise ValueError(msg)
        resolved["auth_method"] = override_auth_method

    if override_model:
        # Validate model against resolved provider
        resolved["model"] = validate_model(override_model, resolved["provider"])

    if override_reasoning_level:
        if override_reasoning_level not in (*REASONING_LEVELS, DEFAULT_REASONING_SELECTION):
            msg = (
                f"Invalid reasoning level: {override_reasoning_level}. "
                f"Valid: {', '.join([*REASONING_LEVELS, DEFAULT_REASONING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["reasoning_level"] = override_reasoning_level

    resolved["reasoning_level"] = _materialize_default_reasoning_level(
        resolved["provider"],
        resolved["model"],
        resolved.get("reasoning_level"),
        role=role,
        tier="medium",
    )

    # Apply git overrides (CLI flags override config)
    if override_skip_git_check is not None:
        resolved["git"]["skip_check"] = override_skip_git_check
        logger.debug(f"Git skip_check overridden by CLI flag: {override_skip_git_check}")

    if override_auto_init_git is not None:
        resolved["git"]["auto_init"] = override_auto_init_git
        logger.debug(f"Git auto_init overridden by CLI flag: {override_auto_init_git}")

    if resolved["provider"] in ("openai", "ollama"):
        provider_label = "OpenAI" if resolved["provider"] == "openai" else "Ollama"
        if (
            resolved["git"]["skip_check"] is not True
            or resolved["codex"]["approval_mode"] != "full-auto"
            or resolved["codex"]["bypass_sandbox"] is not True
        ):
            logger.info(
                "%s provider selected; forcing git.skip_check, codex.approval_mode, "
                "and codex.bypass_sandbox to safe defaults for Codex CLI.",
                provider_label,
            )
        resolved["git"]["skip_check"] = True
        resolved["codex"]["approval_mode"] = "full-auto"
        resolved["codex"]["bypass_sandbox"] = True

    return resolved


def get_llm_config() -> dict[str, Any]:
    """Get LLM configuration from config file.

    Returns:
        Normalized LLM config with role defaults and optional tiers:
        {
            "provider": "anthropic",
            "auth_method": "oauth",
            "model": "default",
            "reasoning_level": "medium",
            "orchestrator": {...},
            "implementation": {...},
            "tiers": {
                "fast": {
                    "provider": "...",
                    "auth_method": "...",
                    "model": "...",
                    "reasoning_level": "...",
                }
            }
        }
    """
    config, _, _ = load_layered_config()
    llm_section = load_llm_section(config)
    if not llm_section:
        return _normalized_llm_config({})
    return _normalized_llm_config(llm_section)


from obra.config.tier_resolution import resolve_tier_config  # noqa: E402,F401
from obra.config.llm_display import get_llm_display, get_reasoning_keyword  # noqa: E402,F401
from obra.config.llm_cli_builder import build_llm_args, get_llm_cli  # noqa: E402,F401


def set_llm_config(
    role: str,  # "orchestrator" or "implementation"
    provider: str,
    auth_method: str,
    model: str = "default",
    reasoning_level: str = "medium",
) -> str:
    """Set LLM configuration for a specific role.

    Thin wrapper around apply_provider_config for backward compatibility.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai, google)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)
        reasoning_level: Abstract reasoning level (off, low, medium, high, extra high, maximum)

    Returns:
        Notification message (joined), empty string if none.
    """
    config = load_config()
    config, notifications = apply_provider_config(
        config,
        provider,
        model=model if model != "default" else None,
        auth_method=auth_method,
        roles=[role],
    )
    save_config(config)
    return "; ".join(notifications)


def get_llm_command() -> tuple[str, list[str]]:
    """Get the implementation LLM command and arguments.

    Returns:
        Tuple of (command, args) for subprocess execution.
        Uses provider-specific CLI:
        - Anthropic: claude (Claude Code CLI)
        - Google: gemini (Gemini CLI)
        - OpenAI: codex (OpenAI Codex CLI)

    Note:
        Consider using resolve_llm_config() + build_llm_args() for more control.
    """
    llm_config = get_llm_config()
    impl_config = llm_config.get("implementation", {})

    provider = impl_config.get("provider", DEFAULT_PROVIDER)
    model = impl_config.get("model", DEFAULT_MODEL)

    cli = get_llm_cli(provider)
    args = build_llm_args({"provider": provider, "model": model})

    return cli, args




# Handler role names for role-based LLM configuration (ADR-061)
# Canonical pre-planning keys use the "enrichment_*" prefix. Legacy
# "scaffolded_*" aliases are accepted via _ROLE_ALIASES.
HANDLER_ROLES = (
    "derive",
    "examine",
    "revise",
    "execute",
    "fix",
    "review",
    "validator",
    "enrichment_assumptions",
    "enrichment_analogues",
    "enrichment_brief",
)

_ROLE_ALIASES: dict[str, str] = {
    "scaffolded_assumptions": "enrichment_assumptions",
    "scaffolded_analogues": "enrichment_analogues",
    "scaffolded_brief": "enrichment_brief",
}

# Default role-to-profile mappings when llm.roles is not configured
# Planning roles use orchestrator, execution roles use implementation
DEFAULT_ROLE_MAPPINGS: dict[str, str] = {
    # Handler actions
    "derive": "orchestrator",
    "examine": "orchestrator",
    "revise": "orchestrator",
    "execute": "implementation",
    "fix": "implementation",
    "review": "implementation",
    "validator": "implementation",
    # Intent enrichment stages (canonical keys)
    "enrichment_assumptions": "orchestrator",
    "enrichment_analogues": "orchestrator",
    "enrichment_brief": "orchestrator",
}


def _normalize_role_key(role: str) -> str:
    """Normalize role/action keys, supporting legacy aliases."""
    role_key = role.strip().lower()
    return _ROLE_ALIASES.get(role_key, role_key)


def _get_role_entry(roles: dict[str, Any], role: str) -> Any:
    """Return role config entry, checking canonical and legacy aliases."""
    if role in roles:
        return roles.get(role)
    for legacy_key, canonical_key in _ROLE_ALIASES.items():
        if canonical_key == role and legacy_key in roles:
            return roles.get(legacy_key)
    return None


def _resolve_action_profile(action: str) -> str:
    """Resolve action to orchestration profile role for tier-based routing."""
    action_key = _normalize_role_key(action)
    default_profile = DEFAULT_ROLE_MAPPINGS.get(action_key, "implementation")
    if default_profile not in ("orchestrator", "implementation"):
        default_profile = "implementation"

    llm_config = get_llm_config()
    roles = llm_config.get("roles", {})
    profiles = llm_config.get("profiles", {})
    role_entry = _get_role_entry(roles, action_key)

    if isinstance(role_entry, str):
        if role_entry in ("orchestrator", "implementation"):
            return role_entry
        if role_entry in profiles:
            return default_profile
    elif isinstance(role_entry, dict):
        profile_name = role_entry.get("profile")
        if isinstance(profile_name, str) and profile_name in ("orchestrator", "implementation"):
            return profile_name
        if isinstance(profile_name, str) and profile_name in profiles:
            return default_profile

    return default_profile


def resolve_action_llm_config(
    action: str,
    *,
    model_tier: str | None = None,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_reasoning_level: str | None = None,
) -> dict[str, Any]:
    """Canonical operation resolver: action -> role -> tier/model config.

    Args:
        action: Action/handler key (derive, examine, revise, execute, fix, review, ...)
        model_tier: Optional fast/medium/high tier selector for the action.
            If omitted, resolves action profile config directly.
        override_provider: Optional provider override.
        override_model: Optional model override.
        override_auth_method: Optional auth method override (tier path only).
        override_reasoning_level: Optional thinking level override.

    Returns:
        Resolved LLM config dictionary.
    """
    action_key = _normalize_role_key(action)
    if model_tier:
        profile_role = _resolve_action_profile(action_key)
        return resolve_tier_config(
            tier=model_tier,
            role=profile_role,
            override_provider=override_provider,
            override_model=override_model,
            override_auth_method=override_auth_method,
            override_reasoning_level=override_reasoning_level,
        )

    return resolve_role_llm_config(
        action_key,
        override_provider=override_provider,
        override_model=override_model,
        override_reasoning_level=override_reasoning_level,
    )


def resolve_role_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_reasoning_level: str | None = None,
) -> dict[str, Any]:
    """Resolve LLM config for a handler role (derive, examine, execute, etc.).

    This function provides indirection between handlers and LLM settings,
    allowing different handlers to use different models based on configuration.

    Resolution order:
    1. llm.roles.<role> - explicit role configuration
    2. llm.profiles.<profile> - if role references a profile
    3. Default mapping (derive->orchestrator, execute->implementation)
    4. Top-level llm.* settings as final fallback

    Args:
        role: Handler role name (derive, examine, revise, execute, fix, review)
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_reasoning_level: Optional thinking level override (session-only)

    Returns:
        Resolved config dict with provider, auth_method, model, reasoning_level keys

    Example:
        >>> # With config: llm.roles.derive: orchestrator
        >>> config = resolve_role_llm_config("derive")
        >>> config["model"]
        'opus'

        >>> # With config: llm.roles.execute: {profile: implementation, reasoning_level: low}
        >>> config = resolve_role_llm_config("execute")
        >>> config["reasoning_level"]
        'low'

    See:
        ADR-069: Role-Based LLM Configuration
    """
    role_key = _normalize_role_key(role)

    if role_key not in HANDLER_ROLES:
        logger.warning("Unknown handler role '%s', using implementation config", role)
        return resolve_llm_config("implementation")

    llm_config = get_llm_config()
    profiles = llm_config.get("profiles", {})
    roles = llm_config.get("roles", {})

    # Get role entry (may be string, dict, or None)
    role_entry = _get_role_entry(roles, role_key)

    resolved: dict[str, Any]

    if role_entry is None:
        # No explicit role config - use default mapping
        default_profile = DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
        if default_profile in profiles:
            resolved = profiles[default_profile].copy()
        else:
            # Fall back to legacy role config (llm.orchestrator.* or llm.implementation.*)
            resolved = resolve_llm_config(default_profile)

    elif isinstance(role_entry, str):
        # Simple profile reference: "derive: orchestrator"
        if role_entry in profiles:
            resolved = profiles[role_entry].copy()
        elif role_entry in ("orchestrator", "implementation"):
            # Legacy role name reference
            resolved = resolve_llm_config(role_entry)
        else:
            logger.warning(
                "Role '%s' references unknown profile '%s', using default",
                role_key,
                role_entry,
            )
            resolved = resolve_llm_config(DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"))

    elif isinstance(role_entry, dict):
        if "profile" in role_entry:
            # Profile with overrides: {profile: orchestrator, reasoning_level: high}
            profile_name = role_entry["profile"]
            if profile_name in profiles:
                resolved = profiles[profile_name].copy()
            elif profile_name in ("orchestrator", "implementation"):
                resolved = resolve_llm_config(profile_name)
            else:
                logger.warning(
                    "Role '%s' references unknown profile '%s', using default",
                    role_key,
                    profile_name,
                )
                resolved = resolve_llm_config(DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"))

            # Apply overrides from role entry
            for key, value in role_entry.items():
                if key != "profile" and value is not None:
                    resolved[key] = value
        else:
            # Fully custom config (no profile reference)
            # Start with defaults and overlay role-specific settings
            default_profile = DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
            resolved = resolve_llm_config(default_profile)
            for key, value in role_entry.items():
                if value is not None:
                    resolved[key] = value
    else:
        logger.warning(
            "Invalid role config type for '%s': %s, using default",
            role_key,
            type(role_entry).__name__,
        )
        resolved = resolve_llm_config(DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"))

    # Apply session overrides (highest priority)
    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_model:
        resolved["model"] = validate_model(
            override_model, resolved.get("provider", DEFAULT_PROVIDER)
        )

    if override_reasoning_level:
        if override_reasoning_level not in (*REASONING_LEVELS, DEFAULT_REASONING_SELECTION):
            msg = (
                f"Invalid reasoning level: {override_reasoning_level}. "
                f"Valid: {', '.join([*REASONING_LEVELS, DEFAULT_REASONING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["reasoning_level"] = override_reasoning_level

    context_role = _resolve_action_profile(role_key)
    # Compute context tier from the resolved model so reasoning-level
    # materialization uses the model's intrinsic quality tier instead of
    # assuming "medium".  An explicit tier in the role entry still wins.
    context_tier = resolve_quality_tier(
        resolved.get("provider", DEFAULT_PROVIDER),
        resolved.get("model", ""),
    )
    if isinstance(role_entry, dict):
        tier_value = role_entry.get("tier")
        if isinstance(tier_value, str) and tier_value in TIER_NAMES:
            context_tier = tier_value
    resolved["reasoning_level"] = _materialize_default_reasoning_level(
        resolved.get("provider", DEFAULT_PROVIDER),
        resolved.get("model"),
        resolved.get("reasoning_level"),
        role=context_role,
        tier=context_tier,
    )

    logger.debug(
        "Resolved role '%s' config: provider=%s, model=%s, reasoning=%s",
        role_key,
        resolved.get("provider"),
        resolved.get("model"),
        resolved.get("reasoning_level"),
    )

    return resolved


# Public exports
__all__ = [
    "DEFAULT_ROLE_MAPPINGS",
    "DEFAULT_THINKING_BUDGET",
    # Reasoning level constants (ADR-073)
    "DEFAULT_REASONING_SELECTION",
    "DEFAULT_REASONING_LEVEL",
    # Role-based configuration (ADR-061)
    "HANDLER_ROLES",
    "MODEL_PROVIDER_PATTERNS",
    "MODEL_PROVIDER_PREFIXES",
    # Model constants
    "MODEL_SHORTCUTS",
    "PROVIDER_TIER_DEFAULTS",
    "ROLE_TIER_DEFAULTS",
    "THINKING_BUDGET_MAX",
    # Thinking budget constants (Anthropic-specific, not renamed)
    "THINKING_BUDGET_MIN",
    "REASONING_LEVELS",
    "REASONING_LEVEL_MAP",
    "TIER_FALLBACKS",
    "TIER_NAMES",
    "XHIGH_SUPPORTED_MODELS",
    "ReasoningSelection",
    "build_llm_args",
    "get_anthropic_api_thinking_param",
    "get_effective_reasoning_value",
    "get_llm_cli",
    "get_llm_command",
    "get_llm_config",
    "get_role_tier_default",
    "get_llm_display",
    "get_project_planning_config",
    "get_provider_tier_defaults",
    # CLI building
    "get_reasoning_keyword",
    # Reasoning level functions
    "get_reasoning_level_notes",
    # Model inference
    "infer_provider_from_model",
    # Config resolution
    "resolve_llm_config",
    "resolve_action_llm_config",
    "resolve_reasoning_selection",
    "resolve_role_llm_config",
    "resolve_tier_config",
    "apply_provider_config",
    "set_llm_config",
    "update_role_tiers_for_provider",
    # Model validation
    "validate_model",
]
