"""Derivation and decomposition getter owners."""

from __future__ import annotations

import logging
import os
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults

logger = logging.getLogger(__name__)
# Rule D: declare locally, do NOT import from _defaults
_DERIVATION_LOOKBACK_DEPRECATION_LOGGED = False

__all__ = [
    "get_decomposition_failure_threshold",
    "get_derivation_auto_decompose_config",
    "get_derivation_budget_config",
    "get_derivation_exploration_lookback_minutes",
    "get_derivation_serialize_max_concurrent",
    "get_derivation_stall_threshold",
    "get_derivation_step1_tier",
    "get_derivation_step2_tier",
    "get_derivation_step3_tier",
    "get_derivation_step_tier",
    "get_derivation_step_timeout",
    "get_derivation_task_config",
    "get_refinement_parallel_max_workers",
    "get_refinement_regression_min_delta",
    "get_refinement_regression_threshold_multiplier",
    "get_refinement_straggler_alert_threshold",
    "is_decomposition_enabled",
]


def is_decomposition_enabled() -> bool:
    """Check whether adaptive decomposition is enabled.

    Requires both features.userplan.auto_decompose.enabled and
    orchestration.decomposition.enabled (or legacy orchestration.auto_decompose_on_timeout).
    """
    config, _, _ = _core.load_layered_config()

    auto_decompose_enabled = True
    features_config = config.get("features", {})
    if isinstance(features_config, dict):
        userplan_config = features_config.get("userplan", {})
        if isinstance(userplan_config, dict):
            auto_decompose_config = userplan_config.get("auto_decompose", {})
            if isinstance(auto_decompose_config, dict):
                enabled = auto_decompose_config.get("enabled")
                if enabled is not None:
                    auto_decompose_enabled = bool(enabled)

    decomposition_enabled = _defaults.DEFAULT_DECOMPOSITION_ENABLED
    enabled = None
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        decomposition_config = orch_config.get("decomposition", {})
        if isinstance(decomposition_config, dict):
            enabled = decomposition_config.get("enabled")
            if enabled is not None:
                decomposition_enabled = bool(enabled)
        if enabled is None:
            legacy_enabled = orch_config.get("auto_decompose_on_timeout")
            if legacy_enabled is not None:
                decomposition_enabled = bool(legacy_enabled)

    return auto_decompose_enabled and decomposition_enabled


def get_decomposition_failure_threshold() -> int:
    """Get the canonical repeated-failure decomposition threshold."""
    config, _, _ = _core.load_layered_config()

    orchestration = config.get("orchestration", {})
    if isinstance(orchestration, dict):
        decomposition = orchestration.get("decomposition", {})
        if isinstance(decomposition, dict):
            raw_threshold = decomposition.get("failure_threshold")
            if raw_threshold is not None:
                try:
                    threshold = int(raw_threshold)
                    if threshold > 0:
                        return threshold
                except (TypeError, ValueError):
                    pass

    derivation = config.get("derivation", {})
    if isinstance(derivation, dict):
        auto_decompose = derivation.get("auto_decompose", {})
        if isinstance(auto_decompose, dict):
            raw_threshold = auto_decompose.get("failure_threshold")
            if raw_threshold is not None:
                try:
                    threshold = int(raw_threshold)
                    if threshold > 0:
                        return threshold
                except (TypeError, ValueError):
                    pass

    return _defaults.DEFAULT_DECOMPOSITION_FAILURE_THRESHOLD


def get_derivation_step_timeout(step_name: str) -> int:
    """Get timeout for a specific derivation step in seconds.

    .. deprecated::
        ISSUE-DERIVE-001: This function has been superseded and will be removed.
        Post-hoc timeout checks cannot detect actual stalls - only duration
        after completion. Real stall detection is handled by MonitoringThread
        during CLI subprocess execution. The CLI subprocess timeout (7200s)
        is the authoritative timeout mechanism.

    Args:
        step_name: Name of the derivation step (structure, tasks, serialize)

    Returns:
        Timeout in seconds (600s default, but value is unused)
    """
    import warnings

    warnings.warn(
        "get_derivation_step_timeout has been superseded per ISSUE-DERIVE-001. "
        "Post-hoc timeout checks were removed; use CLI subprocess timeout instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return 600


def get_derivation_stall_threshold() -> int:
    """Get stall warning threshold for derivation in seconds.

    Resolution order:
    1. derivation.pipeline.stall_warning_threshold from config file
    2. Default 30 seconds

    Returns:
        Stall warning threshold in seconds
    """
    config, _, _ = _core.load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        pipeline_config = derivation_config.get("pipeline", {})
        if isinstance(pipeline_config, dict):
            threshold = pipeline_config.get("stall_warning_threshold")
            if threshold is not None:
                try:
                    value = int(threshold)
                    if value > 0:
                        return value
                    logger.warning(
                        "derivation.pipeline.stall_warning_threshold must be > 0 (got %s)",
                        threshold,
                    )
                except (TypeError, ValueError):
                    pass

    return 30


def get_derivation_serialize_max_concurrent() -> int:
    """Get max concurrent workers for Step 3 per-epic JSON serialization.

    Resolution order:
    1. OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT environment variable
    2. derivation.serialize.max_concurrent from config file
    3. KeyError if missing (default must be in default_config.yaml)

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_DERIVATION_SERIALIZE_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        serialize_config = derivation_config.get("serialize", {})
        if isinstance(serialize_config, dict):
            max_concurrent = serialize_config.get("max_concurrent")
            if max_concurrent is not None:
                try:
                    value = int(max_concurrent)
                    if value > 0:
                        return value
                    logger.warning(
                        "derivation.serialize.max_concurrent must be > 0 (got %s)",
                        max_concurrent,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "derivation.serialize.max_concurrent must be an integer (got %s)",
                        max_concurrent,
                    )

    return 4


def get_refinement_parallel_max_workers() -> int:
    """Get max concurrent workers for parallel refinement batch dispatch.

    Resolution order:
    1. OBRA_REFINEMENT_PARALLEL_MAX_WORKERS environment variable
    2. refinement.parallel.max_workers from config file
    3. Default: 4

    Returns:
        Max concurrent workers for refinement examination/revision batches.
    """
    env_val = os.environ.get("OBRA_REFINEMENT_PARALLEL_MAX_WORKERS")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_REFINEMENT_PARALLEL_MAX_WORKERS must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_REFINEMENT_PARALLEL_MAX_WORKERS must be an integer (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    refinement_config = config.get("refinement", {})
    if isinstance(refinement_config, dict):
        parallel_config = refinement_config.get("parallel", {})
        if isinstance(parallel_config, dict):
            max_workers = parallel_config.get("max_workers")
            if max_workers is not None:
                try:
                    value = int(max_workers)
                    if value > 0:
                        return value
                    logger.warning(
                        "refinement.parallel.max_workers must be > 0 (got %s)",
                        max_workers,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "refinement.parallel.max_workers must be an integer (got %s)",
                        max_workers,
                    )

    return 4


def get_refinement_straggler_alert_threshold() -> float:
    """Get straggler alert threshold for parallel refinement telemetry.

    Resolution order:
    1. OBRA_REFINEMENT_STRAGGLER_ALERT_THRESHOLD environment variable
    2. refinement.straggler_alert_threshold from config file
    3. Default: 1.5
    """
    env_key = "OBRA_REFINEMENT_STRAGGLER_ALERT_THRESHOLD"
    env_val = os.environ.get(env_key)
    if env_val is not None:
        try:
            value = float(env_val)
            if value > 0:
                return value
            logger.warning("%s must be > 0 (got %s)", env_key, env_val)
        except (TypeError, ValueError):
            logger.warning("%s must be a float (got %s)", env_key, env_val)

    config, _, _ = _core.load_layered_config()
    refinement_config = config.get("refinement", {})
    if isinstance(refinement_config, dict):
        threshold = refinement_config.get("straggler_alert_threshold")
        if threshold is not None:
            try:
                value = float(threshold)
                if value > 0:
                    return value
                logger.warning(
                    "refinement.straggler_alert_threshold must be > 0 (got %s)",
                    threshold,
                )
            except (TypeError, ValueError):
                logger.warning(
                    "refinement.straggler_alert_threshold must be a float (got %s)",
                    threshold,
                )

    return _defaults.DEFAULT_REFINEMENT_STRAGGLER_ALERT_THRESHOLD


def get_refinement_regression_threshold_multiplier() -> float:
    """Get blocking-issue regression threshold multiplier for post-revise guardrails.

    Resolution order:
    1. OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER environment variable
    2. OBRA_REFINEMENT_REGRESSION_THRESHOLD (legacy env name)
    3. refinement.regression_threshold_multiplier from config file
    4. Default: 3.0
    """
    primary_env = "OBRA_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER"
    legacy_env = "OBRA_REFINEMENT_REGRESSION_THRESHOLD"

    env_val = os.environ.get(primary_env)
    if env_val is None:
        env_val = os.environ.get(legacy_env)
        if env_val is not None:
            logger.warning(
                "%s is deprecated; use %s",
                legacy_env,
                primary_env,
            )

    if env_val is not None:
        try:
            value = float(env_val)
            if value > 0:
                return value
            logger.warning(
                "%s must be > 0 (got %s)",
                primary_env,
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "%s must be a float (got %s)",
                primary_env,
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    refinement_config = config.get("refinement", {})
    if isinstance(refinement_config, dict):
        threshold = refinement_config.get("regression_threshold_multiplier")
        if threshold is not None:
            try:
                value = float(threshold)
                if value > 0:
                    return value
                logger.warning(
                    "refinement.regression_threshold_multiplier must be > 0 (got %s)",
                    threshold,
                )
            except (TypeError, ValueError):
                logger.warning(
                    "refinement.regression_threshold_multiplier must be a float (got %s)",
                    threshold,
                )

    return _defaults.DEFAULT_REFINEMENT_REGRESSION_THRESHOLD_MULTIPLIER


def get_refinement_regression_min_delta() -> int:
    """Get minimum blocking-issue increase required for regression escalation.

    Resolution order:
    1. OBRA_REFINEMENT_REGRESSION_MIN_DELTA environment variable
    2. refinement.regression_min_delta from config file
    3. Default: 3
    """
    env_key = "OBRA_REFINEMENT_REGRESSION_MIN_DELTA"
    env_val = os.environ.get(env_key)
    if env_val is not None:
        try:
            value = int(env_val)
            if value >= 1:
                return value
            logger.warning("%s must be >= 1 (got %s)", env_key, env_val)
        except (TypeError, ValueError):
            logger.warning("%s must be an integer (got %s)", env_key, env_val)

    config, _, _ = _core.load_layered_config()
    refinement_config = config.get("refinement", {})
    if isinstance(refinement_config, dict):
        min_delta = refinement_config.get("regression_min_delta")
        if min_delta is not None:
            try:
                value = int(min_delta)
                if value >= 1:
                    return value
                logger.warning(
                    "refinement.regression_min_delta must be >= 1 (got %s)",
                    min_delta,
                )
            except (TypeError, ValueError):
                logger.warning(
                    "refinement.regression_min_delta must be an integer (got %s)",
                    min_delta,
                )

    return _defaults.DEFAULT_REFINEMENT_REGRESSION_MIN_DELTA


def get_derivation_step_tier(step: int) -> str:
    """Get the orchestrator tier for a derivation step.

    Args:
        step: Step number (1, 2, or 3)

    Returns:
        Tier name: 'fast', 'medium', or 'high'

    Raises:
        ValueError: If step is not 1, 2, or 3
    """
    if step not in (1, 2, 3):
        raise ValueError(f"Invalid derivation step: {step}. Must be 1, 2, or 3.")

    step_key = f"step{step}_tier"
    env_var = f"OBRA_DERIVATION_STEP{step}_TIER"
    default_tiers = {1: "high", 2: "high", 3: "fast"}

    env_val = os.environ.get(env_var)
    if env_val:
        tier = env_val.lower()
        if tier in ("fast", "medium", "high"):
            return tier
        logger.warning(
            "%s must be fast, medium, or high (got %s)",
            env_var,
            env_val,
        )

    config, _, _ = _core.load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        steps_config = derivation_config.get("steps", {})
        if isinstance(steps_config, dict):
            config_tier = steps_config.get(step_key)
            if config_tier and isinstance(config_tier, str):
                config_tier = config_tier.lower()
                if config_tier in ("fast", "medium", "high"):
                    return config_tier
                logger.warning(
                    "derivation.steps.%s must be fast, medium, or high (got %s)",
                    step_key,
                    config_tier,
                )

    return default_tiers[step]


def get_derivation_step1_tier() -> str:
    """Get orchestrator tier for Step 1 (epic derivation).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    return get_derivation_step_tier(1)


def get_derivation_step2_tier() -> str:
    """Get orchestrator tier for Step 2 (story/task expansion).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'high')
    """
    return get_derivation_step_tier(2)


def get_derivation_step3_tier() -> str:
    """Get orchestrator tier for Step 3 (JSON serialization).

    Returns:
        Tier name: 'fast', 'medium', or 'high' (default: 'fast')
    """
    return get_derivation_step_tier(3)


def get_derivation_exploration_lookback_minutes() -> int:
    """Get exploration lookback window in minutes.

    Deprecated alias for ``orchestration.exploration.skip.recent_exploration_hours``.

    Returns:
        Minutes to look back for recent exploration artifacts (default: 180)
    """
    global _DERIVATION_LOOKBACK_DEPRECATION_LOGGED
    config, _, _ = _core.load_layered_config()

    try:
        hours = int(config["orchestration"]["exploration"]["skip"]["recent_exploration_hours"])
        if not _DERIVATION_LOOKBACK_DEPRECATION_LOGGED:
            logger.warning(
                "get_derivation_exploration_lookback_minutes() is deprecated; "
                "use orchestration.exploration.skip.recent_exploration_hours."
            )
            _DERIVATION_LOOKBACK_DEPRECATION_LOGGED = True
        return hours * 60
    except (KeyError, TypeError, ValueError):
        pass

    try:
        return int(config["derivation"]["exploration_lookback_minutes"])
    except (KeyError, TypeError, ValueError):
        return _defaults.DEFAULT_DERIVATION_EXPLORATION_LOOKBACK_MINUTES


def get_derivation_auto_decompose_config() -> dict:
    """Get derivation auto-decompose configuration.

    Returns:
        Dict with failure_threshold, max_depth keys
    """
    config, _, _ = _core.load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        auto_decompose_config = derivation_config.get("auto_decompose", {})
        if isinstance(auto_decompose_config, dict):
            return {
                "failure_threshold": get_decomposition_failure_threshold(),
                "max_depth": auto_decompose_config.get(
                    "max_depth", _defaults.DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG["max_depth"]
                ),
            }
    result = _defaults.DEFAULT_DERIVATION_AUTO_DECOMPOSE_CONFIG.copy()
    result["failure_threshold"] = get_decomposition_failure_threshold()
    return result


def get_derivation_budget_config() -> dict:
    """Get derivation budget configuration.

    Returns:
        Dict with decompose_threshold, warning_threshold, min_subtask_ratio keys
    """
    config, _, _ = _core.load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        budget_config = derivation_config.get("budget", {})
        if isinstance(budget_config, dict):
            return {
                "decompose_threshold": budget_config.get(
                    "decompose_threshold",
                    _defaults.DEFAULT_DERIVATION_BUDGET_CONFIG["decompose_threshold"],
                ),
                "warning_threshold": budget_config.get(
                    "warning_threshold",
                    _defaults.DEFAULT_DERIVATION_BUDGET_CONFIG["warning_threshold"],
                ),
                "min_subtask_ratio": budget_config.get(
                    "min_subtask_ratio",
                    _defaults.DEFAULT_DERIVATION_BUDGET_CONFIG["min_subtask_ratio"],
                ),
            }
    return _defaults.DEFAULT_DERIVATION_BUDGET_CONFIG.copy()


def get_derivation_task_config() -> dict:
    """Get derivation task budget configuration.

    Returns:
        Dict with token_budget, cost_budget_usd keys
    """
    config, _, _ = _core.load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        task_config = derivation_config.get("task", {})
        if isinstance(task_config, dict):
            return {
                "token_budget": task_config.get(
                    "token_budget", _defaults.DEFAULT_DERIVATION_TASK_CONFIG["token_budget"]
                ),
                "cost_budget_usd": task_config.get(
                    "cost_budget_usd", _defaults.DEFAULT_DERIVATION_TASK_CONFIG["cost_budget_usd"]
                ),
            }
    return _defaults.DEFAULT_DERIVATION_TASK_CONFIG.copy()
