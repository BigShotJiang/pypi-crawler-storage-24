"""Review, convergence, and quality getter owners."""

from __future__ import annotations

import os
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults
from .._defaults import (
    DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
    DEFAULT_REVIEW_FAIL_ADJUSTMENT,
    DEFAULT_REVIEW_FLAG_PENALTY_CAP,
    DEFAULT_REVIEW_PASS_ADJUSTMENT,
    DEFAULT_REVIEW_PASS_RATING_THRESHOLD,
    DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
)

__all__ = [
    "get_convergence_fresh_fix_enabled",
    "get_convergence_identity_overlap_threshold",
    "get_convergence_max_template_failure_cycles",
    "get_convergence_stale_cycles_for_escalate",
    "get_convergence_stale_cycles_for_fresh_fix",
    "get_escalation_continue_iteration_reset",
    "get_generated_plan_quality_threshold",
    "get_quality_config",
    "get_quality_policy_mode",
    "get_quality_threshold",
    "get_review_blocking_low_priority_strict",
    "get_review_complexity_medium",
    "get_review_complexity_simple",
    "get_review_feedback_config",
    "get_review_flag_weights",
    "get_review_loop_exit_policy_enabled",
    "get_review_loop_exit_policy_max_non_critical_review_cycles",
    "get_review_loop_exit_policy_require_no_new_critical",
    "get_review_loop_exit_policy_require_required_checks_pass",
    "get_review_loop_exit_policy_require_threshold_met",
    "get_review_rating_adjustments",
    "get_review_stabilization_cycle_threshold",
    "get_revision_plan_shrinkage_block_threshold",
    "get_revision_plan_shrinkage_warning_threshold",
]


def get_quality_threshold() -> float:
    """Get standard quality threshold for user-provided plans.

    Resolution order:
    1. OBRA_QUALITY_THRESHOLD environment variable
    2. quality.threshold from config file
    3. DEFAULT_QUALITY_THRESHOLD constant (0.6)

    Returns:
        Quality threshold as float (0.0 to 1.0)
    """
    env_threshold = os.environ.get("OBRA_QUALITY_THRESHOLD")
    if env_threshold:
        try:
            threshold = float(env_threshold)
            if 0.0 <= threshold <= 1.0:
                return threshold
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    quality_config = config.get("quality", {})
    if isinstance(quality_config, dict):
        config_threshold: Any = quality_config.get("threshold")
        if config_threshold is not None:
            try:
                threshold_val = float(config_threshold)
                if 0.0 <= threshold_val <= 1.0:
                    return threshold_val
            except (TypeError, ValueError):
                pass

    return _defaults.DEFAULT_QUALITY_THRESHOLD


def get_generated_plan_quality_threshold() -> float:
    """Get relaxed quality threshold for Obra-generated plans.

    Resolution order:
    1. OBRA_GENERATED_PLAN_QUALITY_THRESHOLD environment variable
    2. quality.generated_plan_threshold from config file
    3. DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD constant (0.4)

    Returns:
        Quality threshold as float (0.0 to 1.0)
    """
    env_threshold = os.environ.get("OBRA_GENERATED_PLAN_QUALITY_THRESHOLD")
    if env_threshold:
        try:
            threshold = float(env_threshold)
            if 0.0 <= threshold <= 1.0:
                return threshold
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    quality_config = config.get("quality", {})
    if isinstance(quality_config, dict):
        config_threshold: Any = quality_config.get("generated_plan_threshold")
        if config_threshold is not None:
            try:
                threshold_val = float(config_threshold)
                if 0.0 <= threshold_val <= 1.0:
                    return threshold_val
            except (TypeError, ValueError):
                pass

    return _defaults.DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD


def get_quality_policy_mode() -> str:
    """Get quality policy mode override.

    Resolution order:
    1. OBRA_QUALITY_POLICY_MODE environment variable
    2. orchestration.quality.policy_mode from config file
    3. DEFAULT_QUALITY_POLICY_MODE constant ("auto")

    Returns:
        Quality policy mode string: "auto", "fast", "medium", or "high"

    Raises:
        ConfigurationError: If the value is not in the allowed set
    """
    env_val = os.environ.get("OBRA_QUALITY_POLICY_MODE")
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized not in _defaults.VALID_QUALITY_POLICY_MODES:
            raise ConfigurationError(
                f"Invalid OBRA_QUALITY_POLICY_MODE='{env_val}'. "
                f"Allowed values: {sorted(_defaults.VALID_QUALITY_POLICY_MODES)}"
            )
        return normalized

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        quality_config = orch_config.get("quality", {})
        if isinstance(quality_config, dict):
            mode = quality_config.get("policy_mode")
            if mode is not None:
                mode_str = str(mode).strip().lower()
                if mode_str not in _defaults.VALID_QUALITY_POLICY_MODES:
                    raise ConfigurationError(
                        f"Invalid orchestration.quality.policy_mode='{mode}'. "
                        f"Allowed values: {sorted(_defaults.VALID_QUALITY_POLICY_MODES)}"
                    )
                return mode_str

    return _defaults.DEFAULT_QUALITY_POLICY_MODE


def get_convergence_fresh_fix_enabled() -> bool:
    """Get review convergence fresh-fix toggle.

    Resolution order:
    1. OBRA_CONVERGENCE_FRESH_FIX_ENABLED
    2. review.convergence.fresh_fix_enabled
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_FRESH_FIX_ENABLED"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        msg = f"Invalid boolean value '{env_val}' for {env_name}"
        raise ConfigurationError(msg)

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT
    try:
        raw_value = config["review"]["convergence"]["fresh_fix_enabled"]
    except (KeyError, TypeError) as exc:
        msg = (
            "Convergence setting missing at "
            "review.convergence.fresh_fix_enabled"
        )
        raise ConfigurationError(msg) from exc
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = (
        "Convergence setting review.convergence.fresh_fix_enabled "
        f"is invalid: {raw_value!r}"
    )
    raise ConfigurationError(msg)


def get_convergence_stale_cycles_for_fresh_fix() -> int:
    """Get stale cycle threshold before triggering fresh-fix.

    Resolution order:
    1. OBRA_CONVERGENCE_STALE_CYCLES_FOR_FRESH_FIX
    2. review.convergence.stale_cycles_for_fresh_fix
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_STALE_CYCLES_FOR_FRESH_FIX"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED
    try:
        value = int(config["review"]["convergence"]["stale_cycles_for_fresh_fix"])
    except (KeyError, TypeError, ValueError) as exc:
        msg = (
            "Convergence setting missing/invalid at "
            "review.convergence.stale_cycles_for_fresh_fix"
        )
        raise ConfigurationError(msg) from exc
    if value <= 0:
        msg = (
            "Convergence setting review.convergence.stale_cycles_for_fresh_fix "
            f"must be > 0 (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_convergence_stale_cycles_for_escalate() -> int:
    """Get stale cycle threshold before convergence escalation.

    Resolution order:
    1. OBRA_CONVERGENCE_STALE_CYCLES_FOR_ESCALATE
    2. review.convergence.stale_cycles_for_escalate
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_STALE_CYCLES_FOR_ESCALATE"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    try:
        value = int(config["review"]["convergence"]["stale_cycles_for_escalate"])
    except (KeyError, TypeError, ValueError) as exc:
        msg = (
            "Convergence setting missing/invalid at "
            "review.convergence.stale_cycles_for_escalate"
        )
        raise ConfigurationError(msg) from exc
    if value <= 0:
        msg = (
            "Convergence setting review.convergence.stale_cycles_for_escalate "
            f"must be > 0 (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_convergence_identity_overlap_threshold() -> float:
    """Get identity-overlap threshold for convergence divergence gating.

    Resolution order:
    1. OBRA_CONVERGENCE_IDENTITY_OVERLAP_THRESHOLD
    2. review.convergence.identity_overlap_threshold
    3. Fail fast if missing/invalid
    """
    env_name = "OBRA_CONVERGENCE_IDENTITY_OVERLAP_THRESHOLD"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0.0 or value > 1.0:
            msg = f"{env_name} must be in [0.0, 1.0] (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_CONVERGENCE_IDENTITY_OVERLAP_THRESHOLD
    try:
        value = float(config["review"]["convergence"]["identity_overlap_threshold"])
    except (KeyError, TypeError, ValueError) as exc:
        msg = (
            "Convergence setting missing/invalid at "
            "review.convergence.identity_overlap_threshold"
        )
        raise ConfigurationError(msg) from exc
    if value < 0.0 or value > 1.0:
        msg = (
            "Convergence setting review.convergence.identity_overlap_threshold "
            f"must be in [0.0, 1.0] (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_convergence_max_template_failure_cycles() -> int:
    """Get max consecutive template-failure cycles before counting toward stale_cycles.

    Resolution order:
    1. OBRA_CONVERGENCE_MAX_TEMPLATE_FAILURE_CYCLES
    2. review.convergence.max_template_failure_cycles
    3. Default: 3
    """
    env_name = "OBRA_CONVERGENCE_MAX_TEMPLATE_FAILURE_CYCLES"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return 3
    try:
        value = int(config["review"]["convergence"]["max_template_failure_cycles"])
    except (KeyError, TypeError, ValueError):
        return 3
    if value <= 0:
        return 3
    return value


def get_escalation_continue_iteration_reset() -> int:
    """Get iteration value to reset to when user selects 'continue fixing' after escalation.

    Resolution order:
    1. OBRA_ESCALATION_CONTINUE_ITERATION_RESET
    2. refinement.escalation_continue_iteration_reset
    3. Default: 0
    """
    env_name = "OBRA_ESCALATION_CONTINUE_ITERATION_RESET"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0:
            msg = f"{env_name} must be >= 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return 0
    try:
        value = int(config["refinement"]["escalation_continue_iteration_reset"])
    except (KeyError, TypeError, ValueError):
        return 0
    if value < 0:
        return 0
    return value


def get_review_blocking_low_priority_strict() -> bool:
    """Get strict low-priority blocking policy toggle for review scorecards."""
    env_name = "OBRA_REVIEW_LOW_PRIORITY_STRICT"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        msg = f"Invalid boolean value '{env_val}' for {env_name}"
        raise ConfigurationError(msg)

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    review_config = config.get("review", {})
    if not isinstance(review_config, dict):
        return _defaults.DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT
    blocking_policy = review_config.get("blocking_policy", {})
    if not isinstance(blocking_policy, dict):
        return _defaults.DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT
    raw_value = blocking_policy.get(
        "low_priority_strict",
        _defaults.DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.blocking_policy.low_priority_strict value"
    raise ConfigurationError(msg)


def get_review_stabilization_cycle_threshold() -> int:
    """Get the fix-cycle threshold for P2/P3 deferral during stabilization.

    After this many review->fix cycles, P2/P3 issues are deferred from FIX
    payload so the loop focuses on P0/P1 convergence.

    Config path: review.stabilization.cycle_threshold
    Env override: OBRA_REVIEW_STABILIZATION_CYCLE_THRESHOLD
    Default: 1 (defer P2/P3 after the first fix cycle)
    """
    env_name = "OBRA_REVIEW_STABILIZATION_CYCLE_THRESHOLD"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            parsed = int(env_val.strip())
            if parsed < 0:
                msg = f"Negative value '{env_val}' for {env_name}"
                raise ConfigurationError(msg)
            return parsed
        except ValueError as err:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from err

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_STABILIZATION_CYCLE_THRESHOLD
    review_config = config.get("review", {})
    if not isinstance(review_config, dict):
        return _defaults.DEFAULT_REVIEW_STABILIZATION_CYCLE_THRESHOLD
    stabilization = review_config.get("stabilization", {})
    if not isinstance(stabilization, dict):
        return _defaults.DEFAULT_REVIEW_STABILIZATION_CYCLE_THRESHOLD
    raw_value = stabilization.get(
        "cycle_threshold",
        _defaults.DEFAULT_REVIEW_STABILIZATION_CYCLE_THRESHOLD,
    )
    if isinstance(raw_value, int):
        return max(0, raw_value)
    if isinstance(raw_value, float):
        return max(0, int(raw_value))
    if isinstance(raw_value, str):
        try:
            return max(0, int(raw_value.strip()))
        except ValueError:
            pass
    msg = "Invalid review.stabilization.cycle_threshold value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_enabled() -> bool:
    """Get review.loop_exit_policy.enabled."""
    env_name = "OBRA_REVIEW_LOOP_EXIT_POLICY_ENABLED"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        normalized = env_val.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        msg = f"Invalid boolean value '{env_val}' for {env_name}"
        raise ConfigurationError(msg)

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED
    raw_value = policy_cfg.get(
        "enabled",
        _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.enabled value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_max_non_critical_review_cycles() -> int:
    """Get review.loop_exit_policy.max_non_critical_review_cycles."""
    env_name = "OBRA_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value <= 0:
            msg = f"{env_name} must be > 0 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES
    raw_value = policy_cfg.get(
        "max_non_critical_review_cycles",
        _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES,
    )
    try:
        value = int(raw_value)
    except (TypeError, ValueError):
        msg = "Invalid review.loop_exit_policy.max_non_critical_review_cycles value"
        raise ConfigurationError(msg) from None
    if value <= 0:
        msg = "review.loop_exit_policy.max_non_critical_review_cycles must be > 0"
        raise ConfigurationError(msg)
    return value


def get_review_loop_exit_policy_require_threshold_met() -> bool:
    """Get review.loop_exit_policy.require_threshold_met."""
    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET
    raw_value = policy_cfg.get(
        "require_threshold_met",
        _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.require_threshold_met value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_require_required_checks_pass() -> bool:
    """Get review.loop_exit_policy.require_required_checks_pass."""
    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS
    raw_value = policy_cfg.get(
        "require_required_checks_pass",
        _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.require_required_checks_pass value"
    raise ConfigurationError(msg)


def get_review_loop_exit_policy_require_no_new_critical() -> bool:
    """Get review.loop_exit_policy.require_no_new_critical."""
    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL
    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL
    policy_cfg = review_cfg.get("loop_exit_policy", {})
    if not isinstance(policy_cfg, dict):
        return _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL
    raw_value = policy_cfg.get(
        "require_no_new_critical",
        _defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL,
    )
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    if isinstance(raw_value, (int, float)):
        return bool(raw_value)
    msg = "Invalid review.loop_exit_policy.require_no_new_critical value"
    raise ConfigurationError(msg)


def get_revision_plan_shrinkage_warning_threshold() -> float:
    """Get review.revision_integrity.plan_shrinkage_warning_threshold."""
    env_name = "OBRA_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0 or value > 1:
            msg = f"{env_name} must be between 0 and 1 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD

    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD
    integrity_cfg = review_cfg.get("revision_integrity", {})
    if not isinstance(integrity_cfg, dict):
        return _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD

    raw_value = integrity_cfg.get(
        "plan_shrinkage_warning_threshold",
        _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD,
    )
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        msg = "Invalid review.revision_integrity.plan_shrinkage_warning_threshold value"
        raise ConfigurationError(msg) from None

    if value < 0 or value > 1:
        msg = (
            "review.revision_integrity.plan_shrinkage_warning_threshold "
            f"must be between 0 and 1 (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_revision_plan_shrinkage_block_threshold() -> float:
    """Get review.revision_integrity.plan_shrinkage_block_threshold."""
    env_name = "OBRA_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD"
    env_val = os.environ.get(env_name)
    if env_val is not None:
        try:
            value = float(env_val)
        except ValueError:
            msg = f"Invalid float value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None
        if value < 0 or value > 1:
            msg = f"{env_name} must be between 0 and 1 (got {value})"
            raise ConfigurationError(msg)
        return value

    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
    except Exception:
        return _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD

    review_cfg = config.get("review", {})
    if not isinstance(review_cfg, dict):
        return _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD
    integrity_cfg = review_cfg.get("revision_integrity", {})
    if not isinstance(integrity_cfg, dict):
        return _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD

    raw_value = integrity_cfg.get(
        "plan_shrinkage_block_threshold",
        _defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD,
    )
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        msg = "Invalid review.revision_integrity.plan_shrinkage_block_threshold value"
        raise ConfigurationError(msg) from None

    warning_threshold = get_revision_plan_shrinkage_warning_threshold()
    if value < 0 or value > warning_threshold:
        msg = (
            "review.revision_integrity.plan_shrinkage_block_threshold "
            f"must be between 0 and warning threshold {warning_threshold} (got {value})"
        )
        raise ConfigurationError(msg)
    return value


def get_review_complexity_simple() -> dict:
    """Get simple review complexity thresholds.

    Returns:
        Dict with max_words, max_files, max_lines keys
    """
    config, _, _ = _core.load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        complexity_config = review_config.get("complexity", {})
        if isinstance(complexity_config, dict):
            simple_config = complexity_config.get("simple", {})
            if isinstance(simple_config, dict):
                return {
                    "max_words": simple_config.get(
                        "max_words", _defaults.DEFAULT_REVIEW_COMPLEXITY_SIMPLE["max_words"]
                    ),
                    "max_files": simple_config.get(
                        "max_files", _defaults.DEFAULT_REVIEW_COMPLEXITY_SIMPLE["max_files"]
                    ),
                    "max_lines": simple_config.get(
                        "max_lines", _defaults.DEFAULT_REVIEW_COMPLEXITY_SIMPLE["max_lines"]
                    ),
                }
    return _defaults.DEFAULT_REVIEW_COMPLEXITY_SIMPLE.copy()


def get_review_complexity_medium() -> dict:
    """Get medium review complexity thresholds.

    Returns:
        Dict with max_files, max_lines keys
    """
    config, _, _ = _core.load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        complexity_config = review_config.get("complexity", {})
        if isinstance(complexity_config, dict):
            medium_config = complexity_config.get("medium", {})
            if isinstance(medium_config, dict):
                return {
                    "max_files": medium_config.get(
                        "max_files", _defaults.DEFAULT_REVIEW_COMPLEXITY_MEDIUM["max_files"]
                    ),
                    "max_lines": medium_config.get(
                        "max_lines", _defaults.DEFAULT_REVIEW_COMPLEXITY_MEDIUM["max_lines"]
                    ),
                }
    return _defaults.DEFAULT_REVIEW_COMPLEXITY_MEDIUM.copy()


def get_review_flag_weights() -> dict:
    """Get severity weights for review flags.

    Returns:
        Dict with flag names mapped to severity weights (0.0-1.0).
    """
    config, _, _ = _core.load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        feedback_config = review_config.get("feedback", {})
        if isinstance(feedback_config, dict):
            flag_weights = feedback_config.get("flag_weights", {})
            if isinstance(flag_weights, dict):
                return {
                    "incorrect": flag_weights.get(
                        "incorrect", _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS["incorrect"]
                    ),
                    "off_topic": flag_weights.get(
                        "off_topic", _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS["off_topic"]
                    ),
                    "incomplete": flag_weights.get(
                        "incomplete", _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS["incomplete"]
                    ),
                    "unclear": flag_weights.get(
                        "unclear", _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS["unclear"]
                    ),
                    "quality_issue": flag_weights.get(
                        "quality_issue", _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS["quality_issue"]
                    ),
                }
    return _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS.copy()


def get_review_rating_adjustments() -> dict:
    """Get quality score adjustments based on numeric rating (1-5).

    Returns:
        Dict mapping rating (1-5) to quality score adjustment.
    """
    config, _, _ = _core.load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        feedback_config = review_config.get("feedback", {})
        if isinstance(feedback_config, dict):
            rating_adjustments = feedback_config.get("rating_adjustments", {})
            if isinstance(rating_adjustments, dict):
                result = {}
                for rating in [1, 2, 3, 4, 5]:
                    value = rating_adjustments.get(rating)
                    if value is not None:
                        try:
                            result[rating] = float(value)
                        except (TypeError, ValueError):
                            result[rating] = _defaults.DEFAULT_REVIEW_RATING_ADJUSTMENTS[rating]
                    else:
                        result[rating] = _defaults.DEFAULT_REVIEW_RATING_ADJUSTMENTS[rating]
                return result
    return _defaults.DEFAULT_REVIEW_RATING_ADJUSTMENTS.copy()


def get_review_feedback_config() -> dict:
    """Get review feedback configuration (scalar values).

    Returns:
        Dict with scalar configuration values for review feedback scoring:
        - pass_adjustment, fail_adjustment, flag_penalty_cap,
          default_initial_quality_score, rederivation_threshold,
          pass_rating_threshold
    """
    # Map from config key to DEFAULT_REVIEW_* constant (name-imported per Rule C)
    _float_defaults = {
        "pass_adjustment": DEFAULT_REVIEW_PASS_ADJUSTMENT,
        "fail_adjustment": DEFAULT_REVIEW_FAIL_ADJUSTMENT,
        "flag_penalty_cap": DEFAULT_REVIEW_FLAG_PENALTY_CAP,
        "default_initial_quality_score": DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
        "rederivation_threshold": DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
    }

    config, _, _ = _core.load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        feedback_config = review_config.get("feedback", {})
        if isinstance(feedback_config, dict):
            result = {}
            for key, default_val in _float_defaults.items():
                value = feedback_config.get(key)
                if value is not None:
                    try:
                        result[key] = float(value)
                    except (TypeError, ValueError):
                        result[key] = default_val
                else:
                    result[key] = default_val

            value = feedback_config.get("pass_rating_threshold")
            if value is not None:
                try:
                    result["pass_rating_threshold"] = int(value)
                except (TypeError, ValueError):
                    result["pass_rating_threshold"] = DEFAULT_REVIEW_PASS_RATING_THRESHOLD
            else:
                result["pass_rating_threshold"] = DEFAULT_REVIEW_PASS_RATING_THRESHOLD

            return result

    return {
        "pass_adjustment": DEFAULT_REVIEW_PASS_ADJUSTMENT,
        "fail_adjustment": DEFAULT_REVIEW_FAIL_ADJUSTMENT,
        "flag_penalty_cap": DEFAULT_REVIEW_FLAG_PENALTY_CAP,
        "default_initial_quality_score": DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
        "rederivation_threshold": DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
        "pass_rating_threshold": DEFAULT_REVIEW_PASS_RATING_THRESHOLD,
    }


def get_quality_config(config: dict | None = None) -> dict[str, Any]:
    """Get quality assessment configuration.

    Args:
        config: Optional config dict. If None, loads from layered config

    Returns:
        Dict with quality configuration keys.
    """
    if config is None:
        config, _, _ = _core.load_layered_config()

    return config.get("quality", {})
