"""Runtime-operations getter owners."""

from __future__ import annotations

import logging
import os
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults

logger = logging.getLogger(__name__)

__all__ = [
    "get_derivation_serialize_worker_delay_s",
    "get_enrichment_review_max_concurrent",
    "get_governor_config",
    "get_hang_confidence",
    "get_hierarchy_limit",
    "get_hybrid_polling_config",
    "get_intent_alignment_max_concurrent",
    "get_interactive_guard_enabled",
    "get_interactive_guard_patterns",
    "get_interactive_guard_retry_max",
    "get_interactive_guard_rollback_codes",
    "get_interactive_guard_rollback_enabled",
    "get_limit",
    "get_parallel_worker_delay_s",
    "get_retry_config",
]


def _get_interactive_guard_config() -> dict[str, Any]:
    """Return orchestration.interactive_guard config section."""
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        guard_config = orch_config.get("interactive_guard", {})
        if isinstance(guard_config, dict):
            return guard_config
    return {}


def get_interactive_guard_enabled() -> bool:
    """Get interactive guard enabled flag."""
    guard_config = _get_interactive_guard_config()
    enabled = guard_config.get("enabled")
    if enabled is not None:
        return bool(enabled)
    return _defaults.DEFAULT_INTERACTIVE_GUARD_ENABLED


def get_interactive_guard_patterns() -> list[str]:
    """Get interactive guard regex patterns."""
    guard_config = _get_interactive_guard_config()
    patterns = guard_config.get("patterns")
    if isinstance(patterns, list) and patterns:
        return [str(pattern) for pattern in patterns]
    return _defaults.DEFAULT_INTERACTIVE_GUARD_PATTERNS.copy()


def get_interactive_guard_retry_max() -> int:
    """Get interactive guard retry max."""
    guard_config = _get_interactive_guard_config()
    retry_max = guard_config.get("retry_max")
    if retry_max is not None:
        return int(retry_max)
    return _defaults.DEFAULT_INTERACTIVE_GUARD_RETRY_MAX


def get_interactive_guard_rollback_enabled() -> bool:
    """Get interactive guard rollback enabled flag."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        enabled = rollback.get("enabled")
        if enabled is not None:
            return bool(enabled)
    return _defaults.DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED


def get_interactive_guard_rollback_codes() -> list[str]:
    """Get interactive guard rollback trigger codes."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        codes = rollback.get("trigger_codes")
        if isinstance(codes, list) and codes:
            return [str(code) for code in codes]
    return _defaults.DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES.copy()


def get_retry_config() -> Any:
    """Get retry configuration for LLM invocations.

    Loads settings from the orchestration.retry section in config.
    Returns a RetryConfig object from obra.llm.retry.

    Resolution order:
    1. orchestration.retry.* from config file
    2. DEFAULT_RETRY_* constants

    Returns:
        RetryConfig object with retry settings
    """
    from obra.llm.retry import RetryConfig

    config, _, _ = _core.load_layered_config()
    retry_section = config.get("retry", {})

    if not isinstance(retry_section, dict):
        return RetryConfig()

    max_attempts = retry_section.get("max_attempts", _defaults.DEFAULT_RETRY_MAX_ATTEMPTS)
    auth_max_attempts = retry_section.get(
        "auth_max_attempts", _defaults.DEFAULT_RETRY_AUTH_MAX_ATTEMPTS
    )
    rate_limit_max_attempts = retry_section.get(
        "rate_limit_max_attempts", _defaults.DEFAULT_RETRY_RATE_LIMIT_MAX_ATTEMPTS
    )
    base_delay = retry_section.get(
        "base_delay",
        retry_section.get("base_delay_s", _defaults.DEFAULT_RETRY_BASE_DELAY),
    )
    max_delay = retry_section.get(
        "max_delay",
        retry_section.get("max_delay_s", _defaults.DEFAULT_RETRY_MAX_DELAY),
    )
    backoff_multiplier = retry_section.get(
        "backoff_multiplier", _defaults.DEFAULT_RETRY_BACKOFF_MULTIPLIER
    )
    jitter = retry_section.get("jitter", _defaults.DEFAULT_RETRY_JITTER)
    configured_patterns = retry_section.get("retryable_errors")
    if isinstance(configured_patterns, list):
        normalized_configured = [
            str(pattern).strip()
            for pattern in configured_patterns
            if str(pattern).strip()
        ]
        retryable_patterns = list(
            dict.fromkeys([*normalized_configured, *_defaults.DEFAULT_RETRY_PATTERNS])
        )
    else:
        retryable_patterns = list(_defaults.DEFAULT_RETRY_PATTERNS)

    env_rl = os.environ.get("OBRA_RETRY_RATE_LIMIT_MAX_ATTEMPTS")
    if env_rl:
        rate_limit_max_attempts = env_rl

    return RetryConfig(
        max_attempts=int(max_attempts),
        auth_max_attempts=int(auth_max_attempts),
        rate_limit_max_attempts=int(rate_limit_max_attempts),
        base_delay=float(base_delay),
        max_delay=float(max_delay),
        backoff_multiplier=float(backoff_multiplier),
        jitter=float(jitter),
        retryable_patterns=list(retryable_patterns),
    )


def get_parallel_worker_delay_s(provider: str | None = None) -> float:
    """Get inter-worker delay for parallel LLM dispatchers.

    Resolution order:
    1. OBRA_PARALLEL_WORKER_DELAY_S_<PROVIDER> environment variable (if provider given)
    2. OBRA_PARALLEL_WORKER_DELAY_S environment variable
    3. orchestration.parallel.provider_overrides.<provider> (if provider given)
    4. orchestration.parallel.worker_delay_s from config file
    5. Default: 1.0
    """
    provider_lower = provider.lower() if provider else None

    if provider_lower:
        env_key = f"OBRA_PARALLEL_WORKER_DELAY_S_{provider_lower.upper()}"
        env_val = os.environ.get(env_key)
        if env_val:
            try:
                value = float(env_val)
                if value >= 0:
                    return value
                logger.warning("%s must be >= 0 (got %s)", env_key, env_val)
            except (TypeError, ValueError):
                logger.warning("%s must be a number (got %s)", env_key, env_val)

    env_val = os.environ.get("OBRA_PARALLEL_WORKER_DELAY_S")
    if env_val:
        try:
            value = float(env_val)
            if value >= 0:
                return value
            logger.warning(
                "OBRA_PARALLEL_WORKER_DELAY_S must be >= 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_PARALLEL_WORKER_DELAY_S must be a number (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        parallel_config = orch_config.get("parallel", {})
        if isinstance(parallel_config, dict):
            if provider_lower:
                overrides = parallel_config.get("provider_overrides", {})
                if isinstance(overrides, dict):
                    provider_delay = overrides.get(provider_lower)
                    if provider_delay is not None:
                        try:
                            value = float(provider_delay)
                            if value >= 0:
                                return value
                            logger.warning(
                                "orchestration.parallel.provider_overrides.%s "
                                "must be >= 0 (got %s)",
                                provider_lower,
                                provider_delay,
                            )
                        except (TypeError, ValueError):
                            logger.warning(
                                "orchestration.parallel.provider_overrides.%s "
                                "must be a number (got %s)",
                                provider_lower,
                                provider_delay,
                            )

            delay = parallel_config.get("worker_delay_s")
            if delay is not None:
                try:
                    value = float(delay)
                    if value >= 0:
                        return value
                    logger.warning(
                        "orchestration.parallel.worker_delay_s must be >= 0 (got %s)",
                        delay,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "orchestration.parallel.worker_delay_s must be a number (got %s)",
                        delay,
                    )

    return 1.0


def get_derivation_serialize_worker_delay_s(provider: str | None = None) -> float:
    """Get inter-worker delay for derivation serialization.

    Delegates to get_parallel_worker_delay_s() — kept for backward
    compatibility with existing config overrides.
    """
    return get_parallel_worker_delay_s(provider=provider)


def get_governor_config():  # -> GovernorConfig (imported lazily to avoid circular deps)
    """Get the LLM concurrency governor configuration.

    Resolution order:
    1. OBRA_GOVERNOR_ENABLED, OBRA_GOVERNOR_MAX_CONCURRENT, OBRA_GOVERNOR_COOLDOWN_S
       env vars for global settings
    2. orchestration.governor.* from config file
    3. Backward compat: when orchestration.governor absent, construct from
       orchestration.parallel.worker_delay_s / provider_overrides
    4. Hardcoded defaults from GovernorConfig()

    Per-provider env overrides use OBRA_GOVERNOR_COOLDOWN_S_<PROVIDER> (uppercase).

    Returns:
        GovernorConfig populated from the resolution order above.
    """
    from obra.llm.governor import (  # local import avoids circular dependency
        GovernorConfig,
        GovernorTelemetryConfig,
        ProviderGovernorConfig,
    )

    defaults = GovernorConfig()

    # ---- Global env var overrides ----
    enabled = defaults.enabled
    env_enabled = os.environ.get("OBRA_GOVERNOR_ENABLED")
    if env_enabled is not None:
        enabled = env_enabled.lower() not in ("0", "false", "no")

    max_concurrent = defaults.max_concurrent_calls
    env_max = os.environ.get("OBRA_GOVERNOR_MAX_CONCURRENT")
    if env_max is not None:
        try:
            value = int(env_max)
            if value > 0:
                max_concurrent = value
            else:
                logger.warning(
                    "OBRA_GOVERNOR_MAX_CONCURRENT must be > 0 (got %s)", env_max
                )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_GOVERNOR_MAX_CONCURRENT must be an integer (got %s)", env_max
            )

    cooldown_s = defaults.cooldown_s
    env_cooldown = os.environ.get("OBRA_GOVERNOR_COOLDOWN_S")
    if env_cooldown is not None:
        try:
            value = float(env_cooldown)
            if value >= 0:
                cooldown_s = value
            else:
                logger.warning(
                    "OBRA_GOVERNOR_COOLDOWN_S must be >= 0 (got %s)", env_cooldown
                )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_GOVERNOR_COOLDOWN_S must be a number (got %s)", env_cooldown
            )

    acquire_timeout_s = defaults.acquire_timeout_s
    env_timeout = os.environ.get("OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S")
    if env_timeout is not None:
        try:
            value = float(env_timeout)
            if value > 0:
                acquire_timeout_s = value
            else:
                logger.warning(
                    "OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S must be > 0 (got %s)", env_timeout
                )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S must be a number (got %s)", env_timeout
            )

    # ---- Load config file ----
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {}) if isinstance(config, dict) else {}
    governor_section = (
        orch_config.get("governor", {}) if isinstance(orch_config, dict) else {}
    )

    if isinstance(governor_section, dict) and governor_section:
        # governor section present — read from it
        if env_enabled is None:
            raw = governor_section.get("enabled")
            if raw is not None:
                enabled = bool(raw)
        if env_max is None:
            raw = governor_section.get("max_concurrent_calls")
            if raw is not None:
                try:
                    v = int(raw)
                    if v > 0:
                        max_concurrent = v
                except (TypeError, ValueError):
                    pass
        if env_cooldown is None:
            raw = governor_section.get("cooldown_s")
            if raw is not None:
                try:
                    v = float(raw)
                    if v >= 0:
                        cooldown_s = v
                except (TypeError, ValueError):
                    pass
        if env_timeout is None:
            raw = governor_section.get("acquire_timeout_s")
            if raw is not None:
                try:
                    v = float(raw)
                    if v > 0:
                        acquire_timeout_s = v
                except (TypeError, ValueError):
                    pass

        # Provider overrides from governor section
        providers = dict(defaults.providers)
        raw_providers = governor_section.get("providers", {})
        if isinstance(raw_providers, dict):
            for pname, pdata in raw_providers.items():
                if not isinstance(pdata, dict):
                    continue
                pmax = None
                pcooldown = None
                raw_pmax = pdata.get("max_concurrent_calls")
                if raw_pmax is not None:
                    try:
                        v = int(raw_pmax)
                        if v > 0:
                            pmax = v
                    except (TypeError, ValueError):
                        pass
                raw_pcooldown = pdata.get("cooldown_s")
                if raw_pcooldown is not None:
                    try:
                        v = float(raw_pcooldown)
                        if v >= 0:
                            pcooldown = v
                    except (TypeError, ValueError):
                        pass
                providers[pname] = ProviderGovernorConfig(
                    max_concurrent_calls=pmax,
                    cooldown_s=pcooldown,
                )

        # Telemetry
        log_wait_times = defaults.telemetry.log_wait_times
        warn_threshold_s = defaults.telemetry.warn_threshold_s
        raw_tel = governor_section.get("telemetry", {})
        if isinstance(raw_tel, dict):
            raw_lwt = raw_tel.get("log_wait_times")
            if raw_lwt is not None:
                log_wait_times = bool(raw_lwt)
            raw_wt = raw_tel.get("warn_threshold_s")
            if raw_wt is not None:
                try:
                    v = float(raw_wt)
                    if v > 0:
                        warn_threshold_s = v
                except (TypeError, ValueError):
                    pass

    else:
        # Backward compat: no governor section — fall back to parallel config
        providers = dict(defaults.providers)
        parallel_config = (
            orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
        )
        if isinstance(parallel_config, dict) and parallel_config:
            # Use worker_delay_s as the global cooldown
            raw_delay = parallel_config.get("worker_delay_s")
            if raw_delay is not None and env_cooldown is None:
                try:
                    v = float(raw_delay)
                    if v >= 0:
                        cooldown_s = v
                except (TypeError, ValueError):
                    pass
            # Per-provider overrides become per-provider cooldown
            raw_overrides = parallel_config.get("provider_overrides", {})
            if isinstance(raw_overrides, dict):
                for pname, pdelay in raw_overrides.items():
                    try:
                        v = float(pdelay)
                        if v >= 0:
                            existing = providers.get(pname, ProviderGovernorConfig())
                            providers[pname] = ProviderGovernorConfig(
                                max_concurrent_calls=existing.max_concurrent_calls,
                                cooldown_s=v,
                            )
                    except (TypeError, ValueError):
                        pass
        log_wait_times = defaults.telemetry.log_wait_times
        warn_threshold_s = defaults.telemetry.warn_threshold_s

    # Per-provider env var overrides: OBRA_GOVERNOR_COOLDOWN_S_<PROVIDER>
    for pname in list(providers.keys()):
        env_key = f"OBRA_GOVERNOR_COOLDOWN_S_{pname.upper()}"
        env_val = os.environ.get(env_key)
        if env_val is not None:
            try:
                v = float(env_val)
                if v >= 0:
                    existing = providers[pname]
                    providers[pname] = ProviderGovernorConfig(
                        max_concurrent_calls=existing.max_concurrent_calls,
                        cooldown_s=v,
                    )
                else:
                    logger.warning("%s must be >= 0 (got %s)", env_key, env_val)
            except (TypeError, ValueError):
                logger.warning("%s must be a number (got %s)", env_key, env_val)

    return GovernorConfig(
        enabled=enabled,
        max_concurrent_calls=max_concurrent,
        cooldown_s=cooldown_s,
        acquire_timeout_s=acquire_timeout_s,
        providers=providers,
        telemetry=GovernorTelemetryConfig(
            log_wait_times=log_wait_times,
            warn_threshold_s=warn_threshold_s,
        ),
    )


def get_intent_alignment_max_concurrent() -> int:
    """Get max concurrent workers for intent story checks.

    Resolution order:
    1. OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT environment variable
    2. planning.intent_alignment.max_concurrent from config file
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    planning_config = config.get("planning", {})
    if isinstance(planning_config, dict):
        alignment_config = planning_config.get("intent_alignment", {})
        if isinstance(alignment_config, dict):
            max_concurrent = alignment_config.get("max_concurrent")
            if max_concurrent is not None:
                try:
                    value = int(max_concurrent)
                    if value > 0:
                        return value
                    logger.warning(
                        "planning.intent_alignment.max_concurrent must be > 0 (got %s)",
                        max_concurrent,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "planning.intent_alignment.max_concurrent must be an integer (got %s)",
                        max_concurrent,
                    )

    return 4


def get_enrichment_review_max_concurrent() -> int:
    """Get max concurrent workers for enrichment story review.

    Resolution order:
    1. OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT environment variable
    2. planning.enrichment.stages.review.max_concurrent from config file
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    planning_config = config.get("planning", {})
    if isinstance(planning_config, dict):
        enrichment_config = planning_config.get("enrichment", {})
        if isinstance(enrichment_config, dict):
            stages_config = enrichment_config.get("stages", {})
            if isinstance(stages_config, dict):
                review_config = stages_config.get("review")
                if not isinstance(review_config, dict):
                    review_config = stages_config.get("revise", {})
                if isinstance(review_config, dict):
                    max_concurrent = review_config.get("max_concurrent")
                    if max_concurrent is not None:
                        try:
                            value = int(max_concurrent)
                            if value > 0:
                                return value
                            logger.warning(
                                "planning.enrichment.stages.review.max_concurrent must be > 0 (got %s)",
                                max_concurrent,
                            )
                        except (TypeError, ValueError):
                            logger.warning(
                                "planning.enrichment.stages.review.max_concurrent must be an integer (got %s)",
                                max_concurrent,
                            )

    return 4


def get_hang_confidence(hang_type: str) -> float:
    """Get confidence score for hang type classification.

    Args:
        hang_type: Type of hang (real_hang, io_blocking_with_file,
                  io_blocking_without, slow_progress, external_blocking, unknown)

    Returns:
        Confidence score for hang type (0.0-1.0)
    """
    config, _, _ = _core.load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        hang_config = monitoring_config.get("hang_investigation", {})
        if isinstance(hang_config, dict):
            confidence_config = hang_config.get("confidence", {})
            if isinstance(confidence_config, dict):
                confidence = confidence_config.get(hang_type)
                if confidence is not None:
                    try:
                        return float(confidence)
                    except (TypeError, ValueError):
                        pass
    return _defaults.DEFAULT_HANG_CONFIDENCE.get(hang_type, 0.30)


def get_hybrid_polling_config() -> dict:
    """Get hybrid orchestration polling configuration.

    Returns:
        Dict with max_delay_s, backoff_multiplier, base_delay_s keys
    """
    config, _, _ = _core.load_layered_config()
    hybrid_config = config.get("hybrid", {})
    if isinstance(hybrid_config, dict):
        polling_config = hybrid_config.get("polling", {})
        if isinstance(polling_config, dict):
            return {
                "max_delay_s": polling_config.get(
                    "max_delay_s", _defaults.DEFAULT_HYBRID_POLLING_CONFIG["max_delay_s"]
                ),
                "backoff_multiplier": polling_config.get(
                    "backoff_multiplier",
                    _defaults.DEFAULT_HYBRID_POLLING_CONFIG["backoff_multiplier"],
                ),
                "base_delay_s": polling_config.get(
                    "base_delay_s", _defaults.DEFAULT_HYBRID_POLLING_CONFIG["base_delay_s"]
                ),
            }
    return _defaults.DEFAULT_HYBRID_POLLING_CONFIG.copy()


def get_limit(name: str) -> int:
    """Get operational limit by name.

    Resolution order (Rule 22):
    1. OBRA_LIMIT_{NAME} environment variable (uppercase)
    2. orchestration.limits.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of the valid limit names.

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid limit name
        ConfigurationError: If limit is not found in config
    """
    if name not in _defaults._LIMIT_NAMES:
        valid_names = ", ".join(sorted(_defaults._LIMIT_NAMES))
        msg = f"Invalid limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    env_name = f"OBRA_LIMIT_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        limits_config = config["orchestration"]["limits"]
        return int(limits_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Limit '{name}' not found in config at orchestration.limits.{name}"
        raise ConfigurationError(msg) from exc


def get_hierarchy_limit(name: str) -> int:
    """Get hierarchy constraint limit by name.

    Resolution order (Rule 22):
    1. OBRA_HIERARCHY_{NAME} environment variable (uppercase)
    2. orchestration.hierarchy.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of 'max_stories_per_epic', 'max_tasks_per_story', 'max_subtasks_per_task'

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid hierarchy limit name
        ConfigurationError: If limit is not found in config
    """
    if name not in _defaults._HIERARCHY_LIMIT_NAMES:
        valid_names = ", ".join(sorted(_defaults._HIERARCHY_LIMIT_NAMES))
        msg = f"Invalid hierarchy limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    env_name = f"OBRA_HIERARCHY_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        hierarchy_config = config["orchestration"]["hierarchy"]
        return int(hierarchy_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Hierarchy limit '{name}' not found in config at orchestration.hierarchy.{name}"
        raise ConfigurationError(msg) from exc
