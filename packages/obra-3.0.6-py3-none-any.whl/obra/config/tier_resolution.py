"""Tier-based LLM configuration resolution helpers."""

from __future__ import annotations

from typing import Any

from obra.config.llm_normalization import (
    DEFAULT_REASONING_LEVEL,
    DEFAULT_REASONING_SELECTION,
    _get_env_tier_override,
)
from obra.config.provider_inference import infer_provider_from_model, validate_model
from obra.config.providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)
from obra.config.reasoning_selection import _materialize_default_reasoning_level
from obra.model_registry import REASONING_LEVELS


def _llm_runtime() -> Any:
    import obra.config.llm as llm_module

    return llm_module


def _load_runtime_llm_config() -> dict[str, Any]:
    llm_runtime = _llm_runtime()
    config, _, _ = llm_runtime.load_layered_config()
    llm_section = llm_runtime.load_llm_section(config)
    if not llm_section:
        return llm_runtime._normalized_llm_config({})
    return llm_runtime._normalized_llm_config(llm_section)


def get_role_tier_default(provider: str, role: str, tier: str) -> str | None:
    """Get the role-aware tier default model for a provider/role/tier combination."""
    return _llm_runtime().ROLE_TIER_DEFAULTS.get(provider, {}).get(role, {}).get(tier)


def update_role_tiers_for_provider(
    role: str, new_provider: str, config: dict[str, Any]
) -> tuple[dict[str, Any], str]:
    """Update tier configuration for a role when provider changes."""
    llm_runtime = _llm_runtime()
    role_defaults = llm_runtime.ROLE_TIER_DEFAULTS.get(new_provider, {}).get(role, {})
    tier_defaults = (
        role_defaults
        if role_defaults
        else llm_runtime.PROVIDER_TIER_DEFAULTS.get(new_provider, {})
    )
    if not tier_defaults:
        return config, ""

    if "llm" not in config:
        config["llm"] = {}
    if role not in config["llm"] or not isinstance(config["llm"][role], dict):
        config["llm"][role] = {}

    config["llm"][role]["tiers"] = tier_defaults.copy()
    tier_list = ", ".join(f"{tier}={model}" for tier, model in tier_defaults.items())
    provider_display = new_provider.capitalize()
    notification = f"Updated {role} tiers to match {provider_display}: {tier_list}"
    return config, notification


# pylint: disable=too-many-arguments,too-many-positional-arguments,too-many-branches,too-many-locals
def resolve_tier_config(
    tier: str,
    role: str = "implementation",
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_reasoning_level: str | None = None,
) -> dict[str, Any]:
    """Resolve model config for a given tier with role-specific fallback chain."""
    llm_runtime = _llm_runtime()
    tier_fallbacks = llm_runtime.TIER_FALLBACKS.copy()
    provider_tier_defaults = llm_runtime.PROVIDER_TIER_DEFAULTS.copy()

    if tier not in tier_fallbacks:
        msg = f"Invalid tier: {tier}. Valid: {', '.join(llm_runtime.TIER_NAMES)}"
        raise ValueError(msg)
    if role not in ("orchestrator", "implementation"):
        msg = f"Invalid role: {role}"
        raise ValueError(msg)

    env_override_model = _get_env_tier_override(tier)
    override_model = override_model or env_override_model
    if override_model and not override_provider:
        inferred_provider = infer_provider_from_model(override_model)
        if inferred_provider:
            override_provider = inferred_provider

    llm_config = _load_runtime_llm_config()
    role_config = llm_config.get(role, {})
    top_level_provider = llm_config.get("provider", "per-role")
    top_level_model = llm_config.get("model", "per-tier")
    role_level_provider = role_config.get("provider", DEFAULT_PROVIDER)

    if top_level_provider not in ("per-role", "per-tier"):
        effective_provider = top_level_provider
        provider_is_per_tier = False
    elif role_level_provider not in ("per-role", "per-tier"):
        effective_provider = role_level_provider
        provider_is_per_tier = False
    else:
        effective_provider = DEFAULT_PROVIDER
        provider_is_per_tier = True

    model_passthrough = ("per-tier", "per-role", "default")
    role_level_model = role_config.get("model", "per-tier")

    if top_level_model not in model_passthrough:
        effective_model = top_level_model
        model_cascades_to_tiers = True
    elif role_level_model not in model_passthrough:
        effective_model = role_level_model
        model_cascades_to_tiers = True
    else:
        effective_model = llm_runtime.DEFAULT_MODEL
        model_cascades_to_tiers = False

    base_config = {
        "provider": effective_provider,
        "auth_method": role_config.get(
            "auth_method",
            llm_config.get("auth_method", DEFAULT_AUTH_METHOD),
        ),
        "model": effective_model,
        "reasoning_level": role_config.get(
            "reasoning_level",
            llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL),
        ),
        "parse_retry_enabled": role_config.get("parse_retry_enabled", True),
        "parse_retry_providers": role_config.get("parse_retry_providers"),
        "parse_retry_models": role_config.get("parse_retry_models"),
    }

    if model_cascades_to_tiers:
        chosen = {
            "provider": effective_provider,
            "auth_method": base_config["auth_method"],
            "model": effective_model,
            "reasoning_level": base_config["reasoning_level"],
        }
    else:
        tier_overrides = role_config.get("tiers", {})
        fallback_chain = tier_fallbacks[tier]

        chosen: dict[str, Any] = {}
        for candidate in fallback_chain:
            candidate_config = tier_overrides.get(candidate, {})
            if candidate_config and candidate_config not in model_passthrough:
                if isinstance(candidate_config, str):
                    chosen = {"model": candidate_config}
                    if provider_is_per_tier:
                        inferred = infer_provider_from_model(candidate_config)
                        if inferred:
                            chosen["provider"] = inferred
                else:
                    chosen = candidate_config
                    if provider_is_per_tier and "provider" not in chosen and "model" in chosen:
                        inferred = infer_provider_from_model(chosen["model"])
                        if inferred:
                            chosen["provider"] = inferred
                break

        if not chosen:
            role_provider = (
                DEFAULT_PROVIDER
                if provider_is_per_tier
                else role_config.get("provider", base_config["provider"])
            )
            role_default = get_role_tier_default(role_provider, role, tier)
            if role_default and role_default != "default":
                chosen = {
                    "provider": role_provider,
                    "auth_method": base_config["auth_method"],
                    "model": role_default,
                    "reasoning_level": base_config["reasoning_level"],
                }
            else:
                provider_defaults = provider_tier_defaults.get(role_provider, {})
                if tier in provider_defaults:
                    chosen = {
                        "provider": role_provider,
                        "auth_method": base_config["auth_method"],
                        "model": provider_defaults[tier],
                        "reasoning_level": base_config["reasoning_level"],
                    }

    resolved = {
        "provider": chosen.get("provider", base_config["provider"]),
        "auth_method": chosen.get("auth_method", base_config["auth_method"]),
        "model": chosen.get("model", base_config["model"]),
        "reasoning_level": chosen.get("reasoning_level", base_config["reasoning_level"]),
        "parse_retry_enabled": base_config["parse_retry_enabled"],
        "parse_retry_providers": base_config["parse_retry_providers"],
        "parse_retry_models": base_config["parse_retry_models"],
    }

    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_auth_method:
        if override_auth_method not in LLM_AUTH_METHODS:
            msg = f"Invalid auth method: {override_auth_method}"
            raise ValueError(msg)
        resolved["auth_method"] = override_auth_method

    if override_model:
        resolved["model"] = validate_model(override_model, resolved["provider"])

    if override_reasoning_level:
        if override_reasoning_level not in (*REASONING_LEVELS, DEFAULT_REASONING_SELECTION):
            msg = (
                f"Invalid reasoning level: {override_reasoning_level}. "
                f"Valid: {', '.join([*REASONING_LEVELS, DEFAULT_REASONING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["reasoning_level"] = override_reasoning_level

    resolved["reasoning_level"] = _materialize_default_reasoning_level(
        resolved["provider"],
        resolved["model"],
        resolved.get("reasoning_level"),
        role=role,
        tier=tier,
    )
    return resolved
