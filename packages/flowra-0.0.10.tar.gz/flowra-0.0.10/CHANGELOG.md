# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com),
and this project adheres to [Semantic Versioning](https://semver.org).

## [0.0.10] - 2026-03-15

### Changed
- **`NoSpec`/`NoResult` replaced with `None`.** Use `Agent[None, MyResult]` instead of
  `Agent[NoSpec, MyResult]`, and `Agent[MySpec, None]` instead of `Agent[MySpec, NoResult]`.
  The sentinel classes are removed.
- **`ServiceLocator.provide()` infers type.** `sl.provide(LLMConfig(...))` now works —
  the type is inferred from `type(value)`. The two-argument form `sl.provide(LLMConfig, ...)`
  still works for providing by base type.

## [0.0.9] - 2026-03-15

### Changed
- **Agent spec injection via constructor.** Agent spec (`S` from `Agent[S, R]`) is now
  passed to the agent's `__init__` by type matching at compile time. Spec is NOT a service —
  it does not leak into child agents via `parent_services`.
  ```python
  class Researcher(Agent[ResearchSpec, ResearchResult]):
      def __init__(self, spec: ResearchSpec, sl: ServiceLocator) -> None:
          sl.provide(LLMConfig, LLMConfig(model=spec.model))
  ```
- **Removed `FromAgentSpec`.** Agent spec is no longer available as a step parameter binding
  source. Use the constructor to receive the spec and store it on `self` if needed in steps.
- **Binding markers → UPPER_CASE sentinels.** `FromSpec`, `FromChild`, `FromChildren`
  replaced with `step_arg.SPEC`, `step_arg.CHILD`. `FromChildren` removed — `list[T]` hint
  handles list mode automatically. `FromToolInput`, `FromToolService` replaced with
  `tool_arg.INPUT`, `tool_arg.SERVICE`. New `agent_arg.SPEC`, `agent_arg.SERVICE` for
  agent constructor binding.
- **Removed `HookContext` and `HookProvider`.** `HookContext` replaced entirely by
  `ExecutionContext`. `HookProvider` protocol removed — use `registry.on()` directly.
- `LLMCallResult` now includes `elapsed: float` — wall-clock seconds for the LLM call.

### Added
- `LLMCallAgent` — pre-built agent for single LLM calls. Messages in, response out,
  no tool loop, no session history. Auto-switches to streaming when `TextDeltaEvent`
  or `ThinkingDeltaEvent` handlers are registered. Own hook events independent from
  `ToolLoopAgent`.
- `ExecutionContext` — automatic execution metadata on every emitted event. Two navigable hierarchies:
  - **Execution stack** (`ExecutionContext.stack`): runtime call chain from root to emitting agent.
    Each `ExecutionFrame` carries `agent: AgentInfo`, `spec`, and `tag`.
  - **Registration hierarchy** (`AgentInfo.parent`): agent's position in the name tree.
    Each `AgentInfo` has `name`, `path`, `source_type`, and `parent`.
  - `HookRegistry.with_context()` creates a new registry sharing handlers but stamping
    a different context — the runtime uses this to give each execution node its own context.
- `ExecutionContext` stack navigation helpers: `find_spec(type)`, `get_spec(type)`,
  `find_frame(spec_type=, agent_type=)`, `get_frame(spec_type=, agent_type=)` — search the
  execution stack from current frame upward. `get_*` variants raise `LookupError` on miss.
- `Event.context` is now always `ExecutionContext` (no longer optional). `HookRegistry.emit()`
  raises `RuntimeError` if called without context — ensures events are only emitted within runtime.

## [0.0.8] - 2026-03-14

### Changed
- Renamed interrupt exception: `Interrupted` → `InterruptedError`. The old name `Interrupted`
  is now a frozen dataclass result type (used for interrupt propagation through the execution tree).
- Renamed internal module `flowra/agent/agent_def.py` → `flowra/agent/model.py`.
- **Per-node interrupt tokens.** Each execution node gets its own `InterruptToken` with
  parent→child cascade. `InterruptedError` is caught per-node and converted to `Interrupted()`
  result. `runtime.run()` returns `Interrupted()` instead of `None` on interrupt.
- **Interrupted auto-propagation.** `Interrupted` results flow up the execution tree.
  Parent join-steps receive `None` for interrupted children's nullable parameters;
  if binding fails due to missing results, the parent auto-propagates `Interrupted()`.

### Added
- `Interrupted` frozen dataclass — typed result for interrupted agents (`reason: str | None`).
- **Composable spawn strategies**: `WhenAll`, `WhenAny`, `WhenN` combinators for `Spawn`.
  `Spawn` now accepts positional `SpawnNode` args (alongside the existing `children=` keyword).
  Combinators are nestable: `Spawn(WhenAny(WhenAll(a, b), c), then="join")`.
- `timeout(seconds=, minutes=)` helper — shortcut for a timeout child agent.
  Returns `TimeoutExpired(seconds=...)` on expiry, `Interrupted()` if cancelled.
- `TimeoutExpired` frozen dataclass — result type for the built-in timeout agent.

## [0.0.7] - 2026-03-13

### Changed
- Slots are now created in the agent constructor via `store.slot(Scalar[int], "key")`
  instead of declarative `slot("key")` class attributes. `AgentStore` now provides the
  `slot()` method; the old `slot()` sentinel and `SlotMarker` are removed.
- **Annotated-based step parameter binding.** Step parameters now bind by matching type
  annotations against available values (step spec, child outputs). Optional
  `step_arg` markers (`step_arg.SPEC`, `step_arg.CHILD`, `step_arg.CHILD`) narrow binding
  to a specific source. Replaces the old `StepSpec`/`AgentResult` base class approach —
  user types no longer need to inherit from marker classes. All step parameter and return
  types (other than action types and `None`) must be dataclasses.
- `NoSpec` / `NoResult` are now standalone sentinels (not frozen dataclasses).
- `Agent[S, R]` generic parameters no longer require `StepSpec`/`AgentResult` bounds.

### Added
- `step_arg.SPEC`, `step_arg.CHILD`, `step_arg.CHILD` markers for `Annotated`-based step parameter binding.
- `ChildOutput` bridge type for passing child results with tags between runtime and agent.
- `tag` field on `CallStep` and `CallAgent` — labels a child so the join step can bind
  its result by tag via `step_arg.CHILD("tag")`.
- `allowed_tools` / `denied_tools` now support wildcard patterns via `fnmatch`
  (e.g. `{"mcp_*"}`, `{"debug_?"}`).
- **Exception-based interrupts** (.NET `CancellationToken` pattern):
  `InterruptToken.check()` raises `Interrupted` (like `ThrowIfCancellationRequested`),
  `with_interrupt()` raises `Interrupted` instead of silently ending the loop.
  Uncaught `Interrupted` from any step is caught by the engine — the entire execution
  tree completes immediately and `runtime.run()` returns `None`. Agents and tools can
  catch `Interrupted` explicitly for graceful partial results; `ToolCallAgent` catches
  it from tool execution and returns an error `ToolResultBlock`.

## [0.0.6] - 2026-03-12

### Changed
- Renamed `ToolLoopConfig.max_iterations` → `max_llm_calls` (and `ToolLoopStatus.MAX_ITERATIONS`
  → `MAX_LLM_CALLS`) to avoid confusion with the new runtime-level `max_iterations`.
- Unified sentinel values: `Scalar` and `AgentRuntime` now use shared `Unset`/`UNSET`
  from `flowra._sentinel` instead of per-module private sentinels.

### Added
- **Agents as tools**: `@agent_tool` decorator exposes an agent class as a tool that
  the LLM can call autonomously. `get_agent_tool()` extracts the tool for registry,
  `make_agent_tool()` builds one programmatically. The LLM sees a regular tool; behind
  the scenes, the sub-agent is spawned with its own system prompt and tool loop.
- **Runtime limits**: `AgentRuntime` now supports `max_iterations` (engine advance steps)
  and `timeout` (seconds). Both can be set as defaults in the constructor and overridden
  per `run()`/`resume()` call.
- `format_schema_for_llm` now handles array-style `type` (e.g. `["string", "null"]`).

## [0.0.5] - 2026-03-11

### Changed
- **Agents as black boxes**: agents now have a single entry point (`@step(entry=True)`),
  a typed spec (`S`), and a typed result (`R`) via `Agent[S, R]`. You run an agent —
  not a step of an agent. Steps are internal implementation details.
- **Explicit control flow separation**: split `Goto`/`Call` into `GotoStep`/`GotoAgent`
  and `CallStep`/`CallAgent` — internal step navigation vs external agent invocation.
- **Compile-time validation**: compiler extracts spec/result types from `Agent[S, R]`,
  validates entry step spec matches generic `S`, enforces single entry per agent,
  resolves `TypeAlias` unions.
- `NoSpec` / `NoResult` sentinels for agents that don't need spec or result types.
- `runtime.run()` no longer accepts `step=` parameter — entry point is determined
  by the agent itself.

### Fixed
- `cache_last_session_message` now correctly clears cache hints from turn messages.

## [0.0.4] - 2026-03-09

### Fixed
- **JSON schema response cleanup**: `AnthropicVertexProvider` now returns a single `TextBlock`
  with clean JSON when `json_schema` is set — markdown fences and thinking blocks are stripped.
  Previously, validated JSON was cleaned internally but the original (fenced) text was returned.
- `validate_json_schema` now returns `(error, cleaned_text)` tuple so callers get the
  fence-stripped text.

## [0.0.3] - 2026-03-08

### Changed
- **Hook system redesign**: replaced `ToolLoopHooks`/`ChatHooks` (24 Protocol classes, 12 executor
  functions, 5 result dataclasses) with generic `HookRegistry` + `Event[T]` pattern. Supports
  multiple handlers per event, `HookProvider` for distributable hook sets, and `propagate_to()`
  for parent/child isolation. Hook events are plain mutable dataclasses with result fields.
- `ToolLoopSpec.meta` / `ChatSpec.meta` renamed to `metadata`.

## [0.0.2] - 2026-03-08

### Added
- **Streaming**: `LLMProvider.stream()` method returns `AsyncIterator[StreamEvent]` with `TextDelta`, `ThinkingDelta`, and `ContentComplete` events. All three built-in providers implement real-time streaming. Default fallback calls `call()` and yields `ContentComplete`.
- **Anthropic thinking**: `AnthropicVertexAdditionalConfig` with `thinking_budget_tokens` enables extended thinking on Claude models. Thinking blocks are now parsed from Anthropic responses (`ThinkingBlock`).
- **Streaming hooks**: `on_text_delta` and `on_thinking_delta` hooks in `ToolLoopHooks`. When set, the agent automatically uses `stream()` instead of `call()`. Streaming respects `InterruptToken` — exits immediately even if the LLM is blocked.
- **`with_interrupt`**: Generic async iterator wrapper that races `__anext__()` against `InterruptToken.wait()` via `asyncio.wait(FIRST_COMPLETED)`. Used internally by `ToolLoopAgent` for streaming; available as `from flowra.agent import with_interrupt`.
- **Thinking model entry**: `anthropic/sonnet-4-5-think` in example model registry with 4000 token thinking budget.
- **Console/TUI streaming**: `--stream` flag for `console_chat.py` and `tui_chat.py` examples.

## [0.0.1] - 2026-03-07

Initial release.

### Added
- State machine agents with `@step` methods, `Goto`, `Spawn`, and stored values (`Scalar`, `AppendOnlyList`)
- Provider-agnostic LLM abstraction (`LLMProvider`, `LLMRequest`, `LLMResponse`)
- LLM providers: `AnthropicVertexProvider`, `GoogleVertexProvider`, `OpenAIProvider`
- Tool integration: `@tool` decorator, MCP server support, DI into tool handlers
- Execution engine with persistence, crash recovery, and cooperative interrupts
- Pre-built agents: `ChatAgent` (multi-turn chat) and `ToolLoopAgent` (tool loop with hooks)
- `ChatHooks` with `on_save_turn_messages` for transient message filtering
- Optional provider dependencies via extras: `flowra[anthropic]`, `flowra[openai]`, `flowra[google]`, `flowra[all]`
- Python 3.12, 3.13, 3.14 support
