import dataclasses
import inspect
import types
import typing
from typing import Annotated, Any, TypeAliasType, Union, get_args, get_origin

from . import agent_arg as _agent_arg, step_arg as _step_arg
from .model import (
    AbstractAgent,
    AgentDefinition,
    AgentDefinitionRef,
    AgentInstance,
    CallAgent,
    CallStep,
    ChildOutput,
    GotoAgent,
    GotoStep,
    Spawn,
    StepMeta,
    WhenAll,
    WhenAny,
    WhenN,
    get_step_tag,
)
from .service_locator import ServiceLocator
from .step_decorator import is_entry_step

__all__ = ["collect_dataclass_types", "compile_agent"]

# Action types are transient — the engine processes them immediately,
# they never appear in persisted state and must not be in the type registry.
_ACTION_TYPES = (GotoStep, GotoAgent, CallStep, CallAgent, Spawn, WhenAll, WhenAny, WhenN)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _InitParam:
    name: str
    service_type: type
    nullable: bool = False
    is_spec: bool = False
    has_explicit_marker: bool = False


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _StepParam:
    name: str
    match_type: type | tuple[type, ...]  # for isinstance; object = match any
    is_list: bool = False
    nullable: bool = False
    check_spec: bool = True
    check_children: bool = True
    child_tag: str | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _CompiledStep:
    tag: str
    method_name: str
    spec_types: frozenset[type]
    params: tuple[_StepParam, ...]


def collect_dataclass_types(typ: Any, registry: dict[str, type], seen: set[int] | None = None) -> None:
    """Recursively walk a type hint and register every dataclass type found.

    Traverses into unions, generics, Annotated, and TypeAliasType.
    Skips action types (GotoStep, Spawn, etc.) — they are transient and never persisted.
    Does NOT descend into dataclass fields — marshmallow handles that.

    Examples::

        collect_dataclass_types(ChatSpec, reg)
        # reg = {"ChatSpec": ChatSpec}

        collect_dataclass_types(ChatSpec | None, reg)
        # reg = {"ChatSpec": ChatSpec}   (None is skipped)

        collect_dataclass_types(list[ChatSpec | ExprSpec], reg)
        # reg = {"ChatSpec": ChatSpec, "ExprSpec": ExprSpec}

        collect_dataclass_types(Annotated[ChatSpec, step_arg.SPEC], reg)
        # reg = {"ChatSpec": ChatSpec}   (Annotated args traversed)

        collect_dataclass_types(str, reg)
        # reg = {}   (str is not a dataclass)

        collect_dataclass_types(GotoStep | ChatResult, reg)
        # reg = {"ChatResult": ChatResult}   (GotoStep is an action type, skipped)

        type Msg = UserMsg | AssistantMsg
        collect_dataclass_types(Msg, reg)
        # reg = {"UserMsg": UserMsg, "AssistantMsg": AssistantMsg}
    """
    if seen is None:
        seen = set()
    typ_id = id(typ)
    if typ_id in seen:
        return
    seen.add(typ_id)

    if isinstance(typ, TypeAliasType):
        collect_dataclass_types(typ.__value__, registry, seen)
        return

    origin = get_origin(typ)
    if origin is not None:
        for arg in get_args(typ):
            collect_dataclass_types(arg, registry, seen)
        return

    if not isinstance(typ, type):
        return

    if dataclasses.is_dataclass(typ) and not issubclass(typ, _ACTION_TYPES):
        tag = typ.__qualname__
        existing = registry.get(tag)
        if existing is not None and existing is not typ:
            raise ValueError(f"Duplicate type tag {tag!r}: {existing!r} vs {typ!r}")
        registry[tag] = typ


def compile_agent(
    agent_cls: type,
    subagents: dict[str, AgentDefinitionRef] | None = None,
) -> AgentDefinition:
    return _AgentCompiler.compile(agent_cls, subagents)


class _AgentCompiler:
    __slots__ = ()

    @staticmethod
    def __is_step_marker(meta: Any) -> bool:
        return meta is _step_arg.SPEC or isinstance(meta, _step_arg.Child)

    @staticmethod
    def __is_agent_marker(meta: Any) -> bool:
        return meta is _agent_arg.SPEC or meta is _agent_arg.SERVICE

    @classmethod
    def compile(
        cls,
        agent_cls: type,
        subagents: dict[str, AgentDefinitionRef] | None = None,
    ) -> AgentDefinition:
        init_params = cls.__compile_init(agent_cls)
        compiled_steps, step_metas = cls.__compile_steps(agent_cls)
        entry_step, agent_spec_types, agent_result_types = cls.__extract_agent_contract(agent_cls, step_metas)
        type_registry = cls.__build_type_registry(agent_cls, agent_spec_types, agent_result_types)

        # Post-process: for params without explicit agent_arg marker,
        # mark is_spec=True if type matches a spec type (implicit behavior).
        # Params with explicit markers (agent_arg.SPEC or agent_arg.SERVICE) are never modified.
        init_params = tuple(
            dataclasses.replace(ip, is_spec=True)
            if not ip.has_explicit_marker and not ip.is_spec and ip.service_type in agent_spec_types
            else ip
            for ip in init_params
        )

        create_instance = cls.__create_instance

        def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
            return create_instance(agent_cls, init_params, compiled_steps, sl, agent_spec)

        return AgentDefinition(
            steps=step_metas,
            type_registry=type_registry,
            create_instance=create,
            subagents=subagents or {},
            entry_step=entry_step,
            spec_types=agent_spec_types,
            result_types=agent_result_types,
            source_type=agent_cls if issubclass(agent_cls, AbstractAgent) else None,
        )

    # -----------------------------------------------------------------
    # Agent-level contract extraction
    # -----------------------------------------------------------------

    @classmethod
    def __extract_agent_contract(
        cls,
        agent_cls: type,
        step_metas: dict[str, StepMeta],
    ) -> tuple[str, frozenset[type], frozenset[type]]:
        """Determine agent's entry step, spec types, and result types.

        Sources (in priority order):
        1. Generic params from ``Agent[S, R]`` — if present, they are authoritative.
        2. Step metadata — used as fallback for unparameterized agents.

        Examples::

            class MyAgent(Agent[ChatSpec, ChatResult]):
                @step(entry=True)
                async def run(self, spec: ChatSpec) -> ChatResult: ...
            # → ("run", {ChatSpec}, {ChatResult})

            class MyAgent(Agent[ChatSpec | ExprSpec, DoneResult]):
                @step(entry=True)
                async def run(self, spec: ChatSpec | ExprSpec) -> DoneResult: ...
            # → ("run", {ChatSpec, ExprSpec}, {DoneResult})

            class MyAgent(Agent):  # unparameterized
                @step(entry=True)
                async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult: ...
            # → ("run", {ChatSpec}, {ChatResult})  — inferred from step
        """
        generic_spec_types, generic_result_types = cls.__extract_generic_params(agent_cls)
        entry_step = cls.__find_entry_step(agent_cls)

        if entry_step is None:
            msg = f"Agent {agent_cls.__name__} must have exactly one @step(entry=True)"
            raise TypeError(msg)

        entry_meta = step_metas.get(entry_step)

        if generic_spec_types is None:
            # Unparameterized Agent — infer from entry step
            generic_spec_types = entry_meta.spec_types if entry_meta else frozenset()
        elif entry_meta is not None and entry_meta.spec_types and entry_meta.spec_types != generic_spec_types:
            # Validate: entry step spec matches generic S
            msg = (
                f"Agent {agent_cls.__name__}: entry step {entry_step!r} spec types "
                f"{entry_meta.spec_types} don't match Agent generic spec types "
                f"{generic_spec_types}"
            )
            raise TypeError(msg)

        if generic_result_types is None:
            # Unparameterized Agent — collect result types from all steps
            generic_result_types = frozenset().union(*(m.result_types for m in step_metas.values()))

        return entry_step, generic_spec_types, generic_result_types

    @classmethod
    def __extract_generic_params(
        cls,
        agent_cls: type,
    ) -> tuple[frozenset[type] | None, frozenset[type] | None]:
        """Extract S and R from ``Agent[S, R]`` in __orig_bases__.

        Returns (None, None) if the agent is not parameterized.

        Examples::

            class MyAgent(Agent[ChatSpec, ChatResult]): ...
            # → ({ChatSpec}, {ChatResult})

            class MyAgent(Agent[ChatSpec | ExprSpec, DoneResult | ErrorResult]): ...
            # → ({ChatSpec, ExprSpec}, {DoneResult, ErrorResult})

            class MyAgent(Agent[None, ChatResult]): ...
            # → (frozenset(), {ChatResult})

            class MyAgent(Agent): ...
            # → (None, None)
        """
        # Local import to break agent.py ↔ compile.py cycle:
        # Agent.__init_subclass__ calls compile_agent, and we need Agent
        # to identify the Agent[S, R] base among __orig_bases__.
        # Extracting the generic params in agent.py would duplicate introspection logic;
        # a local import is the lesser evil here.
        from .agent import Agent

        for base in getattr(agent_cls, "__orig_bases__", ()):
            origin = get_origin(base)
            if origin is Agent:
                args = get_args(base)
                if len(args) == 2:
                    spec_raw, result_raw = args
                    spec_types = cls.__flatten_spec_types(spec_raw, agent_cls)
                    result_types = cls.__flatten_result_types(result_raw, agent_cls)
                    return frozenset(spec_types), frozenset(result_types)
        return None, None

    @classmethod
    def __flatten_spec_types(cls, tp: Any, agent_cls: type) -> tuple[type, ...]:
        """Flatten the S type parameter of Agent[S, R] into concrete types.

        Examples::

            ChatSpec          → (ChatSpec,)
            ChatSpec | ExprSpec → (ChatSpec, ExprSpec)
            None              → ()
        """
        tp = cls.__resolve_hint(tp)
        if tp is type(None):
            return ()
        if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
            result: list[type] = []
            for arg in get_args(tp):
                result.extend(cls.__flatten_spec_types(arg, agent_cls))
            return tuple(result)
        if isinstance(tp, type):
            return (tp,)
        msg = f"Agent {agent_cls.__name__}: spec type must be a type, got {tp!r}"
        raise TypeError(msg)

    @classmethod
    def __flatten_result_types(cls, tp: Any, agent_cls: type) -> tuple[type, ...]:
        """Flatten the R type parameter of Agent[S, R] into concrete types.

        Examples::

            ChatResult          → (ChatResult,)
            DoneResult | Error  → (DoneResult, Error)
            None                → ()
        """
        tp = cls.__resolve_hint(tp)
        if tp is type(None):
            return ()
        if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
            result: list[type] = []
            for arg in get_args(tp):
                result.extend(cls.__flatten_result_types(arg, agent_cls))
            return tuple(result)
        if isinstance(tp, type):
            return (tp,)
        msg = f"Agent {agent_cls.__name__}: result type must be a type, got {tp!r}"
        raise TypeError(msg)

    @classmethod
    def __find_entry_step(cls, agent_cls: type) -> str | None:  # None = not found
        """Find the single @step(entry=True) in agent's MRO. Raises on duplicates."""
        entry_tag: str | None = None
        for klass in reversed(agent_cls.__mro__):
            for attr_name in vars(klass):
                val = getattr(klass, attr_name, None)
                if not callable(val):
                    continue
                tag = get_step_tag(val)
                if tag is None:
                    continue
                if is_entry_step(val):
                    if entry_tag is not None and entry_tag != tag:
                        msg = f"Agent {agent_cls.__name__} has multiple entry steps: {entry_tag!r} and {tag!r}"
                        raise TypeError(msg)
                    entry_tag = tag
        return entry_tag

    # -----------------------------------------------------------------
    # Steps
    # -----------------------------------------------------------------

    @classmethod
    def __compile_steps(
        cls,
        agent_cls: type,
    ) -> tuple[dict[str, _CompiledStep], dict[str, StepMeta]]:
        """Walk agent MRO, find all @step methods, compile each into _CompiledStep + StepMeta.

        For each @step method:
        - __validate_step_return_type → result_types (dataclass types from return hint)
        - __compile_step_params → binding descriptors for each parameter
        - __find_spec_types → spec types (only from Annotated[T, step_arg.SPEC] params)

        Later classes in MRO override earlier ones (same tag = same step).

        Example: for an agent with::

            @step("start", entry=True)
            async def start(self, spec: ChatSpec) -> Spawn: ...

            @step("collect")
            async def collect(self, result: Annotated[ToolLoopResult, step_arg.CHILD]) -> ChatResult: ...

        compiled_steps = {
            "start": _CompiledStep(tag="start", method_name="start", spec_types=frozenset(), params=(...)),
            "collect": _CompiledStep(tag="collect", method_name="collect", spec_types=frozenset(), params=(...)),
        }
        step_metas = {
            "start": StepMeta(spec_types=frozenset(), result_types=frozenset()),
            "collect": StepMeta(spec_types=frozenset(), result_types=frozenset({ChatResult})),
        }
        """
        compiled_steps: dict[str, _CompiledStep] = {}
        step_metas: dict[str, StepMeta] = {}

        for klass in reversed(agent_cls.__mro__):
            for attr_name in vars(klass):
                val = getattr(klass, attr_name, None)
                if not callable(val):
                    continue
                tag = get_step_tag(val)
                if tag is None:
                    continue

                result_types = cls.__validate_step_return_type(val, tag)
                params = cls.__compile_step_params(val)
                spec_types = cls.__find_spec_types(val)
                compiled_steps[tag] = _CompiledStep(
                    tag=tag, method_name=attr_name, spec_types=spec_types, params=params
                )
                step_metas[tag] = StepMeta(spec_types=spec_types, result_types=result_types)

        return compiled_steps, step_metas

    # -----------------------------------------------------------------
    # Type registry
    # -----------------------------------------------------------------

    @classmethod
    def __build_type_registry(
        cls,
        agent_cls: type,
        agent_spec_types: frozenset[type],
        agent_result_types: frozenset[type],
    ) -> dict[str, type]:
        """Collect all dataclass types needed for serialization.

        Sources:
        1. All type hints from all @step methods (params + return)
        2. Agent-level spec/result types from ``Agent[S, R]``

        Agent generic types are included unconditionally — agent_spec is persisted
        on ExecutionNode even if no step method mentions it in hints.

        Action types (GotoStep, Spawn, etc.) are skipped — they are transient.

        Example: for ``Agent[ChatSpec, ChatResult]`` with steps::

            async def start(self, spec: ChatSpec) -> Spawn: ...
            async def collect(self, result: ToolLoopResult) -> ChatResult: ...

        registry = {"ChatSpec": ChatSpec, "ToolLoopResult": ToolLoopResult, "ChatResult": ChatResult}
        """
        registry: dict[str, type] = {}
        for klass in reversed(agent_cls.__mro__):
            for attr_name in vars(klass):
                val = getattr(klass, attr_name, None)
                if not callable(val):
                    continue
                if get_step_tag(val) is None:
                    continue
                for name, hint in cls.__get_type_hints(val).items():
                    if name == "self":
                        continue
                    collect_dataclass_types(hint, registry)
        for t in agent_spec_types:
            collect_dataclass_types(t, registry)
        for t in agent_result_types:
            collect_dataclass_types(t, registry)
        return registry

    # -----------------------------------------------------------------
    # Instance creation
    # -----------------------------------------------------------------

    @classmethod
    def __create_instance(
        cls,
        agent_cls: type,
        init_params: tuple[_InitParam, ...],
        compiled_steps: dict[str, _CompiledStep],
        sl: ServiceLocator,
        agent_spec: Any | None = None,
    ) -> AgentInstance:
        """Instantiate agent and return an AgentInstance with a bound call_step closure."""
        all_services = dict(sl.services)
        kwargs: dict[str, Any] = {}
        for ip in init_params:
            if ip.is_spec:
                if agent_spec is not None and isinstance(agent_spec, ip.service_type):
                    kwargs[ip.name] = agent_spec
                elif ip.nullable:
                    kwargs[ip.name] = None
            else:
                if ip.service_type in all_services:
                    kwargs[ip.name] = all_services[ip.service_type]
                elif ip.nullable:
                    kwargs[ip.name] = None
        agent = agent_cls(**kwargs)

        bind_step_args = cls.__bind_step_args

        async def call_step(
            tag: str,
            spec: Any | None = None,
            child_outputs: list[ChildOutput] | None = None,
        ) -> Any:
            step = compiled_steps.get(tag)
            if step is None:
                raise RuntimeError(f"Step {tag!r} not found in {agent_cls.__name__}")
            step_kwargs = bind_step_args(step, spec=spec, child_outputs=child_outputs or [])
            result = getattr(agent, step.method_name)(**step_kwargs)
            if inspect.isawaitable(result):
                return await result
            return result

        return AgentInstance(call_step=call_step)

    @staticmethod
    def __bind_step_args(
        step: _CompiledStep,
        *,
        spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
    ) -> dict[str, Any]:
        """Match available values to step parameters by type.

        Binding sources (each param checks a subset based on its marker):
        - spec: step-level spec (from GotoStep/entry call)
        - child_outputs: results from Spawn children

        Examples::

            # param: ChatResult (is_list=False), children=[ChatResult(...)]
            # → binds the single child result

            # param: list[ToolCallResult] (is_list=True), children=[TCR1, TCR2]
            # → binds [TCR1, TCR2]

            # param: ChatSpec | None (nullable=True), no matching candidates
            # → binds None

            # param: ChatSpec, no matching candidates, not nullable
            # → not bound (Python will raise TypeError for missing arg)
        """
        kwargs: dict[str, Any] = {}
        for param in step.params:
            candidates: list[Any] = []
            mt = param.match_type

            if param.check_spec and spec is not None and isinstance(spec, mt):
                candidates.append(spec)

            if param.check_children and child_outputs:
                for co in child_outputs:
                    if param.child_tag is not None and co.tag != param.child_tag:
                        continue
                    if isinstance(co.result, mt):
                        candidates.append(co.result)

            if param.is_list:
                kwargs[param.name] = candidates
            elif len(candidates) == 1:
                kwargs[param.name] = candidates[0]
            elif len(candidates) > 1:
                raise RuntimeError(
                    f"Ambiguous binding for parameter '{param.name}' in step '{step.tag}': "
                    f"{len(candidates)} candidates match type {mt!r}"
                )
            elif param.nullable:
                kwargs[param.name] = None
        return kwargs

    # -----------------------------------------------------------------
    # Init params
    # -----------------------------------------------------------------

    @classmethod
    def __compile_init(cls, agent_cls: type) -> tuple[_InitParam, ...]:
        """Extract __init__ parameters as service dependencies.

        Each parameter's type annotation is treated as a service key
        for lookup in ServiceLocator.

        Examples::

            __init__(self, store: AgentStore, registry: ToolRegistry)
            # → (_InitParam("store", AgentStore), _InitParam("registry", ToolRegistry))

            __init__(self, hooks: HookRegistry | None = None)
            # → (_InitParam("hooks", HookRegistry, nullable=True))

            __init__(self, hooks: Optional[HookRegistry] = None)
            # → (_InitParam("hooks", HookRegistry, nullable=True))   (same as T | None)

            __init__(self, hooks: HookRegistry | None)
            # → (_InitParam("hooks", HookRegistry, nullable=True))   (= None not required)

            __init__(self, config: Annotated[AppConfig, SomeMeta])
            # → (_InitParam("config", AppConfig))   (Annotated unwrapped)

            __init__(self, spec: Annotated[MySpec, agent_arg.SPEC])
            # → (_InitParam("spec", MySpec, is_spec=True))   (explicit spec)

            __init__(self, svc: Annotated[MyService, agent_arg.SERVICE])
            # → (_InitParam("svc", MyService, is_spec=False))   (explicit service)
        """
        hints = cls.__get_type_hints(agent_cls.__init__)
        params: list[_InitParam] = []
        for name, resolved in hints.items():
            if name == "return":
                continue
            explicit_marker = cls.__find_agent_marker(resolved)
            service_type = cls.__extract_service_type(resolved)
            if service_type is not None:
                nullable = cls.__is_nullable(resolved)
                is_spec = explicit_marker is _agent_arg.SPEC
                has_explicit_marker = explicit_marker is not None
                params.append(
                    _InitParam(
                        name=name,
                        service_type=service_type,
                        nullable=nullable,
                        is_spec=is_spec,
                        has_explicit_marker=has_explicit_marker,
                    )
                )
        return tuple(params)

    @classmethod
    def __find_agent_marker(cls, hint: Any) -> Any:
        """Find an agent_arg marker in an Annotated type hint.

        Returns the marker instance if found, None otherwise.
        """
        if get_origin(hint) is Annotated:
            args = get_args(hint)
            for meta in args[1:]:
                if cls.__is_agent_marker(meta):
                    return meta
        # Check union with None
        if isinstance(hint, types.UnionType) or get_origin(hint) is Union:
            for arg in get_args(hint):
                if arg is type(None):
                    continue
                if get_origin(arg) is Annotated:
                    inner_args = get_args(arg)
                    for meta in inner_args[1:]:
                        if cls.__is_agent_marker(meta):
                            return meta
        return None

    # -----------------------------------------------------------------
    # Step params
    # -----------------------------------------------------------------

    @classmethod
    def __compile_step_params(cls, method: Any) -> tuple[_StepParam, ...]:
        """Compile step method parameters into binding descriptors.

        For each parameter (except self/return):
        1. Check for Annotated marker → determines which sources to check
        2. Extract match_type for isinstance + is_list flag
        3. Validate that match_type is a dataclass (or Any)
        4. Detect nullable (T | None)

        Examples::

            async def run(self, spec: ChatSpec) -> ...:
            # → _StepParam(name="spec", match_type=ChatSpec, check_spec=True,
            #              check_children=True)

            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ...:
            # → _StepParam(name="spec", match_type=ChatSpec, check_spec=True,
            #              check_children=False)

            async def join(self, results: Annotated[list[ToolCallResult], step_arg.CHILD]) -> ...:
            # → _StepParam(name="results", match_type=ToolCallResult, is_list=True,
            #              check_spec=False, check_children=True)

            async def join(self, result: Annotated[Any, step_arg.CHILD("calc")]) -> ...:
            # → _StepParam(name="result", match_type=object, child_tag="calc",
            #              check_spec=False, check_children=True)

            async def run(self, spec: ChatSpec | None = None) -> ...:
            # → _StepParam(name="spec", match_type=ChatSpec, nullable=True)
        """
        hints = cls.__get_type_hints(method)
        params: list[_StepParam] = []
        for name, hint in hints.items():
            if name == "self" or name == "return":
                continue

            marker, inner_type = cls.__find_marker(hint)
            raw_type = inner_type if marker is not None else hint

            # Source flags based on marker (default: all sources)
            check_spec = True
            check_children = True
            child_tag: str | None = None

            if marker is _step_arg.SPEC:
                check_children = False
            elif isinstance(marker, _step_arg.Child):
                check_spec = False
                child_tag = marker.tag

            match_type, is_list = cls.__extract_match_info(raw_type)

            cls.__validate_step_param_type(match_type, name, method)
            nullable = cls.__is_nullable(raw_type)

            params.append(
                _StepParam(
                    name=name,
                    match_type=match_type,
                    is_list=is_list,
                    nullable=nullable,
                    check_spec=check_spec,
                    check_children=check_children,
                    child_tag=child_tag,
                )
            )
        return tuple(params)

    @classmethod
    def __find_marker(cls, hint: Any) -> tuple[Any, Any]:
        """Find a From* marker in an Annotated type hint.

        Returns (marker, inner_type) if found, (None, None) otherwise.

        Examples::

            Annotated[ChatSpec, step_arg.SPEC]           → (step_arg.SPEC, ChatSpec)
            Annotated[Any, step_arg.CHILD("calc")]       → (step_arg.CHILD("calc"), Any)
            Annotated[list[TCR], step_arg.CHILD]      → (step_arg.CHILD, list[TCR])
            Annotated[ChatSpec, step_arg.SPEC] | None     → (step_arg.SPEC, ChatSpec)
            ChatSpec                                → (None, None)
            ChatSpec | None                         → (None, None)
        """
        # Direct Annotated
        if get_origin(hint) is Annotated:
            return cls.__check_annotated_metadata(hint)

        # Union with None: check if any member is Annotated with a marker
        if isinstance(hint, types.UnionType) or get_origin(hint) is Union:
            for arg in get_args(hint):
                if arg is type(None):
                    continue
                if get_origin(arg) is Annotated:
                    return cls.__check_annotated_metadata(arg)

        return None, None

    @classmethod
    def __check_annotated_metadata(cls, annotated_hint: Any) -> tuple[Any, Any]:
        """Check Annotated[T, ...] metadata for From* markers.

        Examples::

            Annotated[ChatSpec, step_arg.SPEC]        → (step_arg.SPEC, ChatSpec)
            Annotated[Any, step_arg.CHILD("tag")]     → (step_arg.CHILD("tag"), Any)
            Annotated[ChatSpec, SomeOtherMeta]   → (None, None)
        """
        args = get_args(annotated_hint)
        if len(args) < 2:
            return None, None
        inner_type = args[0]
        for meta in args[1:]:
            if cls.__is_step_marker(meta):
                return meta, inner_type
        return None, None

    @classmethod
    def __extract_match_info(cls, hint: Any) -> tuple[type | tuple[type, ...], bool]:
        """Extract (match_type, is_list) from a type hint for isinstance-based binding.

        match_type is ``object`` for Any (matches everything).

        Examples::

            ChatSpec                → (ChatSpec, False)
            ChatSpec | None         → (ChatSpec, False)
            ChatSpec | ExprSpec     → ((ChatSpec, ExprSpec), False)
            list[ChatSpec]          → (ChatSpec, True)
            list[A | B]             → ((A, B), True)
            Any                     → (object, False)
            list[Any]               → (object, True)

        With TypeAliasType::

            type Msg = UserMsg | AssistantMsg
            Msg                     → ((UserMsg, AssistantMsg), False)
            list[Msg]               → ((UserMsg, AssistantMsg), True)
        """
        unwrapped = cls.__unwrap_optional(hint)
        resolved = cls.__resolve_hint(unwrapped)
        origin = get_origin(resolved)
        if origin is list:
            args = get_args(resolved)
            if args:
                return cls.__to_isinstance_type(args[0]), True
            return object, True
        return cls.__to_isinstance_type(unwrapped), False

    @classmethod
    def __to_isinstance_type(cls, hint: Any) -> type | tuple[type, ...]:
        """Convert a type hint to a type (or tuple) usable with isinstance().

        Returns ``object`` as a wildcard when the hint is Any or unresolvable.

        Examples::

            ChatSpec            → ChatSpec
            ChatSpec | ExprSpec → (ChatSpec, ExprSpec)
            Any                 → object
            ChatSpec | None     → ChatSpec   (None stripped)
        """
        unwrapped = cls.__unwrap_optional(hint)
        if unwrapped is Any:
            return object
        flat = cls.__flatten_types(unwrapped)
        concrete = [t for t in flat if t is not type(None) and isinstance(t, type)]
        if not concrete:
            return object
        if len(concrete) == 1:
            return concrete[0]
        return tuple(concrete)

    @classmethod
    def __is_nullable(cls, tp: Any) -> bool:
        """Check if type allows None (T | None, Optional[T]).

        Unwraps Annotated before checking.

        Examples::

            ChatSpec                            → False
            ChatSpec | None                     → True
            Optional[ChatSpec]                  → True
            ChatSpec | ExprSpec                 → False
            Annotated[ChatSpec | None, step_arg.SPEC] → True   (None inside Annotated)
            Annotated[ChatSpec, step_arg.SPEC] | None → True   (None outside Annotated)
        """
        tp = cls.__resolve_hint(tp)
        if get_origin(tp) is Annotated:
            tp = get_args(tp)[0]
        if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
            return type(None) in get_args(tp)
        return False

    @classmethod
    def __unwrap_optional(cls, tp: Any) -> Any:
        """Strip None from a union type. Non-union types pass through unchanged.

        Examples::

            ChatSpec | None             → ChatSpec
            ChatSpec | ExprSpec | None  → ChatSpec | ExprSpec
            ChatSpec                    → ChatSpec
            ChatSpec | ExprSpec         → ChatSpec | ExprSpec
        """
        tp = cls.__resolve_hint(tp)
        if isinstance(tp, types.UnionType) or get_origin(tp) is Union:
            non_none = [a for a in get_args(tp) if a is not type(None)]
            if len(non_none) == 1:
                return cls.__resolve_hint(non_none[0])
            if len(non_none) > 1:
                # Reconstruct union without None
                return Union[tuple(non_none)]  # noqa: UP007
        return tp

    @classmethod
    def __find_spec_types(cls, method: Any) -> frozenset[type]:
        """Find spec types from a step method's step_arg.SPEC-annotated parameter.

        Only looks at explicitly marked ``Annotated[T, step_arg.SPEC]`` parameters.
        Returns empty frozenset if no step_arg.SPEC marker is found.

        Examples::

            async def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ...:
            # → frozenset({ChatSpec})

            async def run(self, spec: Annotated[ChatSpec | ExprSpec, step_arg.SPEC]) -> ...:
            # → frozenset({ChatSpec, ExprSpec})

            async def run(self, spec: Annotated[ChatSpec | None, step_arg.SPEC]) -> ...:
            # → frozenset({ChatSpec})

            type MySpec = ChatSpec | ExprSpec
            async def run(self, spec: Annotated[MySpec, step_arg.SPEC]) -> ...:
            # → frozenset({ChatSpec, ExprSpec})   (TypeAliasType unwrapped)

            async def run(self, spec: ChatSpec) -> ...:
            # → frozenset()   (no step_arg.SPEC marker)
        """
        hints = cls.__get_type_hints(method)
        for name, hint in hints.items():
            if name == "self" or name == "return":
                continue
            marker, inner_type = cls.__find_marker(hint)
            if marker is _step_arg.SPEC:
                # Extract spec types from inner_type
                unwrapped = cls.__unwrap_optional(inner_type)
                flat = cls.__flatten_types(unwrapped)
                concrete = [t for t in flat if t is not type(None) and isinstance(t, type)]
                if concrete:
                    return frozenset(concrete)
        return frozenset()

    @staticmethod
    def __validate_step_param_type(match_type: type | tuple[type, ...], param_name: str, method: Any) -> None:
        """Validate that all concrete types in a step parameter are dataclasses.

        ``object`` (representing Any) is allowed as a wildcard.

        Examples (ok)::

            ChatSpec                    — dataclass ✓
            (ChatSpec, ExprSpec)        — both dataclasses ✓
            object                      — Any wildcard ✓

        Examples (raises TypeError)::

            str                         — not a dataclass ✗
            (ChatSpec, str)             — str is not a dataclass ✗
        """
        if match_type is object:  # Any → wildcard, ok
            return
        types_to_check = match_type if isinstance(match_type, tuple) else (match_type,)
        for t in types_to_check:
            if not dataclasses.is_dataclass(t):
                step_name = getattr(method, "__qualname__", getattr(method, "__name__", repr(method)))
                raise TypeError(f"Step {step_name!r} parameter {param_name!r}: type {t.__name__} must be a dataclass")

    @classmethod
    def __validate_step_return_type(cls, method: Any, tag: str) -> frozenset[type]:
        """Validate step return type and extract result (non-action) types.

        Allowed return types: GotoStep, GotoAgent, Spawn, dataclass, None.
        CallStep and CallAgent are explicitly forbidden.

        Examples::

            async def run(...) -> GotoStep | ChatResult:
            # → frozenset({ChatResult})

            async def run(...) -> Spawn:
            # → frozenset()   (Spawn is an action, not a result)

            async def run(...) -> ChatResult | ErrorResult:
            # → frozenset({ChatResult, ErrorResult})

            async def run(...) -> GotoStep | GotoAgent | Spawn | ChatResult | None:
            # → frozenset({ChatResult})

            type MyResult = ChatResult | ErrorResult
            async def run(...) -> MyResult:
            # → frozenset({ChatResult, ErrorResult})   (TypeAliasType unwrapped)

            async def run(...) -> str:
            # → raises TypeError (str is not a dataclass)

            async def run(...) -> CallStep:
            # → raises TypeError (CallStep not allowed)
        """
        hints = cls.__get_type_hints(method)
        ret = hints.get("return")
        if ret is None or ret is inspect.Parameter.empty:
            return frozenset()
        ret_types = cls.__flatten_types(ret)
        result_types: set[type] = set()
        for t in ret_types:
            if t is type(None):
                continue
            if not isinstance(t, type):
                return frozenset()
            if issubclass(t, (GotoStep, GotoAgent, Spawn)):
                continue
            if issubclass(t, (CallStep, CallAgent)):
                raise TypeError(
                    f"Step {tag!r} return type {t.__name__} is not a valid StepResult "
                    f"(must be GotoStep | GotoAgent | Spawn | dataclass | None)"
                )
            if not dataclasses.is_dataclass(t):
                raise TypeError(f"Step {tag!r} return type {t.__name__} must be a dataclass")
            result_types.add(t)
        return frozenset(result_types)

    # -----------------------------------------------------------------
    # Type helpers
    # -----------------------------------------------------------------

    @staticmethod
    def __resolve_hint(hint: Any) -> Any:
        """Unwrap TypeAliasType to the underlying type.

        Examples::

            type Msg = UserMsg | AssistantMsg
            __resolve_hint(Msg) → UserMsg | AssistantMsg

            __resolve_hint(ChatSpec) → ChatSpec   (not a TypeAliasType, pass through)
        """
        while isinstance(hint, TypeAliasType):
            hint = hint.__value__
        return hint

    @classmethod
    def __flatten_types(cls, t: Any) -> list[Any]:
        """Flatten unions into a list of individual types. Non-unions return [t].

        Examples::

            ChatSpec                    → [ChatSpec]
            ChatSpec | ExprSpec         → [ChatSpec, ExprSpec]
            ChatSpec | ExprSpec | None  → [ChatSpec, ExprSpec, NoneType]
            A | (B | C)                 → [A, B, C]   (nested unions flattened)

            type Msg = UserMsg | AssistantMsg
            Msg                         → [UserMsg, AssistantMsg]   (TypeAliasType resolved)
        """
        t = cls.__resolve_hint(t)
        if isinstance(t, types.UnionType) or get_origin(t) is Union:
            result: list[Any] = []
            for arg in get_args(t):
                result.extend(cls.__flatten_types(arg))
            return result
        return [t]

    @staticmethod
    def __extract_service_type(resolved: Any) -> type | None:
        """Extract the service type from an __init__ parameter hint.

        Unwraps Annotated and Optional. Returns None if the hint
        doesn't resolve to a concrete type.

        Examples::

            AgentStore                          → AgentStore
            Annotated[AgentStore, SomeMeta]     → AgentStore
            HookRegistry | None                 → HookRegistry
            str | int                           → None  (ambiguous union)
        """
        # Unwrap Annotated first (include_extras=True)
        if get_origin(resolved) is Annotated:
            resolved = get_args(resolved)[0]
        if isinstance(resolved, type):
            return resolved
        if isinstance(resolved, types.UnionType) or get_origin(resolved) is Union:
            non_none = [a for a in get_args(resolved) if a is not type(None)]
            if len(non_none) == 1 and isinstance(non_none[0], type):
                return non_none[0]
        return None

    @staticmethod
    def __get_type_hints(obj: Any) -> dict[str, Any]:
        """Safe wrapper around typing.get_type_hints with include_extras=True.

        include_extras=True preserves Annotated metadata (needed for From* markers).
        Returns empty dict on failure (e.g. forward reference resolution errors).

        Examples::

            def run(self, spec: ChatSpec) -> ChatResult: ...
            # → {"spec": ChatSpec, "return": ChatResult}

            def run(self, spec: Annotated[ChatSpec, step_arg.SPEC]) -> ChatResult: ...
            # → {"spec": Annotated[ChatSpec, step_arg.SPEC], "return": ChatResult}
            #   (Annotated preserved thanks to include_extras=True)

            # Without include_extras=True, Annotated would be stripped:
            # → {"spec": ChatSpec, "return": ChatResult}   — markers lost!
        """
        try:
            return typing.get_type_hints(obj, include_extras=True)
        except Exception:
            return {}
