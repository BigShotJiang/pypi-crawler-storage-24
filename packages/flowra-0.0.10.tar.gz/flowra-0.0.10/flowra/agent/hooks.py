import dataclasses
import inspect
from collections.abc import Callable
from typing import Any

from .execution_context import ExecutionContext

__all__ = [
    "Event",
    "HookRegistry",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Event[T]:
    """Generic envelope wrapping event data with execution context."""

    data: T
    context: ExecutionContext


class HookRegistry:
    """Central registry for event handlers.

    Supports explicit isolation via propagate_to().
    """

    __slots__ = ("__context", "__handlers")

    def __init__(self, context: ExecutionContext | None = None) -> None:
        self.__context = context
        self.__handlers: dict[type, list[Callable[..., Any]]] = {}

    def on[E](self, event_type: type[E], handler: Callable[[Event[E]], Any], *, prepend: bool = False) -> None:
        handlers = self.__handlers.setdefault(event_type, [])
        if prepend:
            handlers.insert(0, handler)
        else:
            handlers.append(handler)

    def has_handlers(self, event_type: type) -> bool:
        handlers = self.__handlers.get(event_type)
        return handlers is not None and len(handlers) > 0

    async def emit[T](self, data: T) -> T:
        """Wrap data in Event, call all handlers, return (potentially mutated) data."""
        if self.__context is None:
            raise RuntimeError(
                "Cannot emit events from a HookRegistry without ExecutionContext. "
                "This registry must be used within AgentRuntime, which sets context automatically."
            )
        event = Event(data=data, context=self.__context)
        handlers = self.__handlers.get(type(data))
        if handlers:
            for handler in handlers:
                result = handler(event)
                if inspect.isawaitable(result):
                    await result
        return event.data

    def with_context(self, context: ExecutionContext) -> "HookRegistry":
        """Create a new registry sharing this registry's handlers but with a different context."""
        child = HookRegistry(context=context)
        child.__handlers = {k: list(v) for k, v in self.__handlers.items()}  # type: ignore[attr-defined]
        return child

    def propagate_to(
        self,
        target: "HookRegistry",
        *,
        only: list[type] | None = None,
        exclude: list[type] | None = None,
    ) -> None:
        """Register forwarding handlers that re-emit events to target.

        Args:
            exclude: If set, skip these event types.
        """
        source_types: set[type] = set(self.__handlers.keys())
        if only is not None:
            source_types = set(only)
        if exclude is not None:
            source_types -= set(exclude)

        for event_type in source_types:

            async def _forward(event: Event[Any], _target: "HookRegistry" = target) -> None:
                await _target.emit(event.data)

            self.on(event_type, _forward)
