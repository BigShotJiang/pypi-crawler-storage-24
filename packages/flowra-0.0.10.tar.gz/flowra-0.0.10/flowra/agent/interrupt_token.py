import abc
import dataclasses

__all__ = ["InterruptToken", "Interrupted", "InterruptedError"]


class InterruptedError(Exception):
    """Raised when an operation is interrupted via :class:`InterruptToken`."""


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Interrupted:
    """Typed result returned when an agent is interrupted.

    Flows through the execution tree as a normal result.
    Parent can handle it via step_arg.CHILD binding or let it auto-propagate.
    """

    reason: str | None = None


class InterruptToken(abc.ABC):
    __slots__ = ()

    @property
    @abc.abstractmethod
    def interrupted(self) -> bool: ...

    @abc.abstractmethod
    async def wait(self) -> None:
        """Block until interrupted. Returns immediately if already interrupted."""

    def check(self) -> None:
        """Raise :exc:`InterruptedError` if the token has been interrupted.

        Analogous to .NET's ``CancellationToken.ThrowIfCancellationRequested()``.
        """
        if self.interrupted:
            raise InterruptedError
