"""Pricing for OpenAI and OpenAI-compatible models (Mercury/Inception, etc.).

OpenAI charges for input, output, and cache reads.
Cache creation is free (automatic).
"""

from dataclasses import dataclass

__all__ = ["estimate_cost"]


# Not kw_only — constructed positionally in pricing tables for readability.
@dataclass(frozen=True, slots=True)
class _ModelPricing:
    input: float  # $ per 1M tokens
    output: float  # $ per 1M tokens
    cache_read: float  # $ per 1M tokens


# Ordered longest-key-first so the first substring match is the most specific.
_PRICING: list[tuple[str, _ModelPricing]] = [
    # OpenAI
    ("gpt-4.1-mini", _ModelPricing(0.40, 1.60, 0.10)),
    ("gpt-4.1-nano", _ModelPricing(0.10, 0.40, 0.025)),
    ("gpt-4o-mini", _ModelPricing(0.15, 0.60, 0.075)),
    ("gpt-5-mini", _ModelPricing(0.25, 2.00, 0.025)),
    ("gpt-5-nano", _ModelPricing(0.05, 0.40, 0.005)),
    ("o4-mini", _ModelPricing(1.10, 4.40, 0.275)),
    ("o3-mini", _ModelPricing(1.10, 4.40, 0.55)),
    ("o1-mini", _ModelPricing(1.10, 4.40, 0.55)),
    ("gpt-5.4", _ModelPricing(2.50, 15.00, 0.25)),
    ("gpt-5.2", _ModelPricing(1.75, 14.00, 0.175)),
    ("gpt-5.1", _ModelPricing(1.25, 10.00, 0.125)),
    ("gpt-4.1", _ModelPricing(2.00, 8.00, 0.50)),
    ("o3-pro", _ModelPricing(20.00, 80.00, 0)),
    ("gpt-4o", _ModelPricing(2.50, 10.00, 1.25)),
    ("gpt-5", _ModelPricing(1.25, 10.00, 0.125)),
    ("o3", _ModelPricing(2.00, 8.00, 0.50)),
    ("o1", _ModelPricing(15.00, 60.00, 7.50)),
    # Mercury (Inception)
    ("mercury-coder", _ModelPricing(0.25, 1.00, 0)),
    ("mercury-2", _ModelPricing(0.25, 0.75, 0.025)),
]


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int,
) -> float | None:
    """Estimate dollar cost for an OpenAI-compatible model.

    Returns None if the model is not in the pricing table.

    Contract: ``input_tokens`` must NOT include cache tokens.
    Each token is counted in exactly one category.
    """
    for key, p in _PRICING:
        if key in model:
            return (input_tokens * p.input + output_tokens * p.output + cache_read_tokens * p.cache_read) / 1_000_000
    return None
