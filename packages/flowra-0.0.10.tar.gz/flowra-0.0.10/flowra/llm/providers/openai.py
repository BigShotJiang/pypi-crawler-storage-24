import base64
import json
from collections.abc import AsyncIterator
from typing import Any, ClassVar

from openai import AsyncOpenAI
from openai.types import CompletionUsage
from openai.types.chat import ChatCompletion
from openai.types.chat.chat_completion_message_function_tool_call import ChatCompletionMessageFunctionToolCall

from ..blocks import AssistantBlock, ImageBlock, TextBlock, ToolResultBlock, ToolUseBlock
from ..messages import AssistantMessage, Message, SystemMessage, UserMessage
from ..pricing import openai as openai_pricing
from ..provider import LLMProvider
from ..request import LLMRequest
from ..response import LLMResponse, StopReason, Usage
from ..schema_formatting import format_output_schema_for_description
from ..stream import ContentComplete, StreamEvent, TextDelta
from ..tools import Tool

__all__ = [
    "OpenAIProvider",
]


class OpenAIProvider(LLMProvider):
    __slots__ = ("__client",)

    __USAGE_KNOWN_FIELDS: ClassVar[set[str]] = {
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "prompt_tokens_details",
        "completion_tokens_details",
    }

    def __init__(
        self,
        *,
        client: AsyncOpenAI | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        organization: str | None = None,
    ) -> None:
        if client is not None:
            self.__client = client
        elif api_key is not None:
            self.__client = AsyncOpenAI(api_key=api_key, base_url=base_url, organization=organization)
        else:
            raise ValueError("Either 'client' or 'api_key' must be provided")

    async def call(self, request: LLMRequest) -> LLMResponse:
        return await self.__call_llm(request)

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        kwargs = self.__build_kwargs(request)

        async with self.__client.chat.completions.stream(**kwargs) as api_stream:
            async for event in api_stream:
                if event.type == "content.delta":
                    yield TextDelta(text=event.delta)

            completion = await api_stream.get_final_completion()

        yield ContentComplete(response=self.__convert_response(completion, request.model))

    def __build_kwargs(self, request: LLMRequest) -> dict[str, Any]:
        openai_messages: list[dict[str, Any]] = []

        for message in request.messages:
            openai_messages.extend(self.__convert_message(message))

        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": openai_messages,
            "max_tokens": request.max_tokens or 4096,
        }

        if request.temperature is not None:
            kwargs["temperature"] = request.temperature

        if request.stop_sequences:
            kwargs["stop"] = request.stop_sequences

        if request.tools:
            kwargs["tools"] = [self.__convert_tool(tool) for tool in request.tools]

        if request.json_schema:
            strict_schema = self.__make_schema_strict(request.json_schema)
            kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "response",
                    "strict": True,
                    "schema": strict_schema,
                },
            }

        return kwargs

    async def __call_llm(self, request: LLMRequest) -> LLMResponse:
        kwargs = self.__build_kwargs(request)
        response: ChatCompletion = await self.__client.chat.completions.create(**kwargs)
        return self.__convert_response(response, request.model)

    @classmethod
    def __convert_message(cls, message: Message) -> list[dict[str, Any]]:
        match message:
            case SystemMessage(blocks=blocks):
                text = "\n\n".join(b.text for b in blocks)
                return [{"role": "system", "content": text}]

            case UserMessage(blocks=blocks):
                result: list[dict[str, Any]] = []
                content_parts: list[dict[str, Any]] = []

                for block in blocks:
                    match block:
                        case TextBlock(text=text):
                            content_parts.append({"type": "text", "text": text})
                        case ImageBlock(data=data, media_type=media_type):
                            b64 = base64.b64encode(data).decode()
                            content_parts.append(
                                {
                                    "type": "image_url",
                                    "image_url": {"url": f"data:{media_type};base64,{b64}"},
                                }
                            )
                        case ToolResultBlock(tool_use_id=tool_use_id, content=content, is_error=is_error):
                            if content_parts:
                                result.append({"role": "user", "content": cls.__simplify_content(content_parts)})
                                content_parts = []
                            tool_msg: dict[str, Any] = {
                                "role": "tool",
                                "content": content,
                                "tool_call_id": tool_use_id,
                            }
                            if is_error:
                                tool_msg["content"] = f"Error: {content}"
                            result.append(tool_msg)

                if content_parts:
                    result.append({"role": "user", "content": cls.__simplify_content(content_parts)})

                return result

            case AssistantMessage(blocks=blocks):
                text_parts: list[str] = []
                tool_calls: list[dict[str, Any]] = []

                for block in blocks:
                    match block:
                        case TextBlock(text=text):
                            text_parts.append(text)
                        case ToolUseBlock(id=id_, name=name, input=input_):
                            tool_calls.append(
                                {
                                    "id": id_,
                                    "type": "function",
                                    "function": {
                                        "name": name,
                                        "arguments": json.dumps(input_),
                                    },
                                }
                            )
                        case _:
                            pass  # ThinkingBlock is not sent back to the API

                msg: dict[str, Any] = {"role": "assistant"}
                if text_parts:
                    msg["content"] = "\n".join(text_parts)
                if tool_calls:
                    msg["tool_calls"] = tool_calls

                return [msg]

    @staticmethod
    def __simplify_content(parts: list[dict[str, Any]]) -> str | list[dict[str, Any]]:
        if len(parts) == 1 and parts[0]["type"] == "text":
            return parts[0]["text"]
        return parts

    @staticmethod
    def __convert_tool(tool: Tool) -> dict[str, Any]:
        description = tool.description
        if tool.output_schema:
            description += format_output_schema_for_description(tool.output_schema)

        return {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": description,
                "parameters": tool.input_schema or {"type": "object", "properties": {}},
            },
        }

    @classmethod
    def __convert_response(cls, response: ChatCompletion, model: str) -> LLMResponse:
        choice = response.choices[0] if response.choices else None

        blocks: list[AssistantBlock] = []
        stop_reason = StopReason.OTHER
        stop_sequence: str | None = None

        if choice:
            if choice.message.content:
                blocks.append(TextBlock(text=choice.message.content))

            if choice.message.tool_calls:
                for tc in choice.message.tool_calls:
                    if not isinstance(tc, ChatCompletionMessageFunctionToolCall):
                        continue
                    blocks.append(
                        ToolUseBlock(
                            id=tc.id,
                            name=tc.function.name,
                            input=json.loads(tc.function.arguments),
                        )
                    )

            match choice.finish_reason:
                case "stop":
                    stop_reason = StopReason.END_TURN
                case "length":
                    stop_reason = StopReason.MAX_TOKENS
                case "tool_calls":
                    stop_reason = StopReason.TOOL_USE
                case _:
                    stop_reason = StopReason.OTHER

        usage = cls.__convert_usage(response.usage, model) if response.usage else None

        return LLMResponse(
            message=AssistantMessage(blocks=blocks),
            stop_reason=stop_reason,
            stop_sequence=stop_sequence,
            usage=usage,
        )

    @classmethod
    def __convert_usage(cls, usage_obj: CompletionUsage, model: str) -> Usage:
        cache_read = 0
        if usage_obj.prompt_tokens_details and usage_obj.prompt_tokens_details.cached_tokens:
            cache_read = usage_obj.prompt_tokens_details.cached_tokens

        input_tokens = max(0, usage_obj.prompt_tokens - cache_read)

        raw = usage_obj.model_dump(mode="json")
        extra: dict[str, Any] = {k: v for k, v in raw.items() if k not in cls.__USAGE_KNOWN_FIELDS and v is not None}

        pd = usage_obj.prompt_tokens_details
        if pd and pd.audio_tokens:
            extra["prompt_audio_tokens"] = pd.audio_tokens

        cd = usage_obj.completion_tokens_details
        if cd:
            if cd.reasoning_tokens:
                extra["reasoning_tokens"] = cd.reasoning_tokens
            if cd.audio_tokens:
                extra["completion_audio_tokens"] = cd.audio_tokens

        return Usage(
            input_tokens=input_tokens,
            output_tokens=usage_obj.completion_tokens,
            cache_read_input_tokens=cache_read,
            cost_usd=openai_pricing.estimate_cost(
                model=model,
                input_tokens=input_tokens,
                output_tokens=usage_obj.completion_tokens,
                cache_read_tokens=cache_read,
            ),
            extra=extra,
        )

    @classmethod
    def __make_schema_strict(cls, schema: dict[str, Any]) -> dict[str, Any]:
        """Transform JSON schema to OpenAI strict mode requirements.

        OpenAI strict mode requires:
        1. All objects must have "additionalProperties": false
        2. All properties must be in "required" array
        3. Optional fields use anyOf with null type
        """
        return cls.__process_schema_node(schema)

    @staticmethod
    def __strip_ref_extras(item: dict[str, Any]) -> dict[str, Any]:
        if "$ref" in item:
            extra_keys = {"default", "description", "title"}
            if any(k in item for k in extra_keys):
                return {k: v for k, v in item.items() if k not in extra_keys}
        return item

    @classmethod
    def __process_schema_property(cls, prop_schema: dict[str, Any], is_required: bool) -> dict[str, Any]:
        if "$ref" in prop_schema:
            clean = cls.__strip_ref_extras(prop_schema)
            if not is_required:
                return {"anyOf": [clean, {"type": "null"}]}
            return clean

        if "anyOf" in prop_schema:
            items: list[dict[str, Any]] = []
            has_null = False
            for item in prop_schema["anyOf"]:
                if item.get("type") == "null":
                    has_null = True
                else:
                    clean = cls.__strip_ref_extras(item) if "$ref" in item else cls.__process_schema_node(item)
                    items.append(clean)

            if (not is_required and not has_null) or has_null:
                items.append({"type": "null"})

            result = {**prop_schema, "anyOf": items}
            if is_required and "default" in result:
                result = {k: v for k, v in result.items() if k != "default"}
            return result

        result = cls.__process_schema_node(prop_schema)

        if not is_required and "type" in result:
            prop_type = result["type"]
            if isinstance(prop_type, str) and prop_type != "null":
                type_keys = {"type", "items", "properties", "required", "additionalProperties", "enum"}
                metadata = {k: v for k, v in result.items() if k not in type_keys}
                type_schema = {k: v for k, v in result.items() if k in type_keys}
                result = {**metadata, "anyOf": [type_schema, {"type": "null"}]}
            elif isinstance(prop_type, list) and "null" not in prop_type:
                type_keys = {"type", "items", "properties", "required", "additionalProperties", "enum"}
                metadata = {k: v for k, v in result.items() if k not in type_keys}
                type_schema = {k: v for k, v in result.items() if k in type_keys}
                type_schema["type"] = prop_type[0] if len(prop_type) == 1 else prop_type
                result = {**metadata, "anyOf": [type_schema, {"type": "null"}]}

        if is_required and "default" in result:
            result = {k: v for k, v in result.items() if k != "default"}

        return result

    @classmethod
    def __process_schema_node(cls, obj: Any) -> Any:
        if not isinstance(obj, dict):
            return obj

        if "$ref" in obj:
            return obj

        result: dict[str, Any] = {}
        for key, value in obj.items():
            if key == "$defs":
                result[key] = {name: cls.__process_schema_node(defn) for name, defn in value.items()}
            elif key == "properties" and isinstance(value, dict):
                current_required = set(obj.get("required", []))
                result[key] = {
                    name: cls.__process_schema_property(prop, name in current_required) for name, prop in value.items()
                }
            elif key == "items" and isinstance(value, dict):
                result[key] = cls.__process_schema_node(value)
            elif key == "anyOf" and isinstance(value, list):
                result[key] = [cls.__process_schema_node(item) if isinstance(item, dict) else item for item in value]
            elif isinstance(value, dict):
                result[key] = cls.__process_schema_node(value)
            elif isinstance(value, list):
                result[key] = [cls.__process_schema_node(item) if isinstance(item, dict) else item for item in value]
            else:
                result[key] = value

        if "properties" in result:
            result["additionalProperties"] = False
            result["required"] = sorted(result["properties"].keys())
            if "type" not in result:
                result["type"] = "object"
            for prop_name, prop_schema in result["properties"].items():
                if isinstance(prop_schema, dict) and "default" in prop_schema:
                    result["properties"][prop_name] = {k: v for k, v in prop_schema.items() if k != "default"}
        elif result.get("type") == "object":
            result["additionalProperties"] = False
            if "properties" not in result:
                result["properties"] = {}
            if "required" not in result:
                result["required"] = []

        return result
