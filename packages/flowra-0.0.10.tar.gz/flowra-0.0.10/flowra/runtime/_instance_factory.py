from typing import Any

from ..agent import AgentDefinition, AgentInstance, AgentStore, ServiceLocator
from ..agent.compile import collect_dataclass_types
from .runtime_scope import RuntimeScope

__all__ = ["create_instance_sealed"]


class _SealedScope(AgentStore, ServiceLocator):
    __slots__ = ("__scope", "__sealed")

    def __init__(self, scope: RuntimeScope) -> None:
        self.__scope = scope
        self.__sealed = False

    def seal(self) -> None:
        self.__sealed = True

    def slot(self, cls: Any, key: str) -> Any:
        if self.__sealed:
            raise RuntimeError("slot() can only be called during agent construction")
        return self.__scope.slot(cls, key)

    def _do_provide(self, service_type: type, instance: Any) -> None:
        if self.__sealed:
            raise RuntimeError("provide() can only be called during agent construction")
        self.__scope.provide(service_type, instance)

    async def flush(self) -> None:
        await self.__scope.flush()

    @property
    def services(self) -> dict[type, Any]:
        return self.__scope.services


def create_instance_sealed(
    defn: AgentDefinition,
    scope: RuntimeScope,
    services: dict[type, Any],
    agent_spec: Any | None = None,
) -> AgentInstance:
    sealed = _SealedScope(scope)
    for st, inst in services.items():
        if st not in (AgentStore, ServiceLocator):
            scope.provide(st, inst)
    scope.provide(AgentStore, sealed)
    scope.provide(ServiceLocator, sealed)
    instance = defn.create_instance(sealed, agent_spec)
    sealed.seal()

    # Merge slot value types into the type registry
    for value_type in scope.get_slot_value_types().values():
        collect_dataclass_types(value_type, defn.type_registry)

    return instance
