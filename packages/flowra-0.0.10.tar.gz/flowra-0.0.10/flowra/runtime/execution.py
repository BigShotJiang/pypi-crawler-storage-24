import dataclasses
import enum
from typing import Any

from ..agent import AgentDefinition, AgentInstance, CallAgent, CallStep, SpawnNode, WhenAll, WhenAny, WhenN
from .interrupt import InterruptTokenSource
from .runtime_scope import RuntimeScope

__all__ = [
    "CollectedResult",
    "ExecutionNode",
    "ExecutionStatus",
    "SpawnTreeAll",
    "SpawnTreeAny",
    "SpawnTreeLeaf",
    "SpawnTreeN",
    "SpawnTreeNode",
    "build_spawn_tree",
    "deserialize_spawn_tree",
    "serialize_spawn_tree",
]


class ExecutionStatus(enum.StrEnum):
    PENDING_STEP = "pending_step"
    WAITING_CHILDREN = "waiting_children"
    COMPLETED = "completed"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CollectedResult:
    agent_name: str
    result: Any
    tag: str | None = None


# Not frozen — node is mutated during execution tree walk
@dataclasses.dataclass(slots=True, kw_only=True)
class ExecutionNode:
    node_id: str
    storage_key: str | None
    agent_name: str
    defn: AgentDefinition
    instance: AgentInstance
    scope: RuntimeScope
    status: ExecutionStatus

    pending_step: str | None = None
    pending_spec: Any | None = None
    children: "list[ExecutionNode] | None" = None
    child_results: list[CollectedResult] | None = None
    then_step: str | None = None
    result: Any | None = None
    goto_counter: int = 0
    parent: "ExecutionNode | None" = None
    tag: str | None = None
    agent_spec: Any | None = None
    interrupt_source: InterruptTokenSource | None = None
    spawn_tree: "SpawnTreeNode | None" = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeLeaf:
    child_index: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeAll:
    nodes: tuple["SpawnTreeNode", ...]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeAny:
    nodes: tuple["SpawnTreeNode", ...]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeN:
    nodes: tuple["SpawnTreeNode", ...]
    n: int


type SpawnTreeNode = SpawnTreeLeaf | SpawnTreeAll | SpawnTreeAny | SpawnTreeN


def build_spawn_tree(node: SpawnNode, index_counter: list[int]) -> SpawnTreeNode:
    match node:
        case CallStep() | CallAgent():
            idx = index_counter[0]
            index_counter[0] += 1
            return SpawnTreeLeaf(child_index=idx)
        case WhenAll(nodes=nodes):
            return SpawnTreeAll(nodes=tuple(build_spawn_tree(node, index_counter) for node in nodes))
        case WhenAny(nodes=nodes):
            return SpawnTreeAny(nodes=tuple(build_spawn_tree(node, index_counter) for node in nodes))
        case WhenN(nodes=nodes, n=n):
            return SpawnTreeN(nodes=tuple(build_spawn_tree(node, index_counter) for node in nodes), n=n)


def serialize_spawn_tree(tree: SpawnTreeNode) -> dict[str, Any]:
    match tree:
        case SpawnTreeLeaf(child_index=idx):
            return {"type": "leaf", "child_index": idx}
        case SpawnTreeAll(nodes=nodes):
            return {"type": "all", "nodes": [serialize_spawn_tree(n) for n in nodes]}
        case SpawnTreeAny(nodes=nodes):
            return {"type": "any", "nodes": [serialize_spawn_tree(n) for n in nodes]}
        case SpawnTreeN(nodes=nodes, n=n):
            return {"type": "n", "nodes": [serialize_spawn_tree(nd) for nd in nodes], "n": n}


def deserialize_spawn_tree(data: dict[str, Any]) -> SpawnTreeNode:
    match data["type"]:
        case "leaf":
            return SpawnTreeLeaf(child_index=data["child_index"])
        case "all":
            return SpawnTreeAll(nodes=tuple(deserialize_spawn_tree(n) for n in data["nodes"]))
        case "any":
            return SpawnTreeAny(nodes=tuple(deserialize_spawn_tree(n) for n in data["nodes"]))
        case "n":
            return SpawnTreeN(nodes=tuple(deserialize_spawn_tree(nd) for nd in data["nodes"]), n=data["n"])
        case _:
            msg = f"Unknown spawn tree type: {data['type']!r}"
            raise TypeError(msg)
