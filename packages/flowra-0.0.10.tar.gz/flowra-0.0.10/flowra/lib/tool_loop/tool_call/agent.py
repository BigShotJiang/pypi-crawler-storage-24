import dataclasses
import json
from typing import Annotated, Any

import marshmallow_recipe as mr

from ....agent import (
    Agent,
    AgentStore,
    CallAgent,
    InterruptedError,
    InterruptToken,
    Scalar,
    ServiceLocator,
    Spawn,
    step,
    step_arg,
)
from ....llm import ToolResultBlock, ToolUseBlock
from ....tools import ToolRegistry
from ..config import matches_tool_filter
from .context import ToolCallAgentContext

__all__ = [
    "ToolCallAgent",
    "ToolCallResult",
    "ToolCallSpec",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolCallSpec:
    tool_use: ToolUseBlock
    allowed_tools: set[str] | None = None
    denied_tools: set[str] | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolCallResult:
    tool_use: ToolUseBlock
    result: ToolResultBlock


class ToolCallAgent(Agent[ToolCallSpec, ToolCallResult]):
    """Executes a single tool call and returns the result.

    Checks for interrupt before execution and catches ``Interrupted``
    raised by the tool itself. In both cases returns an error result
    instead of propagating the exception.

    If the tool calls context.call_agent(), spawns the requested agent
    and returns its result as a ToolResultBlock.
    """

    __slots__ = ("__interrupt", "__registry", "__services", "__tool_use")

    def __init__(
        self,
        store: AgentStore,
        services: ServiceLocator,
        registry: ToolRegistry,
        interrupt: InterruptToken,
    ) -> None:
        self.__tool_use = store.slot(Scalar[ToolUseBlock], "tool_use")
        self.__services = services
        self.__registry = registry
        self.__interrupt = interrupt

    @step("execute", entry=True)
    async def execute(self, spec: ToolCallSpec) -> ToolCallResult | Spawn:
        tool_use = spec.tool_use

        if self.__interrupt.interrupted:
            return self.__error_result(tool_use, "Tool execution interrupted")

        is_denied = spec.allowed_tools is not None and not matches_tool_filter(tool_use.name, spec.allowed_tools)
        is_denied = is_denied or (
            spec.denied_tools is not None and matches_tool_filter(tool_use.name, spec.denied_tools)
        )
        if is_denied:
            return self.__error_result(tool_use, f"Unknown tool: {tool_use.name}")

        ctx = ToolCallAgentContext()
        services = {**self.__services.services, ToolCallAgentContext: ctx}

        try:
            execution_result = await self.__registry.execute(tool_use.name, tool_use.input, services=services)
        except InterruptedError:
            return self.__error_result(tool_use, "Tool execution interrupted")

        call_request = ctx.get_call_agent_request()
        if call_request is not None:
            agent_ref, agent_spec = call_request
            self.__tool_use.set(spec.tool_use)
            return Spawn(
                children=[CallAgent(agent=agent_ref, spec=agent_spec)],
                then=self.collect_agent_result,
            )

        result = ToolResultBlock(
            tool_use_id=tool_use.id,
            content=execution_result.content,
            is_error=execution_result.is_error,
        )
        return ToolCallResult(tool_use=tool_use, result=result)

    @step("collect_agent_result")
    async def collect_agent_result(self, agent_result: Annotated[Any, step_arg.CHILD]) -> ToolCallResult:
        tool_use = self.__tool_use.get()
        content = json.dumps(mr.dump(agent_result))
        result = ToolResultBlock(
            tool_use_id=tool_use.id,
            content=content,
        )
        return ToolCallResult(tool_use=tool_use, result=result)

    @staticmethod
    def __error_result(tool_use: ToolUseBlock, content: str) -> ToolCallResult:
        return ToolCallResult(
            tool_use=tool_use,
            result=ToolResultBlock(
                tool_use_id=tool_use.id,
                content=content,
                is_error=True,
            ),
        )
