# NOT frozen — consistent with ToolLoopAgent hook events.
# All current events are observation-only.

import dataclasses

from ...llm import LLMRequest, LLMResponse

__all__ = [
    "AfterLLMCallEvent",
    "BeforeLLMCallEvent",
    "TextDeltaEvent",
    "ThinkingDeltaEvent",
]


@dataclasses.dataclass(slots=True, kw_only=True)
class BeforeLLMCallEvent:
    """Emitted before the LLM request.

    Observation-only — use for logging or metrics.
    """

    request: LLMRequest


@dataclasses.dataclass(slots=True, kw_only=True)
class AfterLLMCallEvent:
    """Emitted after the LLM response is received.

    Observation-only — use for logging, cost tracking, or metrics.
    """

    request: LLMRequest
    response: LLMResponse


@dataclasses.dataclass(slots=True, kw_only=True)
class TextDeltaEvent:
    """Emitted during streaming for each text chunk.

    Observation-only — use for real-time text display.
    Registering a handler enables streaming mode automatically.
    """

    text: str


@dataclasses.dataclass(slots=True, kw_only=True)
class ThinkingDeltaEvent:
    """Emitted during streaming for each thinking chunk.

    Observation-only — use for real-time thinking display.
    Registering a handler enables streaming mode automatically.
    """

    text: str
