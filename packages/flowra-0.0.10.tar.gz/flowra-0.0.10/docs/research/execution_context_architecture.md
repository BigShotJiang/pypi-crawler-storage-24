# ExecutionContext Architecture

## Current Design: Per-node HookRegistry via `with_context()`

### How it works

1. **Runtime** creates a root `HookRegistry` (without context) and passes it as a service.
   Users register handlers on this root registry before `runtime.run()`.

2. **Engine creates a node** (`__create_node`, `__create_child_node`, or `GotoStep`/`GotoAgent`
   with a new scope). At this point it:
   - Builds `AgentInfo` from the node's agent name and its `AgentDefinition`
     (registration hierarchy: name, path, source_type, parent chain from path segments).
   - Builds the execution stack by walking `node.parent` up to root — each ancestor
     becomes an `ExecutionFrame(agent=..., spec=..., tag=...)`.
   - Assembles `ExecutionContext(frame=current_frame, stack=(*parent_frames, current_frame))`.
   - Calls `root_hooks.with_context(context)` → creates a **new `HookRegistry`** that
     shares the parent's handler lists (shallow copy) but stamps its own context.
   - Replaces `HookRegistry` in the node's `merged` services dict with this per-node copy.

3. **Agent receives** the per-node `HookRegistry` via constructor DI (`hooks: HookRegistry`).

4. **On emit**: `hooks.emit(MyEvent(...))` wraps data in `Event(data=..., context=self.__context)`.
   The context was baked in at node creation time — no dynamic lookup at emit time.

### Key properties

- **Static context**: context is determined once when the node is created, not on every emit.
- **Shallow copy of handlers**: `with_context()` copies handler lists at snapshot time.
  Handlers registered on the parent registry *after* child node creation are **not** visible
  to the child. Handlers registered *before* are visible.
- **N registries**: each execution node gets its own `HookRegistry` instance. For a tree of
  N nodes, there are N+1 registry instances (root + one per node).
- **Shared handler identity**: because handlers are copied (not referenced), a handler added
  to the root registry is present in all child registries created after that registration —
  but each child has its own list object. Mutations to the list (adding more handlers) are
  not shared across siblings.

### Injection points in engine

Context is injected at every point where a new agent instance is created:

| Location | When |
|----------|------|
| `__create_node()` | Root node or `CallAgent` child |
| `__create_child_node()` (CallStep branch) | `CallStep` child within same agent |
| `__apply_result()` → `GotoStep` with `NEW_SCOPE` | Same agent, new scope |
| `__apply_result()` → `GotoAgent` | Different agent, always new scope |

### Diagram

```
root HookRegistry (no context, handlers=[h1, h2])
  │
  ├─ with_context(ctx_A) → HookRegistry_A (context=ctx_A, handlers=[h1, h2])  ← agent A
  │     │
  │     └─ with_context(ctx_B) → HookRegistry_B (context=ctx_B, handlers=[h1, h2])  ← agent B (child of A)
  │
  └─ with_context(ctx_C) → HookRegistry_C (context=ctx_C, handlers=[h1, h2])  ← agent C
```

When agent B calls `hooks.emit(MyEvent(...))`:
- Event is wrapped as `Event(data=MyEvent(...), context=ctx_B)`
- Handlers h1 and h2 both fire with `event.context == ctx_B`

### Open questions

See TODO items below.
