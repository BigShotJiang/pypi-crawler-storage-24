# TODO

## State

- **`FORK` storage key for explicit forking.** Currently `CallStep` always forks state into a
  new scope, which is surprising — a child step logically runs inside the same agent, so you'd
  expect it to share state by default. Add a `FORK` sentinel (alongside `NEW_SCOPE`) that
  explicitly requests a forked copy of the parent's state. Then change `CallStep` default to
  run on the same scope (no fork), and require `storage_key=FORK` when isolation is needed.
  `NEW_SCOPE` creates a fresh empty scope (as now); `FORK` copies the parent's scope;
  no `storage_key` means shared state. This makes the forking behavior opt-in and visible.

- **Lazy fork / copy-on-write scope.** Currently `RuntimeScope.fork()` copies all scalars
  and append-only lists eagerly. For large state this is expensive. Make it lazy: child
  reads from parent until first write, copies only the specific field on `set()`/`append()`.
  User contract stays the same — child sees a snapshot of parent state at spawn time,
  but the implementation avoids upfront copying.
- **Frozen list.** Immutable list in state (like Scalar, but for lists). Can be created
  cheaply from `append_only` (slice without copying) or from another frozen list. Useful
  when a child agent needs a snapshot of the parent's list.


## Hooks

- **Revisit ExecutionContext architecture.** Current design: per-node `HookRegistry` via
  `with_context()` — context is baked at node creation time, each node gets its own registry
  copy. Description: [`docs/research/execution_context_architecture.md`](research/execution_context_architecture.md).
  Open questions:
  - Is this architecture acceptable overall?
  - Can we keep a single `HookRegistry` and inject context dynamically at `emit()` time
    (e.g. via `contextvars.ContextVar` or an explicit parameter) instead of creating N
    registry copies? This would simplify the model and eliminate the handler snapshot problem.

- **Reintroduce `HookProvider` abstraction.** Removed during review (was unused Protocol).
  When implementing concrete hook packages (guardrails, OTel), decide on the shape:
  Protocol vs ABC, `register_hooks(registry)` vs declarative, composability patterns.

- **Guardrails hooks package.** Ready-made hook set for content filtering and PII protection.
  Input guardrail (`UserMessageEvent`) checks/blocks user messages, output guardrail
  (`ResultMessageEvent`) checks/redacts LLM responses. Hooks support modification —
  e.g. replace `messages` in `UserMessageEvent`, replace `result` in `AfterToolCallEvent`.
  Need integration with a moderation backend (Bedrock Guardrails, OpenAI Moderation API,
  or custom). Two modes: blocking and notify-only (shadow/logging).

- **OpenTelemetry hooks package.** Provide a ready-made set of hooks that emit OTel spans
  for LLM calls, tool calls, and agent iterations. All hook points already exist
  (`BeforeLLMCallEvent`/`AfterLLMCallEvent`, `BeforeToolCallEvent`/`AfterToolCallEvent`,
  `StartIterationEvent`). Implementation is straightforward — register handlers
  that open/close OTel spans in matching event pairs.


## Capabilities (dynamic modes)

- **Capability packs — dynamically loadable modes.** A `Capability` bundles a system prompt
  fragment, a set of tools, and optionally an LLM config override. Capabilities can be
  activated/deactivated during the agent's tool loop (by the agent itself via a special tool,
  or programmatically via `ToolLoopAgentContext`). On each iteration, `ToolLoopAgent` assembles
  the active set: merges system prompts from all active capabilities, unions their tool sets,
  applies LLM config overrides. Similar to how Claude Code switches between planning/coding/etc.
  Building blocks already exist (`ConfigValue` callables, `allowed_tools`/`denied_tools`,
  `on_start_iteration`, `ToolLoopAgentContext`), but there's no unified abstraction tying
  them together. A capability could also carry hooks (e.g. a "verbose" capability that adds
  logging hooks when activated). Pairs well with composable hooks.



## Agent-as-tool

- **Verify union-in-dataclass spec for agent tools.** The docs (`docs/lib.md`, "Agents as tools")
  claim that polymorphic input can be achieved by wrapping a union in a dataclass
  (`class AnimalSpec: animal: Dog | Cat`). Need to check the full chain:
  - Does `marshmallow_recipe` generate a correct JSON schema for `Dog | Cat` union field?
    What does the schema look like — `oneOf`/`anyOf`? Or does it fail entirely?
  - How does this schema land in `Tool.input_schema` and ultimately in the LLM request?
    LLM APIs typically expect `"type": "object"` — nested `oneOf`/`anyOf` may confuse the model.
  - Does the LLM actually produce valid JSON that deserializes back through `mr.load()`?
    Round-trip: schema → LLM output → deserialization → correct `Dog` or `Cat` instance.
  - If the schema is technically valid but LLM-unfriendly (deep nesting, discriminator fields),
    the docs recommendation is misleading even if the code works.
  - If this doesn't work well — remove the recommendation from docs, document the actual
    limitation, and consider alternatives (e.g. separate tools per variant, or a string
    discriminator + flat fields).


## Documentation

- **Improve Hooks documentation in `docs/agent.md`.** The current Hooks section is superficial:
  - `HookProvider` is mentioned in the `HookRegistry.add()` table row but never explained —
    what it is, how to create one, when to use it instead of individual `on()` calls.
  - `propagate_to(target, *, only, exclude)` is in the table with no explanation of what
    `only`/`exclude` accept or what "forwarding events" means in practice. No example.
  - No example of defining a custom event dataclass and emitting it.
  - Overall the section reads as a dry API reference table. It should explain the lifecycle:
    when events are emitted, how handlers receive them, how `Event[T]` wrapping works,
    and how to compose hooks across agent hierarchies via `propagate_to`.

- **Documentation benchmark suite.** A series of tasks given to a coding agent that has access
  only to documentation (no source code). Each task is a self-contained challenge: write a
  race agent (two LLMs, first wins via WhenAny + timeout), build a fan-out/fan-in pipeline,
  create a tool with service injection, wire up hooks with ExecutionContext, etc. For each task
  we define: the prompt, the documentation provided, and the expected outcome (working code
  that passes a test or matches a reference implementation). Run the suite, compare results
  against reference, identify where the agent struggles — those are doc gaps or API ergonomics
  issues. Fix docs/API, re-run, track improvement. This is a systematic, repeatable way to
  measure documentation quality and API usability from the perspective of a new user.

- **Multi-agent patterns cookbook.** Add a doc (e.g. `docs/patterns.md`) with recipes showing
  how to implement common multi-agent patterns using existing primitives (`@step`, `GotoStep`,
  `GotoAgent`, `Spawn`, `CallAgent`). Patterns to cover: router (classify → delegate), pipeline (A → B → C),
  fan-out/fan-in (parallel workers + collector), feedback loop (writer ↔ reviewer with
  iteration limit). Each recipe should include a minimal code example. This replaces the need
  for a dedicated Graph/Workflow DSL — our state machine already covers these cases.


- **Local LLM usage guide.** Document how to use `OpenAIProvider` with local LLM servers
  (Ollama, LM Studio, vLLM). Show `base_url` configuration, recommend models for tool calling,
  and note any quirks (e.g. some models don't support tools well). A dedicated `OllamaProvider`
  is likely unnecessary — the OpenAI-compatible API covers chat, streaming, and tool calling.


## Voice

- **Voice demo (streaming pipeline).** Example `voice_chat.py` — STT (microphone) → agent →
  `on_text_delta` → TTS (speaker). Leverages existing streaming infrastructure. Start with
  simple pipeline, explore STT options: Google Cloud Speech-to-Text (available in GCP),
  OpenAI Whisper API, or local `faster-whisper` for free experimentation.

- **Smart voice pipeline with context-aware re-recognition.** For domain-specific scenarios
  (e.g. payments in Anna Money): STT produces multiple hypotheses with confidence scores.
  Agent receives all variants as structured input ("user said via voice, variants: ...").
  Agent uses domain context (frequent recipients, recent transactions) to select the best
  variant. If uncertain — requests re-recognition with hints (e.g. "typical recipients:
  Маша, Петя, Сбербанк"), STT re-processes the same audio with boosted vocabulary.
  Ties into capabilities (recognize topic → load relevant capability with context),
  agent-as-tool (STT as a callable sub-agent), and hooks (`on_user_message` enriches
  voice input with domain context).


## Integration

- **A2A (Agent-to-Agent) protocol support.** Add `flowra/a2a/` top-level package with optional
  dependency (`flowra[a2a]`) that exposes any Flowra agent as an A2A-compatible HTTP server.
  Thin adapter: takes an agent, publishes Agent Card, accepts messages over HTTP, supports
  streaming via SSE. Allows Flowra agents to participate in the broader A2A ecosystem
  (interop with Strands, LangChain, and other A2A-compatible frameworks).


## Internal providers

- **Anna LLM Proxy provider.** Create a separate private repository (`anna-flowra` or similar)
  with `LLMProxyProvider` for Anna's internal LLM Proxy service. Published to Nexus, not PyPI.
  Depends on `flowra` as a public dependency. Keeps the public flowra repo clean of
  internal/proprietary integrations.


## Services


- **Per-child service overrides.** Currently `ServiceLocator.provide()` sets a service for
  all descendants. There is no way to provide different services to different children spawned
  by the same agent. For example, if an agent spawns two LLM workers that need different
  `LLMConfig`, the only option is to pass the config via spec and have the child call
  `sl.provide()` in its own constructor. Consider a mechanism for scoped service overrides
  at spawn time — e.g. `CallAgent(agent=Worker, spec=..., services={LLMConfig: config_a})`.


## Naming

- **Disambiguate `tag` across the codebase.** The word "tag" is now overloaded with different
  meanings: `CallAgent.tag` / `CallStep.tag` (spawn child disambiguation for `step_arg.CHILD`),
  `ExecutionFrame.tag` (execution context metadata), serialization type tags, and potentially
  others. This causes confusion when reading code — it's unclear which "tag" is meant. Audit
  all usages and rename to explicit names (e.g. `child_tag`, `execution_tag`, `type_tag`)
  so each meaning is immediately obvious from the name.

- **Internal vs public visibility in namespace modules.** Modules like `step_arg` and
  `agent_arg` are exported as user-facing namespaces (`step_arg.SPEC`, `step_arg.CHILD`).
  Any module-level name is visible in IDE autocomplete, even if not in `__all__`. Currently
  `Child` (implementation detail of `CHILD`) leaks into autocomplete. Need a convention for
  hiding internal names from namespace modules while keeping them accessible to sibling
  modules. Options: `_` prefix (ugly in cross-module access), moving internals to a separate
  private module, or accepting the leak.

- **Rethink `lib` package naming and placement.** `flowra/lib/` contains `ChatAgent`,
  `ToolLoopAgent`, `LLMCallAgent` — likely the main entry points for most users. The name
  `lib` is vague (everything in a library is "lib"), but alternatives have their own problems:
  - `prebuilt` — communicates "ready-made components on top of primitives" (LangGraph uses it),
    but frames these agents as secondary/auxiliary, when in reality they're the primary API
    for most users.
  - Promote to top-level `flowra` — `from flowra import ChatAgent, ToolLoopAgent`. Makes the
    main use case a single import. `flowra.agent` becomes the low-level primitive layer for
    people building custom agents. Risk: blurs the boundary between core and composed.
  - Keep `lib` — neutral, doesn't mislead, doesn't help either.
  Decision deferred until usage patterns stabilize.


## Runtime refactoring

- **Split `AgentRuntime` class.** `runtime.py` (~350 lines) combines public API orchestration,
  tree snapshot/restore serialization (~130 lines), and type-registry management. The class
  is too large. Extract snapshot/restore logic and/or type-registry bookkeeping into separate
  modules to improve readability and testability.

- **Move spawn-tree satisfaction logic out of `Engine`.** `engine.py` has ~80 lines of private
  methods that evaluate spawn-tree strategies, but they operate purely on `SpawnTreeNode` types
  from `execution.py`. Move them as free functions to `execution.py` for better cohesion.


## Hook events naming

- **Disambiguate identically-named hook event classes.** `BeforeLLMCallEvent`,
  `AfterLLMCallEvent`, `TextDeltaEvent`, `ThinkingDeltaEvent` exist in both
  `llm_call/hook_events.py` and `tool_loop/hook_events.py` as separate types with different
  fields. Users working with both agents can easily import the wrong one. Consider a namespace
  approach (similar to `step_arg`/`agent_arg` binding markers) — e.g. `tool_loop_hooks.BeforeLLMCallEvent`
  vs `llm_call_hooks.BeforeLLMCallEvent`, or rename one set to be more specific.


## Serialization

- **Custom string tags for serialized types.** Currently the serialization tag is always
  `cls.__qualname__`, which is fragile — renaming or moving a class breaks deserialization of
  persisted state. Should allow explicit string tags, e.g. via a decorator (`@type_tag("my_spec")`)
  or a class attribute (`__type_tag__ = "my_spec"`), falling back to `__qualname__` if not set.
  This also decouples the persistence format from Python naming, making refactoring safer.


