# Package `flowra.llm`

Provider-agnostic abstraction for calling LLMs. Defines a unified request/response interface,
message and block types, and tool definitions.

- **Messages** — `SystemMessage`, `UserMessage`, `AssistantMessage` with content blocks
- **Blocks** — `TextBlock`, `ImageBlock`, `ToolUseBlock`, `ToolResultBlock`, `ThinkingBlock`
- **`LLMRequest` / `LLMResponse`** — unified request/response with tools, JSON schema, and usage tracking
- **`LLMProvider`** — abstract interface with `call()` and `stream()` methods
- **Providers** — `AnthropicVertexProvider`, `OpenAIProvider`, `GoogleVertexProvider`
- **Pricing** — per-provider cost estimation with cache-aware token accounting

## Quick start

```python
from flowra.llm import LLMRequest, TextBlock, UserMessage
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

provider = AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
)

response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Hello!")])],
        max_tokens=256,
    )
)

# response.message — AssistantMessage with blocks
for block in response.message.blocks:
    if isinstance(block, TextBlock):
        print(block.text)
```

## Blocks

Blocks are atomic content units inside messages. Every block has two common fields:

- **`cache: bool`** (default `False`) — prompt caching hint. When `True`, the provider
  marks the element for server-side caching, reducing cost and latency on repeated calls.
  Higher-level layers (from the [`lib` package](lib.md)) set this automatically — you
  typically don't need to set it manually.
- **`metadata: dict[str, Any]`** (default `{}`) — arbitrary key-value pairs for application
  use. **Not sent to the LLM** — the provider strips metadata when building API requests.
  Useful for marking blocks as transient, tracking internal state, or filtering messages
  in storage.
- **`extra: dict[str, Any]`** (default `{}`) — provider-specific data passed through as-is.
  Unlike `metadata`, providers may read and write `extra`. For example, `GoogleVertexProvider`
  stores `thought_signature` here when thinking mode is enabled — this signature must be
  preserved across turns for correct reasoning continuity.

### `TextBlock`

Text block. Used in all message types.

```python
TextBlock(text="Hello, world!")
TextBlock(text="System prompt", cache=True)  # enable prompt caching
```

| Field      | Type             | Default | Description                         |
|------------|------------------|---------|-------------------------------------|
| `text`     | `str`            | —       | Text content                        |
| `cache`    | `bool`           | `False` | Prompt caching hint                 |
| `metadata` | `dict[str, Any]` | `{}`    | Optional metadata (not sent to LLM) |
| `extra`    | `dict[str, Any]` | `{}`    | Provider-specific pass-through data |

### `ImageBlock`

Binary image data.

```python
ImageBlock(data=image_bytes, media_type="image/png")
```

| Field        | Type             | Default | Description                               |
|--------------|------------------|---------|-------------------------------------------|
| `data`       | `bytes`          | —       | Binary image data                         |
| `media_type` | `str`            | —       | MIME type (`"image/png"`, `"image/jpeg"`) |
| `cache`      | `bool`           | `False` | Prompt caching hint                       |
| `metadata`   | `dict[str, Any]` | `{}`    | Optional metadata (not sent to LLM)       |
| `extra`      | `dict[str, Any]` | `{}`    | Provider-specific pass-through data       |

### `ToolUseBlock`

Tool call request from the LLM. Received in provider responses.

```python
# Usually not created manually — comes from AssistantMessage via LLM
ToolUseBlock(id="toolu_123", name="calculate", input={"expression": "2+2"})
```

| Field      | Type             | Default | Description                         |
|------------|------------------|---------|-------------------------------------|
| `id`       | `str`            | —       | Unique call ID                      |
| `name`     | `str`            | —       | Tool name                           |
| `input`    | `dict[str, Any]` | —       | Call parameters                     |
| `cache`    | `bool`           | `False` | Prompt caching hint                 |
| `metadata` | `dict[str, Any]` | `{}`    | Optional metadata (not sent to LLM) |
| `extra`    | `dict[str, Any]` | `{}`    | Provider-specific pass-through data |

### `ToolResultBlock`

Tool execution result. Sent back to the LLM.

```python
ToolResultBlock(tool_use_id="toolu_123", content="4")
ToolResultBlock(tool_use_id="toolu_123", content="Division by zero", is_error=True)
```

| Field         | Type             | Default | Description                          |
|---------------|------------------|---------|--------------------------------------|
| `tool_use_id` | `str`            | —       | ID of the corresponding ToolUseBlock |
| `content`     | `str`            | —       | Result (text)                        |
| `is_error`    | `bool`           | `False` | Whether the result is an error       |
| `cache`       | `bool`           | `False` | Prompt caching hint                  |
| `metadata`    | `dict[str, Any]` | `{}`    | Optional metadata (not sent to LLM)  |
| `extra`       | `dict[str, Any]` | `{}`    | Provider-specific pass-through data  |

### `ThinkingBlock`

Thinking/reasoning content from the LLM. Produced by models that support extended
thinking (e.g. Anthropic Claude with `thinking_budget_tokens`, Google Gemini with
thinking enabled). `AnthropicVertexProvider` strips thinking blocks when sending
history back. `GoogleVertexProvider` sends them back (Gemini requires the full
response including thinking parts in subsequent turns).

```python
# Usually not created manually — comes from AssistantMessage via LLM
ThinkingBlock(text="Let me reason about this...")
```

| Field      | Type             | Default | Description                         |
|------------|------------------|---------|-------------------------------------|
| `text`     | `str`            | —       | Thinking/reasoning text             |
| `cache`    | `bool`           | `False` | Prompt caching hint                 |
| `metadata` | `dict[str, Any]` | `{}`    | Optional metadata (not sent to LLM) |
| `extra`    | `dict[str, Any]` | `{}`    | Provider-specific pass-through data |

## Messages

Three message types, each containing a list of typed blocks.

### `SystemMessage`

System prompt. Must be at the beginning of the messages list. Multiple consecutive
`SystemMessage` objects are allowed. Accepts only `TextBlock` blocks (not images or
tool results):

```python
SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])

# With prompt caching
SystemMessage(blocks=[
    TextBlock(text="Long instructions...", cache=True),
])
```

### `UserMessage`

User message. Can contain text, images, and tool results.

```python
# Text
UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")])

# Text + image
UserMessage(blocks=[
    TextBlock(text="What's in this picture?"),
    ImageBlock(data=png_bytes, media_type="image/png"),
])

# Tool result
UserMessage(blocks=[
    ToolResultBlock(tool_use_id="toolu_123", content="15°C, cloudy"),
])
```

### `AssistantMessage`

LLM response. Contains text and/or tool call requests.

```python
# Usually not created manually — comes from LLMResponse
AssistantMessage(blocks=[TextBlock(text="The weather in Paris: 15°C")])
```

### Union types

These restrict which block types are valid in each message type:

```python
type UserBlock = TextBlock | ImageBlock | ToolResultBlock
type AssistantBlock = TextBlock | ToolUseBlock | ThinkingBlock
type Message = SystemMessage | UserMessage | AssistantMessage
```

## Tools

### `Tool`

Tool definition passed to the LLM.

```python
Tool(
    name="get_weather",
    description="Get current weather for a city.",
    input_schema={
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "City name"},
        },
        "required": ["city"],
    },
    output_schema={
        "type": "object",
        "properties": {
            "temperature": {"type": "number"},
            "condition": {"type": "string"},
        },
    },
)
```

| Field           | Type                     | Default | Description                                                                                                         |
|-----------------|--------------------------|---------|---------------------------------------------------------------------------------------------------------------------|
| `name`          | `str`                    | —       | Tool name                                                                                                           |
| `description`   | `str`                    | —       | Description for the LLM                                                                                             |
| `input_schema`  | `dict[str, Any] \| None` | `None`  | JSON Schema for parameters (`None` = no parameters). Not validated by the provider — passed directly to the LLM API |
| `output_schema` | `dict[str, Any] \| None` | `None`  | JSON Schema describing the tool's return value. Purely informational — not used for validation                      |
| `cache`         | `bool`                   | `False` | Prompt caching hint                                                                                                 |
| `metadata`      | `dict[str, Any]`         | `{}`    | Optional metadata (not sent to LLM)                                                                                 |

No LLM API supports tool output schemas natively. Providers use `output_schema` to give the
LLM context about what to expect in `ToolResultBlock.content` — typically by formatting it
as human-readable text and appending to the tool's `description`.

## Request and response

### `LLMRequest`

```python
LLMRequest(
    model="claude-sonnet-4-5@20250929",
    messages=[
        SystemMessage(blocks=[TextBlock(text="You are a calculator.")]),
        UserMessage(blocks=[TextBlock(text="What is 2+2?")]),
    ],
    tools=[calculator_tool],       # optional
    json_schema=my_schema,         # optional — see provider sections below
    temperature=0.0,               # optional
    max_tokens=1024,               # optional
    stop_sequences=["STOP"],       # optional
    max_schema_retries=3,          # optional — retries on schema validation failure
    additional_config={},          # optional — provider-specific configuration
)
```

| Field                | Type                       | Default | Description                                                         |
|----------------------|----------------------------|---------|---------------------------------------------------------------------|
| `model`              | `str`                      | —       | Model identifier                                                    |
| `messages`           | `list[Message]`            | —       | Message list                                                        |
| `tools`              | `list[Tool] \| None`       | `None`  | Available tools                                                     |
| `json_schema`        | `dict[str, Any] \| None`   | `None`  | JSON Schema for structured output                                   |
| `temperature`        | `float \| None`            | `None`  | Generation temperature                                              |
| `max_tokens`         | `int \| None`              | `None`  | Maximum tokens in response                                          |
| `stop_sequences`     | `list[str] \| None`        | `None`  | Stop sequences — model stops when it generates any of these strings |
| `max_schema_retries` | `int`                      | `3`     | Max retries on schema validation failure                            |
| `additional_config`  | `dict[str, Any]`           | `{}`    | Provider-specific configuration (see individual provider sections)  |

### `LLMResponse`

| Field            | Type                  | Default | Description                                |
|------------------|-----------------------|---------|--------------------------------------------|
| `message`        | `AssistantMessage`    | —       | LLM response message                       |
| `stop_reason`    | `StopReason`          | —       | Why the model stopped generating           |
| `stop_sequence`  | `str \| None`         | `None`  | Which stop sequence was triggered (if any) |
| `usage`          | `Usage \| None`       | `None`  | Token usage metrics                        |

```python
response = await provider.call(request)
response.message        # AssistantMessage
response.stop_reason    # StopReason
response.stop_sequence  # str | None — which stop sequence was triggered
response.usage          # Usage | None — token usage metrics
```

### `StopReason`

```python
class StopReason(StrEnum):
    END_TURN                 = "end_turn"                  # model finished response
    MAX_TOKENS               = "max_tokens"                # token limit reached
    TOOL_USE                 = "tool_use"                  # model wants to call a tool
    STOP_SEQUENCE            = "stop_sequence"             # stop sequence triggered
    SCHEMA_VALIDATION_FAILED = "schema_validation_failed"  # json_schema validation failed after retries
    OTHER                    = "other"                     # provider-specific or unknown stop reason
```

### `Usage`

Typed token usage metrics with cost estimation and cache breakdown.

**Token contract:** each token is counted in exactly one category.
`input_tokens` does **not** include cached tokens — those go into
`cache_read_input_tokens` and `cache_creation_input_tokens`.

```python
response.usage.input_tokens                   # int — excludes cached tokens
response.usage.output_tokens                  # int
response.usage.cache_read_input_tokens        # int (default 0)
response.usage.cache_creation_input_tokens    # int (default 0)
response.usage.cost_usd                       # float | None — estimated cost in USD
response.usage.extra                          # dict[str, Any] — provider-specific fields
```

`cost_usd` is estimated automatically by built-in providers using the `pricing` module.
For unknown models (not in the pricing table), `cost_usd` is `None`. Custom providers
may compute it using the same pricing utilities (see [Pricing](#pricing)).

`Usage` supports `+` for summing across retries or multi-step calls — all fields
including `cost_usd` are summed (if either side is `None`, the non-`None` value is kept).
Note that `response.usage` can be `None` — always check before using:

```python
if response.usage is not None:
    total = total + response.usage
```

## Provider

### `LLMProvider`

Abstract base class for calling an LLM. Defines `call()` (abstract) and `stream()`
(optional, with a default fallback):

```python
class LLMProvider(abc.ABC):
    @abc.abstractmethod
    async def call(self, request: LLMRequest) -> LLMResponse: ...

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        response = await self.call(request)
        yield ContentComplete(response=response)
```

The provider is responsible for converting `LLMRequest` into the target API's format,
calling the API, and converting the response back to `LLMResponse`. If `json_schema`
is set, the provider should also handle validation and retries (see
[Structured output](#structured-output-json-schema)).

#### Streaming

`stream()` returns an `AsyncIterator[StreamEvent]` that yields incremental events
as the LLM generates its response. The default implementation calls `call()` and
yields a single `ContentComplete` event — providers override this for real-time streaming.

**Stream events:**

| Event             | Fields              | Description                              |
|-------------------|---------------------|------------------------------------------|
| `TextDelta`       | `text: str`         | Incremental text content                 |
| `ThinkingDelta`   | `text: str`         | Incremental thinking/reasoning content   |
| `ContentComplete` | `response: LLMResponse` | Always last — full response          |

`ContentComplete` is always the final event and contains the same `LLMResponse` you
would get from `call()`.

```python
async for event in provider.stream(request):
    match event:
        case TextDelta(text=text):
            print(text, end="", flush=True)
        case ThinkingDelta(text=text):
            print(f"[thinking] {text}", end="")
        case ContentComplete(response=response):
            print()  # newline after streaming
            # response.message, response.usage, etc. are available here
```

All three built-in providers implement `stream()` with real-time `TextDelta` events.
`ThinkingDelta` is only emitted by `AnthropicVertexProvider` and `GoogleVertexProvider`
(when thinking mode is enabled) — `OpenAIProvider` does not emit thinking events.
`AnthropicVertexProvider` falls back to non-streaming when `json_schema` is set
(the retry loop requires full responses).

### `AnthropicVertexProvider`

Implementation for Claude via Vertex AI.

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

# Pass required credentials
provider = AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
)

# Or pass a pre-configured client
from anthropic import AsyncAnthropicVertex
provider = AnthropicVertexProvider(client=my_anthropic_client)
```

**Constructor parameters** — either `client` or all of `project`/`location`/`credentials`
must be provided (`ValueError` if neither):

| Parameter     | Description                                                                                                 |
|---------------|-------------------------------------------------------------------------------------------------------------|
| `client`      | Pre-configured `AsyncAnthropicVertex` instance                                                              |
| `project`     | GCP project ID                                                                                              |
| `location`    | Region (e.g. `"us-east5"`)                                                                                  |
| `credentials` | Base64-encoded service account JSON (`base64 -i keyfile.json` on macOS, `base64 -w0 keyfile.json` on Linux) |

The service account must have the `cloud-platform` OAuth scope.

**`max_tokens` default:** When `max_tokens` is `None`, uses a default of 4096.

**`cache=True` handling:** translates to `cache_control: {"type": "ephemeral"}` on the
element. Anthropic's API supports up to 4 cached elements per request; extra `cache=True`
flags are still sent but the API ignores them beyond the limit.

#### System message handling

`SystemMessage` objects must be at the beginning of the messages list — `ValueError` is
raised if a `SystemMessage` appears after a non-system message. Multiple consecutive
`SystemMessage` objects are merged into a single system prompt. When any block has
`cache=True`, block boundaries are preserved (as separate content parts); otherwise,
blocks are joined into a single string with `"\n\n"`.

#### Tool name validation

Tool names are validated against `^[a-zA-Z0-9_-]{1,128}$` — `ValueError` is raised
at call time if the name does not match.

#### Structured output (JSON schema)

Use `json_schema` when you need the LLM to return data in a specific structure —
e.g., extracting entities, generating structured reports, or returning typed results
to your application. Without `json_schema`, you'd need to parse free-form text yourself
and handle formatting inconsistencies.

Claude does not support structured output natively, so `AnthropicVertexProvider`
implements it via prompt injection and validation:

1. Includes the schema in the system prompt (formatted by `format_schema_for_llm`)
2. Calls the LLM
3. Extracts JSON from the response `TextBlock` (stripping markdown code fences if present)
4. Validates against the schema using `jsonschema.validate()`
5. On validation failure, retries up to `max_schema_retries` times — the
   validation error message is sent back to the LLM so it can fix the issue
6. If all retries fail, returns `stop_reason=StopReason.SCHEMA_VALIDATION_FAILED`

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Three European capitals")])],
        json_schema={
            "type": "object",
            "properties": {
                "cities": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["cities"],
        },
        max_tokens=256,
        max_schema_retries=3,  # default
    )
)
if response.stop_reason == StopReason.SCHEMA_VALIDATION_FAILED:
    # response.message still contains the last (invalid) LLM response.
    # Options: log the error, fall back to free-form text, or raise.
    raw_text = response.message.blocks[0].text
    raise ValueError(f"Schema validation failed. Raw response: {raw_text}")
```

#### Schema utilities (`schema_formatting.py`)

`format_schema_for_llm` converts a JSON Schema into a human-readable plain-text format
for embedding in LLM prompts. Handles `$ref` resolution, `allOf`, `anyOf`, enums, default values,
and array-style `type` (e.g. `{"type": ["string", "null"]}` is normalized to `anyOf`).

Notation: `field*` = required, `field?` = optional, `// text` = field description.

```python
from flowra.llm.schema_formatting import format_schema_for_llm

schema = {
    "type": "object",
    "properties": {
        "name": {"type": "string", "description": "User name"},
        "age": {"type": "integer"},
    },
    "required": ["name"],
}

print(format_schema_for_llm(schema))
# {
#   name*: string // User name
#   age?: integer
# }
```

`format_output_schema_for_description` wraps the formatted schema in an
`"Output structure:\n..."` block. Used internally by all providers to append
`Tool.output_schema` to the tool's description.

#### Schema validation (`schema_validation.py`)

`validate_json_schema(text, schema)` strips markdown code fences, parses JSON, and
validates against the schema. Returns `(error, cleaned_text)` tuple — `error` is `None`
on success (and `cleaned_text` contains the fence-stripped JSON), or an error description
when validation fails. Used internally by `AnthropicVertexProvider` for structured output
retries. When validation succeeds, the provider returns a single `TextBlock` with the
cleaned JSON (no markdown fences, no thinking blocks).

`strip_markdown_code_block(text)` removes surrounding markdown code fences
(`` ```...``` ``). Used internally by `validate_json_schema`, but also available
for direct use.

#### `AnthropicVertexAdditionalConfig`

Provider-specific configuration passed via `LLMRequest.additional_config`:

| Field                   | Type           | Default | Description                                     |
|-------------------------|----------------|---------|-------------------------------------------------|
| `thinking_budget_tokens` | `int \| None` | `None`  | Token budget for extended thinking (enables thinking mode) |

When `thinking_budget_tokens` is set, the provider passes `thinking: {"type": "enabled",
"budget_tokens": N}` to the API and forces `temperature=1` (Anthropic requirement for
thinking mode). The response will contain `ThinkingBlock` blocks with the model's
chain-of-thought reasoning.

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexAdditionalConfig

response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Solve this step by step...")])],
        max_tokens=8192,
        additional_config={"thinking_budget_tokens": 4000},
    )
)

# response.message.blocks may contain ThinkingBlock + TextBlock
for block in response.message.blocks:
    if isinstance(block, ThinkingBlock):
        print(f"[thinking] {block.text}")
    elif isinstance(block, TextBlock):
        print(block.text)
```

**Note:** Streaming + `json_schema` is not supported with Anthropic — `stream()` falls
back to non-streaming in that case.

### `OpenAIProvider`

Implementation for OpenAI-compatible APIs (OpenAI, Inception AI, etc.).

```python
from flowra.llm.providers.openai import OpenAIProvider

# Pass API key
provider = OpenAIProvider(
    api_key="sk-...",
    base_url="https://api.openai.com/v1",       # optional
    organization="org-...",                       # optional
)

# Inception AI example
provider = OpenAIProvider(
    api_key="sk_...",
    base_url="https://api.inceptionlabs.ai/v1",
)

# Or pass a pre-configured client
from openai import AsyncOpenAI
provider = OpenAIProvider(client=my_openai_client)
```

**Constructor parameters** — either `client` or `api_key` must be provided
(`ValueError` if neither):

| Parameter      | Required | Description                           |
|----------------|----------|---------------------------------------|
| `client`       | no       | Pre-configured `AsyncOpenAI` instance |
| `api_key`      | no       | API key                               |
| `base_url`     | no       | Base URL for API requests             |
| `organization` | no       | Organization ID                       |

**`max_tokens` default:** When `max_tokens` is `None`, uses a default of 4096.

**Structured output:** Uses OpenAI's native `response_format` with `json_schema` type
and `strict: True`. The schema is automatically adapted to OpenAI strict mode requirements
(all objects get `additionalProperties: false`, all properties become required, optional
fields use `anyOf` with null type).

### `GoogleVertexProvider`

Implementation for Google Gemini models via Vertex AI.

```python
from flowra.llm.providers.google_vertex import GoogleVertexProvider

# Pass required credentials
provider = GoogleVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
)

# Or pass a pre-configured client
from google import genai
provider = GoogleVertexProvider(client=my_genai_client)
```

**Constructor parameters** — either `client` or all of `project`/`location`/`credentials`
must be provided (`ValueError` if neither):

| Parameter     | Description                                                                                                 |
|---------------|-------------------------------------------------------------------------------------------------------------|
| `client`      | Pre-configured `genai.Client` instance                                                                      |
| `project`     | GCP project ID                                                                                              |
| `location`    | Region (e.g. `"us-east5"`)                                                                                  |
| `credentials` | Base64-encoded service account JSON (`base64 -i keyfile.json` on macOS, `base64 -w0 keyfile.json` on Linux) |

**`max_tokens` default:** When `max_tokens` is `None`, uses a default of 4096.

**System message handling:** Same as `AnthropicVertexProvider` — `SystemMessage` objects
must be at the beginning of the messages list (`ValueError` otherwise). Multiple
consecutive `SystemMessage` objects are merged into a single system instruction.

**Structured output:** Uses Gemini's native `response_schema` with `response_mime_type:
"application/json"`. The schema is automatically adapted (flattens `$ref`/`$defs`,
removes `additionalProperties`, converts type arrays to `anyOf`).

#### `GoogleVertexAdditionalConfig`

Provider-specific configuration passed via `LLMRequest.additional_config`:

| Field              | Type                                | Default | Description                                                    |
|--------------------|-------------------------------------|---------|----------------------------------------------------------------|
| `thinking_level`   | `genai_types.ThinkingLevel \| None` | `None`  | Thinking level (MINIMAL, LOW, MEDIUM, HIGH) — for Gemini 3     |
| `thinking_budget`  | `int \| None`                       | `None`  | Token budget for thinking — for Gemini 2.5 (min 128 for Pro)   |

Either field (or both) enables thinking mode. `thinking_level` controls reasoning
depth for Gemini 3 models. `thinking_budget` sets a token budget for Gemini 2.5
models (setting to 0 disables thinking on Flash; minimum 128 on Pro).

```python
from flowra.llm.providers.google_vertex import GoogleVertexAdditionalConfig

# Gemini 3 — thinking level
response = await provider.call(
    LLMRequest(
        model="gemini-3-pro-preview",
        messages=[UserMessage(blocks=[TextBlock(text="Solve this step by step...")])],
        max_tokens=4096,
        additional_config={"thinking_level": "medium"},
    )
)

# Gemini 2.5 — thinking budget
response = await provider.call(
    LLMRequest(
        model="gemini-2.5-pro",
        messages=[UserMessage(blocks=[TextBlock(text="Solve this step by step...")])],
        max_tokens=4096,
        additional_config={"thinking_budget": 4096},
    )
)
```

### Adding a new provider

Inherit from `LLMProvider` and implement `call()`:

```python
from flowra.llm import LLMProvider, LLMRequest, LLMResponse

class MyProvider(LLMProvider):
    async def call(self, request: LLMRequest) -> LLMResponse:
        # Convert request.messages to your API format
        # Call the API
        # Convert response to LLMResponse
        ...
```

Then pass the provider instance to `AgentRuntime` (from the `runtime` package) via services:

```python
from flowra.runtime import AgentRuntime

runtime = AgentRuntime(
    agents=...,
    services={LLMProvider: MyProvider()},
)
```

## Examples

### Simple call

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Capital of France?")])],
        max_tokens=64,
    )
)
print(response.message.blocks[0].text)  # "Paris"
```

### System prompt + prompt caching

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[
            SystemMessage(blocks=[
                TextBlock(text="Long instructions...", cache=True),
            ]),
            UserMessage(blocks=[TextBlock(text="Question")]),
        ],
        max_tokens=1024,
    )
)
```

### Tool use (full cycle)

```python
weather_tool = Tool(
    name="get_weather",
    description="Current weather for a city.",
    input_schema={
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
)

# 1. Send request with tool
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Weather in Paris?")])],
        tools=[weather_tool],
        max_tokens=256,
    )
)
# response.stop_reason == StopReason.TOOL_USE

# 2. Extract tool call
tool_use = next(b for b in response.message.blocks if isinstance(b, ToolUseBlock))
# tool_use.name == "get_weather"
# tool_use.input == {"city": "Paris"}

# 3. Execute tool and return result
result = get_weather(tool_use.input["city"])  # your logic
# If the tool fails:
# ToolResultBlock(tool_use_id=tool_use.id, content="Error: city not found", is_error=True)

response2 = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[
            UserMessage(blocks=[TextBlock(text="Weather in Paris?")]),
            response.message,  # AssistantMessage with ToolUseBlock
            UserMessage(blocks=[
                ToolResultBlock(tool_use_id=tool_use.id, content=result),
            ]),
        ],
        tools=[weather_tool],
        max_tokens=256,
    )
)
# response2 contains the final text response
```

### Usage metrics

```python
response = await provider.call(request)
if response.usage is not None:
    print(f"Input: {response.usage.input_tokens}")
    print(f"Output: {response.usage.output_tokens}")
    print(f"Cache read: {response.usage.cache_read_input_tokens}")
    print(f"Cache created: {response.usage.cache_creation_input_tokens}")
    print(f"Cost: ${response.usage.cost_usd}")  # None if model not in pricing table
```

## Pricing

The `pricing` subpackage provides cost estimation for known models. Each module covers
one API protocol — the pricing algorithm depends on the protocol, not the model vendor.

| Module               | Covers                                               |
|----------------------|------------------------------------------------------|
| `pricing.anthropic`  | Anthropic Claude (with separate 5m/1h cache pricing) |
| `pricing.openai`     | OpenAI + OpenAI-compatible (Mercury, etc.)           |
| `pricing.google`     | Google Gemini                                        |

Built-in providers use these automatically. Custom providers can too:

```python
from flowra.llm.pricing import anthropic as anthropic_pricing

cost = anthropic_pricing.estimate_cost(
    model="claude-sonnet-4-5",
    input_tokens=1000,
    output_tokens=500,
    cache_read_tokens=200,
    cache_creation_5m_tokens=0,
    cache_creation_1h_tokens=0,
)
```

Each `estimate_cost` function returns `float | None` — `None` if the model name
is not in the pricing table. Model matching is by longest substring match.

Each protocol has its own `estimate_cost` signature matching the provider's token
breakdown. For example, `pricing.openai.estimate_cost` takes `input_tokens`,
`output_tokens`, `cache_read_tokens` (no cache creation — it's free), while
`pricing.anthropic` additionally splits cache creation into 5-minute and 1-hour buckets.
