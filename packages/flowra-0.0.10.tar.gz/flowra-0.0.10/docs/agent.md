# Package `flowra.agent`

Define agents as step-based state machines with mandatory contracts. Each agent is a Python class
parameterized with `Agent[S, R]` (spec and result types), whose methods (decorated with `@step`)
form the states; returning `GotoStep`, `GotoAgent`, `Spawn`, or a result dataclass
controls transitions between them.

- **Agent[S, R]** and **@step** — define agents as state machines with typed spec/result contracts
- **Control flow** — `GotoStep`, `GotoAgent`, `Spawn` with combinators (`WhenAll`, `WhenAny`, `WhenN`), `timeout`
- **State management** — `Scalar[T]`, `AppendOnlyList[T]` via `AgentStore` with dirty tracking and persistence
- **Services** — `ServiceLocator` for typed dependency injection between agents
- **Cooperative interrupts** — `InterruptToken`, `Interrupted`, `with_interrupt` for cancellation
- **Hooks** — `HookRegistry`, `Event[T]`, `ExecutionContext` for typed lifecycle events
- **Dependency injection** — constructor and step parameter injection with `agent_arg` / `step_arg` markers

## Quick start

```python
from dataclasses import dataclass
from flowra.agent import Agent, step

@dataclass
class GreetSpec:
    name: str

@dataclass
class GreetResult:
    greeting: str

class Greeter(Agent[GreetSpec, GreetResult]):
    def __init__(self, spec: GreetSpec) -> None:
        self.spec = spec

    @step(entry=True)
    async def greet(self) -> GreetResult:
        return GreetResult(greeting=f"Hello, {self.spec.name}!")
```

This defines a single-step agent. `GreetSpec` is the input (`S`), `GreetResult` is the output (`R`).
The agent spec is received in the constructor by type matching and stored as a field.
Every `Agent[S, R]` subclass **must** have exactly one `@step(entry=True)` method — the entry point.
Returning a result dataclass completes the agent. To execute agents, use `runtime`:

```python
from flowra.runtime import AgentRuntime

runtime = AgentRuntime(agents={"greeter": Greeter})
result = await runtime.run(agent=Greeter, spec=GreetSpec(name="World"))
print(result.greeting)  # "Hello, World!"
```

## Defining agents

### `Agent[S, R]`

Generic base class for agent implementations. `S` is the spec type (input), `R` is the result
type (output). When you subclass `Agent[S, R]`, the framework automatically scans
`@step`-decorated methods and prepares the agent for execution.

**Mandatory contract:**
1. Must have exactly one `@step(entry=True)` method
2. If parameterized (`Agent[MySpec, MyResult]`), the agent spec is received in the constructor
   by type matching. If the entry step also declares a spec parameter, its type must match `S`

Parameterization is optional — `class MyAgent(Agent):` is valid. When omitted,
the compiler infers `S` from the entry step's spec parameter and `R` as the union
of result types across all steps.

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, spec: MySpec, store: AgentStore) -> None:
        self.spec = spec
        # AgentStore and Scalar are explained in "State management" below
        self.counter = store.slot(Scalar[int], "counter")

    @step(entry=True)
    async def start(self) -> GotoStep:
        self.counter.set(self.counter.get(0) + 1)
        return GotoStep(step="process", spec=ProcessSpec(data=self.spec.value))

    @step
    async def process(self, spec: ProcessSpec) -> MyResult:
        return MyResult(answer=spec.data)
```

The agent spec (`S`) is received in the constructor by type matching — the runtime injects it
automatically when instantiating the agent. Store it in a field to use across all steps.
The spec is **not** a service — it does not propagate to child agents. Each child receives
its own spec (from its `CallAgent.spec`). Nullable spec params (`spec: MySpec | None = None`)
receive `None` when no spec is provided.

Subclasses inherit steps from parents (Method Resolution Order). A child can override a step
by defining a new method with the same `@step` tag — the match is by tag string,
not by method name.

### Agents without spec or result

Use `None` for agents that don't need input or output:

```python
class WorkerAgent(Agent[None, WorkerResult]):
    @step(entry=True)
    async def run(self) -> WorkerResult: ...

class FireAndForget(Agent[TaskSpec, None]):
    @step(entry=True)
    async def execute(self, spec: TaskSpec) -> None: ...
```

## Steps and the `@step` decorator

A **step** is a method that represents one state of the agent's state machine.
Steps can be either synchronous (`def`) or asynchronous (`async def`).
The runtime calls steps one at a time: it invokes a step, receives its return value,
and uses that to decide what to do next (transition to another step, spawn children,
or complete the agent).

### `@step`

Marks a method as an agent step.

A **tag** is the string name that identifies a step. It is used for persistence, control-flow
references (`GotoStep`, `CallStep`), and step overriding. By default, the tag is the method name:

```python
@step                          # tag = method name ("process")
async def process(self) -> MyResult: ...

@step("custom_tag")            # tag = "custom_tag"
def process(self) -> MyResult: ...

@step()                        # tag = method name ("process")
async def process(self) -> MyResult: ...

@step("start", entry=True)    # tag = "start", entry point
async def start(self, spec: MySpec) -> GotoStep: ...
```

The `entry=True` parameter marks the single entry point of an `Agent[S, R]` subclass.
Exactly one step per agent must be marked as entry. The entry step's spec type must match
the agent's generic `S` parameter.

If a step's return type annotation contains a concrete type that is not
a dataclass and not `GotoStep | GotoAgent | Spawn | None`, a `TypeError` is raised at class
definition time. PEP 695 type aliases (`type X = A | B`) are resolved automatically,
including nested aliases.

### Dataclass-only constraint

All step parameters and return types (other than action types and `None`) **must be dataclasses**.
This is required for serialization — the runtime persists agent state across steps, and dataclasses
provide the structured metadata needed for reliable serialize/deserialize round-trips.
The compiler validates this at class definition time and raises `TypeError` for non-dataclass types.

```python
# GOOD — dataclass types:
@step(entry=True)
async def run(self, spec: UserInput) -> GreetResult: ...

# BAD — str is not a dataclass, raises TypeError:
@step(entry=True)
async def run(self, spec: UserInput) -> str: ...
```

## Control flow

Steps return one of: `GotoStep`, `GotoAgent`, `Spawn`, a result dataclass, or `None`.

- **`GotoStep`** — transition to another step within the same agent
- **`GotoAgent`** — transition to a different agent (the current agent ends)
- **`Spawn`** — fork multiple children to run in parallel, then reconvene at a join step
- **Result dataclass** — complete the agent and return a result to the caller
- **`None`** — complete the agent with no result

**Storage scopes.** Each agent execution has a **storage key** — an identifier for its
isolated set of stored values (`Scalar`, `AppendOnlyList` — defined in [State management](#state-management)).
`GotoStep`, `GotoAgent`, `CallStep`, and `CallAgent` accept an optional `storage_key`
to control which storage the target uses.

### `GotoStep`

Transition to another step within the same agent.

| Field         | Type                       | Default |
|---------------|----------------------------|---------|
| `step`        | `str`                      | —       |
| `spec`        | `Any \| None`              | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None` | `None`  |

The constructor accepts `StepRef` (`str | StepMethod`) for `step` — you can pass
either a tag string or a method reference (resolved to its tag automatically).

```python
# By tag string:
GotoStep(step="process")

# By method reference:
GotoStep(step=self.process)

# With spec:
GotoStep(step="process", spec=ProcessSpec(data="hello"))

# Fresh storage:
GotoStep(step=self.reset, storage_key=NEW_SCOPE)
```

**`storage_key`** controls which persistent state the target step uses
(see [State management](#state-management) for details on stored values).
Each unique key corresponds to an isolated set of stored values.
When the runtime starts a step with a given storage key, it loads the
stored values from persistent storage for that key:

| `storage_key` value | Behavior                 |
|---------------------|--------------------------|
| `None` (default)    | Keep current storage     |
| `"explicit"`        | Switch to that key       |
| `NEW_SCOPE`         | Auto-generate unique key |

`NEW_SCOPE` is a sentinel value that forces a fresh storage scope.

### `GotoAgent`

Transition to a different agent. The current agent ends, and the target agent starts
from its entry step.

| Field         | Type                         | Default |
|---------------|------------------------------|---------|
| `agent`       | `str \| type[AbstractAgent]` | —       |
| `spec`        | `Any \| None`                | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`   | `None`  |

```python
# By type:
GotoAgent(agent=OtherAgent, spec=OtherSpec(data="hello"))

# By name:
GotoAgent(agent="other", spec=OtherSpec(data="hello"))

# With explicit storage key:
GotoAgent(agent=OtherAgent, storage_key="calc")
```

Agents are always black boxes — `GotoAgent` enters the target through its `entry_step`,
not an arbitrary step.

### `Spawn`

Fork child agents, then reconvene at a join step.

Constructor accepts `StepRef` for `then` — tag string or method reference (same as `GotoStep.step`).

**Basic form** — positional children, all must complete (implicit `WhenAll`):

```python
@step
async def dispatch(self) -> Spawn:
    return Spawn(
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1)),
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=2)),
        then=self.collect,
    )

@step
async def collect(self, results: list[WorkerResult]) -> MyResult:
    total = sum(r.value for r in results)
    return MyResult(total=total)
```

**Keyword form** — equivalent, uses `children=` list:

```python
Spawn(
    children=[
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1)),
        CallAgent(agent=WorkerAgent, spec=TaskSpec(id=2)),
    ],
    then=self.collect,
)
```

**Combinator form** — partial completion with `WhenAny`, `WhenN`, or nested trees:

```python
Spawn(
    WhenAny(
        CallAgent(agent="worker", tag="worker"),
        timeout(seconds=30),
    ),
    then=self.join,
)
```

When the spawn tree is satisfied, unneeded children are cooperatively interrupted
(their `InterruptToken` is set). Interrupted children return `Interrupted()` as their
result — the join step can detect this via nullable parameters
(see [Step parameter injection](#step-parameter-injection) below).

### `WhenAll` / `WhenAny` / `WhenN`

Combinators that control when a `Spawn` is considered satisfied:

| Combinator           | Satisfied when                            | Unsatisfied children |
|----------------------|-------------------------------------------|----------------------|
| `WhenAll(*nodes)`    | All nodes complete with real results      | —                    |
| `WhenAny(*nodes)`    | Any one node completes with a real result | Interrupted          |
| `WhenN(*nodes, n=k)` | `k` nodes complete with real results      | Interrupted          |

Combinators are composable — they can be nested:

```python
# Wait for both workers, OR timeout — whichever happens first
Spawn(
    WhenAny(
        WhenAll(
            CallAgent(agent="worker", spec=TaskSpec(id=1), tag="w1"),
            CallAgent(agent="worker", spec=TaskSpec(id=2), tag="w2"),
        ),
        timeout(seconds=60),
    ),
    then=self.join,
)
```

When positional args are passed to `Spawn` without an explicit combinator,
multiple args are wrapped in `WhenAll`; a single `CallStep`/`CallAgent` is used as-is.

### `timeout`

Built-in helper that creates a child agent for time-based deadlines:

```python
from flowra.agent import timeout

# Use in Spawn — race a worker against a deadline:
Spawn(
    WhenAny(
        CallAgent(agent="worker", tag="worker"),
        timeout(seconds=30),
    ),
    then=self.join,
)
```

`timeout(seconds=..., minutes=...)` returns a `CallAgent` targeting the internal
timeout agent. When the deadline expires, the agent returns `TimeoutExpired(seconds=...)`.
If interrupted before expiry (e.g., because a sibling completed first in `WhenAny`),
it returns `Interrupted()` like any other interrupted child.

The join step binds results by type — no annotations needed when types are unambiguous:

```python
@step
async def join(
    self,
    worker: WorkerResult | None,
    expired: TimeoutExpired | None,
) -> FinalResult:
    if worker is not None:
        return FinalResult(value=worker.value)
    # timeout fired, worker was interrupted
    return FinalResult(value="timed out")
```

Use `Annotated[T, step_arg.CHILD("tag")]` only when multiple children return the same type
and you need to distinguish them by tag (see [Step parameter injection](#step-parameter-injection)).

### `CallStep` / `CallAgent`

Each child in `Spawn.children` is described by a `CallStep` (same agent) or `CallAgent`
(different agent).

**`CallStep`:**

| Field         | Type                       | Default |
|---------------|----------------------------|---------|
| `step`        | `str`                      | —       |
| `spec`        | `Any \| None`              | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None` | `None`  |
| `tag`         | `str \| None`              | `None`  |

Same as `GotoStep`: constructor accepts `StepRef` (tag string or method reference).

**`CallAgent`:**

| Field         | Type                         | Default |
|---------------|------------------------------|---------|
| `agent`       | `str \| type[AbstractAgent]` | —       |
| `spec`        | `Any \| None`                | `None`  |
| `storage_key` | `str \| NEW_SCOPE \| None`   | `None`  |
| `tag`         | `str \| None`                | `None`  |

`tag` labels a child so the join step can bind its result by tag
(see `step_arg.CHILD("tag")` in [Step parameter injection](#step-parameter-injection)).

```python
# Same agent:
CallStep(step="compute", spec=TaskSpec(id=1))
CallStep(step=self.compute, storage_key="worker-1")

# Cross-agent:
CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1))
CallAgent(agent="calc", storage_key="calc")

# With tag — bind result by tag in the join step:
CallAgent(agent=CalcAgent, spec=CalcSpec(expr="2+2"), tag="calc")
CallAgent(agent=EchoAgent, spec=EchoSpec(text="hi"), tag="echo")
```

**Child state behavior:**

| Scenario                       | State behavior                                              |
|--------------------------------|-------------------------------------------------------------|
| Same agent, no `storage_key`   | Copy of parent's state — mutations do not affect the parent |
| Same agent, with `storage_key` | Independent state — loaded from own persistent storage      |
| Different agent                | Independent state — loaded from own persistent storage      |

Same-agent children without `storage_key` get a full copy (new `Scalar`/`AppendOnlyList`
instances initialized with the parent's current values). This is useful for parallel
workers that need context from the parent but should not modify the parent's state.

## Subagents

Agents can declare internal helper agents using the `__subagents__` class variable.
Subagents are automatically registered in the runtime with namespaced names
(e.g., if the parent is `"loop"`, a subagent named `"tool_call"` becomes
`"loop/tool_call"`).

```python
class ToolCallAgent(Agent[ToolCallSpec, ToolCallResult]):
    @step(entry=True)
    async def execute(self, spec: ToolCallSpec) -> ToolCallResult:
        ...

class ToolLoopAgent(Agent[ToolLoopSpec, ToolLoopResult]):
    __subagents__ = {
        "tool_call": ToolCallAgent,
    }

    @step(entry=True)
    async def execute_tools(self, spec: ToolLoopSpec) -> Spawn:
        return Spawn(
            children=[CallAgent(agent=ToolCallAgent, spec=ToolCallSpec(...))],
            then=self.collect,
        )

    @step
    async def collect(self, result: ToolCallResult) -> ToolLoopResult:
        return ToolLoopResult(data=result.data)
```

Nested subagents work recursively (e.g., `"parent/child/grandchild"`).

`__subagents__` is inherited via Method Resolution Order: a subclass that does not redeclare it
inherits the parent's subagent map. Override with `__subagents__ = {}` to clear.

**Referencing subagents:**

```python
CallAgent(agent=ToolCallAgent)                   # by type (contextual resolution)
CallAgent(agent="./tool_call")                    # relative — my child
CallAgent(agent="../sibling")                     # relative — my sibling
CallAgent(agent="loop/tool_call")                 # absolute name
```

Note: with `CallAgent`, agents are always entered through their `entry_step` — you don't
specify which step to call.

**Type-based resolution** walks the agent hierarchy from the current agent upward to root,
so a parent agent can reference its own subagent type without knowing its registration name.
The same class can be a subagent of multiple parents without conflict — each parent resolves
it to its own namespace.

**Relative paths** use Unix-style syntax:
- `"./child"` — my child subagent
- `"../sibling"` — sibling (go up one level, then down)
- `"../../uncle"` — go up two levels

E.g., if the current agent is `"parent/child"`, then `"./gc"` resolves to
`"parent/child/gc"` and `"../sibling"` resolves to `"parent/sibling"`.

**Name validation:** Agent names must match `[a-zA-Z0-9_-]+` (slashes are reserved for
hierarchy separators).

**One class = one name per hierarchy level.** Each agent class can only be registered once at
a given level. This is required for type-based resolution: `CallAgent(agent=WorkerAgent)` must
map to exactly one name. Registering the same class under two names (`{"a": Worker, "b": Worker}`)
raises `ValueError`.

To run multiple instances of the same agent class, register it once and call it multiple times
with different specs and tags:

```python
runtime = AgentRuntime(agents={"coord": Coordinator, "worker": WorkerAgent})

# Inside Coordinator:
Spawn(
    WhenAny(
        CallAgent(agent="worker", spec=TaskSpec(model="fast"), tag="fast"),
        CallAgent(agent="worker", spec=TaskSpec(model="slow"), tag="slow"),
    ),
    then=self.join,
)
```

## State management

Agents persist state across steps using **stored values** — mutable containers created
in the constructor via `store.slot()`. The runtime automatically saves dirty values
at step boundaries. You can also flush manually mid-step via `store.flush()`.

### Creating slots

Slots are created in the agent constructor using `AgentStore.slot()`:

```python
from flowra.agent import Agent, AgentStore, AppendOnlyList, Scalar, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        self.counter = store.slot(Scalar[int], "counter")
        self.log = store.slot(AppendOnlyList[str], "log")

    @step(entry=True)
    async def work(self, spec: MySpec) -> MyResult:
        self.counter.set(self.counter.get(0) + 1)
        self.log.append(f"step {self.counter.get()}")
        return MyResult(count=self.counter.get())
```

The first argument must be `Scalar[T]` or `AppendOnlyList[T]` — the type determines
which container is created. The second argument is the storage key used for persistence.

A new `Scalar` starts **unset** — it holds no value until explicitly set via `set()`
or `restore()`. Use `get(default)` to provide an explicit fallback for unset scalars.

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        self.counter = store.slot(Scalar[int], "counter")
        self.name = store.slot(Scalar[str], "name")
        self.config = store.slot(Scalar[dict[str, int]], "config")

    @step(entry=True)
    async def work(self, spec: MySpec) -> MyResult:
        self.counter.get(0)        # returns 0 if unset
        self.name.get("")          # returns "" if unset
        self.counter.get()         # raises LookupError if unset
```

### `AgentStore`

Interface for creating slots and flushing state. The runtime provides the implementation
and injects it into the agent's `__init__`.

| Method                                              | Description                                                   |
|-----------------------------------------------------|---------------------------------------------------------------|
| `slot(Scalar[T], key) -> Scalar[T]`                 | Create a scalar slot with dirty tracking                      |
| `slot(AppendOnlyList[T], key) -> AppendOnlyList[T]` | Create an append-only list slot                               |
| `flush()`                                           | Persist dirty state immediately, without waiting for step end |

`slot()` can only be called during `__init__` — after construction, the runtime seals
the store and further `slot()` calls raise `RuntimeError`.

### `flush()`

`flush()` persists dirty state immediately, without waiting for a step boundary.

**Caution:** after `flush()`, state is persisted but the step continues running. If the
step crashes after a flush, on resume the step will re-execute from the beginning with the
already-flushed state. The step must handle this correctly — check whether data was already
written before writing again (e.g., guard with `if not messages.get_all()` before appending).

```python
from flowra.agent import Agent, AgentStore, Scalar, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore) -> None:
        self.store = store
        self.progress = store.slot(Scalar[str], "progress")

    @step(entry=True)
    async def process(self, spec: MySpec) -> MyResult | None:
        self.progress.set("halfway")
        await self.store.flush()  # persist now, don't wait for step end
        # ... continue processing ...
```

### `Scalar[T]`

Mutable scalar with dirty tracking. Only changed values are persisted.

```python
self.counter.set(self.counter.get(0) + 1)
```

| Method                | Description                                                  |
|-----------------------|--------------------------------------------------------------|
| `get(default?) -> T`  | Value if set; `default` if provided; `LookupError` otherwise |
| `has_value() -> bool` | Whether the scalar holds a value                             |
| `set(value)`          | Set the value, mark dirty                                    |
| `is_dirty()`          | Whether the value changed since last clean                   |
| `mark_clean()`        | Reset dirty flag                                             |
| `restore(v)`          | Replace value and reset dirty flag (for persistence restore) |

### `AppendOnlyList[T]`

Append-only list with incremental persistence — only newly appended items are written
on each save.

```python
self.messages.append(new_message)
self.messages.extend([msg1, msg2])
all_messages = self.messages.get_all()
```

| Method              | Description                                                             |
|---------------------|-------------------------------------------------------------------------|
| `get_all() -> list` | All items                                                               |
| `append(item)`      | Append one item and mark as unflushed                                   |
| `extend(items)`     | Append multiple items and mark as unflushed                             |
| `get_unflushed()`   | Items appended since last clean                                         |
| `mark_clean()`      | Reset unflushed counter                                                 |
| `restore(items)`    | Replace all items and reset unflushed counter (for persistence restore) |

## Services: `ServiceLocator`

Interface for service provision and access. The runtime provides the implementation and injects
it into the agent's `__init__` (via the same DI mechanism as `AgentStore`).

"Sealed" means the method can only be called during `__init__` — after construction, the
runtime locks it and further calls raise an error. This prevents accidental mutation mid-step.

| Method / Property               | Sealed | Description                                                                 |
|---------------------------------|--------|-----------------------------------------------------------------------------|
| `provide(type[T], instance: T)` | yes    | Register a typed service for descendant agents (runtime `isinstance` check) |
| `provide(instance)`            | yes    | Same, but infers the type from `type(instance)` — shorthand for the common case |
| `services` (property)           | no     | All services available in the current scope (`dict[type, Any]`)             |

`provide()` registers a service that is propagated to all descendant agents
(children, grandchildren, etc.). The call is generic and type-safe — the runtime
verifies `isinstance(instance, service_type)` and raises `TypeError` on mismatch.
Descendants receive the service through constructor injection:

```python
# Parent registers a service:
class ParentAgent(Agent[ParentSpec, ParentResult]):
    def __init__(self, services: ServiceLocator, my_service: MyService) -> None:
        services.provide(MyService, my_service)

# Child (and grandchild) receives it automatically:
class ChildAgent(Agent[ChildSpec, ChildResult]):
    def __init__(self, my_service: MyService) -> None:
        self.service = my_service
```

Combining spec with service provision — the agent spec drives service configuration
for descendants:

```python
class Researcher(Agent[ResearchSpec, ResearchResult]):
    def __init__(self, spec: ResearchSpec, sl: ServiceLocator) -> None:
        self.spec = spec
        sl.provide(LLMConfig(model=spec.model))
```

## Cooperative interrupts: `InterruptToken`

Read-only interrupt interface inspired by .NET's `CancellationToken` / `CancellationTokenSource`
pattern. The runtime always provides `InterruptToken` — agents request it via constructor injection.

| Method / Property        | Description                                                          |
|--------------------------|----------------------------------------------------------------------|
| `interrupted` (property) | Whether interrupt was signaled                                       |
| `check()`                | Raise `InterruptedError` if the token has been interrupted           |
| `wait()`                 | Block until interrupted. Returns immediately if already interrupted. |

### `InterruptedError` exception

`InterruptedError` is the exception raised by `check()` and `with_interrupt()`. It signals that
an operation was cancelled via the interrupt mechanism.

**If a step raises `InterruptedError` (directly or via `check()` / `with_interrupt()`), the engine
catches it and the agent's result becomes `Interrupted()`.** The caller receives this as a normal
child output — see [Interrupted result type](#interrupted-result-type).

```python
from flowra.agent import Agent, InterruptToken, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def process(self, spec: MySpec) -> MyResult:
        # Raises InterruptedError if the token is set — node returns Interrupted()
        self.interrupt.check()
        # ... processing ...
        return MyResult(answer=42)
```

If an agent wants to handle interruption gracefully (e.g., return partial results),
it can catch `InterruptedError` explicitly:

```python
from flowra.agent import Agent, InterruptedError, InterruptToken, with_interrupt, step

class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, interrupt: InterruptToken) -> None:
        self.interrupt = interrupt

    @step(entry=True)
    async def process(self, spec: MySpec) -> MyResult:
        items = []
        try:
            async for item in with_interrupt(some_stream(), self.interrupt):
                items.append(item)
        except InterruptedError:
            return MyResult(items=items, partial=True)
        return MyResult(items=items, partial=False)
```

### `Interrupted` — typed result for interrupted children

When a child agent is interrupted (e.g., because a sibling won in `WhenAny`), the engine
catches `InterruptedError` and converts it into an `Interrupted` result that flows through
the execution tree as a normal value.

| Field    | Type          | Default |
|----------|---------------|---------|
| `reason` | `str \| None` | `None`  |

The join step can bind `Interrupted` results — use nullable types to detect which
children were interrupted:

```python
from flowra.agent import Interrupted

@step
async def join(
    self,
    worker: WorkerResult | None,
    interrupted: Interrupted | None,
) -> FinalResult:
    if worker is not None:
        return FinalResult(value=worker.value)
    # worker was interrupted — interrupted.reason may contain details
    return FinalResult(value="interrupted")
```

When multiple children share the same result type, use `step_arg.CHILD("tag")` to
disambiguate:

```python
@step
async def join(
    self,
    calc: Annotated[WorkerResult | None, step_arg.CHILD("calc")],
    echo: Annotated[WorkerResult | None, step_arg.CHILD("echo")],
) -> FinalResult:
    ...
```

If the join step's parameter binding fails (e.g. expected results are missing) and some
children were interrupted, the parent agent's result also becomes `Interrupted()` —
the interruption cascades up until someone handles it.

### `with_interrupt` — racing async iterators

`with_interrupt` wraps any `AsyncIterator[T]` so it raises `InterruptedError` when
the token fires — even if `__anext__()` is blocked on I/O:

```python
from flowra.agent import InterruptToken, with_interrupt

async def consume(stream: AsyncIterator[str], token: InterruptToken) -> list[str]:
    items = []
    async for item in with_interrupt(stream, token):
        items.append(item)
    return items  # only reached if stream completes without interrupt
```

On each iteration, `__anext__()` and `token.wait()` are raced via
`asyncio.wait(FIRST_COMPLETED)`. If the token wins, the underlying iterator
is closed (`aclose()`) and `InterruptedError` is raised.

**Key behaviors:**

- **Raises `InterruptedError`** when the token fires — the exception propagates up the
  call stack. Catch it explicitly if you need to handle partial results.
- **If the token is already interrupted** before iteration starts, raises `InterruptedError`
  immediately without yielding any items.
- **Exceptions from the underlying iterator** propagate normally — `with_interrupt`
  does not suppress them.
- **`aclose()` is always called** on the underlying iterator, whether the loop
  completes normally or is interrupted — cleanup is guaranteed.

## Dependency injection

### Constructor injection

When a subclass of `Agent` is compiled, its `__init__` parameters are inspected.
The runtime injects values by matching parameter type annotations:

- **Built-in services** (always available, no registration needed):

  | Service          | Purpose                                               | Sealed after construction        |
  |------------------|-------------------------------------------------------|----------------------------------|
  | `AgentStore`     | `slot()` — create slots; `flush()` — persist mid-step | `slot()` — yes; `flush()` — no   |
  | `ServiceLocator` | Register services (`provide`), access `services` dict | `provide` — yes; `services` — no |
  | `InterruptToken` | Check `interrupted`, `wait()` for cooperative stop    | — (read-only, never sealed)      |

- Other types are resolved from the runtime's `services` dict or from parent
  agents via `ServiceLocator.provide()`

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(self, store: AgentStore, services: ServiceLocator, provider: LLMProvider) -> None:
        self.counter = store.slot(Scalar[int], "counter")
        self.services = services
        self.provider = provider
```

If a parameter's type is not found in the available services and has no default value,
the behavior depends on the type annotation:
- `T | None` (nullable) — the runtime passes `None` automatically
- `T` (non-nullable, no default) — Python raises `TypeError` when the constructor is called

```python
class MyAgent(Agent[MySpec, MyResult]):
    def __init__(
        self,
        store: AgentStore,
        provider: LLMProvider,               # required — TypeError if not in services
        config: AppConfig | None,            # nullable — None if not in services
        logger: Logger | None = None,        # nullable with explicit default
    ) -> None: ...
```

**Note:** Service lookup uses exact type matching. If you register `MyService`, a
parameter typed as a superclass of `MyService` will not match — use the exact type.

**`agent_arg` markers** disambiguate constructor parameters when the same type could be
both a service and a spec. Use `Annotated[T, agent_arg.SPEC]` to force spec binding,
or `Annotated[T, agent_arg.SERVICE]` to force service lookup:

```python
from typing import Annotated
from flowra.agent import Agent, agent_arg, step

class MyAgent(Agent[AppConfig, MyResult]):
    def __init__(
        self,
        spec: Annotated[AppConfig, agent_arg.SPEC],        # always from agent spec
        service: Annotated[AppConfig, agent_arg.SERVICE],   # always from services
    ) -> None:
        self.spec = spec
        self.service = service
```

Without markers, the runtime uses implicit matching: if a parameter's type matches one of
the agent's spec types, it is bound from the spec; otherwise, from services.

### Step parameter injection

Step parameters are bound by matching their type annotations against available values.
There are two sources:

1. **Step spec** — passed via `GotoStep(spec=...)`, `CallStep(spec=...)`, or as the initial spec for an entry step
2. **Child outputs** — results from `Spawn` children, collected when all children complete

By default, the runtime checks **both sources** when binding a parameter.

**`step_arg` markers** narrow binding to a specific source. Use `Annotated[T, step_arg.SPEC]`,
`Annotated[T, step_arg.CHILD]`, or `Annotated[list[T], step_arg.CHILD]`
when there is ambiguity (i.e., the same type could match multiple sources).

| Parameter type                        | Injected value                                          |
|---------------------------------------|---------------------------------------------------------|
| `T` (dataclass)                       | First match from any source                             |
| `Annotated[T, step_arg.SPEC]`         | Step-level spec only                                    |
| `Annotated[T, step_arg.CHILD]`        | First child result matching `T`                         |
| `Annotated[T, step_arg.CHILD("tag")]` | Child result whose `CallStep`/`CallAgent` `tag` matches |
| `Annotated[list[T], step_arg.CHILD]`  | All child results matching `T` (use `list[T]` hint)     |
| `list[T]`                             | All child results matching `T` (from any source)        |
| `T \| None`                           | Match or `None` if no candidate found                   |

**Note:** Agent-level spec (`S` from `Agent[S, R]`) is NOT available in step parameters.
It is received in the constructor (see [Defining agents](#agent-s-r)).

Union types and type aliases are supported:

```python
from typing import Annotated
from flowra.agent import step_arg

type AnyWorkerResult = CalcResult | EchoResult

@step
async def join(self, spec: MySpec, results: list[WorkerResult]) -> MyResult:
    # results — all child results of type WorkerResult (from Spawn children)
    ...

@step
async def collect(self, results: list[CalcResult | EchoResult]) -> MyResult:
    # results — all child results matching CalcResult or EchoResult
    ...

@step
async def collect_alias(self, results: list[AnyWorkerResult]) -> MyResult:
    # same as above — type alias is resolved automatically
    ...
```

**Nullable parameters:** If a parameter is typed as `T | None`, the runtime passes `None`
when no matching value is found (instead of raising an error). This works for all binding
sources.

```python
@step(entry=True)
async def start(self, spec: MySpec | None) -> GotoStep:
    # spec is None if no spec was provided
    ...

@step
async def join(self, result: WorkerResult | None) -> MyResult:
    # result is None if no child produced a WorkerResult
    ...
```

## Hooks: `HookRegistry`

Typed event hook system for lifecycle events. Register handlers for event dataclasses.
Supports multiple handlers per event and sync/async transparency.

```python
from flowra.agent import HookRegistry

hooks = HookRegistry()
hooks.on(MyEvent, lambda e: print(e.data.value))
```

| Method                                      | Description                                      |
|---------------------------------------------|--------------------------------------------------|
| `on(event_type, handler, *, prepend=False)` | Register a handler for an event type             |
| `has_handlers(event_type) -> bool`          | Check if any handlers are registered             |
| `async emit(data: T) -> T`                  | Wrap data in `Event`, call handlers, return data |
| `propagate_to(target, *, only, exclude)`    | Forward events to another registry               |

Handlers receive `Event[T]` where `T` is the event dataclass. `Event` has two fields:
`data: T` (the event payload) and `context: ExecutionContext` (execution metadata stamped by emit).
Handlers can mutate fields of `event.data` (assuming the payload dataclass is not frozen) — the caller of `emit()` receives the modified data.

### `ExecutionContext`

Every emitted event carries a `ExecutionContext` that provides two navigable hierarchies:

**Execution stack** — the runtime call chain from root agent to the agent that emitted the event:

```python
@dataclass
class ExecutionContext:
    frame: ExecutionFrame        # the agent that emitted the event
    stack: tuple[ExecutionFrame, ...]  # full path from root to current (inclusive)
```

Each `ExecutionFrame` contains:

```python
@dataclass
class ExecutionFrame:
    agent: AgentInfo      # registration hierarchy node
    spec: Any | None      # the spec passed to this agent (or None)
    tag: str | None       # the tag from CallAgent (if any)
```

**Registration hierarchy** — the agent's position in the agent name tree, navigable via `AgentInfo.parent`:

```python
@dataclass
class AgentInfo:
    name: str                           # leaf name (e.g. "worker")
    path: str                           # full path (e.g. "orchestrator/worker")
    source_type: type[AbstractAgent] | None  # the agent class (if class-based)
    parent: AgentInfo | None            # parent in registration hierarchy
```

**Stack navigation helpers** — `ExecutionContext` provides methods to search the stack
from the current frame upward (nearest match first):

| Method                                   | Returns                  | On miss       |
|------------------------------------------|--------------------------|---------------|
| `find_spec(spec_type)`                   | `T \| None`              | `None`        |
| `get_spec(spec_type)`                    | `T`                      | `LookupError` |
| `find_frame(*, spec_type=, agent_type=)` | `ExecutionFrame \| None` | `None`        |
| `get_frame(*, spec_type=, agent_type=)`  | `ExecutionFrame`         | `LookupError` |

Example — identifying which model is streaming in a multi-agent setup:

```python
async def on_delta(event: Event[TextDeltaEvent]) -> None:
    # find_spec walks the stack and returns the nearest matching spec
    spec = event.context.find_spec(ResearchSpec)
    if spec is not None:
        print(f"Model: {spec.model}")

    # get_spec raises LookupError if not found
    spec = event.context.get_spec(ResearchSpec)
    print(f"Model: {spec.model}")

    # find_frame / get_frame search by spec type, agent type, or both
    frame = event.context.find_frame(agent_type=Researcher)
    if frame is not None:
        print(f"Agent: {frame.agent.path}, spec: {frame.spec}")
```

The runtime automatically stamps `ExecutionContext` on every event emitted during agent execution.
Child agents share their parent's handlers, so a handler registered on the parent will fire
for child events too — with the child's context.

### `propagate_to`

Forward events emitted on one registry to another. `source.propagate_to(target)` means
"when an event fires on `source`, re-emit it on `target`." Useful for observing child
agent events from the parent:

```python
child_hooks.propagate_to(parent_hooks)                          # forward all events
child_hooks.propagate_to(parent_hooks, only=[MyEvent])          # forward only MyEvent
child_hooks.propagate_to(parent_hooks, exclude=[NoisyEvent])    # forward all except NoisyEvent
```

`only` narrows the set to the listed types; `exclude` then removes from that set.
Both can be used together: `only=[A, B, C], exclude=[B]` forwards only `A` and `C`.

## Type aliases

Useful in step return type annotations:

```python
type StepAction = GotoStep | GotoAgent | Spawn
type StepRef = str | StepMethod
type AgentRef = str | type[AbstractAgent]
type SpawnChild = CallStep | CallAgent
type SpawnNode = SpawnChild | WhenAll | WhenAny | WhenN
```

`StepAction` groups all control-flow commands — use it when a step may return
any flow control command alongside a result:

```python
@step
async def process(self) -> StepAction | MyResult:
    if done:
        return MyResult(answer=42)
    return GotoStep(step=self.next_step)
```

