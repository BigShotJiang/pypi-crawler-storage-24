# Readability Review: flowra.tools

## First impression

The title and one-line description are clear: this package handles tool definition, grouping, registration, and execution for both local Python functions and remote MCP servers. After reading the quick start, I could write basic working code — the example shows the full lifecycle (define a tool, group it, create a registry, execute). The quick start is minimal and well-chosen; it introduces only the essentials (decorator, group, registry) without overloading the reader.

One small friction point: the quick start uses `SearchParams` as a dataclass but the reader has not yet learned that "a single dataclass parameter is treated as tool input." The inline comment `# prefix + "__" + tool name` helps, but the naming convention deserves a brief sentence before the code rather than only an inline comment.

## Flow issues

1. **`get_local_tool` and `LocalTool` appear before grouping and registry.** These are intermediate plumbing types that most users never touch directly. The quick start uses `create_local_tool_group` which hides `LocalTool` entirely. Placing `get_local_tool` / `LocalTool` / `ToolHandler` / `ToolExecutionContext` between the `@tool` decorator and the grouping section interrupts the natural "define tool -> group tools -> registry" progression. A user following the quick start pattern will skip straight to grouping and may be confused by the detour into internals.

2. **`ToolGroup` and `ToolSource` type aliases** are defined at the end of the grouping section, after all group types. This is fine logically but the note that `ToolSource` is the input type for `ToolRegistry.create()` would land better if it appeared at the start of the `ToolRegistry` section, closer to where `create()` is documented.

## Forward references

1. **`ToolExecutionContext.services`** — mentioned in the `@tool` decorator section ("injected by matching the parameter's type annotation against `ToolExecutionContext.services`") with a link to "Service injection", but `ToolExecutionContext` is not defined until several paragraphs later. A reader encountering this phrase for the first time has to jump ahead.

2. **`ToolDefinition`** — used in the quick start (`registry.get_tools()  # list[ToolDefinition]`) before the Types section defines it. Minor, since the comment makes the intent clear, but it is technically a forward reference.

3. **`flowra.llm.Tool`** — referenced in `get_llm_tools()` without any explanation of what it is or how it differs from `ToolDefinition`. A reader unfamiliar with the `flowra.llm` package has no context for this.

## Missing explanations

1. **What happens when `input_schema` or `output_schema` is `None`?** The `ToolDefinition` table shows both fields default to `None`, but the doc never explains when they would be `None` versus populated. For local tools, the decorator derives schemas from type annotations — so when would a tool have no input schema? A tool with no parameters? This deserves a brief note.

2. **How does service injection interact with MCP tools?** The service injection section is entirely framed around local tools. If a user has both local and MCP tools in the same registry, it is unclear whether `services` passed to `execute()` has any effect on MCP tool calls.

3. **Error handling behavior.** The doc says exceptions are "caught and returned as `ToolResult(content="Error: ...", is_error=True)`". It would help to know: is this all exceptions? Does it include `KeyboardInterrupt`? Is the traceback included or just the message? A user debugging a failing tool needs to know what information they get back.

4. **`marshmallow_recipe`** — mentioned as "a project dependency for dataclass to JSON Schema conversion" but no link or further context. A user who wants to understand what schema features are supported (e.g., nested dataclasses, optional fields, enums) has no guidance on where to look.

5. **MCP tool execution details.** The `McpToolGroup` section explains how to point to a server, but there is no explanation of how MCP tool execution works from the user's perspective. Does `registry.execute()` make an HTTP call? What happens if the server is down? The `McpConnection` section mentions auto-reconnect but the connection between registry-level `execute()` and the underlying connection is not made explicit.

## Example gaps

1. **No example of a tool with no parameters.** The decorator description says "a single dataclass parameter is treated as tool input" but does not show what a zero-parameter tool looks like. The `ping` example under `get_local_tool` hints at this but does not show execution.

2. **No example of `get_llm_tools()` usage.** This method bridges `flowra.tools` and `flowra.llm`, which is likely a very common operation, but there is no code showing how the returned `Tool` objects feed into an `LLMRequest`.

3. **No example of a tool returning a dataclass.** The return value serialization table mentions dataclass return types but every code example returns `str`.

4. **No example of mixing local and MCP tools in one registry.** This is arguably the central value proposition of the registry, but the quick start only uses local tools and the MCP section only shows `McpToolGroup` construction without a full registry example.

5. **No example of error handling.** The doc says errors become `ToolResult(is_error=True)` but never shows code that demonstrates this or how a caller might handle it.

## Clarity issues

1. **"services" terminology overloaded.** The word "services" is used both for the DI concept and the dictionary field name. The sentence "injected by matching the parameter's type annotation against `ToolExecutionContext.services`" is dense — it packs DI resolution, type matching, and the services dict into one clause. Breaking this into a short explanation ("The registry looks up each service parameter's type in the provided services dictionary and passes the matching instance") would be clearer.

2. **`create()` return type is confusing.** The quick start has `async with await ToolRegistry.create([group]) as registry:` with the comment "create() is async and returns an async context manager." The `await` + `async with` double-layer is unusual. A sentence explaining why both are needed (e.g., "create() is a coroutine that performs async initialization and returns an async context manager for cleanup") would prevent the reader from wondering if this is a typo.

3. **"MCP tool name conflicts are logged and skipped without raising (first registration wins)."** This is clear on its own, but the contrast with local tool behavior ("Duplicate local tool names raise `ValueError`") appears in the same sentence cluster without an explicit "In contrast..." bridge. A reader might miss that the two behave differently.

4. **Return value serialization for lists.** The table says: "`list` — `json.dumps(result)` (if the first element is a dataclass, all elements are serialized field-by-field)". The parenthetical is ambiguous: does "field-by-field" mean each element is individually serialized via `marshmallow_recipe.dump`, or something else? And what if the list is mixed (some dataclasses, some not)? Only the first element is checked?

5. **`McpConnection` section heading says "Low-level... direct use is rarely needed"** but then shows a usage example. This sends mixed signals — is this for users or not? A brief note like "You may need direct access when working outside the registry pattern" would clarify when a user should care about this section.

## Suggested reordering

The current order is mostly good but would benefit from these adjustments:

1. Move `get_local_tool`, `LocalTool`, `ToolHandler`, and `ToolExecutionContext` into a subsection (e.g., "Internals of @tool") or move them after "Grouping tools." The main narrative for most users is: `@tool` -> service injection -> grouping -> registry. The intermediate types break that flow.

2. Move the `ToolGroup` / `ToolSource` type alias note to the beginning of the `ToolRegistry` section, since that is where the reader needs to know what `create()` accepts.

Proposed section order:
- Quick start (unchanged)
- Types: `ToolDefinition`, `ToolResult` (unchanged)
- `@tool` decorator (unchanged)
- Disambiguation with `tool_arg.INPUT` / `tool_arg.SERVICE` (unchanged)
- Service injection (unchanged)
- Optional services (unchanged)
- Return value serialization (unchanged)
- Grouping tools: `LocalToolGroup`, `create_local_tool_group`, `McpToolGroup`, `ToolGroup`/`ToolSource` (unchanged)
- `ToolRegistry` (unchanged)
- `McpConnection` (unchanged)
- **New or relocated subsection:** `LocalTool`, `get_local_tool`, `ToolHandler`, `ToolExecutionContext` (advanced / internals)

## Summary

- First impression: CLEAR
- Flow: HAS ISSUES
- Explanations: GAPS FOUND
- Examples: GAPS FOUND
- Clarity: ISSUES FOUND
