# Review Summary -- All Packages

## How to use this summary

Go through findings one by one, discuss each, decide action (fix / skip / defer). Findings are grouped by category. Each item is one line with enough context to discuss without re-reading the full report.

---

## Category 1: Code Style Violations (fix immediately)

### Rule 4 -- Private members use double underscore

1. **runtime**, `interrupt.py:9-15` -- `_InterruptTokenImpl` fields (`children`, `event`, `is_interrupted`, `parent`) are public; should be `__`-prefixed. Refactor cross-class access from `InterruptTokenSource` into methods on `_InterruptTokenImpl`.

### Rule 5 -- Comments must carry meaning

2. **runtime**, `execution.py:62` -- Section separator comment "Spawn tree: internal index-based tree..." restates class names. Remove.
3. **runtime**, `engine.py:389-391` -- Section separator "Spawn-tree satisfaction helpers" restates method names. Remove.
4. **lib**, `chat/hook_events.py:1` -- "Event dataclasses for ChatAgent hooks" restates filename. Keep only the "NOT frozen" rationale.
5. **lib**, `tool_loop/hook_events.py:1` -- Same as above for ToolLoopAgent. Keep only the "NOT frozen" rationale.

### Rule 6 -- No module-level helpers (when file owned by single class)

6. **runtime**, `engine.py:68-74` -- Module-level `_build_agent_info` duplicates `Engine.__build_agent_info` static method. Remove module-level function, inline logic into the static method, convert `__build_execution_stack` to `@classmethod`.
7. **runtime**, `engine.py:102-104` -- `__build_agent_info` is a one-line wrapper delegating to module-level function. Inline after fixing #6.
8. **tools**, `mcp_connection.py:102-111` -- `get_tools` and `call_tool` appear after `__aenter__`/`__aexit__`. Move public methods before dunder protocol methods.

### Rule 13 -- Import from package, not internal modules

9. **runtime**, `_instance_factory.py:4` -- `from ..agent.compile import collect_dataclass_types`. Export from `flowra.agent.__init__`, then import from `..agent`.
10. **runtime**, `runtime.py:5` -- `from .._sentinel import UNSET, Unset`. Export from `flowra.__init__`, then import from `..`.
11. **runtime**, `runtime.py:14` -- `from ..agent.timeout import TimeoutAgent`. Export from `flowra.agent.__init__`, then import from `..agent`.

---

## Category 2: Structure Issues (discuss)

### tools

12. `local_tool.py` combines data types, decorator/binding logic, and result formatting (~296 lines). Not urgent, but monitor growth.

### runtime

13. `runtime.py` mixes public API, tree snapshot/restore (~130 lines), and type-registry bookkeeping (~350 lines total). Consider extracting snapshot logic into `snapshot.py`.
14. `engine.py` spawn-tree satisfaction logic (~80 lines of private methods) operates purely on `SpawnTreeNode` types from `execution.py`. Consider moving as free functions to `execution.py`.
15. `_instance_factory.py` name does not convey its key behavior (scope sealing). Minor -- consider renaming to `_sealed_scope.py`.

### lib

16. Duplicated LLM call + streaming logic between `ToolLoopAgent.call_llm` and `LLMCallAgent.call` -- same streaming/non-streaming dispatch pattern in two places. Consider delegation or extraction.
17. Identically-named but unrelated hook event classes (`BeforeLLMCallEvent`, `AfterLLMCallEvent`, `TextDeltaEvent`, `ThinkingDeltaEvent`) in both `llm_call/hook_events.py` and `tool_loop/hook_events.py`. Confusing for users working with both agents.
18. `resolve_config_value` not exported from `flowra.lib` despite `ConfigValue` being exported. Users building custom agents need it.
19. Sub-modules (`chat`, `llm_call`, `tool_loop`) exported in `__all__` as namespace objects is unusual. Consider re-exporting commonly used names directly.

---

## Category 3: Documentation Issues (fix)

### Missing file tree (all packages)

20. **tools** `docs/tools.md` -- Missing file tree section (required by doc structure).
21. **runtime** `docs/runtime.md` -- Missing file tree section.
22. **lib** `docs/lib.md` -- Missing file tree section.

### Accuracy issues

23. **runtime** -- Broken internal link `(see [Design notes](#design-notes))` in persistence contract section; no such section exists.
24. **runtime** -- `InterruptTokenSource.clear()` method-level comment says "called automatically on completion" but does not clarify "only on *successful* completion". Prose section is correct but method comment is ambiguous.
25. **runtime** -- Serialization type table missing `Interrupted` type (`{"__interrupted__": "<reason>"}`).
26. **runtime** -- `run()` does not document `asyncio.TimeoutError` from `timeout` parameter (info is scattered).
27. **lib** -- `LLMCallResult` missing `elapsed: float = 0.0` field in doc table.
28. **lib** -- `ToolLoopAgent` step 2 description omits `StopReason.OTHER` from the parenthetical list.

### Clarity / readability issues (runtime)

29. **runtime** -- "Scope semantics" section uses `RuntimeScope`, "fork", "dirty state" before explaining what a scope is. Add brief intro paragraph.
30. **runtime** -- Forward references: `AgentDefinitionRef`, `GotoStep/GotoAgent/CallStep/CallAgent`, `RuntimeScope`, `AgentRegistry`, `AgentStore`, `ServiceLocator`, `Interrupted()`, `with_interrupt()`, `NEW_SCOPE` -- none defined in runtime docs. Add a "Key terms" paragraph or cross-references.
31. **runtime** -- Missing explanations: what is `storage_key`, what is `node_id`, what is `begin_transaction()` for, how `marshmallow_recipe` relates.
32. **runtime** -- Missing examples: resume after crash, scope usage, `storage_key` usage, `has_pending_execution()`, services injection.
33. **runtime** -- Dense sentences: "join-step receives child results via parameter injection", "no flush callback, no dirty state", "auto-propagate Interrupted() if binding fails" -- need unpacking.

### Clarity / readability issues (tools)

34. **tools** -- `get_local_tool`/`LocalTool`/`ToolHandler`/`ToolExecutionContext` appear before grouping, interrupting the "define -> group -> registry" flow. Move to an "Internals" subsection.
35. **tools** -- Forward references: `ToolExecutionContext.services` mentioned before defined, `ToolDefinition` used in quick start before defined, `flowra.llm.Tool` referenced without explanation.
36. **tools** -- Missing explanations: when `input_schema`/`output_schema` is `None`, how service injection interacts with MCP tools, error handling details, `marshmallow_recipe` context, MCP execution mechanics.
37. **tools** -- Missing examples: zero-parameter tool, `get_llm_tools()` usage, tool returning dataclass, mixed local+MCP registry, error handling.
38. **tools** -- `create()` return type (`await` + `async with`) is confusing without explanation.

### Clarity / readability issues (lib)

39. **lib** -- ChatAgent presented before ToolLoopAgent creates forward references. Reorder: LLMCallAgent -> ToolLoopAgent -> ChatAgent.
40. **lib** -- "Prompt caching" section split across distant locations. Merge caching + cache strategy protocols into one section.
41. **lib** -- Forward references: `ToolLoopAgent`, `ToolLoopConfig`, `ConfigValue`, `CacheConfig`, `HookRegistry`/`Event[T]`, `context` field type -- all used before defined.
42. **lib** -- Missing explanations: `turn_messages` vs `session_messages`, `metadata` flow in interrupt scenarios, how interrupts are signaled, `context.request_finish()`, `AgentDefinition`, `StopReason` full enum, `ToolCallAgentContext` vs `ToolLoopAgentContext`.
43. **lib** -- Missing examples: `max_consecutive_errors`, custom cache strategies, `allowed_tools`/`denied_tools`, `ResultMessageEvent` with `continue_messages`, `json_schema` config, `make_agent_tool` with `AgentDefinition`.
44. **lib** -- Unexplained jargon: "observation-only", "flushes state", "fires on resume too", `e.data.*` access pattern, "mutable fields" concept, "user-provided cache hints", `CACHE_MANUAL` as default.

---

## Category 4: Test Issues

### Existing tests to fix

45. **tools**, `test_local_tool.py:238` -- `test_marker_instance_also_works` has stale name (no "instance vs class" distinction exists). Rename to `test_single_param_with_input_marker`.
46. **runtime**, `test_scope.py:147` -- `test_snapshot_includes_scalars_and_lists` only tests unset scalar (excluded from snapshot). Add a set scalar to actually test "scalars and lists".
47. **runtime**, `test_persistence.py:676` -- `test_resume_continues_after_simulated_crash` does not actually simulate crash+resume. Either implement actual crash-resume or rename/delete.

### Missing test scenarios (prioritized)

**High priority (correctness/safety):**

48. **runtime** -- `FileSessionStorage` key collision from sanitization: `root.0` and `root_0` map to same file. No test or warning.
49. **runtime** -- Concurrent `run()` while another `run()` is active -- `has_pending_execution` guard not tested under concurrency.
50. **runtime** -- Resume with `timeout`/`max_iterations` parameters (same UNSET/override logic as `run()`).
51. **tools** -- `McpConnection.connect` failure path (initialize error, tools/list error during handshake).
52. **llm** -- `ImageBlock` conversion in providers -- no unit test for base64/Blob encoding per provider.
53. **lib** -- ToolLoopAgent: multiple parallel tool calls in single response (spawned as parallel children). Untested.

**Medium priority (edge cases/robustness):**

54. **tools** -- `_format_result` with empty list, `None` return.
55. **tools** -- `McpConnection` SSE parsing edge cases (no matching response, malformed JSON).
56. **tools** -- `McpConnection` background refresh with HTTP error triggers reconnect. Untested.
57. **tools** -- `ToolRegistry.execute` with MCP tool that raises exception (not returns error).
58. **tools** -- `ToolRegistry` with empty sources list.
59. **runtime** -- `deserialize_spawn_tree` with unknown type tag.
60. **runtime** -- `RuntimeScope.hydrate` AppendOnlyList does not mark dirty (only scalar tested).
61. **runtime** -- `_SealedScope.slot()` after seal raises (only `provide()` tested).
62. **llm** -- OpenAI: `ToolResultBlock` with `is_error=True` prepends "Error:". Untested.
63. **llm** -- OpenAI: `__simplify_content` single-text-part simplification. Untested.
64. **llm** -- Anthropic: prompt caching conversion paths (cached vs non-cached blocks). Untested.
65. **llm** -- Google: empty candidates in response returns `StopReason.OTHER`. Untested.
66. **llm** -- OpenAI: empty choices in response. Untested.

**Lower priority (coverage gaps):**

67. **tools** -- `_unwrap_optional` with `Optional[X]` syntax (only `X | None` tested).
68. **tools** -- Input validation with extra fields (additionalProperties behavior).
69. **tools** -- `McpConnection.add_on_tools_changed`/`remove_on_tools_changed` direct test.
70. **runtime** -- `build_spawn_tree` direct unit test for `CallStep`/`CallAgent` leaf and nested combinators.
71. **runtime** -- `Engine.register_live_storage_keys` with completed nodes during resume.
72. **runtime** -- `GotoStep` with explicit different `storage_key` on same agent.
73. **lib** -- `allowed_tools`/`denied_tools` filtering at LLM request level (not just ToolCallAgent denial).
74. **lib** -- `json_schema` config propagation to LLMRequest.
75. **lib** -- Usage accumulation across multiple LLM calls in ToolLoopAgent.
76. **lib** -- `ConfigValue` callables for config fields (all tests use plain values).
77. **lib** -- `LLMCallResult.elapsed > 0` assertion.
78. **lib** -- `StopReason.OTHER` handling in parameterized test.
79. **lib** -- Per-tool-name consecutive error counter isolation.
80. **lib** -- `cache_strategy` integration with ToolLoopAgent LLM requests.
81. **llm** -- Anthropic: `output_schema` on `Tool` appends to description. Untested.
82. **llm** -- Google: `__find_tool_name` returns "unknown" fallback. Untested.
83. **llm** -- Google: stop sequence detection logic. Untested.
84. **llm** -- `schema_validation.validate_json_schema` returned `cleaned` text on error. Untested.

---

## Statistics

### Per-package issue counts

| Package | Style | Structure | Docs | Tests to fix | Missing tests |
|---------|-------|-----------|------|-------------|---------------|
| llm     | 0     | 0         | 0    | 0           | 14            |
| tools   | 1     | 1         | 11   | 1           | 12            |
| runtime | 6     | 3         | 15   | 2           | 10            |
| lib     | 2     | 4         | 18   | 0           | 13            |

### Per-category totals

| Category | Count |
|----------|-------|
| Code style violations | 11 |
| Structure issues | 8 |
| Documentation issues | 25 |
| Tests to fix | 3 |
| Missing test scenarios | 37 (high: 6, medium: 13, lower: 18) |
| **Total** | **84** |
