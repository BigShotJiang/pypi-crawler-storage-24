# Test Review: flowra.llm

## Part 1: Test quality

### test_metadata.py

#### test_separate_instances_have_independent_metadata (line 5)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies that `default_factory=dict` works correctly (each instance gets its own dict, not a shared one). Important for mutable default fields.
- **Structure:** OK
- **Verdict:** KEEP

### test_response.py

#### test_sums_all_token_fields (line 7)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_sums_cache_creation_fields (line 15)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies both the top-level `cache_creation_input_tokens` summing and the extra dict numeric merge for the 5m/1h breakdown.
- **Structure:** OK
- **Verdict:** KEEP

#### test_merges_extra_numeric_values (line 33)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_merges_extra_non_numeric_values (line 39)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies that non-numeric extra values are overwritten (last wins).
- **Structure:** OK
- **Verdict:** KEEP

#### test_merges_extra_disjoint_keys (line 45)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_extras (line 51)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_merges_extra_float_values (line 57)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_sums_cost_usd_both_present (line 63)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_cost_usd_one_none (line 69)
- **Name accuracy:** OK
- **Meaningfulness:** OK — tests both orderings (a+b and b+a).
- **Structure:** OK
- **Verdict:** KEEP

#### test_cost_usd_both_none (line 75)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_stream.py

#### test_default_stream_yields_content_complete (line 14)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies the default `stream()` implementation on `LLMProvider` that wraps `call()` into a single `ContentComplete` event.
- **Structure:** OK
- **Verdict:** KEEP

### test_schema_formatting.py

#### test_basic_string_type (line 6)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_basic_integer_type (line 10)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_no_type_returns_any (line 14)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_type_with_default (line 18)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_integer_default (line 22)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_enum (line 26)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_of_strings (line 30)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_of_objects (line 34)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_object_with_required_and_optional (line 49)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_object_with_description (line 65)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_object (line 79)
- **Name accuracy:** OK
- **Meaningfulness:** OK — tests two variants (with and without empty properties dict).
- **Structure:** OK
- **Verdict:** KEEP

#### test_any_of_union (line 84)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_optional_union_with_null (line 88)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_ref_resolution (line 92)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_nested_object (line 109)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_properties_without_type (line 133)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies the `"properties" in schema` branch when `type` is absent.
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_without_items (line 146)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_nested_ref (line 150)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies that `$ref` chains resolve transitively.
- **Structure:** OK
- **Verdict:** KEEP

#### test_all_of_with_ref (line 172)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_all_of_with_properties (line 193)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_all_of_fallback_to_first (line 210)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_style_type_with_null (line 216)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_style_type_without_null (line 220)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_style_type_single (line 224)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_array_style_type_preserves_extra_fields (line 228)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_format_output_schema_for_description (line 235)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_schema_validation.py

#### TestStripMarkdownCodeBlock::test_no_fences (line 5)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestStripMarkdownCodeBlock::test_both_fences (line 8)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestStripMarkdownCodeBlock::test_opening_fence_only (line 12)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestStripMarkdownCodeBlock::test_strips_whitespace (line 16)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestStripMarkdownCodeBlock::test_multiline_content (line 20)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestStripMarkdownCodeBlock::test_fence_with_language_tag (line 24)
- **Name accuracy:** OK
- **Meaningfulness:** OK — duplicates `test_both_fences` somewhat (both use `json` language tag), but demonstrates the tag-stripping intent explicitly.
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_valid_json_valid_schema (line 40)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_valid_json_invalid_schema (line 45)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_invalid_json (line 50)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_empty_string (line 55)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_strips_markdown_before_validating (line 60)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_wrong_type (line 65)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_minimal_valid (line 71)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies that only required fields are needed.
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidateJsonSchema::test_error_includes_path_and_context (line 75)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### pricing/test_anthropic.py

#### test_known_model (line 7)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_cache (line 17)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_unknown_model (line 29)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_substring_match (line 42)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies model name matching works via substring.
- **Structure:** OK
- **Verdict:** KEEP

#### test_zero_tokens (line 53)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### pricing/test_openai.py

#### test_known_model (line 7)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_cache_read (line 13)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_mercury_2 (line 22)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies non-OpenAI model (Mercury/Inception) is in the table.
- **Structure:** OK
- **Verdict:** KEEP

#### test_unknown_model (line 28)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_longest_match (line 34)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies ordering: `gpt-4o-mini` matches before `gpt-4o`.
- **Structure:** OK
- **Verdict:** KEEP

### pricing/test_google.py

#### test_known_model (line 7)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_cache_read (line 13)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_unknown_model (line 22)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_free_cache_read (line 28)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies a model with cache_read=0 costs nothing for cache reads.
- **Structure:** OK
- **Verdict:** KEEP

### providers/test_anthropic_vertex.py

#### TestConstructorValidation::test_no_args_raises_value_error (line 64)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestConstructorValidation::test_project_and_location_without_credentials_raises (line 68)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestToolNameValidation::test_invalid_tool_name_with_spaces (line 74)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestToolNameValidation::test_empty_tool_name (line 83)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestToolNameValidation::test_tool_name_too_long (line 92)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSystemMessageValidation::test_system_message_after_user_message_raises (line 103)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaRetryLoop::test_retry_succeeds_after_first_failure (line 116)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies retry logic, usage accumulation, and cleaned response text.
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaRetryLoop::test_all_retries_fail_returns_schema_validation_failed (line 144)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies SCHEMA_VALIDATION_FAILED stop reason, call count (1 + max_schema_retries), and accumulated usage.
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaRetryLoop::test_strips_markdown_fences_from_valid_response (line 171)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaRetryLoop::test_schema_response_returns_single_text_block (line 196)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies that thinking blocks are stripped and only clean JSON TextBlock remains.
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaRetryLoop::test_retry_short_circuits_on_max_tokens (line 229)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies early exit when retry gets MAX_TOKENS stop reason.
- **Structure:** OK
- **Verdict:** KEEP

#### TestThinkingSupport::test_thinking_block_in_response (line 259)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestThinkingSupport::test_thinking_budget_tokens_config (line 287)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies both the thinking kwargs and the forced temperature=1 override.
- **Structure:** OK
- **Verdict:** KEEP

#### TestStreamFallback::test_json_schema_falls_back_to_call (line 307)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### providers/test_openai_provider.py

#### TestSystemMessageValidation::test_system_messages_at_start_are_ok (line 38)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies each system message becomes its own OpenAI message (not merged).
- **Structure:** OK
- **Verdict:** KEEP

#### TestConstructorValidation::test_no_args_raises_value_error (line 57)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaStrictTransformation::test_simple_schema_gets_strict_properties (line 63)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaStrictTransformation::test_optional_properties_wrapped_with_null (line 88)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaStrictTransformation::test_nested_objects_processed_recursively (line 116)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaStrictTransformation::test_ref_nodes_with_extra_keys_stripped (line 144)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### providers/test_google_vertex.py

#### TestSystemMessageValidation::test_system_message_after_user_message_raises (line 52)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestThoughtSignature::test_thought_signature_preserved_in_response (line 65)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestThoughtSignature::test_thought_signature_sent_back_in_request (line 97)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestThoughtSignature::test_thinking_parts_converted_to_thinking_block (line 146)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestThoughtSignature::test_thinking_block_sent_back_with_thought_flag (line 178)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestThoughtSignature::test_thoughts_tokens_in_usage (line 221)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestConstructorValidation::test_no_args_raises_value_error (line 246)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaAdaptation::test_refs_flattened_inline (line 252)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaAdaptation::test_additional_properties_and_schema_stripped (line 293)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSchemaAdaptation::test_type_arrays_converted_to_anyof (line 328)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAdditionalConfig::test_thinking_level_config (line 364)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAdditionalConfig::test_thinking_budget_config (line 390)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAdditionalConfig::test_thinking_level_and_budget_combined (line 416)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### providers/test_anthropic_e2e.py

All 13 E2E tests are well-named, meaningful, and properly structured. They cover: simple text, system messages (single and multiple), tool use, tool use roundtrip, JSON schema, stop sequences, usage reporting, prompt caching, streaming (text and thinking), extended thinking, and max_tokens truncation.

- **Verdict:** KEEP all

### providers/test_openai_e2e.py

All 9 E2E tests follow the same pattern as the Anthropic E2E tests. They cover: simple text, system messages, tool use, tool use roundtrip, JSON schema, stop sequences, usage reporting, streaming, and max_tokens truncation.

- **Verdict:** KEEP all

### providers/test_google_vertex_e2e.py

All 11 E2E tests follow the same pattern. They cover: simple text, system messages, tool use, tool use roundtrip, JSON schema, usage reporting, streaming, max_tokens truncation, thinking, thinking+tool use roundtrip (Gemini 2.5), and thinking+tool use roundtrip (Gemini 3).

- **Verdict:** KEEP all

## Part 2: Coverage analysis

### Public API coverage

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `TextBlock` | YES | construction, metadata independence, used throughout all tests |
| `ImageBlock` | PARTIAL | only in E2E provider conversion (not directly unit-tested) |
| `ThinkingBlock` | YES | response conversion, round-trip in Anthropic and Google providers |
| `ToolUseBlock` | YES | response conversion, round-trip tool use, thought_signature |
| `ToolResultBlock` | YES | round-trip tool use in all providers |
| `UserBlock` (type alias) | N/A | type alias, not testable behavior |
| `AssistantBlock` (type alias) | N/A | type alias, not testable behavior |
| `SystemMessage` | YES | extraction, validation (must be at beginning), E2E |
| `UserMessage` | YES | used throughout all tests |
| `AssistantMessage` | YES | response conversion, round-trip messages |
| `Message` (type alias) | N/A | type alias, not testable behavior |
| `LLMRequest` | YES | constructed in every test |
| `LLMResponse` | YES | returned and asserted in every provider test |
| `LLMProvider` | YES | default stream() tested, subclassed in all provider tests |
| `StopReason` | YES | END_TURN, MAX_TOKENS, TOOL_USE, STOP_SEQUENCE, SCHEMA_VALIDATION_FAILED all asserted |
| `Usage` | YES | `__add__` thoroughly tested (tokens, cost, extra merging) |
| `Tool` | YES | construction, name validation, used in tool use tests |
| `StreamEvent` (type alias) | N/A | type alias, not testable behavior |
| `TextDelta` | YES | asserted in streaming E2E tests |
| `ThinkingDelta` | YES | asserted in Anthropic streaming E2E |
| `ContentComplete` | YES | asserted in all streaming tests |
| `pricing` (module) | YES | all three pricing submodules tested |

### Integration tests

Integration-level tests exist through the provider unit tests, which exercise the full conversion pipeline (request building, response parsing, schema retry loop, usage conversion). The E2E tests serve as true integration tests exercising the public API end-to-end with real LLM providers.

### E2E tests

E2E tests are present for all three providers:
- `test_anthropic_e2e.py` — 13 tests (Anthropic Vertex)
- `test_openai_e2e.py` — 9 tests (OpenAI)
- `test_google_vertex_e2e.py` — 11 tests (Google Vertex)

All properly separated with `_e2e` suffix. Good coverage of the main use cases: text, system messages, tools, JSON schema, streaming, thinking, and error conditions (max_tokens).

### Missing test scenarios

1. **`ImageBlock` conversion in providers** — No unit test verifies that `ImageBlock` is correctly converted to the provider-specific format (base64 encoding for Anthropic/OpenAI, `Blob` for Google). Only exercised in E2E if you manually add image tests. A unit test should verify `ImageBlock(data=b"png", media_type="image/png")` produces the correct API-level dict in each provider.

2. **OpenAI provider: `ToolResultBlock` with `is_error=True`** — The OpenAI provider prepends `"Error: "` to the content when `is_error` is True (line 139 of `providers/openai.py`). No unit test verifies this behavior.

3. **OpenAI provider: `ToolResultBlock` interleaved with text blocks in `UserMessage`** — The OpenAI provider has special logic to split `UserMessage` blocks when `ToolResultBlock` appears between text blocks (flushing `content_parts` before adding a tool message). No unit test exercises this interleaving.

4. **OpenAI provider: `__simplify_content` logic** — When a user message has a single text part, the provider returns just the string instead of a list. When there are multiple parts (e.g., text + image), it returns the list. No unit test verifies this simplification.

5. **Anthropic provider: `ToolUseBlock` in response** — No unit test verifies that a tool_use block in the Anthropic API response is correctly converted to `ToolUseBlock`. The E2E tests cover this, but a unit test with a mock would ensure the id, name, and input are correctly mapped.

6. **Anthropic provider: prompt caching conversion** — The system message extraction has different paths for cached vs. non-cached blocks (list of dicts with `cache_control` vs. a single concatenated string). Only the E2E test exercises caching. A unit test should verify that `TextBlock(text="...", cache=True)` produces the correct `cache_control` dict.

7. **Anthropic provider: usage conversion with `cache_creation` breakdown** — The `__convert_usage` method has a fallback path when `cache_creation` is None (prices all cache creation at the 5m rate). No unit test exercises both the detailed breakdown path and the fallback path.

8. **Anthropic provider: `output_schema` on `Tool` appends to description** — When `Tool.output_schema` is set, the description gets `format_output_schema_for_description` appended. No unit test verifies this across any provider.

9. **Google provider: `__find_tool_name` returns "unknown" when tool_use_id not found** — No test verifies this fallback behavior when a `ToolResultBlock` references a non-existent `tool_use_id`.

10. **Google provider: stop sequence detection** — The Google provider manually checks if response text ends with a stop sequence to determine `StopReason.STOP_SEQUENCE` and extract the matched sequence. No unit test exercises this logic. (E2E tests don't cover stop sequences for Google Vertex.)

11. **Google provider: empty candidates in response** — The `__convert_response` method handles `response.candidates` being empty (returns `StopReason.OTHER`). No unit test exercises this edge case.

12. **OpenAI provider: empty choices in response** — The `__convert_response` method handles `response.choices` being empty. No unit test exercises this edge case.

13. **`LLMData.extra` field** — The base class `LLMData` has both `metadata` and `extra` fields. The `metadata` field is tested for independence in `test_metadata.py`, but `extra` field independence is not tested (same `default_factory=dict` pattern, but untested).

14. **`schema_validation.validate_json_schema` return of `cleaned` text on error** — The function returns `(error, cleaned_text)` where `cleaned_text` is always the fence-stripped version. No test asserts the `cleaned` value when validation fails (tests only check `error is not None`).

## Summary
- Test files reviewed: 14
- Individual tests reviewed: 95
- Tests to fix: 0
- Tests to delete: 0
- Public symbols tested: 17 / 17 (excluding type aliases which have no testable behavior)
- Missing test scenarios: 14
