# Test Review: flowra.runtime

## Part 1: Test quality

### test_scope.py

#### TestScalar.test_scalar_starts_unset (line 9)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestScalar.test_scalar_get_with_default (line 14)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestScalar.test_scalar_same_key_returns_same_instance (line 19)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies idempotent slot creation
- **Structure:** OK
- **Verdict:** KEEP

#### TestAppendOnly.test_append_only_starts_empty (line 27)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAppendOnly.test_append_only_same_key_returns_same_instance (line 32)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSlot.test_rejects_invalid_type (line 40)
- **Name accuracy:** OK
- **Meaningfulness:** OK — error path coverage
- **Structure:** OK
- **Verdict:** KEEP

#### TestSlot.test_records_value_types (line 45)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestServices.test_provide_and_get_services (line 54)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestServices.test_get_services_merges_parent (line 59)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestServices.test_local_overrides_parent (line 65)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important edge case
- **Structure:** OK
- **Verdict:** KEEP

#### TestServices.test_provide_rejects_wrong_type (line 70)
- **Name accuracy:** OK
- **Meaningfulness:** OK — error path
- **Structure:** OK
- **Verdict:** KEEP

#### TestServices.test_get_inherited_services_excludes_local (line 75)
- **Name accuracy:** OK
- **Meaningfulness:** OK — tests the Goto semantics distinction
- **Structure:** OK
- **Verdict:** KEEP

#### TestServices.test_services_property_returns_merged (line 82)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestFlush.test_flush_calls_callback (line 89)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestFlush.test_flush_without_callback_is_noop (line 101)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case
- **Structure:** OK
- **Verdict:** KEEP

#### TestGetChanges.test_dirty_scalar_returned (line 107)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestGetChanges.test_clean_scalar_not_returned (line 115)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestGetChanges.test_unflushed_appends_returned (line 121)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestMarkClean.test_mark_clean_clears_dirty (line 132)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSnapshot.test_snapshot_includes_scalars_and_lists (line 147)
- **Name accuracy:** STALE: only tests lists (unset scalar excluded from snapshot), name says "scalars and lists" but snapshot omits unset scalars
- **Meaningfulness:** OK — but only tests unset scalar case
- **Structure:** OK
- **Verdict:** FIX — add a scalar that has a value to fully cover "scalars and lists"

#### TestHydrate.test_hydrate_restores_scalar (line 159)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestHydrate.test_hydrate_restores_append_only (line 165)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestHydrate.test_hydrate_does_not_mark_dirty (line 171)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important behavioral contract
- **Structure:** OK
- **Verdict:** KEEP

#### TestFork.test_fork_copies_scalar_values (line 180)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestFork.test_fork_copies_append_only (line 189)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestFork.test_fork_child_is_independent (line 198)
- **Name accuracy:** OK
- **Meaningfulness:** OK — isolation is critical
- **Structure:** OK
- **Verdict:** KEEP

#### TestFork.test_fork_child_not_dirty (line 209)
- **Name accuracy:** OK
- **Meaningfulness:** OK — forked state should be clean
- **Structure:** OK
- **Verdict:** KEEP

#### TestFork.test_fork_with_parent_services (line 219)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestFork.test_fork_does_not_copy_flush_callback (line 224)
- **Name accuracy:** OK
- **Meaningfulness:** OK — documents important non-copy behavior
- **Structure:** OK
- **Verdict:** KEEP

#### TestHydrateUnknownKey.test_unknown_key_skipped (line 240)
- **Name accuracy:** OK
- **Meaningfulness:** OK — defensive edge case
- **Structure:** OK
- **Verdict:** KEEP

#### TestChangeSetEmpty.test_empty_when_no_data (line 249)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestChangeSetEmpty.test_not_empty_with_scalars (line 253)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestChangeSetEmpty.test_not_empty_with_appends (line 257)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_interrupt.py

#### TestInterruptTokenSource.test_initial_state_is_false (line 11)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_interrupt_makes_token_interrupted (line 15)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_interrupt_is_idempotent (line 20)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_clear_resets_token (line 25)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_check_does_not_raise_when_not_interrupted (line 33)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_check_raises_when_interrupted (line 37)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_wait_returns_immediately_when_already_interrupted (line 43)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenSource.test_wait_completes_when_interrupted_concurrently (line 48)
- **Name accuracy:** OK
- **Meaningfulness:** OK — concurrent behavior
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_parent_interrupt_cascades_to_child (line 62)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_child_interrupt_does_not_affect_parent (line 68)
- **Name accuracy:** OK
- **Meaningfulness:** OK — directional cascade
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_cascade_through_multiple_levels (line 75)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_child_created_after_parent_interrupted_starts_interrupted (line 83)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important edge case
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_clear_does_not_cascade (line 89)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_multiple_children_all_receive_cascade (line 99)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_interrupt_one_child_leaves_siblings_unaffected (line 109)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptTokenCascade.test_dispose_removes_child_from_parent (line 118)
- **Name accuracy:** OK
- **Meaningfulness:** OK — lifecycle cleanup
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptedResult.test_runtime_interrupt_returns_interrupted_result (line 129)
- **Name accuracy:** OK
- **Meaningfulness:** OK — integration test
- **Structure:** OK
- **Verdict:** KEEP

#### TestInterruptedResult.test_interrupted_agent_returns_interrupted_not_none (line 153)
- **Name accuracy:** OK
- **Meaningfulness:** OK — ensures Interrupted sentinel is used, not None
- **Structure:** OK
- **Verdict:** KEEP

### test_serialization.py

All 66 tests in this file follow a consistent, well-structured pattern of serialize/deserialize/round-trip verification. Reviewing notable cases only:

#### TestSerializePrimitives (7 tests, lines 63-83)
- **Verdict:** KEEP all — exhaustive primitive coverage

#### TestSerializeBytes (2 tests, lines 86-93)
- **Verdict:** KEEP — includes empty bytes edge case

#### TestSerializeStdlibTypes (5 tests, lines 96-120)
- **Verdict:** KEEP — uuid, datetime, date, time, decimal

#### TestSerializeDataclass (5 tests, lines 123-151)
- **Verdict:** KEEP — includes error paths (unsupported type, unregistered dataclass)

#### TestSerializeMessages (3 tests, lines 154-169)
- **Verdict:** KEEP

#### TestSerializeBlocks (3 tests, lines 172-189)
- **Verdict:** KEEP

#### TestDeserializePrimitives (5 tests, lines 192-206)
- **Verdict:** KEEP

#### TestDeserializeBytes (2 tests, lines 209-216)
- **Verdict:** KEEP

#### TestDeserializeStdlibTypes (5 tests, lines 219-237)
- **Verdict:** KEEP

#### TestDeserializeDataclass (4 tests, lines 241-264)
- **Verdict:** KEEP — includes unknown type error path

#### TestDeserializeMessages (2 tests, lines 267-281)
- **Verdict:** KEEP

#### TestRoundTrip (8 tests, lines 283-343)
- **Verdict:** KEEP — comprehensive round-trip scenarios

#### TestRoundTripStdlibTypes (7 tests, lines 346-384)
- **Verdict:** KEEP

#### TestRoundTripBytes (3 tests, lines 387-412)
- **Verdict:** KEEP — includes ImageBlock with binary data

#### TestSerializeInterrupted (4 tests, lines 415-442)
- **Verdict:** KEEP — both with and without reason

#### TestDeserializeUnsupportedType (1 test, line 446)
- **Verdict:** KEEP — error path

### test_engine.py

#### TestAdvanceSingleStep.test_completed_in_one_tick (line 67)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAdvanceGotoStep.test_progressed_then_completed (line 85)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAdvanceGotoAgent.test_replaces_node_in_place (line 109)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSpawnTreeShape.test_spawn_creates_children_nodes (line 141)
- **Name accuracy:** OK
- **Meaningfulness:** OK — thorough tick-by-tick verification
- **Structure:** OK
- **Verdict:** KEEP

#### TestSpawnCallStepFork.test_fork_children_and_collect (line 195)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestParallelExecution.test_multiple_children_run_in_same_tick (line 228)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies parallel execution semantics
- **Structure:** OK
- **Verdict:** KEEP

#### TestServicePropagation.test_parent_provides_service_child_sees_it (line 270)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestServicePropagation.test_goto_agent_does_not_inherit_local_provides (line 324)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important isolation contract
- **Structure:** OK
- **Verdict:** KEEP

#### TestNodeIds (3 tests, lines 365-436)
- **Verdict:** KEEP all — verify ID assignment scheme

#### TestUnknownAgent.test_build_root_raises_key_error (line 439)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestStorageKeyPassthrough (3 tests, lines 446-509)
- **Verdict:** KEEP all

#### TestStorageKeyUniqueness (2 tests, lines 512-586)
- **Verdict:** KEEP — covers both duplicate detection and key reuse after release

#### TestTypeResolution (3 tests, lines 601-644)
- **Verdict:** KEEP

#### TestGotoStorageKey (6 tests, lines 650-779)
- **Verdict:** KEEP all — thorough coverage of storage key lifecycle under Goto

#### TestCallStepScopeSemantics (4 tests, lines 801-934)
- **Verdict:** KEEP all — critical fork vs fresh scope tests

#### TestScopeRestoreCallback (3 tests, lines 937-1035)
- **Verdict:** KEEP all

### test_persistence.py

#### TestSaveExecutionCalled.test_save_called_after_run (line 56)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSaveExecutionTreeShape.test_spawn_saves_all_node_ids (line 76)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies snapshot tree shape
- **Structure:** OK
- **Verdict:** KEEP

#### TestRunWithStorage.test_spawn_completes_with_storage (line 123)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestRunWithStorage.test_goto_agent_preserves_node_id_in_snapshot (line 155)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestHasPendingExecution (4 tests, lines 187-240)
- **Verdict:** KEEP all — exhaustive state coverage

#### TestRunBlockedByPendingExecution.test_run_raises_when_pending_execution_exists (line 244)
- **Verdict:** KEEP

#### TestResumeNoStorage (2 tests, lines 260-286)
- **Verdict:** KEEP — error paths

#### TestExecutionClearedOnCompletion.test_execution_cleared_after_run (line 290)
- **Verdict:** KEEP

#### TestStorageKeyReleaseWithStorage.test_storage_key_reuse_after_child_completion (line 308)
- **Verdict:** KEEP

#### TestSnapshotIncludesStorageKey.test_storage_key_in_snapshot (line 361)
- **Verdict:** KEEP

#### TestSameQualnameNoCollision (2 tests, lines 379-463)
- **Verdict:** KEEP — important edge case for per-agent type registries

#### TestScopeFlushMidStep.test_flush_saves_node_state (line 491)
- **Verdict:** KEEP

#### TestNodeStatePersistsAfterCompletion.test_node_state_persists_after_completion (line 525)
- **Verdict:** KEEP

#### TestCrossRunContinuity.test_state_restored_in_new_run_with_same_storage_key (line 551)
- **Verdict:** KEEP — critical cross-run persistence test

#### TestDefaultStorageKey.test_root_defaults_to_storage_key_root (line 581)
- **Verdict:** KEEP

#### TestChildStatePersistsAfterPropagation.test_child_dirty_state_saved_before_propagation_prunes_children (line 606)
- **Verdict:** KEEP — regression test for a specific bug

#### TestResumeEndToEnd (3 tests, lines 675-781)
- **Verdict:** KEEP — but see note below about test_resume_continues_after_simulated_crash

#### TestResumeEndToEnd.test_resume_continues_after_simulated_crash (line 676)
- **Name accuracy:** STALE: the test does NOT actually simulate a crash and resume. It runs to completion in a single call. The comment in the test body acknowledges this ("The agent completes in a single run... For a true mid-run crash test we need an agent that doesn't complete immediately.")
- **Meaningfulness:** LOW — it just verifies a 2-step agent completes normally, which is already covered by other tests
- **Structure:** ISSUE: test does not match its stated intent
- **Verdict:** FIX — either make it actually test crash-resume or delete/rename it

#### TestRegisterType.test_register_type_persists_and_restores (line 785)
- **Verdict:** KEEP

#### TestSlotTypeAutoDiscovery (2 tests, lines 825-909)
- **Verdict:** KEEP — tests automatic type discovery from slot()

#### TestSpawnTreePersistence (2 tests, lines 912-983)
- **Verdict:** KEEP

### test_hook_context.py

All 9 tests cover ExecutionContext propagation through the agent tree:

#### TestExecutionContextSingleAgent (2 tests, lines 31-81)
- **Verdict:** KEEP — root agent context

#### TestExecutionContextParentChild (2 tests, lines 84-176)
- **Verdict:** KEEP — stack propagation

#### TestExecutionContextThreeLevels.test_grandchild_has_full_stack (line 179)
- **Verdict:** KEEP — 3-level stack

#### TestExecutionContextRegistrationHierarchy.test_agent_info_parent_chain (line 239)
- **Verdict:** KEEP — AgentInfo parent chain

#### TestExecutionContextWithSpec.test_child_spec_in_context (line 303)
- **Verdict:** KEEP

#### TestExecutionContextPropagation.test_shared_handler_gets_child_context (line 351)
- **Verdict:** KEEP

#### TestExecutionContextWithTag.test_tag_appears_in_child_frame (line 393)
- **Verdict:** KEEP

### test_spec_in_constructor.py

All 6 tests verify spec injection into agent constructors:

#### TestSpecInConstructor.test_spec_in_constructor_by_type (line 40)
- **Verdict:** KEEP

#### TestSpecInConstructor.test_no_spec_agent_works_as_before (line 58)
- **Verdict:** KEEP

#### TestSpecInConstructor.test_spec_and_provide_pattern (line 71)
- **Verdict:** KEEP

#### TestSpecInConstructor.test_spec_does_not_leak_to_child_agent (line 108)
- **Verdict:** KEEP — important isolation test

#### TestSpecInConstructor.test_nullable_spec_param (line 144)
- **Verdict:** KEEP

#### TestSpecInConstructor.test_goto_agent_with_new_spec (line 164)
- **Verdict:** KEEP

### test_runtime.py

All 44 tests are high-quality integration tests through AgentRuntime's public API:

#### TestSingleStep (2 tests, lines 54-82)
- **Verdict:** KEEP

#### TestGotoStep (2 tests, lines 85-119)
- **Verdict:** KEEP

#### TestGotoAgent.test_transfers_to_another_agent (line 122)
- **Verdict:** KEEP

#### TestSpawnCallAgent.test_spawn_children_and_collect_results (line 148)
- **Verdict:** KEEP

#### TestSpawnCallStep.test_spawn_fork_children_and_collect (line 186)
- **Verdict:** KEEP

#### TestUnknownAgent.test_raises_key_error (line 223)
- **Verdict:** KEEP

#### TestAutoCompileType (3 tests, lines 233-280)
- **Verdict:** KEEP

#### TestRunWithAgentRef (4 tests, lines 283-334)
- **Verdict:** KEEP

#### TestSubagentRegistration (6 tests, lines 337-522)
- **Verdict:** KEEP — thorough subagent registration coverage

#### TestInterruptIntegration (2 tests, lines 525-572)
- **Verdict:** KEEP

#### TestSealedScopeProvide.test_provide_after_construction_raises (line 575)
- **Verdict:** KEEP

#### TestMaxIterations (5 tests, lines 593-651)
- **Verdict:** KEEP — covers override, default, None override, normal completion

#### TestTimeout (4 tests, lines 654-700)
- **Verdict:** KEEP

#### TestInterruptedAutoPropagation (4 tests, lines 708-860)
- **Verdict:** KEEP — thorough interrupted auto-propagation scenarios

#### TestWhenAllBackwardCompat.test_spawn_children_kwarg_still_works (line 863)
- **Verdict:** KEEP

#### TestWhenAny (2 tests, lines 902-983)
- **Verdict:** KEEP

#### TestWhenN.test_when_n_two_of_three (line 987)
- **Verdict:** KEEP

#### TestNestedCombinators.test_when_any_of_when_all (line 1039)
- **Verdict:** KEEP

#### TestTimeoutAgent (2 tests, lines 1089-1162)
- **Verdict:** KEEP — worker-wins and timeout-wins scenarios

### storage/test_in_memory.py

#### TestInMemorySessionStorage (7 tests, lines 6-59)
- **Verdict:** KEEP all — covers initial state, save/load/clear execution, scalars, appends, merge, copy semantics

#### TestTrackingSessionStorage.test_tracks_calls (line 63)
- **Verdict:** KEEP — verifies test helper

### storage/test_file.py

#### TestFileSessionStorage (14 tests, lines 8-153)
- **Verdict:** KEEP all — thorough coverage including sanitization, disk layout, append-only semantics, persistence across instances, scalars-only and appends-only edge cases

## Part 2: Coverage analysis

### Public API coverage

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `AgentRuntime` | YES | run, resume, interrupt, has_pending_execution, max_iterations, timeout, storage integration, spec injection, type-based agent ref |
| `ChangeSet` | YES | construction, empty property, used extensively in storage tests |
| `FileSessionStorage` | YES | all CRUD operations, disk layout, sanitization, merge, persistence |
| `InMemorySessionStorage` | YES | all CRUD operations, merge, copy semantics |
| `InterruptTokenSource` | YES | interrupt, clear, create_child, dispose, cascade, token.check, token.wait, token.interrupted |
| `SessionStorage` | YES (via implementations) | abstract interface exercised through InMemory and File implementations |

### Internal module coverage

| Module | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `runtime_scope.py` (RuntimeScope) | YES | slot creation, services, flush, get_changes, mark_clean, snapshot, hydrate, fork |
| `execution.py` | YES | ExecutionStatus used throughout engine tests; SpawnTree serialize/deserialize roundtrip |
| `engine.py` (Engine) | YES | advance loop, GotoStep, GotoAgent, Spawn, parallel execution, service propagation, storage keys, scope semantics, scope restore callback |
| `serialization.py` | YES | primitives, bytes, stdlib types, dataclasses, messages, blocks, Interrupted, error paths |
| `_instance_factory.py` | YES (indirectly) | used via engine and runtime tests; sealed scope tested via test_runtime.TestSealedScopeProvide |

### Integration tests

Strong integration coverage via:
- `test_runtime.py` — 44 tests exercising `AgentRuntime.run()` with real Agent subclasses and the full agent compilation pipeline
- `test_persistence.py` — 29 tests exercising persistence through `AgentRuntime` with `InMemorySessionStorage`
- `test_hook_context.py` — 9 tests exercising `ExecutionContext` propagation through multi-level agent hierarchies
- `test_spec_in_constructor.py` — 6 tests exercising spec injection through the full runtime

### E2E tests

Not applicable. The runtime package does not interact with external services directly.

### Missing test scenarios

1. **`deserialize_spawn_tree` with unknown type tag:** The function raises `TypeError` for unknown `data["type"]` values (line 128 of `execution.py`), but there is no test for this error path.

2. **`build_spawn_tree` with all node types:** Tests exercise `WhenAll`, `WhenAny`, `WhenN` at the runtime integration level, but `build_spawn_tree` itself is only tested indirectly. A unit test covering the direct `CallStep`/`CallAgent` leaf case and nested combinators would add confidence.

3. **`RuntimeScope.hydrate` with `AppendOnlyList` does not mark dirty:** The test `test_hydrate_does_not_mark_dirty` only checks scalars. There is no test verifying that hydrating an `AppendOnlyList` also does not mark it as having unflushed items.

4. **`RuntimeScope.snapshot` with set scalar values:** `test_snapshot_includes_scalars_and_lists` only creates a scalar without setting it (so it is excluded from the snapshot). There is no test that verifies a set scalar appears in the snapshot.

5. **Concurrent resume while run is in progress:** No test verifies that calling `run()` while another `run()` is active (with storage) is properly rejected via the `has_pending_execution` guard.

6. **`Engine.register_live_storage_keys` with completed nodes:** This method is called during resume, but the test for resume does not directly verify that completed nodes' storage keys are not registered (only non-completed nodes should be).

7. **`GotoStep` with explicit `storage_key` (different from current) on same agent:** The engine code handles `GotoStep(storage_key="new-key")` where the new key differs from the current one, creating a new scope. This path is tested for `NEW_SCOPE` and same-key, but not for a different explicit key on the same agent.

8. **`_SealedScope.slot()` after seal raises:** The `_instance_factory.py` `_SealedScope` raises `RuntimeError` if `slot()` is called after sealing. `provide()` after seal is tested in `test_runtime.TestSealedScopeProvide`, but `slot()` after seal is not tested.

9. **Resume with `timeout` or `max_iterations` parameters:** The `resume()` method accepts `max_iterations` and `timeout` parameters with the same UNSET/override logic as `run()`, but no test exercises these parameters on `resume()`.

10. **`FileSessionStorage` key collision from sanitization:** `__sanitize_key` replaces non-alphanumeric chars with `_`. Two different keys like `root.0` and `root_0` would map to the same file. There is no test verifying (or warning about) this collision.

## Summary

- Test files reviewed: 10
- Individual tests reviewed: 260
- Tests to fix: 2 (test_snapshot_includes_scalars_and_lists — stale name/incomplete; test_resume_continues_after_simulated_crash — does not test what it claims)
- Tests to delete: 0
- Public symbols tested: 6 / 6
- Missing test scenarios: 10
