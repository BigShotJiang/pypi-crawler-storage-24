# Readability Review: flowra.runtime

## First impression

The title and one-line description are clear: "Agent execution engine" that handles orchestration, persistence, interrupts, and crash recovery. The bullet list below the description gives a good mental map of the four key areas.

The quick start is minimal and effective. It shows a complete runnable example: define a spec, a result, an agent with a single step, create a runtime, and run it. A first-time reader could write basic working code from this. The quick start does depend on `flowra.agent` concepts (`Agent`, `step`, `entry=True`), but this is reasonable since the runtime exists to run agents.

## Flow issues

1. **"Scope semantics" section appears before scope is explained.** The section "Scope semantics" (under "Execution model") uses terms like `RuntimeScope`, "fork parent scope", "copy scalars + lists", "flush callback", "dirty state", and `mark_clean()` without explaining what a scope is. The reader learns scopes are created and forked, but never what a scope *contains* or what it represents. The "State and persistence" section later describes `ChangeSet` with `scalars` and `appends`, which seems related, but the connection is never made explicit. A brief sentence explaining "a scope holds per-node runtime state (scalar values and append-only lists)" before the tables would help.

2. **Serialization appears under "State and persistence" heading but is a sibling section.** The `### Serialization` heading is at the same level as `### SessionStorage` and `### FileSessionStorage`, which makes it feel like part of the persistence story. However, it discusses the general serialization mechanism. This is minor but slightly disorienting when scanning headings.

## Forward references

1. **`AgentDefinitionRef`** — used in the constructor signature (`dict[str, AgentDefinitionRef]`) but never defined. The prose below says "AbstractAgent subclass (or AgentDefinition)" which partially clarifies, but the actual type name `AgentDefinitionRef` remains unexplained.

2. **`GotoStep`, `GotoAgent`, `CallStep`, `CallAgent`, `Spawn`** — used extensively in "Scope semantics" and "Engine.advance() mechanics" but never defined in this document. These appear to be concepts from `flowra.agent`, but there is no cross-reference or brief explanation. A reader encountering these for the first time in the execution model section has no idea what they are.

3. **`RuntimeScope`** — mentioned in "Root creation" ("Instantiates agent with fresh RuntimeScope") but never defined or explained.

4. **`AgentRegistry`** — mentioned in the execution lifecycle ("resolves agent dict into AgentRegistry") but never explained.

5. **`AgentStore` and `ServiceLocator`** — mentioned parenthetically in the interrupts section ("always available, like AgentStore and ServiceLocator") but never defined in this document.

6. **`Interrupted()`** — used in the interrupt section as a result type, with a cross-link to `agent.md`, but a one-sentence explanation of what it is before the link would help the reader not have to leave the page.

7. **`with_interrupt()`** — mentioned in "Properties" bullet and in the engine behavior section, but only as a link to `agent.md`. The reader does not know what it does without following the link.

8. **`NEW_SCOPE`** — used in the scope semantics tables (`storage_key=NEW_SCOPE`) but never explained. Is it a sentinel constant? A string? Where is it imported from?

## Missing explanations

1. **What is a "scope"?** The document talks about scope creation, forking, fresh scopes, and scope semantics, but never explains what a scope is, what it holds, or why it matters. This is the biggest gap for a first-time reader.

2. **What is `storage_key`?** It appears in the constructor description (briefly), in the scope semantics tables, and in the persistence contract, but there is no clear explanation of what it is, where you set it, or what its purpose is beyond the brief note "Names are used for persistence (storage keys)". The "Storage keys" bullets at the end of the persistence contract help, but they come late and feel disconnected from the scope semantics section that uses the concept heavily.

3. **What does `advance()` return and how does the loop interact with persistence?** The execution loop pseudo-code shows `persist_changes()` but does not explain what "dirty scopes" are or how the runtime knows which nodes are dirty. The persistence contract section later explains the transaction flow, but there is a gap between the loop description and the persistence explanation.

4. **What is `node_id`?** Mentioned in the persistence contract ("otherwise `node_id`") but never defined.

5. **What is `begin_transaction()` for?** The `SessionStorage` interface includes `begin_transaction()` as an async context manager, but the doc never explains what transactional guarantees are expected. Is it for atomicity? What should happen on exception? The `FileSessionStorage` description does not mention transactions either.

6. **How does `marshmallow_recipe` relate to serialization?** The note "Dataclass serialization delegates field conversion to `marshmallow_recipe.dump()`/`load()`" introduces a third-party library without context. Is this a dependency the user needs to know about? Does it affect how they define their dataclasses?

## Example gaps

1. **No example of `resume()` after a crash.** The persistence example shows the pattern conceptually but the `resume()` call is in a comment-heavy block. A concrete before/after showing state being preserved would be more convincing.

2. **No example of scope usage.** Given how much space the scope semantics section takes, there is no code showing how scopes actually affect agent behavior.

3. **No example of `storage_key` usage.** The scope semantics tables reference `storage_key` and `NEW_SCOPE` but no code example shows how to set these.

4. **No example of `has_pending_execution()`.** The method is listed but never demonstrated in context (e.g., checking before deciding whether to `run()` or `resume()`).

5. **No example of `services` injection.** The constructor documents it, but no code example shows an agent receiving an injected service.

## Clarity issues

1. **"Join-step receives child results via parameter injection (`None` results are filtered out)"** — This sentence in "Parallel execution" is unclear. What is a "join-step"? What does "parameter injection" mean here? What does "filtered out" mean in practice — are `None` results skipped entirely, or passed as `None`?

2. **"No flush callback, no dirty state -- child starts clean"** — In "Fork behavior", this sentence uses internal terminology ("flush callback", "dirty state") that has not been explained. A first-time reader does not know what these mean or why it matters that a child "starts clean".

3. **"parent join-steps receive `None` for interrupted children's nullable parameters, or auto-propagate `Interrupted()` if binding fails"** — This sentence in the interrupt section is dense. "Nullable parameters", "binding fails", and "auto-propagate" are all unexplained concepts packed into one sentence.

4. **The `type_tags` and `type_registry` parameters** in the serialization function signatures are shown but not explained. What are type tags? Where does the registry come from? Since the doc says types are "registered automatically at class definition time", these parameters seem like internal details that either need explanation or should be omitted.

5. **"Nodes with the same `storage_key` across runs share persisted state"** — The concept of "nodes" has not been introduced clearly. While "ExecutionNode" appears in the execution lifecycle, the relationship between nodes, agents, and steps is not spelled out for the reader.

## Suggested reordering

The current order is mostly logical, but two adjustments would help:

1. **Add a brief "Concepts" or "Key terms" paragraph** before or at the start of "Execution model" that defines: execution node, scope, storage_key, and the step navigation primitives (GotoStep, GotoAgent, CallStep, CallAgent). Even a single sentence each would prevent the cascade of forward references.

2. **Move "Scope semantics" after "State and persistence"** (or at least after the persistence contract). The scope semantics tables heavily reference `storage_key` behavior, which is better understood after reading how persistence works. Currently the reader encounters scope/storage_key tables before understanding what persistence means in this context.

## Summary

- First impression: CLEAR
- Flow: HAS ISSUES
- Explanations: GAPS FOUND
- Examples: GAPS FOUND
- Clarity: ISSUES FOUND
