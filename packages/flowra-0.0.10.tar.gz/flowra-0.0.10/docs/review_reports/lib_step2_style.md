# Code Style Review: flowra.lib

## __init__.py

No violations.

## config_value.py

### Line 18: Rule 2 violation — `type: ignore` with justification

**Current:**
```python
        return result  # type: ignore[return-value]  # callable() narrows but pyright can't see T through Awaitable
```
**Analysis:** The comment explains the pyright limitation. After `callable(value)` narrows the union, `value()` returns `T | Awaitable[T]`. The `isawaitable` check handles the `Awaitable[T]` branch, but the else branch returns `T` which pyright sees as potentially `Awaitable[T]`. This is a genuine pyright limitation with generic callable-vs-awaitable narrowing. The ignore has a clear justification and restructuring (e.g., explicit `isinstance` checks) would not help since `Awaitable` is not runtime-checkable in a way that would satisfy pyright here.

**Verdict:** Acceptable — the justification is accurate and alternatives are exhausted.

## llm_config.py

No violations.

## chat/__init__.py

No violations.

## chat/hook_events.py

### Line 1: Rule 5 violation — comment restates what is obvious from the module contents

**Current:**
```python
# Event dataclasses for ChatAgent hooks.
#
# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.
```
**Fix:**
```python
# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.
```
**Reason:** The first line ("Event dataclasses for ChatAgent hooks") merely restates the file's purpose which is obvious from the filename and contents. The "NOT frozen" explanation carries meaning and should stay.

## chat/config.py

No violations.

## chat/spec.py

No violations.

## chat/agent.py

No violations.

## tool_loop/__init__.py

No violations.

## tool_loop/hook_events.py

### Line 1: Rule 5 violation — comment restates what is obvious from the module contents

**Current:**
```python
# Event dataclasses for ToolLoopAgent hooks.
#
# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.
```
**Fix:**
```python
# NOT frozen: handlers can mutate fields to communicate
# outcomes back to the agent.
```
**Reason:** Same as `chat/hook_events.py` — the first line is redundant. The "NOT frozen" rationale is valuable.

## tool_loop/config.py

### Line 13-15: Rule 6 violation — module-level function in a module owned by `ToolLoopConfig`

**Current:**
```python
def matches_tool_filter(name: str, patterns: set[str]) -> bool:
    """Check if a tool name matches any of the patterns (supports wildcards via fnmatch)."""
    return any(fnmatch(name, p) for p in patterns)
```
**Analysis:** This file exists primarily for `ToolLoopConfig`, but `matches_tool_filter` is also used by `tool_call/agent.py`. It is a genuinely shared utility used by both `ToolLoopAgent` (via `agent.py`) and `ToolCallAgent`. Since it is consumed by two unrelated classes in different subpackages, it qualifies for the Rule 6 exception ("truly generic utilities shared across unrelated files").

**Verdict:** Acceptable — used by multiple consumers across subpackages.

## tool_loop/spec.py

No violations.

## tool_loop/agent.py

No violations.

## tool_loop/context.py

No violations.

## tool_loop/cache.py

### Lines 73-103: Rule 6 violation — module-level helper functions alongside `CacheConfig`

**Current:**
```python
def cache_last_system_prompt(messages: list[SystemMessage]) -> list[SystemMessage]:
    return _cache_last_block(messages)


def cache_last_message(
    non_system_session_messages: list[Message],
    turn_messages: list[Message],
) -> list[Message]:
    messages = non_system_session_messages + turn_messages
    return _cache_last_block(messages)

# ... more module-level functions ...

def _clear_cache_hints[T: Message](messages: list[T]) -> list[T]:
    ...

def _cache_last_block[T: Message](messages: list[T]) -> list[T]:
    ...
```
**Analysis:** The public functions (`cache_last_system_prompt`, `cache_last_message`, `cache_last_session_message`, `no_cache_system_prompt`, `no_cache_tools`, `no_cache_messages`, `cache_last_tool`) are standalone strategy functions that conform to the `Protocol` signatures (`SystemPromptCacheStrategy`, `ToolsCacheStrategy`, `MessagesCacheStrategy`). They are used to construct the module-level constants `CACHE_MANUAL`, `NO_CACHE`, `CACHE_ALL`, `CACHE_SESSION`, and are also exported for direct use by consumers. The private helpers (`_clear_cache_hints`, `_cache_last_block`) serve multiple of these public functions.

This file is not owned by a single class — it defines `CacheConfig` plus three `Protocol` types plus multiple strategy functions plus preset constants. It is a cohesive "cache strategies" module, not a "single class" module. Rule 6's requirement ("If a file exists for a single class") does not apply here.

**Verdict:** Acceptable — module is not owned by a single class.

## tool_loop/tool_call/__init__.py

No violations.

## tool_loop/tool_call/agent_tool.py

### Line 14: Rule 5 violation — docstring on `matches_tool_filter` restates the function name

**Analysis:** Actually this file is `agent_tool.py`, not `config.py`. Let me re-check. The `matches_tool_filter` docstring is in `config.py`, already reviewed above.

No violations in `agent_tool.py`.

## tool_loop/tool_call/context.py

No violations.

## tool_loop/tool_call/agent.py

No violations.

## llm_call/__init__.py

No violations.

## llm_call/hook_events.py

### Line 1: Rule 5 violation — comment restates what is obvious from the module contents

**Current:**
```python
# NOT frozen — consistent with ToolLoopAgent hook events.
# All current events are observation-only.
```
**Analysis:** This is a two-line comment. The first line ("NOT frozen -- consistent with ToolLoopAgent hook events") explains why the dataclasses lack `frozen=True`, which is meaningful since the default rule (Rule 14) requires `frozen=True`. The second line ("All current events are observation-only") provides additional context about the design intent. Both lines carry useful information.

**Verdict:** Acceptable — both lines explain non-obvious design decisions.

## llm_call/spec.py

No violations.

## llm_call/agent.py

No violations.

## Summary

- Files reviewed: 22
- Violations found: 2
- Breakdown by rule: Rule 5: 2
