# Structure Review: flowra.tools

## Package responsibility

Defines, registers, and executes tools (both local Python functions and remote MCP servers) that LLM agents can invoke.

## Per-file analysis

### types.py
- **Responsibility:** Defines the two fundamental data types shared across the package: `ToolDefinition` (tool metadata + schemas) and `ToolResult` (execution output).
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_arg.py
- **Responsibility:** Provides sentinel markers (`INPUT`, `SERVICE`) used with `Annotated` to explicitly bind tool handler parameters to tool input or injected services.
- **Name accuracy:** OK
- **Cohesion:** OK

### local_tool.py
- **Responsibility:** Implements the `@tool` decorator that turns a Python function into a `LocalTool`, including parameter binding resolution, JSON schema generation, input validation, and result formatting.
- **Name accuracy:** OK
- **Cohesion:** ISSUE: This file bundles three distinct concerns: (1) the `LocalTool`/`ToolExecutionContext`/`ToolHandler` data types, (2) the `@tool` decorator with its binding resolution logic, and (3) result formatting/JSON encoding (`_JSONEncoder`, `_format_result`). At ~296 lines it is manageable today, but if any of these areas grow, consider extracting binding resolution into a `_binding.py` module and result formatting into a `_formatting.py` module. Not urgent, but worth watching.

### tool_group.py
- **Responsibility:** Defines grouping containers (`LocalToolGroup`, `McpToolGroup`) that bundle multiple tools under an optional namespace prefix, plus a convenience factory `create_local_tool_group`.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_registry.py
- **Responsibility:** Provides `ToolRegistry`, the central facade that accepts tool sources, manages MCP connections, resolves prefixed names, converts tools to LLM-compatible format, and dispatches execution to the correct backend.
- **Name accuracy:** OK
- **Cohesion:** OK

### mcp_connection.py
- **Responsibility:** Implements the MCP Streamable HTTP transport (JSON-RPC 2.0), including handshake, tool listing, tool invocation, automatic reconnect, and background tool refresh polling.
- **Name accuracy:** OK
- **Cohesion:** OK

## Package-level issues

1. **Dependency flow is clean.** The internal dependency DAG is:
   - `types.py` (leaf, no intra-package imports)
   - `tool_arg.py` (leaf, no intra-package imports)
   - `mcp_connection.py` -> `types`
   - `local_tool.py` -> `tool_arg`, `types`
   - `tool_group.py` -> `local_tool`
   - `tool_registry.py` -> `local_tool`, `mcp_connection`, `tool_group`, `types`, and `..llm`

   No circular imports. Clean layered DAG.

2. **`tool_arg` exported as a module, not its members.** The `__init__.py` exports the `tool_arg` module itself (not `tool_arg.INPUT` / `tool_arg.SERVICE`) so users write `tool_arg.INPUT`. This is an intentional namespace-style API and works well given the sentinel nature of the markers. No issue here.

No issues found.

## Public API issues

1. **`ToolHandler` type alias is exported but has limited utility.** `ToolHandler` is `Callable[[ToolExecutionContext], ToolResult | Awaitable[ToolResult]]` -- this is the raw handler signature used internally by `LocalTool`. Users create tools via the `@tool` decorator and never construct a `ToolHandler` directly. Exporting it is harmless but adds noise; consider whether it truly belongs in the public API.

2. **`get_local_tool` is exported but is a niche introspection utility.** It extracts a `LocalTool` from a decorated function. The main user-facing path is `create_local_tool_group` (which calls `get_local_tool` internally). Exporting it is fine for advanced use cases but could be documented as such.

3. **All meaningful public types are exported.** `ToolDefinition`, `ToolResult`, `LocalTool`, `ToolRegistry`, `ToolSource`, `ToolGroup`, `LocalToolGroup`, `McpToolGroup`, `McpConnection`, `ToolExecutionContext`, `tool`, `create_local_tool_group`, `get_local_tool`, `tool_arg` -- the full surface area is available from `flowra.tools` without needing to know internal file structure.

No blocking issues found.

## Summary
- Files reviewed: 6 (excluding `__init__.py`)
- Issues found: 0 blocking, 1 observation
- 1. `local_tool.py` combines data types, decorator/binding logic, and result formatting in one file -- not a problem at current size but worth monitoring as the package grows.
