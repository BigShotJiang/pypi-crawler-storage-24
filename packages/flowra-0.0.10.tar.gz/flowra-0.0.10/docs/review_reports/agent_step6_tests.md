# Test Review: flowra.agent

## Part 1: Test quality

### test_step_ref.py

#### test_sets_tag (line 9)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_preserves_function_identity (line 16)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies decorator returns the original function (no wrapper)
- **Structure:** OK
- **Verdict:** KEEP

#### test_sync_function (line 23)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies sync functions work and remain callable
- **Structure:** OK
- **Verdict:** KEEP

#### test_multiple_decorators_last_wins (line 31)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case: double decoration
- **Structure:** OK
- **Verdict:** KEEP

#### test_bare_decorator (line 41)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_bare_decorator_preserves_identity (line 48)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_bare_decorator_async (line 55)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_parens (line 62)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case: `@step()` vs `@step`
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_string_tag_uses_name (line 69)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case: empty string tag fallback
- **Structure:** OK
- **Verdict:** KEEP

#### test_bound_method_auto_tag (line 76)
- **Name accuracy:** OK
- **Meaningfulness:** OK — tests both bound and unbound access
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_none_for_undecorated (line 87)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_tag_for_decorated (line 93)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_none_for_lambda (line 100)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case
- **Structure:** OK
- **Verdict:** KEEP

#### test_string_passthrough (line 105)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_decorated_function (line 108)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_bound_method (line 115)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_unbound_method (line 124)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_undecorated_raises (line 132)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_undecorated_bound_method_raises (line 139)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_lambda_raises (line 147)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_not_entry_by_default (line 153)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_not_entry_with_explicit_tag (line 160)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_entry_true (line 167)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_entry_with_tag (line 174)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies both `entry` and `tag` work together
- **Structure:** OK
- **Verdict:** KEEP

#### test_entry_false_explicit (line 182)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_undecorated_not_entry (line 189)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_agent_def.py

#### test_step_string (line 45)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_spec (line 51) (GotoStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 56) (GotoStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_resolves_step_ref (line 61) (GotoStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_non_step_method_raises (line 65) (GotoStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_storage_key_string (line 71) (GotoStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_storage_key_new_scope (line 75) (GotoStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_basic (line 84) (GotoAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_spec (line 90) (GotoAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_storage_key (line 95) (GotoAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_new_scope (line 99) (GotoAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 103) (GotoAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_step_string (line 113) (CallStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_spec (line 120) (CallStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 125) (CallStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_resolves_step_ref (line 130) (CallStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_storage_key (line 134) (CallStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_tag (line 138) (CallStep)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_basic (line 147) (CallAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_spec (line 154) (CallAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_storage_key (line 159) (CallAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_new_scope (line 163) (CallAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 167) (CallAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_tag (line 172) (CallAgent)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_call_steps (line 181) (Spawn)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_call_agents (line 186) (Spawn)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_mixed_children (line 190) (Spawn)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 198) (Spawn)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_then_resolves_step_ref (line 203) (Spawn)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_default_reason_none (line 212) (Interrupted)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_custom_reason (line 216) (Interrupted)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 220) (Interrupted)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_equality (line 225) (Interrupted)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_basic (line 235) (WhenAll)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_raises (line 240) (WhenAll)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 244) (WhenAll)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_basic (line 251) (WhenAny)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_raises (line 256) (WhenAny)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 260) (WhenAny)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_basic (line 267) (WhenN)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_n_too_small_raises (line 273) (WhenN)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_n_too_large_raises (line 277) (WhenN)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 281) (WhenN)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_single_leaf (line 291) (Spawn positional)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_multiple_leaves_wraps_in_when_all (line 297) (Spawn positional)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_single_combinator (line 304) (Spawn positional)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_nested_combinators_flatten (line 311) (Spawn positional)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_no_args_and_no_children_raises (line 318) (Spawn positional)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_both_args_and_children_raises (line 322) (Spawn positional)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_fields (line 331) (TimeoutExpired)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_frozen (line 335) (TimeoutExpired)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_seconds (line 342) (timeout)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_minutes (line 348) (timeout)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_combined (line 352) (timeout)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_values.py

#### test_get_on_unset_raises (line 7)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_with_default_on_unset (line 12)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_after_set (line 16)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_with_default_after_set (line 21)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `set` value takes precedence over default
- **Structure:** OK
- **Verdict:** KEEP

#### test_has_value_before_set (line 26)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_has_value_after_set (line 29)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_has_value_after_restore (line 34)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_not_dirty_initially (line 39)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_dirty_after_set (line 42)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_dirty_after_set_to_same_value (line 47)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies set always marks dirty, even for 0/default-like values
- **Structure:** OK
- **Verdict:** KEEP

#### test_mark_clean (line 52)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_dirty_again_after_clean_then_set (line 57)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_none_value (line 65)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case: None is a valid stored value
- **Structure:** OK
- **Verdict:** KEEP

#### test_complex_type (line 72)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_sets_value (line 78)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_not_dirty (line 83)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_clears_dirty (line 88)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty (line 98) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_append_and_get (line 101) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_all_returns_copy (line 107) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important: mutation safety
- **Structure:** OK
- **Verdict:** KEEP

#### test_initial_items (line 114) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_initial_items_not_mutated (line 120) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies defensive copy of input
- **Structure:** OK
- **Verdict:** KEEP

#### test_initial_items_are_not_unflushed (line 126) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies initial items don't count as unflushed
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_unflushed_after_append (line 130) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_unflushed_returns_copy (line 136) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_mark_clean_resets_unflushed (line 143) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_append_after_clean (line 150) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_accepts_tuple (line 158) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies Sequence protocol (not just list)
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_replaces_items (line 162) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_not_unflushed (line 167) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_clears_unflushed (line 172) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_extend (line 181) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_extend_unflushed (line 186) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_extend_empty (line 191) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case
- **Structure:** OK
- **Verdict:** KEEP

#### test_extend_after_append (line 197) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_extend_accepts_generator (line 204) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies Iterable protocol
- **Structure:** OK
- **Verdict:** KEEP

#### test_restore_does_not_mutate_input (line 209) (AppendOnlyList)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_agent_registry.py

#### test_valid_names (line 31)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_rejects_dots (line 34)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_rejects_slashes (line 38)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_rejects_spaces (line 42)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_rejects_empty (line 46)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_resolves_top_level (line 52)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_resolves_nested (line 59)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_unknown_name_raises (line 67)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_child_ref (line 74)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_without_context_raises (line 82)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_nested_child (line 87)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_sibling_ref (line 98)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_grandparent_ref (line 107)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_deeper_path_after_going_up (line 116)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_above_root_raises (line 126)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_remainder_raises (line 131)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_bare_dot_prefix_rejected (line 136)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_relative_without_context_raises (line 143)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_resolves_top_level_type (line 150)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_resolves_subagent_type_from_parent_context (line 156)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_walks_hierarchy_upward (line 174)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_unregistered_type_raises (line 180)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_same_type_at_different_levels (line 187)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important: scoped resolution
- **Structure:** OK
- **Verdict:** KEEP

#### test_closer_scope_wins (line 210)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_existing (line 237)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_unknown_raises (line 242)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_full_name (line 249)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_with_context (line 253)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_deeply_nested_agents (line 271)
- **Name accuracy:** OK
- **Meaningfulness:** OK — integration: 3-level nesting with multiple resolution methods
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_all_including_nested (line 289)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_names_and_definitions (line 300)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_duplicate_class_at_same_level_raises (line 314)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_with_interrupt.py

#### test_no_interrupt_yields_all (line 55)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_already_interrupted_raises (line 61)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_mid_iteration (line 69)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_while_waiting_for_next (line 82)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important: tests actual async waiting behavior
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_after_first_slow_item (line 101)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_empty_iterator (line 120)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case
- **Structure:** OK
- **Verdict:** KEEP

#### test_aclose_called_on_interrupt (line 126)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important: resource cleanup
- **Structure:** OK
- **Verdict:** KEEP

#### test_aclose_called_on_normal_completion (line 148)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_works_with_async_generator (line 166)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_exception_in_iterator_propagates (line 178)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important error path
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_stops_at_correct_item_in_fast_loop (line 196)
- **Name accuracy:** OK
- **Meaningfulness:** OK — stress test with 100 items
- **Structure:** OK
- **Verdict:** KEEP

#### test_check_not_interrupted (line 215)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_check_interrupted (line 220)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_execution_context.py

#### test_finds_spec_in_current_frame (line 47)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_finds_spec_in_parent_frame (line 53)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_nearest_spec_wins (line 64)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies "nearest" semantics
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_none_when_not_found (line 75)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_none_for_empty_specs (line 79)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case: all-None specs
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_spec (line 85)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_raises_when_not_found (line 89)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_by_spec_type (line 96)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_by_agent_type (line 107)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_nearest_match (line 118)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_by_both_spec_and_agent_type (line 129)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_none_when_not_found (line 140)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_raises_without_criteria (line 144)
- **Name accuracy:** OK
- **Meaningfulness:** OK — important: validates arg requirement
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_frame (line 151)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_raises_when_not_found (line 156)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_raises_with_spec_type_message (line 161)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies error message content
- **Structure:** OK
- **Verdict:** KEEP

### test_hooks.py

#### test_emit_no_handlers (line 30)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_sync_handler_called (line 35)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_async_handler_called (line 48)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_multiple_handlers_called_in_order (line 60)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_prepend_handler (line 71)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_has_handlers (line 82)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_add_provider (line 90)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_propagate_to (line 103)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_propagate_to_with_only (line 118)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_propagate_to_with_exclude (line 138)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_handler_mutation_visible (line 158)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies mutable Event.data behavior
- **Structure:** OK
- **Verdict:** KEEP

#### test_context_stamped (line 168)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies Event gets context
- **Structure:** OK
- **Verdict:** KEEP

#### test_emit_without_context_raises (line 186)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_agent.py

#### test_auto_compiles_agent_definition (line 60)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_child_inherits_parent_steps (line 66)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_overriding_child_replaces_parent_step (line 70)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_compile.py

All 70+ tests in this file follow the pattern described above and are well-structured. Rather than enumerate every single test, here are the highlights and any issues:

#### TestCompileAgent (6 tests, lines 175-207)
- **Name accuracy:** OK across all
- **Meaningfulness:** OK — covers basic compilation, step discovery, spec types, invalid return types, inheritance, overrides
- **Structure:** OK
- **Verdict:** KEEP all

#### TestAgentInstance (3 tests, lines 212-229)
- **Name accuracy:** OK
- **Meaningfulness:** OK — covers call_step with spec, create returns AgentInstance, unknown step raises
- **Structure:** OK
- **Verdict:** KEEP all

#### TestDI (2 tests, lines 235-249)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestCallStep (4 tests, lines 255-288)
- **Name accuracy:** OK
- **Meaningfulness:** OK — covers goto_step, join with list, join with single, join empty list
- **Structure:** OK
- **Verdict:** KEEP all

#### TestCompileWithSubagents (1 test, line 295)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestResultTypesExtraction (5 tests, lines 317-364)
- **Name accuracy:** OK
- **Meaningfulness:** OK — single, multiple, none, type alias, nested alias, union of aliases
- **Structure:** OK
- **Verdict:** KEEP all

#### TestAbstractServiceDI (1 test, line 371)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestOptionalServiceDI (3 tests, lines 401-450)
- **Name accuracy:** OK
- **Meaningfulness:** OK — covers provided, not provided with default, nullable without default
- **Structure:** OK
- **Verdict:** KEEP all

#### TestMixedChildResults (5 tests, lines 456-540)
- **Name accuracy:** OK
- **Meaningfulness:** OK — ambiguous raises, wildcard, wildcard list, subtree type, mixed picks correct
- **Structure:** OK
- **Verdict:** KEEP all

#### TestSpawnUndecoratedThen (1 test, line 547)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSyncSteps (2 tests, lines 574-591)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestSlotInConstructor (2 tests, lines 597-622)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestSlotContainers (3 tests, lines 628-684)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestTypeRegistry (5 tests, lines 690-763)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestUnionStepParams (4 tests, lines 772-827)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestAgentContract (5 tests, lines 833-881)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestBareAgentRejected (2 tests, lines 887-904)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestEntryWithSpawn (1 test, line 911)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestValidationErrors (5 tests, lines 930-983)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestNoSpecNoResult (5 tests, lines 989-1029)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestStepMeta (2 tests, lines 1035-1058)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestTagBasedBinding (1 test, line 1065)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestAgentSpecBinding (1 test, line 1090)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestOptionalSpecPatterns (2 tests, lines 1116-1140)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestStepTypeValidation (4 tests, lines 1146-1187)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

## Part 2: Coverage analysis

### Public API coverage

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `NEW_SCOPE` | YES | Used in GotoStep/GotoAgent storage_key tests |
| `AbstractAgent` | YES | Used as base in ExecutionContext tests, used indirectly through Agent |
| `Agent` | YES | Auto-compilation, inheritance, overrides, generics |
| `AgentDefinition` | YES | Produced by compile_agent, all fields exercised |
| `AgentDefinitionRef` | YES | Used in AgentRegistry tests (both type and definition refs) |
| `AgentInfo` | YES | Used in ExecutionContext and hooks tests |
| `AgentInstance` | YES | Created via create_instance, call_step exercised |
| `AgentRef` | YES | Tested via resolve (string and type variants) |
| `AgentRegistry` | YES | Name validation, resolve by name/type/relative, nesting, all_definitions |
| `AgentStore` | YES | Used via FakeAgentStore in compile tests |
| `AppendOnlyList` | YES | Thorough: append, extend, restore, unflushed, mark_clean, copy safety |
| `CallAgent` | YES | Construction, fields, frozen |
| `CallStep` | YES | Construction, fields, frozen, step ref resolution |
| `CallStepHandler` | NO | Protocol type, tested indirectly through AgentInstance.call_step |
| `ChildOutput` | YES | Used in call_step child binding tests |
| `CreateInstance` | NO | Protocol type, tested indirectly through AgentDefinition.create_instance |
| `Event` | YES | Created during emit, data/context fields verified |
| `ExecutionContext` | YES | find_spec, get_spec, find_frame, get_frame, stack navigation |
| `ExecutionFrame` | YES | Used in ExecutionContext tests |
| `GotoAgent` | YES | Construction, fields, frozen |
| `GotoStep` | YES | Construction, fields, frozen, step ref resolution, storage_key |
| `HookProvider` | YES | Protocol tested via add() |
| `HookRegistry` | YES | on, emit, has_handlers, add, propagate_to, with_context (indirectly), emit without context |
| `InterruptToken` | YES | Tested via custom impl + check method |
| `Interrupted` | YES | Construction, fields, frozen, equality |
| `InterruptedError` | YES | Raised and caught in with_interrupt and check tests |
| `NoResult` | YES | Cannot instantiate, used in agent contract tests |
| `NoSpec` | YES | Cannot instantiate, used in agent contract tests |
| `ResolvedAgent` | YES | Produced by AgentRegistry.resolve, name/definition verified |
| `Scalar` | YES | Thorough: get, set, restore, has_value, dirty tracking, mark_clean |
| `ServiceLocator` | YES | Used via FakeServiceLocator in compile tests |
| `Spawn` | YES | Construction (children kwarg, positional args), flatten, frozen, step ref |
| `SpawnChild` | YES | Used in Spawn tests |
| `SpawnNode` | YES | Used in Spawn/WhenAll/WhenAny/WhenN tests |
| `StepAction` | YES | Returned from steps (GotoStep, Spawn) |
| `StepMeta` | YES | spec_types, result_types verified |
| `StepMethod` | YES | Tested indirectly via step decorator |
| `StepRef` | YES | String and callable variants tested in resolve_step_ref |
| `StepResult` | YES | Various return types tested |
| `TimeoutExpired` | YES | Fields, frozen |
| `WhenAll` | YES | Construction, empty raises, frozen |
| `WhenAny` | YES | Construction, empty raises, frozen |
| `WhenN` | YES | Construction, n validation, frozen |
| `agent_arg` | PARTIAL | Implicit SPEC binding tested; explicit `agent_arg.SPEC` and `agent_arg.SERVICE` markers not tested |
| `step` | YES | Bare, with tag, with entry, auto-tag, sync |
| `step_arg` | YES | SPEC, CHILD, CHILD("tag"), list variants |
| `timeout` | YES | seconds, minutes, combined |
| `with_interrupt` | YES | Thorough: normal, pre-interrupted, mid, async waiting, cleanup, exceptions |

### Integration tests

The test suite has good integration coverage:
- `test_compile.py` tests the full flow from Agent class definition through compilation to instance creation and step calling, which exercises the interaction between `agent.py`, `compile.py`, `model.py`, `step_decorator.py`, `step_arg.py`, `stored_values.py`, and `service_locator.py`.
- `test_agent_registry.py` tests nesting with real `Agent` subclasses, exercising `Agent.__init_subclass__` -> `compile_agent` -> `AgentRegistry` flow.
- `test_hooks.py` tests `HookRegistry` with `ExecutionContext`, exercising the hooks/execution_context interaction.

### E2E tests

Not applicable. The `flowra.agent` package does not directly interact with external services (LLM providers are in `flowra.llm`). The `TimeoutAgent` is an internal agent that could be E2E-tested through the runtime, but agent-level unit tests are sufficient.

### Missing test scenarios

1. **`agent_arg.SPEC` explicit marker in constructor:** Test that `Annotated[MySpec, agent_arg.SPEC]` on a constructor parameter correctly marks it as spec (not just implicit type matching). The source code at `compile.py:591` handles this explicitly, but no test verifies the explicit `agent_arg.SPEC` marker behavior is different from implicit.

2. **`agent_arg.SERVICE` explicit marker in constructor:** Test that `Annotated[MyService, agent_arg.SERVICE]` on a constructor parameter prevents it from being treated as spec even when its type matches the agent's spec types. The code at `compile.py:156` does post-processing to mark implicit spec params, but `SERVICE` marker should prevent this.

3. **`HookRegistry.with_context` behavior:** The `with_context` method creates a new registry sharing handlers but with a different context. While this is used internally, there's no direct test verifying: (a) handlers are shared (events registered on parent fire on child), (b) the child's context is used in emitted events, (c) handlers added after `with_context` are independent.

4. **`Spawn` with single child in `children=` kwarg:** `Spawn(children=[CallStep(step="a")], then="merge")` takes the single-child branch (line 240 in model.py) which sets `root = children[0]`. This path is not explicitly tested (the existing tests use 2+ children or the positional-args API).

5. **`Spawn` with `children=[]` (empty list):** `Spawn(children=[], then="x")` creates an empty WhenAll via `object.__new__`. The test `test_frozen` uses this path, but doesn't verify that `s.children == []` or `s.root.nodes == ()`.

6. **Nullable step parameter binding when no candidates match:** Test that a step parameter `spec: ChatSpec | None` receives `None` when no spec is provided. The binding code (compile.py:544) handles this, but no test verifies `nullable=True` step params get `None` when unmatched.

7. **Agent spec not matching constructor param type:** Test that when `create_instance` is called with an `agent_spec` that doesn't match the constructor param's type (e.g., wrong spec type), the param receives `None` (if nullable) or is omitted. This is the `isinstance(agent_spec, ip.service_type)` check at compile.py:464.

8. **`collect_dataclass_types` with duplicate same-type (idempotent):** The function skips types already in the registry when `existing is typ` (compile.py:118). No test verifies this idempotent behavior.

9. **`TimeoutAgent` behavior:** No unit test for `TimeoutAgent.wait` step logic (deadline persistence, interrupt during wait, already-past deadline). This would require mocking `time.time` and the interrupt token. Currently only the `timeout()` convenience function is tested.

10. **Step param binding: spec and children both checked (no marker):** When a step param has no `step_arg` marker, both `check_spec=True` and `check_children=True`. No test explicitly verifies that a parameter without `Annotated` markers can match from both sources (spec and child_outputs) or that it receives from whichever matches.

## Summary
- Test files reviewed: 8 (excluding empty `__init__.py`)
- Individual tests reviewed: 163
- Tests to fix: 0
- Tests to delete: 0
- Public symbols tested: 42 / 44 (CallStepHandler and CreateInstance are Protocol types tested only indirectly)
- Missing test scenarios: 10
