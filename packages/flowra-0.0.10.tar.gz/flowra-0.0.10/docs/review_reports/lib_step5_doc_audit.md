# Documentation Audit: flowra.lib

## Type/field consistency

### LLMCallSpec
- All fields: OK

### LLMCallResult
- Field `elapsed`: exists in code (`float`, default `0.0`) but NOT documented — MISSING
- All other fields: OK

### ChatSpec
- All fields: OK

### ChatResult
- All fields: OK

### ChatConfig
- All fields: OK

### SaveTurnMessagesEvent
- All fields: OK

### ToolLoopSpec
- All fields: OK

### ToolLoopResult
- All fields: OK

### ToolLoopStatus
- All values: OK

### ToolLoopConfig
- All fields: OK

### LLMConfig
- All fields: OK

### CacheConfig
- All fields: OK

### LLMCallAgent hook events (flowra.lib.llm_call)
- `BeforeLLMCallEvent`: documented "Has `request`" — code has `request: LLMRequest`. OK
- `AfterLLMCallEvent`: documented "Has `request`, `response`" — code has `request: LLMRequest`, `response: LLMResponse`. OK
- `TextDeltaEvent`: documented "Has `text`" — code has `text: str`. OK
- `ThinkingDeltaEvent`: documented "Has `text`" — code has `text: str`. OK
- Note: LLMCallAgent hook events do NOT have a `context` field (unlike their ToolLoopAgent counterparts). The doc correctly omits `context` from the LLMCallAgent event descriptions.

### ToolLoopAgent hook events (flowra.lib.tool_loop)
- `UserMessageEvent`: documented mutable field `messages: list[UserMessage]` — matches code. OK
- `MessageAcceptedEvent`: documented "Has `messages`, `metadata` (from spec)" — code has `messages: list[Message]`, `metadata: dict[str, Any]`. OK
- `StartIterationEvent`: documented mutable field `additional_messages: list[UserMessage]`, "Has `iteration` (int), `context`" — code has `iteration: int`, `context: ToolLoopAgentContext`, `additional_messages: list[UserMessage]`. OK
- `BeforeLLMCallEvent`: documented "Has `request`, `context`" — code has `request: LLMRequest`, `context: ToolLoopAgentContext`. OK
- `TextDeltaEvent`: documented "Has `text` (str), `context`" — code has `text: str`, `context: ToolLoopAgentContext`. OK
- `ThinkingDeltaEvent`: documented "Has `text` (str), `context`" — code has `text: str`, `context: ToolLoopAgentContext`. OK
- `AfterLLMCallEvent`: documented "Has `request`, `response`, `context`" — code has `request: LLMRequest`, `response: LLMResponse`, `context: ToolLoopAgentContext`. OK
- `TextReasoningEvent`: documented "Has `text` (TextBlock), `context`" — code has `text: TextBlock`, `context: ToolLoopAgentContext`. OK
- `ThinkingEvent`: documented "Has `thinking`, `context`" — code has `thinking: ThinkingBlock`, `context: ToolLoopAgentContext`. OK
- `BeforeToolCallEvent`: documented mutable field `tool_use: ToolUseBlock`, "Has `context`" — code has `tool_use: ToolUseBlock`, `context: ToolLoopAgentContext`. OK
- `AfterToolCallEvent`: documented mutable fields `result: ToolResultBlock`, `additional_messages`, "Has `tool_use`, `context`" — code has `tool_use: ToolUseBlock`, `result: ToolResultBlock`, `context: ToolLoopAgentContext`, `additional_messages: list[UserMessage]`. OK
- `ResultMessageEvent`: documented mutable field `continue_messages: list[UserMessage]`, "Has `message` (AssistantMessage), `context`" — code has `message: AssistantMessage`, `context: ToolLoopAgentContext`, `continue_messages: list[UserMessage]`. OK

### ToolLoopAgentContext
- All methods: OK

### ToolCallAgentContext
- All methods: OK

## API consistency

All APIs match.

## Import consistency

### Quick start example
- `from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec` — all exist in `flowra.lib.chat.__all__`. OK
- `from flowra.lib import LLMConfig` — `LLMConfig` is in `flowra.lib.__all__`. OK
- `from flowra.llm import LLMProvider, SystemMessage, TextBlock` — assumed correct (external package).
- `from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider` — assumed correct (external package).
- `from flowra.runtime import AgentRuntime` — assumed correct (external package).
- `from flowra.tools import ToolRegistry, get_local_tool, tool` — assumed correct (external package).

### LLMCallAgent example
- `from flowra.lib import LLMConfig` — OK
- `from flowra.lib.llm_call import LLMCallAgent, LLMCallResult, LLMCallSpec` — all in `flowra.lib.llm_call.__all__`. OK

### LLMCallAgent streaming example
- `from flowra.agent import HookRegistry` — assumed correct (external package).
- `from flowra.lib.llm_call import LLMCallAgent, TextDeltaEvent` — both in `flowra.lib.llm_call.__all__`. OK

### Hooks example (ToolLoopAgent)
- `from flowra.agent import HookRegistry` — assumed correct.
- `from flowra.lib.tool_loop import BeforeLLMCallEvent, AfterLLMCallEvent` — both in `flowra.lib.tool_loop.__all__`. OK

### Chat hooks example
- `from flowra.lib.chat import ChatAgent, ChatConfig, SaveTurnMessagesEvent` — all in `flowra.lib.chat.__all__`. OK
- `from flowra.llm import Message` — assumed correct.

### ToolLoopAgent example
- `from flowra.lib.tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopSpec` — all in `flowra.lib.tool_loop.__all__`. OK

### Cache presets example
- `from flowra.lib.tool_loop import CACHE_MANUAL, NO_CACHE, CACHE_ALL, CACHE_SESSION` — all in `flowra.lib.tool_loop.__all__`. OK

### Tool services examples
- `from flowra.agent import InterruptToken` — assumed correct.
- `from flowra.lib.tool_loop import ToolLoopAgentContext` — in `flowra.lib.tool_loop.__all__`. OK

### Agent tool examples
- `from flowra.lib.tool_loop import agent_tool, get_agent_tool` — both in `flowra.lib.tool_loop.__all__`. OK
- `from flowra.lib.tool_loop import make_agent_tool` — in `flowra.lib.tool_loop.__all__`. OK
- `from flowra.lib.tool_loop import ToolCallAgentContext` — in `flowra.lib.tool_loop.__all__`. OK

All imports correct.

## Example correctness

### Example in "Quick start"
- Correct. `ChatSpec`, `ChatConfig`, `AgentRuntime` usage all match code signatures.

### Example in "LLMCallAgent"
- Correct. `LLMCallSpec(messages=[...])`, `AgentRuntime` usage matches code.

### Example in "LLMCallAgent > Streaming"
- `hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))` — `HookRegistry.on()` wraps the event data in `Event[T]`, so `e.data.text` is correct since `TextDeltaEvent` has `text: str`. Correct.

### Example in "ChatAgent"
- `ChatSpec(user_message="Hello!")` — matches code. Correct.

### Example in "Chat hooks"
- `event.data.messages` — `event` is `Event[SaveTurnMessagesEvent]`, so `event.data.messages` accesses the `messages` field. Correct.
- `m.metadata.get("transient")` — this depends on Message having a `metadata` attribute, which is outside the audited package. Assumed correct.

### Example in "ToolLoopAgent"
- Correct. `ToolLoopConfig` and `ToolLoopSpec` field names match.

### Example in "Hooks"
- `e.data.request.messages` — `e` is `Event[BeforeLLMCallEvent]`, `e.data.request` is `LLMRequest`. Correct.
- `e.data.response.stop_reason` — `e` is `Event[AfterLLMCallEvent]`, `e.data.response` is `LLMResponse`. Correct.

### Example in "Tool services"
- Correct.

### Example in "Agents as tools > @agent_tool decorator"
- Correct.

### Example in "Agents as tools > make_agent_tool"
- Correct.

### Example in "Agents as tools > ToolCallAgentContext"
- `ctx.call_agent(PoetAgent, PoetSpec(topic=params.topic))` — matches `ToolCallAgentContext.call_agent(agent, spec)`. Correct.
- Doc says return type of tool is `None` — this is fine; the code shows the tool handler return value is ignored when `call_agent()` is used.

### Example in "ConfigValue"
- Correct.

### Example in "Cache strategy protocols"
- `SystemPromptCacheStrategy` protocol: `(messages: list[SystemMessage]) -> list[SystemMessage]` — matches code. Correct.
- `ToolsCacheStrategy` protocol: `(tools: list[Tool]) -> list[Tool]` — matches code. Correct.
- `MessagesCacheStrategy` protocol: `(non_system_session_messages, turn_messages) -> list[Message]` — matches code. Correct.

## Completeness

### Symbols in __all__ but not in docs

**flowra.lib.__all__:**
- `ConfigValue` — documented. OK
- `LLMCallAgent` — documented. OK
- `LLMConfig` — documented. OK
- `chat`, `llm_call`, `tool_loop` — submodule re-exports, not user-facing symbols. OK

**flowra.lib.llm_call.__all__:**
- All symbols documented. OK

**flowra.lib.chat.__all__:**
- All symbols documented. OK

**flowra.lib.tool_loop.__all__:**
- `SystemPromptCacheStrategy`, `ToolsCacheStrategy`, `MessagesCacheStrategy` — documented in "Cache strategy protocols" section. OK
- `cache_last_message`, `cache_last_session_message`, `cache_last_system_prompt`, `cache_last_tool` — documented in built-in strategies table. OK
- `no_cache_messages`, `no_cache_system_prompt`, `no_cache_tools` — documented in built-in strategies table. OK
- All other symbols documented. OK

None.

### Symbols in docs but not in __all__
None.

### Missing exports
None.

## Behavioral accuracy

### "How the loop works" section
- **Step 1 `start`**: Doc says "Wraps the user message into a `UserMessage`" — code creates `UserMessage(blocks=[TextBlock(text=spec.user_message)])`. Correct.
- Doc says "`UserMessageEvent` — handlers can replace or augment the initial messages" — code emits `UserMessageEvent(messages=[user_message])` and uses `event.messages` after. Correct.
- Doc says "Flushes state (for crash recovery)" — code calls `await self.__store.flush()`. Correct.
- Doc says "`MessageAcceptedEvent` — observation-only (fires on resume too)" — code emits this event, and on resume (when `turn_messages` already exist), it still fires. Correct.

- **Step 2 `call_llm`**: Doc says "Calls `interrupt.check()`... checks finish request and iteration limit" — code calls `self.__interrupt.check()`, then checks `is_finish_requested()`, then checks `iteration >= max_llm_calls`. Correct.
- Doc says "Builds `LLMRequest` from config, accumulated messages, tool filters, and cache strategy" — code does this. Correct.
- Doc says streaming auto-switches when TextDeltaEvent/ThinkingDeltaEvent handlers registered — code checks `has_handlers()`. Correct.
- Doc says for `END_TURN`: "`ResultMessageEvent`. If handlers set `continue_messages`, the loop continues; otherwise returns `ToolLoopResult` with `COMPLETED` status." — matches code. Correct.
- Doc says for `TOOL_USE`: "`BeforeToolCallEvent` for each tool call (handlers can modify parameters), then spawns parallel child agents" — code iterates tool_uses, emits BeforeToolCallEvent, then Spawn with children. Correct.
- Doc says "Other (`MAX_TOKENS`, `STOP_SEQUENCE`, `SCHEMA_VALIDATION_FAILED`) — returns immediately" — code matches `MAX_TOKENS | STOP_SEQUENCE | SCHEMA_VALIDATION_FAILED | OTHER`. Doc omits `OTHER` from the parenthetical list but says "Other" which covers it. OK.

- **Step 3 `collect_results`**: Doc says "`AfterToolCallEvent` for each tool — handlers can replace the result or inject additional messages" — code emits AfterToolCallEvent and uses `after_event.result` and `after_event.additional_messages`. Correct.
- Doc says "If a tool has failed too many times in a row (`max_consecutive_errors`), the error is replaced with a prompt to try a different approach" — code implements this. Correct.
- Doc says "All tool results are appended as a `UserMessage`" — code creates `UserMessage(blocks=final_blocks)` and appends. Correct.
- Doc says "Calls `interrupt.check()`... checks finish request" — code calls both. Correct.

### ChatAgent behavior
- Doc says "it prepends `system_messages` to the accumulated conversation history and passes the result as `session_messages` to `ToolLoopAgent`" — code in `__combined_session_messages()` does `system + self.__session_messages.get_all()`. Correct.

### CacheConfig behavior
- Doc says "When a slot is `None`, user-provided `cache` hints are preserved as-is" — code in `apply()` just extends with original messages when strategy is None. Correct.
- Doc says "When a strategy is set, it replaces the caching policy for that slot" — each strategy clears then sets. Correct.
- Doc says `cache_last_system_prompt` "Sets `cache=True` on the last block of the last system message" — code calls `_cache_last_block(messages)` which clears all hints then sets cache on last block of last message. Correct.
- Doc says `cache_last_tool` "Sets `cache=True` on the last tool" — code calls `no_cache_tools(tools)` then sets cache on last. Correct.
- Doc says `cache_last_message` "Sets `cache=True` on the last block across all messages" — code merges `non_system_session_messages + turn_messages` then calls `_cache_last_block`. Correct.
- Doc says `cache_last_session_message` "Same, but only within session messages (not turn messages)" — code calls `_cache_last_block(non_system_session_messages) + _clear_cache_hints(turn_messages)`. Correct.

### Presets
- `CACHE_MANUAL = CacheConfig()` — all slots None. Matches "preserves user-provided cache hints as-is". Correct.
- `NO_CACHE` — uses `no_cache_*` for all slots. Matches "strips all cache hints". Correct.
- `CACHE_ALL` — uses `cache_last_system_prompt`, `cache_last_tool`, `cache_last_message`. Matches "cache system prompt + tools + last message (all messages)". Correct.
- `CACHE_SESSION` — uses `cache_last_system_prompt`, `cache_last_tool`, `cache_last_session_message`. Matches "cache system prompt + tools + last session message (excludes current turn)". Correct.

All descriptions accurate.

## Summary
- Type/field mismatches: 1 (`LLMCallResult.elapsed` undocumented)
- API mismatches: 0
- Import errors: 0
- Example errors: 0
- Undocumented symbols: 0
- Inaccurate descriptions: 0
- Total issues: 1
