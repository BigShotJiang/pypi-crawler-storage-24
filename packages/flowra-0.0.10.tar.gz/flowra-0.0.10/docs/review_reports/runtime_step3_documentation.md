# Documentation Review: flowra.runtime

## Documentation exists: YES

## Structure compliance

1. **Title:** Compliant. `# Package \`flowra.runtime\``
2. **One-line description:** Compliant. First line is a one-sentence summary.
3. **File tree:** Missing. There is no code block showing the package's file structure with per-file comments. Instead, the doc opens with a bullet-point summary of key concepts, which serves a similar orientation purpose but does not match the required format.
4. **Quick start:** Compliant. Minimal working example present immediately after the intro.
5. **Sections organized by user importance:** Compliant. Flows from basic usage (AgentRuntime) to execution model to persistence to advanced features (interrupts, serialization).

## Completeness

### Documented symbols

- `AgentRuntime` — full constructor, methods, and behavior documented
- `ChangeSet` — field table and `empty` property documented
- `SessionStorage` — abstract interface with all methods documented
- `FileSessionStorage` — constructor, file layout documented
- `InMemorySessionStorage` — mentioned in the built-in implementations table
- `InterruptTokenSource` — constructor, `token`, `interrupt()`, `clear()` documented

### Undocumented symbols

None. All 6 symbols from `__all__` are documented.

## Example validation

### Example 1: Quick start
- **Valid:** YES
- **Issues:** None. Imports, types, method signatures, and field names are correct.

### Example 2: AgentRuntime methods
- **Valid:** YES
- **Issues:** None. All shown method calls match the actual API signatures. The `run()` keyword-only parameters, `resume()`, `has_pending_execution()`, and `interrupt()` are all correctly shown.

### Example 3: Execution loop pseudocode
- **Valid:** YES
- **Issues:** None. The pseudocode accurately reflects the `__run_loop_inner` logic.

### Example 4: SessionStorage interface
- **Valid:** YES
- **Issues:** None. The abstract method signatures match the actual code.

### Example 5: FileSessionStorage constructor
- **Valid:** YES
- **Issues:** None. Parameters match the actual `__init__`.

### Example 6: Persistence example
- **Valid:** YES
- **Issues:** None. The `AgentRuntime` constructor call and `run()`/`resume()` usage are correct.

### Example 7: InterruptToken interface
- **Valid:** YES
- **Issues:** None. The `interrupted`, `check()`, and `wait()` members match the actual ABC.

### Example 8: InterruptTokenSource interface
- **Valid:** YES
- **Issues:** Minor — the doc shows `clear()` method, but omits `create_child()` and `dispose()`. These are internal (used by the engine for parent-child cascade), so omitting them is reasonable.

### Example 9: Agent interrupt usage
- **Valid:** YES
- **Issues:** None. The constructor injection of `InterruptToken` and `check()` usage are correct.

### Example 10: Serialization functions
- **Valid:** YES
- **Issues:** None. The function signatures match the actual code.

## Accuracy issues

1. **Broken internal link to "Design notes":** The persistence contract section (line ~302 of the doc) contains `(see [Design notes](#design-notes))` but there is no "Design notes" section anywhere in the document. This is a dead link.

2. **`InterruptTokenSource.clear()` description is slightly misleading:** The doc says `clear()` has the comment "Reset (called automatically on completion)". In the code, `clear()` is called on successful completion only (inside the `Completed` match arm in `__run_loop_inner`). If `run()` raises an exception (e.g., `max_iterations` exceeded, `TimeoutError`, or an unhandled step exception), `clear()` is NOT called. The doc's "Properties" section does clarify this ("Automatically cleared on successful completion (but not on exceptions, allowing resume)"), but the method-level comment is ambiguous.

3. **Serialization `Interrupted` type not documented in the type table:** The serialization section shows a table of supported types but does not include `Interrupted`, which has its own serialization format (`{"__interrupted__": "<reason>"}`). This is a minor omission since `Interrupted` is an internal engine concern, but it could surprise users who inspect their storage files.

4. **`run()` does not document all error conditions:** The doc says `run()` raises `RuntimeError` if a pending execution exists and if `max_iterations` is exceeded. It does not mention that `asyncio.TimeoutError` is raised when the `timeout` expires, though this is implied by the constructor docs mentioning `asyncio.wait_for`. The information is present but scattered.

## Clarity issues

1. **No file tree section:** The review criteria require a file-tree code block showing package structure with per-file comments. This helps a new reader orient themselves in the codebase. The bullet-point intro partially compensates but does not replace it.

2. **Scope semantics section could be confusing for newcomers:** The "Scope semantics" section presents four tables (GotoStep, GotoAgent, CallStep, CallAgent) referencing concepts (`NEW_SCOPE`, `storage_key`, fork) without first explaining what a scope *is* or why it matters. The term `RuntimeScope` is never introduced to the reader. A brief paragraph before the tables explaining that a scope holds an agent's `Scalar` and `AppendOnlyList` state would help.

3. **The "Signaling from outside" comment block mixes behavior levels:** The code comment after `runtime.interrupt()` describes engine internals (per-node catch, `Interrupted()` conversion, auto-propagation) in a way that may confuse readers. The subsequent "Engine behavior on InterruptedError" paragraph then repeats much of this more clearly. The code comment could be simplified.

4. **`with_interrupt()` is referenced but never explained in this doc:** The properties list mentions `with_interrupt()` as a link to `agent.md`, but a reader who hasn't read the agent docs won't understand what it is. A one-line explanation would help (e.g., "a utility for racing async iterators with interrupt support").

## Summary

- Documentation exists: YES
- Structure compliant: NO (missing file tree)
- Symbols documented: 6 / 6
- Examples valid: 10 / 10
- Accuracy issues: 4
- Clarity issues: 4
