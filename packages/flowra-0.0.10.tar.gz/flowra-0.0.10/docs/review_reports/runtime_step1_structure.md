# Structure Review: flowra.runtime

## Package responsibility

Provides the execution engine that runs agent graphs: manages the execution loop, execution tree of nodes, state persistence/recovery, serialization, scoped state, and interrupt propagation.

## Per-file analysis

### runtime.py
- **Responsibility:** Top-level `AgentRuntime` facade that wires together the engine, storage, serialization, and interrupt machinery, and exposes the public `run`/`resume`/`interrupt` API.
- **Name accuracy:** OK
- **Cohesion:** ISSUE: The file mixes three distinct concerns into one class: (1) the public runtime API (`run`, `resume`, `interrupt`, `has_pending_execution`), (2) execution-tree snapshot/restore logic (`__snapshot_tree`, `__restore_tree`, `__save_post_advance`, `__save_dirty_scopes`, `__mark_all_clean`), and (3) type-registry bookkeeping (`__build_type_registries`, `__type_by_tag`, `__tag_by_type`). The snapshot/restore block alone is ~130 lines and could be extracted into a dedicated module (e.g. `snapshot.py` or incorporated into `serialization.py`), which would make `runtime.py` a thin orchestration layer.

### engine.py
- **Responsibility:** Step-level execution engine: advances the execution tree one tick at a time, creates nodes, spawns children, applies step results (goto/spawn/complete), and evaluates spawn-tree satisfaction strategies.
- **Name accuracy:** OK
- **Cohesion:** ISSUE: The spawn-tree satisfaction logic (`__is_tree_satisfied`, `__collect_needed_indices`, `__collect_needed`, `__satisfied_set_from_children`, `__satisfied_set_from_tasks`, `__interrupt_unneeded_from_tasks`) is a self-contained algorithm (~80 lines) that only operates on `SpawnTreeNode` and child indices. It has no dependency on the rest of `Engine`. Extracting it into a set of free functions in `execution.py` (where the spawn-tree types already live) would improve cohesion and testability.

### execution.py
- **Responsibility:** Defines the execution-tree data structures: `ExecutionNode`, `ExecutionStatus`, `CollectedResult`, and the spawn-tree types (`SpawnTreeLeaf/All/Any/N`) with their build/serialize/deserialize functions.
- **Name accuracy:** OK
- **Cohesion:** OK

### interrupt.py
- **Responsibility:** Implements hierarchical cooperative interruption via `InterruptTokenSource` and its internal `_InterruptTokenImpl`, supporting parent-child propagation and disposal.
- **Name accuracy:** OK
- **Cohesion:** OK

### serialization.py
- **Responsibility:** Converts arbitrary Python values (primitives, dataclasses, dates, bytes, UUIDs, `Interrupted`) to/from JSON-safe representations using type-tag registries.
- **Name accuracy:** OK
- **Cohesion:** OK

### runtime_scope.py
- **Responsibility:** Implements `RuntimeScope` -- the per-node mutable state container that holds scalars, append-only lists, provided services, and tracks dirty changes for persistence.
- **Name accuracy:** OK
- **Cohesion:** OK

### _instance_factory.py
- **Responsibility:** Creates agent instances with a sealed scope proxy that prevents `slot()`/`provide()` calls after construction, and collects dataclass types from slot annotations into the type registry.
- **Name accuracy:** ISSUE: The name `_instance_factory` suggests a generic factory pattern, but the module's key behavior is the sealing mechanism. A name like `_sealed_scope.py` or `_instance_sealing.py` would better describe what distinguishes this from a plain `defn.create_instance()` call. Minor issue.
- **Cohesion:** OK

### storage/session_storage.py
- **Responsibility:** Defines the `SessionStorage` abstract base class and the `ChangeSet` data class that represents a batch of state mutations.
- **Name accuracy:** OK
- **Cohesion:** OK

### storage/in_memory.py
- **Responsibility:** In-memory implementation of `SessionStorage` for testing and ephemeral use.
- **Name accuracy:** OK
- **Cohesion:** OK

### storage/file.py
- **Responsibility:** File-system implementation of `SessionStorage` using JSON files for scalars/execution snapshots and JSONL files for append-only lists.
- **Name accuracy:** OK
- **Cohesion:** OK

## Package-level issues

1. **`runtime.py` does too much.** The `AgentRuntime` class is ~350 lines and combines public API orchestration, full tree snapshot/restore serialization, and type-registry management. The snapshot/restore logic (`__snapshot_tree`, `__restore_tree`, `__save_post_advance`, `__save_dirty_scopes`, `__mark_all_clean`, `__next_run_id`) could be extracted into a separate module (e.g. `snapshot.py`) that the runtime delegates to. This would keep `runtime.py` as a thin facade.

2. **Spawn-tree satisfaction logic lives in `engine.py` but belongs with the data types.** The `SpawnTreeNode` types and their build/serialize/deserialize functions live in `execution.py`, but the evaluation logic (satisfaction check, needed-index collection) is spread across private methods in `Engine`. Since this logic is purely algorithmic and only depends on `SpawnTreeNode` and `set[int]`, it would be more cohesive as free functions alongside the types in `execution.py`.

3. **No issues with dependency flow.** The internal dependency DAG is clean: `storage/` has no upward dependency, `interrupt.py` depends only on `..agent`, `execution.py` depends on `interrupt` and `runtime_scope`, `engine.py` depends on `execution`/`interrupt`/`runtime_scope`, and `runtime.py` depends on everything. No circular imports.

## Public API issues

1. **`ExecutionContext` and `ExecutionFrame` are not re-exported.** These types from `flowra.agent` are constructed and injected by the engine but are not exported from `flowra.runtime`. This is likely correct since they originate from the `agent` package -- but worth noting that a user working with hooks will need to import from `flowra.agent` directly.

2. **`Engine`, `RuntimeScope`, and `ExecutionNode` are not exported from the package `__init__.py`.** `Engine` and `RuntimeScope` have their own `__all__` declarations but are not in the top-level `flowra.runtime.__init__.py` exports. This is appropriate -- they are internal implementation details and the public facade is `AgentRuntime`. No issue.

3. **The exports are clean and sufficient.** The package exports `AgentRuntime`, `InterruptTokenSource`, `SessionStorage`, `ChangeSet`, `FileSessionStorage`, and `InMemorySessionStorage` -- all the types a user needs to configure and run agents with persistence and interruption.

## Summary
- Files reviewed: 10 (7 in `runtime/`, 3 in `runtime/storage/`)
- Issues found: 3
- 1. `runtime.py` mixes public API orchestration with tree snapshot/restore serialization logic (~130 lines) and type-registry bookkeeping. Consider extracting snapshot/restore into a dedicated module.
- 2. Spawn-tree satisfaction/evaluation logic (~80 lines of private methods in `Engine`) operates purely on `SpawnTreeNode` types that live in `execution.py`. Moving this logic to `execution.py` as free functions would improve cohesion.
- 3. `_instance_factory.py` name does not convey its key distinguishing behavior (scope sealing). Minor.
