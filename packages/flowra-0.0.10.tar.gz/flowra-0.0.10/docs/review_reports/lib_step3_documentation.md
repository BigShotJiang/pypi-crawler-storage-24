# Documentation Review: flowra.lib

## Documentation exists: YES

`docs/lib.md` exists and covers the package.

## Structure compliance

1. **Title:** Compliant. `# Package flowra.lib`.
2. **One-line description:** Compliant. First paragraph describes what the package does.
3. **File tree:** Missing. There is no code block showing the package's file structure with per-file comments.
4. **Quick start:** Compliant. Minimal multi-turn chat example with a tool.
5. **Sections organized by user importance:** Compliant. Progression from simplest (LLMCallAgent) to most common (ChatAgent) to lower-level (ToolLoopAgent) to composition (agents as tools) to configuration details.

One deviation: missing file tree.

## Completeness

### Documented symbols

**`flowra.lib`:**
- `ConfigValue`
- `LLMCallAgent`
- `LLMConfig`

**`flowra.lib.llm_call`:**
- `LLMCallAgent`
- `LLMCallResult`
- `LLMCallSpec`
- `BeforeLLMCallEvent`
- `AfterLLMCallEvent`
- `TextDeltaEvent`
- `ThinkingDeltaEvent`

**`flowra.lib.chat`:**
- `ChatAgent`
- `ChatConfig`
- `ChatResult`
- `ChatSpec`
- `SaveTurnMessagesEvent`

**`flowra.lib.tool_loop`:**
- `ToolLoopAgent`
- `ToolLoopConfig`
- `ToolLoopResult`
- `ToolLoopSpec`
- `ToolLoopStatus`
- `ToolLoopAgentContext`
- `ToolCallAgentContext`
- `agent_tool`
- `get_agent_tool`
- `make_agent_tool`
- `CacheConfig`
- `SystemPromptCacheStrategy`
- `ToolsCacheStrategy`
- `MessagesCacheStrategy`
- `CACHE_MANUAL`
- `CACHE_ALL`
- `CACHE_SESSION`
- `NO_CACHE`
- `cache_last_system_prompt`
- `cache_last_tool`
- `cache_last_message`
- `cache_last_session_message`
- `no_cache_system_prompt`
- `no_cache_tools`
- `no_cache_messages`
- `BeforeLLMCallEvent`
- `AfterLLMCallEvent`
- `TextDeltaEvent`
- `ThinkingDeltaEvent`
- `BeforeToolCallEvent`
- `AfterToolCallEvent`
- `UserMessageEvent`
- `MessageAcceptedEvent`
- `StartIterationEvent`
- `ResultMessageEvent`
- `TextReasoningEvent`
- `ThinkingEvent`

### Undocumented symbols

None. All user-facing symbols from `__all__` are documented. The `resolve_config_value` utility from `config_value.py` and `matches_tool_filter` from `config.py` are internal and don't need user-facing documentation. The `ToolCallAgent`, `ToolCallResult`, `ToolCallSpec` from `tool_loop/tool_call/` are internal implementation types.

## Example validation

### Example 1: Quick start (ChatAgent multi-turn chat)
- **Valid:** YES
- **Issues:** The example calls `eval_expression(params.expression)` which is not defined. This is intentional (the comment says "Use a safe evaluator") so it's a placeholder, not a bug. Minor: the example would not actually run as-is due to the undefined function, but the intent is clear.

### Example 2: LLMCallAgent basic usage
- **Valid:** YES
- **Issues:** None. Imports, types, and API usage are correct. The `provider` variable is assumed to exist (reasonable in a snippet).

### Example 3: LLMCallAgent streaming
- **Valid:** YES
- **Issues:** None. `hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))` correctly accesses the `text` field through the `Event[T]` wrapper.

### Example 4: ChatAgent basic usage
- **Valid:** YES
- **Issues:** None. Simple and correct.

### Example 5: SaveTurnMessagesEvent (chat hooks)
- **Valid:** YES
- **Issues:** None. `event.data.messages` is correct (Event wrapper around SaveTurnMessagesEvent). Messages do have a `metadata` dict inherited from `LLMData`.

### Example 6: ToolLoopAgent basic usage
- **Valid:** YES
- **Issues:** None. Imports and API are correct.

### Example 7: Hooks registration (BeforeLLMCallEvent, AfterLLMCallEvent)
- **Valid:** YES
- **Issues:** None. Correctly imports from `flowra.lib.tool_loop` and accesses `e.data.request.messages` and `e.data.response.stop_reason`.

### Example 8: Cache presets
- **Valid:** YES
- **Issues:** None.

### Example 9: Tool services (MyDatabase injection)
- **Valid:** YES
- **Issues:** None. Demonstrates service injection correctly.

### Example 10: Tool services (InterruptToken and ToolLoopAgentContext)
- **Valid:** YES
- **Issues:** None.

### Example 11: @agent_tool decorator
- **Valid:** YES
- **Issues:** None. Correctly shows the decorator pattern and `get_agent_tool()`.

### Example 12: Agent tool registration
- **Valid:** YES
- **Issues:** None.

### Example 13: make_agent_tool
- **Valid:** YES
- **Issues:** None.

### Example 14: ToolCallAgentContext.call_agent()
- **Valid:** YES
- **Issues:** None. Correctly shows direct delegation.

### Example 15: ConfigValue forms
- **Valid:** YES
- **Issues:** None.

### Example 16: Cache strategy protocols
- **Valid:** YES
- **Issues:** None. Correctly shows the protocol signatures.

## Accuracy issues

1. **`LLMCallResult` missing `elapsed` field.** The doc table (line 115-118) shows only `message` and `usage`, but the code (`flowra/lib/llm_call/spec.py` line 17) also has `elapsed: float = 0.0`. This field should be documented.

2. **`ToolLoopAgent` step 2 description omits `StopReason.OTHER`.** The doc (line 299) says: "Other (`MAX_TOKENS`, `STOP_SEQUENCE`, `SCHEMA_VALIDATION_FAILED`) -- returns immediately." The code (`flowra/lib/tool_loop/agent.py` lines 246-255) also handles `StopReason.OTHER` in the same match arm. Should be listed as: "Other (`MAX_TOKENS`, `STOP_SEQUENCE`, `SCHEMA_VALIDATION_FAILED`, `OTHER`)".

3. **`TextDeltaEvent` description says "Has `text`" in LLMCallAgent hook events table but says "Has `text` (str), `context`" for ToolLoopAgent.** This is actually correct -- the two are different classes from different modules. However, the doc doesn't make this distinction explicit enough. A reader might confuse the handler signature between `flowra.lib.llm_call.TextDeltaEvent` (which has only `text`) and `flowra.lib.tool_loop.TextDeltaEvent` (which has `text` and `context`). The note on line 148-149 ("These events are independent from ToolLoopAgent events") helps, but this is a subtle gotcha.

## Clarity issues

1. **Missing file tree.** For a package with 4 sub-packages and 22 source files, a file tree would help readers understand the layout before diving in. This is a required structural element per the documentation best practices.

2. **Relationship between LLMCallAgent and ToolLoopAgent hook events could be clearer.** Both packages export identically-named event types (`BeforeLLMCallEvent`, `AfterLLMCallEvent`, `TextDeltaEvent`, `ThinkingDeltaEvent`). The doc notes they are "independent" (line 148-149), but does not explain why both exist or when you'd use one vs the other. Since `ChatAgent` delegates to `ToolLoopAgent` (not `LLMCallAgent`), a reader using ChatAgent might mistakenly import events from `flowra.lib.llm_call` when they should use `flowra.lib.tool_loop`.

3. **`LLMCallAgent` constructor dependency on `LLMConfig` service.** The doc example shows `LLMConfig: LLMConfig(model=...)` in the services dict. This works because the constructor parameter is typed `llm_config: LLMConfig` and gets injected. This is fine for the example, but a reader might wonder whether `LLMCallAgent` supports `ConfigValue[LLMConfig]` like `ToolLoopConfig` does. It does not -- `LLMCallAgent` takes a plain `LLMConfig`, not wrapped in a config.

## Summary

- Documentation exists: YES
- Structure compliant: NO (missing file tree)
- Symbols documented: 42 / 42 (user-facing)
- Examples valid: 16 / 16
- Accuracy issues: 2 (missing `elapsed` field, missing `StopReason.OTHER`)
- Clarity issues: 3
