# Structure Review: flowra.lib

## Package responsibility

Provides pre-built, composable agent implementations (LLM call, tool loop, chat) on top of the core `flowra.agent` framework, along with shared configuration primitives they depend on.

## Per-file analysis

### config_value.py
- **Responsibility:** Defines the `ConfigValue[T]` type alias (plain value, sync callable, or async callable) and its resolver.
- **Name accuracy:** OK
- **Cohesion:** OK

### llm_config.py
- **Responsibility:** Defines the `LLMConfig` dataclass that holds LLM provider parameters (model, temperature, max_tokens, etc.).
- **Name accuracy:** OK
- **Cohesion:** OK

### llm_call/spec.py
- **Responsibility:** Defines the input (`LLMCallSpec`) and output (`LLMCallResult`) data types for `LLMCallAgent`.
- **Name accuracy:** OK
- **Cohesion:** OK

### llm_call/hook_events.py
- **Responsibility:** Defines hook event dataclasses emitted by `LLMCallAgent` (before/after call, text/thinking deltas).
- **Name accuracy:** OK
- **Cohesion:** OK

### llm_call/agent.py
- **Responsibility:** Implements `LLMCallAgent` -- a minimal agent that makes a single LLM call (with optional streaming).
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/spec.py
- **Responsibility:** Defines the input (`ToolLoopSpec`), output (`ToolLoopResult`), and status enum (`ToolLoopStatus`) for `ToolLoopAgent`.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/config.py
- **Responsibility:** Defines `ToolLoopConfig` dataclass and the `matches_tool_filter` helper for wildcard-based tool filtering.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/context.py
- **Responsibility:** Defines `ToolLoopAgentContext` -- a context object that tools can use to request the loop to finish.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/hook_events.py
- **Responsibility:** Defines all hook event dataclasses emitted by `ToolLoopAgent` (13 event types covering the full loop lifecycle).
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/cache.py
- **Responsibility:** Defines prompt-caching strategies (`CacheConfig`, built-in presets like `CACHE_ALL`, `NO_CACHE`, etc.) for controlling cache hints on messages and tools before LLM calls.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/agent.py
- **Responsibility:** Implements `ToolLoopAgent` -- an agent that runs an iterative LLM-call-and-tool-execution loop until completion or a limit is reached.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/tool_call/context.py
- **Responsibility:** Defines `ToolCallAgentContext` -- a per-tool-call context that allows tools to delegate to a sub-agent via `call_agent()`.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/tool_call/agent_tool.py
- **Responsibility:** Provides utilities (`make_agent_tool`, `@agent_tool`, `get_agent_tool`) to expose agent classes as LLM-callable tools.
- **Name accuracy:** OK
- **Cohesion:** OK

### tool_loop/tool_call/agent.py
- **Responsibility:** Implements `ToolCallAgent` -- an agent that executes a single tool call, with support for interrupt handling and agent delegation.
- **Name accuracy:** OK
- **Cohesion:** OK

### chat/spec.py
- **Responsibility:** Defines the input (`ChatSpec`) and output (`ChatResult`) data types for `ChatAgent`.
- **Name accuracy:** OK
- **Cohesion:** OK

### chat/config.py
- **Responsibility:** Defines `ChatConfig` dataclass for configuring `ChatAgent`.
- **Name accuracy:** OK
- **Cohesion:** OK

### chat/hook_events.py
- **Responsibility:** Defines hook event dataclasses emitted by `ChatAgent` (currently just `SaveTurnMessagesEvent`).
- **Name accuracy:** OK
- **Cohesion:** OK

### chat/agent.py
- **Responsibility:** Implements `ChatAgent` -- an agent that manages multi-turn chat by maintaining session history and delegating each turn to `ToolLoopAgent`.
- **Name accuracy:** OK
- **Cohesion:** OK

## Package-level issues

1. **Duplicated LLM call + streaming logic between `ToolLoopAgent` and `LLMCallAgent`.** Both `tool_loop/agent.py` (lines 171-183) and `llm_call/agent.py` (lines 46-58) contain the same streaming/non-streaming dispatch pattern: check for delta handlers, iterate stream events with the same match arms, or fall back to `provider.call()`. `ToolLoopAgent` does not delegate to `LLMCallAgent` -- it re-implements the same logic inline. This is a maintenance risk: changes to LLM call behavior (e.g. adding a new stream event type) must be applied in two places. Consider having `ToolLoopAgent` delegate to `LLMCallAgent` or extracting the shared logic.

2. **Parallel hook event hierarchies for the same concepts.** `tool_loop/hook_events.py` defines `BeforeLLMCallEvent`, `AfterLLMCallEvent`, `TextDeltaEvent`, `ThinkingDeltaEvent` with `context: ToolLoopAgentContext` fields, while `llm_call/hook_events.py` defines identically-named classes without that field. These are completely unrelated types that share names, which could confuse users who work with both agents. Consider either (a) having `ToolLoopAgent` delegate to `LLMCallAgent` and use its events, or (b) giving the tool-loop versions distinct names (e.g. `ToolLoopBeforeLLMCallEvent`) if they must remain separate.

## Public API issues

1. **`resolve_config_value` is not exported from `flowra.lib.__init__.py`.** Tests import it directly from `flowra.lib.config_value`, and examples import `ConfigValue` from `flowra.lib.config_value` as well. Since `ConfigValue` is exported at the top level but its companion function `resolve_config_value` is not, users building custom agents or config resolvers must know the internal file structure. Either export `resolve_config_value` from `flowra.lib` or keep it deliberately internal (in which case only agents inside `lib` should use it -- but example code currently does not call it, so this is minor).

2. **Sub-package modules are exported as namespace objects but not documented as such.** `flowra.lib.__init__.py` exports `chat`, `llm_call`, and `tool_loop` as module references in `__all__`. This is unusual -- typically `__all__` contains names of classes/functions, not sub-modules. It works (users can do `from flowra.lib import tool_loop` and then `tool_loop.ToolLoopAgent`), but it is also redundant since Python already allows `from flowra.lib.tool_loop import ToolLoopAgent`. Consider either removing the module exports from `__all__` or re-exporting the most commonly used names (like `ToolLoopAgent`, `ChatAgent`) directly from `flowra.lib`.

## Summary
- Files reviewed: 19
- Issues found: 4
- 1. Duplicated LLM call + streaming logic between `ToolLoopAgent.call_llm` and `LLMCallAgent.call` -- same pattern implemented twice.
- 2. Identically-named but unrelated hook event classes (`BeforeLLMCallEvent`, `AfterLLMCallEvent`, `TextDeltaEvent`, `ThinkingDeltaEvent`) exist in both `llm_call/hook_events.py` and `tool_loop/hook_events.py`, risking confusion.
- 3. `resolve_config_value` is not exported from `flowra.lib` despite `ConfigValue` being exported and external code needing to resolve it.
- 4. Sub-modules (`chat`, `llm_call`, `tool_loop`) exported in `__all__` as namespace objects is unusual and potentially redundant.
