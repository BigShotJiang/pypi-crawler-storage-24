# Structure Review: flowra.agent

## Package responsibility

Defines the agent programming model: agent base class, step decorator, control-flow actions, parameter binding markers, compilation of agent classes into runtime-ready definitions, hook/event system, execution context, interrupt support, persistence primitives, and service location.

## Per-file analysis

### model.py
- **Responsibility:** Defines all core data types for the agent model: AbstractAgent base, control-flow actions (GotoStep, GotoAgent, CallStep, CallAgent, Spawn, WhenAll, WhenAny, WhenN), sentinels (NoSpec, NoResult, NEW_SCOPE), metadata containers (AgentDefinition, AgentInstance, StepMeta, ChildOutput), protocols (CallStepHandler, CreateInstance), and type aliases (StepAction, StepResult, StepMethod, StepRef, AgentRef, AgentDefinitionRef).
- **Name accuracy:** ISSUE: The name `model.py` is generic. This file is really the type definitions / domain vocabulary for the agent subsystem. A name like `types.py` or `definitions.py` would better reflect that it contains dataclasses, protocols, type aliases, and sentinels -- not business logic. That said, `model` is an acceptable convention for "domain model," so this is a minor concern.
- **Cohesion:** ISSUE: This file bundles several distinct responsibilities: (1) sentinel types (NoSpec, NoResult, NEW_SCOPE), (2) control-flow action dataclasses (GotoStep, GotoAgent, CallStep, CallAgent, Spawn, WhenAll, WhenAny, WhenN), (3) agent definition metadata (AgentDefinition, StepMeta, AgentInstance), (4) helper functions for step/agent attribute tagging (get_step_tag, set_step_tag, set_agent_class, resolve_step_ref), and (5) type aliases. At ~310 lines it is the largest file in the package and holds many unrelated concepts. The tagging helpers (`get_step_tag`, `set_step_tag`, `set_agent_class`, `resolve_step_ref`) are internal implementation details used only by `step_decorator.py`, `agent.py`, and `compile.py` -- they could live in a private `_tags.py` module rather than alongside user-facing types. However, splitting model.py further is optional: the current organization is workable because everything is part of the same domain vocabulary.

### agent.py
- **Responsibility:** Provides the `Agent[S, R]` base class that users subclass to define agents; triggers compilation via `__init_subclass__`.
- **Name accuracy:** OK
- **Cohesion:** OK

### agent_arg.py
- **Responsibility:** Defines `Annotated` sentinel markers (`SPEC`, `SERVICE`) for agent constructor parameter binding.
- **Name accuracy:** OK
- **Cohesion:** OK

### step_arg.py
- **Responsibility:** Defines `Annotated` sentinel markers (`SPEC`, `CHILD`) for step method parameter binding.
- **Name accuracy:** OK
- **Cohesion:** OK

### step_decorator.py
- **Responsibility:** Implements the `@step` decorator and the `is_entry_step` helper.
- **Name accuracy:** OK
- **Cohesion:** OK

### compile.py
- **Responsibility:** Compiles an agent class (its `__init__`, `@step` methods, generic parameters) into an `AgentDefinition`, including parameter binding descriptors, type registry, and instance factory.
- **Name accuracy:** OK
- **Cohesion:** OK -- although the file is large (~1045 lines), all logic serves the single purpose of agent compilation.

### agent_registry.py
- **Responsibility:** Maintains a hierarchical name-to-definition mapping, resolving agent references (by name or type) at runtime.
- **Name accuracy:** OK
- **Cohesion:** OK

### agent_store.py
- **Responsibility:** Abstract interface for slot-based persistent storage used by agents.
- **Name accuracy:** OK
- **Cohesion:** OK

### stored_values.py
- **Responsibility:** Concrete slot types (`Scalar`, `AppendOnlyList`) with dirty-tracking for persistence.
- **Name accuracy:** OK
- **Cohesion:** OK

### service_locator.py
- **Responsibility:** Abstract interface for providing typed services to agent constructors.
- **Name accuracy:** OK
- **Cohesion:** OK

### execution_context.py
- **Responsibility:** Read-only execution metadata (`ExecutionContext`, `ExecutionFrame`, `AgentInfo`) describing the current position in the agent call stack, with navigation helpers.
- **Name accuracy:** OK
- **Cohesion:** OK

### hooks.py
- **Responsibility:** Event/hook system: `Event` envelope, `HookRegistry` for registering and emitting events, `HookProvider` protocol.
- **Name accuracy:** OK
- **Cohesion:** OK

### interrupt_token.py
- **Responsibility:** Interrupt abstraction: `InterruptToken` ABC, `InterruptedError` exception, `Interrupted` result dataclass.
- **Name accuracy:** OK
- **Cohesion:** OK

### interrupt_helpers.py
- **Responsibility:** Provides `with_interrupt`, a utility that wraps an async iterator to abort on `InterruptToken` signal.
- **Name accuracy:** OK
- **Cohesion:** OK

### timeout.py
- **Responsibility:** Built-in timeout agent (`TimeoutAgent`) and its public helper (`timeout()`), plus the `TimeoutExpired` result type.
- **Name accuracy:** OK
- **Cohesion:** ISSUE: This file contains a concrete agent implementation (`TimeoutAgent`) alongside a user-facing helper function (`timeout()`) and result type (`TimeoutExpired`). It is the only file in the package that defines a full agent. If more built-in utility agents are added, they would need their own files or a `builtins/` sub-package. For now this is fine since it is just one agent, but worth noting.

## Package-level issues

1. **Large surface area for a single package.** The package covers agent definition, compilation, registry, hooks, execution context, persistence, interrupts, and a built-in timeout agent. These are all related to "agent," but the package has 16 .py files and exports 43 names. If the package continues to grow, consider extracting sub-packages (e.g., `agent.hooks`, `agent.interrupt`, `agent.store`). Currently manageable but approaching the boundary.

2. **Internal dependency flow is clean.** The dependency DAG is acyclic at module level (ignoring the documented local-import in `compile.py` to break the `agent.py` <-> `compile.py` cycle, which is correctly handled). The flow is roughly: `service_locator` <- `model` <- `step_decorator`, `agent_arg`, `step_arg` <- `compile` <- `agent`; `execution_context` <- `hooks`; `interrupt_token` <- `interrupt_helpers`; `stored_values` (uses `_sentinel` from parent). No issues.

## Public API issues

1. **`__init__.py` exports `agent_arg` and `step_arg` as modules.** This is intentional (users write `agent_arg.SPEC`, `step_arg.CHILD`), but it also means `import flowra.agent` silently exposes the module objects themselves. This is actually the correct design -- the modules act as namespaces for marker constants. No issue.

2. **Internal helpers from `model.py` are not exported (correct).** Functions like `get_step_tag`, `set_step_tag`, `set_agent_class`, `resolve_step_ref` are not in `__all__`. Good.

3. **`TimeoutAgent` is not exported.** The `timeout.py` module's `__all__` includes `TimeoutAgent`, but the package `__init__.py` does not re-export it. `TimeoutAgent` is presumably registered internally by the runtime using the `TIMEOUT_AGENT_NAME` constant (also not exported). If users never need to reference `TimeoutAgent` directly, this is fine. However, `TIMEOUT_AGENT_NAME` being a non-exported module-level constant in `timeout.py` means the runtime must import directly from `flowra.agent.timeout` -- which couples the runtime to the internal file structure. Consider exporting `TIMEOUT_AGENT_NAME` or providing a registration function.

4. **`collect_dataclass_types` from `compile.py` is not exported but is in `compile.__all__`.** The function is listed in `compile.py`'s `__all__` but not re-exported from the package `__init__.py`. If it is only used internally (by the runtime for schema building), this is fine. If external users need it, it should be exported.

5. **`is_entry_step` from `step_decorator.py` is not exported.** Listed in `step_decorator.__all__` but not in the package `__init__.py`. Only used internally by `compile.py`. Correct.

## Summary
- Files reviewed: 15 (excluding `__init__.py`)
- Issues found: 4

1. **model.py cohesion (minor):** The file mixes user-facing domain types with internal tagging helpers (`get_step_tag`, `set_step_tag`, `set_agent_class`, `resolve_step_ref`). Consider extracting the tagging helpers into a private `_tags.py` module.
2. **timeout.py contains a concrete agent:** `TimeoutAgent` is a full agent implementation living alongside public API helpers. Fine for now but worth monitoring as more built-in agents are added.
3. **`TimeoutAgent` / `TIMEOUT_AGENT_NAME` not exported from package:** The runtime must import directly from `flowra.agent.timeout`, coupling it to the internal file structure. Consider exporting these or providing a registration mechanism.
4. **Large package surface area (43 exports, 16 files):** Currently manageable, but approaching the point where sub-packages would improve navigability.
