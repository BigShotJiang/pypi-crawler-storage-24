# Code Style Review: flowra.agent

## hooks.py

### Line 72: Rule 2 violation (`type: ignore` without exhausting alternatives)
**Current:**
```python
child.__handlers = {k: list(v) for k, v in self.__handlers.items()}  # type: ignore[attr-defined]
```
**Fix:**
Accept `handlers` as a private constructor parameter so no cross-instance name-mangled access is needed:
```python
def __init__(
    self,
    context: ExecutionContext | None = None,
    *,
    _handlers: dict[type, list[Callable[..., Any]]] | None = None,
) -> None:
    self.__context = context
    self.__handlers: dict[type, list[Callable[..., Any]]] = (
        {k: list(v) for k, v in _handlers.items()} if _handlers is not None else {}
    )
```
Then `with_context` becomes:
```python
def with_context(self, context: ExecutionContext) -> "HookRegistry":
    return HookRegistry(context=context, _handlers=self.__handlers)
```
**Reason:** The `type: ignore` hides the fact that name-mangled `__handlers` is being accessed on a different instance (`child`). Passing handlers through the constructor avoids the mangled-name access entirely.

## execution_context.py

### Line 93: Rule 4 violation (private method uses single underscore)
**Current:**
```python
def _find_frame(
    self,
    *,
    spec_type: type | None = None,
    agent_type: type[AbstractAgent] | None = None,
) -> ExecutionFrame | None:
```
**Fix:**
```python
def __find_frame(
    self,
    *,
    spec_type: type | None = None,
    agent_type: type[AbstractAgent] | None = None,
) -> ExecutionFrame | None:
```
Update callers on lines 69 and 83 from `self._find_frame(...)` to `self.__find_frame(...)`.
**Reason:** `_find_frame` is an internal implementation detail of `ExecutionContext`, not intended for subclass access (the class is a frozen dataclass). Private methods must use double underscore.

## compile.py

### Line 263: Rule 9 violation (local import)
**Current:**
```python
@classmethod
def __extract_generic_params(
    cls,
    agent_cls: type,
) -> tuple[frozenset[type] | None, frozenset[type] | None]:
    ...
    # Local import to break agent.py ↔ compile.py cycle:
    # Agent.__init_subclass__ calls compile_agent, and we need Agent
    # to identify the Agent[S, R] base among __orig_bases__.
    # Extracting the generic params in agent.py would duplicate introspection logic;
    # a local import is the lesser evil here.
    from .agent import Agent
```
**Fix:**
Move the generic-param extraction trigger into `agent.py` (which already imports from `compile`) and pass the `Agent` base class into `compile_agent` as an argument. For example:

In `agent.py`:
```python
from .compile import compile_agent

class Agent[S, R](AbstractAgent):
    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        ...
        subagents = getattr(cls, "__subagents__", None)
        cls.__agent_definition__ = compile_agent(cls, subagents, agent_base=Agent)
```
In `compile.py`, `__extract_generic_params` receives the `Agent` class as a parameter instead of importing it:
```python
@classmethod
def __extract_generic_params(
    cls,
    agent_cls: type,
    agent_base: type,
) -> tuple[frozenset[type] | None, frozenset[type] | None]:
    for base in getattr(agent_cls, "__orig_bases__", ()):
        origin = get_origin(base)
        if origin is agent_base:
            ...
```
**Reason:** Local imports indicate a circular dependency. The cycle can be broken by having `agent.py` (which already imports `compile`) pass the `Agent` base class as a parameter, eliminating the reverse import.

## model.py

### Line 218: Rule 6 violation (module-level helper when a class owns the logic)
**Current:**
```python
def _flatten_leaves(node: SpawnNode, out: list[SpawnChild]) -> None:
    match node:
        case CallStep() | CallAgent():
            out.append(node)
        case WhenAll(nodes=nodes) | WhenAny(nodes=nodes) | WhenN(nodes=nodes):
            for child in nodes:
                _flatten_leaves(child, out)
```
**Fix:**
Move into `Spawn` as a classmethod (to support recursive calls via `cls`):
```python
@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class Spawn:
    ...
    @classmethod
    def __flatten_leaves(cls, node: SpawnNode, out: list[SpawnChild]) -> None:
        match node:
            case CallStep() | CallAgent():
                out.append(node)
            case WhenAll(nodes=nodes) | WhenAny(nodes=nodes) | WhenN(nodes=nodes):
                for child in nodes:
                    cls.__flatten_leaves(child, out)
```
Update the call in `Spawn.__init__` (line 260) from `_flatten_leaves(root, flat)` to `Spawn.__flatten_leaves(root, flat)` (or use `type(self).__flatten_leaves(root, flat)` — though since `__init__` is not a classmethod, `Spawn` is acceptable here for a frozen dataclass not meant for inheritance).
**Reason:** `_flatten_leaves` is only used by `Spawn.__init__`. It should be a private method of `Spawn`, not a standalone module-level function.

## __init__.py

No violations.

## agent.py

No violations.

## agent_arg.py

No violations.

## agent_registry.py

No violations.

## agent_store.py

No violations.

## interrupt_token.py

No violations.

## interrupt_helpers.py

No violations.

## service_locator.py

No violations.

## step_decorator.py

No violations.

## step_arg.py

No violations.

## stored_values.py

No violations.

## timeout.py

No violations.

## Summary
- Files reviewed: 16
- Violations found: 4
- Breakdown by rule: Rule 2: 1, Rule 4: 1, Rule 6: 1, Rule 9: 1
