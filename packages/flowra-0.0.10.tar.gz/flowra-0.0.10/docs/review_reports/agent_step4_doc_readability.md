# Readability Review: flowra.agent

## First impression

The title and opening description immediately communicate what this package does: agents as step-based state machines with typed contracts. The quick start is minimal and effective -- it shows defining a single-step agent in ~15 lines, then executing it with the runtime. A first-time reader could write basic working code after reading just the quick start.

One minor issue: the file tree listing between the description and quick start is developer-oriented (module names, internal details like `compile.py`). A first-time user does not need to know the internal file layout before seeing a quick start. It slightly delays the "aha" moment.

## Flow issues

1. **`storage_key` explained before State management.** The `GotoStep` section (line ~170) introduces `storage_key` with values like `NEW_SCOPE` and references `Scalar`, `AppendOnlyList`, and the State management section. A reader encounters `storage_key` across `GotoStep`, `GotoAgent`, `CallStep`, `CallAgent` (four times) before reaching "State management" at line 500. This is a lot of forward-referencing. Consider either moving the `storage_key` explanation into the State management section with a brief mention and link in the control flow tables, or moving State management before Control flow.

2. **`CallStep` / `CallAgent` appear inside `Spawn` examples before being formally defined.** The `Spawn` section (line ~241) uses `CallAgent` and `CallStep` in code examples, but their field tables and explanations come later (line ~362). A reader seeing `CallAgent(agent=WorkerAgent, spec=TaskSpec(id=1), tag="worker")` for the first time may wonder what `tag` does before it is explained.

3. **`Interrupted` used in `Spawn` / `WhenAny` section before being defined.** Line ~288 says "Interrupted children return `Interrupted()` as their result" but `Interrupted` is not defined until line ~709. The concept is important for understanding `WhenAny` semantics, but the reader has no context yet.

## Forward references

1. **`GotoStep`, `GotoAgent`, `Spawn`** are mentioned in the opening description (line 5) before any definition. Acceptable since they are immediately explained in "Control flow."

2. **`Scalar`, `AppendOnlyList`** — referenced in `storage_key` explanation (line 171) and child state behavior table (line 412), well before "State management" (line 500).

3. **`NEW_SCOPE`** — used in `GotoStep` examples (line 199) and explained only as "a sentinel value that forces a fresh storage scope" (line 214). What "fresh storage scope" means is not clear until State management is read.

4. **`step_arg.CHILD("tag")`** — referenced at line 359 in the `timeout` section and at line 388 in `CallAgent`, before "Step parameter injection" at line 828.

5. **`Interrupted()`** — mentioned in `Spawn` semantics (line 289) and `timeout` (line 342), defined at line 709.

6. **`ExecutionContext`** — mentioned in `Event` description (line 940) and immediately defined (line 943). This one flows well.

7. **`StepMethod`** — appears in the `StepRef` type alias (line 1054) but is never defined or explained. A reader does not know what `StepMethod` is.

8. **`AbstractAgent`** — appears in `GotoAgent` field table (line 223), `AgentRef` alias (line 1055), and `AgentInfo` (line 973), but is never introduced. The reader only knows about `Agent[S, R]`.

## Missing explanations

1. **How does the runtime actually run agents?** The quick start shows `AgentRuntime(agents={"greeter": Greeter})` and `runtime.run(...)`, but the doc never explains what happens at runtime — how steps are dispatched, how persistence works end-to-end, what "step boundaries" are in practice. This is presumably in the runtime docs, but a brief conceptual overview (even 2-3 sentences) would help the reader build a mental model.

2. **What is `AgentDefinition`?** Line 62 mentions "compiles them into an `AgentDefinition` (stored as `cls.__agent_definition__`)" but never explains what this is or why a user would care. If it is internal, it should not be mentioned. If it is useful, it needs context.

3. **Why dataclass-only constraint?** The section at line 145 states all specs and results must be dataclasses but does not explain why. A brief motivation (e.g., "required for serialization/persistence") would help.

4. **What is `HookProvider` as a protocol?** Line 1012 says "Implement the `register_hooks` method" but the example class `LoggingHooks` does not inherit from `HookProvider`. Is it a protocol? An ABC? Does the class need to inherit from it?

5. **`propagate_to` direction is ambiguous.** Line 1041 shows `parent_hooks.propagate_to(child_hooks)`. Does this mean "forward events from parent to child" or "forward events emitted on child to parent"? The prose says "Forward events from one registry to another" which does not clarify direction. Reading the code comment "forward all events" alongside the method name suggests parent events go to child, but the use case description ("observe child agent events") suggests the opposite.

6. **`ToolLoopAgent.start`** is referenced at line 567 as an example of the flush pattern, but this is an internal implementation detail that a user cannot look up from the docs alone.

## Example gaps

1. **`ServiceLocator.services` property** — documented in the table (line 632) but no example shows accessing `services` directly. When would a user read from it vs. using constructor injection?

2. **Step tag overriding via inheritance** — mentioned at line 89-91 ("A child can override a step by defining a new method with the same `@step` tag") but no code example demonstrates this.

3. **`propagate_to` with `only` / `exclude`** — examples are shown (line 1041-1043) but are minimal one-liners. No example shows a realistic scenario of why you would filter events.

4. **`NoSpec` / `NoResult`** — the examples at line 97-104 show method signatures with `...` bodies but do not show how to invoke such agents (e.g., what spec do you pass to `AgentRuntime.run` for a `NoSpec` agent?).

## Clarity issues

1. **"Agents are always black boxes"** (line 238) — this sentence appears without prior setup of the "black box" concept. It would be clearer as: "You cannot target a specific step inside another agent — `GotoAgent` always enters through the entry step."

2. **"Copy of parent's state — mutations do not affect the parent"** (line 408) — the term "parent" here means the spawning agent, but "parent" is also used for class inheritance (line 89) and registration hierarchy (line 966). This overloading could confuse readers.

3. **`event.context` vs `ctx`** — in the ExecutionContext example (lines 990-1003), the code switches from `event.context` to `ctx` on line 997 without assigning `ctx = event.context`. This looks like a bug in the example.

4. **"the engine catches it per-node"** (line 667-668) — "per-node" is not a term used elsewhere in the doc. The reader knows about agents, steps, and children, but not "nodes."

5. **"auto-propagation"** (line 669, 751) — this term is used but the mechanism is only partially explained. Line 751 says "the interrupt auto-propagates — the parent also returns `Interrupted()`" but does not clarify what triggers this. Is it automatic? Does the parent step need to be running? A brief clarification would help.

6. **The `flush()` section** (line 559) uses `await self.store.flush()` in the example but the `AgentStore` method table (line 554) lists `flush()` without indicating it is async. Since the instructions say not to flag missing `async` annotations, I note only that the table says `flush()` while the example says `await self.store.flush()` — this inconsistency may confuse a reader checking the table.

7. **"Sealed" concept** (line 626-627) — introduced for `ServiceLocator` but the same concept applies to `AgentStore.slot()` (line 556). The "sealed" terminology is not used in the `AgentStore` section, creating inconsistency. The `AgentStore` section says "raises `RuntimeError`" while `ServiceLocator` says "raises an error" — different levels of specificity for the same pattern.

## Suggested reordering

1. **Move the file tree listing** (lines 8-22) to the end of the document or remove it. It is developer/contributor information, not user-facing.

2. **Consider moving State management before Control flow**, or at least before the `storage_key` explanation. Currently, `storage_key` is explained four times (in `GotoStep`, `GotoAgent`, `CallStep`, `CallAgent`) before the reader knows what stored values are. Alternative: explain `storage_key` once in a dedicated subsection within Control flow, with a forward link, rather than repeating the table four times.

3. **Move `CallStep` / `CallAgent` definitions before `Spawn`**, since `Spawn` examples use them extensively. Or at minimum, add a one-sentence introduction before the first `Spawn` example that mentions them.

4. **Move `Interrupted` closer to `Spawn` / `WhenAny`**, since interruption semantics are central to understanding combinators. Currently they are separated by ~400 lines (Spawn at ~241, Interrupted at ~709).

## Summary

- First impression: CLEAR
- Flow: HAS ISSUES
- Explanations: GAPS FOUND
- Examples: GAPS FOUND
- Clarity: ISSUES FOUND
