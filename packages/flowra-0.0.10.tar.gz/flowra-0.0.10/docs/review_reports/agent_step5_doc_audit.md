# Documentation Audit: flowra.agent

## Type/field consistency

### `GotoStep`
- Field `step`: documented as `str` in table — OK (constructor accepts `StepRef` but stored field is `str`, doc notes this)
- Field `spec`: documented as `Any | None`, default `None` — OK
- Field `storage_key`: documented as `str | NEW_SCOPE | None`, default `None` — OK
- All fields: OK

### `GotoAgent`
- Field `agent`: documented as `str | type[AbstractAgent]` — OK
- Field `spec`: documented as `Any | None`, default `None` — OK
- Field `storage_key`: documented as `str | NEW_SCOPE | None`, default `None` — OK
- All fields: OK

### `CallStep`
- Field `step`: documented as `str` — OK
- Field `spec`: documented as `Any | None`, default `None` — OK
- Field `storage_key`: documented as `str | NEW_SCOPE | None`, default `None` — OK
- Field `tag`: documented as `str | None`, default `None` — OK
- All fields: OK

### `CallAgent`
- Field `agent`: documented as `str | type[AbstractAgent]` — OK
- Field `spec`: documented as `Any | None`, default `None` — OK
- Field `storage_key`: documented as `str | NEW_SCOPE | None`, default `None` — OK
- Field `tag`: documented as `str | None`, default `None` — OK
- All fields: OK

### `Interrupted`
- Field `reason`: documented as `str | None`, default `None` — OK
- All fields: OK

### `ExecutionContext`
- Field `frame`: documented as `ExecutionFrame` — OK
- Field `stack`: documented as `tuple[ExecutionFrame, ...]` — OK
- All fields: OK

### `ExecutionFrame`
- Field `agent`: documented as `AgentInfo` — OK
- Field `spec`: documented as `Any` — actual type is `Any | None`, default `None` — **MISMATCH**: doc shows `spec: Any` in the dataclass rendering (line 963), but actual code is `spec: Any | None = None`
- Field `tag`: documented as `str | None` — OK
- All fields: OK

### `AgentInfo`
- Field `name`: documented as `str` — OK
- Field `path`: documented as `str` — OK
- Field `source_type`: documented as `type[AbstractAgent] | None` — OK
- Field `parent`: documented as `AgentInfo | None` — OK
- All fields: OK

### `Scalar[T]`
- All methods documented: `get`, `has_value`, `set`, `is_dirty`, `mark_clean`, `restore` — OK
- All methods: OK

### `AppendOnlyList[T]`
- All methods documented: `get_all`, `append`, `extend`, `get_unflushed`, `mark_clean`, `restore` — OK
- All methods: OK

### `AgentStore`
- Methods `slot` and `flush` — OK
- All methods: OK

### `ServiceLocator`
- Method `provide` and property `services` — OK
- All methods: OK

### `InterruptToken`
- Property `interrupted`, methods `check`, `wait` — OK
- All methods: OK

### `HookRegistry`
- Methods `on`, `has_handlers`, `add`, `emit`, `propagate_to` — OK
- Method `with_context`: exists in code but NOT documented in the method table — **MISSING** (mentioned in prose on line 1007 but not in the method table on lines 931-937)
- All other methods: OK

### `Event[T]`
- Field `data: T` — OK
- Field `context: ExecutionContext` — OK
- All fields: OK

## API consistency

1. **`propagate_to` — `only` and `exclude` described as "mutually exclusive"**: Doc line 1046 says "`only` and `exclude` accept lists of event types and are mutually exclusive." In the actual code (`hooks.py` lines 87-91), both can be provided simultaneously — `only` filters first, then `exclude` subtracts from the result. They are NOT mutually exclusive. — **MISMATCH**

2. **Step parameter injection "three sources" vs "two sources"**: Doc lines 831-835 list three sources of values for step parameters: (1) Step spec, (2) Agent spec, (3) Child outputs. Then line 853 says "Agent-level spec (S from Agent[S, R]) is NOT available in step parameters." The actual `__bind_step_args` in `compile.py` only checks `spec` (step-level) and `child_outputs` — there is no agent-spec source. The list of three sources is internally contradictory. — **MISMATCH**

All other APIs match.

## Import consistency

### Quick start example
- `from flowra.agent import Agent, step` — OK

### State management example
- `from flowra.agent import Agent, AgentStore, AppendOnlyList, Scalar, step` — OK

### Interrupt examples
- `from flowra.agent import Agent, InterruptToken, step` — OK
- `from flowra.agent import Agent, InterruptedError, InterruptToken, with_interrupt, step` — OK
- `from flowra.agent import Interrupted` — OK
- `from flowra.agent import InterruptToken, with_interrupt` — OK

### Hooks examples
- `from flowra.agent import HookRegistry` — OK
- `from flowra.agent import Event, HookProvider, HookRegistry` — OK

### Timeout example
- `from flowra.agent import timeout` — OK

### step_arg usage
- `from flowra.agent import step_arg` — OK (imported as module in `__init__.py`, in `__all__`)

All imports correct.

## Example correctness

### Example in "Quick start"
Correct.

### Example in "Quick start" (runtime usage)
- `from flowra.runtime import AgentRuntime` — cannot verify (outside audited package), assumed correct
- `AgentRuntime(agents={"greeter": Greeter})` and `runtime.run(agent=Greeter, spec=GreetSpec(name="World"))` — cannot verify runtime API
- Otherwise correct.

### Example in "Defining agents" (`MyAgent` with `GotoStep`)
- `GotoStep(step="process", spec=ProcessSpec(data=spec.value))` — uses string for `step`, correct
- Otherwise correct.

### Example in "Spawn — basic form"
Correct.

### Example in "Spawn — keyword form"
Correct.

### Example in "Spawn — combinator form"
Correct.

### Example in "WhenAll / WhenAny / WhenN — nested"
Correct.

### Example in "timeout"
Correct.

### Example in "CallStep / CallAgent"
Correct.

### Example in "Subagents"
Correct.

### Example in "State management — Creating slots"
Correct.

### Example in "flush()"
Correct.

### Example in "ServiceLocator"
Correct.

### Example in "Cooperative interrupts"
Correct.

### Example in "with_interrupt — racing async iterators"
Correct.

### Example in "Agent spec in constructor"
Correct.

### Example in "Step parameter injection" (union/alias)
Correct.

### Example in "HookProvider"
- `LoggingHooks` does not explicitly implement `HookProvider` protocol, but it duck-types it — correct usage.

### Example in "propagate_to"
- `parent_hooks.propagate_to(child_hooks)` — correct direction but note: the doc shows forwarding FROM parent TO child, which means events registered on parent get forwarded. This is consistent with the code.
- Correct.

### Example in "ExecutionContext"
- Line 997: `spec = ctx.get_spec(ResearchSpec)` uses variable `ctx` but the handler parameter is `event`. The `ctx` variable is never defined in the example. Should be `event.context.get_spec(ResearchSpec)`. — **ERROR**

## Completeness

### Symbols in `__all__` but not in docs

The following are in `__init__.py.__all__` but not explicitly documented. Per the audit instructions, only flagging symbols a user would actually need:

- `AbstractAgent` — mentioned in type aliases (`AgentRef = str | type[AbstractAgent]`) and in `AgentInfo.source_type`, but not explained as a standalone concept. Users inherit from `Agent`, not `AbstractAgent` directly. Not flagged — internal base class.
- `AgentDefinition` — internal compile output. Not flagged.
- `AgentDefinitionRef` — internal type alias. Not flagged.
- `AgentInstance` — internal bridge type. Not flagged.
- `AgentRegistry` — used by the runtime to resolve agents. Not flagged — runtime internal.
- `ResolvedAgent` — return type of `AgentRegistry.resolve`. Not flagged — runtime internal.
- `CallStepHandler` — internal protocol. Not flagged.
- `ChildOutput` — internal bridge type. Not flagged.
- `CreateInstance` — internal protocol. Not flagged.
- `NEW_SCOPE` — documented in storage_key tables. OK.
- `StepMeta` — internal compile output. Not flagged.
- `StepMethod` — documented in type aliases section. OK.
- `StepRef` — documented in type aliases section. OK.
- `AgentRef` — documented in type aliases section. OK.
- `SpawnChild` — documented in type aliases section. OK.
- `SpawnNode` — documented in type aliases section. Not explicitly in the type aliases table but used implicitly. Minor.

None.

### Symbols in docs but not in `__all__`

- `TimeoutAgent` — mentioned in the file tree but not importable from `flowra.agent` (not in `__init__.py.__all__`). However, doc does not tell users to import it, just references it in the file listing. Not flagged.
- `step_arg.SPEC`, `step_arg.CHILD` — accessed via `step_arg` module which IS exported. OK.
- `agent_arg.SPEC`, `agent_arg.SERVICE` — accessed via `agent_arg` module which IS exported. OK.

None.

## Behavioral accuracy

1. **`propagate_to` — "mutually exclusive" claim**: As noted in API consistency, the doc says `only` and `exclude` are mutually exclusive, but the code allows both simultaneously. — **INACCURATE**

2. **Step parameter injection "three sources"**: As noted in API consistency, the doc lists "Agent spec" as a binding source for step parameters, then contradicts this in a Note. The actual code only has two sources (step spec and child outputs). The initial list of three sources is inaccurate. — **INACCURATE**

3. **`ExecutionFrame.spec` type in dataclass rendering**: The doc renders the field as `spec: Any` (line 963) but the actual code has `spec: Any | None = None`. The `| None` and default are missing. — **INACCURATE**

All other descriptions accurate.

## Summary

- Type/field mismatches: 2 (`ExecutionFrame.spec` type/default, `HookRegistry.with_context` missing from table)
- API mismatches: 2 (`propagate_to` mutually exclusive claim, step injection three-sources contradiction)
- Import errors: 0
- Example errors: 1 (undefined `ctx` variable in ExecutionContext example)
- Undocumented symbols: 0
- Inaccurate descriptions: 3 (`propagate_to` mutually exclusive, three-sources list, `ExecutionFrame.spec` rendering)
- Total issues: 8
