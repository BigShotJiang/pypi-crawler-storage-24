# Readability Review: flowra.lib

## First impression

The title and one-line description are clear: this package provides high-level agents for LLM interactions, built on lower-level packages. The bullet list of main components gives a good overview of what is available.

The quick start example is ambitious — it demonstrates a multi-turn chat with a tool, which requires imports from five different packages (`flowra.lib`, `flowra.lib.chat`, `flowra.llm`, `flowra.runtime`, `flowra.tools`). For a first-time reader, this is a lot of surface area. The example also references `eval_expression` without defining it, which would prevent a user from actually running the code. That said, the structure is understandable: create a provider, register tools, build a config, create a runtime, run in a loop.

Could a new user write basic working code after reading the quick start? Probably yes for the overall pattern, but they would need to already understand `AgentRuntime`, `ToolRegistry`, and `LLMProvider` from other packages. The quick start does not explain these — it assumes familiarity with the runtime layer.

## Flow issues

1. **ChatAgent before ToolLoopAgent.** The documentation presents `ChatAgent` (section 2) before `ToolLoopAgent` (section 3), but the ChatAgent section says "the agent delegates to ToolLoopAgent for the LLM interaction." A reader encounters references to `ToolLoopAgent`, `ToolLoopSpec`, and `ToolLoopConfig` in the ChatAgent section before those concepts are defined. Since ChatAgent is a higher-level wrapper around ToolLoopAgent, presenting ToolLoopAgent first would follow the simple-to-complex progression better.

2. **"Prompt caching" section appears between "Hooks" and "Tool services."** Caching is a configuration concern tied to `CacheConfig` (a field on `ToolLoopConfig` and `ChatConfig`). It would read more naturally immediately after the config tables, or at the end as an advanced topic. Its current position between hooks and tool services breaks the flow of the agent lifecycle narrative.

3. **"Cache strategy protocols" at the very end** feels orphaned. It is a brief code block with no prose explanation, separated from the "Prompt caching" section by two other sections ("Tool services" and "Agents as tools"). If a reader is learning about caching, they have to jump to the bottom of the document for the protocol signatures.

## Forward references

1. **`ToolLoopAgent` in the ChatAgent section** — "the agent delegates to ToolLoopAgent for the LLM interaction" appears before ToolLoopAgent is introduced.

2. **`ToolLoopSpec` and `ToolLoopConfig` in the ChatAgent section** — `ChatConfig` is described in terms of its differences from `ToolLoopConfig` ("ChatConfig differs from ToolLoopConfig in one key way"), but `ToolLoopConfig` has not been defined yet.

3. **`ConfigValue` in the ChatConfig table** — "All fields accept `ConfigValue[T]`" with a forward reference "(see ConfigValue below)." The type appears in both ChatConfig and ToolLoopConfig tables before it is explained.

4. **`CacheConfig` and `CACHE_MANUAL`** — appear in config tables before the "Prompt caching" section explains them.

5. **`HookRegistry` and `Event[T]`** — the Hooks section says these come from `flowra.agent` and links to `agent.md`, but a reader of this document alone has no context for what `Event[T]` means or how the handler signature works. The `e.data.request` pattern in hook handler lambdas is not explained.

6. **`context` field in hook events table** — many events mention `context` but the table does not explain what type it is. `ToolLoopAgentContext` is only introduced later in "Tool services."

## Missing explanations

1. **`turn_messages` vs `session_messages`** — The `ToolLoopConfig` section says "turn_messages are accumulated during the current run" but `turn_messages` does not appear anywhere in the config or spec. It is an internal concept used in the description but never surfaced as something the user sets or reads. The distinction is important for understanding caching strategies (`cache_last_session_message` vs `cache_last_message`), but the relationship is not fully explained.

2. **How `metadata` flows through the system** — `ChatSpec.metadata` is "passed through to ToolLoopSpec and delivered to MessageAcceptedEvent — useful for tracking message IDs in interrupt scenarios." This is quite terse. What are "interrupt scenarios"? How would a user use message IDs for tracking? A sentence or two more would help.

3. **`InterruptedError` and `InterruptToken`** — These appear in the loop description ("raises InterruptedError if signaled") and in tool services, but the documentation never explains how interrupts are signaled in the first place. How does a user trigger an interrupt? The concept of `interrupt.check()` is shown in a tool example but the setup is missing.

4. **`context.request_finish()`** — mentioned in the loop description (step 3: "checks finish request") before the `ToolLoopAgentContext` section explains it. A brief forward hint would help.

5. **`AgentDefinition`** — mentioned in the `make_agent_tool` section ("It also accepts AgentDefinition instead of a class") without any explanation of what AgentDefinition is or when you would have one instead of a class.

6. **`StopReason` values** — `ToolLoopResult` has a `stop_reason` field, and the loop description mentions `END_TURN`, `MAX_TOKENS`, `STOP_SEQUENCE`, `SCHEMA_VALIDATION_FAILED`, but it is not stated where `StopReason` is defined or what its full set of values is.

7. **`ToolCallAgentContext` vs `ToolLoopAgentContext`** — Both are introduced as things tools can request. The naming is very similar. The doc does not clarify the relationship between them or when you would use one vs the other.

## Example gaps

1. **No example for `max_consecutive_errors`** — described in prose but no code showing what happens when errors accumulate.

2. **No example for custom cache strategies** — the "Cache strategy protocols" section shows protocol signatures but no example of implementing a custom strategy.

3. **No example for `allowed_tools` / `denied_tools`** — described with wildcard patterns but no code showing usage.

4. **No example for `ResultMessageEvent` with `continue_messages`** — this is a powerful mechanism (force the loop to continue after END_TURN) but only described in the hook table.

5. **No example for `json_schema` config field** — mentioned in both ChatConfig and ToolLoopConfig but never demonstrated.

6. **No example for `make_agent_tool` with `AgentDefinition`** — the alternative form is mentioned but not shown.

## Clarity issues

1. **"Flushes state (for crash recovery)"** in the loop description (Step 1) — this is unexplained. What state? What crash recovery mechanism? This appears only once and is never elaborated.

2. **"fires on resume too"** for `MessageAcceptedEvent` — resume of what? This implies some persistence/recovery mechanism that is never described in this document.

3. **`e.data.text` vs `e.data.request`** — the hook examples access event data through `e.data.*` but this pattern is never explained. A reader must infer that `e` is an `Event[T]` wrapper with a `data` property containing the typed payload.

4. **"observation-only"** — used for several hook events without defining the term. It presumably means the handler cannot influence the flow by mutating fields, but that could be stated explicitly once.

5. **"Mutable fields" column in hook events table** — the table header says "Mutable fields" but the concept of mutable vs immutable event data is never explained. A reader must infer that listed fields can be modified to influence behavior, while unlisted fields (or events with "---") are read-only.

6. **The sentence** "When a slot is `None`, user-provided `cache` hints are preserved as-is" — what are "user-provided cache hints"? The concept of `cache=True` on blocks and tools has not been introduced in this document. A reader who has not read the `flowra.llm` docs would not know what this means.

7. **`CACHE_MANUAL` as default** — appears in config tables as the default for `cache_strategy`, but is only explained later in the Presets section. The name "MANUAL" is not self-explanatory; the reader must scroll down to learn it means "preserve user-provided hints as-is."

## Suggested reordering

Proposed order:

1. **Quick start** (keep as-is)
2. **LLMCallAgent** (simplest agent, good starting point)
3. **ToolLoopAgent** (move before ChatAgent, since ChatAgent depends on it)
4. **Hooks** (move immediately after ToolLoopAgent, since they are part of the loop lifecycle)
5. **ChatAgent** (now can freely reference ToolLoopAgent and hooks)
6. **Prompt caching** + **Cache strategy protocols** (merge into one section; an advanced configuration topic)
7. **Tool services** (how tools receive dependencies)
8. **Agents as tools** (advanced composition pattern)
9. **ConfigValue** (reference-style section, could stay near the end)

This reordering eliminates forward references to ToolLoopAgent/ToolLoopConfig from ChatAgent, keeps caching discussion together, and follows a clear simple-to-complex progression.

## Summary

- First impression: NEEDS WORK — quick start has an undefined function and requires cross-package knowledge without guidance
- Flow: HAS ISSUES — ChatAgent before ToolLoopAgent creates forward references; caching is split across distant sections
- Explanations: GAPS FOUND — interrupts, crash recovery, turn_messages vs session_messages, and several concepts lack sufficient context
- Examples: GAPS FOUND — several config options and hook patterns described only in prose
- Clarity: ISSUES FOUND — unexplained jargon ("observation-only", "flushes state", "resume"), event data access pattern not introduced
