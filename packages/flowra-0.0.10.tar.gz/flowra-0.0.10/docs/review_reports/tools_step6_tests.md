# Test Review: flowra.tools

## Part 1: Test quality

### test_local_tool.py

#### TestToolDecorator

##### test_basic_with_docstring (line 43)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies decorator extracts name and docstring
- **Structure:** OK
- **Verdict:** KEEP

##### test_explicit_description (line 53)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies explicit description overrides docstring
- **Structure:** OK
- **Verdict:** KEEP

##### test_no_docstring_no_description_raises (line 61)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies error path
- **Structure:** OK
- **Verdict:** KEEP

##### test_invalid_name_raises (line 68)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies name validation regex
- **Structure:** OK
- **Verdict:** KEEP

##### test_missing_type_annotation_raises (line 75)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies error path for unannotated params
- **Structure:** OK
- **Verdict:** KEEP

#### TestGetLocalTool

##### test_on_decorated (line 84)
- **Name accuracy:** OK
- **Meaningfulness:** TRIVIAL — only checks `isinstance`, doesn't verify any behavior beyond the return type. However, this is the happy-path complement to `test_on_undecorated_raises` and the actual behavior (extracting fields) is tested elsewhere, so it provides marginal value.
- **Structure:** OK
- **Verdict:** KEEP (borderline, but pairs with the error test)

##### test_on_undecorated_raises (line 92)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies error path
- **Structure:** OK
- **Verdict:** KEEP

#### TestBindingHeuristic

##### test_single_dataclass_is_input (line 104)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies heuristic: lone dataclass becomes input
- **Structure:** OK
- **Verdict:** KEEP

##### test_no_params_empty_schema (line 115)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies no-param tools get None schema
- **Structure:** OK
- **Verdict:** KEEP

##### test_non_dataclass_is_service (line 124)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies heuristic: non-dataclass becomes service
- **Structure:** OK
- **Verdict:** KEEP

##### test_multiple_dataclasses_without_marker_raises (line 133)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies ambiguity error
- **Structure:** OK
- **Verdict:** KEEP

##### test_unsupported_param_type_raises (line 144)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies generic types (e.g. `list[str]`) are rejected
- **Structure:** OK
- **Verdict:** KEEP

#### TestExplicitMarkers

##### test_tool_input_marker (line 153)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies INPUT marker selects the input param when two dataclasses exist
- **Structure:** OK
- **Verdict:** KEEP

##### test_tool_input_on_second_param (line 167)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies parameter order doesn't matter for INPUT marker
- **Structure:** OK
- **Verdict:** KEEP

##### test_tool_service_marker (line 181)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies SERVICE marker
- **Structure:** OK
- **Verdict:** KEEP

##### test_tool_input_and_tool_service (line 191)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies both markers together
- **Structure:** OK
- **Verdict:** KEEP

##### test_tool_service_without_tool_input_heuristic_still_works (line 208)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies SERVICE marker coexists with input heuristic
- **Structure:** ISSUE — nearly identical to `test_tool_service_marker` (line 181). Both define `fetch` with `SearchParams` + `MyService` annotated with SERVICE. The difference is subtle (first has explicit marker, second is identical).
- **Verdict:** KEEP (documents a specific edge case, but overlaps heavily with test_tool_service_marker)

##### test_multiple_tool_input_raises (line 218)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies error path for duplicate INPUT markers
- **Structure:** OK
- **Verdict:** KEEP

##### test_tool_input_on_non_dataclass_raises (line 231)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_marker_instance_also_works (line 238)
- **Name accuracy:** STALE — name says "instance also works" but it uses the same `tool_arg.INPUT` sentinel as every other test. There is no "instance" vs "class" distinction. This test is a duplicate of `test_tool_input_marker` minus the second dataclass.
- **Meaningfulness:** OK (validates the simple one-param + marker case)
- **Structure:** OK
- **Verdict:** FIX — rename to something like `test_single_param_with_input_marker`

#### TestSchemas

##### test_input_schema_from_dataclass (line 253)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies schema shape, required fields
- **Structure:** OK
- **Verdict:** KEEP

##### test_output_schema_from_dataclass (line 266)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_output_schema_none_for_non_dataclass (line 277)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestHandlerExecution

##### test_sync_tool (line 291)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies sync handler execution and result serialization
- **Structure:** OK
- **Verdict:** KEEP

##### test_async_tool (line 302)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_no_params (line 312)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_service_injection (line 322)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_params_and_service (line 332)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_explicit_markers_execution (line 342)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies runtime behavior with both markers
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dataclass_to_json (line 356)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dict_to_json (line 366)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_str_passthrough (line 376)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_other_to_str (line 386)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_bool_to_str (line 396)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_list_primitives_to_json (line 406)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_list_dict_to_json (line 416)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_list_dataclass_to_json (line 426)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dict_with_uuid (line 436)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `_JSONEncoder` handles UUID
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dict_with_decimal (line 448)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dict_with_datetime (line 458)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dict_with_date (line 468)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_result_dict_with_time (line 478)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestServiceOptional

##### test_required_service_missing_raises (line 493)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_required_service_provided (line 503)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_optional_service_missing_gets_none (line 513)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_optional_service_provided (line 523)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_optional_service_with_annotated_marker (line 533)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies Annotated + Optional + SERVICE marker
- **Structure:** OK
- **Verdict:** KEEP

##### test_optional_service_with_marker_provided (line 543)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestInputValidation

##### test_invalid_input_raises_validation_error (line 558)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies jsonschema validation on input
- **Structure:** OK
- **Verdict:** KEEP

### test_tool_group.py

#### TestLocalToolGroup

##### test_create_with_prefix (line 26)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_create_without_prefix (line 33)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_undecorated_handler_raises (line 38)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_duplicate_tool_names_raises (line 45)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `LocalToolGroup.__post_init__` duplicate check
- **Structure:** OK
- **Verdict:** KEEP

#### TestMcpToolGroup

##### test_basic (line 51)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies default values
- **Structure:** OK
- **Verdict:** KEEP

##### test_with_prefix (line 56)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_with_headers (line 60)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_tool_registry.py

#### TestLocalTools

##### test_no_prefix (line 97)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_with_prefix (line 102)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_duplicate_raises (line 107)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_same_name_different_prefix_ok (line 113)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_bare_local_tool_as_source (line 119)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `LocalTool` (not wrapped in group) works as source
- **Structure:** OK
- **Verdict:** KEEP

##### test_bare_local_tool_duplicate_with_group_raises (line 124)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_tool_definition_fields (line 130)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestGetLlmTools

##### test_converts_to_llm_tools (line 144)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies conversion to LLM Tool objects
- **Structure:** OK
- **Verdict:** KEEP

##### test_preserves_output_schema (line 156)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_output_schema_none_for_non_dataclass_return (line 172)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_with_prefix (line 178)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestOrder

##### test_order_matches_input (line 189)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_order_reversed (line 196)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_mixed_local_and_mcp_order (line 203)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies ordering across source types
- **Structure:** OK
- **Verdict:** KEEP

#### TestMcpDuplicates

##### test_mcp_duplicate_with_local_ignored (line 218)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies first-wins duplicate handling, local takes priority
- **Structure:** OK
- **Verdict:** KEEP

##### test_mcp_duplicate_with_mcp_ignored (line 232)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_mcp_different_prefixes_no_conflict (line 247)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_mcp_same_prefix_different_tools (line 259)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_mcp_same_prefix_duplicate_tools (line 273)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestMcpCallback

##### test_callback_rebuilds_registry (line 294)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies dynamic tool list update
- **Structure:** OK
- **Verdict:** KEEP

##### test_callback_new_duplicate_ignored (line 307)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestContextManager

##### test_close_called (line 330)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies close propagates to MCP connections
- **Structure:** OK
- **Verdict:** KEEP

##### test_async_with (line 338)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `async with` calls close
- **Structure:** OK
- **Verdict:** KEEP

#### TestExecute

##### test_local_tool (line 351)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_local_tool_no_args (line 358)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_local_tool_with_prefix (line 364)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_unknown_tool (line 370)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies error handling for unknown tool
- **Structure:** OK
- **Verdict:** KEEP

##### test_local_tool_error (line 377)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies exception handling returns ToolResult with is_error
- **Structure:** OK
- **Verdict:** KEEP

##### test_mcp_tool (line 389)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_mcp_tool_error (line 398)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_local_tool_with_services (line 410)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies services dict is passed through
- **Structure:** OK
- **Verdict:** KEEP

##### test_callbacks_removed_on_close (line 425)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies cleanup
- **Structure:** OK
- **Verdict:** KEEP

### test_mcp_connection.py

#### TestGetTools

##### test_returns_cached_tools (line 53)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_excludes_removed_tools (line 62)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies tool removal via invalid params error
- **Structure:** OK
- **Verdict:** KEEP

##### test_returns_empty_when_no_tools (line 91)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestCallTool

##### test_returns_error_for_unknown_tool (line 100)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_calls_server_and_returns_result (line 108)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_returns_tool_execution_error (line 131)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies isError=True from server doesn't remove tool (no "unknown tool" pattern)
- **Structure:** OK
- **Verdict:** KEEP

##### test_unknown_tool_in_call_result_removes_tool (line 149)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_handles_jsonrpc_error_invalid_params (line 170)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies -32602 error code triggers tool removal
- **Structure:** OK
- **Verdict:** KEEP

##### test_non_invalid_params_error_does_not_remove_tool (line 185)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies other error codes don't remove tools
- **Structure:** OK
- **Verdict:** KEEP

##### test_returns_error_for_removed_tool (line 197)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies subsequent call to removed tool returns error without hitting server
- **Structure:** OK
- **Verdict:** KEEP

##### test_passes_empty_dict_for_none_arguments (line 212)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `None` args become `{}`
- **Structure:** OK
- **Verdict:** KEEP

#### TestConnect

##### test_connect_initializes_and_fetches_tools (line 235)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies full handshake sequence
- **Structure:** OK — slightly long but tests one multi-step protocol sequence
- **Verdict:** KEEP

#### TestBackgroundRefresh

##### test_removed_tools_cleared_after_refresh (line 295)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies background refresh clears removed tools and updates tool list
- **Structure:** ISSUE — relies on `asyncio.sleep(0.1)` which is timing-sensitive. May be flaky under load.
- **Verdict:** KEEP (but fragile)

#### TestMultiBlockContent

##### test_multiple_text_blocks_joined_with_newline (line 325)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

##### test_non_text_block_serialized_as_str (line 346)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### TestSseResponses

##### test_sse_response_parsed (line 367)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies SSE content-type triggers SSE parsing
- **Structure:** OK
- **Verdict:** KEEP

#### TestReconnect

##### test_reconnect_on_http_error_then_retry_succeeds (line 394)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies full reconnect flow: HTTP 500 -> handshake -> retry -> success
- **Structure:** OK
- **Verdict:** KEEP

##### test_reconnect_fails_returns_unavailable (line 433)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies reconnect failure returns "temporarily unavailable"
- **Structure:** OK
- **Verdict:** KEEP

#### TestContextManager

##### test_async_context_manager (line 453)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies `__aenter__` returns self
- **Structure:** OK
- **Verdict:** KEEP

## Part 2: Coverage analysis

### Public API coverage

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `LocalTool` | YES | construction via `@tool`, handler execution (sync/async), result formatting, schema derivation |
| `LocalToolGroup` | YES | creation with/without prefix, duplicate detection, via `create_local_tool_group` |
| `McpConnection` | YES | connect handshake, call_tool (success/error/unknown/removed), get_tools, reconnect, SSE, background refresh, close, context manager |
| `McpToolGroup` | YES | construction with prefix/headers/url |
| `ToolDefinition` | YES | used extensively throughout tests as a data carrier |
| `ToolExecutionContext` | YES | constructed and used in handler execution tests |
| `ToolGroup` | YES | type alias — both `LocalToolGroup` and `McpToolGroup` are tested |
| `ToolHandler` | YES | type alias — exercised via handler execution tests |
| `ToolRegistry` | YES | create, get_tools, get_llm_tools, execute (local/mcp/unknown/error), close, context manager, callback rebuild, duplicate handling, ordering |
| `ToolResult` | YES | used extensively, content and is_error fields verified |
| `ToolSource` | YES | type alias — both `ToolGroup` and `LocalTool` as sources tested |
| `create_local_tool_group` | YES | with/without prefix, undecorated handler error, duplicate names |
| `get_local_tool` | YES | on decorated, on undecorated |
| `tool` | YES | decorator behavior, name/description, binding, schemas, execution |
| `tool_arg` | YES | `INPUT` and `SERVICE` markers used in explicit marker tests |

### Integration tests

Good integration coverage exists:
- `test_tool_registry.py` serves as an integration test file, combining `LocalTool`, `LocalToolGroup`, `McpToolGroup` (mocked), and `ToolRegistry`.
- Tests verify the full flow from tool decoration through registry creation to execution.
- Mixed local + MCP source ordering is tested.
- Callback-driven registry rebuild is tested.

### E2E tests

None found. `McpConnection` interacts with external MCP servers over HTTP. There are no E2E tests with a real MCP server. The `_build_connection` helper with `httpx.MockTransport` provides good unit-level coverage. E2E tests with a real MCP server would be valuable but are not critical given the thorough mocking.

### Missing test scenarios

1. **`_format_result` with empty list:** `_format_result([])` follows the `isinstance(result, list)` branch but the `result and dataclasses.is_dataclass(result[0])` check short-circuits. Should verify it returns `"[]"`.

2. **`_format_result` with `None` return:** If a tool handler returns `None`, `_format_result` falls through to `str(result)` returning `"None"`. No test verifies this edge case.

3. **`_unwrap_optional` with `Optional[X]` syntax:** Tests only use `X | None` syntax. The code also handles `Union[X, None]` (i.e., `Optional[X]`). A test with `Optional[MyService]` would verify this path.

4. **Input validation with extra fields:** `test_invalid_input_raises_validation_error` tests missing required fields. No test verifies behavior with extra unexpected fields in input (jsonschema may allow or reject them depending on `additionalProperties`).

5. **`McpConnection.connect` failure path:** The test for `connect` only covers the success path. There is no test for `connect` when the `initialize` call returns an error or when `tools/list` returns an error during handshake.

6. **`McpConnection` SSE parsing edge cases:** Only one SSE test exists. Missing scenarios: SSE with multiple events where only one matches the request ID, SSE with no matching response (should raise `RuntimeError`), SSE with malformed JSON data lines.

7. **`McpConnection` background refresh with HTTP error triggers reconnect:** The `__background_refresh_loop` has a specific code path for `httpx.HTTPStatusError`/`httpx.HTTPError` that calls `__reconnect()`. This is not tested.

8. **`McpConnection` background refresh with `tools/list` returning an error:** The loop handles `"error" in tools_body` without updating tools. This path is untested.

9. **`McpConnection.add_on_tools_changed` / `remove_on_tools_changed`:** These are tested indirectly through `ToolRegistry`, but there is no direct test verifying that a registered callback fires when tools change, or that `remove_on_tools_changed` prevents future calls.

10. **`ToolRegistry.execute` with MCP tool that raises an exception:** `test_mcp_tool_error` tests a returned error result, but there is no test where `mcp_connection.call_tool` raises an exception (the `except Exception` branch in `execute`).

11. **`ToolRegistry` with empty sources list:** No test verifies `ToolRegistry.create([])` works correctly (should produce an empty registry).

12. **`McpConnection` reconnect on second call also fails:** `test_reconnect_fails_returns_unavailable` tests reconnect failure. But there is no test for: reconnect succeeds but the retry call also gets an HTTP error (returning "temporarily unavailable").

## Summary

- Test files reviewed: 4
- Individual tests reviewed: 67
- Tests to fix: 1 (naming: `test_marker_instance_also_works`)
- Tests to delete: 0
- Public symbols tested: 15 / 15
- Missing test scenarios: 12
