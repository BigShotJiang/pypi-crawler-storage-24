# Documentation Audit: flowra.tools

## Type/field consistency

### ToolDefinition
- Field `name`: `str`, no default — OK
- Field `description`: `str`, no default — OK
- Field `input_schema`: documented as `dict[str, Any] | None`, default `None` — OK
- Field `output_schema`: documented as `dict[str, Any] | None`, default `None` — OK
- All fields accounted for, no undocumented fields.

### ToolResult
- Field `content`: `str`, no default — OK
- Field `is_error`: `bool`, default `False` — OK
- All fields accounted for, no undocumented fields.

### ToolExecutionContext
- Field `input`: `dict[str, Any]`, no default — OK
- Field `services`: `dict[type, Any]`, no default — OK
- All fields accounted for, no undocumented fields.

### LocalTool
- Field `definition`: `ToolDefinition` — OK
- Field `handler`: `ToolHandler` — OK
- All fields accounted for, no undocumented fields.

### LocalToolGroup
- Field `prefix`: `str | None`, default `None` — OK
- Field `tools`: `list[LocalTool]`, no default — OK
- All fields accounted for, no undocumented fields.

### McpToolGroup
- Field `prefix`: `str | None`, default `None` — OK (code: `str | None = None`)
- Field `url`: `str`, default `""` — OK (code: `str = ""`)
- Field `headers`: `dict[str, str] | None`, default `None` — OK (code: `dict[str, str] | None = None`)
- All fields accounted for, no undocumented fields.

## API consistency

### `@tool` decorator
- Signature: `tool(name: str, description: str | None = None)` — docs say `name` and optional `description`, match.
- Docs say `ValueError` if no description and no docstring — code raises `ValueError`. OK.
- Docs say name must match `^[a-zA-Z0-9_-]+$` — code uses `_TOOL_NAME_RE.fullmatch(name)` with that pattern. OK.

### `get_local_tool`
- Signature: `get_local_tool(handler: Callable[..., Any]) -> LocalTool` — docs say "Extracts the `LocalTool` from a `@tool`-decorated function. Raises `ValueError` if the function is not decorated." Code raises `ValueError`. OK.

### `ToolHandler` type alias
- Documented: `Callable[[ToolExecutionContext], ToolResult | Awaitable[ToolResult]]` — code: identical. OK.

### `ToolGroup` type alias
- Documented: `LocalToolGroup | McpToolGroup` — code: identical. OK.

### `ToolSource` type alias
- Documented: `ToolGroup | LocalTool` — code: identical. OK.

### `create_local_tool_group`
- Docs show `create_local_tool_group([search, calculate], prefix="utils")` — code signature: `create_local_tool_group(handlers: list[Callable[..., Any]], *, prefix: str | None = None)`. OK.

### `ToolRegistry.create`
- Docs: `create(tool_sources)` — code: `create(cls, tool_sources: Sequence[ToolSource]) -> Self`. OK.
- Docs say duplicate local names raise `ValueError` — code `__validate_local_tools` does this. OK.
- Docs say MCP conflicts are logged and skipped — code `__build_registry` logs and continues. OK.

### `ToolRegistry.get_tools`
- Docs: `get_tools() -> list[ToolDefinition]` — code: returns `[entry.tool_definition for entry in self.__registry.values()]`. OK.

### `ToolRegistry.get_llm_tools`
- Docs: `get_llm_tools() -> list[Tool]` — code: converts to `flowra.llm.Tool` objects. OK.
- Docs say "Preserves `output_schema`" — code passes `output_schema=td.output_schema`. OK.

### `ToolRegistry.execute`
- Docs: `execute(name, args=None, *, services=None) -> ToolResult` — code signature matches. OK.
- Docs say exceptions are caught and returned as `ToolResult(content="Error: ...", is_error=True)` — code does this. OK.

### `ToolRegistry.close`
- Docs: "Removes MCP change callbacks and closes all connections." — code removes callbacks and calls `exit_stack.aclose()`. OK.

### `McpConnection.connect`
- Docs: `McpConnection.connect(url, headers)` — code: `connect(cls, url: str, headers: dict[str, str] | None = None) -> Self`. OK.

### `McpConnection.get_tools`
- Docs: `conn.get_tools()` returns `list[ToolDefinition]` — code confirms. OK.

### `McpConnection.call_tool`
- Docs: `conn.call_tool("search", {...})` returns `ToolResult` — code: `call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> ToolResult`. OK.

All APIs match.

## Import consistency

### Quick start example
- `from flowra.tools import ToolRegistry, create_local_tool_group, tool` — all three are in `__all__`. OK.

### `get_local_tool` example
- `from flowra.tools import get_local_tool, tool` — both in `__all__`. OK.

### Disambiguation example
- `from flowra.tools import tool, tool_arg` — both in `__all__`. OK.

All imports correct.

## Example correctness

### Example in "Quick start"
- `@tool("search")` on a function with `SearchParams` param and docstring — correct usage.
- `create_local_tool_group([search], prefix="kb")` — correct, `search` is a decorated callable.
- `async with await ToolRegistry.create([group]) as registry:` — correct, `create` is async and returns `Self` which implements `__aenter__`.
- `registry.get_tools()` returns `list[ToolDefinition]` — correct.
- `registry.execute("kb__search", {"query": "hello"})` — correct prefixed name, correct args.
- `result.content` and `result.is_error` — correct `ToolResult` fields.
- Correct.

### Example in "@tool decorator"
- `@tool("calculate", description="Evaluate a math expression")` — correct signature.
- Correct.

### Example in "get_local_tool"
- `get_local_tool(ping)` returns `LocalTool` — correct.
- Correct.

### Example in "Disambiguation"
- `Annotated[FetchParams, tool_arg.INPUT]` and `Annotated[ApiConfig, tool_arg.SERVICE]` — correct markers.
- Correct.

### Example in "Service injection"
- `registry.execute("fetch", {"path": "users"}, services={ApiClient: ApiClient(...)})` — correct signature.
- Correct.

### Example in "Optional services"
- `cache: CacheService | None` — correct pattern for optional service.
- Correct.

### Example in "LocalToolGroup"
- `LocalToolGroup(tools=[local_tool_1, local_tool_2], prefix="math")` — correct, `kw_only=True` so keyword args are required. Both fields used correctly.
- Correct.

### Example in "McpToolGroup"
- `McpToolGroup(url="...", prefix="google")` and `McpToolGroup(url="...", prefix="private", headers={...})` — correct field names and types.
- Correct.

### Example in "ToolRegistry"
- `async with await ToolRegistry.create([group1, group2]) as registry:` — correct pattern.
- Correct.

### Example in "McpConnection"
- `async with await McpConnection.connect(url, headers) as conn:` — correct, `connect` is async classmethod.
- `conn.get_tools()` and `conn.call_tool("search", {...})` — correct method names and signatures.
- Correct.

## Completeness

### Symbols in `__all__`:
1. `LocalTool` — documented
2. `LocalToolGroup` — documented
3. `McpConnection` — documented
4. `McpToolGroup` — documented
5. `ToolDefinition` — documented
6. `ToolExecutionContext` — documented
7. `ToolGroup` — documented
8. `ToolHandler` — documented
9. `ToolRegistry` — documented
10. `ToolResult` — documented
11. `ToolSource` — documented
12. `create_local_tool_group` — documented
13. `get_local_tool` — documented
14. `tool` — documented
15. `tool_arg` — documented

### Symbols in `__all__` but not in docs:
None.

### Symbols in docs but not in `__all__`:
None.

## Behavioral accuracy

- Docs: "A single dataclass parameter is treated as tool input (its fields become the JSON Schema)" — code in `_resolve_binding`: when no explicit `INPUT` marker, a single dataclass param becomes `_InputSource`. Accurate.
- Docs: "Multiple unmarked dataclass parameters raise `TypeError` at decoration time" — code at line 176-179 raises `TypeError`. Accurate.
- Docs: "description — taken from docstring if not passed explicitly (`ValueError` if neither is provided)" — code checks `func.__doc__`, raises `ValueError`. Accurate.
- Docs: "Duplicate tool names within a group raise `ValueError` at construction time" — `LocalToolGroup.__post_init__` checks and raises. Accurate.
- Docs: "MCP tool name conflicts are logged and skipped without raising (first registration wins)" — `__build_registry` logs error and `continue`s. Accurate.
- Docs: "Auto-reconnect on HTTP/connection errors (one retry)" — `call_tool` tries once, reconnects, retries once. Accurate.
- Docs: "Background refresh: event-driven with a 60-second fallback poll of `tools/list`" — `__background_refresh_loop` uses `asyncio.wait_for` with `_PERIODIC_REFRESH_TIMEOUT = 60.0` and `__refresh_event`. Accurate.
- Docs: "Tracks tool removals (`invalid_params` errors or 'unknown tool' responses)" — code checks `_INVALID_PARAMS` error code and `_UNKNOWN_TOOL_PATTERN` in content. Accurate.
- Docs: "`add_on_tools_changed()` / `remove_on_tools_changed()`" — both methods exist on `McpConnection`. Accurate.
- Docs: Return value serialization table for `list` says "if the first element is a dataclass, all elements are serialized field-by-field" — code checks `result[0]` and uses `mr.dump` on each. Accurate.

All descriptions accurate.

## Summary
- Type/field mismatches: 0
- API mismatches: 0
- Import errors: 0
- Example errors: 0
- Undocumented symbols: 0
- Inaccurate descriptions: 0
- Total issues: 0
