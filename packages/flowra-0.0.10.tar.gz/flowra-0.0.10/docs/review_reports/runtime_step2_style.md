# Code Style Review: flowra.runtime

## __init__.py

No violations.

## runtime_scope.py

No violations.

## execution.py

### Line 62: Rule 5 violation
**Current:**
```python
# ---------------------------------------------------------------------------
# Spawn tree: internal index-based tree for strategy evaluation
# ---------------------------------------------------------------------------
```
**Fix:**
Remove the comment block. The `SpawnTree*` class names and the `type SpawnTreeNode` alias make the purpose self-evident.
**Reason:** The comment restates what the class names already communicate. Section separators with restating comments add no information.

## interrupt.py

### Lines 9, 13-15: Rule 4 violation
**Current:**
```python
class _InterruptTokenImpl(InterruptToken):
    __slots__ = ("children", "event", "is_interrupted", "parent")

    def __init__(self) -> None:
        self.is_interrupted = False
        self.event = asyncio.Event()
        self.children: list[_InterruptTokenImpl] = []
        self.parent: _InterruptTokenImpl | None = None
```
**Fix:**
```python
class _InterruptTokenImpl(InterruptToken):
    __slots__ = ("__children", "__event", "__is_interrupted", "__parent")

    def __init__(self) -> None:
        self.__is_interrupted = False
        self.__event = asyncio.Event()
        self.__children: list[_InterruptTokenImpl] = []
        self.__parent: _InterruptTokenImpl | None = None
```
And update the `interrupted` property, `wait`, `set`, `clear` methods to use the mangled names. `InterruptTokenSource.create_child` and `dispose` currently reach into these fields cross-class; refactor them into methods on `_InterruptTokenImpl` itself (e.g., `add_child`, `remove_from_parent`).
**Reason:** These fields are implementation details of `_InterruptTokenImpl`, not intended for subclass access. They should be private (`__`). The cross-class access from `InterruptTokenSource` should be replaced with proper methods on `_InterruptTokenImpl`.

## serialization.py

No violations.

## _instance_factory.py

### Line 4: Rule 13 violation
**Current:**
```python
from ..agent.compile import collect_dataclass_types
```
**Fix:**
Export `collect_dataclass_types` from `flowra.agent.__init__.py` (add it to `__all__`), then:
```python
from ..agent import collect_dataclass_types
```
**Reason:** Importing from an internal module (`agent.compile`) instead of from the package. `collect_dataclass_types` is used by a sibling package, so it should be part of `flowra.agent`'s public API.

## engine.py

### Lines 68-74: Rule 6 violation
**Current:**
```python
def _build_agent_info(agent_name: str, defn: AgentDefinition) -> AgentInfo:
    parts = agent_name.split("/")
    parent: AgentInfo | None = None
    for i in range(len(parts) - 1):
        ancestor_path = "/".join(parts[: i + 1])
        parent = AgentInfo(name=parts[i], path=ancestor_path, source_type=None, parent=parent)
    return AgentInfo(name=parts[-1], path=agent_name, source_type=defn.source_type, parent=parent)
```
**Fix:**
Remove the module-level `_build_agent_info` function and keep only the `@staticmethod __build_agent_info` on `Engine`. Update `__build_execution_stack` (line 111) to call `cls.__build_agent_info` (converting it from `@staticmethod` to `@classmethod`):
```python
class Engine:
    ...
    @staticmethod
    def __build_agent_info(agent_name: str, defn: AgentDefinition) -> AgentInfo:
        parts = agent_name.split("/")
        parent: AgentInfo | None = None
        for i in range(len(parts) - 1):
            ancestor_path = "/".join(parts[: i + 1])
            parent = AgentInfo(name=parts[i], path=ancestor_path, source_type=None, parent=parent)
        return AgentInfo(name=parts[-1], path=agent_name, source_type=defn.source_type, parent=parent)

    @classmethod
    def __build_execution_stack(cls, node: ExecutionNode | None) -> tuple[ExecutionFrame, ...]:
        frames: list[ExecutionFrame] = []
        current = node
        while current is not None:
            agent_info = cls.__build_agent_info(current.agent_name, current.defn)
            frames.append(ExecutionFrame(agent=agent_info, spec=current.agent_spec, tag=current.tag))
            current = current.parent
        frames.reverse()
        return tuple(frames)
```
**Reason:** The file exists for the `Engine` class. The module-level `_build_agent_info` is only used by `Engine` and should be a method of it. Currently there are two copies: the module-level function and the `@staticmethod` wrapper that delegates to it. The `@staticmethod __build_execution_stack` also calls the module-level function directly instead of going through the class, which is why both exist. Fix by removing the module-level function and converting `__build_execution_stack` to a `@classmethod`.

### Lines 102-104: Rule 5 violation (redundant wrapper)
**Current:**
```python
@staticmethod
def __build_agent_info(agent_name: str, defn: AgentDefinition) -> AgentInfo:
    return _build_agent_info(agent_name, defn)
```
**Fix:**
Inline the logic from `_build_agent_info` directly into this `@staticmethod` (as shown in the fix above).
**Reason:** The `@staticmethod` is a one-line wrapper that delegates to the module-level function. After removing the module-level function (per the Rule 6 fix above), this method should contain the actual logic.

### Lines 389-391: Rule 5 violation
**Current:**
```python
# ------------------------------------------------------------------
# Spawn-tree satisfaction helpers
# ------------------------------------------------------------------
```
**Fix:**
Remove the section separator comment.
**Reason:** The method names (`__satisfied_set_from_children`, `__is_tree_satisfied`, `__collect_needed_indices`, etc.) already communicate their purpose. Section separators with descriptive labels are redundant comments.

## runtime.py

### Line 5: Rule 13 violation
**Current:**
```python
from .._sentinel import UNSET, Unset
```
**Fix:**
`_sentinel` is a private module at the `flowra` package level. If `UNSET`/`Unset` are meant to be used by subpackages, they should be exported from `flowra.__init__.py`, and the import should be:
```python
from .. import UNSET, Unset
```
Alternatively, if `_sentinel` is intentionally a shared internal module, this is acceptable as an intra-package import. Verify `flowra/__init__.py` exports these symbols; if not, add them.
**Reason:** Importing from a private internal module (`_sentinel`) of the parent package rather than from the package itself.

### Line 14: Rule 13 violation
**Current:**
```python
from ..agent.timeout import TimeoutAgent
```
**Fix:**
Export `TimeoutAgent` from `flowra.agent.__init__.py` (add it to `__all__`), then:
```python
from ..agent import TimeoutAgent
```
**Reason:** Importing from an internal module (`agent.timeout`) instead of from the package.

### Line 15: Rule 13 violation
**Current:**
```python
from ._instance_factory import create_instance_sealed
```
**Fix:**
This is an import from a sibling module within the same package, which is acceptable per Rule 13's exception ("relative imports within the same package may reference sibling modules directly"). However, the module is prefixed with `_` indicating it is private. This is fine for intra-package use.
**Reason:** No violation after re-evaluation. Withdrawn.

## storage/__init__.py

No violations.

## storage/session_storage.py

No violations.

## storage/in_memory.py

No violations.

## storage/file.py

No violations.

## Summary
- Files reviewed: 12
- Violations found: 7
- Breakdown by rule:
  - Rule 4 (private members use double underscore): 1
  - Rule 5 (comments must carry meaning): 3
  - Rule 6 (no module-level helpers): 1
  - Rule 13 (import from package, not internal modules): 2
