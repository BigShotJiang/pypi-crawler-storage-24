# Documentation Review: flowra.agent

## Documentation exists: YES

`docs/agent.md` exists and covers the package comprehensively.

## Structure compliance

Compliant. The document follows the expected structure:

1. Title: `# Package \`flowra.agent\`` -- correct
2. One-line description -- present (first paragraph)
3. File tree -- present (code block with per-file comments)
4. Quick start -- present with minimal working example
5. Sections organized by user importance -- follows a natural progression: defining agents, steps, control flow, state management, services, interrupts, DI, hooks, type aliases

One minor deviation: the `compile.py` file is listed in the file tree but `execution_context.py` and `agent_arg.py` are missing from the file tree.

## Completeness

### Documented symbols

- `Agent`
- `step`
- `step_arg` (module -- `SPEC`, `CHILD` markers documented in "Step parameter injection")
- `GotoStep`
- `GotoAgent`
- `CallStep`
- `CallAgent`
- `Spawn`
- `WhenAll`
- `WhenAny`
- `WhenN`
- `timeout`
- `TimeoutExpired`
- `NoSpec`
- `NoResult`
- `NEW_SCOPE`
- `AgentStore`
- `Scalar`
- `AppendOnlyList`
- `ServiceLocator`
- `InterruptToken`
- `InterruptedError`
- `Interrupted`
- `with_interrupt`
- `HookRegistry`
- `HookProvider`
- `Event`
- `ExecutionContext`
- `ExecutionFrame`
- `AgentInfo`
- `StepAction`
- `StepRef` (type alias)
- `AgentRef` (type alias)
- `SpawnChild` (type alias)
- `SpawnNode` (type alias)

### Undocumented symbols

The following symbols from `__all__` are not documented. Per the review prompt guidelines, many of these are internal/bridge types that don't need user-facing documentation:

- `AbstractAgent` -- base class, internal; `Agent` is the user-facing type. Acceptable omission.
- `AgentDefinition` -- internal compile-time type. Acceptable omission.
- `AgentDefinitionRef` -- internal type alias. Acceptable omission.
- `AgentInstance` -- internal runtime bridge type. Acceptable omission.
- `AgentRegistry` -- internal runtime type. Acceptable omission.
- `ResolvedAgent` -- internal runtime type. Acceptable omission.
- `CallStepHandler` -- internal protocol. Acceptable omission.
- `ChildOutput` -- internal bridge type. Acceptable omission.
- `CreateInstance` -- internal protocol. Acceptable omission.
- `StepMeta` -- internal compile-time type. Acceptable omission.
- `StepMethod` -- type alias, documented implicitly via `StepRef`. Acceptable omission.
- `StepResult` -- type alias. Acceptable omission.
- `agent_arg` -- module with `SPEC` and `SERVICE` markers for constructor injection. **Should be documented** (see Accuracy Issues below).

## Example validation

### Example 1: Quick start (line 26-42)
- **Valid:** YES
- **Issues:** None

### Example 2: Quick start -- runtime usage (line 48-54)
- **Valid:** PARTIALLY
- **Issues:** Cannot fully validate without reading `flowra.runtime`, but the example pattern is consistent with the package's described behavior.

### Example 3: Agent definition with GotoStep (line 74-87)
- **Valid:** YES
- **Issues:** None. `GotoStep(step="process", spec=ProcessSpec(data=spec.value))` correctly uses keyword-only arguments.

### Example 4: NoSpec / NoResult (line 98-105)
- **Valid:** YES
- **Issues:** None

### Example 5: @step decorator variants (line 123-134)
- **Valid:** YES
- **Issues:** None

### Example 6: Dataclass constraint (line 151-158)
- **Valid:** YES
- **Issues:** None

### Example 7: GotoStep usage (line 189-199)
- **Valid:** YES
- **Issues:** None

### Example 8: GotoAgent usage (line 228-236)
- **Valid:** YES
- **Issues:** None

### Example 9: Spawn basic form (line 250-261)
- **Valid:** YES
- **Issues:** None

### Example 10: Spawn keyword form (line 267-274)
- **Valid:** YES
- **Issues:** None

### Example 11: Spawn combinator form (line 279-285)
- **Valid:** YES
- **Issues:** None

### Example 12: Nested combinators (line 306-317)
- **Valid:** YES
- **Issues:** None

### Example 13: timeout usage (line 328-337)
- **Valid:** YES
- **Issues:** None

### Example 14: timeout join step (line 347-357)
- **Valid:** YES
- **Issues:** None

### Example 15: CallStep / CallAgent usage (line 391-401)
- **Valid:** YES
- **Issues:** None

### Example 16: Subagents (line 424-444)
- **Valid:** YES
- **Issues:** None

### Example 17: Subagent referencing (line 454-458)
- **Valid:** YES
- **Issues:** None

### Example 18: Multiple instances via tags (line 488-498)
- **Valid:** YES
- **Issues:** None

### Example 19: State management -- creating slots (line 511-523)
- **Valid:** YES
- **Issues:** None

### Example 20: Scalar get with default (line 532-543)
- **Valid:** YES
- **Issues:** None

### Example 21: flush() usage (line 570-582)
- **Valid:** YES
- **Issues:** None

### Example 22: ServiceLocator usage (line 640-649)
- **Valid:** YES
- **Issues:** None

### Example 23: InterruptToken usage (line 674-686)
- **Valid:** YES
- **Issues:** None

### Example 24: Interrupt with graceful handling (line 692-707)
- **Valid:** YES
- **Issues:** None

### Example 25: Interrupted result binding (line 725-748)
- **Valid:** YES
- **Issues:** None

### Example 26: with_interrupt (line 760-766)
- **Valid:** YES
- **Issues:** None

### Example 27: Constructor injection (line 801-807)
- **Valid:** YES
- **Issues:** None

### Example 28: Nullable constructor params (line 815-823)
- **Valid:** YES
- **Issues:** None

### Example 29: Step parameter injection examples (line 864-878)
- **Valid:** YES
- **Issues:** None

### Example 30: Nullable step params (line 885-894)
- **Valid:** YES
- **Issues:** None

### Example 31: Agent spec in constructor (line 902-910)
- **Valid:** YES
- **Issues:** None

### Example 32: HookRegistry usage (line 924-929)
- **Valid:** YES
- **Issues:** None

### Example 33: HookProvider (line 1014-1032)
- **Valid:** YES
- **Issues:** None

### Example 34: propagate_to (line 1040-1044)
- **Valid:** YES
- **Issues:** None

### Example 35: ExecutionContext navigation (line 990-1004)
- **Valid:** NO
- **Issues:** Line 997 uses `ctx.get_spec(ResearchSpec)` but `ctx` is never defined; it should be `event.context.get_spec(ResearchSpec)`. Similarly, lines 1001-1003 use `ctx.find_frame(...)` and `ctx` -- should be `event.context`.

### Example 36: StepAction type alias usage (line 1063-1069)
- **Valid:** YES
- **Issues:** None

## Accuracy issues

1. **Missing `execution_context.py` from file tree** (line 9-22): The file tree lists 11 files but omits `execution_context.py` (which defines `ExecutionContext`, `ExecutionFrame`, `AgentInfo`) and `agent_arg.py` (which defines `agent_arg.SPEC` and `agent_arg.SERVICE`). These are user-facing modules and should be listed.

2. **`agent_arg` module undocumented**: The `agent_arg` module is exported in `__all__` and provides `agent_arg.SPEC` and `agent_arg.SERVICE` markers for explicit constructor parameter binding. The docs describe implicit spec injection in "Agent spec in constructor" (line 896-918) but never mention `agent_arg.SPEC` or `agent_arg.SERVICE` as explicit markers. The code in `compile.py` (lines 576-593) shows that `Annotated[T, agent_arg.SPEC]` explicitly marks a param as spec, and `Annotated[T, agent_arg.SERVICE]` explicitly marks it as a service. This is a user-facing feature that should be documented, especially for disambiguation.

3. **Step parameter injection table -- "Agent spec" source is misleading** (line 834): The docs state there are three sources: "Step spec", "Agent spec", and "Child outputs". However, the code in `compile.py` `__bind_step_args` (line 493-546) only checks two sources: `spec` (step-level spec) and `child_outputs`. There is no agent-spec source in step parameter binding. The docs themselves later clarify on line 853: "Agent-level spec (`S` from `Agent[S, R]`) is NOT available in step parameters." This contradicts the earlier claim that "Agent spec" is a binding source for step parameters.

4. **`propagate_to` docs say `only` and `exclude` are "mutually exclusive"** (line 1046): The code in `hooks.py` (lines 75-98) does not enforce mutual exclusivity -- both `only` and `exclude` can be passed simultaneously. When both are provided, `only` is applied first, then `exclude` removes from that set. The docs should either describe the actual behavior or not claim mutual exclusivity.

5. **ExecutionContext example uses undefined variable `ctx`** (lines 997-1003): As noted in Example 35, the variable `ctx` is used but never defined. It should be `event.context`.

6. **`HookRegistry.__init__` signature difference**: The docs say `HookRegistry()` with no args (line 927), but the actual constructor is `__init__(self, context: ExecutionContext | None = None)`. This is acceptable since `context` defaults to `None` and is set by the runtime, but `emit()` will raise `RuntimeError` if called on a registry without context. The docs don't mention this constraint -- they show `hooks.on(...)` (which works) but not `emit()` on a standalone registry (which would fail). This could confuse users who try to use `HookRegistry` outside of the runtime.

## Clarity issues

1. **`agent_arg` markers not explained alongside constructor injection**: The "Constructor injection" section (line 783) explains implicit type matching but never introduces `agent_arg.SPEC` or `agent_arg.SERVICE` for explicit disambiguation. A user reading the "Agent spec in constructor" section (line 896) sees implicit matching but has no way to learn about the explicit markers.

2. **Step parameter injection -- the "Agent spec" source is confusing**: The section lists three sources (line 831-836) including "Agent spec", then later says agent spec is NOT available in step parameters (line 853). This back-and-forth is confusing. The list should only mention the two actual sources: step spec and child outputs.

3. **`with_context` mentioned but not documented**: Line 1007 mentions `with_context` method on `HookRegistry` ("via `with_context`") but this method is not in the method table (line 931-937). The method exists in code (`hooks.py` line 69) and creates a new registry sharing handlers but with a different context.

## Summary

- Documentation exists: YES
- Structure compliant: YES (minor: 2 files missing from file tree)
- Symbols documented: 34 / 47 (13 undocumented are mostly internal types; 1 user-facing: `agent_arg`)
- Examples valid: 35 / 36
- Accuracy issues: 6
- Clarity issues: 3
