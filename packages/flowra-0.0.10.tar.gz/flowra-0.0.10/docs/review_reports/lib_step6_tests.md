# Test Review: flowra.lib

## Part 1: Test quality

### test_config_value.py

#### test_plain_value (line 5)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK — clear arrange/act/assert
- **Verdict:** KEEP

#### test_sync_callable (line 8)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_async_callable (line 11)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_matches_tool_filter.py

#### test_exact_match (line 5)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_exact_no_match (line 8)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_wildcard_star (line 11)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_wildcard_star_no_match (line 14)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_wildcard_question_mark (line 17)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK — tests both match and non-match in one test, but they exercise the same concept (single-char wildcard), so acceptable
- **Verdict:** KEEP

#### test_multiple_patterns (line 21)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_star_matches_all (line 26)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_mixed_exact_and_wildcard (line 29)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

### test_llm_call_agent.py

#### test_simple_call_returns_result (line 34)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies the happy path end-to-end
- **Structure:** OK
- **Verdict:** KEEP

#### test_passes_messages_to_provider (line 56)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies messages are forwarded correctly
- **Structure:** OK
- **Verdict:** KEEP

#### test_uses_llm_config (line 82)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies LLMConfig fields propagate to LLMRequest
- **Structure:** OK
- **Verdict:** KEEP

#### test_returns_usage (line 109)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_no_delta_hooks_uses_call (line 133)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies call() vs stream() dispatch
- **Structure:** OK
- **Verdict:** KEEP

#### test_text_delta_hook_enables_streaming (line 169)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies streaming path and delta delivery
- **Structure:** OK
- **Verdict:** KEEP

#### test_thinking_delta_hook_enables_streaming (line 214)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_before_and_after_hooks (line 249)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies hook invocation order
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_during_streaming (line 283)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies interrupt breaks the stream loop
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_before_call (line 327)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies interrupt check before LLM call
- **Structure:** OK
- **Verdict:** KEEP

### test_tool_call_agent.py

#### test_execute_tool_call (line 22)
- **Name accuracy:** OK
- **Meaningfulness:** OK — happy path for tool execution
- **Structure:** OK
- **Verdict:** KEEP

#### test_denied_by_allowed_tools (line 42)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_denied_by_denied_tools (line 60)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_allowed_tools_permits_listed_tool (line 78)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_allowed_tools_wildcard (line 96)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_allowed_tools_wildcard_no_match (line 114)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_denied_tools_wildcard (line 131)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_execute_interrupted (line 148)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies interrupt produces error result
- **Structure:** OK
- **Verdict:** KEEP

### test_tool_call_agent_call_agent.py

#### test_call_agent_spawns_and_returns_result (line 65)
- **Name accuracy:** OK
- **Meaningfulness:** OK — end-to-end call_agent delegation
- **Structure:** OK
- **Verdict:** KEEP

#### test_no_call_agent_returns_normal_result (line 85)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies the non-delegation path
- **Structure:** OK
- **Verdict:** KEEP

#### test_call_agent_twice_raises (line 103)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies the once-only contract
- **Structure:** OK
- **Verdict:** KEEP

#### test_make_agent_tool_creates_working_tool (line 113)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies make_agent_tool end-to-end
- **Structure:** OK
- **Verdict:** KEEP

#### test_make_agent_tool_with_string_ref (line 136)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies string agent_ref path
- **Structure:** OK
- **Verdict:** KEEP

#### test_decorator_and_get_agent_tool (line 157)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies @agent_tool decorator + get_agent_tool
- **Structure:** OK
- **Verdict:** KEEP

#### test_get_agent_tool_raises_for_undecorated (line 184)
- **Name accuracy:** OK
- **Meaningfulness:** OK — error path
- **Structure:** OK
- **Verdict:** KEEP

#### test_agent_tool_outside_tool_call_agent_raises (line 190)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies RuntimeError when ToolCallAgentContext is missing
- **Structure:** OK
- **Verdict:** KEEP

#### test_multiple_spec_types_raises (line 197)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies TypeError for multi-spec agents
- **Structure:** OK
- **Verdict:** KEEP

#### test_agent_definition_without_agent_ref_raises (line 209)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies TypeError when AgentDefinition passed without agent_ref
- **Structure:** OK
- **Verdict:** KEEP

### test_tool_loop_agent.py

#### test_request_finish_in_tool (line 58)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies tool can request early finish
- **Structure:** OK
- **Verdict:** KEEP

#### test_max_llm_calls_exceeded (line 106)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies max_llm_calls limit
- **Structure:** OK
- **Verdict:** KEEP

#### test_simple_end_turn_returns_completed (line 157)
- **Name accuracy:** OK
- **Meaningfulness:** OK — happy path
- **Structure:** OK
- **Verdict:** KEEP

#### test_no_delta_hooks_uses_call (line 194)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_during_streaming_stops_early (line 242)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_max_consecutive_errors_replaces_message (line 307)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies the replacement message after max consecutive errors
- **Structure:** OK
- **Verdict:** KEEP

#### test_consecutive_errors_reset_on_success (line 375)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies counter resets on success
- **Structure:** OK
- **Verdict:** KEEP

#### test_non_end_turn_stop_reasons_return_completed (line 444)
- **Name accuracy:** OK
- **Meaningfulness:** OK — parameterized over multiple stop reasons
- **Structure:** OK
- **Verdict:** KEEP

#### test_interrupt_before_call_llm (line 481)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_after_tool_call_amends_result (line 521)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies AfterToolCallEvent result mutation
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_after_tool_call_can_request_finish (line 601)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies finish via hook
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_after_tool_call_adds_additional_messages (line 663)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies additional_messages injection
- **Structure:** OK
- **Verdict:** KEEP

#### test_all_hooks_are_called (line 747)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies hook ordering across a full tool-use cycle
- **Structure:** OK
- **Verdict:** KEEP

#### test_async_hooks_are_called (line 829)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies async hooks work
- **Structure:** OK
- **Verdict:** KEEP

#### test_before_tool_call_amends_tool_use (line 912)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies BeforeToolCallEvent tool_use mutation
- **Structure:** OK
- **Verdict:** KEEP

#### test_start_iteration_hook_adds_messages (line 990)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies StartIterationEvent additional_messages
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_message_accepted_receives_messages_and_metadata (line 1092)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_message_accepted_async_hook (line 1137)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_text_reasoning_fires_for_text_blocks (line 1179)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_thinking_event_fires_for_thinking_blocks (line 1217)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_result_message_continues_loop (line 1257)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies ResultMessageEvent continue_messages
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_text_delta_triggers_streaming (line 1304)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_thinking_delta_alone_triggers_streaming (line 1365)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP

#### test_thinking_delta_events_flow_through_agent (line 1428)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies both text and thinking deltas simultaneously
- **Structure:** OK
- **Verdict:** KEEP

### test_chat_agent.py

#### test_single_turn (line 25)
- **Name accuracy:** OK
- **Meaningfulness:** OK — happy path single turn
- **Structure:** OK
- **Verdict:** KEEP

#### test_multi_turn_session_accumulates (line 60)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies session history accumulation across turns
- **Structure:** OK
- **Verdict:** KEEP

#### test_tool_use_turn (line 133)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies tool use within chat, usage aggregation
- **Structure:** OK
- **Verdict:** KEEP

#### test_none_response_when_no_text (line 190)
- **Name accuracy:** OK
- **Meaningfulness:** OK — edge case: empty blocks
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_user_message_hook (line 223)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies UserMessageEvent hook augments messages
- **Structure:** OK
- **Verdict:** KEEP

#### test_on_save_turn_messages_hook_filters_messages (line 281)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies SaveTurnMessagesEvent filters transient messages from session
- **Structure:** OK
- **Verdict:** KEEP

#### test_no_hook_saves_all_messages (line 358)
- **Name accuracy:** OK
- **Meaningfulness:** OK — contrast to the filter test above
- **Structure:** OK
- **Verdict:** KEEP

#### test_system_messages_prepended_to_session (line 420)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies system messages are always first
- **Structure:** OK
- **Verdict:** KEEP

### tool_loop/test_cache.py

#### TestCacheLastSystemPrompt (4 tests, lines 35-71)
- **Name accuracy:** OK for all
- **Meaningfulness:** OK — covers caching, empty list, clearing existing cache, immutability
- **Structure:** OK
- **Verdict:** KEEP all

#### TestCacheLastTool (5 tests, lines 74-98)
- **Name accuracy:** OK for all
- **Meaningfulness:** OK — covers last tool caching, single, empty, clear existing, immutability
- **Structure:** OK
- **Verdict:** KEEP all

#### TestCacheLastMessage (5 tests, lines 101-147)
- **Name accuracy:** OK for all
- **Meaningfulness:** OK — covers caching last, middle not cached, empty, non-text blocks, clearing existing
- **Structure:** OK
- **Verdict:** KEEP all

#### TestCacheLastSessionMessage (3 tests, lines 150-178)
- **Name accuracy:** OK for all
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestNoCacheSystemPrompt (3 tests, lines 181-197)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestNoCacheTools (3 tests, lines 200-213)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestNoCacheMessages (3 tests, lines 216-232)
- **Name accuracy:** OK
- **Meaningfulness:** OK
- **Structure:** OK
- **Verdict:** KEEP all

#### TestCacheConfig (5 tests, lines 235-315)
- **Name accuracy:** OK
- **Meaningfulness:** OK — covers all strategies, no strategies, partial, empty blocks filtering, system/non-system separation
- **Structure:** OK
- **Verdict:** KEEP all

#### TestPresets (5 tests, lines 318-388)
- **Name accuracy:** OK
- **Meaningfulness:** OK — verifies CACHE_MANUAL, NO_CACHE, CACHE_ALL, CACHE_SESSION presets
- **Structure:** OK
- **Verdict:** KEEP all

## Part 2: Coverage analysis

### Public API coverage

The `flowra.lib` package exports the following via `__init__.py` `__all__`:

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `ConfigValue` | YES (indirectly) | Type alias, tested via `resolve_config_value` |
| `resolve_config_value` | YES | Plain value, sync callable, async callable |
| `LLMConfig` | YES (indirectly) | Used extensively in tests as config input; construction + field propagation verified |
| `LLMCallAgent` | YES | Happy path, message passing, config usage, usage return, call vs stream dispatch, delta hooks, thinking hooks, before/after hooks, interrupt during streaming, interrupt before call |
| `llm_call` subpackage | YES | `LLMCallSpec`, `LLMCallResult`, `BeforeLLMCallEvent`, `AfterLLMCallEvent`, `TextDeltaEvent`, `ThinkingDeltaEvent` all exercised |
| `tool_loop` subpackage | YES | See below |
| `chat` subpackage | YES | See below |

#### tool_loop subpackage public API

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `ToolLoopAgent` | YES | End turn, tool use loop, max_llm_calls, interrupt, streaming, consecutive errors |
| `ToolLoopConfig` | YES (indirectly) | Constructed in every ToolLoopAgent test |
| `ToolLoopSpec` | YES (indirectly) | Constructed in every ToolLoopAgent test |
| `ToolLoopResult` | YES | Status, stop_reason, result_message, messages, usage all verified |
| `ToolLoopStatus` | YES | COMPLETED, MAX_LLM_CALLS, FINISH_REQUESTED, INTERRUPTED (via Interrupted) |
| `ToolLoopAgentContext` | YES | request_finish via tool, is_finish_requested checked in agent |
| `matches_tool_filter` | YES | Exact, wildcard *, ?, multiple patterns, star-matches-all |
| `CacheConfig` | YES | apply with all/no/partial strategies, empty blocks filter, system separation |
| `CACHE_MANUAL` | YES | Preserves existing hints |
| `NO_CACHE` | YES | Clears all hints |
| `CACHE_ALL` | YES | Caches last of everything |
| `CACHE_SESSION` | YES | Caches session, clears turn |
| `cache_last_system_prompt` | YES | Caches last, clears others, empty, immutability |
| `cache_last_tool` | YES | Caches last, clears others, empty, immutability |
| `cache_last_message` | YES | Caches last overall, middle not cached, empty, non-text, clears existing |
| `cache_last_session_message` | YES | Caches last session, clears turn, empty session |
| `no_cache_system_prompt` | YES | Clears hints, no hints, empty |
| `no_cache_tools` | YES | Clears hints, no hints, empty |
| `no_cache_messages` | YES | Clears hints, no hints, empty |
| `SystemPromptCacheStrategy` | N/A | Protocol type, not directly testable |
| `ToolsCacheStrategy` | N/A | Protocol type, not directly testable |
| `MessagesCacheStrategy` | N/A | Protocol type, not directly testable |
| `AfterLLMCallEvent` | YES | Verified in hook tests |
| `AfterToolCallEvent` | YES | Amend result, request finish, additional messages |
| `BeforeLLMCallEvent` | YES | Verified in hook tests |
| `BeforeToolCallEvent` | YES | Amend tool_use |
| `MessageAcceptedEvent` | YES | Receives messages and metadata, async hook |
| `ResultMessageEvent` | YES | continue_messages to force loop continuation |
| `StartIterationEvent` | YES | additional_messages injection |
| `TextDeltaEvent` | YES | Streaming dispatch, delta delivery |
| `TextReasoningEvent` | YES | Fires for TextBlocks |
| `ThinkingDeltaEvent` | YES | Streaming dispatch, delta delivery |
| `ThinkingEvent` | YES | Fires for ThinkingBlocks |
| `UserMessageEvent` | YES | Via ChatAgent test (augment user messages) |
| `ToolCallAgent` | YES | Execute, denied by allowed/denied tools, wildcards, interrupt |
| `ToolCallAgentContext` | YES | call_agent, call_agent twice raises |
| `agent_tool` | YES | Decorator + get_agent_tool |
| `get_agent_tool` | YES | Success and raises for undecorated |
| `make_agent_tool` | YES | Direct class, string ref, error cases |

#### chat subpackage public API

| Symbol | Tested | Key behaviors covered |
|--------|--------|-----------------------|
| `ChatAgent` | YES | Single turn, multi-turn session accumulation, tool use, no-text response, hooks |
| `ChatConfig` | YES (indirectly) | Constructed in every ChatAgent test |
| `ChatSpec` | YES (indirectly) | Constructed in every ChatAgent test |
| `ChatResult` | YES | response, usage, None response |
| `SaveTurnMessagesEvent` | YES | Filtering transient messages, without filter saves all |

### Integration tests

Strong integration coverage. Tests exercise realistic multi-component flows:
- ChatAgent tests run the full stack: ChatAgent -> ToolLoopAgent -> ToolCallAgent -> ToolRegistry
- ToolLoopAgent tests exercise the full tool loop cycle with hooks
- call_agent tests verify the ToolCallAgent -> sub-agent delegation flow
- Multi-turn session accumulation verifies ChatAgent + storage integration

### E2E tests

Not applicable. The `flowra.lib` package does not directly interact with external services; it delegates to `LLMProvider` which is mocked in all tests. E2E tests for real LLM providers live in `tests/llm/`.

### Missing test scenarios

1. **ToolLoopAgent: `allowed_tools` / `denied_tools` filtering at the LLM request level.** The agent filters `tools` passed to `LLMRequest` based on `allowed_tools` and `denied_tools` config (lines 149-152 of `tool_loop/agent.py`). No test verifies that the LLM request's `tools` list is actually filtered — only ToolCallAgent-level denial is tested. A test should verify that when `allowed_tools={"add"}` is set, only the "add" tool appears in the LLMRequest sent to the provider.

2. **ToolLoopAgent: `json_schema` config propagation.** The `json_schema` field from `ToolLoopConfig` is resolved and passed to `LLMRequest` (line 156 of `tool_loop/agent.py`), but no test verifies this. A test should set `json_schema` in config and assert it appears in the provider's received request.

3. **ToolLoopAgent: usage accumulation across multiple LLM calls.** While ChatAgent tests verify aggregated usage, the ToolLoopAgent itself tracks usage via `self.__usage` across iterations. A direct test should verify that `ToolLoopResult.usage` correctly sums usage from multiple LLM calls in a tool loop.

4. **ToolLoopAgent: `BeforeToolCallEvent` amendment is reflected in stored messages.** The agent stores the amended `ToolUseBlock` in turn messages when the hook modifies it (lines 225-229 of `tool_loop/agent.py`). The existing test (`test_before_tool_call_amends_tool_use`) verifies the tool received modified params but does not verify that `result.messages` contains the amended `ToolUseBlock` (with the modified input) rather than the original.

5. **ToolLoopAgent: multiple parallel tool calls in a single response.** The LLM can return multiple `ToolUseBlock`s in one message (spawned as parallel children). No test exercises this path — all tool-use tests return a single tool call per response.

6. **ToolLoopAgent: `StopReason.OTHER` handling.** The `test_non_end_turn_stop_reasons_return_completed` test covers `MAX_TOKENS`, `STOP_SEQUENCE`, and `SCHEMA_VALIDATION_FAILED` but omits `StopReason.OTHER` which is also handled (line 251 of `tool_loop/agent.py`).

7. **ToolLoopAgent: `max_consecutive_errors` with multiple different tools.** The consecutive error counter is per-tool-name. No test verifies that errors from tool A do not affect tool B's counter.

8. **ToolLoopAgent: `cache_strategy` is actually applied to LLM requests.** While cache functions are thoroughly tested in `test_cache.py`, no integration test verifies that ToolLoopAgent correctly calls `cache_strategy.apply()` and uses the resulting messages/tools for the LLM request.

9. **ToolLoopAgent: `ConfigValue` callables for config fields.** Config fields like `max_llm_calls`, `allowed_tools`, etc. accept `ConfigValue[T]` (callable or plain). All tests use plain values. A test should verify that passing a callable (e.g., `max_llm_calls=lambda: 3`) works correctly.

10. **LLMCallAgent: `LLMConfig` as `ConfigValue` (callable).** The agent resolves `llm_config` via `resolve_config_value`, but all tests pass a plain `LLMConfig` instance. A test with a callable `LLMConfig` would verify the dynamic resolution path.

11. **LLMCallAgent: `elapsed` field in `LLMCallResult`.** The agent measures elapsed time (line 59 of `llm_call/agent.py`) and includes it in the result, but no test verifies that `result.elapsed > 0`.

12. **LLMCallAgent: `stop_sequences` and `additional_config` propagation from `LLMConfig`.** The test `test_uses_llm_config` checks `model`, `temperature`, and `max_tokens` but not `stop_sequences` or `additional_config`.

13. **ToolLoopAgent: metadata=None default in ToolLoopSpec.** When `metadata` is None, the agent passes `{}` to `MessageAcceptedEvent`. No test verifies this — all tests either pass explicit metadata or don't check the event.

## Summary

- Test files reviewed: 8
- Individual tests reviewed: 73
- Tests to fix: 0
- Tests to delete: 0
- Public symbols tested: 47 / 47 (all public symbols exercised)
- Missing test scenarios: 13
