# Code Style Review: flowra.tools

## mcp_connection.py

### Line 102-111: Rule 6 violation — public methods after dunder methods

Public methods `get_tools` and `call_tool` appear after `__aenter__` / `__aexit__`, breaking the public-methods-together grouping.

**Current:**
```python
    async def close(self) -> None:
        ...

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    def get_tools(self) -> list[ToolDefinition]:
        ...

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> ToolResult:
        ...
```

**Fix:** Move `get_tools` and `call_tool` before `__aenter__` / `__aexit__`:
```python
    async def close(self) -> None:
        ...

    def get_tools(self) -> list[ToolDefinition]:
        ...

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> ToolResult:
        ...

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()
```

**Reason:** Rule 6 requires public methods to be grouped together before private methods. Dunder protocol methods (`__aenter__`, `__aexit__`) act as a boundary between public and private — all regular public methods should appear before them.

## __init__.py

No violations.

## types.py

No violations.

## tool_arg.py

No violations.

## tool_group.py

No violations.

## tool_registry.py

No violations.

## local_tool.py

No violations.

## Summary

- Files reviewed: 7
- Violations found: 1
- Breakdown by rule: Rule 6: 1
