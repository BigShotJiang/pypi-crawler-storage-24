# Documentation Audit: flowra.runtime

## Type/field consistency

### ChangeSet
- Field `scalars`: documented as `dict[str, Any]`, actual is `dict[str, Any]` — OK
- Field `appends`: documented as `dict[str, list[Any]]`, actual is `dict[str, list[Any]]` — OK
- Property `empty: bool`: documented, actual exists — OK
- All fields: OK

### SessionStorage
- Method `begin_transaction`: documented, actual exists — OK
- Method `has_execution`: documented, actual exists — OK
- Method `save_execution`: documented, actual exists — OK
- Method `load_execution`: documented, actual exists — OK
- Method `clear_execution`: documented, actual exists — OK
- Method `save_node_state`: documented, actual exists — OK
- Method `load_node_state`: documented, actual exists — OK
- All methods: OK

### InterruptToken (abc, flowra.agent)
- Property `interrupted -> bool`: documented, actual exists — OK
- Method `check() -> None`: documented as "Raise InterruptedError if set", actual raises `InterruptedError` if `self.interrupted` — OK
- Method `wait() -> None`: documented as "Block until interrupted (returns immediately if already set)", actual uses `asyncio.Event.wait()` — OK
- All methods: OK

### InterruptTokenSource (flowra.runtime)
- Property `token -> InterruptToken`: documented, actual exists — OK
- Method `interrupt() -> None`: documented, actual exists — OK
- Method `clear() -> None`: documented, actual exists — OK
- Method `create_child()`: exists in code but NOT documented — not flagged (internal use by engine)
- Method `dispose()`: exists in code but NOT documented — not flagged (internal use by engine)
- All documented methods: OK

### AgentRuntime
- Constructor parameter `agents: dict[str, AgentDefinitionRef]`: documented, actual matches — OK
- Constructor parameter `storage: SessionStorage | None = None`: documented, actual matches — OK
- Constructor parameter `services: dict[type, Any] | None = None`: documented, actual matches — OK
- Constructor parameter `max_iterations: int | None = None`: documented, actual matches — OK
- Constructor parameter `timeout: float | None = None`: documented, actual matches — OK
- All constructor parameters: OK

## API consistency

### AgentRuntime.run()
- Documented signature shows `agent=MyAgent` and `agent="my_agent"` — actual parameter type is `agent: AgentRef` which is `str | type[AbstractAgent]` — OK
- Documented `spec=MySpec(...)` — actual `spec: Any | None = None` — OK
- Documented `storage_key="main"` — actual `storage_key: str | None = None` — OK
- Documented `max_iterations=50, timeout=30.0` — actual types `int | None | Unset` and `float | None | Unset` with `UNSET` default — OK (Unset is internal sentinel)
- Return type documented as `Any` — actual is `Any` — OK

### AgentRuntime.resume()
- Documented `resume(max_iterations=100, timeout=60.0)` — actual has these parameters — OK
- Return type documented as `Any` — actual is `Any` — OK

### AgentRuntime.has_pending_execution()
- Documented as returning `bool` — actual returns `bool` — OK

### AgentRuntime.interrupt()
- Documented as `runtime.interrupt()` — actual exists, calls `self.__interrupt_source.interrupt()` — OK

### serialize_value / deserialize_value
- `serialize_value(value: Any, type_tags: dict[type, str]) -> Any` — matches actual — OK
- `deserialize_value(value: Any, type_registry: dict[str, type]) -> Any` — matches actual — OK

All APIs match.

## Import consistency

### Quick start example
- `from flowra.agent import Agent, step` — need to verify these are exported.

### Example with persistence
- `from flowra.runtime import AgentRuntime, InMemorySessionStorage, FileSessionStorage` — all in `flowra.runtime.__all__` — OK

### Cooperative interrupts example
- `from flowra.agent import Agent, InterruptToken, step` — need to verify `InterruptToken` is exported from `flowra.agent`.

Let me verify the agent `__init__.py` exports:

`InterruptToken` is in `flowra/agent/__init__.py`'s `__all__` — OK
`Agent` is in `flowra/agent/__init__.py`'s `__all__` — OK
`step` is in `flowra/agent/__init__.py`'s `__all__` — OK

All imports correct.

## Example correctness

### Example in "Quick start"
- `AgentRuntime(agents={"greeter": Greeter})` — `Greeter` is a class (type of `AbstractAgent`), which is a valid `AgentDefinitionRef` — OK
- `await runtime.run(agent=Greeter, spec=GreetSpec(name="World"))` — uses keyword args, `agent` accepts `type[AbstractAgent]` — OK
- `result.greeting` — `GreetResult` has `greeting: str` — OK
- Correct.

### Example in "AgentRuntime methods"
- All method call forms shown are valid per the actual signatures — OK
- `runtime.interrupt()` — exists — OK
- `await runtime.has_pending_execution()` — exists, returns bool — OK
- Correct.

### Example in "Execution loop" (pseudocode)
- Shows `engine.advance(root)` returning `Completed(result=r)` or `Progressed()` — matches actual `Engine.advance()` return — OK
- Shows `max_iterations` check and `RuntimeError` — matches actual `__run_loop_inner` — OK
- Correct.

### Example in "Example with persistence"
- `InMemorySessionStorage()` — no-arg constructor — matches actual — OK
- `FileSessionStorage(base_dir="/var/data/agents", session_id="session-123")` — matches actual constructor `(base_dir: str, session_id: str)` — OK
- `AgentRuntime(agents=..., storage=..., services=..., max_iterations=..., timeout=...)` — all valid constructor params — OK
- `await runtime.run(agent="worker", spec=TaskSpec(...))` — valid — OK
- `await runtime2.resume()` — valid — OK
- Correct.

### Example in "Cooperative interrupts"
- `InterruptToken` constructor injection: `def __init__(self, interrupt: InterruptToken)` — runtime injects `InterruptToken` via services dict — OK
- `self.interrupt.check()` — method exists on `InterruptToken` — OK
- `runtime.interrupt()` — method exists — OK
- Correct.

## Completeness

### Symbols in `flowra.runtime.__all__`:
1. `AgentRuntime` — documented — OK
2. `ChangeSet` — documented — OK
3. `FileSessionStorage` — documented — OK
4. `InMemorySessionStorage` — documented — OK
5. `InterruptTokenSource` — documented — OK
6. `SessionStorage` — documented — OK

### Symbols in `__all__` but not in docs:
None.

### Symbols in docs but not in `__all__`:
None.

### Missing exports check:
- `serialize_value` and `deserialize_value` are documented in the Serialization section but are NOT exported from `flowra.runtime.__all__`. They are internal functions in `flowra.runtime.serialization` — MISSING EXPORT (but see note below)
  - These functions are documented with full signatures and a type table. However, they are described as automatic runtime behavior ("The runtime automatically serializes all values before they reach storage"), and users do not need to call them directly. The documentation describes the serialization *format* for users implementing custom `SessionStorage`, not an API users call. Not a meaningful issue.

## Behavioral accuracy

### Serialization table — missing `Interrupted` type
- The serialization code (`serialization.py` lines 20-21, 64-65) handles `Interrupted` specially: serialized as `{"__interrupted__": reason}` and deserialized back. The documentation's serialization type table does not list `Interrupted` — MISSING from table. This is a user-visible type (agents can return `Interrupted()` and it gets persisted/restored), so it should be documented.

### "Per-node interrupt tokens with parent→child cascade"
- The code confirms parent→child cascade: `InterruptTokenSource.create_child()` links parent to child, and `_InterruptTokenImpl.set()` cascades to all children — OK, accurate.

### "Automatically cleared on successful completion (but not on exceptions, allowing resume)"
- In `__run_loop_inner` (runtime.py line 153), `self.__interrupt_source.clear()` is called only inside `case Completed(result=r)`, not on exceptions — OK, accurate.

### "wait() is useful in tools — block until interrupted"
- `InterruptToken.wait()` delegates to `asyncio.Event.wait()` which blocks until `event.set()` is called — OK, accurate.

### Fork behavior description
- Doc: "Copies all scalar values (snapshot)" and "Copies all list contents (snapshot)" and "Child scope is fully independent"
- Code (`runtime_scope.py` lines 90-105): `fork()` creates new `Scalar` with restored value, new `AppendOnlyList` with restored items. "No flush callback, no dirty state" — fork creates a new `RuntimeScope` without flush callback, but dirty state is not explicitly cleaned (new `Scalar`/`AppendOnlyList` start clean by default). OK, accurate.

### Persistence contract step 2 description
- Doc says: "Snapshot execution tree → `storage.save_execution(tree_snapshot)`"
- Actual order in `__save_post_advance` (runtime.py lines 158-164): opens transaction, saves execution, then saves dirty scopes, then commits. Doc says step 2 is save_execution and step 3 is save_node_state — matches actual order. OK, accurate.

### Persistence contract step 5 description
- Doc says: "Runtime calls `scope.mark_clean()` for all nodes (outside transaction)"
- Code (runtime.py line 164): `self.__mark_all_clean(root)` is called after the `async with` block — OK, accurate.

### "None → ephemeral node (still persisted under node_id for crash recovery, but no cross-run continuity)"
- Code (runtime.py line 168): `effective_key = node.storage_key if node.storage_key is not None else node.node_id` — OK, accurate.

### Execution loop pseudocode — `persist_changes()` description
- The pseudocode shows `await persist_changes()` after `engine.advance(root)`, which matches `await self.__save_post_advance(root)` — OK, accurate.

### "run() raises RuntimeError if a pending execution snapshot already exists"
- Code (runtime.py lines 72-74): checks `await self.has_pending_execution()` and raises `RuntimeError` — OK, accurate.

### "run() raises RuntimeError if max_iterations is exceeded"
- Code (runtime.py lines 143-145): raises `RuntimeError(f"Agent exceeded max_iterations limit ({max_iterations})")` — OK, accurate.

### "resume() raises RuntimeError if no storage is configured or if no execution snapshot exists"
- Code (runtime.py lines 108-114): raises `RuntimeError("No storage configured for resume")` and `RuntimeError("No persisted state to resume from")` — OK, accurate.

### "Dataclass serialization delegates field conversion to marshmallow_recipe.dump()/load()"
- Code (serialization.py line 42): `mr.dump(value)` and (line 72): `mr.load(cls, value["__data__"])` — OK, accurate.

### GotoAgent scope behavior: "Any storage_key → Always fresh scope"
- Code (engine.py lines 292-327): GotoAgent always creates a new scope regardless of `storage_key` value — OK, accurate.

### CallStep scope behavior with no `storage_key`
- Doc: "Fork parent scope (copy scalars + lists, independent)"
- Code (engine.py lines 557-561): when `storage_key is None`, calls `parent.scope.fork(parent_services=merged)` — but note that `call.storage_key` from `CallStep` can be `None` (no storage_key attribute on CallStep), but the `__create_child_node` logic (line 540) checks `isinstance(call.storage_key, str) or call.storage_key is None`. When `call.storage_key is None`, `storage_key` local var is `None`, and then line 557 checks `if storage_key is not None` — false, so fork is used. OK, accurate.

All other descriptions accurate.

## Summary
- Type/field mismatches: 0
- API mismatches: 0
- Import errors: 0
- Example errors: 0
- Undocumented symbols: 0
- Inaccurate descriptions: 1 (serialization table missing `Interrupted` type)
- Total issues: 1
