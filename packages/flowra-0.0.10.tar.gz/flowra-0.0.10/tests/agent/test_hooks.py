import dataclasses

import pytest

from flowra.agent import Agent, AgentInfo, Event, ExecutionContext, ExecutionFrame, HookRegistry


@dataclasses.dataclass(slots=True, kw_only=True)
class SampleEvent:
    value: int
    extra: str = ""


@dataclasses.dataclass(slots=True, kw_only=True)
class OtherEvent:
    name: str


def _test_context() -> ExecutionContext:
    info = AgentInfo(name="test", path="test", source_type=None, parent=None)
    frame = ExecutionFrame(agent=info)
    return ExecutionContext(frame=frame, stack=(frame,))


def _registry() -> HookRegistry:
    return HookRegistry(context=_test_context())


class TestHookRegistry:
    async def test_emit_no_handlers(self) -> None:
        registry = _registry()
        result = await registry.emit(SampleEvent(value=42))
        assert result.value == 42

    async def test_sync_handler_called(self) -> None:
        received: list[Event[SampleEvent]] = []

        def handler(event: Event[SampleEvent]) -> None:
            received.append(event)

        registry = _registry()
        registry.on(SampleEvent, handler)
        await registry.emit(SampleEvent(value=7))

        assert len(received) == 1
        assert received[0].data.value == 7

    async def test_async_handler_called(self) -> None:
        received: list[int] = []

        async def handler(event: Event[SampleEvent]) -> None:
            received.append(event.data.value)

        registry = _registry()
        registry.on(SampleEvent, handler)
        await registry.emit(SampleEvent(value=99))

        assert received == [99]

    async def test_multiple_handlers_called_in_order(self) -> None:
        order: list[str] = []

        registry = _registry()
        registry.on(SampleEvent, lambda e: order.append("first"))
        registry.on(SampleEvent, lambda e: order.append("second"))
        registry.on(SampleEvent, lambda e: order.append("third"))
        await registry.emit(SampleEvent(value=0))

        assert order == ["first", "second", "third"]

    async def test_prepend_handler(self) -> None:
        order: list[str] = []

        registry = _registry()
        registry.on(SampleEvent, lambda e: order.append("first"))
        registry.on(SampleEvent, lambda e: order.append("prepended"), prepend=True)
        registry.on(SampleEvent, lambda e: order.append("last"))
        await registry.emit(SampleEvent(value=0))

        assert order == ["prepended", "first", "last"]

    async def test_has_handlers(self) -> None:
        registry = _registry()
        assert not registry.has_handlers(SampleEvent)

        registry.on(SampleEvent, lambda e: None)
        assert registry.has_handlers(SampleEvent)
        assert not registry.has_handlers(OtherEvent)

    async def test_propagate_to(self) -> None:
        received: list[int] = []

        ctx = _test_context()
        source = HookRegistry(context=ctx)
        target = HookRegistry(context=ctx)
        target.on(SampleEvent, lambda e: received.append(e.data.value))

        # Need a handler on source for the event type to be propagated
        source.on(SampleEvent, lambda e: None)
        source.propagate_to(target)
        await source.emit(SampleEvent(value=42))

        assert received == [42]

    async def test_propagate_to_with_only(self) -> None:
        sample_received: list[int] = []
        other_received: list[str] = []

        ctx = _test_context()
        source = HookRegistry(context=ctx)
        target = HookRegistry(context=ctx)
        target.on(SampleEvent, lambda e: sample_received.append(e.data.value))
        target.on(OtherEvent, lambda e: other_received.append(e.data.name))

        source.on(SampleEvent, lambda e: None)
        source.on(OtherEvent, lambda e: None)
        source.propagate_to(target, only=[SampleEvent])

        await source.emit(SampleEvent(value=1))
        await source.emit(OtherEvent(name="test"))

        assert sample_received == [1]
        assert other_received == []

    async def test_propagate_to_with_exclude(self) -> None:
        sample_received: list[int] = []
        other_received: list[str] = []

        ctx = _test_context()
        source = HookRegistry(context=ctx)
        target = HookRegistry(context=ctx)
        target.on(SampleEvent, lambda e: sample_received.append(e.data.value))
        target.on(OtherEvent, lambda e: other_received.append(e.data.name))

        source.on(SampleEvent, lambda e: None)
        source.on(OtherEvent, lambda e: None)
        source.propagate_to(target, exclude=[OtherEvent])

        await source.emit(SampleEvent(value=2))
        await source.emit(OtherEvent(name="excluded"))

        assert sample_received == [2]
        assert other_received == []

    async def test_handler_mutation_visible(self) -> None:
        def mutate(event: Event[SampleEvent]) -> None:
            event.data.extra = "mutated"

        registry = _registry()
        registry.on(SampleEvent, mutate)
        result = await registry.emit(SampleEvent(value=1))

        assert result.extra == "mutated"

    async def test_context_stamped(self) -> None:
        agent_info = AgentInfo(name="test", path="root/test", source_type=Agent, parent=None)
        frame = ExecutionFrame(agent=agent_info, spec=None)
        context = ExecutionContext(frame=frame, stack=(frame,))
        received_contexts: list[ExecutionContext] = []

        def handler(event: Event[SampleEvent]) -> None:
            received_contexts.append(event.context)

        registry = HookRegistry(context=context)
        registry.on(SampleEvent, handler)
        await registry.emit(SampleEvent(value=1))

        assert len(received_contexts) == 1
        assert received_contexts[0] is context
        assert received_contexts[0].frame.agent.source_type is Agent
        assert received_contexts[0].frame.agent.path == "root/test"

    async def test_emit_without_context_raises(self) -> None:
        registry = HookRegistry()
        with pytest.raises(RuntimeError, match="without ExecutionContext"):
            await registry.emit(SampleEvent(value=1))
