import dataclasses

import pytest

from flowra.agent import AbstractAgent, AgentInfo, ExecutionContext, ExecutionFrame


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpecA:
    value: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpecB:
    name: str


class AgentA(AbstractAgent):
    pass


class AgentB(AbstractAgent):
    pass


def _make_context(
    frames: list[tuple[str, type | None, object, str | None]],
) -> ExecutionContext:
    """Build an ExecutionContext from a list of (name, agent_type, spec_instance, tag) tuples."""
    built: list[ExecutionFrame] = []
    parent_info: AgentInfo | None = None
    path_parts: list[str] = []
    for name, agent_type, spec, tag in frames:
        path_parts.append(name)
        info = AgentInfo(
            name=name,
            path="/".join(path_parts),
            source_type=agent_type,
            parent=parent_info,
        )
        built.append(ExecutionFrame(agent=info, spec=spec, tag=tag))
        parent_info = info
    return ExecutionContext(frame=built[-1], stack=tuple(built))


class TestFindSpec:
    def test_finds_spec_in_current_frame(self) -> None:
        ctx = _make_context([("root", None, SpecA(value=42), None)])
        result = ctx.find_spec(SpecA)
        assert result is not None
        assert result.value == 42

    def test_finds_spec_in_parent_frame(self) -> None:
        ctx = _make_context(
            [
                ("root", None, SpecA(value=1), None),
                ("child", None, None, None),
            ]
        )
        result = ctx.find_spec(SpecA)
        assert result is not None
        assert result.value == 1

    def test_nearest_spec_wins(self) -> None:
        ctx = _make_context(
            [
                ("root", None, SpecA(value=1), None),
                ("child", None, SpecA(value=2), None),
            ]
        )
        result = ctx.find_spec(SpecA)
        assert result is not None
        assert result.value == 2

    def test_returns_none_when_not_found(self) -> None:
        ctx = _make_context([("root", None, SpecA(value=1), None)])
        assert ctx.find_spec(SpecB) is None

    def test_returns_none_for_empty_specs(self) -> None:
        ctx = _make_context([("root", None, None, None)])
        assert ctx.find_spec(SpecA) is None


class TestGetSpec:
    def test_returns_spec(self) -> None:
        ctx = _make_context([("root", None, SpecA(value=7), None)])
        assert ctx.get_spec(SpecA).value == 7

    def test_raises_when_not_found(self) -> None:
        ctx = _make_context([("root", None, None, None)])
        with pytest.raises(LookupError, match="SpecA"):
            ctx.get_spec(SpecA)


class TestFindFrame:
    def test_by_spec_type(self) -> None:
        ctx = _make_context(
            [
                ("root", None, SpecA(value=1), None),
                ("child", None, SpecB(name="x"), None),
            ]
        )
        frame = ctx.find_frame(spec_type=SpecA)
        assert frame is not None
        assert frame.agent.name == "root"

    def test_by_agent_type(self) -> None:
        ctx = _make_context(
            [
                ("root", AgentA, SpecA(value=1), None),
                ("child", AgentB, SpecB(name="x"), None),
            ]
        )
        frame = ctx.find_frame(agent_type=AgentA)
        assert frame is not None
        assert frame.agent.name == "root"

    def test_nearest_match(self) -> None:
        ctx = _make_context(
            [
                ("root", AgentA, SpecA(value=1), None),
                ("child", AgentA, SpecA(value=2), None),
            ]
        )
        frame = ctx.find_frame(agent_type=AgentA)
        assert frame is not None
        assert frame.agent.name == "child"

    def test_by_both_spec_and_agent_type(self) -> None:
        ctx = _make_context(
            [
                ("root", AgentA, SpecA(value=1), None),
                ("child", AgentB, SpecA(value=2), None),
            ]
        )
        frame = ctx.find_frame(spec_type=SpecA, agent_type=AgentA)  # type: ignore[call-overload]
        assert frame is not None
        assert frame.agent.name == "root"

    def test_returns_none_when_not_found(self) -> None:
        ctx = _make_context([("root", AgentA, SpecA(value=1), None)])
        assert ctx.find_frame(agent_type=AgentB) is None

    def test_raises_without_criteria(self) -> None:
        ctx = _make_context([("root", None, None, None)])
        with pytest.raises(TypeError, match="At least one"):
            ctx.find_frame()  # type: ignore[call-overload]


class TestGetFrame:
    def test_returns_frame(self) -> None:
        ctx = _make_context([("root", AgentA, SpecA(value=1), None)])
        frame = ctx.get_frame(agent_type=AgentA)
        assert frame.agent.name == "root"

    def test_raises_when_not_found(self) -> None:
        ctx = _make_context([("root", AgentA, None, None)])
        with pytest.raises(LookupError, match="agent_type=AgentB"):
            ctx.get_frame(agent_type=AgentB)

    def test_raises_with_spec_type_message(self) -> None:
        ctx = _make_context([("root", None, None, None)])
        with pytest.raises(LookupError, match="spec_type=SpecB"):
            ctx.get_frame(spec_type=SpecB)
