"""Pure state-machine agent demo using runtime.

Menu agent: user picks "calc" or "echo", then interacts with the chosen sub-agent.
Agents contain NO I/O — each step returns a prompt or result.
The single input loop in main() handles all user interaction.

Usage:
    uv run python examples/menu_agent.py
"""

import asyncio
import dataclasses
from typing import Any

from examples.tools import eval_expression
from flowra.agent import (
    AgentDefinition,
    AgentDefinitionRef,
    AgentInstance,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    ChildOutput,
    GotoStep,
    Scalar,
    ServiceLocator,
    Spawn,
)
from flowra.runtime import AgentRuntime, InMemorySessionStorage

# -- Specs & Results ----------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserInput:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PromptResult:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DoneResult:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class QuitResult:
    pass


_SHARED_TYPE_REGISTRY: dict[str, type] = {
    "UserInput": UserInput,
    "PromptResult": PromptResult,
    "DoneResult": DoneResult,
    "QuitResult": QuitResult,
}

# -- Calculator ---------------------------------------------------------------


def _calculate(expression: str) -> str:
    try:
        return eval_expression(expression)
    except Exception as e:
        return f"Error: {e}"


def _calc_agent() -> AgentDefinition:
    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        store: AgentStore = sl.services[AgentStore]
        history = store.slot(AppendOnlyList[str], "history")

        async def call_step(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "main":
                if isinstance(spec, UserInput):
                    expr = spec.text.strip()
                    if expr.lower() in ("q", "quit", "back"):
                        return QuitResult()
                    result = _calculate(expr)
                    history.append(f"{expr} = {result}")
                    return PromptResult(text=f"  = {result}\ncalc> ")
                return PromptResult(text="calc> ")
            msg = f"Unknown step: {tag}"
            raise ValueError(msg)

        return AgentInstance(call_step=call_step)

    return AgentDefinition(
        entry_step="main",
        steps={},
        create_instance=create,
        type_registry=_SHARED_TYPE_REGISTRY,
    )


# -- Echo ---------------------------------------------------------------------


def _echo_agent() -> AgentDefinition:
    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        store: AgentStore = sl.services[AgentStore]
        count = store.slot(Scalar[int], "count")

        async def call_step(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "main":
                if isinstance(spec, UserInput):
                    text = spec.text.strip()
                    if text.lower() in ("q", "quit", "back"):
                        return QuitResult()
                    count.set(count.get(0) + 1)
                    return PromptResult(text=f"  echo: {text}\necho> ")
                return PromptResult(text="echo> ")
            msg = f"Unknown step: {tag}"
            raise ValueError(msg)

        return AgentInstance(call_step=call_step)

    return AgentDefinition(
        entry_step="main",
        steps={},
        create_instance=create,
        type_registry=_SHARED_TYPE_REGISTRY,
    )


# -- Menu (root) --------------------------------------------------------------

_MENU_TEXT = """
=== Menu ===
1. Calculator
2. Echo
q. Quit
choice> """


def _menu_agent() -> AgentDefinition:
    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        store: AgentStore = sl.services[AgentStore]
        mode = store.slot(Scalar[str], "mode")

        async def call_step(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "main":
                current = mode.get("")
                if isinstance(spec, UserInput):
                    # User provided input — route to appropriate handler
                    if not current:
                        choice = spec.text.strip().lower()
                        if choice == "1":
                            mode.set("calc")
                            return GotoStep(step="show_prompt")
                        if choice == "2":
                            mode.set("echo")
                            return GotoStep(step="show_prompt")
                        if choice in ("q", "quit"):
                            return DoneResult(text="Bye!")
                        return PromptResult(text=f"  Unknown: {spec.text!r}\nchoice> ")
                    return Spawn(
                        children=[CallAgent(agent=current, spec=spec, storage_key=current)],
                        then="handle_child",
                    )
                # No input — show prompt
                return GotoStep(step="show_prompt")

            if tag == "show_prompt":
                current = mode.get("")
                if current == "calc":
                    return Spawn(
                        children=[CallAgent(agent="calc", storage_key="calc")],
                        then="forward",
                    )
                if current == "echo":
                    return Spawn(
                        children=[CallAgent(agent="echo", storage_key="echo")],
                        then="forward",
                    )
                return PromptResult(text=_MENU_TEXT)

            if tag == "forward":
                assert child_outputs is not None
                return child_outputs[0].result

            if tag == "handle_child":
                assert child_outputs is not None
                child_result = child_outputs[0].result
                if isinstance(child_result, QuitResult):
                    mode.set("")
                    return GotoStep(step="show_prompt")
                return child_result

            msg = f"Unknown step: {tag}"
            raise ValueError(msg)

        return AgentInstance(call_step=call_step)

    return AgentDefinition(
        entry_step="main",
        steps={},
        create_instance=create,
        type_registry=_SHARED_TYPE_REGISTRY,
    )


# -- Main ---------------------------------------------------------------------


async def main() -> None:
    agents: dict[str, AgentDefinitionRef] = {
        "menu": _menu_agent(),
        "calc": _calc_agent(),
        "echo": _echo_agent(),
    }
    storage = InMemorySessionStorage()
    runtime = AgentRuntime(agents=agents, storage=storage)

    spec: Any = None
    while True:
        result = await runtime.run(agent="menu", spec=spec)
        if isinstance(result, DoneResult):
            print(result.text)
            break
        assert isinstance(result, PromptResult)
        user_input = input(result.text)
        spec = UserInput(text=user_input)


if __name__ == "__main__":
    asyncio.run(main())
