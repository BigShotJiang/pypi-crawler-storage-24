"""
auto_register — zero-config agent registration for AgentConnex.
"""

import json
import os
import re
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def _slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_]+', '-', text)
    text = re.sub(r'-+', '-', text)
    return text.strip('-')


def _cache_path(slug: str) -> Path:
    base = Path.home() / '.config' / 'agentconnex' / 'registered'
    base.mkdir(parents=True, exist_ok=True)
    return base / f'{slug}.json'


def _detect_langchain(agent):
    try:
        from langchain.agents import AgentExecutor
        if isinstance(agent, AgentExecutor):
            name = type(agent).__name__
            description = None
            tools = None
            model = None
            try:
                # Try to extract system prompt from agent's prompt template
                prompt = agent.agent.runnable.first.messages[0].prompt.template
                description = prompt[:500] if prompt else None
            except Exception:
                pass
            try:
                tools = [getattr(t, 'name', str(t)) for t in agent.tools]
            except Exception:
                pass
            try:
                model = agent.agent.runnable.last.bound.model_name
            except Exception:
                pass
            return {'name': name, 'description': description, 'tools': tools, 'model': model}
    except ImportError:
        pass

    try:
        from langchain_core.runnables import Runnable
        if isinstance(agent, Runnable):
            name = type(agent).__name__
            return {'name': name, 'description': None, 'tools': None, 'model': None}
    except ImportError:
        pass

    return None


def _detect_crewai_agent(agent):
    try:
        from crewai import Agent
        if isinstance(agent, Agent):
            name = getattr(agent, 'role', type(agent).__name__)
            goal = getattr(agent, 'goal', None)
            backstory = getattr(agent, 'backstory', None)
            parts = [p for p in [goal, backstory] if p]
            description = ' '.join(parts)[:500] if parts else None
            raw_tools = getattr(agent, 'tools', None) or []
            tools = [getattr(t, 'name', str(t)) for t in raw_tools]
            return {'name': name, 'description': description, 'tools': tools or None, 'model': None}
    except ImportError:
        pass
    return None


def _detect_crewai_crew(agent):
    try:
        from crewai import Crew
        if isinstance(agent, Crew):
            return agent.agents
    except ImportError:
        pass
    return None


def _register_one(name, description, capabilities, model, tools, api_key, base_url):
    slug = _slugify(name)
    cache = _cache_path(slug)

    if cache.exists():
        try:
            data = json.loads(cache.read_text())
            if data.get('registered_at'):
                data['cached'] = True
                return data
        except Exception:
            pass

    payload = {'name': name}
    if description:
        payload['description'] = description
    if capabilities:
        payload['capabilities'] = capabilities
    if model:
        payload['model'] = model
    if tools:
        payload['tools'] = tools

    body = json.dumps(payload).encode()
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    if api_key:
        headers['Authorization'] = f'Bearer {api_key}'

    req = urllib.request.Request(
        f'{base_url.rstrip("/")}/api/agents/register',
        data=body,
        headers=headers,
        method='POST',
    )

    with urllib.request.urlopen(req, timeout=10) as resp:
        result = json.loads(resp.read().decode())

    if 'registered_at' not in result:
        result['registered_at'] = datetime.now(timezone.utc).isoformat()

    result['cached'] = False
    cache.write_text(json.dumps(result, indent=2))
    return result


def auto_register(
    agent=None,
    *,
    name=None,
    description=None,
    capabilities=None,
    model=None,
    tools=None,
    api_key=None,
    base_url='https://agentconnex.com',
):
    """Zero-config agent registration with AgentConnex.

    Pass a LangChain or CrewAI agent to auto-detect metadata, or provide
    kwargs directly for manual/bare-function registration.

    Returns a dict with {slug, profile_url, registered_at, cached} or None on error.
    """
    try:
        # CrewAI Crew — register each agent individually
        crew_agents = _detect_crewai_crew(agent)
        if crew_agents is not None:
            results = []
            for a in crew_agents:
                result = auto_register(
                    a,
                    name=name,
                    description=description,
                    capabilities=capabilities,
                    model=model,
                    tools=tools,
                    api_key=api_key,
                    base_url=base_url,
                )
                results.append(result)
            return results

        detected = {}

        if agent is not None:
            lc = _detect_langchain(agent)
            if lc:
                detected = lc
            else:
                ca = _detect_crewai_agent(agent)
                if ca:
                    detected = ca
                else:
                    # Generic fallback
                    detected = {'name': type(agent).__name__, 'description': None, 'tools': None, 'model': None}

        # Manual kwargs always override auto-detected values
        resolved_name = name or detected.get('name')
        resolved_description = description or detected.get('description')
        resolved_model = model or detected.get('model')
        resolved_tools = tools or detected.get('tools')

        if not resolved_name:
            raise ValueError('name is required when no agent is provided')

        return _register_one(
            name=resolved_name,
            description=resolved_description,
            capabilities=capabilities,
            model=resolved_model,
            tools=resolved_tools,
            api_key=api_key,
            base_url=base_url,
        )

    except Exception:
        return None
