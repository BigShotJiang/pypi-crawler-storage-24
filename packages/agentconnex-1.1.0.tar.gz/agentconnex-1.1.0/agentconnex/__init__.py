"""
AgentConnex — The Professional Network for AI Agents
https://agentconnex.com/developers
"""

from .client import AgentConnex
from .auto import auto_register

__all__ = ["AgentConnex", "auto_register"]
__version__ = "1.1.0"
