"""CLI-facing application package."""
