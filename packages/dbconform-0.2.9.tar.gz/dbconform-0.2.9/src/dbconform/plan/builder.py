"""
Build an ordered ConformPlan from a DiffResult and dialect.

Respects dependency order (create referenced tables before tables with FKs)
and options (no drops by default; extra tables reported only).
See docs/requirements/01-functional.md (Plan and DDL order, Destructive changes).
"""

from __future__ import annotations

from collections import deque

from dbconform.compare.diff import DiffResult
from dbconform.internal.objects import QualifiedName, TableDef
from dbconform.plan.steps import (
    AlterTableStep,
    ConformPlan,
    ConformStep,
    CreateIndexStep,
    CreateTableStep,
    DropTableStep,
    RebuildTableStep,
    SkippedStep,
)
from dbconform.sql_dialect.base import Dialect


def _topological_table_order(
    tables: dict[QualifiedName, TableDef],
) -> list[QualifiedName]:
    """
    Return table names in an order such that referenced tables come first.

    If table A has FK to table B, we create B before A.
    """
    names = list(tables.keys())
    name_set = set(names)
    out_edges: dict[QualifiedName, list[QualifiedName]] = {n: [] for n in names}
    for n in names:
        t = tables[n]
        for fk in t.foreign_keys:
            ref = fk.ref_table
            if ref in name_set and ref != n:
                out_edges[ref].append(n)
    in_degree = dict.fromkeys(names, 0)
    for n in names:
        for m in out_edges[n]:
            in_degree[m] += 1
    zero = deque(k for k, v in in_degree.items() if v == 0)
    result: list[QualifiedName] = []
    while zero:
        n = zero.popleft()
        result.append(n)
        for m in out_edges[n]:
            in_degree[m] -= 1
            if in_degree[m] == 0:
                zero.append(m)
    if len(result) != len(names):
        return names
    return result


class ConformPlanBuilder:
    """
    Builds a ConformPlan from DiffResult and dialect.

    Does not emit DROP TABLE unless allow_drop_extra_tables is True. Does not emit
    DROP COLUMN unless allow_drop_extra_columns is True. Does not emit ALTER COLUMN
    when the change would shrink the column (e.g. reduce length) unless
    allow_shrink_column is True. Tables in DB but not in model are listed
    in plan.extra_tables for reporting only.
    """

    def __init__(
        self,
        dialect: Dialect,
        *,
        allow_drop_extra_tables: bool = False,
        allow_drop_extra_columns: bool = False,
        allow_drop_extra_constraints: bool = True,
        allow_shrink_column: bool = False,
        allow_sqlite_table_rebuild: bool = True,
        report_extra_tables: bool = True,
    ) -> None:
        self.dialect = dialect
        self.allow_drop_extra_tables = allow_drop_extra_tables
        self.allow_drop_extra_columns = allow_drop_extra_columns
        self.allow_drop_extra_constraints = allow_drop_extra_constraints
        self.allow_shrink_column = allow_shrink_column
        self.allow_sqlite_table_rebuild = allow_sqlite_table_rebuild
        self.report_extra_tables = report_extra_tables

    def build(self, diff: DiffResult) -> ConformPlan:
        """Produce an ordered ConformPlan from the diff."""
        steps: list[ConformStep] = []
        extra_tables: list[QualifiedName] = []
        skipped_steps: list[SkippedStep] = []

        if self.report_extra_tables:
            extra_tables = list(diff.removed_tables.keys())

        # Drop tables first (dependents before refs): reverse of create order.
        if self.allow_drop_extra_tables and diff.removed_tables:
            drop_order = list(reversed(_topological_table_order(diff.removed_tables)))
            for name in drop_order:
                if name not in diff.removed_tables:
                    continue
                sql = self.dialect.drop_table_sql(name)
                steps.append(
                    DropTableStep(
                        description=f"Drop table {name}",
                        sql=sql,
                        table_name=name,
                    )
                )

        order = _topological_table_order(diff.added_tables)
        for name in order:
            if name not in diff.added_tables:
                continue
            table = diff.added_tables[name]
            sql = self.dialect.create_table_sql(table)
            steps.append(
                CreateTableStep(
                    description=f"Need to Create table '{name}'",
                    sql=sql,
                    table=table,
                )
            )
            for idx in table.indexes:
                idx_sql = self.dialect.create_index_sql(idx, name)
                steps.append(
                    CreateIndexStep(
                        description=f"Create index {idx.name} on {name}",
                        sql=idx_sql,
                        index=idx,
                        table_name=name,
                    )
                )

        _SKIP_REASON = (
            "SQLite does not support ADD CONSTRAINT for existing tables; "
            "set allow_sqlite_table_rebuild=True to rebuild table (default)"
        )

        for name, table_diff in diff.modified_tables.items():
            needs_rebuild = (
                self.dialect.name == "sqlite"
                and self.allow_sqlite_table_rebuild
                and (
                    table_diff.added_checks
                    or table_diff.added_unique
                    or table_diff.added_foreign_keys
                )
            )

            if needs_rebuild:
                steps.append(
                    RebuildTableStep(
                        description=f"Rebuild table {name} to add constraints (SQLite)",
                        sql=None,
                        table_name=name,
                        target_table=table_diff.new_table,
                        old_table=table_diff.old_table,
                    )
                )
                continue

            if self.allow_drop_extra_constraints:
                for idx in table_diff.removed_indexes:
                    sql = self.dialect.drop_index_sql(idx.name, name)
                    steps.append(
                        AlterTableStep(
                            description=f"Drop index {idx.name} on {name}",
                            sql=sql,
                            table_name=name,
                        )
                    )
                for u in table_diff.removed_unique:
                    drop_sql = self.dialect.drop_unique_sql(name, u)
                    if drop_sql:
                        steps.append(
                            AlterTableStep(
                                description=f"Drop unique constraint on {name}",
                                sql=drop_sql,
                                table_name=name,
                                unique=u,
                            )
                        )
                for fk in table_diff.removed_foreign_keys:
                    drop_sql = self.dialect.drop_foreign_key_sql(name, fk)
                    if drop_sql:
                        steps.append(
                            AlterTableStep(
                                description=f"Drop foreign key on {name}",
                                sql=drop_sql,
                                table_name=name,
                            )
                        )
                for ck in table_diff.removed_checks:
                    drop_sql = self.dialect.drop_check_sql(name, ck)
                    if drop_sql:
                        steps.append(
                            AlterTableStep(
                                description=f"Drop check constraint on {name}",
                                sql=drop_sql,
                                table_name=name,
                            )
                        )
            if self.allow_drop_extra_columns:
                for col in table_diff.removed_columns:
                    drop_sql = self.dialect.drop_column_sql(name, col.name)
                    if drop_sql:
                        steps.append(
                            AlterTableStep(
                                description=f"Drop column `{col.name}` from `{name}`",
                                sql=drop_sql,
                                table_name=name,
                            )
                        )
            else:
                for col in table_diff.removed_columns:
                    skipped_steps.append(
                        SkippedStep(
                            description=f"Drop column `{col.name}` from `{name}`",
                            reason="Column drop blocked: allow_drop_extra_columns=False",
                            table_name=name,
                        )
                    )
            for col in table_diff.added_columns:
                sql = self.dialect.add_column_sql(name, col)
                steps.append(
                    AlterTableStep(
                        description=f"Add column {col.name} to {name}",
                        sql=sql,
                        table_name=name,
                        column=col,
                    )
                )
            for old_col, new_col in table_diff.modified_columns:
                alter_sql = self.dialect.alter_column_sql(name, old_col, new_col)
                if alter_sql:
                    if self.dialect.would_shrink(old_col, new_col) and not self.allow_shrink_column:
                        skipped_steps.append(
                            SkippedStep(
                                description=f"Alter column {new_col.name} on {name}",
                                reason="Column shrink blocked: allow_shrink_column=False",
                                table_name=name,
                            )
                        )
                        continue
                    steps.append(
                        AlterTableStep(
                            description=f"Alter column {new_col.name} on {name}",
                            sql=alter_sql,
                            table_name=name,
                            column=new_col,
                        )
                    )
            for u in table_diff.added_unique:
                if self.dialect.name == "sqlite":
                    skipped_steps.append(
                        SkippedStep(
                            description=f"Add unique constraint on {name}",
                            reason=_SKIP_REASON,
                            table_name=name,
                        )
                    )
                else:
                    sql = self.dialect.add_unique_sql(name, u)
                    steps.append(
                        AlterTableStep(
                            description=f"Add unique constraint on {name}",
                            sql=sql,
                            table_name=name,
                            unique=u,
                        )
                    )
            for fk in table_diff.added_foreign_keys:
                if self.dialect.name == "sqlite":
                    skipped_steps.append(
                        SkippedStep(
                            description=f"Add foreign key on {name}",
                            reason=_SKIP_REASON,
                            table_name=name,
                        )
                    )
                else:
                    sql = self.dialect.add_foreign_key_sql(name, fk)
                    steps.append(
                        AlterTableStep(
                            description=f"Add foreign key on {name}",
                            sql=sql,
                            table_name=name,
                        )
                    )
            for ck in table_diff.added_checks:
                if self.dialect.name == "sqlite":
                    skipped_steps.append(
                        SkippedStep(
                            description=f"Add check constraint on {name}",
                            reason=_SKIP_REASON,
                            table_name=name,
                        )
                    )
                else:
                    sql = self.dialect.add_check_sql(name, ck)
                    steps.append(
                        AlterTableStep(
                            description=f"Add check constraint on {name}",
                            sql=sql,
                            table_name=name,
                        )
                    )
            for idx in table_diff.added_indexes:
                sql = self.dialect.create_index_sql(idx, name)
                steps.append(
                    CreateIndexStep(
                        description=f"Create index {idx.name} on {name}",
                        sql=sql,
                        index=idx,
                        table_name=name,
                    )
                )

        return ConformPlan(steps=steps, extra_tables=extra_tables, skipped_steps=skipped_steps)
