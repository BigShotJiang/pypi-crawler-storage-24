# SPDX-FileCopyrightText: Copyright (c) Fideus Labs LLC
# SPDX-License-Identifier: MIT
import itk
import itkwasm
import numpy as np
from ngff_zarr import from_ngff_zarr, itk_image_to_ngff_image, ngff_image_to_itk_image

from ._data import test_data_dir

rng = np.random.default_rng(12345)


def test_2d_itk_image(input_images):
    itk_image = itk.imread(test_data_dir / "input" / "cthead1.png")
    ngff_image = itk_image_to_ngff_image(itk_image)
    itk_image_back = ngff_image_to_itk_image(ngff_image, wasm=False)
    diff = itk.comparison_image_filter(itk_image, itk_image_back)
    assert np.sum(np.asarray(diff)) == 0.0


def test_2d_rgb_itk_image(input_images):
    array = rng.integers(0, 255, size=(224, 224, 3), dtype=np.uint8)
    itk_image = itk.image_from_array(array, is_vector=True)
    ngff_image = itk_image_to_ngff_image(itk_image)  # noqa: F841
    # Requires fixes for itk
    # itk_image_back = ngff_image_to_itk_image(ngff_image, wasm=False)
    # diff = itk.comparison_image_filter(itk_image, itk_image_back)
    # assert np.sum(np.asarray(diff)) == 0.0


def test_2d_itk_vector_image(input_images):
    array = rng.random(size=(224, 224, 3), dtype=np.float32)
    itk_image = itk.image_from_array(array, is_vector=True)
    ngff_image = itk_image_to_ngff_image(itk_image)  # noqa: F841
    # Requires fixes for itk
    # itk_image_back = ngff_image_to_itk_image(ngff_image, wasm=False)
    # assert np.array_equal(itk.array_from_image(itk_image), itk.array_from_image(itk_image_back))


def test_3d_itk_image(input_images):
    array = rng.integers(0, 255, size=(32, 32, 32), dtype=np.uint8)
    itk_image = itk.image_from_array(array, is_vector=False)
    ngff_image = itk_image_to_ngff_image(itk_image)
    itk_image_back = ngff_image_to_itk_image(ngff_image, wasm=False)
    diff = itk.comparison_image_filter(itk_image, itk_image_back)
    assert np.sum(np.asarray(diff)) == 0.0


def test_3d_itk_vector_image(input_images):
    array = rng.random(size=(224, 224, 128, 3), dtype=np.float32)
    itk_image = itk.image_from_array(array, is_vector=True)
    ngff_image = itk_image_to_ngff_image(itk_image)  # noqa: F841
    # Requires fixes for itk
    # itk_image_back = ngff_image_to_itk_image(ngff_image, wasm=False)
    # assert np.array_equal(itk.array_from_image(itk_image), itk.array_from_image(itk_image_back))


def test_2d_itkwasm_image(input_images):
    itk_image = itk.imread(test_data_dir / "input" / "cthead1.png")
    itk_image_dict = itk.dict_from_image(itk_image)
    itkwasm_image = itkwasm.Image(**itk_image_dict)
    ngff_image = itk_image_to_ngff_image(itkwasm_image)
    itkwasm_image_back = ngff_image_to_itk_image(ngff_image)
    assert np.array_equal(
        np.asarray(itkwasm_image.data), np.asarray(itkwasm_image_back.data)
    )


def test_t_index(input_images):
    dataset_name = "13457537"
    store_path = test_data_dir / "input" / f"{dataset_name}.zarr"
    multiscales = from_ngff_zarr(store_path)
    ngff_image = multiscales.images[0]

    itk_image = ngff_image_to_itk_image(ngff_image)

    assert itk_image.imageType.dimension == 4
    assert itk_image.imageType.components == 6
    assert len(itk_image.size) == 4
    assert len(itk_image.spacing) == 4
    assert len(itk_image.origin) == 4
    assert len(itk_image.direction) == 4
    assert itk_image.data.shape == (18, 12, 223, 198, 6)

    itk_image = ngff_image_to_itk_image(ngff_image, t_index=0)

    assert itk_image.imageType.dimension == 3
    assert itk_image.imageType.components == 6
    assert len(itk_image.size) == 3
    assert len(itk_image.spacing) == 3
    assert len(itk_image.origin) == 3
    assert len(itk_image.direction) == 3
    assert itk_image.data.shape == (12, 223, 198, 6)


def test_c_index(input_images):
    dataset_name = "13457537"
    store_path = test_data_dir / "input" / f"{dataset_name}.zarr"
    multiscales = from_ngff_zarr(store_path)
    ngff_image = multiscales.images[0]

    itk_image = ngff_image_to_itk_image(ngff_image)

    assert itk_image.imageType.dimension == 4
    assert itk_image.imageType.components == 6
    assert len(itk_image.size) == 4
    assert len(itk_image.spacing) == 4
    assert len(itk_image.origin) == 4
    assert len(itk_image.direction) == 4
    assert itk_image.data.shape == (18, 12, 223, 198, 6)

    itk_image = ngff_image_to_itk_image(ngff_image, c_index=0)

    assert itk_image.imageType.dimension == 4
    assert itk_image.imageType.components == 1
    assert len(itk_image.size) == 4
    assert len(itk_image.spacing) == 4
    assert len(itk_image.origin) == 4
    assert len(itk_image.direction) == 4
    assert itk_image.data.shape == (18, 12, 223, 198)

    itk_image = ngff_image_to_itk_image(ngff_image, t_index=0, c_index=0)

    assert itk_image.imageType.dimension == 3
    assert itk_image.imageType.components == 1
    assert len(itk_image.size) == 3
    assert len(itk_image.spacing) == 3
    assert len(itk_image.origin) == 3
    assert len(itk_image.direction) == 3
    assert itk_image.data.shape == (12, 223, 198)


def test_t_index_with_none_axes_units():
    """Test t_index extraction when axes_units is None."""
    import dask.array as da
    from ngff_zarr import NgffImage

    # Create a 4D image with t, z, y, x dimensions
    data = da.zeros((2, 4, 8, 8), dtype=np.uint8)
    ngff_image = NgffImage(
        data=data,
        dims=("t", "z", "y", "x"),
        scale={"t": 1.0, "z": 1.0, "y": 1.0, "x": 1.0},
        translation={"t": 0.0, "z": 0.0, "y": 0.0, "x": 0.0},
        axes_units=None,  # This is the key part - axes_units is None
    )

    # This should not raise TypeError
    itk_image = ngff_image_to_itk_image(ngff_image, t_index=0)
    assert itk_image is not None
    # Verify that t_index actually reduced dimensions (from 4D to 3D)
    assert itk_image.imageType.dimension == 3
    assert len(itk_image.size) == 3
    assert itk_image.data.shape == (4, 8, 8)  # (z, y, x) after removing t


def test_c_index_with_none_axes_units():
    """Test c_index extraction when axes_units is None."""
    import dask.array as da
    from ngff_zarr import NgffImage

    # Create a 4D image with c, z, y, x dimensions
    data = da.zeros((3, 4, 8, 8), dtype=np.uint8)
    ngff_image = NgffImage(
        data=data,
        dims=("c", "z", "y", "x"),
        scale={"c": 1.0, "z": 1.0, "y": 1.0, "x": 1.0},
        translation={"c": 0.0, "z": 0.0, "y": 0.0, "x": 0.0},
        axes_units=None,  # This is the key part - axes_units is None
    )

    # This should not raise TypeError
    itk_image = ngff_image_to_itk_image(ngff_image, c_index=0)
    assert itk_image is not None
    # Verify that c_index actually reduced components (from 3 to 1)
    assert itk_image.imageType.dimension == 3
    assert itk_image.imageType.components == 1
    assert len(itk_image.size) == 3
    assert itk_image.data.shape == (4, 8, 8)  # (z, y, x) after removing c


def test_t_and_c_index_with_none_axes_units():
    """Test both t_index and c_index extraction when axes_units is None."""
    import dask.array as da
    from ngff_zarr import NgffImage

    # Create a 5D image with t, c, z, y, x dimensions
    data = da.zeros((2, 3, 4, 8, 8), dtype=np.uint8)
    ngff_image = NgffImage(
        data=data,
        dims=("t", "c", "z", "y", "x"),
        scale={"t": 1.0, "c": 1.0, "z": 1.0, "y": 1.0, "x": 1.0},
        translation={"t": 0.0, "c": 0.0, "z": 0.0, "y": 0.0, "x": 0.0},
        axes_units=None,  # This is the key part - axes_units is None
    )

    # This should not raise TypeError
    itk_image = ngff_image_to_itk_image(ngff_image, t_index=0, c_index=0)
    assert itk_image is not None
    # Verify that both t_index and c_index reduced dimensions (from 5D to 3D)
    assert itk_image.imageType.dimension == 3
    assert itk_image.imageType.components == 1
    assert len(itk_image.size) == 3
    assert itk_image.data.shape == (4, 8, 8)  # (z, y, x) after removing t and c


def test_t_index_with_partial_axes_units():
    """Test t_index extraction when axes_units has only some dimensions."""
    import dask.array as da
    from ngff_zarr import NgffImage

    # Create a 4D image with t, z, y, x dimensions
    # axes_units only has 'z', missing 't', 'y', 'x'
    data = da.zeros((2, 4, 8, 8), dtype=np.uint8)
    ngff_image = NgffImage(
        data=data,
        dims=("t", "z", "y", "x"),
        scale={"t": 1.0, "z": 1.0, "y": 1.0, "x": 1.0},
        translation={"t": 0.0, "z": 0.0, "y": 0.0, "x": 0.0},
        axes_units={"z": "micrometer"},  # Partial mapping - only 'z' has units
    )

    # This should not raise KeyError
    itk_image = ngff_image_to_itk_image(ngff_image, t_index=0)
    assert itk_image is not None
    # Verify that t_index actually reduced dimensions (from 4D to 3D)
    assert itk_image.imageType.dimension == 3
    assert len(itk_image.size) == 3
    assert itk_image.data.shape == (4, 8, 8)  # (z, y, x) after removing t


def test_c_index_with_empty_axes_units():
    """Test c_index extraction when axes_units is an empty dict."""
    import dask.array as da
    from ngff_zarr import NgffImage

    # Create a 4D image with c, z, y, x dimensions
    data = da.zeros((3, 4, 8, 8), dtype=np.uint8)
    ngff_image = NgffImage(
        data=data,
        dims=("c", "z", "y", "x"),
        scale={"c": 1.0, "z": 1.0, "y": 1.0, "x": 1.0},
        translation={"c": 0.0, "z": 0.0, "y": 0.0, "x": 0.0},
        axes_units={},  # Empty dict - should be preserved as empty dict
    )

    # This should not raise KeyError
    itk_image = ngff_image_to_itk_image(ngff_image, c_index=0)
    assert itk_image is not None
    # Verify that c_index actually reduced components (from 3 to 1)
    assert itk_image.imageType.dimension == 3
    assert itk_image.imageType.components == 1
    assert len(itk_image.size) == 3
    assert itk_image.data.shape == (4, 8, 8)  # (z, y, x) after removing c
