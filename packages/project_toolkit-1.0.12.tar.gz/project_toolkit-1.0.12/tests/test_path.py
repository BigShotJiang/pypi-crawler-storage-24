import os
import pathlib
import pytest
import shutil
import inspect
from project_toolkit.project_path import DataPathConfig

@pytest.fixture
def clean_env(monkeypatch):
    # Remove environment variables for isolation (though class doesn't use them)
    monkeypatch.delenv("DATA_DIR", raising=False)
    # LOG_DIR removed from API; no action needed

def print_green(msg):
    print(f"\033[92m{msg}\033[0m")

def print_detail(label, actual, expected=None):
    if expected is not None:
        print(f"{label}: actual={actual} expected={expected}")
    else:
        print(f"{label}: {actual}")

def test_data_dir_base(tmp_path, clean_env):
    print_green("Running test_data_dir_base...")
    # Use /tmp/data for testing
    data_root = pathlib.Path("/tmp/data")
    data_root.mkdir(parents=True, exist_ok=True)
    pc = DataPathConfig(
        project_name="projA",
        data_dir=str(data_root),
        subproject="subA"
    )
    print_detail("data_dir", pc.data_dir(), data_root.resolve())
    print_detail("project_dir", pc.project_dir(), (data_root / "projA").resolve())
    print_detail("sub_project_dir", pc.sub_project_dir(), (data_root / "projA" / "subA").resolve())
    assert pc.data_dir() == data_root.resolve()
    assert pc.project_dir() == (data_root / "projA").resolve()
    assert pc.sub_project_dir() == (data_root / "projA" / "subA").resolve()
    print_green("test_data_dir_base passed.")
    # Cleanup
    shutil.rmtree(data_root, ignore_errors=True)

def test_root_dir_base(tmp_path, clean_env):
    print_green("Running test_root_dir_base...")
    root_path = pathlib.Path("/tmp")
    data_root = pathlib.Path("/tmp/data")
    root_path.mkdir(parents=True, exist_ok=True)
    data_root.mkdir(parents=True, exist_ok=True)
    # Print signature is left out; focus on functional test output.
    pc = DataPathConfig(
        project_name="projB",
        root_dir=str(root_path),
        data_dir=str(data_root),
        subproject="subB"
    )
    print_detail("root_dir", pc.get_root_dir(), root_path.resolve())
    print_detail("data_dir", pc.data_dir(), data_root.resolve())
    print_detail("project_dir", pc.project_dir(), (data_root / "projB").resolve())
    print_detail("sub_project_dir", pc.sub_project_dir(), (data_root / "projB" / "subB").resolve())
    assert pc.get_root_dir() == root_path.resolve()
    assert pc.data_dir() == data_root.resolve()
    assert pc.project_dir() == (data_root / "projB").resolve()
    assert pc.sub_project_dir() == (data_root / "projB" / "subB").resolve()
    print_green("test_root_dir_base passed.")
    # Cleanup
    shutil.rmtree(data_root, ignore_errors=True)

def test_no_subproject_raises(tmp_path, clean_env):
    print_green("Running test_no_subproject_raises...")
    data_root = pathlib.Path("/tmp/data")
    data_root.mkdir(parents=True, exist_ok=True)
    pc = DataPathConfig(
        project_name="projC",
        data_dir=str(data_root),
        subproject=None
    )
    print_detail("sub_project_dir (expect raise)", pc.project_dir())
    with pytest.raises(ValueError):
        pc.sub_project_dir()
    print_green("test_no_subproject_raises passed.")
    # Cleanup
    shutil.rmtree(data_root, ignore_errors=True)

def test_get_project_today_file_name():
    print_green("Running test_get_project_today_file_name...")
    data_root = pathlib.Path("/tmp/data")
    data_root.mkdir(parents=True, exist_ok=True)
    pc = DataPathConfig(
        project_name="projD",
        data_dir=str(data_root),
        subproject="subD"
    )
    from datetime import date
    expected = pc.sub_project_dir() / f"projD_subD_{date.today()}.json"
    print_detail("subproject_today_file", pc.get_project_today_file_name(), expected)
    assert pc.get_project_today_file_name() == expected
    print_green("test_get_project_today_file_name passed.")
    # Cleanup
    shutil.rmtree(data_root, ignore_errors=True)

def test_get_project_today_file_name_no_subproject():
    print_green("Running test_get_project_today_file_name_no_subproject...")
    data_root = pathlib.Path("/tmp/data")
    data_root.mkdir(parents=True, exist_ok=True)
    pc = DataPathConfig(
        project_name="projE",
        data_dir=str(data_root),
        subproject=None
    )
    from datetime import date
    expected = pc.project_dir() / f"projE_{date.today()}.json"
    print_detail("project_today_file", pc.get_project_today_file_name(), expected)
    assert pc.get_project_today_file_name() == expected
    print_green("test_get_project_today_file_name_no_subproject passed.")
    # Cleanup
    shutil.rmtree(data_root, ignore_errors=True)

def test_default_data_under_root(tmp_path, clean_env):
    print_green("Running test_default_data_under_root...")
    root_path = pathlib.Path("/tmp/root_dir")
    data_under_root = pathlib.Path("/tmp/root_dir/data")
    root_path.mkdir(parents=True, exist_ok=True)
    # Create data_under_root so base data dir exists
    data_under_root.mkdir(parents=True, exist_ok=True)
    # Print signature is left out; focus on functional test output.
    pc = DataPathConfig(
        project_name="projF",
        root_dir=str(root_path),
        data_dir=None,
        subproject=None
    )
    # data_dir should default to /tmp/root_dir/data
    print_detail("data_dir", pc.data_dir(), data_under_root.resolve())
    print_detail("project_dir", pc.project_dir(), (data_under_root / "projF").resolve())
    assert pc.data_dir() == data_under_root.resolve()
    assert pc.project_dir() == (data_under_root / "projF").resolve()
    print_green("test_default_data_under_root passed.")
    # Cleanup
    shutil.rmtree(root_path, ignore_errors=True)
