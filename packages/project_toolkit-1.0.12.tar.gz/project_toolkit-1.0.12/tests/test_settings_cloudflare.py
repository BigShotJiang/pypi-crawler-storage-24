"""Tests for Cloudflare settings and clients using .env.dev configuration."""

import pytest

from project_toolkit.settings.base import get_settings
from project_toolkit.settings.cloudflare import CloudflareSettings


class TestCloudflareSettings:
    """Test CloudflareSettings loading from .env.dev."""

    def setup_method(self):
        get_settings.cache_clear()

    def test_loads_r2_access_token(self):
        """R2_ACCESS_TOKEN should be loaded from .env.dev."""
        settings = get_settings()
        assert settings.cloudflare.r2_access_token is not None
        assert len(settings.cloudflare.r2_access_token) > 0
        print(f"R2 Access Token: {settings.cloudflare.r2_access_token[:8]}...")

    def test_loads_r2_account_id(self):
        """R2_ACCOUNT_ID should be loaded from .env.dev."""
        settings = get_settings()
        assert settings.cloudflare.r2_account_id is not None
        assert len(settings.cloudflare.r2_account_id) > 0
        print(f"R2 Account ID: {settings.cloudflare.r2_account_id[:8]}...")

    def test_loads_r2_domain(self):
        """R2_DOMAIN should be loaded from .env.dev."""
        settings = get_settings()
        assert settings.cloudflare.r2_domain is not None
        assert settings.cloudflare.r2_domain.startswith("https://")
        print(f"R2 Domain: {settings.cloudflare.r2_domain}")

    def test_cloudflare_settings_used_by_requests_client(self):
        """CloudflareRequestsClient should accept settings."""
        from project_toolkit.cloudflare.requests_client import CloudflareRequestsClient

        settings = get_settings()
        client = CloudflareRequestsClient.from_settings(settings.cloudflare)
        assert client.token == settings.cloudflare.r2_access_token
        print("CloudflareRequestsClient created from settings OK")

    def test_cloudflare_requests_client_validate_token(self):
        """Validate token using the requests client with settings."""
        from project_toolkit.cloudflare.requests_client import CloudflareRequestsClient

        settings = get_settings()
        client = CloudflareRequestsClient.from_settings(settings.cloudflare)
        is_valid, data = client.validate_token()
        print(f"Token valid: {is_valid}")
        assert isinstance(is_valid, bool)
