"""
WanIP — fetch public WAN IP addresses via curl.

Supports HTTP/2 and HTTP/3 (when curl has nghttp3/HTTP3 support),
both IPv4 and IPv6, with configurable timeout and URL.

Usage::

    from project_toolkit.ip_tool.wan_ip import WanIP

    wan_ip = WanIP()
    print(wan_ip.ipv4())       # "1.2.3.4"
    print(wan_ip.ipv6())       # "2001:db8::1" or "unreachable"
    print(wan_ip.h3ipv4())     # HTTP/3 IPv4
    print(wan_ip.h3ipv6())     # HTTP/3 IPv6
"""

from __future__ import annotations

import ipaddress
import shutil
import subprocess
from typing import Optional


class WanIP:
    """Fetch public WAN IP addresses using curl.

    Provides individual fetch methods for every combination of
    protocol (HTTP/2 vs HTTP/3) and address family (IPv4 vs IPv6).

    Args:
        url: The URL to query for the IP address.
        curl_path: Explicit path to a curl binary (auto-detected if omitted).
        timeout: Maximum seconds to wait for a response.
    """

    UNREACHABLE = "unreachable"

    def __init__(
        self,
        url: str = "https://ifconfig.me/ip",
        curl_path: Optional[str] = None,
        timeout: int = 5,
    ):
        self.url = url
        self.timeout = timeout
        self.curl = curl_path or self._find_curl()
        self.has_h3 = self._check_h3_support() if self.curl else False

    # ------------------------------------------------------------------
    # Curl discovery
    # ------------------------------------------------------------------

    @staticmethod
    def _find_curl() -> Optional[str]:
        """Locate preferred curl executable.

        Prefers Homebrew curl (often compiled with HTTP/3) over system curl.
        """
        candidates = ["/opt/homebrew/opt/curl/bin/curl", "curl"]
        return next((c for c in candidates if shutil.which(c)), None)

    def _check_h3_support(self) -> bool:
        """Return *True* if the selected curl binary supports HTTP/3."""
        if not self.curl:
            return False
        version_output = subprocess.getoutput(f"{self.curl} --version")
        return any(token in version_output for token in ("HTTP3", "nghttp3"))

    # ------------------------------------------------------------------
    # Low-level fetch
    # ------------------------------------------------------------------

    def fetch(self, *, ipv6: bool = False, h3: bool = False, timeout: Optional[int] = None) -> str:
        """Fetch the public IP address via curl.

        Args:
            ipv6: Use IPv6 (``-6``) instead of IPv4 (``-4``).
            h3: Use ``--http3-only`` instead of ``--http2``.
            timeout: Override the instance-level timeout.

        Returns:
            The IP address string, or :pyattr:`UNREACHABLE` on failure.
        """
        if not self.curl:
            return self.UNREACHABLE

        effective_timeout = timeout if timeout is not None else self.timeout
        cmd = [
            self.curl, "-fsS",
            "--max-time", str(effective_timeout),
            "-6" if ipv6 else "-4",
        ]
        cmd += ["--http3-only"] if h3 else ["--http2"]
        cmd.append(self.url)

        try:
            return subprocess.check_output(
                cmd, text=True, stderr=subprocess.DEVNULL,
            ).strip()
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            return self.UNREACHABLE

    # ------------------------------------------------------------------
    # Convenience accessors
    # ------------------------------------------------------------------

    def ipv4(self, timeout: Optional[int] = None) -> str:
        """Fetch IPv4 via HTTP/2."""
        return self.fetch(ipv6=False, h3=False, timeout=timeout)

    def ipv6(self, timeout: Optional[int] = None) -> str:
        """Fetch IPv6 via HTTP/2.

        If the returned address is actually an IPv4 address (no real v6
        connectivity), ``UNREACHABLE`` is returned instead.
        """
        result = self.fetch(ipv6=True, h3=False, timeout=timeout)
        return self._validate_ipv6(result)

    def h3ipv4(self, timeout: Optional[int] = None) -> str:
        """Fetch IPv4 via HTTP/3 (requires curl with HTTP/3 support)."""
        if not self.has_h3:
            return self.UNREACHABLE
        return self.fetch(ipv6=False, h3=True, timeout=timeout)

    def h3ipv6(self, timeout: Optional[int] = None) -> str:
        """Fetch IPv6 via HTTP/3 (requires curl with HTTP/3 support)."""
        if not self.has_h3:
            return self.UNREACHABLE
        result = self.fetch(ipv6=True, h3=True, timeout=timeout)
        return self._validate_ipv6(result)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @classmethod
    def _validate_ipv6(cls, ip_str: str) -> str:
        """Return *UNREACHABLE* if *ip_str* is not a valid IPv6 address.

        Some hosts with no IPv6 connectivity get an IPv4 address back
        from ``curl -6``; this guard catches that case.
        """
        if ip_str == cls.UNREACHABLE:
            return cls.UNREACHABLE
        try:
            if ipaddress.ip_address(ip_str).version != 6:
                return cls.UNREACHABLE
        except ValueError:
            return cls.UNREACHABLE
        return ip_str

    # ------------------------------------------------------------------
    # Bulk operations
    # ------------------------------------------------------------------

    def fetch_all(self) -> dict[str, str]:
        """Fetch all available IPs and return a dict.

        Keys: ``h2v4``, ``h3v4``, ``h2v6``, ``h3v6``.
        Missing entries (unreachable or H3 unsupported) are omitted.
        """
        results: dict[str, str] = {}

        # 1. Fetch IPv4 (H2 then H3)
        v4 = self.ipv4()
        if v4 != self.UNREACHABLE:
            results["h2v4"] = v4

        if self.has_h3:
            h3v4 = self.h3ipv4()
            if h3v4 != self.UNREACHABLE:
                results["h3v4"] = h3v4

        # 2. Fetch IPv6 (H2 then H3)
        v6 = self.ipv6()
        if v6 != self.UNREACHABLE:
            results["h2v6"] = v6

        if self.has_h3:
            h3v6 = self.h3ipv6()
            if h3v6 != self.UNREACHABLE:
                results["h3v6"] = h3v6

        return results

    def get_report_parts(self) -> list[str]:
        """Return human-readable report lines.

        If H2 and H3 results match for a version they are collapsed
        into a single line (e.g. ``v4: 1.2.3.4``); otherwise separate
        ``H2v4`` / ``H3v4`` lines are produced.
        """
        all_ips = self.fetch_all()
        parts: list[str] = []

        for v in (4, 6):
            h2_key = f"h2v{v}"
            h3_key = f"h3v{v}"
            h2 = all_ips.get(h2_key)
            h3 = all_ips.get(h3_key)

            if h2 is None and h3 is None:
                continue

            label = f"v{v}"
            if h3 is None:
                # H3 not available or not supported
                parts.append(f"{label}: {h2}")
            elif h2 == h3:
                parts.append(f"{label}: {h2}")
            else:
                if h2 is not None:
                    parts.append(f"H2{label}: {h2}")
                if h3 is not None:
                    parts.append(f"H3{label}: {h3}")

        return parts

    def get_report_string(self, separator: str = "\t") -> str:
        """Return a single-line string with all IP results joined by *separator*."""
        return separator.join(self.get_report_parts())

    def report(self, separator: str = "\t") -> str:
        """Alias for :meth:`get_report_string`."""
        return self.get_report_string(separator=separator)

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"WanIP(url={self.url!r}, curl={self.curl!r}, "
            f"timeout={self.timeout}, has_h3={self.has_h3})"
        )

