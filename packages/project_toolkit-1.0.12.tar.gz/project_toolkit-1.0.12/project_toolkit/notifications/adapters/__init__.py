"""Framework-specific adapters that normalise callback signatures into NotificationContext."""
