"""
Prefect adapter — translates Prefect hook arguments into NotificationContext.

Prefect hooks receive ``(flow, flow_run, state)`` positional arguments.
This adapter maps those objects to the shared context so the notifier
stays framework-agnostic.

Usage::

    # Zero-config — reads DISCORD_PREFECT_WEBHOOK_URL from env / .env
    from project_toolkit.notifications.adapters.prefect import PrefectAdapter

    hooks = PrefectAdapter()

    # Or pass an explicit notifier
    from project_toolkit.notifications.discord import DiscordNotifier

    notifier = DiscordNotifier(webhook_url="...")
    hooks = PrefectAdapter(notifier)

    @flow(
        on_failure=[hooks.on_failure],
        on_completion=[hooks.on_success],
        on_crashed=[hooks.on_crashed],
    )
    def my_flow():
        ...
"""

from __future__ import annotations

import logging
from typing import Optional

from project_toolkit.notifications.context import NotificationContext
from project_toolkit.notifications.discord import DiscordNotifier

logger = logging.getLogger(__name__)

_DEFAULT_ENV_KEY = "DISCORD_PREFECT_WEBHOOK_URL"


class PrefectAdapter:
    """Thin adapter from Prefect hook signature to :class:`DiscordNotifier`.

    When *notifier* is omitted the adapter auto-creates a
    :class:`DiscordNotifier` using the ``DISCORD_PREFECT_WEBHOOK_URL``
    environment variable (or ``.env`` value).

    Args:
        notifier: A configured :class:`DiscordNotifier` instance.
            If ``None``, one is created from
            ``DISCORD_PREFECT_WEBHOOK_URL``.
    """

    def __init__(self, notifier: Optional[DiscordNotifier] = None):
        if notifier is None:
            from project_toolkit.settings import get_settings
            settings = get_settings()
            webhook_url = settings.env(_DEFAULT_ENV_KEY, "")
            notifier = DiscordNotifier(webhook_url=webhook_url)
        self.notifier = notifier

    def _build_context(self, status: str, flow, flow_run, state) -> NotificationContext:
        """Map Prefect objects to a framework-agnostic context."""
        return NotificationContext(
            status=status,
            flow_name=getattr(flow, "name", "unknown"),
            run_name=getattr(flow_run, "name", str(getattr(flow_run, "id", "unknown"))),
            run_id=str(getattr(flow_run, "id", "")) or None,
            error_message=str(getattr(state, "message", "")) or None,
            start_time=getattr(flow_run, "start_time", None),
            extra_fields=[
                {"name": "Environment", "value": getattr(flow, "name", "n/a"), "inline": True},
            ],
        )

    # ------------------------------------------------------------------
    # Prefect hook callbacks — signature: (flow, flow_run, state)
    # ------------------------------------------------------------------

    def on_failure(self, flow, flow_run, state) -> None:
        """Hook for ``on_failure``."""
        logger.info("Prefect on_failure hook triggered for flow=%s", getattr(flow, "name", "?"))
        self.notifier.notify(self._build_context("failure", flow, flow_run, state))

    def on_success(self, flow, flow_run, state) -> None:
        """Hook for ``on_completion``."""
        logger.info("Prefect on_success hook triggered for flow=%s", getattr(flow, "name", "?"))
        self.notifier.notify(self._build_context("success", flow, flow_run, state))

    def on_crashed(self, flow, flow_run, state) -> None:
        """Hook for ``on_crashed``."""
        logger.info("Prefect on_crashed hook triggered for flow=%s", getattr(flow, "name", "?"))
        self.notifier.notify(self._build_context("warning", flow, flow_run, state))
