"""
Notifications module — framework-agnostic pipeline notifications.

Provides a core Discord notifier with thin adapters that normalize
each framework's callback signature into a shared NotificationContext.

Quick start::

    from project_toolkit.notifications.adapters.prefect import PrefectAdapter

    # Zero-config — reads DISCORD_PREFECT_WEBHOOK_URL from env / .env
    hooks = PrefectAdapter()

    # Attach to a Prefect flow
    @flow(on_failure=[hooks.on_failure])
    def my_flow():
        ...
"""
