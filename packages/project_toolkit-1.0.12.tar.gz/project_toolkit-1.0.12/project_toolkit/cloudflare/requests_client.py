import os
import logging
from typing import Optional

import requests

logger = logging.getLogger(__name__)


class CloudflareRequestsClient:
    """Cloudflare API client using the requests library.

    Can be initialized with explicit args or from CloudflareSettings:

        # Zero-config (reads CLOUDFLARE_API_TOKEN from env)
        client = CloudflareRequestsClient()

        # Explicit
        client = CloudflareRequestsClient(token="...")

        # From settings
        from project_toolkit.settings import get_settings
        client = CloudflareRequestsClient.from_settings(get_settings().cloudflare)
    """

    def __init__(self, token: Optional[str] = None):
        if token is None:
            token = os.environ.get("CLOUDFLARE_API_TOKEN")
        if token is None:
            from project_toolkit.settings import get_settings
            settings = get_settings().cloudflare
            token = settings.api_token  # standard > legacy
        if not token:
            raise ValueError(
                "Token must be provided or set via CLOUDFLARE_API_TOKEN "
                "or R2_ACCESS_TOKEN environment variable"
            )
        self.token = token
        self.headers = {"Authorization": f"Bearer {token}"}
        self.base_url = "https://api.cloudflare.com/client/v4"
        self.account_id = None

    @classmethod
    def from_settings(cls, cloudflare_settings) -> "CloudflareRequestsClient":
        """Create client from a CloudflareSettings instance.

        Args:
            cloudflare_settings: A CloudflareSettings instance.

        Returns:
            Configured CloudflareRequestsClient.
        """
        return cls(token=cloudflare_settings.api_token)

    def validate_token(self):
        response = requests.get(
            f"{self.base_url}/user/tokens/verify", headers=self.headers
        )
        if response.status_code == 200:
            return True, response.json()
        else:
            return False, response.text

    def get_token_status(self):
        return self.validate_token()

    def get_id(self):
        success, data = self.validate_token()
        if success:
            return data["result"]["id"]
        return None

    def get_account_id_name(self):
        response = requests.get(
            f"{self.base_url}/accounts", headers=self.headers
        )
        if response.status_code == 200:
            accounts = response.json()["result"]
            if accounts:
                self.account_id = accounts[0]["id"]
                name = accounts[0]["name"]
                return self.account_id, name
            return None, None
        return None, None

    def get_buckets(self):
        if not self.account_id:
            self.get_account_id_name()
        if self.account_id:
            response = requests.get(
                f"{self.base_url}/accounts/{self.account_id}/r2/buckets",
                headers=self.headers,
            )
            if response.status_code == 200:
                buckets = response.json()["result"]["buckets"]
                return buckets
            return None
        return None