"""Vault configuration settings module."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger(__name__)


class VaultSettings(BaseSettings):
    """Settings for HashiCorp Vault integration.

    Connects to Vault using VAULT_ADDR and VAULT_TOKEN (same env vars
    as the official ``vault`` CLI).

    Env vars loaded automatically: VAULT_ADDR, VAULT_TOKEN

    Example .env.dev::

        VAULT_ADDR=http://192.168.12.2:8200
        VAULT_TOKEN=hvs.xxxxx

    Usage::

        from project_toolkit.settings.base import get_settings

        settings = get_settings()
        secret = settings.vault.read_secret("secret/gcp/credentials")
        print(secret)  # {'username': 'admin', 'password': 'secret-password-123'}
    """

    model_config = SettingsConfigDict(extra="ignore")

    vault_addr: Optional[str] = Field(
        default=None,
        description="Vault server address (e.g., http://192.168.12.2:8200).",
    )
    vault_token: Optional[str] = Field(
        default=None,
        description="Vault authentication token.",
    )

    @property
    def is_configured(self) -> bool:
        """Check if Vault connection details are available."""
        return bool(self.vault_addr and self.vault_token)

    def get_vault_client(self):
        """Create and return an hvac Vault client if configured.

        Returns:
            hvac.Client or None if vault is not configured or hvac is not installed.
        """
        if not self.is_configured:
            return None
        try:
            import hvac

            client = hvac.Client(url=self.vault_addr, token=self.vault_token)
            if client.is_authenticated():
                return client
            logger.warning("Vault client authentication failed")
            return None
        except ImportError:
            logger.warning(
                "hvac package not installed. Install with: pip install project-toolkit[vault]"
            )
            return None

    def read_secret(self, path: str) -> Optional[Dict[str, Any]]:
        """Read a secret from Vault KV v2 engine.

        Works like ``vault kv get <path>``. The path format is
        ``<mount>/<secret-name>`` — for example ``secret/gcp/credentials``
        maps to mount ``secret`` and secret name ``gcp/credentials``.

        Args:
            path: Vault KV path, e.g. ``"secret/my-credentials"``
                  or ``"secret/gcp/credentials"``.

        Returns:
            Dict of secret key-value pairs, or None if unavailable.

        Examples::

            settings = get_settings()

            # Read a secret (like: vault kv get secret/my-credentials)
            creds = settings.vault.read_secret("secret/my-credentials")
            print(creds["username"])  # 'admin'
            print(creds["password"])  # 'secret-password-123'

            # Read another path (like: vault kv get secret/gcp/credentials)
            gcp = settings.vault.read_secret("secret/gcp/credentials")
        """
        client = self.get_vault_client()
        if client is None:
            return None

        try:
            # Parse mount point and secret name from path.
            # "secret/my-credentials"       → mount="secret", name="my-credentials"
            # "secret/gcp/credentials"      → mount="secret", name="gcp/credentials"
            # "secret/data/my-credentials"  → mount="secret", name="my-credentials"  (strip /data/)
            parts = path.split("/")
            if len(parts) < 2:
                logger.error("Invalid secret path '%s' — expected <mount>/<name>", path)
                return None

            mount_point = parts[0]

            # If the user passes the full API path with /data/, strip it
            if len(parts) >= 3 and parts[1] == "data":
                secret_name = "/".join(parts[2:])
            else:
                secret_name = "/".join(parts[1:])

            response = client.secrets.kv.v2.read_secret_version(
                path=secret_name,
                mount_point=mount_point,
                raise_on_deleted_version=True,
            )
            data = response.get("data", {}).get("data", {})
            logger.info(
                "Successfully read secret from Vault: %s/%s", mount_point, secret_name
            )
            return data

        except Exception as e:
            logger.error("Failed to read secret from Vault: %s", e)
            return None

    def read_field(self, path: str, field: str, default: Any = None) -> Any:
        """Read a single field from a Vault secret.

        Works like ``vault kv get -field=<field> <path>``.

        Args:
            path: Vault KV path (e.g., ``"secret/api"``).
            field: Field name to extract (e.g., ``"OPENAI_API_KEY"``).
            default: Fallback value if the field is not found.

        Returns:
            The field value, or default if not found.

        Examples::

            # Like: vault kv get -field=OPENAI_API_KEY secret/api
            key = settings.vault.read_field("secret/api", "OPENAI_API_KEY")

            # Like: vault kv get -field=password secret/my-credentials
            pwd = settings.vault.read_field("secret/my-credentials", "password")
        """
        data = self.read_secret(path)
        if data is None:
            return default
        return data.get(field, default)
