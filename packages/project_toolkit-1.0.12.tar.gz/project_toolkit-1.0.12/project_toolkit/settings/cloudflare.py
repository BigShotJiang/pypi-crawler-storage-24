"""Cloudflare configuration settings module.

Supports both the **standard** env vars used by the official
``cloudflare-python`` SDK and the **legacy** ``R2_*`` env vars:

=========================  ===========================
Standard env var           Legacy env var
=========================  ===========================
CLOUDFLARE_API_TOKEN       R2_ACCESS_TOKEN
CLOUDFLARE_ACCOUNT_ID      R2_ACCOUNT_ID
CLOUDFLARE_ZONE_ID         (no legacy equivalent)
=========================  ===========================

Both sets are loaded; the standard names take priority when both are set.
"""

from __future__ import annotations

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class CloudflareSettings(BaseSettings):
    """Settings for Cloudflare services (API, R2, DNS, KV, D1, …).

    Env vars loaded automatically:
        CLOUDFLARE_API_TOKEN, CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_ZONE_ID,
        R2_ACCESS_TOKEN, R2_ACCOUNT_ID, R2_DOMAIN
    """

    model_config = SettingsConfigDict(extra="ignore")

    # --- Standard env vars (official SDK convention) ---
    cloudflare_api_token: Optional[str] = Field(
        default=None,
        description=(
            "Cloudflare API token (standard). "
            "Falls back to R2_ACCESS_TOKEN if not set."
        ),
    )
    cloudflare_account_id: Optional[str] = Field(
        default=None,
        description=(
            "Cloudflare account ID (standard). "
            "Falls back to R2_ACCOUNT_ID if not set."
        ),
    )
    cloudflare_zone_id: Optional[str] = Field(
        default=None,
        description=(
            "Default Cloudflare zone ID. Domain-specific zone IDs "
            "can be set via {KEY}_ZONE_ID env vars (e.g. LGNAT_ZONE_ID)."
        ),
    )

    # --- Legacy R2-specific env vars ---
    r2_access_key_id: Optional[str] = Field(
        default=None,
        description="Cloudflare R2 AWS Access Key ID.",
    )
    r2_secret_access_key: Optional[str] = Field(
        default=None,
        description="Cloudflare R2 AWS Secret Access Key.",
    )
    r2_access_token: Optional[str] = Field(
        default=None,
        description="Cloudflare R2 API access token (legacy).",
    )
    r2_account_id: Optional[str] = Field(
        default=None,
        description="Cloudflare account ID (legacy).",
    )
    r2_domain: Optional[str] = Field(
        default=None,
        description="Custom R2 domain URL (e.g., https://r2.example.com/).",
    )

    @property
    def api_token(self) -> Optional[str]:
        """Resolved API token (standard takes priority over legacy)."""
        return self.cloudflare_api_token or self.r2_access_token

    @property
    def account_id(self) -> Optional[str]:
        """Resolved account ID (standard takes priority over legacy)."""
        return self.cloudflare_account_id or self.r2_account_id
