"""
Trading context for strategy framework.

Provides access to market data, positions, orders, and account information.
"""

from typing import Dict, List, Optional, Any, Callable
from datetime import datetime
import uuid

from ..models import Position, PositionSide, ClosedPosition, AccountInfo, OrderData, Symbol
from ..utils.logging_config import VeroLogger


logger = VeroLogger("context")

# Type for trade-closed listener: receives ClosedPosition
TradeClosedListener = Callable[[ClosedPosition], None]


class TradingContext:
    """
    Trading context providing access to all trading data.
    
    Single source of truth for trade processing. Both backtest engine
    and live Strategy send trade events here; context handles all
    balance, PnL, equity, NAV, metrics, and notifies listeners.
    
    Used by Strategy to access:
    - symbols: Dict of Symbol objects with market data
    - positions: Dict of open Position objects
    - orders: Dict of pending OrderData objects
    - history: List of ClosedPosition objects
    - account: AccountInfo
    """
    
    def __init__(self, account_id: str = "", initial_capital: float = 100000, max_nav_usage_pct: float = 100.0):
        # Symbols
        self._symbols: Dict[str, Symbol] = {}
        
        # Positions and orders
        self._positions: Dict[str, Position] = {}
        self._orders: Dict[str, OrderData] = {}
        self._history: List[ClosedPosition] = []
        
        # Account
        self._account = AccountInfo(
            account_id=account_id,
            equity=initial_capital,
            balance=initial_capital,
            free_margin=initial_capital,
        )
        
        # Tracking
        self._initial_capital = initial_capital
        self._peak_equity = initial_capital
        self._daily_pnl = 0.0
        self._daily_start_equity = initial_capital
        
        # Equity curve (for metrics calculation in both live and backtest)
        self._equity_curve: List[float] = [initial_capital]
        self._equity_dates: List[int] = [int(datetime.now().timestamp() * 1000)]
        self._start_time: int = int(datetime.now().timestamp() * 1000)
        
        # NAV Management
        self._max_nav_usage_pct = max_nav_usage_pct  # Max % of NAV to use
        self._max_nav = initial_capital * max_nav_usage_pct / 100
        self._used_nav = 0.0  # Currently reserved NAV
        self._reserved_orders: Dict[str, float] = {}  # order_id -> reserved amount
        
        # Current time (for backtesting)
        self._current_time = int(datetime.now().timestamp() * 1000)  # Unix ms
        
        # Trade-closed listeners (strategy, risk manager, callbacks notify through here)
        self._on_trade_closed_listeners: List[TradeClosedListener] = []
    
    @property
    def symbols(self) -> Dict[str, Symbol]:
        """Get all subscribed symbols."""
        return self._symbols
    
    @property
    def positions(self) -> Dict[str, Position]:
        """Get all open positions."""
        return self._positions
    
    @property
    def orders(self) -> Dict[str, OrderData]:
        """Get all pending orders."""
        return self._orders
    
    @property
    def history(self) -> List[ClosedPosition]:
        """Get trade history (closed positions)."""
        return self._history
    
    @property
    def account(self) -> AccountInfo:
        """Get account information."""
        return self._account
    
    @property
    def equity(self) -> float:
        """Get current equity."""
        return self._account.equity
    
    @property
    def balance(self) -> float:
        """Get current balance."""
        return self._account.balance
    
    @property
    def unrealized_pnl(self) -> float:
        """Get total unrealized P&L across all positions."""
        return sum(p.unrealized_pnl for p in self._positions.values())
    
    @property
    def realized_pnl(self) -> float:
        """Get total realized P&L."""
        return sum(p.pnl for p in self._history)
    
    @property
    def daily_pnl(self) -> float:
        """Get today's P&L."""
        return self._daily_pnl
    
    @property
    def drawdown(self) -> float:
        """Get current drawdown from peak equity."""
        if self._peak_equity <= 0:
            return 0
        return (self._peak_equity - self._account.equity) / self._peak_equity * 100
    
    @property
    def current_time(self) -> int:
        """Get current time as Unix timestamp in milliseconds."""
        return self._current_time
    
    def add_symbol(self, symbol_name: str) -> Symbol:
        """Add and return a symbol."""
        if symbol_name not in self._symbols:
            self._symbols[symbol_name] = Symbol(name=symbol_name)
        return self._symbols[symbol_name]
    
    def get_symbol(self, symbol_name: str) -> Optional[Symbol]:
        """Get a symbol by name."""
        return self._symbols.get(symbol_name)
    
    def get_position(self, symbol: str) -> Optional[Position]:
        """Get position for a symbol."""
        for pos in self._positions.values():
            if pos.symbol == symbol:
                return pos
        return None
    
    def get_positions_by_symbol(self, symbol: str) -> List[Position]:
        """Get all positions for a symbol."""
        return [p for p in self._positions.values() if p.symbol == symbol]
    
    def has_position(self, symbol: str) -> bool:
        """Check if there's an open position for symbol."""
        return any(p.symbol == symbol for p in self._positions.values())
    
    def open_position(
        self,
        symbol: str,
        side: PositionSide,
        quantity: int,
        price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        trailing_stop: bool = False,
        trailing_stop_distance: float = 0,
    ) -> Position:
        """
        Open a new position.
        
        Returns:
            The new Position object
        """
        # 1. Get Symbol info
        sym_obj = self.get_symbol(symbol)
        point_value = sym_obj.point_value if sym_obj else 1.0
        margin_rate = sym_obj.margin_rate if sym_obj else 1.0 # Default cash
        
        # 2. Normalize
        if sym_obj:
            quantity = sym_obj.normalize_quantity(quantity)
            price = sym_obj.normalize_price(price)
            
        position = Position(
            id=str(uuid.uuid4()),
            symbol=symbol,
            side=side,
            quantity=quantity,
            entry_price=price,
            entry_time=self._current_time,
            current_price=price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trailing_stop=trailing_stop,
            trailing_stop_distance=trailing_stop_distance,
            account_id=self._account.account_id,
            point_value=point_value,
        )
        
        self._positions[position.id] = position
        
        # 3. Update Margin
        # Cost = Qty * Price * MarginRate * PointValue
        margin_required = quantity * price * margin_rate * point_value
        
        self._account.margin += margin_required
        # Free margin = Equity - Margin
        self._account.free_margin = self._account.equity - self._account.margin
        
        logger.info(
            f"Position opened: {side.value} {symbol} qty={quantity} @ {price:.4f} "
            f"id={position.id[:8]}"
        )
        logger.debug(
            f"Position details: margin_required={margin_required:,.2f} "
            f"point_value={point_value} margin_rate={margin_rate} "
            f"SL={stop_loss} TP={take_profit} trailing={trailing_stop}"
        )
        logger.debug(
            f"Account after open: equity={self._account.equity:,.2f} "
            f"margin={self._account.margin:,.2f} free_margin={self._account.free_margin:,.2f}"
        )
        
        return position
    
    def add_on_trade_closed(self, listener: TradeClosedListener) -> None:
        """Register a listener called after every position close."""
        self._on_trade_closed_listeners.append(listener)

    def close_position(self, position_id: str, price: float, exit_time: Optional[int] = None, commission_pct: float = 0.0) -> Optional[ClosedPosition]:
        """
        Close a position. Single source of truth for trade processing.
        
        Handles: PnL, commission, account update, margin release, NAV release,
        equity snapshot, and notifies all registered listeners.
        
        Args:
            position_id: ID of the position to close
            price: Exit price
            exit_time: Exit time as Unix ms (defaults to current_time)
            commission_pct: Commission as % of |PnL| (0 for live, >0 for backtest)
        
        Returns:
            ClosedPosition record or None if position not found
        """
        position = self._positions.get(position_id)
        if not position:
            logger.warning(f"close_position: position {position_id} not found")
            return None
            
        # 1. Get Symbol info
        sym_obj = self.get_symbol(position.symbol)
        point_value = sym_obj.point_value if sym_obj else 1.0
        margin_rate = sym_obj.margin_rate if sym_obj else 1.0
        
        # Normalize exit price
        if sym_obj:
            price = sym_obj.normalize_price(price)
        
        # 2. Calculate PnL
        price_diff = price - position.entry_price
        if position.side == PositionSide.SHORT:
            price_diff = -price_diff
            
        realized_pnl = price_diff * position.quantity * point_value
        
        # 3. Apply commission
        if commission_pct > 0:
            commission = abs(realized_pnl) * commission_pct / 100
            realized_pnl -= commission
        
        # Create closed position record
        closed = ClosedPosition.from_position(position, price, point_value=point_value, exit_time=exit_time)
        closed.pnl = realized_pnl
        self._history.append(closed)
        
        # 4. Update account
        self._account.balance += realized_pnl
        self._account.equity = self._account.balance + self.unrealized_pnl
        self._daily_pnl += realized_pnl
        
        # Update peak equity
        if self._account.equity > self._peak_equity:
            self._peak_equity = self._account.equity
        
        # 5. Release Margin
        margin_released = position.quantity * position.entry_price * margin_rate * point_value
        self._account.margin = max(0, self._account.margin - margin_released)
        self._account.free_margin = self._account.equity - self._account.margin
        
        # 6. Release NAV
        order_value = position.quantity * position.entry_price * margin_rate * point_value
        self._used_nav = max(0, self._used_nav - order_value)
        
        # Remove from open positions
        del self._positions[position_id]
        
        # 7. Record equity snapshot for metrics
        self._equity_curve.append(self._account.equity)
        self._equity_dates.append(self._current_time)
        
        logger.info(
            f"Position closed: {position.side.value} {position.symbol} qty={position.quantity} "
            f"entry={position.entry_price:.4f} exit={price:.4f} PnL={realized_pnl:+,.2f} "
            f"id={position_id[:8]}"
        )
        logger.debug(
            f"Close details: price_diff={price_diff:.4f} commission_pct={commission_pct} "
            f"margin_released={margin_released:,.2f} nav_released={order_value:,.2f}"
        )
        logger.debug(
            f"Account after close: balance={self._account.balance:,.2f} "
            f"equity={self._account.equity:,.2f} margin={self._account.margin:,.2f} "
            f"daily_pnl={self._daily_pnl:+,.2f} used_nav={self._used_nav:,.2f}"
        )
        
        # 8. Notify all listeners
        for listener in self._on_trade_closed_listeners:
            listener(closed)
        
        return closed
    
    def update_prices(self) -> None:
        """Update all position prices from symbol data (uses bar close, not last_price)."""
        for position in self._positions.values():
            symbol = self._symbols.get(position.symbol)
            if symbol:
                current_bar = symbol.bars.current
                price = current_bar.close if current_bar else symbol.last_price
                position.update_price(price)
        
        # Update account equity
        self._account.unrealized_pnl = self.unrealized_pnl
        self._account.equity = self._account.balance + self._account.unrealized_pnl
        
        # Update max NAV based on current equity
        self._max_nav = self._account.equity * self._max_nav_usage_pct / 100
    
    def reset_daily_pnl(self) -> None:
        """Reset daily P&L tracking (call at start of new day)."""
        self._daily_pnl = 0.0
        self._daily_start_equity = self._account.equity
    
    def set_time(self, time: int) -> None:
        """Set current time as Unix timestamp in milliseconds (for backtesting)."""
        self._current_time = time
    
    # ========================================================================
    # NAV Management
    # ========================================================================
    
    @property
    def max_nav(self) -> float:
        """Get maximum NAV allowed for trading."""
        return self._max_nav
    
    @property
    def used_nav(self) -> float:
        """Get currently used NAV."""
        return self._used_nav
    
    @property
    def available_nav(self) -> float:
        """Get available NAV for new orders."""
        return max(0, self._max_nav - self._used_nav)
    
    @property
    def nav_usage_pct(self) -> float:
        """Get NAV usage percentage."""
        if self._max_nav <= 0:
            return 100.0
        return (self._used_nav / self._max_nav) * 100
    
    def can_use_nav(self, amount: float) -> bool:
        """
        Check if NAV is available for an order.
        
        Args:
            amount: Order value to check
            
        Returns:
            True if NAV is available
        """
        available = self.available_nav
        allowed = amount <= available
        if not allowed:
            logger.debug(f"NAV check failed: need {amount:,.2f}, available {available:,.2f}")
        return allowed
    
    def reserve_nav(self, order_id: str, amount: float) -> bool:
        """
        Reserve NAV for a pending order.
        
        Args:
            order_id: Order ID
            amount: Value to reserve
            
        Returns:
            True if reserved successfully
        """
        if not self.can_use_nav(amount):
            logger.warning(f"NAV reserve failed: order={order_id[:8]} amount={amount:,.2f} available={self.available_nav:,.2f}")
            return False
        
        self._used_nav += amount
        self._reserved_orders[order_id] = amount
        logger.debug(f"NAV reserved: order={order_id[:8]} amount={amount:,.2f} used={self._used_nav:,.2f}/{self._max_nav:,.2f}")
        return True
    
    def release_nav(self, order_id: str) -> float:
        """
        Release reserved NAV for an order (cancelled/rejected).
        
        Args:
            order_id: Order ID
            
        Returns:
            Amount released
        """
        if order_id in self._reserved_orders:
            amount = self._reserved_orders.pop(order_id)
            self._used_nav = max(0, self._used_nav - amount)
            logger.debug(f"NAV released: order={order_id[:8]} amount={amount:,.2f} used={self._used_nav:,.2f}/{self._max_nav:,.2f}")
            return amount
        logger.debug(f"NAV release: order={order_id[:8]} not found in reservations")
        return 0
    
    def convert_nav_to_position(self, order_id: str) -> float:
        """
        Convert reserved NAV to used (order filled -> position opened).
        NAV stays used, just no longer tied to order_id.
        
        Args:
            order_id: Order ID
            
        Returns:
            Amount converted
        """
        if order_id in self._reserved_orders:
            amount = self._reserved_orders.pop(order_id)
            logger.debug(f"NAV converted to position: order={order_id[:8]} amount={amount:,.2f}")
            # NAV remains used (now in position)
            return amount
        logger.debug(f"NAV convert: order={order_id[:8]} not found in reservations")
        return 0
    
    def cancel_order(self, order_id: str) -> bool:
        """
        Cancel a pending order.
        
        Args:
            order_id: Order ID to cancel
            
        Returns:
            True if found and cancelled
        """
        if order_id in self._reserved_orders:
            self.release_nav(order_id)
            logger.info(f"Order cancelled: {order_id[:8]} (NAV released)")
            return True
            
        # Check _orders dict just in case future implementation uses it
        if order_id in self._orders:
            del self._orders[order_id]
            logger.info(f"Order cancelled: {order_id[:8]} (removed from orders)")
            return True
        
        logger.debug(f"Cancel order: {order_id[:8]} not found")
        return False
