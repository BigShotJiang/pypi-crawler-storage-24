"""
Strategy base class for Vero Algo SDK.

Provides trading strategy framework with event-based processing.
Used as a base class by Vero (core.py) which handles running and orchestration.
"""

import threading
import uuid
from abc import ABC
import math
from typing import List, Optional, Dict, Any
from datetime import datetime

from .context import TradingContext
from ..models import Position, ClosedPosition, AccountInfo, Symbol, Bar, Bars
from ..models import RunMode, PositionSide, PendingOrder
from ..utils.logging_config import StrategyLogger
from ..utils.defaults import enum_val


class Strategy(ABC):
    """
    Base class for trading strategies.
    
    Subclass this and implement event handlers:
    - on_start(): Called after initialization
    - on_stop(): Called before shutdown
    - on_bar(bar): Called when a new bar closes
    - on_tick(symbol): Called on price updates
    - on_order(order): Called on order status change
    - on_trade(trade): Called when trade executes
    - on_position_opened(position): Called when position opens
    - on_position_closed(position): Called when position closes
    
    Example:
        class MyStrategy(Strategy):
            def on_bar(self, bar):
                if bar.close > bar.open:
                    self.client.orders.place_order("VN30F2401", "B", bar.close, qty=1)
    """
    
    # Class-level configuration
    name: str = "Strategy"
    version: str = "1.0.0"
    
    def __init__(self):
        self._mode = RunMode.LIVE
        self._symbols: List[str] = []
        self._account_id = ""
        self._context: Optional[TradingContext] = None
        self._logger: Optional[StrategyLogger] = None
        self._client = None  # VeroClient instance
        self._running = False
        self._stop_event = threading.Event()
        
        # Backtest engine reference (set in backtest mode)
        self._backtest_engine = None
        
        # Callback service reference (set by run method)
        self._callback = None
        
        # Pending limit orders for backtest (checked each bar by engine)
        self._pending_orders: List["PendingOrder"] = []
        
        # Strategy metrics (recalculated after every trade)
        from ..models import StrategyMetrics, PerformanceReport
        self._metrics: StrategyMetrics = StrategyMetrics()
        self._report: PerformanceReport = PerformanceReport()
        
        # Position sizing: default % of available NAV to use per trade
        # Best practice: 50% allows room for scaling in and diversification
        self.default_risk_pct: float = 50.0
    
    # ========================================================================
    # Properties
    # ========================================================================
    
    @property
    def logger(self) -> StrategyLogger:
        """Get strategy logger."""
        if self._logger is None:
            self._logger = StrategyLogger(self.name)
        return self._logger
    
    @property
    def context(self) -> Optional[TradingContext]:
        """Get trading context."""
        return self._context
    
    @property
    def positions(self) -> Dict[str, Position]:
        """Get all open positions."""
        return self._context.positions if self._context else {}
    
    @property
    def orders(self) -> Dict[str, Any]:
        """Get all pending orders."""
        return self._context.orders if self._context else {}
    
    @property
    def account(self) -> AccountInfo:
        """Get account information."""
        return self._context.account if self._context else AccountInfo()
    
    @property
    def symbols(self) -> Dict[str, Symbol]:
        """Get subscribed symbols."""
        return self._context.symbols if self._context else {}
    
    @property
    def equity(self) -> float:
        """Get current equity."""
        return self._context.equity if self._context else 0
    
    @property
    def is_running(self) -> bool:
        """Check if strategy is running."""
        return self._running
    
    @property
    def mode(self) -> RunMode:
        """Get current run mode."""
        return self._mode
    
    @property
    def time(self) -> datetime:
        """Get current time."""
        return self._context.current_time if self._context else datetime.now()
    
    # ========================================================================
    # Event Handlers (Override in subclass)
    # ========================================================================
    
    def on_start(self) -> None:
        """
        Called when strategy starts.
        
        Override to perform initialization logic.
        Market data and symbols are already loaded at this point.
        """
        pass
    
    def on_stop(self) -> None:
        """
        Called when strategy stops.
        
        Override to perform cleanup logic.
        """
        pass
    
    def on_bar(self, bar: Bar) -> None:
        """
        Called when a new bar closes.
        
        Args:
            bar: The completed bar data
        """
        pass
    
    def on_tick(self, symbol: Symbol) -> None:
        """
        Called on price tick updates.
        
        Args:
            symbol: Symbol with updated price data
        """
        pass
    
    def on_depth(self, symbol: Symbol) -> None:
        """
        Called on order book depth updates.
        
        Args:
            symbol: Symbol with updated depth data
        """
        pass
    
    def on_order(self, order: Any) -> None:
        """
        Called when order status changes.
        
        Args:
            order: Order data with updated status
        """
        pass
    
    def on_trade(self, trade: Any) -> None:
        """
        Called when a trade executes.
        
        Args:
            trade: Trade execution data
        """
        pass
    
    def on_position_opened(self, position: Position) -> None:
        """
        Called when a position is opened.
        
        Args:
            position: The newly opened position
        """
        pass
    
    def on_position_closed(self, position: ClosedPosition) -> None:
        """
        Called when a position is closed.
        
        Args:
            position: The closed position record
        """
        pass
    
    def on_error(self, error: Exception) -> None:
        """
        Called when an error occurs.
        
        Args:
            error: The exception that occurred
        """
        self.logger.error(f"Error: {error}")
    
    # ========================================================================
    # Trading Methods
    # ========================================================================
    
    def _setup_trade_listeners(self) -> None:
        """Register trade-closed listeners on context for centralized handling."""
        if not self._context:
            return

        def _on_trade_closed(closed: ClosedPosition) -> None:
            # 1. Log
            self.logger.position("CLOSED", closed.symbol, closed.quantity,
                                 closed.entry_price, closed.pnl, closed.pnl_percent)
            # 2. Strategy callback
            self.on_position_closed(closed)
            # 3. Fire callback event
            if self._callback:
                from ..models import CallbackEventType
                self._callback.send_event(
                    CallbackEventType.POSITION_CLOSED,
                    data=closed.to_dict(),
                    strategy_name=self.name,
                )
            # 5. Recalculate strategy metrics and build report
            self._update_strategy_metrics()
            self._update_report()

        self._context.add_on_trade_closed(_on_trade_closed)

    def close_position(
        self,
        position: Position,
        price: Optional[float] = None,
    ) -> Optional[ClosedPosition]:
        """
        Close an open position.
        
        Args:
            position: Position to close
            price: Exit price (None for market)
            
        Returns:
            ClosedPosition record if successful
        """
        if not self._context:
            return None
        
        symbol = self._context.get_symbol(position.symbol)
        if not symbol:
            return None
        
        current_bar = symbol.bars.current
        
        if self._mode == RunMode.BACKTEST:
            # Backtest fill pricing for manual close:
            # - Market close (price=None): use (O+H+L+C)/4
            # - Limit close (price set): check bar range, queue pending if outside
            if price is None:
                if not current_bar:
                    self.logger.error(f"No bar data for {position.symbol} — cannot fill market close")
                    return None
                exit_price = (current_bar.open + current_bar.high + current_bar.low + current_bar.close) / 4
            else:
                if current_bar and (price < current_bar.low or price > current_bar.high):
                    # Queue as pending close order
                    self._queue_pending_close(position, price)
                    return None
                # No bar data or price within range: fill at limit price
                exit_price = price
        else:
            exit_price = price or (current_bar.close if current_bar else symbol.last_price)
        exit_price = symbol.normalize_price(exit_price)
        
        if self._mode == RunMode.LIVE and self._client:
            # Place close order via API
            side = "S" if position.is_long else "B"
            self.logger.debug(f"Closing position via API: {position.symbol} {side} qty={position.quantity} @ {exit_price:.4f}")
            response = self._client.orders.place_order(
                symbol=position.symbol,
                side=side,
                price=exit_price,
                qty=position.quantity,
                account_id=self._account_id,
            )
            
            if not response.success:
                self.logger.error(f"Failed to close position: {response.message}")
                return None
        
        # Close in context (handles PnL, account, margin, NAV, equity, listeners)
        closed = self._context.close_position(position.id, exit_price)
        
        return closed
    
    def close_all_positions(self, symbol: Optional[str] = None) -> List[ClosedPosition]:
        """
        Close all open positions.
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of closed positions
        """
        closed = []
        if not self._context:
            return closed
            
        positions = list(self._context.positions.values())
        filter_msg = f" for {symbol}" if symbol else ""
        self.logger.info(f"Closing all positions{filter_msg} ({len(positions)} open)")
        
        for pos in positions:
            if symbol is None or pos.symbol == symbol:
                result = self.close_position(pos)
                if result:
                    closed.append(result)
        
        return closed
    
    def cancel_order(self, order_id: str) -> bool:
        """
        Cancel a pending order.
        
        Args:
            order_id: Order ID to cancel
            
        Returns:
            True if cancellation request was sent/processed
        """
        self.logger.debug(f"Cancelling order: {order_id[:8]}")
        if self._mode == RunMode.LIVE and self._client:
            # Call API
            response = self._client.orders.cancel_order(
                order_id=order_id,
                account_id=self._account_id
            )
            return response.success
            
        elif self._context:
            # Backtest: check pending orders first, then context
            for pending in self._pending_orders:
                if pending.order_id == order_id:
                    # Release NAV if entry order
                    if pending.nav_order_id:
                        self._context.release_nav(pending.nav_order_id)
                    self._pending_orders.remove(pending)
                    self.logger.debug(f"Pending order cancelled: {order_id[:8]}")
                    return True
            return self._context.cancel_order(order_id)
            
        return False
    
    # ========================================================================
    # NAV Access
    # ========================================================================
    
    @property
    def available_nav(self) -> float:
        """Get available NAV for new orders."""
        return self._context.available_nav if self._context else 0
    
    @property
    def used_nav(self) -> float:
        """Get currently used NAV."""
        return self._context.used_nav if self._context else 0
    
    @property
    def max_nav(self) -> float:
        """Get maximum allowed NAV."""
        return self._context.max_nav if self._context else 0
    
    @property
    def nav_usage_pct(self) -> float:
        """Get NAV usage percentage."""
        return self._context.nav_usage_pct if self._context else 0
    
    # ========================================================================
    # Strategy Metrics
    # ========================================================================

    @property
    def metrics(self):
        """Get latest strategy metrics (recalculated after every trade)."""
        return self._metrics

    def _update_strategy_metrics(self) -> None:
        """Recalculate strategy metrics from trade history and equity curve."""
        if not self._context or not self._context.history:
            return

        from ..metrics import calculate_metrics

        ctx = self._context
        now_ms = ctx._current_time

        self._metrics = calculate_metrics(
            trades=ctx.history,
            equity_curve=ctx._equity_curve,
            initial_capital=ctx._initial_capital,
            start_date=ctx._start_time,
            end_date=now_ms,
        )
        self._metrics.current_nav = ctx.available_nav

        # Open position snapshot
        positions = list(ctx.positions.values())
        if positions:
            total_qty = sum(p.quantity for p in positions)
            total_cost = sum(p.entry_price * p.quantity for p in positions)
            self._metrics.open_position_qty = total_qty
            self._metrics.open_position_avg_price = total_cost / total_qty if total_qty > 0 else 0
            self._metrics.open_position_unrealized_pnl = ctx.unrealized_pnl

        # Fire callback with updated metrics
        if self._callback:
            from ..models import CallbackEventType
            self._callback.send_event(
                CallbackEventType.STRATEGY_METRICS,
                data=self._metrics.to_dict(),
                strategy_name=self.name,
            )

    def _update_report(self) -> None:
        """Build and send updated report after every trade."""
        if not self._context:
            return

        from ..report import build_report

        ctx = self._context
        now_ms = ctx._current_time

        self._report = build_report(
            strategy_name=self.name,
            start_date=ctx._start_time,
            end_date=now_ms,
            metrics=self._metrics,
            equity_curve=ctx._equity_curve,
            equity_dates=ctx._equity_dates,
        )
        self._report.trades = ctx.history

        # Fire report callback
        if self._callback:
            from ..models import CallbackEventType
            self._callback.send_event(
                CallbackEventType.REPORT,
                data=self._report.to_dict(),
                strategy_name=self.name,
            )

    @property
    def report(self):
        """Get latest performance report (updated after every trade)."""
        return self._report

    def _calculate_smart_qty(
        self,
        symbol: str,
        price: float,
        risk_pct: Optional[float] = None,
    ) -> int:
        """
        Calculate optimal order quantity using Kelly Criterion.
        
        Uses available NAV (scaled by risk_pct or Kelly fraction), current price,
        symbol specs, and trade history to determine position size.
        
        Position sizing:
        - With ≥5 closed trades: uses half-Kelly from win_rate & payoff_ratio
        - With <5 trades: falls back to default_risk_pct (50%)
        
        Args:
            symbol: Trading symbol
            price: Entry price for calculation
            risk_pct: Percentage of available NAV to use (0-100).
                      Defaults to self.default_risk_pct (50%).
                      Kelly fraction overrides this when sufficient history exists.
            
        Returns:
            Optimal quantity (0 if insufficient NAV)
        """
        if not self._context or price <= 0:
            return 0
        
        sym = self._context.get_symbol(symbol)
        if not sym:
            return 0
        
        # 1. Available capital for this order
        available = self._context.available_nav
        if risk_pct is None:
            risk_pct = self.default_risk_pct
        risk_pct = max(0.0, min(100.0, risk_pct))
        capital_for_order = available * risk_pct / 100.0
        
        if capital_for_order <= 0:
            return 0
        
        # 2. Kelly Criterion sizing
        #    f* = (win_rate × payoff_ratio - loss_rate) / payoff_ratio
        #    Use half-Kelly for safety (standard best practice)
        #    Requires minimum 5 closed trades for reliable stats
        MIN_TRADES_FOR_KELLY = 5
        history = self._context.history
        
        if len(history) >= MIN_TRADES_FOR_KELLY:
            wins = [t.pnl for t in history if t.pnl > 0]
            losses = [t.pnl for t in history if t.pnl <= 0]
            
            win_rate = len(wins) / len(history)
            loss_rate = 1.0 - win_rate
            
            avg_win = sum(wins) / len(wins) if wins else 0
            avg_loss = abs(sum(losses) / len(losses)) if losses else 0
            
            if avg_loss > 0 and avg_win > 0:
                payoff_ratio = avg_win / avg_loss  # b in Kelly formula
                kelly_fraction = (win_rate * payoff_ratio - loss_rate) / payoff_ratio
                
                # Half-Kelly: more conservative, smoother equity curve
                half_kelly_pct = (kelly_fraction / 2.0) * 100.0
                
                # Clamp: min 5%, max default_risk_pct
                kelly_pct = max(5.0, min(risk_pct, half_kelly_pct))
                capital_for_order = available * kelly_pct / 100.0
            # else: edge cases (no wins or no losses) → keep default risk_pct
        
        scaled_capital = capital_for_order
        
        # 3. Compute raw qty: capital / (price * margin_rate * point_value)
        margin_rate = sym.margin_rate if sym.margin_rate > 0 else 1.0
        point_value = sym.point_value if sym.point_value > 0 else 1.0
        cost_per_unit = price * margin_rate * point_value
        
        if cost_per_unit <= 0:
            return 0
        
        raw_qty = scaled_capital / cost_per_unit
        
        # 4. Round down to lot_size
        lot_size = sym.lot_size if sym.lot_size > 0 else 1
        rounded_qty = int(math.floor(raw_qty / lot_size)) * lot_size
        
        # 5. Enforce min/max qty
        if rounded_qty < sym.min_qty:
            return 0  # Insufficient NAV for minimum order
        if rounded_qty > sym.max_qty:
            rounded_qty = sym.max_qty
        
        return rounded_qty
    
    def _queue_pending_entry(
        self,
        symbol: str,
        side: PositionSide,
        qty: int,
        limit_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        trailing_stop: bool = False,
        trailing_stop_pct: float = 0,
    ) -> None:
        """
        Queue a limit entry order as pending for backtest.
        
        The order will be checked each bar by the engine and filled
        when the limit price falls within a bar's [low, high] range.
        Reserves NAV immediately. Returns None (no position yet).
        """
        if not self._context:
            return None
        
        sym = self._context.get_symbol(symbol)
        if not sym:
            return None
        
        # Prices already normalized at order receipt
        # Qty already resolved by caller (_open_position)
        
        # Reserve NAV
        margin_rate = sym.margin_rate if sym.margin_rate > 0 else 1.0
        point_value = sym.point_value if sym.point_value > 0 else 1.0
        order_value = qty * limit_price * margin_rate * point_value
        
        if not self._context.can_use_nav(order_value):
            self.logger.risk(f"Insufficient NAV for pending order: need {order_value:,.0f}")
            return None
        
        nav_order_id = str(uuid.uuid4())
        if not self._context.reserve_nav(nav_order_id, order_value):
            self.logger.risk(f"Failed to reserve NAV for pending order")
            return None
        
        pending = PendingOrder(
            order_id=str(uuid.uuid4()),
            symbol=symbol,
            side=side.value,
            quantity=qty,
            limit_price=limit_price,
            order_type="entry",
            stop_loss=stop_loss,
            take_profit=take_profit,
            trailing_stop=trailing_stop,
            trailing_stop_pct=trailing_stop_pct,
            nav_order_id=nav_order_id,
            created_time=self._context.current_time,
        )
        
        self._pending_orders.append(pending)
        action = "BUY" if side == PositionSide.LONG else "SELL"
        self.logger.debug(
            f"Pending {action} limit order queued: {symbol} qty={qty} @ {limit_price:.4f}"
        )
        return None
    
    def _queue_pending_close(
        self,
        position: Position,
        limit_price: float,
    ) -> None:
        """
        Queue a limit close order as pending for backtest.
        
        The order will be checked each bar by the engine and filled
        when the limit price falls within a bar's [low, high] range.
        """
        pending = PendingOrder(
            order_id=str(uuid.uuid4()),
            symbol=position.symbol,
            side=position.side.value,
            quantity=position.quantity,
            limit_price=limit_price,
            order_type="close",
            position_id=position.id,
            created_time=self._context.current_time if self._context else 0,
        )
        
        self._pending_orders.append(pending)
        self.logger.debug(
            f"Pending close order queued: {position.symbol} @ {limit_price:.4f}"
        )
        return None

    def _open_position(
        self,
        symbol: str,
        side: PositionSide,
        qty: int,
        price: Optional[float] = None,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        trailing_stop: bool = False,
        trailing_stop_pct: float = 0,
    ) -> Optional[Position]:
        """Internal method to open a position."""
        if not self._context:
            return None
        
        sym = self._context.get_symbol(symbol)
        if not sym:
            self.logger.error(f"Symbol {symbol} not found")
            return None
        
        current_bar = sym.bars.current
        
        if price is None:
            if not current_bar:
                self.logger.error(f"No bar data for {symbol} — cannot fill market order")
                return None
            entry_price = (current_bar.open + current_bar.high + current_bar.low + current_bar.close) / 4
            entry_price = sym.normalize_price(entry_price)
        else:
            if current_bar:
                if price < current_bar.low or price > current_bar.high:
                    return self._queue_pending_entry(
                        symbol=symbol, side=side, qty=qty, limit_price=price,
                        stop_loss=stop_loss, take_profit=take_profit,
                        trailing_stop=trailing_stop, trailing_stop_pct=trailing_stop_pct,
                    )
            entry_price = price
        
        # Calculate order value for NAV check (margin-adjusted)
        margin_rate = sym.margin_rate if sym.margin_rate > 0 else 1.0
        point_value = sym.point_value if sym.point_value > 0 else 1.0
        order_value = qty * entry_price * margin_rate * point_value
        
        # Check NAV availability
        if not self._context.can_use_nav(order_value):
            self.logger.risk(f"Insufficient NAV: need {order_value:,.0f}, available {self._context.available_nav:,.0f}")
            return None
        
        # Calculate trailing stop distance
        trailing_distance = 0
        if trailing_stop and trailing_stop_pct > 0:
            trailing_distance = entry_price * trailing_stop_pct / 100
        
        # Generate order ID for NAV tracking
        order_id = str(uuid.uuid4())
        
        # Reserve NAV
        if not self._context.reserve_nav(order_id, order_value):
            self.logger.risk(f"Failed to reserve NAV: {order_value:,.0f}")
            return None
        
        # Convert NAV reservation to position
        self._context.convert_nav_to_position(order_id)
        
        # Open in context
        position = self._context.open_position(
            symbol=symbol,
            side=side,
            quantity=qty,
            price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trailing_stop=trailing_stop,
            trailing_stop_distance=trailing_distance,
        )
        
        # Store order_id on position for NAV tracking on close
        position.order_id = order_id
        
        action = "BUY" if side == PositionSide.LONG else "SELL"
        self.logger.order(action, symbol, qty, entry_price)
        self.on_position_opened(position)
        
        # Fire callback
        if self._callback:
            from ..models import CallbackEventType
            self._callback.send_event(
                CallbackEventType.POSITION_OPENED,
                data=position.to_dict(),
                strategy_name=self.name,
            )
        
        return position
    
    # ========================================================================
    # Symbol Access
    # ========================================================================
    
    def bars(self, symbol: str) -> Bars:
        """
        Get bars for a symbol.
        
        Args:
            symbol: Symbol name
            
        Returns:
            Bars object with historical data
        """
        sym = self._context.get_symbol(symbol) if self._context else None
        return sym.bars if sym else Bars()
    
    def symbol(self, name: str) -> Optional[Symbol]:
        """
        Get symbol data.
        
        Args:
            name: Symbol name
            
        Returns:
            Symbol object or None
        """
        return self._context.get_symbol(name) if self._context else None
    
    # ========================================================================
    # Control Methods
    # ========================================================================
    
    def stop(self) -> None:
        """Stop the strategy."""
        self.logger.info("Strategy stop requested")
        self._stop_event.set()
        self._running = False
