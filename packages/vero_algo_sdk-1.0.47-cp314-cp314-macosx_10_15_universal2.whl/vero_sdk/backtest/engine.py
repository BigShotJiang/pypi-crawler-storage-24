"""
Backtest simulation engine for Vero Algo SDK.

Runs strategy against historical data and produces performance report.
"""

import asyncio
from typing import List, Optional, TYPE_CHECKING, Callable
from datetime import datetime

from ..models import PerformanceReport, ClosedPosition, Bar
from ..metrics import calculate_metrics
from ..report import build_report
from ..strategy.context import TradingContext
from ..utils.logging_config import VeroLogger
from ..utils.defaults import DEFAULT_MICRO_API_SERVER, DEFAULT_AUTH_SERVER, DEFAULT_COMMISSION_PCT, DEFAULT_SLIPPAGE_TICKS
from ..config import VeroConfig
from ..models import TimeResolution

if TYPE_CHECKING:
    from ..strategy.base import Strategy

logger = VeroLogger("backtest")


class BacktestEngine:
    """
    Backtesting simulation engine.
    
    Runs a strategy against historical bar data and produces
    performance metrics and trade history.
    """
    
    def __init__(
        self,
        strategy: "Strategy",
        symbols: List[str],
        start_date: int,
        end_date: int,
        initial_capital: float = 100000,
        resolution: int = TimeResolution.DAY_1,
        commission_pct: float = DEFAULT_COMMISSION_PCT,
        slippage_ticks: int = DEFAULT_SLIPPAGE_TICKS,
        fill_ratio: float = 1.0,
        risk_free_rate: float = 0.02,
        jwt_token: str = "",
        account_id: str = "user",
        max_nav_usage_pct: float = 100.0,
    ):
        """
        Initialize BacktestEngine.
        
        Args:
            strategy: Strategy instance to test
            symbols: List of symbols to load
            start_date: Start date as Unix timestamp in milliseconds
            end_date: End date as Unix timestamp in milliseconds
            initial_capital: Starting capital
            resolution: Bar resolution in seconds
            commission_pct: Commission percentage per trade
            slippage_ticks: Slippage in ticks per trade
            fill_ratio: Order fill ratio (0.0-1.0)
            risk_free_rate: Annual risk-free rate for Sharpe ratio
            jwt_token: JWT token for API data fetching
            account_id: Account ID for the simulation
        """
        self.strategy = strategy
        self.symbols = symbols
        self.start_date = start_date  # Unix ms
        self.end_date = end_date  # Unix ms
        self.initial_capital = initial_capital
        self.resolution = resolution
        self.commission_pct = commission_pct
        self.slippage_ticks = slippage_ticks
        self.fill_ratio = fill_ratio
        self.risk_free_rate = risk_free_rate
        self.jwt_token = jwt_token
        self.account_id = account_id
        self.max_nav_usage_pct = max_nav_usage_pct
        
        # Historical data
        self._bars_data: dict = {}  # symbol -> list of Bar
        
        # Results tracking
        self._equity_curve: List[float] = []
        self._equity_dates: List[int] = []  # Unix timestamps in milliseconds
        self._closed_positions: List[ClosedPosition] = []
    

    async def run(self, on_progress: Optional[Callable[[float], None]] = None) -> PerformanceReport:
        """
        Execute the backtest.
        
        Args:
            on_progress: Optional callback(float) for progress percentage (0.0 to 100.0)
            
        Returns:
            PerformanceReport with all metrics, equity curve, and trade history
        """
        from ..features.market_data import MarketDataService
        
        _start_dt = datetime.utcfromtimestamp(self.start_date / 1000)
        _end_dt = datetime.utcfromtimestamp(self.end_date / 1000)
        logger.info(f"Starting backtest from {_start_dt.date()} to {_end_dt.date()}")
        logger.info(f"Initial capital: {self.initial_capital:,.0f}")
        logger.info(f"Symbols: {', '.join(self.symbols)}")
        
        # Initialize Services
        config = VeroConfig(
            micro_api_server=DEFAULT_MICRO_API_SERVER,
            auth_server=DEFAULT_AUTH_SERVER
        )
        
        # Authenticate if token provided
        if self.jwt_token:
            logger.info("Setting up auth for market data...")
            config.jwt_token = self.jwt_token
        
        market_data = MarketDataService(config)

        # Initialize context with strategy
        self.strategy._context = TradingContext(initial_capital=self.initial_capital, max_nav_usage_pct=self.max_nav_usage_pct)
        
        # Register centralized trade-closed listeners on the new context
        self.strategy._setup_trade_listeners()
        
        # Load Symbol Data (Master + Margin)
        for symbol in self.symbols:
            logger.info(f"Fetching Product Info for {symbol}...")
            sym_obj = self.strategy._context.add_symbol(symbol)
            
            # Fetch Master
            try:
                master = market_data.get_product_master(symbol)
                if master:
                    sym_obj.update_from_master(master)
                    logger.debug(f"Updated {symbol} master data: Tick={sym_obj.tick_size}, Lot={sym_obj.lot_size}")
            except Exception as e:
                logger.warning(f"Failed to fetch master for {symbol}: {e}")
                
            # Fetch Margin
            try:
                mr = market_data.get_margin_rate(symbol)
                sym_obj.margin_rate = mr
                logger.debug(f"Updated {symbol} Margin Rate: {mr}")
            except Exception:
                pass
                
            logger.debug(f"Symbol {symbol}: tick_size={sym_obj.tick_size}, lot_size={sym_obj.lot_size}, point_value={sym_obj.point_value}, margin_rate={sym_obj.margin_rate}")
        
        # Load historical data
        self._load_historical_data(market_data)
        
        if not self._bars_data:
            logger.error("No historical data loaded")
            return PerformanceReport()
            
        # ... (rest of function)

        
        # Record initial equity
        self._equity_curve.append(self.initial_capital)
        self._equity_dates.append(self.start_date)
        
        # Call strategy on_start
        self.strategy._running = True
        if asyncio.iscoroutinefunction(self.strategy.on_start):
            await self.strategy.on_start()
        else:
            self.strategy.on_start()
        
        # Get the primary symbol for bar iteration
        primary_symbol = self.symbols[0]
        bars = self._bars_data.get(primary_symbol, [])
        
        if not bars:
            logger.error(f"No bars for primary symbol {primary_symbol}")
            return PerformanceReport()
        
        logger.info(f"Processing {len(bars)} bars...")
        
        # Iterate through bars
        for i, bar in enumerate(bars):
            
            # Progress update
            if on_progress and i % 100 == 0:
                progress = (i / len(bars)) * 100.0
                if asyncio.iscoroutinefunction(on_progress):
                     await on_progress(progress)
                else:
                    on_progress(progress)
            
            # Update context time (convert datetime to Unix ms if needed)
            bar_time_ms = int(bar.time.timestamp() * 1000) if isinstance(bar.time, datetime) else bar.time
            self.strategy._context.set_time(bar_time_ms)
            
            # Update all symbol bars from historical data
            for symbol_name in self.symbols:
                symbol = self.strategy._context.get_symbol(symbol_name)
                if symbol and symbol_name in self._bars_data:
                    symbol_bars = self._bars_data[symbol_name]
                    if i < len(symbol_bars):
                        sym_bar = symbol_bars[i]
                        symbol.bars.add(sym_bar)
            
            # Update position prices
            self.strategy._context.update_prices()
            
            # Process pending limit orders
            self._process_pending_orders()
            
            # Check SL/TP using bar high/low range (not just close price)
            for pos_id, pos in list(self.strategy._context.positions.items()):
                sym_obj = self.strategy._context.get_symbol(pos.symbol)
                if not sym_obj:
                    continue
                current_bar = sym_obj.bars.current
                if not current_bar:
                    continue
                
                reason = self._check_sl_tp_hit(pos, current_bar)
                if reason:
                    logger.info(f"[Backtest] {reason.upper()} triggered for {pos.symbol}")
                    closed = self._close_position(pos, current_bar, close_reason=reason)
                    if closed:
                        self._closed_positions.append(closed)
            
            # Call strategy on_bar for primary symbol
            if asyncio.iscoroutinefunction(self.strategy.on_bar):
                await self.strategy.on_bar(bar)
            else:
                self.strategy.on_bar(bar)
            
            # Record equity
            self._equity_curve.append(self.strategy._context.equity)
            self._equity_dates.append(bar_time_ms)
        
        # Close any remaining positions at final price
        if on_progress:
            if asyncio.iscoroutinefunction(on_progress):
                await on_progress(100.0)
            else:
                on_progress(100.0)

        # Cancel any remaining pending orders and release their NAV
        for pending in list(self.strategy._pending_orders):
            if pending.nav_order_id:
                self.strategy._context.release_nav(pending.nav_order_id)
            logger.debug(f"[Backtest] Cancelled unfilled pending order: {pending.symbol} @ {pending.limit_price:.4f}")
        self.strategy._pending_orders.clear()
        
        # Call strategy on_stop
        self.strategy.on_stop()
        self.strategy._running = False
        
        # Calculate final metrics
        logger.info("Calculating metrics...")
        
        # Use history from context as it contains all closed positions (manual + risk + end of test)
        all_trades = self.strategy._context.history
        
        metrics = calculate_metrics(
            trades=all_trades,
            equity_curve=self._equity_curve,
            initial_capital=self.initial_capital,
            start_date=self.start_date,
            end_date=self.end_date,
        )
        
        # Generate report
        report = build_report(
            strategy_name=self.strategy.name,
            start_date=self.start_date,
            end_date=self.end_date,
            metrics=metrics,
            equity_curve=self._equity_curve,
            equity_dates=self._equity_dates,
        )
        report.trades = all_trades
        
        logger.info(f"Backtest complete. Net profit: {metrics.net_profit:,.2f} ({metrics.net_profit_pct:.2f}%)")
        logger.info(f"Total trades: {metrics.total_trades}, Win rate: {metrics.win_rate:.1f}%")
        
        # Update strategy metrics property
        metrics.current_nav = self.strategy._context.available_nav
        self.strategy._metrics = metrics
        
        # Fire callback events for metrics and report
        if hasattr(self.strategy, '_callback') and self.strategy._callback:
            from ..models import CallbackEventType
            # Strategy metrics callback
            self.strategy._callback.send_event(
                CallbackEventType.STRATEGY_METRICS,
                data=metrics.to_dict(),
                strategy_name=self.strategy.name,
            )
            # Report callback
            self.strategy._callback.send_event(
                CallbackEventType.REPORT,
                data=report.to_dict(),
                strategy_name=self.strategy.name,
            )
            # Flush pending callbacks before returning
            self.strategy._callback.flush()
        
        return report
    
    def _load_historical_data(self, market_data) -> None:
        """Load historical bar data for all symbols."""
        # Reuse service
        
        start_ts = self.start_date
        end_ts = self.end_date
        
        for symbol in self.symbols:
            logger.info(f"Loading historical data for {symbol}...")
            
            try:
                candles = market_data.fetch_candles(
                    symbol=symbol,
                    resolution=self.resolution,
                    from_ts=start_ts,
                    to_ts=end_ts,
                )
                
                bars = [Bar.from_candle(c, symbol) for c in candles]
                self._bars_data[symbol] = bars
                
                logger.info(f"Loaded {len(bars)} bars for {symbol}")
                
                if not bars:
                    raise Exception(f"No historical data loaded for {symbol} within the specified date range.")
                
            except Exception as e:
                logger.error(f"Failed to load data for {symbol}: {e}")
                raise
    
    def _check_sl_tp_hit(self, position, bar) -> Optional[str]:
        """
        Check if SL or TP is hit within the bar's high-low range.
        
        Uses bar high/low to determine if SL/TP price was reached,
        rather than just the close price.
        
        Returns:
            Close reason string ("sl", "tp", "trailing") or None
        """
        bar_high = bar.high
        bar_low = bar.low
        
        # Check trailing stop first
        if position.trailing_stop and position.trailing_stop_distance > 0:
            if position.is_long:
                # Update highest price if bar made new high
                if bar_high > position.highest_price:
                    position.highest_price = bar_high
                dynamic_stop = position.highest_price - position.trailing_stop_distance
                if bar_low <= dynamic_stop:
                    return "trailing"
            else:
                # Update lowest price if bar made new low
                if bar_low < position.lowest_price:
                    position.lowest_price = bar_low
                dynamic_stop = position.lowest_price + position.trailing_stop_distance
                if bar_high >= dynamic_stop:
                    return "trailing"
        
        # Check stop loss
        if position.stop_loss is not None:
            if position.is_long and bar_low <= position.stop_loss:
                return "sl"
            elif position.is_short and bar_high >= position.stop_loss:
                return "sl"
        
        # Check take profit
        if position.take_profit is not None:
            if position.is_long and bar_high >= position.take_profit:
                return "tp"
            elif position.is_short and bar_low <= position.take_profit:
                return "tp"
        
        return None

    def _process_pending_orders(self) -> None:
        """
        Check all pending limit orders against current bars.
        
        For each pending order, if the limit price falls within the bar's
        [low, high] range, fill the order at the limit price.
        """
        if not self.strategy._pending_orders:
            return
        
        filled = []
        for pending in self.strategy._pending_orders:
            sym_obj = self.strategy._context.get_symbol(pending.symbol)
            if not sym_obj:
                continue
            current_bar = sym_obj.bars.current
            if not current_bar:
                continue
            
            # Check if limit price is within bar range
            if pending.limit_price < current_bar.low or pending.limit_price > current_bar.high:
                continue
            
            # Fill the order
            if pending.order_type == "entry":
                self._fill_pending_entry(pending, sym_obj)
            elif pending.order_type == "close":
                self._fill_pending_close(pending, sym_obj)
            
            filled.append(pending)
        
        # Remove filled orders
        for p in filled:
            self.strategy._pending_orders.remove(p)
    
    def _fill_pending_entry(self, pending, sym_obj) -> None:
        """Fill a pending entry limit order."""
        from ..models import PositionSide
        
        side = PositionSide.LONG if pending.side == "LONG" else PositionSide.SHORT
        entry_price = pending.limit_price
        
        # Convert NAV reservation to position
        self.strategy._context.convert_nav_to_position(pending.nav_order_id)
        
        # Calculate trailing stop distance
        trailing_distance = 0.0
        if pending.trailing_stop and pending.trailing_stop_pct > 0:
            trailing_distance = entry_price * pending.trailing_stop_pct / 100
        
        # Open position
        position = self.strategy._context.open_position(
            symbol=pending.symbol,
            side=side,
            quantity=pending.quantity,
            price=entry_price,
            stop_loss=pending.stop_loss,
            take_profit=pending.take_profit,
            trailing_stop=pending.trailing_stop,
            trailing_stop_distance=trailing_distance,
        )
        
        position.order_id = pending.nav_order_id
        
        action = "BUY" if side == PositionSide.LONG else "SELL"
        logger.info(
            f"[Backtest] Pending {action} filled: {pending.symbol} "
            f"qty={pending.quantity} @ {entry_price:.4f}"
        )
        
        self.strategy.on_position_opened(position)
        
        if self.strategy._callback:
            from ..models import CallbackEventType
            self.strategy._callback.send_event(
                CallbackEventType.POSITION_OPENED,
                data=position.to_dict(),
                strategy_name=self.strategy.name,
            )
    
    def _fill_pending_close(self, pending, sym_obj) -> None:
        """Fill a pending close limit order."""
        exit_price = sym_obj.normalize_price(pending.limit_price)
        
        pos = self.strategy._context.positions.get(pending.position_id)
        if not pos:
            logger.debug(f"[Backtest] Pending close: position {pending.position_id[:8]} already closed")
            return
        
        bar_time_ms = self.strategy._context.current_time
        
        closed = self.strategy._context.close_position(
            pending.position_id, exit_price, exit_time=bar_time_ms, commission_pct=self.commission_pct
        )
        
        if closed:
            self._closed_positions.append(closed)
            pnl_pct = closed.pnl_percent if hasattr(closed, 'pnl_percent') else 0
            logger.info(
                f"[Backtest] Pending close filled: {pending.symbol} "
                f"@ {exit_price:.4f} PnL={closed.pnl:+,.2f} ({pnl_pct:+.2f}%)"
            )

    def _close_position(self, position, bar, close_reason: str = "manual") -> Optional[ClosedPosition]:
        """
        Close a position using bar-level fill simulation.

        Fill logic:
        - SL: fill at stop_loss price + slippage (worse direction)
        - TP: fill at take_profit price + slippage (worse direction)
        - Trailing: fill at dynamic stop price + slippage (worse direction)
        - Manual/Risk: fill at bar close + slippage

        Slippage direction (worse for the trader):
        - Long exit (selling): price decreases → subtract slippage
        - Short exit (buying back): price increases → add slippage

        Args:
            position: Position to close
            bar: Current bar (Bar object) for price reference
            close_reason: "sl", "tp", "trailing", "manual", or "risk"
        """
        if not self.strategy._context:
            return None
        symbol = self.strategy._context.get_symbol(position.symbol)
        if not symbol:
            return None

        tick = symbol.tick_size
        slippage = self.slippage_ticks * tick
        bar_time_ms = self.strategy._context.current_time

        if close_reason == "sl":
            # Fill at SL price + slippage (worse)
            if position.stop_loss is not None:
                raw_price = position.stop_loss
            else:
                raw_price = bar.close if bar else 0.0
            if position.is_long:
                raw_price -= slippage  # worse for long = lower
            else:
                raw_price += slippage  # worse for short = higher

        elif close_reason == "tp":
            # Fill at TP price + slippage (worse)
            if position.take_profit is not None:
                raw_price = position.take_profit
            else:
                raw_price = bar.close if bar else 0.0
            if position.is_long:
                raw_price -= slippage  # worse for long = lower
            else:
                raw_price += slippage  # worse for short = higher

        elif close_reason == "trailing":
            # Fill at dynamic trailing stop price + slippage
            if position.is_long:
                raw_price = position.highest_price - position.trailing_stop_distance
                raw_price -= slippage
            else:
                raw_price = position.lowest_price + position.trailing_stop_distance
                raw_price += slippage
        else:
            # Manual / risk close: use bar close + slippage
            raw_price = bar.close if bar else 0.0
            if position.is_long:
                raw_price -= slippage
            else:
                raw_price += slippage

        exit_price = symbol.normalize_price(raw_price)

        logger.debug(
            f"[Backtest] Fill for {position.symbol}: "
            f"reason={close_reason}, price={exit_price:.4f} (slippage={self.slippage_ticks} ticks)"
        )

        # Close in context (handles PnL, commission, account, margin, NAV, equity, listeners)
        closed = self.strategy._context.close_position(
            position.id, exit_price, exit_time=bar_time_ms, commission_pct=self.commission_pct
        )

        if closed:
            pnl_pct = closed.pnl_percent if hasattr(closed, 'pnl_percent') else 0
            logger.info(
                f"[Backtest] Position closed: {position.symbol} {position.side.value} "
                f"reason={close_reason} entry={position.entry_price:.4f} exit={exit_price:.4f} "
                f"PnL={closed.pnl:+,.2f} ({pnl_pct:+.2f}%)"
            )

        return closed
