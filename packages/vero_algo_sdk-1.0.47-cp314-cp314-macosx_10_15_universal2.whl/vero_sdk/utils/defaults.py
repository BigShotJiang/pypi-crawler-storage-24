"""
Default configuration for Vero Algo SDK.

Contains hardcoded server URLs - no environment variables needed.
"""

# ============================================================================
# Default Server URLs (from tenant.json)
# ============================================================================

# Main API server for trading operations
DEFAULT_BACKEND_SERVER = "api-gw-dev.verolabs.co"

# Authentication server
DEFAULT_AUTH_SERVER = "https://api-gw-dev.verolabs.co/api/authen"

# Micro API for market data (OpenAPI)
DEFAULT_MICRO_API_SERVER = "https://openapi.verolabs.co"

# Streaming endpoints
DEFAULT_STREAMING_WS = "wss://streaming.verolabs.co/connection/websocket"
DEFAULT_STREAMING_HTTP = "https://streaming.verolabs.co/connection/http_stream"
DEFAULT_STREAMING_SSE = "https://streaming.verolabs.co/connection/sse"

# Default protocol
DEFAULT_PROTOCOL = "https"


# ============================================================================
# Default Backtest Settings
# ============================================================================

DEFAULT_COMMISSION_PCT = 0.1  # Commission percentage
DEFAULT_SLIPPAGE_TICKS = 0  # Slippage in ticks


# ============================================================================
# Logging Defaults
# ============================================================================

DEFAULT_LOG_LEVEL = "DEBUG"
DEFAULT_LOG_FILE = "logs/vero_strategy.log"
DEFAULT_WARN_LOG_FILE = "logs/warn.log"
DEFAULT_STREAM_LOG_FILE = "logs/stream.log"
DEFAULT_LOG_MAX_SIZE_MB = 10
DEFAULT_LOG_BACKUP_COUNT = 5

# ============================================================================
# Enum Helpers
# ============================================================================

def enum_val(value):
    """
    Extract .value from an enum, pass strings/other types through unchanged.

    Cython-compiled modules reject enum subclasses of str even though they
    inherit from str. This helper ensures we always pass plain strings.
    """
    if hasattr(value, "value") and hasattr(value, "name"):
        # It's an enum — extract the raw value
        return str(value.value)
    return value

