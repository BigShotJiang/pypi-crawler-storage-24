"""
Logging configuration for Vero Algo SDK.

Provides detailed logging with file rotation and formatted output.
"""

import logging
import sys
import os
from logging.handlers import RotatingFileHandler
from typing import Optional

from .defaults import (
    DEFAULT_LOG_LEVEL,
    DEFAULT_LOG_FILE,
    DEFAULT_LOG_MAX_SIZE_MB,
    DEFAULT_LOG_BACKUP_COUNT,
    DEFAULT_WARN_LOG_FILE,
    DEFAULT_STREAM_LOG_FILE,
)
from .._version import __version__


# ============================================================================
# Custom Formatters
# ============================================================================

class DetailedFormatter(logging.Formatter):
    """Detailed formatter for all logging (console and file)."""

    def __init__(self):
        super().__init__(
            fmt="%(asctime)s.%(msecs)03d | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )


# ============================================================================
# Logger Setup
# ============================================================================

_configured = False


def setup_logging(
    level: str = DEFAULT_LOG_LEVEL,
    log_file: Optional[str] = DEFAULT_LOG_FILE,
    warn_log_file: Optional[str] = DEFAULT_WARN_LOG_FILE,
    stream_log_file: Optional[str] = DEFAULT_STREAM_LOG_FILE,
    console: bool = True,
    max_size_mb: int = DEFAULT_LOG_MAX_SIZE_MB,
    backup_count: int = DEFAULT_LOG_BACKUP_COUNT,
) -> None:
    """
    Configure logging for Vero SDK.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Path to log file (None to disable file logging)
        warn_log_file: Path to warning/error log file
        stream_log_file: Path to dedicated streaming log file
        console: Enable console output
        max_size_mb: Max log file size before rotation
        backup_count: Number of backup log files to keep
    """
    global _configured

    if _configured:
        return

    # Configure Root Logger to capture EVERYTHING
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, level.upper()))

    # Clear existing handlers to prevent duplicates/default format
    if logger.hasHandlers():
        logger.handlers.clear()

    # Console handler
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(DetailedFormatter())
        logger.addHandler(console_handler)

    # Helper to ensure directory exists
    def _ensure_dir(path: str):
        if not path:
            return
        log_dir = os.path.dirname(path)
        if log_dir and not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir, exist_ok=True)
            except Exception as e:
                sys.stderr.write(f"Failed to create log directory {log_dir}: {e}\n")

    # File handler with rotation
    if log_file:
        _ensure_dir(log_file)
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=max_size_mb * 1024 * 1024,
            backupCount=backup_count,
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(DetailedFormatter())
        logger.addHandler(file_handler)

    # Warn File handler (Errors and Warnings only)
    if warn_log_file:
        _ensure_dir(warn_log_file)
        warn_handler = RotatingFileHandler(
            warn_log_file,
            maxBytes=max_size_mb * 1024 * 1024,
            backupCount=backup_count,
        )
        warn_handler.setLevel(logging.WARNING)
        warn_handler.setFormatter(DetailedFormatter())
        logger.addHandler(warn_handler)

    # Separate Streaming Log Handler
    if stream_log_file:
        _ensure_dir(stream_log_file)
        stream_handler = RotatingFileHandler(
            stream_log_file,
            maxBytes=max_size_mb * 1024 * 1024,
            backupCount=backup_count,
        )
        stream_handler.setLevel(logging.DEBUG)
        stream_handler.setFormatter(DetailedFormatter())

        # Configure streaming loggers (Internal + External)
        stream_loggers = [
            "vero_sdk.features.streaming",
            "websockets",
            "centrifuge"
        ]

        for name in stream_loggers:
            s_logger = logging.getLogger(name)
            s_logger.setLevel(logging.DEBUG)
            s_logger.addHandler(stream_handler)
            s_logger.propagate = False

            if console and 'console_handler' in locals():
                s_logger.addHandler(console_handler)

    _configured = True

    # Log SDK version on startup
    logger.info(f"Vero SDK v{__version__} initialized")


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger for a component.

    Args:
        name: Component name (e.g., "strategy", "risk", "backtest")

    Returns:
        Logger instance
    """
    if not _configured:
        setup_logging()

    if name == "vero":
        return logging.getLogger("vero_sdk.core")

    return logging.getLogger(f"vero_sdk.{name}")


# ============================================================================
# Strategy-specific Logging Helpers
# ============================================================================


class VeroLogger:
    """
    SDK logger that optionally sends log events to the callback API.

    Uses a class-level shared callback so that once any part of the SDK
    sets the callback service, ALL VeroLogger instances automatically
    forward log events.

    Args:
        name: Logger name (will be prefixed with vero_sdk.)
        send_callback: If True, log events are also sent to the callback API.
                       Set to False for internal services (e.g. CallbackService)
                       to prevent infinite loops.
    """

    _shared_callback = None  # Class-level CallbackService, shared by all instances

    def __init__(self, name: str, send_callback: bool = True):
        self._logger = get_logger(name)
        self._send_callback = send_callback
        self.name = name

    @classmethod
    def set_callback(cls, callback) -> None:
        """Set the shared callback service for all VeroLogger instances."""
        cls._shared_callback = callback

    def _fire_log_callback(self, level: str, message: str) -> None:
        """Send log event to callback API if enabled and configured."""
        if not self._send_callback or not VeroLogger._shared_callback:
            return
        from ..models import CallbackEventType
        VeroLogger._shared_callback.send_event(
            CallbackEventType.LOG,
            data={"level": level, "message": message},
            strategy_name=self.name,
        )

    def debug(self, msg: str, *args, **kwargs) -> None:
        self._logger.debug(msg, *args, **kwargs)

    def info(self, msg: str, *args, **kwargs) -> None:
        self._logger.info(msg, *args, **kwargs)
        self._fire_log_callback("INFO", msg)

    def warning(self, msg: str, *args, **kwargs) -> None:
        self._logger.warning(msg, *args, **kwargs)
        self._fire_log_callback("WARNING", msg)

    def error(self, msg: str, *args, **kwargs) -> None:
        self._logger.error(msg, *args, **kwargs)
        self._fire_log_callback("ERROR", msg)

    def critical(self, msg: str, *args, **kwargs) -> None:
        self._logger.critical(msg, *args, **kwargs)
        self._fire_log_callback("CRITICAL", msg)



class StrategyLogger(VeroLogger):
    """Enhanced logger for strategy/robot with trading-specific methods."""

    def __init__(self, strategy_name: str):
        super().__init__(f"strategy.{strategy_name}", send_callback=True)
        self.strategy_name = strategy_name

    def order(self, action: str, symbol: str, qty: int, price: float, **kwargs) -> None:
        """Log order action."""
        self._logger.info(f"ORDER: {action.upper()} {symbol} {qty}@{price}")
        self._fire_log_callback("INFO", f"ORDER: {action.upper()} {symbol} {qty}@{price}")

    def trade(self, symbol: str, side: object, qty: int, price: float, pnl: float = 0) -> None:
        """Log trade execution."""
        pnl_str = f" P&L: {pnl:+.2f}" if pnl != 0 else ""
        self._logger.info(f"TRADE: {side} {symbol} {qty}@{price}{pnl_str}")
        self._fire_log_callback("INFO", f"TRADE: {side} {symbol} {qty}@{price}{pnl_str}")

    def position(self, action: str, symbol: str, qty: int, entry: float, pnl: float = 0, pnl_pct: float = 0) -> None:
        """Log position change."""
        pct_str = f" ({pnl_pct:+.2f}%)" if pnl_pct != 0 else ""
        self._logger.info(f"POSITION {action.upper()}: {symbol} {qty}@{entry} P&L: {pnl:+.2f}{pct_str}")
        self._fire_log_callback("INFO", f"POSITION {action.upper()}: {symbol} {qty}@{entry} P&L: {pnl:+.2f}{pct_str}")

    def risk(self, msg: str) -> None:
        """Log risk management event."""
        self._logger.warning(f"RISK: {msg}")
        self._fire_log_callback("WARNING", f"RISK: {msg}")

    def bar(self, symbol: str, o: float, h: float, l: float, c: float, v: float) -> None:
        """Log bar data (debug level)."""
        self._logger.debug(f"BAR: {symbol} O={o} H={h} L={l} C={c} V={v}")

    def candle(self, bar, indicators: dict = None) -> None:
        """
        Log candle data with indicator values at INFO level.

        Args:
            bar: Bar object with time, open, high, low, close, volume
            indicators: Dict of {name: indicator} where indicator supports [-1] access
        """
        parts = [f"[CANDLE] {bar.time} C:{bar.close}"]

        if indicators:
            for ind_name, ind in indicators.items():
                try:
                    val = ind[-1] if len(ind) > 0 else None
                    if val is not None:
                        parts.append(f"{ind_name}: {val}")
                except (IndexError, TypeError):
                    pass

        msg = ", ".join(parts)
        self._logger.info(msg)
        self._fire_log_callback("INFO", msg)
