"""
Vero Algo SDK for Python

A Python SDK for the Vero Algo trading platform with authentication,
order management, streaming, market data, and algorithmic trading capabilities.
"""

from .client import VeroClient
from .config import VeroConfig
from .features.orders import OrderService
from .features.market_data import MarketDataService
from .features.streaming import VeroStream
from .utils.defaults import (
    DEFAULT_BACKEND_SERVER,
    DEFAULT_AUTH_SERVER,
    DEFAULT_MICRO_API_SERVER,
    DEFAULT_STREAMING_WS,
)
from .utils.logging_config import setup_logging, get_logger, VeroLogger
from .models import (
    OrderSide,
    OrderType,
    OrderStatus,
    AlgoStatus,
    RunMode,
    PositionSide,
    Timeframe,
    DatePreset,
    NewOrderRequest,
    CancelOrderRequest,
    OrderData,
    OrderResponse,
    Trade,
    Candle,
    ProductMaster,
    PriceLevel,
    PersistenceInfo,
    MarginRatio,
    Account,
    SubscribeData,
    StreamMessage,
    StrategyInitSettings,
    Bar,
    Bars,
    Symbol,
)

# Strategy framework
from .strategy import Strategy, TradingContext, Position

# Backtesting
from .backtest import BacktestEngine, PerformanceReport
from .models import StrategyMetrics
from .metrics import calculate_metrics, calculate_monthly_returns
from .report import build_report, print_report

# Callback
from .callback import CallbackService
from .models import CallbackEventType, CallbackEvent

from .core import Vero

try:
    from ._version import __version__
except ImportError:
    __version__ = "0.0.0+unknown"

__all__ = [
    # Version
    "__version__",
    # Core
    "VeroClient",
    "VeroConfig",
    "OrderService",
    "MarketDataService",
    "VeroStream",
    "Vero",
    # Enums
    "OrderSide",
    "OrderType",
    "OrderStatus",
    "AlgoStatus",
    "RunMode",
    "PositionSide",
    "Timeframe",
    "DatePreset",
    # Orders
    "PersistenceInfo",
    "NewOrderRequest",
    "CancelOrderRequest",
    "OrderData",
    "OrderResponse",
    "Trade",
    # Market Data
    "Candle",
    "PriceLevel",
    "ProductMaster",
    "MarginRatio",
    # Account
    "Account",
    # Streaming
    "SubscribeData",
    "StreamMessage",
    # Settings
    "StrategyInitSettings",
    # Strategy
    "Strategy",
    "TradingContext",
    "Position",
    "Symbol",
    "Bar",
    "Bars",
    # Backtest
    "BacktestEngine",
    "PerformanceReport",
    "StrategyMetrics",
    # Metrics & Report
    "calculate_metrics",
    "calculate_monthly_returns",
    "build_report",
    "print_report",
    # Callback
    "CallbackEventType",
    "CallbackEvent",
    "CallbackService",
    # Logging
    "setup_logging",
    "get_logger",
    "VeroLogger",
]
