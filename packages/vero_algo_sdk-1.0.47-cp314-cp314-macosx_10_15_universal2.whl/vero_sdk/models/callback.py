"""
Callback event types and DTOs for Vero Algo SDK.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict


class CallbackEventType(str, Enum):
    """Types of callback events."""
    ORDER_PLACED = "order_placed"
    POSITION_OPENED = "position_opened"
    POSITION_CLOSED = "position_closed"
    TRADE = "trade"
    STRATEGY_METRICS = "strategy_metrics"
    REPORT = "report"
    LOG = "log"


@dataclass
class CallbackEvent:
    """
    Callback event payload.
    
    Attributes:
        event_type: Type of event
        timestamp: Unix timestamp in milliseconds
        strategy_name: Name of the strategy that generated the event
        data: Event-specific payload data
    """
    event_type: str
    timestamp: int
    strategy_name: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "strategy_name": self.strategy_name,
            "data": self.data,
        }
