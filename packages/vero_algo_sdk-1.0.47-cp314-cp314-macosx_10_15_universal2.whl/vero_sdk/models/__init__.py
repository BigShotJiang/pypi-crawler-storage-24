"""
Models (DTOs) and Enums for Vero Algo SDK.

All data transfer objects, enums, and type definitions are stored here.
"""

from .enums import (
    OrderSide,
    OrderType,
    OrderStatus,
    AlgoStatus,
    RunMode,
    PositionSide,
    Timeframe,
    DatePreset,
)
from .orders import (
    PersistenceInfo,
    NewOrderRequest,
    CancelOrderRequest,
    OrderData,
    OrderResponse,
    Trade,
    PendingOrder,
)
from .market_data import (
    Candle,
    PriceLevel,
    ProductMaster,
    MarginRatio,
    ProductInfo,
    ProductStat,
    Depth,
)
from .account import Account
from .streaming import SubscribeData, StreamMessage, VeroSubscription
from .settings import StrategyInitSettings
from .position import Position, ClosedPosition, AccountInfo
from .reports import StrategyMetrics, PerformanceReport
from .constants import Channels, DataTypes, TimeResolution
from .callback import CallbackEventType, CallbackEvent
from .symbol import Bar, Bars, Symbol

__all__ = [
    # Enums
    "OrderSide",
    "OrderType",
    "OrderStatus",
    "AlgoStatus",
    "RunMode",
    "PositionSide",
    "Timeframe",
    "DatePreset",
    # Orders
    "PersistenceInfo",
    "NewOrderRequest",
    "CancelOrderRequest",
    "OrderData",
    "OrderResponse",
    "Trade",
    "PendingOrder",
    # Market Data
    "Candle",
    "PriceLevel",
    "ProductMaster",
    "MarginRatio",
    "ProductInfo",
    "ProductStat",
    "Depth",
    # Account
    "Account",
    # Streaming
    "SubscribeData",
    "StreamMessage",
    # Settings
    "StrategyInitSettings",
    # Position
    "Position",
    "ClosedPosition",
    "AccountInfo",
    # Reports
    "StrategyMetrics",
    "PerformanceReport",
    # Constants
    "Channels",
    "DataTypes",
    "TimeResolution",
    # Callback
    "CallbackEventType",
    "CallbackEvent",
    # Symbol
    "Bar",
    "Bars",
    "Symbol",
]
