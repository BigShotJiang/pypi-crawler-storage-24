from dataclasses import dataclass
from typing import Any, Optional, List, Union, Callable, Awaitable

@dataclass
class SubscribeData:
    """Data for subscribing to a channel."""
    channel_name: str
    channel: str
    data_type: str
    data_id: str
    listener_guid: str


@dataclass
class StreamMessage:
    """Message received from stream."""
    channel: str
    data_type: str
    data_id: str
    data: Any
    seq: int = 0
    message_id: str = ""


@dataclass
class VeroSubscription:
    """Represents an active subscription wrapper."""
    channel_name: str
    callbacks: Optional[List[Union[Callable[[Any], Awaitable[None]], Callable[[Any], None]]]] = None
    sub_obj: Any = None  # Subscription type from centrifuge
    active: bool = True
    
    def __post_init__(self):
        if self.callbacks is None:
            self.callbacks = []
