"""
Constants for Vero Algo SDK streaming and time resolution.
"""


# Channel names for streaming
class Channels:
    """Channel names for Centrifuge subscriptions."""
    MARKET = "mkt"
    ALGO = "algo"
    ORDER = "order"
    NOTIFY = "notify"


# Data types for streaming
class DataTypes:
    """Data types for Centrifuge subscriptions."""
    DEPTH = "depth"
    PRODUCT_INFO = "productInfo"
    PRODUCT_STAT = "productStat"
    HEAT_MAP = "HeatMap"
    TRADE_LOG = "tradeLog"
    OHLCV = "OhlcvDTO"
    ALGO_MASTER = "AlgoMaster"
    ALGO_LOG = "AlgoLog"
    ALGO_PLAN = "AlgoPlan"
    ALGO_POSITION = "AlgoPosition"
    ALGO_ORDER = "AlgoOrder"
    ALGO_STATUS = "AlgoStatus"
    ALGO_NOTIFY = "AlgoNotify"
    ORDER_EXECUTION_REPORT = "OrderExecutionReport"


# Time resolutions for candle data (in seconds)
class TimeResolution:
    """Time resolution constants for OHLCV data (in seconds)."""
    MINUTE_1 = 60
    MINUTE_5 = 300
    MINUTE_15 = 900
    MINUTE_30 = 1800
    HOUR_1 = 3600
    HOUR_4 = 14400
    DAY_1 = 86400
