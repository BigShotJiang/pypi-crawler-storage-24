"""
Callback API for Vero Algo SDK.

Fires HTTP POST requests to a configured URL when trading events occur.
Events include: order placed, position opened/closed, trade, metrics, report.
"""

import threading
import queue
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .models import CallbackEventType, CallbackEvent
from .utils.logging_config import VeroLogger

# send_callback=False prevents infinite loop: callback logs -> fire callback -> callback logs -> ...
logger = VeroLogger("callback", send_callback=False)


class CallbackService:
    """
    Asynchronous callback service.
    
    Sends HTTP POST requests to a configured URL in a background thread.
    Fire-and-forget: failures are logged but do not raise exceptions.
    
    Usage:
        service = CallbackService("https://example.com/webhook")
        service.send(CallbackEvent(...))
        service.flush()  # Wait for pending callbacks
        service.shutdown()  # Stop background thread
    """
    
    def __init__(self, callback_url: str, timeout: float = 10.0):
        """
        Initialize CallbackService.
        
        Args:
            callback_url: Full callback URL including strategy_id in path
                          (e.g. http://host:8000/api/events/{strategy_id})
            timeout: HTTP request timeout in seconds
        """
        self._url = callback_url
        self._timeout = timeout
        self._queue: queue.Queue = queue.Queue()
        self._shutdown_event = threading.Event()
        
        # Start background worker thread
        self._worker = threading.Thread(
            target=self._worker_loop,
            name="vero-callback-worker",
            daemon=True,
        )
        self._worker.start()
        logger.info(f"Callback service started: {callback_url}")
    
    @property
    def url(self) -> str:
        """Get the callback URL."""
        return self._url
    
    def send(self, event: CallbackEvent) -> None:
        """
        Queue a callback event for delivery.
        
        Args:
            event: The callback event to send
        """
        if self._shutdown_event.is_set():
            logger.warning("Callback service is shut down, ignoring event")
            return
        logger.debug(f"Queuing callback event: {event.event_type} (queue_size={self._queue.qsize()})")
        self._queue.put(event)
    
    def send_event(
        self,
        event_type: CallbackEventType,
        data: Dict[str, Any],
        strategy_name: str = "",
    ) -> None:
        """
        Convenience method to create and queue a callback event.
        
        Args:
            event_type: Type of event
            data: Event payload data
            strategy_name: Name of the strategy
        """
        event = CallbackEvent(
            event_type=event_type.value if isinstance(event_type, CallbackEventType) else str(event_type),
            timestamp=int(datetime.now(timezone.utc).timestamp() * 1000),
            strategy_name=strategy_name,
            data=data,
        )
        self.send(event)
    
    def flush(self, timeout: float = 30.0) -> None:
        """
        Wait for all pending callbacks to be sent.
        
        Args:
            timeout: Maximum time to wait in seconds
        """
        self._queue.join()
    
    def shutdown(self) -> None:
        """Stop the callback service and wait for pending events."""
        self._shutdown_event.set()
        # Drain remaining events
        try:
            self.flush(timeout=10.0)
        except Exception:
            pass
        self._worker.join(timeout=5.0)
        logger.info("Callback service stopped")
    
    def _worker_loop(self) -> None:
        """Background worker that processes the event queue."""
        import requests as req_lib
        
        while not self._shutdown_event.is_set() or not self._queue.empty():
            try:
                event = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue
            
            try:
                payload = event.to_dict()
                response = req_lib.post(
                    self._url,
                    json=payload,
                    timeout=self._timeout,
                    headers={"Content-Type": "application/json"},
                )
                if response.status_code >= 400:
                    logger.warning(
                        f"Callback POST failed: {response.status_code} "
                        f"for event {event.event_type} | "
                        f"url={self._url} | body={payload} | "
                        f"response={response.text}"
                    )
                else:
                    logger.debug(
                        f"Callback sent: {event.event_type} -> {response.status_code}"
                    )
            except Exception as e:
                logger.warning(f"Callback POST error for {event.event_type}: {e}")
            finally:
                self._queue.task_done()
