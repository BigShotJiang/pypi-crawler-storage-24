"""Session ingestion pipeline."""
