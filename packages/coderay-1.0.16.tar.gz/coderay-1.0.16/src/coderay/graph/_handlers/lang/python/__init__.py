"""Python-specific graph handlers."""
