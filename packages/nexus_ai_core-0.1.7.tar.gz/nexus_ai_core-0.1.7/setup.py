from pathlib import Path
from setuptools import setup, find_packages, Extension
from Cython.Build import cythonize

base_dir = Path("nexus/docpipe")

extensions = []
for py_file in base_dir.glob("*.py"):
    if py_file.name in ["__init__.py", "summary.py"]:
        continue

    module_name = f"nexus.docpipe.{py_file.stem}"
    extensions.append(Extension(module_name, [str(py_file)]))

setup(
    name="nexus-ai-core",
    version="0.1.7",
    packages=find_packages(include=["nexus", "nexus.*"]),
    include_package_data=True,
    package_data={
        "nexus.docpipe": ["*.so", "*.py"],
    },
    ext_modules=cythonize(
        extensions,
        compiler_directives={"language_level": "3"},
    ),
    zip_safe=False,
    python_requires=">=3.11",
)