# docpipe/__init__.py
from __future__ import annotations

"""
docpipe package: document processing helpers.

Modules:
- metadata: load CSV metadata
- qd_extract: extract QD-style document numbers from user queries
- doc_number_search: fuzzy search over document numbers
- bpe_fuzzy: BPE/Tokenizer-based fuzzy search for filenames
"""

__all__ = [
    "metadata",
    "qd_extract",
    "doc_number_search",
    "bpe_fuzzy",
    "llm_logic",
    "agent_logic"
]
