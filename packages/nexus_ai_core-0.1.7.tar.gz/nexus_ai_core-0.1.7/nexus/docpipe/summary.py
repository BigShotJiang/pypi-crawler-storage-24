from pathlib import Path
from typing import Optional, Dict, List, Union

def get_summary(qd_number:Optional[str]=None, document_name:Optional[str]=None, folder_DIR:Optional[Union[str,Path]]=None)->Dict:
    
    
    summary_dict= {"filename": document_name,
                    "summary":"",
                    "loaded_succesfully?":False,
                    "error_message":""}

    if folder_DIR is None:
        folder_DIR = Path.cwd() / 'summaries'
    else:
        folder_DIR = Path(folder_DIR)
    
    try:
        file_path = (folder_DIR / document_name).with_suffix('.md')
        
        if not file_path.exists():
            summary_dict['error_message'] = f"❌ File not found at  {file_path}"
            
            return summary_dict
        
    
        with open(file_path, 'r', encoding='utf-8') as file:
            summary = file.read()
        summary_dict["summary"] = summary
        summary_dict["loaded_succesfully?"]= True
    
    except Exception as e:
            summary_dict['error_message'] = f"ERROR:  {e}"
          
    return summary_dict



from pathlib import Path
from typing import Optional, Dict, Union

def get_summary(
    qd_number: Optional[str] = None,
    document_name: Optional[str] = None,
    folder_DIR: Optional[Union[str, Path]] = None,
    *,
    local_files_only: bool = True
) -> Dict:
    """
    Load a pre-generated document summary from disk.

    Args:
        qd_number: Optional QD number (not used yet, reserved for future).
        document_name: Base document filename (without .md).
        folder_DIR: Directory containing summary markdown files.
        local_files_only: If True, requires folder_DIR to be provided and forbids fallback.

    Returns:
        {
            "filename": document_name,
            "summary": str,
            "loaded_successfully?": bool,
            "error_message": str
        }
    """

    summary_dict = {
        "filename": document_name,
        "summary": "",
        "loaded_successfully?": False,
        "error_message": ""
    }

    # Enforce explicit folder in prod/offline mode
    if local_files_only:
        if folder_DIR is None:
            raise RuntimeError("❌ folder_DIR must be provided when local_files_only=True")

    try:
        file_path = (folder_path / document_name).with_suffix(".md")

        if not file_path.exists():
            summary_dict["error_message"] = f"❌ File not found at {file_path}"
            return summary_dict

        with open(file_path, "r", encoding="utf-8") as file:
            summary = file.read()

        summary_dict["summary"] = summary
        summary_dict["loaded_successfully?"] = True

    except Exception as e:
        summary_dict["error_message"] = f"ERROR: {e}"

    return summary_dict
 