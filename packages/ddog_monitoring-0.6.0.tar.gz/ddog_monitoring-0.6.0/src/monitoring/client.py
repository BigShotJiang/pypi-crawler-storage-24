from .interfaces import MetricProvider
from .config import MonitoringConfig

class MonitoringFacade:
    _instance = None
    _config: MonitoringConfig = None

    @classmethod
    def configure(cls, config: MonitoringConfig):
        cls._config = config
        cls._instance = None  # Reset instance so it picks up new config

    @classmethod
    def get_instance(cls) -> MetricProvider:
        if cls._instance is None:
            if cls._config is None:
                raise ValueError("MonitoringFacade is not configured. Call MonitoringFacade.configure() first.")

            provider_name = cls._config.provider

            if provider_name == "datadog":
                from .providers.datadog import DatadogProvider
                cls._instance = DatadogProvider(
                    api_key=cls._config.datadog_api_key,
                    app_key=cls._config.datadog_app_key,
                    host_name=cls._config.datadog_hostname,
                    logger=cls._config.logger,
                )
            elif provider_name == "sumologic":
                from .providers.sumologic import SumologicProvider
                cls._instance = SumologicProvider(
                    sumologic_url=cls._config.sumologic_url,
                    logger=cls._config.logger,
                )
            else:
                from .providers.console import ConsoleProvider
                cls._instance = ConsoleProvider(
                    logger=cls._config.logger,
                )

        return cls._instance
