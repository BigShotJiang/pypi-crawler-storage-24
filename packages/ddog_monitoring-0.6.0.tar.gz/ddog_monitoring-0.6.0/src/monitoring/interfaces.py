from abc import ABC, abstractmethod

class MetricProvider(ABC):
    @abstractmethod
    def send(self, *args, **kwargs) -> None:
        pass
