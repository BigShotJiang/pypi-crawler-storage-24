import logging
from pydantic import BaseModel, ConfigDict
from typing import Optional, Literal

class MonitoringConfig(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    provider: Literal["console", "datadog", "sumologic"] = "console"
    datadog_api_key: Optional[str] = None
    datadog_app_key: Optional[str] = None
    datadog_hostname: Optional[str] = None
    sumologic_url: Optional[str] = None
    logger: Optional[logging.Logger] = None
