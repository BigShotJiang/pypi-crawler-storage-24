import json
import logging
from typing import Optional, List, Dict

def convert_tags(tags: Optional[Dict[str, str]] = None) -> Optional[List[str]]:
    """
    Convert tags to a list of strings.
    """
    if not tags:
        return []
    return [f"{k}:{v}" for k, v in (tags or {}).items()]

def prepare_json_payload(payload: Dict) -> str:
    """
    Prepare a JSON payload for Sumologic.
    """
    return json.dumps(payload)

def get_logger(name: str) -> logging.Logger:
    """
    Return a stdlib Logger namespaced under ``ddog_monitoring.*``.

    The logger name is built as::

        ddog_monitoring.<name>

    where *name* is typically ``__name__`` of the calling module, e.g.
    ``monitoring.providers.datadog`` becomes
    ``ddog_monitoring.monitoring.providers.datadog``.

    The library never attaches handlers — log records propagate to the host
    application's root logger, which controls format and destination.

    Args:
        name: Caller's module name, typically ``__name__``.

    Returns:
        A :class:`logging.Logger` instance.
    """
    logger_name = f"ddog_monitoring.{name}"

    return logging.getLogger(logger_name)
