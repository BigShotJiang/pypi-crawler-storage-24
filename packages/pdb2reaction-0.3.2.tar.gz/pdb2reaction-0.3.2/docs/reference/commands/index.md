# CLI Command Reference

```{toctree}
:maxdepth: 1
:hidden:

add_elem_info
all
dft
energy_diagram
extract
fix_altloc
freq
irc
opt
path_opt
path_search
scan
scan2d
scan3d
trj2fig
tsopt
```

| Command | Page |
|---|---|
| `pdb2reaction add-elem-info` | [add-elem-info](add_elem_info.md) |
| `pdb2reaction all` | [all](all.md) |
| `pdb2reaction dft` | [dft](dft.md) |
| `pdb2reaction energy-diagram` | [energy-diagram](energy_diagram.md) |
| `pdb2reaction extract` | [extract](extract.md) |
| `pdb2reaction fix-altloc` | [fix-altloc](fix_altloc.md) |
| `pdb2reaction freq` | [freq](freq.md) |
| `pdb2reaction irc` | [irc](irc.md) |
| `pdb2reaction opt` | [opt](opt.md) |
| `pdb2reaction path-opt` | [path-opt](path_opt.md) |
| `pdb2reaction path-search` | [path-search](path_search.md) |
| `pdb2reaction scan` | [scan](scan.md) |
| `pdb2reaction scan2d` | [scan2d](scan2d.md) |
| `pdb2reaction scan3d` | [scan3d](scan3d.md) |
| `pdb2reaction trj2fig` | [trj2fig](trj2fig.md) |
| `pdb2reaction tsopt` | [tsopt](tsopt.md) |
