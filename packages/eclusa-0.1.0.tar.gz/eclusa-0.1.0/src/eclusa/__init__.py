def main():
    print("eclusa")
