"""
Core simplified API for the Olakai SDK.
"""

import time
import asyncio
from typing import Callable, Dict, Any
from .shared.types import OlakaiEventParams, MonitorPayload
from .client.api import send_to_api_simple
from .config import require_config


def olakai(params: OlakaiEventParams) -> None:
    """
    Track an event with the Olakai API.

    Args:
        params: Event parameters
    """
    config = require_config()

    # Convert to MonitorPayload for API compatibility
    payload = MonitorPayload(
        userEmail=params.userEmail or "anonymous@olakai.ai",
        chatId=params.sessionId or config.sessionId,
        taskExecutionId=params.taskExecutionId,
        prompt=params.prompt,
        response=params.response,
        tokens=params.tokens,
        requestTime=params.requestTime,
        task=params.task,
        subTask=params.subTask,
        customData=params.customData,
        shouldScore=params.shouldScore,
    )

    # Send asynchronously in background if possible, otherwise ignore
    try:
        loop = asyncio.get_running_loop()
        asyncio.create_task(send_to_api_simple(config, payload))
    except RuntimeError:
        # No event loop running, skip API call
        if config.debug:
            print(f"[Olakai SDK] Skipping API call - no event loop running")


def olakai_event(params: OlakaiEventParams) -> None:
    """
    Direct reporting function for simple event tracking.
    
    Args:
        params: The input data  
    """
    
    olakai(params)


def olakai_monitor(fn: Callable = None, **options):
    """
    Decorator for automatic function monitoring.
    
    Args:
        fn: Function to monitor (when used as decorator)
        **options: Monitoring options (email, chatId, task, subTask, etc.)
    """
    def decorator(func: Callable) -> Callable:
        def sync_wrapper(*args, **kwargs):
            start_time = time.time() * 1000

            try:
                # Execute the function
                result = func(*args, **kwargs)

                # Create event parameters
                params = OlakaiEventParams(
                    prompt=str(args) + str(kwargs),
                    response=str(result),
                    userEmail=options.get("userEmail", "anonymous@olakai.ai"),
                    sessionId=options.get("sessionId"),
                    task=options.get("task"),
                    subTask=options.get("subTask"),
                    customData=options.get("customData"),
                    shouldScore=options.get("shouldScore", True),
                    tokens=0,
                    requestTime=int(time.time() * 1000 - start_time),
                )

                # Track the event
                olakai(params)

                return result

            except Exception as e:
                # Track error event
                params = OlakaiEventParams(
                    prompt=str(args) + str(kwargs),
                    response=f"Error: {str(e)}",
                    userEmail=options.get("userEmail", "anonymous@olakai.ai"),
                    sessionId=options.get("sessionId"),
                    task=options.get("task"),
                    subTask=options.get("subTask"),
                    customData=options.get("customData"),
                    shouldScore=options.get("shouldScore", True),
                    tokens=0,
                    requestTime=int(time.time() * 1000 - start_time),
                )

                olakai(params)
                raise

        async def async_wrapper(*args, **kwargs):
            start_time = time.time() * 1000

            try:
                # Execute the async function
                result = await func(*args, **kwargs)

                # Create event parameters
                params = OlakaiEventParams(
                    prompt=str(args) + str(kwargs),
                    response=str(result),
                    userEmail=options.get("userEmail", "anonymous@olakai.ai"),
                    sessionId=options.get("sessionId"),
                    task=options.get("task"),
                    subTask=options.get("subTask"),
                    customData=options.get("customData"),
                    shouldScore=options.get("shouldScore", True),
                    tokens=0,
                    requestTime=int(time.time() * 1000 - start_time),
                )

                # Track the event
                olakai(params)

                return result

            except Exception as e:
                # Track error event
                params = OlakaiEventParams(
                    prompt=str(args) + str(kwargs),
                    response=f"Error: {str(e)}",
                    userEmail=options.get("userEmail", "anonymous@olakai.ai"),
                    sessionId=options.get("sessionId"),
                    task=options.get("task"),
                    subTask=options.get("subTask"),
                    customData=options.get("customData"),
                    shouldScore=options.get("shouldScore", True),
                    tokens=0,
                    requestTime=int(time.time() * 1000 - start_time),
                )

                olakai(params)
                raise

        # Return appropriate wrapper based on function type
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    # Handle both @olakai_monitor and @olakai_monitor(options) usage
    if fn is None:
        return decorator
    else:
        return decorator(fn)


