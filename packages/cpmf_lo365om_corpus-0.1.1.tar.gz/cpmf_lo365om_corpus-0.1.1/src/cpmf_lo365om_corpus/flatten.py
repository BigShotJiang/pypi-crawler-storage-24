"""Flatten a corpus.json manifest into a table suitable for UiPath test data import.

Adapter pattern:
    flatten_manifest(manifest) -> list[dict]   # format-agnostic row extraction
    FlattenAdapter.write(rows, path)           # abstract base
    XlsxAdapter                                # openpyxl — all cells as String
    JsonAdapter                                # stdlib json — counts as int
"""

import json
from abc import ABC, abstractmethod
from pathlib import Path

from openpyxl import Workbook

# ── Row extraction ────────────────────────────────────────────────────────────

def flatten_manifest(manifest: dict) -> list[dict]:
    """Return one dict per message with in_-prefixed keys.

    Keys produced:
        in_label                  — fixture label
        in_immutableId            — Graph ImmutableId
        in_subject                — resolved subject string
        in_sourceFolder           — folder path where message was created
        in_separator              — body separator declared in scenario
        in_expected_values        — JSON string of expected extracted values dict
        in_expected_unmatchedCount — number of expected unmatched source fields
        in_expected_missingCount   — number of expected missing required keys
    """
    rows = []
    for label, msg in manifest.get("messages", {}).items():
        body     = msg.get("body", {}) or {}
        expected = msg.get("expected", {}) or {}
        be       = expected.get("bodyExtraction", {}) or {}

        rows.append({
            "in_label":                   label,
            "in_immutableId":             msg.get("immutableId", ""),
            "in_subject":                 msg.get("subject", ""),
            "in_sourceFolder":            msg.get("sourceFolder", ""),
            "in_separator":               body.get("separator", ": "),
            "in_expected_values":         json.dumps(be.get("values", {}), ensure_ascii=False),
            "in_expected_unmatchedCount": len(be.get("unmatchedFields", [])),
            "in_expected_missingCount":   len(be.get("missingRequiredKeys", [])),
        })
    return rows


# ── Adapters ─────────────────────────────────────────────────────────────────

class FlattenAdapter(ABC):
    @abstractmethod
    def write(self, rows: list[dict], path: Path) -> None: ...


class XlsxAdapter(FlattenAdapter):
    """Write a flat xlsx file.

    All cell values are written as strings — UiPath reads xlsx columns as
    String and casts to the target type in the XAML workflow.
    """

    def write(self, rows: list[dict], path: Path) -> None:
        if not rows:
            raise ValueError("No rows to write — manifest may be empty.")

        wb = Workbook()
        ws = wb.active
        ws.title = "TestData"

        headers = list(rows[0].keys())
        ws.append(headers)

        for row in rows:
            ws.append([str(row[h]) for h in headers])

        path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(path)


class JsonAdapter(FlattenAdapter):
    """Write a JSON array.

    String values stay as strings; count fields are written as int.
    """

    def write(self, rows: list[dict], path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")


# ── Adapter registry ──────────────────────────────────────────────────────────

_ADAPTERS: dict[str, type[FlattenAdapter]] = {
    "xlsx": XlsxAdapter,
    "json": JsonAdapter,
}


def get_adapter(fmt: str) -> FlattenAdapter:
    """Return an adapter instance for the given format name."""
    try:
        return _ADAPTERS[fmt.lower()]()
    except KeyError:
        available = ", ".join(sorted(_ADAPTERS))
        raise ValueError(f"Unknown format {fmt!r}. Available: {available}")


def detect_format(path: Path) -> str:
    """Infer format from file extension. Raises ValueError if not recognised."""
    ext = path.suffix.lower().lstrip(".")
    if ext in _ADAPTERS:
        return ext
    available = ", ".join(f".{k}" for k in sorted(_ADAPTERS))
    raise ValueError(f"Cannot detect format from extension {path.suffix!r}. "
                     f"Use --format or choose an output file with extension: {available}")
