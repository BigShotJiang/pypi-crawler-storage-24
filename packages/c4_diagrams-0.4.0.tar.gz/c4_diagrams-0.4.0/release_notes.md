## 0.4.0 (2026-03-22)

### Feat

- **cli**: add json-to-python converters CLI
- **converters**: add json-to-python converters
- **renderers**: replace layout options with render options
- **core**: add constraints for diagram types

