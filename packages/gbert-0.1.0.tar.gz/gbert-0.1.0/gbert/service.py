from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
from typing import Any, Sequence
import warnings

import joblib
import pandas as pd

from .modeling_causal_interpretable import CausalInterpretableForSequenceClassification


MODEL_COUNTRY_TO_WB = {
    "Bosnia-Herzegovina": "Bosnia and Herzegovina",
    "Czech Republic": "Czechia",
    "Russia": "Russian Federation",
    "Slovakia": "Slovak Republic",
    "South Korea": "Korea, Rep.",
    "Turkey": "Turkiye",
}

WB_COUNTRY_TO_MODEL = {value: key for key, value in MODEL_COUNTRY_TO_WB.items()}

PACKAGE_DIR = Path(__file__).resolve().parent

MACRO_SOURCES = {
    "battle_value": "add/battle/API_VC.BTL.DETH_DS2_en_csv_v2_9816.csv",
    "gdp_value": "add/gdp/API_NY.GDP.MKTP.KD.ZG_DS2_en_csv_v2_2509.csv",
    "trade_value": "add/trade/API_NE.TRD.GNFS.ZS_DS2_en_csv_v2_2650.csv",
    "debt_value": "add/debt/API_GC.DOD.TOTL.GD.ZS_DS2_en_csv_v2_2484.csv",
    "inflation_value": "add/inflation/API_FP.CPI.TOTL.ZG_DS2_en_csv_v2_2479.csv",
    "unemployment_value": "add/unemployment/API_SL.UEM.TOTL.ZS_DS2_en_csv_v2_2821.csv",
}


@dataclass(frozen=True)
class MacroLookupResult:
    country: str
    year: int
    raw_values: dict[str, float]
    standardized_values: list[float]
    raw_sources: dict[str, str]


def _normalize_state_dict_keys(state_dict: dict[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in state_dict.items():
        new_key = key
        if new_key.startswith("module."):
            new_key = new_key[len("module."):]
        if new_key.startswith("bert."):
            new_key = "text_encoder." + new_key[len("bert."):]
        if new_key == "ctx_to_bert.weight":
            new_key = "ctx_to_text.weight"
        elif new_key == "ctx_to_bert.bias":
            new_key = "ctx_to_text.bias"
        normalized[new_key] = value
    return normalized


def _as_list(value: Any, size: int, *, name: str) -> list[Any]:
    if isinstance(value, (str, bytes)):
        return [value] * size
    if isinstance(value, Sequence):
        items = list(value)
        if len(items) != size:
            raise ValueError(f"{name} must have the same length as texts.")
        return items
    return [value] * size


class GbertClassifier:
    def __init__(
        self,
        *,
        base_dir: str | Path | None = None,
        model_path: str | Path | None = None,
        model_repo_id: str | None = None,
        model_filename: str | None = None,
        hf_token: str | None = None,
        text_model_name_or_path: str | None = None,
        device: str | None = None,
        batch_size: int = 16,
        max_length: int = 128,
        torch_num_threads: int | None = None,
    ) -> None:
        self.base_dir = Path(base_dir or PACKAGE_DIR).resolve()
        self.meta_path = self.base_dir / "preprocess_meta.joblib"
        self.model_path = self._resolve_model_path(model_path)
        self.model_repo_id = (
            model_repo_id
            or os.environ.get("GBERT_MODEL_REPO_ID")
            or os.environ.get("MODEL_REPO_ID")
            or ""
        ).strip()
        self.model_filename = (
            model_filename
            or os.environ.get("GBERT_MODEL_FILENAME")
            or os.environ.get("MODEL_FILENAME")
            or "causal_nam_best.pt"
        ).strip()
        self.hf_token = (
            hf_token
            or os.environ.get("HF_TOKEN")
            or os.environ.get("HUGGING_FACE_HUB_TOKEN")
            or None
        )
        self.text_model_name_or_path = (
            text_model_name_or_path
            or os.environ.get("TEXT_MODEL_NAME_OR_PATH")
            or "bert-base-multilingual-cased"
        ).strip()
        self.device_name = device
        self.batch_size = max(1, int(batch_size))
        self.max_length = max(8, int(max_length))
        self.torch_num_threads = int(
            torch_num_threads
            or os.environ.get("TORCH_NUM_THREADS")
            or 1
        )

        self.meta = self._load_meta()
        self.country_classes = [str(v) for v in self.meta["country_le"].classes_]
        self.year_classes = sorted(int(v) for v in self.meta["year_le"].classes_)
        self.label_classes = [str(v) for v in self.meta["cat_le"].classes_]
        self.macro_cols = list(self.meta["macro_cols"])
        self.macro_means = {
            key: float(value) for key, value in self.meta["macro_means"].to_dict().items()
        }
        self.macro_stds = {
            key: float(value) if float(value) != 0 else 1.0
            for key, value in self.meta["macro_stds"].to_dict().items()
        }
        self.macro_frame = self._load_macro_frame()
        self.model_year_min = min(self.year_classes)
        self.model_year_max = max(self.year_classes)
        self.supported_years = self._build_supported_years()
        self.available_years = self._build_available_years()

        self._torch = None
        self._tokenizer = None
        self._model = None
        self._device = None

        self._load_runtime()

    def _resolve_model_path(self, model_path: str | Path | None) -> Path:
        configured = (
            str(model_path)
            if model_path is not None
            else (
                os.environ.get("GBERT_MODEL_PATH")
                or os.environ.get("MODEL_PATH")
                or ""
            )
        ).strip()
        if configured:
            path = Path(configured)
            if not path.is_absolute():
                path = self.base_dir / path
            return path.resolve()
        return (self.base_dir / "causal_nam_best.pt").resolve()

    def _load_meta(self) -> dict[str, Any]:
        warnings.filterwarnings(
            "ignore",
            message="Trying to unpickle estimator LabelEncoder",
        )
        return joblib.load(self.meta_path)

    def _load_world_bank_csv(self, macro_name: str, relative_path: str) -> pd.DataFrame:
        csv_path = self.base_dir / relative_path
        df = pd.read_csv(csv_path, skiprows=4)
        year_cols = [col for col in df.columns if str(col).isdigit()]
        df = df[["Country Name", *year_cols]].copy()
        df["Country Name"] = df["Country Name"].replace(WB_COUNTRY_TO_MODEL)

        long_df = df.melt(
            id_vars="Country Name",
            value_vars=year_cols,
            var_name="year",
            value_name=macro_name,
        )
        long_df = long_df.rename(columns={"Country Name": "country"})
        long_df["year"] = long_df["year"].astype(int)
        long_df[macro_name] = pd.to_numeric(long_df[macro_name], errors="coerce")
        long_df = long_df[long_df["country"].isin(self.country_classes)].copy()
        return long_df

    def _load_macro_frame(self) -> pd.DataFrame:
        merged: pd.DataFrame | None = None
        for macro_name, relative_path in MACRO_SOURCES.items():
            macro_df = self._load_world_bank_csv(macro_name, relative_path)
            if merged is None:
                merged = macro_df
            else:
                merged = merged.merge(macro_df, on=["country", "year"], how="outer")

        if merged is None:
            raise RuntimeError("No macro data loaded from add directory.")
        return merged.sort_values(["country", "year"]).reset_index(drop=True)

    def _build_supported_years(self) -> list[int]:
        macro_years = sorted(int(v) for v in self.macro_frame["year"].dropna().astype(int).unique())
        return [year for year in macro_years if year >= self.model_year_min]

    def _build_available_years(self) -> dict[str, list[int]]:
        valid_years = set(self.supported_years)
        by_country: dict[str, list[int]] = {}
        for country in self.country_classes:
            country_df = self.macro_frame[self.macro_frame["country"] == country]
            years = sorted(
                int(y) for y in country_df["year"].dropna().astype(int).unique() if int(y) in valid_years
            )
            by_country[country] = years
        return by_country

    def _load_runtime(self) -> None:
        os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

        import torch
        from huggingface_hub import hf_hub_download
        from transformers import AutoTokenizer

        torch.set_num_threads(self.torch_num_threads)
        if hasattr(torch, "set_num_interop_threads"):
            torch.set_num_interop_threads(1)

        model_path = self.model_path
        if not model_path.exists():
            if not self.model_repo_id:
                raise FileNotFoundError(
                    "Model weights were not found. Set `model_path` or `GBERT_MODEL_PATH`, "
                    "or provide `model_repo_id` / `GBERT_MODEL_REPO_ID` for Hugging Face Hub."
                )
            model_path = Path(
                hf_hub_download(
                    repo_id=self.model_repo_id,
                    filename=self.model_filename,
                    token=self.hf_token,
                )
            )

        device_name = self.device_name
        if not device_name or device_name == "auto":
            device_name = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device_name)

        model = CausalInterpretableForSequenceClassification.from_text_pretrained(
            self.text_model_name_or_path,
            num_labels=len(self.label_classes),
            num_macro=len(self.macro_cols),
            num_countries=len(self.country_classes),
            num_years=len(self.year_classes),
            text_pretrained_kwargs={"low_cpu_mem_usage": True},
        ).to(device)

        load_kwargs: dict[str, Any] = {"map_location": device}
        if "weights_only" in torch.load.__code__.co_varnames:
            load_kwargs["weights_only"] = True
        if "mmap" in torch.load.__code__.co_varnames:
            load_kwargs["mmap"] = True
        state_dict = torch.load(model_path, **load_kwargs)
        if isinstance(state_dict, dict) and "state_dict" in state_dict and isinstance(state_dict["state_dict"], dict):
            state_dict = state_dict["state_dict"]
        state_dict = _normalize_state_dict_keys(state_dict)
        model.load_state_dict(state_dict)
        model.eval()
        model.requires_grad_(False)

        self._torch = torch
        self._tokenizer = AutoTokenizer.from_pretrained(self.text_model_name_or_path)
        self._model = model
        self._device = device
        self.model_path = model_path.resolve()

    def _validate_country(self, country: str) -> None:
        if country not in self.country_classes:
            raise ValueError(f"Unsupported country: {country}")

    def _validate_year(self, year: int) -> None:
        if year not in self.supported_years:
            raise ValueError(f"Unsupported year: {year}")

    def _encode_year(self, year: int) -> int:
        encoded_year = min(int(year), self.model_year_max)
        return int(self.meta["year_le"].transform([encoded_year])[0])

    def get_macro_values(self, country: str, year: int) -> MacroLookupResult:
        self._validate_country(country)
        self._validate_year(year)

        row = self.macro_frame[
            (self.macro_frame["country"] == country) & (self.macro_frame["year"] == year)
        ]

        raw_values: dict[str, float] = {}
        raw_sources: dict[str, str] = {}
        if row.empty:
            for macro_name in self.macro_cols:
                raw_values[macro_name] = 0.0
                raw_sources[macro_name] = "missing-year-filled-zero"
        else:
            row_data = row.iloc[0]
            for macro_name in self.macro_cols:
                value = row_data.get(macro_name)
                if pd.isna(value):
                    raw_values[macro_name] = 0.0
                    raw_sources[macro_name] = "dataset-missing-filled-zero"
                else:
                    raw_values[macro_name] = float(value)
                    raw_sources[macro_name] = "dataset"

        standardized_values = [
            (raw_values[macro_name] - self.macro_means[macro_name]) / self.macro_stds[macro_name]
            for macro_name in self.macro_cols
        ]
        return MacroLookupResult(
            country=country,
            year=int(year),
            raw_values=raw_values,
            standardized_values=standardized_values,
            raw_sources=raw_sources,
        )

    def _predict_batch_internal(
        self,
        texts: Sequence[str],
        countries: Sequence[str],
        years: Sequence[int],
        *,
        top_k: int,
        batch_size: int,
    ) -> list[dict[str, Any]]:
        torch = self._torch
        tokenizer = self._tokenizer
        model = self._model
        device = self._device

        prepared_rows: list[dict[str, Any]] = []
        for text, country, year in zip(texts, countries, years):
            normalized_text = (text or "").strip()
            if not normalized_text:
                raise ValueError("Text is required.")
            self._validate_country(country)
            self._validate_year(int(year))
            macro_lookup = self.get_macro_values(country, int(year))
            prepared_rows.append(
                {
                    "text": normalized_text,
                    "country": country,
                    "year": int(year),
                    "country_id": int(self.meta["country_le"].transform([country])[0]),
                    "year_id": self._encode_year(int(year)),
                    "macro_lookup": macro_lookup,
                }
            )

        outputs: list[dict[str, Any]] = []
        top_k = max(1, min(int(top_k), len(self.label_classes)))
        batch_size = max(1, int(batch_size))

        for start in range(0, len(prepared_rows), batch_size):
            chunk = prepared_rows[start:start + batch_size]
            encoded = tokenizer(
                [item["text"] for item in chunk],
                truncation=True,
                max_length=self.max_length,
                padding=True,
                return_tensors="pt",
            )

            macro_tensor = torch.tensor(
                [item["macro_lookup"].standardized_values for item in chunk],
                dtype=torch.float32,
                device=device,
            )
            country_tensor = torch.tensor(
                [item["country_id"] for item in chunk],
                dtype=torch.long,
                device=device,
            )
            year_tensor = torch.tensor(
                [item["year_id"] for item in chunk],
                dtype=torch.long,
                device=device,
            )

            with torch.inference_mode():
                logits = model(
                    input_ids=encoded["input_ids"].to(device),
                    attention_mask=encoded["attention_mask"].to(device),
                    macro=macro_tensor,
                    country_id=country_tensor,
                    year_id=year_tensor,
                ).logits
                probs = torch.softmax(logits, dim=-1).detach().cpu().numpy()

            for item, item_probs in zip(chunk, probs):
                ranked_indices = item_probs.argsort()[::-1][:top_k]
                predictions = [
                    {
                        "rank": rank + 1,
                        "label": str(self.label_classes[idx]),
                        "probability": float(item_probs[idx]),
                    }
                    for rank, idx in enumerate(ranked_indices)
                ]
                macro_payload = {
                    macro_name: {
                        "raw": item["macro_lookup"].raw_values[macro_name],
                        "standardized": item["macro_lookup"].standardized_values[i],
                        "source": item["macro_lookup"].raw_sources[macro_name],
                    }
                    for i, macro_name in enumerate(self.macro_cols)
                }
                outputs.append(
                    {
                        "text": item["text"],
                        "country": item["country"],
                        "year": item["year"],
                        "predictions": predictions,
                        "macro_values": macro_payload,
                    }
                )
        return outputs

    def list_countries(self) -> list[str]:
        return [country for country in self.country_classes if self.available_years.get(country)]

    def list_years(self, country: str) -> list[int]:
        self._validate_country(country)
        years = self.available_years.get(country, [])
        if not years:
            raise ValueError(f"{country} has no supported years in add data.")
        return years

    def runtime_info(self) -> dict[str, Any]:
        return {
            "model_path": str(self.model_path),
            "model_repo_id": self.model_repo_id or None,
            "model_filename": self.model_filename,
            "text_model_name_or_path": self.text_model_name_or_path,
            "device": str(self._device),
            "torch_num_threads": self.torch_num_threads,
            "batch_size": self.batch_size,
            "max_length": self.max_length,
        }

    def predict(
        self,
        text: str,
        country: str,
        year: int,
        *,
        top_k: int = 5,
    ) -> dict[str, Any]:
        return self._predict_batch_internal(
            texts=[text],
            countries=[country],
            years=[int(year)],
            top_k=top_k,
            batch_size=1,
        )[0]

    def predict_batch(
        self,
        texts: Sequence[str],
        country: str | Sequence[str],
        year: int | Sequence[int],
        *,
        top_k: int = 5,
        batch_size: int | None = None,
        return_df: bool = False,
    ) -> list[dict[str, Any]] | pd.DataFrame:
        if isinstance(texts, (str, bytes)):
            raise TypeError("texts must be a sequence of strings, not a single string.")

        texts = list(texts)
        if not texts:
            return pd.DataFrame() if return_df else []

        countries = [str(item) for item in _as_list(country, len(texts), name="country")]
        years = [int(item) for item in _as_list(year, len(texts), name="year")]
        results = self._predict_batch_internal(
            texts=texts,
            countries=countries,
            years=years,
            top_k=top_k,
            batch_size=batch_size or self.batch_size,
        )
        if not return_df:
            return results

        flat_rows: list[dict[str, Any]] = []
        for result in results:
            best_prediction = result["predictions"][0]
            flat_rows.append(
                {
                    "text": result["text"],
                    "country": result["country"],
                    "year": result["year"],
                    "label": best_prediction["label"],
                    "probability": best_prediction["probability"],
                    "predictions": result["predictions"],
                }
            )
        return pd.DataFrame(flat_rows)


def load_default_model(**kwargs: Any) -> GbertClassifier:
    return GbertClassifier(**kwargs)


def predict(
    text: str,
    country: str,
    year: int,
    *,
    top_k: int = 5,
    model: GbertClassifier | None = None,
    **model_kwargs: Any,
) -> dict[str, Any]:
    classifier = model or GbertClassifier(**model_kwargs)
    return classifier.predict(text=text, country=country, year=year, top_k=top_k)


def predict_batch(
    texts: Sequence[str],
    country: str | Sequence[str],
    year: int | Sequence[int],
    *,
    top_k: int = 5,
    batch_size: int | None = None,
    return_df: bool = False,
    model: GbertClassifier | None = None,
    **model_kwargs: Any,
) -> list[dict[str, Any]] | pd.DataFrame:
    classifier = model or GbertClassifier(**model_kwargs)
    return classifier.predict_batch(
        texts=texts,
        country=country,
        year=year,
        top_k=top_k,
        batch_size=batch_size,
        return_df=return_df,
    )
