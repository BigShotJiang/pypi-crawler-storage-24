# gbert

`gbert` 是一个尽量简单的多语言文本分析包，适合：

- Kaggle Notebook
- 单条文本快速预测
- 大批量文本批处理

它默认不包含网页、Flask 或服务端代码，只保留推理必需内容。

## 安装

```bash
pip install gbert
```

如果你在 Kaggle 里使用，推荐先安装再直接在 Notebook 里跑：

```python
!pip -q install gbert
```

## 最简单用法

```python
from gbert import GbertClassifier

model = GbertClassifier(
    model_repo_id="your-hf-model-repo",
    hf_token="your_hf_token_if_needed",
)

result = model.predict(
    "The government will expand industrial policy and labour training.",
    country="Japan",
    year=2026,
)

result["predictions"][:3]
```

## 批量分析

```python
from gbert import GbertClassifier

model = GbertClassifier(model_repo_id="your-hf-model-repo")

results = model.predict_batch(
    texts=[
        "We will invest in industry.",
        "Healthcare access must improve.",
        "Tax reform should support growth.",
    ],
    country="Japan",
    year=2026,
    batch_size=16,
)
```

如果你更喜欢 `pandas.DataFrame`：

```python
df = model.predict_batch(
    texts=["text a", "text b"],
    country=["Japan", "Germany"],
    year=[2026, 2024],
    return_df=True,
)
```

## API

### `GbertClassifier`

常用参数：

- `model_path`: 本地模型权重路径
- `model_repo_id`: Hugging Face Hub 模型仓库
- `model_filename`: 默认是 `causal_nam_best.pt`
- `hf_token`: 私有仓库时可传
- `device`: `cpu` / `cuda` / 自动检测
- `batch_size`: 批量推理默认 batch 大小

### 方法

- `predict(text, country, year, top_k=5)`
- `predict_batch(texts, country, year, top_k=5, batch_size=None, return_df=False)`
- `list_countries()`
- `list_years(country)`
- `runtime_info()`

## 设计目标

- Notebook first
- Kaggle friendly
- 单次加载，多次复用
- 单条和批量接口统一

## 模型说明

这个包会打包：

- `preprocess_meta.joblib`
- `add/` 下的宏观变量 CSV

它不会打包大模型权重文件。运行时会按以下顺序寻找模型：

1. 你显式传入的 `model_path`
2. 环境变量 `GBERT_MODEL_PATH`
3. 包目录下的 `causal_nam_best.pt`
4. Hugging Face Hub (`model_repo_id`)

如果你想通过环境变量控制，也支持：

- `GBERT_MODEL_PATH`
- `GBERT_MODEL_REPO_ID`
- `GBERT_MODEL_FILENAME`
- `HF_TOKEN`
- `TEXT_MODEL_NAME_OR_PATH`
- `TORCH_NUM_THREADS`

## 命令行

```bash
gbert --text "Industrial policy matters." --country Japan --year 2026
```

## 备注

- 当前宏观数据可支持到 `2026`
- 对超出训练年份的输入，年份 embedding 会自动回退到模型训练期的最后一年
- 批量分析建议复用同一个 `GbertClassifier` 实例，不要每条文本重新初始化模型
