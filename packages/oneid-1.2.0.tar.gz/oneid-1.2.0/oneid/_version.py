"""Version string for the oneid-sdk package."""

__version__ = "1.2.0"
USER_AGENT = f"oneid-sdk-python/{__version__}"
