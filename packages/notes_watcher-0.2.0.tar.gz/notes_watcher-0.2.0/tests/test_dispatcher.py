"""Tests for the agent dispatcher."""

import json

import pytest

from note_watcher.config import AgentConfig, Config
from note_watcher.dispatcher import AgentDispatcher, UnknownAgentError
from note_watcher.parser import Instruction


@pytest.fixture
def config(tmp_path) -> Config:
    return Config(
        vault=tmp_path,
        agents={
            "echo_agent": AgentConfig(name="echo_agent", type="echo"),
            "upper_agent": AgentConfig(name="upper_agent", type="uppercase"),
        },
    )


@pytest.fixture
def dispatcher(config: Config) -> AgentDispatcher:
    return AgentDispatcher(config)


def _make_instruction(agent_name: str, text: str = "Test text") -> Instruction:
    return Instruction(
        agent_name=agent_name,
        instruction_text=text,
        line_number=1,
        original_text=f"@{agent_name} {text}",
    )


class TestAgentDispatcher:
    """Tests for AgentDispatcher."""

    def test_echo_agent_returns_text(self, dispatcher: AgentDispatcher) -> None:
        instruction = _make_instruction("echo_agent", "Hello world")
        result = dispatcher.dispatch(instruction)
        assert result == "Hello world"

    def test_uppercase_agent_returns_uppercased(self, dispatcher: AgentDispatcher) -> None:
        instruction = _make_instruction("upper_agent", "make me big")
        result = dispatcher.dispatch(instruction)
        assert result == "MAKE ME BIG"

    def test_unknown_agent_raises_error(self, dispatcher: AgentDispatcher) -> None:
        instruction = _make_instruction("nonexistent")
        with pytest.raises(UnknownAgentError) as exc_info:
            dispatcher.dispatch(instruction)
        assert "nonexistent" in str(exc_info.value)

    def test_unknown_agent_error_has_name(self) -> None:
        err = UnknownAgentError("test_agent")
        assert err.agent_name == "test_agent"

    def test_echo_preserves_special_characters(self, dispatcher: AgentDispatcher) -> None:
        text = "Hello! @world #test $100"
        instruction = _make_instruction("echo_agent", text)
        result = dispatcher.dispatch(instruction)
        assert result == text

    def test_uppercase_handles_empty_instruction(self, dispatcher: AgentDispatcher) -> None:
        """Uppercase agent with minimal text."""
        instruction = _make_instruction("upper_agent", "a")
        result = dispatcher.dispatch(instruction)
        assert result == "A"

    def test_command_agent(self, tmp_path) -> None:
        """Test command agent type."""
        config = Config(
            vault=tmp_path,
            agents={
                "cat_agent": AgentConfig(name="cat_agent", type="command", command="cat"),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("cat_agent", "hello from command")
        result = dispatcher.dispatch(instruction)
        assert result == "hello from command"

    def test_unsupported_agent_type_raises(self, tmp_path) -> None:
        """An agent with an unrecognized type should raise."""
        config = Config(
            vault=tmp_path,
            agents={
                "bad_agent": AgentConfig(name="bad_agent", type="teleport"),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("bad_agent")
        with pytest.raises(UnknownAgentError):
            dispatcher.dispatch(instruction)


class TestCommandAgentEnvVars:
    """Tests for environment variables passed to command agents."""

    def test_command_receives_file_path_env(self, tmp_path) -> None:
        """Command agent receives NOTE_WATCHER_FILE_PATH env var."""
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_FILE_PATH",
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == "/tmp/notes/test.md"

    def test_command_receives_vault_path_env(self, tmp_path) -> None:
        """Command agent receives NOTE_WATCHER_VAULT_PATH env var."""
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_VAULT_PATH",
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == str(tmp_path)

    def test_command_receives_system_prompt_env(self, tmp_path) -> None:
        """Command agent receives NOTE_WATCHER_SYSTEM_PROMPT env var."""
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_SYSTEM_PROMPT",
                    system_prompt="You are helpful.",
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == "You are helpful."

    def test_system_prompt_interpolates_vault_path(self, tmp_path) -> None:
        """System prompt template variables are interpolated."""
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_SYSTEM_PROMPT",
                    system_prompt="Vault: {vault_path}",
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == f"Vault: {tmp_path}"

    def test_system_prompt_interpolates_file_path(self, tmp_path) -> None:
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_SYSTEM_PROMPT",
                    system_prompt="File: {file_path}",
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == "File: /tmp/notes/test.md"

    def test_system_prompt_file_loaded(self, tmp_path) -> None:
        """System prompt loaded from file relative to config_dir."""
        prompt_file = tmp_path / "prompts" / "test.md"
        prompt_file.parent.mkdir(parents=True)
        prompt_file.write_text("Prompt from file: {vault_path}")

        config = Config(
            vault=tmp_path,
            config_dir=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_SYSTEM_PROMPT",
                    system_prompt_file="prompts/test.md",
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == f"Prompt from file: {tmp_path}"

    def test_system_prompt_with_curly_braces_not_crashed(self, tmp_path) -> None:
        """System prompt containing curly braces (e.g. JSON) should not crash."""
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command="printenv NOTE_WATCHER_SYSTEM_PROMPT",
                    system_prompt='Use JSON like {"key": "value"} in responses.',
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        assert result == 'Use JSON like {"key": "value"} in responses.'

    def test_no_system_prompt_env_when_not_configured(self, tmp_path) -> None:
        """No NOTE_WATCHER_SYSTEM_PROMPT env var when system_prompt not set."""
        # Use a command that prints all env vars as JSON so we can check absence
        config = Config(
            vault=tmp_path,
            agents={
                "env_agent": AgentConfig(
                    name="env_agent",
                    type="command",
                    command=(
                        "python3 -c \"import os, json;"
                        " print(json.dumps(dict(os.environ)))\""
                    ),
                ),
            },
        )
        dispatcher = AgentDispatcher(config)
        instruction = _make_instruction("env_agent")
        result = dispatcher.dispatch(instruction, file_path="/tmp/notes/test.md")
        env = json.loads(result)
        assert "NOTE_WATCHER_SYSTEM_PROMPT" not in env
        assert env["NOTE_WATCHER_FILE_PATH"] == "/tmp/notes/test.md"
