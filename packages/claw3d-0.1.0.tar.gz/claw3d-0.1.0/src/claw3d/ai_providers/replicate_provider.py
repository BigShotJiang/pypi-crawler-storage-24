"""Replicate provider — stub for future implementation.

Coming soon. Replicate offers 3D generation models; this provider will support
them once implemented. The interface matches AIProvider for drop-in replacement.
"""

from pathlib import Path
from typing import Optional

from .base import AIProvider, ImageToImageRequest, ImageToImageResult, ImageResult


COMING_SOON_MSG = (
    "Replicate provider is coming soon. Use FAL.ai for now: set FAL_API_KEY and "
    "run `claw3d configure` to select FAL, or set CLAW3D_PROVIDER=fal."
)


class ReplicateProvider(AIProvider):
    """Replicate.com implementation — coming soon."""

    def __init__(self, api_key: Optional[str] = None):
        self._key = api_key

    @property
    def provider_id(self) -> str:
        return "replicate"

    def upload_file(self, path: Path) -> str:
        raise NotImplementedError(COMING_SOON_MSG)

    def image_to_image(
        self,
        request: ImageToImageRequest,
        model_id: Optional[str] = None,
    ) -> ImageToImageResult:
        raise NotImplementedError(COMING_SOON_MSG)

    def text_to_image(self, prompt: str, model_id: Optional[str] = None) -> ImageResult:
        raise NotImplementedError(COMING_SOON_MSG)

    def image_to_3d(self, image_url: str, model_id: Optional[str] = None) -> bytes:
        raise NotImplementedError(COMING_SOON_MSG)

    def multiview_to_3d(
        self,
        front_url: str,
        back_url: str,
        left_url: str,
        model_id: Optional[str] = None,
    ) -> bytes:
        raise NotImplementedError(COMING_SOON_MSG)
