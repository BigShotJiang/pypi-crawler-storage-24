"""Edit 3D — render views from GLB for 3d-to-3d pipeline.

Fixed camera + model rotation (validated vs Hunyuan expectations):
- Camera at 15° elevation (on sphere, from -Z axis), looking at center
- Model rotations: front=105°, back=285°, left=195° (left is 180° from front)
- Orthographic projection
- Front/Back/Left views (Hunyuan skips Right)
- 1024x1024 per view, black background
"""

import io
import math
import os
from pathlib import Path
from typing import Tuple

import numpy as np
import trimesh

# Front/back/left model Y-rotations (degrees): front=105°, back=285°, left=195° (180° from front)
VIEWS = [("front", 105), ("back", 285), ("left", 195)]
VIEW_RESOLUTION = 1024
ELEVATION_DEG = 15.0
ORTHO_SCALE_FACTOR = 1.2
EDIT_WHITE_ROUGHNESS = 0.7
EDIT_WHITE_METALNESS = 0.0


def _look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
    """4x4 camera-to-world matrix: camera at eye looking at target."""
    fwd = target - eye
    fwd = fwd / (np.linalg.norm(fwd) + 1e-8)
    right = np.cross(up, fwd)
    right = right / (np.linalg.norm(right) + 1e-8)
    up_w = np.cross(fwd, right)
    m = np.eye(4)
    m[:3, 0] = right
    m[:3, 1] = up_w
    m[:3, 2] = -fwd
    m[:3, 3] = eye
    return m


def _light_pose_from_direction(dx: float, dy: float, dz: float, distance: float) -> np.ndarray:
    """Pose for directional light at distance along (dx,dy,dz), shining toward origin."""
    d = np.array([dx, dy, dz], dtype=float)
    d = d / (np.linalg.norm(d) + 1e-8)
    return _look_at(d * distance, np.zeros(3), np.array([0.0, 1.0, 0.0]))


def _rotation_y(angle_deg: float) -> np.ndarray:
    """4x4 rotation matrix around Y axis (vertical). Angle in degrees."""
    a = math.radians(angle_deg)
    c, s = math.cos(a), math.sin(a)
    m = np.eye(4)
    m[0, 0] = c
    m[0, 2] = s
    m[2, 0] = -s
    m[2, 2] = c
    return m


def _load_mesh(glb_path: Path) -> trimesh.Trimesh:
    """Load GLB as single trimesh, centered."""
    mesh = trimesh.load(glb_path, file_type="glb", force="mesh")
    if hasattr(mesh, "geometry"):
        mesh = trimesh.util.concatenate(
            [m for m in mesh.geometry.values() if isinstance(m, trimesh.Trimesh)]
        )
    if not isinstance(mesh, trimesh.Trimesh):
        raise ValueError("Could not load mesh from GLB")
    mesh.vertices -= mesh.centroid
    return mesh


def _render_views_pyrender(mesh: trimesh.Trimesh) -> dict[str, bytes]:
    """Render front, back, left: camera at 15° elevation from -Z, model rotates."""
    import pyrender
    from PIL import Image

    try:
        import numpy as _np
        if not hasattr(_np, "infty"):
            _np.infty = _np.inf  # type: ignore[attr-defined]
    except Exception:
        pass

    bounds = mesh.bounds
    extents = bounds[1] - bounds[0]
    # Use diagonal of bounding box so tall/rotated models stay fully framed in all views
    diagonal = float(np.linalg.norm(extents))
    if diagonal < 0.01:
        diagonal = 1.0

    ortho_half = (diagonal / 2) * ORTHO_SCALE_FACTOR
    distance = diagonal * 2.0
    dist = diagonal * 2.5

    white_material = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=np.array([1.0, 1.0, 1.0, 1.0], dtype=np.float32),
        metallicFactor=EDIT_WHITE_METALNESS,
        roughnessFactor=EDIT_WHITE_ROUGHNESS,
        alphaMode="OPAQUE",
        doubleSided=True,
    )
    if mesh.visual is not None:
        nv, nf = len(mesh.vertices), len(mesh.faces)
        w = np.array([255, 255, 255, 255], dtype=np.uint8)
        if hasattr(mesh.visual, "vertex_colors") and mesh.visual.vertex_colors is not None:
            mesh.visual.vertex_colors = np.tile(w, (nv, 1))
        if hasattr(mesh.visual, "face_colors") and mesh.visual.face_colors is not None:
            mesh.visual.face_colors = np.tile(w, (nf, 1))
    mesh_pr = pyrender.Mesh.from_trimesh(mesh, material=white_material)

    # Camera at 15° elevation: from -Z axis, lift toward +Y. Unit pos = (0, sin(15°), -cos(15°))
    el_rad = math.radians(ELEVATION_DEG)
    camera_pos = (0.0, math.sin(el_rad), -math.cos(el_rad))
    eye = np.array(camera_pos, dtype=float) * distance
    center = np.zeros(3)
    up = np.array([0.0, 1.0, 0.0])
    cam_pose = _look_at(eye, center, up)

    try:
        renderer = pyrender.OffscreenRenderer(VIEW_RESOLUTION, VIEW_RESOLUTION)
    except Exception as e:
        raise RuntimeError(
            f"OffscreenRenderer failed: {e}. On headless: use xvfb-run claw3d convert ... or apt install xvfb xauth."
        ) from e

    rendered = {}
    try:
        for view_name, model_rotation_deg in VIEWS:
            view_scene = pyrender.Scene(
                ambient_light=np.array([0.4, 0.4, 0.4]),
                bg_color=np.array([0.0, 0.0, 0.0]),
            )
            mesh_pose = _rotation_y(model_rotation_deg)
            view_scene.add(mesh_pr, pose=mesh_pose)
            for (dx, dy, dz), intensity in [
                ((5, 5, 5), 1.5),
                ((-5, 3, -5), 0.8),
                ((0, 5, -5), 1.2),
            ]:
                light_pose = _light_pose_from_direction(dx, dy, dz, dist)
                view_scene.add(
                    pyrender.DirectionalLight(color=np.ones(3), intensity=intensity),
                    pose=light_pose,
                )
            camera = pyrender.OrthographicCamera(
                xmag=ortho_half,
                ymag=ortho_half,
                znear=0.01,
                zfar=diagonal * 20,
            )
            view_scene.add(camera, pose=cam_pose)
            color, _ = renderer.render(view_scene)
            img = Image.fromarray(color[:, :, :3])
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            rendered[view_name] = buf.getvalue()
    finally:
        renderer.delete()

    return rendered


def render_views_from_glb(glb_path: Path) -> dict[str, bytes]:
    """Render front, back, left views from GLB. Returns {front, back, left} PNG bytes."""
    mesh = _load_mesh(glb_path)

    if not os.environ.get("DISPLAY"):
        raise RuntimeError(
            "No DISPLAY. Edit-3D render needs pyrender. For headless: xvfb-run claw3d convert --edit-3d ... or apt install xvfb xauth"
        )

    return _render_views_pyrender(mesh)


def merge_views_to_grid(views: dict[str, bytes]) -> bytes:
    """Merge front, back, left into 2x2 grid (right quadrant black). Standard Hunyuan layout."""
    from PIL import Image

    front = Image.open(io.BytesIO(views["front"])).convert("RGB")
    back = Image.open(io.BytesIO(views["back"])).convert("RGB")
    left = Image.open(io.BytesIO(views["left"])).convert("RGB")
    w, h = front.size
    grid = Image.new("RGB", (w * 2, h * 2), (0, 0, 0))
    grid.paste(front, (0, 0))
    grid.paste(back, (w, 0))
    grid.paste(left, (0, h))
    buf = io.BytesIO()
    grid.save(buf, format="PNG")
    return buf.getvalue()


def split_grid_to_views(grid_bytes: bytes) -> Tuple[bytes, bytes, bytes]:
    """Split 2x2 grid into front, back, left (same order as merge)."""
    from PIL import Image

    img = Image.open(io.BytesIO(grid_bytes)).convert("RGB")
    w, h = img.size
    hw, hh = w // 2, h // 2

    def to_png(crop) -> bytes:
        buf = io.BytesIO()
        crop.save(buf, format="PNG")
        return buf.getvalue()

    front = img.crop((0, 0, hw, hh))
    back = img.crop((hw, 0, w, hh))
    left = img.crop((0, hh, hw, h))
    return to_png(front), to_png(back), to_png(left)
