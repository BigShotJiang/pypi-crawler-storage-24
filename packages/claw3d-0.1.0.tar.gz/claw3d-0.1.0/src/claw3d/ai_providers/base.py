"""AI provider base — flow/step types and abstract interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional


class FlowType(str, Enum):
    """High-level convert flow — determines which steps run and in what order."""

    SKETCH_TO_3D = "sketch_to_3d"  # 1 image → enhance → image_to_3d
    MULTIVIEW_TO_3D = "multiview_to_3d"  # 1 quad image → enhance → split → multiview_to_3d
    TEXT_TO_3D = "text_to_3d"  # prompt → text_to_image → image_to_3d
    EDIT_3D = "edit_3d"  # 3D model → render → enhance → split → multiview_to_3d


class StepType(str, Enum):
    """Individual step in a flow — each can have its own model selection.

    Image-to-image steps differ by input/output:
    - sketch_enhance: 1 sketch in → 1 enhanced out (for Tripo)
    - multiview_enhance: 1 user-drawn quad in → 1 enhanced quad out (split after)
    - edit_3d_enhance: 1 rendered grid in → 1 transformed grid out (3d-to-3d pipeline)
    """

    # Image-to-image (different flows, different default models)
    SKETCH_ENHANCE = "sketch_enhance"
    MULTIVIEW_ENHANCE = "multiview_enhance"
    EDIT_3D_ENHANCE = "edit_3d_enhance"

    # Other steps
    TEXT_TO_IMAGE = "text_to_image"
    IMAGE_TO_3D = "image_to_3d"
    MULTIVIEW_TO_3D = "multiview_to_3d"


@dataclass
class ImageToImageRequest:
    """Normalized request for image-to-image — flexible input."""

    image_urls: list[str]  # 1 or N images
    prompt: Optional[str] = None
    step_type: StepType = StepType.SKETCH_ENHANCE  # Determines which model to use


@dataclass
class ImageToImageResult:
    """Normalized result from image-to-image."""

    image_urls: list[str]


@dataclass
class ImageResult:
    """Single image result (text-to-image)."""

    image_url: str


class AIProvider(ABC):
    """Abstract base for AI generation providers (FAL, Replicate, Google, etc.).

    All providers implement the same interface. Under the hood, request/response
    structures differ per provider (FAL REST, Replicate API, etc.).
    """

    @property
    @abstractmethod
    def provider_id(self) -> str:
        """e.g. 'fal', 'replicate', 'google'"""
        ...

    @abstractmethod
    def upload_file(self, path: Path) -> str:
        """Upload local file and return URL for the provider to use."""
        ...

    @abstractmethod
    def image_to_image(
        self,
        request: ImageToImageRequest,
        model_id: Optional[str] = None,
    ) -> ImageToImageResult:
        """Transform 1 or more images. step_type determines default model if model_id omitted."""
        ...

    @abstractmethod
    def text_to_image(self, prompt: str, model_id: Optional[str] = None) -> ImageResult:
        """Generate image from text prompt."""
        ...

    @abstractmethod
    def image_to_3d(self, image_url: str, model_id: Optional[str] = None) -> bytes:
        """Single image → GLB."""
        ...

    def multiview_to_3d(
        self,
        front_url: str,
        back_url: str,
        left_url: str,
        model_id: Optional[str] = None,
    ) -> bytes:
        """Multi-view (3 images) → GLB."""
        raise NotImplementedError(
            f"{self.provider_id} does not support multiview_to_3d"
        )
