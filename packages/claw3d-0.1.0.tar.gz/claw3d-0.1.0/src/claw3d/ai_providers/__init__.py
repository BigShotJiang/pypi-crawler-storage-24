"""AI providers — abstract interface and implementations for image/3D generation."""

from .base import (
    AIProvider,
    FlowType,
    StepType,
    ImageToImageRequest,
    ImageToImageResult,
    ImageResult,
)
from .provider_registry import (
    get_provider,
    get_available_providers,
    get_provider_info,
    list_providers,
    register_provider,
)
from .registry import (
    ModelRegistry,
    get_registry,
    get_step_catalog,
    get_recommended_model,
    is_model_allowed,
)
from .fal_provider import FALProvider
from .replicate_provider import ReplicateProvider

__all__ = [
    "AIProvider",
    "FlowType",
    "StepType",
    "ImageToImageRequest",
    "ImageToImageResult",
    "ImageResult",
    "ModelRegistry",
    "get_registry",
    "get_provider",
    "get_available_providers",
    "get_provider_info",
    "list_providers",
    "register_provider",
    "get_step_catalog",
    "get_recommended_model",
    "is_model_allowed",
    "FALProvider",
    "ReplicateProvider",
]
