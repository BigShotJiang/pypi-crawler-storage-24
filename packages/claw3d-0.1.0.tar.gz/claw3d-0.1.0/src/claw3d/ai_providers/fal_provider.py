"""FAL.ai provider — implements AIProvider for FAL endpoints."""

import base64
import os
import sys
import time
from pathlib import Path
from typing import Optional

import requests

try:
    import fal_client
except ImportError:
    fal_client = None

from .base import (
    AIProvider,
    ImageToImageRequest,
    ImageToImageResult,
    ImageResult,
    StepType,
)
from .registry import FAL_MODELS, get_registry

# ── Render prompts ────────────────────────────────────────────────────────────

# sketch_prefix + render_core
SKETCH_ENHANCE_DEFAULT = (
    "Transform this sketch into a professional, photorealistic 3D product render."
    " Crucial Output Instruction: photorealistic isometric-orthographic 3D render of the object"
    " on a plain, stealth-black background with soft studio lighting."
    " Object made out of ABS plastic. No moving parts. Center the object."
    " Ignore text unless it is part of the main object."
    " The input image may have multiple views of the same product — render only a single object."
    " Preserve the original charm. No watermarks."
)

# render_core only (for photo → replicate-object flow)
RENDER_CORE_PROMPT = (
    "Crucial Output Instruction: photorealistic isometric-orthographic 3D render of the object"
    " on a plain, stealth-black background with soft studio lighting."
    " Object made out of ABS plastic. No moving parts. Center the object."
    " Ignore text unless it is part of the main object."
    " The input image may have multiple views of the same product — render only a single object."
    " Preserve the original charm. No watermarks."
)

# dual_image_context — appended when two images are sent (original + annotated)
# "Image 1 is the original object photo. Image 2 is the same photo with a red marker drawing on top."
DUAL_IMAGE_SUFFIX = (
    " Image 1 is the original object photo."
    " Image 2 is the same photo with a red marker drawing on top,"
    " representing the desired object shape or location."
)

GENERIC_PROMPTS = frozenset({"a 3d printable object", "a 3d object", "3d printable object", "3d object", ""})


FAL_KEY_HINT = (
    "Please check OpenClaw Control UI → Skills → 3d-ai-forger and ensure your FAL API key is set correctly. "
    "Get a key from https://fal.ai/dashboard/keys"
)


def _get_fal_key() -> str:
    key = os.environ.get("FAL_API_KEY") or os.environ.get("FAL_KEY")
    if not key:
        print(
            "Error: FAL_API_KEY is required for conversion. Set it in OpenClaw Control UI → Skills → 3d-ai-forger "
            "(or export FAL_API_KEY). " + FAL_KEY_HINT,
            file=sys.stderr,
        )
        sys.exit(1)
    return key


def _extract_image_url(data) -> Optional[str]:
    """Extract image URL from FAL response (sync, queue, or wrapped).

    Handles plain dicts, fal_client result objects, and nested wrappers.
    """
    # fal_client may return a non-dict object with dict-like access
    if not isinstance(data, dict):
        try:
            data = dict(data)
        except (TypeError, ValueError):
            return None

    # Recursively search through common wrapper keys
    for layer in [data, data.get("response"), data.get("data"), data.get("payload"), data.get("output")]:
        if not isinstance(layer, dict):
            continue
        # Pattern: {"images": [{"url": "..."}, ...]}
        imgs = layer.get("images")
        if imgs and isinstance(imgs, list) and len(imgs) > 0:
            first = imgs[0]
            if isinstance(first, str) and first.startswith(("http://", "https://", "data:")):
                return first
            if isinstance(first, dict) and first.get("url"):
                return first["url"]
            # Some models: {"images": [{"content": "base64..."}]}
            if isinstance(first, dict) and first.get("content"):
                return f"data:image/png;base64,{first['content']}"
        # Pattern: {"image": {"url": "..."}} or {"image": "https://..."}
        img = layer.get("image")
        if img:
            if isinstance(img, dict) and img.get("url"):
                return img["url"]
            if isinstance(img, str) and img.startswith(("http://", "https://", "data:")):
                return img
        # Pattern: {"output": "https://..."} or {"output": {"url": "..."}}
        out = layer.get("output")
        if isinstance(out, dict) and out.get("url"):
            return out["url"]
        if isinstance(out, str) and out.startswith(("http://", "https://", "data:")):
            return out
        # Pattern: {"url": "https://..."} at top level
        url = layer.get("url")
        if isinstance(url, str) and url.startswith(("http://", "https://", "data:")):
            return url
    return None


def _extract_glb_url(data) -> Optional[str]:
    """Extract GLB URL from FAL 3D response."""
    if not isinstance(data, dict):
        try:
            data = dict(data)
        except (TypeError, ValueError):
            return None

    for layer in [data, data.get("response"), data.get("data"), data.get("payload")]:
        if not isinstance(layer, dict):
            continue
        url = (
            (layer.get("model") or {}).get("url")
            or (layer.get("model_3d") or {}).get("url")
            or (layer.get("model_glb") or {}).get("url")
            or (layer.get("model_mesh") or {}).get("url")
            or (layer.get("base_model") or {}).get("url")
            or (layer.get("pbr_model") or {}).get("url")
            or layer.get("model_url")
            or ((layer.get("output") or {}).get("url") if isinstance(layer.get("output"), dict) else None)
            or ((layer.get("meshes") or [{}])[0].get("url") if layer.get("meshes") else None)
        )
        if url:
            return url
    return None


def _poll_fal_status(
    status_url: str,
    response_url: str,
    headers: dict,
    max_wait: int = 600,
) -> Optional[dict]:
    """Poll FAL queue until COMPLETED; then fetch result from response_url."""
    start = time.time()
    while time.time() - start < max_wait:
        time.sleep(3)
        r = requests.get(status_url, headers=headers, timeout=30)
        if r.status_code != 200:
            continue
        status_data = r.json()
        status = status_data.get("status", "")
        if status == "COMPLETED":
            if _extract_image_url(status_data):
                return status_data
            fetch_url = status_data.get("response_url") or response_url
            for _ in range(10):
                resp = requests.get(fetch_url, headers=headers, timeout=90)
                if resp.ok:
                    return resp.json()
                if resp.status_code in (400, 404):
                    time.sleep(2)
                    continue
                break
            return None
        if status == "FAILED":
            return None
    return None


def _endpoint_to_app_id(endpoint: str) -> Optional[str]:
    """Convert queue.fal.run URL to fal_client application ID."""
    if "queue.fal.run/" in endpoint:
        return endpoint.split("queue.fal.run/", 1)[1].rstrip("/")
    return None


def _is_auth_error(exc: BaseException) -> bool:
    """True if exception looks like an auth/API key error."""
    msg = str(exc).lower()
    return any(
        x in msg for x in ("401", "403", "unauthorized", "invalid key", "api key", "authentication")
    )


_SUBSCRIBE_NOT_AVAILABLE = "__no_subscribe__"


def _run_via_fal_subscribe(
    endpoint: str,
    body: dict,
    extract_url_func,
    client_timeout: int = 600,
) -> str:
    """Use fal_client.subscribe for queue endpoints — handles IN_QUEUE automatically.

    Returns:
      - The extracted URL string on success
      - "" if subscribe ran but extraction failed (caller should NOT retry with POST)
      - _SUBSCRIBE_NOT_AVAILABLE if fal_client is unavailable (caller should fall back to POST)
    """
    if not fal_client:
        return _SUBSCRIBE_NOT_AVAILABLE
    app_id = _endpoint_to_app_id(endpoint)
    if not app_id:
        return _SUBSCRIBE_NOT_AVAILABLE
    if os.environ.get("FAL_API_KEY") and not os.environ.get("FAL_KEY"):
        os.environ["FAL_KEY"] = os.environ["FAL_API_KEY"]
    try:
        result = fal_client.sync_client.subscribe(
            app_id,
            body,
            client_timeout=client_timeout,
        )
    except Exception as e:
        if _is_auth_error(e):
            raise RuntimeError(f"FAL API key appears invalid. {FAL_KEY_HINT}") from e
        raise
    url = extract_url_func(result)
    if not url:
        # Log actual response for debugging — FAL succeeded but we couldn't parse it
        try:
            keys = list(result.keys()) if hasattr(result, 'keys') else type(result).__name__
        except Exception:
            keys = repr(result)[:200]
        print(
            f"Warning: FAL subscribe succeeded but URL extraction failed. "
            f"Response keys: {keys}. Full response (truncated): {str(result)[:500]}",
            file=sys.stderr,
        )
    return url or ""


class FALProvider(AIProvider):
    """FAL.ai implementation of AIProvider."""

    def __init__(self, api_key: Optional[str] = None):
        self._key = api_key or _get_fal_key()

    @property
    def provider_id(self) -> str:
        return "fal"

    def _headers(self) -> dict:
        return {"Authorization": f"Key {self._key}", "Content-Type": "application/json"}

    def upload_file(self, path: Path) -> str:
        """Upload local file to FAL and return URL."""
        if fal_client:
            if os.environ.get("FAL_API_KEY") and not os.environ.get("FAL_KEY"):
                os.environ["FAL_KEY"] = os.environ["FAL_API_KEY"]
            return fal_client.upload_file(str(path))
        data = path.read_bytes()
        b64 = base64.b64encode(data).decode()
        mime = "image/png" if path.suffix.lower() == ".png" else "image/jpeg"
        return f"data:{mime};base64,{b64}"

    def _run_fal_image_model(
        self,
        endpoint: str,
        body: dict,
        max_wait: int = 600,
    ) -> str:
        """Post to FAL image endpoint. Use fal_client.subscribe for queue endpoints."""
        # Prefer subscribe for queue endpoints (handles IN_QUEUE automatically)
        if "queue.fal.run" in endpoint:
            url = _run_via_fal_subscribe(
                endpoint, body, _extract_image_url, client_timeout=max_wait
            )
            if url and url != _SUBSCRIBE_NOT_AVAILABLE:
                return url
            if url != _SUBSCRIBE_NOT_AVAILABLE:
                # Subscribe ran and FAL succeeded, but we couldn't parse the response.
                # Do NOT fire a second POST (wastes money). Raise with debug info.
                raise RuntimeError(
                    "FAL image generation succeeded but response format was not recognized. "
                    "Check stderr logs for the full response. This is a claw3d parsing bug — "
                    "the image was generated on FAL but we couldn't extract the URL."
                )
        # Fallback: direct POST (only when fal_client unavailable)
        r = requests.post(endpoint, headers=self._headers(), json=body, timeout=60)
        if r.status_code in (401, 403):
            raise RuntimeError(
                f"FAL API key appears invalid or expired ({r.status_code}). {FAL_KEY_HINT}"
            )
        if r.status_code != 200:
            raise RuntimeError(f"FAL failed ({r.status_code}): {r.text[:500]}")
        data = r.json()
        url = _extract_image_url(data)
        if url:
            return url
        if data.get("status_url"):
            result = _poll_fal_status(
                data["status_url"],
                data.get("response_url", ""),
                self._headers(),
                max_wait=max_wait,
            )
            if result:
                url = _extract_image_url(result)
                if url:
                    return url
        raise RuntimeError(
            f"No image URL in FAL response. Keys: {list((data or {}).keys())}"
        )

    def _run_fal_3d_model(
        self,
        endpoint: str,
        body: dict,
        max_wait: int = 600,
    ) -> str:
        """Post to FAL 3D endpoint. Use fal_client.subscribe for queue endpoints."""
        if "queue.fal.run" in endpoint:
            url = _run_via_fal_subscribe(
                endpoint, body, _extract_glb_url, client_timeout=max_wait
            )
            if url and url != _SUBSCRIBE_NOT_AVAILABLE:
                return url
            if url != _SUBSCRIBE_NOT_AVAILABLE:
                raise RuntimeError(
                    "FAL 3D generation succeeded but response format was not recognized. "
                    "Check stderr logs for the full response. This is a claw3d parsing bug — "
                    "the model was generated on FAL but we couldn't extract the URL."
                )
        # Fallback: direct POST (only when fal_client unavailable)
        r = requests.post(endpoint, headers=self._headers(), json=body, timeout=60)
        if r.status_code in (401, 403):
            raise RuntimeError(
                f"FAL API key appears invalid or expired ({r.status_code}). {FAL_KEY_HINT}"
            )
        if r.status_code != 200:
            raise RuntimeError(f"FAL 3D failed ({r.status_code}): {r.text[:500]}")
        data = r.json()
        url = _extract_glb_url(data)
        if url:
            return url
        if data.get("status_url"):
            result = _poll_fal_status(
                data["status_url"],
                data.get("response_url", ""),
                self._headers(),
                max_wait=max_wait,
            )
            if result:
                url = _extract_glb_url(result)
                if url:
                    return url
        raise RuntimeError(
            f"No 3D model URL in FAL response. Keys: {list((data or {}).keys())}"
        )

    def image_to_image(
        self,
        request: ImageToImageRequest,
        model_id: Optional[str] = None,
    ) -> ImageToImageResult:
        model_id = model_id or get_registry().get_model(request.step_type)
        if model_id not in FAL_MODELS:
            raise ValueError(f"Unknown model: {model_id}")
        cfg = FAL_MODELS[model_id]
        endpoint = cfg["endpoint"]
        params = dict(cfg.get("params") or {})

        user_prompt = (request.prompt or "").strip()
        generic = user_prompt.lower() in GENERIC_PROMPTS or not user_prompt

        # Edit-3D / Multiview: use modification prefix (multi-view grid, apply user change)
        if request.step_type in (StepType.EDIT_3D_ENHANCE, StepType.MULTIVIEW_ENHANCE):
            modification_prefix = cfg.get("prompt_modification_prefix") or (
                "You are seeing the same 3D model from different views. "
                "If any view is missing, do not create it. Keep the same exact design, look and view orientations "
                "of the render but apply the following modification to the model: "
            )
            prompt = (
                f"{modification_prefix}{user_prompt}" if user_prompt
                else modification_prefix + "apply no visible changes."
            )
        elif len(request.image_urls) >= 2:
            # Annotation / attachment flow (dual_image_context):
            # Image 1 = original photo, Image 2 = user's drawing on top.
            # Use attachment_request + render_core + dual_image_context.
            if user_prompt and user_prompt.lower() not in GENERIC_PROMPTS:
                attachment_header = (
                    f"Output a 3D object that is an attachment or feature."
                    f" Only render the new object, do not include anything else.\n\n"
                    f"User Request: \"{user_prompt}\"\n\n"
                )
            else:
                attachment_header = (
                    "Output a 3D object that is an attachment or feature."
                    " Only render the new object, do not include anything else.\n\n"
                )
            prompt = attachment_header + RENDER_CORE_PROMPT + DUAL_IMAGE_SUFFIX
        else:
            # Sketch / photo enhance: default render prompt; NEVER "a 3D printable object"
            prompt = (
                SKETCH_ENHANCE_DEFAULT
                if generic
                else f"{SKETCH_ENHANCE_DEFAULT}\n\nUser input: {user_prompt}"
            )
            if prompt.lower().strip() in GENERIC_PROMPTS:
                prompt = SKETCH_ENHANCE_DEFAULT

        params["image_urls"] = request.image_urls
        params["prompt"] = prompt

        url = self._run_fal_image_model(endpoint, params)
        return ImageToImageResult(image_urls=[url])

    def text_to_image(self, prompt: str, model_id: Optional[str] = None) -> ImageResult:
        model_id = model_id or get_registry().get_model(StepType.TEXT_TO_IMAGE)
        if model_id not in FAL_MODELS:
            raise ValueError(f"Unknown model: {model_id}")
        cfg = FAL_MODELS[model_id]
        prefix = cfg.get("prompt_prefix", "")
        full_prompt = f"{prefix} — {prompt.strip()}" if prefix else prompt.strip()
        params = dict(cfg.get("params") or {})
        params["prompt"] = full_prompt
        url = self._run_fal_image_model(cfg["endpoint"], params)
        return ImageResult(image_url=url)

    def image_to_3d(self, image_url: str, model_id: Optional[str] = None) -> bytes:
        model_id = model_id or get_registry().get_model(StepType.IMAGE_TO_3D)
        if model_id not in FAL_MODELS:
            raise ValueError(f"Unknown model: {model_id}")
        cfg = FAL_MODELS[model_id]
        params = dict(cfg.get("params") or {})
        params["image_url"] = image_url
        glb_url = self._run_fal_3d_model(cfg["endpoint"], params)
        resp = requests.get(glb_url, timeout=120)
        if not resp.ok:
            raise RuntimeError(f"Failed to download GLB: {resp.status_code}")
        return resp.content

    def multiview_to_3d(
        self,
        front_url: str,
        back_url: str,
        left_url: str,
        model_id: Optional[str] = None,
    ) -> bytes:
        model_id = model_id or get_registry().get_model(StepType.MULTIVIEW_TO_3D)
        if model_id not in FAL_MODELS:
            raise ValueError(f"Unknown model: {model_id}")
        cfg = FAL_MODELS[model_id]
        params = dict(cfg.get("params") or {})
        params["front_image_url"] = front_url
        params["back_image_url"] = back_url
        params["left_image_url"] = left_url
        # Hunyuan can take up to 10+ min when cold on FAL; allow 20 min
        glb_url = self._run_fal_3d_model(cfg["endpoint"], params, max_wait=1200)
        resp = requests.get(glb_url, timeout=120)
        if not resp.ok:
            raise RuntimeError(f"Failed to download GLB: {resp.status_code}")
        return resp.content
