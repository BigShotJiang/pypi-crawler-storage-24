"""AI provider registry — factory for provider selection (FAL, Replicate, etc.).

Providers implement the AIProvider interface. The registry resolves which provider
to use from config, env, or explicit override.

To add a new provider (e.g. from a community package):
  1. Implement AIProvider (image_to_image, text_to_image, image_to_3d, upload_file, etc.)
  2. Call register_provider(id, factory, label, env, available=True)
  3. User runs `claw3d configure <id>` to select it
"""

import os
from pathlib import Path
from typing import Callable, Optional

from .base import AIProvider


# Provider metadata: id, label, env var, available (not "coming soon")
PROVIDER_INFO: dict[str, dict] = {
    "fal": {
        "id": "fal",
        "label": "FAL.ai",
        "env": "FAL_API_KEY",
        "available": True,
        "hint": "Get key at fal.ai/dashboard",
    },
    "replicate": {
        "id": "replicate",
        "label": "Replicate",
        "env": "REPLICATE_API_TOKEN",
        "available": False,
        "hint": "Coming soon",
    },
}


def _create_fal(api_key: Optional[str] = None) -> AIProvider:
    from .fal_provider import FALProvider

    return FALProvider(api_key=api_key)


def _create_replicate(api_key: Optional[str] = None) -> AIProvider:
    from .replicate_provider import ReplicateProvider

    return ReplicateProvider(api_key=api_key)


# Factory functions: provider_id -> (api_key?: str) -> AIProvider
PROVIDER_FACTORIES: dict[str, Callable[[Optional[str]], AIProvider]] = {
    "fal": _create_fal,
    "replicate": _create_replicate,
}


def list_providers() -> list[dict]:
    """List all registered providers with metadata."""
    return [dict(p) for p in PROVIDER_INFO.values()]


def get_available_providers() -> list[dict]:
    """List providers that are available (not coming soon)."""
    return [p for p in list_providers() if p.get("available")]


def get_provider_info(provider_id: str) -> Optional[dict]:
    """Get metadata for a provider."""
    return PROVIDER_INFO.get(provider_id)


def resolve_provider_id() -> str:
    """Resolve which provider to use: config > env > default."""
    try:
        from ..config import load_config

        cfg = load_config()
        provider = (cfg.get("provider") or cfg.get("ai_provider") or "").strip().lower()
        if provider in PROVIDER_FACTORIES:
            return provider
    except Exception:
        pass
    provider = (os.environ.get("CLAW3D_PROVIDER") or os.environ.get("FAL_PROVIDER") or "").strip().lower()
    if provider in PROVIDER_FACTORIES:
        return provider
    return "fal"


def get_provider(provider_id: Optional[str] = None, api_key: Optional[str] = None) -> AIProvider:
    """Get an AIProvider instance. Uses resolved provider_id if omitted."""
    pid = (provider_id or resolve_provider_id()).strip().lower()
    if pid not in PROVIDER_FACTORIES:
        raise ValueError(
            f"Unknown provider '{pid}'. Available: {', '.join(PROVIDER_FACTORIES.keys())}. "
            "Set CLAW3D_PROVIDER or run `claw3d configure`."
        )
    factory = PROVIDER_FACTORIES[pid]
    return factory(api_key)


def register_provider(
    provider_id: str,
    factory: Callable[[Optional[str]], AIProvider],
    label: str,
    env: str,
    available: bool = True,
    hint: str = "",
) -> None:
    """Register a provider (for community extensions)."""
    PROVIDER_INFO[provider_id] = {
        "id": provider_id,
        "label": label,
        "env": env,
        "available": available,
        "hint": hint,
    }
    PROVIDER_FACTORIES[provider_id] = factory
