"""Model registry — flow/step → model mapping for user-selectable models.

Each step has a provider-specific catalog of allowed models. Only models in the
catalog can be selected. SKETCH_ENHANCE (simple image→image) allows flux or
nano_banana; flux is recommended. Other steps have a single model for now.
"""

import os
from pathlib import Path
from typing import Any, Optional

from .base import FlowType, StepType

# Per-provider step catalogs: step → list of {id, label, recommended}
# Only these models can be selected for each step.
FAL_STEP_MODELS: dict[StepType, list[dict[str, Any]]] = {
    StepType.SKETCH_ENHANCE: [
        {"id": "flux2_pro_edit", "label": "FLUX 2 Pro Edit", "recommended": True},
        {"id": "gemini_edit", "label": "Nano Banana Pro", "recommended": False},
    ],
    StepType.MULTIVIEW_ENHANCE: [
        {"id": "gemini_edit", "label": "Nano Banana Pro", "recommended": True},
    ],
    StepType.EDIT_3D_ENHANCE: [
        {"id": "gemini_edit", "label": "Nano Banana Pro", "recommended": True},
    ],
    StepType.TEXT_TO_IMAGE: [
        {"id": "flux_pro_ultra", "label": "FLUX Pro Ultra", "recommended": True},
    ],
    StepType.IMAGE_TO_3D: [
        {"id": "tripo_v25", "label": "Tripo v2.5", "recommended": True},
    ],
    StepType.MULTIVIEW_TO_3D: [
        {"id": "hunyuan3d_v2", "label": "Hunyuan3D v2", "recommended": True},
    ],
}

# Provider → step catalog
STEP_MODEL_CATALOGS: dict[str, dict[StepType, list[dict[str, Any]]]] = {
    "fal": FAL_STEP_MODELS,
}

# Default model IDs per step (recommended model for each)
DEFAULT_MODELS: dict[StepType, str] = {
    StepType.SKETCH_ENHANCE: "flux2_pro_edit",
    StepType.MULTIVIEW_ENHANCE: "gemini_edit",
    StepType.EDIT_3D_ENHANCE: "gemini_edit",
    StepType.TEXT_TO_IMAGE: "flux_pro_ultra",
    StepType.IMAGE_TO_3D: "tripo_v25",
    StepType.MULTIVIEW_TO_3D: "hunyuan3d_v2",
}


def get_step_catalog(provider_id: str, step_type: StepType) -> list[dict[str, Any]]:
    """Get allowed models for a step on a provider. Returns empty if unknown."""
    catalogs = STEP_MODEL_CATALOGS.get(provider_id)
    if not catalogs:
        return []
    return catalogs.get(step_type, [])


def get_recommended_model(provider_id: str, step_type: StepType) -> Optional[str]:
    """Get recommended model id for a step on a provider."""
    catalog = get_step_catalog(provider_id, step_type)
    for m in catalog:
        if m.get("recommended"):
            return m["id"]
    return catalog[0]["id"] if catalog else None


def is_model_allowed(provider_id: str, step_type: StepType, model_id: str) -> bool:
    """True if model_id is in the allowed list for this step and provider."""
    catalog = get_step_catalog(provider_id, step_type)
    return any(m["id"] == model_id for m in catalog)

# FAL model config: endpoint, params, prompts
FAL_MODELS: dict[str, dict[str, Any]] = {
    "flux2_pro_edit": {
        "endpoint": "https://queue.fal.run/fal-ai/flux-2-pro/edit",
        "params": {
            "seed": 100,
            "sync_mode": False,  # Queue returns async; we poll status_url
            "image_size": "square_hd",
            "output_format": "png",
            "safety_tolerance": 5,
            "enable_safety_checker": False,
        },
        "prompt_default": (
            "Transform this sketch into a professional, photorealistic isometric-orthographic 3D render of the object on a plain stealth black background with soft studio lighting. Center the object. Ignore text unless it is part of the main object. The input image may have multiple views sketched of the same product, but it's important that we render only one single product. Preserve the original charm. No watermarks"
        ),
        "prompt_modification_prefix": (
            "You are seeing the same 3D model from different views. If any view is missing, do not create it. Keep the same exact design, look and view orientations of the render but apply the following modification to the model: "
        ),
    },
    "gemini_edit": {
        "endpoint": "https://queue.fal.run/fal-ai/nano-banana-pro/edit",
        "params": {
            "num_images": 1,
            "resolution": "1K",
            "aspect_ratio": "1:1",
            "output_format": "png",
        },
        "prompt_default": (
            "Transform this sketch into a professional, photorealistic isometric-orthographic 3D render of the object on a plain stealth black background with soft studio lighting. Center the object. Ignore text unless it is part of the main object. The input image may have multiple views sketched of the same product, but it's important that we render only one single product. Preserve the original charm. No watermarks"
        ),
        "prompt_modification_prefix": (
            "You are seeing the same 3D model from different views. If any view is missing, do not create it. Keep the same exact design, look and view orientations of the render but apply the following modification to the model: "
        ),
    },
    "flux_pro_ultra": {
        "endpoint": "https://queue.fal.run/fal-ai/flux-pro/v1.1-ultra",
        "params": {
            "aspect_ratio": "1:1",
            "output_format": "png",
            "safety_tolerance": 5,
        },
        "prompt_prefix": (
            "Render as a high-detail orthographic product photo on a seamless pure dark background with soft studio lighting and subtle natural shadows for depth. Center the object. No text, no logos, no watermarks. Material: matte ABS plastic."
        ),
    },
    "tripo_v25": {
        "endpoint": "https://queue.fal.run/tripo3d/tripo/v2.5/image-to-3d",
        "params": {"texture": "no", "pbr": False, "face_limit": 100000},
    },
    "hunyuan3d_v2": {
        "endpoint": "https://queue.fal.run/fal-ai/hunyuan3d/v2/multi-view",
        "params": {
            "seed": 10,
            "num_inference_steps": 50,
            "guidance_scale": 8,
            "octree_resolution": 300,
            "textured_mesh": False,
        },
    },
}


class ModelRegistry:
    """Resolves model_id for each step from defaults + config overrides.

    Validates against provider-specific step catalogs. Only allowed models
    can be used. Provider is optional; when omitted, no validation.
    """

    def __init__(
        self,
        overrides: Optional[dict[str, str]] = None,
        provider_id: Optional[str] = None,
    ):
        self._overrides = overrides or {}
        self._provider_id = provider_id
        self._load_config_overrides()

    def _load_config_overrides(self) -> None:
        """Load model overrides from ~/.config/claw3d/config.json. Validates if provider set."""
        try:
            from ..config import load_config

            cfg = load_config()
            models = cfg.get("models") or cfg.get("ai_models") or {}
            if isinstance(models, dict):
                for step_key, model_id in models.items():
                    try:
                        step_type = StepType(step_key)
                        mid = str(model_id)
                        if self._provider_id and not is_model_allowed(
                            self._provider_id, step_type, mid
                        ):
                            continue  # Skip invalid; use default
                        self._overrides[step_key] = mid
                    except ValueError:
                        pass
        except Exception:
            pass

    def get_model(self, step_type: StepType) -> str:
        """Get model_id for a step. Overrides > config > default. Validates if provider set."""
        key = step_type.value
        model_id = self._overrides.get(key) or DEFAULT_MODELS.get(
            step_type, "flux2_pro_edit"
        )
        if self._provider_id and not is_model_allowed(
            self._provider_id, step_type, model_id
        ):
            recommended = get_recommended_model(self._provider_id, step_type)
            return recommended or model_id
        return model_id

    def set_override(self, step_type: StepType, model_id: str) -> bool:
        """Override model for this session. Returns False if model not allowed."""
        if self._provider_id and not is_model_allowed(
            self._provider_id, step_type, model_id
        ):
            return False
        self._overrides[step_type.value] = model_id
        return True


def get_registry(
    overrides: Optional[dict[str, str]] = None,
    provider_id: Optional[str] = None,
) -> ModelRegistry:
    """Get model registry. provider_id enables step catalog validation."""
    return ModelRegistry(overrides=overrides, provider_id=provider_id)
