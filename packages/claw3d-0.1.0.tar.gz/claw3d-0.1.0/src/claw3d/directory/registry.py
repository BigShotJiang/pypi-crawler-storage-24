"""Provider registry — builds SearchProviders from config/env."""

from __future__ import annotations

import os
from typing import List, Optional, Sequence

from .providers.base import SearchProvider
from .providers.thingiverse import ThingiverseProvider


# Built-in provider IDs
PROVIDER_IDS = frozenset({"thingiverse"})


def _providers_from_env() -> List[SearchProvider]:
    """Build providers from environment (CLAW3D_DIRECTORY_PROVIDERS, tokens)."""
    raw = os.environ.get("CLAW3D_DIRECTORY_PROVIDERS", "thingiverse")
    # Comma-separated, case-insensitive
    ids = [p.strip().lower() for p in raw.split(",") if p.strip()]
    providers = []
    for pid in ids:
        if pid == "thingiverse":
            token = os.environ.get("THINGIVERSE_ACCESS_TOKEN") or os.environ.get(
                "THINGIVERSE_APP_TOKEN"
            )
            providers.append(ThingiverseProvider(token=token))
    return providers


def get_registry_from_config(
    provider_ids: Optional[Sequence[str]] = None,
) -> List[SearchProvider]:
    """
    Return list of SearchProviders to use.
    If provider_ids is given, filter to those only; otherwise use CLAW3D_DIRECTORY_PROVIDERS.
    """
    all_providers = _providers_from_env()
    if not provider_ids:
        return all_providers
    wanted = {p.strip().lower() for p in provider_ids if p.strip()}
    return [p for p in all_providers if p.id in wanted]


def list_providers():
    """Return (id, name, is_configured) for each configured provider."""
    providers = _providers_from_env()
    return [(p.id, p.name, p.is_configured()) for p in providers]
