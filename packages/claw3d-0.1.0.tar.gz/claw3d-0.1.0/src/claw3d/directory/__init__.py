"""3D model directory search — provider abstraction for Thingiverse, Sketchfab, etc."""

from .providers.base import SearchResult, SearchProvider
from .registry import get_registry_from_config, list_providers

__all__ = [
    "SearchResult",
    "SearchProvider",
    "get_registry_from_config",
    "list_providers",
]
