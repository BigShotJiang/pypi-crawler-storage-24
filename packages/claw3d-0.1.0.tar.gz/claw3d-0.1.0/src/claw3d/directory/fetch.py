"""Fetch/download 3D model from Thingiverse by thing ID or URL."""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Optional

import requests
import trimesh

BASE_URL = "https://api.thingiverse.com"

# Model file extensions we can load and merge
MODEL_EXTENSIONS = frozenset((".stl", ".obj", ".3mf", ".glb"))

# Extension priority for deterministic selection (best first)
EXTENSION_PRIORITY = [".stl", ".obj", ".glb", ".3mf"]

# Exclude files that are docs/config, not printable parts
SKIP_NAME_PATTERNS = ("readme", "config", "license", "instruction", "bill of materials", "bom")

# Prefer files that look like "complete" sets (one file with everything)
COMPLETE_SET_PATTERNS = ("complete", "full", "entire", "whole", "all-in-one", "set", "kit")

# Size/dimension keywords that indicate sub-variants (different sizes of same object)
SIZE_KEYWORDS = ("small", "medium", "large", "mini", "micro", "xl", "big", "standard", "compact", "slim")

# Cosmetic variation suffixes — same base model, minor cosmetic difference
COSMETIC_SUFFIXES: frozenset = frozenset({
    "notext", "nologo", "nowords", "noletters",
    "withtext", "withlogo",
    "simple", "simplified",
    "clean", "plain", "basic",
    "detailed", "fancy", "ornate", "decorated",
    "hollow", "solid",
    "open", "closed",
    "withbase", "nobase",
    "flat", "rounded", "smooth",
})

# Preference scores for cosmetic modifiers (higher = better for 3D printing)
COSMETIC_SCORES: dict = {
    "notext": 10, "nologo": 10, "nowords": 10, "noletters": 10,
    "nobase": 8,
    "simple": 7, "simplified": 7,
    "clean": 7, "plain": 7, "basic": 7,
    "smooth": 6,
    "hollow": 5,
    "flat": 4, "rounded": 4,
    "solid": 3, "open": 3, "closed": 3,
    "withbase": -3,
    "withtext": -5, "withlogo": -5,
    "detailed": -5, "fancy": -5, "ornate": -5, "decorated": -5,
}


def _get_token() -> Optional[str]:
    return os.environ.get("THINGIVERSE_ACCESS_TOKEN") or os.environ.get("THINGIVERSE_APP_TOKEN")


def _thing_id_from_url(url: str) -> Optional[str]:
    """Extract thing ID from thingiverse URL. E.g. thing:1342970 or thingiverse.com/thing:1342970."""
    if not url or not isinstance(url, str):
        return None
    # thing:1342970 or /thing:1342970
    m = re.search(r"thing[:\s]*(\d+)", url, re.IGNORECASE)
    return m.group(1) if m else None


def _download_file_with_auth(url: str, output_path: Path, token: str) -> bool:
    """Download a file, adding auth (Bearer header or access_token param) if needed."""
    headers = {"Authorization": f"Bearer {token}"}
    # Some Thingiverse URLs work with access_token in query; try Bearer first
    try:
        r = requests.get(url, headers=headers, timeout=60, stream=True)
    except requests.RequestException:
        return False
    if r.status_code == 200:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                f.write(chunk)
        return True
    # Fallback: append access_token to URL (for CDN/signed URLs)
    sep = "&" if "?" in url else "?"
    auth_url = f"{url}{sep}access_token={token}"
    try:
        r2 = requests.get(auth_url, timeout=60, stream=True)
    except requests.RequestException:
        return False
    if r2.status_code != 200:
        return False
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "wb") as f:
        for chunk in r2.iter_content(chunk_size=65536):
            f.write(chunk)
    return True


def _is_model_file(name: str) -> bool:
    """True if filename looks like a printable 3D model (not readme/config)."""
    n = name.lower()
    if any(p in n for p in SKIP_NAME_PATTERNS):
        return False
    return Path(name).suffix.lower() in MODEL_EXTENSIONS


def _is_complete_set(name: str) -> bool:
    """True if filename suggests a complete/all-in-one set."""
    n = name.lower()
    return any(p in n for p in COMPLETE_SET_PATTERNS)


def _version_sort_key(name: str) -> tuple[int, int, int]:
    """Sort key for reverse: (has_complete, version, is_set). Prefer complete, then highest version."""
    n = name.lower()
    has_complete = 1 if "complete" in n else 0
    is_set = 1 if _is_complete_set(name) else 0
    v_match = re.search(r"v[_\s.]*(\d+)[_\s.]*(\d+)", n, re.I)
    ver = (int(v_match.group(1)) * 100 + int(v_match.group(2))) if v_match else 0
    return (has_complete, ver, is_set)


def _detect_variant_tag(name: str) -> Optional[str]:
    """Detect size/version/dimension tag in filename. Returns tag string or None."""
    n = name.lower()
    # Dimension: 25mm, 50mm, 100mm
    m = re.search(r"(\d+)\s*mm", n)
    if m:
        return f"{m.group(1)}mm"
    # Size keyword
    for kw in SIZE_KEYWORDS:
        if re.search(r"(?<![a-z])" + kw + r"(?![a-z])", n):
            return kw
    # Version with two parts: v1_1, v2_0
    m = re.search(r"v[_\s.]*(\d+)[_\s.]*(\d+)", n, re.I)
    if m:
        return f"v{m.group(1)}.{m.group(2)}"
    # Version single: v1, v2
    m = re.search(r"(?<![a-z])v(\d+)(?!\d)", n, re.I)
    if m:
        return f"v{m.group(1)}"
    return None


def _extract_cosmetic_base(stem: str) -> tuple:
    """
    If stem ends with a known cosmetic modifier (after '_' or '-'), return (base, modifier_key).
    Otherwise return (lowercased_stem, None).

    e.g. "TiltedWineBottleStand_NoText" → ("tiltedwinebottlestand", "notext")
         "TiltedWineBottleStand"         → ("tiltedwinebottlestand", None)
    """
    for sep in ("_", "-"):
        idx = stem.rfind(sep)
        if idx <= 0:
            continue
        raw_suffix = stem[idx + 1:].lower()
        if raw_suffix in COSMETIC_SUFFIXES:
            return stem[:idx].lower(), raw_suffix
    return stem.lower(), None


def _cosmetic_reason(modifier: Optional[str]) -> str:
    """Human-readable reason for auto-selecting a cosmetic variant."""
    reasons = {
        "notext": "no-text variant (cleaner for printing)",
        "nologo": "no-logo variant (cleaner for printing)",
        "nowords": "no-text variant (cleaner for printing)",
        "noletters": "no-text variant (cleaner for printing)",
        "nobase": "no-base variant",
        "simple": "simplified variant",
        "simplified": "simplified variant",
        "clean": "clean variant",
        "plain": "plain variant (no decorations)",
        "basic": "basic variant",
        "smooth": "smooth surface variant",
        "hollow": "hollow variant (saves material)",
    }
    return reasons.get(modifier or "", f"{modifier} variant") if modifier else "base variant"


def list_thingiverse_files_grouped(
    thing_id: str,
    token: Optional[str] = None,
) -> Optional[dict]:
    """
    List files grouped by extension with sub-variant detection.

    Returns:
        {
            "best_ext": ".stl",          # best available extension (deterministic priority)
            "best_group": [...],          # files in the best extension group
            "groups": {".stl": [...], …}, # all groups
            "has_sub_variants": bool,     # True if best group has size/version sub-variants
            "sub_variants": [...],        # files with variant tags (size/version choices)
            "parts_only": [...],          # files without variant tags (multi-part components)
        }
    Returns None on API failure.
    """
    tok = token or _get_token()
    if not tok or not str(tok).strip():
        return None

    files_url = f"{BASE_URL}/things/{thing_id}/files"
    params = {"access_token": tok}
    headers = {"Authorization": f"Bearer {tok}"}
    try:
        r = requests.get(files_url, params=params, headers=headers, timeout=15)
    except requests.RequestException:
        return None
    if r.status_code != 200:
        return None
    try:
        files_data = r.json()
    except Exception:
        return None

    files = files_data if isinstance(files_data, list) else files_data.get("files", [])
    if not isinstance(files, list):
        return None

    # Collect model files grouped by extension
    groups: dict[str, list[dict]] = {}
    for f in files:
        if not isinstance(f, dict):
            continue
        name = f.get("name", "")
        if not name:
            continue
        dl = f.get("download_url") or f.get("public_url") or f.get("url")
        if not dl:
            continue
        if not _is_model_file(name):
            continue
        ext = Path(name).suffix.lower()
        if ext not in groups:
            groups[ext] = []
        groups[ext].append({
            "name": name,
            "url": dl,
            "is_complete_set": _is_complete_set(name),
            "variant_tag": _detect_variant_tag(name),
        })

    if not groups:
        return None

    # Find best available extension (deterministic priority)
    best_ext = next((e for e in EXTENSION_PRIORITY if e in groups), next(iter(groups)))
    best_group_raw = groups[best_ext]

    # Tag each file with cosmetic modifier (only if no size/version variant_tag)
    best_group: list[dict] = []
    for f in best_group_raw:
        if f["variant_tag"] is not None:
            best_group.append({**f, "cosmetic_modifier": None, "cosmetic_base": None})
        else:
            stem = Path(f["name"]).stem
            base, cosm = _extract_cosmetic_base(stem)
            best_group.append({**f, "cosmetic_modifier": cosm, "cosmetic_base": base})

    # Separate size/version sub-variants from the rest
    sub_variants = [f for f in best_group if f["variant_tag"] is not None]
    non_variants = [f for f in best_group if f["variant_tag"] is None]

    # Group non-variants by cosmetic base name to find cosmetic variation groups
    base_groups: dict = {}
    for f in non_variants:
        key = f["cosmetic_base"]
        if key not in base_groups:
            base_groups[key] = []
        base_groups[key].append(f)

    cosmetic_variation_groups: list[dict] = []
    parts_only: list[dict] = []
    for base, group_files in base_groups.items():
        has_cosm = any(f["cosmetic_modifier"] is not None for f in group_files)
        if len(group_files) > 1 and has_cosm:
            # Multiple files with same base and at least one cosmetic modifier → variation group
            sorted_files = sorted(
                group_files,
                key=lambda f: COSMETIC_SCORES.get(f["cosmetic_modifier"] or "", 0),
                reverse=True,
            )
            auto = sorted_files[0]
            cosmetic_variation_groups.append({
                "base": base,
                "files": group_files,
                "auto_selected": auto,
                "auto_selected_reason": _cosmetic_reason(auto["cosmetic_modifier"]),
            })
        else:
            parts_only.extend(group_files)

    # has_sub_variants = multiple tagged files (size/version choices for user to pick from)
    has_sub_variants = len(sub_variants) > 1
    has_cosmetic_variations = len(cosmetic_variation_groups) > 0
    cosmetic_auto_selected = [g["auto_selected"] for g in cosmetic_variation_groups]

    return {
        "best_ext": best_ext,
        "best_group": best_group,
        "groups": groups,
        "has_sub_variants": has_sub_variants,
        "sub_variants": sub_variants,
        "has_cosmetic_variations": has_cosmetic_variations,
        "cosmetic_variation_groups": cosmetic_variation_groups,
        "cosmetic_auto_selected": cosmetic_auto_selected,
        "parts_only": parts_only,
    }


def list_thingiverse_files(
    thing_id: str,
    token: Optional[str] = None,
) -> Optional[list[dict]]:
    """
    List available model files for a thing (no download). Returns list of
    {name, url, is_complete_set} for the bot to show options. None on failure.
    """
    tok = token or _get_token()
    if not tok or not str(tok).strip():
        return None

    files_url = f"{BASE_URL}/things/{thing_id}/files"
    params = {"access_token": tok}
    headers = {"Authorization": f"Bearer {tok}"}
    try:
        r = requests.get(files_url, params=params, headers=headers, timeout=15)
    except requests.RequestException:
        return None
    if r.status_code != 200:
        return None
    try:
        files_data = r.json()
    except Exception:
        return None
    files = files_data if isinstance(files_data, list) else files_data.get("files", [])
    if not isinstance(files, list):
        return None

    result: list[dict] = []
    for f in files:
        if not isinstance(f, dict):
            continue
        name = f.get("name", "")
        if not name:
            continue
        dl = f.get("download_url") or f.get("public_url") or f.get("url")
        if not dl:
            continue
        if _is_model_file(name):
            result.append({"name": name, "url": dl, "is_complete_set": _is_complete_set(name)})
    return result


def fetch_thingiverse(
    thing_id: str,
    output_dir: Path,
    token: Optional[str] = None,
    choose: Optional[str] = None,
) -> tuple[Optional[Path], bool]:
    """
    Fetch a Thingiverse thing by ID, download ALL model parts.

    Single part: returns (path_to_file, False).
    Multi-part: returns (path_to_directory, True) — parts are separate files; use
    claw3d pack to arrange on build plate before slicing.
    """
    tok = token or _get_token()
    if not tok or not str(tok).strip():
        return None, False

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # /things/{id}/files — package-url is deprecated/returns 400
    files_url = f"{BASE_URL}/things/{thing_id}/files"
    params = {"access_token": tok}
    headers = {"Authorization": f"Bearer {tok}"}
    try:
        r = requests.get(files_url, params=params, headers=headers, timeout=15)
    except requests.RequestException as e:
        if os.environ.get("CLAW3D_DEBUG"):
            print(f"[claw3d] Thingiverse files request failed: {e}", file=sys.stderr)
        return None, False

    if r.status_code != 200:
        if os.environ.get("CLAW3D_DEBUG"):
            try:
                body = r.text[:500] if r.text else ""
                print(
                    f"[claw3d] Thingiverse API {r.status_code}: {body}",
                    file=sys.stderr,
                )
            except Exception:
                pass
        return None, False

    try:
        files_data = r.json()
    except Exception:
        return None, False

    files = files_data if isinstance(files_data, list) else files_data.get("files", [])
    if not isinstance(files, list):
        return None, False

    # Collect model files
    model_candidates: list[tuple[str, str]] = []
    for f in files:
        if not isinstance(f, dict):
            continue
        name = f.get("name", "")
        if not name:
            continue
        dl = f.get("download_url") or f.get("public_url") or f.get("url")
        if not dl:
            continue
        if _is_model_file(name):
            model_candidates.append((name, dl))

    if not model_candidates:
        return None, False

    # User override: --choose "v_1_1" or "complete" filters to matching file(s)
    if choose:
        choose_lower = choose.lower()
        filtered = [(n, u) for n, u in model_candidates if choose_lower in n.lower()]
        if filtered:
            model_candidates = filtered

    # Smart selection: prefer "complete" / "set" files over individual parts
    complete_files = [(n, u) for n, u in model_candidates if _is_complete_set(n)]
    if complete_files:
        complete_files.sort(key=lambda x: _version_sort_key(x[0]), reverse=True)
        model_candidates = [complete_files[0]]  # single best complete set

    # Download selected files
    downloaded: list[Path] = []
    for name, url in model_candidates:
        dest = output_dir / Path(name).name
        if _download_file_with_auth(url, dest, tok):
            downloaded.append(dest)

    if not downloaded:
        return None, False

    downloaded.sort(key=lambda p: p.name.lower())  # deterministic order

    # Single file: return as-is
    if len(downloaded) == 1:
        return downloaded[0], False

    # Multi-part: return directory. Caller must run claw3d pack with --build before slicing
    return output_dir, True


def ensure_glb_for_preview(input_path: Path, output_path: Path) -> bool:
    """Convert STL/OBJ/3MF to GLB when output_path ends with .glb. Otherwise copy as-is.

    All files stored as Z-up (slicer convention). No coordinate rotation is applied here.
    preview.py converts Z-up → Y-up at render time by applying −90°X.
    """
    import shutil

    import trimesh

    ext = input_path.suffix.lower()
    wants_glb = output_path.suffix.lower() == ".glb"

    if ext == ".glb":
        shutil.copy2(input_path, output_path)
        return True
    if ext in (".obj", ".stl", ".3mf") and wants_glb:
        try:
            mesh = trimesh.load(str(input_path), force="mesh")
            if isinstance(mesh, trimesh.Scene):
                mesh = mesh.dump(concatenate=True)
            # No rotation — keep Z-up as-is. preview.py handles the Z-up→Y-up conversion.
            mesh.export(str(output_path), file_type="glb")
            return output_path.exists()
        except Exception:
            return False
    # Output is not GLB
    shutil.copy2(input_path, output_path)
    return True
