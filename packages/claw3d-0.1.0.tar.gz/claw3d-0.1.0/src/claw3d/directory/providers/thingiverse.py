"""Thingiverse directory search provider."""

from __future__ import annotations

import os
from typing import Any, Optional
import requests

from .base import SearchResult, SearchProvider

# Thingiverse API: https://www.thingiverse.com/developers
# App token from https://www.thingiverse.com/apps/create
BASE_URL = "https://api.thingiverse.com"

# Words to ignore when checking result relevance (not meaningful query terms)
_STOP_WORDS = frozenset({
    "a", "an", "the", "of", "for", "in", "on", "to", "by", "with",
    "and", "or", "is", "it", "at", "as", "3d", "print", "printed",
    "printable", "model", "file", "files",
})


def _query_words(query: str) -> frozenset:
    """Return significant lowercase words from the query (excluding stop words)."""
    return frozenset(
        w for w in query.lower().split()
        if w not in _STOP_WORDS and len(w) >= 3
    )


def _result_is_relevant(name: str, query_words: frozenset) -> bool:
    """True if at least one query word appears in the result name."""
    if not query_words:
        return True
    name_lower = name.lower()
    return any(w in name_lower for w in query_words)


def _get_token():  # type: () -> Optional[str]
    return os.environ.get("THINGIVERSE_ACCESS_TOKEN") or os.environ.get("THINGIVERSE_APP_TOKEN")


def _upgrade_thumbnail_url(url: str) -> str:
    """Upgrade a Thingiverse CDN thumbnail URL to the largest available size."""
    if not url:
        return url
    import re
    # e.g. _thumb_medium.JPG → _thumb_large.JPG
    upgraded = re.sub(r'_thumb_(thumb|small|medium)(\.[a-zA-Z]+)$', r'_thumb_large\2', url, flags=re.IGNORECASE)
    return upgraded


def _thing_to_result(thing):
    """Convert Thingiverse thing dict to SearchResult."""
    thing_id = str(thing.get("id", ""))
    name = thing.get("name", "Untitled")
    # public_url is the web page; thumbnail is the image
    url = thing.get("public_url", thing.get("url", f"https://www.thingiverse.com/thing:{thing_id}"))
    creator = thing.get("creator", {})
    author = creator.get("name", creator.get("public_url", "")) if isinstance(creator, dict) else str(creator)

    # Thingiverse returns files under /things/{id}; primary download is usually first file
    # We don't fetch files here; download_url can be built as /things/{id}/zip
    download_url = f"https://api.thingiverse.com/things/{thing_id}/package-url?access_token=REDACTED"
    # For display we use a generic download info; actual download requires token in request
    download_url = f"https://www.thingiverse.com/thing:{thing_id}/zip"

    license_info = thing.get("license")
    if isinstance(license_info, str):
        license_str = license_info
    elif isinstance(license_info, dict):
        license_str = license_info.get("full_name") or license_info.get("title") or ""
    else:
        license_str = ""

    # Prefer default_image.sizes (has large/medium options) over thumbnail field (usually small)
    thumbnail = None
    SIZE_PREF = {"large": 4, "medium": 3, "small": 2, "thumb": 1}
    default_images = thing.get("default_image", {})
    if isinstance(default_images, dict):
        thumbs = default_images.get("sizes") or []
        if isinstance(thumbs, list) and thumbs:
            best = max(
                (t for t in thumbs if isinstance(t, dict) and t.get("url")),
                key=lambda t: SIZE_PREF.get(t.get("size", t.get("type", "")), 0),
                default=None,
            )
            if best:
                thumbnail = best["url"]
        if not thumbnail and isinstance(default_images.get("thumbnail"), str):
            thumbnail = default_images["thumbnail"]
    # Fall back to top-level thumbnail/thumbnail_url (usually small, last resort)
    if not thumbnail:
        thumbnail = thing.get("thumbnail") or (thing.get("thumbnail_url") if isinstance(thing.get("thumbnail_url"), str) else None)
    # Always try to upgrade the URL to the largest CDN size available
    thumbnail = _upgrade_thumbnail_url(thumbnail)

    return SearchResult(
        id=thing_id,
        name=name,
        url=url,
        download_url=download_url,
        thumbnail_url=thumbnail,
        author=author or None,
        license=license_str or None,
        source="thingiverse",
        formats=None,
    )


class ThingiverseProvider(SearchProvider):
    """Thingiverse search provider. Requires THINGIVERSE_ACCESS_TOKEN or THINGIVERSE_APP_TOKEN."""

    def __init__(self, token: Optional[str] = None) -> None:
        self._token = token or _get_token()

    @property
    def id(self) -> str:
        return "thingiverse"

    @property
    def name(self) -> str:
        return "Thingiverse"

    @property
    def requires_key(self) -> bool:
        return True

    def is_configured(self) -> bool:
        return bool(self._token)

    def search(self, query: str, limit: int = 10):
        if not self._token:
            return []

        # Thingiverse REST API search: GET /search/{term}?type=things
        # Per official OpenAPI spec: path-based term, type=things filters to printable models.
        from urllib.parse import quote
        url = f"{BASE_URL}/search/{quote(query)}"
        params = {
            "access_token": self._token,
            "type": "things",
            "per_page": min(limit, 20),
            "page": 1,
        }

        try:
            r = requests.get(url, params=params, timeout=15)
        except requests.RequestException:
            return []

        if r.status_code != 200:
            return []

        try:
            data = r.json()
        except Exception:
            return []

        # Response: {"hits": [...]}, {"things": [...]}, or direct list
        hits = []
        if isinstance(data, list):
            hits = data
        elif isinstance(data, dict):
            hits = data.get("hits") or data.get("things") or data.get("items") or []
        if not isinstance(hits, list):
            return []

        qwords = _query_words(query)
        results = []
        for thing in hits:
            if not isinstance(thing, dict):
                continue
            name = thing.get("name", "")
            # Post-filter: skip results with no query word in the name (Thingiverse mixes
            # in popular/featured items that are completely unrelated to the search query)
            if not _result_is_relevant(name, qwords):
                continue
            results.append(_thing_to_result(thing))
            if len(results) >= limit:
                break
        return results
