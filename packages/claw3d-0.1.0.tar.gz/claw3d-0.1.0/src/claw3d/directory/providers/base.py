"""Base types for directory search providers."""

from dataclasses import dataclass
from typing import List, Optional, Protocol


@dataclass
class SearchResult:
    """Unified result from any directory provider."""

    id: str
    name: str
    url: str
    download_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    author: Optional[str] = None
    license: Optional[str] = None
    source: str = ""
    formats: Optional[List[str]] = None


class SearchProvider(Protocol):
    """Protocol for directory search providers."""

    @property
    def id(self) -> str:
        """Provider identifier (e.g. 'thingiverse')."""
        ...

    @property
    def name(self) -> str:
        """Human-readable name."""
        ...

    @property
    def requires_key(self) -> bool:
        """True if API key/token is required."""
        ...

    def is_configured(self) -> bool:
        """True if provider has credentials and can be used."""
        ...

    def search(self, query: str, limit: int = 10) -> list[SearchResult]:
        """Search for 3D models. Returns unified SearchResult list."""
        ...
