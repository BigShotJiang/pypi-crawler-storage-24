"""Minimal Gemini API client for claw3d analysis commands.

Used by:
  - claw3d analyze  (image intent classification)
  - claw3d extract-frame  (video hero-frame selection)

Requires: requests (already a dependency)
API key: CLAW3D_GEMINI_API_KEY | GEMINI_API_KEY | GOOGLE_API_KEY | config file
"""

from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Any

import requests

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"

# Primary model: Gemini 2.5 Flash (fast, cheap, multimodal, supports video via File API)
GEMINI_PRIMARY = "gemini-2.5-flash"
# Fallback: 2.0 Flash (no thinking tokens, lower cost on retries)
GEMINI_FALLBACK = "gemini-2.0-flash"


class GeminiError(Exception):
    pass


def _b64(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode()


def _mime_from_path(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".webp": "image/webp",
        ".gif": "image/gif",
    }.get(ext, "image/jpeg")


def call_json(
    api_key: str,
    system_prompt: str,
    user_parts: list[dict[str, Any]],
    model: str = GEMINI_PRIMARY,
    fallback_model: str = GEMINI_FALLBACK,
    timeout: int = 120,
    temperature: float = 1.0,
) -> dict[str, Any]:
    """Call Gemini with JSON output mode. Returns parsed dict.

    Retries once on 429/503 with backoff, then tries fallback model.
    Raises GeminiError on unrecoverable failure.
    """
    models_to_try = [model, fallback_model] if fallback_model and fallback_model != model else [model]
    last_error: str = ""

    for model_id in models_to_try:
        url = f"{GEMINI_BASE}/models/{model_id}:generateContent?key={api_key}"
        payload: dict[str, Any] = {
            "contents": [{"parts": user_parts}],
            "system_instruction": {"parts": [{"text": system_prompt}]},
            "generationConfig": {
                "temperature": temperature,
                "responseMimeType": "application/json",
            },
        }

        for attempt in range(3):
            try:
                r = requests.post(url, json=payload, timeout=timeout)
            except requests.RequestException as e:
                last_error = str(e)
                time.sleep(3 * (attempt + 1))
                continue

            if r.status_code in (429, 503):
                last_error = f"HTTP {r.status_code}: {r.text[:200]}"
                wait = min(3 * 2 ** attempt, 30)
                time.sleep(wait)
                continue

            if r.status_code != 200:
                last_error = f"HTTP {r.status_code}: {r.text[:400]}"
                break  # non-retriable error, try next model

            data = r.json()
            if data.get("error"):
                last_error = data["error"].get("message", str(data["error"]))
                break

            raw = data.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
            try:
                # Strip markdown fences if present
                text = raw.strip()
                if text.startswith("```"):
                    text = text.split("```", 2)[1]
                    if text.startswith("json"):
                        text = text[4:]
                    text = text.rsplit("```", 1)[0]
                return json.loads(text.strip())
            except json.JSONDecodeError as e:
                raise GeminiError(f"JSON parse failed: {e}\nRaw output: {raw[:400]}")

    raise GeminiError(f"Gemini request failed after all attempts: {last_error}")


# ─── Image helper ────────────────────────────────────────────────────────────

def image_parts(image_path: Path, annotated_path: Path | None = None) -> list[dict[str, Any]]:
    """Build Gemini content parts list from one or two image files."""
    parts: list[dict[str, Any]] = [
        {"inline_data": {"mime_type": _mime_from_path(image_path), "data": _b64(image_path)}}
    ]
    if annotated_path and annotated_path.exists():
        parts.append({"text": "The user marked this second image to clarify their intent:"})
        parts.append({"inline_data": {"mime_type": _mime_from_path(annotated_path), "data": _b64(annotated_path)}})
    return parts


# ─── Video File API ───────────────────────────────────────────────────────────

def upload_video(api_key: str, video_path: Path, mime_type: str = "video/mp4") -> str:
    """Upload video to Gemini File API. Returns fileUri. Polls until ACTIVE."""
    data = video_path.read_bytes()
    resp = requests.post(
        f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={api_key}",
        headers={
            "X-Goog-Upload-Protocol": "raw",
            "X-Goog-Upload-Command": "upload, finalize",
            "Content-Type": mime_type,
        },
        data=data,
        timeout=300,
    )
    if not resp.ok:
        raise GeminiError(f"Video upload failed ({resp.status_code}): {resp.text[:300]}")
    file_obj = resp.json().get("file", {})
    file_uri = file_obj.get("uri")
    file_name = file_obj.get("name")
    if not file_uri:
        raise GeminiError(f"No file URI in upload response: {resp.text[:200]}")

    # Poll until ACTIVE
    for _ in range(30):
        state = file_obj.get("state", "PROCESSING")
        if state == "ACTIVE":
            return file_uri
        time.sleep(2)
        check = requests.get(f"{GEMINI_BASE}/{file_name}?key={api_key}", timeout=15)
        if check.ok:
            file_obj = check.json()
        else:
            break

    raise GeminiError(f"Video never reached ACTIVE state (last state: {file_obj.get('state')})")


def delete_video(api_key: str, file_uri: str) -> None:
    """Delete video from Gemini File API (best-effort, non-fatal)."""
    # file_uri looks like "https://generativelanguage.googleapis.com/v1beta/files/xxxx"
    # file name = "files/xxxx"
    try:
        file_name = file_uri.split("/v1beta/")[-1]
        requests.delete(f"{GEMINI_BASE}/{file_name}?key={api_key}", timeout=10)
    except Exception:
        pass
