"""Allow running claw3d as python -m claw3d."""

from .cli import main

if __name__ == "__main__":
    main()
