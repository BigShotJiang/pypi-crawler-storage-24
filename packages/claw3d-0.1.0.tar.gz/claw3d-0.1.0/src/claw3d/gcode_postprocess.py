"""G-code post-processing — substitute Cura placeholders and enforce bed calibration defaults.

1. Placeholder substitution: CuraEngine outputs {setting_name} placeholders. The slicing
   API substitutes them; we provide client-side fallback for robustness.

2. Bed calibration: run_bed_autocalibration is OFF by default. When disabled,
   we comment out BED_MESH_CALIBRATE, G29, M420 S1 in the G-code so the printer does not run
   auto bed leveling (can clog some printers). Belt-and-suspenders: API should do this too, but
   we enforce it client-side for any slicing backend.
"""

import re
from pathlib import Path
from typing import Any, Optional

# Fallback values for common Cura placeholders (when API doesn't substitute)
# Based on safe_normal.inst.cfg and generic PLA profiles
PLACEHOLDER_FALLBACKS: dict[str, Any] = {
    "material_bed_temperature_layer_0": 60,
    "material_bed_temperature": 60,
    "material_print_temperature_layer_0": 200,
    "material_print_temperature": 200,
    "material_initial_print_temperature": 200,
    "material_final_print_temperature": 200,
    "material_standby_temperature": 150,
    "default_material_print_temperature": 200,
    "default_material_bed_temperature": 60,
    "machine_nozzle_size": 0.4,
    "machine_nozzle_head_distance": 0,
    "layer_height": 0.2,
    "layer_height_0": 0.2,
    "line_width": 0.4,
    "wall_line_count": 3,
    "skirt_line_count": 4,
    "support_line_distance": 4,
    "infill_sparse_density": 20,
    "speed_print": 50,
    "speed_travel": 150,
    "speed_wall": 25,
    "speed_wall_x": 25,
    "speed_topbottom": 25,
    "acceleration_print": 500,
    "acceleration_travel": 1500,
    "jerk_print": 5,
    "jerk_travel": 10,
    "retraction_amount": 5,
    "retraction_speed": 45,
    "machine_width": 220,
    "machine_depth": 220,
    "machine_height": 250,
    "machine_gcode_flavor": "RepRap (Marlin/Sprinter)",
}


def substitute_placeholders(content: str, fallbacks: Optional[dict[str, Any]] = None) -> str:
    """
    Substitute {setting_name} placeholders in G-code with fallback values.

    Handles {setting_name} and {setting_name, extruder_nr} formats. For extruder variant,
    uses the same value (extruder number is ignored for fallbacks).
    """
    if fallbacks is None:
        fallbacks = PLACEHOLDER_FALLBACKS

    def _replace(match: re.Match) -> str:
        inner = match.group(1).strip()
        setting_name = inner.split(",")[0].strip()
        if setting_name in fallbacks:
            return str(fallbacks[setting_name])
        return match.group(0)

    return re.sub(r"\{(\w[\w\s,]*)\}", _replace, content)


# Bed calibration patterns (Klipper and Marlin)
_BED_CALIBRATION_PATTERNS = (
    re.compile(r"^\s*BED_MESH_CALIBRATE", re.IGNORECASE),
    re.compile(r"^\s*G29\b", re.IGNORECASE),
    re.compile(r"^\s*M420\s+S1\b", re.IGNORECASE),
)


def strip_bed_calibration_from_gcode(gcode_path: Path) -> bool:
    """
    Comment out bed calibration commands (BED_MESH_CALIBRATE, G29, M420 S1) in G-code.
    Default OFF — auto bed leveling can clog some printers.
    Returns True if any line was changed.
    """
    try:
        raw = gcode_path.read_text(encoding="utf-8")
    except OSError:
        return False

    lines = raw.splitlines(keepends=True)
    updated_lines: list[str] = []
    changed = False

    for line in lines:
        stripped = line.lstrip()
        if not stripped or stripped.startswith(";"):
            updated_lines.append(line)
            continue

        is_calibration = any(pat.search(line) for pat in _BED_CALIBRATION_PATTERNS)
        if is_calibration:
            indent = line[: len(line) - len(stripped)]
            commented = f"{indent}; [claw3d] Bed calibration disabled (default OFF): {stripped.rstrip()}\n"
            updated_lines.append(commented)
            changed = True
        else:
            updated_lines.append(line)

    if changed:
        gcode_path.write_text("".join(updated_lines), encoding="utf-8")
    return changed


def postprocess_gcode_file(gcode_path: Path, fallbacks: Optional[dict[str, Any]] = None) -> bool:
    """
    Post-process a G-code file: substitute any remaining placeholders.
    Returns True if any substitution was made.
    """
    try:
        content = gcode_path.read_text(encoding="utf-8")
    except Exception:
        return False

    if "{" not in content:
        return False

    updated = substitute_placeholders(content, fallbacks)
    if updated != content:
        gcode_path.write_text(updated, encoding="utf-8")
        return True
    return False
