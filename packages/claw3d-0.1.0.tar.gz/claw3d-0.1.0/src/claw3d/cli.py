"""claw3d CLI - convert, scale, slice, print, status, printers, config."""

import sys
from .commands import convert, preview, scale, slice_cmd, gcode_preview_cmd, print_cmd, config_cmd, setup_cmd, configure_cmd, search_cmd, fetch_cmd, dimensions_cmd, pack_cmd, queue_cmd, analyze_cmd, extract_frame_cmd, fit_check_cmd, find_cmd, rotate_cmd, stamp_cmd, doctor_cmd, model_status_cmd


def main() -> None:
    if len(sys.argv) < 2:
        _print_help()
        sys.exit(1)

    subcommand = sys.argv[1].lower()
    args = sys.argv[2:]

    if subcommand == "convert":
        sys.exit(convert.run(args))
    elif subcommand == "preview":
        sys.exit(preview.run(args))
    elif subcommand == "scale":
        sys.exit(scale.run(args))
    elif subcommand == "slice":
        sys.exit(slice_cmd.run(args))
    elif subcommand == "gcode-preview":
        sys.exit(gcode_preview_cmd.run(args))
    elif subcommand == "print":
        sys.exit(print_cmd.run(args))
    elif subcommand == "status":
        sys.exit(print_cmd.run_status(args))
    elif subcommand == "printers":
        sys.exit(print_cmd.run_printers(args))
    elif subcommand == "printer":
        sys.exit(config_cmd.run_printer(args))
    elif subcommand == "profile":
        sys.exit(config_cmd.run_profile(args))
    elif subcommand == "setup":
        sys.exit(setup_cmd.run(args))
    elif subcommand == "configure":
        sys.exit(configure_cmd.run(args))
    elif subcommand == "pause":
        sys.exit(print_cmd.run_pause(args))
    elif subcommand == "resume":
        sys.exit(print_cmd.run_resume(args))
    elif subcommand == "cancel":
        sys.exit(print_cmd.run_cancel(args))
    elif subcommand == "camera":
        sys.exit(print_cmd.run_camera(args))
    elif subcommand == "preheat":
        sys.exit(print_cmd.run_preheat(args))
    elif subcommand == "cooldown":
        sys.exit(print_cmd.run_cooldown(args))
    elif subcommand == "home":
        sys.exit(print_cmd.run_home(args))
    elif subcommand == "files":
        sys.exit(print_cmd.run_files(args))
    elif subcommand == "start":
        sys.exit(print_cmd.run_start(args))
    elif subcommand == "emergency-stop":
        sys.exit(print_cmd.run_emergency_stop(args))
    elif subcommand == "metadata":
        sys.exit(print_cmd.run_metadata(args))
    elif subcommand == "search":
        sys.exit(search_cmd.run(args))
    elif subcommand == "fetch":
        sys.exit(fetch_cmd.run(args))
    elif subcommand == "dimensions":
        sys.exit(dimensions_cmd.run(args))
    elif subcommand == "pack":
        sys.exit(pack_cmd.run(args))
    elif subcommand == "queue":
        sys.exit(queue_cmd.run(args))
    elif subcommand == "analyze":
        sys.exit(analyze_cmd.run(args))
    elif subcommand == "extract-frame":
        sys.exit(extract_frame_cmd.run(args))
    elif subcommand == "fit-check":
        sys.exit(fit_check_cmd.run(args))
    elif subcommand == "find":
        sys.exit(find_cmd.run(args))
    elif subcommand == "rotate":
        sys.exit(rotate_cmd.run(args))
    elif subcommand == "stamp-thumbnails":
        sys.exit(stamp_cmd.run(args))
    elif subcommand == "doctor":
        sys.exit(doctor_cmd.run(args))
    elif subcommand == "model-status":
        sys.exit(model_status_cmd.run(args))
    elif subcommand in ("-h", "--help", "help"):
        _print_help()
        sys.exit(0)
    else:
        print(f"Unknown command: {subcommand}", file=sys.stderr)
        _print_help()
        sys.exit(1)


def _print_help() -> None:
    print("""claw3d - Convert sketches/images to 3D models and print

Usage: claw3d <command> [options]

Commands:
  analyze   Classify user intent from an image (requires GEMINI_API_KEY)
  extract-frame  Extract best frame from video (requires ffmpeg; GEMINI_API_KEY for smart selection)
  convert   Turn sketch/image or text prompt into 3D model (GLB)
  preview   Render 360° turntable video of a 3D model (MP4)
  rotate    Rotate a 3D model (baked into file — permanent, cumulative)
  scale     Scale a 3D model
  dimensions Print bounding box (X Y Z mm) of a 3D model
  fit-check Check if a model fits in build volume (all 90° orientations); optionally pre-rotate
  pack      Arrange multi-part models on build plate (2mm spacing)
  queue     Print queue: add, list, next, clear (multi-plate jobs)
  find      Search Thingiverse and return only models verified to fit the printer
  search    Search 3D model directories (Thingiverse)
  fetch     Download 3D model from Thingiverse (URL or thing ID)
  slice     Slice 3D model to G-code (optionally generate 360° preview video)
  gcode-preview  Render 360° turntable video of G-code (body + supports in different colors)
  print     Upload G-code and start print on printer
  status    Show printer status (single or all)
  printers  List configured printers
  printer   Add/list/remove printers (claw3d printer add --name X --host IP --port P)
  profile   Create/list/clear profiles
  setup     Show configuration (slicer URL, default profile)
  configure Select AI provider and per-step models
  pause     Pause current print
  resume    Resume paused print
  cancel    Cancel current print
  camera    Get camera stream/snapshot URL
  preheat   Set extruder/bed temps before printing
  cooldown  Turn off heaters
  home      Home axes
  files     List gcode files on printer
  start     Start an already-uploaded file
  emergency-stop  Immediate halt (use sparingly)
  metadata  Get gcode file metadata (time, filament, etc)
  stamp-thumbnails  Stamp A/B/C option badges onto thumbnail images
  model-status  Show full status of a model (source, dimensions, slice config, files)
  doctor    Check system health (API keys, slicer, printers, ffmpeg)

Examples:
  claw3d convert --image sketch.png --prompt "a toy robot" --output model.glb
  claw3d slice --input model.glb --profile <profile_id> --output model.gcode
  claw3d slice -i model.glb --profile-from-3mf settings.3mf -o model.gcode
  claw3d printer add --name "Main" --host 192.168.1.100 --port 7125   # save printer for later
  claw3d print --gcode model.gcode [--printer main]   # uses default if configured
  claw3d status                    # all printers
  claw3d status --printer main      # one printer

Environment:
  FAL_API_KEY              Required for convert (when using FAL provider)
  GEMINI_API_KEY           Optional: enables analyze + smart extract-frame (Gemini 2.5 Flash)
  THINGIVERSE_ACCESS_TOKEN  For claw3d search/fetch (Thingiverse API)
  CLAW3D_PROVIDER          Override provider (fal, replicate)
  CLAW3D_GEMINI_API_KEY    Override Gemini key (takes precedence over GEMINI_API_KEY)
  CLAW3D_SLICER_URL        Slicing API (default: http://localhost:8000)
  CLAW3D_PRINTER           Default printer (host:port or id:host:port)
  CLAW3D_PRINTERS          JSON {"id": "host:port", ...} for multiple printers
""")


if __name__ == "__main__":
    main()
