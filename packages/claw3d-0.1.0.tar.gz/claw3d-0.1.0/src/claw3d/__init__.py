"""claw3d - CLI for sketch/image → 3D model → slice → print."""

__version__ = "0.1.0"
