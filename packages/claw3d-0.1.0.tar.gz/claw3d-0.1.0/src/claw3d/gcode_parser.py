"""Parse CuraEngine G-code for visualization (body vs supports).

G-code type classification:
- ;TYPE: comments (Cura: ;TYPE:WALL-OUTER, ;TYPE:SUPPORT, etc.)
- E values to distinguish extrusion from travel (only extrusion is rendered)
- Support = SUPPORT, BRIM, SKIRT, RAFT
- Body = WALL, PERIMETER, OUTER, INNER, FILL, INFILL, SKIN, other
- Travel moves are never included (de <= 0 or G0)
"""

from __future__ import annotations

from pathlib import Path


def _parse_float(s: str) -> float | None:
    try:
        return float(s.strip())
    except ValueError:
        return None


def _gcode_to_render_coords(x: float, y: float, z: float) -> tuple[float, float, float]:
    """Convert G-code coords (X=right, Y=back, Z=up) to pyrender (X, Y-up, Z)."""
    # Coordinate transform: X→X, Z→Y (height), Y→-Z
    return (x, z, -y)


def parse_gcode(
    path: Path | str,
    *,
    sample_rate: int = 2,
) -> tuple[list[tuple[tuple[float, float, float], tuple[float, float, float]]], list[tuple[tuple[float, float, float], tuple[float, float, float]]]]:
    """Parse G-code file, return (body_segments, support_segments).

    Each segment is ((start_x, start_y, start_z), (end_x, end_y, end_z))
    in pyrender coords (Y-up).
    """
    path = Path(path)
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    body_segments: list[tuple[tuple[float, float, float], tuple[float, float, float]]] = []
    support_segments: list[tuple[tuple[float, float, float], tuple[float, float, float]]] = []

    pos = [0.0, 0.0, 0.0]
    last_e = 0.0
    extruder_absolute = True
    current_is_support = False
    sample_counter = 0

    for line in lines:
        trimmed = line.strip()

        # ;TYPE: comments — CuraEngine type classification
        # Support = SUPPORT, BRIM, SKIRT, RAFT (grouped together)
        # Body = WALL, PERIMETER, OUTER, INNER, FILL, INFILL, SKIN, other
        if trimmed.upper().startswith(";TYPE:"):
            type_str = trimmed[6:].upper()
            if any(k in type_str for k in ("SUPPORT", "BRIM", "SKIRT", "RAFT")):
                current_is_support = True
            elif any(k in type_str for k in ("WALL", "PERIMETER", "OUTER", "INNER", "FILL", "INFILL", "SKIN")):
                current_is_support = False
            else:
                current_is_support = False  # other → body
            continue

        if trimmed.startswith(";"):
            continue

        if trimmed == "M82":
            extruder_absolute = True
            continue
        if trimmed == "M83":
            extruder_absolute = False
            continue

        # G0/G00 = travel (no extrusion). G1/G01 = linear move (may extrude).
        if not (
            trimmed.startswith("G0 ") or trimmed.startswith("G00 ")
            or trimmed.startswith("G1 ") or trimmed.startswith("G01 ")
        ):
            continue

        is_g0 = trimmed.startswith("G0 ") or trimmed.startswith("G00 ")
        parts = trimmed.split()

        new_x, new_y, new_z = pos[0], pos[1], pos[2]
        e_value: float | None = None

        for part in parts[1:]:
            if not part:
                continue
            c = part[0].upper()
            val = _parse_float(part[1:])
            if val is None:
                continue
            if c == "X":
                new_x = val
            elif c == "Y":
                new_y = val
            elif c == "Z":
                new_z = val
            elif c == "E":
                e_value = val

        dx = new_x - pos[0]
        dy = new_y - pos[1]
        dz = new_z - pos[2]
        dist = (dx * dx + dy * dy + dz * dz) ** 0.5
        if dist < 0.1:
            pos = [new_x, new_y, new_z]
            if e_value is not None and extruder_absolute:
                last_e = e_value
            continue

        de = 0.0
        if e_value is not None:
            de = e_value - last_e if extruder_absolute else e_value
            if extruder_absolute:
                last_e = e_value

        is_extrusion = not is_g0 and de > 0.0001
        if not is_extrusion:
            pos = [new_x, new_y, new_z]
            continue

        sample_counter += 1
        if sample_counter % sample_rate != 0:
            pos = [new_x, new_y, new_z]
            continue

        start = _gcode_to_render_coords(pos[0], pos[1], pos[2])
        end = _gcode_to_render_coords(new_x, new_y, new_z)
        seg = (start, end)

        if current_is_support:
            support_segments.append(seg)
        else:
            body_segments.append(seg)

        pos = [new_x, new_y, new_z]

    return (body_segments, support_segments)
