"""Build area visualization for 360° preview videos.

Adds a printer build plate (border + 10mm grid) and optional volume wireframe
to a pyrender scene. Matches gcode preview visual style: thin line-art look,
same colours as gcode_preview_cmd.py.

Coordinate system (Y-up, same as pyrender):
  - Build plate surface at Y = plate_y (default 0)
  - Build volume extends from Y=plate_y to Y=plate_y+build_h
  - Build plate centered at XZ = (0, 0), spans [-W/2, W/2] × [-D/2, D/2]
"""

from __future__ import annotations

import math
import numpy as np


# Colours — black beams (matches iOS app dark wireframe style)
PLATE_COLOR = np.array([0.05, 0.05, 0.05, 1.0], dtype=np.float32)
GRID_COLOR  = np.array([0.15, 0.15, 0.15, 1.0], dtype=np.float32)
WIRE_COLOR  = np.array([0.05, 0.05, 0.05, 1.0], dtype=np.float32)

# Cylinder radii — halved from previous values
BORDER_RADIUS = 1.0   # mm — plate perimeter (4 edges)
GRID_RADIUS   = 0.75  # mm — 10mm grid lines
WIRE_RADIUS_BASE = 1.0  # mm — volume wireframe edges


def _cylinder_between(
    a: np.ndarray,
    b: np.ndarray,
    radius: float,
) -> "trimesh.Trimesh":
    """Return a cylinder mesh from point a to point b."""
    import trimesh

    vec = b - a
    length = float(np.linalg.norm(vec))
    if length < 1e-6:
        return trimesh.Trimesh()

    cyl = trimesh.creation.cylinder(radius=radius, height=length, sections=6)
    # Cylinder is centered at origin along Z — rotate then translate to midpoint

    direction = vec / length
    z_axis = np.array([0.0, 0.0, 1.0])
    dot = float(np.dot(z_axis, direction))

    if dot < -0.999:
        rot = np.diag([-1.0, -1.0, 1.0])
    elif dot > 0.999:
        rot = np.eye(3)
    else:
        axis = np.cross(z_axis, direction)
        axis = axis / np.linalg.norm(axis)
        angle = math.acos(max(-1.0, min(1.0, dot)))
        K = np.array([
            [0.0, -axis[2], axis[1]],
            [axis[2], 0.0, -axis[0]],
            [-axis[1], axis[0], 0.0],
        ])
        rot = np.eye(3) + math.sin(angle) * K + (1 - math.cos(angle)) * (K @ K)

    R4 = np.eye(4)
    R4[:3, :3] = rot
    cyl.apply_transform(R4)

    T4 = np.eye(4)
    T4[:3, 3] = (a + b) / 2
    cyl.apply_transform(T4)
    return cyl


def _make_plate_border_mesh(build_w: float, build_d: float, plate_y: float) -> "trimesh.Trimesh | None":
    """4 thin cylinder edges forming the plate perimeter at plate_y."""
    import trimesh

    hw, hd = build_w / 2, build_d / 2
    y = plate_y
    corners = [
        np.array([-hw, y, -hd]),
        np.array([ hw, y, -hd]),
        np.array([ hw, y,  hd]),
        np.array([-hw, y,  hd]),
    ]
    meshes = []
    for i in range(4):
        m = _cylinder_between(corners[i], corners[(i + 1) % 4], BORDER_RADIUS)
        if len(m.vertices) > 0:
            meshes.append(m)
    if not meshes:
        return None
    return trimesh.util.concatenate(meshes)


def _make_grid_mesh(build_w: float, build_d: float, plate_y: float) -> "trimesh.Trimesh | None":
    """10mm grid lines on the build plate surface (thin cylinders)."""
    import trimesh

    grid_y = plate_y + BORDER_RADIUS  # sit grid lines just above plate level

    # Auto-scale step: double until ≤20 lines per axis for readability
    step = 10.0
    while (build_w / step) > 20 or (build_d / step) > 20:
        step *= 2.0

    hw, hd = build_w / 2, build_d / 2
    meshes = []

    for x in list(np.arange(-hw, hw + 0.001, step)):
        m = _cylinder_between(
            np.array([x, grid_y, -hd]),
            np.array([x, grid_y,  hd]),
            GRID_RADIUS,
        )
        if len(m.vertices) > 0:
            meshes.append(m)

    for z in list(np.arange(-hd, hd + 0.001, step)):
        m = _cylinder_between(
            np.array([-hw, grid_y, z]),
            np.array([ hw, grid_y, z]),
            GRID_RADIUS,
        )
        if len(m.vertices) > 0:
            meshes.append(m)

    if not meshes:
        return None
    return trimesh.util.concatenate(meshes)


def _make_wireframe_mesh(
    build_w: float,
    build_d: float,
    build_h: float,
    plate_y: float,
) -> "trimesh.Trimesh | None":
    """12 cylinder edges forming the build volume wireframe box."""
    import trimesh

    wire_radius = max(WIRE_RADIUS_BASE, build_h * 0.004)
    hw, hd = build_w / 2, build_d / 2
    x0, x1 = -hw, hw
    y0, y1 = plate_y, plate_y + build_h
    z0, z1 = -hd, hd

    corners_bottom = [
        np.array([x0, y0, z0]), np.array([x1, y0, z0]),
        np.array([x1, y0, z1]), np.array([x0, y0, z1]),
    ]
    corners_top = [
        np.array([x0, y1, z0]), np.array([x1, y1, z0]),
        np.array([x1, y1, z1]), np.array([x0, y1, z1]),
    ]

    edges = (
        [(corners_bottom[i], corners_bottom[(i + 1) % 4]) for i in range(4)] +
        [(corners_top[i],    corners_top[(i + 1) % 4])    for i in range(4)] +
        [(corners_bottom[i], corners_top[i])               for i in range(4)]
    )

    meshes = []
    for a, b in edges:
        m = _cylinder_between(a, b, wire_radius)
        if len(m.vertices) > 0:
            meshes.append(m)

    if not meshes:
        return None
    return trimesh.util.concatenate(meshes)


def add_build_area(
    scene: "pyrender.Scene",
    build_w: float,
    build_d: float,
    build_h: float,
    plate_y: float = 0.0,
    show_volume_box: bool = True,
) -> None:
    """Add build plate border, grid, and optional volume wireframe to a pyrender scene."""
    import pyrender

    def _mesh_node(tm_mesh, color):
        mat = pyrender.MetallicRoughnessMaterial(
            baseColorFactor=color,
            metallicFactor=0.0,
            roughnessFactor=1.0,
            alphaMode="OPAQUE",
            doubleSided=True,
        )
        return pyrender.Mesh.from_trimesh(tm_mesh, material=mat)

    # Plate border (4 thin edge lines)
    border = _make_plate_border_mesh(build_w, build_d, plate_y)
    if border is not None:
        scene.add(_mesh_node(border, PLATE_COLOR))

    # Grid
    grid = _make_grid_mesh(build_w, build_d, plate_y)
    if grid is not None:
        scene.add(_mesh_node(grid, GRID_COLOR))

    # Volume wireframe
    if show_volume_box:
        wire = _make_wireframe_mesh(build_w, build_d, build_h, plate_y)
        if wire is not None:
            scene.add(_mesh_node(wire, WIRE_COLOR))


def parse_build_volume(s: str) -> tuple[float, float, float]:
    """Parse '350x350x350' → (width, depth, height) in mm. Raises ValueError on bad input."""
    parts = s.lower().replace("×", "x").split("x")
    if len(parts) != 3:
        raise ValueError(f"Expected WxDxH (e.g. 350x350x350), got: {s!r}")
    w, d, h = (float(p.strip()) for p in parts)
    if w <= 0 or d <= 0 or h <= 0:
        raise ValueError(f"Build volume dimensions must be positive, got: {s!r}")
    return w, d, h
