"""Multi-printer registry — orchestrate multiple 3D printers."""

from .base import PrinterBackend, PrinterStatus, PrinterState
from typing import Optional


class PrinterRegistry:
    """Registry of named printers for multi-printer orchestration."""

    def __init__(self) -> None:
        self._printers: dict[str, PrinterBackend] = {}

    def add(self, printer_id: str, backend: PrinterBackend) -> None:
        """Register a printer. Overwrites if id exists."""
        self._printers[printer_id] = backend

    def remove(self, printer_id: str) -> bool:
        """Remove a printer. Returns True if it existed."""
        if printer_id in self._printers:
            del self._printers[printer_id]
            return True
        return False

    def get(self, printer_id: str) -> Optional[PrinterBackend]:
        """Get backend for a printer, or None."""
        return self._printers.get(printer_id)

    def list_ids(self) -> list[str]:
        """List all registered printer ids."""
        return list(self._printers.keys())

    def get_status(self, printer_id: str) -> Optional[PrinterStatus]:
        """Get status for one printer. Returns None if printer not found or offline."""
        backend = self._printers.get(printer_id)
        if not backend:
            return None
        try:
            status = backend.get_status()
            status.printer_id = printer_id
            return status
        except Exception:
            return PrinterStatus(state=PrinterState.OFFLINE, printer_id=printer_id)

    def get_all_status(self) -> dict[str, PrinterStatus]:
        """Get status for all printers. Useful for orchestration dashboards."""
        result: dict[str, PrinterStatus] = {}
        for pid in self._printers:
            s = self.get_status(pid)
            if s:
                result[pid] = s
        return result

    def printers_busy(self) -> list[str]:
        """Ids of printers currently printing or paused."""
        return [
            pid
            for pid, status in self.get_all_status().items()
            if status.state in (PrinterState.PRINTING, PrinterState.PAUSED)
        ]

    def printers_idle(self) -> list[str]:
        """Ids of printers that are idle and ready for a job."""
        return [
            pid
            for pid, status in self.get_all_status().items()
            if status.state == PrinterState.IDLE
        ]
