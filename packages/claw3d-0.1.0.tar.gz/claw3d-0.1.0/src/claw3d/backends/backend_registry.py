"""3D printer backend registry — protocol abstraction (Moonraker, PrusaLink, etc.).

Each backend implements PrinterBackend. The registry provides metadata and
factory for creating backend instances. Community backends can register
via register_backend().
"""

from typing import Any, Callable, Optional

from .base import PrinterBackend


# Backend metadata: id, label, available, hint
BACKEND_INFO: dict[str, dict[str, Any]] = {
    "moonraker": {
        "id": "moonraker",
        "label": "Moonraker",
        "available": True,
        "hint": "Klipper/Fluidd/Mainsail. Default port 7125.",
    },
    "prusalink": {
        "id": "prusalink",
        "label": "PrusaLink",
        "available": False,
        "hint": "Coming soon",
    },
}


def _create_moonraker(host: str, port: int = 7125, **kwargs: Any) -> PrinterBackend:
    from .moonraker import MoonrakerBackend

    return MoonrakerBackend(host=host, port=port, **kwargs)


def _create_prusalink(host: str, port: int = 80, **kwargs: Any) -> PrinterBackend:
    from .prusalink import PrusaLinkBackend

    return PrusaLinkBackend(host=host, port=port, **kwargs)


# Factory: backend_id -> (host, port, **kwargs) -> PrinterBackend
BACKEND_FACTORIES: dict[str, Callable[..., PrinterBackend]] = {
    "moonraker": _create_moonraker,
    "prusalink": _create_prusalink,
}

# Default ports per backend
BACKEND_DEFAULT_PORTS: dict[str, int] = {
    "moonraker": 7125,
    "prusalink": 80,
}


def list_backends() -> list[dict[str, Any]]:
    """List all registered backends with metadata."""
    return [dict(b) for b in BACKEND_INFO.values()]


def get_available_backends() -> list[dict[str, Any]]:
    """List backends that are available (not coming soon)."""
    return [b for b in list_backends() if b.get("available")]


def get_backend_info(backend_id: str) -> Optional[dict[str, Any]]:
    """Get metadata for a backend."""
    return BACKEND_INFO.get(backend_id)


def is_backend_available(backend_id: str) -> bool:
    """True if backend is implemented and available."""
    return BACKEND_INFO.get(backend_id, {}).get("available", False)


def create_backend(
    backend_id: str,
    host: str,
    port: Optional[int] = None,
    **kwargs: Any,
) -> PrinterBackend:
    """Create a PrinterBackend instance. Uses default port if port omitted."""
    bid = backend_id.strip().lower()
    if bid not in BACKEND_FACTORIES:
        raise ValueError(
            f"Unknown backend '{backend_id}'. Available: {', '.join(BACKEND_FACTORIES.keys())}"
        )
    if port is None:
        port = BACKEND_DEFAULT_PORTS.get(bid, 7125)
    return BACKEND_FACTORIES[bid](host=host, port=port, **kwargs)


def register_backend(
    backend_id: str,
    factory: Callable[..., PrinterBackend],
    label: str,
    available: bool = True,
    hint: str = "",
    default_port: int = 7125,
) -> None:
    """Register a backend (for community extensions)."""
    BACKEND_INFO[backend_id] = {
        "id": backend_id,
        "label": label,
        "available": available,
        "hint": hint,
    }
    BACKEND_FACTORIES[backend_id] = factory
    BACKEND_DEFAULT_PORTS[backend_id] = default_port
