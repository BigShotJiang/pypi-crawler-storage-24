"""Abstract base for 3D printer backends.

Defines the standardized interface that all printer communication protocols
(Moonraker, PrusaLink, SDCP, Bambu, etc.) must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class PrinterState(str, Enum):
    """Printer state — normalized across all backends."""

    UNKNOWN = "unknown"
    IDLE = "idle"
    PRINTING = "printing"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    ERROR = "error"
    OFFLINE = "offline"


@dataclass
class PrinterStatus:
    """Normalized printer status — returned by all backends."""

    state: PrinterState
    printer_id: str = ""
    current_file: Optional[str] = None
    progress: float = 0.0  # 0–100
    print_duration: float = 0.0  # seconds
    print_duration_left: Optional[float] = None  # seconds, if estimable
    temperatures: dict[str, float] = field(default_factory=dict)  # e.g. {"extruder": 200, "bed": 60}
    camera_url: Optional[str] = None  # Snapshot/stream URL if available
    raw: Optional[dict[str, Any]] = None  # Backend-specific payload for debugging


@dataclass
class PrinterInfo:
    """Printer identity and capabilities."""

    printer_id: str
    backend: str  # e.g. "moonraker", "prusalink"
    name: Optional[str] = None
    connected: bool = True
    capabilities: set[str] = field(default_factory=set)  # e.g. {"camera", "pause", "preheat"})


class PrinterBackend(ABC):
    """Abstract base for printer communication backends.

    Implement this for Moonraker, PrusaLink, SDCP, Bambu, etc.
    """

    @property
    @abstractmethod
    def backend_id(self) -> str:
        """Unique id for this backend type (e.g. 'moonraker')."""
        ...

    @abstractmethod
    def print_file(self, gcode_path: Path, filename: Optional[str] = None) -> None:
        """Upload G-code and start print. Raises on failure."""
        ...

    def start_existing(self, filename: str) -> None:
        """Start an already-uploaded file by name. Raises if not supported."""
        raise NotImplementedError(f"{self.backend_id} does not support start_existing()")

    @abstractmethod
    def pause(self) -> None:
        """Pause the current print."""
        ...

    @abstractmethod
    def resume(self) -> None:
        """Resume a paused print."""
        ...

    @abstractmethod
    def cancel(self) -> None:
        """Cancel the current print."""
        ...

    @abstractmethod
    def get_status(self) -> PrinterStatus:
        """Return current printer status."""
        ...

    def get_info(self) -> PrinterInfo:
        """Return printer identity and capabilities. Override to customize."""
        return PrinterInfo(
            printer_id="",
            backend=self.backend_id,
            connected=True,
            capabilities={"pause", "resume", "cancel", "status"},
        )

    # Optional operations — subclasses override if supported

    def home(self, axes: Optional[list[str]] = None) -> None:
        """Home axes (e.g. ['x','y','z']). Default: all."""
        raise NotImplementedError(f"{self.backend_id} does not support home()")

    def preheat(self, extruder: Optional[float] = None, bed: Optional[float] = None) -> None:
        """Set target temperatures (Celsius)."""
        raise NotImplementedError(f"{self.backend_id} does not support preheat()")

    def cooldown(self) -> None:
        """Turn off heaters."""
        raise NotImplementedError(f"{self.backend_id} does not support cooldown()")

    def get_camera_url(self) -> Optional[str]:
        """Return camera snapshot or stream URL if available."""
        return None

    def list_files(self, path: str = "") -> list[dict[str, Any]]:
        """List files on printer storage. path is subdirectory (e.g. '' or 'gcodes/')."""
        raise NotImplementedError(f"{self.backend_id} does not support list_files()")

    def emergency_stop(self) -> None:
        """Immediate emergency stop. Use sparingly; puts printer in shutdown state."""
        raise NotImplementedError(f"{self.backend_id} does not support emergency_stop()")

    def get_file_metadata(self, filename: str) -> Optional[dict[str, Any]]:
        """Get gcode file metadata (estimated time, filament, etc). Returns None if not supported."""
        raise NotImplementedError(f"{self.backend_id} does not support get_file_metadata()")
