"""Moonraker backend — Klipper/Fluidd/Mainsail compatible printers."""

from pathlib import Path
from typing import Any, Optional
from urllib.parse import urljoin, quote

import requests

from .base import PrinterBackend, PrinterInfo, PrinterState, PrinterStatus


def _norm_state(raw: str) -> PrinterState:
    """Map Moonraker print_stats.state to PrinterState."""
    m = {
        "standby": PrinterState.IDLE,
        "printing": PrinterState.PRINTING,
        "paused": PrinterState.PAUSED,
        "complete": PrinterState.IDLE,
        "cancelled": PrinterState.CANCELLED,
        "error": PrinterState.ERROR,
    }
    return m.get(raw, PrinterState.UNKNOWN)


class MoonrakerBackend(PrinterBackend):
    """Moonraker (Klipper) backend. Supports camera stream/snapshot via server/webcams."""

    def __init__(self, host: str, port: int = 7125, use_https: bool = False) -> None:
        self.host = host
        self.port = port
        scheme = "https" if use_https else "http"
        self._base = f"{scheme}://{host}:{port}"
        self._timeout = 30
        self._upload_timeout = 900

    @property
    def backend_id(self) -> str:
        return "moonraker"

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        files: Optional[dict] = None,
        timeout: Optional[float] = None,
    ) -> requests.Response:
        url = f"{self._base}{path}"
        return requests.request(
            method,
            url,
            json=json,
            files=files,
            timeout=timeout or self._timeout,
        )

    def _get(self, path: str, timeout: Optional[float] = None) -> dict:
        r = self._request("GET", path, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, json: Optional[dict] = None, timeout: Optional[float] = None) -> Any:
        r = self._request("POST", path, json=json, timeout=timeout)
        r.raise_for_status()
        try:
            return r.json()
        except Exception:
            return r.text

    def print_file(self, gcode_path: Path, filename: Optional[str] = None) -> None:
        filename = filename or gcode_path.name
        gcode_data = gcode_path.read_bytes()

        url = f"{self._base}/server/files/upload"
        files = {"file": (filename, gcode_data, "application/octet-stream")}
        r = requests.post(url, files=files, timeout=self._upload_timeout)
        r.raise_for_status()

        self._start_print(filename)

    def start_existing(self, filename: str) -> None:
        """Start an already-uploaded file by name."""
        self._start_print(filename)

    def _start_print(self, filename: str) -> None:
        r2 = self._post("/printer/print/start", json={"filename": filename})
        # Moonraker may return "ok" (text) or {"result": "ok"} (JSON-RPC)
        if r2 != "ok" and (not isinstance(r2, dict) or r2.get("result") != "ok"):
            raise RuntimeError(f"Start print failed: {r2}")

    def pause(self) -> None:
        self._post("/printer/print/pause")

    def resume(self) -> None:
        self._post("/printer/print/resume")

    def cancel(self) -> None:
        self._post("/printer/print/cancel")

    def get_status(self) -> PrinterStatus:
        try:
            data = self._post(
                "/printer/objects/query",
                json={
                    "objects": {
                        "print_stats": None,
                        "virtual_sdcard": ["progress", "file_path", "file_position", "file_size"],
                        "extruder": ["temperature", "target"],
                        "heater_bed": ["temperature", "target"],
                    }
                },
            )
        except requests.RequestException as e:
            return PrinterStatus(
                state=PrinterState.OFFLINE,
                raw={"error": str(e)},
            )

        # Moonraker may return {"result": {"status": ...}} or {"status": ...}
        if isinstance(data, dict) and "result" in data and "status" in data["result"]:
            data = data["result"]
        status = data.get("status") or {}
        ps = status.get("print_stats") or {}
        vsd = status.get("virtual_sdcard") or {}
        ext = status.get("extruder") or {}
        bed = status.get("heater_bed") or {}

        state = _norm_state(ps.get("state", "standby"))
        filename = ps.get("filename") or vsd.get("file_path") or ""
        if filename and "/" in filename:
            filename = filename.split("/")[-1]

        progress = vsd.get("progress", 0.0) * 100.0
        print_duration = ps.get("print_duration") or 0.0
        total_duration = ps.get("total_duration") or 0.0
        duration_left: Optional[float] = None
        if progress > 0 and progress < 100 and print_duration > 0:
            # Rough estimate: (100 - progress) / progress * print_duration
            ratio = (100 - progress) / progress
            duration_left = print_duration * ratio

        temps: dict[str, float] = {}
        if ext:
            temps["extruder"] = ext.get("temperature", 0.0)
        if bed:
            temps["bed"] = bed.get("temperature", 0.0)

        camera_url = self.get_camera_url()

        return PrinterStatus(
            state=state,
            current_file=filename or None,
            progress=progress,
            print_duration=print_duration,
            print_duration_left=duration_left,
            temperatures=temps,
            camera_url=camera_url,
            raw=data,
        )

    def get_info(self) -> PrinterInfo:
        caps = {"pause", "resume", "cancel", "status", "home", "preheat", "cooldown", "camera", "list_files"}
        try:
            info = self._get("/server/info")
            klippy = info.get("klippy_state", "unknown")
            connected = info.get("klippy_connected", False) and klippy == "ready"
        except Exception:
            connected = False

        return PrinterInfo(
            printer_id="",
            backend=self.backend_id,
            name=f"{self.host}:{self.port}",
            connected=connected,
            capabilities=caps,
        )

    def home(self, axes: Optional[list[str]] = None) -> None:
        script = "G28"
        if axes:
            script = "G28 " + " ".join(a.upper() for a in axes)
        self._post("/printer/gcode/script", json={"script": script})

    def preheat(self, extruder: Optional[float] = None, bed: Optional[float] = None) -> None:
        parts: list[str] = []
        if extruder is not None:
            parts.append(f"M104 S{int(extruder)}")
        if bed is not None:
            parts.append(f"M140 S{int(bed)}")
        if not parts:
            return
        self._post("/printer/gcode/script", json={"script": "\n".join(parts)})

    def cooldown(self) -> None:
        self._post("/printer/gcode/script", json={"script": "TURN_OFF_HEATERS"})

    def get_camera_url(self) -> Optional[str]:
        """Return first enabled webcam's stream URL. Resolves relative paths against Moonraker host."""
        try:
            data = self._get("/server/webcams/list")
        except Exception:
            return None
        webcams = data.get("webcams") or []
        for w in webcams:
            if not w.get("enabled", True):
                continue
            stream = w.get("stream_url")
            snapshot = w.get("snapshot_url")
            url = stream or snapshot
            if not url:
                continue
            if url.startswith(("http://", "https://")):
                return url
            return urljoin(f"{self._base}/", url.lstrip("/"))
        return None

    def get_camera_snapshot_url(self) -> Optional[str]:
        """Return first enabled webcam's snapshot URL."""
        try:
            data = self._get("/server/webcams/list")
        except Exception:
            return None
        webcams = data.get("webcams") or []
        for w in webcams:
            if not w.get("enabled", True):
                continue
            url = w.get("snapshot_url")
            if not url:
                continue
            if url.startswith(("http://", "https://")):
                return url
            return urljoin(f"{self._base}/", url.lstrip("/"))
        return None

    def emergency_stop(self) -> None:
        self._post("/printer/emergency_stop")

    def get_file_metadata(self, filename: str) -> Optional[dict[str, Any]]:
        try:
            enc = quote(filename, safe="/")
            data = self._get(f"/server/files/metadata?filename={enc}")
            return data if isinstance(data, dict) else None
        except Exception:
            return None

    def list_files(self, path: str = "") -> list[dict[str, Any]]:
        """List gcode files. path is subdir under gcodes (e.g. '' = root, 'subfolder' = gcodes/subfolder)."""
        # Moonraker list returns files from root; use get_directory for a specific folder
        try:
            if path:
                data = self._get(f"/server/files/directory?path=gcodes/{path.rstrip('/')}&extended=false")
                items = (data.get("files") or []) + (data.get("dirs") or [])
                return [
                    {"path": f.get("filename") or f.get("dirname", ""), "size": f.get("size", 0), "modified": f.get("modified", 0)}
                    for f in items
                    if isinstance(f, dict)
                ]
            data = self._get("/server/files/list?root=gcodes")
        except Exception:
            return []
        # Response can be raw array or {"result": [...]}
        files = data if isinstance(data, list) else data.get("result", [])
        return [f for f in (files or []) if isinstance(f, dict)]
