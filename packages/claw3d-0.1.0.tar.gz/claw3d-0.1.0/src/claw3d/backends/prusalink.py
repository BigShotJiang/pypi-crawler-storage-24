"""PrusaLink backend — stub for future implementation.

Coming soon. PrusaLink is Prusa's native printer connectivity protocol.
This backend will support Prusa printers when implemented.
"""

from pathlib import Path
from typing import Any, Optional

from .base import PrinterBackend, PrinterInfo, PrinterState, PrinterStatus


COMING_SOON_MSG = (
    "PrusaLink backend is coming soon. Use Moonraker for Klipper printers. "
    "Run `claw3d configure backends` to see options."
)


class PrusaLinkBackend(PrinterBackend):
    """PrusaLink protocol — coming soon."""

    def __init__(self, host: str, port: int = 80, use_https: bool = False) -> None:
        self.host = host
        self.port = port
        self._use_https = use_https

    @property
    def backend_id(self) -> str:
        return "prusalink"

    def print_file(self, gcode_path: Path, filename: Optional[str] = None) -> None:
        raise NotImplementedError(COMING_SOON_MSG)

    def pause(self) -> None:
        raise NotImplementedError(COMING_SOON_MSG)

    def resume(self) -> None:
        raise NotImplementedError(COMING_SOON_MSG)

    def cancel(self) -> None:
        raise NotImplementedError(COMING_SOON_MSG)

    def get_status(self) -> PrinterStatus:
        raise NotImplementedError(COMING_SOON_MSG)

    def get_info(self) -> PrinterInfo:
        return PrinterInfo(
            printer_id="",
            backend=self.backend_id,
            name=f"{self.host}:{self.port}",
            connected=False,
            capabilities=set(),
        )
