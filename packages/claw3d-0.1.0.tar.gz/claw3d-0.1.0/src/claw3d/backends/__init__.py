"""3D printer backends — abstract interface and implementations.

Use PrinterRegistry to manage multiple printers. Protocols (Moonraker, PrusaLink)
implement PrinterBackend. Moonraker is recommended; PrusaLink coming soon.

Example:
    from claw3d.backends import PrinterRegistry, get_registry_from_env
    from claw3d.backends import create_backend

    registry = PrinterRegistry()
    registry.add("main", create_backend("moonraker", "192.168.1.100", 7125))
    status = registry.get_status("main")

    # Or load from config/env (CLAW3D_PRINTER, CLAW3D_PRINTERS)
    registry = get_registry_from_env()
"""

import json
import os

from .base import PrinterBackend, PrinterStatus, PrinterState
from .backend_registry import (
    create_backend,
    list_backends,
    get_available_backends,
    get_backend_info,
    is_backend_available,
)
from .moonraker import MoonrakerBackend
from .registry import PrinterRegistry


def parse_printer_address(addr: str, default_port: int = 7125) -> tuple[str, int]:
    """Parse 'host:port' or 'host'. Return (host, port)."""
    if ":" in addr:
        host, port_s = addr.rsplit(":", 1)
        return host.strip(), int(port_s)
    return addr.strip(), default_port


def create_moonraker_from_address(addr: str) -> MoonrakerBackend:
    """Create MoonrakerBackend from 'host:port' string. Kept for backward compat."""
    host, port = parse_printer_address(addr)
    return MoonrakerBackend(host=host, port=port)


def _create_backend_from_address(addr: str, backend_id: str = "moonraker") -> PrinterBackend:
    """Create backend from 'host:port' string. Uses backend default port if no port in addr."""
    from .backend_registry import BACKEND_DEFAULT_PORTS

    default_port = BACKEND_DEFAULT_PORTS.get(backend_id, 7125)
    host, port = parse_printer_address(addr, default_port=default_port)
    return create_backend(backend_id, host, port)


def get_registry_from_env() -> PrinterRegistry:
    """Build PrinterRegistry from config + CLAW3D_PRINTER and CLAW3D_PRINTERS env vars.

    Precedence: env vars override config file.
    Config: ~/.config/claw3d/config.json (printers with host, port, backend)
    CLAW3D_PRINTER: single default as 'host:port' or 'id:host:port'
    CLAW3D_PRINTERS: JSON {"id": "host:port", ...} or {"id": {"host", "port", "backend"}, ...}
    """
    registry = PrinterRegistry()

    # Load from config first
    try:
        from ..config import get_printers

        config_printers = get_printers()
        for pid, p in config_printers.items():
            if isinstance(p, dict):
                host = p.get("host", "")
                port = p.get("port")
                backend_id = (p.get("backend") or "moonraker").strip().lower()
                if not host:
                    continue
                if not is_backend_available(backend_id):
                    continue  # Skip coming-soon backends in config
                port = int(port) if port is not None else None
                try:
                    registry.add(pid, create_backend(backend_id, host, port))
                except Exception:
                    pass
    except Exception:
        pass

    # Env overrides (env always uses moonraker for backward compat)
    default = os.environ.get("CLAW3D_PRINTER")
    if default:
        parts = default.split(":", 2)
        if len(parts) == 3:
            pid, host, port_s = parts
            registry.add(pid, MoonrakerBackend(host=host.strip(), port=int(port_s)))
        else:
            registry.add("default", create_moonraker_from_address(default))

    printers_json = os.environ.get("CLAW3D_PRINTERS")
    if printers_json:
        try:
            printers = json.loads(printers_json)
            if isinstance(printers, dict):
                for pid, val in printers.items():
                    if isinstance(val, str):
                        registry.add(pid, create_moonraker_from_address(val))
                    elif isinstance(val, dict) and val.get("host"):
                        backend_id = (val.get("backend") or "moonraker").strip().lower()
                        if is_backend_available(backend_id):
                            registry.add(
                                pid,
                                create_backend(
                                    backend_id,
                                    val["host"],
                                    val.get("port"),
                                ),
                            )
        except json.JSONDecodeError:
            pass

    return registry


__all__ = [
    "PrinterBackend",
    "PrinterStatus",
    "PrinterState",
    "PrinterRegistry",
    "MoonrakerBackend",
    "create_backend",
    "list_backends",
    "get_available_backends",
    "get_backend_info",
    "is_backend_available",
    "get_registry_from_env",
    "create_moonraker_from_address",
]
