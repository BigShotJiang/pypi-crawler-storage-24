"""Persistent config for printers, slicer URL, and default profile.

Config file: ~/.config/claw3d/config.json (or CLAW3D_CONFIG_PATH)
"""

import json
import os
from pathlib import Path
from typing import Any, Optional

# XDG-compliant default
_DEFAULT_CONFIG_DIR = Path.home() / ".config" / "claw3d"
_DEFAULT_CONFIG_PATH = _DEFAULT_CONFIG_DIR / "config.json"


def _get_config_path() -> Path:
    env_path = os.environ.get("CLAW3D_CONFIG_PATH")
    if env_path:
        return Path(env_path).expanduser()
    return _DEFAULT_CONFIG_PATH


def load_config() -> dict[str, Any]:
    """Load config from disk. Returns empty dict if not found or invalid."""
    path = _get_config_path()
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_config(data: dict[str, Any]) -> None:
    """Save config to disk."""
    path = _get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_printers() -> dict[str, dict[str, Any]]:
    """Get printers from config. Returns {id: {host, port}}."""
    cfg = load_config()
    return cfg.get("printers") or {}


def set_printers(printers: dict[str, dict[str, Any]]) -> None:
    """Save printers to config."""
    cfg = load_config()
    cfg["printers"] = printers
    save_config(cfg)


def get_default_printer() -> Optional[str]:
    """Get default printer ID from config."""
    cfg = load_config()
    return cfg.get("default_printer")


def set_default_printer(printer_id: Optional[str]) -> None:
    """Set default printer ID."""
    cfg = load_config()
    cfg["default_printer"] = printer_id
    save_config(cfg)


def get_default_printer_build_volume() -> "Optional[tuple[float, float, float]]":
    """Get build volume (W, D, H in mm) from the default printer config, or None if not set.

    Falls back to the only configured printer when no explicit default is set.
    """
    printers = get_printers()
    default_id = get_default_printer()
    if not default_id and len(printers) == 1:
        default_id = next(iter(printers))
    if not default_id or default_id not in printers:
        return None
    p = printers[default_id]
    bw, bd, bh = p.get("build_width"), p.get("build_depth"), p.get("build_height")
    if bw and bd and bh:
        try:
            return float(bw), float(bd), float(bh)
        except (ValueError, TypeError):
            return None
    return None


def get_slicer_url() -> Optional[str]:
    """Get slicer URL from config."""
    cfg = load_config()
    return cfg.get("slicer_url")


def set_slicer_url(url: Optional[str]) -> None:
    """Set slicer URL in config."""
    cfg = load_config()
    cfg["slicer_url"] = url
    save_config(cfg)


def get_default_profile() -> Optional[str]:
    """Get default slicing profile ID from config."""
    cfg = load_config()
    return cfg.get("default_profile")


def set_default_profile(profile_id: Optional[str]) -> None:
    """Set default slicing profile ID."""
    cfg = load_config()
    cfg["default_profile"] = profile_id
    save_config(cfg)


def get_ai_provider() -> Optional[str]:
    """Get configured AI provider (e.g. 'fal', 'replicate')."""
    cfg = load_config()
    return (cfg.get("provider") or cfg.get("ai_provider") or "").strip() or None


def set_ai_provider(provider_id: Optional[str]) -> None:
    """Set AI provider (e.g. 'fal', 'replicate')."""
    cfg = load_config()
    if provider_id:
        cfg["provider"] = provider_id.strip().lower()
    else:
        cfg.pop("provider", None)
        cfg.pop("ai_provider", None)
    save_config(cfg)


def get_models() -> dict[str, str]:
    """Get model overrides per step from config."""
    cfg = load_config()
    models = cfg.get("models") or cfg.get("ai_models") or {}
    return dict(models) if isinstance(models, dict) else {}


def set_models(models: dict[str, str]) -> None:
    """Set model overrides per step (e.g. {'sketch_enhance': 'flux2_pro_edit'})."""
    cfg = load_config()
    cfg["models"] = {k: str(v) for k, v in models.items() if v}
    save_config(cfg)


def set_model_for_step(step_key: str, model_id: str) -> None:
    """Set model for a single step."""
    models = get_models()
    models[step_key] = model_id
    set_models(models)


def get_gemini_api_key() -> Optional[str]:
    """Get Gemini API key for analysis commands.

    Checked in order:
      1. CLAW3D_GEMINI_API_KEY env var
      2. GEMINI_API_KEY env var
      3. GOOGLE_API_KEY env var
      4. gemini_api_key in config file
    """
    import os
    key = (
        os.environ.get("CLAW3D_GEMINI_API_KEY")
        or os.environ.get("GEMINI_API_KEY")
        or os.environ.get("GOOGLE_API_KEY")
    )
    if key:
        return key.strip() or None
    cfg = load_config()
    return cfg.get("gemini_api_key") or None


def set_gemini_api_key(key: Optional[str]) -> None:
    """Store Gemini API key in config file."""
    cfg = load_config()
    if key:
        cfg["gemini_api_key"] = key.strip()
    else:
        cfg.pop("gemini_api_key", None)
    save_config(cfg)


def get_analysis_mode() -> str:
    """Get analysis mode: 'auto' | 'native' | 'gemini'.

    auto   (default) — use Gemini if GEMINI_API_KEY is set, else native
    native           — always use the skill agent's own reasoning (no Gemini call)
    gemini           — require Gemini; error if key not configured
    """
    cfg = load_config()
    mode = cfg.get("analysis_mode", "auto").strip().lower()
    return mode if mode in ("auto", "native", "gemini") else "auto"


def set_analysis_mode(mode: str) -> None:
    """Set analysis mode: 'auto', 'native', or 'gemini'."""
    if mode not in ("auto", "native", "gemini"):
        raise ValueError(f"Invalid analysis mode: {mode!r}. Choose: auto, native, gemini")
    cfg = load_config()
    cfg["analysis_mode"] = mode
    save_config(cfg)


