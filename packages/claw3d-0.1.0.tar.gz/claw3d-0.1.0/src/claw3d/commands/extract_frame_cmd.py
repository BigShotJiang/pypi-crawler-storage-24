"""claw3d extract-frame — Extract the best frame from a video for 3D model creation.

Two modes:
  Smart (GEMINI_API_KEY configured):
    1. Upload video to Gemini File API
    2. Ask Gemini to identify the best frame timestamp (clearest view of the subject)
    3. Use ffmpeg to extract that exact frame
    4. Delete video from Gemini (privacy)

  Basic (no API key, or --no-gemini):
    Extract the frame at the midpoint of the video using ffmpeg.

Outputs (stdout):
  Line 1: absolute path to extracted frame image
  Line 2 (stderr): subject description (if Gemini used)

Requires: ffmpeg on PATH (or set FFMPEG_PATH)
Optional: GEMINI_API_KEY for smart frame selection
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

# ─── Gemini system prompt for hero-frame selection ───────────────────────────

_VIDEO_SYSTEM_PROMPT = """\
You are analyzing a short video (typically 5-60 seconds) to find the single best
frame for 3D model creation.

The ideal frame:
- Shows the subject clearly, fully in frame, well-lit
- Has the most informative angle (front 3/4 view is often best)
- Is not blurry, not occluded, not transitioning

Return a JSON object:
{
  "hero_shot_timestamp": "<HH:MM:SS>",
  "subject": "<what is the main subject of this video>",
  "description": "<one sentence describing the best frame>"
}

If the video is very short (< 5s), return timestamp "00:00:01".
"""


def _find_ffmpeg() -> str | None:
    path = os.environ.get("FFMPEG_PATH")
    if path and os.path.isfile(path):
        return path
    return shutil.which("ffmpeg")


def _get_video_duration(ffmpeg: str, video_path: Path) -> float | None:
    """Get video duration in seconds using ffprobe."""
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        # Try ffprobe next to ffmpeg
        ffprobe = str(Path(ffmpeg).parent / "ffprobe")
        if not Path(ffprobe).exists():
            ffprobe = None
    if not ffprobe:
        return None
    try:
        r = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)],
            capture_output=True, text=True, timeout=15,
        )
        return float(r.stdout.strip())
    except Exception:
        return None


def _extract_frame_at(ffmpeg: str, video_path: Path, timestamp: str, output_path: Path) -> bool:
    """Extract a single frame at timestamp (HH:MM:SS or seconds) using ffmpeg."""
    cmd = [
        ffmpeg, "-y", "-ss", timestamp,
        "-i", str(video_path),
        "-frames:v", "1",
        "-q:v", "2",  # JPEG quality (2 = high)
        str(output_path),
    ]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=30)
        return r.returncode == 0 and output_path.exists() and output_path.stat().st_size > 0
    except Exception:
        return False


def _normalize_timestamp(ts: str, duration_sec: float | None = None) -> str:
    """Normalize HH:MM:SS, cap at video duration - 1s."""
    parts = ts.strip().split(":")
    try:
        if len(parts) == 3:
            total = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
        elif len(parts) == 2:
            total = int(parts[0]) * 60 + int(parts[1])
        else:
            total = int(parts[0])
    except ValueError:
        total = 5

    if duration_sec and total >= duration_sec:
        # Gemini sometimes returns out-of-range timestamps
        total = max(0, int(duration_sec) - 2)

    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _smart_extract(
    api_key: str,
    video_path: Path,
    output_path: Path,
    ffmpeg: str,
) -> tuple[bool, str | None]:
    """Gemini-powered frame extraction. Returns (success, subject_description)."""
    from ..gemini_client import upload_video, call_json, delete_video, GeminiError

    ext = video_path.suffix.lower()
    mime = {"mov": "video/quicktime", "webm": "video/webm", "avi": "video/avi"}.get(
        ext.lstrip("."), "video/mp4"
    )

    file_uri = None
    try:
        print("[extract-frame] Uploading video to Gemini File API...", file=sys.stderr)
        file_uri = upload_video(api_key, video_path, mime)

        duration_sec = _get_video_duration(ffmpeg, video_path)
        user_parts = [
            {"file_data": {"file_uri": file_uri, "mime_type": mime}},
            {"text": "Identify the best frame for 3D model creation."},
        ]

        print("[extract-frame] Asking Gemini for best frame...", file=sys.stderr)
        result = call_json(api_key, _VIDEO_SYSTEM_PROMPT, user_parts)

        raw_ts = str(result.get("hero_shot_timestamp", "00:00:05"))
        timestamp = _normalize_timestamp(raw_ts, duration_sec)
        subject = result.get("subject") or result.get("description") or None

        print(f"[extract-frame] Best frame at {timestamp} — {subject}", file=sys.stderr)

        ok = _extract_frame_at(ffmpeg, video_path, timestamp, output_path)
        return ok, subject

    except GeminiError as e:
        print(f"[extract-frame] Gemini error: {e} — falling back to midpoint", file=sys.stderr)
        return False, None
    finally:
        if file_uri:
            delete_video(api_key, file_uri)


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d extract-frame",
        description="Extract the best frame from a video for 3D model creation.",
    )
    parser.add_argument("--input", "-i", required=True, help="Input video file")
    parser.add_argument("--output", "-o", default=None, help="Output image path (default: input_frame.jpg)")
    parser.add_argument(
        "--timestamp", "-t", default=None,
        help="Override: extract frame at this timestamp (HH:MM:SS). Skips Gemini.",
    )
    parser.add_argument(
        "--no-gemini", action="store_true",
        help="Skip Gemini; always extract midpoint frame.",
    )
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    if not inp.exists():
        print(f"Error: Video not found: {inp}", file=sys.stderr)
        return 1

    out = Path(parsed.output) if parsed.output else inp.with_stem(inp.stem + "_frame").with_suffix(".jpg")
    out.parent.mkdir(parents=True, exist_ok=True)

    ffmpeg = _find_ffmpeg()
    if not ffmpeg:
        print(
            "Error: ffmpeg not found. Install it: apt install ffmpeg  OR  brew install ffmpeg",
            file=sys.stderr,
        )
        print("Set FFMPEG_PATH env var if installed in a non-standard location.", file=sys.stderr)
        return 1

    # Manual timestamp override — just extract and done
    if parsed.timestamp:
        ok = _extract_frame_at(ffmpeg, inp, parsed.timestamp, out)
        if not ok:
            print(f"Error: ffmpeg failed to extract frame at {parsed.timestamp}", file=sys.stderr)
            return 1
        print(str(out))
        return 0

    # Try Gemini smart extraction
    if not parsed.no_gemini:
        from ..config import get_gemini_api_key
        api_key = get_gemini_api_key()
        if api_key:
            ok, subject = _smart_extract(api_key, inp, out, ffmpeg)
            if ok:
                print(str(out))
                if subject:
                    print(f"Subject: {subject}", file=sys.stderr)
                return 0
            # Gemini failed — no silent fallback
            print(
                "Error: Gemini frame selection failed and no --timestamp was provided.\n"
                "Use --timestamp HH:MM:SS to extract a specific frame, or check your Gemini API key.",
                file=sys.stderr,
            )
            return 1
        else:
            print(
                "Error: No --timestamp provided and no Gemini API key configured.\n"
                "The agent should analyze the video and pass --timestamp <HH:MM:SS>.\n"
                "If running manually: claw3d extract-frame --input <video> --timestamp 00:00:05\n"
                "To configure Gemini: claw3d configure analysis --gemini-api-key <KEY>",
                file=sys.stderr,
            )
            return 1

    # --no-gemini with no timestamp: also an error
    print(
        "Error: --no-gemini specified but no --timestamp provided.\n"
        "Use --timestamp HH:MM:SS to extract a specific frame.",
        file=sys.stderr,
    )
    return 1
