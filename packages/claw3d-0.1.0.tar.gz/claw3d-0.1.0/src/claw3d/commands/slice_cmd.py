"""Slice 3D model to G-code via remote slicing API."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import requests
from scipy.spatial.transform import Rotation

from ..config import get_default_profile, get_default_printer_build_volume
from .dimensions_cmd import _dimensions_path
from ..gcode_postprocess import postprocess_gcode_file, strip_bed_calibration_from_gcode


def _load_source_json(model_path: Path) -> dict | None:
    """Load .source.json sidecar for a model (if exists)."""
    src_path = model_path.with_suffix(".source.json")
    if src_path.exists():
        try:
            return json.loads(src_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _load_slice_config(model_path: Path) -> dict | None:
    """Load .slice_config.json sidecar (previous slice settings)."""
    cfg_path = model_path.with_suffix(".slice_config.json")
    if cfg_path.exists():
        try:
            return json.loads(cfg_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _save_slice_config(model_path: Path, config: dict) -> None:
    """Save .slice_config.json sidecar for re-slice reuse."""
    cfg_path = model_path.with_suffix(".slice_config.json")
    try:
        cfg_path.write_text(json.dumps(config, indent=2))
    except OSError:
        pass

# Strength presets — used when merging overrides
STRENGTH_PRESETS = {
    1: {"layer_height": 0.24, "infill_sparse_density": 5, "infill_pattern": "grid", "wall_line_count": 2, "top_layers": 4, "bottom_layers": 2},
    2: {"layer_height": 0.22, "infill_sparse_density": 10, "infill_pattern": "grid", "wall_line_count": 2, "top_layers": 5, "bottom_layers": 3},
    3: {"layer_height": 0.20, "infill_sparse_density": 25, "infill_pattern": "grid", "wall_line_count": 3, "top_layers": 6, "bottom_layers": 4},
    4: {"layer_height": 0.15, "infill_sparse_density": 50, "infill_pattern": "grid", "wall_line_count": 4, "top_layers": 7, "bottom_layers": 5},
    5: {"layer_height": 0.10, "infill_sparse_density": 90, "infill_pattern": "grid", "wall_line_count": 5, "top_layers": 8, "bottom_layers": 8},
}

QUALITY_PRESETS = {
    1: {"layer_height": 0.10},
    2: {"layer_height": 0.15},
    3: {"layer_height": 0.20},
    4: {"layer_height": 0.22},
    5: {"layer_height": 0.25},
}

# All stored GLBs are Z-up (AI GLBs baked at convert time, Thingiverse GLBs native from STL).
# No coordinate fix needed — GLBs arrive at the slicer already in Z-up slicer space.
GLB_COORDINATE_FIX_DEG = (0.0, 0.0, 0.0)  # (rotation_x, rotation_y, rotation_z)


def _ensure_3mf_filename(name: str) -> str:
    if name and name.lower().endswith(".3mf"):
        return name
    return (name or "settings").rstrip(".") + ".3mf"


def _create_profile_from_3mf_api(slicer_url: str, model_data: bytes, model_filename: str, name: str, nozzle_size: float = 0.4) -> str:
    """Create profile via HTTP API."""
    files = {"file_3mf": (_ensure_3mf_filename(model_filename), model_data, "model/3mf")}
    data = {"name": name, "nozzle_size": str(nozzle_size)}
    r = requests.post(f"{slicer_url}/profiles/from-3mf", files=files, data=data, timeout=120)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Profile from 3MF failed ({r.status_code}): {r.text[:500]}")
    resp = r.json()
    profile_id = resp.get("id")
    if not profile_id:
        raise RuntimeError("No profile id in response")
    return profile_id


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d slice")
    parser.add_argument("--input", "-i", required=True, help="Input 3D file (GLB, STL, OBJ, 3MF)")
    parser.add_argument("--output", "-o", required=True, help="Output G-code path")
    parser.add_argument("--profile", "-p", default=None, help="Slicing profile ID")
    parser.add_argument("--profile-from-3mf", default=None, help="Create profile from this 3MF and slice")
    parser.add_argument("--profile-name", default=None, help="Profile name when creating from 3MF")
    parser.add_argument("--nozzle-size", type=float, default=0.4, help="Nozzle size (mm) when creating from 3MF")
    parser.add_argument("--strength", "-s", type=int, default=3, choices=[1, 2, 3, 4, 5])
    parser.add_argument("--quality", "-q", type=int, default=None, choices=[1, 2, 3, 4, 5])
    parser.add_argument("--slicer-url", default=None, help="Slicing API URL (remote mode only)")
    parser.add_argument("--max-dimension", type=float, default=None, help="Max dimension in mm (default 100 for GLB — AI models are often normalized)")
    parser.add_argument(
        "--max-from-model",
        action="store_true",
        help="Use max from model.glb.dimensions.json (from claw3d dimensions). Use for 3d-directory models.",
    )
    parser.add_argument("--rotation-x", type=float, default=0)
    parser.add_argument("--rotation-y", type=float, default=0)
    parser.add_argument("--rotation-z", type=float, default=0)
    parser.add_argument(
        "--no-mesh-clean",
        action="store_true",
        default=False,
        help="Disable all mesh cleaning/repair during GLB→STL conversion (use for directory/Thingiverse models)",
    )
    parser.add_argument("--bed-autocalibration", action="store_true")
    parser.add_argument("--layer-height", type=float, default=None)
    parser.add_argument("--infill-density", type=float, default=None)
    parser.add_argument("--infill-pattern", default=None)
    parser.add_argument("--wall-line-count", type=int, default=None)
    parser.add_argument("--top-layers", type=int, default=None)
    parser.add_argument("--bottom-layers", type=int, default=None)
    parser.add_argument(
        "--preview-video",
        action="store_true",
        default=True,
        help="Generate 360° G-code preview video (body + supports) after slice. Default: True.",
    )
    parser.add_argument("--no-preview-video", action="store_false", dest="preview_video")
    parser.add_argument(
        "--build-volume", default=None,
        metavar="WxDxH",
        help="Printer build volume in mm (e.g. 350x350x350). Passed to gcode-preview to show build plate.",
    )
    parsed = parser.parse_args(args)

    # Resolve build volume: explicit flag > default printer config
    build_volume_str = parsed.build_volume
    if not build_volume_str:
        from ..config import get_default_printer_build_volume
        cfg_vol = get_default_printer_build_volume()
        if cfg_vol:
            build_volume_str = f"{cfg_vol[0]:.0f}x{cfg_vol[1]:.0f}x{cfg_vol[2]:.0f}"
            print(f"Using default printer build volume: {build_volume_str}mm", file=sys.stderr)

    # Remote API path
    slicer_url = (
        parsed.slicer_url
        or os.environ.get("CLAW3D_SLICER_URL")
        or "http://localhost:8000"
    ).rstrip("/")

    inp = Path(parsed.input)
    out = Path(parsed.output)
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1
    out.parent.mkdir(parents=True, exist_ok=True)

    max_dim = parsed.max_dimension
    if parsed.max_from_model:
        dim_path = _dimensions_path(inp)
        if not dim_path.exists():
            print(
                f"Error: No dimensions file at {dim_path}. Run 'claw3d dimensions -i {inp}' first (e.g. after fetch in 3d-directory).",
                file=sys.stderr,
            )
            return 1
        try:
            dims = json.loads(dim_path.read_text())
            max_dim = dims.get("max")
        except (json.JSONDecodeError, OSError) as e:
            print(f"Error: Could not read dimensions: {e}", file=sys.stderr)
            return 1
        if max_dim is None:
            print("Error: dimensions file has no 'max' field", file=sys.stderr)
            return 1

    model_data = inp.read_bytes()
    ext = inp.suffix.lower()
    if not ext and model_data[:4] == b"glTF":
        ext = ".glb"
    model_filename = inp.name if ext else inp.name + ".bin"

    profile_id = parsed.profile
    if not profile_id and parsed.profile_from_3mf:
        path_3mf = Path(parsed.profile_from_3mf)
        if not path_3mf.exists():
            print(f"Error: Profile 3MF not found: {path_3mf}", file=sys.stderr)
            return 1
        profile_name = parsed.profile_name or path_3mf.stem or "from_3mf"
        try:
            data_3mf = path_3mf.read_bytes()
            tmf_fn = path_3mf.name if path_3mf.suffix.lower() == ".3mf" else "settings.3mf"
            profile_id = _create_profile_from_3mf_api(slicer_url, data_3mf, tmf_fn, profile_name, parsed.nozzle_size)
            print(f"Created profile '{profile_id}' from {path_3mf.name}", file=sys.stderr)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    elif not profile_id and ext == ".3mf":
        profile_name = parsed.profile_name or inp.stem or "from_3mf"
        try:
            profile_id = _create_profile_from_3mf_api(slicer_url, model_data, model_filename, profile_name, parsed.nozzle_size)
            print(f"Created profile '{profile_id}' from 3MF settings", file=sys.stderr)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    elif not profile_id:
        profile_id = get_default_profile()
    if not profile_id:
        print("Error: --profile or --profile-from-3mf required. Or run: claw3d setup", file=sys.stderr)
        return 1

    # ── Source-based auto-routing ──────────────────────────────────────────
    # Read .source.json to auto-detect Thingiverse vs AI models.
    # This is deterministic — the agent doesn't need to remember or pass flags.
    source_info = _load_source_json(inp)
    is_thingiverse = (
        (source_info and source_info.get("source") == "thingiverse")
        or parsed.no_mesh_clean  # legacy manual flag
    )
    if is_thingiverse and not parsed.no_mesh_clean:
        parsed.no_mesh_clean = True
        print("Auto-detected Thingiverse model (from .source.json) — skipping mesh clean + scaling", file=sys.stderr)

    # ── Load previous slice config as defaults ─────────────────────────────
    prev_config = _load_slice_config(inp)

    if ext == ".glb":
        glb_fn = model_filename if model_filename.lower().endswith(".glb") else "model.glb"
        # AI-generated GLBs (FAL, Tripo, Hunyuan) use normalized coords; need explicit max_dim.
        # Thingiverse/directory GLBs are already at correct physical size — do NOT scale.
        # max_dim may have been set by --max-from-model above
        if max_dim is None:
            if is_thingiverse:
                pass  # keep None — no scaling for directory models
            elif prev_config and prev_config.get("max_dimension_mm"):
                # Reuse previous slice's max-dimension
                max_dim = prev_config["max_dimension_mm"]
                print(f"Reusing previous max-dimension: {max_dim}mm (from .slice_config.json)", file=sys.stderr)
            else:
                max_dim = parsed.max_dimension if parsed.max_dimension is not None else None
                if max_dim is None:
                    # Smart default: suggest from build volume
                    build_vol = get_default_printer_build_volume()
                    if build_vol:
                        suggested = min(build_vol) * 0.8
                        print(
                            f"Warning: No --max-dimension specified for AI model. "
                            f"Suggested: {suggested:.0f}mm (80% of printer's {min(build_vol):.0f}mm axis). "
                            f"Using 100mm default.",
                            file=sys.stderr,
                        )
                    max_dim = 100.0
        # GLBs are stored Z-up; GLB_COORDINATE_FIX_DEG=(0,0,0) — no fix needed.
        # Combine fix (identity) with any user rotation.
        rot_x, rot_y, rot_z = parsed.rotation_x, parsed.rotation_y, parsed.rotation_z
        r_fix = Rotation.from_euler("xyz", list(GLB_COORDINATE_FIX_DEG), degrees=True)
        if rot_x == 0 and rot_y == 0 and rot_z == 0:
            rot_x, rot_y, rot_z = GLB_COORDINATE_FIX_DEG
        else:
            r_user = Rotation.from_euler("xyz", [rot_x, rot_y, rot_z], degrees=True)
            r_combined = r_user * r_fix
            rot_x, rot_y, rot_z = r_combined.as_euler("xyz", degrees=True).tolist()
        files_conv = {"model": (glb_fn, model_data, "model/gltf-binary")}
        _clean = "false" if parsed.no_mesh_clean else "true"
        data_conv = {
            "max_dimension_mm": str(max_dim) if max_dim else "",
            "rotation_x": str(rot_x),
            "rotation_y": str(rot_y),
            "rotation_z": str(rot_z),
            "clean_mesh": _clean,
            "merge_vertices": _clean,
            "remove_degenerate": _clean,
            "remove_spaghetti": _clean,
            "repair_mesh": _clean,
            "smart_decimate": _clean,
        }
        r = requests.post(f"{slicer_url}/convert/glb-to-stl", files=files_conv, data=data_conv, timeout=120)
        if r.status_code != 200:
            print(f"Error: GLB conversion failed ({r.status_code})", file=sys.stderr)
            return 1
        model_data = r.content
        model_filename = inp.stem + ".stl"
    elif ext in (".stl", ".obj", ".3mf"):
        # Downloaded models (Thingiverse STL/3MF) — already Z-up, no coordinate fix needed.
        # Apply user rotation locally via trimesh if any rotation is specified.
        rot_x, rot_y, rot_z = parsed.rotation_x, parsed.rotation_y, parsed.rotation_z
        if rot_x != 0 or rot_y != 0 or rot_z != 0:
            try:
                import io
                import numpy as np
                import trimesh

                mesh = trimesh.load(io.BytesIO(model_data), file_type=ext.lstrip("."))
                if isinstance(mesh, trimesh.Scene):
                    mesh = mesh.dump(concatenate=True)
                R = trimesh.transformations.euler_matrix(
                    np.radians(rot_x), np.radians(rot_y), np.radians(rot_z), axes="rxyz"
                )
                mesh.apply_transform(R)
                # Normalize: translate so min bounds = (0, 0, 0).
                # Rotation can produce negative coordinates; CuraEngine expects non-negative Z.
                if mesh.bounds is not None:
                    mesh.vertices -= mesh.bounds[0]
                buf = io.BytesIO()
                mesh.export(buf, file_type="stl")
                model_data = buf.getvalue()
                model_filename = inp.stem + "_rotated.stl"
            except Exception as e:
                print(f"Error applying rotation to STL: {e}", file=sys.stderr)
                return 1

    merged = dict(STRENGTH_PRESETS[parsed.strength])
    if parsed.quality is not None:
        merged["layer_height"] = QUALITY_PRESETS[parsed.quality]["layer_height"]
    if parsed.layer_height is not None:
        merged["layer_height"] = parsed.layer_height
    if parsed.infill_density is not None:
        merged["infill_sparse_density"] = parsed.infill_density
    if parsed.infill_pattern is not None:
        merged["infill_pattern"] = parsed.infill_pattern
    if parsed.wall_line_count is not None:
        merged["wall_line_count"] = parsed.wall_line_count
    if parsed.top_layers is not None:
        merged["top_layers"] = parsed.top_layers
    if parsed.bottom_layers is not None:
        merged["bottom_layers"] = parsed.bottom_layers

    files = {"model": (model_filename, model_data, "application/octet-stream")}
    data = {
        "profile_id": profile_id,
        "layer_height": str(merged["layer_height"]),
        "infill_sparse_density": str(merged["infill_sparse_density"]),
        "infill_pattern": merged["infill_pattern"],
        "wall_line_count": str(merged["wall_line_count"]),
        "top_layers": str(merged["top_layers"]),
        "bottom_layers": str(merged["bottom_layers"]),
        "gzip_output": "false",
        "run_bed_autocalibration": "true" if parsed.bed_autocalibration else "false",
    }
    t0_slice = time.perf_counter()
    r = requests.post(f"{slicer_url}/slice/start", files=files, data=data, timeout=60)
    if r.status_code not in (200, 202):
        print(f"Error: Slice start failed ({r.status_code})", file=sys.stderr)
        return 1
    job_id = r.json().get("job_id")
    if not job_id:
        print("Error: No job_id in response", file=sys.stderr)
        return 1

    for _ in range(120):  # 120 × 10s = 20 min max
        r = requests.get(f"{slicer_url}/slice/status/{job_id}", timeout=10)
        if r.status_code != 200:
            time.sleep(10)
            continue
        st = r.json()
        status = st.get("status", "")
        if status == "completed":
            break
        if status == "failed":
            print(f"Error: Slice failed: {st.get('error_message', 'unknown')}", file=sys.stderr)
            return 1
        time.sleep(10)
    else:
        print("Error: Slice timed out after 20 minutes", file=sys.stderr)
        return 1

    r = requests.get(f"{slicer_url}/slice/result/{job_id}", timeout=60)
    if r.status_code != 200:
        print(f"Error: Failed to get result ({r.status_code})", file=sys.stderr)
        return 1
    out.write_bytes(r.content)
    t_slice = time.perf_counter() - t0_slice
    print(f"[timing] Slicing: {t_slice:.1f}s", file=sys.stderr)

    if postprocess_gcode_file(out):
        print("Post-processed G-code placeholders", file=sys.stderr)
    if not parsed.bed_autocalibration and strip_bed_calibration_from_gcode(out):
        print("Disabled bed auto-calibration in G-code", file=sys.stderr)

    print(f"Wrote {out} ({len(r.content)} bytes)")

    # ── Save slice config sidecar for re-slice reuse ───────────────────────
    _save_slice_config(inp, {
        "max_dimension_mm": max_dim,
        "strength": parsed.strength,
        "quality": parsed.quality,
        "infill_density": parsed.infill_density,
        "layer_height": parsed.layer_height,
        "profile_id": profile_id,
        "no_mesh_clean": parsed.no_mesh_clean,
        "build_volume": build_volume_str,
        "source": source_info.get("source") if source_info else None,
    })

    if parsed.preview_video:
        from . import gcode_preview_cmd

        t0_preview = time.perf_counter()
        preview_out = out.with_stem(out.stem + "_gcode_preview").with_suffix(".mp4")
        preview_args = ["--input", str(out), "--output", str(preview_out)]
        if build_volume_str:
            preview_args += ["--build-volume", build_volume_str]
        rc = gcode_preview_cmd.run(preview_args)
        t_preview = time.perf_counter() - t0_preview
        if rc == 0:
            print(f"G-code preview: {preview_out} [timing: {t_preview:.1f}s]", file=sys.stderr)

    return 0
