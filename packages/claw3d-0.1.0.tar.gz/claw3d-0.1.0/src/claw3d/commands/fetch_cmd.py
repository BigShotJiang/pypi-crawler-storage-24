"""claw3d fetch - download 3D model from Thingiverse."""

from __future__ import annotations

import argparse
import shutil
import sys
import tempfile
from pathlib import Path

from ..directory.fetch import (
    _thing_id_from_url,
    ensure_glb_for_preview,
    fetch_thingiverse,
    list_thingiverse_files,
    list_thingiverse_files_grouped,
)


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d fetch",
        description="Download a 3D model from Thingiverse by URL or thing ID",
    )
    parser.add_argument(
        "source",
        nargs="?",
        default=None,
        help="Thingiverse URL or thing ID (omit with --list-only)",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output path. Use .glb for preview/slice-ready. Required unless --list-only.",
    )
    parser.add_argument(
        "--list-only",
        "-l",
        action="store_true",
        help="List available model files (complete sets vs parts) without downloading",
    )
    parser.add_argument(
        "--list-grouped",
        "-g",
        action="store_true",
        help="List files grouped by extension priority (STL>OBJ>GLB>3MF) with sub-variant detection",
    )
    parser.add_argument(
        "--choose",
        "-c",
        metavar="PATTERN",
        help="Pick file(s) matching this substring (e.g. 'v_1_1', 'complete')",
    )
    parser.add_argument(
        "--as-glb",
        action="store_true",
        help="Force conversion to GLB (default when output ends with .glb)",
    )
    parsed = parser.parse_args(args)

    if not parsed.source:
        print("Error: source (URL or thing ID) required", file=sys.stderr)
        return 1

    thing_id = _thing_id_from_url(parsed.source)
    if not thing_id:
        thing_id = parsed.source.strip()
        if not thing_id.isdigit():
            print("Error: source must be a Thingiverse URL or numeric thing ID", file=sys.stderr)
            return 1

    if parsed.list_only:
        items = list_thingiverse_files(thing_id, token=None)
        if not items:
            print("Error: Could not list files (check THINGIVERSE_ACCESS_TOKEN)", file=sys.stderr)
            return 1
        complete = [i for i in items if i.get("is_complete_set")]
        parts = [i for i in items if not i.get("is_complete_set")]
        if complete:
            print("Complete / set files (preferred):")
            for i in complete:
                print(f"  • {i['name']}")
        if parts:
            print("Individual parts:" if complete else "Model files:")
            for i in parts:
                print(f"  • {i['name']}")
        return 0

    if parsed.list_grouped:
        result = list_thingiverse_files_grouped(thing_id, token=None)
        if not result:
            print("Error: Could not list files (check THINGIVERSE_ACCESS_TOKEN)", file=sys.stderr)
            return 1
        best_ext = result["best_ext"]
        best_group = result["best_group"]
        other_exts = [e for e in result["groups"] if e != best_ext]
        print(f"Best extension: {best_ext} ({len(best_group)} file(s))")
        for f in best_group:
            tags = []
            if f["is_complete_set"]:
                tags.append("complete-set")
            if f["variant_tag"]:
                tags.append(f"variant:{f['variant_tag']}")
            tag_str = f"  [{', '.join(tags)}]" if tags else ""
            print(f"  • {f['name']}{tag_str}")
        if result["has_sub_variants"]:
            print(f"\nSub-variants (size/version choices — pick one with --choose):")
            for f in result["sub_variants"]:
                print(f"  • {f['name']}  →  {f['variant_tag']}")
        elif result["has_cosmetic_variations"]:
            print(f"\nCosmetic variations (same model, minor differences — agent auto-selects best):")
            for grp in result["cosmetic_variation_groups"]:
                print(f"  Base: {grp['base']}")
                for f in grp["files"]:
                    mod = f.get("cosmetic_modifier")
                    mod_str = f"  [{mod}]" if mod else "  [base]"
                    arrow = "  <- auto-selected" if f["name"] == grp["auto_selected"]["name"] else ""
                    print(f"    * {f['name']}{mod_str}{arrow}")
            if result["parts_only"]:
                print(f"\nAdditional parts (needed alongside chosen variant):")
                for f in result["parts_only"]:
                    print(f"  • {f['name']}")
        elif len(result["parts_only"]) > 1:
            print(f"\nMulti-part model ({len(result['parts_only'])} components — download all and pack)")
        if other_exts:
            print(f"\nOther available extensions (lower priority): {', '.join(other_exts)}")
        return 0

    if not parsed.output:
        print("Error: -o/--output required", file=sys.stderr)
        return 1

    out = Path(parsed.output)
    if not out.suffix:
        out = out.with_suffix(".glb")
    wants_glb = parsed.as_glb or out.suffix.lower() == ".glb"

    # Fetch to temp dir so we get the original file with correct extension
    with tempfile.TemporaryDirectory() as td:
        tmp_dir = Path(td)
        written, is_multi = fetch_thingiverse(
            thing_id, tmp_dir, token=None, choose=parsed.choose
        )
        if not written:
            from ..directory.fetch import _get_token

            tok = _get_token()
            if not tok or not str(tok).strip():
                print(
                    "Error: THINGIVERSE_ACCESS_TOKEN is not set. Add it in OpenClaw Control UI → Skills → 3d-directory, "
                    "or set it in .env and restart the gateway.",
                    file=sys.stderr,
                )
            else:
                print(
                    "Error: Thingiverse API request failed (token is set). Check token validity at "
                    "https://www.thingiverse.com/apps/create. Run with CLAW3D_DEBUG=1 for details.",
                    file=sys.stderr,
                )
            return 1

        out.parent.mkdir(parents=True, exist_ok=True)

        if is_multi:
            # Multi-part: copy parts to output_parts/ for pack
            parts_dir = out.parent / (out.stem + "_parts")
            if parts_dir.exists():
                shutil.rmtree(parts_dir)
            shutil.copytree(written, parts_dir)
            n = len(list(parts_dir.glob("*")))
            print(
                f"Wrote {n} parts to {parts_dir}/. Run: claw3d pack -i {parts_dir} --build WxHxD -o {out}",
                file=sys.stderr,
            )
            print(f"Wrote {parts_dir}/ ({n} parts)")
            return 0

        if not written.exists():
            from ..directory.fetch import _get_token

            tok = _get_token()
            if not tok or not str(tok).strip():
                print("Error: THINGIVERSE_ACCESS_TOKEN is not set.", file=sys.stderr)
            else:
                print("Error: Thingiverse fetch failed.", file=sys.stderr)
            return 1

        if wants_glb:
            if not ensure_glb_for_preview(written, out):
                print("Error: Failed to convert to GLB.", file=sys.stderr)
                return 1
            # Save original format alongside GLB for slicing (no coord manipulation needed)
            orig_suffix = written.suffix.lower()
            orig_out = None
            if orig_suffix and orig_suffix != ".glb":
                orig_out = out.with_suffix(orig_suffix)
                shutil.copy2(written, orig_out)
                print(f"Saved original {orig_suffix} for slicing: {orig_out}", file=sys.stderr)
            # Auto-compute dimensions on the original STL so the agent always has size info
            if orig_out and orig_out.exists():
                try:
                    from .dimensions_cmd import run as _dim_run
                    _dim_run(["-i", str(orig_out)])
                except Exception as e:
                    print(f"Warning: Could not compute dimensions: {e}", file=sys.stderr)
        else:
            shutil.copy2(written, out)

        # Write provenance sidecar (enables deterministic slicing path selection)
        # Preserve fitting_rotation from previous source.json (from claw3d find)
        import json as _json
        from datetime import datetime, timezone
        prev_rotation = None
        prev_fitted_extents = None
        source_path = out.with_suffix(".source.json")
        if source_path.exists():
            try:
                prev = _json.loads(source_path.read_text())
                prev_rotation = prev.get("fitting_rotation")
                prev_fitted_extents = prev.get("fitted_extents_mm")
            except (ValueError, _json.JSONDecodeError, OSError):
                pass
        src = {
            "source": "thingiverse",
            "thing_id": thing_id,
            "url": f"https://www.thingiverse.com/thing:{thing_id}",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        if prev_rotation:
            src["fitting_rotation"] = prev_rotation
        if prev_fitted_extents:
            src["fitted_extents_mm"] = prev_fitted_extents
        try:
            source_path.write_text(_json.dumps(src, indent=2))
        except OSError:
            pass

    # Re-apply fitting rotation if a previous source.json has one stored
    # (happens when claw3d find already fit-checked and rotated, then user re-fetches a variant)
    import json as _json2
    existing_source = out.with_suffix(".source.json")
    if existing_source.exists():
        try:
            prev_src = _json2.loads(existing_source.read_text())
            rot = prev_src.get("fitting_rotation")
            if rot and isinstance(rot, list) and len(rot) == 3:
                frx, fry, frz = float(rot[0]), float(rot[1]), float(rot[2])
                if frx != 0 or fry != 0 or frz != 0:
                    from .fit_check_cmd import _apply_rotation_to_file
                    try:
                        _apply_rotation_to_file(out, frx, fry, frz)
                        print(f"Re-applied fitting rotation ({frx:.0f}°X {fry:.0f}°Y {frz:.0f}°Z) from previous fit-check", file=sys.stderr)
                        # Also rotate the STL sidecar if it exists
                        stl_sidecar = out.with_suffix(".stl")
                        if stl_sidecar.exists():
                            _apply_rotation_to_file(stl_sidecar, frx, fry, frz)
                            print(f"Re-applied rotation to sidecar: {stl_sidecar.name}", file=sys.stderr)
                    except Exception as e:
                        print(f"Warning: Could not re-apply fitting rotation: {e}", file=sys.stderr)
        except (ValueError, _json2.JSONDecodeError, OSError):
            pass

    size = out.stat().st_size
    print(f"Wrote {out} ({size} bytes)")
    return 0
