"""claw3d model-status — Show full status of a model and its sidecars."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _read_json(path: Path) -> dict | None:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _find_related_files(model_path: Path) -> dict[str, Path | None]:
    """Find all sidecar and derived files for a model."""
    stem = model_path.stem  # e.g. "model_660698"
    parent = model_path.parent

    def _find(suffix: str) -> Path | None:
        p = parent / f"{stem}{suffix}"
        return p if p.exists() else None

    return {
        "glb": _find(".glb"),
        "stl": _find(".stl"),
        "source_json": _find(".source.json"),
        "glb_dimensions": parent / f"{stem}.glb.dimensions.json" if (parent / f"{stem}.glb.dimensions.json").exists() else None,
        "stl_dimensions": parent / f"{stem}.stl.dimensions.json" if (parent / f"{stem}.stl.dimensions.json").exists() else None,
        "slice_config": _find(".slice_config.json"),
        "gcode": _find(".gcode"),
        "preview": parent / f"preview_{stem.replace('model_', '')}.mp4" if (parent / f"preview_{stem.replace('model_', '')}.mp4").exists() else None,
        "gcode_preview": _find("_gcode_preview.mp4"),
        "parts_dir": parent / f"{stem}_parts" if (parent / f"{stem}_parts").is_dir() else None,
    }


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d model-status",
        description="Show full status of a model and its sidecars.",
    )
    parser.add_argument("--input", "-i", required=True, help="Model file (GLB or STL)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    if not inp.exists():
        print(f"Error: File not found: {inp}", file=sys.stderr)
        return 1

    files = _find_related_files(inp)
    source = _read_json(files["source_json"]) if files["source_json"] else None
    dims_json = files["stl_dimensions"] or files["glb_dimensions"]
    dims = _read_json(dims_json) if dims_json else None
    slice_cfg = _read_json(files["slice_config"]) if files["slice_config"] else None

    result = {
        "model": str(inp),
        "source": source.get("source", "unknown") if source else "unknown",
        "source_detail": source or {},
        "dimensions_mm": [dims.get("x"), dims.get("y"), dims.get("z")] if dims else None,
        "max_dimension_mm": dims.get("max") if dims else None,
        "slice_config": slice_cfg,
        "sliced": files["gcode"] is not None,
        "gcode": str(files["gcode"]) if files["gcode"] else None,
        "preview": str(files["preview"]) if files["preview"] else None,
        "gcode_preview": str(files["gcode_preview"]) if files["gcode_preview"] else None,
        "has_stl_sidecar": files["stl"] is not None,
        "has_glb": files["glb"] is not None,
        "multi_part": files["parts_dir"] is not None,
        "files": {k: str(v) for k, v in files.items() if v is not None},
    }

    if parsed.json:
        print(json.dumps(result, indent=2))
    else:
        src_label = result["source"]
        if source:
            if src_label == "thingiverse":
                tid = source.get("thing_id", "?")
                src_label = f"Thingiverse (thing:{tid})"
            elif src_label == "ai":
                prov = source.get("provider", "?")
                src_label = f"AI ({prov})"

        print(f"Model: {inp.name}")
        print(f"Source: {src_label}")
        if dims:
            print(f"Dimensions: {dims.get('x', '?')} x {dims.get('y', '?')} x {dims.get('z', '?')} mm (max: {dims.get('max', '?')}mm)")
        else:
            print("Dimensions: not computed")

        if slice_cfg:
            parts = []
            if slice_cfg.get("max_dimension_mm"):
                parts.append(f"max={slice_cfg['max_dimension_mm']}mm")
            if slice_cfg.get("strength"):
                parts.append(f"strength={slice_cfg['strength']}")
            if slice_cfg.get("quality"):
                parts.append(f"quality={slice_cfg['quality']}")
            if slice_cfg.get("infill_density"):
                parts.append(f"infill={slice_cfg['infill_density']}%")
            if slice_cfg.get("layer_height"):
                parts.append(f"layer={slice_cfg['layer_height']}mm")
            print(f"Last slice config: {', '.join(parts) if parts else 'defaults'}")
        else:
            print("Last slice config: none")

        print(f"Sliced: {'YES → ' + str(files['gcode']) if files['gcode'] else 'NO'}")
        print(f"Preview: {files['preview'] or 'none'}")
        if files["parts_dir"]:
            print(f"Multi-part: {files['parts_dir']}")

    return 0
