"""Convert sketch/image or text prompt to 3D model via AI providers.

Flows (with step_type differentiation for image-to-image):
- Sketch → 3D: sketch_enhance (e.g. FLUX 2 Pro Edit) → image_to_3d (Tripo)
- Multiview → 3D: multiview_enhance (e.g. Gemini Edit) → split → multiview_to_3d (Hunyuan)
- Text → 3D: text_to_image (FLUX Pro Ultra) → image_to_3d (Tripo)
- Edit 3D: render GLB views → edit_3d_enhance → split → multiview_to_3d
"""

import argparse
import io
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Tuple

import requests

try:
    from PIL import Image
except ImportError:
    Image = None

from ..ai_providers import (
    AIProvider,
    ImageToImageRequest,
    StepType,
    get_provider,
    get_registry,
)
from ..ai_providers.edit_3d_render import (
    merge_views_to_grid,
    render_views_from_glb,
    split_grid_to_views,
)


def _bake_yup_to_zup(path: Path) -> None:
    """Apply +90°X rotation to a Y-up GLB and re-save as Z-up in place.

    AI-generated GLBs (FAL/Tripo/Hunyuan) use Y-up (glTF convention).
    The entire pipeline stores Z-up so slicing and packing work without any further fix.
    """
    import numpy as _np
    import trimesh as _trimesh

    try:
        loaded = _trimesh.load(str(path), force="mesh")
        if isinstance(loaded, _trimesh.Scene):
            loaded = loaded.dump(concatenate=True)
        R = _trimesh.transformations.rotation_matrix(_np.pi / 2, [1, 0, 0])
        loaded.apply_transform(R)
        loaded.export(str(path), file_type="glb")
    except Exception as e:
        print(f"Warning: Could not bake Y-up→Z-up on {path.name}: {e}", file=sys.stderr)


def _write_source_json(output_path: Path, provider_id: str, **extra) -> None:
    """Write model provenance sidecar (enables deterministic slicing path selection)."""
    import json as _json
    from datetime import datetime, timezone

    src = {"source": "ai", "provider": provider_id, "created_at": datetime.now(timezone.utc).isoformat()}
    src.update({k: v for k, v in extra.items() if v is not None})
    try:
        output_path.with_suffix(".source.json").write_text(_json.dumps(src, indent=2))
    except OSError:
        pass


def _split_image_quadrants(image_bytes: bytes) -> Tuple[bytes, bytes, bytes]:
    """Split 4-quadrant image into front, back, left.

    Layout:
      FRONT (top-left) | BACK (top-right)
      LEFT (bot-left)  | RIGHT (bot-right, unused)
    """
    if not Image:
        print("Error: Pillow required for --multiview. pip install Pillow", file=sys.stderr)
        sys.exit(1)
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    w, h = img.size
    hw, hh = w // 2, h // 2
    front = img.crop((0, 0, hw, hh))
    back = img.crop((hw, 0, w, hh))
    left = img.crop((0, hh, hw, h))

    def to_png(crop):
        buf = io.BytesIO()
        crop.save(buf, format="PNG")
        return buf.getvalue()

    return to_png(front), to_png(back), to_png(left)


def _upload_or_get_url(path: Path, provider: AIProvider) -> str:
    """Upload local file via provider and return URL."""
    return provider.upload_file(path)


def run(args):
    parser = argparse.ArgumentParser(prog="claw3d convert")
    parser.add_argument("--image", help="Path to sketch/image or original photo")
    parser.add_argument(
        "--annotated-image", dest="annotated_image", default=None,
        help="Annotated version of --image (original + drawn annotation sent together as dual-image context)",
    )
    parser.add_argument("--prompt", help="Description or text prompt")
    parser.add_argument("--output", "-o", required=True, help="Output GLB path")
    parser.add_argument(
        "--multiview",
        action="store_true",
        help="Multiview flow: unified 4-view image → enhance → split → multiview_to_3d",
    )
    parser.add_argument(
        "--edit-3d",
        metavar="MODEL.glb",
        dest="edit_3d_model",
        help="Edit 3D flow: load GLB → render views → enhance → multiview_to_3d",
    )
    parser.add_argument(
        "--save-grid",
        metavar="PATH",
        help="[Edit-3D debug] Save merged 3-view grid to file before enhancement",
    )
    parser.add_argument(
        "--render-only",
        action="store_true",
        help="[Edit-3D] Render views and save grid only, skip enhance/multiview. Requires --save-grid.",
    )
    parser.add_argument(
        "--no-enhance",
        action="store_true",
        help="Skip enhancement (use image directly with Tripo). Only for single-view.",
    )
    # Model override flags
    parser.add_argument("--sketch-enhance-model", help="Model for sketch enhancement (e.g. flux2_pro_edit)")
    parser.add_argument("--multiview-enhance-model", help="Model for multiview enhancement (e.g. gemini_edit)")
    parser.add_argument("--edit-3d-enhance-model", help="Model for edit-3d grid enhancement (e.g. gemini_edit)")
    parser.add_argument("--text-to-image-model", help="Model for text-to-image (e.g. flux_pro_ultra)")
    parser.add_argument("--image-to-3d-model", help="Model for single-image → 3D (e.g. tripo_v25)")
    parser.add_argument("--multiview-to-3d-model", help="Model for multiview → 3D (e.g. hunyuan3d_v2)")

    parsed = parser.parse_args(args)

    output_path = Path(parsed.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        provider = get_provider()
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    # Apply model overrides to registry (validates against provider step catalog)
    reg = get_registry(provider_id=provider.provider_id)
    override_errors = []
    if parsed.sketch_enhance_model:
        if not reg.set_override(StepType.SKETCH_ENHANCE, parsed.sketch_enhance_model):
            override_errors.append(
                f"sketch-enhance: '{parsed.sketch_enhance_model}' not allowed for {provider.provider_id}. "
                f"Use flux2_pro_edit or gemini_edit."
            )
    if parsed.multiview_enhance_model:
        if not reg.set_override(
            StepType.MULTIVIEW_ENHANCE, parsed.multiview_enhance_model
        ):
            override_errors.append(
                f"multiview-enhance: '{parsed.multiview_enhance_model}' not allowed"
            )
    if parsed.edit_3d_enhance_model:
        if not reg.set_override(
            StepType.EDIT_3D_ENHANCE, parsed.edit_3d_enhance_model
        ):
            override_errors.append(
                f"edit-3d-enhance: '{parsed.edit_3d_enhance_model}' not allowed"
            )
    if parsed.text_to_image_model:
        if not reg.set_override(
            StepType.TEXT_TO_IMAGE, parsed.text_to_image_model
        ):
            override_errors.append(
                f"text-to-image: '{parsed.text_to_image_model}' not allowed"
            )
    if parsed.image_to_3d_model:
        if not reg.set_override(
            StepType.IMAGE_TO_3D, parsed.image_to_3d_model
        ):
            override_errors.append(
                f"image-to-3d: '{parsed.image_to_3d_model}' not allowed"
            )
    if parsed.multiview_to_3d_model:
        if not reg.set_override(
            StepType.MULTIVIEW_TO_3D, parsed.multiview_to_3d_model
        ):
            override_errors.append(
                f"multiview-to-3d: '{parsed.multiview_to_3d_model}' not allowed"
            )
    if override_errors:
        for err in override_errors:
            print(f"Error: {err}", file=sys.stderr)
        print("Run `claw3d configure models` to see allowed models per step.", file=sys.stderr)
        return 1
    try:
        return _run_convert(parsed, output_path, provider)
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except RuntimeError as e:
        err = str(e)
        if "API key" in err or "FAL_API_KEY" in err:
            print(f"Error: {err}", file=sys.stderr)
            return 1
        raise


def _run_convert(parsed, output_path, provider):
    # --- Edit 3D flow: GLB → render → merge → i2i (edit_3d_enhance) → split → multiview_to_3d ---
    if parsed.edit_3d_model:
        glb_path = Path(parsed.edit_3d_model)
        if not glb_path.exists():
            print(f"Error: Model not found: {glb_path}", file=sys.stderr)
            return 1
        # Edit-3D uses pyrender (orthographic); headless needs xvfb
        if not os.environ.get("DISPLAY"):
            xvfb = shutil.which("xvfb-run") or "/usr/bin/xvfb-run"
            if os.path.isfile(xvfb) and os.access(xvfb, os.X_OK):
                cmd = ["xvfb-run", "-a", "claw3d", "convert", "--edit-3d", str(glb_path), "--output", str(output_path)]
                if parsed.prompt:
                    cmd.extend(["--prompt", parsed.prompt])
                if getattr(parsed, "save_grid", None):
                    cmd.extend(["--save-grid", parsed.save_grid])
                if getattr(parsed, "render_only", False):
                    cmd.extend(["--render-only"])
                if parsed.edit_3d_enhance_model:
                    cmd.extend(["--edit-3d-enhance-model", parsed.edit_3d_enhance_model])
                if parsed.multiview_to_3d_model:
                    cmd.extend(["--multiview-to-3d-model", parsed.multiview_to_3d_model])
                return subprocess.call(cmd)
            print(
                "Error: No DISPLAY and xvfb-run not found. Edit-3D needs pyrender. apt install xvfb xauth",
                file=sys.stderr,
            )
            return 1
        try:
            views = render_views_from_glb(glb_path)
        except Exception as e:
            print(f"Error: Failed to render views: {e}", file=sys.stderr)
            return 1
        grid_bytes = merge_views_to_grid(views)
        if getattr(parsed, "save_grid", None):
            Path(parsed.save_grid).write_bytes(grid_bytes)
            print(f"Debug: Saved 3-view grid to {parsed.save_grid}", file=sys.stderr)
        if getattr(parsed, "render_only", False):
            return 0
        grid_path = Path(tempfile.mkstemp(suffix="_grid.png")[1])
        try:
            grid_path.write_bytes(grid_bytes)
            grid_url = provider.upload_file(grid_path)
            req = ImageToImageRequest(
                image_urls=[grid_url],
                prompt=parsed.prompt or "",
                step_type=StepType.EDIT_3D_ENHANCE,
            )
            result = provider.image_to_image(req)
            enhanced_url = result.image_urls[0]
        finally:
            try:
                if grid_path.exists():
                    grid_path.unlink()
            except OSError:
                pass

        # Download enhanced grid and split
        resp = requests.get(enhanced_url, timeout=60)
        if not resp.ok:
            print(f"Error: Failed to download enhanced image: {resp.status_code}", file=sys.stderr)
            return 1
        front_png, back_png, left_png = split_grid_to_views(resp.content)

        # Upload views and call multiview_to_3d
        front_path = Path(tempfile.mkstemp(suffix="_front.png")[1])
        back_path = Path(tempfile.mkstemp(suffix="_back.png")[1])
        left_path = Path(tempfile.mkstemp(suffix="_left.png")[1])
        try:
            front_path.write_bytes(front_png)
            back_path.write_bytes(back_png)
            left_path.write_bytes(left_png)
            front_url = provider.upload_file(front_path)
            back_url = provider.upload_file(back_path)
            left_url = provider.upload_file(left_path)
            glb_bytes = provider.multiview_to_3d(front_url, back_url, left_url)
        finally:
            for p in (front_path, back_path, left_path):
                try:
                    if p.exists():
                        p.unlink()
                except OSError:
                    pass

        output_path.write_bytes(glb_bytes)
        _bake_yup_to_zup(output_path)
        _write_source_json(output_path, provider.provider_id)
        print(f"Wrote {output_path} ({len(glb_bytes)} bytes) [edit-3d flow]")
        return 0

    # --- Multiview flow: unified image → enhance → split → multiview_to_3d ---
    if parsed.image and parsed.multiview:
        path = Path(parsed.image)
        if not path.exists():
            print(f"Error: Image not found: {path}", file=sys.stderr)
            return 1
        unified_url = provider.upload_file(path)
        req = ImageToImageRequest(
            image_urls=[unified_url],
            prompt=parsed.prompt or "",
            step_type=StepType.MULTIVIEW_ENHANCE,
        )
        result = provider.image_to_image(req)
        enhanced_url = result.image_urls[0]

        resp = requests.get(enhanced_url, timeout=60)
        if not resp.ok:
            print(f"Error: Failed to download enhanced image: {resp.status_code}", file=sys.stderr)
            return 1
        front_png, back_png, left_png = _split_image_quadrants(resp.content)

        front_path = Path(tempfile.mkstemp(suffix="_front.png")[1])
        back_path = Path(tempfile.mkstemp(suffix="_back.png")[1])
        left_path = Path(tempfile.mkstemp(suffix="_left.png")[1])
        try:
            front_path.write_bytes(front_png)
            back_path.write_bytes(back_png)
            left_path.write_bytes(left_png)
            front_url = provider.upload_file(front_path)
            back_url = provider.upload_file(back_path)
            left_url = provider.upload_file(left_path)
            glb_bytes = provider.multiview_to_3d(front_url, back_url, left_url)
        finally:
            for p in (front_path, back_path, left_path):
                try:
                    if p.exists():
                        p.unlink()
                except OSError:
                    pass
        output_path.write_bytes(glb_bytes)
        _bake_yup_to_zup(output_path)
        _write_source_json(output_path, provider.provider_id)
        print(f"Wrote {output_path} ({len(glb_bytes)} bytes) [multiview flow]")
        return 0

    # --- Sketch / photo-annotation flow: enhance (optional) → image_to_3d ---
    if parsed.image:
        path = Path(parsed.image)
        if not path.exists():
            print(f"Error: Image not found: {path}", file=sys.stderr)
            return 1
        image_url = provider.upload_file(path)
        image_urls = [image_url]

        # Dual-image (annotation) flow: upload annotated image and pass both to FLUX
        if parsed.annotated_image:
            ann_path = Path(parsed.annotated_image)
            if not ann_path.exists():
                print(f"Warning: --annotated-image not found: {ann_path} — ignoring", file=sys.stderr)
            else:
                annotated_url = provider.upload_file(ann_path)
                image_urls = [image_url, annotated_url]
                print("[convert] Dual-image annotation flow: original + annotated → FLUX", file=sys.stderr)

        if parsed.no_enhance:
            enhanced_url = image_urls[0]
        else:
            req = ImageToImageRequest(
                image_urls=image_urls,
                prompt=parsed.prompt or "",
                step_type=StepType.SKETCH_ENHANCE,
            )
            result = provider.image_to_image(req)
            enhanced_url = result.image_urls[0]
        glb_bytes = provider.image_to_3d(enhanced_url)
        output_path.write_bytes(glb_bytes)
        _bake_yup_to_zup(output_path)
        _write_source_json(output_path, provider.provider_id,
                           prompt=parsed.prompt, image=str(path) if path else None,
                           flow="sketch_enhance")
        dual = " + annotation" if len(image_urls) == 2 else ""
        flow = "direct → image_to_3d" if parsed.no_enhance else f"sketch_enhance{dual} → image_to_3d"
        print(f"Wrote {output_path} ({len(glb_bytes)} bytes) [{flow}]")
        return 0

    # --- Text prompt flow: text_to_image → image_to_3d ---
    if not parsed.prompt:
        print("Error: Either --image or --prompt is required", file=sys.stderr)
        return 1
    img_result = provider.text_to_image(parsed.prompt)
    glb_bytes = provider.image_to_3d(img_result.image_url)
    output_path.write_bytes(glb_bytes)
    _bake_yup_to_zup(output_path)
    _write_source_json(output_path, provider.provider_id,
                       prompt=parsed.prompt, flow="text_to_image")
    print(f"Wrote {output_path} ({len(glb_bytes)} bytes) [text → image → 3D]")
    return 0
