"""claw3d queue - Print queue for multi-plate jobs.

When a model needs more than one build plate, G-code files are added to a queue.
After each print finishes, the bot can run 'claw3d queue next' to get the next file
and ask the user if they want to start it.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

QUEUE_FILE = os.environ.get("CLAW3D_QUEUE_PATH") or str(
    Path.home() / ".config" / "claw3d" / "queue.json"
)


def _load_queue() -> list[dict]:
    """Load queue from file. Returns list of {path, label?}."""
    p = Path(QUEUE_FILE)
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_queue(items: list[dict]) -> None:
    Path(QUEUE_FILE).parent.mkdir(parents=True, exist_ok=True)
    Path(QUEUE_FILE).write_text(json.dumps(items, indent=2, ensure_ascii=False))


def run_add(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d queue add")
    parser.add_argument("gcode", help="G-code file path to add")
    parser.add_argument("--label", "-l", default=None, help="Optional label (e.g. 'Plate 2')")
    parsed = parser.parse_args(args)

    path = Path(parsed.gcode).resolve()
    if not path.exists():
        print(f"Error: File not found: {path}", file=sys.stderr)
        return 1

    queue = _load_queue()
    entry = {"path": str(path), "label": parsed.label or path.stem}
    queue.append(entry)
    _save_queue(queue)
    print(f"Added {path.name} to queue ({len(queue)} items)")
    return 0


def run_list(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d queue list")
    parsed = parser.parse_args(args)

    queue = _load_queue()
    if not queue:
        print("Queue is empty")
        return 0
    for i, e in enumerate(queue):
        label = e.get("label", e.get("path", "?"))
        print(f"  {i + 1}. {label}")
    print(f"Total: {len(queue)} items")
    return 0


def run_next(args: list[str]) -> int:
    """Pop and return next item. Exit 1 if empty. Used by bot: 'claw3d queue next' → path or empty."""
    parser = argparse.ArgumentParser(prog="claw3d queue next")
    parsed = parser.parse_args(args)

    queue = _load_queue()
    if not queue:
        print("Queue is empty", file=sys.stderr)
        return 1
    item = queue.pop(0)
    _save_queue(queue)
    path = item.get("path", "")
    label = item.get("label", path)
    print(path)  # stdout: path for scripting (claw3d print -g "$(claw3d queue next)")
    print(f"Next: {label} ({len(queue)} remaining)", file=sys.stderr)
    return 0


def run_clear(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d queue clear")
    parsed = parser.parse_args(args)
    _save_queue([])
    print("Queue cleared")
    return 0


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d queue",
        description="Print queue for multi-plate jobs. Add G-code files, then 'next' to get next after each print.",
    )
    parser.add_argument(
        "subcommand",
        choices=["add", "list", "next", "clear"],
        help="add | list | next | clear",
    )
    parsed, rest = parser.parse_known_args(args)

    if parsed.subcommand == "add":
        return run_add(rest)
    if parsed.subcommand == "list":
        return run_list(rest)
    if parsed.subcommand == "next":
        return run_next(rest)
    if parsed.subcommand == "clear":
        return run_clear(rest)
    return 1
