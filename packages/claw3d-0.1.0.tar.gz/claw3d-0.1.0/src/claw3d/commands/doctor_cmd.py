"""claw3d doctor — Check system health and dependency availability."""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

import requests


def _check(label: str, ok: bool, detail: str = "", warn: bool = False) -> bool:
    tag = "[OK]" if ok else ("[WARN]" if warn else "[FAIL]")
    msg = f"  {tag} {label}"
    if detail:
        msg += f": {detail}"
    print(msg)
    return ok


def run(args: list[str]) -> int:
    print("claw3d doctor — system health check\n")
    all_ok = True

    # 1. Slicer API
    slicer_url = (
        os.environ.get("CLAW3D_SLICER_URL")
        or "http://localhost:8000"
    ).rstrip("/")
    try:
        r = requests.get(f"{slicer_url}/health", timeout=5)
        ok = r.status_code == 200
        _check("Slicer API", ok, f"{slicer_url} ({'responding' if ok else f'HTTP {r.status_code}'})")
    except Exception as e:
        _check("Slicer API", False, f"{slicer_url} (unreachable: {e})")
        all_ok = False

    # 2. API Keys
    fal_key = os.environ.get("FAL_API_KEY", "")
    _check("FAL_API_KEY", bool(fal_key), "configured" if fal_key else "NOT SET — convert will fail")
    if not fal_key:
        all_ok = False

    from ..config import get_gemini_api_key
    gemini_key = get_gemini_api_key()
    _check("GEMINI_API_KEY", bool(gemini_key),
           "configured" if gemini_key else "not set (video analysis will use native mode)",
           warn=not gemini_key)

    thingi_key = os.environ.get("THINGIVERSE_ACCESS_TOKEN", "")
    _check("THINGIVERSE_ACCESS_TOKEN", bool(thingi_key),
           "configured" if thingi_key else "not set (search/find will fail)",
           warn=not thingi_key)

    # 3. ffmpeg
    ffmpeg = shutil.which("ffmpeg")
    _check("ffmpeg", bool(ffmpeg),
           ffmpeg if ffmpeg else "not found (video frame extraction will fail)",
           warn=not ffmpeg)

    # 4. Printers
    from ..config import get_printers, get_default_printer, get_default_printer_build_volume
    printers = get_printers()
    default_id = get_default_printer()
    if printers:
        for pid, pcfg in printers.items():
            host = pcfg.get("host", "?")
            port = pcfg.get("port", "?")
            name = pcfg.get("name", pid)
            is_default = " (default)" if pid == default_id else ""
            profile = pcfg.get("profile_id", "none")
            bv = ""
            bw, bd, bh = pcfg.get("build_width"), pcfg.get("build_depth"), pcfg.get("build_height")
            if bw and bd and bh:
                bv = f" [{bw}x{bd}x{bh}mm]"

            # Try to reach printer
            try:
                r = requests.get(f"http://{host}:{port}/printer/info", timeout=3)
                state = "online" if r.status_code == 200 else f"HTTP {r.status_code}"
            except Exception:
                state = "unreachable"

            _check(f"Printer: {name}{is_default}", state == "online",
                   f"{host}:{port} — {state}, profile: {profile}{bv}",
                   warn=state != "online")
    else:
        _check("Printers", False, "none configured", warn=True)

    # 5. Profiles
    try:
        r = requests.get(f"{slicer_url}/profiles", timeout=5)
        if r.status_code == 200:
            profiles = r.json().get("profiles", [])
            _check("Slicing profiles", bool(profiles),
                   f"{len(profiles)} profile(s)" if profiles else "none — send a 3MF to create one",
                   warn=not profiles)
        else:
            _check("Slicing profiles", False, f"API error {r.status_code}", warn=True)
    except Exception:
        _check("Slicing profiles", False, "slicer unreachable", warn=True)

    # 6. xvfb (for headless preview)
    xvfb = shutil.which("xvfb-run")
    display = os.environ.get("DISPLAY")
    _check("Display/xvfb", bool(display or xvfb),
           f"DISPLAY={display}" if display else (f"xvfb-run at {xvfb}" if xvfb else "no DISPLAY and no xvfb-run"),
           warn=not (display or xvfb))

    print()
    if all_ok:
        print("All critical checks passed.")
    else:
        print("Some checks failed — see above.")
    return 0 if all_ok else 1
