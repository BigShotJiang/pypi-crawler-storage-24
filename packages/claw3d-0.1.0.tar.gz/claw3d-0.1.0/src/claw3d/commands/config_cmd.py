"""Config commands — printer add/list/remove, profile create/list."""

import argparse
import sys
from pathlib import Path

import requests

from ..backends import get_backend_info, is_backend_available
from ..config import (
    get_default_printer,
    get_printers,
    get_slicer_url,
    set_default_printer,
    set_default_profile,
    set_printers,
)
def _slicer_url() -> str:
    import os

    return (
        get_slicer_url()
        or os.environ.get("CLAW3D_SLICER_URL")
        or "http://localhost:8000"
    ).rstrip("/")


def _ensure_3mf_filename(name: str) -> str:
    if name and name.lower().endswith(".3mf"):
        return name
    return (name or "settings").rstrip(".") + ".3mf"


def run_printer(args: list[str]) -> int:
    """Run printer subcommand: add, list, set-default, set-profile, remove."""
    if not args:
        print("Usage: claw3d printer <add|list|set-default|set-profile|remove> [options]", file=sys.stderr)
        return 1

    sub = args[0].lower()
    rest = args[1:]

    if sub == "add":
        return _printer_add(rest)
    if sub == "list":
        return _printer_list(rest)
    if sub == "set-default":
        return _printer_set_default(rest)
    if sub == "set-profile":
        return _printer_set_profile(rest)
    if sub == "remove":
        return _printer_remove(rest)

    print(f"Unknown printer subcommand: {sub}", file=sys.stderr)
    return 1


def _name_to_id(name: str) -> str:
    """Derive slug id from display name: lowercase, spaces→underscores, alphanumeric+underscores only."""
    s = name.strip().lower()
    s = "".join(c if c.isalnum() or c in " -_" else "" for c in s)
    s = "_".join(s.split())
    s = "".join(c for c in s if c.isalnum() or c == "_")
    return s or "printer"


def _printer_add(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d printer add")
    parser.add_argument("--name", "-n", required=True, help="Display name (e.g. 'Creality K2 Pro')")
    parser.add_argument("--host", "-H", required=True, help="Printer IP or hostname")
    parser.add_argument(
        "--port", "-P", type=int, default=None,
        help="Port (default: 7125 Moonraker, 80 PrusaLink)",
    )
    parser.add_argument(
        "--backend", "-b", default="moonraker",
        help="Protocol: moonraker (recommended), prusalink (coming soon)",
    )
    parser.add_argument("--id", "-i", default=None, help="Slug id (optional; derived from --name if omitted)")
    parser.add_argument(
        "--profile-from-3mf", "-f", default=None,
        help="3MF path: create slicing profile from this file and link it as printer default",
    )
    parser.add_argument("--profile-name", default=None, help="Profile name when using --profile-from-3mf")
    parsed = parser.parse_args(args)

    backend_id = (parsed.backend or "moonraker").strip().lower()
    if not is_backend_available(backend_id):
        info = get_backend_info(backend_id)
        msg = info.get("hint", "coming soon") if info else "unknown"
        print(
            f"Error: Backend '{backend_id}' is not available ({msg})",
            file=sys.stderr,
        )
        print("Use moonraker (recommended). Run `claw3d configure backends` to see options.", file=sys.stderr)
        return 1

    port = parsed.port
    if port is None:
        from ..backends.backend_registry import BACKEND_DEFAULT_PORTS
        port = BACKEND_DEFAULT_PORTS.get(backend_id, 7125)

    printers = get_printers()
    pid = (parsed.id.strip() if parsed.id else _name_to_id(parsed.name))
    if not pid or not pid.replace("_", "").replace("-", "").isalnum():
        print("Error: Printer id must be alphanumeric (underscores/dashes ok)", file=sys.stderr)
        return 1

    profile_id = None
    build_snapshot: dict = {}
    if parsed.profile_from_3mf:
        path_3mf = Path(parsed.profile_from_3mf)
        if not path_3mf.exists():
            print(f"Error: 3MF not found: {path_3mf}", file=sys.stderr)
            return 1
        profile_name = parsed.profile_name or (pid + "_profile")
        try:
            data = path_3mf.read_bytes()
            fn = _ensure_3mf_filename(path_3mf.name)
            slicer_url = _slicer_url()
            files = {"file_3mf": (fn, data, "model/3mf")}
            payload = {"name": profile_name, "nozzle_size": "0.4"}
            r = requests.post(f"{slicer_url}/profiles/from-3mf", files=files, data=payload, timeout=120)
            if r.status_code not in (200, 201):
                print(f"Error: Profile from 3MF failed ({r.status_code}): {r.text[:300]}", file=sys.stderr)
                return 1
            resp_json = r.json()
            profile_id = resp_json.get("id")
            if not profile_id:
                print("Error: No profile id in response", file=sys.stderr)
                return 1
            # Snapshot build volume and machine info onto the printer record
            for k in ("build_width", "build_depth", "build_height", "machine_name", "nozzle_size"):
                v = resp_json.get(k)
                if v is not None:
                    build_snapshot[k] = v
            print(f"Created profile '{profile_id}' from {path_3mf.name}", file=sys.stderr)
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    printers[pid] = {
        "host": parsed.host.strip(),
        "port": port,
        "backend": backend_id,
        "name": parsed.name.strip(),
    }
    if profile_id:
        printers[pid]["default_profile"] = profile_id
        printers[pid].update(build_snapshot)
    set_printers(printers)
    # Auto-set as default when this is the only printer (no need to ask)
    if get_default_printer() is None and len(printers) == 1:
        set_default_printer(pid)
        print(f"Set '{pid}' as default printer (only printer configured)", file=sys.stderr)
    print(f"Added printer '{parsed.name}' (id: {pid}) at {parsed.host}:{port} [{backend_id}]")
    if profile_id:
        bw = build_snapshot.get("build_width")
        bd = build_snapshot.get("build_depth")
        bh = build_snapshot.get("build_height")
        dims = f" — build volume: {bw}×{bd}×{bh}mm" if bw and bd and bh else ""
        print(f"Linked profile '{profile_id}'{dims}", file=sys.stderr)
    return 0


def _printer_list(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d printer list")
    parsed = parser.parse_args(args)

    printers = get_printers()
    default = get_default_printer()
    if not printers:
        print("No printers configured. Add one with: claw3d printer add --name \"My Printer\" --host <ip> --port 7125")
        return 0
    for pid, p in printers.items():
        mark = " (default)" if pid == default else ""
        name = p.get("name", "")
        display = f"{name} ({pid})" if name and name != pid else pid
        profile = p.get("default_profile", "")
        profile_info = f" [profile: {profile}]" if profile else ""
        backend = p.get("backend", "moonraker")
        bw, bd, bh = p.get("build_width"), p.get("build_depth"), p.get("build_height")
        build_info = f" [{bw}×{bd}×{bh}mm]" if bw and bd and bh else ""
        print(f"  {display}: {p.get('host', '?')}:{p.get('port', 7125)} [{backend}]{profile_info}{build_info}{mark}")
    return 0


def _printer_set_profile(args: list[str]) -> int:
    """Link a slicing profile as the default for a printer and snapshot its build volume."""
    parser = argparse.ArgumentParser(prog="claw3d printer set-profile")
    parser.add_argument("printer_id", help="Printer id")
    parser.add_argument("profile_id", help="Slicing profile id to link (empty string to unlink)")
    parsed = parser.parse_args(args)

    printers = get_printers()
    if parsed.printer_id not in printers:
        print(f"Error: Printer '{parsed.printer_id}' not found", file=sys.stderr)
        return 1

    profile_id = parsed.profile_id.strip()
    printers[parsed.printer_id]["default_profile"] = profile_id

    if profile_id:
        # Fetch profile metadata and snapshot build volume onto the printer record
        try:
            slicer_url = _slicer_url()
            r = requests.get(f"{slicer_url}/profiles/{profile_id}", timeout=10)
            if r.status_code == 200:
                meta = r.json()
                for k in ("build_width", "build_depth", "build_height", "machine_name", "nozzle_size"):
                    v = meta.get(k)
                    if v is not None:
                        printers[parsed.printer_id][k] = v
        except Exception:
            pass  # Non-fatal: printer is still linked, just no build volume snapshot
    else:
        # Unlinking: clear the build volume snapshot
        for k in ("build_width", "build_depth", "build_height", "machine_name", "nozzle_size"):
            printers[parsed.printer_id].pop(k, None)

    set_printers(printers)
    if profile_id:
        bw = printers[parsed.printer_id].get("build_width")
        bd = printers[parsed.printer_id].get("build_depth")
        bh = printers[parsed.printer_id].get("build_height")
        dims = f" — build volume: {bw}×{bd}×{bh}mm" if bw and bd and bh else ""
        print(f"Printer '{parsed.printer_id}' default profile set to '{profile_id}'{dims}")
    else:
        print(f"Printer '{parsed.printer_id}' profile unlinked")
    return 0


def _printer_set_default(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d printer set-default")
    parser.add_argument("id", nargs="?", default=None, help="Printer id to set as default")
    parsed = parser.parse_args(args)

    if parsed.id:
        printers = get_printers()
        if parsed.id not in printers:
            print(f"Error: Printer '{parsed.id}' not found", file=sys.stderr)
            return 1
        set_default_printer(parsed.id)
        print(f"Default printer set to '{parsed.id}'")
    else:
        set_default_printer(None)
        print("Cleared default printer")
    return 0


def _printer_remove(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d printer remove")
    parser.add_argument("id", help="Printer id to remove")
    parsed = parser.parse_args(args)

    printers = get_printers()
    if parsed.id not in printers:
        print(f"Error: Printer '{parsed.id}' not found", file=sys.stderr)
        return 1
    del printers[parsed.id]
    set_printers(printers)
    if get_default_printer() == parsed.id:
        set_default_printer(None)
    print(f"Removed printer '{parsed.id}'")
    return 0


def run_profile(args: list[str]) -> int:
    """Run profile subcommand: create, list, set-default, clear."""
    if not args:
        print("Usage: claw3d profile <create|list|set-default|clear> [options]", file=sys.stderr)
        return 1

    sub = args[0].lower()
    rest = args[1:]

    if sub == "create":
        return _profile_create(rest)
    if sub == "list":
        return _profile_list(rest)
    if sub == "set-default":
        return _profile_set_default(rest)
    if sub == "clear":
        return _profile_clear(rest)

    print(f"Unknown profile subcommand: {sub}", file=sys.stderr)
    return 1


def _profile_create(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d profile create")
    parser.add_argument("--from-3mf", "-f", required=True, help="Path to 3MF file with Cura settings")
    parser.add_argument("--name", "-n", required=True, help="Profile name (e.g. neptune4_pla)")
    parser.add_argument("--nozzle-size", type=float, default=0.4, help="Nozzle size in mm (default: 0.4)")
    parsed = parser.parse_args(args)

    path = Path(parsed.from_3mf)
    if not path.exists():
        print(f"Error: 3MF file not found: {path}", file=sys.stderr)
        return 1

    data = path.read_bytes()
    fn = _ensure_3mf_filename(path.name)
    slicer_url = _slicer_url()
    files = {"file_3mf": (fn, data, "model/3mf")}
    payload = {"name": parsed.name, "nozzle_size": str(parsed.nozzle_size)}
    try:
        r = requests.post(f"{slicer_url}/profiles/from-3mf", files=files, data=payload, timeout=120)
    except requests.RequestException as e:
        print(f"Error: Cannot reach slicing API at {slicer_url}: {e}", file=sys.stderr)
        return 1
    if r.status_code not in (200, 201):
        print(f"Error: Profile creation failed ({r.status_code}): {r.text[:500]}", file=sys.stderr)
        return 1
    resp = r.json()
    profile_id = resp.get("id")
    if not profile_id:
        print("Error: No profile id in response", file=sys.stderr)
        return 1
    print(f"Created profile '{profile_id}' from {path.name}")
    return 0


def _profile_set_default(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d profile set-default")
    parser.add_argument("id", nargs="?", default=None, help="Profile id to set as default")
    parsed = parser.parse_args(args)

    if parsed.id:
        set_default_profile(parsed.id)
        print(f"Default profile set to '{parsed.id}'")
    else:
        set_default_profile(None)
        print("Cleared default profile")
    return 0


def _profile_clear(args: list[str]) -> int:
    """Delete all slicing profiles. Use for a fresh start."""
    parser = argparse.ArgumentParser(prog="claw3d profile clear", description="Delete all profiles")
    parser.add_argument("--yes", "-y", action="store_true", help="Skip confirmation")
    parsed = parser.parse_args(args)

    slicer_url = _slicer_url()
    try:
        r = requests.get(f"{slicer_url}/profiles", timeout=10)
    except requests.RequestException as e:
        print(f"Error: Cannot reach slicing API at {slicer_url}: {e}", file=sys.stderr)
        return 1
    if r.status_code != 200:
        print(f"Error: Failed to list profiles ({r.status_code})", file=sys.stderr)
        return 1
    data = r.json()
    profiles = data.get("profiles") or []
    if not profiles:
        print("No profiles to clear.")
        return 0
    ids = [p.get("id") for p in profiles if p.get("id")]
    for pid in ids:
        try:
            dr = requests.delete(f"{slicer_url}/profiles/{pid}", timeout=10)
            if dr.status_code in (200, 204):
                print(f"Deleted profile '{pid}'")
            else:
                print(f"Failed to delete '{pid}': {dr.status_code}", file=sys.stderr)
        except requests.RequestException as e:
            print(f"Error deleting '{pid}': {e}", file=sys.stderr)
    set_default_profile(None)
    return 0


def _profile_list(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d profile list")
    parsed = parser.parse_args(args)

    slicer_url = _slicer_url()
    try:
        r = requests.get(f"{slicer_url}/profiles", timeout=10)
    except requests.RequestException as e:
        print(f"Error: Cannot reach slicing API at {slicer_url}: {e}", file=sys.stderr)
        return 1
    if r.status_code != 200:
        print(f"Error: Failed to list profiles ({r.status_code})", file=sys.stderr)
        return 1
    data = r.json()
    profiles = data.get("profiles") or []
    if not profiles:
        print("No profiles on slicing server. Create one with: claw3d profile create --from-3mf <path> --name <name>")
        return 0
    for p in profiles:
        name = p.get("name", "?")
        pid = p.get("id", "?")
        machine = p.get("machine_name", "")
        nozzle = p.get("nozzle_size", "")
        extra = f" ({machine}, {nozzle}mm)" if machine or nozzle else ""
        print(f"  {pid}: {name}{extra}")
    return 0
