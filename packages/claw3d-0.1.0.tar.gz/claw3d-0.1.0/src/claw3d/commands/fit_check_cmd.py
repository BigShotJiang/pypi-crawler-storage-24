"""claw3d fit-check — Check if a 3D model fits in the printer's build volume.

Tries all 6 axis-aligned 90°-multiple orientations in deterministic order (identity first).
Exits 0 and prints JSON if a fitting orientation is found; exits 1 if nothing fits or on error.

With --apply-rotation: if a non-identity rotation is needed, applies it in-place to the input
file AND the paired sidecar (.glb alongside .stl, or .stl alongside .glb) so that all
downstream commands (preview, slice) see the correctly-oriented model automatically.

The 6 orientations cover all 6 unique bounding-box permutations of a rectangular box:
  (0,0,0)   → extents (a, b, c)  identity
  (90,0,0)  → extents (a, c, b)  90° around X
  (0,90,0)  → extents (c, b, a)  90° around Y
  (0,0,90)  → extents (b, a, c)  90° around Z
  (90,0,90) → extents (c, a, b)  90°X then 90°Z
  (0,90,90) → extents (b, c, a)  90°Y then 90°Z
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

# All 6 axis-aligned orientations (euler XYZ degrees) in deterministic order.
# Identity is first so no rotation is applied when the model already fits.
ORIENTATIONS: list[tuple[float, float, float]] = [
    (0, 0, 0),
    (90, 0, 0),
    (0, 90, 0),
    (0, 0, 90),
    (90, 0, 90),
    (0, 90, 90),
]


def _rotated_extents(ex: float, ey: float, ez: float, rx: float, ry: float, rz: float) -> tuple[float, float, float]:
    """Compute bounding-box extents of a box (ex,ey,ez) after euler XYZ rotation (degrees)."""
    from scipy.spatial.transform import Rotation

    corners = np.array([
        [s * ex / 2, t * ey / 2, u * ez / 2]
        for s in (-1, 1) for t in (-1, 1) for u in (-1, 1)
    ])
    rot = Rotation.from_euler("xyz", [rx, ry, rz], degrees=True)
    rotated = rot.apply(corners)
    extents = rotated.max(axis=0) - rotated.min(axis=0)
    return float(extents[0]), float(extents[1]), float(extents[2])


def _find_fitting_orientation(
    extents: tuple[float, float, float],
    bw: float,
    bd: float,
    bh: float,
) -> tuple[float, float, float] | None:
    """Return first (rx, ry, rz) where the model fits in (bw × bd × bh), or None."""
    for rx, ry, rz in ORIENTATIONS:
        fx, fy, fz = _rotated_extents(*extents, rx, ry, rz)
        if fx <= bw and fy <= bd and fz <= bh:
            return rx, ry, rz
    return None


def _apply_rotation_to_file(path: Path, rx: float, ry: float, rz: float) -> None:
    """Apply euler XYZ rotation (degrees) to a mesh in-place; normalize so min=(0,0,0)."""
    import trimesh

    mesh = trimesh.load(str(path), force="mesh")
    if isinstance(mesh, trimesh.Scene):
        mesh = mesh.dump(concatenate=True)
    R = trimesh.transformations.euler_matrix(
        np.radians(rx), np.radians(ry), np.radians(rz), axes="rxyz"
    )
    mesh.apply_transform(R)
    if mesh.bounds is not None:
        mesh.vertices -= mesh.bounds[0]
    file_type = path.suffix.lower().lstrip(".")
    if file_type not in ("stl", "obj", "glb", "3mf"):
        file_type = "stl"
    mesh.export(str(path), file_type=file_type)


def _parse_build(build_str: str) -> tuple[float, float, float]:
    for sep in ("x", "X", "*", ",", " "):
        if sep in build_str:
            parts = [p.strip() for p in build_str.replace(",", sep).split(sep)][:3]
            if len(parts) == 3:
                return float(parts[0]), float(parts[1]), float(parts[2])
    raise ValueError(f"Invalid --build: expected WxDxH (e.g. 220x220x250), got: {build_str!r}")


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d fit-check",
        description="Check if a 3D model fits in the printer's build volume in any 90° orientation",
    )
    parser.add_argument("--input", "-i", required=True, help="Input STL/GLB/OBJ/3MF file")
    parser.add_argument(
        "--build", "-b", default=None,
        help="Build volume WxDxH in mm (e.g. 220x220x250). Defaults to default printer's build volume.",
    )
    parser.add_argument(
        "--apply-rotation",
        action="store_true",
        help="Apply fitting rotation in-place to the model (and its sidecar file) so "
             "preview and slice use the correctly-oriented version automatically.",
    )
    parsed = parser.parse_args(args)

    # Resolve build volume
    if parsed.build:
        try:
            bw, bd, bh = _parse_build(parsed.build)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    else:
        from ..config import get_default_printer_build_volume
        vol = get_default_printer_build_volume()
        if not vol:
            print("Error: --build required (no default printer build volume configured)", file=sys.stderr)
            return 1
        bw, bd, bh = vol

    inp = Path(parsed.input)
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1

    try:
        import trimesh
        mesh = trimesh.load(str(inp), force="mesh")
        if isinstance(mesh, trimesh.Scene):
            mesh = mesh.dump(concatenate=True)
        if not hasattr(mesh, "bounds") or mesh.bounds is None:
            print("Error: Could not compute bounds", file=sys.stderr)
            return 1
        ext_arr = mesh.bounds[1] - mesh.bounds[0]
        extents: tuple[float, float, float] = (float(ext_arr[0]), float(ext_arr[1]), float(ext_arr[2]))
    except Exception as e:
        print(f"Error: Failed to load model: {e}", file=sys.stderr)
        return 1

    fitting = _find_fitting_orientation(extents, bw, bd, bh)

    if fitting is None:
        result = {
            "fits": False,
            "extents_mm": [round(e, 1) for e in extents],
            "build_volume_mm": [bw, bd, bh],
        }
        print(json.dumps(result))
        return 1

    rx, ry, rz = fitting
    fx, fy, fz = _rotated_extents(*extents, rx, ry, rz)
    result = {
        "fits": True,
        "rotation_x": rx,
        "rotation_y": ry,
        "rotation_z": rz,
        "extents_mm": [round(e, 1) for e in extents],
        "fitted_extents_mm": [round(fx, 1), round(fy, 1), round(fz, 1)],
    }
    print(json.dumps(result))

    if parsed.apply_rotation and (rx != 0 or ry != 0 or rz != 0):
        suffix = inp.suffix.lower()
        # Apply to the input file itself
        try:
            _apply_rotation_to_file(inp, rx, ry, rz)
            print(f"Applied rotation ({rx:.0f}°X {ry:.0f}°Y {rz:.0f}°Z) to {inp.name}", file=sys.stderr)
        except Exception as e:
            print(f"Warning: Could not apply rotation to {inp.name}: {e}", file=sys.stderr)

        # Apply to the paired sidecar
        if suffix != ".glb":
            sidecar = inp.with_suffix(".glb")
        else:
            # GLB input: look for STL or OBJ sidecar
            sidecar = inp.with_suffix(".stl")
            if not sidecar.exists():
                sidecar = inp.with_suffix(".obj")

        if sidecar.exists():
            try:
                _apply_rotation_to_file(sidecar, rx, ry, rz)
                print(f"Applied rotation to sidecar: {sidecar.name}", file=sys.stderr)
            except Exception as e:
                print(f"Warning: Could not apply rotation to {sidecar.name}: {e}", file=sys.stderr)

    return 0
