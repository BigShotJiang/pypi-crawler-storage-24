"""claw3d stamp-thumbnails — Stamp A/B/C option badges onto thumbnail images.

Deterministic replacement for the copy-paste Python snippet in the skill.
Takes 1-6 thumbnail paths, stamps sequential letters (A, B, C...) on each.

With --grid, also composes a single 2x2 grid image (A top-left, B top-right,
C bottom-left, bottom-right reserved). Output: thumb_grid_<stem>.jpg
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _stamp_letter(input_path: Path, letter: str, output_path: Path, tile_size: int = 400) -> bool:
    """Stamp a letter badge on a thumbnail image. Returns True on success."""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print("Error: Pillow not installed. Run: pip install Pillow", file=sys.stderr)
        return False

    try:
        img = Image.open(input_path).convert("RGB")
        img = img.resize((tile_size, tile_size), Image.LANCZOS)
        w, h = img.size
        r = max(h // 16, 12)
        cx, cy = r + 8, r + 8
        draw = ImageDraw.Draw(img)
        draw.ellipse([(cx - r, cy - r), (cx + r, cy + r)], fill=(255, 255, 255))
        sz = max(int(r * 1.8), 18)
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", sz)
            bb = font.getbbox(letter)
            tx = cx - (bb[0] + bb[2]) // 2
            ty = cy - (bb[1] + bb[3]) // 2
            draw.text((tx, ty), letter, fill=(30, 30, 30), font=font)
        except Exception:
            draw.text((cx - 4, cy - 5), letter, fill=(30, 30, 30))
        img.save(str(output_path))
        return True
    except Exception as e:
        print(f"Error stamping {input_path}: {e}", file=sys.stderr)
        return False


def _compose_grid(stamped_paths: list[Path], output_path: Path, tile_size: int = 400, gap: int = 4) -> bool:
    """Compose stamped images into a 2x2 grid. Bottom-right cell is dark placeholder."""
    try:
        from PIL import Image
    except ImportError:
        print("Error: Pillow not installed.", file=sys.stderr)
        return False

    try:
        cols, rows = 2, 2
        canvas_w = cols * tile_size + (cols - 1) * gap
        canvas_h = rows * tile_size + (rows - 1) * gap
        canvas = Image.new("RGB", (canvas_w, canvas_h), (30, 30, 30))

        positions = [(0, 0), (tile_size + gap, 0), (0, tile_size + gap), (tile_size + gap, tile_size + gap)]
        for i, sp in enumerate(stamped_paths):
            tile = Image.open(sp).convert("RGB").resize((tile_size, tile_size), Image.LANCZOS)
            canvas.paste(tile, positions[i])

        canvas.save(str(output_path), quality=90)
        return True
    except Exception as e:
        print(f"Error composing grid: {e}", file=sys.stderr)
        return False


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d stamp-thumbnails",
        description="Stamp A/B/C option badges onto thumbnail images.",
    )
    parser.add_argument(
        "thumbnails", nargs="+",
        help="Thumbnail image paths (1-6). First gets A, second B, etc.",
    )
    parser.add_argument(
        "--grid", action="store_true",
        help="Also output a single 2x2 grid image combining all stamped thumbnails.",
    )
    parsed = parser.parse_args(args)

    if len(parsed.thumbnails) > 6:
        print("Error: Max 6 thumbnails (A-F)", file=sys.stderr)
        return 1

    letters = "ABCDEF"
    outputs = []
    for i, thumb_path in enumerate(parsed.thumbnails):
        inp = Path(thumb_path)
        if not inp.exists():
            print(f"Error: Thumbnail not found: {inp}", file=sys.stderr)
            return 1
        letter = letters[i]
        out = inp.with_stem(inp.stem + f"_{letter}")
        if not _stamp_letter(inp, letter, out):
            return 1
        outputs.append(out)
        print(f"Stamped {letter} → {out}")

    if parsed.grid and outputs:
        first = outputs[0]
        grid_path = first.parent / f"thumb_grid_{first.stem.rsplit('_', 1)[0]}.jpg"
        if _compose_grid(outputs, grid_path):
            print(f"Grid → {grid_path}")
        else:
            return 1

    return 0
