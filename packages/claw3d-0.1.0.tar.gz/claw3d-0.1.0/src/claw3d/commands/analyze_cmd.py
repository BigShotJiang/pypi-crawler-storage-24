"""claw3d analyze — Classify user intent from an image using Gemini.

Outputs structured JSON to stdout so the skill agent can decide the next step
without needing to be multimodal itself. Works with any underlying AI.

Requires GEMINI_API_KEY (or CLAW3D_GEMINI_API_KEY / GOOGLE_API_KEY) to be set.
Without a key, falls back to a basic non-AI analysis that always returns
needs_clarification=false so the skill can still proceed (via the user's own AI).

Output JSON schema:
  {
    "subject":               string — what is visible in the image
    "image_type":            "sketch" | "photo" | "3d_model" | "reference"
    "intent":                "create_new" | "create_attachment" | "find_existing" | "unclear"
    "needs_clarification":   boolean
    "clarification_question": string | null  — ONE question if needs_clarification=true
    "suggested_prompt":      string | null  — 3D model description for the convert command
    "gemini_used":           boolean — whether Gemini was called
  }
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# ─── Gemini system prompt ────────────────────────────────────────────────────

_SYSTEM_PROMPT = """\
You are an expert assistant for a 3D printing workflow. Your job is to analyze
an image (and an optional text description) and understand what 3D model the
user wants to create or print.

Return a JSON object with EXACTLY these fields:

{
  "subject": "<brief description of what you see>",
  "image_type": "<sketch | photo | 3d_model | reference>",
  "intent": "<create_new | create_attachment | find_existing | unclear>",
  "needs_clarification": <true | false>,
  "clarification_question": "<one question, or null>",
  "suggested_prompt": "<detailed 3D model description, or null>"
}

Rules:
- image_type:
    sketch      = hand-drawn, outline drawing, whiteboard sketch
    photo       = real photograph of a physical object or scene
    3d_model    = rendered 3D model or CAD screenshot
    reference   = product photo, inspiration image, brand logo, etc.

- intent:
    create_new        = make a standalone 3D model of the subject
    create_attachment = make something that attaches to or holds the object in the photo
    find_existing     = user wants to find a ready-made model (mentions search / Thingiverse)
    unclear           = cannot determine what they want

- needs_clarification = true ONLY when you genuinely cannot infer a reasonable 3D model to create.
  Examples that do NOT need clarification:
    - Any sketch (intent is always create_new)
    - "print this" on a photo of a single object
    - A description that makes the intent obvious
  Examples that DO need clarification:
    - Photo of a complex scene with many objects and no description
    - "make this better" with no context about what to change
    - Photo of something abstract (e.g., a landscape) with no description

- clarification_question: if needs_clarification=true, ask ONE short, specific question.
  Example: "I can see a keyboard. Do you want me to create a 3D model of the keyboard itself,
  or a stand/wrist rest to go with it?"
  If needs_clarification=false, this must be null.

- suggested_prompt: a detailed text description of the 3D model to create, suitable for
  a text-to-image-to-3D pipeline. Include shape, material hints, scale cues, function.
  Example: "a minimalist bamboo phone stand with a 70° angled back support and a
  1cm front lip to prevent the phone from sliding, designed for desk use"
  If intent=find_existing or needs_clarification=true, this may be null.
"""


def _analyze_with_gemini(
    api_key: str,
    image_path: Path,
    description: str | None,
    annotated_path: Path | None,
) -> dict:
    from ..gemini_client import call_json, image_parts, GeminiError

    parts = image_parts(image_path, annotated_path)
    if description:
        parts.append({"text": f'User description: "{description}"\n\nAnalyze this image.'})
    else:
        annotation_hint = ""
        if annotated_path:
            annotation_hint = " The user has already annotated the image — treat intent as clarified."
        parts.append({"text": f"No description provided.{annotation_hint}\n\nAnalyze this image."})

    return call_json(api_key, _SYSTEM_PROMPT, parts)


def _native_result(description: str | None, annotated: bool) -> dict:
    """Return native_mode=true so the skill agent does the analysis itself."""
    return {
        "native_mode": True,
        "gemini_used": False,
        "description": description or None,
        "has_annotation": annotated,
    }


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d analyze",
        description="Classify user intent from an image. Outputs JSON.",
    )
    parser.add_argument("--input", "-i", required=True, help="Input image path (MediaPath from chat)")
    parser.add_argument("--description", "-d", default=None, help="Optional user description/message")
    parser.add_argument(
        "--annotated", "-a", default=None,
        help="Optional second image: same photo with user's marks/drawings on top",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")
    parsed = parser.parse_args(args)

    image_path = Path(parsed.input)
    if not image_path.exists():
        print(f"Error: Image not found: {image_path}", file=sys.stderr)
        return 1

    annotated_path = Path(parsed.annotated) if parsed.annotated else None
    if annotated_path and not annotated_path.exists():
        print(f"Warning: Annotated image not found: {annotated_path} — ignoring", file=sys.stderr)
        annotated_path = None

    from ..config import get_gemini_api_key, get_analysis_mode
    mode = get_analysis_mode()
    indent = 2 if parsed.pretty else None

    # Native mode: skip Gemini entirely, let the skill agent analyze
    if mode == "native":
        result = _native_result(parsed.description, annotated_path is not None)
        print(json.dumps(result, indent=indent, ensure_ascii=False))
        return 0

    api_key = get_gemini_api_key()

    # Gemini required but not configured
    if mode == "gemini" and not api_key:
        print(
            "Error: analysis_mode=gemini but no API key is configured.",
            file=sys.stderr,
        )
        print("Set key: claw3d configure analysis --gemini-api-key <KEY>", file=sys.stderr)
        print("Or switch: claw3d configure analysis --mode auto", file=sys.stderr)
        return 1

    # Auto mode without key → native fallback
    if mode == "auto" and not api_key:
        print(
            "Tip: Set GEMINI_API_KEY for full intent analysis. Falling back to native mode.",
            file=sys.stderr,
        )
        result = _native_result(parsed.description, annotated_path is not None)
        print(json.dumps(result, indent=indent, ensure_ascii=False))
        return 0

    # Use Gemini
    try:
        from ..gemini_client import GeminiError
        result = _analyze_with_gemini(api_key, image_path, parsed.description, annotated_path)
        result["gemini_used"] = True
        result["native_mode"] = False
        print(json.dumps(result, indent=indent, ensure_ascii=False))
        return 0
    except GeminiError as e:
        print(f"Error: Gemini analysis failed: {e}", file=sys.stderr)
        if mode == "auto":
            print("Falling back to native mode.", file=sys.stderr)
            result = _native_result(parsed.description, annotated_path is not None)
            print(json.dumps(result, indent=indent, ensure_ascii=False))
            return 0
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
