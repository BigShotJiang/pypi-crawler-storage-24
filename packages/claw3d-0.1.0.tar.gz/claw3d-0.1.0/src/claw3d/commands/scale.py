"""Scale a 3D model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import trimesh

from .dimensions_cmd import _dimensions_path


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d scale")
    parser.add_argument("--input", "-i", required=True, help="Input mesh (GLB, STL, OBJ)")
    parser.add_argument("--output", "-o", required=True, help="Output path")
    parser.add_argument("--scale", "-s", type=float, default=1.0, help="Uniform scale factor")
    parser.add_argument("--max-dimension", type=float, help="Scale so max dimension is this (mm)")
    parser.add_argument(
        "--same-size",
        action="store_true",
        help="Scale to original max dimension (reads .dimensions.json from claw3d dimensions)",
    )
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    out = Path(parsed.output)
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1
    out.parent.mkdir(parents=True, exist_ok=True)

    try:
        mesh = trimesh.load(str(inp), force="scene")
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    if isinstance(mesh, trimesh.Scene):
        if not mesh.geometry:
            print("Error: Scene has no geometry", file=sys.stderr)
            return 1
        mesh = mesh.dump(concatenate=True)
    if not isinstance(mesh, trimesh.Trimesh):
        print("Error: Could not get single mesh", file=sys.stderr)
        return 1

    scale_factor = parsed.scale
    max_dimension = parsed.max_dimension

    if parsed.same_size:
        dim_path = _dimensions_path(inp)
        if not dim_path.exists():
            print(
                f"Error: No dimensions file at {dim_path}. Run 'claw3d dimensions -i {inp}' first.",
                file=sys.stderr,
            )
            return 1
        try:
            dims = json.loads(dim_path.read_text())
            max_dimension = dims.get("max")
        except (json.JSONDecodeError, OSError) as e:
            print(f"Error: Could not read dimensions: {e}", file=sys.stderr)
            return 1
        if max_dimension is None:
            print("Error: dimensions file has no 'max' field", file=sys.stderr)
            return 1

    if max_dimension is not None:
        extents = mesh.extents
        current_max = max(extents)
        if current_max <= 0:
            print("Error: Mesh has zero extent", file=sys.stderr)
            return 1
        scale_factor = max_dimension / current_max

    mesh.apply_scale(scale_factor)
    mesh.export(str(out))
    print(f"Scaled by {scale_factor:.4f}, wrote {out}")
    return 0
