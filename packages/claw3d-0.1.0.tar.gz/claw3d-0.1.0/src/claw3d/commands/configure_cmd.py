"""claw3d configure — select AI provider and per-step models."""

import sys

from ..backends import list_backends
from ..ai_providers import (
    StepType,
    list_providers,
    get_provider_info,
    get_step_catalog,
    is_model_allowed,
)
from ..config import get_ai_provider, set_ai_provider, get_models, set_model_for_step


def run(args: list[str]) -> int:
    """Interactive or non-interactive provider/model selection."""
    if args and args[0] in ("--help", "-h"):
        _print_help()
        return 0

    # claw3d configure models [step] [model_id]
    if args and args[0].lower() == "models":
        return _run_models(args[1:])

    # claw3d configure backends
    if args and args[0].lower() == "backends":
        return _run_backends()

    # claw3d configure analysis [--gemini-api-key KEY | --status | --clear]
    if args and args[0].lower() == "analysis":
        return _run_analysis(args[1:])

    # Non-interactive: claw3d configure fal | claw3d configure --provider fal
    provider_arg = None
    if args:
        if args[0] == "--provider" and len(args) > 1:
            provider_arg = args[1].strip().lower()
        elif not args[0].startswith("-"):
            provider_arg = args[0].strip().lower()

    if provider_arg:
        return _set_provider(provider_arg)

    return _run_interactive()


def _run_interactive() -> int:
    """Prompt user to select provider."""
    providers = list_providers()
    current = get_ai_provider() or "fal"

    print("claw3d AI Provider")
    print()
    print("Available providers:")
    for p in providers:
        mark = " (current)" if p["id"] == current else ""
        status = "✓" if p.get("available") else "coming soon"
        print(f"  {p['id']}: {p['label']} [{status}]{mark}")
        if p.get("hint"):
            print(f"      {p['hint']}")
    print()
    print("To set provider: claw3d configure <provider_id>")
    print("Example: claw3d configure fal")
    print()
    print("Environment: CLAW3D_PROVIDER overrides config")
    return 0


def _set_provider(provider_id: str) -> int:
    """Set provider in config."""
    info = get_provider_info(provider_id)
    if not info:
        print(f"Error: Unknown provider '{provider_id}'", file=sys.stderr)
        print("Available:", ", ".join(p["id"] for p in list_providers()), file=sys.stderr)
        return 1
    if not info.get("available"):
        print(
            f"Error: {info['label']} is not available yet ({info.get('hint', 'coming soon')})",
            file=sys.stderr,
        )
        return 1
    set_ai_provider(provider_id)
    env_var = info.get("env", "")
    print(f"Provider set to {info['label']} ({provider_id})")
    if env_var:
        print(f"Ensure {env_var} is set (OpenClaw Control UI → Skills → 3d-ai-forger)")
    return 0


def _run_backends() -> int:
    """Show available printer protocols (Moonraker, PrusaLink, etc.)."""
    backends = list_backends()
    print("claw3d Printer Backends")
    print()
    for b in backends:
        status = "✓ recommended" if b.get("available") else "coming soon"
        print(f"  {b['id']}: {b['label']} [{status}]")
        if b.get("hint"):
            print(f"      {b['hint']}")
    print()
    print("When adding a printer: claw3d printer add --backend moonraker --name \"My Printer\" --host <ip> --port 7125")
    return 0


def _run_models(args: list[str]) -> int:
    """Show or set model per step. claw3d configure models [step] [model_id]"""
    provider_id = get_ai_provider() or "fal"
    models_config = get_models()

    # claw3d configure models <step> <model_id> — set one step
    if len(args) >= 2:
        step_key = args[0].strip().lower().replace("-", "_")
        model_id = args[1].strip().lower()
        try:
            step_type = StepType(step_key)
        except ValueError:
            print(f"Error: Unknown step '{step_key}'", file=sys.stderr)
            _print_models_help(provider_id)
            return 1
        if not is_model_allowed(provider_id, step_type, model_id):
            catalog = get_step_catalog(provider_id, step_type)
            allowed = ", ".join(m["id"] for m in catalog)
            print(
                f"Error: Model '{model_id}' not allowed for {step_key}. Allowed: {allowed}",
                file=sys.stderr,
            )
            return 1
        set_model_for_step(step_key, model_id)
        print(f"Set {step_key} → {model_id}")
        return 0

    # claw3d configure models — list steps and options
    print(f"claw3d Models (provider: {provider_id})")
    print()
    for step_type in StepType:
        catalog = get_step_catalog(provider_id, step_type)
        if not catalog:
            continue
        current = models_config.get(step_type.value)
        if not current:
            current = next((m["id"] for m in catalog if m.get("recommended")), catalog[0]["id"])
        print(f"  {step_type.value}:")
        for m in catalog:
            rec = " (recommended)" if m.get("recommended") else ""
            cur = " [current]" if m["id"] == current else ""
            print(f"    {m['id']}: {m['label']}{rec}{cur}")
        print()
    print("To set: claw3d configure models <step> <model_id>")
    print("Example: claw3d configure models sketch_enhance gemini_edit")
    return 0


def _run_backends() -> int:
    """Show available printer protocols (Moonraker, PrusaLink, etc.)."""
    backends = list_backends()
    print("claw3d Printer Backends")
    print()
    for b in backends:
        status = "✓ recommended" if b.get("available") else "coming soon"
        print(f"  {b['id']}: {b['label']} [{status}]")
        if b.get("hint"):
            print(f"      {b['hint']}")
    print()
    print("When adding a printer: claw3d printer add --backend moonraker --name \"My Printer\" --host <ip> --port 7125")
    return 0


def _run_analysis(args: list[str]) -> int:
    """Configure analysis layer (Gemini key + mode).

    claw3d configure analysis                           Show status
    claw3d configure analysis --gemini-api-key <KEY>   Set Gemini key
    claw3d configure analysis --mode <auto|native|gemini>  Set mode
    claw3d configure analysis --clear                  Remove Gemini key
    """
    import argparse as _ap
    from ..config import get_gemini_api_key, set_gemini_api_key, get_analysis_mode, set_analysis_mode

    parser = _ap.ArgumentParser(prog="claw3d configure analysis")
    parser.add_argument("--gemini-api-key", default=None, metavar="KEY",
                        help="Gemini API key (from https://aistudio.google.com/apikey)")
    parser.add_argument(
        "--mode", default=None, choices=["auto", "native", "gemini"],
        help=(
            "auto   (default): use Gemini if key set, else native | "
            "native: always use skill agent's own AI (no Gemini call) | "
            "gemini: require Gemini, error if key missing"
        ),
    )
    parser.add_argument("--status", action="store_true", help="Show current analysis configuration")
    parser.add_argument("--clear", action="store_true", help="Remove stored Gemini API key")
    parsed = parser.parse_args(args)

    if parsed.clear:
        set_gemini_api_key(None)
        print("Gemini API key cleared.")
        return 0

    if parsed.gemini_api_key:
        key = parsed.gemini_api_key.strip()
        if not key:
            print("Error: API key cannot be empty", file=sys.stderr)
            return 1
        set_gemini_api_key(key)
        # Auto-set mode to 'gemini' if explicitly providing a key and mode is native
        if get_analysis_mode() == "native":
            set_analysis_mode("auto")
            print("Analysis mode reset to 'auto' (was 'native').")
        print("Gemini API key saved.")
        print("Enables: image intent analysis, video hero-frame selection.")
        print("Test it: claw3d analyze --input <image.jpg> --pretty")
        return 0

    if parsed.mode:
        try:
            set_analysis_mode(parsed.mode)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
        mode_desc = {
            "auto": "Gemini if key available, else skill agent",
            "native": "Always use skill agent's own AI (no Gemini)",
            "gemini": "Always use Gemini (error if key missing)",
        }[parsed.mode]
        print(f"Analysis mode set to '{parsed.mode}': {mode_desc}")
        return 0

    # --status or no args: show current state
    key = get_gemini_api_key()
    mode = get_analysis_mode()
    print("claw3d Analysis Layer")
    print()
    print(f"  Mode:    {mode}")
    mode_labels = {
        "auto":   "Gemini if key set, else skill agent's own AI",
        "native": "Always skill agent's own AI (no Gemini call)",
        "gemini": "Always Gemini (error if key missing)",
    }
    print(f"           {mode_labels.get(mode, '')}")
    print()
    if key:
        masked = key[:8] + "..." + key[-4:] if len(key) > 12 else "***"
        print(f"  Gemini:  ✓ Configured ({masked})")
    else:
        print("  Gemini:  ✗ Not configured")
        if mode != "native":
            print()
            print("  To enable Gemini (recommended for video + consistent analysis):")
            print("    1. Free API key: https://aistudio.google.com/apikey")
            print("    2. claw3d configure analysis --gemini-api-key <KEY>")
            print("       OR: set env var GEMINI_API_KEY=<KEY>")
    print()
    print("  To use your own AI for analysis (if it's multimodal):")
    print("    claw3d configure analysis --mode native")
    print()
    print("  Commands:")
    print("    claw3d analyze --input <image>         → intent JSON")
    print("    claw3d extract-frame --input <video>   → best frame image")
    return 0


def _print_models_help(provider_id: str) -> None:
    print("Steps:", ", ".join(s.value for s in StepType), file=sys.stderr)


def _print_help() -> None:
    print("""claw3d configure — Select AI provider, per-step models, and analysis layer

Usage:
  claw3d configure              Show providers and current selection
  claw3d configure <provider>   Set provider (e.g. fal, replicate)
  claw3d configure models       Show model options per step
  claw3d configure models <step> <model_id>   Set model for a step
  claw3d configure backends     Show printer protocols (Moonraker, PrusaLink)
  claw3d configure analysis     Show analysis (Gemini) configuration
  claw3d configure analysis --gemini-api-key <KEY>   Set Gemini API key
  claw3d configure analysis --clear                  Remove Gemini API key

Providers (AI generation — FAL_API_KEY):
  fal       FAL.ai (default) — required for convert, sketch, 3D generation
  replicate Replicate (coming soon)

Analysis layer (GEMINI_API_KEY — optional but recommended):
  Gemini 2.5 Flash powers: image intent analysis, video hero-frame selection.
  Works with ANY underlying AI model. Free tier available.
  Get key: https://aistudio.google.com/apikey

Printer backends:
  moonraker Moonraker (recommended) — Klipper/Fluidd/Mainsail
  prusalink PrusaLink (coming soon)

Config is saved to ~/.config/claw3d/config.json
""")
