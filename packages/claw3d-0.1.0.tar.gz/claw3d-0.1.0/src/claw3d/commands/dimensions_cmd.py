"""claw3d dimensions - get bounding box / print size of a 3D model."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import trimesh


def _dimensions_path(model_path: Path) -> Path:
    """Path for sidecar dimensions file (for --same-size scaling)."""
    return model_path.with_suffix(model_path.suffix + ".dimensions.json")


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d dimensions",
        description="Print bounding box dimensions (X Y Z in mm) of a 3D model",
    )
    parser.add_argument(
        "--input",
        "-i",
        required=True,
        help="Input GLB/STL/OBJ/3MF file",
    )
    parser.add_argument(
        "--format",
        "-f",
        choices=["simple", "verbose"],
        default="simple",
        help="Output format: simple (X Y Z one line), verbose (with labels)",
    )
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1

    try:
        loaded = trimesh.load(str(inp), force="mesh")
        if isinstance(loaded, trimesh.Scene):
            loaded = loaded.dump(concatenate=True)
        if not hasattr(loaded, "bounds") or loaded.bounds is None:
            print("Error: Could not compute bounds.", file=sys.stderr)
            return 1
    except Exception as e:
        print(f"Error: Failed to load model: {e}", file=sys.stderr)
        return 1

    bounds = loaded.bounds
    extents = bounds[1] - bounds[0]
    # Assume mm for STL/OBJ/GLB (common in 3D printing)
    x, y, z = float(extents[0]), float(extents[1]), float(extents[2])
    max_dim = max(x, y, z)

    # Save sidecar so scale --same-size can restore original size
    dims = {"x": round(x, 1), "y": round(y, 1), "z": round(z, 1), "max": round(max_dim, 1)}
    dim_path = _dimensions_path(inp)
    try:
        dim_path.write_text(json.dumps(dims, indent=2))
    except OSError as e:
        print(f"Warning: Could not save dimensions to {dim_path}: {e}", file=sys.stderr)

    if parsed.format == "verbose":
        print(f"X: {x:.1f} mm")
        print(f"Y: {y:.1f} mm")
        print(f"Z: {z:.1f} mm")
        print(f"Size: {x:.1f} × {y:.1f} × {z:.1f} mm")
        print(f"Max dimension: {max_dim:.1f} mm (saved for --same-size)")
    else:
        print(f"{x:.1f} {y:.1f} {z:.1f} max={max_dim:.1f}")

    return 0
