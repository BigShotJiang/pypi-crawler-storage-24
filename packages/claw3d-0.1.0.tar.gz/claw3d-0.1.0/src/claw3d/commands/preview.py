"""Render a 360° turntable preview video of a 3D model.

Uses stealth black material with soft wrap-around studio lighting
(key/fill/rim/overhead/front) — similar to iOS slicer page: no harsh hotspots,
even illumination with gentle shape definition.
Background: warm beige (#fdf6ed) for contrast.
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
import trimesh

# Do NOT set PYOPENGL_PLATFORM=osmesa — OSMesa libs may be missing. Use xvfb-run for headless.

# Stealth black material — slightly lighter (0x181818) than pure black for better
# visible form and detail; dark models at 0x040404 often look like silhouettes.
# Glossy black lacquer — dark studio style.
# Near-black base + low roughness = clear bright specular highlights on curves.
# Low metalness keeps the lacquer/painted look (not chrome/mirror).
STEALTH_COLOR = np.array([6 / 255, 6 / 255, 6 / 255, 1.0], dtype=np.float32)
STEALTH_ROUGHNESS = 0.55  # soft studio look — subtle highlights without sharp hotspots
STEALTH_METALNESS = 0.05  # lacquer, not metallic

# Soft wrap-around lighting — like iOS slicer page: no harsh hotspots,
# even fill from multiple directions, gentle rim for shape definition.
LIGHTING = [
    ((5, 5, 5),    2.5),  # Key light — softer, still creates main highlight
    ((-5, 3, -5),  1.5),  # Fill light — stronger fill reduces harsh shadow contrast
    ((0, 5, -5),   1.0),  # Rim light — softer edge definition
    ((0, 6, 0.5),  0.6),  # Overhead — prevents top from going pure black
    ((0, -2, -5),  0.4),  # Back-bottom rim
    ((0, 2, 5),    0.8),  # Front fill — wraps light around the front face
]


def _look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
    """4x4 camera-to-world matrix: camera at eye looking at target."""
    fwd = target - eye
    fwd = fwd / (np.linalg.norm(fwd) + 1e-8)
    right = np.cross(up, fwd)
    right = right / (np.linalg.norm(right) + 1e-8)
    up_w = np.cross(fwd, right)
    m = np.eye(4)
    m[:3, 0] = right
    m[:3, 1] = up_w
    m[:3, 2] = -fwd  # OpenGL camera looks down -Z
    m[:3, 3] = eye
    return m


def _light_pose_from_direction(dx: float, dy: float, dz: float, distance: float) -> np.ndarray:
    """Pose for directional light at distance along (dx,dy,dz), shining toward origin."""
    d = np.array([dx, dy, dz], dtype=float)
    d = d / (np.linalg.norm(d) + 1e-8)
    pose = _look_at(d * distance, np.zeros(3), np.array([0.0, 1.0, 0.0]))
    return pose


def _load_mesh_for_preview(input_path: str):
    """Load a 3D file as a single trimesh for preview (stealth material applied in pyrender).

    All stored models (GLB, STL, OBJ, 3MF) use Z-up coordinates (slicer convention).
    Apply −90°X to every input to convert Z-up → Y-up for pyrender's Y-up world.
    """
    path = Path(input_path)
    suffix = path.suffix.lower()

    # Detect GLB by header when extension is missing
    is_glb = suffix in (".glb", ".gltf")
    if not is_glb:
        data = path.read_bytes()
        if data[:4] == b"glTF":
            is_glb = True

    if is_glb:
        loaded = trimesh.load(path, file_type="glb", force="scene")
    else:
        loaded = trimesh.load(str(path), force="scene")

    if isinstance(loaded, trimesh.Scene):
        if not loaded.geometry:
            raise ValueError("Scene has no geometry")
        mesh = loaded.dump(concatenate=True)
    else:
        mesh = loaded
        if not isinstance(mesh, trimesh.Trimesh):
            mesh = trimesh.util.concatenate([m for m in mesh.geometry.values()])

    # All stored files are Z-up. Convert to Y-up for pyrender by applying −90°X.
    R = trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0])
    mesh.apply_transform(R)

    return mesh


def _render_turntable(
    glb_path: str,
    out_path: str,
    elevation_deg: float = 15.0,
    build_volume: "tuple[float, float, float] | None" = None,
    rotation_x: float = 0.0,
    rotation_y: float = 0.0,
    rotation_z: float = 0.0,
    real_scale: bool = False,
) -> bool:
    """Render GLB to turntable MP4. Returns True on success."""
    try:
        import imageio
        # NumPy 2.0 compatibility: pyrender uses np.infty (removed in 2.0)
        import numpy as _np
        if not hasattr(_np, "infty"):
            _np.infty = _np.inf  # type: ignore[attr-defined]
        import pyrender
    except ImportError as e:
        print(f"Error: {e}. Run: pip install pyrender imageio imageio-ffmpeg", file=sys.stderr)
        return False

    # Load mesh
    mesh_trimesh = _load_mesh_for_preview(glb_path)

    # Fix faceted shading: split vertices at sharp edges (like Blender's Auto Smooth).
    # Flat surfaces get uniform normals (no visible triangle seams), curved surfaces get
    # smooth interpolation, and sharp edges (>60°) stay crisp.
    try:
        mesh_trimesh = trimesh.graph.smooth_shade(mesh_trimesh, angle=np.radians(60))
    except Exception:
        mesh_trimesh.merge_vertices()

    # Apply user-requested rotation around mesh centroid, before any centering/scaling
    if rotation_x or rotation_y or rotation_z:
        import trimesh as _trimesh
        center = mesh_trimesh.centroid.copy()
        if rotation_x:
            R = _trimesh.transformations.rotation_matrix(np.radians(rotation_x), [1, 0, 0], center)
            mesh_trimesh.apply_transform(R)
        if rotation_y:
            R = _trimesh.transformations.rotation_matrix(np.radians(rotation_y), [0, 1, 0], center)
            mesh_trimesh.apply_transform(R)
        if rotation_z:
            R = _trimesh.transformations.rotation_matrix(np.radians(rotation_z), [0, 0, 1], center)
            mesh_trimesh.apply_transform(R)

    if build_volume:
        build_w, build_d, build_h = build_volume
        # Center model's bounding box at origin (not centroid — centroid shifts
        # asymmetric models off-center since it's the vertex average, not the
        # geometric center of the bounding box)
        b = mesh_trimesh.bounds
        if b is not None:
            bbox_center = (b[0] + b[1]) / 2.0
            mesh_trimesh.vertices[:, 0] -= bbox_center[0]
            mesh_trimesh.vertices[:, 1] -= bbox_center[1]
            mesh_trimesh.vertices[:, 2] -= bbox_center[2]
        if not real_scale:
            # Scale to maximum size that fits the build volume — same logic as iOS app:
            # compute per-axis scale factor, take minimum so no axis overflows.
            b = mesh_trimesh.bounds  # [[min_x,min_y,min_z],[max_x,max_y,max_z]]
            if b is not None:
                model_w = float(b[1][0] - b[0][0]) or 1.0  # X → build_w
                model_h = float(b[1][1] - b[0][1]) or 1.0  # Y (up) → build_h
                model_d = float(b[1][2] - b[0][2]) or 1.0  # Z → build_d
                scale = min(build_w / model_w, build_h / model_h, build_d / model_d) * 0.95
                mesh_trimesh.vertices *= scale
        # Sit bottom at plate Y=0
        min_y = float(mesh_trimesh.bounds[0][1]) if mesh_trimesh.bounds is not None else 0.0
        mesh_trimesh.vertices[:, 1] -= min_y
    else:
        mesh_trimesh.vertices -= mesh_trimesh.centroid

    bounds = mesh_trimesh.bounds
    diag = float(np.linalg.norm(bounds[1] - bounds[0])) if bounds is not None else 2.0
    if diag < 0.01:
        diag = 1.0

    # Stealth material (dark studio style)
    # doubleSided=True — AI-generated GLBs (Tripo, Hunyuan) often have flipped normals;
    # back-face culling then creates "holes" that look translucent. Render both sides.
    stealth_material = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=STEALTH_COLOR,
        metallicFactor=STEALTH_METALNESS,
        roughnessFactor=STEALTH_ROUGHNESS,
        alphaMode="OPAQUE",
        doubleSided=True,
    )
    # Strip vertex/face colors — original GLB materials can have alpha or odd colors that bleed through
    if mesh_trimesh.visual is not None:
        n_vertices = len(mesh_trimesh.vertices)
        n_faces = len(mesh_trimesh.faces)
        opaque_white = np.array([255, 255, 255, 255], dtype=np.uint8)
        if hasattr(mesh_trimesh.visual, "vertex_colors") and mesh_trimesh.visual.vertex_colors is not None:
            mesh_trimesh.visual.vertex_colors = np.tile(opaque_white, (n_vertices, 1))
        if hasattr(mesh_trimesh.visual, "face_colors") and mesh_trimesh.visual.face_colors is not None:
            mesh_trimesh.visual.face_colors = np.tile(opaque_white, (n_faces, 1))
    mesh_pr = pyrender.Mesh.from_trimesh(mesh_trimesh, material=stealth_material, smooth=True)

    # Warm background (#fdf6ed) — cream/beige for contrast with black models
    PREVIEW_BG = np.array([253 / 255, 246 / 255, 237 / 255])
    scene = pyrender.Scene(
        ambient_light=np.array([0.28, 0.28, 0.28]),  # Higher ambient: softer shadows, less harsh contrast
        bg_color=PREVIEW_BG,
    )
    scene.add(mesh_pr)

    # Build area: plate border + grid + volume wireframe (3D geometry in pyrender scene)
    if build_volume:
        from ..scene_build_area import add_build_area
        add_build_area(scene, build_w, build_d, build_h, plate_y=0.0, show_volume_box=True)

    # Camera: frame the full build plate
    if build_volume:
        plate_diag = float(np.sqrt(build_w ** 2 + build_d ** 2))
        r = max(plate_diag * 0.75, diag * 1.2, 0.5)
    else:
        r = max(diag * 1.2, 0.5)

    # Camera target: vertical center of model
    if build_volume:
        model_max_y = float(mesh_trimesh.bounds[1][1]) if mesh_trimesh.bounds is not None else 0.0
        cam_target = np.array([0.0, model_max_y / 2, 0.0])
    else:
        cam_target = np.zeros(3)

    el_rad = np.radians(elevation_deg)
    up = np.array([0.0, 1.0, 0.0])

    w, h = 640, 640
    camera = pyrender.PerspectiveCamera(yfov=np.pi / 3.0, aspectRatio=1.0)
    cam_node = scene.add(camera, pose=np.eye(4))

    # Studio lighting: key, fill, rim, overhead, back rim (each at distance, shining toward origin)
    dist = r * 2.5
    for (dx, dy, dz), intensity in LIGHTING:
        light_pose = _light_pose_from_direction(dx, dy, dz, dist)
        scene.add(
            pyrender.DirectionalLight(color=np.ones(3), intensity=intensity),
            pose=light_pose,
        )

    # Frames: 360° over ~4 seconds at 24fps = 96 frames
    n_frames = 96
    fps = 24

    try:
        renderer = pyrender.OffscreenRenderer(w, h)
    except Exception as e:
        print(f"Error: OffscreenRenderer failed: {e}", file=sys.stderr)
        print(
            "Tip: On headless (Docker): use openclaw:claw3d image or apt install xvfb xauth",
            file=sys.stderr,
        )
        return False

    # Axis indicator setup
    from PIL import Image as _PilImage, ImageDraw as _PilDraw, ImageFont as _PilFont
    # Axis gizmo in slicer-world coordinates (Z-up).
    # Models are rendered in pyrender's Y-up after a −90°X conversion, so:
    #   World X → Pyrender X,  World Y → Pyrender −Z,  World Z → Pyrender Y
    _AXIS_DEFS = [
        (np.array([ 1.,  0.,  0.]), (220,  60,  60), "X"),  # World X = pyrender X
        (np.array([ 0.,  0., -1.]), ( 60, 200,  60), "Y"),  # World Y = pyrender −Z
        (np.array([ 0.,  1.,  0.]), ( 60, 120, 220), "Z"),  # World Z = pyrender Y (up)
    ]
    _AXIS_L = 48   # arrow length in pixels (~1/6 of 640px preview width per axis arm)
    _MARGIN = 28   # distance from corner to axis origin
    _ox = _MARGIN + _AXIS_L
    _oy = h - _MARGIN - _AXIS_L
    try:
        _axis_font = _PilFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 15)
    except Exception:
        _axis_font = _PilFont.load_default()

    def _draw_axis_indicator(frame_rgb: np.ndarray, cam_pose: np.ndarray) -> np.ndarray:
        """Overlay XYZ axis indicator in bottom-left corner of frame (uint8 H×W×3 array)."""
        cam_right = cam_pose[:3, 0]
        cam_up = cam_pose[:3, 1]
        # Blend a dark rounded-rect background for readability
        bg_r = _AXIS_L + 14
        x0, y0 = _ox - bg_r, _oy - bg_r
        x1, y1 = _ox + bg_r, _oy + bg_r
        x0c, y0c = max(0, x0), max(0, y0)
        x1c, y1c = min(frame_rgb.shape[1], x1), min(frame_rgb.shape[0], y1)
        region = frame_rgb[y0c:y1c, x0c:x1c].astype(np.float32)
        region = region * 0.65 + np.array([255, 255, 255], dtype=np.float32) * 0.35
        frame_rgb = frame_rgb.copy()
        frame_rgb[y0c:y1c, x0c:x1c] = np.clip(region, 0, 255).astype(np.uint8)
        img = _PilImage.fromarray(frame_rgb)
        draw = _PilDraw.Draw(img)
        for d, col, label in _AXIS_DEFS:
            sx = float(np.dot(d, cam_right))
            sy = float(np.dot(d, cam_up))
            # Image is horizontally flipped → negate sx; image y goes down → negate sy
            px = _ox + int(-sx * _AXIS_L)
            py = _oy + int(-sy * _AXIS_L)
            draw.line([(_ox, _oy), (px, py)], fill=col, width=2)
            draw.ellipse([(px - 3, py - 3), (px + 3, py + 3)], fill=col)
            draw.text((px + 4, py - 7), label, fill=col, font=_axis_font)
        return np.asarray(img)

    frames = []
    try:
        for i in range(n_frames):
            azimuth = 2 * np.pi * i / n_frames
            x = r * np.cos(el_rad) * np.cos(azimuth)
            y = r * np.sin(el_rad)
            z = r * np.cos(el_rad) * np.sin(azimuth)
            eye = np.array([x, y, z], dtype=float) + cam_target
            pose = _look_at(eye, cam_target, up)
            scene.set_pose(cam_node, pose)
            color, _ = renderer.render(scene)
            # Horizontal flip (pyrender/OpenGL convention vs image/video expectation)
            flipped = np.ascontiguousarray(color[:, ::-1, :])
            frames.append(_draw_axis_indicator(flipped, pose))
    finally:
        renderer.delete()

    # Encode to MP4
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    writer = imageio.get_writer(out_path, fps=fps, codec="libx264", quality=8)
    for f in frames:
        writer.append_data(f)
    writer.close()
    return True


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d preview")
    parser.add_argument("--input", "-i", required=True, help="Input GLB/OBJ")
    parser.add_argument("--output", "-o", help="Output MP4 path (default: input_preview.mp4)")
    parser.add_argument("--elevation", type=float, default=15.0, help="Camera elevation in degrees")
    parser.add_argument(
        "--build-volume", default=None,
        metavar="WxDxH",
        help="Printer build volume in mm (e.g. 350x350x350). Shows build plate + grid under model.",
    )
    parser.add_argument("--rotation-x", type=float, default=0.0, help="Rotate model around X axis (degrees) before rendering")
    parser.add_argument("--rotation-y", type=float, default=0.0, help="Rotate model around Y axis (degrees) before rendering")
    parser.add_argument("--rotation-z", type=float, default=0.0, help="Rotate model around Z axis (degrees) before rendering")
    parser.add_argument(
        "--real-scale",
        action="store_true",
        help="Show model at actual physical size (mm) on build plate instead of scaling to fill 95%% of build volume.",
    )
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    out = Path(parsed.output) if parsed.output else inp.with_stem(inp.stem + "_preview").with_suffix(".mp4")
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1

    build_volume = None
    if parsed.build_volume:
        from ..scene_build_area import parse_build_volume
        try:
            build_volume = parse_build_volume(parsed.build_volume)
        except ValueError as e:
            print(f"Error: --build-volume: {e}", file=sys.stderr)
            return 1
    else:
        # Fallback: use default printer's build volume from config
        from ..config import get_default_printer_build_volume
        cfg_vol = get_default_printer_build_volume()
        if cfg_vol:
            build_volume = cfg_vol
            print(f"Using default printer build volume: {cfg_vol[0]:.0f}×{cfg_vol[1]:.0f}×{cfg_vol[2]:.0f}mm", file=sys.stderr)

    rot_x, rot_y, rot_z = parsed.rotation_x, parsed.rotation_y, parsed.rotation_z
    real_scale = parsed.real_scale

    # Headless: must use xvfb-run when DISPLAY not set (pyrender needs a display)
    if not os.environ.get("DISPLAY"):
        xvfb = shutil.which("xvfb-run") or "/usr/bin/xvfb-run"
        if os.path.isfile(xvfb) and os.access(xvfb, os.X_OK):
            cmd = [xvfb, "-a", "claw3d", "preview", "--input", str(inp), "--output", str(out)]
            if parsed.elevation != 15.0:
                cmd += ["--elevation", str(parsed.elevation)]
            if parsed.build_volume:
                cmd += ["--build-volume", parsed.build_volume]
            elif build_volume:
                cmd += ["--build-volume", f"{build_volume[0]:.0f}x{build_volume[1]:.0f}x{build_volume[2]:.0f}"]
            if rot_x:
                cmd += ["--rotation-x", str(rot_x)]
            if rot_y:
                cmd += ["--rotation-y", str(rot_y)]
            if rot_z:
                cmd += ["--rotation-z", str(rot_z)]
            if real_scale:
                cmd += ["--real-scale"]
            return subprocess.call(cmd)
        print(
            "Error: No DISPLAY and xvfb-run not found. For headless (Docker): apt install xvfb xauth",
            file=sys.stderr,
        )
        return 1

    if _render_turntable(str(inp), str(out), parsed.elevation, build_volume=build_volume,
                         rotation_x=rot_x, rotation_y=rot_y, rotation_z=rot_z, real_scale=real_scale):
        size = out.stat().st_size
        print(f"Wrote {out} ({size} bytes)")
        return 0
    return 1
