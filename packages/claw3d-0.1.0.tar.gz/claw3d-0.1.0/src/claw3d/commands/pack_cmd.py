"""claw3d pack - Arrange multi-part models (or N copies of one model) on build plate.

Loads separate mesh parts, computes bounding boxes, packs them on the XY build plate
using the printer's build size, applies at least 2mm gap between parts, then
concatenates into a single output file (or multiple when >1 plate needed) for slicing.

Use --copies N to duplicate a single model N times onto the plate.
Use --rotation-x/y/z to bake an orientation into every part before packing.

If any single part exceeds the build volume, exits with code 1 so the caller can
try another model from the directory.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

import numpy as np
import trimesh


def _parse_build(build_str: str) -> tuple[float, float, float]:
    """Parse --build as WxHxD or W,H,D (mm). Returns (bed_x, bed_y, bed_z)."""
    for sep in ("x", "X", "*", ",", " "):
        if sep in build_str:
            parts = [p.strip() for p in build_str.replace(",", sep).split(sep)][:3]
            if len(parts) == 3:
                return float(parts[0]), float(parts[1]), float(parts[2])
    raise ValueError(f"Invalid --build: expected WxHxD or W,H,D (e.g. 220x220x250)")


def _part_exceeds_build(box: tuple[float, float, float], bed_x: float, bed_y: float, bed_z: float) -> bool:
    """True if the part (wx, wy, wz) exceeds the build volume."""
    return box[0] > bed_x or box[1] > bed_y or box[2] > bed_z


def _collect_parts(inputs: Sequence[Path]) -> list[trimesh.Trimesh]:
    """Load mesh parts from files or directory. Split multi-body meshes by connected components."""
    parts: list[trimesh.Trimesh] = []
    paths: list[Path] = []

    for inp in inputs:
        if inp.is_dir():
            paths.extend(
                sorted(inp.iterdir(), key=lambda p: p.name.lower())
            )
        elif inp.is_file():
            paths.append(inp)

    for p in paths:
        if p.suffix.lower() not in (".stl", ".obj", ".3mf", ".glb"):
            continue
        try:
            loaded = trimesh.load(str(p), force="mesh")
            if isinstance(loaded, trimesh.Scene):
                loaded = loaded.dump(concatenate=True)
            if isinstance(loaded, trimesh.Trimesh):
                # Split by connected components - one file may contain multiple bodies
                try:
                    split = trimesh.graph.split(loaded, only_watertight=False)
                    for m in split:
                        if isinstance(m, trimesh.Trimesh) and len(m.vertices) >= 3:
                            parts.append(m)
                except Exception:
                    parts.append(loaded)
            elif hasattr(loaded, "geometry"):
                for g in loaded.geometry.values():
                    if isinstance(g, trimesh.Trimesh) and len(g.vertices) >= 3:
                        parts.append(g)
        except Exception as e:
            print(f"Warning: Skipped {p.name}: {e}", file=sys.stderr)

    return parts


def _pack_2d_multi_plate(
    boxes: list[tuple[float, float, float]],
    bed_x: float,
    bed_y: float,
    margin: float,
) -> list[list[tuple[int, float, float]]]:
    """
    Shelf packing across multiple plates. Returns list of plates; each plate is
    list of (part_idx, x, y) for parts on that plate.
    """
    indexed = sorted(enumerate(boxes), key=lambda x: (-x[1][2], -x[1][0] * x[1][1]))  # tall first
    m = margin
    plates: list[list[tuple[int, float, float]]] = []
    current_plate: list[tuple[int, float, float]] = []
    x_cur, y_cur = m, m
    row_max_y = 0.0

    for idx, (w, d, h) in indexed:
        bw, bd = w + m, d + m
        if x_cur + bw > bed_x:
            x_cur = m
            y_cur += row_max_y + m
            row_max_y = 0.0
        if y_cur + bd > bed_y:
            # New plate
            if current_plate:
                plates.append(current_plate)
            current_plate = []
            x_cur, y_cur = m, m
            row_max_y = 0.0
        current_plate.append((idx, x_cur, y_cur))
        row_max_y = max(row_max_y, bd)
        x_cur += bw

    if current_plate:
        plates.append(current_plate)
    return plates


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d pack",
        description="Arrange multi-part models on build plate with 2mm spacing for slicing",
    )
    parser.add_argument(
        "--input",
        "-i",
        required=True,
        nargs="+",
        help="Input files or directory containing part STL/OBJ/GLB files",
    )
    parser.add_argument(
        "--output",
        "-o",
        required=True,
        help="Output path (GLB or STL)",
    )
    parser.add_argument(
        "--build",
        "-b",
        default=None,
        help="Build volume WxHxD in mm (e.g. 220x220x250). Defaults to default printer's build volume.",
    )
    parser.add_argument(
        "--margin",
        "-m",
        type=float,
        default=2.0,
        help="Gap between parts in mm (default: 2)",
    )
    parser.add_argument(
        "--copies",
        "-n",
        type=int,
        default=1,
        help="Number of copies of the input model to place on the plate (default: 1)",
    )
    parser.add_argument("--rotation-x", type=float, default=0.0, help="Rotate each part X degrees around X axis before packing")
    parser.add_argument("--rotation-y", type=float, default=0.0, help="Rotate each part X degrees around Y axis before packing")
    parser.add_argument("--rotation-z", type=float, default=0.0, help="Rotate each part X degrees around Z axis before packing")
    parsed = parser.parse_args(args)

    build_str = parsed.build
    if not build_str:
        from ..config import get_default_printer_build_volume
        vol = get_default_printer_build_volume()
        if vol:
            build_str = f"{vol[0]:.0f}x{vol[1]:.0f}x{vol[2]:.0f}"
            print(f"Using default printer build volume: {build_str}mm", file=sys.stderr)
        else:
            print("Error: --build required (no default printer build volume configured)", file=sys.stderr)
            return 1
    try:
        bed_x, bed_y, bed_z = _parse_build(build_str)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    inputs = [Path(p) for p in parsed.input]
    for inp in inputs:
        if not inp.exists():
            print(f"Error: Input not found: {inp}", file=sys.stderr)
            return 1

    parts = _collect_parts(inputs)
    if not parts:
        print("Error: No mesh parts found in input", file=sys.stderr)
        return 1

    # Apply rotation to each part (bakes orientation before packing)
    rot_x, rot_y, rot_z = parsed.rotation_x, parsed.rotation_y, parsed.rotation_z
    if rot_x != 0 or rot_y != 0 or rot_z != 0:
        R = trimesh.transformations.euler_matrix(
            np.radians(rot_x), np.radians(rot_y), np.radians(rot_z), axes="rxyz"
        )
        for mesh in parts:
            mesh.apply_transform(R)
            # Normalize per-part so negative coordinates don't cause packing offsets.
            # The packer translates each part by (px - min_x, py - min_y, margin - min_z)
            # which already handles negative mins, but explicit normalization avoids
            # surprises when the slicer receives the final merged mesh.
            if mesh.bounds is not None:
                mesh.vertices -= mesh.bounds[0]

    # Duplicate: replace parts list with N copies of each part
    if parsed.copies > 1:
        parts = [mesh.copy() for mesh in parts for _ in range(parsed.copies)]

    # Bounding box per part (axis-aligned)
    boxes: list[tuple[float, float, float]] = []
    for m in parts:
        b = m.bounds
        if b is not None:
            ext = b[1] - b[0]
            boxes.append((float(ext[0]), float(ext[1]), float(ext[2])))
        else:
            boxes.append((10.0, 10.0, 10.0))

    # Reject if any single part exceeds build volume — caller should try another model
    for i, box in enumerate(boxes):
        if _part_exceeds_build(box, bed_x, bed_y, bed_z):
            print(
                f"Error: Part {i+1} ({box[0]:.0f}x{box[1]:.0f}x{box[2]:.0f}mm) exceeds build volume {bed_x:.0f}x{bed_y:.0f}x{bed_z:.0f}mm — try another design",
                file=sys.stderr,
            )
            return 1

    plates = _pack_2d_multi_plate(boxes, bed_x, bed_y, parsed.margin)
    margin = parsed.margin
    out = Path(parsed.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    ext = out.suffix.lower()
    output_paths: list[Path] = []

    for plate_idx, plate_assigned in enumerate(plates):
        translated: list[trimesh.Trimesh] = []
        for idx, px, py in plate_assigned:
            mesh = parts[idx]
            box = boxes[idx]
            bounds = mesh.bounds
            if bounds is None:
                translated.append(mesh.copy())
                continue
            min_corner = bounds[0]
            offset = [
                px - min_corner[0],
                py - min_corner[1],
                margin - min_corner[2],
            ]
            moved = mesh.copy()
            moved.vertices += offset
            translated.append(moved)

        merged = trimesh.util.concatenate(translated)
        if len(plates) > 1:
            plate_out = out.parent / f"{out.stem}_plate{plate_idx + 1}{out.suffix}"
        else:
            plate_out = out
        if ext == ".glb":
            merged.export(str(plate_out), file_type="glb")
        else:
            merged.export(str(plate_out), file_type="stl")
        output_paths.append(plate_out)

    n_src = len(_collect_parts([Path(p) for p in parsed.input]))  # original part count
    n_copies = parsed.copies
    n_plates = len(plates)
    if n_copies > 1:
        src_name = Path(parsed.input[0]).name
        print(
            f"Packed {n_copies} copies of {src_name} on {n_plates} plate(s) with {parsed.margin}mm spacing",
            file=sys.stderr,
        )
    elif n_src > 1 or n_plates > 1:
        print(
            f"Packed {n_src} parts on {n_plates} plate(s) with {parsed.margin}mm spacing",
            file=sys.stderr,
        )
    for p in output_paths:
        print(f"Wrote {p} ({p.stat().st_size} bytes)")
    if n_plates > 1:
        print(f"Multi-plate: add G-code files to queue and print sequentially", file=sys.stderr)
    return 0
