"""Render a 360° turntable video of G-code with body and supports in different colors.

Uses ;TYPE: for classification, E for extrusion.
Body (model): red/coral. Support: yellow. Only extrusion segments — no travel.

Fast PIL-based line renderer: no pyrender/trimesh/xvfb needed.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np

from ..gcode_parser import parse_gcode

# Preview colors (RGB tuples for PIL)
BG_COLOR      = (253, 246, 237)  # warm background
BODY_COLOR    = (255, 80,  80)   # Red/coral — model walls, infill, skin
SUPPORT_COLOR = (255, 200, 50)   # Yellow — support, skirt, brim
PLATE_COLOR   = (170, 170, 170)  # Grey build plate edge
GRID_COLOR    = (210, 210, 210)  # 10mm grid lines
BOX_COLOR     = (150, 150, 150)  # Volume wireframe

# Adaptive segment cap — controls preview quality vs speed
TARGET_SEGMENTS = 80000

N_FRAMES = 72
FPS = 24
WIDTH, HEIGHT = 640, 640
FOV_RAD = np.pi / 3.0  # 60°


def _segs_to_array(segs: list) -> np.ndarray:
    """Convert list of ((x1,y1,z1),(x2,y2,z2)) to (N,2,3) float32 array."""
    if not segs:
        return np.zeros((0, 2, 3), dtype=np.float32)
    return np.array(segs, dtype=np.float32)


def _make_view(azimuth: float, elevation: float, r: float, target: np.ndarray):
    """Return (V 3x3, eye 3) for camera orbit at azimuth/elevation around target."""
    az, el = azimuth, elevation
    eye = np.array([
        r * np.cos(el) * np.cos(az),
        r * np.sin(el),
        r * np.cos(el) * np.sin(az),
    ], dtype=np.float64) + target

    forward = target - eye
    forward /= np.linalg.norm(forward) + 1e-8
    world_up = np.array([0., 1., 0.])
    right = np.cross(forward, world_up)
    rn = np.linalg.norm(right)
    right = right / rn if rn > 1e-8 else np.array([1., 0., 0.])
    up_cam = np.cross(right, forward)

    V = np.stack([right, up_cam, forward], axis=0)  # 3×3, cam axes as rows
    return V.astype(np.float32), eye.astype(np.float32)


def _project(pts: np.ndarray, V: np.ndarray, eye: np.ndarray, f: float) -> np.ndarray:
    """Perspective-project Nx3 world points → Nx2 screen coords."""
    p_cam = (pts - eye) @ V.T          # Nx3 in camera space (Z = depth toward target)
    z = np.maximum(p_cam[:, 2], 0.001)
    sx =  f * p_cam[:, 0] / z + WIDTH  / 2
    sy = -f * p_cam[:, 1] / z + HEIGHT / 2
    return np.stack([sx, sy], axis=-1).astype(np.float32)


def _draw_segments(draw, proj: np.ndarray, color: tuple, width: int = 2):
    """Draw N line segments from an (2N, 2) array of projected points."""
    n = len(proj) // 2
    for i in range(n):
        p1 = proj[i * 2]
        p2 = proj[i * 2 + 1]
        draw.line([(float(p1[0]), float(p1[1])), (float(p2[0]), float(p2[1]))],
                  fill=color, width=width)


def _build_plate_segs(bw: float, bd: float, bh: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (plate_edge_segs, grid_segs, box_segs) as (N,2,3) arrays in render coords."""
    hw, hd = bw / 2, bd / 2
    grid_step = max(10, int(min(bw, bd) // 20) * 10)  # auto-scale grid for large plates

    # Plate border (4 edges at Y=0)
    corners = [
        (-hw, 0, -hd), (hw, 0, -hd),
        (hw, 0, hd), (-hw, 0, hd),
    ]
    plate_segs = np.array(
        [(corners[i], corners[(i+1) % 4]) for i in range(4)], dtype=np.float32
    )

    # Grid lines at Y=0
    xs = np.arange(-hw, hw + 1, grid_step)
    zs = np.arange(-hd, hd + 1, grid_step)
    grid_list = []
    for x in xs:
        grid_list.append(((x, 0, -hd), (x, 0, hd)))
    for z in zs:
        grid_list.append(((-hw, 0, z), (hw, 0, z)))
    grid_segs = np.array(grid_list, dtype=np.float32)

    # Volume wireframe: 8 corners, 12 edges
    cx8 = [(-hw, 0, -hd), (hw, 0, -hd), (hw, 0, hd), (-hw, 0, hd),
           (-hw, bh, -hd), (hw, bh, -hd), (hw, bh, hd), (-hw, bh, hd)]
    box_edges = [(0,1),(1,2),(2,3),(3,0), (4,5),(5,6),(6,7),(7,4),
                 (0,4),(1,5),(2,6),(3,7)]
    box_segs = np.array([(cx8[a], cx8[b]) for a, b in box_edges], dtype=np.float32)

    return plate_segs, grid_segs, box_segs


def _render_turntable(
    gcode_path: str,
    out_path: str,
    elevation_deg: float = 15.0,
    build_volume: "tuple[float, float, float] | None" = None,
) -> bool:
    try:
        import imageio
        from PIL import Image, ImageDraw
    except ImportError as e:
        print(f"Error: {e}. Run: pip install imageio imageio-ffmpeg Pillow", file=sys.stderr)
        return False

    t0 = time.perf_counter()

    # Parse G-code (all segments; adaptive cap applied below)
    body_segs, support_segs = parse_gcode(gcode_path, sample_rate=1)
    total = len(body_segs) + len(support_segs)
    if total > TARGET_SEGMENTS:
        step = max(2, total // TARGET_SEGMENTS)
        body_segs = body_segs[::step]
        support_segs = support_segs[::step]
    if not body_segs and not support_segs:
        print("Error: No extrusion segments found in G-code", file=sys.stderr)
        return False
    print(
        f"[gcode-preview] Parsed: {len(body_segs)} body, {len(support_segs)} support segments",
        file=sys.stderr,
    )

    body_arr    = _segs_to_array(body_segs)    # (N,2,3)
    support_arr = _segs_to_array(support_segs)

    # Bounds & centering
    all_pts = []
    if len(body_arr):    all_pts.append(body_arr.reshape(-1, 3))
    if len(support_arr): all_pts.append(support_arr.reshape(-1, 3))
    all_pts_arr = np.vstack(all_pts)
    min_pt = all_pts_arr.min(axis=0)
    max_pt = all_pts_arr.max(axis=0)
    diag = float(np.linalg.norm(max_pt - min_pt)) or 1.0

    if build_volume:
        bw, bd, bh = build_volume
        hw, hd = bw / 2, bd / 2
        # Gcode origin is front-left corner of plate; render plate is centered at (0,0,0).
        # Gcode→render: X→X, gcode_Z→render_Y, gcode_Y→render_Z*(-1).
        # Model XZ center in render coords: (bw/2, -bd/2). Subtract to center at origin.
        offset = np.array([bw / 2, 0.0, -bd / 2], dtype=np.float32)
        cam_target = np.array([0.0, max_pt[1] / 2, 0.0], dtype=np.float32)
        # Fit the full build plate in view with 15% margin
        half_extent = max(hw, hd)
        r = half_extent * 1.25 / np.tan(FOV_RAD / 2)
    else:
        offset = ((min_pt + max_pt) / 2).astype(np.float32)
        cam_target = np.zeros(3, dtype=np.float32)
        r = (diag / 2) * 1.25 / np.tan(FOV_RAD / 2)

    if len(body_arr):    body_arr    -= offset
    if len(support_arr): support_arr -= offset

    # Precompute build-plate geometry (already centered at origin — no offset needed)
    plate_segs = grid_segs = box_segs = None
    if build_volume:
        plate_segs, grid_segs, box_segs = _build_plate_segs(bw, bd, bh)

    f = (HEIGHT / 2) / np.tan(FOV_RAD / 2)  # focal length in pixels
    el = np.radians(elevation_deg)

    def render_frame(azimuth: float) -> np.ndarray:
        V, eye = _make_view(azimuth, el, r, cam_target)

        img = Image.new("RGB", (WIDTH, HEIGHT), BG_COLOR)
        draw = ImageDraw.Draw(img)

        # Build plate (back-to-front: grid → border → wireframe)
        if plate_segs is not None:
            proj = _project(grid_segs.reshape(-1, 3), V, eye, f)
            _draw_segments(draw, proj, GRID_COLOR, 1)
            proj = _project(plate_segs.reshape(-1, 3), V, eye, f)
            _draw_segments(draw, proj, PLATE_COLOR, 2)
            proj = _project(box_segs.reshape(-1, 3), V, eye, f)
            _draw_segments(draw, proj, BOX_COLOR, 1)

        # Supports (behind body)
        if len(support_arr):
            proj = _project(support_arr.reshape(-1, 3), V, eye, f)
            _draw_segments(draw, proj, SUPPORT_COLOR, 2)

        # Body (on top)
        if len(body_arr):
            proj = _project(body_arr.reshape(-1, 3), V, eye, f)
            _draw_segments(draw, proj, BODY_COLOR, 2)

        return np.asarray(img)

    frames = [render_frame(2 * np.pi * i / N_FRAMES) for i in range(N_FRAMES)]

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    writer = imageio.get_writer(out_path, fps=FPS, codec="libx264", quality=8)
    for f_arr in frames:
        writer.append_data(f_arr)
    writer.close()

    t_total = time.perf_counter() - t0
    print(f"[gcode-preview] Rendered in {t_total:.1f}s", file=sys.stderr)
    return True


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d gcode-preview",
        description="Render 360° turntable video of G-code (body + supports in different colors)",
    )
    parser.add_argument("--input", "-i", required=True, help="Input G-code file")
    parser.add_argument("--output", "-o", help="Output MP4 path (default: input_gcode_preview.mp4)")
    parser.add_argument("--elevation", type=float, default=15.0, help="Camera elevation in degrees")
    parser.add_argument(
        "--build-volume", default=None,
        metavar="WxDxH",
        help="Printer build volume in mm (e.g. 350x350x350). Shows build plate, grid, and volume wireframe.",
    )
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    out = Path(parsed.output) if parsed.output else inp.with_stem(inp.stem + "_gcode_preview").with_suffix(".mp4")
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1

    build_volume = None
    if parsed.build_volume:
        from ..scene_build_area import parse_build_volume
        try:
            build_volume = parse_build_volume(parsed.build_volume)
        except ValueError as e:
            print(f"Error: --build-volume: {e}", file=sys.stderr)
            return 1

    if _render_turntable(str(inp), str(out), parsed.elevation, build_volume=build_volume):
        size = out.stat().st_size
        print(f"Wrote {out} ({size} bytes)")
        return 0
    return 1
