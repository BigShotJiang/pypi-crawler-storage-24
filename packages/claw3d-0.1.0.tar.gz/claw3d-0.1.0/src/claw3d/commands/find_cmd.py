"""claw3d find — Search Thingiverse and return only models that fit the printer.

Combines search + thumbnail download + fetch + fit-check into one deterministic step.
The agent only needs to run this once and then make a single visual choice from the
guaranteed-fitting results. No fit-check decisions are left to the agent.

Exit 0: at least one fitting model found (results printed to stdout).
Exit 1: no fitting models found after exhausting all search results.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import requests
import trimesh


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d find",
        description="Search Thingiverse and return models verified to fit your printer",
    )
    parser.add_argument("query", help="Search query (e.g. 'wine stand')")
    parser.add_argument(
        "--limit", type=int, default=20,
        help="Max results to search (default: 20)",
    )
    parser.add_argument(
        "--max-passing", type=int, default=5,
        help="Stop once this many models pass fit-check (default: 5)",
    )
    parser.add_argument(
        "--build", "-b", default=None,
        help="Build volume WxDxH in mm (e.g. 220x215x245). Defaults to default printer.",
    )
    parser.add_argument(
        "--output-dir", "-o", default=".",
        help="Directory to write thumbnails and model files (default: current dir)",
    )
    parsed = parser.parse_args(args)

    # Resolve build volume
    if parsed.build:
        from .fit_check_cmd import _parse_build
        try:
            bw, bd, bh = _parse_build(parsed.build)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    else:
        from ..config import get_default_printer_build_volume
        vol = get_default_printer_build_volume()
        if not vol:
            print("Error: --build required (no default printer build volume configured)", file=sys.stderr)
            return 1
        bw, bd, bh = vol

    # Search
    from ..directory.providers.thingiverse import ThingiverseProvider
    provider = ThingiverseProvider()
    if not provider.is_configured():
        print("Error: THINGIVERSE_ACCESS_TOKEN not set.", file=sys.stderr)
        return 1

    print(f'Searching for "{parsed.query}"...', file=sys.stderr)
    results = provider.search(parsed.query, limit=parsed.limit)
    if not results:
        print("No results found.", file=sys.stderr)
        return 1

    # Always use absolute path so all output filenames in results are absolute
    out_dir = Path(parsed.output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # Download all thumbnails upfront (small, fast)
    print(f"Downloading thumbnails for {len(results)} results...", file=sys.stderr)
    thumbnails: dict[str, Path] = {}
    for r in results:
        if not r.thumbnail_url:
            continue
        thumb_path = out_dir / f"thumb_{r.id}.jpg"
        try:
            resp = requests.get(r.thumbnail_url, timeout=15, stream=True)
            if resp.status_code == 200:
                with open(thumb_path, "wb") as f:
                    for chunk in resp.iter_content(65536):
                        f.write(chunk)
                # Accept only if file has meaningful content (>500 bytes)
                if thumb_path.stat().st_size > 500:
                    thumbnails[r.id] = thumb_path
                else:
                    thumb_path.unlink(missing_ok=True)
        except Exception:
            pass

    # Import fit-check helpers
    from .fit_check_cmd import _find_fitting_orientation, _apply_rotation_to_file, _rotated_extents
    from ..directory.fetch import fetch_thingiverse, ensure_glb_for_preview

    print(
        f"Fit-checking models for {bw:.0f}×{bd:.0f}×{bh:.0f}mm build volume...",
        file=sys.stderr,
    )

    passing = []
    checked = 0

    for r in results:
        if len(passing) >= parsed.max_passing:
            break

        checked += 1
        thing_id = r.id
        model_out = out_dir / f"model_{thing_id}.glb"
        print(f"  [{checked}/{len(results)}] {r.name} (ID: {thing_id})", file=sys.stderr)

        # Fetch
        with tempfile.TemporaryDirectory() as td:
            tmp_dir = Path(td)
            written, is_multi = fetch_thingiverse(thing_id, tmp_dir, token=None)
            if not written:
                print(f"    Fetch failed — skip", file=sys.stderr)
                continue

            if is_multi:
                # Copy parts to persistent directory for packing
                parts_dir = out_dir / f"model_{thing_id}_parts"
                if parts_dir.exists():
                    shutil.rmtree(parts_dir)
                shutil.copytree(written, parts_dir)

                # Pack using pack_cmd.run so all pack logic is reused
                from .pack_cmd import run as pack_run
                rc = pack_run(["-i", str(parts_dir), "-o", str(model_out)])
                if rc != 0:
                    print(f"    Pack failed (part too large) — skip", file=sys.stderr)
                    continue
                fit_path = model_out  # fit-check the packed GLB
            else:
                orig_suffix = written.suffix.lower()
                if orig_suffix != ".glb":
                    orig_out = model_out.with_suffix(orig_suffix)
                    shutil.copy2(written, orig_out)
                    if not ensure_glb_for_preview(orig_out, model_out):
                        print(f"    GLB conversion failed — skip", file=sys.stderr)
                        continue
                    fit_path = orig_out  # fit-check the STL/OBJ
                else:
                    shutil.copy2(written, model_out)
                    fit_path = model_out

        # Guard: skip if file doesn't exist (copy may have silently failed)
        fit_path = fit_path.resolve()
        if not fit_path.exists():
            print(f"    File not found after fetch: {fit_path.name} — skip", file=sys.stderr)
            continue

        # Guard: skip very large files to prevent OOM in the container (>40MB)
        file_mb = fit_path.stat().st_size / (1024 * 1024)
        if file_mb > 40:
            print(f"    Model too large ({file_mb:.0f}MB) — skip", file=sys.stderr)
            continue

        # Fit-check
        try:
            mesh = trimesh.load(str(fit_path), force="mesh")
            if isinstance(mesh, trimesh.Scene):
                mesh = mesh.dump(concatenate=True)
            if not hasattr(mesh, "bounds") or mesh.bounds is None:
                print(f"    Could not compute bounds — skip", file=sys.stderr)
                continue
            ext_arr = mesh.bounds[1] - mesh.bounds[0]
            extents = (float(ext_arr[0]), float(ext_arr[1]), float(ext_arr[2]))
        except Exception as e:
            print(f"    Load failed: {e} — skip", file=sys.stderr)
            continue

        fitting = _find_fitting_orientation(extents, bw, bd, bh)
        if fitting is None:
            print(
                f"    Doesn't fit in any orientation "
                f"({extents[0]:.0f}×{extents[1]:.0f}×{extents[2]:.0f}mm) — skip",
                file=sys.stderr,
            )
            continue

        rx, ry, rz = fitting
        fx, fy, fz = _rotated_extents(*extents, rx, ry, rz)

        # Apply rotation in-place so model and sidecar are already correctly oriented
        if rx != 0 or ry != 0 or rz != 0:
            try:
                _apply_rotation_to_file(fit_path, rx, ry, rz)
                if fit_path != model_out and model_out.exists():
                    _apply_rotation_to_file(model_out, rx, ry, rz)
                rotation_str = f"{rx:.0f}°X {ry:.0f}°Y {rz:.0f}°Z"
                print(f"    PASS — rotated {rotation_str} → {fx:.0f}×{fy:.0f}×{fz:.0f}mm ✓", file=sys.stderr)
            except Exception as e:
                print(f"    Warning: rotation apply failed: {e}", file=sys.stderr)
                rotation_str = "none"
        else:
            rotation_str = "none"
            print(f"    PASS — fits as-is → {fx:.0f}×{fy:.0f}×{fz:.0f}mm ✓", file=sys.stderr)

        # Write provenance sidecar (includes fitting rotation for re-application after re-fetch)
        from datetime import datetime, timezone
        src = {
            "source": "thingiverse",
            "thing_id": thing_id,
            "name": r.name,
            "url": f"https://www.thingiverse.com/thing:{thing_id}",
            "query": parsed.query,
            "fitting_rotation": [rx, ry, rz],
            "fitted_extents_mm": [round(fx, 1), round(fy, 1), round(fz, 1)],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        try:
            model_out.with_suffix(".source.json").write_text(json.dumps(src, indent=2))
        except OSError:
            pass

        passing.append({
            "id": thing_id,
            "name": r.name,
            "author": r.author or "",
            "url": r.url,
            "thumbnail": str(thumbnails.get(r.id, "")),
            "model": str(model_out),
            "extents_mm": [round(fx, 1), round(fy, 1), round(fz, 1)],
            "rotation_applied": rotation_str,
            "is_multi_part": is_multi,
        })

    if not passing:
        print(f"\nNo fitting models found (checked {checked}/{len(results)}).")
        return 1

    # Output results
    print(
        f"\n{len(passing)} model(s) fit your printer ({bw:.0f}×{bd:.0f}×{bh:.0f}mm). "
        f"Checked {checked} of {len(results)} results.\n"
    )
    for i, m in enumerate(passing, 1):
        print(f"[{i}] {m['name']}")
        print(f"    ID: {m['id']}")
        print(f"    URL: {m['url']}")
        if m["author"]:
            print(f"    By: {m['author']}")
        print(f"    Thumbnail: {m['thumbnail']}")
        print(f"    Model: {m['model']}")
        print(f"    Extents: {m['extents_mm'][0]}×{m['extents_mm'][1]}×{m['extents_mm'][2]}mm")
        if m["rotation_applied"] != "none":
            print(f"    Rotation applied: {m['rotation_applied']}")
        print()

    return 0
