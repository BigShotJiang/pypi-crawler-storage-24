"""claw3d search - search 3D model directories (Thingiverse, etc.)."""

from __future__ import annotations

import argparse
import sys

from ..directory import get_registry_from_config, list_providers


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d search",
        description="Search 3D model repositories (Thingiverse, etc.)",
    )
    parser.add_argument(
        "query",
        nargs="?",
        default="",
        help="Search term (e.g. 'dragon', 'vase')",
    )
    parser.add_argument(
        "-l",
        "--limit",
        type=int,
        default=10,
        help="Max results per provider (default: 10)",
    )
    parser.add_argument(
        "-p",
        "--providers",
        type=str,
        default=None,
        metavar="LIST",
        help="Comma-separated providers (default: all from CLAW3D_DIRECTORY_PROVIDERS)",
    )
    parser.add_argument(
        "--list-providers",
        action="store_true",
        help="List configured providers and exit",
    )
    parsed = parser.parse_args(args)

    if parsed.list_providers:
        for pid, name, configured in list_providers():
            status = "configured" if configured else "missing token"
            print(f"  {pid}: {name} ({status})")
        return 0

    if not parsed.query.strip():
        print("Usage: claw3d search <query> [options]", file=sys.stderr)
        print("Example: claw3d search dragon --limit 5", file=sys.stderr)
        return 1

    provider_ids = None
    if parsed.providers:
        provider_ids = [p.strip() for p in parsed.providers.split(",") if p.strip()]

    providers = get_registry_from_config(provider_ids)
    if not providers:
        print("No directory providers configured.", file=sys.stderr)
        print("Set CLAW3D_DIRECTORY_PROVIDERS=thingiverse and THINGIVERSE_ACCESS_TOKEN", file=sys.stderr)
        return 1

    configured = [p for p in providers if p.is_configured()]
    if not configured:
        print("No providers have credentials. Set THINGIVERSE_ACCESS_TOKEN for Thingiverse.", file=sys.stderr)
        return 1

    total = 0
    for prov in configured:
        results = prov.search(parsed.query, limit=parsed.limit)
        if results:
            print(f"\n--- {prov.name} ---")
            for i, r in enumerate(results, 1):
                print(f"  [{i}] {r.name}")
                print(f"    ID: {r.id}")
                print(f"    URL: {r.url}")
                if r.author:
                    print(f"    By: {r.author}")
                if r.thumbnail_url:
                    print(f"    Thumbnail: {r.thumbnail_url}")
                if r.download_url:
                    print(f"    Download: {r.download_url}")
                print()
                total += 1

    if total == 0:
        print("No results found.")
    return 0
