"""Print G-code to 3D printer via backend abstraction.

Supports multiple printers via PrinterRegistry. Use CLAW3D_PRINTER for default,
CLAW3D_PRINTERS JSON for multi-printer setup.
"""

import argparse
import json
import os
import sys
from pathlib import Path

from ..backends import (
    PrinterRegistry,
    PrinterState,
    create_moonraker_from_address,
    get_registry_from_env,
)


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d print",
        description="Upload G-code and start print on a 3D printer",
    )
    parser.add_argument("--gcode", "-g", required=True, help="G-code file path")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parser.add_argument("--filename", default=None, help="Filename on printer (default: claw3d_<id>.gcode for model_<id>.gcode)")
    parsed = parser.parse_args(args)

    # Resolve printer: arg > env > config default
    printer_arg = (
        parsed.printer
        or os.environ.get("CLAW3D_PRINTER")
    )
    if not printer_arg:
        try:
            from ..config import get_default_printer

            printer_arg = get_default_printer()
        except Exception:
            pass
    if not printer_arg:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1

    registry = get_registry_from_env()

    # Use registry if printer_arg is a known id, else treat as host:port address
    backend = registry.get(printer_arg)
    if not backend:
        backend = create_moonraker_from_address(printer_arg)

    path = Path(parsed.gcode)
    if not path.exists():
        print(f"Error: G-code not found: {path}", file=sys.stderr)
        return 1

    # Use claw3d_<id>.gcode on printer so we can infer which model
    # is printing from the filename and clean up old claw3d_* files
    if parsed.filename:
        filename = parsed.filename
    elif path.stem.startswith("model_") and len(path.stem) > 6:
        model_id = path.stem[6:]  # strip "model_"
        filename = f"claw3d_{model_id}.gcode"
    else:
        filename = path.name

    try:
        backend.print_file(path, filename=filename)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    base = getattr(backend, "_base", printer_arg or "printer")
    print(f"Uploaded {filename} and started print on {base}")
    return 0


def _extract_model_id_from_printer_filename(filename: str) -> str | None:
    """If filename is claw3d_<id>.gcode, return the model id. Else None."""
    if not filename or not filename.startswith("claw3d_") or not filename.endswith(".gcode"):
        return None
    mid = filename[7:-6]  # strip "claw3d_" and ".gcode"
    return mid if mid else None


def run_status(args: list[str]) -> int:
    """Show status of one or all printers."""
    parser = argparse.ArgumentParser(prog="claw3d status", description="Show printer status")
    parser.add_argument("--printer", "-p", default=None, help="Printer id (omit for all)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parsed = parser.parse_args(args)

    registry = get_registry_from_env()
    if not registry.list_ids():
        print("Error: No printers configured. Set CLAW3D_PRINTER or CLAW3D_PRINTERS", file=sys.stderr)
        return 1

    if parsed.printer:
        status = registry.get_status(parsed.printer)
        if not status:
            print(f"Error: Printer '{parsed.printer}' not found or offline", file=sys.stderr)
            return 1
        statuses = {parsed.printer: status}
    else:
        statuses = registry.get_all_status()

    if parsed.json:
        out = {}
        for pid, s in statuses.items():
            out[pid] = {
                "state": s.state.value,
                "current_file": s.current_file,
                "progress": s.progress,
                "print_duration": s.print_duration,
                "print_duration_left": s.print_duration_left,
                "temperatures": s.temperatures,
                "camera_url": s.camera_url,
            }
        print(json.dumps(out, indent=2))
        return 0

    for pid, s in statuses.items():
        file_display = s.current_file or ""
        if file_display:
            mid = _extract_model_id_from_printer_filename(file_display)
            if mid:
                file_display = f"{file_display} (model {mid})"
            elif not file_display.startswith("claw3d_"):
                file_display = f"{file_display} (external)"
        file_info = f" | {file_display}" if file_display else ""
        prog = f"{s.progress:.1f}%" if s.progress else "-"
        dur = f"{s.print_duration/60:.1f}m" if s.print_duration else "-"
        left = f" (~{s.print_duration_left/60:.0f}m left)" if s.print_duration_left else ""
        temps = " | ".join(f"{k}: {v:.0f}°C" for k, v in s.temperatures.items()) if s.temperatures else ""
        cam = f" | camera: {s.camera_url}" if s.camera_url else ""
        print(f"{pid}: {s.state.value}{file_info} | {prog} | {dur}{left}")
        if temps:
            print(f"  temps: {temps}")
        if cam:
            print(f"  {cam}")
    return 0


def _get_backend(printer_arg):  # Optional[str] -> Optional[Tuple[Backend, str]]
    """Resolve backend from printer id or address. Returns (backend, display_name) or None."""
    printer_arg = (
        printer_arg
        or os.environ.get("CLAW3D_PRINTER")
    )
    if not printer_arg:
        try:
            from ..config import get_default_printer

            printer_arg = get_default_printer()
        except Exception:
            pass
    if not printer_arg:
        return None
    registry = get_registry_from_env()
    backend = registry.get(printer_arg)
    if not backend:
        backend = create_moonraker_from_address(printer_arg)
    return (backend, printer_arg)


def run_pause(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d pause", description="Pause current print")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.pause()
        print(f"Paused print on {name}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_resume(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d resume", description="Resume paused print")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.resume()
        print(f"Resumed print on {name}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_cancel(args: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="claw3d cancel", description="Cancel current print")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.cancel()
        print(f"Cancelled print on {name}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_preheat(args) -> int:
    parser = argparse.ArgumentParser(prog="claw3d preheat", description="Set extruder/bed target temperatures")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parser.add_argument("--extruder", "-e", type=float, default=None, help="Extruder temp (°C)")
    parser.add_argument("--bed", "-b", type=float, default=None, help="Bed temp (°C)")
    parsed = parser.parse_args(args)
    if parsed.extruder is None and parsed.bed is None:
        print("Error: Specify --extruder and/or --bed", file=sys.stderr)
        return 1
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.preheat(extruder=parsed.extruder, bed=parsed.bed)
        parts = []
        if parsed.extruder is not None:
            parts.append(f"extruder {parsed.extruder}°C")
        if parsed.bed is not None:
            parts.append(f"bed {parsed.bed}°C")
        print(f"Heating {', '.join(parts)} on {name}")
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_cooldown(args) -> int:
    parser = argparse.ArgumentParser(prog="claw3d cooldown", description="Turn off all heaters")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.cooldown()
        print(f"Heaters off on {name}")
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_home(args) -> int:
    parser = argparse.ArgumentParser(prog="claw3d home", description="Home printer axes")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parser.add_argument("--axes", "-a", nargs="+", default=None, help="Axes to home (e.g. x y z, default: all)")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.home(axes=parsed.axes)
        ax = " ".join(parsed.axes) if parsed.axes else "all"
        print(f"Homing {ax} on {name}")
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_files(args) -> int:
    parser = argparse.ArgumentParser(prog="claw3d files", description="List gcode files on printer")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parser.add_argument("--path", default="", help="Subdirectory under gcodes (e.g. subfolder)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, _ = res
    try:
        items = backend.list_files(path=parsed.path)
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    if parsed.json:
        print(json.dumps(items, indent=2))
        return 0
    for f in items:
        path = f.get("path") or f.get("filename") or f.get("dirname", "?")
        size = f.get("size", 0)
        sz = f"{size/1024:.1f}K" if size else "-"
        print(f"  {path}  ({sz})")
    return 0


def run_start(args) -> int:
    parser = argparse.ArgumentParser(prog="claw3d start", description="Start an already-uploaded gcode file")
    parser.add_argument("--file", "-f", required=True, help="Filename on printer (e.g. model.gcode)")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.start_existing(parsed.file)
        print(f"Started {parsed.file} on {name}")
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_emergency_stop(args) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d emergency-stop",
        description="Immediate emergency stop (shutdown state). Use sparingly.",
    )
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, name = res
    try:
        backend.emergency_stop()
        print(f"Emergency stop sent to {name}")
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


def run_metadata(args) -> int:
    parser = argparse.ArgumentParser(prog="claw3d metadata", description="Get gcode file metadata from printer")
    parser.add_argument("--file", "-f", required=True, help="Filename on printer (e.g. model.gcode)")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parser.add_argument("--json", action="store_true", help="Output raw JSON")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, _ = res
    try:
        meta = backend.get_file_metadata(parsed.file)
    except NotImplementedError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    if meta is None:
        print("No metadata available", file=sys.stderr)
        return 1
    if parsed.json:
        print(json.dumps(meta, indent=2))
        return 0
    # Human-readable summary
    est = meta.get("estimated_time")
    if est:
        mins = int(est) // 60
        print(f"Estimated time: {mins} min")
    for k in ("filament_type", "filament_name", "layer_height", "object_height"):
        if meta.get(k):
            print(f"  {k}: {meta[k]}")
    return 0


def run_camera(args: list[str]) -> int:
    """Output camera stream or snapshot URL for the printer."""
    parser = argparse.ArgumentParser(prog="claw3d camera", description="Get printer camera URL")
    parser.add_argument("--printer", "-p", default=None, help="Printer id or ip:port")
    parser.add_argument("--snapshot", action="store_true", help="Use snapshot URL instead of stream")
    parsed = parser.parse_args(args)
    res = _get_backend(parsed.printer)
    if not res:
        print("Error: --printer or CLAW3D_PRINTER required", file=sys.stderr)
        return 1
    backend, _ = res
    if parsed.snapshot and hasattr(backend, "get_camera_snapshot_url"):
        url = backend.get_camera_snapshot_url()
    else:
        url = backend.get_camera_url() if hasattr(backend, "get_camera_url") else None
    if not url:
        print("Error: No camera configured for this printer", file=sys.stderr)
        return 1
    print(url)
    return 0


def _printer_display_labels() -> dict[str, str]:
    """Get display label for each printer id: name (id) if name exists, else id."""
    try:
        from ..config import get_printers

        printers = get_printers()
        return {
            pid: f"{p.get('name', '')} ({pid})" if p.get("name") and p.get("name") != pid else pid
            for pid, p in printers.items()
            if isinstance(p, dict)
        }
    except Exception:
        return {}


def run_printers(args: list[str]) -> int:
    """List configured printers and their status."""
    parser = argparse.ArgumentParser(prog="claw3d printers", description="List printers")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parsed = parser.parse_args(args)

    registry = get_registry_from_env()
    ids = registry.list_ids()
    if not ids:
        print("No printers configured. Set CLAW3D_PRINTER or CLAW3D_PRINTERS", file=sys.stderr)
        return 0

    all_status = registry.get_all_status()
    busy = registry.printers_busy()
    idle = registry.printers_idle()
    labels = _printer_display_labels()

    if parsed.json:
        out = {
            "printers": ids,
            "labels": {pid: labels.get(pid, pid) for pid in ids},
            "status": {pid: s.state.value for pid, s in all_status.items()},
            "busy": busy,
            "idle": idle,
        }
        print(json.dumps(out, indent=2))
        return 0

    printer_list = ", ".join(labels.get(pid, pid) for pid in ids)
    print("Printers:", printer_list)
    print("Busy:", ", ".join(busy) if busy else "(none)")
    print("Idle:", ", ".join(idle) if idle else "(none)")
    return 0
