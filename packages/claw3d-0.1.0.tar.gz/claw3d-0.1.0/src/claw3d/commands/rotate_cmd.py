"""claw3d rotate — Apply rotation to a 3D model and save it back.

Rotation is baked into the file: the model is permanently rotated.
This makes rotation deterministic — no state tracking needed.
The agent just calls `claw3d rotate` each time the user asks,
and the file always reflects the accumulated orientation.

Supports GLB, STL, OBJ. For GLB files, scene structure
(materials, textures) is preserved.
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import numpy as np
import trimesh

MAX_BACKUPS = 5  # keep up to 5 undo levels


def _apply_rotation(mesh_or_scene, rx: float, ry: float, rz: float):
    """Apply Euler rotation (degrees) around X, Y, Z axes."""
    R = trimesh.transformations.euler_matrix(
        np.radians(rx), np.radians(ry), np.radians(rz), axes="rxyz"
    )
    mesh_or_scene.apply_transform(R)


def _backup(path: Path) -> None:
    """Create a backup of the file before overwriting. Rotates up to MAX_BACKUPS."""
    if not path.exists():
        return
    # Shift existing backups: .bak.3 → .bak.4, .bak.2 → .bak.3, etc.
    for i in range(MAX_BACKUPS, 1, -1):
        older = path.with_suffix(f"{path.suffix}.bak.{i - 1}")
        newer = path.with_suffix(f"{path.suffix}.bak.{i}")
        if older.exists():
            shutil.move(str(older), str(newer))
    # Save current as .bak.1
    bak = path.with_suffix(f"{path.suffix}.bak.1")
    shutil.copy2(str(path), str(bak))


def _undo(path: Path) -> bool:
    """Restore the most recent backup. Returns True on success."""
    bak = path.with_suffix(f"{path.suffix}.bak.1")
    if not bak.exists():
        return False
    shutil.copy2(str(bak), str(path))
    # Shift backups down: .bak.2 → .bak.1, .bak.3 → .bak.2, etc.
    for i in range(1, MAX_BACKUPS):
        newer = path.with_suffix(f"{path.suffix}.bak.{i + 1}")
        current = path.with_suffix(f"{path.suffix}.bak.{i}")
        if newer.exists():
            shutil.move(str(newer), str(current))
        else:
            current.unlink(missing_ok=True)
            break
    else:
        path.with_suffix(f"{path.suffix}.bak.{MAX_BACKUPS}").unlink(missing_ok=True)
    return True


def run(args: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="claw3d rotate",
        description="Rotate a 3D model and save the result. Rotation is baked into the file.",
    )
    parser.add_argument("--input", "-i", required=True, help="Input 3D file (GLB, STL, OBJ)")
    parser.add_argument("--output", "-o", default=None, help="Output path (default: overwrite input)")
    parser.add_argument("--rotation-x", type=float, default=0.0, help="Degrees to rotate around X axis")
    parser.add_argument("--rotation-y", type=float, default=0.0, help="Degrees to rotate around Y axis")
    parser.add_argument("--rotation-z", type=float, default=0.0, help="Degrees to rotate around Z axis")
    parser.add_argument("--undo", action="store_true", help="Undo the last rotation (restore backup)")
    parsed = parser.parse_args(args)

    inp = Path(parsed.input)
    if not inp.exists():
        print(f"Error: Input not found: {inp}", file=sys.stderr)
        return 1

    # Handle --undo
    if parsed.undo:
        if _undo(inp):
            print(f"Restored previous version of {inp}")
            return 0
        else:
            print(f"Error: No backup found for {inp}", file=sys.stderr)
            return 1

    rx, ry, rz = parsed.rotation_x, parsed.rotation_y, parsed.rotation_z
    if rx == 0 and ry == 0 and rz == 0:
        print("No rotation specified (all axes are 0°). Nothing to do.", file=sys.stderr)
        return 0

    out = Path(parsed.output) if parsed.output else inp
    ext = inp.suffix.lower()

    # Detect GLB by magic bytes if extension is missing
    is_glb = ext in (".glb", ".gltf")
    if not is_glb:
        data = inp.read_bytes()
        if data[:4] == b"glTF":
            is_glb = True
            ext = ".glb"

    # Backup before overwriting (for undo support)
    if out == inp:
        _backup(inp)

    try:
        if is_glb:
            # Load as scene to preserve materials, textures, hierarchy
            scene = trimesh.load(str(inp), file_type="glb", force="scene")
            _apply_rotation(scene, rx, ry, rz)
            # Normalize: translate so min Z = 0 (model sits on build plate)
            try:
                combined = scene.dump(concatenate=True)
                if combined.bounds is not None:
                    min_z = float(combined.bounds[0][2])
                    if abs(min_z) > 0.001:
                        T = np.eye(4)
                        T[2, 3] = -min_z
                        scene.apply_transform(T)
            except Exception:
                pass  # Skip normalization if scene can't be dumped
            scene.export(str(out), file_type="glb")
        else:
            # STL/OBJ — load as mesh
            mesh = trimesh.load(str(inp), force="mesh")
            _apply_rotation(mesh, rx, ry, rz)
            # Normalize: translate so min Z = 0 (model sits on build plate)
            if mesh.bounds is not None:
                mesh.vertices[:, 2] -= mesh.bounds[0][2]
            out_ext = out.suffix.lower() or ext
            mesh.export(str(out), file_type=out_ext.lstrip("."))

        size = out.stat().st_size
        axes = []
        if rx: axes.append(f"X={rx}°")
        if ry: axes.append(f"Y={ry}°")
        if rz: axes.append(f"Z={rz}°")
        print(f"Rotated {', '.join(axes)} → {out} ({size} bytes)")
        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
