"""claw3d setup — show configuration and slicer URL."""

import os

from ..config import get_default_profile, get_slicer_url, get_ai_provider, load_config


def run(args: list[str]) -> int:
    """Show current config and how to use the remote slicer."""
    cfg = load_config()
    slicer_url = (
        get_slicer_url()
        or os.environ.get("CLAW3D_SLICER_URL")
        or "(not set, defaults to http://localhost:8000)"
    )
    profile = get_default_profile() or "(none)"
    provider = get_ai_provider() or os.environ.get("CLAW3D_PROVIDER") or "fal"

    print("claw3d configuration")
    print()
    print(f"  AI provider: {provider}")
    print(f"  Slicer URL:  {slicer_url}")
    print(f"  Default profile: {profile}")
    print()
    print("To change AI provider: claw3d configure <fal|replicate>")
    print("To set models per step: claw3d configure models")
    print("To see printer protocols: claw3d configure backends")
    print("Slicing uses the remote curaengine-slicer-api. Set CLAW3D_SLICER_URL")
    print("or run with Docker Compose (slicer service is included).")
    print()
    print("Examples:")
    print("  claw3d configure fal")
    print("  claw3d profile create --from-3mf settings.3mf --name my_printer")
    print("  claw3d slice -i model.glb --profile <id> -o model.gcode")
    return 0
