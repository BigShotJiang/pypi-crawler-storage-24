"""
OpenIntent SDK - High-Level Agent Abstractions

Provides declarative, minimal-boilerplate abstractions for building
multi-agent systems with OpenIntent.

Usage:
    ```python
    from openintent import Agent, on_assignment

    @Agent("research-bot")
    class ResearchAgent:
        @on_assignment
        async def work(self, intent):
            return {"result": "done"}  # Auto-patches state

    ResearchAgent.run()
    ```
"""

# mypy: disable-error-code="attr-defined, arg-type, misc, call-arg"

import asyncio
import logging
from abc import ABC
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, TypeVar, Union

from .client import AsyncOpenIntentClient, OpenIntentClient
from .exceptions import InputCancelledError, InputTimeoutError
from .models import (
    AccessRequest,
    ACLEntry,
    EngagementDecision,
    EngagementSignals,
    Escalation,
    EventType,
    HumanRetryPolicy,
    InputResponse,
    Intent,
    IntentContext,
    IntentPortfolio,
    IntentStatus,
    MembershipRole,
    PeerInfo,
    Permission,
    ResponseType,
    SuspensionChoice,
    SuspensionRecord,
)
from .streaming import SSEEvent, SSEEventType, SSEStream, SSESubscription

logger = logging.getLogger("openintent.agents")


class _ToolsProxy:
    """Proxy for agent tool operations."""

    def __init__(self, agent):
        self._agent = agent

    async def invoke(self, tool_name, **kwargs):
        return await self._agent.async_client.invoke_tool(
            tool_name=tool_name,
            agent_id=self._agent._agent_id,
            parameters=kwargs,
        )


class _GovernanceProxy:
    """Proxy for governance policy operations (RFC-0013 Enforcement).

    Accessible via ``self.governance`` on any agent.  Provides methods
    to set policies, request approval, and await approval resolution.
    """

    def __init__(self, agent):
        self._agent = agent

    async def set_policy(self, intent_id: str, policy: dict, version: int) -> dict:
        """Set or update a governance policy on an intent."""
        return await self._agent.async_client.set_governance_policy(
            intent_id=intent_id, policy=policy, version=version
        )

    async def get_policy(self, intent_id: str) -> dict:
        """Get the effective governance policy for an intent."""
        return await self._agent.async_client.get_governance_policy(intent_id)

    async def remove_policy(self, intent_id: str, version: int) -> dict:
        """Remove a governance policy (returns to permissive defaults)."""
        return await self._agent.async_client.remove_governance_policy(
            intent_id=intent_id, version=version
        )

    async def request_approval(
        self, intent_id: str, action: str, reason: str = ""
    ) -> dict:
        """Request approval for a governed action (e.g. 'complete')."""
        return await self._agent.async_client.create_approval_request(
            intent_id=intent_id,
            action=action,
            reason=reason,
            requested_by=self._agent._agent_id,
        )

    async def approve(self, intent_id: str, approval_id: str) -> dict:
        """Approve a pending approval request."""
        return await self._agent.async_client.approve_approval(
            intent_id=intent_id, approval_id=approval_id
        )

    async def deny(self, intent_id: str, approval_id: str) -> dict:
        """Deny a pending approval request."""
        return await self._agent.async_client.deny_approval(
            intent_id=intent_id, approval_id=approval_id
        )


class _ChannelsProxy:
    """Proxy for agent channel messaging operations (RFC-0021)."""

    def __init__(self, agent):
        self._agent = agent

    async def open(
        self,
        name: str,
        intent_id: str,
        members: Optional[list] = None,
        member_policy: str = "intent",
        options: Optional[dict] = None,
    ):
        """Open or get a channel on an intent. Creates implicitly if not found."""
        existing = await self._agent.async_client.list_channels(intent_id)
        for ch in existing:
            if ch.get("name") == name:
                return _ChannelHandle(self._agent, ch["id"], name, intent_id)
        result = await self._agent.async_client.create_channel(
            intent_id=intent_id,
            name=name,
            members=members or [],
            member_policy=member_policy,
            options=options,
        )
        return _ChannelHandle(self._agent, result["id"], name, intent_id)


class _ChannelHandle:
    """Handle for interacting with a specific channel (RFC-0021)."""

    def __init__(self, agent, channel_id: str, name: str, intent_id: str):
        self._agent = agent
        self.channel_id = channel_id
        self.name = name
        self.intent_id = intent_id

    async def ask(self, to: str, payload: dict, timeout: int = 30):
        """Send a request message and await the response."""
        return await self._agent.async_client.ask(
            channel_id=self.channel_id,
            sender=self._agent._agent_id,
            to=to,
            payload=payload,
            timeout=timeout,
        )

    async def notify(self, to: str, payload: dict):
        """Send a fire-and-forget notification."""
        return await self._agent.async_client.send_message(
            channel_id=self.channel_id,
            sender=self._agent._agent_id,
            to=to,
            message_type="notify",
            payload=payload,
        )

    async def broadcast(self, payload: dict):
        """Send a broadcast message to all channel members."""
        return await self._agent.async_client.send_message(
            channel_id=self.channel_id,
            sender=self._agent._agent_id,
            to="*",
            message_type="broadcast",
            payload=payload,
        )


# ==================== Event Handler Decorators ====================


def on_assignment(func: Callable) -> Callable:
    """
    Decorator: Called when the agent is assigned to an intent.

    The handler receives the intent and should return state updates.
    Return values are automatically patched to the intent's state.

    Example:
        ```python
        @on_assignment
        async def handle(self, intent):
            result = await do_work(intent.title)
            return {"result": result}  # Auto-patched to state
        ```
    """
    func._openintent_handler = "assignment"
    return func


def on_complete(func: Callable) -> Callable:
    """
    Decorator: Called when an intent completes.

    Useful for cleanup, notification, or triggering follow-up work.

    Example:
        ```python
        @on_complete
        async def cleanup(self, intent):
            await notify_completion(intent.id)
        ```
    """
    func._openintent_handler = "complete"
    return func


def on_lease_available(scope: str) -> Callable:
    """
    Decorator: Called when a lease becomes available for a specific scope.

    Args:
        scope: The scope to watch for lease availability.

    Example:
        ```python
        @on_lease_available("research")
        async def claim(self, intent, scope):
            async with self.lease(intent.id, scope):
                await do_exclusive_work()
        ```
    """

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "lease_available"
        func._openintent_scope = scope
        return func

    return decorator


def on_state_change(keys: Optional[list[str]] = None) -> Callable:
    """
    Decorator: Called when intent state changes.

    Args:
        keys: Optional list of state keys to watch. If None, triggers on any change.

    Example:
        ```python
        @on_state_change(["progress"])
        async def track_progress(self, intent, old_state, new_state):
            print(f"Progress: {new_state.get('progress')}")
        ```
    """

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "state_change"
        func._openintent_keys = keys
        return func

    return decorator


def on_event(event_type: Union[str, EventType]) -> Callable:
    """
    Decorator: Called when a specific event type occurs.

    Args:
        event_type: The event type to handle.

    Example:
        ```python
        @on_event(EventType.ARBITRATION_REQUESTED)
        async def handle_arbitration(self, intent, event):
            await escalate(intent.id)
        ```
    """

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "event"
        func._openintent_event_type = (
            event_type if isinstance(event_type, str) else event_type.value
        )
        return func

    return decorator


def on_all_complete(func: Callable) -> Callable:
    """
    Decorator: Called when all intents in a portfolio complete.

    Only applicable for Coordinator agents managing portfolios.

    Example:
        ```python
        @on_all_complete
        async def finalize(self, portfolio):
            return merge_results(portfolio.intents)
        ```
    """
    func._openintent_handler = "all_complete"
    return func


def on_access_requested(func: Callable) -> Callable:
    """
    Decorator: Called when another principal requests access to an intent
    this agent administers. Return "approve", "deny", or "defer".

    Enables policy-as-code for automated access decisions.

    Example:
        ```python
        @on_access_requested
        async def policy(self, intent, request):
            if "ocr" in request.capabilities:
                return "approve"
            return "defer"
        ```
    """
    func._openintent_handler = "access_requested"
    return func


def on_task(status: Optional[str] = None) -> Callable:
    """
    Decorator: Called when a task lifecycle event occurs.

    Args:
        status: Optional task status filter (e.g., "completed", "failed").
                If None, triggers on any task event.
    """

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "task"
        func._openintent_task_status = status
        return func

    return decorator


def on_trigger(name: Optional[str] = None) -> Callable:
    """
    Decorator: Called when a trigger fires and creates an intent for this agent.

    Args:
        name: Optional trigger name filter. If None, handles any trigger.
    """

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "trigger"
        func._openintent_trigger_name = name
        return func

    return decorator


def on_message(channel: Optional[str] = None):
    """
    Decorator: Called when the agent receives a message on a channel (RFC-0021).

    If `channel` is specified, only messages on that named channel trigger the handler.
    If `channel` is None, messages on any channel trigger the handler.

    The handler receives the message and can optionally return a response payload
    that is automatically sent as a reply (for request messages).
    """

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "message"
        func._openintent_channel = channel
        return func

    return decorator


def on_drain(func: Callable) -> Callable:
    """
    Decorator: Called when the agent receives a drain signal.

    The handler should finish in-progress work and prepare for shutdown.
    The agent will stop accepting new assignments after this is called.
    """
    func._openintent_handler = "drain"
    return func


def on_input_requested(func: Callable) -> Callable:
    """
    Decorator: Called after suspension is written, before the agent blocks on input (RFC-0025).

    The handler receives the SuspensionRecord. Use this to route the question
    to an operator (e.g. send a Slack message, email, or dashboard notification).

    Example:
        ```python
        @on_input_requested
        async def notify_operator(self, intent, suspension):
            await send_slack(suspension.question, channel=suspension.channel_hint)
        ```
    """
    func._openintent_handler = "input_requested"
    return func


def on_input_received(func: Callable) -> Callable:
    """
    Decorator: Called when operator input arrives, before the awaiting call unblocks (RFC-0025).

    The handler receives the InputResponse. Use this to log the response or
    route it before it reaches the suspended agent.

    Example:
        ```python
        @on_input_received
        async def log_response(self, intent, response):
            await self.log(intent.id, f"Operator responded: {response.value}")
        ```
    """
    func._openintent_handler = "input_received"
    return func


def on_suspension_expired(func: Callable) -> Callable:
    """
    Decorator: Called when a suspension times out before the fallback policy is applied (RFC-0025).

    The handler receives the SuspensionRecord. Use this to send alerts or
    adjust state before the fallback kicks in.

    Example:
        ```python
        @on_suspension_expired
        async def alert_timeout(self, intent, suspension):
            await send_alert(f"Suspension {suspension.id} expired — applying fallback")
        ```
    """
    func._openintent_handler = "suspension_expired"
    return func


def on_engagement_decision(func: Callable) -> Callable:
    """
    Decorator: Called after should_request_input() returns an EngagementDecision (RFC-0025).

    The handler receives the EngagementDecision. Use this to audit the
    engagement mode chosen by the agent or to override it.

    Example:
        ```python
        @on_engagement_decision
        async def audit_decision(self, intent, decision):
            await self.log(intent.id, f"Engagement mode: {decision.mode}")
        ```
    """
    func._openintent_handler = "engagement_decision"
    return func


def on_identity_registered(func: Callable) -> Callable:
    """
    Decorator: Called when the agent's cryptographic identity is registered.

    Receives the agent's identity record including public key and DID.
    """
    func._openintent_handler = "identity_registered"
    return func


def on_conflict(func: Callable) -> Callable:
    """Decorator: Called when version conflicts occur between agents (RFC-0002).
    Handler receives (self, intent, conflict) with conflict details."""
    func._openintent_handler = "conflict"
    return func


def on_escalation(func: Callable) -> Callable:
    """Decorator: Called when an agent requests coordinator intervention.
    Handler receives (self, intent, agent_id, reason)."""
    func._openintent_handler = "escalation"
    return func


def on_governance_blocked(func: Callable) -> Callable:
    """
    Decorator: Called when a mutation is rejected by a governance policy.

    The handler receives the intent, the violated rule, and the server's
    error detail dict.  Use this to request approval, escalate, or
    adjust strategy when the server enforces a governance gate.

    Example:
        ```python
        @on_governance_blocked
        async def handle_block(self, intent, rule, detail):
            if rule == "completion_mode":
                await self.governance.request_approval(
                    intent.id, "complete", "Ready for review"
                )
            elif rule == "write_scope":
                await self.escalate(intent.id, "Not authorized")
        ```
    """
    func._openintent_handler = "governance_blocked"
    return func


def on_approval_granted(func: Callable) -> Callable:
    """
    Decorator: Called when an approval request is granted (via SSE).

    This is the **resume hook** — when the server broadcasts a
    ``governance.approval_granted`` event, this handler fires so the
    agent can retry the previously blocked operation.

    Example:
        ```python
        @on_approval_granted
        async def resume(self, intent, approval):
            if approval["action"] == "complete":
                await self.async_client.set_status(
                    intent.id, "completed",
                    version=intent.version,
                    reason="Approved and completing"
                )
        ```
    """
    func._openintent_handler = "approval_granted"
    return func


def on_approval_denied(func: Callable) -> Callable:
    """
    Decorator: Called when an approval request is denied (via SSE).

    Allows the agent to handle denial — e.g. escalate, abandon,
    or try a different approach.

    Example:
        ```python
        @on_approval_denied
        async def denied(self, intent, approval):
            await self.escalate(intent.id, "Approval denied, need guidance")
        ```
    """
    func._openintent_handler = "approval_denied"
    return func


def on_quorum(threshold: float = 0.5) -> Callable:
    """Decorator: Called when multi-agent voting reaches a threshold.
    Args: threshold - fraction of agents needed (0.0 to 1.0).
    Handler receives (self, intent, votes)."""

    def decorator(func: Callable) -> Callable:
        func._openintent_handler = "quorum"
        func._openintent_quorum_threshold = threshold
        return func

    return decorator


def on_handoff(func: Callable) -> Callable:
    """
    Decorator: Called when this agent receives work delegated from another agent.

    Unlike @on_assignment which fires for all assignments, @on_handoff fires
    only when the assignment includes delegation context (delegated_by is set).
    The handler receives the intent and the delegating agent's ID.

    Example:
        ```python
        @on_handoff
        async def received(self, intent, from_agent):
            previous = await self.memory.recall(key=f"handoff:{intent.id}")
            return {"status": "continuing", "from": from_agent}
        ```
    """
    func._openintent_handler = "handoff"
    return func


def on_retry(func: Callable) -> Callable:
    """
    Decorator: Called when an intent is reassigned after a previous failure.

    The handler receives the intent and retry metadata (attempt number,
    previous failure reason). Allows agents to adapt behaviour on retries
    (e.g. use a different strategy, reduce scope, or escalate).

    Example:
        ```python
        @on_retry
        async def handle_retry(self, intent, attempt, last_error):
            if attempt >= 3:
                await self.escalate(intent.id, "Too many retries")
                return
            return await self.think(f"Retry attempt {attempt}: {intent.title}")
        ```
    """
    func._openintent_handler = "retry"
    return func


def input_guardrail(func: Callable) -> Callable:
    """
    Decorator: Validates or transforms intent data before assignment handlers run.

    Input guardrails execute in registration order before any @on_assignment
    handler. If a guardrail raises ``GuardrailError`` (or returns ``False``),
    the assignment is rejected and the intent can be escalated.

    Example:
        ```python
        @input_guardrail
        async def check_scope(self, intent):
            if len(intent.description) > 10_000:
                raise GuardrailError("Input too long")
        ```
    """
    func._openintent_handler = "input_guardrail"
    return func


def output_guardrail(func: Callable) -> Callable:
    """
    Decorator: Validates or transforms handler results before they are committed.

    Output guardrails execute in registration order after @on_assignment
    handlers return. The guardrail receives the intent and the result dict.
    If it raises ``GuardrailError`` (or returns ``False``), the result is
    discarded and the intent can be escalated.

    Example:
        ```python
        @output_guardrail
        async def check_pii(self, intent, result):
            for key, val in result.items():
                if contains_pii(str(val)):
                    raise GuardrailError(f"PII detected in '{key}'")
        ```
    """
    func._openintent_handler = "output_guardrail"
    return func


def Identity(  # noqa: N802
    key_path: Optional[str] = None,
    auto_sign: bool = True,
    auto_register: bool = True,
    verify_incoming: bool = False,
) -> Callable:
    """
    Protocol decorator: Configures cryptographic identity for an agent (RFC-0018).

    When applied, the agent generates or loads an Ed25519 key pair,
    registers it with the server, and automatically signs all emitted events.

    Args:
        key_path: Path to Ed25519 private key file. If None, generates a new key.
        auto_sign: Automatically sign all events emitted by this agent.
        auto_register: Register the key with the server on agent startup.
        verify_incoming: Verify signatures on incoming events.

    Example:
        ```python
        @Agent("secure-bot")
        @Identity(auto_sign=True)
        class SecureAgent:
            @on_assignment
            async def work(self, intent):
                return {"result": "signed"}
        ```
    """

    def decorator(cls: type) -> type:
        cls._identity_config = {
            "key_path": key_path,
            "auto_sign": auto_sign,
            "auto_register": auto_register,
            "verify_incoming": verify_incoming,
        }
        return cls

    return decorator


class GuardrailError(Exception):
    """Raised by input/output guardrails to reject processing."""

    pass


# ==================== Portfolio DSL ====================


@dataclass
class IntentSpec:
    """Specification for an intent to be created within a portfolio."""

    title: str
    description: str = ""
    assign: Optional[str] = None
    depends_on: Optional[list[str]] = None
    constraints: dict[str, Any] = field(default_factory=dict)
    initial_state: dict[str, Any] = field(default_factory=dict)
    # RFC-0024: I/O contracts preserved from WorkflowSpec phases.
    # inputs: mapping from local key name -> upstream reference expression.
    # outputs: mapping from output key name -> type declaration.
    # The executor uses these to pre-populate ctx.input and validate
    # completions; they are not consumed by IntentSpec itself.
    inputs: dict[str, str] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.depends_on is None:
            self.depends_on = []


@dataclass
class PortfolioSpec:
    """
    Declarative portfolio specification.

    Example:
        ```python
        spec = PortfolioSpec(
            name="Research Project",
            intents=[
                IntentSpec("Research", assign="researcher"),
                IntentSpec("Write", assign="writer", depends_on=["Research"]),
                IntentSpec("Review", depends_on=["Write"]),
            ]
        )
        ```
    """

    name: str
    description: str = ""
    intents: list[IntentSpec] = field(default_factory=list)
    governance_policy: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


# ==================== Agent Configuration ====================


@dataclass
class AgentConfig:
    """Configuration for an Agent."""

    base_url: str = "http://localhost:5000"
    api_key: str = ""
    auto_subscribe: bool = True
    auto_complete: bool = True
    reconnect_delay: float = 5.0
    max_reconnects: int = 10
    log_level: int = logging.INFO
    capabilities: list[str] = field(default_factory=list)
    auto_request_access: bool = False
    # v0.8.0: Lifecycle (RFC-0016)
    auto_heartbeat: bool = True
    heartbeat_interval: float = 30.0
    drain_timeout: float = 60.0
    # v0.8.0: Memory (RFC-0015)
    memory: Optional[str] = None  # "working", "episodic", "semantic"
    memory_namespace: Optional[str] = None
    # v0.8.0: Tools (RFC-0014)
    tools: list = field(default_factory=list)
    # v0.10.0: Cryptographic Identity (RFC-0018)
    identity_key_path: Optional[str] = None
    auto_sign: bool = False
    auto_register_identity: bool = False
    verify_incoming: bool = False


# ==================== Base Agent Class ====================


T = TypeVar("T", bound="BaseAgent")

_SENTINEL = object()


def _merge_retry_policies(
    *,
    call_site: "Optional[HumanRetryPolicy]",
    agent_default: "Optional[HumanRetryPolicy]",
    platform_default: "Optional[HumanRetryPolicy]",
) -> "Optional[HumanRetryPolicy]":
    """RFC-0026 §5.3: field-level merge of retry policy levels.

    Merge precedence: call_site overrides agent_default overrides platform_default.
    Each level only contributes a field when its value differs from the HumanRetryPolicy
    class default, so the highest-priority level that explicitly sets a field wins.

    If all three are ``None``, returns ``None`` (single-attempt semantics).
    """
    levels = [p for p in (platform_default, agent_default, call_site) if p is not None]
    if not levels:
        return None
    if len(levels) == 1:
        return levels[0]

    _class_defaults = HumanRetryPolicy()
    _scalar_fields = (
        "max_attempts",
        "interval_seconds",
        "strategy",
        "final_fallback_policy",
    )

    merged: dict = {}
    merged_ladder: list | None = None

    for policy in levels:
        for field_name in _scalar_fields:
            val = getattr(policy, field_name)
            class_default = getattr(_class_defaults, field_name)
            if val != class_default:
                merged[field_name] = val
        if policy.escalation_ladder:
            merged_ladder = [s.to_dict() for s in policy.escalation_ladder]

    for field_name in _scalar_fields:
        merged.setdefault(field_name, getattr(_class_defaults, field_name))

    if merged_ladder:
        merged["escalation_ladder"] = merged_ladder

    return HumanRetryPolicy.from_dict(merged)


class BaseAgent(ABC):
    """
    Base class for OpenIntent agents.

    Provides automatic subscription management, event routing,
    and lifecycle handling.
    """

    _agent_id: str = ""
    _config: AgentConfig = field(default_factory=AgentConfig)
    _handlers: dict[str, list[Callable]] = field(default_factory=dict)

    default_human_retry_policy: Optional["HumanRetryPolicy"] = None
    """Class-level or instance-level default re-notification policy (RFC-0026).

    When set, this policy is applied to all ``request_input()`` calls that do
    not supply an explicit ``retry_policy`` argument.  Subclasses may override
    at class level:

    .. code-block:: python

        class MyAgent(BaseAgent):
            default_human_retry_policy = HumanRetryPolicy(
                max_attempts=3,
                interval_seconds=900,
                strategy="linear",
                final_fallback_policy="complete_with_fallback",
            )
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        config: Optional[AgentConfig] = None,
    ):
        self._config = config or AgentConfig()
        if base_url:
            self._config.base_url = base_url
        if api_key:
            self._config.api_key = api_key

        self._client: Optional[OpenIntentClient] = None
        self._async_client: Optional[AsyncOpenIntentClient] = None
        self._subscription: Optional[SSESubscription] = None
        self._running = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._platform_retry_policy_cache: Optional["HumanRetryPolicy | None"] = (
            _SENTINEL
        )

        self._discover_handlers()

        # v0.8.0 proxies
        self._memory_proxy: Optional[_MemoryProxy] = None
        self._tasks_proxy: Optional[_TasksProxy] = None
        self._tools_proxy: Optional[_ToolsProxy] = None
        self._channels_proxy: Optional[_ChannelsProxy] = None
        self._governance_proxy: Optional[_GovernanceProxy] = None

        # MCP bridge for MCPTool-based tools (connected at startup)
        self._mcp_bridge: Any = None

    def _discover_handlers(self) -> None:
        """Discover decorated handler methods."""
        self._handlers = {
            "assignment": [],
            "complete": [],
            "lease_available": [],
            "state_change": [],
            "event": [],
            "all_complete": [],
            "access_requested": [],
            "task": [],
            "trigger": [],
            "message": [],
            "drain": [],
            "handoff": [],
            "retry": [],
            "input_guardrail": [],
            "output_guardrail": [],
            "identity_registered": [],
            "governance_blocked": [],
            "approval_granted": [],
            "approval_denied": [],
            # RFC-0025: HITL lifecycle hooks
            "input_requested": [],
            "input_received": [],
            "suspension_expired": [],
            "engagement_decision": [],
        }

        for name in dir(self):
            if name.startswith("_"):
                continue
            method = getattr(self, name, None)
            if method and callable(method) and hasattr(method, "_openintent_handler"):
                handler_type = method._openintent_handler
                if handler_type in self._handlers:
                    self._handlers[handler_type].append(method)

    @property
    def agent_id(self) -> str:
        """The agent's unique identifier."""
        return self._agent_id

    @property
    def client(self) -> OpenIntentClient:
        """Get or create the synchronous client."""
        if not self._client:
            self._client = OpenIntentClient(
                base_url=self._config.base_url,
                api_key=self._config.api_key,
                agent_id=self._agent_id,
            )
        return self._client

    @property
    def async_client(self) -> AsyncOpenIntentClient:
        """Get or create the asynchronous client."""
        if not self._async_client:
            self._async_client = AsyncOpenIntentClient(
                base_url=self._config.base_url,
                api_key=self._config.api_key,
                agent_id=self._agent_id,
            )
        return self._async_client

    @property
    def memory(self) -> "_MemoryProxy":
        """Access agent memory (RFC-0015). Configure via @Agent(memory="episodic")."""
        if not self._memory_proxy:
            self._memory_proxy = _MemoryProxy(
                self.async_client,
                self._agent_id,
                memory_type=self._config.memory or "episodic",
                namespace=self._config.memory_namespace,
            )
        return self._memory_proxy

    @property
    def tasks(self) -> "_TasksProxy":
        """Access task operations (RFC-0012)."""
        if not self._tasks_proxy:
            self._tasks_proxy = _TasksProxy(self.async_client, self._agent_id)
        return self._tasks_proxy

    @property
    def tools(self) -> _ToolsProxy:
        """Access tool invocation (RFC-0014). Configure via @Agent(tools=["web_search"])."""
        if not self._tools_proxy:
            self._tools_proxy = _ToolsProxy(self)
        return self._tools_proxy

    @property
    def channels(self) -> _ChannelsProxy:
        """Access channel messaging operations (RFC-0021)."""
        if not self._channels_proxy:
            self._channels_proxy = _ChannelsProxy(self)
        return self._channels_proxy

    @property
    def governance(self) -> _GovernanceProxy:
        """Access governance policy operations (RFC-0013 Enforcement).

        Provides methods to set/get/remove governance policies,
        request approval, and approve/deny approval requests.
        """
        if not self._governance_proxy:
            self._governance_proxy = _GovernanceProxy(self)
        return self._governance_proxy

    @property
    def identity_config(self) -> dict:
        """Get identity configuration (RFC-0018)."""
        return getattr(self.__class__, "_identity_config", {})

    def lease(self, intent_id: str, scope: str, duration_seconds: int = 300):
        """
        Acquire a lease as a context manager.

        Example:
            ```python
            async with self.lease(intent.id, "research"):
                await do_exclusive_work()
            ```
        """
        return self.client.lease(intent_id, scope, duration_seconds)

    async def patch_state(self, intent_id: str, updates: dict[str, Any]) -> None:
        """
        Patch intent state with updates.

        Automatically handles version tracking.
        """
        intent = await self.async_client.get_intent(intent_id)
        await self.async_client.update_state(intent_id, intent.version, updates)

    async def complete_intent(
        self, intent_id: str, final_state: Optional[dict[str, Any]] = None
    ) -> None:
        """Mark an intent as completed with optional final state."""
        intent = await self.async_client.get_intent(intent_id)
        if final_state:
            await self.async_client.update_state(intent_id, intent.version, final_state)
            intent = await self.async_client.get_intent(intent_id)
        await self.async_client.set_status(
            intent_id, IntentStatus.COMPLETED, intent.version
        )

    async def log(self, intent_id: str, message: str, **data: Any) -> None:
        """Log a comment event to an intent."""
        await self.async_client.log_event(
            intent_id, EventType.COMMENT, {"message": message, **data}
        )

    # ==================== Access Control (RFC-0011) ====================

    async def _build_context(self, intent: Intent) -> "IntentContext":
        """
        Build an IntentContext for an intent, auto-populating based on
        this agent's permission level.

        RFC-0024: If the intent's state contains ``_io_inputs`` (set by the
        executor via ``to_portfolio_spec``), the declared input mappings are
        resolved from completed upstream dependency outputs and placed in
        ``ctx.input`` before the handler is called.  Agents should read
        ``intent.ctx.input`` rather than probing dependency state directly.
        """
        ctx = IntentContext()

        try:
            if intent.parent_intent_id:
                ctx.parent = await self.async_client.get_intent(intent.parent_intent_id)
        except Exception:
            pass

        dep_outputs: dict[str, dict[str, Any]] = {}
        if intent.depends_on:
            for dep_id in intent.depends_on:
                try:
                    dep = await self.async_client.get_intent(dep_id)
                    dep_state = dep.state.to_dict()
                    ctx.dependencies[dep.title] = dep_state
                    dep_outputs[dep.title] = dep_state
                except Exception:
                    pass

        # RFC-0024: resolve ctx.input from declared _io_inputs mapping stored
        # in the intent's initial state.  Input mapping expressions use phase
        # names (YAML keys), but dependency intents are indexed by title.
        # _io_dep_title_to_name provides the title→name mapping so we can
        # resolve "phase_name.key" correctly even when title != phase name.
        try:
            intent_state_dict = intent.state.to_dict()
        except Exception:
            intent_state_dict = {}

        io_inputs: dict[str, str] = intent_state_dict.get("_io_inputs") or {}
        dep_title_to_name: dict[str, str] = (
            intent_state_dict.get("_io_dep_title_to_name") or {}
        )
        # Build a phase-name-keyed view of dep outputs for input resolution
        dep_outputs_by_name: dict[str, dict[str, Any]] = {}
        for dep_title, dep_name in dep_title_to_name.items():
            if dep_title in dep_outputs:
                dep_outputs_by_name[dep_name] = dep_outputs[dep_title]

        if io_inputs:
            resolved_input: dict[str, Any] = {}
            unresolvable: list[str] = []

            for local_key, mapping_expr in io_inputs.items():
                if not isinstance(mapping_expr, str):
                    continue
                try:
                    if mapping_expr.startswith("$trigger."):
                        key = mapping_expr[len("$trigger.") :]
                        if key in intent_state_dict:
                            resolved_input[local_key] = intent_state_dict[key]
                        else:
                            unresolvable.append(mapping_expr)
                    elif mapping_expr.startswith("$initial_state."):
                        key = mapping_expr[len("$initial_state.") :]
                        if key in intent_state_dict:
                            resolved_input[local_key] = intent_state_dict[key]
                        else:
                            unresolvable.append(mapping_expr)
                    else:
                        parts = mapping_expr.split(".", 1)
                        if len(parts) == 2:
                            ref_phase, ref_key = parts[0], parts[1]
                            # Try phase-name index first, fall back to title
                            phase_out = dep_outputs_by_name.get(
                                ref_phase, dep_outputs.get(ref_phase, {})
                            )
                            if ref_key in phase_out:
                                resolved_input[local_key] = phase_out[ref_key]
                            else:
                                unresolvable.append(mapping_expr)
                        else:
                            unresolvable.append(mapping_expr)
                except Exception:
                    pass

            if unresolvable:
                from .workflow import UnresolvableInputError

                raise UnresolvableInputError(
                    task_id=intent.id,
                    phase_name=getattr(intent, "title", intent.id),
                    unresolvable_refs=unresolvable,
                )

            ctx.input = resolved_input

        try:
            events = await self.async_client.get_events(intent.id, limit=20)
            ctx.events = events
        except Exception:
            pass

        try:
            acl = await self.async_client.get_acl(intent.id)
            ctx.acl = acl
            for entry in acl.entries:
                if entry.principal_id == self._agent_id:
                    ctx.my_permission = entry.permission
                ctx.peers.append(
                    PeerInfo(
                        principal_id=entry.principal_id,
                        principal_type=entry.principal_type,
                        permission=entry.permission,
                    )
                )
        except Exception:
            pass

        return ctx

    async def grant_access(
        self,
        intent_id: str,
        principal_id: str,
        permission: str = "write",
        reason: Optional[str] = None,
    ) -> ACLEntry:
        """Grant access to another principal on an intent."""
        return await self.async_client.grant_access(
            intent_id,
            principal_id,
            principal_type="agent",
            permission=Permission(permission),
            reason=reason,
        )

    async def revoke_access(self, intent_id: str, entry_id: str) -> None:
        """Revoke access from a principal."""
        await self.async_client.revoke_access(intent_id, entry_id)

    def temp_access(
        self,
        intent_id: str,
        principal_id: str,
        permission: str = "write",
        reason: Optional[str] = None,
    ) -> "_TempAccessContext":
        """
        Context manager for temporary access grants with automatic revocation.

        Example:
            ```python
            async with self.temp_access(intent.id, "helper-agent", "write"):
                await self.client.assign_agent(intent.id, "helper-agent")
            # Access automatically revoked
            ```
        """
        return _TempAccessContext(self, intent_id, principal_id, permission, reason)

    async def delegate(
        self,
        intent_id: str,
        target_agent_id: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> None:
        """
        Delegate work on an intent to another agent.

        The target agent receives the assignment with intent.ctx.delegated_by set.
        """
        await self.async_client.log_event(
            intent_id,
            EventType.AGENT_ASSIGNED,
            {
                "agent_id": target_agent_id,
                "delegated_by": self._agent_id,
                "payload": payload or {},
            },
        )
        await self.async_client.assign_agent(intent_id, target_agent_id)

    async def escalate(
        self,
        intent_id: str,
        reason: str,
        data: Optional[dict[str, Any]] = None,
        priority: str = "medium",
        urgency: str = "medium",
    ) -> Escalation:
        """
        Escalate an intent to a human for review.

        Creates a human escalation request through the governance pipeline (RFC-0013).
        """
        return await self.async_client.escalate_to_human(
            intent_id,
            reason=reason,
            priority=priority,
            urgency=urgency,
            context=data or {},
        )

    # ==================== HITL: Human-in-the-Loop (RFC-0025) ====================

    async def request_input(
        self,
        intent_id: str,
        question: str,
        response_type: str = "choice",
        choices: Optional[list[Union[dict[str, Any], "SuspensionChoice"]]] = None,
        context: Optional[dict[str, Any]] = None,
        channel_hint: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
        fallback_policy: str = "fail",
        fallback_value: Optional[Any] = None,
        confidence: Optional[float] = None,
        retry_policy: Optional["HumanRetryPolicy"] = None,
    ) -> Any:
        """
        Suspend the intent and request operator input (RFC-0025 / RFC-0026).

        Transitions the intent to ``suspended_awaiting_input``, fires
        ``@on_input_requested`` hooks, and polls for a response. When the
        operator responds (via POST /intents/{id}/suspend/respond), the
        suspension is resolved and the operator's response value is returned.

        When ``retry_policy`` is supplied (RFC-0026), the agent re-notifies the
        operator up to ``retry_policy.max_attempts`` times, waiting
        ``retry_policy.interval_seconds`` between each attempt, firing
        ``@on_input_requested`` hooks and emitting
        ``intent.suspension_renotified`` events on each re-attempt.
        Escalation steps in ``retry_policy.escalation_ladder`` cause an
        ``intent.suspension_escalated`` event to be emitted. After all
        attempts are exhausted, ``retry_policy.final_fallback_policy`` is
        applied.

        If ``retry_policy`` is omitted, single-attempt behaviour is preserved
        (original RFC-0025 semantics).

        The class attribute ``default_human_retry_policy`` can be set on a
        ``BaseAgent`` subclass or instance to apply a retry policy to all
        ``request_input()`` calls that do not supply an explicit one.

        Args:
            intent_id: The intent to suspend.
            question: The question or prompt for the operator.
            response_type: Expected response type — ``"choice"`` (default),
                ``"confirm"``, ``"text"``, or ``"form"``.
            choices: List of ``SuspensionChoice`` objects or plain dicts with
                ``value`` and ``label`` keys. For ``response_type="confirm"``
                and no explicit choices, defaults to yes/no. For ``"choice"``
                the operator must select one of these values.
            context: Structured context to help the operator decide.
            channel_hint: Preferred delivery channel (e.g. ``"slack"``).
            timeout_seconds: Seconds before the suspension expires.
            fallback_policy: What to do on timeout: ``"fail"``,
                ``"complete_with_fallback"``, or ``"use_default_and_continue"``.
            fallback_value: Value to use for ``"complete_with_fallback"`` policy.
            confidence: Agent confidence score at suspension time (0.0–1.0).
            retry_policy: Optional re-notification / escalation policy
                (RFC-0026). When omitted, falls back to
                ``self.default_human_retry_policy`` (if set), then single-attempt.

        Returns:
            The operator's response value.

        Raises:
            InputTimeoutError: If the suspension expires without a response
                and fallback_policy is ``"fail"``.
            InputCancelledError: If the suspension is cancelled.
        """
        from datetime import datetime, timedelta
        from uuid import uuid4

        # RFC-0026 §5.3: three-level cascade with field-level merge.
        # Fetch platform default once per agent instance (_SENTINEL = not yet fetched).
        if self._platform_retry_policy_cache is _SENTINEL:
            try:
                cfg = await self.async_client.get_server_config()
                policy_dict = (cfg.get("suspension") or {}).get("default_retry_policy")
                if policy_dict:
                    self._platform_retry_policy_cache = HumanRetryPolicy.from_dict(
                        policy_dict
                    )
                else:
                    self._platform_retry_policy_cache = None
            except Exception:
                self._platform_retry_policy_cache = None

        effective_retry_policy = _merge_retry_policies(
            call_site=retry_policy,
            agent_default=getattr(self, "default_human_retry_policy", None),
            platform_default=self._platform_retry_policy_cache,
        )

        suspension_id = str(uuid4())
        now = datetime.utcnow()
        expires_at = None
        if effective_retry_policy is not None:
            # RFC-0026: total expiry = interval_seconds × max_attempts.
            # Safeguard: if interval_seconds is 0 (e.g. max_attempts=1 single-shot)
            # fall back to timeout_seconds so the suspension doesn't hang indefinitely.
            total_seconds = (
                effective_retry_policy.interval_seconds
                * effective_retry_policy.max_attempts
            )
            if total_seconds > 0:
                expires_at = now + timedelta(seconds=total_seconds)
            elif timeout_seconds is not None:
                expires_at = now + timedelta(seconds=timeout_seconds)
        elif timeout_seconds is not None:
            expires_at = now + timedelta(seconds=timeout_seconds)

        resolved_choices: list[SuspensionChoice] = []
        if choices:
            for c in choices:
                if isinstance(c, SuspensionChoice):
                    resolved_choices.append(c)
                elif isinstance(c, dict):
                    resolved_choices.append(SuspensionChoice.from_dict(c))
        elif response_type == ResponseType.CONFIRM.value:
            resolved_choices = [
                SuspensionChoice(value="yes", label="Yes", style="primary"),
                SuspensionChoice(value="no", label="No", style="default"),
            ]

        suspension = SuspensionRecord(
            id=suspension_id,
            question=question,
            response_type=response_type,
            choices=resolved_choices,
            context=context or {},
            channel_hint=channel_hint,
            suspended_at=now,
            timeout_seconds=timeout_seconds,
            expires_at=expires_at,
            fallback_value=fallback_value,
            fallback_policy=fallback_policy,
            retry_policy=effective_retry_policy,
            confidence_at_suspension=confidence,
        )

        intent = await self.async_client.get_intent(intent_id)

        # Transition to suspended_awaiting_input
        await self.async_client.set_status(
            intent_id,
            IntentStatus.SUSPENDED_AWAITING_INPUT,
            intent.version,
        )

        # Persist suspension record in state
        updated = await self.async_client.get_intent(intent_id)
        await self.async_client.update_state(
            intent_id,
            updated.version,
            {"_suspension": suspension.to_dict()},
        )

        # Emit intent_suspended event
        await self.async_client.log_event(
            intent_id,
            EventType.INTENT_SUSPENDED,
            {
                "suspension_id": suspension_id,
                "question": question,
                "response_type": response_type,
                "choices": [c.to_dict() for c in resolved_choices],
                "channel_hint": channel_hint,
                "timeout_seconds": timeout_seconds,
                "fallback_policy": fallback_policy,
                "confidence_at_suspension": confidence,
                "retry_policy": effective_retry_policy.to_dict()
                if effective_retry_policy
                else None,
            },
        )

        # Fire @on_input_requested hooks
        current_intent = await self.async_client.get_intent(intent_id)
        for handler in self._handlers.get("input_requested", []):
            try:
                await self._call_handler(handler, current_intent, suspension)
            except Exception as e:
                logger.exception(f"on_input_requested handler error: {e}")

        # Resolve effective fallback policy (RFC-0026: retry_policy takes precedence)
        effective_fallback = fallback_policy
        if effective_retry_policy is not None:
            effective_fallback = effective_retry_policy.final_fallback_policy

        # Poll for operator response, with optional re-notification (RFC-0026)
        poll_interval = 2.0
        attempt = 1
        max_attempts = 1
        interval_seconds = 0
        if effective_retry_policy is not None:
            max_attempts = effective_retry_policy.max_attempts
            interval_seconds = effective_retry_policy.interval_seconds

        next_renotify_at: Optional[datetime] = None
        if (
            effective_retry_policy is not None
            and interval_seconds > 0
            and max_attempts > 1
        ):
            next_renotify_at = now + timedelta(seconds=interval_seconds)

        while True:
            await asyncio.sleep(poll_interval)
            try:
                current = await self.async_client.get_intent(intent_id)
            except Exception:
                continue

            state = current.state.to_dict() if current.state else {}
            susp_data = state.get("_suspension", {})

            resolution = susp_data.get("resolution")
            if resolution == "responded":
                response_value = susp_data.get("response")
                responded_at_str = susp_data.get("responded_at")
                responded_at = None
                if responded_at_str:
                    try:
                        responded_at = datetime.fromisoformat(responded_at_str)
                    except Exception:
                        pass

                input_response = InputResponse(
                    suspension_id=suspension_id,
                    value=response_value,
                    responded_by=susp_data.get("responded_by", ""),
                    responded_at=responded_at,
                )

                # Fire @on_input_received hooks
                for handler in self._handlers.get("input_received", []):
                    try:
                        await self._call_handler(handler, current, input_response)
                    except Exception as e:
                        logger.exception(f"on_input_received handler error: {e}")

                return response_value

            elif resolution == "expired":
                # Fire @on_suspension_expired hooks before applying fallback
                for handler in self._handlers.get("suspension_expired", []):
                    try:
                        await self._call_handler(handler, current, suspension)
                    except Exception as e:
                        logger.exception(f"on_suspension_expired handler error: {e}")

                if effective_fallback == "fail":
                    raise InputTimeoutError(
                        f"Suspension {suspension_id} expired without operator response",
                        suspension_id=suspension_id,
                        fallback_policy=effective_fallback,
                    )
                elif effective_fallback == "complete_with_fallback":
                    return fallback_value
                else:
                    return fallback_value

            elif resolution == "cancelled":
                raise InputCancelledError(
                    f"Suspension {suspension_id} was cancelled",
                    suspension_id=suspension_id,
                )

            # RFC-0026: re-notification loop
            if (
                effective_retry_policy is not None
                and next_renotify_at is not None
                and datetime.utcnow() >= next_renotify_at
            ):
                if attempt < max_attempts:
                    attempt += 1
                    logger.info(
                        f"Re-notifying operator for suspension {suspension_id} "
                        f"(attempt {attempt}/{max_attempts})"
                    )

                    # Check escalation ladder for this attempt
                    escalation_steps = effective_retry_policy.escalation_ladder
                    triggered_steps = [
                        s for s in escalation_steps if s.attempt == attempt
                    ]
                    escalation_channel_hint: Optional[str] = None
                    escalation_notify_to: Optional[str] = None
                    for step in triggered_steps:
                        escalation_channel_hint = (
                            step.channel_hint or escalation_channel_hint
                        )
                        escalation_notify_to = step.notify_to or escalation_notify_to
                        try:
                            await self.async_client.log_event(
                                intent_id,
                                EventType.INTENT_SUSPENSION_ESCALATED,
                                {
                                    "suspension_id": suspension_id,
                                    "attempt": attempt,
                                    "escalated_to": step.notify_to or None,
                                    "channel_hint": step.channel_hint or None,
                                },
                            )
                        except Exception as e:
                            logger.exception(f"suspension_escalated event error: {e}")

                    # Compute when the next attempt fires (for telemetry)
                    next_attempt_at = (
                        datetime.utcnow() + timedelta(seconds=interval_seconds)
                    ).isoformat() + "Z"

                    # Emit re-notification event with RFC-0026 field names
                    try:
                        await self.async_client.log_event(
                            intent_id,
                            EventType.INTENT_SUSPENSION_RENOTIFIED,
                            {
                                "suspension_id": suspension_id,
                                "attempt": attempt,
                                "max_attempts": max_attempts,
                                "channel_hint": escalation_channel_hint
                                or suspension.channel_hint,
                                "notify_to": escalation_notify_to,
                                "next_attempt_at": next_attempt_at
                                if attempt < max_attempts
                                else None,
                            },
                        )
                    except Exception as e:
                        logger.exception(f"suspension_renotified event error: {e}")

                    # Build a re-notification SuspensionRecord that carries attempt
                    # metadata in its context using RFC-0026 key names (_attempt,
                    # _max_attempts) so @on_input_requested handlers can read them
                    # without a signature change.
                    import dataclasses

                    renotify_context = dict(suspension.context)
                    renotify_context["_attempt"] = attempt
                    renotify_context["_max_attempts"] = max_attempts
                    if escalation_notify_to:
                        renotify_context["_notify_to"] = escalation_notify_to

                    renotify_suspension = dataclasses.replace(
                        suspension,
                        context=renotify_context,
                        channel_hint=escalation_channel_hint or suspension.channel_hint,
                    )

                    # Re-fire @on_input_requested hooks with the enriched suspension
                    for handler in self._handlers.get("input_requested", []):
                        try:
                            await self._call_handler(
                                handler, current, renotify_suspension
                            )
                        except Exception as e:
                            logger.exception(
                                f"on_input_requested (renotify) handler error: {e}"
                            )

                    next_renotify_at = datetime.utcnow() + timedelta(
                        seconds=interval_seconds
                    )
                else:
                    # All attempts exhausted — apply final fallback
                    for handler in self._handlers.get("suspension_expired", []):
                        try:
                            await self._call_handler(handler, current, suspension)
                        except Exception as e:
                            logger.exception(
                                f"on_suspension_expired handler error: {e}"
                            )

                    if effective_fallback == "fail":
                        raise InputTimeoutError(
                            f"Suspension {suspension_id} exhausted all {max_attempts} re-notification attempts",
                            suspension_id=suspension_id,
                            fallback_policy=effective_fallback,
                        )
                    return fallback_value

            # Check if expired by time without server update (single-attempt path)
            if (
                effective_retry_policy is None
                and expires_at is not None
                and datetime.utcnow() > expires_at
            ):
                for handler in self._handlers.get("suspension_expired", []):
                    try:
                        await self._call_handler(handler, current, suspension)
                    except Exception as e:
                        logger.exception(f"on_suspension_expired handler error: {e}")

                if effective_fallback == "fail":
                    raise InputTimeoutError(
                        f"Suspension {suspension_id} expired (client-side timeout)",
                        suspension_id=suspension_id,
                        fallback_policy=effective_fallback,
                    )
                return fallback_value

    async def should_request_input(
        self,
        intent_id: str,
        signals: Optional[EngagementSignals] = None,
        confidence: Optional[float] = None,
        risk: Optional[float] = None,
        reversibility: Optional[float] = None,
    ) -> EngagementDecision:
        """
        Decide whether to ask for human input or act autonomously (RFC-0025).

        Implements the default rule-based engagement logic:
        - ``autonomous``: high confidence, low risk, reversible — act now.
        - ``request_input``: moderate uncertainty — ask but don't block.
        - ``require_input``: high risk or low confidence — must ask.
        - ``defer``: risk too high to act, escalate to coordinator.

        The decision is emitted as an ``engagement.decision`` event and
        ``@on_engagement_decision`` handlers are fired before returning.

        Args:
            intent_id: The intent context.
            signals: Pre-built EngagementSignals object (takes priority).
            confidence: Agent confidence in autonomous action (0.0–1.0).
            risk: Estimated risk of acting autonomously (0.0–1.0).
            reversibility: How reversible the action is (0.0–1.0).

        Returns:
            An EngagementDecision indicating the recommended mode.
        """
        if signals is None:
            signals = EngagementSignals(
                confidence=confidence if confidence is not None else 1.0,
                risk=risk if risk is not None else 0.0,
                reversibility=reversibility if reversibility is not None else 1.0,
            )

        c = signals.confidence
        r = signals.risk
        rev = signals.reversibility

        # Default rule-based engagement logic
        if c >= 0.85 and r <= 0.2 and rev >= 0.5:
            mode = "autonomous"
            should_ask = False
            rationale = (
                f"High confidence ({c:.2f}), low risk ({r:.2f}), "
                f"reversible ({rev:.2f}) — acting autonomously."
            )
        elif r >= 0.8 or rev <= 0.1:
            mode = "defer"
            should_ask = False
            rationale = (
                f"Risk ({r:.2f}) or irreversibility ({rev:.2f}) exceeds safe threshold "
                f"— deferring to coordinator."
            )
        elif c < 0.5 or r > 0.5:
            mode = "require_input"
            should_ask = True
            rationale = (
                f"Low confidence ({c:.2f}) or elevated risk ({r:.2f}) "
                f"— operator input required before proceeding."
            )
        else:
            mode = "request_input"
            should_ask = True
            rationale = (
                f"Moderate confidence ({c:.2f}) with manageable risk ({r:.2f}) "
                f"— requesting operator input but can proceed without it."
            )

        decision = EngagementDecision(
            mode=mode,
            should_ask=should_ask,
            rationale=rationale,
            signals=signals,
        )

        # Emit engagement.decision event
        try:
            await self.async_client.log_event(
                intent_id,
                EventType.ENGAGEMENT_DECISION,
                decision.to_dict(),
            )
        except Exception as e:
            logger.warning(f"Could not emit engagement.decision event: {e}")

        # Fire @on_engagement_decision hooks
        try:
            intent = await self.async_client.get_intent(intent_id)
            for handler in self._handlers.get("engagement_decision", []):
                try:
                    await self._call_handler(handler, intent, decision)
                except Exception as e:
                    logger.exception(f"on_engagement_decision handler error: {e}")
        except Exception:
            pass

        return decision

    # ==================== Event Routing ====================

    async def _handle_event(self, event: SSEEvent) -> None:
        """Route SSE events to appropriate handlers."""
        try:
            if (
                event.type == SSEEventType.AGENT_ASSIGNED
                or event.type == "AGENT_ASSIGNED"
            ):
                await self._on_assignment(event)
            elif (
                event.type == SSEEventType.STATUS_CHANGED
                or event.type == "STATUS_CHANGED"
            ):
                await self._on_status_change(event)
            elif (
                event.type == SSEEventType.LEASE_RELEASED
                or event.type == "LEASE_RELEASED"
            ):
                await self._on_lease_released(event)
            elif (
                event.type == SSEEventType.STATE_CHANGED
                or event.type == "STATE_CHANGED"
            ):
                await self._on_state_change(event)
            elif (
                event.type == SSEEventType.INTENT_COMPLETED
                or event.type == "INTENT_COMPLETED"
            ):
                await self._on_intent_complete(event)
            elif (
                event.type == SSEEventType.ACCESS_REQUESTED
                or event.type == "ACCESS_REQUESTED"
                or event.type == "access_requested"
            ):
                await self._on_access_requested(event)
            else:
                await self._on_generic_event(event)
        except Exception as e:
            logger.exception(f"Error handling event {event.type}: {e}")

    async def _on_assignment(self, event: SSEEvent) -> None:
        """Handle assignment events with guardrails, handoff, and retry support."""
        intent_id = event.data.get("intent_id")
        if not intent_id:
            return

        intent = await self.async_client.get_intent(intent_id)

        # RFC-0024: _build_context raises UnresolvableInputError if declared
        # inputs cannot be resolved from upstream deps.  This is a hard
        # rejection — the handler is not invoked.
        try:
            ctx = await self._build_context(intent)
        except Exception as build_err:
            from .workflow import UnresolvableInputError

            if isinstance(build_err, UnresolvableInputError):
                logger.warning(
                    f"RFC-0024: rejecting assignment for intent {intent_id}: "
                    f"{build_err}"
                )
                return
            raise
        delegated_by = event.data.get("delegated_by")
        if delegated_by:
            ctx.delegated_by = delegated_by
        intent.ctx = ctx

        retry_attempt = event.data.get("retry_attempt", 0)
        last_error = event.data.get("last_error")

        if retry_attempt and self._handlers["retry"]:
            for handler in self._handlers["retry"]:
                try:
                    result = await self._call_handler(
                        handler, intent, retry_attempt, last_error
                    )
                    if (
                        result
                        and isinstance(result, dict)
                        and self._config.auto_complete
                    ):
                        await self.patch_state(intent_id, result)
                except Exception as e:
                    logger.exception(f"Retry handler error: {e}")
            return

        if delegated_by and self._handlers["handoff"]:
            for handler in self._handlers["handoff"]:
                try:
                    result = await self._call_handler(handler, intent, delegated_by)
                    if (
                        result
                        and isinstance(result, dict)
                        and self._config.auto_complete
                    ):
                        await self.patch_state(intent_id, result)
                except Exception as e:
                    logger.exception(f"Handoff handler error: {e}")
            return

        for guardrail in self._handlers["input_guardrail"]:
            try:
                check = await self._call_handler(guardrail, intent)
                if check is False:
                    logger.warning(f"Input guardrail rejected intent {intent_id}")
                    return
            except GuardrailError as e:
                logger.warning(f"Input guardrail rejected intent {intent_id}: {e}")
                return
            except Exception as e:
                logger.exception(f"Input guardrail error: {e}")
                return

        for handler in self._handlers["assignment"]:
            try:
                result = await self._call_handler(handler, intent)
                if result and isinstance(result, dict):
                    # RFC-0024: validate output against declared _io_outputs
                    # schema before passing through output guardrails or
                    # patching state.  Raises MissingOutputError /
                    # OutputTypeMismatchError on failure which is caught
                    # below; result is dropped so the agent can be retried.
                    try:
                        self._validate_io_outputs(intent_id, intent, result)
                    except Exception as io_err:
                        from .workflow import (
                            MissingOutputError,
                            OutputTypeMismatchError,
                        )

                        if isinstance(
                            io_err, (MissingOutputError, OutputTypeMismatchError)
                        ):
                            logger.warning(
                                f"RFC-0024 output validation failed for "
                                f"{intent_id}: {io_err}"
                            )
                        else:
                            logger.warning(
                                f"RFC-0024 output validation error for "
                                f"{intent_id}: {io_err}"
                            )
                        result = None

                    if result is not None:
                        for guardrail in self._handlers["output_guardrail"]:
                            try:
                                check = await self._call_handler(
                                    guardrail, intent, result
                                )
                                if check is False:
                                    logger.warning(
                                        f"Output guardrail rejected result for {intent_id}"
                                    )
                                    result = None
                                    break
                            except GuardrailError as e:
                                logger.warning(
                                    f"Output guardrail rejected result for {intent_id}: {e}"
                                )
                                result = None
                                break
                            except Exception as e:
                                logger.exception(f"Output guardrail error: {e}")
                                result = None
                                break

                    if result and self._config.auto_complete:
                        await self.patch_state(intent_id, result)
            except Exception as e:
                logger.exception(f"Assignment handler error: {e}")

    def _validate_io_outputs(
        self,
        intent_id: str,
        intent: Any,
        result: dict[str, Any],
    ) -> bool:
        """Validate an agent's result dict against RFC-0024 declared outputs.

        Reads the ``_io_outputs`` schema stored in the intent's state
        (populated by the executor via ``to_portfolio_spec``).  Raises
        ``MissingOutputError`` or ``OutputTypeMismatchError`` on failure.
        Returns ``True`` if validation passes or if no schema is declared.

        Type primitives supported: ``string``, ``number``, ``boolean``,
        ``object``, ``array``.  Named types from the ``_io_types`` block are
        validated structurally (key presence + enum membership).
        Optional outputs (``required: false``) are allowed to be absent.
        """
        from .workflow import MissingOutputError, OutputTypeMismatchError

        try:
            try:
                state_dict = intent.state.to_dict()
            except Exception:
                return True  # Cannot read state — skip validation

            io_outputs: dict[str, Any] = state_dict.get("_io_outputs") or {}
            if not io_outputs:
                return True

            # Named type schemas may be stored alongside _io_outputs as
            # _io_types if the WorkflowSpec stored them (future extension).
            # For now, look up type schemas from _io_types if present.
            io_types: dict[str, Any] = state_dict.get("_io_types") or {}

            primitive_type_map: dict[str, type] = {
                "string": str,
                "number": (int, float),  # type: ignore[dict-item]
                "boolean": bool,
                "object": dict,
                "array": list,
            }

            missing: list[str] = []

            for output_key, type_decl in io_outputs.items():
                required = True
                expected_type = "any"

                if isinstance(type_decl, dict):
                    required = type_decl.get("required", True)
                    expected_type = str(type_decl.get("type", "any"))
                elif isinstance(type_decl, str):
                    expected_type = type_decl

                if output_key not in result:
                    if required:
                        missing.append(output_key)
                    continue

                value = result[output_key]
                if expected_type in ("any", ""):
                    continue

                # Primitive type check
                if expected_type in primitive_type_map:
                    expected_python_type = primitive_type_map[expected_type]
                    if not isinstance(value, expected_python_type):
                        raise OutputTypeMismatchError(
                            task_id=intent_id,
                            phase_name=getattr(intent, "title", intent_id),
                            key=output_key,
                            expected_type=expected_type,
                            actual_type=type(value).__name__,
                        )
                    continue

                # Named type check from _io_types
                type_schema = io_types.get(expected_type)
                if type_schema is None:
                    # Unknown type — accept without validation (incremental adoption)
                    continue

                # Enum type
                if isinstance(type_schema, dict) and "enum" in type_schema:
                    enum_values = type_schema["enum"]
                    if isinstance(enum_values, list) and value not in enum_values:
                        raise OutputTypeMismatchError(
                            task_id=intent_id,
                            phase_name=getattr(intent, "title", intent_id),
                            key=output_key,
                            expected_type=f"{expected_type}(enum:{enum_values})",
                            actual_type=repr(value),
                        )
                    continue

                # Struct type — value must be a dict with declared keys
                if not isinstance(value, dict):
                    raise OutputTypeMismatchError(
                        task_id=intent_id,
                        phase_name=getattr(intent, "title", intent_id),
                        key=output_key,
                        expected_type=expected_type,
                        actual_type=type(value).__name__,
                    )
                if isinstance(type_schema, dict):
                    for schema_key in type_schema:
                        if schema_key not in value:
                            raise OutputTypeMismatchError(
                                task_id=intent_id,
                                phase_name=getattr(intent, "title", intent_id),
                                key=output_key,
                                expected_type=expected_type,
                                actual_type=f"dict missing required field '{schema_key}'",
                            )

            if missing:
                raise MissingOutputError(
                    task_id=intent_id,
                    phase_name=getattr(intent, "title", intent_id),
                    missing_keys=missing,
                )

        except (MissingOutputError, OutputTypeMismatchError):
            raise
        except Exception as e:
            logger.debug(f"RFC-0024 output validation error for {intent_id}: {e}")

        return True

    async def _on_status_change(self, event: SSEEvent) -> None:
        """Handle status change events."""
        new_status = event.data.get("new_status")
        if new_status == "completed":
            await self._on_intent_complete(event)

    async def _on_intent_complete(self, event: SSEEvent) -> None:
        """Handle intent completion events."""
        intent_id = event.data.get("intent_id")
        if not intent_id:
            return

        intent = await self.async_client.get_intent(intent_id)

        for handler in self._handlers["complete"]:
            try:
                await self._call_handler(handler, intent)
            except Exception as e:
                logger.exception(f"Complete handler error: {e}")

    async def _on_lease_released(self, event: SSEEvent) -> None:
        """Handle lease release events."""
        intent_id = event.data.get("intent_id")
        scope = event.data.get("scope")
        if not intent_id or not scope:
            return

        intent = await self.async_client.get_intent(intent_id)

        for handler in self._handlers["lease_available"]:
            handler_scope = getattr(handler, "_openintent_scope", None)
            if handler_scope == scope:
                try:
                    await self._call_handler(handler, intent, scope)
                except Exception as e:
                    logger.exception(f"Lease available handler error: {e}")

    async def _on_state_change(self, event: SSEEvent) -> None:
        """Handle state change events."""
        intent_id = event.data.get("intent_id")
        if not intent_id:
            return

        old_state = event.data.get("old_state", {})
        new_state = event.data.get("new_state", {})
        intent = await self.async_client.get_intent(intent_id)

        for handler in self._handlers["state_change"]:
            keys = getattr(handler, "_openintent_keys", None)
            if keys is None or any(k in new_state for k in keys):
                try:
                    await self._call_handler(handler, intent, old_state, new_state)
                except Exception as e:
                    logger.exception(f"State change handler error: {e}")

    async def _on_generic_event(self, event: SSEEvent) -> None:
        """Handle generic events via @on_event decorators and HITL hooks."""
        intent_id = event.data.get("intent_id")
        if not intent_id:
            return

        intent = await self.async_client.get_intent(intent_id)

        # Route HITL events (RFC-0025)
        if event.type in (EventType.INTENT_SUSPENDED, "intent.suspended"):
            suspension = SuspensionRecord.from_dict(event.data)
            for handler in self._handlers["input_requested"]:
                try:
                    await self._call_handler(handler, intent, suspension)
                except Exception as e:
                    logger.exception(f"on_input_requested handler error: {e}")
            return

        if event.type in (EventType.INTENT_RESUMED, "intent.resumed"):
            input_response = InputResponse.from_dict(event.data)
            for handler in self._handlers["input_received"]:
                try:
                    await self._call_handler(handler, intent, input_response)
                except Exception as e:
                    logger.exception(f"on_input_received handler error: {e}")
            return

        if event.type in (
            EventType.INTENT_SUSPENSION_EXPIRED,
            "intent.suspension_expired",
        ):
            suspension = SuspensionRecord.from_dict(event.data)
            for handler in self._handlers["suspension_expired"]:
                try:
                    await self._call_handler(handler, intent, suspension)
                except Exception as e:
                    logger.exception(f"on_suspension_expired handler error: {e}")
            return

        if event.type in (EventType.ENGAGEMENT_DECISION, "engagement.decision"):
            decision = EngagementDecision.from_dict(event.data)
            for handler in self._handlers["engagement_decision"]:
                try:
                    await self._call_handler(handler, intent, decision)
                except Exception as e:
                    logger.exception(f"on_engagement_decision handler error: {e}")
            return

        for handler in self._handlers["event"]:
            handler_type = getattr(handler, "_openintent_event_type", None)
            if handler_type == event.type:
                try:
                    await self._call_handler(handler, intent, event)
                except Exception as e:
                    logger.exception(f"Event handler error: {e}")

    async def _on_access_requested(self, event: SSEEvent) -> None:
        """Handle access request events via @on_access_requested decorator."""
        intent_id = event.data.get("intent_id")
        if not intent_id:
            return

        intent = await self.async_client.get_intent(intent_id)
        request = AccessRequest.from_dict(event.data.get("request", event.data))

        for handler in self._handlers["access_requested"]:
            try:
                result = await self._call_handler(handler, intent, request)
                if result == "approve":
                    await self.async_client.approve_access_request(
                        intent_id,
                        request.id,
                        permission=request.requested_permission,
                        reason="Auto-approved by agent policy",
                    )
                elif result == "deny":
                    await self.async_client.deny_access_request(
                        intent_id,
                        request.id,
                        reason="Denied by agent policy",
                    )
            except Exception as e:
                logger.exception(f"Access request handler error: {e}")

    async def _call_handler(self, handler: Callable, *args: Any) -> Any:
        """Call a handler, handling both sync and async methods."""
        if asyncio.iscoroutinefunction(handler):
            return await handler(*args)
        else:
            return handler(*args)

    # ==================== Lifecycle ====================

    def run(self) -> None:
        """
        Start the agent and begin processing events.

        This method blocks until stop() is called.
        """
        logger.info(f"Starting agent: {self._agent_id}")
        self._running = True

        asyncio.run(self._run_async())

    async def _resolve_mcp_tools(self) -> None:
        """Connect to MCP servers declared in tools list and register their tools."""
        from .mcp import MCPTool, is_mcp_uri, resolve_mcp_tools

        mcp_entries = [
            t for t in self._config.tools if isinstance(t, MCPTool) or is_mcp_uri(t)
        ]
        if not mcp_entries:
            return

        non_mcp = [
            t
            for t in self._config.tools
            if not isinstance(t, MCPTool) and not is_mcp_uri(t)
        ]

        bridge, tool_defs = await resolve_mcp_tools(mcp_entries)
        self._mcp_bridge = bridge
        self._config.tools = non_mcp + tool_defs
        logger.info(
            "Agent '%s': resolved %d MCP tools from %d servers",
            self._agent_id,
            len(tool_defs),
            len(mcp_entries),
        )

    async def _disconnect_mcp(self) -> None:
        """Disconnect from all MCP servers."""
        if self._mcp_bridge is not None:
            try:
                await self._mcp_bridge.disconnect_all()
            except Exception as exc:
                logger.warning("Error disconnecting MCP bridge: %s", exc)
            self._mcp_bridge = None

    async def _run_async(self) -> None:
        """Async run loop."""
        self._loop = asyncio.get_event_loop()

        await self._resolve_mcp_tools()

        if self._config.auto_subscribe:
            await self._subscribe()

        try:
            while self._running:
                await asyncio.sleep(0.1)
        finally:
            await self._disconnect_mcp()

    async def _subscribe(self) -> None:
        """Set up SSE subscription for this agent."""
        url = f"{self._config.base_url}/api/v1/agents/{self._agent_id}/subscribe"
        headers = {
            "X-API-Key": self._config.api_key,
            "X-Agent-ID": self._agent_id,
        }

        async def event_loop():
            stream = SSEStream(
                url,
                headers,
                reconnect_delay=self._config.reconnect_delay,
                max_reconnects=self._config.max_reconnects,
            )
            for event in stream:
                if not self._running:
                    break
                await self._handle_event(event)

        asyncio.create_task(event_loop())

    def stop(self) -> None:
        """Stop the agent and disconnect MCP servers."""
        logger.info(f"Stopping agent: {self._agent_id}")
        self._running = False
        if self._subscription:
            self._subscription.stop()
        if self._mcp_bridge is not None and self._loop is not None:
            try:
                if self._loop.is_running():
                    self._loop.create_task(self._disconnect_mcp())
                else:
                    self._loop.run_until_complete(self._disconnect_mcp())
            except Exception:
                pass


class _MemoryProxy:
    """Proxy for natural memory access from agent methods."""

    def __init__(
        self,
        client_ref,
        agent_id: str,
        memory_type: str = "episodic",
        namespace: Optional[str] = None,
    ):  # noqa: E501
        self._client_ref = client_ref
        self._agent_id = agent_id
        self._memory_type = memory_type
        self._namespace = namespace

    async def store(
        self, key: str, value: Any, tags: Optional[list[str]] = None
    ) -> Any:
        """Store a memory entry."""
        return await self._client_ref.memory.store(
            agent_id=self._agent_id,
            key=key,
            value=value,
            memory_type=self._memory_type,
            tags=tags or [],
            namespace=self._namespace,
        )

    async def recall(
        self, key: Optional[str] = None, tags: Optional[list[str]] = None
    ) -> Any:
        """Recall memories by key or tags."""
        return await self._client_ref.memory.query(
            agent_id=self._agent_id,
            namespace=self._namespace,
            key=key,
            tags=tags,
        )

    async def forget(self, key: str) -> None:
        """Remove a memory entry."""
        await self._client_ref.memory.delete(agent_id=self._agent_id, key=key)

    async def pin(self, key: str) -> None:
        """Pin a memory to prevent eviction."""
        await self._client_ref.memory.pin(agent_id=self._agent_id, key=key)


class _TasksProxy:
    """Proxy for task operations from agent methods."""

    def __init__(self, client_ref, agent_id: str):
        self._client_ref = client_ref
        self._agent_id = agent_id

    async def create(self, intent_id: str, title: str, **kwargs) -> Any:
        """Create a subtask within an intent."""
        return await self._client_ref.tasks.create(
            intent_id=intent_id,
            title=title,
            assigned_to=kwargs.get("assigned_to", self._agent_id),
            **{k: v for k, v in kwargs.items() if k != "assigned_to"},
        )

    async def complete(self, task_id: str, result: Optional[dict] = None) -> Any:
        """Mark a task as completed."""
        return await self._client_ref.tasks.update_status(
            task_id, status="completed", result=result
        )  # noqa: E501

    async def fail(self, task_id: str, error: Optional[str] = None) -> Any:
        """Mark a task as failed."""
        return await self._client_ref.tasks.update_status(
            task_id, status="failed", error=error
        )

    async def list(self, intent_id: str, status: Optional[str] = None) -> list:
        """List tasks for an intent, optionally filtered by status."""
        return await self._client_ref.tasks.list(intent_id=intent_id, status=status)


class _TempAccessContext:
    """Async context manager for temporary access grants."""

    def __init__(
        self,
        agent: BaseAgent,
        intent_id: str,
        principal_id: str,
        permission: str,
        reason: Optional[str],
    ):
        self._agent = agent
        self._intent_id = intent_id
        self._principal_id = principal_id
        self._permission = permission
        self._reason = reason
        self._entry: Optional[ACLEntry] = None

    async def __aenter__(self) -> ACLEntry:
        self._entry = await self._agent.grant_access(
            self._intent_id,
            self._principal_id,
            self._permission,
            self._reason,
        )
        return self._entry

    async def __aexit__(self, *args: Any) -> None:
        if self._entry:
            try:
                await self._agent.revoke_access(self._intent_id, self._entry.id)
            except Exception:
                pass


def _setup_llm_engine(
    agent_instance,
    model: str,
    provider: Optional[str] = None,
    system_prompt: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    max_tool_rounds: int = 10,
    planning: bool = False,
    stream_by_default: bool = False,
    api_key_override: Optional[str] = None,
) -> None:
    """Attach LLM engine, think(), and think_stream() to an agent instance."""
    from .llm import LLMConfig, LLMEngine, _resolve_provider

    resolved_provider = provider or _resolve_provider(model)

    llm_config = LLMConfig(
        model=model,
        provider=resolved_provider,
        api_key=api_key_override,
        system_prompt=system_prompt,
        temperature=temperature,
        max_tokens=max_tokens,
        max_tool_rounds=max_tool_rounds,
        planning=planning,
        stream_by_default=stream_by_default,
    )

    engine = LLMEngine(agent_instance, llm_config)
    agent_instance._llm_engine = engine
    agent_instance._llm_config = llm_config
    agent_instance._llm_adapter = None

    async def think(prompt, intent=None, stream=None, on_token=None, **kw):
        return await engine.think(
            prompt, intent=intent, stream=stream, on_token=on_token, **kw
        )

    async def think_stream(prompt, intent=None, on_token=None, **kw):
        return await engine.think(
            prompt, intent=intent, stream=True, on_token=on_token, **kw
        )

    agent_instance.think = think
    agent_instance.think_stream = think_stream
    agent_instance.reset_conversation = engine.reset_history


def Agent(  # noqa: N802 - intentionally capitalized as class-like decorator
    agent_id: str,
    config: Optional[AgentConfig] = None,
    capabilities: Optional[list[str]] = None,
    memory: Optional[str] = None,
    tools: Optional[list] = None,
    auto_heartbeat: bool = True,
    governance_policy: Optional[dict[str, Any]] = None,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    system_prompt: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    max_tool_rounds: int = 10,
    planning: bool = False,
    stream_by_default: bool = False,
    federation_visibility: Optional[str] = None,
    **kwargs: Any,
) -> Callable[[type], type]:
    """
    Class decorator to create an Agent from a class.

    When ``model`` is provided, the agent becomes LLM-powered:
    ``self.think(prompt)`` runs an agentic loop that reasons, calls
    protocol tools (memory, escalation, clarification), and returns a
    result. ``self.think_stream(prompt)`` does the same but yields tokens.

    Tools can be plain strings (resolved via RFC-0014 protocol grants)
    or ``Tool`` objects with rich descriptions, parameter schemas, and
    local callable handlers.

    Example — manual agent (no model):
        ```python
        @Agent("research-bot")
        class ResearchAgent:
            @on_assignment
            async def work(self, intent):
                return {"result": "done"}
        ```

    Example — LLM-powered agent with Tool objects:
        ```python
        from openintent import Agent, Tool, tool, on_assignment

        @tool(description="Search the web.", parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query."},
            },
            "required": ["query"],
        })
        async def web_search(query: str) -> dict:
            return {"results": [...]}

        @Agent("analyst", model="gpt-5.2", tools=[web_search])
        class Analyst:
            @on_assignment
            async def work(self, intent):
                return await self.think(intent.description)
        ```
    """

    def decorator(cls: type) -> type:
        original_init = cls.__init__ if hasattr(cls, "__init__") else None

        def new_init(
            self, base_url: Optional[str] = None, api_key: Optional[str] = None
        ):
            BaseAgent.__init__(self, base_url, api_key, config)
            self._agent_id = agent_id
            if capabilities:
                self._config.capabilities = capabilities
            if memory:
                self._config.memory = memory
            if tools:
                self._config.tools = tools
            self._config.auto_heartbeat = auto_heartbeat
            self._governance_policy = governance_policy
            self._federation_visibility = federation_visibility

            if model:
                _setup_llm_engine(
                    self,
                    model=model,
                    provider=provider,
                    system_prompt=system_prompt,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    max_tool_rounds=max_tool_rounds,
                    planning=planning,
                    stream_by_default=stream_by_default,
                    api_key_override=kwargs.get("llm_api_key"),
                )

            if original_init and original_init is not object.__init__:
                original_init(self)

        cls.__init__ = new_init

        for name, method in BaseAgent.__dict__.items():
            if not name.startswith("__") and callable(method):
                if not hasattr(cls, name):
                    setattr(cls, name, method)

        for prop_name in [
            "agent_id",
            "client",
            "async_client",
            "memory",
            "tasks",
            "tools",
            "governance",
        ]:
            if not hasattr(cls, prop_name):
                setattr(cls, prop_name, getattr(BaseAgent, prop_name))

        @classmethod
        def run_agent(
            cls_self, base_url: Optional[str] = None, api_key: Optional[str] = None
        ):
            instance = cls_self(base_url, api_key)
            instance.run()

        cls.run = run_agent

        return cls

    return decorator


def _install_builtin_guardrails(agent_instance, guardrail_names: list[str]) -> None:
    """Install built-in guardrail handlers based on guardrail name strings.

    Supported guardrails:
    - "require_approval": logs a decision record before any assignment is processed
    - "budget_limit": rejects intents whose cost estimate exceeds constraints
    - "agent_allowlist": rejects delegation to agents not in the managed list
    """
    for name in guardrail_names:
        if name == "require_approval":

            async def _approval_guardrail(intent):
                logger.info(
                    f"Guardrail 'require_approval': assignment to intent "
                    f"{intent.id} requires approval"
                )
                if hasattr(agent_instance, "record_decision"):
                    await agent_instance.record_decision(
                        "guardrail",
                        f"require_approval check for intent {intent.id}",
                        rationale="Built-in guardrail: require_approval",
                    )

            _approval_guardrail._openintent_handler = "input_guardrail"
            agent_instance._handlers["input_guardrail"].append(_approval_guardrail)

        elif name == "budget_limit":

            async def _budget_guardrail(intent):
                cost_limit = getattr(intent, "constraints", {})
                if isinstance(cost_limit, dict) and cost_limit.get("max_cost"):
                    current = getattr(intent, "cost_total", 0) or 0
                    if current > cost_limit["max_cost"]:
                        raise GuardrailError(
                            f"Budget exceeded: {current} > {cost_limit['max_cost']}"
                        )

            _budget_guardrail._openintent_handler = "input_guardrail"
            agent_instance._handlers["input_guardrail"].append(_budget_guardrail)

        elif name == "agent_allowlist":

            async def _allowlist_guardrail(intent, result):
                delegated_to = (
                    result.get("delegated_to") if isinstance(result, dict) else None
                )
                if delegated_to and hasattr(agent_instance, "_agents_list"):
                    if delegated_to not in agent_instance._agents_list:
                        raise GuardrailError(
                            f"Agent '{delegated_to}' not in managed agent list"
                        )

            _allowlist_guardrail._openintent_handler = "output_guardrail"
            agent_instance._handlers["output_guardrail"].append(_allowlist_guardrail)

        else:
            logger.warning(f"Unknown built-in guardrail: '{name}' — ignored")


# ==================== Coordinator Decorator ====================


def Coordinator(  # noqa: N802
    coordinator_id: str,
    agents: Optional[list[str]] = None,
    strategy: str = "sequential",
    guardrails: Optional[list[str]] = None,
    config: Optional[AgentConfig] = None,
    capabilities: Optional[list[str]] = None,
    memory: Optional[str] = None,
    tools: Optional[list] = None,
    auto_heartbeat: bool = True,
    governance_policy: Optional[dict[str, Any]] = None,
    model: Optional[str] = None,
    provider: Optional[str] = None,
    system_prompt: Optional[str] = None,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    max_tool_rounds: int = 10,
    planning: bool = True,
    stream_by_default: bool = False,
    federation_visibility: Optional[str] = None,
    federation_policy: Optional[dict[str, Any]] = None,
    **kwargs: Any,
) -> Callable[[type], type]:
    """
    Class decorator to create a Coordinator from a class.

    A Coordinator manages portfolios of intents, handles dependency
    tracking, multi-intent orchestration, and governance.

    When ``model`` is provided, the coordinator becomes LLM-powered:
    ``self.think(prompt)`` reasons about delegation, planning, and
    governance decisions. The LLM can call coordinator-specific tools
    like ``delegate``, ``create_plan``, and ``record_decision``.

    Example — manual coordinator:
        ```python
        @Coordinator("orchestrator", agents=["researcher", "writer"])
        class MyCoordinator:
            @on_assignment
            async def plan(self, intent):
                spec = PortfolioSpec(
                    name=intent.title,
                    intents=[
                        IntentSpec("Research", assign="researcher"),
                        IntentSpec("Write", assign="writer", depends_on=["Research"]),
                    ]
                )
                return await self.execute(spec)
        ```

    Example — LLM-powered coordinator:
        ```python
        @Coordinator(
            "lead",
            model="claude-sonnet-4-20250514",
            agents=["researcher", "writer", "reviewer"],
            memory="episodic",
        )
        class ProjectLead:
            @on_assignment
            async def plan(self, intent):
                return await self.think(
                    f"Break down this project and delegate to your team: {intent.description}"
                )
        ```
    """

    def decorator(cls: type) -> type:
        original_init = cls.__init__ if hasattr(cls, "__init__") else None

        def new_init(
            self, base_url: Optional[str] = None, api_key: Optional[str] = None
        ):
            BaseAgent.__init__(self, base_url, api_key, config)
            self._agent_id = coordinator_id
            if capabilities:
                self._config.capabilities = capabilities
            if memory:
                self._config.memory = memory
            if tools:
                self._config.tools = tools
            self._config.auto_heartbeat = auto_heartbeat
            self._governance_policy = governance_policy
            self._federation_visibility = federation_visibility
            self._federation_policy = federation_policy
            self._agents_list = agents or []
            self._strategy = strategy
            self._guardrails = guardrails or []
            self._decision_log = []
            self._portfolios = {}
            self._intent_to_portfolio = {}
            self._pending_approvals: dict[str, asyncio.Future] = {}
            self._handlers.update({"conflict": [], "escalation": [], "quorum": []})
            _install_builtin_guardrails(self, self._guardrails)
            registered_funcs = set()
            for handler_type, handler_list in self._handlers.items():
                for h in handler_list:
                    registered_funcs.add(getattr(h, "__func__", h))
            for attr_name in dir(self):
                if attr_name.startswith("_"):
                    continue
                method = getattr(self, attr_name, None)
                if (
                    method
                    and callable(method)
                    and hasattr(method, "_openintent_handler")
                ):
                    handler_type = method._openintent_handler
                    func = getattr(method, "__func__", method)
                    if handler_type in self._handlers and func not in registered_funcs:
                        self._handlers[handler_type].append(method)
                        registered_funcs.add(func)
            if model:
                _setup_llm_engine(
                    self,
                    model=model,
                    provider=provider,
                    system_prompt=system_prompt,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    max_tool_rounds=max_tool_rounds,
                    planning=planning,
                    stream_by_default=stream_by_default,
                    api_key_override=kwargs.get("llm_api_key"),
                )

            if original_init and original_init is not object.__init__:
                original_init(self)

        cls.__init__ = new_init

        for name, method in BaseAgent.__dict__.items():
            if not name.startswith("__") and callable(method):
                if not hasattr(cls, name):
                    setattr(cls, name, method)

        for prop_name in [
            "agent_id",
            "client",
            "async_client",
            "memory",
            "tasks",
            "tools",
            "governance",
        ]:
            if not hasattr(cls, prop_name):
                setattr(cls, prop_name, getattr(BaseAgent, prop_name))

        async def create_portfolio(self, spec: PortfolioSpec) -> IntentPortfolio:
            """Create a portfolio from a specification."""
            portfolio = await self.async_client.create_portfolio(
                name=spec.name,
                description=spec.description,
                governance_policy=spec.governance_policy,
                metadata=spec.metadata,
            )

            intent_id_map: dict[str, str] = {}
            ordered = self._topological_sort(spec.intents)

            for intent_spec in ordered:
                wait_for = [
                    intent_id_map[dep] for dep in (intent_spec.depends_on or [])
                ]
                initial_state = dict(intent_spec.initial_state)

                intent = await self.async_client.create_intent(
                    title=intent_spec.title,
                    description=intent_spec.description,
                    constraints=intent_spec.constraints,
                    initial_state=initial_state,
                    depends_on=wait_for,
                )

                intent_id_map[intent_spec.title] = intent.id

                await self.async_client.add_intent_to_portfolio(
                    portfolio.id,
                    intent.id,
                    role=MembershipRole.MEMBER,
                )

                if intent_spec.assign:
                    await self.async_client.assign_agent(intent.id, intent_spec.assign)

                self._intent_to_portfolio[intent.id] = portfolio.id

            self._portfolios[portfolio.id] = portfolio
            return portfolio

        cls.create_portfolio = create_portfolio

        def _topological_sort(self, intents: list[IntentSpec]) -> list[IntentSpec]:
            """Sort intents by dependencies."""
            by_title = {i.title: i for i in intents}
            visited: set[str] = set()
            result: list[IntentSpec] = []

            def visit(spec: IntentSpec):
                if spec.title in visited:
                    return
                visited.add(spec.title)
                for dep in spec.depends_on or []:
                    if dep in by_title:
                        visit(by_title[dep])
                result.append(spec)

            for spec in intents:
                visit(spec)

            return result

        cls._topological_sort = _topological_sort

        async def execute(
            self,
            spec: PortfolioSpec,
            workflow_spec: Optional[Any] = None,
        ) -> dict[str, Any]:
            """Execute a portfolio and wait for completion.

            Args:
                spec: The portfolio specification to execute.
                workflow_spec: Optional ``WorkflowSpec`` for RFC-0024 I/O
                    contract enforcement.  When provided the executor calls
                    ``validate_claim_inputs`` when an intent becomes claimable
                    and ``validate_task_outputs`` when it completes.

            Returns:
                Merged results from all completed intents.
            """
            from .workflow import WorkflowSpec

            portfolio = await self.create_portfolio(spec)
            await self._subscribe_portfolio(portfolio.id)

            # RFC-0024: track which intents we have already validated so we
            # don't re-validate on every poll cycle.
            _claim_validated: set[str] = set()
            _completion_validated: set[str] = set()

            while True:
                portfolio_with_intents = await self.async_client.get_portfolio(
                    portfolio.id
                )
                intents_list, aggregate = await self.async_client.get_portfolio_intents(
                    portfolio.id
                )
                portfolio_with_intents.intents = intents_list
                portfolio_with_intents.aggregate_status = aggregate

                # RFC-0024: executor-side I/O validation when a WorkflowSpec is
                # provided.  We resolve phase names from intent titles via the
                # name→title mapping stored in the WorkflowSpec.
                if isinstance(workflow_spec, WorkflowSpec):
                    title_to_name = {p.title: p.name for p in workflow_spec.phases}
                    # Build upstream outputs from all completed intents
                    upstream_outputs: dict[str, dict[str, Any]] = {}
                    for intent in intents_list:
                        if intent.status == IntentStatus.COMPLETED:
                            phase_name = title_to_name.get(intent.title, intent.title)
                            try:
                                upstream_outputs[phase_name] = intent.state.to_dict()
                            except Exception:
                                upstream_outputs[phase_name] = {}

                    for intent in intents_list:
                        phase_name = title_to_name.get(intent.title, intent.title)

                        # Claim-time validation: validate inputs for intents
                        # that are PENDING with all deps satisfied.  Raises
                        # UnresolvableInputError / InputWiringError to the
                        # caller if inputs cannot be resolved — this blocks
                        # the entire portfolio (RFC-0024 §3.1).
                        # Note: intent.depends_on contains intent IDs (not
                        # titles), so we compare against i2.id.
                        # Intents start in DRAFT and transition to ACTIVE
                        # when ready; validate claim when still in DRAFT
                        # with all deps complete.
                        if (
                            intent.id not in _claim_validated
                            and intent.status == IntentStatus.DRAFT
                        ):
                            deps_complete = all(
                                any(
                                    i2.id == dep and i2.status == IntentStatus.COMPLETED
                                    for i2 in intents_list
                                )
                                for dep in (intent.depends_on or [])
                            )
                            if deps_complete:
                                # Raises UnresolvableInputError if unresolvable
                                workflow_spec.validate_claim_inputs(
                                    phase_name=phase_name,
                                    upstream_outputs=upstream_outputs,
                                    task_id=intent.id,
                                )
                                _claim_validated.add(intent.id)

                        # Completion-time validation: validate outputs for
                        # intents that just completed.  Raises
                        # MissingOutputError / OutputTypeMismatchError to the
                        # caller if outputs violate the declared schema
                        # (RFC-0024 §3.3).
                        if (
                            intent.id not in _completion_validated
                            and intent.status == IntentStatus.COMPLETED
                        ):
                            agent_output: dict[str, Any] = {}
                            try:
                                agent_output = intent.state.to_dict()
                            except Exception:
                                pass
                            # Raises MissingOutputError / OutputTypeMismatchError
                            workflow_spec.validate_task_outputs(
                                phase_name=phase_name,
                                agent_output=agent_output,
                                task_id=intent.id,
                            )
                            _completion_validated.add(intent.id)

                all_complete = all(
                    i.status == IntentStatus.COMPLETED for i in intents_list
                )

                if all_complete:
                    for handler in self._handlers["all_complete"]:
                        result = await self._call_handler(
                            handler, portfolio_with_intents
                        )
                        if result:
                            return result
                    return self._merge_results(portfolio_with_intents)

                await asyncio.sleep(0.5)

        cls.execute = execute

        async def _subscribe_portfolio(self, portfolio_id: str) -> None:
            """Subscribe to portfolio events."""
            url = f"{self._config.base_url}/api/v1/portfolios/{portfolio_id}/subscribe"
            headers = {
                "X-API-Key": self._config.api_key,
                "X-Agent-ID": self._agent_id,
            }

            async def event_loop():
                stream = SSEStream(
                    url,
                    headers,
                    reconnect_delay=self._config.reconnect_delay,
                    max_reconnects=self._config.max_reconnects,
                )
                for event in stream:
                    if not self._running:
                        break
                    await self._handle_event(event)

            asyncio.create_task(event_loop())

        cls._subscribe_portfolio = _subscribe_portfolio

        def _merge_results(self, portfolio: IntentPortfolio) -> dict[str, Any]:
            """Merge results from all intents in a portfolio."""
            return {
                "portfolio_id": portfolio.id,
                "name": portfolio.name,
                "intents": {i.title: i.state.to_dict() for i in portfolio.intents},
            }

        cls._merge_results = _merge_results

        async def coord_delegate(self, intent_id: str, agent_id: str, **kw):
            """Delegate work on an intent to another agent."""
            await self.record_decision(
                "delegation", f"Delegating to {agent_id}", agent_id=agent_id
            )  # noqa: E501
            return await self.async_client.assign_agent(intent_id, agent_id)

        cls.delegate = coord_delegate

        async def coord_escalate(self, intent_id: str, reason: str, **kw):
            """Escalate an intent to the coordinator for review."""
            await self.record_decision("escalation", reason)
            return await self.async_client.request_arbitration(
                intent_id,
                reason=reason,
                context=kw,
            )

        cls.escalate = coord_escalate

        async def record_decision(
            self, decision_type: str, summary: str, rationale: str = "", **data: Any
        ) -> dict[str, Any]:  # noqa: E501
            """Record an auditable coordinator decision (RFC-0013)."""
            record = {
                "type": decision_type,
                "summary": summary,
                "rationale": rationale,
                "coordinator_id": self._agent_id,
                **data,
            }
            self._decision_log.append(record)
            return record

        cls.record_decision = record_decision

        decisions_prop = property(lambda self: list(self._decision_log))
        decisions_prop.__doc__ = "Access the coordinator's decision log."
        cls.decisions = decisions_prop

        agents_prop = property(lambda self: list(self._agents_list))
        agents_prop.__doc__ = "List of managed agent IDs."
        cls.agents = agents_prop

        @classmethod
        def run_agent(
            cls_self, base_url: Optional[str] = None, api_key: Optional[str] = None
        ):
            instance = cls_self(base_url, api_key)
            instance.run()

        cls.run = run_agent

        return cls

    return decorator


# ==================== First-class Protocol Decorators ====================


def Plan(  # noqa: N802
    name: str,
    strategy: str = "sequential",
    max_concurrent: int = 5,
    failure_policy: str = "fail_fast",
) -> Callable[[type], type]:
    """Declarative plan definition (RFC-0012). Defines task decomposition strategy."""

    def decorator(cls: type) -> type:
        cls._plan_name = name
        cls._plan_strategy = strategy
        cls._plan_max_concurrent = max_concurrent
        cls._plan_failure_policy = failure_policy

        def to_spec(self) -> PortfolioSpec:
            """Convert plan to PortfolioSpec for execution."""
            plan_tasks = []
            for attr_name in dir(self):
                attr = getattr(self, attr_name, None)
                if isinstance(attr, IntentSpec):
                    plan_tasks.append(attr)
            return PortfolioSpec(name=name, intents=plan_tasks)

        cls.to_spec = to_spec
        return cls

    return decorator


def Vault(  # noqa: N802
    name: str,
    rotate_keys: bool = False,
) -> Callable[[type], type]:
    """Declarative credential vault (RFC-0014). Defines tool access and credential policies."""

    def decorator(cls: type) -> type:
        cls._vault_name = name
        cls._vault_rotate_keys = rotate_keys

        def get_tools(self) -> list[str]:
            """List all tools declared in this vault."""
            found_tools = []
            for attr_name in dir(self):
                if not attr_name.startswith("_"):
                    attr = getattr(self, attr_name, None)
                    if isinstance(attr, dict) and "scopes" in attr:
                        found_tools.append(attr_name)
            return found_tools

        cls.get_tools = get_tools
        return cls

    return decorator


def Memory(  # noqa: N802
    namespace: str,
    tier: str = "episodic",
    ttl: Optional[int] = None,
    max_entries: int = 1000,
) -> Callable[[type], type]:
    """Declarative memory configuration (RFC-0015). Defines memory tier and policies."""

    def decorator(cls: type) -> type:
        cls._memory_namespace = namespace
        cls._memory_tier = tier
        cls._memory_ttl = ttl
        cls._memory_max_entries = max_entries
        return cls

    return decorator


def Trigger(  # noqa: N802
    name: str,
    type: str = "schedule",
    condition: Optional[str] = None,
    cron: Optional[str] = None,
    dedup: str = "skip",
) -> Callable[[type], type]:
    """Declarative trigger definition (RFC-0017). Creates intents when conditions are met."""

    def decorator(cls: type) -> type:
        cls._trigger_name = name
        cls._trigger_type = type
        cls._trigger_condition = condition
        cls._trigger_cron = cron
        cls._trigger_dedup = dedup
        return cls

    return decorator


# ==================== Simple Worker ====================


class Worker:
    """
    Ultra-minimal worker for simple, single-purpose agents.

    Example:
        ```python
        async def process(intent):
            return {"result": do_work(intent.title)}

        worker = Worker("processor", process)
        worker.run()
        ```
    """

    def __init__(
        self,
        agent_id: str,
        handler: Callable[[Intent], Any],
        base_url: str = "http://localhost:5000",
        api_key: str = "",
    ):
        self.agent_id = agent_id
        self.handler = handler
        self.base_url = base_url
        self.api_key = api_key
        self._running = False

    def run(self) -> None:
        """Run the worker."""
        asyncio.run(self._run_async())

    async def _run_async(self) -> None:
        """Async run loop."""
        client = AsyncOpenIntentClient(
            base_url=self.base_url,
            api_key=self.api_key,
            agent_id=self.agent_id,
        )

        url = f"{self.base_url}/api/v1/agents/{self.agent_id}/subscribe"
        headers = {
            "X-API-Key": self.api_key,
            "X-Agent-ID": self.agent_id,
        }

        self._running = True
        stream = SSEStream(url, headers)

        for event in stream:
            if not self._running:
                break

            if event.type in ("AGENT_ASSIGNED", SSEEventType.AGENT_ASSIGNED):
                intent_id = event.data.get("intent_id")
                if intent_id:
                    intent = await client.get_intent(intent_id)

                    try:
                        if asyncio.iscoroutinefunction(self.handler):
                            result = await self.handler(intent)
                        else:
                            result = self.handler(intent)

                        if result and isinstance(result, dict):
                            await client.update_state(intent_id, intent.version, result)
                            intent = await client.get_intent(intent_id)

                        await client.set_status(
                            intent_id, IntentStatus.COMPLETED, intent.version
                        )
                    except Exception as e:
                        logger.exception(f"Worker error: {e}")

    def stop(self) -> None:
        """Stop the worker."""
        self._running = False
