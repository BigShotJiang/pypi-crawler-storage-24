# Nexus Ledger — Signed proof that your agents did the work

Built by Mercury & Vickson of Vickson Enterprises ☿️

Nexus Ledger is a pure sign + log + anchor library.

```python
from nexus_ledger import Agent

agent = Agent("Mercury")
agent.log("delivered_research", {"topic": "market analysis"})
tx = agent.anchor({"task": "research", "result": "complete"})
```

## Core model

- keypair = identity
- signature = proof
- Solana memo anchor = permanent record

No server needed. No registration. No financial features.

## Install

```bash
pip install nexus-ledger
```

**If that doesn't work:**

| Problem | Fix |
|---------|-----|
| `command not found: pip` | Try `pip3 install nexus-ledger` |
| Still not found | Try `python3 -m pip install nexus-ledger` |
| "externally managed environment" | Try `python3 -m pip install nexus-ledger --user` |
| Still stuck | `python3 -m venv .venv && source .venv/bin/activate && pip install nexus-ledger` |

**Requirements:** Python 3.10+. That's it.

Optional — for on-chain proof anchoring on Solana:

```bash
pip install nexus-ledger[solana]
```

## Full example

```python
from nexus_ledger import Agent

agent_a = Agent("Mercury")
agent_b = Agent("Iris")

agent_a.log("delivered_research", {"topic": "market analysis"}, counterparty=agent_b)

tx = agent_a.anchor({"task": "research", "result": "complete"})
assert agent_a.verify({"task": "research", "result": "complete"}, tx["hash"])

print(agent_a.history())
```

## Demo

```bash
python demo.py
python demo.py --mainnet
python exchange_demo.py
```

- default mode is mock anchoring
- `--mainnet` sends real SPL Memo anchors to Solana mainnet-beta

## Cross-Machine Receipts

Two agents sign the same receipt for a shared event. Agent A signs first, Agent B verifies and countersigns, and both keep a copy. Later, either side can verify both signatures and prove the transaction happened.

Flow:

```python
from nexus_ledger import Agent

agent_a = Agent("Mercury-A")
agent_b = Agent("Iris-B")

receipt = agent_a.create_receipt(
    "delivered_research",
    {"task_id": "T-9001", "result": "complete"},
    agent_b.public_key,
)

payload_to_b = agent_a.export_receipt(receipt)          # create -> export -> send
from_a = agent_b.import_receipt(payload_to_b)
signed_by_b = agent_b.countersign_receipt(from_a)       # countersign
payload_to_a = agent_b.export_receipt(signed_by_b)      # send back
final_receipt = agent_a.import_receipt(payload_to_a)

assert agent_a.verify_receipt(final_receipt) is True    # verify
assert agent_b.verify_receipt(final_receipt) is True

agent_a.store_receipt(final_receipt)                    # store
agent_b.store_receipt(final_receipt)
```

The exchange format is plain JSON strings. You can send them over HTTP, WebSocket, files, email, Discord, or any other transport.

Two agents. Two machines. One unfakeable receipt.

## License

Business Source License 1.1 (BSL 1.1). See [LICENSE](LICENSE).
