from .clipitTab import ClipIt
