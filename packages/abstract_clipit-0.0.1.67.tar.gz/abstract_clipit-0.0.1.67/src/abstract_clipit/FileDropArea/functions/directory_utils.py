from ..imports import *
from abstract_utilities import *
def _update_dir_patterns(self):
    """Update self.exclude_dirs from dir_input text."""
    text = self.dir_checks
    if text:
        self.exclude_dirs = self.dir_checks
    else:
        self.exclude_dirs = set()
    self.exclude_dirs.update(self.exclude_dirs)  # Include defaults

    #self._log(f"Directory row visible: True, checkboxes: {list(new_checks.keys())}")





def dragEnterEvent(self, event: QtGui.QDragEnterEvent):
    if event.mimeData().hasUrls():
        event.acceptProposedAction()
    else:
        event.ignore()

def dropEvent(self, event: QtGui.QDropEvent):
    try:
        urls = event.mimeData().urls()
        paths = [url.toLocalFile() for url in make_list(urls)]
        if not paths:
            raise ValueError("No local files detected on drop.")
        self.process_files(paths)
    except Exception as e:
        tb = traceback.format_exc()
        self.status.setText(f"⚠️ Error during drop: {e}")
        self._log(f"dropEvent ERROR:\n{tb}")

def filter_paths(self, paths: list[str]) -> list[str]:
    filtered=[]
##    self._log(f"""filtering {paths} with allowed_exts={self.allowed_exts}\n,
##            exclude_exts={self.exclude_exts}\n,
##            allowed_types={self.allowed_types}\n,
##            exclude_types={self.exclude_types}\n,
##            allowed_dirs={self.allowed_dirs}\n,  # Use dynamic dir patterns
##            exclude_dirs={self.exclude_dirs}\n,
##            allowed_patterns={self.allowed_patterns}\n,
##            exclude_patterns={self.exclude_patterns}\n
##
##            as\n\n
##            filtered = collect_filepaths(
##                {paths},
##                allowed_exts={self.allowed_exts}\n,
##                exclude_exts={self.exclude_exts}\n,
##                allowed_types={self.allowed_types}\n,
##                exclude_types={self.exclude_types}\n,
##                allowed_dirs={self.allowed_dirs}\n,  # Use dynamic dir patterns
##                exclude_dirs={self.exclude_dirs}\n,
##                allowed_patterns={self.allowed_patterns}\n,
##                exclude_patterns={self.exclude_patterns}\n
##        )""")
    cfg=define_defaults(allowed_exts=self.allowed_exts,
            exclude_exts=self.exclude_exts,
            allowed_types=self.allowed_types,
            exclude_types=self.exclude_types,
            allowed_dirs=self.allowed_dirs,  # Use dynamic dir patterns
            exclude_dirs=self.exclude_dirs,
            allowed_patterns=self.allowed_patterns,
            exclude_patterns=self.exclude_patterns
        )
    allowed_items = filter_allowed_items(paths,cfg=cfg)
    filtered = [item for item in allowed_items if os.path.isfile(item)]
    dirs = [item for item in allowed_items if os.path.isdir(item)]
    if dirs:
        filtered += collect_filepaths(
                directories=dirs,
                cfg=cfg
            )
    filtered = list(set(filtered))   
    self._log(f"_filtered_file_list returned {len(filtered)} path(s) as {filtered}")
    if not filtered:
        self.status.setText("⚠️ No valid files detected in drop.")
        self._log("No valid paths after filtering.")
        return []
    self._log(f"Proceeding to process {len(filtered)} file(s).")
    return filtered

def get_contents_text(self, file_path: str, idx: int = 0, filtered_paths: list[str] = []):
    basename = os.path.basename(file_path)
    filename, ext = os.path.splitext(basename)
    if ext not in self.exclude_exts:
        header = f"=== {file_path} ===\n"
        footer = "\n\n――――――――――――――――――\n\n"
        info = {
            'path': file_path,
            'basename': basename,
            'filename': filename,
            'ext': ext,
            'text': "",
            'error': False,
            'visible': True
        }
        try:
            body = read_file_as_text(file_path) or ""
            if isinstance(body, list):
                body = "\n".join(body)
            info["text"] = [header, body, footer]
            if ext == '.py':
                self._parse_functions(file_path, str(body))
        except Exception as exc:
            info["error"] = True
            info["text"] = f"[Error reading {basename}: {exc}]\n"
            self._log(f"Error reading {file_path} → {exc}")
        return info

def process_files(self, paths: list[str] = None) -> None:
    paths = make_list(paths or [])
    self._last_raw_paths = paths
    filtered = self.filter_paths(paths)
    if not filtered:
        return
    self._rebuild_ext_row(filtered)
    self._rebuild_dir_row(filtered)
    filtered_paths=[]
    if self.ext_checks or self.dir_checks:
        visible_exts = {ext for ext, cb in self.ext_checks.items() if cb.isChecked()}
        visible_dirs = {di for di, cb in self.dir_checks.items() if cb.isChecked()}
        
        self._log(f"Visible extensions: {visible_exts}")
        filtered_paths = [
            p for p in filtered
            if (os.path.isdir(p) or os.path.splitext(p)[1].lower() in visible_exts) and not is_string_in_dir(p,list(visible_dirs))
        ]
    else:
        filtered_paths  = filtered
    if not filtered_paths:
        self.text_view.clear()
        self.status.setText("⚠️ No files match current extension filter.")
        return
    self.status.setText(f"Reading {len(filtered_paths)} file(s)…")
    QtWidgets.QApplication.processEvents()
    self.combined_text_lines = {}
    self.functions = []
    self.python_files = []
    for idx, p in enumerate(filtered_paths, 1):
        info = self.get_contents_text(p, idx, filtered_paths)
        if info:
            self.combined_text_lines[p] = info
            if info['ext'] == '.py':
                self.python_files.append(info)
    self._populate_list_view()
    self._populate_text_view()
    self.status.setText("Files processed. Switch tabs to view.")
    
def on_function_clicked(self, item: QtWidgets.QListWidgetItem) -> None:
    index = self.function_list.row(item)
    function_info = self.functions[index]
    self.function_selected.emit(function_info)

def on_python_file_clicked(self, item: QtWidgets.QListWidgetItem) -> None:
    index = self.python_file_list.row(item)
    file_info = self.python_files[index]
    self.file_selected.emit(file_info)

def browse_files(self) -> None:
    files, _ = QtWidgets.QFileDialog.getOpenFileNames(
        self,
        "Select Files to Copy",
        "",
        "All Supported Files (" + " ".join(f"*{ext}" for ext in self.allowed_exts) + ");;All Files (*)"
    )
    if files:
        filtered = self.filter_paths(files)
        if filtered:
            self.process_files(filtered)

def _log(self, message: str) -> None:
    timestamp = QtCore.QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
    logger.info(f"[{timestamp}] {message}")
    self.log_widget.append(f"[{timestamp}] {message}")

def _clear_layout(self, layout: QtWidgets.QLayout) -> None:
    if layout is None:
        return
    while layout.count():
        item = layout.takeAt(0)
        if item.widget():
            item.widget().setParent(None)
            item.widget().deleteLater()
        elif item.layout():
            self._clear_layout(item.layout())

