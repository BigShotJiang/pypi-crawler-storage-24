from imports import *
ClipIt()
