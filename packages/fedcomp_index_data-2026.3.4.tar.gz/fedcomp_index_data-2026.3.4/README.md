# FedComp Index Data

![FedComp Index](https://fedcompindex.org/static/img/FedComp-Index-Tabularium-3.png)

Pre-scored federal contractor datasets bundled for Python. Each contractor has a FedComp Index score (0-100) and posture class assignment based on five years of USASpending award data.

Updated monthly with fresh data from the FedComp Index pipeline.

## Install

```bash
pip install fedcomp-index-data
```

## Usage

```python
from fedcomp_index_data import load_state, lookup

# Load all scored contractors for a state
contractors = load_state("NV")
print(f"{len(contractors)} contractors scored")

# Filter by posture class
class_1 = [c for c in contractors if c["posture_class"] == "Class 1"]
print(f"{len(class_1)} Class 1 contractors")

# Look up a specific contractor by UEI
c = lookup("CGAKREGGN9J3")
print(c["legal_name"])      # FLEET VEHICLE SOURCE INC
print(c["fedcomp_index"])   # 81
print(c["posture_class"])   # Class 1
```

## Available states

| State | Contractors | Updated |
|-------|-------------|---------|
| Nevada (NV) | 348 | March 2026 |

More states are added as the FedComp Index expands coverage.

## Data fields

| Field | Description |
|-------|-------------|
| `rank` | FedComp Index rank within the state |
| `legal_name` | Registered legal name from SAM.gov |
| `uei` | Unique Entity Identifier |
| `cage` | CAGE code |
| `fedcomp_index` | FedComp Index score (0-100) |
| `posture_class` | Posture class: Class 1 (60+), Class 2 (40-59), Class 3 (<40) |
| `awards_5yr_total_usd` | Total award dollars over trailing 5-year window |
| `award_count` | Number of distinct awards |
| `active_contracts` | Currently active contracts |
| `last_award_date` | Date of most recent award (YYYY-MM) |
| `primary_naics` | Primary NAICS code |
| `top_agency` | Most frequent awarding agency |
| `city` | Registered city |
| `certifications` | SBA certifications (pipe-separated) |
| `state` | State of registration |
| `scored_date` | Year-month this score was computed |

## FedComp Index scoring

Two drivers, no normalization:

| Driver | Weight | How it works |
|--------|--------|-------------|
| Award volume | 90% | log10 of total dollars won, mapped to 0-100 |
| Award recency | 10% | Last award date, bucketed by age |

Posture classes are fixed thresholds:
- **Class 1** - score 60+ (~$100M+ in awards)
- **Class 2** - score 40-59 (~$5M-$100M)
- **Class 3** - below 40

Full methodology: [fedcompindex.org/wiki/methodology](https://fedcompindex.org/methodology/)

## Related packages

- [fedcomp-index-scoring](https://pypi.org/project/fedcomp-index-scoring/) - scoring engine
- [fedcomp-index](https://pypi.org/project/fedcomp-index/) - meta-package

## Data sources

- [USASpending.gov](https://www.usaspending.gov/) - award history
- [SAM.gov](https://sam.gov/) - entity registration
- [SBA.gov](https://www.sba.gov/) - certification verification

## Also available on npm

```bash
npm install fedcomp-index-data
```

- [fedcomp-index](https://www.npmjs.com/package/fedcomp-index) - meta-package
- [fedcomp-index-scoring](https://www.npmjs.com/package/fedcomp-index-scoring) - scoring engine
- [fedcomp-index-data](https://www.npmjs.com/package/fedcomp-index-data) - pre-scored datasets

## Links

- Website: [https://fedcompindex.org/](https://fedcompindex.org/)
- Nevada Rankings: [https://fedcompindex.org/nv/](https://fedcompindex.org/nv/)
- Methodology: [https://fedcompindex.org/methodology/](https://fedcompindex.org/methodology/)
- Tabularium: [https://fedcompindex.org/tabularium/](https://fedcompindex.org/tabularium/)
- FAQ: [https://fedcompindex.org/faq/](https://fedcompindex.org/faq/)
- Source: [https://github.com/fedcompindex/FedCompIndex](https://github.com/fedcompindex/FedCompIndex)
- npm packages: [https://github.com/fedcompindex/fedcomp-index-npm](https://github.com/fedcompindex/fedcomp-index-npm)
- PyPI: [https://pypi.org/project/fedcomp-index/](https://pypi.org/project/fedcomp-index/)
- PyPI (Scoring): [https://pypi.org/project/fedcomp-index-scoring/](https://pypi.org/project/fedcomp-index-scoring/)
- PyPI (Data): [https://pypi.org/project/fedcomp-index-data/](https://pypi.org/project/fedcomp-index-data/)
- HuggingFace: [https://huggingface.co/datasets/npetro6/nevada-federal-contractors](https://huggingface.co/datasets/npetro6/nevada-federal-contractors)
- Kaggle: [https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index](https://www.kaggle.com/datasets/npetro6/nevada-federal-contractors-fedcomp-index)

## License

MIT
