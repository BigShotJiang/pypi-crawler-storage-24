"""
FedComp Index Data - Pre-scored federal contractor datasets.

Bundled scored data from the FedComp Index pipeline. Each contractor
has a FedComp Index score (0-100) and posture class assignment.

Updated monthly with fresh USASpending award data.

Full datasets: https://huggingface.co/datasets/npetro6/nevada-federal-contractors
Live rankings: https://fedcompindex.org/nv/
"""

__version__ = "2026.3.2"

import csv
import io
from pathlib import Path

_DATA_DIR = Path(__file__).parent / "data"


def load_state(state="NV"):
    """
    Load scored contractors for a state.

    Returns list of dicts with keys: rank, legal_name, uei, cage,
    fedcomp_index, posture_class, awards_5yr_total_usd, award_count,
    active_contracts, last_award_date, primary_naics, top_agency,
    city, certifications, state, scored_date.

    Args:
        state: Two-letter state code (default "NV").

    Example::

        from fedcomp_index_data import load_state

        contractors = load_state("NV")
        for c in contractors[:5]:
            print(c["legal_name"], c["fedcomp_index"], c["posture_class"])
    """
    path = _DATA_DIR / f"{state.lower()}.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"No data for state '{state}'. Available: {list_states()}"
        )
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def list_states():
    """Return list of available state codes."""
    return sorted(
        p.stem.upper() for p in _DATA_DIR.glob("*.csv")
    )


def lookup(uei, state="NV"):
    """
    Look up a single contractor by UEI.

    Returns dict with FedComp Index score and posture class, or None.

    Args:
        uei: Unique Entity Identifier.
        state: Two-letter state code (default "NV").

    Example::

        from fedcomp_index_data import lookup

        c = lookup("CGAKREGGN9J3")
        print(c["fedcomp_index"])   # 81
        print(c["posture_class"])   # Class 1
    """
    for row in load_state(state):
        if row["uei"] == uei:
            return row
    return None
