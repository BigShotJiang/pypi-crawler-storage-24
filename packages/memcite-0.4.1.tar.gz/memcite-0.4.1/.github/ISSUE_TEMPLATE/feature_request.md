---
name: Feature Request
about: Suggest a feature or improvement
title: "[Feature] "
labels: enhancement
---

**Problem**
What problem does this solve?

**Proposed solution**
How should it work?

**Alternatives considered**
Any other approaches you've thought about.
