"""Test utilities for ``pillar-ai-server``.

Usage::

    from pillar.testing import generate_signature, create_tool_context
"""
from __future__ import annotations

from pillar._context import ToolContext
from pillar._signature import generate_signature

__all__ = ["create_tool_context", "generate_signature"]


def create_tool_context(payload: dict) -> ToolContext:
    """Build a :class:`ToolContext` from a raw webhook payload dict.

    Convenience wrapper around :meth:`ToolContext.from_payload` for tests.
    """
    return ToolContext.from_payload(payload)
