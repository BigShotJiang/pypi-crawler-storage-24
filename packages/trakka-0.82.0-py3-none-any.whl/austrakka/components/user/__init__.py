from typing import List

import click

from austrakka.utils.output import table_format_option
from austrakka.utils.cmd_filter import hide_admin_cmds
from austrakka.utils.options import \
    opt_identifier, \
    opt_username, \
    opt_owner_group_roles, \
    opt_name, \
    opt_email_address, \
    opt_is_active, \
    opt_user_no_dl_quota, \
    opt_user_monthly_dl_quota_bytes, opt_user_position
from austrakka.utils.options import opt_is_austrakka_process
from austrakka.utils.options import opt_user_object_id
from austrakka.utils.options import opt_organisation
from austrakka.utils.options import opt_show_disabled
from austrakka.utils.options import opt_server_username
from austrakka import __prog_name__ as PROG_NAME
from austrakka.utils.privilege import USER_RESOURCE
from austrakka.utils.subcommands.log import log_subcommands
from .funcs import list_users
from .funcs import add_user
from .funcs import update_user
from .funcs import enable_user
from .funcs import disable_user
from .funcs import rename_user


@click.group()
@click.pass_context
def user(ctx):
    '''Commands related to users'''
    ctx.context = ctx.parent.context

user.add_command(log_subcommands(USER_RESOURCE))

@user.command('list', help=f"List users in {PROG_NAME}")
@opt_show_disabled()
@table_format_option()
def user_list(show_disabled: bool, out_format: str):
    list_users(show_disabled, out_format)


@user.command('add', hidden=hide_admin_cmds(), help=f'Add users in {PROG_NAME}')
@opt_user_object_id()
@opt_username()
@opt_organisation()
@opt_owner_group_roles(required=False)
@opt_is_austrakka_process(default=False)
@opt_server_username()
@opt_user_no_dl_quota()
@opt_email_address(required=False)
@opt_user_position()
@opt_user_monthly_dl_quota_bytes()
def user_add(
        user_id: str,
        username: str,
        org: str,
        email: str,
        position: str,
        owner_group_roles: List[str],
        is_process: bool,
        server_username: str,
        no_download_quota: bool,
        download_quota: int,
):
    add_user(
        user_id,
        username,
        org, 
        email,
        position,
        owner_group_roles, 
        is_process, 
        server_username, 
        no_download_quota, 
        download_quota
    )


@user.command('update', hidden=hide_admin_cmds(), help=f'Add users in {PROG_NAME}')
@opt_user_object_id()
@opt_name(help="Display Name", required=False)
@opt_email_address(required=False)
@opt_user_position(required=False)
@opt_organisation(required=False)
@opt_is_active(required=False)
@opt_server_username(required=False)
@opt_user_no_dl_quota(default=None)
@opt_user_monthly_dl_quota_bytes()
def user_update(
    user_id: str,
    org: str,
    is_active: bool,
    email: str,
    position: str,
    name: str,
    server_username: str,
    no_download_quota: bool,
    download_quota: int,
):
    update_user(
        user_id, 
        name, 
        email, 
        position,
        org, 
        server_username, 
        is_active, 
        no_download_quota, 
        download_quota
    )


@user.command('enable', help=f"Re-enable a user in {PROG_NAME}")
@opt_user_object_id()
def user_enable(user_id: str):
    enable_user(user_id)


@user.command('disable', help=f"Disable a user in {PROG_NAME}")
@opt_user_object_id()
def user_disable(user_id: str):
    disable_user(user_id)


@user.command('rename', help="Rename a user username")
@opt_identifier()
@opt_username(help="New username for user")
def user_rename(global_id: str, username: str):
    rename_user(global_id, username)
