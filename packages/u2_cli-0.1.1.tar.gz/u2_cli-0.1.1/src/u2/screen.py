from __future__ import annotations

import io
import sys
import xml.etree.ElementTree as ET
from typing import Optional

import typer

from u2 import get_device, out

# Attributes kept in simplified output (all others dropped)
_KEEP_ATTRS = {"text", "resource-id", "content-desc", "bounds", "class"}
# Boolean attributes included only when "true"
_BOOL_ATTRS = {
    "clickable", "scrollable", "checkable", "checked", "selected", "long-clickable", "focused"
}
# Class name suffixes used as short labels
_CLASS_SHORT = {
    "TextView": "text",
    "EditText": "input",
    "Button": "button",
    "ImageView": "image",
    "ImageButton": "image-button",
    "CheckBox": "checkbox",
    "RadioButton": "radio",
    "Switch": "switch",
    "ToggleButton": "toggle",
    "SeekBar": "seekbar",
    "ProgressBar": "progress",
    "ListView": "list",
    "RecyclerView": "list",
    "ScrollView": "scroll",
    "HorizontalScrollView": "scroll-h",
    "ViewPager": "pager",
    "WebView": "web",
    "FrameLayout": "frame",
    "LinearLayout": "linear",
    "RelativeLayout": "relative",
    "ConstraintLayout": "constraint",
    "CoordinatorLayout": "coordinator",
    "Toolbar": "toolbar",
    "TabLayout": "tabs",
    "BottomNavigationView": "bottom-nav",
    "NavigationView": "nav",
}


def _short_class(class_name: str) -> str:
    suffix = class_name.rsplit(".", 1)[-1]
    return _CLASS_SHORT.get(suffix, suffix)


def _simplify_node(node: ET.Element) -> dict | None:
    """Convert an XML node to a simplified dict, or None if the node should be pruned."""
    attrib = node.attrib

    # Drop invisible nodes and their subtrees
    if attrib.get("visible-to-user") == "false":
        return None

    children = []
    for child in node:
        simplified = _simplify_node(child)
        if simplified is not None:
            children.append(simplified)

    # Build the simplified representation
    entry: dict = {}

    class_name = attrib.get("class", "")
    short = _short_class(class_name)
    if short != class_name:
        entry["type"] = short
    else:
        entry["type"] = class_name

    text = attrib.get("text", "").strip()
    if text:
        entry["text"] = text

    desc = attrib.get("content-desc", "").strip()
    if desc and desc != text:
        entry["desc"] = desc

    rid = attrib.get("resource-id", "")
    if rid:
        # Strip package prefix for brevity: "com.example:id/foo" -> "foo"
        entry["id"] = rid.split("/", 1)[-1] if "/" in rid else rid

    bounds = attrib.get("bounds", "")
    if bounds:
        entry["bounds"] = bounds

    for attr in _BOOL_ATTRS:
        if attrib.get(attr) == "true":
            entry[attr] = True

    # Prune container nodes that carry no info and have exactly one child
    no_info = not any(k in entry for k in ("text", "desc", "id"))
    no_flags = not any(entry.get(a) for a in _BOOL_ATTRS)
    if no_info and no_flags and len(children) == 1:
        return children[0]

    if children:
        entry["children"] = children

    return entry


def _simplify_xml(xml: str) -> str:
    import json

    root = ET.fromstring(xml)
    # The root is <hierarchy>, its child is the top-level node
    nodes = []
    for child in root:
        result = _simplify_node(child)
        if result is not None:
            nodes.append(result)

    top = nodes[0] if len(nodes) == 1 else nodes
    return json.dumps(top, ensure_ascii=False)

screen_app = typer.Typer(no_args_is_help=True)


@screen_app.command()
def screenshot(
    path: Optional[str] = typer.Argument(
        None, help="Output file path (omit to write PNG to stdout)"
    ),
) -> None:
    """Take a screenshot. Saves to file or writes PNG bytes to stdout."""
    try:
        d = get_device()
        if path:
            d.screenshot(path)
            out(True, f"Screenshot saved to: {path}", f"d.screenshot({path!r})")
        else:
            img = d.screenshot()
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            sys.stdout.buffer.write(buf.getvalue())
    except Exception as e:
        out(False, str(e))


@screen_app.command()
def dump(
    compressed: bool = typer.Option(False, "--compressed", help="Use compressed hierarchy"),  # noqa: FBT001, FBT002
    pretty: bool = typer.Option(False, "--pretty", help="Pretty-print XML"),  # noqa: FBT001, FBT002
    simplify: bool = typer.Option(  # noqa: FBT001, FBT002
        False, "--simplify", "-s", help="Strip noise, return compact JSON"
    ),
) -> None:
    """Dump UI hierarchy as XML, or simplified JSON with --simplify."""
    try:
        d = get_device()
        xml = d.dump_hierarchy(compressed=compressed)
        if simplify:
            result = _simplify_xml(xml)
            out(True, result, "d.dump_hierarchy() [simplified]")
        else:
            out(True, xml, f"d.dump_hierarchy(compressed={compressed}, pretty={pretty})")
    except Exception as e:
        out(False, str(e))


@screen_app.command()
def size() -> None:
    """Show screen size."""
    try:
        d = get_device()
        w, h = d.window_size()
        out(True, f"{w}x{h}", "d.window_size()")
    except Exception as e:
        out(False, str(e))


@screen_app.command()
def brightness(
    value: Optional[int] = typer.Argument(None, help="Brightness level 0-255 (omit to get)"),
) -> None:
    """Get or set screen brightness (0-255)."""
    try:
        d = get_device()
        if value is None:
            resp = d.shell("settings get system screen_brightness")
            out(True, resp.output.strip(), "d.shell('settings get system screen_brightness')")
        else:
            cmd = f"settings put system screen_brightness {value}"
            d.shell(cmd)
            out(True, f"Brightness set to: {value}", f"d.shell({cmd!r})")
    except Exception as e:
        out(False, str(e))
