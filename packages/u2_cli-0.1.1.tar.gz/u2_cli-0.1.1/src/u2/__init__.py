from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional

import typer
import uiautomator2 as u2

cli = typer.Typer(no_args_is_help=True)


@dataclass
class State:
    serial: str = ""


state = State()


def get_device() -> u2.Device:
    return u2.connect(state.serial) if state.serial else u2.connect()


def out(success: bool, output: str, code: str = "") -> None:  # noqa: FBT001
    typer.echo(json.dumps({"success": success, "output": output, "code": code}, ensure_ascii=False))


@cli.callback()
def main_callback(
    serial: Optional[str] = typer.Option(None, "-s", "--serial", help="Android device serial"),
) -> None:
    if serial:
        state.serial = serial


from u2.device import device_app  # noqa: E402
from u2.app import app_app  # noqa: E402
from u2.screen import screen_app  # noqa: E402
from u2.interact import interact_app  # noqa: E402
from u2.element import element_app  # noqa: E402
from u2.watch import watch_app  # noqa: E402

cli.add_typer(device_app, name="device")
cli.add_typer(app_app, name="app")
cli.add_typer(screen_app, name="screen")
cli.add_typer(interact_app, name="interact")
cli.add_typer(element_app, name="element")
cli.add_typer(watch_app, name="watch")


def main() -> None:
    cli()


if __name__ == "__main__":
    main()
