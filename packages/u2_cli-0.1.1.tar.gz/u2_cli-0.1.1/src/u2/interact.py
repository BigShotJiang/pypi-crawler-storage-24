from __future__ import annotations

import typer

from u2 import get_device, out

interact_app = typer.Typer(no_args_is_help=True)


@interact_app.command()
def tap(
    x: int = typer.Argument(..., help="X coordinate"),
    y: int = typer.Argument(..., help="Y coordinate"),
) -> None:
    """Tap at screen coordinates."""
    try:
        d = get_device()
        d.click(x, y)
        out(True, f"Tapped at ({x}, {y})", f"d.click({x}, {y})")
    except Exception as e:
        out(False, str(e))


@interact_app.command(name="long-tap")
def long_tap(
    x: int = typer.Argument(..., help="X coordinate"),
    y: int = typer.Argument(..., help="Y coordinate"),
    duration: float = typer.Option(0.5, "--duration", "-d", help="Press duration in seconds"),
) -> None:
    """Long tap at screen coordinates."""
    try:
        d = get_device()
        d.long_click(x, y, duration=duration)
        out(True, f"Long-tapped at ({x}, {y})", f"d.long_click({x}, {y}, duration={duration})")
    except Exception as e:
        out(False, str(e))


@interact_app.command()
def swipe(
    fx: int = typer.Argument(..., help="From X coordinate"),
    fy: int = typer.Argument(..., help="From Y coordinate"),
    tx: int = typer.Argument(..., help="To X coordinate"),
    ty: int = typer.Argument(..., help="To Y coordinate"),
    duration: float = typer.Option(0.5, "--duration", "-d", help="Swipe duration in seconds"),
) -> None:
    """Swipe from one point to another."""
    try:
        d = get_device()
        d.swipe(fx, fy, tx, ty, duration=duration)
        code = f"d.swipe({fx}, {fy}, {tx}, {ty}, duration={duration})"
        out(True, f"Swiped ({fx},{fy}) -> ({tx},{ty})", code)
    except Exception as e:
        out(False, str(e))


@interact_app.command()
def drag(
    sx: int = typer.Argument(..., help="Start X coordinate"),
    sy: int = typer.Argument(..., help="Start Y coordinate"),
    ex: int = typer.Argument(..., help="End X coordinate"),
    ey: int = typer.Argument(..., help="End Y coordinate"),
    duration: float = typer.Option(0.5, "--duration", "-d", help="Drag duration in seconds"),
) -> None:
    """Drag from one point to another."""
    try:
        d = get_device()
        d.drag(sx, sy, ex, ey, duration=duration)
        code = f"d.drag({sx}, {sy}, {ex}, {ey}, duration={duration})"
        out(True, f"Dragged ({sx},{sy}) -> ({ex},{ey})", code)
    except Exception as e:
        out(False, str(e))


@interact_app.command(name="type")
def type_text(
    text: str = typer.Argument(..., help="Text to type into the focused element"),
) -> None:
    """Type text into the focused element (supports Unicode/Chinese via clipboard paste)."""
    try:
        d = get_device()
        d.send_keys(text)
        out(True, f"Typed: {text!r}", f"d.send_keys('{text}')")
    except Exception as e:
        out(False, str(e))
    except Exception as e:
        out(False, str(e))


@interact_app.command()
def clear() -> None:
    """Clear text in the focused element."""
    try:
        d = get_device()
        d.clear_text()
        out(True, "Cleared focused element", "d.clear_text()")
    except Exception as e:
        out(False, str(e))
