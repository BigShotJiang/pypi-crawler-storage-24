from __future__ import annotations

import json
from typing import Optional

import typer

from u2 import get_device, out

element_app = typer.Typer(no_args_is_help=True)

# Shared selector options reused across commands
_TEXT = typer.Option(None, "--text", "-t", help="Element text")
_RESOURCE_ID = typer.Option(None, "--resource-id", "-r", help="Resource ID")
_CLASS_NAME = typer.Option(None, "--class-name", "-c", help="Class name")
_XPATH = typer.Option(None, "--xpath", "-x", help="XPath expression")
_DESCRIPTION = typer.Option(None, "--description", "-d", help="Content description")


def _build_selector(
    text: Optional[str],
    resource_id: Optional[str],
    class_name: Optional[str],
    description: Optional[str],
) -> dict:
    sel: dict = {}
    if text is not None:
        sel["text"] = text
    if resource_id is not None:
        sel["resourceId"] = resource_id
    if class_name is not None:
        sel["className"] = class_name
    if description is not None:
        sel["description"] = description
    return sel


@element_app.command()
def find(
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
    timeout: float = typer.Option(0.0, "--timeout", "-T", help="Wait up to N seconds for elements"),
) -> None:
    """Find elements matching the given selector."""
    try:
        d = get_device()
        if xpath:
            el = d.xpath(xpath)
            if timeout > 0:
                el.wait(timeout=timeout)
            elements = el.all()
            results = [e.elem.attrib for e in elements]
            code = f"d.xpath({xpath!r}).all()"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            el = d(**sel)
            count = el.count
            results = [el[i].info for i in range(count)]
            code = f"d({', '.join(f'{k}={v!r}' for k, v in sel.items())}).info"
        out(True, json.dumps(results), code)
    except Exception as e:
        out(False, str(e))


@element_app.command()
def wait(
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
    timeout: float = typer.Option(10.0, "--timeout", "-T", help="Timeout in seconds"),
) -> None:
    """Wait for an element to appear."""
    try:
        d = get_device()
        if xpath:
            found = d.xpath(xpath).wait(timeout=timeout)
            code = f"d.xpath({xpath!r}).wait(timeout={timeout})"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            found = d(**sel).wait(exists=True, timeout=timeout)
            sel_str = ", ".join(f"{k}={v!r}" for k, v in sel.items())
            code = f"d({sel_str}).wait(exists=True, timeout={timeout})"
        out(bool(found), "Element found" if found else "Element not found", code)
    except Exception as e:
        out(False, str(e))


@element_app.command()
def exists(
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
) -> None:
    """Check if an element exists."""
    try:
        d = get_device()
        if xpath:
            found = d.xpath(xpath).exists
            code = f"d.xpath({xpath!r}).exists"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            found = bool(d(**sel).exists)
            code = f"d({', '.join(f'{k}={v!r}' for k, v in sel.items())}).exists"
        out(True, str(found).lower(), code)
    except Exception as e:
        out(False, str(e))


@element_app.command(name="get-text")
def get_text(
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
    timeout: float = typer.Option(10.0, "--timeout", "-T", help="Timeout in seconds"),
) -> None:
    """Get text content of a matching element."""
    try:
        d = get_device()
        if xpath:
            el = d.xpath(xpath)
            el.wait(timeout=timeout)
            value = el.get_text()
            code = f"d.xpath({xpath!r}).get_text()"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            value = d(**sel).get_text(timeout=timeout)
            code = f"d({', '.join(f'{k}={v!r}' for k, v in sel.items())}).get_text()"
        out(True, value or "", code)
    except Exception as e:
        out(False, str(e))


@element_app.command(name="set-text")
def set_text(
    value: str = typer.Argument(..., help="Text to set"),
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
    timeout: float = typer.Option(10.0, "--timeout", "-T", help="Timeout in seconds"),
) -> None:
    """Set text on a matching element."""
    try:
        d = get_device()
        if xpath:
            el = d.xpath(xpath)
            el.wait(timeout=timeout)
            el.set_text(value)
            code = f"d.xpath({xpath!r}).set_text({value!r})"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            d(**sel).set_text(value, timeout=timeout)
            code = f"d({', '.join(f'{k}={v!r}' for k, v in sel.items())}).set_text({value!r})"
        out(True, f"Set text to: {value!r}", code)
    except Exception as e:
        out(False, str(e))


@element_app.command()
def tap(
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
    timeout: float = typer.Option(10.0, "--timeout", "-T", help="Timeout in seconds"),
) -> None:
    """Tap a matching element."""
    try:
        d = get_device()
        if xpath:
            el = d.xpath(xpath)
            el.wait(timeout=timeout)
            el.click()
            code = f"d.xpath({xpath!r}).click()"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            d(**sel).click(timeout=timeout)
            code = f"d({', '.join(f'{k}={v!r}' for k, v in sel.items())}).click()"
        out(True, "Tapped element", code)
    except Exception as e:
        out(False, str(e))


@element_app.command(name="long-tap")
def long_tap(
    text: Optional[str] = _TEXT,
    resource_id: Optional[str] = _RESOURCE_ID,
    class_name: Optional[str] = _CLASS_NAME,
    xpath: Optional[str] = _XPATH,
    description: Optional[str] = _DESCRIPTION,
    duration: float = typer.Option(0.5, "--duration", "-D", help="Hold duration in seconds"),
    timeout: float = typer.Option(10.0, "--timeout", "-T", help="Timeout in seconds"),
) -> None:
    """Long-tap a matching element."""
    try:
        d = get_device()
        if xpath:
            el = d.xpath(xpath)
            el.wait(timeout=timeout)
            el.long_click()
            code = f"d.xpath({xpath!r}).long_click()"
        else:
            sel = _build_selector(text, resource_id, class_name, description)
            d(**sel).long_click(duration=duration, timeout=timeout)
            sel_str = ", ".join(f"{k}={v!r}" for k, v in sel.items())
            code = f"d({sel_str}).long_click(duration={duration})"
        out(True, "Long-tapped element", code)
    except Exception as e:
        out(False, str(e))
