from __future__ import annotations

import time

import typer

from u2 import get_device, out

watch_app = typer.Typer(no_args_is_help=True)


@watch_app.command()
def add(
    name: str = typer.Argument(..., help="Watcher name"),
    xpath: str = typer.Option(..., "--xpath", "-x", help="XPath expression to watch for"),
    action: str = typer.Option("click", "--action", "-a", help="Action: click, back, home"),
    timeout: float = typer.Option(30.0, "--timeout", "-t", help="Watch duration in seconds"),
) -> None:
    """Register a watcher and run it for a duration."""
    try:
        d = get_device()
        w = d.watcher(name).when(xpath)
        code_action: str
        if action == "click":
            w.click()
            code_action = ".click()"
        elif action in ("back", "home", "recent"):
            w.press(action)
            code_action = f".press({action!r})"
        else:
            out(False, f"Unknown action: {action!r}. Use: click, back, home, recent")
            return

        code = f"d.watcher({name!r}).when({xpath!r}){code_action}"
        d.watcher.start()
        time.sleep(timeout)
        d.watcher.stop()
        out(True, f"Watcher '{name}' ran for {timeout}s", code)
    except Exception as e:
        out(False, str(e))


@watch_app.command()
def remove(
    name: str = typer.Argument(..., help="Watcher name (use '__all__' to remove all)"),
) -> None:
    """Remove a named watcher (note: only meaningful within same process)."""
    try:
        d = get_device()
        if name == "__all__":
            d.watcher.remove()
            out(True, "Removed all watchers", "d.watcher.remove()")
        else:
            d.watcher.remove(name)
            out(True, f"Removed watcher: {name}", f"d.watcher.remove({name!r})")
    except Exception as e:
        out(False, str(e))


@watch_app.command(name="list")
def list_watchers() -> None:
    """List registered watchers (note: only meaningful within same process)."""
    try:
        d = get_device()
        running = d.watcher.running()
        out(True, f"Watcher running: {running}", "d.watcher.running()")
    except Exception as e:
        out(False, str(e))


@watch_app.command()
def run(
    xpath: str = typer.Option(..., "--xpath", "-x", help="XPath expression to watch for"),
    action: str = typer.Option("click", "--action", "-a", help="Action: click, back, home"),
) -> None:
    """Run watcher once and report if it triggered."""
    try:
        d = get_device()
        w = d.watcher("__run__").when(xpath)
        code_action: str
        if action == "click":
            w.click()
            code_action = ".click()"
        elif action in ("back", "home", "recent"):
            w.press(action)
            code_action = f".press({action!r})"
        else:
            out(False, f"Unknown action: {action!r}. Use: click, back, home, recent")
            return

        triggered = d.watcher.run()
        d.watcher.remove("__run__")
        code = f"d.watcher('__run__').when({xpath!r}){code_action}; d.watcher.run()"
        out(triggered, "Watcher triggered" if triggered else "Watcher did not trigger", code)
    except Exception as e:
        out(False, str(e))
