from __future__ import annotations

import dataclasses
import json
from typing import Optional

import typer

from u2 import get_device, out

device_app = typer.Typer(no_args_is_help=True)


@device_app.command()
def info() -> None:
    """Show device info."""
    try:
        d = get_device()
        result = d.device_info
        out(True, json.dumps(result), "d.device_info")
    except Exception as e:
        out(False, str(e))


@device_app.command()
def battery() -> None:
    """Show battery info."""
    try:
        d = get_device()
        b = d.adb_device.battery()
        result = dataclasses.asdict(b)
        out(True, json.dumps(result), "d.adb_device.battery()")
    except Exception as e:
        out(False, str(e))


@device_app.command(name="wlan-ip")
def wlan_ip() -> None:
    """Show WLAN IP address."""
    try:
        d = get_device()
        ip = d.wlan_ip
        out(True, ip or "", "d.wlan_ip")
    except Exception as e:
        out(False, str(e))


@device_app.command()
def shell(cmd: str = typer.Argument(..., help="Shell command to run")) -> None:
    """Run an adb shell command."""
    try:
        d = get_device()
        resp = d.shell(cmd)
        out(True, resp.output, f"d.shell({cmd!r})")
    except Exception as e:
        out(False, str(e))


@device_app.command()
def keyevent(key: str = typer.Argument(..., help="Key name or keycode")) -> None:
    """Send a key event (e.g. home, back, power)."""
    try:
        d = get_device()
        d.press(key)
        out(True, f"Sent key: {key}", f"d.press({key!r})")
    except Exception as e:
        out(False, str(e))


@device_app.command()
def push(
    src: str = typer.Argument(..., help="Local source path"),
    dst: str = typer.Argument(..., help="Remote destination path"),
) -> None:
    """Push a file to the device."""
    try:
        d = get_device()
        d.push(src, dst)
        out(True, f"Pushed {src} -> {dst}", f"d.push({src!r}, {dst!r})")
    except Exception as e:
        out(False, str(e))


@device_app.command()
def pull(
    src: str = typer.Argument(..., help="Remote source path"),
    dst: str = typer.Argument(..., help="Local destination path"),
) -> None:
    """Pull a file from the device."""
    try:
        d = get_device()
        d.pull(src, dst)
        out(True, f"Pulled {src} -> {dst}", f"d.pull({src!r}, {dst!r})")
    except Exception as e:
        out(False, str(e))


@device_app.command(name="screen-on")
def screen_on() -> None:
    """Turn the screen on."""
    try:
        d = get_device()
        d.screen_on()
        out(True, "Screen on", "d.screen_on()")
    except Exception as e:
        out(False, str(e))


@device_app.command(name="screen-off")
def screen_off() -> None:
    """Turn the screen off."""
    try:
        d = get_device()
        d.screen_off()
        out(True, "Screen off", "d.screen_off()")
    except Exception as e:
        out(False, str(e))


@device_app.command()
def orientation(
    value: Optional[str] = typer.Argument(
        None, help="Set orientation: natural, left, right, upsidedown (omit to get)"
    ),
) -> None:
    """Get or set screen orientation."""
    try:
        d = get_device()
        if value is None:
            current = d.orientation
            out(True, current, "d.orientation")
        else:
            d.orientation = value  # type: ignore[assignment]
            out(True, f"Orientation set to: {value}", f"d.orientation = {value!r}")
    except Exception as e:
        out(False, str(e))
