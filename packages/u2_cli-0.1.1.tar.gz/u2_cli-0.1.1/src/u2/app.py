from __future__ import annotations

import json
from typing import Optional

import typer

from u2 import get_device, out

app_app = typer.Typer(no_args_is_help=True)


@app_app.command()
def start(
    package: str = typer.Argument(..., help="Package name"),
    activity: Optional[str] = typer.Option(None, "--activity", "-a", help="Activity to launch"),
    wait: bool = typer.Option(False, "--wait", help="Wait for app to start"),  # noqa: FBT001, FBT002
    stop: bool = typer.Option(False, "--stop", help="Stop before starting"),  # noqa: FBT001, FBT002
) -> None:
    """Start an app by package name."""
    try:
        d = get_device()
        d.app_start(package, activity=activity, wait=wait, stop=stop)
        code = f"d.app_start({package!r}"
        if activity:
            code += f", activity={activity!r}"
        if wait:
            code += ", wait=True"
        if stop:
            code += ", stop=True"
        code += ")"
        out(True, f"Started: {package}", code)
    except Exception as e:
        out(False, str(e))


@app_app.command()
def stop(package: str = typer.Argument(..., help="Package name")) -> None:
    """Stop an app by package name."""
    try:
        d = get_device()
        d.app_stop(package)
        out(True, f"Stopped: {package}", f"d.app_stop({package!r})")
    except Exception as e:
        out(False, str(e))


@app_app.command()
def install(path: str = typer.Argument(..., help="APK path or URL")) -> None:
    """Install an APK from path or URL."""
    try:
        d = get_device()
        d.app_install(path)
        out(True, f"Installed: {path}", f"d.app_install({path!r})")
    except Exception as e:
        out(False, str(e))


@app_app.command()
def uninstall(package: str = typer.Argument(..., help="Package name")) -> None:
    """Uninstall an app by package name."""
    try:
        d = get_device()
        success = d.app_uninstall(package)
        msg = f"Uninstalled: {package}" if success else f"Failed to uninstall: {package}"
        out(success, msg, f"d.app_uninstall({package!r})")
    except Exception as e:
        out(False, str(e))


@app_app.command()
def clear(package: str = typer.Argument(..., help="Package name")) -> None:
    """Clear app data."""
    try:
        d = get_device()
        d.app_clear(package)
        out(True, f"Cleared: {package}", f"d.app_clear({package!r})")
    except Exception as e:
        out(False, str(e))


@app_app.command(name="list")
def list_apps(
    filter: Optional[str] = typer.Option(  # noqa: A002
        None,
        "-f",
        "--filter",
        help="Filter: -3 (third-party), -s (system), -d (disabled), -e (enabled)",
    ),
) -> None:
    """List installed apps."""
    try:
        d = get_device()
        packages = d.app_list(filter) if filter else d.app_list()
        code = f"d.app_list({filter!r})" if filter else "d.app_list()"
        out(True, json.dumps(packages), code)
    except Exception as e:
        out(False, str(e))


@app_app.command()
def current() -> None:
    """Show the current foreground app."""
    try:
        d = get_device()
        info = d.app_current()
        out(True, json.dumps(info), "d.app_current()")
    except Exception as e:
        out(False, str(e))


@app_app.command(name="wait-activity")
def wait_activity(
    activity: str = typer.Argument(..., help="Activity name to wait for"),
    timeout: float = typer.Option(10.0, "--timeout", "-t", help="Timeout in seconds"),
) -> None:
    """Wait for a specific activity to appear."""
    try:
        d = get_device()
        found = d.wait_activity(activity, timeout=timeout)
        code = f"d.wait_activity({activity!r}, timeout={timeout})"
        out(found, f"Activity {'found' if found else 'not found'}: {activity}", code)
    except Exception as e:
        out(False, str(e))
