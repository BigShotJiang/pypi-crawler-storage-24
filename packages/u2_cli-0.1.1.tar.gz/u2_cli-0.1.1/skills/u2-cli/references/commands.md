# u2-cli Command Reference

## Global Options

Applies to every command:

```
u2 [-s SERIAL] <sub-app> <command> [args]
```

| Flag | Short | Type | Description |
|------|-------|------|-------------|
| `--serial` | `-s` | `str` | Android device serial (required when multiple devices connected) |

**Output format (all commands):**
```json
{"success": bool, "output": str, "code": str}
```
- `success` — whether the operation succeeded
- `output` — result data or error message
- `code` — the uiautomator2 Python expression that was executed

---

## `device` sub-app

Physical device state and low-level operations.

| Command | Args | Description |
|---------|------|-------------|
| `device info` | — | Returns `d.device_info` dict |
| `device battery` | — | Returns battery info dict |
| `device wlan-ip` | — | Returns WLAN IP string |
| `device shell <cmd>` | `cmd: str` | Run adb shell command, returns stdout |
| `device keyevent <key>` | `key: str` | Send key event (e.g. `home`, `back`, `power`) |
| `device push <src> <dst>` | `src: str`, `dst: str` | Push local file to device |
| `device pull <src> <dst>` | `src: str`, `dst: str` | Pull file from device |
| `device screen-on` | — | Turn screen on |
| `device screen-off` | — | Turn screen off |
| `device orientation [value]` | `value?: natural\|left\|right\|upsidedown` | Get or set orientation |

---

## `app` sub-app

App lifecycle management.

| Command | Args / Flags | Description |
|---------|-------------|-------------|
| `app start <package>` | `--activity/-a str`, `--wait bool`, `--stop bool` | Launch app, optionally stopping first and waiting |
| `app stop <package>` | `package: str` | Stop app by package name |
| `app install <path>` | `path: str` | Install APK from path or URL |
| `app uninstall <package>` | `package: str` | Uninstall app |
| `app clear <package>` | `package: str` | Clear app data |
| `app list` | `--filter/-f str` (`-3` third-party, `-s` system, `-d` disabled, `-e` enabled) | List installed packages |
| `app current` | — | Returns current foreground app (package, activity, pid) |
| `app wait-activity <activity>` | `--timeout/-t float` (default: 10.0) | Wait for activity to appear; `success` reflects result |

---

## `screen` sub-app

Visual state capture.

| Command | Args / Flags | Description |
|---------|-------------|-------------|
| `screen screenshot [path]` | `path?: str` | Save PNG to file (JSON output), or omit to write raw PNG bytes to stdout |
| `screen dump` | `--compressed bool`, `--pretty bool`, `--simplify/-s bool` | Dump UI hierarchy as XML or simplified JSON |
| `screen size` | — | Returns screen size as `WxH` string (e.g. `1080x2340`) |
| `screen brightness [value]` | `value?: int (0–255)` | Get or set screen brightness |

**`screen dump --simplify`** returns compact JSON tree with pruned/collapsed nodes:
- Keys: `type`, `text`, `desc`, `id`, `bounds`, plus boolean flags (`clickable`, `scrollable`, etc.) only when `true`, plus `children`
- Class names are shortened (e.g. `TextView` → `text`)

---

## `interact` sub-app

Coordinate-based input actions.

| Command | Args / Flags | Description |
|---------|-------------|-------------|
| `interact tap <x> <y>` | `x: int`, `y: int` | Tap at coordinates |
| `interact long-tap <x> <y>` | `x: int`, `y: int`, `--duration/-d float` (default: 0.5) | Long press at coordinates |
| `interact swipe <fx> <fy> <tx> <ty>` | from/to coords, `--duration/-d float` (default: 0.5) | Swipe between two points |
| `interact drag <sx> <sy> <ex> <ey>` | start/end coords, `--duration/-d float` (default: 0.5) | Drag between two points |
| `interact type <text>` | `text: str` | Type text into focused element (clipboard paste, supports Unicode/Chinese) |
| `interact clear` | — | Clear text in focused element |

---

## `element` sub-app

Selector-based element interaction. At least one selector required per command.

**Shared selector options:**

| Flag | Short | Description |
|------|-------|-------------|
| `--text` | `-t` | Element text |
| `--resource-id` | `-r` | Resource ID |
| `--class-name` | `-c` | Class name |
| `--xpath` | `-x` | XPath expression (uses `d.xpath(...)` path) |
| `--description` | `-d` | Content description |

Multiple non-xpath selectors can be combined. XPath takes a separate code path.

| Command | Extra Flags | Description |
|---------|------------|-------------|
| `element find` | `--timeout/-T float` (default: 0.0) | Find elements, returns JSON array of element info dicts |
| `element wait` | `--timeout/-T float` (default: 10.0) | Wait for element; `success` reflects result |
| `element exists` | — | `output` is `"true"` or `"false"` |
| `element get-text` | `--timeout/-T float` (default: 10.0) | Returns element's text in `output` |
| `element set-text <value>` | `value: str`, `--timeout/-T float` (default: 10.0) | Set element text |
| `element tap` | `--timeout/-T float` (default: 10.0) | Tap matched element |
| `element long-tap` | `--duration/-D float` (default: 0.5), `--timeout/-T float` (default: 10.0) | Long-tap matched element |

---

## `watch` sub-app

UI watchers that auto-trigger actions when a matching element appears.

| Command | Args / Flags | Description |
|---------|-------------|-------------|
| `watch add <name>` | `--xpath/-x str` (required), `--action/-a str` (default: `click`), `--timeout/-t float` (default: 30.0) | Register watcher, start it, block for timeout, then stop. Actions: `click`, `back`, `home`, `recent` |
| `watch remove <name>` | `name: str` (use `__all__` to remove all) | Remove watcher (in-memory, same process only) |
| `watch list` | — | Returns whether watcher loop is running |
| `watch run` | `--xpath/-x str` (required), `--action/-a str` (default: `click`) | One-shot: register `__run__` watcher, fire once, remove it. `success` reflects whether it triggered |
