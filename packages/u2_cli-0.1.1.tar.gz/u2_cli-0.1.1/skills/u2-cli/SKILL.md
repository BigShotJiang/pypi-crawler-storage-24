---
name: u2-cli
description: Use this skill when the user wants to control an Android device using the u2-cli tool. Triggers when: controlling an Android device via CLI, automating Android UI interactions, using uiautomator2 from the command line, finding/tapping/swiping UI elements on Android, taking screenshots or dumping UI hierarchy, managing Android apps, or running adb-based device operations through u2.
---

# u2-cli Skill

You are helping the user control an Android device using `u2-cli`, a CLI tool wrapping uiautomator2.

The complete command reference is in [references/commands.md](references/commands.md). Always consult it for exact syntax, flags, and defaults.

Install:

```bash
uv pip install u2-cli
```

## Core Workflow

### 1. Orient yourself

Before interacting with the device, understand its current state:

```bash
u2 screen dump --simplify          # Get UI hierarchy as compact JSON
u2 screen screenshot /tmp/sc.png   # Take a screenshot for visual context
u2 app current                     # See what app is in foreground
```

Use `screen dump --simplify` as your primary tool for understanding what's on screen — it produces a compact JSON tree with pruned noise, shortened class names, and only the relevant attributes.

### 2. Find elements before acting on them

Verify elements exist before tapping or typing:

```bash
u2 element exists --text "Login"
u2 element find --xpath "//android.widget.Button"
u2 element wait --resource-id com.example:id/submit --timeout 5
```

### 3. Prefer `element` commands over coordinate `interact` commands

Use selector-based `element tap/long-tap` when you can identify elements by text, resource-id, or xpath. Fall back to `interact tap <x> <y>` only when no selector is available.

### 4. Parse output correctly

All commands return JSON:
```json
{"success": true, "output": "...", "code": "d(text='Login').click()"}
```

Check `success` before proceeding. The `output` field contains the actual data (parse as JSON if it's a list/dict). The `code` field shows what uiautomator2 expression ran.

---

## Common Tasks

### Navigate the UI

```bash
u2 device keyevent back           # Press Back
u2 device keyevent home           # Press Home
u2 interact swipe 540 1500 540 500 --duration 0.3   # Scroll up
u2 interact swipe 540 500 540 1500 --duration 0.3   # Scroll down
```

### Tap an element

```bash
# By text
u2 element tap --text "Sign In"

# By resource ID
u2 element tap --resource-id com.example:id/btn_login

# By XPath
u2 element tap --xpath "//android.widget.Button[@text='OK']"

# By coordinates (fallback)
u2 interact tap 540 960
```

### Type text

```bash
# Tap the input field first, then type
u2 element tap --resource-id com.example:id/email_input
u2 interact type "user@example.com"

# Or set text directly on an element
u2 element set-text "user@example.com" --resource-id com.example:id/email_input
```

### Launch an app

```bash
# Start fresh (stop + start)
u2 app start com.example.app --stop --wait

# Wait for specific activity to load
u2 app wait-activity .MainActivity --timeout 15
```

### Handle popups automatically

```bash
# Block for 30s, auto-click any "Allow" button that appears
u2 watch add allow-popup --xpath "//android.widget.Button[@text='Allow']" --timeout 30

# One-shot: trigger immediately if a dialog is currently visible
u2 watch run --xpath "//android.widget.Button[@text='OK']"
```

### Capture screen state

```bash
# Screenshot to file
u2 screen screenshot /tmp/screen.png

# Screenshot to stdout (pipe to viewer/tool)
u2 screen screenshot | display

# UI hierarchy for AI analysis
u2 screen dump --simplify
```

---

## Strategy for Autonomous Tasks

When given a multi-step task (e.g., "fill in this form", "open settings and enable X"):

1. **Dump the screen** with `screen dump --simplify` to understand current state
2. **Plan the steps** based on what elements are visible
3. **Act step by step**, checking success after each command
4. **Re-dump** after navigation or significant UI changes
5. **Use `element wait`** before acting when a screen transition is expected

If an element isn't found, try:
- `element find` with a broader selector to explore what's on screen
- `screen dump --simplify` to re-check the current UI state
- Scrolling with `interact swipe` and then retrying

---

## Device Selection

When multiple devices are connected, prefix all commands with `-s SERIAL`:

```bash
u2 -s emulator-5554 screen dump --simplify
u2 -s R3CN10XXXXX element tap --text "Login"
```

Get available devices with:
```bash
adb devices
```
