# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

`u2-cli` is a CLI tool wrapping [uiautomator2](https://github.com/openatx/uiautomator2) to control Android devices, designed for use by AI agents.

## Commands

```bash
# Install deps and activate env
uv sync

# Run CLI during development (no install needed)
uv run src/u2/__init__.py <cmd>

# Run after installing as a package
uv run u2 <cmd>

# Lint
uv run ruff check .
uv run ruff format .

# Build for PyPI
uv build
```

## Architecture

All CLI commands output JSON: `{"success": bool, "output": str, "code": str}` where `code` is the uiautomator2 Python expression that was executed, example: `d(text='Hello').click()`, `d.shell('ls')`.

The CLI is built with [Typer](https://typer.tiangolo.com/) and organized into sub-apps:

```
src/u2/
├── __init__.py    # Root app, State dataclass, global --serial/-s flag, main()
├── device.py      # device sub-app: info, battery, wlan-ip, shell, keyevent, push, pull, screen-on, screen-off, orientation
├── app.py         # app sub-app: start, stop, install, uninstall, clear, list, current, wait-activity
├── screen.py      # screen sub-app: screenshot, dump, size, brightness
├── interact.py    # interact sub-app: tap, long-tap, swipe, drag, type, clear
├── element.py     # element sub-app: find, wait, exists, get-text, set-text, tap, long-tap (selector-based)
└── watch.py       # watch sub-app: add, remove, list, run (uiautomator2 Watcher)
```

**Sub-app responsibilities:**

- `device` — physical device state and low-level operations: device info, battery, IP, adb shell, key events (`home`, `back`, `power`, etc.), file push/pull, screen on/off, rotation
- `app` — app lifecycle: install/uninstall APK, start/stop by package, clear data, list installed apps, get current foreground app, wait for a target activity
- `screen` — visual state: screenshot (PNG to stdout or file), XML hierarchy dump, screen size, brightness
- `interact` — coordinate-based input: tap, long-tap, swipe (from/to coords), drag, send text to focused element, clear focused text
- `element` — selector-based element interaction: find elements by `text`, `resourceId`, `className`, `xpath`, `description`; check existence; get/set text; tap or long-tap matched elements
- `watch` — register/run UI watchers that auto-click or trigger actions when a matching element appears

**Global state:** The `--serial`/`-s` flag (Android device serial) is stored in a module-level `State` dataclass in `__init__.py`. Sub-command modules access it via `from u2 import state`.

**Entry point:** `u2 = "u2:main"` in `pyproject.toml`.

## Linting

Ruff is configured with `FBT` rules enabled — boolean positional arguments in function signatures trigger warnings. Typer-style boolean CLI options require `# noqa: FBT001/FBT002` suppressions.
