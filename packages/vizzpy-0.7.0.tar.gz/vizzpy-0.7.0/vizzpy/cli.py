"""
vizzpy CLI entry point.

Usage:
  vizzpy --serve   [--host HOST] [--port PORT] [--project PROJECT_PATH]
  vizzpy --headless --project PROJECT_PATH [--format svg|mermaid] [--level function|module|both] [--output OUTPUT]
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path


def cli() -> None:
    parser = argparse.ArgumentParser(
        prog="vizzpy",
        description="Python call tree visualizer",
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--serve", action="store_true", help="Start the web server")
    mode.add_argument("--headless", action="store_true", help="Render call graph without a web server (requires --project)")

    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (serve mode)")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind (serve mode)")
    parser.add_argument("--project", default=None, metavar="PROJECT_PATH",
                        help="Pre-load a local project directory in serve mode (skips browser upload)")
    parser.add_argument("--output", default=None, help="Output file path (headless mode); defaults to call_tree.svg or call_tree.md")
    parser.add_argument("--format", choices=["svg", "mermaid"], default="mermaid", help="Output format for headless mode (default: mermaid)")
    parser.add_argument(
        "--level",
        choices=["function", "module", "both"],
        default="function",
        help="Granularity of the call graph: function (default), module, or both",
    )

    args = parser.parse_args()

    if args.serve:
        _run_server(args.host, args.port, Path(args.project) if args.project else None)
    else:
        if not args.project:
            parser.error("--headless requires --project PROJECT_PATH")
        ext = ".md" if args.format == "mermaid" else ".svg"
        if args.level == "both":
            if args.output:
                base = Path(args.output)
                func_out = base.parent / (base.stem + "_functions" + base.suffix)
                mod_out  = base.parent / (base.stem + "_modules"   + base.suffix)
            else:
                func_out = Path(f"call_tree_functions{ext}")
                mod_out  = Path(f"call_tree_modules{ext}")
            _run_headless(Path(args.project), func_out, args.format, "function")
            _run_headless(Path(args.project), mod_out,  args.format, "module")
        else:
            output_path = Path(args.output) if args.output else Path(f"call_tree{ext}")
            _run_headless(Path(args.project), output_path, args.format, args.level)


def _run_server(host: str, port: int, project_path: "Path | None" = None) -> None:
    try:
        import uvicorn  # noqa: F401
        from vizzpy.server import app, preload_project
    except ImportError as exc:
        sys.exit(
            f"Server dependencies missing ({exc}).\n"
            "Install with: pip install 'vizzpy[serve]'"
        )
    if project_path is not None:
        if not project_path.exists():
            sys.exit(f"Project path does not exist: {project_path}")
        print(f"Pre-loading project: {project_path} ...")
        preload_project(project_path)
        print("Done. Starting server...")
    uvicorn.run(app, host=host, port=port)


def _run_headless(project_path: Path, output_path: Path, fmt: str, level: str) -> None:
    if not project_path.exists():
        sys.exit(f"Project path does not exist: {project_path}")

    print(f"Analyzing {project_path} ...")
    if fmt == "mermaid":
        from vizzpy.render import render_mermaid
        render_mermaid(project_path, output_path, level=level)
        print(f"Mermaid markdown written to {output_path}")
    else:
        from vizzpy.render import render_svg
        try:
            render_svg(project_path, output_path, level=level)
        except ImportError as exc:
            sys.exit(
                f"SVG rendering requires the graphviz package ({exc}).\n"
                "Install with: pip install 'vizzpy[svg]'\n"
                "Also ensure the Graphviz system package is installed "
                "(brew install graphviz / apt install graphviz)."
            )
        print(f"SVG written to {output_path}")


if __name__ == "__main__":
    cli()
