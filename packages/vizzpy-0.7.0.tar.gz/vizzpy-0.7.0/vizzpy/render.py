"""
Headless SVG rendering via the graphviz Python package.

The graphviz package is a thin wrapper around the `dot` binary (Graphviz).
Install Graphviz system package first:
  macOS:  brew install graphviz
  Ubuntu: apt install graphviz
"""
from __future__ import annotations
from pathlib import Path

from .graph import aggregate_to_modules, build_graph


def render_mermaid(project_root: Path, output_path: Path, level: str = "function") -> None:
    """
    Analyze *project_root* and write the call graph as a Mermaid markdown
    flowchart to *output_path*.

    *level* controls granularity: ``"function"`` (default) shows individual
    functions; ``"module"`` collapses each module to a single node.
    """
    graph_data = build_graph(project_root)
    if level == "module":
        graph_data = aggregate_to_modules(graph_data)
    md = _to_mermaid(graph_data, level=level)
    output_path.write_text(md, encoding="utf-8")


def _to_mermaid(graph_data: dict, level: str = "function") -> str:
    node_by_id = {n["id"]: n for n in graph_data["nodes"]}
    external_ids = {n["id"] for n in graph_data["nodes"] if n.get("external")}

    lines = ["```mermaid", "flowchart LR"]

    if level == "module":
        # Flat nodes — no subgraph nesting at module level
        for n in graph_data["nodes"]:
            nid = _mermaid_id(n["id"])
            lines.append(f"    {nid}(\"{n['label']}\")")
    else:
        # Split modules into project vs external for subgraph grouping
        project_modules: dict[str, list[str]] = {}
        external_modules: dict[str, list[str]] = {}
        for module_name, node_ids in graph_data["modules"].items():
            if all(nid in external_ids for nid in node_ids):
                external_modules[module_name] = node_ids
            else:
                project_modules[module_name] = node_ids

        # Project subgraphs
        for module_name, node_ids in project_modules.items():
            safe_module = module_name.replace(".", "_").replace("-", "_")
            lines.append(f"    subgraph {safe_module}[\"{module_name}\"]")
            for nid in node_ids:
                n = node_by_id[nid]
                lines.append(f"        {_mermaid_id(nid)}[\"{n['label']}\"]")
            lines.append("    end")

        # External subgraphs grouped under a single outer subgraph
        if external_modules:
            lines.append('    subgraph __ext__["external libraries"]')
            for module_name, node_ids in external_modules.items():
                safe_module = module_name.replace(".", "_").replace("-", "_")
                lines.append(f"        subgraph {safe_module}[\"{module_name}\"]")
                for nid in node_ids:
                    n = node_by_id[nid]
                    lines.append(f"            {_mermaid_id(nid)}[\"{n['label']}\"]")
                lines.append("        end")
            lines.append("    end")

    # Edges
    for edge in graph_data["edges"]:
        src = _mermaid_id(edge["source"])
        tgt = _mermaid_id(edge["target"])
        if edge["count"] > 1:
            lines.append(f"    {src} -->|\"{edge['count']}x\"| {tgt}")
        else:
            lines.append(f"    {src} --> {tgt}")

    # Style external nodes
    if external_ids:
        lines.append(
            "    classDef external"
            " fill:#f0f0f0,stroke:#aaaaaa,color:#888888,stroke-dasharray:4"
        )
        lines.append(
            "    class " + ",".join(_mermaid_id(nid) for nid in sorted(external_ids))
            + " external"
        )

    lines.append("```")
    return "\n".join(lines) + "\n"


def _mermaid_id(qname: str) -> str:
    """Convert a qualified name to a safe Mermaid node ID."""
    return qname.replace(".", "__").replace("-", "_") + "_"


def render_svg(project_root: Path, output_path: Path, level: str = "function") -> None:
    """
    Analyze *project_root* and write the call graph as an SVG to *output_path*.

    *level* controls granularity: ``"function"`` (default) shows individual
    functions; ``"module"`` collapses each module to a single node.
    """
    import graphviz  # type: ignore  # requires system graphviz + pip package

    graph_data = build_graph(project_root)
    if level == "module":
        graph_data = aggregate_to_modules(graph_data)
    dot = _to_dot(graph_data, level=level)
    svg_source = dot.pipe(format="svg").decode("utf-8")
    output_path.write_text(svg_source, encoding="utf-8")


def _to_dot(graph_data: dict, level: str = "function") -> "graphviz.Digraph":
    import graphviz  # type: ignore

    node_by_id = {n["id"]: n for n in graph_data["nodes"]}

    dot = graphviz.Digraph(
        graph_attr={
            "rankdir": "LR",
            "fontname": "Helvetica",
            "splines": "ortho",
            "nodesep": "0.5",
            "ranksep": "1.0",
        },
        node_attr={
            "shape": "box",
            "style": "rounded,filled",
            "fillcolor": "#dbe9f4",
            "fontname": "Helvetica",
            "fontsize": "11",
        },
        edge_attr={
            "fontname": "Helvetica",
            "fontsize": "9",
        },
    )

    if level == "module":
        # Flat nodes — no cluster subgraphs at module level
        for n in graph_data["nodes"]:
            if n.get("external"):
                dot.node(
                    n["id"],
                    label=n["label"],
                    fillcolor="#f0f0f0",
                    style="rounded,filled,dashed",
                    fontcolor="#888888",
                    color="#aaaaaa",
                )
            else:
                dot.node(n["id"], label=n["label"])
    else:
        # Add module subgraphs (clusters) at function level
        for module_name, node_ids in graph_data["modules"].items():
            all_external = all(node_by_id[nid].get("external") for nid in node_ids)
            cluster_attrs: dict[str, str] = {
                "label": module_name,
                "style": "rounded,dashed,filled" if all_external else "rounded,filled",
                "color": "#cccccc" if all_external else "#aaaaaa",
                "fillcolor": "#f5f5f5" if all_external else "#fffde7",
                "fontsize": "10",
                "fontcolor": "#999999" if all_external else "#444444",
            }
            with dot.subgraph(name=f"cluster_{module_name}") as sub:
                sub.attr(**cluster_attrs)
                for nid in node_ids:
                    n = node_by_id[nid]
                    if n.get("external"):
                        sub.node(
                            nid,
                            label=n["label"],
                            fillcolor="#f0f0f0",
                            style="rounded,filled,dashed",
                            fontcolor="#888888",
                            color="#aaaaaa",
                        )
                    else:
                        sub.node(nid, label=n["label"])

    # Add edges
    for edge in graph_data["edges"]:
        label = str(edge["count"]) if edge["count"] > 1 else ""
        dot.edge(edge["source"], edge["target"], label=label)

    return dot
