# VizzPy

Interactive Python call tree visualizer. Upload a Python project and explore its function call graph in the browser. Here are some usecases:
* Bake the `headless` mode in your CI pipeline for adding auto-generated call tree in your repo (auto-documentation helping in understaanding the functionality and its implementation)
* Use in `interactive` mode to explore and understand the implementation of a particular functionality. This can also be helpful ahead of code reviews.

## Features

- **Interactive web UI** — zoom, pan, drag nodes, collapse subtrees
- **Two granularity levels** — toggle between function-level and module-level call graph in the UI or via `--level`
- **Cross-module resolution** — follows imports across files to draw edges between modules
- **Dark mode** — toggle with one click
- **Headless mode** — render a static SVG or Mermaid flowchart from the command line (SVG requires Graphviz)
- **Archive upload** — drag-and-drop a `.zip`, `.tar.gz`, `.egg`, or `.whl` in the web UI; pass a folder path in headless mode

## Installation

Install only what you need:

| Goal | Command |
|---|---|
| Mermaid headless (CI-friendly, zero extra deps) | `pip install vizzpy` |
| SVG headless | `pip install 'vizzpy[svg]'` |
| Interactive web UI | `pip install 'vizzpy[serve]'` |
| Everything | `pip install 'vizzpy[all]'` |

SVG rendering additionally requires the [Graphviz](https://graphviz.org/download/) system package:

```bash
# macOS
brew install graphviz

# Debian/Ubuntu
apt install graphviz
```

## Usage

### Web UI (recommended)

```bash
vizzpy --serve
# open http://127.0.0.1:8000

# or pre-load a local project — renders immediately on page open
vizzpy --serve --project ./myproject
```

Upload a `.zip`, `.tar.gz`, `.egg`, or `.whl` of your Python project, then click **Analyze**.

- **Scroll / pinch** to zoom
- **Drag background** to pan
- **Drag nodes** to rearrange
- **Double-click a node** to collapse/expand its call subtree (function view)
- **Hover** a node to see its docstring
- **Function view / Module view** button in the toolbar — toggle between individual function nodes and a rolled-up module-level graph

### Headless rendering

```bash
# Mermaid markdown — no extra dependencies (default format)
vizzpy --headless --project ./myproject                          # → call_tree.md  (function level)
vizzpy --headless --project ./myproject --level module           # → call_tree.md  (module level)
vizzpy --headless --project ./myproject --level both             # → call_tree_functions.md + call_tree_modules.md

# SVG — requires Graphviz
vizzpy --headless --project ./myproject --format svg
vizzpy --headless --project ./myproject --format svg --level module
vizzpy --headless --project ./myproject --format svg --level both

# Custom output path
vizzpy --headless --project ./myproject --format mermaid --output graph.md
```

### Options

```
vizzpy --serve   [--host HOST] [--port PORT] [--project PROJECT_PATH]
vizzpy --headless --project PROJECT_PATH [--format svg|mermaid] [--level function|module|both] [--output OUTPUT]
```

## How it works

VizPy uses Python's `ast` module to do a two-pass analysis of your source files:

1. **Scope pass** — collects every top-level function and class method with its qualified name (`module.ClassName.method`)
2. **Edge pass** — walks each file again, resolves `self.method()`, `cls.method()`, imported names, and direct calls to project-internal functions

Results are rendered in the browser with [dagre-d3](https://github.com/dagrejs/dagre-d3) (vendored, works offline). Calls to explicitly imported library functions (e.g. `pandas.read_csv`) are shown as external leaf nodes — their internals are not traced.

## Development

```bash
git clone https://github.com/atulsaurav/vizzpy
cd vizzpy
pip install -e ".[dev]"

# run tests
pytest

# run with coverage
pytest --cov=vizzpy --cov-report=term-missing
```

## License

MIT
