"""Setup script for pysq package.

Note: Most configuration is in pyproject.toml.
This file is kept for compatibility with older pip versions.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
