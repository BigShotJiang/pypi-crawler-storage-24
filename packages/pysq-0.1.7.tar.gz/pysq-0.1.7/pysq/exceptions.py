"""Exception classes for the SQ API."""

from typing import Optional


class SQAPIError(Exception):
    """Base exception for all SQ API errors."""
    
    def __init__(self, message: str, error_code: Optional[int] = None) -> None:
        super().__init__(message)
        self.error_code = error_code
        self.message = message
    
    def __repr__(self) -> str:
        if self.error_code is not None:
            return f"{self.__class__.__name__}({self.message!r}, error_code={self.error_code})"
        return f"{self.__class__.__name__}({self.message!r})"


class SQAPITaskError(SQAPIError):
    """Exception raised for task-related errors."""
    pass


class SQAPIRefinementError(SQAPIError):
    """Exception raised for refinement-related errors."""
    pass


class SQAPIConfigError(SQAPIError):
    """Exception raised for configuration-related errors."""
    pass

