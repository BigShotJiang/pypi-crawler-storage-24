"""pysq - Python SDK for Siroquant API V5."""

from .api import SQAPI, TaskContext
from .config import SQAPIConfig
from .constants import SQErrorCode, SaveTaskFlags, ReportResultsFlags, ERROR_MESSAGES, cmaxphases, LIB_NAME
from .exceptions import (
    SQAPIError,
    SQAPITaskError,
    SQAPIRefinementError,
    SQAPIConfigError
)
from .dataclasses import (
    UnitCell,
    UVW,
    TaskInfo,
    PatternInfo,
    RefinementParams,
    RefinementResult,
    PhaseResult,
    SearchMatchResult,
    TraceInfo,
    CrystalliteResult,
    AmorphousResult
)
from .utils import (
    validate_task_file,
    validate_pattern_file,
    export_results_to_csv,
    format_error_message
)

# Version: single source from pyproject.toml via importlib.metadata
try:
    from importlib.metadata import version as _get_version, PackageNotFoundError
    __version__ = _get_version("pysq")
except (PackageNotFoundError, ImportError):
    __version__ = "0.1.0"  # Fallback for development installs

__all__ = [
    # Main API
    "SQAPI",
    "TaskContext",
    "SQAPIConfig",
    # Constants
    "SQErrorCode",
    "SaveTaskFlags",
    "ReportResultsFlags",
    "ERROR_MESSAGES",
    "cmaxphases",
    "LIB_NAME",
    # Exceptions
    "SQAPIError",
    "SQAPITaskError",
    "SQAPIRefinementError",
    "SQAPIConfigError",
    # Dataclasses
    "UnitCell",
    "UVW",
    "TaskInfo",
    "PatternInfo",
    "RefinementParams",
    "RefinementResult",
    "PhaseResult",
    "SearchMatchResult",
    "TraceInfo",
    "CrystalliteResult",
    "AmorphousResult",
    # Utilities
    "validate_task_file",
    "validate_pattern_file",
    "export_results_to_csv",
    "format_error_message",
    # Version
    "__version__",
]
