import pandas as pd
import re
from google.cloud import bigquery
import numpy as np
import google.auth.impersonated_credentials


creds, pid = google.auth.default()

project_id = 'sista-data-stream'
target_principal = "data-stream-bq@sista-data-stream.iam.gserviceaccount.com"
target_scopes = [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/drive"
]

def initialize_bq_client():
    """
    Inicializuje BigQuery klienta. 
    Zkouší impersonaci servisního účtu, pokud selže, použije defaultní credentials uživatele.
    """
    try:
        creds, pid = google.auth.default(scopes=target_scopes)
        
        #  pokus o impersonaci (vyžaduje roli 'Service Account Token Creator')
        tcreds = google.auth.impersonated_credentials.Credentials(
            source_credentials=creds,
            target_principal=target_principal,
            target_scopes=target_scopes
        )
        client = bigquery.Client(credentials=tcreds, project=project_id)
        client.list_datasets(max_results=1)  # testovaci volani
        return client

    except Exception as e:
        # pokud nemaji prava
        print(f"Impersonace selhala ({e}). Pokračuji s výchozími právy uživatele.")
        creds, _ = google.auth.default(scopes=target_scopes)
        return bigquery.Client(credentials=creds, project=project_id)

client = initialize_bq_client()


class Projects:
    """ Třída, která načítá a reprezentuje tabulku projektů.
    Funguje pouze v rámci Google Colab prostředí.

    :param projects: DataFrame načtených dat ze zdroje pravdy nebo z nově vytvořené (vyfiltrované) instance
    :type projects: DataFrame
    :param summary_cfp: DataFrame s agregovanými údaji na úrovni veřejných soutěží
    :type summary_cfp: DataFrame
    :param summary_prog: DataFrame s agregovanými údaji na úrovni programů
    :type summary_prog: DataFrame
    """

    def __init__(self, df: object = None):
        """ Konstruktor, který načte data do DataFrame a vytvoří agregovanou tabulku.
        """
        if df is None:
            self.projects = self._get_projects()
        else:
            self.projects = df
        self.summary_cfp = self.create_summary() 
        self.summary_prog = self.create_summary('prog') 


    def _get_projects(self) -> pd.DataFrame:
        """ Načte data o projektech z databáze zdroje pravdy v Bigquery.
           Lze použít pouze v rámci Google Colab prostředí.


        :return: DataFrame načtených dat
        """

        query = """
        SELECT *
        FROM `sista-data-stream.ssot.projects`
        """
        df = client.query(query).to_dataframe()
        return df
    

    def _check_missing_items(self, provided_items: tuple, existing_items: list, item_name: str): 
        """Ověří, zda se všechny zadané položky nacházejí v existujícím seznamu. 

        Pokud jsou nalezeny chybějící položky, vyvolá ValueError s chybovou zprávou. 

        :param provided_items: Tuple položek zadaných pro filtrování. 
        :param existing_items: Seznam všech unikátních položek nacházejících se v datové sadě. 
        :param item_name: Popisný název položky, který se použije v chabové hlášce. 
        
        :raises ValueError: Pokud alespoň jedna zadaná položka neexistuje v datové sadě. 
        """

        missing_items = [item for item in provided_items if item not in existing_items]
        if missing_items: 
            raise ValueError(f'{item_name} {missing_items} neexistuje/neexistují.')


    def create_summary(self, level: str = 'cfp') -> pd.DataFrame:
        """ Vytvoří agregovaný souhrn buď na úrovni veřejných soutěží (defaultní) nebo na úrovni programů.


        :param level: určuje, na jaké úrovni se provede agregace
                    * 'cfp' (defaultní) - na úrovni veřejných soutěží
                    * 'prog' - na úrovni programů
        :return: agregovaný DataFrame, který obsahuje:
                    * Počet podaných projektů
                    * Počet podpořených projektů
                    * Náklady podpořených projektů
                    * Podpora podpořených projektů
        """
        
        if level not in ['cfp', 'prog']:
            raise ValueError('Neexistující forma agregace.')

        temp_df = self.projects.copy()

        temp_df['Podpořené_bool'] = temp_df['project_state'].isin(['400', '500', '600'])
        submitted = temp_df.groupby(['programme_code', 'cfp_code']).agg(
            {'project_code': 'count', 'costs_total': 'sum', 'resources_funding': 'sum'}).reset_index()
            # {'kod_projektu': 'count', 'naklady_celkem': 'sum', 'podpora_celkem': 'sum'}).reset_index()
        funded = temp_df[temp_df['Podpořené_bool']].groupby(['programme_code', 'cfp_code']).agg(
            {'project_code': 'count', 'costs_total': 'sum', 'resources_funding': 'sum'}).reset_index()

        summary_df = pd.merge(submitted[['programme_code', 'cfp_code', 'project_code']], funded, how='inner',
                              on=['programme_code', 'cfp_code'])
        summary_df.columns = ['Program', 'VS', 'Podané', 'Podpořené', 'Náklady', 'Podpora']


        if level == 'prog':
            summary_df = summary_df.groupby('Program').agg('sum', numeric_only=True).reset_index()

        return summary_df


    def select_programme(self, *args: str) -> 'Projects':
        """ Vyfiltruje dataframe projektů tak, aby obsahovala pouze projekty vybraných programů.


        :param args: kódy programů (dvoumístné - například 'FW'), které se mají vyfiltrovat
        :return: nová instance třídy Projects s vyfiltrovanými údaji
        :raise: ValueError
        """

        existing_programmes = self.projects['programme_code'].unique()
        self._check_missing_items(args, existing_programmes, 'Programy')
        
        programme_list = [prog for prog in args]
        select_df = self.projects[self.projects['programme_code'].isin(programme_list)].reset_index(drop=True)
        return Projects(select_df)


    def select_cfp(self, *args: str) -> 'Projects':
        """ Vyfiltruje dataframe projektů tak, aby obsahovala pouze projekty vybraných veřejných soutěží.


       :param args: kódy veřejných soutěží (čtyřmístné - například 'FW01'), které se mají vyfiltrovat
       :return: nová instance třídy Projects s vyfiltrovanými údaji
       :raise: ValueError
       """

        existing_cfp = self.projects['cfp_code'].unique()
        self._check_missing_items(args, existing_cfp, 'Veřejné soutěže')

        cfp_list = [cfp for cfp in args]
        select_df = self.projects[self.projects['cfp_code'].isin(cfp_list)].reset_index(drop=True)
        return Projects(select_df)
    
    #? DONE, tested, rename to `select_financed()` 
    def select_funded(self) -> 'Projects':
        """ Vyfiltruje dataframe projektů tak, aby obsahoval pouze podpořené projekty.


        :return: nová instance třídy Projects s vyfiltrovanými údaji
        """
        financed_states = ['400','500', '600']
        select_df = self.projects[self.projects['project_state'].isin(financed_states)].reset_index(drop=True)
        return Projects(select_df)

    #? DONE, tested
    def select_cep(self, level: int, *args: str) -> 'Projects':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze projekty vybraných oborů nebo skupin oborů klasifikace CEP

        :param level: úroveň - 1 = skupiny oborů CEP, 2 = obory CEP
        :param args: kódy skupin oborů CEP (1 písmeno) nebo oborů CEP (2 písmena), které se mají vyfiltrovat
              úroveň 1 - skupiny oborů:
                               * A	= A - Společenské vědy
                               * B	= B - Fyzika a matematika
                               * C	= C - Chemie
                               * D	= D - Vědy o zemi
                               * E	= E - Biovědy
                               * F	= F - Lékařské vědy
                               * G	= G - Zemědělství
                               * I	= I - Informatika
                               * J	= J - Průmysl
                               * K	= K - Vojenství a politika
              úroveň 2 - obory CEP dostupná zde https://docs.google.com/spreadsheets/d/1VknMmHAjKspJmyYlCeJCVEOn01xFGETbTNKi4dMvqf8/edit#gid=0

        :return: nová instance třídy Projects s vyfiltrovanými údaji
        :raise: ValueError
        """
        
        cep_columns = {1: 'CEP1', 2: 'CEP2', 3: 'CEP3'}
        if level not in cep_columns: 
            raise ValueError("Lze zvolit pouze úroveň 1, 2 nebo 3.")

        target_col = cep_columns[level]

        existing_codes = self.projects[target_col].unique()
        self._check_missing_items(args, existing_codes, f"Obory v {target_col}")

        select_df = self.projects[self.projects[target_col].isin(args)].reset_index(drop=True)
        return Projects(select_df)
    

    def select_ford(self, level, *args: str) -> 'Projects':
        """ Vyfiltruje tabulku projektů podle klasifikace FORD (úroveň 1, 2 nebo 3).

        :param level: úroveň - 1 (oblast), 2 (obor), 3 (detailní obor)
        :param args: kódy k vyfiltrování (např. '1', '101', '10101')
        :return: nová instance třídy Projects s vyfiltrovanými údaji
        :raise: ValueError
        """

        ford_cols = {1: 'FORD1', 2: 'FORD2', 3: 'FORD3'}

        if level not in ford_cols: 
            raise ValueError("Lze zvolit pouze úroveň 1, 2 nebo 3.")

        target_col = ford_cols[level]

        existing_codes = self.projects[target_col].unique() 
        self._check_missing_items(args, existing_codes, f"Obory v {target_col}")

        select_df = self.projects[self.projects[target_col].isin(args)].reset_index(drop=True)
        return Projects(select_df)


class Applicants: 
    """ Třída, která načítá a reprezentuje tabulku organizací.

    Funguje pouze v rámci Google Colab prostředí.

    :param applicants: DataFrame načtených dat ze zdroje nebo z nově vytvořené (vyfiltrované) instance
    :type applicants: DataFrame
    :param summary_cfp: DataFrame s agregovanými údaji na úrovni veřejných soutěží
    :type summary_cfp: DataFrame
    :param summary_prog: DataFrame s agregovanými údaji na úrovni programů
    :type summary_prog: DataFrame
    :param summary_ico: DataFrame s agregovanými údaji na úrovni organizací
    :type summary_ico: DataFrame
    """

    def __init__(self, df: object = None):
        """ Kontstruktor, který načte data do DataFrame, očistí finanční hodnoty a vytvoří agregovanou tabulku.

        :param df: dataframe instance Project
        """
        if df is None:
            self.applicants = self._get_applicants()
            self._data_preparing()
        else:
            self.applicants = df

        self.summary_cfp = self.create_summary()
        self.summary_prog = self.create_summary('prog')
        self.summary_ico = self.create_summary('ico')


    def _get_applicants(self) -> pd.DataFrame: 
        """ Načte data o organizacích ze "zdroje pravdy" z databázového úložiště BigQuery.
        Lze použít pouze v rámci Google Colab prostředí.

        :return: DataFrame načtených dat ze zdroje
        """

        query = """
        SELECT *
        FROM `sista-data-stream.ssot.applicants`
        """
        df = client.query(query).to_dataframe()
        return df


    def _data_preparing(self):
        """ Interní funkce, která doplní potřebná data, které nejsou ve zdroji pravdy v tabulce organizací.
        """

        self.applicants["kod_program"] = self.applicants["project_code"].str[:2]

        self.applicants["kod_vs"] = np.where(
            self.applicants["kod_program"] == 'TG',  # podminka 
            self.applicants["project_code"].str[:6],  # pokud ano 
            self.applicants["project_code"].str[:4]  # pokud ne
        )
        self.applicants["typeorg_kod"] = self.applicants["type"] # uz tam davame do nazvu jen ty dvoupismenne kody 
        # map_roles = {"Příjemce": "HP", "Hlavní příjemce": "HP", "Zahraniční partner": "ZU", "Další účastník": "DU"}
        map_roles = {"main": "main", "foreign-partner": "foreign", "additional": "additional"}
        self.applicants["role_kod"] = self.applicants["role"].map(map_roles) # role v novem: mame foreign-partner, main, additional

        map_kraj = {
            "Hlavní město Praha": "PH", 
            "Středočeský kraj": "ST", 
            "Ústecký kraj": "US", 
            "Liberecký kraj": "LI",
            "Pardubický kraj": "PA", 
            "Královéhradecký kraj": "KR", 
            "Karlovarský kraj": "KA",
            "Plzeňský kraj": "PL",
            "Jihočeský kraj": "JC", 
            "Kraj Vysočina": "VY", 
            "Jihomoravský kraj": "JM", 
            "Zlínský kraj": "ZL",
            "Olomoucký kraj": "OL", 
            "Moravskoslezský kraj": "MO", 
            # "ZAH": "ZP"
        }
        self.applicants["kraj_kod"] = self.applicants["region"].map(map_kraj).fillna("ZP")   # fillna protoze if zahranicni tak `null`

        query = """
        SELECT *
        FROM `sista-data-stream.ssot.projects`
        """
        projekty_df = client.query(query).to_dataframe()
        self.applicants = pd.merge(self.applicants,
                                      projekty_df[["project_code", "project_state", "project_substate"]], on='project_code',
                                      how="left")
        

    def _check_missing_items(self, provided_items: tuple, existing_items: list, item_name: str): 
        """Ověří, zda se všechny zadané položky nacházejí v existujícím seznamu. 

        Pokud jsou nalezeny chybějící položky, vyvolá ValueError s chybovou zprávou. 

        :param provided_items: Tuple položek zadaných pro filtrování. 
        :param existing_items: Seznam všech unikátních položek nacházejících se v datové sadě. 
        :param item_name: Popisný název položky, který se použije v chabové hlášce. 
        
        :raises ValueError: Pokud alespoň jedna zadaná položka neexistuje v datové sadě. 
        """

        missing_items = [item for item in provided_items if item not in existing_items]
        if missing_items: 
            raise ValueError(f'{item_name} {missing_items} neexistuje/neexistují.')


    def create_summary(self, level: str = 'cfp') -> pd.DataFrame:
        """ Vytvoří agregovaný souhrn buď na úrovni veřejných soutěží (defaultní),na úrovni programů
        nebo organizací.
    
        :param level: určuje, na jaké úrovni se provede agregace
                      * 'cfp' (defaultní) - na úrovni veřejných soutěží
                      * 'prog' - na úrovni programů
                      # 'ico' - na úrovni jednotlivých organizací
        :return: agregovaný DataFrame, který obsahuje:
                * Počet žádostí o podporu
                * Počet účastí v podpořených projektech
                * Náklady organizace/organizací v podpořených projektech
                * Podpora organizace/organizací v podpořených projektech
        """

        if level not in ['cfp', 'prog', 'ico']:
            raise ValueError('Neexistující forma agregace.')

        temp_df = self.applicants.copy()
        temp_df['Podpořené_bool'] = temp_df['project_state'].isin(['400', '500', '600'])

        if level == 'ico':
            submitted = temp_df.groupby('id_number').agg({'project_code': 'nunique'}).reset_index()
            funded = temp_df[temp_df['Podpořené_bool']].groupby('id_number').agg(
                {'project_code': 'nunique', 'costs_total': 'sum', 'resources_funding': 'sum'}).reset_index()

            summary_df = pd.merge(submitted, funded, how='left', on='id_number',
                                  suffixes=('_podane', '_podporene'))
            summary_df.rename(columns={'project_code_podane': 'Podané', 'project_code_podporene': 'Podpořené'},
                              inplace=True)
            summary_df.fillna(0, inplace=True)
            summary_df['Podpořené'] = summary_df['Podpořené'].astype(int)
            summary_df.rename(columns={'costs_total' : 'Náklady', 'resources_funding' : 'Podpora'}, inplace=True)
            summary_df = summary_df.sort_values('Podpora', ascending=False).reset_index(drop=True)

            return summary_df

        else:
            submitted = temp_df.groupby(['kod_program', 'kod_vs']).agg(
                {'id_number': 'count', 'costs_total': 'sum', 'resources_funding': 'sum'}).reset_index()
            funded = temp_df[temp_df['Podpořené_bool']].groupby(['kod_program', 'kod_vs']).agg(
                {'id_number': 'count', 'costs_total': 'sum', 'resources_funding': 'sum'}).reset_index()

            summary_df = pd.merge(submitted[['kod_program', 'kod_vs', 'id_number']], funded, how='inner',
                                  on=['kod_program', 'kod_vs'])
            summary_df.columns = ['Program', 'VS', 'Podané', 'Podpořené', 'Náklady', 'Podpora']

            if level == 'prog':
                summary_df = summary_df.groupby('Program').agg('sum', numeric_only=True).reset_index()

            return summary_df


    def select_ico(self, *args: str) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze konkrétní vybrané organizace na základě zadaného IČ.

        :param args: IČ organizace/organizací, které se mají vyfiltrovat
        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        :raise: ValueError
        """

        existing_ico = self.applicants['id_number'].unique()
        self._check_missing_items(args, existing_ico, 'Organizace')

        ico_list = [ico for ico in args]
        select_df = self.applicants[self.applicants['id_number'].isin(ico_list)].reset_index(drop=True)
        return Applicants(select_df)


    def select_programme(self, *args: str) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze organizace z vybraných programů.

        :param args: kódy programů, které se mají vyfiltrovat
        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        :raise: ValueError
        """

        existing_programmes = self.applicants['kod_program'].unique()
        self._check_missing_items(args, existing_programmes, 'Programy')

        programme_list = [prog for prog in args]
        select_df = self.applicants[self.applicants['kod_program'].isin(programme_list)].reset_index(drop=True) 
        return Applicants(select_df)  # todo maybe another class Programms?


    def select_cfp(self, *args: str) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze organizace z vybraných veřejných soutěží.

        :param args: kódy veřejných soutěží, které se mají vyfiltrovat
        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        :raise: ValueError
        """

        existing_cfp = self.applicants['kod_vs'].unique()
        self._check_missing_items(args, existing_cfp, 'Veřejné soutěže')

        cfp_list = [cfp for cfp in args]
        select_df = self.applicants[self.applicants['kod_vs'].isin(cfp_list)].reset_index(drop=True)
        return Applicants(select_df)


    def select_funded(self) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze organizace v podpořených projektech.

        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        """
        
        financed_states = ['400', '500', '600']

        select_df = self.applicants[self.applicants['project_state'].isin(financed_states)].reset_index(drop=True)
        return Applicants(select_df)


    def select_type(self, *args: str) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze organizace podle vybraného typu organizace.

        :param args: kódy typu organizací, které se mají vyfiltrovat
                    * UP = mikro podnik
                    * MP = malý podnik
                    * SP = střední podnik
                    * VP = velký podnik
                    * VO = výzkumná organizace
                    * DPO = další právnické osoby veřejného i soukromého práva
                    * O = ostatní uchazeči povolení ZD
        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        :raise: ValueError
        """
        existing_orgtype = self.applicants['typeorg_kod'].unique()
        self._check_missing_items(args, existing_orgtype, 'Typy organizace')

        orgtype_list = [orgtype for orgtype in args]
        select_df = self.applicants[self.applicants['typeorg_kod'].isin(orgtype_list)].reset_index(drop=True)
        return Applicants(select_df)


    def select_role(self, *args: str) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze organizace podle vybraného typu role.

        :param args: kódy rolí, které se mají vyfiltrovat
                    * main = hlavní příjemce
                    * additional = další účastník
                    * foreign = zahraniční účastník
        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        :raise: ValueError
        """

        existing_roles = self.applicants['role_kod'].unique()
        self._check_missing_items(args, existing_roles, 'Role')

        roles_list = [role for role in args]
        select_df = self.applicants[self.applicants['role_kod'].isin(roles_list)].reset_index(drop=True)
        return Applicants(select_df)


    def select_region(self, *args: str) -> 'Applicants':
        """ Vyfiltruje tabulku tak, aby obsahovala pouze organiazce podle vybraného kraje.

        :param args: kódy krajů, které se mají vyfiltrovat
                    * PH = Hlavní město Praha
                    * ST = Středočeský kraj
                    * US = Ústecký kraj
                    * LI = Liberecký kraj
                    * PA = Pardubický kraj
                    * KR = Královéhradecký kraj
                    * KA = Karlovarský kraj
                    * PL = Plzeňský kraj
                    * JC = Jihočeský kraj
                    * VY = Kraj Vysočina
                    * JM = Jihomoravský kraj
                    * ZL = Zlínský kraj
                    * OL = Olomoucký kraj
                    * MO = Moravskoslezský kraj
                    * ZP = ZAH
        :return: nová instance třídy Applicants s vyfiltrovanými údaji
        :raise: ValueError
        """
        
        existing_kraje = self.applicants['kraj_kod'].unique()
        self._check_missing_items(args, existing_kraje, 'Kraje')

        kraje_list = [kraj for kraj in args]
        select_df = self.applicants[self.applicants['kraj_kod'].isin(kraje_list)].reset_index(drop=True)
        return Applicants(select_df)



def projects_finance() -> pd.DataFrame:
    """ Načte data o financích projektů z databáze zdroje pravdy v Bigquery.
    Finance jsou v rozdělení po jednotlivých letech.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
           SELECT *
           FROM `sista-data-stream.ssot.projects_finances` 
           """
    df = client.query(query).to_dataframe()
    return df

#? DONE, , 
def applicants_finance() -> pd.DataFrame:
    """ Načte data o financích organizací z databáze zdroje pravdy v Bigquery.
    Finance jsou v rozdělení po jednotlivých letech.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
           SELECT *
           FROM `sista-data-stream.ssot.applicants_finances` 
           """
    df = client.query(query).to_dataframe()
    return df

#? DONE, , 
def results() -> pd.DataFrame:
    """ Načte data o výsledcích projektů z databáze zdroje pravdy v Bigquery.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
            SELECT *
            FROM `sista-data-stream.ssot.results`
            """
    df = client.query(query).to_dataframe()
    return df

#? DONE, , 
def cfp() -> pd.DataFrame:
    """ Načte data o veřejných soutěží z databáze zdroje pravdy v Bigquery.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
            SELECT *
            FROM `sista-data-stream.ssot.cfp` 
            """
    df = client.query(query).to_dataframe()
    return df

#? DONE, , 
def programmes() -> pd.DataFrame:
    """ Načte data o programech z databáze zdroje pravdy v Bigquery.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
            SELECT *
            FROM `sista-data-stream.ssot.programmes` 
            """
    df = client.query(query).to_dataframe()
    return df

#?, DONE, , solved: internal_data_ISTA (ask Vojta, protoze nic jako `export_projekty` neni nikde)
def projects_raw_data() -> pd.DataFrame:
    """ Načte kompletní zdrojová data o projektech z databáze zdroje pravdy v Bigquery.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
            SELECT *
            FROM `sista-data-stream.internal_data_ISTA.raw_projects`
            """
    df = client.query(query).to_dataframe()
    return df

#? DONE, , same 
def applicants_raw_data() -> pd.DataFrame:
    """ Načte kompletní zdrojová data o organizacích z databáze zdroje pravdy v Bigquery.
    Lze použít pouze v rámci Google Colab prostředí.

    :return: DataFrame načtených dat ze zdroje
    """

    query = """
            SELECT *
            FROM `sista-data-stream.internal_data_ISTA.raw_applicants`
            """
    df = client.query(query).to_dataframe()
    return df

class Administrovane_projekty:
    """ Třída, která vypočítává počet administrovaných projektů v určitému časovému úseku.

    Lze použít pouze v rámci Google Colab prostředí.

    :param df_hodnoceno_final: DataFrame počtu hodnocených projektů ve zvoleném časovém úseku, agregace podle programu nebo VS
    :type df_hodnoceno_final: DataFrame
    :param df_realizace_final: DataFrame počtu realizovaných projektů ve zvoleném časovém úseku, agregace podle programu nebo VS
    :type df_realizace_final: DataFrame
    :param df_implementace_final: DataFrame počtu implementovaných projektů ve zvoleném časovém úseku, agregace podle programu nebo VS
    :type df_implementace_final: DataFrame
    :param df_administrovan_vse_final: DataFrame počtu administrovaných projektů ve zvoleném časovém úseku, agregace podle programu nebo VS
    :type df_administrovan_vse_final: DataFrame
    :param df_administrovan_bez_impl_final: DataFrame počtu administrovaných projektů (bez implementovaných) ve zvoleném časovém úseku, agregace podle programu nebo VS
    :type df_administrovan_bez_impl_final: DataFrame
    :param df_pouze_implementace_final: DataFrame počtu pouze implementovaných projektů (vyloučení projektů, které byly ve stejném období v realizaci nebo hodnocené) ve zvoleném časovém úseku, agregace podle programu nebo VS
    :type df_pouze_implementace_final: DataFrame

    """

    pd.set_option("mode.chained_assignment", None)

    def __init__(self, agg_col: str, start_period: str, end_period: str):
        """Konstruktor, který vrací potřebné výstupy ve formě dataframe
        """

        self.df = self.intersects(start_period, end_period)
        self.create_output(self.df, agg_col)

    @staticmethod
    def intersects(start_period, end_period):
        """připraví data ze ssot načte projekty a přidá termíny ze souboru VS, upraví formáty dat
           vyhodnotí, zda byl projekt hodnocen, realizován nebo implementován
           v případě administrovaných nebo pouze implementovaných projektů započítá každý projekt pouze jednou

           Lze použít pouze v rámci Google Colab prostředí.

        :param start_period: začátek intervalu pro výpočet ve formátu 'YYYY-MM-DD'
        :param end_period: konec intervalu pro výpočet ve formátu 'YYYY-MM-DD'
        :return: dataframe s novým sloupcem/sloupci s označením fáze ve kterém se projekt během zadaného intervalu nacházel
        """

        vs_data = cfp()

        proj_obj = Projects()
        df = proj_obj.projects.copy()

        df = pd.merge(df, vs_data[['cfp_code', 'results_announcement_date', 'full_submission_end']], on="cfp_code", how="left")

        date_cols = ["zacatek_reseni", "konec_reseni", "ukonceni_soutezni_lhuty", "termin_vyhlaseni_vysledku"]
        date_cols = [
            "implementation_start", 
            "implementation_end", 
            "full_submission_end", 
            "results_announcement_date"
        ]
        for col in date_cols:
            df[col]=pd.to_datetime(df[col], errors="coerce")

        if start_period is None or end_period is None:
            raise ValueError("Musíte zadat oba parametry 'start_period' a 'end_period', pokud vybíráte typ 'period'.")
        try:
            report_start = pd.to_datetime(start_period)
            report_end = pd.to_datetime(end_period)

            is_funded = df['project_state'].isin(['400', '500', '600'])

            # projekty v hodnocení
            df['hodnocen'] = (df["full_submission_end"] <= report_end) & (df["results_announcement_date"] >= report_start)
            # projekty v řešení
            df['realizace'] = (df["implementation_start"] <= report_end) & (df["implementation_end"] >= report_start) & is_funded
            # projekty v období využitelnosti (implementace)
            df['implementace'] = (df["implementation_end"] < report_end) & ((df["implementation_end"] + pd.DateOffset(years=4)) >= report_start) & is_funded

            df['administrovan_vse'] = (df["hodnocen"] == True) | (df["realizace"] == True) | (df["implementace"] == True)
            df['administrovan_bez_impl'] = (df["hodnocen"] == True) | (df["realizace"] == True)
            df['pouze_implementace'] = (df["hodnocen"] == False) & (df["realizace"] == False) & (df["implementace"] == True)

        except ValueError:
            raise ValueError("Parametry 'start_period' a 'end_period' musí být ve správném formátu 'YYYY-MM-DD'.")

        if report_end < report_start:
            raise ValueError("'end_period' nemůže být dříve než 'start_period'.")

        return df


    def create_output(self, df:pd.DataFrame, agg_col: str):
        """vytoří agregovaný souhrn počtu projektů v zadané fázi

        :param df: určuje fázi, pro kterou chci provést výpočet
                * hodnoceno - počet hodnocených projektů
                * realizace - počet realizovancých projektů
                * implementace - počet implementovaných projektů
                * administrovan_vse - počet administrovaných projektů
                * administrovan_bez_impl - počet administroavných projektů bez implementovaných
                * pouze_implementace - počet implementovaných projektů s vyloučením projektů které byly realizovány nebo hodnoceny
        :param agg_col: určuje agregaci výpočtu
                * kod_programu - na úrovni programů
                * kod_VS - na úrovni VS
        :return: dataframe s počty projektů v zadané fázi
        """

        agg_enable = ['programme_code', 'cfp_code']
        if agg_col not in agg_enable:
            raise ValueError(f"Chyba: Sloupec '{agg_col}' není povolený pro agregaci! Zadejte jeden z těchto sloupců: {agg_enable}")

        cols_to_process = [
            'hodnocen',
            'realizace',
            'implementace',
            'administrovan_vse',
            'administrovan_bez_impl',
            'pouze_implementace'
        ]

        results = {}

        for col in cols_to_process:
            df_grouped = df.groupby(agg_col)[col].sum().reset_index()
            total_count = df_grouped[col].sum()
            df_final = pd.concat([df_grouped, pd.DataFrame({agg_col: ['Součet'], col: [total_count]})], ignore_index=True)
            results[col] = df_final

        self.hodnoceno = results['hodnocen']
        self.realizace = results['realizace']
        self.implementace = results['implementace']
        self.administrovan_vse = results['administrovan_vse']
        self.administrovan_bez_impl = results['administrovan_bez_impl']
        self.pouze_implementace = results['pouze_implementace']


def _get_VOPO_kod(typ, list_item):
    """Pomocná funkce pro získání typu organizace. Respektive se jedná o agregaci původní typologie do nové"""

    if typ in list_item:
        return 'PO'
    elif typ == 'VO':
        return 'VO'
    else:
        return 'O'

#? DONE, , 
def podporene_VOPO(from_date, to_date, typ_agg, show_projects=False):
    """Funkce, která spočítá počet podpořených organizací (unikátně podle IČO) po programech v zadaném roce.
    Organizace jsou dělené na VO - výzkumné organizace a PO - podniky, příp. O - ostatní.
    Používá se do tabulek ve VZ a zprávě pro KR.

    Použití v Google prostředí.

    :param from_date: datum začátku intervalu, za který chceme podpořené organizace spočítat, ve formátu 'YYYY-MM-DD'
    :param to_date: datum konce intervalu, za který chceme podpořené organizace spočítat, ve formátu 'YYYY-MM-DD'
    :param typ_agg: typ agregace, 'celkem' počítá účasti nebo 'unikatni' počítá unikátní IČA
    :param show_projects: volitelný parametr, pokud je True, vrací seznam projektů za dané období 
    :return: dataframe s počtem podpořených organizací po porogramech rozděleno na VO, PO a ostatní
    """
    
    try:
      from_date = pd.to_datetime(from_date)
      to_date = pd.to_datetime(to_date)
    except ValueError:
      raise ValueError("Parametry 'from_date' a 'to_date' musí být ve správném formátu 'YYYY-MM-DD'.")

    if from_date > to_date:
      raise ValueError("Začátek intervalu (from_date) nesmí být později než konec intervalu (to_date).")

    org_podp = Applicants().select_funded().applicants
    projects_podp=Projects().select_funded().projects

    org_podp_terminy=pd.merge(org_podp, projects_podp, left_on='project_code', right_on='project_code')

    PO_list = ['MP', 'SP', 'VP', 'UP']
    org_podp_terminy['VOPO_kod'] = org_podp_terminy['typeorg_kod'].apply(lambda typ: _get_VOPO_kod(typ, PO_list)) #? `typeorg` by mel byt zdefinovany z `_data_preparing()`

    filtered_df = org_podp_terminy[(org_podp_terminy['implementation_end'] >= from_date) & (org_podp_terminy['implementation_start'] <= to_date)]

    if typ_agg == 'celkem':
        org_prog_typ = filtered_df.groupby(['programme_code', 'VOPO_kod']).agg({'id_number': 'count'}).reset_index()
    elif typ_agg == 'unikatni':
        org_prog_typ = filtered_df.groupby(['programme_code', 'VOPO_kod']).agg({'id_number': 'nunique'}).reset_index()
    else:
        raise ValueError(f'Neznámý typ agregace {typ_agg}, platné typy jsou \'celkem\' a \'unikatni\'')

    org_prog_typ_pivot = org_prog_typ.pivot(
        index='programme_code', columns='VOPO_kod', values="id_number"
    )

    org_prog_typ_pivot = org_prog_typ_pivot.fillna(0)
    org_prog_typ_pivot = org_prog_typ_pivot.astype(int)
    org_prog_typ_pivot = org_prog_typ_pivot[['VO', 'PO','O']]

    period_str = f"{from_date.strftime('%Y-%m-%d')} - {to_date.strftime('%Y-%m-%d')}"
    new_names = {'PO': f"Počet podpořených podniků v období {period_str}",'VO': f"Počet podpořených VO v období {period_str}: ",'O': f"Počet podpořených ostatních v období {period_str}: "}

    org_prog_typ_pivot.rename(columns=new_names, inplace=True)
    org_prog_typ_pivot.loc['Celkem'] = org_prog_typ_pivot.sum(numeric_only=True)

    if show_projects:
        ### kdybychom to chteli tridit dle programu, coz ale Michal tvrdi, ze spis nechceme: ###
        # projects_list = filtered_df.groupby('kod_program')['kod_projektu'].apply(lambda x: x.unique().tolist()).reset_index()
        # projects_list.rename(columns={'kod_projektu': 'list_of_projects'}, inplace=True)
        # print(projects_list)
        # projects_list.to_excel('projects_list.xlsx', index=False)
        # print(f"\nSeznam projektu ke kazdemu programu byl ulozen do souboru 'projects_list.xlsx'.\n")
        # unique_projects_df = filtered_df[['kod_projektu']].drop_duplicates().reset_index(drop=True)
        unique_projects_df = filtered_df[['project_code']].drop_duplicates().reset_index(drop=True)
        # unique_projects_df.rename(columns={'kod_projektu': 'Seznam unikátních projektů'}, inplace=True)
        unique_projects_df.rename(columns={'project_code': 'Seznam unikátních projektů'}, inplace=True)
        print(unique_projects_df)
        unique_projects_df.to_excel('unique_projects.xlsx', index=False)
        print(f"\nSeznam unikátních projektů byl uložen do souboru 'unique_projects.xlsx'.\n")
        
    return org_prog_typ_pivot



#! project_state = faze_projektu 
#! project_substate = stav_projektu 
#! funded: ['400', '500', '600']

