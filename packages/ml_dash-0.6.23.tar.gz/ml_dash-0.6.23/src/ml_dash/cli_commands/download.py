"""
CLI command for downloading experiments from remote server to local storage.
"""

import argparse
import json
import os
import tempfile
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.table import Table

from ..client import RemoteClient
from ..config import Config
from ..storage import LocalStorage

console = Console()


@dataclass
class ExperimentInfo:
  """Information about an experiment to download."""

  project: str
  experiment: str
  experiment_id: str
  owner: Optional[str] = None
  has_logs: bool = False
  has_params: bool = False
  metric_names: List[str] = field(default_factory=list)
  file_count: int = 0
  estimated_size: int = 0
  log_count: int = 0
  status: str = "RUNNING"
  prefix: Optional[str] = None
  description: Optional[str] = None
  tags: List[str] = field(default_factory=list)


@dataclass
class DownloadState:
  """State for resuming interrupted downloads."""

  remote_url: str
  local_path: str
  completed_experiments: List[str] = field(default_factory=list)
  failed_experiments: List[str] = field(default_factory=list)
  in_progress_experiment: Optional[str] = None
  in_progress_items: Dict[str, Any] = field(default_factory=dict)
  timestamp: Optional[str] = None

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)

  @classmethod
  def from_dict(cls, data: Dict[str, Any]) -> "DownloadState":
    return cls(**data)

  def save(self, path: Path):
    path.write_text(json.dumps(self.to_dict(), indent=2))

  @classmethod
  def load(cls, path: Path) -> Optional["DownloadState"]:
    if not path.exists():
      return None
    try:
      data = json.loads(path.read_text())
      return cls.from_dict(data)
    except Exception as e:
      console.print(f"[yellow]Warning: Could not load state file: {e}[/yellow]")
      return None


@dataclass
class DownloadResult:
  """Result of downloading an experiment."""

  experiment: str
  success: bool = False
  downloaded: Dict[str, int] = field(default_factory=dict)
  failed: Dict[str, List[str]] = field(default_factory=dict)
  errors: List[str] = field(default_factory=list)
  bytes_downloaded: int = 0
  skipped: bool = False


def _format_bytes(bytes_count: int) -> str:
  for unit in ["B", "KB", "MB", "GB"]:
    if bytes_count < 1024:
      return f"{bytes_count:.2f} {unit}"
    bytes_count /= 1024
  return f"{bytes_count:.2f} TB"


def _format_bytes_per_sec(bytes_per_sec: float) -> str:
  return f"{_format_bytes(bytes_per_sec)}/s"


def _experiment_from_graphql(graphql_data: Dict[str, Any]) -> ExperimentInfo:
  log_metadata = graphql_data.get("logMetadata") or {}

  metadata = graphql_data.get("metadata") or {}
  prefix = metadata.get("prefix")

  project_data = graphql_data.get("project", {})
  namespace_data = project_data.get("namespace", {})
  owner = namespace_data.get("slug")

  return ExperimentInfo(
    project=project_data.get("slug", "unknown"),
    experiment=graphql_data["name"],
    experiment_id=graphql_data["id"],
    owner=owner,
    has_logs=log_metadata.get("totalLogs", 0) > 0,
    has_params=graphql_data.get("parameters") is not None,
    metric_names=[m["name"] for m in graphql_data.get("metrics", []) or []],
    file_count=len(graphql_data.get("files", []) or []),
    log_count=int(log_metadata.get("totalLogs", 0)),
    status=graphql_data.get("status", "RUNNING"),
    prefix=prefix,
    description=graphql_data.get("description"),
    tags=graphql_data.get("tags", []) or [],
  )


def discover_experiments(
  remote_client: RemoteClient,
  project_filter: Optional[str] = None,
  experiment_filter: Optional[str] = None,
) -> List[ExperimentInfo]:
  """Discover experiments on remote server using GraphQL."""
  if project_filter and experiment_filter:
    exp_data = remote_client.get_experiment_graphql(project_filter, experiment_filter)
    if exp_data:
      return [_experiment_from_graphql(exp_data)]
    return []

  has_wildcards = project_filter and any(c in project_filter for c in ['*', '?', '['])

  if has_wildcards:
    if '/' not in project_filter:
      # "tut*" -> "*/tut*/*"
      search_pattern = f"*/{project_filter}/*"
    else:
      search_pattern = project_filter

    result = remote_client.search_experiments_graphql(search_pattern)
    return [_experiment_from_graphql(exp) for exp in result["experiments"]]

  if project_filter:
    result = remote_client.list_experiments_graphql(project_filter)
    return [_experiment_from_graphql(exp) for exp in result["experiments"]]

  projects = remote_client.list_projects_graphql()["projects"]
  all_experiments = []
  for project in projects:
    result = remote_client.list_experiments_graphql(project["slug"])
    all_experiments.extend([_experiment_from_graphql(exp) for exp in result["experiments"]])

  return all_experiments


class ExperimentDownloader:
  """Downloads a single experiment from remote server."""

  def __init__(
    self,
    local_storage: LocalStorage,
    remote_client: RemoteClient,
    batch_size: int = 1000,
    skip_logs: bool = False,
    skip_metrics: bool = False,
    skip_files: bool = False,
    skip_params: bool = False,
    verbose: bool = False,
    max_concurrent_metrics: int = 5,
    max_concurrent_files: int = 3,
  ):
    self.local = local_storage
    self.remote = remote_client
    self.batch_size = batch_size
    self.skip_logs = skip_logs
    self.skip_metrics = skip_metrics
    self.skip_files = skip_files
    self.skip_params = skip_params
    self.verbose = verbose
    self.max_concurrent_metrics = max_concurrent_metrics
    self.max_concurrent_files = max_concurrent_files
    self._lock = threading.Lock()
    self._thread_local = threading.local()

  def _get_remote_client(self) -> RemoteClient:
    """Get thread-local remote client for safe concurrent access."""
    if not hasattr(self._thread_local, "client"):
      self._thread_local.client = RemoteClient(
        base_url=self.remote.base_url,
        namespace=self.remote.namespace,
        api_key=self.remote.api_key
      )
    return self._thread_local.client

  def download_experiment(self, exp_info: ExperimentInfo) -> DownloadResult:
    result = DownloadResult(experiment=f"{exp_info.project}/{exp_info.experiment}")

    try:
      if self.verbose:
        console.print(
          f"  [dim]Downloading {exp_info.project}/{exp_info.experiment}[/dim]"
        )

      self._download_metadata(exp_info, result)

      if not self.skip_params and exp_info.has_params:
        self._download_parameters(exp_info, result)

      if not self.skip_logs and exp_info.has_logs:
        self._download_logs(exp_info, result)

      if not self.skip_metrics and exp_info.metric_names:
        self._download_metrics(exp_info, result)

      if not self.skip_files and exp_info.file_count > 0:
        self._download_files(exp_info, result)

      result.success = True

    except Exception as e:
      result.success = False
      result.errors.append(str(e))
      if self.verbose:
        console.print(f"  [red]Error: {e}[/red]")

    return result

  def _download_metadata(self, exp_info: ExperimentInfo, result: DownloadResult):
    if exp_info.prefix:
      full_prefix = exp_info.prefix
    else:
      if exp_info.owner:
        full_prefix = f"{exp_info.owner}/{exp_info.project}/{exp_info.experiment}"
      else:
        full_prefix = f"{exp_info.project}/{exp_info.experiment}"

    owner = exp_info.owner if exp_info.owner else full_prefix.split('/')[0]

    self.local.create_experiment(
      owner=owner,
      project=exp_info.project,
      prefix=full_prefix,
      description=exp_info.description,
      tags=exp_info.tags,
      bindrs=[],
      metadata=None,
    )

  def _download_parameters(self, exp_info: ExperimentInfo, result: DownloadResult):
    try:
      params_data = self.remote.get_parameters(exp_info.experiment_id)
      if params_data:
        self.local.write_parameters(
          project=exp_info.project, experiment=exp_info.experiment, data=params_data
        )
        result.downloaded["parameters"] = 1
        result.bytes_downloaded += len(json.dumps(params_data))
    except Exception as e:
      result.failed.setdefault("parameters", []).append(str(e))

  def _download_logs(self, exp_info: ExperimentInfo, result: DownloadResult):
    """Download logs with pagination."""
    try:
      offset = 0
      total_downloaded = 0

      while True:
        logs_data = self.remote.query_logs(
          experiment_id=exp_info.experiment_id,
          limit=self.batch_size,
          offset=offset,
          order_by="sequenceNumber",
          order="asc",
        )

        logs = logs_data.get("logs", [])
        if not logs:
          break

        for log in logs:
          self.local.write_log(
            project=exp_info.project,
            experiment=exp_info.experiment,
            message=log["message"],
            level=log["level"],
            timestamp=log["timestamp"],
            metadata=log.get("metadata"),
          )

        total_downloaded += len(logs)
        result.bytes_downloaded += sum(len(json.dumps(log)) for log in logs)

        if not logs_data.get("hasMore", False):
          break

        offset += len(logs)

      result.downloaded["logs"] = total_downloaded

    except Exception as e:
      result.failed.setdefault("logs", []).append(str(e))

  def _download_metrics(self, exp_info: ExperimentInfo, result: DownloadResult):
    """Download all metrics in parallel."""
    with ThreadPoolExecutor(max_workers=self.max_concurrent_metrics) as executor:
      future_to_metric = {}

      for metric_name in exp_info.metric_names:
        future = executor.submit(
          self._download_single_metric,
          exp_info.experiment_id,
          exp_info.project,
          exp_info.experiment,
          metric_name,
        )
        future_to_metric[future] = metric_name

      for future in as_completed(future_to_metric):
        metric_name = future_to_metric[future]
        metric_result = future.result()

        with self._lock:
          if metric_result["success"]:
            result.downloaded["metrics"] = result.downloaded.get("metrics", 0) + 1
            result.bytes_downloaded += metric_result["bytes"]
          else:
            result.failed.setdefault("metrics", []).append(
              f"{metric_name}: {metric_result['error']}"
            )

  def _download_single_chunk(
    self, experiment_id: str, metric_name: str, chunk_number: int
  ):
    """Download a single chunk (for parallel downloading)."""
    remote = self._get_remote_client()
    try:
      chunk_data = remote.download_metric_chunk(
        experiment_id, metric_name, chunk_number
      )
      return {
        "success": True,
        "chunk_number": chunk_number,
        "data": chunk_data.get("data", []),
        "error": None,
      }
    except Exception as e:
      return {
        "success": False,
        "chunk_number": chunk_number,
        "error": str(e),
        "data": [],
      }

  def _download_single_metric(
    self, experiment_id: str, project: str, experiment: str, metric_name: str
  ):
    """Download a single metric using chunk-aware approach (thread-safe)."""
    remote = self._get_remote_client()

    total_downloaded = 0
    bytes_downloaded = 0

    try:
      metadata = remote.get_metric_stats(experiment_id, metric_name)
      total_chunks = metadata.get("totalChunks", 0)
      buffered_points = int(metadata.get("bufferedDataPoints", 0))

      all_data = []

      if total_chunks > 0:
        with ThreadPoolExecutor(max_workers=min(10, total_chunks)) as executor:
          chunk_futures = {
            executor.submit(
              self._download_single_chunk, experiment_id, metric_name, i
            ): i
            for i in range(total_chunks)
          }

          for future in as_completed(chunk_futures):
            result = future.result()
            if result["success"]:
              all_data.extend(result["data"])
            else:
              # If a chunk fails, fall back to pagination
              raise Exception(
                f"Chunk {result['chunk_number']} download failed: {result['error']}"
              )

      if buffered_points > 0:
        response = remote.get_metric_data(experiment_id, metric_name, buffer_only=True)
        all_data.extend(response.get("data", []))

      all_data.sort(key=lambda x: int(x.get("index", 0)))

      batch_size = 10000
      for i in range(0, len(all_data), batch_size):
        batch = all_data[i : i + batch_size]
        self.local.append_batch_to_metric(
          project, experiment, metric_name, data_points=[d["data"] for d in batch]
        )
        total_downloaded += len(batch)
        bytes_downloaded += sum(len(json.dumps(d)) for d in batch)

      return {
        "success": True,
        "downloaded": total_downloaded,
        "bytes": bytes_downloaded,
        "error": None,
      }

    except Exception as e:
      # Fall back to pagination if chunk download fails
      console.print(
        f"[yellow]Chunk download failed for {metric_name}, falling back to pagination: {e}[/yellow]"
      )
      return self._download_metric_with_pagination(
        experiment_id, project, experiment, metric_name
      )

  def _download_metric_with_pagination(
    self, experiment_id: str, project: str, experiment: str, metric_name: str
  ):
    """Original pagination-based download (fallback method)."""
    remote = self._get_remote_client()

    total_downloaded = 0
    bytes_downloaded = 0
    start_index = 0

    try:
      while True:
        response = remote.get_metric_data(
          experiment_id, metric_name, start_index=start_index, limit=self.batch_size
        )

        data_points = response.get("data", [])
        if not data_points:
          break

        self.local.append_batch_to_metric(
          project, experiment, metric_name, data_points=[d["data"] for d in data_points]
        )

        total_downloaded += len(data_points)
        bytes_downloaded += sum(len(json.dumps(d)) for d in data_points)

        if not response.get("hasMore", False):
          break

        start_index += len(data_points)

      return {
        "success": True,
        "downloaded": total_downloaded,
        "bytes": bytes_downloaded,
        "error": None,
      }

    except Exception as e:
      return {"success": False, "error": str(e), "downloaded": 0, "bytes": 0}

  def _download_files(self, exp_info: ExperimentInfo, result: DownloadResult):
    """Download files in parallel, paging through all files."""
    offset = 0
    limit = 500
    while True:
      try:
        page = self.remote.list_files(exp_info.experiment_id, limit=limit, offset=offset)
      except Exception as e:
        result.failed.setdefault("files", []).append(f"List files failed: {e}")
        return

      files_data = page["files"]
      if not files_data:
        break

      with ThreadPoolExecutor(max_workers=self.max_concurrent_files) as executor:
        future_to_file = {}

        for file_info in files_data:
          future = executor.submit(
            self._download_single_file,
            exp_info.experiment_id,
            exp_info.project,
            exp_info.experiment,
            file_info,
          )
          future_to_file[future] = file_info.get("name", "unknown")

        for future in as_completed(future_to_file):
          filename = future_to_file[future]
          file_result = future.result()

          with self._lock:
            if file_result["success"]:
              result.downloaded["files"] = result.downloaded.get("files", 0) + 1
              result.bytes_downloaded += file_result["bytes"]
            else:
              result.failed.setdefault("files", []).append(
                f"{filename}: {file_result['error']}"
              )

      if not page["hasMore"]:
        break
      offset += limit

  def _download_single_file(
    self, experiment_id: str, project: str, experiment: str, file_info: Dict[str, Any]
  ):
    """Download a single file with streaming (thread-safe)."""
    remote = self._get_remote_client()

    try:
      temp_fd, temp_path = tempfile.mkstemp(prefix="ml_dash_download_")
      os.close(temp_fd)

      try:
        remote.download_file_streaming(
          experiment_id, file_info["id"], dest_path=temp_path
        )

        self.local.write_file(
          project=project,
          experiment=experiment,
          file_path=temp_path,
          prefix=file_info["path"],
          filename=file_info["filename"],
          description=file_info.get("description"),
          tags=file_info.get("tags", []),
          metadata=file_info.get("metadata"),
          checksum=file_info["checksum"],
          content_type=file_info["contentType"],
          size_bytes=file_info["sizeBytes"],
        )
      finally:
        os.remove(temp_path)

      return {"success": True, "bytes": file_info["sizeBytes"], "error": None}

    except Exception as e:
      return {"success": False, "error": str(e), "bytes": 0}


def cmd_download_track(args: argparse.Namespace) -> int:
  """Download track data from remote server."""
  config = Config()
  remote_url = args.dash_url or config.remote_url
  api_key = config.api_key

  if not remote_url:
    console.print("[red]Error:[/red] --dash-url is required (or set in config)")
    return 1

  # Parse track path: finding where experiment ends and topic begins requires
  # trying different split points, since experiments can have folder structures.
  track_path = args.tracks.strip("/")
  parts = track_path.split("/")

  if len(parts) < 4:
    console.print(
      "[red]Error:[/red] Track path must be in format: "
      "'namespace/project/experiment/topic'"
    )
    console.print("Examples:")
    console.print("  geyang/project/experiment/position")
    console.print("  geyang/project/experiment/robot/position")
    console.print("  geyang/project/folder/experiment/robot/camera/position")
    return 1

  namespace = parts[0]
  project = parts[1]

  experiment_name = None
  experiment_data = None
  topic = None

  try:
    remote_client = RemoteClient(base_url=remote_url, namespace=namespace, api_key=api_key)
  except Exception as e:
    console.print(f"[red]Error:[/red] Failed to connect to server: {e}")
    return 1

  # Try each possible split point: experiment name is parts[2:split_idx],
  # topic is parts[split_idx:]. Experiments can have folder structures.
  tried_names = []
  for split_idx in range(3, len(parts) + 1):
    potential_exp_name = "/".join(parts[2:split_idx])
    potential_topic = "/".join(parts[split_idx:])

    if not potential_topic:
      continue

    tried_names.append(potential_exp_name)

    try:
      exp_data = remote_client.get_experiment_by_path_graphql(project, potential_exp_name, namespace)
      if exp_data:
        experiment_name = potential_exp_name
        experiment_data = exp_data
        topic = potential_topic
        break
    except Exception:
      pass

    try:
      exp_data = remote_client.get_experiment_graphql(project, potential_exp_name, namespace)
      if exp_data:
        experiment_name = potential_exp_name
        experiment_data = exp_data
        topic = potential_topic
        break
    except Exception:
      continue

  if not experiment_name or not topic:
    console.print(
      f"[red]Error:[/red] Could not find valid experiment in path: {track_path}"
    )
    console.print("\nTried the following experiment names:")
    for name in tried_names:
      console.print(f"  - {name}")
    console.print(f"\nMake sure the experiment exists in project '{project}'")
    return 1

  console.print("[bold]Downloading track data...[/bold]")
  console.print(f"  Namespace: {namespace}")
  console.print(f"  Project: {project}")
  console.print(f"  Experiment: {experiment_name}")
  console.print(f"  Topic: {topic}")
  console.print(f"  Format: {args.format}")

  try:
    experiment_id = experiment_data["id"]

    console.print("\n[cyan]Fetching track data from server...[/cyan]")
    track_data = remote_client.get_track_data(
      experiment_id=experiment_id,
      topic=topic,
      format=args.format,
    )

    if args.output:
      output_path = Path(args.output)
    else:
      safe_topic = topic.replace("/", "_")
      output_path = Path(f"{safe_topic}.{args.format}")

    if args.format in ("jsonl", "parquet", "mcap"):
      output_path.write_bytes(track_data)
    else:
      if isinstance(track_data, dict):
        output_path.write_text(json.dumps(track_data, indent=2))
      else:
        output_path.write_text(str(track_data))

    file_size = output_path.stat().st_size
    console.print("\n[green]✓ Track data downloaded successfully[/green]")
    console.print(f"  Output: {output_path}")
    console.print(f"  Size: {_format_bytes(file_size)}")
    console.print(f"  Format: {args.format}")

    if args.format == "json" and isinstance(track_data, dict):
      entry_count = track_data.get("count", len(track_data.get("entries", [])))
      if entry_count:
        console.print(f"  Entries: {entry_count}")

    return 0

  except Exception as e:
    console.print(f"[red]Error downloading track data:[/red] {e}")
    if args.verbose:
      console.print(traceback.format_exc())
    return 1


def cmd_download(args: argparse.Namespace) -> int:
  """Execute download command."""
  if args.tracks:
    return cmd_download_track(args)

  config = Config()
  remote_url = args.dash_url or config.remote_url
  api_key = config.api_key  # auto-loaded from token storage if None

  if not remote_url:
    console.print("[red]Error:[/red] --dash-url is required (or set in config)")
    return 1

  namespace = None
  if args.project:
    project_parts = args.project.strip("/").split("/")
    if len(project_parts) >= 2:
      namespace = project_parts[0]

  if not namespace:
    console.print(
      "[red]Error:[/red] --project must be in format 'namespace/project' or 'namespace/project/exp'"
    )
    console.print("Example: ml-dash download --project alice/my-project")
    return 1

  remote_client = RemoteClient(base_url=remote_url, namespace=namespace, api_key=api_key)
  local_storage = LocalStorage(root_path=Path(args.path))

  state_file = Path(args.state_file)
  if args.resume:
    state = DownloadState.load(state_file)
    if state:
      console.print(
        f"[cyan]Resuming from previous download ({len(state.completed_experiments)} completed)[/cyan]"
      )
    else:
      console.print("[yellow]No previous state found, starting fresh[/yellow]")
      state = DownloadState(remote_url=remote_url, local_path=str(args.path))
  else:
    state = DownloadState(remote_url=remote_url, local_path=str(args.path))

  console.print("[bold]Discovering experiments on remote server...[/bold]")
  try:
    experiments = discover_experiments(remote_client, args.project, args.experiment)
  except Exception as e:
    console.print(f"[red]Failed to discover experiments: {e}[/red]")
    return 1

  if not experiments:
    console.print("[yellow]No experiments found[/yellow]")
    return 0

  console.print(f"Found {len(experiments)} experiment(s)")

  experiments_to_download = []
  for exp in experiments:
    exp_key = f"{exp.project}/{exp.experiment}"

    if exp_key in state.completed_experiments and not args.overwrite:
      console.print(f"  [dim]Skipping {exp_key} (already completed)[/dim]")
      continue

    exp_json = (
      local_storage.root_path / exp.project / exp.experiment / "experiment.json"
    )
    if exp_json.exists() and not args.overwrite:
      console.print(f"  [yellow]Skipping {exp_key} (already exists locally)[/yellow]")
      continue

    experiments_to_download.append(exp)

  if not experiments_to_download:
    console.print("[green]All experiments already downloaded[/green]")
    return 0

  if args.dry_run:
    console.print("\n[bold]Dry run - would download:[/bold]")
    for exp in experiments_to_download:
      console.print(f"  • {exp.project}/{exp.experiment}")
      console.print(
        f"    Logs: {exp.log_count}, Metrics: {len(exp.metric_names)}, Files: {exp.file_count}"
      )
    return 0

  console.print(
    f"\n[bold]Downloading {len(experiments_to_download)} experiment(s)...[/bold]"
  )
  results = []
  start_time = time.time()

  for i, exp in enumerate(experiments_to_download, 1):
    exp_key = f"{exp.project}/{exp.experiment}"
    console.print(f"\n[cyan][{i}/{len(experiments_to_download)}] {exp_key}[/cyan]")

    state.in_progress_experiment = exp_key
    state.save(state_file)

    downloader = ExperimentDownloader(
      local_storage=local_storage,
      remote_client=remote_client,
      batch_size=args.batch_size,
      skip_logs=args.skip_logs,
      skip_metrics=args.skip_metrics,
      skip_files=args.skip_files,
      skip_params=args.skip_params,
      verbose=args.verbose,
      max_concurrent_metrics=args.max_concurrent_metrics,
      max_concurrent_files=args.max_concurrent_files,
    )

    result = downloader.download_experiment(exp)
    results.append(result)

    if result.success:
      state.completed_experiments.append(exp_key)
      console.print("  [green]✓ Downloaded successfully[/green]")
    else:
      state.failed_experiments.append(exp_key)
      console.print(f"  [red]✗ Failed: {', '.join(result.errors)}[/red]")

    state.in_progress_experiment = None
    state.save(state_file)

  end_time = time.time()
  elapsed_time = end_time - start_time
  total_bytes = sum(r.bytes_downloaded for r in results)
  successful = sum(1 for r in results if r.success)

  console.print("\n[bold]Download Summary[/bold]")
  summary_table = Table()
  summary_table.add_column("Metric", style="cyan")
  summary_table.add_column("Value", style="green")

  summary_table.add_row("Total Experiments", str(len(results)))
  summary_table.add_row("Successful", str(successful))
  summary_table.add_row("Failed", str(len(results) - successful))
  summary_table.add_row("Total Data", _format_bytes(total_bytes))
  summary_table.add_row("Total Time", f"{elapsed_time:.2f}s")

  if elapsed_time > 0:
    speed = total_bytes / elapsed_time
    summary_table.add_row("Avg Speed", _format_bytes_per_sec(speed))

  console.print(summary_table)

  if all(r.success for r in results):
    state_file.unlink(missing_ok=True)

  return 0 if all(r.success for r in results) else 1


def add_parser(subparsers):
  """Add download command parser."""
  parser = subparsers.add_parser(
    "download", help="Download experiments from remote server to local storage"
  )

  parser.add_argument(
    "path",
    nargs="?",
    default="./.dash",
    help="Local storage directory (default: ./.dash)",
  )

  parser.add_argument(
    "--tracks",
    type=str,
    help="Download track data from path (e.g., 'namespace/project/exp/robot/position')",
  )
  parser.add_argument(
    "-f",
    "--format",
    type=str,
    choices=["json", "jsonl", "parquet", "mcap"],
    default="jsonl",
    help="Track export format (default: jsonl)",
  )
  parser.add_argument(
    "-o",
    "--output",
    type=str,
    help="Output file path (default: auto-generated from topic)",
  )

  parser.add_argument(
    "--dash-url", "--api-url",
    dest="dash_url",
    help="ML-Dash server URL (defaults to config or https://api.dash.ml)",
  )

  parser.add_argument(
    "-p",
    "--pref",
    "--prefix",
    "--proj",
    "--project",
    dest="project",
    type=str,
    help="Filter experiments by project or pattern (supports glob: 'tut*', 'tom*/tutorials/*')"
  )
  parser.add_argument(
    "--experiment",
    help="Download specific experiment (requires --project)"
  )

  parser.add_argument("--skip-logs", action="store_true", help="Don't download logs")
  parser.add_argument(
    "--skip-metrics", action="store_true", help="Don't download metrics"
  )
  parser.add_argument("--skip-files", action="store_true", help="Don't download files")
  parser.add_argument(
    "--skip-params", action="store_true", help="Don't download parameters"
  )

  parser.add_argument(
    "--dry-run", action="store_true", help="Preview without downloading"
  )
  parser.add_argument(
    "--overwrite", action="store_true", help="Overwrite existing experiments"
  )
  parser.add_argument(
    "--resume", action="store_true", help="Resume interrupted download"
  )
  parser.add_argument(
    "--state-file",
    default=".dash-download-state.json",
    help="State file path for resume (default: .dash-download-state.json)",
  )
  parser.add_argument(
    "--batch-size",
    type=int,
    default=1000,
    help="Batch size for logs/metrics (default: 1000, max: 10000)",
  )
  parser.add_argument(
    "--max-concurrent-metrics",
    type=int,
    default=5,
    help="Parallel metric downloads (default: 5)",
  )
  parser.add_argument(
    "--max-concurrent-files",
    type=int,
    default=3,
    help="Parallel file downloads (default: 3)",
  )
  parser.add_argument(
    "-v", "--verbose", action="store_true", help="Detailed progress output"
  )

  parser.set_defaults(func=cmd_download)
