from mnemo.mcp.server import main

main()
