import shutil
import uuid
from pathlib import Path
from typing import Any

from harmony_client.artifacts.base import BaseArtifact
from harmony_client.runtime.context import RecipeContext


class CustomArtifact(BaseArtifact):
    """A custom artifact for storing arbitrary data.

    Custom artifacts can optionally have a file associated with them.
    If a file is provided, it will be uploaded to Concorde when finalized.

    The artifact file is stored locally in the working directory's artifacts folder.
    """

    _local_path: Path | None

    def __init__(self, name: str, ctx: RecipeContext, file: str | None = None, **metadata: Any) -> None:
        artifact_id = str(uuid.uuid4())

        if file:
            local_path = Path(file)
            if not local_path.exists():
                # Create an empty file so it exists for finalization
                # (user can write content later with write() or copy_from())
                local_path.touch()
        else:
            local_path = None

        super().__init__(
            ctx=ctx,
            id=artifact_id,
            name=name,
            kind="custom",
            file_path=str(local_path) if local_path else None,
            **metadata,
        )

        self._local_path = local_path

        if local_path:
            self._register_pending()
        else:
            # No file to upload, register immediately
            self.ctx.job.register_artifact(self)

    @property
    def file_path(self) -> Path:
        """Get the local file path for this artifact."""
        if self._local_path is None:
            raise ValueError("This artifact has no associated file")
        return self._local_path

    def write(self, content: str | bytes) -> None:
        """Write content to the artifact file.

        Args:
            content: String or bytes to write to the file
        """
        if self._local_path is None:
            raise ValueError("This artifact has no associated file")

        mode = "w" if isinstance(content, str) else "wb"
        with open(self._local_path, mode) as f:
            f.write(content)

    def append(self, content: str | bytes) -> None:
        """Append content to the artifact file.

        Args:
            content: String or bytes to append to the file
        """
        if self._local_path is None:
            raise ValueError("This artifact has no associated file")

        mode = "a" if isinstance(content, str) else "ab"
        with open(self._local_path, mode) as f:
            f.write(content)

    def read(self) -> bytes:
        """Read the artifact file content.

        Returns:
            The file content as bytes
        """
        if self._local_path is None:
            raise ValueError("This artifact has no associated file")

        with open(self._local_path, "rb") as f:
            return f.read()

    def copy_from(self, source_path: str | Path) -> None:
        """Copy a file to this artifact's location.

        Args:
            source_path: Path to the source file to copy
        """
        if self._local_path is None:
            raise ValueError("This artifact has no associated file")

        shutil.copy2(source_path, self._local_path)

    def __repr__(self):
        return f"CustomArtifact(id={self.id}, name={self.name}, kind={self.kind}, file_path={self._local_path})"
