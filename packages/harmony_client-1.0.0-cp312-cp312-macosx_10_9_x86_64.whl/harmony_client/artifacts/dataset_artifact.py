import json
import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Self, Sequence

from harmony_client import StringThread
from harmony_client.artifacts.base import BaseArtifact
from harmony_client.runtime.context import RecipeContext
from harmony_client.runtime.dto.AdaptiveDataset import AdaptiveDatasetKind
from harmony_client.runtime.dto.DatasetSampleFormats import (
    DatasetMetricSample,
    DatasetPreferenceSample,
    DatasetPromptSample,
    DatasetSample,
    SampleMetadata,
)

logger = logging.getLogger(__name__)

# Union type for all supported dataset sample types
DatasetSampleType = DatasetSample | DatasetPromptSample | DatasetMetricSample | DatasetPreferenceSample


class DatasetArtifact(BaseArtifact):
    """
    Artifact for saving dataset samples generated during recipe execution.

    Supports different dataset kinds (Prompt, Completion, Metric, Preference, Mixed)
    and can save samples in JSONL format compatible with the platform's dataset format.

    The dataset file is stored locally in the working directory's artifacts folder.
    """

    _local_path: Path

    def __init__(self, name: str, ctx: RecipeContext, kind: AdaptiveDatasetKind = AdaptiveDatasetKind.Mixed) -> None:
        """
        Initialize a dataset artifact.

        Args:
            name: Name of the dataset artifact
            ctx: Recipe context for job registration
            kind: Type of dataset (Prompt, Completion, Metric, Preference, Mixed)
        """
        artifact_id = str(uuid.uuid4())
        local_path = ctx.artifacts_dir / f"dataset_samples_{artifact_id}.jsonl"

        super().__init__(
            ctx=ctx,
            id=artifact_id,
            name=name,
            kind="dataset",
            file_path=str(local_path),
            # Store dataset kind and sample count in metadata
            dataset_kind=kind.value,
            sample_count=0,
        )

        self._local_path = local_path
        self._dataset_kind = kind
        self._sample_count = 0
        # Register as pending artifact
        self._register_pending()

    @property
    def artifact_kind(self) -> str:
        """Get the artifact kind (always 'dataset')."""
        return self._kind

    @property
    def dataset_kind(self) -> AdaptiveDatasetKind:
        """Get the dataset kind (Prompt, Completion, etc.)."""
        return self._dataset_kind

    @property
    def sample_count(self) -> int:
        """Get the number of samples added to this artifact."""
        return self._sample_count

    def add_samples_from_thread(self, threads: List[StringThread]) -> Self:
        """
        Add a dataset sample from a string thread.
        """
        return self.add_samples([self._thread_to_dataset_sample(thread) for thread in threads])

    def add_samples(self, samples: Sequence[DatasetSampleType]) -> Self:
        """
        Add dataset samples to this artifact.

        Args:
            samples: List of dataset samples to add

        Returns:
            Self for method chaining

        Raises:
            ValueError: If samples list is empty
            TypeError: If sample type doesn't match dataset kind
            Exception: If serialization or storage fails
        """
        if not samples:
            raise ValueError("Cannot add empty samples list")

        try:
            # Validate samples match the dataset kind (unless Mixed)
            if self._dataset_kind != AdaptiveDatasetKind.Mixed:
                self._validate_samples_kind(samples)

            json_lines = "\n".join([self._sample_to_json(sample) for sample in samples])
            # Append samples to local JSONL file
            with open(self._local_path, "a", encoding="utf-8") as f:
                f.write(json_lines + "\n")

            self._sample_count += len(samples)
            logger.debug(f"Added {len(samples)} samples to dataset artifact {self.id}")
        except Exception as e:
            logger.error(f"Failed to add samples to dataset artifact {self.id}: {e}")
            raise

        return self

    def add_prompt_items(self, items: List[DatasetPromptSample]) -> Self:
        """
        Add prompt-only items to the dataset.
        """
        return self.add_samples(items)

    def add_completion_items(self, items: List[DatasetSample]) -> Self:
        """
        Add prompt-completion items to the dataset.
        """
        return self.add_samples(items)

    def add_metric_items(self, items: List[DatasetMetricSample]) -> Self:
        """
        Add items with evaluation metrics to the dataset.
        """
        return self.add_samples(items)

    def add_preference_items(self, items: List[DatasetPreferenceSample]) -> Self:
        """
        Add preference items (good vs bad completions) to the dataset.
        """
        return self.add_samples(items)

    @property
    def file_path(self) -> Path:
        """Get the local file path for this artifact."""
        return self._local_path

    def _validate_samples_kind(self, samples: Sequence[DatasetSampleType]) -> None:
        """Validate that samples match the expected dataset kind."""
        expected_type = {
            AdaptiveDatasetKind.Prompt: DatasetPromptSample,
            AdaptiveDatasetKind.Completion: DatasetSample,
            AdaptiveDatasetKind.Metric: DatasetMetricSample,
            AdaptiveDatasetKind.Preference: DatasetPreferenceSample,
        }.get(self._dataset_kind)

        if expected_type:
            for i, sample in enumerate(samples):
                if not isinstance(sample, expected_type):
                    raise TypeError(
                        f"Sample {i} is {type(sample)}, expected {expected_type} for {self._dataset_kind} dataset"
                    )

    def _sample_to_json(self, sample: DatasetSampleType) -> str:
        """Convert a dataset sample to JSON string."""
        # Use pydantic's model_dump to get the dictionary representation
        if hasattr(sample, "model_dump"):
            sample_dict = sample.model_dump()
        else:
            # Manual conversion as fallback
            sample_dict = sample.__dict__

        return json.dumps(sample_dict, default=str)  # default=str handles UUID serialization

    def _create_default_metadata(self) -> SampleMetadata:
        """Create default metadata for a sample."""
        return SampleMetadata(
            id=uuid.uuid4(), created_at=int(datetime.now().timestamp()), model_id=None, external_data=None
        )

    def _thread_to_dataset_sample(self, thread: StringThread) -> DatasetSampleType:
        """Convert a string thread to a dataset sample."""
        fragments = thread.get_fragments()
        completion_text = thread.completion()
        completion = ["assistant", completion_text] if completion_text else None

        turns = fragments[:-1] if completion_text else fragments

        metadata = thread.metadata
        match self._dataset_kind:
            case AdaptiveDatasetKind.Prompt:
                return DatasetPromptSample(
                    prompt=turns,  # type: ignore
                    metadata=SampleMetadata(
                        id=uuid.uuid4(),
                        created_at=int(datetime.now().timestamp()),
                        model_id=None,
                        external_data=metadata,
                    ),
                )
            case AdaptiveDatasetKind.Completion:
                return DatasetSample(
                    prompt=turns,  # type: ignore
                    completion=completion,  # type: ignore
                    metadata=SampleMetadata(
                        id=uuid.uuid4(),
                        created_at=int(datetime.now().timestamp()),
                        model_id=None,
                        external_data=metadata,
                    ),
                )
            case AdaptiveDatasetKind.Metric:
                raise ValueError("Metric dataset kind is not supported with threads")
            case AdaptiveDatasetKind.Preference:
                raise ValueError("Preference dataset kind is not supported with threads")
            case AdaptiveDatasetKind.Mixed:
                return DatasetSample(
                    prompt=turns,  # type: ignore
                    completion=completion,  # type: ignore
                    metadata=SampleMetadata(
                        id=uuid.uuid4(),
                        created_at=int(datetime.now().timestamp()),
                        model_id=None,
                        external_data=metadata,
                    ),
                )

    def __repr__(self):
        return f"DatasetArtifact(id={self.id}, name={self.name}, kind={self.dataset_kind}, samples={self.sample_count}, file_path={self._local_path})"
