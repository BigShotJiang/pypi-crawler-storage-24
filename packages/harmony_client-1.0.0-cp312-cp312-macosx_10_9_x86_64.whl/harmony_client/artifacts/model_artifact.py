import uuid

from harmony_client.artifacts.base import ArtifactProcessingMode, BaseArtifact
from harmony_client.runtime.context import RecipeContext


class ModelArtifact(BaseArtifact):
    def __init__(self, key: str, ctx: RecipeContext) -> None:
        super().__init__(
            ctx=ctx,
            id=str(uuid.uuid4()),
            name=key,
            kind="model",
            processing_mode=ArtifactProcessingMode.ON_REGISTRATION,
            model_key=key,
        )
        self.ctx.job.register_artifact(self)

    @property
    def model_key(self) -> str:
        return self._metadata["model_key"]
