import logging
import uuid
from pathlib import Path
from typing import List, MutableSequence, Self

from harmony_client import (
    EvalSample,
    EvaluationArtifactBase,
)
from harmony_client.artifacts.base import BaseArtifact
from harmony_client.runtime.context import RecipeContext

logger = logging.getLogger(__name__)


class EvaluationArtifact(BaseArtifact):
    """
    Artifact for saving evaluation results generated during recipe execution.

    Artifact data is written to a local directory and uploaded to Concorde either:
    - When finalize() is called explicitly
    - Automatically when the job completes
    """

    def __init__(self, name: str, ctx: RecipeContext) -> None:
        artifact_id = str(uuid.uuid4())
        # Store artifact in local artifact directory
        file_path = ctx.artifacts_dir / f"eval_samples_{artifact_id}.jsonl"
        self._eval_base = EvaluationArtifactBase(name, str(file_path), artifact_id)

        super().__init__(
            ctx=ctx,
            id=artifact_id,
            name=name,
            kind="eval",
            file_path=str(file_path),
        )

        self._sample_count = 0
        # Register as pending artifact
        self._register_pending()

    @property
    def file_path(self) -> Path:
        """Local file path where artifact data is stored."""
        return Path(self._file_path) if self._file_path else Path()

    @property
    def sample_count(self) -> int:
        """Get the number of samples added to this artifact."""
        return self._sample_count

    def add_samples(self, samples: MutableSequence[EvalSample] | List[EvalSample]) -> Self:
        """Add evaluation samples to this artifact.

        Args:
            samples: List of evaluation samples to add

        Returns:
            Self for method chaining

        Raises:
            ValueError: If samples list is empty
            Exception: If serialization or storage fails
        """
        if not samples:
            raise ValueError("Cannot add empty samples list")

        try:
            samples_json = self._eval_base.samples_to_adaptive_json(list(samples))
            jsonl_content = "\n".join(samples_json) + "\n"
            # Append to local file
            assert self._file_path is not None, "EvaluationArtifact file_path should never be None"
            with open(self._file_path, "a", encoding="utf-8") as f:
                f.write(jsonl_content)
            self._sample_count += len(samples)
            logger.debug(f"Added {len(samples)} samples to artifact {self.id}")
        except Exception as e:
            logger.error(f"Failed to add samples to artifact {self.id}: {e}")
            raise

        return self

    def __repr__(self):
        return f"EvaluationArtifact(id={self.id}, name={self.name}, kind={self.kind}, samples={self.sample_count}, path={self._file_path})"
