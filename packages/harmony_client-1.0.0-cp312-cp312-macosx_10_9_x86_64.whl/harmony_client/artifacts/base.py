"""Base artifact class with common finalization logic."""

from abc import ABC
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from harmony_client.runtime.context import RecipeContext


class ArtifactProcessingMode(Enum):
    """Controls when Concorde processes an artifact.

    ON_REGISTRATION: Process immediately when the artifact is registered.
    ON_COMPLETION: Process when the job completes (default).
    """

    ON_REGISTRATION = "on_registration"
    ON_COMPLETION = "on_completion"


class BaseArtifact(ABC):
    """Base class for artifacts that can be finalized and uploaded to Concorde.

    This class provides common functionality for:
    - Tracking finalization state
    - Registering as a pending artifact
    - Finalizing (uploading) the artifact to Concorde

    Subclasses should:
    - Call `_register_pending()` in __init__ if the artifact has a file to upload
    - Pass artifact fields (id, name, kind, file_path, metadata) to __init__

    Attributes:
        id: Unique identifier for this artifact
        name: Human-readable name
        kind: Type of artifact - "model", "eval", "dataset", or "custom"
        metadata: Additional key-value metadata for the artifact
    """

    ctx: "RecipeContext"
    _id: str
    _name: str
    _kind: str
    _metadata: dict[str, Any]
    _file_path: Optional[str]
    _finalized: bool
    _processing_mode: ArtifactProcessingMode

    def __init__(
        self,
        ctx: "RecipeContext",
        id: str,
        name: str,
        kind: str,
        file_path: Optional[str] = None,
        processing_mode: ArtifactProcessingMode = ArtifactProcessingMode.ON_COMPLETION,
        **metadata: Any,
    ) -> None:
        """Initialize the base artifact.

        Args:
            ctx: Recipe context for job operations
            id: Unique identifier for this artifact
            name: Human-readable name
            kind: Type of artifact - "model", "eval", "dataset", or "custom"
            file_path: Optional local file path where artifact data is stored
            processing_mode: When to process the artifact (default: ON_COMPLETION)
            **metadata: Additional key-value metadata for the artifact
        """
        self.ctx = ctx
        self._id = id
        self._name = name
        self._kind = kind
        self._metadata = metadata
        self._file_path = file_path
        self._finalized = False
        self._processing_mode = processing_mode

    def _register_pending(self) -> None:
        """Register this artifact as pending for later finalization.

        Call this in subclass __init__ if the artifact has a file to upload.
        """
        if self._file_path:
            self.ctx.job.add_pending_artifact(self, self._file_path)

    @property
    def id(self) -> str:
        """Get the artifact ID."""
        return self._id

    @property
    def name(self) -> str:
        """Get the artifact name."""
        return self._name

    @property
    def kind(self) -> str:
        """Get the artifact kind."""
        return self._kind

    @property
    def metadata(self) -> dict[str, Any]:
        """Get the artifact metadata."""
        return self._metadata

    @property
    def processing_mode(self) -> ArtifactProcessingMode:
        """Get the artifact processing mode."""
        return self._processing_mode

    def finalize(self) -> None:
        """Finalize the artifact by uploading it to Concorde.

        This uploads the artifact data and registers it with Concorde.
        After finalization, no more data should be added to the artifact.

        Note: If not called explicitly, the artifact will be finalized
        automatically when the job completes.
        """
        if self._finalized:
            return

        if not self._file_path:
            # No file to upload, nothing to finalize
            self._finalized = True
            return

        # Remove from pending list and finalize immediately
        self.ctx.job.remove_pending_artifact(self._id)
        self.ctx.job.finalize_artifact(self, self._file_path)
        self._finalized = True
