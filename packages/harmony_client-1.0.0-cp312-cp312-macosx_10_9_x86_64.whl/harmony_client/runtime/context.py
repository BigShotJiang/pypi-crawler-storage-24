from __future__ import annotations

import inspect
import json
import sys
import tempfile
import traceback
from datetime import datetime
from pathlib import Path
from types import TracebackType
from typing import Generator, Self

import pandas as pd
from loguru import logger
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from rich.console import Console
from rich.table import Table as RichTable

from harmony_client import ControlPlaneClient, EvalSample, HarmonyClient, get_client
from harmony_client.internal import _extract_model_key, _save_detailed_eval_table
from harmony_client.runtime.job_notifiers import ControlPlaneJobNotifier, StdoutJobNotifier
from harmony_client.utils import uuid_v7


class RecipeConfig(BaseModel):
    """Configuration for connecting to the Adaptive Harmony platform.

    Example:
        ```python
        config = RecipeConfig(
            harmony_url="ws://localhost:9000",
            num_gpus=1,
            api_key="my-api-key",
            project="my-project",
        )

        # As context manager (recommended for scripts)
        async with RecipeContext.from_config(config) as ctx:
            model = ctx.client.model("model_registry://llama-3.1-8b")
            inf = await model.spawn_inference("my-model")

        # Or await directly (for notebooks)
        ctx = await RecipeContext.from_config(config)
        # ... use ctx ...
        ctx.close()  # marks job complete and cleans up
        ```
    """

    harmony_url: str = Field(description="url of harmony service")
    control_plane_url: str | None = Field(
        default=None,
        description="URL of the control plane public API (Concorde). Used for job operations and file uploads via /api/v1/.",
    )
    control_plane_internal_url: str | None = Field(
        default=None,
        description="URL of the control plane internal API (Concorde). Used for fetching grader, dataset, and model configurations via /api/_internal/. If not set, falls back to control_plane_url.",
    )
    control_plane_api_token: str | None = Field(
        default=None,
        description="JWT token for authenticating with the control plane service (Concorde). Required when accessing protected API endpoints; may be omitted for local or test runs.",
    )
    num_gpus: int = 0
    name: str | None = Field(default=None, description="Name of this job, can be set for interactive sessions")
    recipe_name: str | None = Field(default=None, description="Name of the recipe being executed")
    job_id: str | None = None
    project: str | None = None
    api_key: str | None = None
    compute_pool: str | None = None
    working_dir: str | None = Field(
        default=None,
        description="Local working directory for recipe execution. Used for storing downloaded recipes, datasets, and artifacts. Defaults to /tmp/adaptive/{job_id}.",
    )
    user_input_file: str | None = None


class RecipeConfigCli(RecipeConfig, BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ADAPTIVE_", cli_parse_args=True, cli_kebab_case=True)


class RecipeContextManager:
    """A manager that can be both awaited and used as an async context manager.

    This allows two usage patterns:

        # Pattern 1: Async context manager (recommended for scripts)
        async with RecipeContext.from_config(config) as ctx:
            ...  # auto-complete on success, error reporting on failure

        # Pattern 2: Direct await (for notebooks/interactive use)
        ctx = await RecipeContext.from_config(config)
        ...
        ctx.close()  # marks job complete and cleans up
    """

    def __init__(self, config: RecipeConfig):
        self._config = config
        self._ctx: RecipeContext | None = None

    async def _create(self) -> RecipeContext:
        if self._ctx is None:
            self._ctx = RecipeContext(self._config, _internal=True)
            await self._ctx._initialize()
        return self._ctx

    def __await__(self) -> Generator[None, None, RecipeContext]:
        return self._create().__await__()

    async def __aenter__(self) -> RecipeContext:
        return await self._create()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._ctx is None:
            return

        try:
            if exc_type is None:
                self._ctx.job.complete()
            else:
                stack_trace = "".join(traceback.format_exception(exc_type, exc_val, exc_tb))
                try:
                    self._ctx.job.finalize_pending_artifacts()
                    self._ctx.job.report_error(stack_trace)
                except Exception as report_err:
                    logger.error("Failed to report error to control plane: {}", report_err)
        finally:
            self._ctx.job.stop_heartbeat()
            self._ctx.client.close()


class RecipeContext:
    """Context for executing recipes on the Adaptive Harmony platform.

    Create using `RecipeContext.from_config()`:

        # As context manager (recommended for scripts)
        async with RecipeContext.from_config(config) as ctx:
            ...  # auto-complete on success, error reporting on failure

        # Or await directly (for notebooks)
        ctx = await RecipeContext.from_config(config)
        ...
        ctx.close()  # marks job complete and cleans up
    """

    client: HarmonyClient
    job: ControlPlaneJobNotifier | StdoutJobNotifier
    config: RecipeConfig
    _working_dir: Path
    control_plane: ControlPlaneClient | None = None

    def __init__(self, config: RecipeConfig, *, _internal: bool = False):
        if not _internal:
            raise TypeError(
                "RecipeContext cannot be instantiated directly. Use 'RecipeContext.from_config(config)' instead."
            )
        self.config = config

    @classmethod
    def from_config(cls, config: RecipeConfig) -> RecipeContextManager:
        """Create a RecipeContext from configuration.

        Can be used either as an async context manager or awaited directly:

            # Pattern 1: Async context manager (recommended for scripts)
            async with RecipeContext.from_config(config) as ctx:
                ...  # auto-complete on success, error reporting on failure

            # Pattern 2: Direct await (for notebooks/interactive use)
            ctx = await RecipeContext.from_config(config)
            ...
            ctx.close()  # marks job complete and cleans up

        Args:
            config: The recipe configuration.

        Returns:
            A manager that can be awaited or used as an async context manager.
        """
        return RecipeContextManager(config)

    async def _initialize(self) -> None:
        self._setup_loguru()
        config = self.config
        job_id = config.job_id or uuid_v7()

        api_token = config.control_plane_api_token or config.api_key
        control_plane_url = config.control_plane_url or config.harmony_url.replace("ws://", "http://").replace(
            "wss://", "https://"
        )
        control_plane_url = control_plane_url.rstrip("/")
        if api_token and config.project:
            self.control_plane = ControlPlaneClient(
                api_endpoint=control_plane_url,
                api_token=api_token,
                project=config.project,
            )
            logger.info("Using ControlPlaneJobNotifier with control_plane_url={}", control_plane_url)
            self.job = ControlPlaneJobNotifier(self.control_plane, job_id)
        else:
            self.control_plane = None
            logger.info("Using StdoutJobNotifier")
            self.job = StdoutJobNotifier(job_id)

        logger.debug("Setting working dir")
        if config.working_dir:
            self._working_dir = Path(config.working_dir)
        else:
            self._working_dir = Path(tempfile.gettempdir()) / "adaptive"
        self._working_dir.mkdir(parents=True, exist_ok=True)
        logger.debug("working_dir={}", self._working_dir)

        # Create subdirectories
        self.recipes_dir.mkdir(parents=True, exist_ok=True)
        self.datasets_dir.mkdir(parents=True, exist_ok=True)
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)

        self.job.start_heartbeat(interval_seconds=10.0)

        harmony_url = config.harmony_url.replace("http://", "ws://").replace("https://", "wss://")
        harmony_url = harmony_url.rstrip("/")
        client = await get_client(
            harmony_url,
            num_gpus=config.num_gpus,
            api_key=config.api_key,
            project=config.project,
            compute_pool=config.compute_pool,
            job_id=job_id,
        )
        self.client = client

    def close(self) -> None:
        """Close the context, mark the job as complete, and release resources.
        Use this for manual cleanup when not using the context manager pattern
        """
        self.job.complete()
        self.job.stop_heartbeat()
        self.client.close()

    @classmethod
    async def load(cls) -> Self:
        """Load configuration from CLI arguments and environment variables.

        For manual usage, prefer `RecipeContext.from_config(config)`.
        """
        config = RecipeConfigCli()  # type: ignore
        ctx = cls(config, _internal=True)
        await ctx._initialize()
        return ctx

    @property
    def working_dir(self) -> Path:
        """Local working directory for recipe execution."""
        return self._working_dir

    @property
    def recipes_dir(self) -> Path:
        """Directory for downloaded and extracted recipe files."""
        return self._working_dir / f"job_{self.job.job_id}" / "recipes"

    @property
    def datasets_dir(self) -> Path:
        """Directory for downloaded dataset files."""
        return self._working_dir / "datasets"

    @property
    def artifacts_dir(self) -> Path:
        """Directory for artifact files before upload."""
        return self._working_dir / f"job_{self.job.job_id}" / "artifacts"

    @staticmethod
    def log_eval_result(eval_samples: list[EvalSample]) -> None:
        # Convert to DataFrame for easy aggregation
        data = []
        for eval_sample in eval_samples:
            for grade in eval_sample.grades:
                data.append(
                    {
                        "model": _extract_model_key(eval_sample.interaction.source),
                        "grader": grade.grader_key,
                        "score": grade.value,
                    }
                )
        df = pd.DataFrame(data)

        # Create pivot table with models as rows and graders as columns
        if not df.empty:
            pivot_df = df.pivot_table(index="model", columns="grader", values="score", aggfunc="mean")

            # Create Rich table from pivot
            console = Console()
            table = RichTable(title="GRADER EVALUATION RESULTS")
            table.add_column("Model", style="cyan", no_wrap=True)
            # One column per grader
            for grader_name in pivot_df.columns:
                table.add_column(grader_name, justify="center")

            # Find the maximum score for each grader (excluding NaN values)
            max_scores = {}
            for grader_name in pivot_df.columns:
                valid_scores = pivot_df[grader_name].dropna()
                if len(valid_scores) > 0:
                    max_scores[grader_name] = valid_scores.max()

            # One row per model
            for model_name in pivot_df.index:
                row = [model_name]
                for grader_name in pivot_df.columns:
                    score = pivot_df.loc[model_name, grader_name]
                    # Avg will be nan if grader failed on all samples
                    if pd.isna(score):
                        row.append("All failed")
                    else:
                        score_str = f"{score:.3f}"
                        # Highlight the highest score in green
                        if grader_name in max_scores and abs(score - max_scores[grader_name]) < 1e-9:
                            row.append(f"[green]{score_str}[/green]")
                        else:
                            row.append(score_str)
                table.add_row(*row)

            console.print(table)

            # Get the directory of the original caller (skip this method's frame)
            caller_frame = inspect.currentframe()
            original_caller_dir = None
            if caller_frame is not None and caller_frame.f_back is not None:
                original_caller_file = caller_frame.f_back.f_globals["__file__"]
                original_caller_dir = str(Path(original_caller_file).parent)

            # Save compact JSON of grader results
            original_caller_dir = original_caller_dir or Path.cwd()
            results_json = {}
            for model_name in pivot_df.index:
                results_json[model_name] = {}
                for grader_name in pivot_df.columns:
                    score = pivot_df.loc[model_name, grader_name]
                    if pd.isna(score):
                        results_json[model_name][grader_name] = None
                    else:
                        # Convert pandas scalar to native Python type
                        score_val = score.item() if hasattr(score, "item") else float(score)  # type: ignore
                        results_json[model_name][grader_name] = round(score_val, 3)  # type:ignore

            timestamp = datetime.now().replace(microsecond=0).isoformat()
            eval_dir = Path(original_caller_dir) / "adaptive_eval_samples" / timestamp
            eval_dir.mkdir(parents=True, exist_ok=True)

            results_path = eval_dir / "aggregate_scores.json"
            with open(results_path, "w") as f:
                json.dump(results_json, f, indent=2)
            print(f"\n📁 Aggregate results saved to: {results_path}")

            # Save detailed evaluation samples as html
            _save_detailed_eval_table(eval_samples, output_dir=str(eval_dir))
        else:
            print("No evaluation data to display")

    @staticmethod
    def _setup_loguru():
        """Redirect loguru to stdout if the user hasn't customized the logger."""
        if len(logger._core.handlers) == 1 and 0 in logger._core.handlers:  # type: ignore
            logger.remove(0)
            logger.add(sys.stdout)
