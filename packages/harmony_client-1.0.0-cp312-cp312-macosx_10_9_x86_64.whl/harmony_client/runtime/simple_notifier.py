from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from harmony_client.runtime.job_notifiers import StageNotifier


class SimpleProgressNotifier:
    """Simple progress notifier that reports 0% on enter and 100% on exit.

    Use as a context manager with ControlPlaneStageNotifier or StdoutStageNotifier.

    Example:
        ```python
        stage = context.job.stage_notifier("training")
        with SimpleProgressNotifier(stage):
            # do work
            pass
        ```
    """

    def __init__(self, job_notifier: "StageNotifier", monitoring_link=None):
        self.job_notifier = job_notifier
        self.monitoring_link = monitoring_link

    def __enter__(self):
        self.job_notifier.report_progress(1, 0, self.monitoring_link)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.job_notifier.report_progress(1, 1, self.monitoring_link)

    async def __aenter__(self):
        self.job_notifier.report_progress(1, 0, self.monitoring_link)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.job_notifier.report_progress(1, 1, self.monitoring_link)
