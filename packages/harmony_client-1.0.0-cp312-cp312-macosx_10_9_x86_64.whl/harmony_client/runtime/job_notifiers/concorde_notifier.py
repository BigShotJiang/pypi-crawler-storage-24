"""ControlPlaneJobNotifier - sends job updates to Concorde via GraphQL API."""

import threading
from typing import TYPE_CHECKING, Optional, Sequence

from loguru import logger

from harmony_client import ControlPlaneClient
from harmony_client.runtime.job_notifiers import JobNotifier, PendingArtifact, StageNotifier

if TYPE_CHECKING:
    from harmony_client.artifacts.base import BaseArtifact


class ControlPlaneJobNotifier(JobNotifier):
    """Job notifier that reports progress directly to Concorde via GraphQL API.

    Use this when running jobs in sandkasten or any environment that needs to
    communicate with Concorde without going through Mangrove's Sonic RPC.

    Example:
        ```python
        notifier = ControlPlaneJobNotifier(
            control_plane=control_plane_client,
            job_id="uuid-job-id"
        )
        notifier.register_stages(["training", "evaluation"])

        # Report progress
        stage = notifier.stage_notifier("training")
        stage.report_progress(tot_num_samples=1000, processed_num_samples=500)

        # Mark job complete when done
        notifier.complete()
        ```
    """

    def __init__(self, control_plane: ControlPlaneClient, job_id: str):
        """Create a new ControlPlaneJobNotifier."""
        self.job_id = job_id
        self.stages: list[str] = []
        self.monitoring_link: Optional[str] = None

        self._control_plane = control_plane

        # Track pending artifacts that need to be finalized
        self._pending_artifacts: list[PendingArtifact] = []
        # Heartbeat thread management
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._heartbeat_stop_event = threading.Event()

    def set_monitoring_link(self, monitoring_link: str) -> None:
        self.monitoring_link = monitoring_link

    def register_stages(self, stages: Sequence[str]) -> None:
        """Register the stages of this job.

        Args:
            stages: Ordered list of stage names
        """
        stage_tuples = [(stage, idx, stages[idx - 1] if idx > 0 else None) for idx, stage in enumerate(stages)]

        self._control_plane.register_job_stages(self.job_id, stage_tuples)
        self.stages = list(stages)

    def register_artifact(self, artifact: "BaseArtifact", session_id: Optional[str] = None) -> None:
        """Register an artifact produced by this job.

        Args:
            artifact: Artifact to register
            session_id: Optional session_id from chunked upload to link the file.
                        Required for dataset and eval artifacts (they need file upload).
        """
        metadata = dict(artifact.metadata) if artifact.metadata else None

        self._control_plane.register_job_artifact(
            job_id=self.job_id,
            artifact_id=artifact.id,
            name=artifact.name,
            kind=artifact.kind,
            metadata=metadata,
            session_id=session_id,
            processing_mode=artifact.processing_mode.value,
        )

    def add_pending_artifact(self, artifact: "BaseArtifact", file_path: str) -> None:
        """Add an artifact to be finalized later.

        Args:
            artifact: The artifact metadata
            file_path: The local file path where the artifact data is stored
        """
        self._pending_artifacts.append(PendingArtifact(artifact=artifact, file_path=file_path))

    def remove_pending_artifact(self, artifact_id: str) -> None:
        """Remove a pending artifact by its ID.

        Args:
            artifact_id: The ID of the artifact to remove
        """
        self._pending_artifacts = [p for p in self._pending_artifacts if p.artifact.id != artifact_id]

    def finalize_artifact(self, artifact: "BaseArtifact", file_path: str) -> None:
        """Finalize an artifact by uploading its data and registering it.

        Args:
            artifact: The artifact metadata
            file_path: The local file path where the artifact data is stored
        """
        logger.info(f"Finalizing artifact {artifact.id} ({artifact.kind}): uploading from {file_path}")

        # Upload via chunked upload (file is read in Rust to avoid Python memory overhead)
        content_type = "application/jsonl" if file_path.endswith(".jsonl") else "application/octet-stream"
        session_id = self._control_plane.upload_file(file_path, content_type)
        logger.info(f"Finalizing artifact {artifact.id}: uploaded, session_id={session_id}")

        # Register artifact with session_id - Concorde will move it to the final location
        self.register_artifact(artifact, session_id)
        logger.info(f"Finalizing artifact {artifact.id}: registered successfully")

    def finalize_pending_artifacts(self) -> None:
        """Finalize all pending artifacts."""
        logger.info(f"Finalizing {len(self._pending_artifacts)} pending artifacts")
        for pending in self._pending_artifacts:
            try:
                self.finalize_artifact(pending.artifact, pending.file_path)
            except Exception as e:
                # Log but don't fail - we want to try to finalize all artifacts
                logger.error(f"Failed to finalize artifact {pending.artifact.id} ({pending.artifact.kind}): {e}")
        self._pending_artifacts.clear()

    def report_error(self, error: str) -> None:
        """Report an error that occurred during the job.

        Args:
            error: Error message
        """
        self._control_plane.report_job_error(self.job_id, error)

    def report_progress(
        self,
        stage: str,
        tot_num_samples: Optional[int] = None,
        processed_num_samples: Optional[int] = None,
        monitoring_link: Optional[str] = None,
        checkpoints: Optional[Sequence[str]] = None,
    ) -> None:
        """Report progress for a stage.

        Args:
            stage: Stage name
            tot_num_samples: Total number of samples to process
            processed_num_samples: Number of samples processed so far
            monitoring_link: Optional monitoring dashboard URL
            checkpoints: Optional list of checkpoint identifiers
        """
        effective_monitoring_link = monitoring_link or self.monitoring_link
        checkpoints_list = list(checkpoints) if checkpoints else None

        self._control_plane.update_job_progress(
            job_id=self.job_id,
            stage_key=stage,
            total_num_samples=tot_num_samples,
            processed_num_samples=processed_num_samples,
            monitoring_link=effective_monitoring_link,
            checkpoints=checkpoints_list,
        )

    def stage_notifier(self, stage: str) -> "ControlPlaneStageNotifier":
        """Get a stage-specific notifier.

        Args:
            stage: Stage name (must be previously registered with register_stages)

        Returns:
            ControlPlaneStageNotifier for the given stage
        """
        if stage not in self.stages:
            raise ValueError(
                f"Stage '{stage}' needs to be previously registered with 'register_stages'. "
                f"Currently registered stages are: {self.stages}"
            )
        return ControlPlaneStageNotifier(self, stage)

    def complete(self) -> None:
        """Mark the job as complete.

        This will also finalize any pending artifacts before marking complete.
        """
        # Finalize any pending artifacts first
        self.finalize_pending_artifacts()
        self._control_plane.complete_job(self.job_id)
        self.stop_heartbeat()

    def heartbeat(self) -> None:
        """Send a heartbeat to indicate the job is still running."""
        ...
        # try:
        #     self._control_plane.job_heartbeat(self.job_id, interval_s)
        #     logger.trace("Heartbeat sent for job {}", self.job_id)
        # except Exception as e:
        #     logger.warning("Failed to send heartbeat for job {}: {}", self.job_id, e)

    def start_heartbeat(self, interval_seconds: float = 10.0) -> None:
        """Start a background thread that sends periodic heartbeats.

        Args:
            interval_seconds: Time between heartbeats in seconds. Defaults to 10.
        """
        self._control_plane.job_heartbeat(self.job_id, int(interval_seconds))
        # if self._heartbeat_thread is not None and self._heartbeat_thread.is_alive():
        #     logger.debug("Heartbeat thread already running for job")
        #     return

        # self._heartbeat_stop_event.clear()

        # def heartbeat_loop():
        #     logger.debug("Starting heartbeat loop for job {} (interval={}s)", self.job_id, interval_seconds)
        #     # Wait 1 second before the first heartbeat to allow job initialization
        #     time.sleep(1)
        #     self.heartbeat()
        #     while not self._heartbeat_stop_event.wait(timeout=interval_seconds):
        #         self.heartbeat()
        #     logger.debug("Heartbeat loop stopped for job {}", self.job_id)

        # self._heartbeat_thread = threading.Thread(target=heartbeat_loop, daemon=True, name=f"heartbeat-{self.job_id}")
        # self._heartbeat_thread.start()
        # logger.info("Heartbeat thread started for job {}", self.job_id)

    def stop_heartbeat(self) -> None:
        # """Stop the background heartbeat thread."""
        # if self._heartbeat_thread is None or not self._heartbeat_thread.is_alive():
        #     return

        # logger.debug("Stopping heartbeat thread")
        # self._heartbeat_stop_event.set()
        # self._heartbeat_thread.join(timeout=5.0)
        # if self._heartbeat_thread.is_alive():
        #     logger.warning("Heartbeat thread did not stop gracefully for job {}", self.job_id)
        # self._heartbeat_thread = None
        ...

    def close(self) -> None:
        """Stop heartbeat and cleanup resources."""
        # self.stop_heartbeat()
        ...

    def __enter__(self) -> "ControlPlaneJobNotifier":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    def __repr__(self) -> str:
        return f"ControlPlaneJobNotifier(job_id={self.job_id})"


class ControlPlaneStageNotifier(StageNotifier):
    """Helper class to report progress for a specific job stage."""

    def __init__(self, notifier: ControlPlaneJobNotifier, stage: str):
        self._notifier = notifier
        self._stage = stage
        self.monitoring_link: Optional[str] = None

    def set_monitoring_link(self, monitoring_link: str) -> None:
        """Set monitoring link for this stage."""
        self.monitoring_link = monitoring_link

    def report_progress(
        self,
        tot_num_samples: Optional[int] = None,
        processed_num_samples: Optional[int] = None,
        monitoring_link: Optional[str] = None,
        checkpoints: Optional[Sequence[str]] = None,
    ) -> None:
        """Report progress for this stage.

        Args:
            tot_num_samples: Total number of samples to process
            processed_num_samples: Number of samples processed so far
            monitoring_link: Optional monitoring dashboard URL
            checkpoints: Optional list of checkpoint identifiers
        """
        if (
            tot_num_samples is not None
            and processed_num_samples is not None
            and processed_num_samples > tot_num_samples
        ):
            logger.warning(
                "processed_num_samples ({}) exceeds tot_num_samples ({}) — clamping to total. "
                "This can happen when using async_map_batch with retries, as retried samples "
                "increment the counter beyond the expected total.",
                processed_num_samples,
                tot_num_samples,
            )
            processed_num_samples = tot_num_samples
        effective_monitoring_link = monitoring_link or self.monitoring_link
        self._notifier.report_progress(
            stage=self._stage,
            tot_num_samples=tot_num_samples,
            processed_num_samples=processed_num_samples,
            monitoring_link=effective_monitoring_link,
            checkpoints=checkpoints,
        )

    def __repr__(self) -> str:
        return f"ControlPlaneStageNotifier(stage={self._stage})"
