"""Job notifiers for reporting job progress.

This module provides base classes and implementations for job progress reporting:
- JobNotifier: Abstract base class defining the job notifier interface
- StageNotifier: Abstract base class for stage-specific progress reporting
- ControlPlaneJobNotifier: Reports progress to Concorde via GraphQL API
- StdoutJobNotifier: Logs progress to stdout (for local development/testing)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional, Sequence

if TYPE_CHECKING:
    from harmony_client.artifacts.base import BaseArtifact


@dataclass
class PendingArtifact:
    """Tracks an artifact that needs to be finalized."""

    artifact: "BaseArtifact"
    file_path: str


class StageNotifier(ABC):
    """Abstract base class for stage-specific progress reporting.

    A stage notifier provides a convenient way to report progress for a
    specific stage without having to pass the stage name each time.
    """

    monitoring_link: Optional[str]

    @abstractmethod
    def set_monitoring_link(self, monitoring_link: str) -> None:
        """Set monitoring link for this stage.

        Args:
            monitoring_link: URL to monitoring dashboard (e.g., Weights & Biases)
        """
        ...

    @abstractmethod
    def report_progress(
        self,
        tot_num_samples: Optional[int] = None,
        processed_num_samples: Optional[int] = None,
        monitoring_link: Optional[str] = None,
        checkpoints: Optional[Sequence[str]] = None,
    ) -> None:
        """Report progress for this stage.

        Args:
            tot_num_samples: Total number of samples to process
            processed_num_samples: Number of samples processed so far
            monitoring_link: Optional monitoring dashboard URL (overrides stage default)
            checkpoints: Optional list of checkpoint identifiers
        """
        ...


class JobNotifier(ABC):
    """Abstract base class for job progress notifiers.

    Job notifiers are responsible for reporting job progress, registering
    artifacts, and managing job lifecycle (completion, errors).

    Implementations:
    - ControlPlaneJobNotifier: Reports to Concorde via GraphQL API
    - StdoutJobNotifier: Logs to stdout for local development

    Example:
        ```python
        notifier = StdoutJobNotifier(job_id="test-job")
        notifier.register_stages(["training", "evaluation"])

        stage = notifier.stage_notifier("training")
        stage.report_progress(tot_num_samples=1000, processed_num_samples=500)

        notifier.complete()
        ```
    """

    job_id: str
    stages: list[str]
    monitoring_link: Optional[str]
    _pending_artifacts: list[PendingArtifact]

    @abstractmethod
    def set_monitoring_link(self, monitoring_link: str) -> None:
        """Set a monitoring link (e.g., Weights & Biases URL).

        Args:
            monitoring_link: URL to the monitoring dashboard
        """
        ...

    @abstractmethod
    def register_stages(self, stages: Sequence[str]) -> None:
        """Register the stages of this job.

        Stages should be registered before reporting progress.

        Args:
            stages: Ordered list of stage names
        """
        ...

    @abstractmethod
    def register_artifact(self, artifact: "BaseArtifact", session_id: Optional[str] = None) -> None:
        """Register an artifact produced by this job.

        Args:
            artifact: Artifact to register
            session_id: Optional session_id from chunked upload to link the file
        """
        ...

    @abstractmethod
    def add_pending_artifact(self, artifact: "BaseArtifact", file_path: str) -> None:
        """Add an artifact to be finalized later.

        Pending artifacts are finalized when complete() is called.

        Args:
            artifact: The artifact metadata
            file_path: The local file path where the artifact data is stored
        """
        ...

    @abstractmethod
    def remove_pending_artifact(self, artifact_id: str) -> None:
        """Remove a pending artifact by its ID.

        Args:
            artifact_id: The ID of the artifact to remove
        """
        ...

    @abstractmethod
    def finalize_artifact(self, artifact: "BaseArtifact", file_path: str) -> None:
        """Finalize an artifact by uploading its data and registering it.

        Args:
            artifact: The artifact metadata
            file_path: The local file path where the artifact data is stored
        """
        ...

    @abstractmethod
    def finalize_pending_artifacts(self) -> None:
        """Finalize all pending artifacts."""
        ...

    @abstractmethod
    def report_error(self, error: str) -> None:
        """Report an error that occurred during the job.

        Args:
            error: Error message
        """
        ...

    @abstractmethod
    def report_progress(
        self,
        stage: str,
        tot_num_samples: Optional[int] = None,
        processed_num_samples: Optional[int] = None,
        monitoring_link: Optional[str] = None,
        checkpoints: Optional[Sequence[str]] = None,
    ) -> None:
        """Report progress for a stage.

        Args:
            stage: Stage name (must be registered with register_stages)
            tot_num_samples: Total number of samples to process
            processed_num_samples: Number of samples processed so far
            monitoring_link: Optional monitoring dashboard URL
            checkpoints: Optional list of checkpoint identifiers
        """
        ...

    @abstractmethod
    def stage_notifier(self, stage: str) -> StageNotifier:
        """Get a stage-specific notifier.

        Args:
            stage: Stage name (must be previously registered with register_stages)

        Returns:
            A stage notifier for the given stage
        """
        ...

    @abstractmethod
    def complete(self) -> None:
        """Mark the job as complete.

        This will also finalize any pending artifacts before marking complete.
        """
        ...

    @abstractmethod
    def heartbeat(self) -> None:
        """Send a heartbeat to indicate the job is still running.

        This should be called periodically (e.g., every 30 seconds) to let
        the control plane know the job is still alive. The control plane uses
        heartbeats to detect dead jobs.
        """
        ...

    @abstractmethod
    def start_heartbeat(self, interval_seconds: float = 30.0) -> None:
        """Start a background thread that sends periodic heartbeats.

        Args:
            interval_seconds: Time between heartbeats in seconds. Defaults to 30.
        """
        ...

    @abstractmethod
    def stop_heartbeat(self) -> None:
        """Stop the background heartbeat thread."""
        ...

    @abstractmethod
    def close(self) -> None:
        """Close any resources (HTTP clients, etc.)."""
        ...

    def __enter__(self) -> "JobNotifier":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()


# Import implementations to make them available from this module
from harmony_client.runtime.job_notifiers.concorde_notifier import (
    ControlPlaneJobNotifier,
    ControlPlaneStageNotifier,
)
from harmony_client.runtime.job_notifiers.stdout_notifier import (
    StdoutJobNotifier,
    StdoutStageNotifier,
)

__all__ = [
    "JobNotifier",
    "StageNotifier",
    "PendingArtifact",
    "ControlPlaneJobNotifier",
    "ControlPlaneStageNotifier",
    "StdoutJobNotifier",
    "StdoutStageNotifier",
]
