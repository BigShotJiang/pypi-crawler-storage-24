"""StdoutJobNotifier - logs job updates using loguru for local/test runs."""

from typing import TYPE_CHECKING, Optional, Sequence

from loguru import logger

from harmony_client.runtime.job_notifiers import JobNotifier, PendingArtifact, StageNotifier

if TYPE_CHECKING:
    from harmony_client.artifacts.base import BaseArtifact


class StdoutJobNotifier(JobNotifier):
    """Job notifier that logs progress using loguru.

    Use this for local development or testing when Concorde is not available.

    Example:
        ```python
        notifier = StdoutJobNotifier(job_id="test-job")
        notifier.register_stages(["training", "evaluation"])

        stage = notifier.stage_notifier("training")
        stage.report_progress(tot_num_samples=1000, processed_num_samples=500)
        ```
    """

    def __init__(self, job_id: str = "local"):
        """Create a new StdoutJobNotifier.

        Args:
            job_id: The job ID (used for logging context). Defaults to "local".
        """
        self.job_id = job_id
        self.stages: list[str] = []
        self.monitoring_link: Optional[str] = None
        self._pending_artifacts: list[PendingArtifact] = []

    def set_monitoring_link(self, monitoring_link: str) -> None:
        """Set a monitoring link (e.g., Weights & Biases URL)."""
        self.monitoring_link = monitoring_link
        logger.info("Job {}: Monitoring link set to {}", self.job_id, monitoring_link)

    def register_stages(self, stages: Sequence[str]) -> None:
        """Register the stages of this job.

        Args:
            stages: Ordered list of stage names
        """
        self.stages = list(stages)
        logger.info("Job {}: Registered stages: {}", self.job_id, stages)

    def register_artifact(self, artifact: "BaseArtifact", session_id: Optional[str] = None) -> None:
        """Register an artifact produced by this job.

        Args:
            artifact: Artifact to register
            session_id: Session ID from file upload (logged for debugging)
        """
        # Validate that dataset/eval artifacts have a session_id (file upload)
        if artifact.kind in ("dataset", "eval") and session_id is None:
            raise ValueError(
                f"Cannot register {artifact.kind} artifact without session_id - "
                f"these artifact types require file upload via finalize_artifact()"
            )

        logger.info(
            "Job {}: Registered artifact: {} (kind={}, id={}, session_id={})",
            self.job_id,
            artifact.name,
            artifact.kind,
            artifact.id,
            session_id,
        )

    def add_pending_artifact(self, artifact: "BaseArtifact", file_path: str) -> None:
        """Add an artifact to be finalized later.

        Args:
            artifact: The artifact metadata
            file_path: The local file path where the artifact data is stored
        """
        self._pending_artifacts.append(PendingArtifact(artifact=artifact, file_path=file_path))
        logger.info(
            "Job {}: Added pending artifact: {} (kind={}, id={}, file_path={})",
            self.job_id,
            artifact.name,
            artifact.kind,
            artifact.id,
            file_path,
        )

    def remove_pending_artifact(self, artifact_id: str) -> None:
        """Remove a pending artifact by its ID.

        Args:
            artifact_id: The ID of the artifact to remove
        """
        self._pending_artifacts = [p for p in self._pending_artifacts if p.artifact.id != artifact_id]

    def finalize_artifact(self, artifact: "BaseArtifact", file_path: str) -> None:
        """Finalize an artifact (logs and registers for stdout notifier).

        Args:
            artifact: The artifact metadata
            file_path: The local file path where the artifact data is stored
        """
        logger.info(
            "Job {}: Finalizing artifact: {} (kind={}, id={}, file_path={})",
            self.job_id,
            artifact.name,
            artifact.kind,
            artifact.id,
            file_path,
        )
        # Also register the artifact (with a mock session_id for local testing)
        self.register_artifact(artifact, session_id="local-mock-session")

    def finalize_pending_artifacts(self) -> None:
        """Finalize all pending artifacts."""
        for pending in self._pending_artifacts:
            self.finalize_artifact(pending.artifact, pending.file_path)
        self._pending_artifacts.clear()

    def report_error(self, error: str) -> None:
        """Report an error that occurred during the job.

        Args:
            error: Error message
        """
        logger.error("Job {}: {}", self.job_id, error)

    def report_progress(
        self,
        stage: str,
        tot_num_samples: Optional[int] = None,
        processed_num_samples: Optional[int] = None,
        monitoring_link: Optional[str] = None,
        checkpoints: Optional[Sequence[str]] = None,
    ) -> None:
        """Report progress for a stage.

        Args:
            stage: Stage name
            tot_num_samples: Total number of samples to process
            processed_num_samples: Number of samples processed so far
            monitoring_link: Optional monitoring dashboard URL
            checkpoints: Optional list of checkpoint identifiers
        """
        progress_str = ""
        if tot_num_samples is not None and processed_num_samples is not None:
            pct = (processed_num_samples / tot_num_samples * 100) if tot_num_samples > 0 else 0
            progress_str = f" {processed_num_samples}/{tot_num_samples} ({pct:.1f}%)"
        elif processed_num_samples is not None:
            progress_str = f" {processed_num_samples} samples"

        checkpoint_str = f" checkpoints={checkpoints}" if checkpoints else ""
        logger.info("Job {}: Stage '{}':{}{}", self.job_id, stage, progress_str, checkpoint_str)

    def stage_notifier(self, stage: str) -> "StdoutStageNotifier":
        """Get a stage-specific notifier.

        Args:
            stage: Stage name (must be previously registered with register_stages)

        Returns:
            StdoutStageNotifier for the given stage
        """
        return StdoutStageNotifier(self, stage)

    def complete(self) -> None:
        """Mark the job as complete."""
        # Finalize any pending artifacts first
        self.finalize_pending_artifacts()
        logger.info("Job {}: Job completed", self.job_id)

    def heartbeat(self) -> None:
        """Send a heartbeat (no-op for stdout notifier, just logs at trace level)."""
        logger.trace("Job {}: Heartbeat", self.job_id)

    def start_heartbeat(self, interval_seconds: float = 30.0) -> None:
        """Start heartbeat (no-op for stdout notifier)."""
        logger.debug(
            "Job {}: Heartbeat started (interval={}s) - no-op for stdout notifier", self.job_id, interval_seconds
        )

    def stop_heartbeat(self) -> None:
        """Stop heartbeat (no-op for stdout notifier)."""
        pass

    def close(self) -> None:
        """Close any resources (no-op for stdout notifier)."""
        pass

    def __enter__(self) -> "StdoutJobNotifier":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()

    def __repr__(self) -> str:
        return f"StdoutJobNotifier(job_id={self.job_id})"


class StdoutStageNotifier(StageNotifier):
    """Helper class to report progress for a specific job stage."""

    def __init__(self, notifier: StdoutJobNotifier, stage: str):
        self._notifier = notifier
        self._stage = stage
        self.monitoring_link: Optional[str] = None

    def set_monitoring_link(self, monitoring_link: str) -> None:
        """Set monitoring link for this stage."""
        self.monitoring_link = monitoring_link

    def report_progress(
        self,
        tot_num_samples: Optional[int] = None,
        processed_num_samples: Optional[int] = None,
        monitoring_link: Optional[str] = None,
        checkpoints: Optional[Sequence[str]] = None,
    ) -> None:
        """Report progress for this stage.

        Args:
            tot_num_samples: Total number of samples to process
            processed_num_samples: Number of samples processed so far
            monitoring_link: Optional monitoring dashboard URL
            checkpoints: Optional list of checkpoint identifiers
        """
        if (
            tot_num_samples is not None
            and processed_num_samples is not None
            and processed_num_samples > tot_num_samples
        ):
            logger.warning(
                "processed_num_samples ({}) exceeds tot_num_samples ({}) — clamping to total. "
                "This can happen when using async_map_batch with retries, as retried samples "
                "increment the counter beyond the expected total.",
                processed_num_samples,
                tot_num_samples,
            )
            processed_num_samples = tot_num_samples
        effective_monitoring_link = monitoring_link or self.monitoring_link
        self._notifier.report_progress(
            stage=self._stage,
            tot_num_samples=tot_num_samples,
            processed_num_samples=processed_num_samples,
            monitoring_link=effective_monitoring_link,
            checkpoints=checkpoints,
        )

    def __repr__(self) -> str:
        return f"StdoutStageNotifier(stage={self._stage})"
