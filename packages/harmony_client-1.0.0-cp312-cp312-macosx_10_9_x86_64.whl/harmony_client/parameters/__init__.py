import json
from typing import TYPE_CHECKING, Any, Self

import aiofiles
from loguru import logger
from pydantic import BaseModel, PrivateAttr, model_serializer, model_validator

from harmony_client import StringThread
from harmony_client.parameters import dataset_kinds, model_kinds
from harmony_client.runtime.context import RecipeContext
from harmony_client.runtime.dto.DatasetSampleFormats import SampleMetadata

if TYPE_CHECKING:
    from adaptive_harmony.graders.base_grader import BaseGrader

    from harmony_client import InferenceModel, TrainingModel


class Dataset[T: dataset_kinds.DatasetKind](BaseModel):
    dataset_key: str
    feedback_key: str | None = None
    local_file_path: str | None = None

    @model_validator(mode="before")
    @classmethod
    def validate_from_json(cls, data):
        """Handle deserialization from JSON - accepts dict with dataset_key."""
        # If it's a string, convert it to the expected dict format
        if isinstance(data, str):
            return {"dataset_key": data, "feedback_key": None}
        return data

    async def load(self, ctx: RecipeContext | None = None) -> list[StringThread]:
        """
        Load dataset samples from the Harmony service.

        Args:
            ctx: RecipeContext for downloading datasets

        Returns:
            list of StringThread objects
        """
        # Resolve the concrete type parameter T at runtime.
        # T is a TypeVar at runtime, but Pydantic stores the concrete type in generic metadata.
        kind_args = type(self).__pydantic_generic_metadata__.get('args', ())
        kind = kind_args[0] if kind_args else None

        def with_metadata(thread: StringThread, metadata: SampleMetadata):
            # Only populate thread.metadata with external_data to avoid duplication
            # System fields (id, created_at, model_id) are metadata ABOUT the sample
            # and should not be mixed with user metadata IN the sample
            if metadata.external_data:
                thread.metadata = metadata.external_data
            else:
                thread.metadata = {}

        async def parse_internal_format(line_dict: Any) -> StringThread | None:
            thread = None

            format: type[dataset_kinds.DtoBaseModel] | None = None
            if kind is dataset_kinds.Prompt:
                format = dataset_kinds.DatasetPromptSample
            elif kind is dataset_kinds.Completion:
                format = dataset_kinds.DatasetSample
            elif kind is dataset_kinds.Metric:
                format = dataset_kinds.DatasetMetricSample
            elif kind is dataset_kinds.Preference:
                format = dataset_kinds.DatasetPreferenceSample
            else:  # Mixed dataset case (no type parameter or unknown kind)
                # order is important here: try the most constrained formats first
                formats: list[type[dataset_kinds.DtoBaseModel]] = [
                    dataset_kinds.DatasetPreferenceSample,
                    dataset_kinds.DatasetMetricSample,
                    dataset_kinds.DatasetSample,
                    dataset_kinds.DatasetPromptSample,
                ]
                for f in formats:
                    try:
                        f.model_validate(line_dict)
                        format = f
                        break
                    except Exception:
                        pass

            if format is None:
                raise ValueError(f"Could not determine format for line in dataset. Line {line_dict}")

            match format:
                case dataset_kinds.DatasetPromptSample:
                    sample = format.model_validate(line_dict)
                    thread = await StringThread.from_dataset(
                        [(turn.root[0], turn.root[1]) for turn in sample.prompt], None
                    )
                    with_metadata(thread, sample.metadata)
                case dataset_kinds.DatasetSample:
                    sample = format.model_validate(line_dict)
                    thread = await StringThread.from_dataset(
                        [(turn.root[0], turn.root[1]) for turn in sample.prompt], None
                    )
                    thread = thread.assistant(sample.completion.root[1])
                    thread = thread.with_weight_last_assistant_turn()
                    with_metadata(thread, sample.metadata)
                case dataset_kinds.DatasetMetricSample:
                    sample = dataset_kinds.DatasetMetricSample.model_validate(line_dict)
                    thread = await StringThread.from_dataset(
                        [(turn.root[0], turn.root[1]) for turn in sample.prompt], None
                    )
                    thread = thread.assistant(sample.completion.root[1])
                    thread = thread.with_weight_last_assistant_turn()
                    with_metadata(thread, sample.metadata)
                    if self.feedback_key and sample.metrics:
                        # put metric value in "res" key in the metadata
                        thread.metadata["res"] = sample.metrics.get(self.feedback_key)

                case dataset_kinds.DatasetPreferenceSample:
                    sample = dataset_kinds.DatasetPreferenceSample.model_validate(line_dict)
                    thread = await StringThread.from_dataset(
                        [(turn.root[0], turn.root[1]) for turn in sample.prompt], None
                    )
                    with_metadata(thread, sample.metadata)
                    thread.metadata["other_completion"] = sample.bad_completion.root[1]
                    thread.metadata["preferred_completion"] = sample.good_completion.root[1]

            return thread

        async def parse_external_format(line_dict: Any) -> StringThread | None:
            thread = None
            if "input" in line_dict or "messages" in line_dict:
                key = "input" if "input" in line_dict else "messages"
                turns = [(inner_turn_dict["role"], inner_turn_dict["content"]) for inner_turn_dict in line_dict[key]]

                # For Prompt kind, strip trailing assistant turns and skip adding completion
                if kind is dataset_kinds.Prompt:
                    while turns and turns[-1][0] == "assistant":
                        turns.pop()
                    thread = await StringThread.from_dataset(turns, None)
                else:
                    thread = await StringThread.from_dataset(turns, None)
                    if "completion" in line_dict and line_dict["completion"]:
                        thread = thread.assistant(line_dict["completion"])
                    thread = thread.with_weight_last_assistant_turn()
            else:
                print("Did not find `input`, or `messages` key in sample, ignoring")
            if thread is not None:
                thread.metadata = line_dict.get("metadata", {})
                if "other_completion" in line_dict and "preferred_completion" in line_dict:
                    thread.metadata["other_completion"] = line_dict["other_completion"]
                    thread.metadata["preferred_completion"] = line_dict["preferred_completion"]
                if "feedbacks" in line_dict and self.feedback_key:
                    thread.metadata["res"] = line_dict["feedbacks"].get(self.feedback_key)
            return thread

        if ctx and ctx.control_plane:
            # Download dataset to the datasets directory
            dataset_path = ctx.datasets_dir / f"{self.dataset_key}.jsonl"
            ctx.control_plane.download_dataset(self.dataset_key, str(dataset_path))
            lines = []
            async with aiofiles.open(dataset_path, encoding="utf-8") as f:
                async for line in f:
                    lines.append(line.rstrip("\n"))
        else:
            assert self.local_file_path is not None, (
                "Local file path is required when control_plane_url is not provided"
            )
            lines = []
            async with aiofiles.open(self.local_file_path, encoding="utf-8") as f:
                async for line in f:
                    lines.append(line.rstrip("\n"))

        threads = []
        parse_function = None
        for line in lines:
            if len(line.strip()) == 0:
                continue
            line_dict = json.loads(line)

            if parse_function is None:
                try:
                    thread = await parse_internal_format(line_dict)
                    parse_function = parse_internal_format
                except Exception as e:
                    logger.warning("Could not read dataset as internal format, falling back to external format {}", e)
                    thread = await parse_external_format(line_dict)
                    parse_function = parse_external_format
            else:
                thread = await parse_function(line_dict)

            if thread is not None:
                threads.append(thread)

        if len(threads) == 0:
            raise ValueError("Did not find any valid format samples in the dataset")
        return threads

    def __hash__(self):
        """Make Dataset hashable based on its keys."""
        return hash((self.dataset_key, self.feedback_key))


class Model[T: model_kinds.ModelKind](BaseModel):
    model_key: str
    _pending_calls: list[tuple[str, tuple, dict]] = PrivateAttr(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def validate_from_json(cls, data):
        """Handle deserialization - accepts string or dict."""
        if isinstance(data, str):
            return {"model_key": data}
        return data

    @model_serializer
    def serialize_model(self) -> str:
        """Serialize as just the model_key string."""
        return self.model_key

    def _with_call(self, method: str, *args, **kwargs) -> Self:
        new = self.model_copy()
        new._pending_calls = self._pending_calls + [(method, args, kwargs)]
        return new

    async def to_builder(
        self,
        ctx: RecipeContext,
        kv_cache_len: int | None = None,
        tokens_to_generate: int | None = None,
        tp: int | None = None,
        extra_params: dict | None = None,
    ):
        """Resolve pending builder calls into a ModelBuilder ready for spawning."""
        assert ctx.control_plane, "control-plane-url must be provided to load a model from its key"
        config_response = await ctx.control_plane.get_model_config(self.model_key)

        kwargs = {
            k: v
            for k, v in {
                "kv_cache_len": kv_cache_len or config_response.kv_cache_len,
                "tokens_to_generate": tokens_to_generate,
            }.items()
            if v is not None
        }
        builder = ctx.client.model(config_response.harmony_url, **kwargs)

        if tp_to_pass := tp or config_response.tp:
            builder = builder.tp(tp_to_pass)

        extra = (
            extra_params
            if extra_params is not None
            else (json.loads(config_response.extra_params) if config_response.extra_params else None)
        )
        if extra:
            builder = builder.extra_params(**extra)

        for method, args, kw in self._pending_calls:
            builder = getattr(builder, method)(*args, **kw)
        return builder

    # Builder methods — return a new Model with the call recorded
    def tp(self, tp: int) -> Self:
        return self._with_call("tp", tp)

    def with_adapter(self, use_adapter: bool = True) -> Self:
        return self._with_call("with_adapter", use_adapter)

    def with_draft(self, draft_model_path: str, num_draft_steps: int | None = None) -> Self:
        return self._with_call("with_draft", draft_model_path, num_draft_steps=num_draft_steps)

    def into_scoring_model(self) -> Self:
        return self._with_call("into_scoring_model")

    def extra_params(self, **params) -> Self:
        return self._with_call("extra_params", **params)

    def tools(self, tools: list[str]) -> Self:
        return self._with_call("tools", tools)

    def api_key(self, api_key: str) -> Self:
        return self._with_call("api_key", api_key)

    async def spawn_inference(
        self,
        name: str,
        ctx: RecipeContext,
        kv_cache_len: int | None = None,
        tokens_to_generate: int | None = None,
        tp: int | None = None,
        extra_params: dict | None = None,
    ) -> "InferenceModel":
        builder = await self.to_builder(ctx, kv_cache_len=kv_cache_len, tokens_to_generate=tokens_to_generate, tp=tp, extra_params=extra_params)
        return await builder.spawn_inference(name)

    async def spawn_train(
        self,
        name: str,
        ctx: RecipeContext,
        max_batch_size: int,
        tp: int | None = None,
        extra_params: dict | None = None,
    ) -> "TrainingModel":
        builder = await self.to_builder(ctx, tp=tp, extra_params=extra_params)
        return await builder.spawn_train(name, max_batch_size)

    def __hash__(self):
        """Make Model hashable based on its key."""
        return hash(self.model_key)


class Grader(BaseModel):
    grader_key: str

    @model_validator(mode="before")
    @classmethod
    def validate_from_json(cls, data):
        """Handle deserialization - accepts string or dict."""
        if isinstance(data, str):
            return {"grader_key": data}
        return data

    @model_serializer
    def serialize_model(self) -> str:
        """Serialize as just the grader_key string."""
        return self.grader_key

    async def load(
        self,
        ctx: RecipeContext,
        tp: int | None = None,
        kv_cache_len: int | None = None,
        max_tokens: int | None = None,
    ) -> "BaseGrader":
        """
        Load a grader instance configured with this grader's parameters.

        Args:
            ctx: RecipeContext with client
            tp (int | None, optional): Tensor parallelism override
            kv_cache_len (int | None, optional): KV cache length override

        Returns:
            BaseGrader: A configured grader instance ready for use
        """
        # puke: need to figure out smth better here.
        # I don't like code duplication but maybe we should duplicate these guys?
        # I'm not sure tbh...
        try:
            from adaptive_harmony.graders import BaseGrader as GraderImpl  # pyright: ignore[reportAttributeAccessIssue]
        except ImportError:
            raise ImportError(
                "To load and instantiate a grader, the adaptive_harmony package is required. Install it with `pip install adaptive-harmony`"
            )

        assert ctx.control_plane, "control-plane-url must be provided to load a grader from its key"
        grader_config = await ctx.control_plane.get_grader_config(self.grader_key)

        return await GraderImpl.from_config(
            grader_config=grader_config, ctx=ctx, tp=tp, kv_cache_len=kv_cache_len, max_tokens=max_tokens
        )

    def __hash__(self):
        """Make Grader hashable based on its key."""
        return hash(self.grader_key)
