# ruff: noqa: E501, F401
"""Utility functions for harmony_client."""

def uuid_v7() -> str:
    """Generate a UUID v7 (time-ordered).

    UUID v7 includes a timestamp component that makes them naturally sortable
    by creation time. This is useful for generating identifiers that need to
    be ordered chronologically, such as job IDs.

    Returns:
        A new UUID v7 string in the standard hyphenated format.

    Example:
        ```python
        from harmony_client.utils import uuid_v7

        job_id = uuid_v7()
        print(job_id)  # e.g., "01938c5e-8a7f-7000-b234-567890abcdef"
        ```
    """
    ...

__all__: list[str]
