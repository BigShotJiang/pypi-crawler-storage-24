"""Integration tests for 'siftd search' semantic search CLI.

Tests the query → search → format output flow and key options.
"""

import argparse

import pytest

pytestmark = pytest.mark.embeddings

pytest.importorskip("fastembed")

from siftd.cli_search import cmd_search
from siftd.embeddings.indexer import build_embeddings_index
from siftd.storage.sqlite import (
    create_database,
    get_or_create_harness,
    get_or_create_model,
    get_or_create_workspace,
    insert_conversation,
    insert_prompt,
    insert_prompt_content,
    insert_response,
    insert_response_content,
)

# Uses semantic_search_db fixture from conftest.py for populated_db


@pytest.fixture
def populated_db(semantic_search_db):
    """Alias to shared semantic_search_db fixture for CLI search tests."""
    return semantic_search_db


@pytest.fixture
def indexed_db(populated_db, tmp_path):
    """Create database with embeddings index built."""
    embed_db_path = tmp_path / "embeddings.db"

    build_embeddings_index(
        db_path=populated_db["db_path"],
        embed_db_path=embed_db_path,
        verbose=False,
    )

    return {
        **populated_db,
        "embed_db_path": embed_db_path,
    }


def make_args(**kwargs):
    """Create argparse.Namespace with defaults for cmd_search."""
    defaults = {
        "query": [],
        "db": None,
        "embed_db": None,
        "limit": 10,
        "verbose": False,
        "full": False,
        "context": None,
        "by_time": False,
        "workspace": None,
        "model": None,
        "since": None,
        "before": None,
        "index": False,
        "rebuild": False,
        "backend": None,
        "thread": False,
        "embeddings_only": False,
        "recall": 80,
        "role": None,
        "first": False,
        "conversations": False,
        "refs": None,
        "threshold": None,
        "json": False,
        "format": None,
        "no_exclude_active": True,  # Disable active exclusion for tests
        "include_derivative": True,  # Include derivative for tests
        "no_diversity": True,  # Disable MMR for deterministic tests
        "lambda_": 0.7,
        "recency": False,
        "recency_half_life": 30.0,
        "recency_max_boost": 1.15,
        "tag": None,
        "all_tags": None,
        "no_tag": None,
    }
    defaults.update(kwargs)
    return argparse.Namespace(**defaults)


class TestSearchIndexing:
    """Tests for --index and --rebuild modes."""

    def test_index_builds_embeddings(self, populated_db, tmp_path, capsys):
        """--index creates embeddings database."""
        embed_db_path = tmp_path / "embeddings.db"

        args = make_args(
            db=str(populated_db["db_path"]),
            embed_db=str(embed_db_path),
            index=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert embed_db_path.exists()
        assert "Embedding" in captured.out or "chunks" in captured.out

    def test_rebuild_clears_and_rebuilds(self, indexed_db, capsys):
        """--rebuild clears existing index and rebuilds."""
        args = make_args(
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            rebuild=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "Clearing" in captured.out or "chunks" in captured.out

    def test_index_requires_main_db(self, tmp_path):
        """--index fails if main database doesn't exist."""
        args = make_args(
            db=str(tmp_path / "nonexistent.db"),
            embed_db=str(tmp_path / "embed.db"),
            index=True,
        )

        result = cmd_search(args)

        assert result == 1


class TestSearchSearch:
    """Tests for query → search → format flow."""

    def test_basic_search_returns_results(self, indexed_db, capsys):
        """Basic search returns relevant results."""
        args = make_args(
            query=["error", "handling"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        # Should find content about errors/exceptions
        assert "error" in captured.out.lower() or "exception" in captured.out.lower() or captured.out

    def test_empty_query_shows_usage(self, indexed_db, capsys):
        """Empty query shows usage message."""
        args = make_args(
            query=[],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 1
        assert "Usage" in captured.out

    def test_missing_embed_db_shows_hint(self, populated_db, tmp_path, capsys):
        """Missing embeddings database shows helpful message when --semantic used."""
        args = make_args(
            query=["test"],
            db=str(populated_db["db_path"]),
            embed_db=str(tmp_path / "nonexistent_embed.db"),
            semantic=True,  # Explicitly request semantic mode to trigger error
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 1
        assert "No embeddings index found" in captured.out
        assert "--index" in captured.out

    def test_missing_main_db_shows_hint(self, tmp_path, capsys):
        """Missing main database shows helpful message."""
        args = make_args(
            query=["test"],
            db=str(tmp_path / "nonexistent.db"),
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 1
        assert "Database not found" in captured.out
        assert "ingest" in captured.out


class TestSearchFilters:
    """Tests for workspace and other filters."""

    def test_workspace_filter(self, indexed_db, capsys):
        """--workspace filters to matching workspace."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            workspace="python",
            json=True,  # JSON output for easier verification
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        # Results should only contain Python workspace
        if captured.out.strip():
            import json
            data = json.loads(captured.out)
            # Verify results exist (or no results which is also valid)
            assert isinstance(data, (list, dict))

    def test_limit_restricts_results(self, indexed_db, capsys):
        """--limit restricts number of results."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            limit=1,
            json=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        if captured.out.strip():
            import json
            data = json.loads(captured.out)
            # JSON output is a list of results
            if isinstance(data, list):
                assert len(data) <= 1


class TestSearchOutputFormats:
    """Tests for output format options."""

    def test_json_output(self, indexed_db, capsys):
        """--json outputs valid JSON."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            json=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        # Should be valid JSON
        import json
        data = json.loads(captured.out)
        assert isinstance(data, (list, dict))

    def test_verbose_shows_more_text(self, indexed_db, capsys, monkeypatch):
        """--verbose shows full chunk text."""
        # Isolate from user config by setting empty XDG_CONFIG_HOME
        monkeypatch.setenv("XDG_CONFIG_HOME", str(indexed_db["db_path"].parent / "empty_config"))

        # Run without verbose
        args1 = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
        )
        cmd_search(args1)
        out1 = capsys.readouterr().out

        # Run with verbose
        args2 = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            verbose=True,
        )
        cmd_search(args2)
        out2 = capsys.readouterr().out

        # Verbose output should be longer or equal
        assert len(out2) >= len(out1)


class TestSearchServeDelegation:
    def test_delegates_to_serve_when_available(self, indexed_db, capsys, monkeypatch):
        """When delegation returns results, CLI should not initialize a local embedding backend."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            json=True,
        )

        # Force delegation eligibility regardless of DB path checks.
        monkeypatch.setattr("siftd.cli_search._can_delegate_to_serve", lambda *a, **k: True)

        fake_results = [
            {
                "chunk_id": "01HXFAKECHUNK000000000000",
                "conversation_id": indexed_db["conv1_id"],
                "chunk_type": "exchange",
                "text": "delegated result",
                "score": 0.9,
                "source_ids": [],
                "breakdown": None,
            }
        ]
        monkeypatch.setattr("siftd.cli_search._delegate_search_via_serve", lambda *a, **k: fake_results)

        # If local semantic path is used, this would be called.
        import siftd.embeddings as embeddings

        def _should_not_be_called(*_a, **_k):
            raise AssertionError("expected serve delegation (no local embedding backend init)")

        monkeypatch.setattr(embeddings, "get_backend", _should_not_be_called)

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        import json

        body = json.loads(captured.out)
        assert body["query"] == "error"
        assert body["result_count"] == 1
        assert body["results"][0]["conversation_id"] == indexed_db["conv1_id"]

    def test_delegation_rejects_mismatched_db_path(self, monkeypatch, tmp_path):
        """Delegate path should reject serve instances pointing at a different DB."""
        from siftd.cli_search import _delegate_search_via_serve

        args = make_args()

        cli_db = tmp_path / "cli.db"
        cli_db.write_text("")  # path existence isn't required, but keep it realistic
        other_db = tmp_path / "other.db"
        other_db.write_text("")

        monkeypatch.setenv("SIFTD_SERVE_URL", "http://127.0.0.1:8484")

        monkeypatch.setattr(
            "siftd.serve.client.probe_health",
            lambda **_k: {"service": "siftd", "status": "ok", "db_path": str(other_db.resolve())},
        )

        def _should_not_call_search(**_k):
            raise AssertionError("expected DB mismatch rejection before calling /v1/search")

        monkeypatch.setattr("siftd.serve.client.search", _should_not_call_search)

        out = _delegate_search_via_serve(
            args,
            query="q",
            n=10,
            embeddings_only=False,
            rerank="mmr",
            exclude_active=True,
            db=cli_db,
        )
        assert out is None

    def test_resolves_default_url_from_serve_port_config(self, monkeypatch, tmp_path):
        from siftd.cli_search import _resolve_serve_base_url

        monkeypatch.delenv("SIFTD_SERVE_URL", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

        cfg_dir = tmp_path / "siftd"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        (cfg_dir / "config.toml").write_text("[serve]\nport = 9000\n")

        base_url, explicit = _resolve_serve_base_url()
        assert base_url == "http://127.0.0.1:9000"
        assert explicit is False

    def test_resolves_url_from_serve_state_file(self, monkeypatch, tmp_path):
        """CLI discovers serve port from runtime state file."""
        from siftd.cli_search import _resolve_serve_base_url
        import json
        import os

        monkeypatch.delenv("SIFTD_SERVE_URL", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
        monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))

        state_dir = tmp_path / "state" / "siftd"
        state_dir.mkdir(parents=True)
        (state_dir / "serve.json").write_text(
            json.dumps(
                {
                    "pid": os.getpid(),  # current process is alive
                    "port": 9000,
                    "db_path": "/tmp/test.db",
                }
            )
        )

        base_url, explicit = _resolve_serve_base_url()
        assert base_url == "http://127.0.0.1:9000"
        assert explicit is False

    def test_serve_port_config_takes_precedence_over_state_file(self, monkeypatch, tmp_path):
        """serve.port config should win over a live state file."""
        from siftd.cli_search import _resolve_serve_base_url
        import json
        import os

        monkeypatch.delenv("SIFTD_SERVE_URL", raising=False)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
        monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))

        # Config says port 7000
        cfg_dir = tmp_path / "config" / "siftd"
        cfg_dir.mkdir(parents=True)
        (cfg_dir / "config.toml").write_text("[serve]\nport = 7000\n")

        # State file says port 9000 (live PID)
        state_dir = tmp_path / "state" / "siftd"
        state_dir.mkdir(parents=True)
        (state_dir / "serve.json").write_text(
            json.dumps({"pid": os.getpid(), "port": 9000, "db_path": "/tmp/test.db"})
        )

        base_url, explicit = _resolve_serve_base_url()
        assert base_url == "http://127.0.0.1:7000"
        assert explicit is False


class TestSearchFlagValidation:
    """Tests for flag combination validation."""

    def test_json_with_refs_errors(self, indexed_db, capsys):
        """--json with --refs returns error (refs would break JSON validity)."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            json=True,
            refs=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 1
        assert "--refs is not supported with --json" in captured.err

    def test_json_with_thread_warns_but_succeeds(self, indexed_db, capsys):
        """--json with --thread warns to stderr but outputs valid JSON."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            json=True,
            thread=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--thread is ignored with --json output" in captured.err
        # Output should still be valid JSON
        import json
        data = json.loads(captured.out)
        assert isinstance(data, (list, dict))

    def test_json_without_refs_works(self, indexed_db, capsys):
        """--json without --refs outputs valid JSON."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            json=True,
            refs=None,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        import json
        data = json.loads(captured.out)
        assert isinstance(data, (list, dict))

    def test_refs_without_json_works(self, indexed_db, capsys):
        """--refs without --json outputs refs as before."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            json=False,
            refs=True,
        )

        result = cmd_search(args)
        # Should succeed (refs content may or may not be present depending on data)
        assert result == 0

    def test_unknown_format_shows_clean_error(self, indexed_db, capsys):
        """--format with unknown name shows clean error listing valid formats."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            format="nonexistent_format",
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 1
        assert "Unknown format 'nonexistent_format'" in captured.err
        assert "Available:" in captured.err


class TestSearchEdgeCases:
    """Edge case tests."""

    def test_no_results_for_unrelated_query(self, indexed_db, capsys):
        """Query with no matches returns appropriate message."""
        args = make_args(
            query=["xyzzy", "completely", "unrelated", "gibberish"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            threshold=0.99,  # Very high threshold to ensure no matches
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        # Should return 0 (no error) but indicate no results
        assert result == 0
        assert "No results" in captured.out or not captured.out.strip()

    def test_threshold_filters_low_scores(self, indexed_db, capsys):
        """--threshold filters out low-scoring results."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            threshold=0.99,  # Very high threshold
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        # Either returns 0 with "No results" or returns successfully
        assert result == 0

    def test_first_respects_custom_threshold(self, indexed_db, capsys):
        """--first with --threshold uses the user-specified threshold, not hardcoded 0.65."""
        # First, verify default (implicit 0.65) behavior with --first
        args_default = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            first=True,
            json=True,
        )
        cmd_search(args_default)
        out_default = capsys.readouterr().out

        # Now test with explicit low threshold
        args_low = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            first=True,
            threshold=0.1,  # Very low threshold
            json=True,
        )
        result = cmd_search(args_low)
        out_low = capsys.readouterr().out

        # Should succeed (no error)
        assert result == 0
        # With a low threshold, we should get results if any exist
        # (The exact behavior depends on scores, but we're testing the passthrough)


class TestSearchThreadMode:
    """Tests for --thread mode candidate pool handling."""

    @pytest.fixture
    def multi_chunk_db(self, tmp_path):
        """Create database with many chunks across conversations for thread tests."""
        db_path = tmp_path / "main.db"
        conn = create_database(db_path)

        harness_id = get_or_create_harness(conn, "test_harness", source="test", log_format="jsonl")
        model_id = get_or_create_model(conn, "test-model")
        ws_id = get_or_create_workspace(conn, "/projects/test", "2024-01-01T10:00:00Z")

        # Create 10 conversations with 2 exchanges each = 20 chunks
        # All about "error handling" to ensure they match the query
        for i in range(10):
            conv_id = insert_conversation(
                conn, external_id=f"conv-{i}", harness_id=harness_id,
                workspace_id=ws_id, started_at=f"2024-01-{10+i:02d}T10:00:00Z",
            )
            # First exchange
            p1_id = insert_prompt(conn, conv_id, f"p{i}-1", f"2024-01-{10+i:02d}T10:00:00Z")
            insert_prompt_content(conn, p1_id, 0, "text", f'{{"text": "How do I handle errors in scenario {i}?"}}')
            r1_id = insert_response(
                conn, conv_id, p1_id, model_id, None, f"r{i}-1", f"2024-01-{10+i:02d}T10:00:01Z",
                input_tokens=10, output_tokens=100,
            )
            insert_response_content(
                conn, r1_id, 0, "text",
                f'{{"text": "For error handling in scenario {i}, use try/except blocks and proper logging."}}'
            )
            # Second exchange
            p2_id = insert_prompt(conn, conv_id, f"p{i}-2", f"2024-01-{10+i:02d}T10:01:00Z")
            insert_prompt_content(conn, p2_id, 0, "text", f'{{"text": "What about error recovery in case {i}?"}}')
            r2_id = insert_response(
                conn, conv_id, p2_id, model_id, None, f"r{i}-2", f"2024-01-{10+i:02d}T10:01:01Z",
                input_tokens=10, output_tokens=100,
            )
            insert_response_content(
                conn, r2_id, 0, "text",
                f'{{"text": "Error recovery for case {i} should include retry logic and graceful degradation."}}'
            )

        conn.commit()
        conn.close()

        embed_db_path = tmp_path / "embeddings.db"
        build_embeddings_index(db_path=db_path, embed_db_path=embed_db_path, verbose=False)

        return {"db_path": db_path, "embed_db_path": embed_db_path}

    def test_thread_mode_returns_more_than_limit(self, multi_chunk_db, capsys):
        """--thread mode should not trim results to --limit.

        The widened candidate pool (40+) should be preserved for the thread
        formatter to group by conversation, rather than being trimmed early.
        """
        args = make_args(
            query=["error", "handling"],
            db=str(multi_chunk_db["db_path"]),
            embed_db=str(multi_chunk_db["embed_db_path"]),
            limit=3,  # Request only 3, but thread mode should get more
            thread=True,
            json=True,  # JSON for easy counting
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0

        import json
        data = json.loads(captured.out)
        # JSON output is {"results": [...], ...}
        results = data.get("results", data) if isinstance(data, dict) else data
        # Thread mode should return more results than --limit since it
        # manages its own candidate pool for conversation grouping
        assert len(results) > 3, f"Expected >3 results for --thread, got {len(results)}"

    def test_non_thread_mode_respects_limit(self, multi_chunk_db, capsys):
        """Non-thread mode should respect --limit as before."""
        args = make_args(
            query=["error", "handling"],
            db=str(multi_chunk_db["db_path"]),
            embed_db=str(multi_chunk_db["embed_db_path"]),
            limit=3,
            thread=False,
            json=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0

        import json
        data = json.loads(captured.out)
        # JSON output is {"results": [...], ...}
        results = data.get("results", data) if isinstance(data, dict) else data
        assert len(results) <= 3, f"Expected <=3 results without --thread, got {len(results)}"


class TestSearchPrivacyWarning:
    """Tests for privacy warning on --full and --refs flags."""

    def test_full_flag_prints_privacy_warning(self, indexed_db, capsys):
        """--full prints privacy warning to stderr."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            full=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "Showing full content which may contain sensitive information" in captured.err

    def test_refs_flag_prints_privacy_warning(self, indexed_db, capsys):
        """--refs prints privacy warning to stderr."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            refs=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "Showing full content which may contain sensitive information" in captured.err

    def test_normal_output_no_privacy_warning(self, indexed_db, capsys):
        """Normal output (no --full or --refs) has no privacy warning."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            full=False,
            refs=None,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "Showing full content which may contain sensitive information" not in captured.err


class TestByTimeWarning:
    """Tests for --by-time warning when used with incompatible modes."""

    def test_by_time_with_conversations_warns(self, indexed_db, capsys):
        """--by-time with --conversations prints warning to stderr."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            by_time=True,
            conversations=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--by-time has no effect in conversation mode" in captured.err

    def test_by_time_with_thread_warns(self, indexed_db, capsys):
        """--by-time with --thread prints warning to stderr."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            by_time=True,
            thread=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--by-time has no effect in thread mode" in captured.err

    def test_by_time_with_json_warns(self, indexed_db, capsys):
        """--by-time with --json prints warning to stderr."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            by_time=True,
            json=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--by-time has no effect in json mode" in captured.err

    def test_by_time_with_verbose_no_warning(self, indexed_db, capsys):
        """--by-time with --verbose (compatible mode) has no warning."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            by_time=True,
            verbose=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--by-time has no effect" not in captured.err

    def test_by_time_with_full_no_warning(self, indexed_db, capsys):
        """--by-time with --full (compatible mode) has no warning."""
        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            by_time=True,
            full=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--by-time has no effect" not in captured.err

    def test_by_time_default_mode_no_warning(self, indexed_db, capsys, monkeypatch):
        """--by-time with default chunk list mode has no warning."""
        # Isolate from user config
        monkeypatch.setenv("XDG_CONFIG_HOME", str(indexed_db["db_path"].parent / "empty_config"))

        args = make_args(
            query=["error"],
            db=str(indexed_db["db_path"]),
            embed_db=str(indexed_db["embed_db_path"]),
            by_time=True,
        )

        result = cmd_search(args)
        captured = capsys.readouterr()

        assert result == 0
        assert "--by-time has no effect" not in captured.err
