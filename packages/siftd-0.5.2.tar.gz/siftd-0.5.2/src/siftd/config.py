"""User configuration management for siftd.

Config file location: ~/.config/siftd/config.toml

Example config:
    [search]
    formatter = "verbose"
"""

import sys
from collections.abc import Callable, Iterable
from typing import NamedTuple, cast

import tomlkit
import tomlkit.exceptions
from tomlkit import TOMLDocument
from tomlkit.container import Container

from siftd.paths import config_dir, config_file


class _SchemaEntry(NamedTuple):
    pattern: str
    expected: str
    validator: Callable[[object], bool]


def _is_str(value: object) -> bool:
    return isinstance(value, str)


def _is_int_like(value: object) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, str):
        try:
            int(value)
            return True
        except ValueError:
            return False
    return False


def _is_bool_like(value: object) -> bool:
    if isinstance(value, bool):
        return True
    if isinstance(value, str):
        return value.strip().lower() in ("true", "false", "0", "1", "yes", "no")
    return False


def _is_str_list(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) for item in value)


_CONFIG_SCHEMA: list[_SchemaEntry] = [
    _SchemaEntry("db.path", "string", _is_str),
    _SchemaEntry("search.formatter", "string", _is_str),
    _SchemaEntry("search.serve_delegate", "bool", _is_bool_like),
    _SchemaEntry("tools.limit", "int", _is_int_like),
    _SchemaEntry("query.limit", "int", _is_int_like),
    _SchemaEntry("query.chars", "int", _is_int_like),
    _SchemaEntry("query.tool_chars", "int", _is_int_like),
    _SchemaEntry("ingestion.filter_binary", "bool", _is_bool_like),
    _SchemaEntry("serve.url", "string", _is_str),
    _SchemaEntry("serve.db", "string", _is_str),
    _SchemaEntry("serve.host", "string", _is_str),
    _SchemaEntry("serve.port", "int", _is_int_like),
    _SchemaEntry("serve.fts_rebuild", "string", _is_str),
    _SchemaEntry("adapters.*.locations", "list[string]", _is_str_list),
    _SchemaEntry("sync.ssh.options", "list[string]", _is_str_list),
    _SchemaEntry("sync.ssh.connect_timeout_s", "int", _is_int_like),
    _SchemaEntry("sync.remotes.*.host", "string", _is_str),
    _SchemaEntry("sync.remotes.*.path", "string", _is_str),
    _SchemaEntry("sync.remotes.*.last_push", "string", _is_str),
    _SchemaEntry("sync.remotes.*.last_pull", "string", _is_str),
    _SchemaEntry("sync.remotes.*.ssh.options", "list[string]", _is_str_list),
    _SchemaEntry("update.check", "bool", _is_bool_like),
]


def _match_schema(key: str) -> _SchemaEntry | None:
    parts = key.split(".")
    for entry in _CONFIG_SCHEMA:
        pattern_parts = entry.pattern.split(".")
        if len(pattern_parts) != len(parts):
            continue
        if all(p == "*" or p == k for p, k in zip(pattern_parts, parts)):
            return entry
    return None


def _iter_config_items(obj: object, prefix: str = "") -> Iterable[tuple[str, object]]:
    if not isinstance(obj, dict):
        return
    for key, value in obj.items():
        key_str = str(key)
        full_key = f"{prefix}.{key_str}" if prefix else key_str
        yield full_key, value
        if isinstance(value, dict):
            yield from _iter_config_items(value, full_key)


def _warn_validation(message: str) -> None:
    print(f"Warning: {message}", file=sys.stderr)


def _validate_config(doc: TOMLDocument) -> None:
    for key, value in _iter_config_items(doc):
        entry = _match_schema(key)
        if entry is None:
            if not isinstance(value, dict):
                _warn_validation(f"Unknown config key '{key}'")
            continue
        if not entry.validator(value):
            _warn_validation(
                f"Config key '{key}' expects {entry.expected} but found {type(value).__name__}"
            )


def _ensure_known_key(key: str) -> None:
    if _match_schema(key) is None:
        raise ValueError(f"Unknown config key '{key}'")


def load_config() -> TOMLDocument:
    """Load config from file, returning empty document if missing or invalid."""
    path = config_file()
    if not path.exists():
        return tomlkit.document()

    try:
        doc = tomlkit.parse(path.read_text())
    except tomlkit.exceptions.TOMLKitError as e:
        print(f"Warning: Invalid config file {path}: {e}", file=sys.stderr)
        return tomlkit.document()
    return doc


def get_config(key: str) -> str | None:
    """Get config value by dotted key path (e.g., 'ask.formatter').

    Returns None if key doesn't exist.
    """
    doc = load_config()
    parts = key.split(".")

    current = doc
    for part in parts:
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]

    # Return string representation for non-container values
    if isinstance(current, (dict, list)):
        return None
    return str(current) if current is not None else None


def _coerce_value(value: str) -> str | bool:
    """Coerce CLI string value to appropriate TOML type.

    Detects "true"/"false" (case-insensitive) as booleans.
    Everything else passes through as string.
    """
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    return value


def set_config(key: str, value: str) -> None:
    """Set config value by dotted key path (e.g., 'ask.formatter').

    Creates intermediate tables as needed. Preserves existing comments and formatting.
    Raises ValueError for unknown keys.
    """
    _ensure_known_key(key)
    path = config_file()

    # Load existing or create new
    if path.exists():
        try:
            doc = tomlkit.parse(path.read_text())
        except tomlkit.exceptions.TOMLKitError:
            doc = tomlkit.document()
    else:
        doc = tomlkit.document()

    parts = key.split(".")
    current = doc

    # Navigate/create intermediate tables
    for part in parts[:-1]:
        if part not in current:
            current[part] = tomlkit.table()
        current = current[part]

    # Set the final value (with type coercion)
    cast(Container, current)[parts[-1]] = _coerce_value(value)

    # Ensure config directory exists and write
    config_dir().mkdir(parents=True, exist_ok=True)
    path.write_text(tomlkit.dumps(doc))


def _ensure_parent_table(doc: TOMLDocument, parts: list[str]) -> Container:
    """Return parent container for a dotted key, creating tables as needed."""
    current: Container = doc
    for part in parts[:-1]:
        if part not in current:
            current[part] = tomlkit.table()
        elif not isinstance(current[part], dict):
            raise ValueError(f"Config path '{'.'.join(parts[:-1])}' is not a table")
        current = cast(Container, current[part])
    if not isinstance(current, dict):
        raise ValueError(f"Config path '{'.'.join(parts[:-1])}' is not a table")
    return current


def _get_parent_table(doc: TOMLDocument, parts: list[str]) -> Container | None:
    """Return parent container for a dotted key, or None if missing/invalid."""
    current: Container = doc
    for part in parts[:-1]:
        if not isinstance(current, dict) or part not in current:
            return None
        current = cast(Container, current[part])
    if not isinstance(current, dict):
        return None
    return current


def append_config_list(key: str, value: str) -> bool:
    """Append a value to a list-valued config key.

    Creates intermediate tables and list if missing. Returns True if changed.
    Raises ValueError if the key exists and is not a list.
    """
    path = config_file()

    if path.exists():
        try:
            doc = tomlkit.parse(path.read_text())
        except tomlkit.exceptions.TOMLKitError:
            doc = tomlkit.document()
    else:
        doc = tomlkit.document()

    parts = key.split(".")
    parent = _ensure_parent_table(doc, parts)
    leaf = parts[-1]

    existing = parent.get(leaf)
    if existing is None:
        arr = tomlkit.array()
        arr.append(value)
        parent[leaf] = arr
        config_dir().mkdir(parents=True, exist_ok=True)
        path.write_text(tomlkit.dumps(doc))
        return True

    if not isinstance(existing, list):
        raise ValueError(f"Config key '{key}' is not a list")

    if value in existing:
        return False

    existing.append(value)
    config_dir().mkdir(parents=True, exist_ok=True)
    path.write_text(tomlkit.dumps(doc))
    return True


def remove_config_list(key: str, value: str) -> bool:
    """Remove a value from a list-valued config key.

    Returns True if a value was removed, False otherwise.
    Raises ValueError if the key exists and is not a list.
    """
    path = config_file()
    if not path.exists():
        return False

    try:
        doc = tomlkit.parse(path.read_text())
    except tomlkit.exceptions.TOMLKitError:
        return False

    parts = key.split(".")
    parent = _get_parent_table(doc, parts)
    if parent is None:
        return False
    leaf = parts[-1]

    existing = parent.get(leaf)
    if existing is None:
        return False
    if not isinstance(existing, list):
        raise ValueError(f"Config key '{key}' is not a list")

    changed = False
    while value in existing:
        existing.remove(value)
        changed = True

    if not changed:
        return False

    path.write_text(tomlkit.dumps(doc))
    return True


def get_search_defaults() -> dict:
    """Get default values for 'siftd search' command from config.

    Returns dict with keys matching argparse attribute names.
    Only includes values that are set in config.
    """
    doc = load_config()
    defaults = {}

    search_config = doc.get("search", {})
    if isinstance(search_config, dict):
        if "formatter" in search_config:
            defaults["format"] = str(search_config["formatter"])

    return defaults


def get_query_defaults() -> dict:
    """Get default values for 'siftd query' command from config.

    Reads [query] section. Returns dict with int-valued keys only
    (limit, chars, tool_chars). Non-int values are silently skipped.
    """
    doc = load_config()
    defaults = {}

    query_config = doc.get("query", {})
    if isinstance(query_config, dict):
        for key in ("limit", "chars", "tool_chars"):
            raw = query_config.get(key)
            if raw is not None:
                try:
                    defaults[key] = int(raw)
                except (ValueError, TypeError):
                    pass  # skip non-int values

    return defaults


def get_tools_defaults() -> dict:
    """Get default values for 'siftd tools' command from config.

    Reads [tools] section. Returns dict with int-valued keys only (limit).
    """
    doc = load_config()
    defaults = {}

    tools_config = doc.get("tools", {})
    if isinstance(tools_config, dict):
        for key in ("limit",):
            raw = tools_config.get(key)
            if raw is not None:
                try:
                    defaults[key] = int(raw)
                except (ValueError, TypeError):
                    pass

    return defaults


def get_adapter_locations(name: str) -> list[str] | None:
    """Get configured discovery locations for an adapter.

    Reads [adapters.<name>].locations as a TOML array.
    Returns None if unconfigured.
    """
    doc = load_config()
    adapters_config = doc.get("adapters", {})
    if not isinstance(adapters_config, dict):
        return None
    adapter_config = adapters_config.get(name, {})
    if not isinstance(adapter_config, dict):
        return None
    locations = adapter_config.get("locations")
    if isinstance(locations, list):
        return [str(loc) for loc in locations]
    return None


def get_sync_remotes() -> list[dict]:
    """Get all configured sync remotes.

    Reads from [sync.remotes.*] sections in config.toml.

    Returns list of dicts with keys: name, host, path, last_push.
    """
    doc = load_config()
    sync_config = doc.get("sync", {})
    if not isinstance(sync_config, dict):
        return []
    remotes_config = sync_config.get("remotes", {})
    if not isinstance(remotes_config, dict):
        return []

    remotes = []
    for name, cfg in remotes_config.items():
        if not isinstance(cfg, dict):
            continue
        remotes.append({
            "name": name,
            "host": cfg.get("host"),
            "path": str(cfg.get("path", "")),
            "last_push": cfg.get("last_push"),
            "last_pull": cfg.get("last_pull"),
            "auth": dict(cfg["auth"]) if "auth" in cfg and isinstance(cfg.get("auth"), dict) else None,
        })
    return remotes


def get_sync_remote(name: str) -> dict | None:
    """Get a single sync remote by name.

    Returns dict with keys: name, host, path, last_push. Or None if not found.
    """
    for remote in get_sync_remotes():
        if remote["name"] == name:
            return remote
    return None


def set_sync_remote(name: str, host: str | None, path: str) -> None:
    """Create or update a sync remote in config.

    Example TOML:
        [sync.remotes.alcove]
        host = "alcove"
        path = "/data/siftd/team.db"
    """
    cfg_path = config_file()

    if cfg_path.exists():
        try:
            doc = tomlkit.parse(cfg_path.read_text())
        except tomlkit.exceptions.TOMLKitError:
            doc = tomlkit.document()
    else:
        doc = tomlkit.document()

    # Navigate/create sync.remotes.<name>
    if "sync" not in doc:
        doc["sync"] = tomlkit.table()
    sync_tbl = cast(Container, doc["sync"])
    if "remotes" not in sync_tbl:
        sync_tbl["remotes"] = tomlkit.table()
    remotes_tbl = cast(Container, sync_tbl["remotes"])
    if name not in remotes_tbl:
        remotes_tbl[name] = tomlkit.table()

    remote_tbl = cast(Container, remotes_tbl[name])
    if host is not None:
        remote_tbl["host"] = host
    elif "host" in remote_tbl:
        del remote_tbl["host"]
    remote_tbl["path"] = path

    config_dir().mkdir(parents=True, exist_ok=True)
    cfg_path.write_text(tomlkit.dumps(doc))


def set_remote_auth(name: str, auth: dict) -> None:
    """Set auth config for a sync remote."""
    cfg_path = config_file()
    doc = tomlkit.parse(cfg_path.read_text())
    sync_tbl = cast(Container, doc["sync"])
    remotes_tbl = cast(Container, sync_tbl["remotes"])
    remote_tbl = cast(Container, remotes_tbl[name])
    remote_tbl["auth"] = auth
    cfg_path.write_text(tomlkit.dumps(doc))


def remove_sync_remote(name: str) -> bool:
    """Remove a sync remote from config.

    Returns True if the remote existed and was removed.
    """
    cfg_path = config_file()
    if not cfg_path.exists():
        return False

    try:
        doc = tomlkit.parse(cfg_path.read_text())
    except tomlkit.exceptions.TOMLKitError:
        return False

    sync_config = doc.get("sync")
    if not isinstance(sync_config, dict):
        return False
    remotes_config = sync_config.get("remotes")
    if not isinstance(remotes_config, dict):
        return False
    if name not in remotes_config:
        return False

    del remotes_config[name]
    cfg_path.write_text(tomlkit.dumps(doc))
    return True


def update_last_push(name: str, timestamp: str) -> None:
    """Write last_push timestamp for a sync remote."""
    cfg_path = config_file()

    if cfg_path.exists():
        try:
            doc = tomlkit.parse(cfg_path.read_text())
        except tomlkit.exceptions.TOMLKitError:
            doc = tomlkit.document()
    else:
        doc = tomlkit.document()

    sync_config = doc.get("sync")
    if not isinstance(sync_config, dict):
        return
    remotes_config = sync_config.get("remotes")
    if not isinstance(remotes_config, dict):
        return
    if name not in remotes_config:
        return

    cast(Container, remotes_config[name])["last_push"] = timestamp
    cfg_path.write_text(tomlkit.dumps(doc))


def update_last_pull(name: str, timestamp: str) -> None:
    """Write last_pull timestamp for a sync remote."""
    cfg_path = config_file()

    if cfg_path.exists():
        try:
            doc = tomlkit.parse(cfg_path.read_text())
        except tomlkit.exceptions.TOMLKitError:
            doc = tomlkit.document()
    else:
        doc = tomlkit.document()

    sync_config = doc.get("sync")
    if not isinstance(sync_config, dict):
        return
    remotes_config = sync_config.get("remotes")
    if not isinstance(remotes_config, dict):
        return
    if name not in remotes_config:
        return

    cast(Container, remotes_config[name])["last_pull"] = timestamp
    cfg_path.write_text(tomlkit.dumps(doc))


def get_ssh_options(remote_name: str | None = None) -> list[str]:
    """Build SSH CLI options from config.

    Per-remote ``sync.remotes.<name>.ssh.options`` takes precedence over
    global ``sync.ssh.options``.  The ``sync.ssh.connect_timeout_s`` value
    is always appended as ``-o ConnectTimeout=N`` (unless overridden by a
    per-remote options list).

    Returns a flat list of strings suitable for splicing into a subprocess
    command (e.g. ``["ssh"] + get_ssh_options("alcove") + [host, ...]``).
    """
    doc = load_config()
    sync_config = doc.get("sync", {})
    if not isinstance(sync_config, dict):
        return []

    # Check per-remote options first
    if remote_name is not None:
        remotes_config = sync_config.get("remotes", {})
        if isinstance(remotes_config, dict):
            remote_cfg = remotes_config.get(remote_name, {})
            if isinstance(remote_cfg, dict):
                ssh_cfg = remote_cfg.get("ssh", {})
                if isinstance(ssh_cfg, dict):
                    opts = ssh_cfg.get("options")
                    if isinstance(opts, list):
                        return [str(o) for o in opts]

    # Fall back to global options
    ssh_config = sync_config.get("ssh", {})
    if not isinstance(ssh_config, dict):
        return []

    result: list[str] = []

    opts = ssh_config.get("options")
    if isinstance(opts, list):
        result.extend(str(o) for o in opts)

    timeout = ssh_config.get("connect_timeout_s")
    if timeout is not None:
        try:
            result.extend(["-o", f"ConnectTimeout={int(timeout)}"])
        except (ValueError, TypeError):
            pass

    return result


def get_ingestion_filter_binary() -> bool:
    """Get whether to filter binary content during ingestion.

    Reads from config [ingestion] filter_binary, defaults to True.

    Example config:
        [ingestion]
        filter_binary = false  # disable binary filtering
    """
    doc = load_config()
    ingestion_config = doc.get("ingestion", {})
    if isinstance(ingestion_config, dict):
        value = ingestion_config.get("filter_binary")
        if value is not None:
            # Handle boolean or string "true"/"false"
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                return value.lower() not in ("false", "0", "no")
    # Default: filtering is enabled
    return True
