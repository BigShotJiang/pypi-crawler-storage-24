"""Public search API for programmatic access by agent harnesses."""

import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from siftd.storage.filters import WhereBuilder
from siftd.storage.sql_helpers import batched_in_query
from siftd.storage.sqlite import open_database

# Hard cap on MMR candidates to prevent unbounded memory usage.
# 1000 vectors * 1536 dims * 4 bytes = ~6MB — safe for all systems.
MAX_MMR_CANDIDATES = 1000


@dataclass
class ScoreBreakdown:
    """Detailed score components for explainability.

    Tracks how the final score was computed through the scoring pipeline:
    - embedding_sim: Raw cosine similarity [0-1]
    - recency_boost: Multiplier applied (1.0 if recency disabled)
    - pre_mmr_score: embedding_sim * recency_boost
    - mmr_penalty: Diversity penalty applied (None if MMR disabled)
    - mmr_rank: Position in MMR selection order (1-indexed, None if MMR disabled)
    - final_score: Score after all adjustments
    - fts5_matched: Was this conversation in FTS5 recall set?
    - fts5_mode: FTS5 match mode ("and", "or", or None if no FTS5 match)
    """

    embedding_sim: float
    recency_boost: float = 1.0
    pre_mmr_score: float | None = None
    mmr_penalty: float | None = None
    mmr_rank: int | None = None
    final_score: float | None = None
    fts5_matched: bool = False
    fts5_mode: str | None = None

    def __post_init__(self):
        if self.pre_mmr_score is None:
            self.pre_mmr_score = self.embedding_sim * self.recency_boost
        if self.final_score is None:
            self.final_score = self.pre_mmr_score

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "embedding_sim": round(self.embedding_sim, 4),
            "recency_boost": round(self.recency_boost, 4),
            "pre_mmr_score": round(self.pre_mmr_score, 4) if self.pre_mmr_score is not None else None,
            "mmr_penalty": round(self.mmr_penalty, 4) if self.mmr_penalty is not None else None,
            "mmr_rank": self.mmr_rank,
            "final_score": round(self.final_score, 4) if self.final_score is not None else None,
            "fts5_matched": self.fts5_matched,
            "fts5_mode": self.fts5_mode,
        }


def apply_temporal_weight(
    results: list[dict],
    timestamps: dict[str, str],
    *,
    half_life_days: float = 30.0,
    max_boost: float = 1.15,
) -> list[dict]:
    """Apply temporal weighting to boost recent results.

    Uses a mild exponential decay that:
    - Boosts recent results (up to max_boost for today's results)
    - Gently decays older results (half-life controls decay rate)
    - Never penalizes old results below their original score

    The decay formula: weight = 1 + (max_boost - 1) * exp(-days_ago * ln(2) / half_life)

    At days_ago=0: weight = max_boost (e.g., 1.15 = 15% boost)
    At days_ago=half_life: weight ≈ 1 + (max_boost-1)/2 (half the boost)
    As days_ago→∞: weight → 1.0 (no penalty, just no boost)

    Args:
        results: List of result dicts with 'conversation_id' and 'score'.
            If results have 'breakdown' (ScoreBreakdown), it will be updated.
        timestamps: Dict mapping conversation_id to ISO timestamp string.
        half_life_days: Days until boost decays to half. Default 30.
        max_boost: Maximum boost multiplier for today's results. Default 1.15.

    Returns:
        Results with adjusted 'score' values (original list is not modified).
        ScoreBreakdown.recency_boost is updated if present.
    """
    if not results or max_boost <= 1.0:
        return results

    import numpy as np

    now = datetime.now(UTC)
    decay_constant = np.log(2) / half_life_days

    weighted = []
    for r in results:
        r_copy = dict(r)
        conv_id = r["conversation_id"]
        ts_str = timestamps.get(conv_id, "")
        weight = 1.0

        if ts_str:
            try:
                # Parse ISO timestamp (with or without timezone)
                ts_str_clean = ts_str.replace("Z", "+00:00")
                if "+" not in ts_str_clean and ts_str_clean.count("-") <= 2:
                    # No timezone, assume UTC
                    ts = datetime.fromisoformat(ts_str_clean).replace(tzinfo=UTC)
                else:
                    ts = datetime.fromisoformat(ts_str_clean)
                days_ago = max(0, (now - ts).total_seconds() / 86400)
                # Exponential decay: starts at max_boost, decays to 1.0
                weight = 1.0 + (max_boost - 1.0) * np.exp(-decay_constant * days_ago)
                r_copy["score"] = r["score"] * weight
            except (ValueError, TypeError):
                pass  # Keep original score if timestamp parsing fails

        # Update breakdown if present
        if "breakdown" in r_copy and isinstance(r_copy["breakdown"], ScoreBreakdown):
            breakdown = r_copy["breakdown"]
            breakdown.recency_boost = float(weight)
            breakdown.pre_mmr_score = breakdown.embedding_sim * breakdown.recency_boost
            breakdown.final_score = breakdown.pre_mmr_score

        weighted.append(r_copy)

    return weighted


@dataclass
class SearchResult:
    """A single search result from hybrid_search."""

    conversation_id: str
    score: float
    text: str
    chunk_type: str
    workspace_path: str | None
    started_at: str | None
    chunk_id: str | None = None
    source_ids: list[str] | None = None
    breakdown: dict | None = None


def mmr_rerank(
    results: list[dict],
    query_embedding: list[float],
    *,
    lambda_: float = 0.7,
    limit: int = 10,
) -> list[dict]:
    """Rerank results using Maximal Marginal Relevance with conversation-level penalty.

    Two-tier penalty:
    1. If a chunk's conversation is already in the selected set, penalty = 1.0
       (hard suppress same-conversation duplicates).
    2. Otherwise, penalty = max cosine similarity between this chunk's embedding
       and any already-selected chunk's embedding (standard MMR diversity).

    Each result dict must include 'embedding' and 'score' keys.

    Args:
        results: Candidate chunks with 'embedding', 'score', 'conversation_id'.
        query_embedding: The query's embedding vector.
        lambda_: Balance between relevance (1.0) and diversity (0.0). Default 0.7.
        limit: Number of results to select.

    Returns:
        Selected results in MMR rank order (without 'embedding' key).
    """
    if not results:
        return []

    import numpy as np

    n = len(results)

    # Pre-compute embeddings matrix for vectorized similarity
    # Embeddings may be numpy arrays or lists; stack them
    embeddings = np.vstack([
        r["embedding"] if isinstance(r["embedding"], np.ndarray) else np.asarray(r["embedding"], dtype=np.float32)
        for r in results
    ])

    # Normalize all embeddings once for faster dot products
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms = np.where(norms == 0, 1, norms)
    embeddings_normalized = embeddings / norms

    # Pre-compute relevance scores
    relevances = np.array([r["score"] for r in results], dtype=np.float32)
    conv_ids = [r["conversation_id"] for r in results]

    remaining = set(range(n))
    selected: list[int] = []
    selected_convs: set[str] = set()
    chunk_ids = [r.get("chunk_id", "") for r in results]

    # Track max similarity to selected set for each candidate
    max_sim_to_selected = np.zeros(n, dtype=np.float32)

    while remaining and len(selected) < limit:
        best_idx = -1
        best_score = float("-inf")
        best_chunk_id = ""

        for idx in remaining:
            conv_id = conv_ids[idx]
            if conv_id in selected_convs:
                penalty = 1.0
            elif selected:
                penalty = float(max_sim_to_selected[idx])
            else:
                penalty = 0.0

            mmr_score = lambda_ * relevances[idx] - (1 - lambda_) * penalty
            chunk_id = chunk_ids[idx]
            # Deterministic tie-breaker: use chunk_id (ULIDs sort by creation time)
            if (mmr_score, chunk_id) > (best_score, best_chunk_id):
                best_score = mmr_score
                best_idx = idx
                best_chunk_id = chunk_id

        remaining.remove(best_idx)
        selected.append(best_idx)
        selected_convs.add(conv_ids[best_idx])

        # Update max similarities: compute similarity of all remaining to newly selected
        if remaining:
            new_vec = embeddings_normalized[best_idx]
            for idx in remaining:
                sim = float(np.dot(embeddings_normalized[idx], new_vec))
                if sim > max_sim_to_selected[idx]:
                    max_sim_to_selected[idx] = sim

    # Track penalty at selection time for breakdown
    penalties: dict[int, float] = {}
    for rank, idx in enumerate(selected):
        # Recompute penalty for this result at selection time
        conv_id = conv_ids[idx]
        convs_before = set(conv_ids[i] for i in selected[:rank])
        if conv_id in convs_before:
            penalties[idx] = 1.0
        elif rank == 0:
            penalties[idx] = 0.0
        else:
            # Approximate: use current max_sim value (slightly conservative)
            penalties[idx] = float(max_sim_to_selected[idx])

    # Return selected results without embedding key, with MMR breakdown
    reranked = []
    for rank, idx in enumerate(selected):
        r = dict(results[idx])
        r.pop("embedding", None)

        # Update breakdown if present
        if "breakdown" in r and isinstance(r["breakdown"], ScoreBreakdown):
            breakdown = r["breakdown"]
            breakdown.mmr_penalty = penalties.get(idx, 0.0)
            breakdown.mmr_rank = rank + 1  # 1-indexed rank
            # Final score after MMR: pre_mmr - (1-lambda)*penalty
            breakdown.final_score = (
                lambda_ * (breakdown.pre_mmr_score or breakdown.embedding_sim)
                - (1 - lambda_) * breakdown.mmr_penalty
            )

        reranked.append(r)
    return reranked


def hybrid_search(
    query: str,
    *,
    db_path: Path | None = None,
    embed_db_path: Path | None = None,
    limit: int = 10,
    recall: int = 80,
    embeddings_only: bool = False,
    workspace: str | None = None,
    model: str | None = None,
    since: str | None = None,
    before: str | None = None,
    tags: list[str] | None = None,
    all_tags: list[str] | None = None,
    exclude_tags: list[str] | None = None,
    include_derivative: bool = False,
    backend: str | None = None,
    exclude_active: bool = True,
    rerank: str = "mmr",
    lambda_: float = 0.7,
    recency: bool = False,
    recency_half_life: float = 30.0,
    recency_max_boost: float = 1.15,
    fts5_passthrough: bool = False,
) -> list[SearchResult]:
    """Run hybrid FTS5+embeddings search, return structured results.

    Args:
        query: The search query string.
        db_path: Path to main SQLite DB. Defaults to XDG data path.
        embed_db_path: Path to embeddings DB. Defaults to XDG data path.
        limit: Maximum number of results to return.
        recall: Number of FTS5 candidate conversations for hybrid recall.
        embeddings_only: Skip FTS5 recall, search all embeddings directly.
        workspace: Filter to conversations from workspaces matching this substring.
        model: Filter to conversations using models matching this substring.
        since: Filter to conversations started at or after this ISO date.
        before: Filter to conversations started before this ISO date.
        tags: OR filter — conversations with any of these tags.
        all_tags: AND filter — conversations with all of these tags.
        exclude_tags: NOT filter — exclude conversations with any of these tags.
        include_derivative: Include derivative conversations (default False).
        backend: Preferred embedding backend name (ollama, fastembed).
        exclude_active: Auto-exclude conversations from active sessions (default True).
        rerank: Reranking strategy — "mmr" for diversity or "relevance" for pure similarity.
        lambda_: MMR balance between relevance (1.0) and diversity (0.0). Default 0.7.
        recency: Enable temporal weighting to boost recent results. Default False.
        recency_half_life: Days until recency boost decays to half. Default 30.
        recency_max_boost: Maximum boost for today's results (e.g., 1.15 = 15%). Default 1.15.
        fts5_passthrough: If True, allow an FTS5-only fast-path when FTS5 can
            supply at least `limit` results (after filters). This is an opt-in
            escape hatch for structured identifier queries where semantic reranking
            may hurt exact-match relevance. Default False.

    Returns:
        List of SearchResult ordered by reranking strategy.

    Raises:
        FileNotFoundError: If the database files don't exist.
        RuntimeError: If no embedding backend is available.
        EmbeddingsNotAvailable: If embedding dependencies are not installed.
    """
    from siftd.embeddings import require_embeddings

    require_embeddings("Semantic search")

    from siftd.embeddings import SCHEMA_VERSION, get_backend
    from siftd.paths import db_path as default_db_path
    from siftd.paths import embeddings_db_path as default_embed_path
    from siftd.storage.embeddings import (
        IndexCompatError,
        open_embeddings_db,
        search_similar,
        validate_index_compat,
    )
    from siftd.storage.fts import fts5_best_hit_for_conversation, fts5_recall_details
    from siftd.storage.tags import DERIVATIVE_TAG

    db = db_path if db_path is not None else default_db_path()
    embed_db = embed_db_path if embed_db_path is not None else default_embed_path()

    if not db.exists():
        raise FileNotFoundError(f"Database not found: {db}")
    if not embed_db.exists():
        raise FileNotFoundError(f"Embeddings database not found: {embed_db}")

    # Build candidate filter set and active exclusion set
    excluded: set[str] = set()
    candidate_ids: set[str] | None = None

    exclude_tags_final = list(exclude_tags or [])
    if not include_derivative and DERIVATIVE_TAG not in exclude_tags_final:
        exclude_tags_final.append(DERIVATIVE_TAG)

    if exclude_active:
        excluded = get_active_conversation_ids(db)

    main_conn = open_database(db, read_only=True)
    fts5_ids: set[str] | None = None
    fts5_mode: str | None = None
    fts5_query: str | None = None
    fts5_ordered: list[str] | None = None
    try:
        candidate_ids = _filter_conversations_conn(
            main_conn,
            workspace=workspace,
            model=model,
            since=since,
            before=before,
            tags=tags,
            all_tags=all_tags,
            exclude_tags=exclude_tags_final or None,
        )

        # Pre-filter active sessions when we have an explicit candidate set
        if excluded and candidate_ids is not None:
            candidate_ids = candidate_ids - excluded

        # Hybrid recall: FTS5 narrows candidates, embeddings rerank
        if not embeddings_only:
            recall_details = fts5_recall_details(main_conn, query, limit=recall)
            fts5_ordered = recall_details.conversation_ids
            fts5_ids = set(fts5_ordered)
            fts5_mode = recall_details.mode
            fts5_query = recall_details.fts_query

            if fts5_ids:
                # Remove active sessions from FTS5 recall set
                if excluded:
                    fts5_ids = fts5_ids - excluded
                if candidate_ids is not None:
                    intersected = fts5_ids & candidate_ids
                    candidate_ids = intersected if intersected else candidate_ids
                else:
                    candidate_ids = fts5_ids
    finally:
        main_conn.close()

    # Optional FTS5-only passthrough for exact-match structured queries.
    # Default remains pure hybrid (FTS5 recall -> embeddings scoring -> reranking).
    if (
        fts5_passthrough
        and not embeddings_only
        and fts5_query
        and fts5_ordered
        and fts5_mode in {"and", "or"}
    ):
        passthrough_ids: list[str] = []
        for conv_id in fts5_ordered:
            if excluded and conv_id in excluded:
                continue
            if candidate_ids is not None and conv_id not in candidate_ids:
                continue
            passthrough_ids.append(conv_id)
            if len(passthrough_ids) >= limit:
                break

        if len(passthrough_ids) >= limit:
            main_conn_fts = open_database(db, read_only=True)
            try:
                raw_results: list[dict] = []
                for conv_id in passthrough_ids[:limit]:
                    hit = fts5_best_hit_for_conversation(main_conn_fts, fts5_query, conversation_id=conv_id)
                    snippet = hit["snippet"] if hit else ""
                    rank = float(hit["rank"]) if hit and hit.get("rank") is not None else 0.0
                    score = -rank
                    raw_results.append(
                        {
                            "conversation_id": conv_id,
                            "score": score,
                            "text": snippet,
                            "chunk_type": "fts5",
                            "chunk_id": None,
                            "source_ids": None,
                            "breakdown": ScoreBreakdown(
                                embedding_sim=0.0,
                                pre_mmr_score=score,
                                final_score=score,
                                fts5_matched=True,
                                fts5_mode=fts5_mode,
                            ),
                        }
                    )

                meta_rows = batched_in_query(
                    main_conn_fts,
                    "SELECT c.id, c.started_at, w.path AS workspace FROM conversations c "
                    "LEFT JOIN workspaces w ON w.id = c.workspace_id "
                    "WHERE c.id IN ({placeholders})",
                    passthrough_ids[:limit],
                )
                meta = {row["id"]: dict(row) for row in meta_rows}
            finally:
                main_conn_fts.close()

            results: list[SearchResult] = []
            for r in raw_results:
                conv_id = r["conversation_id"]
                m = meta.get(conv_id, {})
                breakdown = r.get("breakdown")
                breakdown_dict = breakdown.to_dict() if breakdown and isinstance(breakdown, ScoreBreakdown) else None
                results.append(
                    SearchResult(
                        conversation_id=conv_id,
                        score=r["score"],
                        text=r["text"],
                        chunk_type=r["chunk_type"],
                        workspace_path=m.get("workspace"),
                        started_at=m.get("started_at"),
                        chunk_id=None,
                        source_ids=None,
                        breakdown=breakdown_dict,
                    )
                )

            return results

    # Embed query and search
    use_mmr = rerank == "mmr"
    embed_backend = get_backend(preferred=backend, verbose=False)
    try:
        query_embedding = embed_backend.embed_one(query)
    except (RuntimeError, ConnectionError, OSError):
        # Cached backend may have become unavailable (e.g., ollama stopped).
        # Invalidate and retry with fallback chain.
        from siftd.embeddings import invalidate_backend_cache

        invalidate_backend_cache()
        embed_backend = get_backend(preferred=backend, verbose=False)
        query_embedding = embed_backend.embed_one(query)

    # Fetch wider candidate set for MMR to select from
    search_limit = limit * 3 if use_mmr else limit

    # Pass excluded conversations to search_similar for score masking —
    # this guarantees they never appear in results regardless of chunk count.
    exclude_from_search = excluded if (excluded and candidate_ids is None) else None

    embed_conn = open_embeddings_db(embed_db, read_only=True)
    try:
        try:
            validate_index_compat(
                embed_conn,
                backend_name=embed_backend.name,
                backend_model=embed_backend.model,
                backend_dimension=embed_backend.dimension,
                current_schema_version=SCHEMA_VERSION,
            )
        except IndexCompatError:
            # Match CLI behavior: actionable error instead of silently returning wrong results.
            raise

        raw_results = search_similar(
            embed_conn,
            query_embedding,
            limit=search_limit,
            conversation_ids=candidate_ids,
            include_embeddings=use_mmr,
            exclude_conversation_ids=exclude_from_search,
        )
    finally:
        embed_conn.close()

    if not raw_results:
        return []

    # Annotate breakdown with FTS5 recall info (used by JSON output explainability)
    if fts5_ids is not None:
        for r in raw_results:
            breakdown = r.get("breakdown")
            if breakdown and isinstance(breakdown, ScoreBreakdown):
                matched = r["conversation_id"] in fts5_ids
                breakdown.fts5_matched = matched
                breakdown.fts5_mode = fts5_mode if matched else None

    # Apply temporal weighting if requested (before MMR so it affects reranking)
    if recency:
        from siftd.storage.queries import fetch_conversation_timestamps

        conv_ids_for_ts = list({r["conversation_id"] for r in raw_results})
        main_conn_ts = open_database(db, read_only=True)
        try:
            timestamps = fetch_conversation_timestamps(main_conn_ts, conv_ids_for_ts)
        finally:
            main_conn_ts.close()

        raw_results = apply_temporal_weight(
            raw_results,
            timestamps,
            half_life_days=recency_half_life,
            max_boost=recency_max_boost,
        )
        # Re-sort by weighted score (MMR does its own reranking)
        # Use chunk_id as deterministic tie-breaker (ULIDs sort by creation time)
        if not use_mmr:
            raw_results = sorted(raw_results, key=lambda r: (-r["score"], r.get("chunk_id", "")))

    # Apply MMR reranking if requested
    if use_mmr:
        # Cap candidates to prevent unbounded memory in np.vstack
        if len(raw_results) > MAX_MMR_CANDIDATES:
            print(
                f"Warning: Capping MMR candidates from {len(raw_results)} to {MAX_MMR_CANDIDATES}",
                file=sys.stderr,
            )
            # Keep top candidates by score
            raw_results = sorted(raw_results, key=lambda r: -r["score"])[:MAX_MMR_CANDIDATES]

        raw_results = mmr_rerank(
            raw_results,
            query_embedding,
            lambda_=lambda_,
            limit=limit,
        )

    # Enrich with metadata from main DB
    main_conn_meta = open_database(db, read_only=True)
    try:
        conv_ids = list({r["conversation_id"] for r in raw_results})
        meta_rows = batched_in_query(
            main_conn_meta,
            "SELECT c.id, c.started_at, w.path AS workspace FROM conversations c "
            "LEFT JOIN workspaces w ON w.id = c.workspace_id "
            "WHERE c.id IN ({placeholders})",
            conv_ids,
        )
    finally:
        main_conn_meta.close()
    meta = {row["id"]: dict(row) for row in meta_rows}

    results = []
    for r in raw_results:
        conv_id = r["conversation_id"]
        m = meta.get(conv_id, {})
        breakdown = r.get("breakdown")
        breakdown_dict = breakdown.to_dict() if breakdown and isinstance(breakdown, ScoreBreakdown) else None
        results.append(SearchResult(
            conversation_id=conv_id,
            score=r["score"],
            text=r["text"],
            chunk_type=r["chunk_type"],
            workspace_path=m.get("workspace"),
            started_at=m.get("started_at"),
            chunk_id=r.get("chunk_id"),
            source_ids=r.get("source_ids"),
            breakdown=breakdown_dict,
        ))

    return results


def filter_conversations(
    db: Path,
    *,
    workspace: str | None = None,
    model: str | None = None,
    since: str | None = None,
    before: str | None = None,
    tags: list[str] | None = None,
    all_tags: list[str] | None = None,
    exclude_tags: list[str] | None = None,
) -> set[str] | None:
    """Apply filters and return candidate conversation IDs.

    Returns None if no filters are applied (search all conversations).

    Args:
        db: Path to the database.
        workspace: Filter by workspace path substring.
        model: Filter by model name substring.
        since: Filter conversations started at or after this date.
        before: Filter conversations started before this date.
        tags: OR filter — conversations with any of these tags.
        all_tags: AND filter — conversations with all of these tags.
        exclude_tags: NOT filter — exclude conversations with any of these tags.

    Returns:
        Set of conversation IDs matching filters, or None if no filters.
    """
    if not any([workspace, model, since, before, tags, all_tags, exclude_tags]):
        return None

    conn = open_database(db, read_only=True)
    try:
        return _filter_conversations_conn(
            conn, workspace=workspace, model=model, since=since, before=before,
            tags=tags, all_tags=all_tags, exclude_tags=exclude_tags,
        )
    finally:
        conn.close()


def _filter_conversations_conn(
    conn,
    *,
    workspace: str | None = None,
    model: str | None = None,
    since: str | None = None,
    before: str | None = None,
    tags: list[str] | None = None,
    all_tags: list[str] | None = None,
    exclude_tags: list[str] | None = None,
) -> set[str] | None:
    """Internal: filter conversations using an existing connection."""
    if not any([workspace, model, since, before, tags, all_tags, exclude_tags]):
        return None

    wb = WhereBuilder()
    wb.workspace(workspace)
    wb.model(model)
    wb.since(since)
    wb.before(before)
    wb.tags_any(tags)
    wb.tags_all(all_tags)
    wb.tags_none(exclude_tags)

    sql = f"""
        SELECT DISTINCT c.id
        FROM conversations c
        LEFT JOIN workspaces w ON w.id = c.workspace_id
        LEFT JOIN responses r ON r.conversation_id = c.id
        LEFT JOIN models m ON m.id = r.model_id
        {wb.where_sql()}
    """

    rows = conn.execute(sql, wb.params).fetchall()
    return {row["id"] for row in rows}


_active_ids_cache: tuple[float, Path, set[str]] | None = None
_ACTIVE_IDS_TTL = 5.0  # seconds — short enough to track session changes, long enough to help batch use


def get_active_conversation_ids(db: Path) -> set[str]:
    """Get conversation IDs that originated from currently-active session files.

    Uses list_active_sessions() from the peek module to find active JSONL files,
    then looks up which ingested conversations came from those file paths.

    Results are cached for 5 seconds to avoid repeated filesystem scans
    when called in tight loops (e.g., batch search).

    Args:
        db: Path to the main database.

    Returns:
        Set of conversation IDs to exclude (may be empty).
    """
    import time as _time

    global _active_ids_cache
    now = _time.monotonic()
    if _active_ids_cache is not None:
        cached_time, cached_db, cached_ids = _active_ids_cache
        if cached_db == db and (now - cached_time) < _ACTIVE_IDS_TTL:
            return cached_ids

    try:
        from siftd.peek.scanner import list_active_sessions
    except ImportError:
        _active_ids_cache = (now, db, set())
        return set()

    try:
        sessions = list_active_sessions(include_inactive=False)
    except Exception:
        # Filesystem scan failed — don't block search
        _active_ids_cache = (now, db, set())
        return set()

    if not sessions:
        _active_ids_cache = (now, db, set())
        return set()

    file_paths = [str(s.file_path) for s in sessions]

    conn = open_database(db, read_only=True)
    try:
        rows = batched_in_query(
            conn,
            "SELECT conversation_id FROM ingested_files WHERE path IN ({placeholders}) AND conversation_id IS NOT NULL",
            file_paths,
        )
    finally:
        conn.close()

    result = {row["conversation_id"] for row in rows}
    _active_ids_cache = (now, db, result)
    return result
