"""
Planning Operator

Middleware operator for planning using runtime components.

Supports engine_type switching:
- sagellm (default): SageLLMGenerator via single inference service port
- openai: OpenAIGenerator for OpenAI-compatible APIs
- hf: HFGenerator for HuggingFace models
"""

from typing import Any

from sage.common.core.functions import MapFunction

from .runtime import _build_generator


class PlanningOperator(MapFunction):
    """
    Operator for planning.

    Wraps runtime planner in a middleware operator interface.

    Args:
        planner: Planner instance (optional)
        config: Configuration dictionary with optional keys:
            - planner: Planner-specific config
            - generator: Generator config with engine_type
            - engine_type: Shorthand for generator.engine_type (sagellm/openai/hf)

    Example:
        ```python
        # Using sagellm service-port mode
        operator = PlanningOperator(config={
            "generator": {
                "engine_type": "sagellm",
                "model_path": "Qwen/Qwen2.5-7B-Instruct",
            },
        })

        # Using default sagellm mode
        operator = PlanningOperator(config={
            "engine_type": "sagellm",
        })
        ```
    """

    def __init__(
        self,
        planner: Any | None = None,
        config: dict[str, Any] | None = None,
    ):
        """Initialize planning operator.

        Args:
            planner: Planner instance (optional)
            config: Configuration dictionary
        """
        super().__init__()

        # Parse configuration
        if config is None:
            config = {}

        self.config = config

        # Build generator if config provided
        generator_conf = config.get("generator", {})
        # Allow shorthand engine_type at top level
        if "engine_type" in config and "engine_type" not in generator_conf:
            generator_conf["engine_type"] = config["engine_type"]

        # Build generator (defaults to sagellm service-port mode)
        if generator_conf or not planner:
            engine_type = generator_conf.get("engine_type", "sagellm")
            # Ensure we have at least minimal config
            if not generator_conf:
                generator_conf = {"engine_type": "sagellm"}
            self.generator = _build_generator(generator_conf, engine_type=engine_type)
        else:
            self.generator = None

        try:
            from sage_libs.sage_agentic.agents.runtime import (
                BenchmarkAdapter,
                Orchestrator,
                RuntimeConfig,
            )
            from sage_libs.sage_agentic.agents.runtime.config import PlannerConfig
        except ImportError as exc:
            raise ImportError(
                "PlanningOperator requires 'isage-agentic'. "
                "Install it with: pip install isage-agentic"
            ) from exc
        planner_config = PlannerConfig(**config.get("planner", {}))
        runtime_config = RuntimeConfig(planner=planner_config)

        # Create orchestrator
        self.orchestrator = Orchestrator(config=runtime_config, planner=planner)

        # Create adapter for easy use
        self.adapter = BenchmarkAdapter(self.orchestrator)

    def __call__(self, request: Any) -> Any:
        """Execute planning.

        Args:
            request: Planning request

        Returns:
            Generated plan
        """
        return self.adapter.run_planning(request)

    def execute(self, data: Any) -> Any:
        """Execute map function interface."""
        return self.__call__(data)

    def get_metrics(self) -> dict[str, Any]:
        """Get performance metrics.

        Returns:
            Dictionary of metrics
        """
        return self.adapter.get_metrics()
