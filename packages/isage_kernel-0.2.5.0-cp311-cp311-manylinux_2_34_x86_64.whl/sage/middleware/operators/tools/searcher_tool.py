"""Bocha search streaming operators for SAGE middleware pipelines.

These operators wrap ``sage.tools.BochaSearcher`` inside SAGE streaming
``MapFunction`` operators so they can be used directly in SAGE flownet
pipelines.  All raw API interaction is handled by ``sage.tools.BochaSearcher``
(in the ``isage-tools`` package); this module focuses exclusively on
``ModelContext`` integration.

For standalone / agent use (no pipeline), import from ``sage.tools`` instead::

    from sage.tools import BochaSearcher
    results = BochaSearcher().execute("latest RAG benchmarks")
"""

from __future__ import annotations

import os
import time
from typing import Any

from sage.common.core.functions import MapFunction as MapOperator
from sage.middleware.operators.context.model_context import ModelContext
from sage.middleware.operators.context.search_result import SearchResult
from sage.middleware.operators.context.search_session import SearchSession


def _build_searcher(config: dict):
    """Lazily import and construct a BochaSearcher from sage.tools."""
    try:
        from sage.tools.bocha_searcher import BochaSearcher
    except ImportError as exc:
        raise ImportError(
            "BochaSearchTool requires 'isage-tools'. Install with: pip install isage-tools"
        ) from exc

    return BochaSearcher(
        api_key=config.get("api_key", os.getenv("BOCHA_API_KEY")),
        api_url=config.get("url", "https://api.bochasearch.com/search"),
        timeout=config.get("timeout", 30),
    )


class BochaSearchTool(MapOperator):
    """Bocha search operator for SAGE streaming pipelines.

    Reads search queries from a :class:`ModelContext`, calls the Bocha API via
    :class:`sage.tools.BochaSearcher`, and writes structured
    :class:`SearchResult` objects back into the context.

    For standalone (non-pipeline) use, prefer :class:`sage.tools.BochaSearcher`
    directly.

    Args:
        config: Operator configuration dict. Recognised keys:

            - ``api_key``               — Bocha API key (falls back to
              ``BOCHA_API_KEY`` env var).
            - ``url``                   — Override the Bocha endpoint.
            - ``timeout``               — HTTP timeout (seconds, default 30).
            - ``max_results_per_query`` — Results per query (default 3).
            - ``search_engine_name``    — Label stored in the SearchSession
              (default "Bocha").
    """

    def __init__(self, config: dict, **kwargs):
        super().__init__(**kwargs)

        self._searcher = _build_searcher(config)
        self.max_results_per_query: int = config.get("max_results_per_query", 3)
        self.search_engine_name: str = config.get("search_engine_name", "Bocha")
        self.search_count: int = 0

        self.logger.info(
            "BochaSearchTool initialised — max_results_per_query=%d",
            self.max_results_per_query,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _search_and_convert(self, query: str) -> tuple[list[SearchResult], int, int]:
        """Call BochaSearcher and convert results to SearchResult objects.

        Returns:
            (search_results, execution_time_ms, api_total_count)
        """
        t0 = time.monotonic()
        raw: list[dict[str, Any]] = self._searcher.execute(
            query, max_results=self.max_results_per_query
        )
        execution_time_ms = int((time.monotonic() - t0) * 1000)

        if not raw:
            return (
                [
                    SearchResult(
                        title=f"No Results for '{query}'",
                        content=f"No search results found for query: '{query}'",
                        source="Search Engine",
                        rank=1,
                        relevance_score=0.0,
                    )
                ],
                execution_time_ms,
                0,
            )

        results: list[SearchResult] = []
        for item in raw:
            relevance_score = max(0.1, 1.0 - (item["rank"] - 1) * 0.1)
            results.append(
                SearchResult(
                    title=item["title"] or "No Title",
                    content=item["snippet"] or "No content available",
                    source=item["url"] or "No URL",
                    rank=item["rank"],
                    relevance_score=relevance_score,
                )
            )
        return results, execution_time_ms, len(raw)

    def _create_legacy_chunks_for_compatibility(self, search_session: SearchSession) -> list[str]:
        """Build legacy retriver_chunks strings for backward compatibility."""
        chunks: list[str] = []
        for qr in search_session.query_results:
            for result in qr.results:
                chunks.append(
                    f"[Search Result {result.rank} for '{qr.query}']\n"
                    f"Title: {result.title}\n"
                    f"Content: {result.content}\n"
                    f"Source: {result.source}"
                )
        return chunks

    # ------------------------------------------------------------------
    # MapOperator interface
    # ------------------------------------------------------------------

    def execute(self, context: ModelContext) -> ModelContext:
        """Execute Bocha search and populate the ModelContext with results."""
        try:
            search_queries = context.get_search_queries()
            self.logger.debug(
                "BochaSearchTool processing %d queries for context %s",
                len(search_queries),
                context.uuid,
            )

            if not search_queries:
                self.logger.info("No search queries provided, returning original context")
                return context

            if not context.search_session:
                context.create_search_session(context.raw_question)

            total_results = 0

            for query in search_queries:
                search_results, execution_time_ms, api_count = self._search_and_convert(query)
                context.add_search_results(
                    query=query,
                    results=search_results,
                    search_engine=self.search_engine_name,
                    execution_time_ms=execution_time_ms,
                    total_results_count=api_count,
                )
                total_results += len(search_results)
                self.logger.debug("Query '%s' returned %d results", query, len(search_results))

            # Update legacy retriver_chunks for backward compat
            if context.search_session:
                legacy_chunks = self._create_legacy_chunks_for_compatibility(context.search_session)
                if context.retriver_chunks is None:
                    context.retriver_chunks = []
                context.retriver_chunks.extend(legacy_chunks)

            self.search_count += 1
            self.logger.info(
                "Search completed: queries=%d total_results=%d context=%s",
                len(search_queries),
                total_results,
                context.uuid,
            )
            context.update_tool_config(
                {
                    "bocha_search_info": {
                        "bocha_search_executed": True,
                        "queries_count": len(search_queries),
                        "total_results": total_results,
                        "search_engine": self.search_engine_name,
                        "execution_timestamp": int(time.time() * 1000),
                        "session_id": (
                            context.search_session.session_id if context.search_session else None
                        ),
                    }
                }
            )
            return context

        except Exception as exc:
            self.logger.error("BochaSearchTool execution failed: %s", exc, exc_info=True)
            context.update_tool_config(
                {
                    "bocha_search_error": {
                        "error": str(exc),
                        "error_timestamp": int(time.time() * 1000),
                    }
                }
            )
            return context


class EnhancedBochaSearchTool(BochaSearchTool):
    """Enhanced Bocha search operator with deduplication and result-count limiting.

    Extends :class:`BochaSearchTool` with post-processing:

    - **Deduplication** — removes results that are too similar by URL or
      vocabulary overlap.
    - **Minimum relevance filtering** — drops results below a relevance
      score threshold.
    - **Total-result cap** — keeps the highest-scoring results up to
      ``max_total_chunks``.

    Args:
        config: Same as :class:`BochaSearchTool`, plus:

            - ``deduplicate_results``  — enable deduplication (default True).
            - ``max_total_chunks``     — maximum total results across all
              queries (default 20).
            - ``min_relevance_score``  — minimum relevance score to keep
              (default 0.1).
            - ``diversity_threshold``  — Jaccard similarity above which two
              results are considered duplicates (default 0.8).
    """

    def __init__(self, config: dict, **kwargs):
        super().__init__(config, **kwargs)

        self.deduplicate_results: bool = config.get("deduplicate_results", True)
        self.max_total_chunks: int = config.get("max_total_chunks", 20)
        self.min_relevance_score: float = config.get("min_relevance_score", 0.1)
        self.diversity_threshold: float = config.get("diversity_threshold", 0.8)

        self.logger.info(
            "EnhancedBochaSearchTool initialised — deduplicate=%s max_total=%d min_relevance=%s",
            self.deduplicate_results,
            self.max_total_chunks,
            self.min_relevance_score,
        )

    # ------------------------------------------------------------------
    # Deduplication helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _jaccard(text_a: str, text_b: str) -> float:
        words_a = set(text_a.lower().split())
        words_b = set(text_b.lower().split())
        if not words_a or not words_b:
            return 0.0
        return len(words_a & words_b) / len(words_a | words_b)

    def _deduplicate(self, results: list[SearchResult]) -> list[SearchResult]:
        if not self.deduplicate_results or not results:
            return results

        sorted_r = sorted(results, key=lambda r: r.relevance_score, reverse=True)
        kept: list[SearchResult] = []
        seen_sources: set[str] = set()

        for result in sorted_r:
            if result.source in seen_sources:
                continue
            if result.relevance_score < self.min_relevance_score:
                continue
            if any(
                self._jaccard(result.content, k.content) > self.diversity_threshold for k in kept
            ):
                continue
            kept.append(result)
            seen_sources.add(result.source)

        kept.sort(key=lambda r: r.rank)
        return kept

    def _limit_total(self, context: ModelContext) -> None:
        if not context.search_session:
            return

        total = context.search_session.get_total_results_count()
        if total <= self.max_total_chunks:
            return

        all_pairs = [(qr, r) for qr in context.search_session.query_results for r in qr.results]
        all_pairs.sort(key=lambda x: x[1].relevance_score, reverse=True)

        for qr in context.search_session.query_results:
            qr.results = []

        slots_per_query = self.max_total_chunks // len(context.search_session.query_results)
        extra = self.max_total_chunks % len(context.search_session.query_results)
        counts: dict = dict.fromkeys(context.search_session.query_results, 0)
        placed = 0

        for qr, result in all_pairs:
            cap = slots_per_query + (1 if extra > 0 else 0)
            if counts[qr] < cap:
                qr.results.append(result)
                counts[qr] += 1
                if counts[qr] == cap and extra > 0:
                    extra -= 1
                placed += 1
                if placed >= self.max_total_chunks:
                    break

        self.logger.info("Limited search results from %d to %d", total, placed)

    def _rebuild_legacy_chunks(self, context: ModelContext) -> None:
        if not context.search_session:
            return
        new_chunks = self._create_legacy_chunks_for_compatibility(context.search_session)
        non_search = [
            c for c in (context.retriver_chunks or []) if not c.strip().startswith("[Search Result")
        ]
        context.retriver_chunks = non_search + new_chunks

    # ------------------------------------------------------------------
    # MapOperator interface
    # ------------------------------------------------------------------

    def execute(self, context: ModelContext) -> ModelContext:
        try:
            context = super().execute(context)

            if context.search_session and context.search_session.query_results:
                for qr in context.search_session.query_results:
                    qr.results = self._deduplicate(qr.results)

                self._limit_total(context)
                self._rebuild_legacy_chunks(context)

                final_count = context.search_session.get_total_results_count()
                context.update_tool_config(
                    {
                        "enhanced_search_info": {
                            "enhanced_search_applied": True,
                            "deduplicate_results": self.deduplicate_results,
                            "max_total_chunks": self.max_total_chunks,
                            "min_relevance_score": self.min_relevance_score,
                            "final_results_count": final_count,
                            "final_chunks_count": (
                                len(context.retriver_chunks) if context.retriver_chunks else 0
                            ),
                        }
                    }
                )
                self.logger.info(
                    "Enhanced search completed: %d results, %d chunks",
                    final_count,
                    len(context.retriver_chunks) if context.retriver_chunks else 0,
                )

            return context

        except Exception as exc:
            self.logger.error("EnhancedBochaSearchTool execution failed: %s", exc, exc_info=True)
            context.update_tool_config(
                {
                    "enhanced_search_error": {
                        "error": str(exc),
                        "error_timestamp": int(time.time() * 1000),
                        "fallback_to_basic": True,
                    }
                }
            )
            return context
