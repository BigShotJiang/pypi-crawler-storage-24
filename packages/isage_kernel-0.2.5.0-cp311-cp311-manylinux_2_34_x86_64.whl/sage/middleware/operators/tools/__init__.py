"""Middleware-native tool operators.

``sage.middleware.operators.tools`` now contains only tools that depend on
middleware-specific context types.

The generic search / scraping / OCR tools were migrated to ``isage-tools`` and
must be imported from ``sage.tools`` instead.
"""

from sage.middleware.operators.tools.searcher_tool import BochaSearchTool

__all__ = ["BochaSearchTool"]
