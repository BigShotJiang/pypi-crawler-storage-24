"""
SAGE Flow - High-performance vector stream processing engine (Python wrapper)

This module re-exports SageFlow classes from the isage-flow PyPI package.
"""

from sage.middleware.components.sage_flow import require_sage_flow

_sage_flow = require_sage_flow()

DataType = _sage_flow.DataType
SimpleStreamSource = _sage_flow.SimpleStreamSource
Stream = _sage_flow.Stream
StreamEnvironment = _sage_flow.StreamEnvironment
VectorData = _sage_flow.VectorData
VectorRecord = _sage_flow.VectorRecord
__author__ = _sage_flow.__author__
__email__ = _sage_flow.__email__
__version__ = _sage_flow.__version__

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    "StreamEnvironment",
    "Stream",
    "SimpleStreamSource",
    "VectorData",
    "VectorRecord",
    "DataType",
]
