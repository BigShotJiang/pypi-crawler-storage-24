"""SageFlow 兼容命名空间。

该目录仅保留历史导入路径所需的轻量 Python 包装层，
真正的底层实现来自外部 `isage-flow` 包（导入名：`sage_flow`）。
"""

__all__ = ["sage_flow", "micro_service"]
