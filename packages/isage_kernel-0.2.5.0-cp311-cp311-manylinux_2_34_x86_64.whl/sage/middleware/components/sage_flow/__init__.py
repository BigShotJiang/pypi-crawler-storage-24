"""SageFlow compatibility layer for SAGE.

SageFlow 的 Python API 已迁移到独立 PyPI 包 `isage-flow`（导入名：`sage_flow`）。
本模块只保留向后兼容导出与 SAGE 侧辅助封装，不再承载本地 `_sage_flow` 扩展实现。

安装：
    pip install isage-flow
"""

from __future__ import annotations

from types import ModuleType

_SAGE_FLOW_AVAILABLE = False
_SAGE_FLOW_IMPORT_ERROR: str | None = None
_sage_flow_module: ModuleType | None = None

try:
    import sage_flow as _sage_flow_module
    from sage_flow import (
        DataType,
        SimpleStreamSource,
        Stream,
        StreamEnvironment,
        VectorData,
        VectorRecord,
        __author__,
        __email__,
        __version__,
    )

    _SAGE_FLOW_AVAILABLE = True
except ImportError as e:
    _SAGE_FLOW_IMPORT_ERROR = str(e)
    DataType = None
    SimpleStreamSource = None
    Stream = None
    StreamEnvironment = None
    VectorData = None
    VectorRecord = None
    __version__ = "unavailable"
    __author__ = "IntelliStream Team"
    __email__ = "shuhao_zhang@hust.edu.cn"

if _SAGE_FLOW_AVAILABLE:
    from .python.micro_service.sage_flow_service import SageFlowService
else:
    SageFlowService = None


def require_sage_flow() -> ModuleType:
    """返回 `sage_flow` 模块；若未安装则抛出带指引的错误。"""
    if _sage_flow_module is None:
        message = "SAGE Flow 不可用。请先安装独立包：\n  pip install isage-flow"
        if _SAGE_FLOW_IMPORT_ERROR:
            message += f"\n原始错误: {_SAGE_FLOW_IMPORT_ERROR}"
        raise ImportError(message)
    return _sage_flow_module


__all__ = [
    # Core API from isage-flow (may be None if not installed)
    "StreamEnvironment",
    "Stream",
    "SimpleStreamSource",
    "VectorData",
    "VectorRecord",
    "DataType",
    "__version__",
    "__author__",
    "__email__",
    # SAGE-specific services (may be None if isage-flow not installed)
    "SageFlowService",
    "require_sage_flow",
    # Availability flag
    "_SAGE_FLOW_AVAILABLE",
]


def __getattr__(name: str):
    """为未安装 `isage-flow` 时的兼容导入提供友好错误。"""
    if name in __all__ and not _SAGE_FLOW_AVAILABLE:
        raise ImportError("SAGE Flow 不可用。请安装独立包：pip install isage-flow")
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
