"""
SageFlow Middleware Service

This module provides the middleware service interface for SageFlow,
wrapping the external `isage-flow` Python package for SAGE integrations.
"""

from . import DataType, SimpleStreamSource, Stream, StreamEnvironment, VectorData, VectorRecord
from .python.micro_service.sage_flow_service import SageFlowService

__all__ = [
    "StreamEnvironment",
    "Stream",
    "SimpleStreamSource",
    "VectorData",
    "VectorRecord",
    "DataType",
    "SageFlowService",
]
