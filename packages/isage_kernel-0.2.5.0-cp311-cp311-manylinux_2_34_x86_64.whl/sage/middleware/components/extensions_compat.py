"""SAGE Middleware Components - 运行时兼容性检测。

该模块统一检测独立能力包是否可用：
- `isage-vdb`   -> `sagevdb`
- `isage-flow`  -> `sage_flow`
- `isage-tsdb`  -> `sage_tsdb`
"""

from typing import TYPE_CHECKING, Any

# 类型检查时导入，运行时通过try/except处理
if TYPE_CHECKING:
    from types import ModuleType
else:
    ModuleType = Any
    _sage_flow: ModuleType | None = None

# 尝试导入C++扩展，失败时使用纯Python实现
_SAGE_DB_AVAILABLE = False  # 通过 isage-vdb 包检测 (Python: sagevdb)
_SAGE_FLOW_AVAILABLE = False  # 通过 isage-flow 包检测 (Python: sage_flow)
_SAGE_TSDB_AVAILABLE = False  # 通过 isage-tsdb 包检测

if not TYPE_CHECKING:
    # SageVDB 现在是独立的 PyPI 包 (PyPI: isage-vdb, Python: sagevdb)
    try:
        import sagevdb  # noqa: F401

        _SAGE_DB_AVAILABLE = True
    except ImportError:
        # Don't warn on import - only when trying to use the feature
        pass

    try:
        import sage_flow as _sage_flow

        _SAGE_FLOW_AVAILABLE = True
    except ImportError:
        _sage_flow = None
        pass

    # SageTSDB 现在是独立的 PyPI 包
    try:
        import sage_tsdb  # noqa: F401

        _SAGE_TSDB_AVAILABLE = True
    except ImportError:
        # Don't warn on import - only when trying to use the feature
        pass


def is_sage_db_available() -> bool:
    """检查SAGE DB扩展是否可用"""
    return _SAGE_DB_AVAILABLE


def is_sage_flow_available() -> bool:
    """检查SAGE Flow扩展是否可用"""
    return _SAGE_FLOW_AVAILABLE


def is_sage_tsdb_available() -> bool:
    """检查SAGE TSDB扩展是否可用"""
    return _SAGE_TSDB_AVAILABLE


def get_extension_status() -> dict:
    """获取所有扩展的状态"""
    return {
        "sage_db": _SAGE_DB_AVAILABLE,
        "sage_flow": _SAGE_FLOW_AVAILABLE,
        "sage_tsdb": _SAGE_TSDB_AVAILABLE,
        "total_available": sum([_SAGE_DB_AVAILABLE, _SAGE_FLOW_AVAILABLE, _SAGE_TSDB_AVAILABLE]),
        "total_extensions": 3,
    }


def check_extensions_availability() -> dict:
    """检查扩展可用性，返回兼容格式用于CI"""
    return {
        "sage_db": _SAGE_DB_AVAILABLE,
        "sage_flow": _SAGE_FLOW_AVAILABLE,
        "sage_tsdb": _SAGE_TSDB_AVAILABLE,
    }


def require_sage_db():
    """要求SageVDB可用，否则抛出异常"""
    if not _SAGE_DB_AVAILABLE:
        raise ImportError(
            "此功能需要 SageVDB。请安装:\n"
            "  pip install isage-vdb\n"
            "注意: PyPI 包名是 'isage-vdb'，Python 导入名是 'sagevdb'"
        )
    import sagevdb

    return sagevdb


def require_sage_flow():
    """要求 SAGE Flow 可用，否则抛出异常。"""
    if not _SAGE_FLOW_AVAILABLE:
        raise ImportError("此功能需要 SAGE Flow 独立包。请安装：\n  pip install isage-flow")
    return _sage_flow


def require_sage_tsdb():
    """要求SAGE TSDB可用，否则抛出异常"""
    if not _SAGE_TSDB_AVAILABLE:
        raise ImportError("此功能需要 SAGE TSDB。请安装: pip install isage-tsdb")
    import sage_tsdb

    return sage_tsdb


# 在模块导入时显示状态（仅在明确导入时）
# 避免在用户导入其他模块时显示无关警告
if __name__ == "__main__":
    status = get_extension_status()
    if status["total_available"] < status["total_extensions"]:
        print(f"ℹ️  SAGE扩展状态: {status['total_available']}/{status['total_extensions']} 可用")
        if not _SAGE_DB_AVAILABLE:
            print("  ❌ SageVDB: 未安装 (pip install isage-vdb)")
        if not _SAGE_FLOW_AVAILABLE:
            print("  ❌ SAGE Flow: 未安装 (pip install isage-flow)")
        if not _SAGE_TSDB_AVAILABLE:
            print("  ❌ SAGE TSDB: 未安装 (pip install isage-tsdb)")
        print("  💡 提示: 安装相应依赖可启用完整功能")
