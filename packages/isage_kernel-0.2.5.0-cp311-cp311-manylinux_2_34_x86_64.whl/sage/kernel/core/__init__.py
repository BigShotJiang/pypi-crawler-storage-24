"""
Kernel Core Module - 共享类型、异常和常量

这个模块包含 sage-kernel 中各个子模块共享的核心定义。
"""

from sage.kernel.core.constants import (
    DEFAULT_CHECKPOINT_INTERVAL,
    DEFAULT_CLEANUP_TIMEOUT,
    DEFAULT_HEALTH_CHECK_INTERVAL,
    DEFAULT_MAX_RESTART_ATTEMPTS,
    PLACEMENT_STRATEGY_LOAD_BALANCE,
    PLACEMENT_STRATEGY_RESOURCE_AWARE,
    PLACEMENT_STRATEGY_SIMPLE,
    RESTART_STRATEGY_EXPONENTIAL,
    RESTART_STRATEGY_FAILURE_RATE,
    RESTART_STRATEGY_FIXED,
    SCHEDULING_STRATEGY_FIFO,
    SCHEDULING_STRATEGY_PRIORITY,
    SCHEDULING_STRATEGY_RESOURCE_AWARE,
)
from sage.kernel.core.exceptions import (
    CheckpointError,
    FaultToleranceError,
    KernelError,
    PlacementError,
    RecoveryError,
    ResourceAllocationError,
    SchedulingError,
)
from sage.kernel.core.types import (
    ExecutionMode,
    JobID,
    JobStatus,
    NodeID,
    QueueID,
    ServiceID,
    ServiceType,
    T,
    TaskID,
    TaskStatus,
    TaskType,
)

__all__ = [
    # Types
    "ExecutionMode",
    "TaskStatus",
    "JobStatus",
    "TaskID",
    "ServiceID",
    "NodeID",
    "QueueID",
    "JobID",
    "T",
    "TaskType",
    "ServiceType",
    # Exceptions
    "KernelError",
    "SchedulingError",
    "FaultToleranceError",
    "ResourceAllocationError",
    "RecoveryError",
    "CheckpointError",
    "PlacementError",
    # Constants
    "DEFAULT_CHECKPOINT_INTERVAL",
    "DEFAULT_HEALTH_CHECK_INTERVAL",
    "DEFAULT_MAX_RESTART_ATTEMPTS",
    "DEFAULT_CLEANUP_TIMEOUT",
    "RESTART_STRATEGY_FIXED",
    "RESTART_STRATEGY_EXPONENTIAL",
    "RESTART_STRATEGY_FAILURE_RATE",
    "PLACEMENT_STRATEGY_SIMPLE",
    "PLACEMENT_STRATEGY_RESOURCE_AWARE",
    "PLACEMENT_STRATEGY_LOAD_BALANCE",
    "SCHEDULING_STRATEGY_FIFO",
    "SCHEDULING_STRATEGY_PRIORITY",
    "SCHEDULING_STRATEGY_RESOURCE_AWARE",
]
