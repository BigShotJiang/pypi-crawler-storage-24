from __future__ import annotations

from typing import Any


def create_default_scheduler(*, platform: str):
    """Create the canonical default scheduler for kernel runtime.

    Args:
        platform: Execution platform name, e.g. "local" or "remote".

    Returns:
        BaseScheduler instance.
    """
    from sage.kernel.scheduler.impl import FIFOScheduler

    return FIFOScheduler(platform=platform)


def resolve_scheduler(*, scheduler: Any, platform: str):
    """Resolve a scheduler input to a concrete BaseScheduler instance.

    Accepted forms:
    - ``None``: default FIFO scheduler
    - ``str``: "fifo" or "load_aware" / "loadaware"
    - ``BaseScheduler`` instance
    """
    from sage.kernel.scheduler.api import BaseScheduler
    from sage.kernel.scheduler.impl import FIFOScheduler, LoadAwareScheduler

    if scheduler is None:
        return FIFOScheduler(platform=platform)

    if isinstance(scheduler, str):
        scheduler_lower = scheduler.lower()
        if scheduler_lower == "fifo":
            return FIFOScheduler(platform=platform)
        if scheduler_lower in ["load_aware", "loadaware"]:
            return LoadAwareScheduler(platform=platform)
        raise ValueError(
            f"Unknown scheduler type: {scheduler}. Available options: 'fifo', 'load_aware'"
        )

    if isinstance(scheduler, BaseScheduler):
        return scheduler

    raise TypeError(
        f"scheduler must be None, str, or BaseScheduler instance, got {type(scheduler)}"
    )
