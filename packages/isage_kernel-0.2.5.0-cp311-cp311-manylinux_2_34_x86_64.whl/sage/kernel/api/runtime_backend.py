"""Shared runtime backend access helpers for sage-kernel API tiers.

This module centralizes runtime-backend acquisition so both:

- `sage.kernel.facade` (default tier)
- `sage.kernel.api.FlownetEnvironment` (advanced tier)

route through the same protocol-adapter entry point.

The primary adapter is now **flutty** (``FluttyRuntimeAdapter``).
The legacy ``get_flownet_runtime_backend()`` name is kept as a deprecated
alias for backward compatibility.
"""

from __future__ import annotations

import warnings
from typing import Any


def get_runtime_backend() -> Any:
    """Return the process-global flutty runtime adapter.

    Returns:
        RuntimeBackendProtocol-compatible ``FluttyRuntimeAdapter`` instance.

    Raises:
        ImportError: If flutty adapter module is unavailable.
    """
    from sage.platform.runtime.adapters.flutty_adapter import get_flutty_adapter

    return get_flutty_adapter()


def get_flownet_runtime_backend() -> Any:
    """Deprecated alias for :func:`get_runtime_backend`.

    .. deprecated::
        Use :func:`get_runtime_backend` instead.
    """
    warnings.warn(
        "get_flownet_runtime_backend() is deprecated; use get_runtime_backend() instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return get_runtime_backend()
