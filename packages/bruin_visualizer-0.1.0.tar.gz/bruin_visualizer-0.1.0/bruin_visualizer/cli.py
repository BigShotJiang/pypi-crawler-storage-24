"""
CLI interface for bruin-visualizer
"""

import argparse
import sys
import webbrowser
from pathlib import Path
from .parser import BruinParser
from .log_parser import BruinLogParser
from .server import start_server


def cmd_parse(args):
    """Parse a Bruin pipeline and generate visualization data"""
    pipeline_path = args.pipeline_path
    output_file = args.output or "pipeline_graph.json"
    
    print(f"Parsing pipeline: {pipeline_path}")
    parser = BruinParser(pipeline_path)
    parser.export_for_visualization(output_file)
    print(f"\nDone! Generated {output_file}")
    print(f"Run 'bruin-viz serve' to view the visualization")


def cmd_serve(args):
    """Start the visualization server"""
    port = args.port
    
    # Check if HTML file exists in current directory
    current_html = Path("bruin-visualizer-history.html")
    
    if not current_html.exists():
        # Copy from package to current directory
        static_dir = Path(__file__).parent / "static"
        html_file = static_dir / "bruin-visualizer-history.html"
        
        if not html_file.exists():
            print(f"Error: Could not find {html_file}")
            print("Make sure the package is installed correctly.")
            sys.exit(1)
        
        import shutil
        print(f"Copying bruin-visualizer-history.html to current directory...")
        shutil.copy(html_file, current_html)
    
    # Check for data files
    if not Path("pipeline_graph.json").exists():
        print("Warning: pipeline_graph.json not found")
        print("Run: bruin-viz parse <pipeline-path>")
        print()
    
    if not Path("bruin_history.db").exists():
        print("Note: bruin_history.db not found (run history will be empty)")
        print("To track runs: bruin-viz run <pipeline-path> --start-date YYYY-MM-DD --end-date YYYY-MM-DD")
        print()
    
    import os
    print(f"Starting Bruin Visualizer on http://localhost:{port}")
    print(f"Serving from: {os.getcwd()}")
    print(f"\nWeb UI: http://localhost:{port}/bruin-visualizer-history.html")
    print("\nPress Ctrl+C to stop\n")
    
    if not args.no_browser:
        webbrowser.open(f'http://localhost:{port}/bruin-visualizer-history.html')
    
    start_server(port)


def cmd_run(args):
    """Run a Bruin pipeline with history tracking"""
    pipeline_path = args.pipeline_path
    db_path = args.db or "bruin_history.db"
    
    # Build flags list from args
    flags = []
    if args.start_date:
        flags.extend(['--start-date', args.start_date])
    if args.end_date:
        flags.extend(['--end-date', args.end_date])
    if args.full_refresh:
        flags.append('--full-refresh')
    if args.workers:
        flags.extend(['--workers', str(args.workers)])
    
    # Get DuckDB config path
    duckdb_config_path = None
    bruin_config = Path('.bruin.yml')
    if bruin_config.exists():
        try:
            import yaml
            with open(bruin_config) as f:
                config = yaml.safe_load(f)
                default_env = config.get('default_environment', 'default')
                connections = config.get('environments', {}).get(default_env, {}).get('connections', {})
                duckdb_conns = connections.get('duckdb', [])
                if duckdb_conns:
                    duckdb_config_path = duckdb_conns[0].get('path', 'duckdb.db')
        except Exception as e:
            print(f"Warning: Could not read DuckDB config: {e}")
    
    parser = BruinLogParser(db_path, duckdb_config_path)
    exit_code = parser.run_and_track(pipeline_path, flags)
    
    print("\n" + "=" * 60)
    print(f"Run history saved to {db_path}")
    print("View history: bruin-viz serve")
    
    sys.exit(exit_code)


def cmd_init(args):
    """Initialize bruin-visualizer in current directory"""
    output_dir = Path(args.output_dir or ".")
    
    # Create directory if it doesn't exist
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Copy HTML file
    static_dir = Path(__file__).parent / "static"
    html_file = static_dir / "bruin-visualizer-history.html"
    
    if html_file.exists():
        import shutil
        dest = output_dir / "bruin-visualizer-history.html"
        shutil.copy(html_file, dest)
        print(f"Created {dest}")
    
    # Create empty database
    from .history import BruinRunHistory
    db_path = output_dir / "bruin_history.db"
    BruinRunHistory(str(db_path))
    print(f"Created {db_path}")
    
    print("\nInitialized bruin-visualizer!")
    print("\nNext steps:")
    print(f"  1. Parse your pipeline: bruin-viz parse ./pipeline")
    print(f"  2. Run with tracking: bruin-viz run ./pipeline --start-date 2024-01-01 --end-date 2024-01-31")
    print(f"  3. View visualization: bruin-viz serve")


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        prog='bruin-viz',
        description='Bruin Pipeline Visualizer - Visualize and track your Bruin data pipelines'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Parse command
    parse_parser = subparsers.add_parser('parse', help='Parse a Bruin pipeline and generate visualization data')
    parse_parser.add_argument('pipeline_path', help='Path to the Bruin pipeline directory')
    parse_parser.add_argument('-o', '--output', help='Output file path (default: pipeline_graph.json)')
    parse_parser.set_defaults(func=cmd_parse)
    
    # Serve command
    serve_parser = subparsers.add_parser('serve', help='Start the visualization web server')
    serve_parser.add_argument('-p', '--port', type=int, default=8001, help='Port to run server on (default: 8001)')
    serve_parser.add_argument('--no-browser', action='store_true', help='Do not open browser automatically')
    serve_parser.set_defaults(func=cmd_serve)
    
    # Run command
    run_parser = subparsers.add_parser('run', help='Run a Bruin pipeline with history tracking')
    run_parser.add_argument('pipeline_path', help='Path to the Bruin pipeline directory')
    run_parser.add_argument('--start-date', help='Start date for pipeline run')
    run_parser.add_argument('--end-date', help='End date for pipeline run')
    run_parser.add_argument('--full-refresh', action='store_true', help='Run with full refresh')
    run_parser.add_argument('--workers', type=int, help='Number of workers')
    run_parser.add_argument('--db', help='Path to history database (default: bruin_history.db)')
    run_parser.set_defaults(func=cmd_run)
    
    # Init command
    init_parser = subparsers.add_parser('init', help='Initialize bruin-visualizer in current directory')
    init_parser.add_argument('-o', '--output-dir', help='Output directory (default: current directory)')
    init_parser.set_defaults(func=cmd_init)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)


if __name__ == '__main__':
    main()
