#!/usr/bin/env python3
###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
###############################################################################
# Local test runner for ap_debug_ci_failure_multiagent graph.
#
# Connects to real MCP tools (LbAP SSE endpoint) and a user-configured
# OpenAI-compatible LLM. Each run gets its own directory under .threads/
# with SQLite checkpoints, a readable transcript, and a JSON state dump.
#
# Secrets are loaded from .env in the lbagents root (copy .env.example).
#
# Usage:
#   cp .env.example .env   # fill in values
#   pixi run python scripts/run_multiagent_local.py --pipeline-id 27814
#
# Resume an interrupted run:
#   pixi run python scripts/run_multiagent_local.py --resume <thread-id>
#
# Dump a thread's state as JSON (also re-generates transcript):
#   pixi run python scripts/run_multiagent_local.py --dump <thread-id>
#
# Output structure:
#   .threads/<thread-id>/
#     checkpoints.db   — SQLite LangGraph checkpoints
#     transcript.txt   — human-readable conversation log
#     state.json       — structured state dump
###############################################################################
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

# Ensure lbagents src is importable when running from repo root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

# Load .env from lbagents root (secrets, LLM endpoints, etc.)
_dotenv_path = os.path.join(os.path.dirname(__file__), "..", ".env")
if os.path.exists(_dotenv_path):
    try:
        from dotenv import load_dotenv

        load_dotenv(_dotenv_path)
    except ImportError:
        # Manual fallback — parse KEY=VALUE lines
        with open(_dotenv_path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                value = value.strip().strip("'\"")
                os.environ.setdefault(key.strip(), value)

# .threads/ directory in lbagents root
THREADS_DIR = Path(__file__).resolve().parent.parent / ".threads"

# Rich console with custom theme
_theme = Theme(
    {
        "node": "bold cyan",
        "tool.name": "bold yellow",
        "tool.result": "dim",
        "info": "bold blue",
        "success": "bold green",
        "warning": "bold yellow",
        "error": "bold red",
    }
)
console = Console(theme=_theme)

# Node name → display label
_NODE_LABELS = {
    "triage": "Triage",
    "investigator": "Investigator",
    "code_reviewer": "Code Reviewer",
    "code_trace": "Code Trace",
    "synthesizer": "Synthesizer",
    "human_review": "Human Review",
    "post_review": "Post Review",
}


def _thread_dir(thread_id: str) -> Path:
    """Return the directory for a given thread, creating it if needed."""
    d = THREADS_DIR / thread_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _db_path(thread_id: str) -> Path:
    return _thread_dir(thread_id) / "checkpoints.db"


class TranscriptWriter:
    """Accumulates a plain-text transcript and appends to disk.

    Each run (initial or resume) appends a new section to transcript.txt,
    so the full history of a thread is preserved across multiple runs.
    """

    def __init__(self, thread_id: str, *, is_resume: bool = False):
        self.thread_id = thread_id
        self.lines: list[str] = []
        self._path = _thread_dir(thread_id) / "transcript.txt"

        # Section header for this run
        now = datetime.now(timezone.utc).isoformat()
        if is_resume:
            self.lines.append(f"\n{'#' * 72}")
            self.lines.append(f"# RESUMED: {now}")
            self.lines.append(f"{'#' * 72}\n")
        else:
            if not self._path.exists():
                self.lines.append(f"Thread: {thread_id}")
            self.lines.append(f"\n{'#' * 72}")
            self.lines.append(f"# RUN: {now}")
            self.lines.append(f"{'#' * 72}\n")

    def header(self, text: str):
        self.lines.append(f"\n{'=' * 72}")
        self.lines.append(f"  {text}")
        self.lines.append(f"{'=' * 72}\n")

    def node(self, name: str):
        label = _NODE_LABELS.get(name, name)
        self.lines.append(f"\n--- [{label}] ---\n")

    def llm(self, content: str):
        self.lines.append(content)
        self.lines.append("")

    def tool_call(self, name: str, inputs: str):
        self.lines.append(f"  >> {name}({inputs})")

    def tool_result(self, output: str):
        self.lines.append(f"  << {output}")
        self.lines.append("")

    def info(self, text: str):
        self.lines.append(text)

    def save(self):
        self.lines.append(f"\nEnded: {datetime.now(timezone.utc).isoformat()}")
        # Append to existing transcript (preserves previous runs)
        with open(self._path, "a", encoding="utf-8") as f:
            f.write("\n".join(self.lines))
            f.write("\n")
        return self._path


class TraceRecorder:
    """Records structured trace events to traces.jsonl for analysis.

    Each line is a JSON object with a type, timestamp, and payload.
    Designed to be ingested by an LLM to identify optimization opportunities.

    Event types:
      - run_start: pipeline_id, model, thread_id
      - node_start: node name, wall-clock timestamp
      - node_end: node name, duration_s
      - llm_start: node, model (from metadata)
      - llm_end: node, duration_s, input_tokens, output_tokens, content_length
      - tool_start: node, tool name, args (full, not truncated)
      - tool_end: node, tool name, duration_s, result_length, result (full, not truncated)
      - tool_error: node, tool name, error message
      - state_snapshot: node, keys + sizes of state values at node boundaries
      - interrupt: pending_tool_calls summary
      - run_end: total_duration_s, summary stats
    """

    def __init__(self, thread_id: str):
        self._path = _thread_dir(thread_id) / "traces.jsonl"
        self._start = time.monotonic()
        self._pending: dict[str, float] = {}  # event_key → start time
        self._stats = {
            "llm_calls": 0,
            "tool_calls": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "tool_errors": 0,
            "nodes_visited": [],
        }

    def _write(self, event_type: str, **data):
        record = {
            "type": event_type,
            "ts": datetime.now(timezone.utc).isoformat(),
            "elapsed_s": round(time.monotonic() - self._start, 3),
            **data,
        }
        with open(self._path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")

    def run_start(self, *, pipeline_id, model, thread_id, **extra):
        self._write(
            "run_start",
            pipeline_id=pipeline_id,
            model=model,
            thread_id=thread_id,
            **extra,
        )

    def node_start(self, node: str):
        self._pending[f"node:{node}"] = time.monotonic()
        if node not in self._stats["nodes_visited"]:
            self._stats["nodes_visited"].append(node)
        self._write("node_start", node=node)

    def node_end(self, node: str):
        key = f"node:{node}"
        duration = time.monotonic() - self._pending.pop(key, time.monotonic())
        self._write("node_end", node=node, duration_s=round(duration, 3))

    def llm_start(self, node: str, *, run_id: str = ""):
        self._pending[f"llm:{run_id}"] = time.monotonic()
        self._stats["llm_calls"] += 1
        self._write("llm_start", node=node, run_id=run_id)

    def llm_end(
        self,
        node: str,
        *,
        run_id: str = "",
        content: str = "",
        usage: dict | None = None,
    ):
        key = f"llm:{run_id}"
        duration = time.monotonic() - self._pending.pop(key, time.monotonic())
        input_tokens = (usage or {}).get("input_tokens", 0) or (usage or {}).get(
            "prompt_tokens", 0
        )
        output_tokens = (usage or {}).get("output_tokens", 0) or (usage or {}).get(
            "completion_tokens", 0
        )
        self._stats["total_input_tokens"] += input_tokens
        self._stats["total_output_tokens"] += output_tokens
        self._write(
            "llm_end",
            node=node,
            run_id=run_id,
            duration_s=round(duration, 3),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            content_length=len(content),
        )

    def tool_start(self, node: str, name: str, args: dict):
        self._pending[f"tool:{name}"] = time.monotonic()
        self._stats["tool_calls"] += 1
        self._write("tool_start", node=node, tool=name, args=args)

    def tool_end(self, node: str, name: str, result: str):
        key = f"tool:{name}"
        duration = time.monotonic() - self._pending.pop(key, time.monotonic())
        self._write(
            "tool_end",
            node=node,
            tool=name,
            duration_s=round(duration, 3),
            result_length=len(result),
            result=result,
        )

    def tool_error(self, node: str, name: str, error: str):
        self._stats["tool_errors"] += 1
        self._write("tool_error", node=node, tool=name, error=error)

    def state_snapshot(self, node: str, state_values: dict):
        """Record sizes of state channels at a node boundary."""
        sizes = {}
        for k, v in state_values.items():
            if k == "messages":
                sizes[k] = {
                    "count": len(v),
                    "total_chars": sum(len(getattr(m, "content", "") or "") for m in v),
                }
            elif isinstance(v, list):
                sizes[k] = {"count": len(v)}
            elif isinstance(v, str):
                sizes[k] = {"chars": len(v)}
            else:
                sizes[k] = {"value": str(v)[:200]}
        self._write("state_snapshot", node=node, channels=sizes)

    def interrupt(self, data):
        self._write("interrupt", data=data)

    def run_end(self):
        total = time.monotonic() - self._start
        self._write("run_end", total_duration_s=round(total, 3), stats=self._stats)
        return self._path


def parse_args():
    p = argparse.ArgumentParser(description="Run multiagent CI debug graph locally")

    # Mode: new run vs resume vs dump
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--pipeline-id", type=int, help="LbAP pipeline ID (new run)")
    mode.add_argument(
        "--resume", metavar="THREAD_ID", help="Resume an interrupted thread"
    )
    mode.add_argument(
        "--dump", metavar="THREAD_ID", help="Dump thread state as JSON + transcript"
    )

    p.add_argument("--mr-iid", type=int, default=None, help="GitLab MR IID (optional)")
    p.add_argument(
        "--gitlab-project-id",
        type=int,
        default=None,
        help="GitLab project ID (default: AP repo 76059)",
    )
    p.add_argument(
        "--gitlab-token",
        default=os.environ.get("GITLAB_TOKEN"),
        help="GitLab API token (or set GITLAB_TOKEN env var)",
    )

    # LLM config (env var names match LbAPI settings)
    p.add_argument(
        "--orchestrator-base-url",
        default=os.environ.get("LBAP_KSERVE_ORCHESTRATOR_URL"),
        help="KServe base URL for orchestrator LLM",
    )
    p.add_argument(
        "--orchestrator-model",
        default=os.environ.get("LBAP_ORCHESTRATOR_MODEL_NAME"),
        help="Model name for orchestrator",
    )
    p.add_argument(
        "--coder-base-url",
        default=os.environ.get("LBAP_KSERVE_CODER_URL"),
        help="KServe base URL for coder LLM (defaults to orchestrator URL)",
    )
    p.add_argument(
        "--coder-model",
        default=os.environ.get("LBAP_CODER_MODEL_NAME"),
        help="Model name for coder (defaults to orchestrator model)",
    )

    # MCP server
    p.add_argument(
        "--mcp-url",
        default=os.environ.get("LBAP_MCP_URL", "https://lbap.app.cern.ch/mcp"),
        help="LbAP MCP endpoint URL",
    )
    p.add_argument(
        "--no-mcp",
        action="store_true",
        help="Skip MCP tools (use only GitLab tools + scratchpad)",
    )

    # Resume decision (used with --resume)
    resume_action = p.add_mutually_exclusive_group()
    resume_action.add_argument(
        "--approve",
        action="store_true",
        help="Approve the pending action when resuming",
    )
    resume_action.add_argument(
        "--reject",
        metavar="FEEDBACK",
        nargs="?",
        const="",
        help="Reject the pending action when resuming (optional feedback)",
    )

    p.add_argument(
        "--auto-approve",
        action="store_true",
        help="Auto-approve all human review interrupts",
    )
    p.add_argument(
        "--interactive",
        "-i",
        action="store_true",
        help="Block at interrupts for interactive approve/reject (default: save and exit)",
    )
    p.add_argument("--verbose", "-v", action="store_true", help="Debug logging")
    return p.parse_args()


def build_llms(args):
    """Create ChatOpenAI clients from CLI args."""
    from langchain_openai import ChatOpenAI

    api_key = os.environ.get("OPENAI_API_KEY", "unused")

    # KServe auth via session cookie (matches LbAPI's kserve_auth.py format)
    session_cookie = os.environ.get("LBAP_KSERVE_SESSION_COOKIE")
    if session_cookie:
        if not session_cookie.startswith("authservice_session="):
            session_cookie = f"authservice_session={session_cookie}"
        headers = {"Cookie": session_cookie}
    else:
        headers = {}

    def _ensure_v1(url: str) -> str:
        return url if url.rstrip("/").endswith("/v1") else f"{url.rstrip('/')}/v1"

    orchestrator = ChatOpenAI(
        base_url=_ensure_v1(args.orchestrator_base_url),
        model=args.orchestrator_model,
        api_key=api_key,
        temperature=0.6,
        max_tokens=16384,
        default_headers=headers,
    )

    coder_base = args.coder_base_url or args.orchestrator_base_url
    coder_model = args.coder_model or args.orchestrator_model
    coder = ChatOpenAI(
        base_url=_ensure_v1(coder_base),
        model=coder_model,
        api_key=api_key,
        temperature=0.6,
        max_tokens=16384,
        default_headers=headers,
    )

    return orchestrator, coder


async def connect_mcp(mcp_url: str):
    """Create and connect a persistent MCP client (single OAuth flow).

    OAuth tokens are cached on disk under .threads/.oauth_cache/ so that
    subsequent runs within the token lifetime skip the browser auth flow.
    """
    from fastmcp import Client
    from fastmcp.client.auth.oauth import OAuth
    from key_value.aio.stores.disk import DiskStore

    token_cache_dir = THREADS_DIR / ".oauth_cache"
    token_store = DiskStore(directory=token_cache_dir)
    oauth = OAuth(token_storage=token_store)
    client = Client(mcp_url, auth=oauth)
    with console.status(
        f"[info]Connecting to MCP server at {mcp_url} (OIDC auth)...[/info]"
    ):
        await client.__aenter__()
    console.print("[success]Connected to MCP server[/success]")
    return client


def build_mcp_tools(client, mcp_tools, tool_allowlist: set[str]) -> list:
    """Convert MCP tool descriptors to LangChain tools using a shared client."""
    from langchain_core.tools import StructuredTool
    from pydantic import Field, create_model

    _JSON_TYPE_MAP = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }

    def _json_type_to_python(json_type):
        if isinstance(json_type, list):
            for t in json_type:
                if t != "null":
                    return _JSON_TYPE_MAP.get(t, str)
            return str
        return _JSON_TYPE_MAP.get(json_type or "string", str)

    tools = []
    for mt in mcp_tools:
        if mt.name not in tool_allowlist:
            continue
        schema = mt.inputSchema or {"type": "object", "properties": {}}
        properties = schema.get("properties", {})
        required = set(schema.get("required", []))
        fields = {}
        for name, prop in properties.items():
            py_type = _json_type_to_python(prop.get("type"))
            desc = prop.get("description", "")
            if name in required:
                fields[name] = (py_type, Field(description=desc))
            else:
                fields[name] = (
                    py_type | None,
                    Field(default=prop.get("default"), description=desc),
                )
        args_model = (
            create_model(f"{mt.name}_Args", **fields)
            if fields
            else create_model(f"{mt.name}_Args")
        )

        def _make_caller(tool_name, shared_client):
            async def _call(**kwargs):
                result = await shared_client.call_tool(tool_name, kwargs)
                parts = []
                for block in result.content:
                    parts.append(block.text if hasattr(block, "text") else str(block))
                return "\n".join(parts)

            return _call

        tool = StructuredTool.from_function(
            func=lambda **kw: "async-only tool",
            coroutine=_make_caller(mt.name, client),
            name=mt.name,
            description=mt.description or mt.name,
            args_schema=args_model,
        )
        tools.append(tool)

    return tools


def make_scratchpad_tools():
    """Minimal scratchpad tools for local testing."""
    from langchain_core.tools import StructuredTool
    from pydantic import BaseModel, Field

    _scratchpad: dict[str, str] = {}
    _CHUNK = 200

    class ReadArgs(BaseModel):
        doc_id: str = Field(description="Document ID")
        start_line: int = Field(default=0, description="Start line")
        end_line: int | None = Field(default=None, description="End line")

    class SearchArgs(BaseModel):
        doc_id: str = Field(description="Document ID")
        pattern: str = Field(description="Regex pattern")
        context_lines: int = Field(default=3, description="Context lines")

    class ListArgs(BaseModel):
        pass

    def read_document(
        doc_id: str, start_line: int = 0, end_line: int | None = None
    ) -> str:
        if doc_id not in _scratchpad:
            return (
                f"Document '{doc_id}' not found. Available: {list(_scratchpad.keys())}"
            )
        lines = _scratchpad[doc_id].splitlines()
        end = end_line or start_line + _CHUNK
        chunk = lines[start_line:end]
        if not chunk:
            return f"No content at lines {start_line}-{end}. Document has {len(lines)} lines."
        return (
            f"[{doc_id} lines {start_line}-{min(end, len(lines))} of {len(lines)}]\n"
            + "\n".join(chunk)
        )

    def search_document(doc_id: str, pattern: str, context_lines: int = 3) -> str:
        if doc_id not in _scratchpad:
            return f"Document '{doc_id}' not found."
        lines = _scratchpad[doc_id].splitlines()
        regex = re.compile(pattern, re.IGNORECASE)
        matches = []
        for i, line in enumerate(lines):
            if regex.search(line):
                s, e = max(0, i - context_lines), min(len(lines), i + context_lines + 1)
                ctx = [
                    f"{'>>>' if j == i else '   '} {j}: {lines[j]}" for j in range(s, e)
                ]
                matches.append("\n".join(ctx))
        if not matches:
            return f"No matches for '{pattern}' in {doc_id}"
        return f"Found {len(matches)} matches:\n\n" + "\n---\n".join(matches[:20])

    def list_documents() -> str:
        if not _scratchpad:
            return "No documents stored."
        return "Stored documents:\n" + "\n".join(
            f"  {k}: {len(v.splitlines())} lines" for k, v in _scratchpad.items()
        )

    tools = [
        StructuredTool.from_function(
            func=read_document,
            name="read_document",
            description="Read a chunk of a stored document by line range.",
            args_schema=ReadArgs,
        ),
        StructuredTool.from_function(
            func=search_document,
            name="search_document",
            description="Search a stored document with regex.",
            args_schema=SearchArgs,
        ),
        StructuredTool.from_function(
            func=list_documents,
            name="list_documents",
            description="List stored documents.",
            args_schema=ListArgs,
        ),
    ]
    return tools


def _message_to_dict(msg) -> dict:
    """Convert a LangChain message to a JSON-serializable dict."""
    d = {"type": msg.type, "content": msg.content}
    if hasattr(msg, "name") and msg.name:
        d["name"] = msg.name
    if hasattr(msg, "tool_calls") and msg.tool_calls:
        d["tool_calls"] = msg.tool_calls
    if hasattr(msg, "tool_call_id") and msg.tool_call_id:
        d["tool_call_id"] = msg.tool_call_id
    return d


def _state_to_json(state_values: dict) -> dict:
    """Convert graph state to a JSON-serializable dict."""
    out = {}
    for k, v in state_values.items():
        if k == "messages":
            out[k] = [_message_to_dict(m) for m in v]
        elif k in ("job_findings", "job_clusters", "code_review_comments"):
            out[k] = v
        else:
            out[k] = v
    return out


def _state_to_transcript(state_values: dict) -> str:
    """Render checkpoint state as a readable transcript."""
    lines = []
    for msg in state_values.get("messages", []):
        mtype = msg.type.upper()
        if mtype == "HUMAN":
            lines.append(f"[USER]\n{msg.content}\n")
        elif mtype == "AI":
            node = getattr(msg, "name", None) or ""
            label = f" ({node})" if node else ""
            lines.append(f"[ASSISTANT{label}]")
            if msg.content:
                lines.append(msg.content)
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                for tc in msg.tool_calls:
                    args_str = json.dumps(tc.get("args", {}), default=str)
                    if len(args_str) > 500:
                        args_str = args_str[:500] + "..."
                    lines.append(f"  >> {tc['name']}({args_str})")
            lines.append("")
        elif mtype == "TOOL":
            name = getattr(msg, "name", "tool")
            content = msg.content or ""
            if len(content) > 2000:
                content = content[:2000] + "\n... (truncated)"
            lines.append(f"[TOOL: {name}]\n{content}\n")

    # Append structured findings if present
    findings = state_values.get("job_findings", [])
    if findings:
        lines.append("\n" + "=" * 72)
        lines.append("  JOB FINDINGS")
        lines.append("=" * 72)
        for f in findings:
            lines.append(json.dumps(f, indent=2, default=str))
        lines.append("")

    comments = state_values.get("code_review_comments", [])
    if comments:
        lines.append("=" * 72)
        lines.append("  CODE REVIEW COMMENTS")
        lines.append("=" * 72)
        for c in comments:
            lines.append(json.dumps(c, indent=2, default=str))
        lines.append("")

    review_body = state_values.get("review_body")
    if review_body:
        lines.append("=" * 72)
        lines.append("  FINAL REVIEW")
        lines.append("=" * 72)
        lines.append(review_body)
        lines.append("")

    return "\n".join(lines)


async def dump_thread(thread_id: str):
    """Dump a thread's checkpoint state as JSON + transcript."""
    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    db = _db_path(thread_id)
    if not db.exists():
        console.print(f"[error]No checkpoint database at {db}[/error]")
        return

    async with AsyncSqliteSaver.from_conn_string(str(db)) as checkpointer:
        config = {"configurable": {"thread_id": thread_id}}
        state = await checkpointer.aget_tuple(config)
        if not state or not state.checkpoint:
            console.print(f"[error]No checkpoint found for thread {thread_id}[/error]")
            return

        values = state.checkpoint.get("channel_values", {})
        thread_dir = _thread_dir(thread_id)

        # JSON dump
        json_path = thread_dir / "state.json"
        with open(json_path, "w") as f:
            json.dump(
                {"thread_id": thread_id, "state": _state_to_json(values)},
                f,
                indent=2,
                default=str,
            )
        console.print(f"[success]JSON:[/success]  {json_path}")

        # Transcript
        txt_path = thread_dir / "transcript.txt"
        header = (
            f"Thread: {thread_id}\nDumped: {datetime.now(timezone.utc).isoformat()}\n\n"
        )
        txt_path.write_text(header + _state_to_transcript(values), encoding="utf-8")
        console.print(f"[success]Transcript:[/success] {txt_path}")


async def build_tools(args, tool_allowlist):
    """Build all tools (MCP + GitLab + scratchpad). Returns (tools, mcp_client)."""
    tools = []
    mcp_client = None

    if not args.no_mcp:
        try:
            mcp_client = await connect_mcp(args.mcp_url)
            mcp_tool_descriptors = await mcp_client.list_tools()
            console.print(
                f"  Discovered [info]{len(mcp_tool_descriptors)}[/info] MCP tools"
            )
            mcp_tools = build_mcp_tools(
                mcp_client, mcp_tool_descriptors, tool_allowlist
            )
            tools.extend(mcp_tools)
            console.print(f"  Using [info]{len(mcp_tools)}[/info] from allowlist")
        except Exception as e:
            console.print(f"[warning]MCP connection failed: {e}[/warning]")
            console.print(
                "[warning]Continuing without MCP tools (use --no-mcp to skip)[/warning]"
            )

    if args.gitlab_token and args.mr_iid:
        from LbAgents.tools.gitlab import make_gitlab_review_tools

        gitlab_tools = make_gitlab_review_tools(
            gitlab_token=args.gitlab_token,
            mr_iid=args.mr_iid,
            project_id=args.gitlab_project_id or 76059,
        )
        tools.extend(gitlab_tools)
        console.print(
            f"  Added [info]{len(gitlab_tools)}[/info] GitLab tools for MR !{args.mr_iid}"
        )
    elif args.mr_iid:
        console.print(
            "[warning]--mr-iid given but no --gitlab-token, skipping GitLab tools[/warning]"
        )

    tools.extend(make_scratchpad_tools())

    # Tool summary table
    _GITLAB_TOOLS = {
        "get_mr_info",
        "get_mr_diff",
        "get_mr_file_content",
        "post_mr_review",
        "get_mr_commits",
        "get_commit_diff",
        "get_target_branch_file",
    }
    _LOCAL_TOOLS = {"read_document", "search_document", "list_documents"}
    table = Table(
        title="Tools",
        show_header=True,
        header_style="bold",
        show_lines=False,
        pad_edge=False,
    )
    table.add_column("Name", style="tool.name", no_wrap=True)
    table.add_column("Source", style="dim")
    for t in tools:
        if t.name in _LOCAL_TOOLS:
            source = "local"
        elif t.name in _GITLAB_TOOLS:
            source = "GitLab"
        else:
            source = "MCP"
        table.add_row(t.name, source)
    console.print(table)
    console.print()

    return tools, mcp_client


async def stream_graph(
    compiled,
    input_or_command,
    config,
    transcript: TranscriptWriter,
    tracer: TraceRecorder,
):
    """Stream graph events with rich formatting, recording to transcript + traces."""
    current_node = None
    token_buffer = ""

    async for event in compiled.astream_events(
        input_or_command, config=config, version="v2"
    ):
        kind = event["event"]
        meta = event.get("metadata", {})
        node = meta.get("langgraph_node", "?")
        run_id = event.get("run_id", "")

        if kind == "on_chat_model_start":
            # Flush any previous buffer
            if token_buffer.strip():
                console.print(Markdown(token_buffer))
                transcript.llm(token_buffer)
                token_buffer = ""

            label = _NODE_LABELS.get(node, node)
            if node != current_node:
                if current_node:
                    tracer.node_end(current_node)
                current_node = node
                console.rule(f"[node]{label}[/node]", style="cyan")
                transcript.node(node)
                tracer.node_start(node)

            tracer.llm_start(node, run_id=run_id)

        elif kind == "on_chat_model_stream":
            chunk = event["data"].get("chunk")
            if chunk and hasattr(chunk, "content") and chunk.content:
                token_buffer += chunk.content

        elif kind == "on_chat_model_end":
            # Extract token usage from the response metadata
            output = event["data"].get("output")
            usage = None
            if output and hasattr(output, "usage_metadata"):
                usage = output.usage_metadata
            elif output and hasattr(output, "response_metadata"):
                rm = output.response_metadata or {}
                usage = rm.get("token_usage") or rm.get("usage")

            tracer.llm_end(node, run_id=run_id, content=token_buffer, usage=usage)

            if token_buffer.strip():
                console.print(Markdown(token_buffer))
                transcript.llm(token_buffer)
                token_buffer = ""

        elif kind == "on_tool_start":
            if token_buffer.strip():
                console.print(Markdown(token_buffer))
                transcript.llm(token_buffer)
                token_buffer = ""

            name = event.get("name", "?")
            inputs = event["data"].get("input", {})

            # Trace gets full args (no truncation)
            tracer.tool_start(node, name, inputs)

            # Console gets truncated display
            inp_str = json.dumps(inputs, default=str)
            if len(inp_str) > 300:
                inp_str = inp_str[:300] + "..."
            console.print(
                Panel(
                    Text(inp_str, style="dim"),
                    title=f"[tool.name]{name}[/tool.name]",
                    title_align="left",
                    border_style="yellow",
                    expand=False,
                    padding=(0, 1),
                )
            )
            transcript.tool_call(name, inp_str)

        elif kind == "on_tool_end":
            name = event.get("name", "?")
            full_output = str(event["data"].get("output", ""))

            # Trace gets full result (no truncation)
            tracer.tool_end(node, name, full_output)

            # Console gets truncated display
            display = full_output
            if len(display) > 500:
                display = display[:500] + "..."
            console.print(Text(f"  {display}", style="tool.result"))
            transcript.tool_result(display)

    # Flush trailing buffer
    if token_buffer.strip():
        console.print(Markdown(token_buffer))
        transcript.llm(token_buffer)

    # Close final node
    if current_node:
        tracer.node_end(current_node)


async def handle_interrupt(
    compiled, config, args, transcript: TranscriptWriter, tracer: TraceRecorder
) -> bool:
    """Handle a human review interrupt. Returns True if graph should continue."""
    state = await compiled.aget_state(config)
    if not state.next:
        return False

    interrupt_data = None
    for task in state.tasks:
        if hasattr(task, "interrupts") and task.interrupts:
            interrupt_data = task.interrupts[0].value
            break

    transcript.header("INTERRUPT")
    tracer.interrupt(interrupt_data)

    # Render the interrupt payload in a readable way
    console.print()
    console.rule("[warning]Human Review Required[/warning]", style="yellow")
    console.print()

    if interrupt_data and isinstance(interrupt_data, dict):
        # Show pending tool calls with their args rendered nicely
        for tc in interrupt_data.get("pending_tool_calls", []):
            tool_name = tc.get("name", "?")
            tool_args = tc.get("args", {})

            console.print(f"[tool.name]Pending tool call:[/tool.name] {tool_name}")
            console.print()

            # Render body/text args as markdown, show others as key=value
            for key, value in tool_args.items():
                if key == "body" and isinstance(value, str) and len(value) > 100:
                    # This is the review body — render as markdown
                    console.print(
                        Panel(
                            Markdown(value),
                            title="Review Body",
                            border_style="blue",
                            padding=(1, 2),
                        )
                    )
                elif key == "inline_comments" and isinstance(value, list):
                    if value:
                        comments_table = Table(title="Inline Comments", show_lines=True)
                        comments_table.add_column("File", style="cyan", no_wrap=True)
                        comments_table.add_column("Line", justify="right")
                        comments_table.add_column("Comment")
                        for c in value:
                            comments_table.add_row(
                                c.get("file_path", "?"),
                                str(c.get("new_line", "?")),
                                c.get("body", ""),
                            )
                        console.print(comments_table)
                else:
                    val_str = (
                        json.dumps(value, default=str)
                        if not isinstance(value, str)
                        else value
                    )
                    if len(val_str) > 200:
                        val_str = val_str[:200] + "..."
                    console.print(f"  [bold]{key}:[/bold] {val_str}")

            transcript.info(f"Tool: {tool_name}")
            transcript.info(json.dumps(tool_args, indent=2, default=str)[:5000])

        # Show any other keys in the interrupt data
        other_keys = {
            k: v for k, v in interrupt_data.items() if k != "pending_tool_calls"
        }
        if other_keys:
            console.print()
            console.print(json.dumps(other_keys, indent=2, default=str)[:1000])
            transcript.info(json.dumps(other_keys, indent=2, default=str))

    elif interrupt_data:
        # Fallback: raw JSON for unknown structure
        payload = json.dumps(interrupt_data, indent=2, default=str)[:3000]
        console.print(payload)
        transcript.info(payload)

    console.print()
    console.rule(style="yellow")

    thread_id = config["configurable"]["thread_id"]

    if args.auto_approve:
        console.print("[success]Auto-approving...[/success]")
        decision = {"action": "approve"}
    elif args.interactive:
        console.print(f"  Thread: [info]{thread_id}[/info]")
        console.print(
            "  Options: [green][a]pprove[/green] / [yellow][r]eject[/yellow]"
            " / [red][q]uit[/red] (resume later)"
        )
        choice = input("  >> ").strip().lower()
        if choice in ("a", "approve", ""):
            decision = {"action": "approve"}
        elif choice in ("q", "quit"):
            console.print(f"\n[info]Saved. Resume with:[/info] --resume {thread_id}")
            transcript.info(f"User quit. Resume with: --resume {thread_id}")
            return False
        else:
            feedback = input("  Feedback: ").strip()
            decision = {"action": "reject"}
            if feedback:
                decision["feedback"] = feedback
    else:
        # Default: non-blocking — save and exit, resume later
        console.print("\n[info]Review the output above, then resume:[/info]")
        console.print(f"  --resume {thread_id}")
        transcript.info(f"Paused (non-blocking). Resume with: --resume {thread_id}")
        return False

    from langgraph.types import Command

    transcript.info(f"Decision: {json.dumps(decision)}")
    console.print(f"[info]Resuming with:[/info] {decision}")
    await stream_graph(compiled, Command(resume=decision), config, transcript, tracer)
    return True


async def run(args):
    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    from LbAgents.graphs.ap_debug_ci_failure_v2 import (
        build_ap_debug_ci_failure_multiagent_graph,
    )

    if not args.orchestrator_base_url:
        console.print(
            "[error]Set LBAP_KSERVE_ORCHESTRATOR_URL or pass --orchestrator-base-url[/error]"
        )
        sys.exit(1)

    THREADS_DIR.mkdir(exist_ok=True)

    orchestrator, coder = build_llms(args)

    tool_allowlist = {
        "get_pipeline_info",
        "get_pipeline_log",
        "get_pipeline_validation_report",
        "get_ci_run_info",
        "get_ci_run_log",
        "get_ci_job_info",
        "get_ci_job_logs",
        "grep_ci_job_log",
        "list_pipelines_for_mr",
        "get_production_summary",
        "get_production_repo_path",
        "explain_ci_job_status",
        "get_debugging_guide",
        "list_application_versions",
        "get_mr_info",
        "get_mr_diff",
        "get_mr_file_content",
        "post_mr_review",
        "get_mr_commits",
        "get_commit_diff",
        "get_target_branch_file",
        "query_code_graph",
        "get_code_snippet",
        "get_graph_schema",
        "run_cypher",
        "search_code_text",
    }

    tools, mcp_client = await build_tools(args, tool_allowlist)

    write_tool_names = ["post_mr_review"]
    graph = build_ap_debug_ci_failure_multiagent_graph(
        orchestrator_llm=orchestrator,
        tools=tools,
        write_tool_names=write_tool_names,
        coder_llm=coder,
    )

    if args.resume:
        thread_id = args.resume
    else:
        thread_id = str(uuid.uuid4())

    db = _db_path(thread_id)
    transcript = TranscriptWriter(thread_id, is_resume=bool(args.resume))
    tracer = TraceRecorder(thread_id)

    async with AsyncSqliteSaver.from_conn_string(str(db)) as checkpointer:
        await checkpointer.setup()
        compiled = graph.compile(checkpointer=checkpointer)

        config = {
            "configurable": {"thread_id": thread_id},
            "recursion_limit": 100,
        }

        if args.resume:
            console.print(f"[info]Resuming thread:[/info] {thread_id}")
            transcript.header("RESUMED (pipeline from previous run)")
            tracer.run_start(
                pipeline_id="resumed",
                model=args.orchestrator_model or "",
                thread_id=thread_id,
            )

            # If --approve or --reject given, apply directly without showing interrupt
            if args.approve or args.reject is not None:
                from langgraph.types import Command

                if args.approve:
                    decision = {"action": "approve"}
                else:
                    decision = {"action": "reject"}
                    if args.reject:
                        decision["feedback"] = args.reject

                console.print(f"[info]Resuming with:[/info] {decision}")
                transcript.info(f"Decision: {json.dumps(decision)}")
                await stream_graph(
                    compiled, Command(resume=decision), config, transcript, tracer
                )

                # Handle further interrupts
                while await handle_interrupt(
                    compiled, config, args, transcript, tracer
                ):
                    pass
            else:
                await handle_interrupt(compiled, config, args, transcript, tracer)

        else:
            from langchain_core.messages import HumanMessage

            message = (
                f"Investigate pipeline {args.pipeline_id} and diagnose the CI failure."
            )
            input_state = {
                "messages": [HumanMessage(content=message)],
                "pipeline_id": args.pipeline_id,
            }
            if args.mr_iid:
                input_state["mr_iid"] = args.mr_iid
            if args.gitlab_project_id:
                input_state["gitlab_project_id"] = args.gitlab_project_id

            # Run header
            info_table = Table(
                show_header=False, show_edge=False, pad_edge=False, box=None
            )
            info_table.add_column(style="bold")
            info_table.add_column()
            info_table.add_row("Thread", thread_id)
            info_table.add_row("Pipeline", str(args.pipeline_id))
            info_table.add_row("Checkpoints", str(db))
            console.print(
                Panel(
                    info_table,
                    title="[info]New Run[/info]",
                    border_style="blue",
                    expand=False,
                )
            )
            console.print()

            transcript.header(f"Pipeline {args.pipeline_id}")
            transcript.info(f"Model: {args.orchestrator_model}")
            if args.mr_iid:
                transcript.info(f"MR: !{args.mr_iid}")

            tracer.run_start(
                pipeline_id=args.pipeline_id,
                model=args.orchestrator_model or "",
                thread_id=thread_id,
                mr_iid=args.mr_iid,
            )

            await stream_graph(compiled, input_state, config, transcript, tracer)

            # Handle interrupt(s)
            while await handle_interrupt(compiled, config, args, transcript, tracer):
                pass

        # Final state
        state = await compiled.aget_state(config)
        thread_dir = _thread_dir(thread_id)

        if state.next:
            console.print(
                f"\n[warning]Graph paused. Resume with:[/warning] --resume {thread_id}"
            )
            transcript.info(f"\nGraph paused. Resume with: --resume {thread_id}")
        else:
            error = state.values.get("error")
            if error:
                console.print(f"\n[error]Graph finished with error:[/error] {error}")
                transcript.info(f"\nError: {error}")
            else:
                console.print(
                    Panel(
                        "[success]Graph completed successfully.[/success]",
                        border_style="green",
                    )
                )
                transcript.info("\nGraph completed successfully.")

        vals = state.values
        tracer.state_snapshot("final", vals)
        tracer.run_end()

        summary = Table(
            title="Final State", show_header=False, show_edge=False, box=None
        )
        summary.add_column(style="bold")
        summary.add_column()
        summary.add_row("Thread", thread_id)
        summary.add_row("Findings", str(len(vals.get("job_findings", []))))
        summary.add_row(
            "Review comments", str(len(vals.get("code_review_comments", [])))
        )
        summary.add_row(
            "Review body", f"{len(vals.get('review_body', '') or '')} chars"
        )
        summary.add_row("Messages", str(len(vals.get("messages", []))))
        console.print(summary)

        # Write state.json
        json_path = thread_dir / "state.json"
        with open(json_path, "w") as f:
            json.dump(
                {"thread_id": thread_id, "state": _state_to_json(vals)},
                f,
                indent=2,
                default=str,
            )

        # Write transcript
        transcript.save()

        console.print()
        console.print(f"[info]Outputs:[/info] {thread_dir}/")
        console.print("  checkpoints.db  transcript.txt  state.json  traces.jsonl")

    # Clean up MCP client
    if mcp_client is not None:
        await mcp_client.__aexit__(None, None, None)


def main():
    args = parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    if not args.verbose:
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("httpcore").setLevel(logging.WARNING)
        logging.getLogger("openai").setLevel(logging.WARNING)

    if args.dump:
        asyncio.run(dump_thread(args.dump))
    elif args.pipeline_id or args.resume:
        asyncio.run(run(args))
    else:
        console.print(
            "[error]Provide --pipeline-id (new run) or --resume THREAD_ID[/error]"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
