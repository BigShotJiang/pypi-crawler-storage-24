#!/usr/bin/env python3

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from bub.channels.message import ChannelMessage

from bub_wecom.wecom_longconn_bot import WeComLongConnBotChannel


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Send a WeCom long-connection message using Bub's native bridge adapter.")
    parser.add_argument("--chat-id", required=True, help="Target WeCom user_id or group chatid")
    parser.add_argument(
        "--kind",
        default="send_message",
        choices=["send_message", "reply_message", "update_card"],
        help="Outbound action kind",
    )
    parser.add_argument(
        "--content-type",
        default="text",
        choices=["text", "rich_text", "card", "image", "file", "audio"],
        help="Outbound content type",
    )
    parser.add_argument("--message", help="Message text content")
    parser.add_argument("--card-json", help="Template card JSON object")
    parser.add_argument("--attachment", help="Attachment path/URL/data URL for image/file/audio sends")
    parser.add_argument("--reply-token", help="WeCom callback req_id for reply/update flows")
    parser.add_argument("--reply-to-message-id", help="Optional source message id")
    parser.add_argument("--event-type", help="Optional callback event type, such as enter_chat or template_card_event")
    parser.add_argument("--target-id", action="append", default=[], help="Target user id list for update_card")
    parser.add_argument("--mention-user", action="append", default=[], help="Mention a WeCom user_id")
    parser.add_argument("--mention-mobile", action="append", default=[], help="Mention a mobile number")
    parser.add_argument("--mention-all", action="store_true", help="Mention @all")
    return parser.parse_args()


def _card_from_json(raw: str | None) -> dict[str, object] | None:
    if raw is None:
        return None
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise TypeError("--card-json must decode to a JSON object")
    return data


def _mentions(args: argparse.Namespace) -> list[dict[str, str]]:
    items = [{"kind": "user_id", "value": value} for value in args.mention_user]
    items.extend({"kind": "mobile", "value": value} for value in args.mention_mobile)
    if args.mention_all:
        items.append({"kind": "all", "value": "@all"})
    return items


def _reply_grant(args: argparse.Namespace) -> dict[str, object] | None:
    if not args.reply_token and not args.reply_to_message_id and not args.event_type:
        return None
    metadata: dict[str, object] = {}
    if args.event_type:
        metadata["event_type"] = args.event_type
    reply_grant: dict[str, object] = {}
    if args.reply_token:
        reply_grant["token"] = args.reply_token
    if args.reply_to_message_id:
        reply_grant["reply_to_message_id"] = args.reply_to_message_id
    if metadata:
        reply_grant["metadata"] = metadata
    return reply_grant


def _content(args: argparse.Namespace) -> str:
    payload: dict[str, object] = {
        "kind": args.kind,
        "message": args.message or "",
        "content_type": args.content_type,
        "mentions": _mentions(args),
        "target_ids": [str(item) for item in args.target_id],
    }
    if card := _card_from_json(args.card_json):
        payload["card"] = card
    if args.attachment:
        payload["source"] = args.attachment
    if reply_grant := _reply_grant(args):
        payload["reply_grant"] = reply_grant
    return json.dumps(payload, ensure_ascii=False)


async def _main_async(args: argparse.Namespace) -> None:
    async def _on_receive(_message) -> None:
        return

    channel = WeComLongConnBotChannel(on_receive=_on_receive)
    stop_event = asyncio.Event()
    message = ChannelMessage(
        session_id=f"wecom_longconn_bot:{args.chat_id}",
        channel="wecom_longconn_bot",
        chat_id=args.chat_id,
        content=_content(args),
    )

    await channel.start(stop_event)
    try:
        await channel.send(message)
    finally:
        await channel.stop()


def main() -> int:
    args = _parse_args()
    try:
        asyncio.run(_main_async(args))
    except Exception as exc:
        print(f"wecom long-connection send failed: {exc}", file=sys.stderr)
        return 1
    print("wecom long-connection action sent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
