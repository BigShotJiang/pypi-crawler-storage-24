from __future__ import annotations

import asyncio
import base64
import contextlib
import json
import shlex
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiohttp
from bub.channels.base import Channel
from bub.channels.message import ChannelMessage, MediaItem
from bub.types import MessageHandler
from loguru import logger

from bub_wecom.outbound import message_to_action

BRIDGE_PROTOCOL_VERSION = "1"


def build_action_frame(action: Mapping[str, Any]) -> dict[str, Any]:
    return {"type": "action", "version": BRIDGE_PROTOCOL_VERSION, "action": _to_primitive(action)}


def build_configure_frame(channel: str, config: Mapping[str, Any], **metadata: Any) -> dict[str, Any]:
    return {
        "type": "configure",
        "version": BRIDGE_PROTOCOL_VERSION,
        "channel": channel,
        "config": _to_primitive(config),
        **metadata,
    }


def build_ready_frame(channel: str, **metadata: Any) -> dict[str, Any]:
    return {"type": "ready", "version": BRIDGE_PROTOCOL_VERSION, "channel": channel, **metadata}


def build_log_frame(message: str, *, level: str = "info", **metadata: Any) -> dict[str, Any]:
    return {"type": "log", "version": BRIDGE_PROTOCOL_VERSION, "level": level, "message": message, **metadata}


def build_state_frame(state: str, **metadata: Any) -> dict[str, Any]:
    return {"type": "state", "version": BRIDGE_PROTOCOL_VERSION, "state": state, **metadata}


def build_provisioning_frame(info: Mapping[str, Any]) -> dict[str, Any]:
    return {"type": "provisioning", "version": BRIDGE_PROTOCOL_VERSION, "provisioning": _to_primitive(info)}


def build_inbound_message_frame(message: ChannelMessage) -> dict[str, Any]:
    return {"type": "message", "version": BRIDGE_PROTOCOL_VERSION, "message": _to_primitive(message)}


@dataclass(slots=True)
class BridgeProvisioning:
    mode: str
    state: str
    pairing_code: str | None = None
    config_key: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> BridgeProvisioning:
        metadata = value.get("metadata")
        return cls(
            mode=str(value.get("mode", "")),
            state=str(value.get("state", "")),
            pairing_code=_string_or_none(value.get("pairing_code")),
            config_key=_string_or_none(value.get("config_key")),
            metadata=dict(metadata) if isinstance(metadata, Mapping) else {},
        )


class BridgeChannel(Channel):
    """Base class for subprocess-backed WeCom bridge channels."""

    _process: asyncio.subprocess.Process | None = None

    def __init__(self, on_receive: MessageHandler) -> None:
        self._on_receive = on_receive
        self._stdout_task: asyncio.Task[None] | None = None
        self._stderr_task: asyncio.Task[None] | None = None
        self._ready = asyncio.Event()
        self._bridge_info: dict[str, Any] = {}
        self._bridge_state: str | None = None
        self._bridge_provisioning: BridgeProvisioning | None = None

    async def start(self, stop_event: asyncio.Event) -> None:
        del stop_event
        command = self.command
        if not command:
            logger.info("bridge.start channel={} configured=false", self.name)
            return
        await self.prepare()
        self._ready.clear()
        self._bridge_info = {}
        self._bridge_state = None
        self._bridge_provisioning = None
        self._process = await asyncio.create_subprocess_exec(
            *command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        self._stdout_task = asyncio.create_task(self._stdout_loop())
        self._stderr_task = asyncio.create_task(self._stderr_loop())
        for frame in self.startup_frames:
            await self._send_frame(frame)
        logger.info("bridge.start channel={} command={}", self.name, command)
        with contextlib.suppress(TimeoutError):
            async with asyncio.timeout(self.ready_timeout_seconds):
                await self._ready.wait()
        if not self._ready.is_set():
            logger.warning("bridge.start channel={} ready_timeout_seconds={}", self.name, self.ready_timeout_seconds)

    async def stop(self) -> None:
        for task in (self._stdout_task, self._stderr_task):
            if task is not None:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self._stdout_task = None
        self._stderr_task = None
        if self._process is not None:
            if self._process.returncode is None:
                forced_kill = await terminate_process(self._process, timeout_seconds=max(self.ready_timeout_seconds, 1.0))
                if forced_kill:
                    logger.warning("bridge.stop force_killed channel={}", self.name)
            self._process = None
        self._ready.clear()
        self._bridge_state = None
        self._bridge_provisioning = None
        logger.info("bridge.stopped channel={}", self.name)

    async def send(self, message: ChannelMessage) -> None:
        if not self._ready.is_set():
            async with asyncio.timeout(self.ready_timeout_seconds):
                await self._ready.wait()
        await self._send_frame(build_action_frame(self.outbound_action(message)))

    def outbound_action(self, message: ChannelMessage) -> dict[str, Any]:
        return message_to_action(message, route_channel=self.name)

    @property
    def command(self) -> Sequence[str]:
        return ()

    @property
    def startup_frames(self) -> list[dict[str, Any]]:
        return []

    async def prepare(self) -> None:
        return

    @property
    def ready_timeout_seconds(self) -> float:
        return 5.0

    @property
    def is_ready(self) -> bool:
        return self._ready.is_set()

    @property
    def bridge_info(self) -> dict[str, Any]:
        return dict(self._bridge_info)

    @property
    def bridge_state(self) -> str | None:
        return self._bridge_state

    @property
    def bridge_provisioning(self) -> BridgeProvisioning | None:
        return self._bridge_provisioning

    async def _stdout_loop(self) -> None:
        if self._process is None or self._process.stdout is None:
            return
        while True:
            line = await self._process.stdout.readline()
            if not line:
                break
            raw = line.decode("utf-8", errors="replace").strip()
            if not raw:
                continue
            try:
                record = json.loads(raw)
            except json.JSONDecodeError:
                logger.info("bridge.stdout channel={} raw={}", self.name, raw)
                continue
            await self._handle_record(record)

    async def _stderr_loop(self) -> None:
        if self._process is None or self._process.stderr is None:
            return
        while True:
            line = await self._process.stderr.readline()
            if not line:
                break
            raw = line.decode("utf-8", errors="replace").strip()
            if raw:
                logger.warning("bridge.stderr channel={} raw={}", self.name, raw)

    async def _handle_record(self, record: dict[str, Any]) -> None:
        record_type = str(record.get("type", ""))
        version = str(record.get("version", BRIDGE_PROTOCOL_VERSION))
        if version != BRIDGE_PROTOCOL_VERSION:
            logger.warning("bridge.record.version_mismatch channel={} version={}", self.name, version)
        if record_type == "ready":
            self._bridge_info = {key: value for key, value in record.items() if key != "type"}
            self._ready.set()
            logger.info("bridge.ready channel={} info={}", self.name, self._bridge_info)
            return
        if record_type == "state":
            self._bridge_state = str(record.get("state", "unknown"))
            logger.info("bridge.state channel={} state={}", self.name, self._bridge_state)
            return
        if record_type == "provisioning":
            provisioning = record.get("provisioning", {})
            if not isinstance(provisioning, Mapping):
                logger.warning("bridge.provisioning.invalid channel={} payload={}", self.name, record)
                return
            self._bridge_provisioning = BridgeProvisioning.from_mapping(provisioning)
            logger.info("bridge.provisioning channel={} state={}", self.name, self._bridge_provisioning.state)
            return
        if record_type in {"inbound", "message", "inbound_message"}:
            payload = record.get("message", record)
            if not isinstance(payload, Mapping):
                logger.warning("bridge.record.invalid channel={} payload={}", self.name, record)
                return
            await self._on_receive(_channel_message_from_bridge_payload(payload))
            return
        if record_type == "log":
            level = str(record.get("level", "info")).lower()
            log_method = getattr(logger, level, logger.info)
            extras = {key: value for key, value in record.items() if key not in {"type", "version", "level", "message"}}
            if extras:
                log_method("bridge.log channel={} message={} extras={}", self.name, record.get("message", ""), extras)
            else:
                log_method("bridge.log channel={} message={}", self.name, record.get("message", ""))
            return
        logger.debug("bridge.record.ignored channel={} type={}", self.name, record_type)

    async def _send_frame(self, frame: dict[str, Any]) -> None:
        if self._process is None or self._process.stdin is None:
            raise RuntimeError(f"{self.name} bridge is not running.")
        payload = json.dumps(frame, ensure_ascii=False) + "\n"
        self._process.stdin.write(payload.encode("utf-8"))
        await self._process.stdin.drain()


def split_command(value: str | None) -> list[str]:
    if value is None:
        return []
    return shlex.split(value)


async def run_command(command: Sequence[str], *, cwd: Path | None = None) -> None:
    process = await asyncio.create_subprocess_exec(
        *command,
        cwd=str(cwd) if cwd is not None else None,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    if process.returncode != 0:
        raise RuntimeError(
            f"command failed exit={process.returncode}: {(stderr or stdout).decode('utf-8', errors='replace').strip()}"
        )


async def terminate_process(process: asyncio.subprocess.Process, *, timeout_seconds: float) -> bool:
    if process.returncode is not None:
        return False
    process.terminate()
    try:
        await asyncio.wait_for(process.wait(), timeout=timeout_seconds)
    except TimeoutError:
        process.kill()
        with contextlib.suppress(ProcessLookupError):
            await process.wait()
        return True
    else:
        return False


def _channel_message_from_bridge_payload(payload: Mapping[str, Any]) -> ChannelMessage:
    channel = str(payload.get("channel", "wecom_longconn_bot"))
    chat_id = str(payload.get("chat_id", "default"))
    session_id = str(payload.get("session_id", f"{channel}:{chat_id}"))
    content = str(payload.get("content", ""))
    context = dict(payload.get("context", {})) if isinstance(payload.get("context"), Mapping) else {}

    conversation = payload.get("conversation")
    if isinstance(conversation, Mapping):
        _set_string(context, "surface", conversation.get("surface"))
        _set_string(context, "thread_id", conversation.get("thread_id"))
        _set_string(context, "tenant_id", conversation.get("tenant_id"))
        metadata = conversation.get("metadata")
        if isinstance(metadata, Mapping):
            for key, value in metadata.items():
                context[f"wecom_conversation_{key}"] = value

    sender = payload.get("sender")
    if isinstance(sender, Mapping):
        _set_string(context, "actor_id", sender.get("id"))
        _set_string(context, "wecom_sender_id_kind", sender.get("id_kind"))

    _set_string(context, "wecom_message_id", payload.get("message_id"))

    reply_grant = payload.get("reply_grant")
    if isinstance(reply_grant, Mapping):
        _set_string(context, "wecom_reply_token", reply_grant.get("token"))
        _set_string(context, "wecom_reply_to_message_id", reply_grant.get("reply_to_message_id"))
        metadata = reply_grant.get("metadata")
        if isinstance(metadata, Mapping):
            _set_string(context, "wecom_response_url", metadata.get("response_url"))
            _set_string(context, "wecom_event_type", metadata.get("event_type"))
            _set_string(context, "wecom_raw_msgtype", metadata.get("raw_msgtype"))

    metadata = payload.get("metadata")
    if isinstance(metadata, Mapping):
        for key, value in metadata.items():
            context[f"wecom_{key}"] = value

    return ChannelMessage(
        session_id=session_id,
        channel=channel,
        chat_id=chat_id,
        content=content,
        is_active=bool(payload.get("is_active", True)),
        context=context,
        media=_media_items_from_attachments(payload.get("attachments")),
    )


def _media_items_from_attachments(value: object) -> list[MediaItem]:
    if not isinstance(value, list):
        return []
    items: list[MediaItem] = []
    for attachment in value:
        if not isinstance(attachment, Mapping):
            continue
        content_type = str(attachment.get("content_type", "application/octet-stream"))
        metadata = attachment.get("metadata")
        metadata_mapping = metadata if isinstance(metadata, Mapping) else {}
        source = _string_or_none(attachment.get("url")) or _string_or_none(metadata_mapping.get("path"))
        data_fetcher = _data_fetcher(source) if source is not None else None
        if content_type.startswith("image/"):
            media_type = "image"
        elif content_type.startswith("audio/"):
            media_type = "audio"
        else:
            media_type = "document"
        items.append(
            MediaItem(
                type=media_type,
                mime_type=content_type,
                filename=_string_or_none(attachment.get("name")),
                data_fetcher=data_fetcher,
            )
        )
    return items


def _data_fetcher(source: str) -> Any:
    async def _fetch() -> bytes:
        if source.startswith("data:"):
            _, encoded = source.split(",", 1)
            return base64.b64decode(encoded)
        if source.startswith("http://") or source.startswith("https://"):
            async with aiohttp.ClientSession() as session, session.get(source) as response:
                response.raise_for_status()
                return await response.read()
        path = Path(source.removeprefix("file://")).expanduser()
        return await asyncio.to_thread(path.read_bytes)

    return _fetch


def _string_or_none(value: object) -> str | None:
    if value is None:
        return None
    text = str(value)
    return text if text else None


def _set_string(context: dict[str, Any], key: str, value: object) -> None:
    text = _string_or_none(value)
    if text is not None:
        context[key] = text


def _to_primitive(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _to_primitive(item) for key, item in value.items()}
    if isinstance(value, list | tuple | set):
        return [_to_primitive(item) for item in value]
    if hasattr(value, "__dict__"):
        return _to_primitive(vars(value))
    return value
