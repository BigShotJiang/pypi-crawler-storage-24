from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from bub.channels.message import ChannelMessage


def parse_json_object(text: str) -> dict[str, Any] | None:
    stripped = text.strip()
    if not stripped:
        return None
    try:
        value = json.loads(stripped)
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def message_to_action(message: ChannelMessage, *, route_channel: str) -> dict[str, Any]:
    payload = parse_json_object(message.content)
    raw_action = _embedded_action(payload)
    if raw_action is not None:
        return _finalize_action(dict(raw_action), message=message, route_channel=route_channel)

    action = _base_action(message, route_channel=route_channel)
    if payload is None:
        return action

    _apply_payload_fields(action, payload=payload, context=message.context)
    return action


def _base_action(message: ChannelMessage, *, route_channel: str) -> dict[str, Any]:
    return {
        "kind": "send_message",
        "conversation": {"chat_id": message.chat_id, "route_channel": route_channel},
        "text": message.content,
        "content_type": "text",
    }


def _embedded_action(payload: Mapping[str, Any] | None) -> Mapping[str, Any] | None:
    if payload is None:
        return None
    for key in ("wecom_action", "action"):
        raw = payload.get(key)
        if isinstance(raw, Mapping):
            return raw
    return None


def _apply_payload_fields(action: dict[str, Any], *, payload: Mapping[str, Any], context: Mapping[str, Any]) -> None:
    text = _first_string(payload.get("text"), payload.get("message"))
    if text is not None:
        action["text"] = text

    content_type = _normalize_content_type(payload)
    if content_type is not None:
        action["content_type"] = content_type

    card = payload.get("card")
    if not isinstance(card, dict):
        card = payload.get("template_card")
    if isinstance(card, dict):
        action["card"] = card
        action["content_type"] = "card"

    source = _first_string(
        payload.get("source"),
        payload.get("path"),
        payload.get("url"),
    )
    if source is not None and action.get("content_type") in {"image", "file", "audio"}:
        action["text"] = source

    mentions = _normalize_mentions(payload.get("mentions"))
    if mentions:
        action["mentions"] = mentions

    target_ids = _normalize_target_ids(payload.get("target_ids"))
    if target_ids:
        action["target_ids"] = target_ids

    reply_grant = _normalize_reply_grant(payload.get("reply_grant"))
    if reply_grant is None:
        reply_grant = _reply_grant_from_context(context)
    if reply_grant is not None:
        action["reply_grant"] = reply_grant


def _finalize_action(raw: dict[str, Any], *, message: ChannelMessage, route_channel: str) -> dict[str, Any]:
    conversation = raw.get("conversation")
    if not isinstance(conversation, Mapping):
        raw["conversation"] = {"chat_id": message.chat_id, "route_channel": route_channel}
    else:
        raw["conversation"] = {
            "chat_id": str(conversation.get("chat_id", message.chat_id)),
            "route_channel": str(conversation.get("route_channel", route_channel)),
        }
    raw.setdefault("kind", "send_message")
    raw.setdefault("text", message.content)
    raw.setdefault("content_type", _normalize_content_type(raw) or "text")
    return raw


def _normalize_content_type(payload: Mapping[str, Any]) -> str | None:
    msgtype = _first_string(payload.get("msgtype"), payload.get("content_type"))
    if msgtype is None:
        return None
    normalized = msgtype.casefold()
    if normalized in {"markdown", "markdown_v2", "rich_text"}:
        return "rich_text"
    if normalized in {"template_card", "card"}:
        return "card"
    if normalized == "voice":
        return "audio"
    if normalized in {"image", "file", "audio", "text"}:
        return normalized
    return msgtype


def _normalize_mentions(value: object) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    mentions: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, Mapping):
            continue
        kind = _first_string(item.get("kind"))
        mention_value = _first_string(item.get("value"))
        if kind is None or mention_value is None:
            continue
        mentions.append({"kind": kind, "value": mention_value})
    return mentions


def _normalize_target_ids(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if str(item).strip()]


def _normalize_reply_grant(value: object) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    token = _first_string(value.get("token"))
    if token is None:
        return None
    metadata = value.get("metadata")
    normalized: dict[str, Any] = {"token": token}
    reply_to_message_id = _first_string(value.get("reply_to_message_id"))
    if reply_to_message_id is not None:
        normalized["reply_to_message_id"] = reply_to_message_id
    if isinstance(metadata, Mapping):
        normalized["metadata"] = dict(metadata)
    return normalized


def _reply_grant_from_context(context: Mapping[str, Any]) -> dict[str, Any] | None:
    token = _first_string(context.get("wecom_reply_token"))
    if token is None:
        return None
    metadata: dict[str, Any] = {}
    response_url = _first_string(context.get("wecom_response_url"))
    event_type = _first_string(context.get("wecom_event_type"))
    raw_msgtype = _first_string(context.get("wecom_raw_msgtype"))
    if response_url is not None:
        metadata["response_url"] = response_url
    if event_type is not None:
        metadata["event_type"] = event_type
    if raw_msgtype is not None:
        metadata["raw_msgtype"] = raw_msgtype
    reply_grant: dict[str, Any] = {"token": token}
    reply_to_message_id = _first_string(context.get("wecom_message_id"))
    if reply_to_message_id is not None:
        reply_grant["reply_to_message_id"] = reply_to_message_id
    if metadata:
        reply_grant["metadata"] = metadata
    return reply_grant


def _first_string(*values: object) -> str | None:
    for value in values:
        if isinstance(value, str) and value.strip():
            return value
    return None
