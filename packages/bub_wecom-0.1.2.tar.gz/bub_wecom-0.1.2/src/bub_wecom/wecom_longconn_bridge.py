from __future__ import annotations

import argparse
import asyncio
import json
import sys
from dataclasses import dataclass
from typing import Any

from bub.channels.message import ChannelMessage

from bub_wecom.bridge_runtime import (
    build_action_frame,
    build_configure_frame,
    build_inbound_message_frame,
    build_log_frame,
    build_provisioning_frame,
    build_ready_frame,
    build_state_frame,
)
from bub_wecom.outbound import message_to_action


@dataclass(slots=True)
class _BridgeState:
    channel: str
    chat_id: str
    configured: bool = False
    config: dict[str, Any] | None = None


async def main_async() -> int:
    parser = argparse.ArgumentParser(description="Bundled WeCom long-connection bridge for Bub.")
    parser.add_argument("--channel", default="wecom_longconn_bot")
    parser.add_argument("--chat-id", default="wecom-dev-chat")
    parser.add_argument("--boot-message", default="")
    parser.add_argument("--echo-actions", action="store_true")
    args = parser.parse_args()

    state = _BridgeState(channel=args.channel, chat_id=args.chat_id)
    if args.boot_message:
        _emit(
            build_inbound_message_frame(
                ChannelMessage(
                    session_id=f"{args.channel}:{args.chat_id}",
                    channel=args.channel,
                    chat_id=args.chat_id,
                    content=args.boot_message,
                    is_active=True,
                )
            )
        )

    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            frame = json.loads(raw)
        except json.JSONDecodeError:
            _emit(build_log_frame("invalid json from host", level="warning", raw=raw))
            continue

        frame_type = str(frame.get("type", ""))
        if frame_type == "configure":
            await _handle_configure(frame, state)
            continue
        if frame_type == "action":
            await _handle_action(frame, state, echo_actions=args.echo_actions)
            continue
        _emit(build_log_frame("ignored frame", level="debug", frame_type=frame_type))

    return 0


async def _handle_configure(frame: dict[str, Any], state: _BridgeState) -> None:
    config = frame.get("config", {})
    state.config = config if isinstance(config, dict) else {}
    state.configured = bool(state.config.get("bot_id") and state.config.get("secret"))
    _emit(
        build_provisioning_frame(
            {
                "mode": "interactive_pairing",
                "state": "active" if state.configured else "pending",
                "pairing_code": _string_or_none(state.config.get("pairing_code")),
                "config_key": _string_or_none(state.config.get("config_key")),
                "metadata": {
                    "callback_token": _string_or_none(state.config.get("callback_token")),
                    "encoding_aes_key": _string_or_none(state.config.get("encoding_aes_key")),
                },
            }
        )
    )
    _emit(build_state_frame("configured", configured=state.configured))
    _emit(build_ready_frame(state.channel, name="wecom_longconn_bridge", configured=state.configured))


async def _handle_action(frame: dict[str, Any], state: _BridgeState, *, echo_actions: bool) -> None:
    action_payload = frame.get("action", {})
    if not isinstance(action_payload, dict):
        _emit(build_log_frame("invalid action payload", level="warning"))
        return
    _emit(build_log_frame("translated action", request=action_payload))
    if echo_actions and isinstance(action_payload.get("text"), str) and action_payload["text"]:
        _emit(
            build_inbound_message_frame(
                ChannelMessage(
                    session_id=f"{state.channel}:{state.chat_id}",
                    channel=state.channel,
                    chat_id=state.chat_id,
                    content=f"echo: {action_payload['text']}",
                )
            )
        )


def _emit(frame: dict[str, object]) -> None:
    print(json.dumps(frame, ensure_ascii=False), flush=True)


def _string_or_none(value: object) -> str | None:
    if value is None:
        return None
    text = str(value)
    return text if text else None


def message_frame_for_text(channel: str, chat_id: str, text: str) -> dict[str, Any]:
    message = ChannelMessage(session_id=f"{channel}:{chat_id}", channel=channel, chat_id=chat_id, content=text)
    return build_action_frame(message_to_action(message, route_channel=channel))


def configure_frame(channel: str, config: dict[str, Any]) -> dict[str, Any]:
    return build_configure_frame(channel, config)


def main() -> int:
    return asyncio.run(main_async())


if __name__ == "__main__":
    raise SystemExit(main())
