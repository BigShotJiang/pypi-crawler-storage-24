from __future__ import annotations

from bub.channels.base import Channel
from bub.hookspecs import hookimpl
from bub.types import MessageHandler, State

WECOM_SYSTEM_PROMPT = """\
For inbound conversations on Bub's WeCom native channel (`wecom_longconn_bot`), your final plain text answer will be routed automatically by Bub.
Do NOT invoke `wecom_longconn_send.py` while handling an inbound `wecom_longconn_bot` message unless you need a proactive message or another native WeCom-only action.
"""


class WeComPlugin:
    """External Bub plugin that provides WeCom channels and prompt guidance."""

    def __init__(self, framework: object) -> None:
        self.framework = framework

    @hookimpl
    def provide_channels(self, message_handler: MessageHandler) -> list[Channel]:
        from bub_wecom.wecom_longconn_bot import WeComLongConnBotChannel
        from bub_wecom.wecom_webhook import WeComWebhookChannel

        return [
            WeComWebhookChannel(),
            WeComLongConnBotChannel(on_receive=message_handler),
        ]

    @hookimpl
    def system_prompt(self, prompt: str | list[dict], state: State) -> str:
        del prompt, state
        return WECOM_SYSTEM_PROMPT
