from __future__ import annotations

import asyncio
import contextlib
import json

import pytest
from bub.channels.message import ChannelMessage

from bub_wecom.bridge_runtime import build_action_frame, build_configure_frame
from bub_wecom.outbound import message_to_action
from bub_wecom.wecom_longconn_bot import WeComLongConnBotChannel

BRIDGE_SCRIPT = WeComLongConnBotChannel._bridge_script_path()
FAKE_TARGET_USER_ID = "wecom_user_12ab45cd"
FAKE_SECOND_TARGET_USER_ID = "wecom_user_98ef76ab"


async def _write_frame(process: asyncio.subprocess.Process, frame: dict[str, object]) -> None:
    assert process.stdin is not None
    process.stdin.write((json.dumps(frame) + "\n").encode("utf-8"))
    await process.stdin.drain()


async def _read_until_log(process: asyncio.subprocess.Process) -> dict[str, object]:
    assert process.stdout is not None
    while True:
        line = await asyncio.wait_for(process.stdout.readline(), timeout=3)
        if not line:
            raise RuntimeError("bridge closed before producing a translation log")
        record = json.loads(line.decode("utf-8"))
        if record.get("type") == "log" and record.get("message") in {"translated action", "failed to translate action"}:
            return record


async def _translate_action(action: dict[str, object]) -> dict[str, object]:
    process = await asyncio.create_subprocess_exec(
        "node",
        str(BRIDGE_SCRIPT),
        "--channel",
        "wecom_longconn_bot",
        "--mock",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        await _write_frame(
            process,
            build_configure_frame("wecom_longconn_bot", {"bot_id": "bot-id", "secret": "secret"}),
        )
        await _write_frame(process, build_action_frame(action))
        return await _read_until_log(process)
    finally:
        if process.stdin is not None:
            process.stdin.close()
            with contextlib.suppress(Exception):
                await process.stdin.wait_closed()
        if process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                process.terminate()
            with contextlib.suppress(Exception):
                await process.wait()


@pytest.mark.asyncio
async def test_node_wecom_longconn_bridge_translates_proactive_text_to_markdown_send() -> None:
    action = message_to_action(
        ChannelMessage(
            session_id="wecom_longconn_bot:chat-1",
            channel="wecom_longconn_bot",
            chat_id="chat-1",
            content="hello",
        ),
        route_channel="wecom_longconn_bot",
    )
    record = await _translate_action(action)

    request = record["request"]
    assert request["op"] == "sendMessage"
    assert request["args"] == ["chat-1", {"msgtype": "markdown", "markdown": {"content": "hello"}}]


@pytest.mark.asyncio
async def test_node_wecom_longconn_bridge_translates_passive_text_reply_to_reply_stream() -> None:
    action = {
        "kind": "reply_message",
        "conversation": {"chat_id": "chat-1", "route_channel": "wecom_longconn_bot"},
        "text": "hello",
        "reply_grant": {"token": "req-1"},
    }
    record = await _translate_action(action)

    request = record["request"]
    assert request["op"] == "replyStream"
    assert request["args"][0] == {"headers": {"req_id": "req-1"}}
    assert isinstance(request["args"][1], str)
    assert request["args"][2:] == ["hello", True]
    assert request["fallback"]["op"] == "sendMessage"
    assert request["fallback"]["args"] == ["chat-1", {"msgtype": "markdown", "markdown": {"content": "hello"}}]


@pytest.mark.asyncio
async def test_node_wecom_longconn_bridge_translates_update_card_from_native_fields() -> None:
    card = {"card_type": "text_notice", "main_title": {"title": "updated"}}
    record = await _translate_action(
        {
            "kind": "update_card",
            "conversation": {"chat_id": "chat-1", "route_channel": "wecom_longconn_bot"},
            "content_type": "card",
            "card": card,
            "target_ids": [FAKE_TARGET_USER_ID, FAKE_SECOND_TARGET_USER_ID],
            "reply_grant": {"token": "req-1", "metadata": {"event_type": "template_card_event"}},
        }
    )

    request = record["request"]
    assert request["op"] == "updateTemplateCard"
    assert request["args"] == [
        {"headers": {"req_id": "req-1"}},
        card,
        [FAKE_TARGET_USER_ID, FAKE_SECOND_TARGET_USER_ID],
    ]
