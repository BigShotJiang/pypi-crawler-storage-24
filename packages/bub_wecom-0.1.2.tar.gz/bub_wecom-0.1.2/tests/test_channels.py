from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest
from bub.channels.message import ChannelMessage
from bub.framework import BubFramework

from bub_wecom.plugin import WECOM_SYSTEM_PROMPT, WeComPlugin
from bub_wecom.wecom_longconn_bot import WeComLongConnBotChannel
from bub_wecom.wecom_webhook import WeComWebhookChannel

FAKE_MENTION_USER_ID = "wecom_user_0d54ef21"


def test_plugin_provides_wecom_channels_and_prompt() -> None:
    plugin = WeComPlugin(BubFramework())

    async def on_receive(_message) -> None:
        return None

    channels = plugin.provide_channels(on_receive)

    assert [channel.name for channel in channels] == ["wecom_webhook", "wecom_longconn_bot"]
    assert isinstance(channels[0], WeComWebhookChannel)
    assert isinstance(channels[1], WeComLongConnBotChannel)
    assert plugin.system_prompt(prompt="hello", state={}) == WECOM_SYSTEM_PROMPT


@pytest.mark.asyncio
async def test_wecom_webhook_channel_send_text_with_mentions(monkeypatch: pytest.MonkeyPatch) -> None:
    channel = WeComWebhookChannel()
    channel._settings.webhook_url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=test-key"
    sent: list[dict[str, object]] = []

    async def post_json(payload: dict[str, object]) -> None:
        sent.append(payload)

    monkeypatch.setattr(channel, "_post_json", post_json)

    await channel.send(
        ChannelMessage(
            session_id="wecom_webhook:room",
            channel="wecom_webhook",
            chat_id="room",
            content=json.dumps(
                {
                    "message": "hello",
                    "mentions": [
                        {"kind": "user_id", "value": FAKE_MENTION_USER_ID},
                        {"kind": "mobile", "value": "13800001111"},
                        {"kind": "all", "value": "@all"},
                    ],
                }
            ),
        )
    )

    assert sent == [
        {
            "msgtype": "text",
            "text": {
                "content": "hello",
                "mentioned_list": [FAKE_MENTION_USER_ID, "@all"],
                "mentioned_mobile_list": ["13800001111", "@all"],
            },
        }
    ]


@pytest.mark.asyncio
async def test_wecom_webhook_channel_send_file_uploads_media_first(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    channel = WeComWebhookChannel()
    channel._settings.webhook_url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=test-key"
    sent: list[dict[str, object]] = []
    file_path = tmp_path / "report.pdf"

    async def upload_media(media_type: str, action: dict[str, object]) -> str:
        assert media_type == "file"
        assert action["text"] == str(file_path)
        return "MEDIA123"

    async def post_json(payload: dict[str, object]) -> None:
        sent.append(payload)

    monkeypatch.setattr(channel, "_upload_media", upload_media)
    monkeypatch.setattr(channel, "_post_json", post_json)

    await channel.send(
        ChannelMessage(
            session_id="wecom_webhook:room",
            channel="wecom_webhook",
            chat_id="room",
            content=json.dumps({"source": str(file_path), "content_type": "file"}),
        )
    )

    assert sent == [{"msgtype": "file", "file": {"media_id": "MEDIA123"}}]


@pytest.mark.asyncio
async def test_wecom_webhook_channel_send_template_card_uses_native_card_field(monkeypatch: pytest.MonkeyPatch) -> None:
    channel = WeComWebhookChannel()
    channel._settings.webhook_url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=test-key"
    sent: list[dict[str, object]] = []

    async def post_json(payload: dict[str, object]) -> None:
        sent.append(payload)

    monkeypatch.setattr(channel, "_post_json", post_json)

    await channel.send(
        ChannelMessage(
            session_id="wecom_webhook:room",
            channel="wecom_webhook",
            chat_id="room",
            content=json.dumps(
                {
                    "content_type": "card",
                    "card": {"card_type": "text_notice", "main_title": {"title": "hello"}},
                }
            ),
        )
    )

    assert sent == [
        {
            "msgtype": "template_card",
            "template_card": {"card_type": "text_notice", "main_title": {"title": "hello"}},
        }
    ]


def test_wecom_webhook_channel_upload_url_derives_key_and_type() -> None:
    channel = WeComWebhookChannel()
    channel._settings.webhook_url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=test-key"

    assert (
        channel._upload_url("voice")
        == "https://qyapi.weixin.qq.com/cgi-bin/webhook/upload_media?key=test-key&type=voice"
    )


@pytest.mark.asyncio
async def test_wecom_longconn_bot_channel_start_and_send_via_bundled_mock_bridge() -> None:
    received = []

    async def on_receive(message) -> None:
        received.append(message)

    channel = WeComLongConnBotChannel(on_receive=on_receive)
    channel._settings = channel._settings.model_copy(
        update={
            "command": (
                "node "
                f"{WeComLongConnBotChannel._bridge_script_path()} "
                "--channel wecom_longconn_bot --mock --echo-actions"
            ),
            "bot_id": "bot-id",
            "secret": "token-value",
            "pairing_code": "PAIR-123",
            "config_key": "CONF-456",
            "callback_token": "token-abc",
            "encoding_aes_key": "aes-key-xyz",
        }
    )

    await channel.start(asyncio.Event())
    assert channel.is_ready is True
    assert channel.bridge_info["channel"] == "wecom_longconn_bot"
    assert channel.bridge_info["configured"] is True
    assert channel.bridge_state == "configured"
    assert channel.bridge_provisioning is not None
    assert channel.bridge_provisioning.state == "active"
    assert channel.bridge_provisioning.pairing_code == "PAIR-123"
    assert channel.bridge_provisioning.config_key == "CONF-456"
    await asyncio.sleep(0.2)
    await channel.send(
        ChannelMessage(
            session_id="wecom_longconn_bot:chat-1",
            channel="wecom_longconn_bot",
            chat_id="chat-1",
            content="ping",
        )
    )
    await asyncio.sleep(0.2)
    await channel.stop()

    assert channel.is_ready is False
    assert received[0].channel == "wecom_longconn_bot"
    assert received[0].content == "echo: ping"


def test_wecom_longconn_bot_channel_command_parsing_and_startup_frames() -> None:
    channel = WeComLongConnBotChannel(lambda message: None)
    channel._settings = channel._settings.model_copy(
        update={
            "command": "python bridge.py --flag",
            "bot_id": "bot-id",
            "secret": "token-value",
            "pairing_code": "PAIR-123",
            "config_key": "CONF-456",
            "callback_token": "token-abc",
            "encoding_aes_key": "aes-key-xyz",
        }
    )

    assert list(channel.command) == ["python", "bridge.py", "--flag"]
    assert channel.ready_timeout_seconds == 5.0
    assert channel.startup_frames[0]["type"] == "configure"
    assert channel.startup_frames[0]["config"]["bot_id"] == "bot-id"
    assert channel.startup_frames[0]["config"]["config_key"] == "CONF-456"


def test_wecom_longconn_bot_channel_uses_bundled_bridge_when_credentials_present() -> None:
    channel = WeComLongConnBotChannel(lambda message: None)
    channel._settings = channel._settings.model_copy(update={"bot_id": "bot-id", "secret": "token-value"})

    command = list(channel.command)

    assert command[0] == "node"
    assert command[1] == str(WeComLongConnBotChannel._bridge_script_path())
    assert command[-2:] == ["--channel", "wecom_longconn_bot"]


def test_wecom_longconn_bot_channel_appends_mock_flag_for_bundled_bridge() -> None:
    channel = WeComLongConnBotChannel(lambda message: None)
    channel._settings = channel._settings.model_copy(
        update={"bot_id": "bot-id", "secret": "token-value", "mock": True}
    )

    assert list(channel.command)[-1] == "--mock"
