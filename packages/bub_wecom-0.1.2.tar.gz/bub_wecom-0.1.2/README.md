# bub-wecom

WeCom channel plugin for the [Bub fork](https://github.com/ximenzun/bub).

## Install

> Note
> This package targets the `ximenzun/bub` fork. It is not an official `bubbuild/bub` plugin package, and compatibility with upstream Bub should not be assumed.

Once published:

```bash
uv pip install bub-wecom
```

For local development next to the Bub repo:

```bash
cd ../bub-wecom
uv sync
```

## Included Channels

- `wecom_webhook`: outbound-only Enterprise WeCom webhook adapter
- `wecom_longconn_bot`: Enterprise WeCom smart-bot bridge adapter

## Usage

Once installed, `bub gateway` will auto-discover this plugin via Python entry points.

```bash
uv run bub gateway --enable-channel wecom_longconn_bot
uv run bub gateway --enable-channel wecom_webhook
```

When `bub-wecom` is checked out next to [bub](https://github.com/ximenzun/bub), `uv sync` uses the sibling `../bub` checkout as an editable dependency via `tool.uv.sources`, matching the local-development workflow used by `bub-social-coding`.

## Run

From the `bub-wecom` repo root:

```bash
uv sync
uv run bub gateway --enable-channel wecom_longconn_bot
```

Use the bundled WeCom skill after installation; it is shipped through the `bub_skills` namespace package.

## Release

Publishing is driven by GitHub Actions.
Create a GitHub Release on `main` with a tag like `v0.1.0` or `0.1.0`, and the release workflow will:

1. normalize the tag to a package version
2. build the sdist and wheel
3. publish to PyPI through Trusted Publishing (GitHub OIDC)

No long-lived `PYPI_TOKEN` secret is required when PyPI Trusted Publisher is configured for `.github/workflows/on-release-main.yml`.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for the local workflow, verification commands, and pull request process.

## Development

```bash
uv run pytest -q
uv run ruff check .
```
