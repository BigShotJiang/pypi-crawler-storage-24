# +-------------------------------------+
# |         ~ Author : Xenely ~         |
# +=====================================+
# | GitHub: https://github.com/Xenely14 |
# | Discord: xenely                     |
# +-------------------------------------+

# ==-------------------------------------------------------------------== #
# Classes                                                                 #
# ==-------------------------------------------------------------------== #
class NtError(Exception):
    """Exception that raises on `nt` functions calls fails."""

    # ==--------------------------------== #
    # Public methods                       #
    # ==--------------------------------== #
    def __init__(self, message: str, status: int | None) -> None:
        """Initialize instance of `nt` error."""

        # Save initializer arguments as an attributes
        self.message = message
        self.status = status

        # Call initializer of parrent class
        super().__init__(message)

    def __str__(self) -> str:
        """Overload triggered on `str` cast calls"""

        # If error status is defined
        if self.status is not None:
            return "Nt function failed with `%s` status: %s" % (self.get_hex_status(), self.message)

        # If error status is not defined
        return "Nt function failed: %s" % self.message

    def get_hex_status(self, hex_prefix: str | None = "0x") -> str:
        """Get error `nt`status in hex string view."""

        return "%s%08x" % (hex_prefix if hex_prefix is not None else "", self.status)


class OpenProcessError(NtError):
    """Exception that raises on process open fail."""

    # ==--------------------------------== #
    # Public methods                       #
    # ==--------------------------------== #
    def __init__(self, message: str, status: int | None = None) -> None:
        """Initialize instance of `nt` error."""

        # Call initializer of parrent class
        super().__init__(message, status)

    def __str__(self) -> str:
        """Overload triggered on `str` cast calls."""

        # If error status is defined
        if self.status is not None:
            return "Unable to open process due `nt` function failed with `%s` status: %s" % (self.get_hex_status(), self.message)

        # If error status is not defined
        return "Unable to open process: %s" % self.message


class MemoryReadError(NtError):
    """Exception that raises on virtual memory read fail."""

    # ==--------------------------------== #
    # Public methods                       #
    # ==--------------------------------== #
    def __init__(self, status: int, address: int):

        # Save initializer arguments as an attributes
        self.address = address

        # Call initializer of parrent class
        super().__init__(None, status)

    def __str__(self) -> str:
        """Overload triggered on `str` cast calls"""

        return "Unalble to read memory at `0x%08x` address, `nt` function failed with `%s` status" % (self.address, self.get_hex_status())


class MemoryWriteError(NtError):
    """Exception that raises on virtual memory read fail."""

    # ==--------------------------------== #
    # Public methods                       #
    # ==--------------------------------== #
    def __init__(self, status: int, address: int):

        # Save initializer arguments as an attributes
        self.address = address

        # Call initializer of parrent class
        super().__init__(None, status)

    def __str__(self) -> str:
        """Overload triggered on `str` cast calls"""

        return "Unalble to write memory at `0x%08x` address, `nt` function failed with `%s` status" % (self.address, self.get_hex_status())
