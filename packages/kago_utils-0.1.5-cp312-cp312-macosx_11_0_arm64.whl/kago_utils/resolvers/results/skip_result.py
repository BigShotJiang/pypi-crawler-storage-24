class SkipResult:
    pass
