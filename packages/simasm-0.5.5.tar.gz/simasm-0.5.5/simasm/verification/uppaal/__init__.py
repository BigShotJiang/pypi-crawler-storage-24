"""
UPPAAL timed automata verification for Event Graph models.

Implements the verified compilation pipeline:
  Bounded-ASM(EG) -> UPPAAL Network of Timed Automata (NTA)

Modules:
- abstraction: Step 2 — ASM(EG) -> Bounded-ASM(EG) (bounds checking + abstraction)
- compiler: Step 3 — Bounded-ASM(EG) -> UPPAAL NTA construction
- model: Pydantic data model for UPPAAL NTA elements
- xml_emitter: Serialize UppaalModel -> UPPAAL XML
- properties: Standard UPPAAL property templates (safety, liveness, bounded response)

References:
- Alur & Dill (1994). A Theory of Timed Automata.
- Saadawi & Wainer (2009, 2013). DEVS Model Verification via Timed Automata.
- Project 3 plan: files/project_3/plans/03_verified_compilation_plan.md
"""
