from unittest.mock import patch

import pytest

from matterlab_hotplates.ika_hotplate import IKAHotplate
from tests.conftest import PORT


@pytest.fixture
def hotplate_fixture(mock_serial):
    return IKAHotplate(com_port=PORT, connect_hardware=False)


def test_initialization_defaults(mock_serial, hotplate_fixture):
    assert isinstance(hotplate_fixture, IKAHotplate)
    assert hotplate_fixture.max_temp == 200
    assert hotplate_fixture.max_rpm == 1700
    assert hotplate_fixture.device is mock_serial
    assert hotplate_fixture._tared is False


def test_default_initialization_sequence(mock_serial):
    with patch.object(IKAHotplate, "reset", autospec=True) as reset_spy, patch.object(
        IKAHotplate,
        "stand_by",
        autospec=True,
    ) as standby_spy:
        hotplate = IKAHotplate(com_port=PORT)

    reset_spy.assert_called_once_with(hotplate)
    standby_spy.assert_called_once_with(hotplate)


def test_write_hotplate(hotplate_fixture, mocker):
    mocker.patch("matterlab_hotplates.ika_hotplate.time.sleep")
    write_spy = mocker.patch.object(hotplate_fixture, "write")

    hotplate_fixture._write_hotplate("test")

    write_spy.assert_called_once_with("test\r\n")


def test_query_hotplate(hotplate_fixture, mocker):
    query_spy = mocker.patch.object(hotplate_fixture, "query", return_value="123.4 C\r\n")

    assert hotplate_fixture._query_hotplate("test") == "123.4"

    query_spy.assert_called_once_with(write_command="test\r\n", read_delay=0.5)


def test_reset_writes_reset_command(hotplate_fixture, mocker):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture.reset()

    write_spy.assert_called_once_with(IKAHotplate._reset)


def test_get_temp(hotplate_fixture, mocker):
    query_spy = mocker.patch.object(hotplate_fixture, "_query_hotplate", return_value="50.0")

    assert hotplate_fixture.temp == 50.0
    query_spy.assert_called_once_with(IKAHotplate._temp_query)


@pytest.mark.parametrize(
    ("temp", "switch_status", "switch_cmd"),
    [
        (0, False, IKAHotplate._heat_stop),
        (100, True, IKAHotplate._heat_start),
    ],
)
def test_set_temp(hotplate_fixture, mocker, temp, switch_status, switch_cmd):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture.temp = temp

    assert hotplate_fixture.target_temp == temp
    assert hotplate_fixture._heat_switch is switch_status
    write_spy.assert_has_calls(
        [
            mocker.call(f"{IKAHotplate._temp_set} {temp:.1f}"),
            mocker.call(switch_cmd),
        ]
    )


def test_set_temp_raises_type_error(hotplate_fixture):
    with pytest.raises(TypeError, match="Temperature must be float or int!"):
        hotplate_fixture.temp = "invalid"


@pytest.mark.parametrize("temp", [-10, 250])
def test_set_temp_raises_value_error(hotplate_fixture, temp):
    with pytest.raises(ValueError, match="Temperature out of range: min 0, max 200!"):
        hotplate_fixture.temp = temp


@pytest.mark.parametrize("heat_switch_status", [True, False])
def test_heat_switch_property(hotplate_fixture, mocker, heat_switch_status):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture._heat_switch = heat_switch_status

    assert hotplate_fixture._heat_switch is heat_switch_status
    write_spy.assert_called_once_with(IKAHotplate._heat_start if heat_switch_status else IKAHotplate._heat_stop)


def test_get_rpm(hotplate_fixture, mocker):
    query_spy = mocker.patch.object(hotplate_fixture, "_query_hotplate", return_value="500")

    assert hotplate_fixture.rpm == 500
    query_spy.assert_called_once_with(IKAHotplate._rpm_query)


@pytest.mark.parametrize(
    ("rpm", "switch_status", "switch_cmd"),
    [
        (0, False, IKAHotplate._stir_stop),
        (400, True, IKAHotplate._stir_start),
    ],
)
def test_set_rpm(hotplate_fixture, mocker, rpm, switch_status, switch_cmd):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture.rpm = rpm

    assert hotplate_fixture.target_rpm == rpm
    assert hotplate_fixture._stir_switch is switch_status
    write_spy.assert_has_calls(
        [
            mocker.call(f"{IKAHotplate._rpm_set} {rpm}"),
            mocker.call(switch_cmd),
        ]
    )


def test_set_rpm_raises_type_error(hotplate_fixture):
    with pytest.raises(TypeError, match="rpm must be an integer"):
        hotplate_fixture.rpm = "invalid"


def test_set_rpm_raises_value_error(hotplate_fixture):
    with pytest.raises(ValueError, match="RPM out of range: min 0, max 1700!"):
        hotplate_fixture.rpm = 1800


@pytest.mark.parametrize("stir_switch_status", [True, False])
def test_stir_switch_property(hotplate_fixture, mocker, stir_switch_status):
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")

    hotplate_fixture._stir_switch = stir_switch_status

    assert hotplate_fixture._stir_switch is stir_switch_status
    write_spy.assert_called_once_with(IKAHotplate._stir_start if stir_switch_status else IKAHotplate._stir_stop)


def test_tare_marks_hotplate_as_tared_on_success(hotplate_fixture, mocker):
    mocker.patch("matterlab_hotplates.ika_hotplate.time.sleep")
    write_spy = mocker.patch.object(hotplate_fixture, "_write_hotplate")
    query_spy = mocker.patch.object(hotplate_fixture, "_query_hotplate", return_value="1041")

    hotplate_fixture.tare()

    assert hotplate_fixture._tared is True
    write_spy.assert_has_calls([mocker.call(IKAHotplate._heat_start), mocker.call(IKAHotplate._weight_start)])
    query_spy.assert_called_once_with(IKAHotplate._weight_status)


def test_weight_requires_tare(hotplate_fixture):
    assert hotplate_fixture.weight is None


def test_weight_reads_after_tare(hotplate_fixture, mocker):
    hotplate_fixture._tared = True
    query_spy = mocker.patch.object(hotplate_fixture, "_query_hotplate", return_value="12.5")

    assert hotplate_fixture.weight == 12.5
    query_spy.assert_called_once_with(IKAHotplate._weight_query)
