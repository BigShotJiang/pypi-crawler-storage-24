import pytest

from matterlab_hotplates.ika_hotbath import IKAHBHotbath
from tests.conftest import PORT


@pytest.fixture
def hotbath_fixture(mock_serial):
    return IKAHBHotbath(com_port=PORT, connect_hardware=False)


def test_initialization_defaults(mock_serial, hotbath_fixture):
    assert isinstance(hotbath_fixture, IKAHBHotbath)
    assert hotbath_fixture.max_temp == 80
    assert hotbath_fixture.target_temp == 20
    assert hotbath_fixture.target_rpm == 0
    assert hotbath_fixture.device is mock_serial


def test_write_hotplate_uses_query_transport(hotbath_fixture, mocker):
    query_spy = mocker.patch.object(hotbath_fixture, "query", return_value="OK")

    hotbath_fixture._write_hotplate("START_1")

    query_spy.assert_called_once_with(write_command="START_1\r\n", read_delay=0.5)


def test_query_hotbath_and_hotplate(hotbath_fixture, mocker):
    query_spy = mocker.patch.object(hotbath_fixture, "query", return_value="55 C\r\n")

    assert hotbath_fixture._query_hotbath("IN_PV_2") == "55"
    assert hotbath_fixture._query_hotplate("IN_PV_2") == "55"
    assert query_spy.call_count == 2


def test_name_property(hotbath_fixture, mocker):
    query_spy = mocker.patch.object(hotbath_fixture, "_query_hotplate", return_value="HB10")

    assert hotbath_fixture.name == "HB10"
    query_spy.assert_called_once_with(IKAHBHotbath._name)


def test_temp_getter_and_setter(hotbath_fixture, mocker):
    query_spy = mocker.patch.object(hotbath_fixture, "_query_hotplate", side_effect=["40", "OK", "OK"])

    assert hotbath_fixture.temp == 40

    hotbath_fixture.temp = 60

    assert hotbath_fixture.target_temp == 60
    assert query_spy.call_args_list[1:] == [
        mocker.call(f"{IKAHBHotbath._temp_set} 60"),
        mocker.call(IKAHBHotbath._heat_start),
    ]


def test_temp_setter_can_switch_off_heating(hotbath_fixture, mocker):
    query_spy = mocker.patch.object(hotbath_fixture, "_query_hotplate", side_effect=["OK", "OK"])

    hotbath_fixture.temp = 0

    assert hotbath_fixture.target_temp == 0
    assert query_spy.call_args_list == [
        mocker.call(f"{IKAHBHotbath._temp_set} 0"),
        mocker.call(IKAHBHotbath._heat_stop),
    ]


def test_temp_setter_validates_inputs(hotbath_fixture):
    with pytest.raises(TypeError, match="Temperature must be float or int!"):
        hotbath_fixture.temp = "bad"

    with pytest.raises(ValueError, match="Temperature out of range: min 0, max 80!"):
        hotbath_fixture.temp = 100


@pytest.mark.parametrize("heat_switch_status", [True, False])
def test_heat_switch_property(hotbath_fixture, mocker, heat_switch_status):
    query_spy = mocker.patch.object(hotbath_fixture, "_query_hotplate", return_value="OK")

    hotbath_fixture._heat_switch = heat_switch_status

    assert hotbath_fixture._heat_switch is heat_switch_status
    query_spy.assert_called_once_with(IKAHBHotbath._heat_start if heat_switch_status else IKAHBHotbath._heat_stop)


def test_maxtemp_property(hotbath_fixture, mocker):
    query_spy = mocker.patch.object(hotbath_fixture, "_query_hotplate", side_effect=["95", "OK"])

    assert hotbath_fixture.maxtemp == 95

    hotbath_fixture.maxtemp = 70

    assert query_spy.call_args_list == [
        mocker.call(IKAHBHotbath._max_temp_query),
        mocker.call(f"{IKAHBHotbath._max_temp_set} 70"),
    ]


def test_rpm_is_fixed_for_hotbath(hotbath_fixture):
    assert hotbath_fixture.rpm == 0
    assert hotbath_fixture.target_rpm == 0

    with pytest.raises(ValueError, match="IKA hotbath does not support stirring; rpm must remain 0."):
        hotbath_fixture.rpm = 100


def test_stir_switch_cannot_be_enabled(hotbath_fixture):
    assert hotbath_fixture._stir_switch is False

    with pytest.raises(ValueError, match="IKA hotbath does not support stirring."):
        hotbath_fixture._stir_switch = True
