"""Mock loader for MicroPython modules.

This module injects mock implementations into sys.modules so that
MicroPython imports work in the desktop emulator.
"""

import builtins
import shutil
import sys
from pathlib import Path

# Store original open function
_original_open = builtins.open
_vfs_enabled = False
_vfs_root = None


def _translate_path(path: str) -> str:
    """Translate MicroPython absolute path to host filesystem path.

    Checks uos mount points first (e.g. /sd/), then translates known
    MicroPython device paths like /badges/, /examples/, etc.
    """
    if not isinstance(path, str):
        return path

    # Check uos mount points (works even without VFS enabled)
    if path.startswith("/"):
        try:
            from emulator.mocks import uos
            mount_points = getattr(uos, '_mount_points', {})
            for mount_path, local_path in sorted(mount_points.items(), key=lambda x: -len(x[0])):
                if path == mount_path or path.startswith(mount_path + "/"):
                    remainder = path[len(mount_path):].lstrip("/")
                    return str(Path(local_path) / remainder)
        except ImportError:
            pass

    global _vfs_root
    if not _vfs_enabled or not _vfs_root:
        return path

    # Only translate known MicroPython filesystem paths
    micropython_roots = ("/badges", "/examples", "/icons", "/images", "/books")
    if path.startswith(micropython_roots):
        return str(Path(_vfs_root) / path.lstrip("/"))

    return path


def _vfs_open(path, mode="r", *args, **kwargs):
    """Open function with VFS path translation."""
    translated = _translate_path(path)
    return _original_open(translated, mode, *args, **kwargs)


def setup_vfs(app_path: str, vfs_root: str = "/tmp/badger_vfs"):
    """Set up virtual filesystem for an app.

    This copies necessary files from the app's directory structure
    to a temporary VFS location that mimics the MicroPython filesystem.

    Args:
        app_path: Path to the app file being run
        vfs_root: Root directory for the virtual filesystem
    """
    global _vfs_enabled, _vfs_root

    _vfs_root = vfs_root
    vfs_path = Path(vfs_root)

    # Find the app's base directory (e.g., badger_os folder)
    app_file = Path(app_path).resolve()
    app_dir = app_file.parent

    # Look for common badger_os structure
    if "badger_os" in str(app_dir) or "examples" in str(app_dir):
        # Find the badger_os root
        current = app_dir
        while current.parent != current:
            if (current / "badges").exists() or (current / "examples").exists():
                break
            current = current.parent

        # Copy directory structure to VFS
        for subdir in ["badges", "examples", "icons", "images", "books"]:
            src = current / subdir
            if src.exists():
                dst = vfs_path / subdir
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)

    # Enable VFS and patch open
    _vfs_enabled = True
    builtins.open = _vfs_open

    # Store in emulator state for uos module
    from emulator import get_state
    state = get_state()
    state["vfs_root"] = vfs_root


def teardown_vfs():
    """Restore original open function and disable VFS."""
    global _vfs_enabled
    _vfs_enabled = False
    builtins.open = _original_open


def _patch_os_uname():
    """Patch os.uname() to return MicroPython-like values.

    Apps check os.uname().sysname == "rp2" to detect MicroPython on RP2.
    We can't replace the os module, so we monkey-patch uname.
    """
    import os
    from collections import namedtuple
    _uname_result = namedtuple("uname_result",
                               ["sysname", "nodename", "release", "version", "machine"])
    _fake_uname = _uname_result(
        sysname="rp2",
        nodename="rp2",
        release="1.24.1",
        version="MicroPython v1.24.1 (emulator)",
        machine="Raspberry Pi Pico 2 W with RP2350",
    )
    os.uname = lambda: _fake_uname


def install_mocks():
    """Install all mock modules into sys.modules."""
    # Import base module (provides trace_log and base classes)
    # Import mocks and register them
    # Hardware sensor mocks
    # Additional breakout sensor mocks
    # WiFi helpers
    from emulator.mocks import (
        badger2040,
        badger_os,
        base,  # noqa: F401
        breakout_as7262,
        breakout_as7343,
        breakout_bh1745,
        breakout_bme68x,
        breakout_bme280,
        breakout_bmp280,
        breakout_dotmatrix,
        breakout_encoder,
        breakout_encoder_wheel,
        breakout_icp10125,
        breakout_ioexpander,
        breakout_ltr559,
        breakout_matrix11x7,
        breakout_mics6814,
        breakout_mlx90640,
        breakout_msa301,
        breakout_pmw3901,
        breakout_potentiometer,
        breakout_rgbmatrix5x5,
        breakout_rtc,
        breakout_scd41,
        breakout_sgp30,
        breakout_trackball,
        breakout_vl53l5cx,
        ezwifi,
        inky_frame,
        jpegdec,
        lsm6ds3,
        machine,
        network,
        network_manager,
        ntptime,
        picographics,
        picovector,
        pimoroni,
        pngdec,
        presto,
        psram,
        qwstpad,
        rp2,
        sdcard,
        touch,
        tufty2350,
        uos,
        urequests,
    )
    from emulator.mocks import gc as mock_gc
    from emulator.mocks import micropython as mock_micropython
    from emulator.mocks import socket as mock_socket
    from emulator.mocks import time as mock_time

    # Core MicroPython modules
    sys.modules["machine"] = machine
    sys.modules["time"] = mock_time
    sys.modules["utime"] = mock_time  # MicroPython alias
    sys.modules["gc"] = mock_gc
    sys.modules["micropython"] = mock_micropython

    # MicroPython asyncio alias (wrapper that auto-creates event loops in threads)
    from emulator.mocks import uasyncio
    sys.modules["uasyncio"] = uasyncio
    sys.modules["rp2"] = rp2

    # MicroPython stdlib aliases
    import json as _json
    sys.modules["ujson"] = _json

    # Patch os.uname() to report as MicroPython on RP2
    _patch_os_uname()

    # Pimoroni libraries
    sys.modules["picographics"] = picographics
    sys.modules["pimoroni"] = pimoroni
    sys.modules["network"] = network
    # Note: Don't replace sys.modules["socket"] - it breaks urllib/SSL
    # Only provide usocket for MicroPython compatibility
    sys.modules["usocket"] = mock_socket
    sys.modules["jpegdec"] = jpegdec

    # Device-specific modules
    sys.modules["presto"] = presto
    sys.modules["tufty2350"] = tufty2350
    sys.modules["touch"] = touch
    sys.modules["inky_frame"] = inky_frame
    sys.modules["picovector"] = picovector
    sys.modules["badger2040"] = badger2040
    sys.modules["badger_os"] = badger_os
    sys.modules["pngdec"] = pngdec
    sys.modules["uos"] = uos
    sys.modules["ntptime"] = ntptime
    sys.modules["sdcard"] = sdcard
    sys.modules["urequests"] = urequests
    # Hardware sensor mocks
    sys.modules["breakout_bme280"] = breakout_bme280
    sys.modules["breakout_ltr559"] = breakout_ltr559
    sys.modules["lsm6ds3"] = lsm6ds3
    sys.modules["qwstpad"] = qwstpad
    sys.modules["psram"] = psram
    # Additional breakout sensor mocks
    sys.modules["breakout_bme68x"] = breakout_bme68x
    sys.modules["breakout_bmp280"] = breakout_bmp280
    sys.modules["breakout_scd41"] = breakout_scd41
    sys.modules["breakout_sgp30"] = breakout_sgp30
    sys.modules["breakout_rtc"] = breakout_rtc
    sys.modules["breakout_potentiometer"] = breakout_potentiometer
    sys.modules["breakout_encoder"] = breakout_encoder
    sys.modules["breakout_trackball"] = breakout_trackball
    sys.modules["breakout_msa301"] = breakout_msa301
    sys.modules["breakout_bh1745"] = breakout_bh1745
    sys.modules["breakout_as7262"] = breakout_as7262
    sys.modules["breakout_as7343"] = breakout_as7343
    sys.modules["breakout_dotmatrix"] = breakout_dotmatrix
    sys.modules["breakout_rgbmatrix5x5"] = breakout_rgbmatrix5x5
    sys.modules["breakout_matrix11x7"] = breakout_matrix11x7
    sys.modules["breakout_ioexpander"] = breakout_ioexpander
    sys.modules["breakout_encoder_wheel"] = breakout_encoder_wheel
    sys.modules["breakout_icp10125"] = breakout_icp10125
    sys.modules["breakout_mics6814"] = breakout_mics6814
    sys.modules["breakout_vl53l5cx"] = breakout_vl53l5cx
    sys.modules["breakout_pmw3901"] = breakout_pmw3901
    sys.modules["breakout_mlx90640"] = breakout_mlx90640
    # WiFi helpers
    sys.modules["ezwifi"] = ezwifi
    sys.modules["network_manager"] = network_manager
    # Note: Don't replace sys.modules["os"] - it breaks CPython internals

    # Initialize battery mock
    from emulator.mocks.battery import init_battery
    init_battery()


def install_inky_mocks():
    """Install Inky library mocks for Raspberry Pi devices.

    This is separate from MicroPython mocks since Inky uses regular Python
    and runs on Raspberry Pi (not RP2040/RP2350).
    """
    from emulator.mocks import inky
    from emulator.mocks.inky import auto as inky_auto

    sys.modules["inky"] = inky
    sys.modules["inky.auto"] = inky_auto
    sys.modules["inky.inky"] = inky.inky
    sys.modules["inky.inky_uc8159"] = inky.inky_uc8159
    sys.modules["inky.inky_ac073tc1a"] = inky.inky_ac073tc1a


def install_badgeware_mocks():
    """Install badgeware mocks for Blinky 2350.

    Badgeware is a custom API used by Blinky that provides drawing primitives,
    shapes, colors, and input handling through builtins.

    Also includes picographics for low-level examples that use both APIs.
    """
    from emulator.mocks import (
        badgeware,
        blinky,
        breakout_bme280,
        easing,
        machine,
        network,
        ntptime,
        picographics,
        picovector,
        pimoroni,
        powman,
        rp2,
        urequests,
    )
    from emulator.mocks import gc as mock_gc
    from emulator.mocks import micropython as mock_micropython
    from emulator.mocks import socket as mock_socket
    from emulator.mocks import time as mock_time

    # Core MicroPython modules
    sys.modules["machine"] = machine
    sys.modules["time"] = mock_time
    sys.modules["utime"] = mock_time
    sys.modules["gc"] = mock_gc
    sys.modules["micropython"] = mock_micropython
    sys.modules["network"] = network
    sys.modules["usocket"] = mock_socket

    # MicroPython asyncio alias (wrapper that auto-creates event loops in threads)
    from emulator.mocks import uasyncio
    sys.modules["uasyncio"] = uasyncio
    sys.modules["rp2"] = rp2

    # MicroPython stdlib aliases
    import json as _json
    sys.modules["ujson"] = _json

    # Patch os.uname() to report as MicroPython on RP2
    _patch_os_uname()

    # Blinky-specific modules
    sys.modules["blinky"] = blinky
    sys.modules["badgeware"] = badgeware
    sys.modules["picovector"] = picovector
    sys.modules["picographics"] = picographics
    sys.modules["ntptime"] = ntptime
    sys.modules["powman"] = powman
    sys.modules["pimoroni"] = pimoroni
    sys.modules["breakout_bme280"] = breakout_bme280
    sys.modules["easing"] = easing
    sys.modules["urequests"] = urequests

    # Initialize battery mock
    from emulator.mocks.battery import init_battery
    init_battery()

    # Initialize blinky display
    blinky_display = blinky.Blinky()

    # Create screen and install builtins
    badgeware._create_screen()
    badgeware._setup_builtins()

    # Link the badgeware screen buffer to the blinky display buffer
    badgeware.screen._buffer = blinky_display._buffer


def uninstall_mocks():
    """Remove mock modules from sys.modules."""
    mock_names = [
        "machine", "time", "utime", "uasyncio", "rp2", "gc", "micropython",
        "picographics", "pimoroni", "network", "usocket",
        "jpegdec", "presto", "tufty2350", "touch", "inky_frame", "picovector",
        "badger2040", "badger_os", "pngdec", "uos", "ntptime", "sdcard", "urequests",
        # Inky mocks
        "inky", "inky.auto", "inky.inky", "inky.inky_uc8159", "inky.inky_ac073tc1a"
    ]
    teardown_vfs()
    for name in mock_names:
        sys.modules.pop(name, None)
