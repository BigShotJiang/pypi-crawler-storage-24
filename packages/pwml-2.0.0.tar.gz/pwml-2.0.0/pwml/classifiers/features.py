__all__ = ['InputFeature', 'OutputFeature']

from dataclasses import dataclass, field

_VALID_FEATURE_TYPES = {'category', 'numeric', 'text', 'longtext'}


@dataclass
class InputFeature:
    feature_name: str
    feature_type: str
    classes: list | None = field(default=None, repr=False)
    range: tuple[float, float] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        if self.feature_type not in _VALID_FEATURE_TYPES:
            raise ValueError(
                "feature_type {!r} is not valid. Must be one of: {}".format(
                    self.feature_type, sorted(_VALID_FEATURE_TYPES)))


@dataclass
class OutputFeature:
    feature_name: str
    child_feature: 'OutputFeature | None' = None
