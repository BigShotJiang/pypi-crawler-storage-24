__all__ = [
    'BaseEmbedder',
    'CategoryEmbedder',
    'NumericEmbedder',
    'SentenceTransformerEmbedder',
]

import os
import sqlite3
import threading
import warnings
import logging
import numpy as np

_log = logging.getLogger(__name__)

# Default cache directory: <project_root>/.cache/pwml/
# Resolved from this file's location so it is always absolute and independent
# of the working directory (important when notebooks run from examples/).
# Structure: pwml/classifiers/embedders.py -> up 3 levels -> project root
# Override with the PWML_CACHE_DIR environment variable.
_DEFAULT_CACHE_DIR = (
    os.environ.get('PWML_CACHE_DIR')
    or os.path.join(
        os.path.dirname(  # project root
            os.path.dirname(  # pwml/
                os.path.dirname(  # pwml/classifiers/
                    os.path.abspath(__file__)))),
        '.cache', 'pwml'))

# Module-level registry of open SQLite connections.  All BaseEmbedder instances
# that resolve to the same cache path share a single connection so that
# concurrent embedder instances in the same process (e.g. cross_validate
# fold models) do not contend for file locks.
_OPEN_DBS: dict[str, sqlite3.Connection] = {}
_DB_LOCK = threading.Lock()


def _open_db(filepath: str) -> sqlite3.Connection:
    """Open (or create) an SQLite database for embedding cache storage.

    WAL mode is enabled for concurrent read/write access from multiple
    Jupyter kernels or threads.  The connection uses check_same_thread=False
    because access is serialised via _DB_LOCK at the module level.
    """
    conn = sqlite3.connect(filepath, check_same_thread=False)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute(
        'CREATE TABLE IF NOT EXISTS cache '
        '(key TEXT PRIMARY KEY, value BLOB, dtype TEXT, shape TEXT)')
    conn.commit()
    return conn


class BaseEmbedder:
    """Base class for all embedding strategies.

    Thread safety
    -------------
    The shared SQLite connection (``_OPEN_DBS``) is protected by ``_DB_LOCK``
    during :meth:`load_cache`.  Individual calls to :meth:`embed_data` are
    serialised via SQLite's internal locking (WAL mode allows concurrent reads).
    """

    def __init__(
        self,
        input_type: str | None = None,
        input_size: int | None = None,
        output_size: int | None = None,
        cache_path: str | None = None,
    ) -> None:
        self.input_type = input_type
        self.input_size = input_size
        self.output_size = output_size
        self.cache_path = cache_path
        self._db: sqlite3.Connection | None = None
        self._db_path: str | None = None

        self.load_cache()

    def __enter__(self) -> 'BaseEmbedder':
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def __del__(self) -> None:
        # Detach from the shared connection but do not close it - the
        # connection is shared across instances.
        self._db = None

    def load_cache(self) -> None:
        base_dir = os.path.abspath(
            self.cache_path if self.cache_path is not None else _DEFAULT_CACHE_DIR)

        # If PWML_CACHE_ROOT is set, enforce that base_dir stays within it.
        cache_root_env = os.environ.get('PWML_CACHE_ROOT')
        if cache_root_env:
            safe_root = os.path.abspath(cache_root_env)
            if not (base_dir.startswith(safe_root + os.sep) or base_dir == safe_root):
                raise ValueError(
                    "cache_path '{0}' is outside the allowed root '{1}' "
                    "(set by PWML_CACHE_ROOT).".format(base_dir, safe_root))

        os.makedirs(base_dir, exist_ok=True)
        self._db_path = os.path.join(base_dir, '{0}.db'.format(self.input_type))
        with _DB_LOCK:
            if self._db_path not in _OPEN_DBS:
                _OPEN_DBS[self._db_path] = _open_db(self._db_path)
            self._db = _OPEN_DBS[self._db_path]

    def close(self) -> None:
        """Detach this instance from the shared cache connection."""
        self._db = None

    def flush_cache(self) -> None:
        """Commit any pending writes to disk."""
        if self._db is not None:
            self._db.commit()

    def data_empty(self, data: object, feature: object) -> np.ndarray:
        raise NotImplementedError('Subclasses must implement data_empty()')

    def data_preparation(self, data: object, feature: object) -> object:
        return data

    def data_embedding(self, data: object, feature: object) -> np.ndarray:
        return data

    def _cache_key(self, data: object, feature: object) -> str:
        return '{0}::{1}'.format(feature.feature_name, str(data))

    def _cache_get(self, key: str) -> np.ndarray | None:
        """Retrieve a cached embedding from SQLite, or None if not found."""
        if self._db is None:
            return None
        row = self._db.execute(
            'SELECT value, dtype, shape FROM cache WHERE key = ?', (key,)
        ).fetchone()
        if row is None:
            return None
        blob, dtype, shape_str = row
        shape = tuple(int(s) for s in shape_str.split(',') if s)
        return np.frombuffer(blob, dtype=dtype).reshape(shape).copy()

    def _cache_put(self, key: str, value: np.ndarray) -> None:
        """Store an embedding in the SQLite cache."""
        if self._db is None:
            return
        blob = value.tobytes()
        dtype = str(value.dtype)
        shape = ','.join(str(s) for s in value.shape)
        self._db.execute(
            'INSERT OR REPLACE INTO cache (key, value, dtype, shape) VALUES (?, ?, ?, ?)',
            (key, blob, dtype, shape))
        self._db.commit()

    def embed_data(self, data: object, feature: object) -> np.ndarray:
        if data is None:
            return self.data_empty(data=data, feature=feature)

        data_prepared = self.data_preparation(data=data, feature=feature)

        cache_key = self._cache_key(data, feature)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached

        embedding = self.data_embedding(data=data_prepared, feature=feature)

        self._cache_put(cache_key, embedding)

        return embedding


class CategoryEmbedder(BaseEmbedder):

    def __init__(
        self,
        input_size: int | None = None,
        output_size: int | None = None,
        cache_path: str | None = None,
    ) -> None:
        super().__init__(
            input_type='category',
            input_size=input_size,
            output_size=output_size,
            cache_path=cache_path)
        self._class_dicts: dict[str, dict[str, int]] = {}

    def data_empty(self, data: object, feature: object) -> np.ndarray:
        if self.output_size is None:
            empty_data = [0] * len(feature.classes)
        else:
            empty_data = [0] * self.output_size

        return np.array(empty_data, dtype=np.float64)

    def data_embedding(self, data: object, feature: object) -> np.ndarray:
        vect = self.data_empty(data, feature)

        if data is not None:
            # Build a lookup dict once per feature (O(k) amortised over all samples).
            if feature.feature_name not in self._class_dicts:
                self._class_dicts[feature.feature_name] = {
                    v: i for i, v in enumerate(feature.classes)
                }
            position = self._class_dicts[feature.feature_name].get(data)
            if position is not None and position < len(vect):
                vect[position] = 1
            # Unknown category values produce a zero vector (all-absent encoding)
            # rather than raising an error, allowing inference on unseen data.

        return vect


_VALID_OOD_POLICIES = frozenset({'clip', 'warn', 'raise'})


class NumericEmbedder(BaseEmbedder):

    def __init__(
        self,
        default_value: float = 0.0,
        cache_path: str | None = None,
        out_of_range: str = 'clip',
    ) -> None:
        if out_of_range not in _VALID_OOD_POLICIES:
            raise ValueError(
                "out_of_range must be one of {0!r}, got {1!r}".format(
                    sorted(_VALID_OOD_POLICIES), out_of_range))
        super().__init__(
            input_type='numeric',
            input_size=None,
            output_size=None,
            cache_path=cache_path)

        self.default_value = default_value
        self.out_of_range = out_of_range

    def data_empty(self, data: object, feature: object) -> np.ndarray:
        return np.array([self.default_value], dtype=np.float64)

    def embed_data(self, data: object, feature: object) -> np.ndarray:
        """Override to bypass the cache.

        Numeric embedding is a single float operation - caching adds overhead
        with no benefit.  Normalisation also depends on training-time range, so
        cached raw values from a previous run would be incorrect.
        """
        if data is None:
            return self.data_empty(data=data, feature=feature)
        return self.data_embedding(data=data, feature=feature)

    def data_embedding(self, data: object, feature: object) -> np.ndarray:
        """Embed a numeric value, normalising to [0, 1] using the training range."""
        val = float(data)
        if hasattr(feature, 'range') and feature.range is not None:
            min_val, max_val = feature.range
            if max_val > min_val:
                normalised = (val - min_val) / (max_val - min_val)
                if normalised < 0.0 or normalised > 1.0:
                    if self.out_of_range == 'raise':
                        raise ValueError(
                            "Feature '{0}': value {1} is outside the training "
                            "range [{2}, {3}].".format(
                                feature.feature_name, val, min_val, max_val))
                    elif self.out_of_range == 'warn':
                        warnings.warn(
                            "Feature '{0}': value {1} is outside the training "
                            "range [{2}, {3}]; normalised value {4:.4f} is "
                            "outside [0, 1].".format(
                                feature.feature_name, val, min_val, max_val,
                                normalised),
                            UserWarning,
                            stacklevel=3)
                    else:  # 'clip'
                        normalised = float(np.clip(normalised, 0.0, 1.0))
                val = normalised
        return np.array([val], dtype=np.float64)


# Known embedding dimensions for common sentence-transformers models.
_ST_KNOWN_DIMS: dict[str, int] = {
    'all-MiniLM-L6-v2':              384,
    'all-MiniLM-L12-v2':             384,
    'all-mpnet-base-v2':             768,
    'multi-qa-MiniLM-L6-cos-v1':     384,
    'multi-qa-mpnet-base-dot-v1':    768,
    'paraphrase-MiniLM-L6-v2':       384,
    'paraphrase-multilingual-MiniLM-L12-v2': 384,
    'all-distilroberta-v1':          768,
}


class SentenceTransformerEmbedder(BaseEmbedder):
    """Text embedder backed by sentence-transformers.

    Args:
        input_type: Feature type key used for embedder registry lookup.
            Use 'text' for short descriptions, 'longtext' for paragraphs.
        model_name: Any sentence-transformers model identifier.
            Default 'all-MiniLM-L6-v2' (384-dim, ~80 MB, fast on CPU).
            Use 'all-mpnet-base-v2' (768-dim, ~420 MB) for higher quality.
        cache_path: Directory for the SQLite embedding cache.
    """

    def __init__(
        self,
        input_type: str = 'text',
        model_name: str = 'all-MiniLM-L6-v2',
        cache_path: str | None = None,
    ) -> None:
        self.model_name = model_name
        self._st_model = None  # lazy-loaded on first embed call

        output_size = _ST_KNOWN_DIMS.get(model_name, 384)

        super().__init__(
            input_type=input_type,
            input_size=None,
            output_size=output_size,
            cache_path=cache_path)

    def _get_model(self):
        """Lazy-load the sentence-transformers model (download on first call)."""
        if self._st_model is None:
            from sentence_transformers import SentenceTransformer
            self._st_model = SentenceTransformer(self.model_name)
            # Sync output_size with the actual model dimension.
            self.output_size = self._st_model.get_sentence_embedding_dimension()
        return self._st_model

    def data_empty(self, data: object, feature: object) -> np.ndarray:
        return np.zeros(self.output_size, dtype=np.float64)

    def data_embedding(self, data: object, feature: object) -> np.ndarray:
        model = self._get_model()
        embedding = model.encode(
            [str(data)],
            normalize_embeddings=True,
            show_progress_bar=False)
        return embedding[0].astype(np.float64)
