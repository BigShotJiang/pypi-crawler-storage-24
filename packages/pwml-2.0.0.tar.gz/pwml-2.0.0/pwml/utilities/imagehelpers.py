__all__ = [
    'Rectangle',
    'image_to_array', 'image_to_batch_array',
    'crop_image', 'extract_square_portion',
    'open_image',
]

import math as mth
from dataclasses import dataclass
import numpy as np
import PIL as pil
import PIL.Image

_VALID_H_POSITIONS = frozenset({'Left', 'Center', 'Right'})
_VALID_V_POSITIONS = frozenset({'Top', 'Middle', 'Bottom'})


@dataclass
class Rectangle:
    """A rectangle defined by top-left corner (x, y) and dimensions (width, height)."""
    x: int
    y: int
    width: int
    height: int

    def __str__(self) -> str:
        return 'Rectangle(x:{0}, y:{1}, width:{2}, height:{3})'.format(
            self.x, self.y, self.width, self.height)

    def to_simple_text(self) -> str:
        return '{0}-{1}-{2}-{3}'.format(
            self.x, self.y, self.width, self.height)

    def lt(self) -> tuple[int, int]:
        return self.x, self.y

    def rb(self) -> tuple[int, int]:
        return self.x + self.width, self.y + self.height

    def ltrb(self) -> tuple[int, int, int, int]:
        return (*self.lt(), *self.rb())

    def contains(self, other: 'Rectangle') -> bool:
        return (other.x >= self.x and
                other.y >= self.y and
                other.x + other.width <= self.x + self.width and
                other.y + other.height <= self.y + self.height)

    def grow(self, ratio: float, image_width: int, image_height: int) -> 'Rectangle':
        """Inflate rectangle by ratio, without exceeding the image bounds."""
        image = Rectangle(0, 0, image_width, image_height)

        w_max = min(
            min(self.x, image.width - (self.x + self.width)),
            mth.floor(self.width * ratio / 2.0))

        h_max = min(
            min(self.y, image.height - (self.y + self.height)),
            mth.floor(self.height * ratio / 2.0))

        r_max = min(
            2 * w_max / self.width,
            2 * h_max / self.height)

        w = mth.floor(self.width * r_max / 2.0)
        h = mth.floor(self.height * r_max / 2.0)

        new_rec = Rectangle(
            self.x - w,
            self.y - h,
            self.width + 2 * w,
            self.height + 2 * h)

        if not image.contains(new_rec):
            raise ValueError(
                'grow() produced rectangle {0} that extends outside the image '
                '({1}x{2}). This should not happen and indicates a bug in the '
                'grow logic.'.format(new_rec, image_width, image_height))

        return new_rec


def image_to_array(pil_image: PIL.Image.Image, rescaled: bool = True) -> np.ndarray:
    return np.array(pil_image, dtype=np.float32) / (255.0 if rescaled else 1.0)


def image_to_batch_array(pil_image: PIL.Image.Image, rescaled: bool = True) -> np.ndarray:
    return image_to_array(
        pil_image=pil_image,
        rescaled=rescaled)[np.newaxis, :, :, :]


def crop_image(pil_image: PIL.Image.Image, rectangle: Rectangle) -> PIL.Image.Image:
    return pil_image.transform(
        size=(rectangle.width, rectangle.height),
        method=pil.Image.EXTENT,
        resample=pil.Image.BILINEAR,
        data=rectangle.ltrb())


def extract_square_portion(
    pil_image: PIL.Image.Image,
    h_position: str | None = None,
    v_position: str | None = None,
    output_size: tuple[int, int] | None = None,
) -> PIL.Image.Image:

    if h_position is not None and h_position not in _VALID_H_POSITIONS:
        raise ValueError(
            "h_position must be one of {0} or None, got {1!r}.".format(
                sorted(_VALID_H_POSITIONS), h_position))
    if v_position is not None and v_position not in _VALID_V_POSITIONS:
        raise ValueError(
            "v_position must be one of {0} or None, got {1!r}.".format(
                sorted(_VALID_V_POSITIONS), v_position))

    max_dim = min(pil_image.width, pil_image.height)
    x = 0
    y = 0

    if h_position == 'Left':
        x = 0
    elif h_position in ['Center', None]:
        x = mth.floor((pil_image.width - max_dim) / 2)
    elif h_position == 'Right':
        x = pil_image.width - max_dim

    if v_position == 'Top':
        y = 0
    elif v_position in ['Middle', None]:
        y = mth.floor((pil_image.height - max_dim) / 2)
    elif v_position == 'Bottom':
        y = pil_image.height - max_dim

    if output_size is None:
        output_size = (max_dim, max_dim)

    return pil_image.transform(
        size=output_size,
        method=pil.Image.EXTENT,
        resample=pil.Image.BILINEAR,
        data=(x, y, x + max_dim, y + max_dim))


def open_image(path: str) -> PIL.Image.Image:
    return pil.Image.open(path)
