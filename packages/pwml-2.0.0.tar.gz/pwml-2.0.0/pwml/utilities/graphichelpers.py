__all__ = ['GraphicsStatics']

import threading

import matplotlib as mat
from matplotlib import pyplot as plt
import pylab as pyl
import seaborn as sns

_styles_lock = threading.Lock()


class GraphicsStatics:

    # Globals
    g_palette: list = []
    g_hatch: list[str] = ['/', '\\', '|', '-', '+', 'x', 'o', 'O', '.', '*']
    g_linestyle: list[str] = ['-', '--', '-.', ':']

    g_landscape_fig_size: tuple[int, int] = (20, 10)
    g_square_fig_size: tuple[int, int] = (20, 20)
    g_portrait_fig_size: tuple[int, int] = (20, 30)

    g_styles_initialized: bool = False

    @staticmethod
    def initialize_matplotlib_styles(force: bool = False) -> None:

        with _styles_lock:
            if force:
                GraphicsStatics.g_styles_initialized = False

            if not GraphicsStatics.g_styles_initialized:
                sns.set_theme()
                sns.set_style('whitegrid', {'axes.facecolor': '.9'})
                plt.style.use('fivethirtyeight')
                sns.set_context('talk')

                GraphicsStatics.g_palette = sns.color_palette('Set2', 8)

                sns.set_palette(GraphicsStatics.g_palette)

                pyl.rcParams['figure.figsize'] = GraphicsStatics.g_landscape_fig_size
                plt.rcParams['figure.figsize'] = GraphicsStatics.g_landscape_fig_size
                plt.rcParams['axes.labelsize'] = 18
                plt.rcParams['axes.titlesize'] = 18

                GraphicsStatics.g_styles_initialized = True

    @staticmethod
    def get_color(index: int) -> tuple:
        if not GraphicsStatics.g_palette:
            GraphicsStatics.initialize_matplotlib_styles()
        return GraphicsStatics.g_palette[index % len(GraphicsStatics.g_palette)]

    @staticmethod
    def get_hatch(index: int) -> str:
        return GraphicsStatics.g_hatch[index % len(GraphicsStatics.g_hatch)]

    @staticmethod
    def get_linestyle(index: int) -> str:
        return GraphicsStatics.g_linestyle[index % len(GraphicsStatics.g_linestyle)]

    @staticmethod
    def style_plot(
        title: str | None,
        subtitle: str | None,
        tl_name: str | None,
        fig,
        ax,
        experiment_tracker: object | None = None,
        top: float = 0.91,
        tight_layout: bool = False,
    ) -> None:
        """Apply consistent styling to a matplotlib figure.

        Args:
            experiment_tracker: Any object implementing the
                :class:`~pwml.utilities.neptunehelpers.ExperimentTracker`
                protocol, or None.
        """
        fig.subplots_adjust(top=top)

        if title is not None:
            fig.suptitle(
                t=title,
                fontsize=26,
                fontweight='bold',
                verticalalignment='top',
                horizontalalignment='center',
                fontstyle='italic',
                x=(fig.subplotpars.right + fig.subplotpars.left)/2)

        if subtitle is not None:
            ax.set_title(
                label=subtitle,
                fontdict={
                    'fontsize': 18,
                    'horizontalalignment': 'center'
                })

        if experiment_tracker:
            experiment_id = experiment_tracker.get_experiment_id()

            fig.text(
                    x=0.98,
                    y=1,
                    s=experiment_id,
                    ha='right',
                    va='top',
                    fontsize=16,
                    fontstyle='italic',
                    bbox={
                        'facecolor': GraphicsStatics.get_color(6),
                        'alpha': 0.5,
                        'pad': 7
                    })

        if tl_name is not None:
            fig.text(
                x=0.02,
                y=1,
                s=tl_name,
                ha='left',
                va='top',
                fontsize=16,
                fontstyle='italic',
                bbox={
                    'facecolor': GraphicsStatics.get_color(5),
                    'alpha': 0.5,
                    'pad': 7
                })

        if tight_layout:
            plt.tight_layout()

        if experiment_tracker is not None:
            import datetime as _dt
            chart_name = tl_name.replace('\n', ' - ') if tl_name is not None else str(int(_dt.datetime.now().timestamp()))
            experiment_tracker.log_chart(
                figure=fig,
                name=chart_name)
