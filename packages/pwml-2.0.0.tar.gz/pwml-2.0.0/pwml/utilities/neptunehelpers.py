__all__ = ['ExperimentTracker', 'NeptuneExperimentManager']

import logging
import os
import tempfile
import datetime as dt
from typing import Protocol, runtime_checkable

from matplotlib.figure import Figure
import pandas as pd

_log = logging.getLogger(__name__)


@runtime_checkable
class ExperimentTracker(Protocol):
    """Vendor-neutral protocol for experiment tracking.

    Any object implementing these methods can be used as an experiment tracker
    throughout pwml (DriftMonitor, graphichelpers, etc.).  The built-in
    :class:`NeptuneExperimentManager` is one such implementation.
    """

    @property
    def experiment_name(self) -> str: ...

    def get_experiment_id(self) -> str | None: ...

    def add_experiment_tags(self, tag: str) -> None: ...

    def set_experiment_property(self, key: str, value: object) -> None: ...

    def log_data(self, data: pd.DataFrame, name: str | None = None,
                 log_index: bool = False) -> None: ...

    def log_chart(self, figure: Figure, name: str | None = None) -> None: ...

    def stop(self) -> None: ...


class NeptuneExperimentManager:
    """Neptune-backed implementation of :class:`ExperimentTracker`.

    When ``log=False`` the object is a no-op stub so that downstream code that
    calls tracking methods still runs without changes.

    Requires: ``pip install pwml[neptune]`` (neptune >= 1.0)
    """

    def __init__(
        self,
        log: bool,
        project_name: str,
        experiment_name: str,
        experiment_params: dict | None = None,
        experiment_tags: list[str] | None = None,
    ) -> None:
        self.log = log
        self.run = None
        self._experiment_name: str | None = None

        if self.log:
            import neptune
            logging.getLogger('neptune').setLevel(logging.ERROR)

            self.run = neptune.init_run(
                project=project_name,
                name=experiment_name,
                tags=list(experiment_tags) if experiment_tags else [])

            if experiment_params:
                self.run['parameters'] = experiment_params

    @property
    def experiment_name(self) -> str:
        if self._experiment_name is None:
            if self.log and self.run:
                self._experiment_name = self.run['sys/id'].fetch()
            else:
                self._experiment_name = self._fake_name()

        return self._experiment_name

    @staticmethod
    def _fake_name() -> str:
        return str(int(dt.datetime.now().timestamp()))

    def get_experiment_id(self) -> str | None:
        if self.log and self.run:
            return self.run['sys/id'].fetch()
        return None

    def add_experiment_tags(self, tag: str) -> None:
        if self.log and self.run:
            self.run['sys/tags'].add(tag)
            _log.info('[Tag] %s', tag)

    def set_experiment_property(self, key: str, value: object) -> None:
        if self.log and self.run:
            self.run[key] = value
            _log.info('[Property] %s: %s', key, value)

    def log_data(self, data: pd.DataFrame, name: str | None = None,
                 log_index: bool = False) -> None:
        if self.log and self.run:
            if name is None:
                name = self._fake_name()

            import stat
            tmp = tempfile.NamedTemporaryFile(
                suffix='.csv', delete=False, prefix='pwml_')
            file_path = tmp.name
            tmp.close()
            os.chmod(file_path, stat.S_IRUSR | stat.S_IWUSR)
            try:
                data.to_csv(file_path, index=log_index)
                self.run['data/{0}.csv'.format(name)].upload(file_path)
            finally:
                if os.path.exists(file_path):
                    os.remove(file_path)

    def log_chart(self, figure: Figure, name: str | None = None) -> None:
        if self.log and self.run:
            if name is None:
                name = self._fake_name()

            import stat
            tmp = tempfile.NamedTemporaryFile(
                suffix='.jpg', delete=False, prefix='pwml_')
            file_path = tmp.name
            tmp.close()
            os.chmod(file_path, stat.S_IRUSR | stat.S_IWUSR)
            try:
                figure.savefig(
                    fname=file_path,
                    dpi=96,
                    format='jpg',
                    bbox_inches='tight')
                self.run['charts/{0}.jpg'.format(name)].upload(file_path)
            finally:
                if os.path.exists(file_path):
                    os.remove(file_path)

    def stop(self) -> None:
        """Stop the Neptune run. Call when done logging."""
        if self.log and self.run:
            self.run.stop()
            self.run = None

    def __enter__(self) -> 'NeptuneExperimentManager':
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.stop()
