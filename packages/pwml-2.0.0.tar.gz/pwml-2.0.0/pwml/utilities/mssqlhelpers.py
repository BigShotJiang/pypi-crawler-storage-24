__all__ = ['connect', 'execute']

import logging
import re
import pandas as pd

_log = logging.getLogger(__name__)

# Allow only safe stored-procedure names: letters, digits, underscores, dots.
_PROC_NAME_RE = re.compile(r'^[\w\.]+$')


def _get_pymssql():
    """Lazy import of pymssql (optional dependency)."""
    try:
        import pymssql
        return pymssql
    except ImportError:
        raise ImportError(
            "pymssql is required for mssqlhelpers. "
            "Install it with: pip install pwml[mssql]")


def connect(conn_params: tuple):
    mssql = _get_pymssql()
    return mssql.connect(*conn_params)

def execute(
    proc_name: str,
    conn_params: tuple,
    proc_params: tuple,
    commit: bool = True,
) -> pd.DataFrame | None:
    """Execute a stored procedure and return the first result set as a DataFrame.

    Raises:
        ValueError: if ``proc_name`` contains characters outside ``[\\w.]``.
    """
    if not _PROC_NAME_RE.match(proc_name):
        raise ValueError(
            "proc_name '{0}' contains invalid characters. "
            "Only letters, digits, underscores, and dots are allowed.".format(
                proc_name))

    mssql = _get_pymssql()
    result = None

    try:
        with connect(conn_params) as conn:
            with conn.cursor(as_dict=True) as cursor:
                cursor.callproc(proc_name, proc_params)

                if cursor.nextset():
                    rows = cursor.fetchall()
                    result = pd.DataFrame.from_records(rows) if rows else pd.DataFrame()

                if commit:
                    conn.commit()
    except mssql.Error:
        _log.error(
            'Database error executing stored procedure "%s".',
            proc_name,
            exc_info=True)
        raise

    return result
