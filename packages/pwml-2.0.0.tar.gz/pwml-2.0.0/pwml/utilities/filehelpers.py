__all__ = [
    'md5',
    'save_ndarray', 'load_ndarray',
    'save_cache_dict_file', 'load_cache_dict_file',
    'load_from_npz', 'save_to_npz',
    'save_to_pickle', 'load_from_pickle',
    'save_to_file',
    'get_timestamped_filename', 'get_timestamped_name', 'get_stamp_text',
    'create_if_not_exists', 'get_stamp_folder',
]

import os
import datetime as dt
import numpy as np
import pickle as pk
import hashlib as hl


def md5(filepath: str) -> str:
    hash_md5 = hl.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def save_ndarray(filepath: str, data: np.ndarray) -> str:
    np.savez_compressed(file=filepath, x=data)
    return filepath

def load_ndarray(filepath: str) -> np.ndarray:
    return np.load(file=filepath, allow_pickle=False)['x']


def save_cache_dict_file(filepath: str, dict: dict) -> str:
    """Save a Python dict to a pickle file.

    Note: this function uses pickle serialisation. Only load files produced
    here from trusted sources (see :func:`load_cache_dict_file`).
    """
    return save_to_pickle(filepath=filepath, data=dict)

def load_cache_dict_file(filepath: str) -> dict:
    """Load a dict previously saved with :func:`save_cache_dict_file`.

    Warning: unpickling executes arbitrary code. Only call this with files
    from trusted sources.
    """
    return load_from_pickle(filepath=filepath)


def load_from_npz(filepath: str) -> dict:
    with np.load(filepath, allow_pickle=True) as npz_file:
        data = dict(npz_file.items())
    return data

def save_to_npz(filepath: str, data_dict: dict) -> str:
    np.savez_compressed(filepath, **data_dict)
    return filepath


def save_to_pickle(filepath: str, data: object) -> str:
    with open(filepath, 'wb') as fp:
        pk.dump(data, fp, protocol=pk.HIGHEST_PROTOCOL)
    return filepath


def load_from_pickle(filepath: str) -> object:
    """Load a Python object from a pickle file.

    Warning: unpickling executes arbitrary code. Only call this with files
    from trusted sources.
    """
    with open(filepath, 'rb') as fp:
        data = pk.load(fp)
    return data


def save_to_file(filepath: str, text: str) -> str:
    with open(filepath, 'w') as fp:
        fp.write(text)
    return filepath


def get_timestamped_filename(filename: str, extension: str, stamp: dt.datetime) -> str:
    return '{0}-{1}.{2}'.format(
        filename,
        get_stamp_text(stamp),
        extension)


def get_timestamped_name(name: str, stamp: dt.datetime) -> str:
    return '{0}-{1}'.format(
        name,
        get_stamp_text(stamp))


def get_stamp_text(stamp: dt.datetime) -> str:
    return '{0:04d}-{1:02d}-{2:02d}-{3:02d}-{4:02d}-{5:02d}'.format(
        stamp.year,
        stamp.month,
        stamp.day,
        stamp.hour,
        stamp.minute,
        stamp.second)


def create_if_not_exists(directory: str) -> str:
    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory


def get_stamp_folder(directory: str, stamp: dt.datetime) -> str:
    return create_if_not_exists(
        os.path.join(
            directory,
            get_stamp_text(stamp)))
