import pytest
from pwml.utilities.imagehelpers import Rectangle


def test_contains_self():
    """A rectangle contains itself."""
    r = Rectangle(10, 20, 100, 50)
    assert r.contains(r)


def test_contains_inner():
    """A strictly smaller rectangle fully inside is contained."""
    outer = Rectangle(0, 0, 100, 100)
    inner = Rectangle(10, 10, 80, 80)
    assert outer.contains(inner)


def test_contains_offset_outer():
    """Outer rectangle not at origin - inner must be checked relative to outer."""
    outer = Rectangle(50, 50, 100, 100)   # spans x:50-150, y:50-150
    inner = Rectangle(60, 60, 80, 80)     # spans x:60-140, y:60-140
    assert outer.contains(inner)


def test_not_contains_overflow_right():
    """Inner rectangle extending beyond the right edge is not contained."""
    outer = Rectangle(0, 0, 100, 100)
    inner = Rectangle(50, 0, 60, 50)   # right edge at 110 > 100
    assert not outer.contains(inner)


def test_not_contains_overflow_bottom():
    """Inner rectangle extending beyond the bottom edge is not contained."""
    outer = Rectangle(0, 0, 100, 100)
    inner = Rectangle(0, 50, 50, 60)   # bottom edge at 110 > 100
    assert not outer.contains(inner)


def test_not_contains_offset_outer_overflow():
    """The bug case: outer starts at x=50; a rect starting at x=0 is not inside."""
    outer = Rectangle(50, 50, 100, 100)  # spans x:50-150
    overflow = Rectangle(0, 50, 40, 40)  # starts left of outer.x
    assert not outer.contains(overflow)


def test_grow_stays_within_image():
    """grow() result must be contained within the image bounds."""
    r = Rectangle(30, 30, 40, 40)
    grown = r.grow(ratio=0.5, image_width=200, image_height=200)
    image = Rectangle(0, 0, 200, 200)
    assert image.contains(grown)
