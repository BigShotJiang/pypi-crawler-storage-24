import json
import argparse
from .core import SecuritySkill361


def main():
    parser = argparse.ArgumentParser(
        prog="skill-361",
        description="OpenClaw Security Skill - 361",
    )
    subparsers = parser.add_subparsers(dest="action", help="Action to perform")

    cmd_parser = subparsers.add_parser("check", help="Check a command for risks")
    cmd_parser.add_argument("command", nargs="+", help="Command to check")

    scan_parser = subparsers.add_parser("scan", help="Scan a skill for security issues")
    scan_parser.add_argument("path", help="Path to skill directory")

    scanall_parser = subparsers.add_parser("scan-all", help="Scan all skills in directory")
    scanall_parser.add_argument("directory", help="Path to skills directory")

    subparsers.add_parser("report", help="Show security event report")

    args = parser.parse_args()
    skill = SecuritySkill361()

    if args.action == "check":
        skill.check_command(" ".join(args.command))
    elif args.action == "scan":
        skill.scan_skill(args.path)
    elif args.action == "scan-all":
        skill.scan_all(args.directory)
    elif args.action == "report":
        print(json.dumps(skill.get_security_report(), indent=2))
    else:
        parser.print_help()
