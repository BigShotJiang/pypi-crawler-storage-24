#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║   361 — OpenClaw Security Skill                             ║
║   "360° coverage + 1° of vigilance"                         ║
║                                                              ║
║   • Intercepts dangerous commands before execution           ║
║   • Scans other skills for malicious patterns                ║
║   • Provides real-time security alerts                       ║
╚══════════════════════════════════════════════════════════════╝
"""

import re
import json
from pathlib import Path
from typing import Optional

import yaml

from .utils.logger import SecurityLogger, Severity
from .utils.alert import AlertDispatcher
from .scanner import SkillScanner, ScanReport


class SecuritySkill361:
    """
    OpenClaw Security Skill — 361
    
    Hooks into the OpenClaw lifecycle to:
      1. pre_execute:       Check every command before it runs
      2. on_skill_install:  Scan newly installed skills
      3. on_skill_load:     Verify skill integrity on load
    """

    BANNER = r"""
    ╔═══════════════════════════════════════╗
    ║      ███╗   ██████╗  ██╗             ║
    ║      ╚══╝  ██╔════╝ ███║             ║
    ║  ██████╗   ███████╗ ╚██║   🛡️        ║
    ║  ╚═══██║   ██╔═══██╗ ██║   Security  ║
    ║  ██████║   ╚██████╔╝ ██║   Skill     ║
    ║  ╚═════╝    ╚═════╝  ╚═╝             ║
    ╚═══════════════════════════════════════╝
    """

    def __init__(self, config: Optional[dict] = None):
        self.config = config or self._load_default_config()
        self.logger = SecurityLogger(level=self.config.get("log_level", "WARNING"))
        self.alerter = AlertDispatcher(channels=self.config.get("alert_channels", ["console", "log"]))
        self.scanner = SkillScanner(logger=self.logger, alerter=self.alerter)
        self.command_rules = self._load_command_rules()
        self.whitelist = set(self.config.get("whitelist_skills", []))
        self.strict_mode = self.config.get("strict_mode", True)
        self.auto_block = self.config.get("auto_block", True)

        print(self.BANNER)
        print("  [361] 🛡️  Security skill activated.\n")

    # ─── Configuration ──────────────────────────────────────

    @staticmethod
    def _load_default_config() -> dict:
        config_path = Path(__file__).parent / "skill.json"
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                manifest = json.load(f)
                return manifest.get("config", {})
        return {}

    @staticmethod
    def _load_command_rules() -> list[dict]:
        rules_path = Path(__file__).parent / "rules" / "dangerous_commands.yaml"
        if rules_path.exists():
            with open(rules_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
                return data.get("rules", [])
        return []

    # ─── Hook: PRE_EXECUTE ──────────────────────────────────
    #     Intercepts commands before they run.

    def pre_execute(self, command: str, context: Optional[dict] = None) -> dict:
        """
        Called by OpenClaw before any command execution.
        
        Args:
            command: The raw command string to be executed.
            context: Optional execution context (skill name, user, etc.).
            
        Returns:
            dict with keys:
                - allowed (bool): Whether the command may proceed
                - reason (str):   Explanation if blocked
                - severity (str): Threat level
                - rule_id (str):  Matched rule ID
        """
        context = context or {}
        source_skill = context.get("skill_name", "unknown")

        # Allow whitelisted skills in non-strict mode
        if not self.strict_mode and source_skill in self.whitelist:
            return {"allowed": True, "reason": "Whitelisted skill", "severity": "INFO", "rule_id": None}

        # Check command against all rules
        for rule in self.command_rules:
            for pattern in rule.get("patterns", []):
                try:
                    match = re.search(pattern, command, re.IGNORECASE)
                except re.error:
                    continue
                if match:
                    severity_name = rule["severity"]
                    severity_enum = Severity[severity_name]
                    action = rule.get("action", "WARN")

                    # Determine whether to block
                    blocked = (action == "BLOCK" and self.auto_block) or (
                        self.strict_mode and severity_enum >= Severity.HIGH
                    )

                    action_taken = "BLOCKED" if blocked else "WARNED"

                    # Log the event
                    self.logger.log_event(
                        rule_id=rule["id"],
                        severity=severity_enum,
                        message=rule["message"],
                        command=command,
                        skill_name=source_skill,
                        action_taken=action_taken,
                    )

                    # Alert for HIGH/CRITICAL
                    if severity_enum >= Severity.HIGH:
                        self.alerter.send(
                            title=f"Dangerous Command Detected — {rule['id']}",
                            body=rule["message"],
                            severity=severity_name,
                            metadata={
                                "command": command,
                                "source_skill": source_skill,
                                "action": action_taken,
                            },
                        )

                    return {
                        "allowed": not blocked,
                        "reason": rule["message"],
                        "severity": severity_name,
                        "rule_id": rule["id"],
                    }

        # No rules matched — safe
        return {"allowed": True, "reason": "No threats detected", "severity": "INFO", "rule_id": None}

    # ─── Hook: ON_SKILL_INSTALL ─────────────────────────────
    #     Scans a skill when first installed.

    def on_skill_install(self, skill_path: str) -> ScanReport:
        """
        Called by OpenClaw when a new skill is installed.
        
        Args:
            skill_path: Path to the newly installed skill directory.
            
        Returns:
            ScanReport with findings.
        """
        print(f"\n🛡️  [361] Scanning newly installed skill: {skill_path}")
        report = self.scanner.scan_skill(skill_path)
        print(report.summary())

        if not report.is_safe:
            self.alerter.send(
                title="⚠️  Unsafe Skill Installation Attempt",
                body=f"Skill at '{skill_path}' failed security scan (score: {report.score}/100)",
                severity="HIGH",
                metadata={"skill_path": skill_path, "findings": len(report.findings)},
            )

            if self.auto_block:
                print(f"\n🚫 [361] BLOCKED installation of unsafe skill: {skill_path}")
                # In real OpenClaw: raise SkillInstallBlockedError(report)

        return report

    # ─── Hook: ON_SKILL_LOAD ────────────────────────────────
    #     Quick integrity check on skill load.

    def on_skill_load(self, skill_path: str) -> bool:
        """
        Called by OpenClaw each time a skill is loaded.
        Performs a lightweight integrity check.
        
        Returns:
            True if skill passed checks, False if suspect.
        """
        skill_path = Path(skill_path)
        manifest = skill_path / "skill.json"

        if not manifest.exists():
            self.logger.log_event(
                rule_id="LOAD-001",
                severity=Severity.MEDIUM,
                message="Skill loaded without manifest — cannot verify integrity.",
                skill_name=skill_path.name,
                action_taken="WARNED",
            )
            return not self.strict_mode  # block in strict mode

        return True

    # ─── Manual Commands ────────────────────────────────────

    def scan_skill(self, skill_path: str) -> ScanReport:
        """Manually trigger a scan on a specific skill."""
        report = self.scanner.scan_skill(skill_path)
        print(report.summary())
        return report

    def scan_all(self, skills_directory: str) -> list[ScanReport]:
        """Scan all installed skills."""
        return self.scanner.scan_all_skills(skills_directory)

    def check_command(self, command: str) -> dict:
        """Manually check a command for risks (without blocking)."""
        result = self.pre_execute(command, context={"skill_name": "manual-check"})
        if result["allowed"]:
            print(f"  ✅ Command appears safe: `{command}`")
        else:
            print(f"  🚫 Command BLOCKED: `{command}`")
            print(f"     Reason: {result['reason']}")
        return result

    def get_security_report(self) -> dict:
        """Return cumulative security report."""
        return self.logger.get_report()


# ─── CLI Interface ──────────────────────────────────────────

def main():
    import argparse

    parser = argparse.ArgumentParser(
        prog="361",
        description="🛡️ OpenClaw Security Skill — 361",
    )
    subparsers = parser.add_subparsers(dest="action", help="Action to perform")

    # Check a command
    cmd_parser = subparsers.add_parser("check", help="Check a command for risks")
    cmd_parser.add_argument("command", nargs="+", help="Command to check")

    # Scan a skill
    scan_parser = subparsers.add_parser("scan", help="Scan a skill for security issues")
    scan_parser.add_argument("path", help="Path to skill directory")

    # Scan all skills
    scanall_parser = subparsers.add_parser("scan-all", help="Scan all skills in directory")
    scanall_parser.add_argument("directory", help="Path to skills directory")

    # Show report
    subparsers.add_parser("report", help="Show security event report")

    args = parser.parse_args()
    skill = SecuritySkill361()

    if args.action == "check":
        command_str = " ".join(args.command)
        skill.check_command(command_str)

    elif args.action == "scan":
        skill.scan_skill(args.path)

    elif args.action == "scan-all":
        skill.scan_all(args.directory)

    elif args.action == "report":
        report = skill.get_security_report()
        print(json.dumps(report, indent=2))

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
