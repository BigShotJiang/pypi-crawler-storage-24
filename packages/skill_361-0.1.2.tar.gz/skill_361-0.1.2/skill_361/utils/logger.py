"""
361 Security Skill — Logger Utility
"""

import logging
from datetime import datetime, timezone
from enum import IntEnum
from typing import Optional


class Severity(IntEnum):
    INFO = 1
    LOW = 2
    MEDIUM = 3
    HIGH = 4
    CRITICAL = 5


# Color codes for terminal output
COLORS = {
    Severity.INFO:     "\033[36m",
    Severity.LOW:      "\033[34m",
    Severity.MEDIUM:   "\033[33m",
    Severity.HIGH:     "\033[91m",
    Severity.CRITICAL: "\033[97;41m",
}
RESET = "" #"\033[0m"


class SecurityLogger:
    """Centralized security event logger for the 361 skill."""

    def __init__(self, log_file: str = "361_security.log", level: str = "WARNING"):
        self.logger = logging.getLogger("361")
        self.logger.setLevel(getattr(logging, level.upper(), logging.WARNING))

        # Prevent duplicate handlers on re-init
        if not self.logger.handlers:
            # File handler
            fh = logging.FileHandler(log_file)
            fh.setFormatter(logging.Formatter(
                "[%(asctime)s] [361/%(levelname)s] %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            ))
            self.logger.addHandler(fh)

            # Console handler
            ch = logging.StreamHandler()
            ch.setFormatter(logging.Formatter("%(message)s"))
            self.logger.addHandler(ch)

        self.events: list = []

    def log_event(
        self,
        rule_id: str,
        severity: Severity,
        message: str,
        command: Optional[str] = None,
        skill_name: Optional[str] = None,
        action_taken: str = "LOGGED"
    ):
        """Record a security event."""
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "rule_id": rule_id,
            "severity": severity.name,
            "message": message,
            "command": command,
            "skill": skill_name,
            "action": action_taken,
        }
        self.events.append(event)

        color = "" #COLORS.get(severity, "")
        prefix = f"{color}[361 | {severity.name}]{RESET}"
        log_line = f"{prefix} {rule_id}: {message}"

        if command:
            log_line += f"\n    └─ Command: `{command}`"
        if skill_name:
            log_line += f"\n    └─ Skill:   {skill_name}"
        log_line += f"\n    └─ Action:  {action_taken}"

        if severity >= Severity.HIGH:
            self.logger.error(log_line)
        elif severity >= Severity.MEDIUM:
            self.logger.warning(log_line)
        else:
            self.logger.info(log_line)

    def get_report(self) -> dict:
        """Return a summary report of all logged events."""
        summary = {s.name: 0 for s in Severity}
        for e in self.events:
            summary[e["severity"]] += 1
        return {
            "total_events": len(self.events),
            "summary": summary,
            "events": self.events,
        }
