"""
361 Security Skill — Alert Dispatcher
"""

import json
from typing import Optional


class AlertDispatcher:
    """
    Dispatches security alerts to configured channels.
    Extensible: add webhook, email, or OpenClaw notification targets.
    """

    def __init__(self, channels: Optional[list] = None):
        self.channels = channels or ["console", "log"]

    def send(self, title: str, body: str, severity: str, metadata: Optional[dict] = None):
        """Dispatch alert to all configured channels."""
        alert_payload = {
            "title": title,
            "body": body,
            "severity": severity,
            "metadata": metadata or {},
        }

        for channel in self.channels:
            handler = getattr(self, f"_send_{channel}", None)
            if handler:
                handler(alert_payload)
            else:
                print(f"[361] ⚠ Unknown alert channel: {channel}")

    # ── Channel Handlers ─────────────────────────────────────

    @staticmethod
    def _send_console(payload: dict):
        sev = payload["severity"]
        icons = {
            "CRITICAL": "🚨🚨🚨",
            "HIGH": "🚨",
            "MEDIUM": "⚠️",
            "LOW": "ℹ️",
            "INFO": "📝",
        }
        icon = icons.get(sev, "📝")
        print(f"\n{'='*60}")
        print(f"  {icon}  361 SECURITY ALERT — [{sev}]")
        print(f"  {payload['title']}")
        print(f"  {payload['body']}")
        if payload["metadata"]:
            for k, v in payload["metadata"].items():
                print(f"    • {k}: {v}")
        print(f"{'='*60}\n")

    @staticmethod
    def _send_log(payload: dict):
        with open("361_alerts.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(payload) + "\n")

    @staticmethod
    def _send_webhook(payload: dict):
        """Placeholder for webhook integration."""
        # import requests
        # requests.post(WEBHOOK_URL, json=payload, timeout=10)
        pass
