"""
361 Security Skill — Skill Scanner Engine (with Permission Inference)
"""

import re
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, List, Set, Tuple

import yaml
import ast
from .utils.logger import SecurityLogger, Severity
from .utils.alert import AlertDispatcher


# =========================
# Data Models
# =========================

@dataclass
class ScanFinding:
    rule_id: str
    rule_name: str
    severity: str
    message: str
    file_path: str
    line_number: int
    line_content: str


@dataclass
class ScanReport:
    skill_name: str
    skill_path: str
    findings: List[ScanFinding] = field(default_factory=list)
    is_safe: bool = True
    score: int = 100

    def add_finding(self, finding: ScanFinding):
        self.findings.append(finding)

        penalty = {
            "CRITICAL": 40,
            "HIGH": 25,
            "MEDIUM": 10,
            "LOW": 3,
            "INFO": 0,
        }

        self.score = max(0, self.score - penalty.get(finding.severity, 5))

        if finding.severity in ("CRITICAL", "HIGH"):
            self.is_safe = False

    def to_dict(self) -> dict:
        return {
            "skill_name": self.skill_name,
            "skill_path": self.skill_path,
            "is_safe": self.is_safe,
            "security_score": self.score,
            "total_findings": len(self.findings),
            "findings": [
                {
                    "rule_id": f.rule_id,
                    "rule_name": f.rule_name,
                    "severity": f.severity,
                    "message": f.message,
                    "file": f.file_path,
                    "line": f.line_number,
                    "content": f.line_content.strip(),
                }
                for f in self.findings
            ],
        }
    def summary(self) -> str:
        # 状态 & 评分
        grade = "🟢 SAFE" if self.is_safe else "🔴 UNSAFE"

        # 统计各级别数量
        severity_count = {
            "CRITICAL": 0,
            "HIGH": 0,
            "MEDIUM": 0,
            "LOW": 0,
            "INFO": 0,
        }

        for f in self.findings:
            severity_count[f.severity] = severity_count.get(f.severity, 0) + 1

        header = (
            f"\n{'━'*60}\n"
            f"  🛡️  361 SKILL SCAN REPORT\n"
            f"  Skill:  {self.skill_name}\n"
            f"  Status: {grade}\n"
            f"  Score:  {self.score}/100\n"
            f"  Issues: {len(self.findings)}\n"
            f"  Breakdown: "
            f"☠️ {severity_count['CRITICAL']}  "
            f"🚨 {severity_count['HIGH']}  "
            f"⚠️ {severity_count['MEDIUM']}  "
            f"ℹ️ {severity_count['LOW']}\n"
            f"{'━'*60}"
        )

        if not self.findings:
            return header + "\n  ✅ No issues found.\n"

        # 按严重程度排序（关键优化）
        severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        sorted_findings = sorted(
            self.findings,
            key=lambda f: severity_order.get(f.severity, 99)
        )

        lines = [header]

        for f in sorted_findings:
            icon = {
                "CRITICAL": "☠️",
                "HIGH": "🚨",
                "MEDIUM": "⚠️",
                "LOW": "ℹ️",
                "INFO": "📝",
            }.get(f.severity, "📝")

            lines.append(
                f"\n  {icon} [{f.severity}] {f.rule_id} — {f.rule_name}\n"
                f"     {f.message}\n"
                f"     📄 {f.file_path}:{f.line_number}\n"
                f"     > {f.line_content.strip()}"
            )

        lines.append(f"\n{'━'*60}")
        return "\n".join(lines)





# =========================
# Scanner Engine
# =========================

class SkillScanner:

    SCAN_EXTENSIONS = {".py", ".js", ".ts", ".sh", ".bash", ".rb", ".pl", ".yaml", ".yml"}
    EXCLUDE_DIRS = {".git", "node_modules", "__pycache__"}

    # ===== 权限推断规则 =====
    PERMISSION_PATTERNS = {
        "network": [
            r"\bimport\s+requests\b",
            r"\bfrom\s+requests\b",
            r"\baiohttp\b",
            r"\bhttpx\b",
            r"\burllib\b",
            r"\bsocket\b",
        ],
        "filesystem": [
            r"\bopen\(",
            r"\bos\.remove\b",
            r"\bos\.rename\b",
            r"\bpathlib\b",
            r"\bshutil\b",
        ],
        "exec": [
            r"\bsubprocess\b",
            r"\bos\.system\b",
            r"\beval\(",
            r"\bexec\(",
        ],
        "env": [
            r"\bos\.environ\b",
            r"\bos\.getenv\b",
        ],
    }

    def __init__(
        self,
        rules_path: str = None,
        logger: Optional[SecurityLogger] = None,
        alerter: Optional[AlertDispatcher] = None,
    ):
        self.logger = logger or SecurityLogger()
        self.alerter = alerter or AlertDispatcher()

        if rules_path is None:
            rules_path = str(Path(__file__).parent / "rules" / "skill_audit_rules.yaml")
            if not Path(rules_path).exists():
                import importlib.resources as pkg_resources
                rules_path = str(pkg_resources.files("skill_361") / "rules" / "skill_audit_rules.yaml")

        self.rules = self._load_rules(rules_path)

        # ✅ 预编译权限检测 regex
        self.permission_patterns = {
            perm: [re.compile(p, re.IGNORECASE) for p in patterns]
            for perm, patterns in self.PERMISSION_PATTERNS.items()
        }

    # =========================
    # Rules
    # =========================

    def _load_rules(self, path: str) -> list:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            rules = data.get("skill_scan_rules", [])
            self._validate_rules(rules)

            # 预编译规则 regex
            for rule in rules:
                compiled = []
                for p in rule.get("patterns", []):
                    try:
                        compiled.append(re.compile(p, re.IGNORECASE))
                    except re.error:
                        self.logger.log_event(
                            rule_id=rule.get("id", "UNKNOWN"),
                            severity=Severity.LOW,
                            message=f"Skipping malformed pattern in rule {rule.get('id', '?')}: {p}",
                            action_taken="WARNED",
                        )
                rule["compiled_patterns"] = compiled

            return rules

        except FileNotFoundError:
            self.logger.warning(f"[361] Rules file not found: {path}")
            return []

    def _validate_rules(self, rules: list):
        required = {"id", "name", "severity", "message"}

        for rule in rules:
            if not required.issubset(rule):
                raise ValueError(f"Invalid rule detected: {rule}")

    # =========================
    # Manifest (SKILL.md)
    # =========================

    def _load_manifest(self, skill_path: Path) -> Optional[dict]:
        manifest_path = skill_path / "SKILL.md"

        if not manifest_path.exists():
            return None

        try:
            content = manifest_path.read_text(encoding="utf-8")

            if not content.startswith("---"):
                return None

            parts = content.split("---", 2)
            if len(parts) < 3:
                return None

            yaml_part = parts[1]
            result = yaml.safe_load(yaml_part)
            if not isinstance(result, dict):
                return None
            return result

        except Exception:
            return None

    def _validate_manifest(self, manifest: dict, path: Path, report: ScanReport):
        required = {"name", "description"}

        missing = required - manifest.keys()
        if missing:
            report.add_finding(ScanFinding(
                rule_id="SKILL-009",
                rule_name="Incomplete Manifest",
                severity="LOW",
                message=f"Missing fields: {missing}",
                file_path=str(path),
                line_number=0,
                line_content=str(manifest),
            ))

    def _is_comment_line(self, line: str, suffix: str) -> bool:
        comment_prefix = {
            ".py": "#",
            ".sh": "#",
            ".bash": "#",
            ".yaml": "#",
            ".yml": "#",
            ".js": "//",
            ".ts": "//",
            ".rb": "#",
            ".pl": "#",
        }

        prefix = comment_prefix.get(suffix)

        if prefix and line.startswith(prefix):
            return True

        # 多行注释（简单处理）
        if suffix in {".js", ".ts"}:
            if line.startswith("/*") or line.startswith("*") or line.startswith("*/"):
                return True

        return False
    def _strip_inline_comment(self, line: str, suffix: str) -> str:

        if suffix in {".py", ".sh", ".bash", ".yaml", ".yml", ".rb", ".pl"}:
            return line.split("#", 1)[0]

        if suffix in {".js", ".ts"}:
            return line.split("//", 1)[0]

        return line

    def _scan_python_ast(self, file_path: Path, report: ScanReport, seen: Set[Tuple]):
        try:
            tree = ast.parse(file_path.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            return

        for node in ast.walk(tree):

            # ===== 函数调用检测 =====
            if isinstance(node, ast.Call):

                func_name = self._get_call_name(node)

                if not func_name:
                    continue

                # ===== 危险函数 =====
                if func_name in {"eval", "exec"}:
                    self._add_ast_finding(
                        report, seen, file_path, node,
                        "AST-001", "Dangerous Function",
                        "CRITICAL",
                        f"Use of dangerous function '{func_name}'"
                    )

                elif func_name.startswith("subprocess"):
                    self._add_ast_finding(
                        report, seen, file_path, node,
                        "AST-002", "Subprocess Execution",
                        "HIGH",
                        f"Subprocess execution detected: {func_name}"
                    )

                elif func_name == "os.system":
                    self._add_ast_finding(
                        report, seen, file_path, node,
                        "AST-003", "System Call",
                        "HIGH",
                        "Use of os.system()"
                    )

                elif func_name.startswith("requests"):
                    self._add_ast_finding(
                        report, seen, file_path, node,
                        "AST-004", "Network Usage",
                        "INFO",
                        f"Network call via {func_name}"
                    )

                elif func_name == "open":
                    self._add_ast_finding(
                        report, seen, file_path, node,
                        "AST-005", "File Access",
                        "INFO",
                        "File system access via open()"
                    )


    def _get_call_name(self, node: ast.Call) -> Optional[str]:
        """
        解析函数名:
        - eval()
        - os.system()
        - subprocess.run()
        """

        if isinstance(node.func, ast.Name):
            return node.func.id

        elif isinstance(node.func, ast.Attribute):
            parts = []
            current = node.func

            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value

            if isinstance(current, ast.Name):
                parts.append(current.id)

            return ".".join(reversed(parts))

        return None
        
    def _add_ast_finding(
        self,
        report: ScanReport,
        seen: Set[Tuple],
        file_path: Path,
        node: ast.AST,
        rule_id: str,
        rule_name: str,
        severity: str,
        message: str
    ):
        line_no = getattr(node, "lineno", 0)

        key = (str(file_path), line_no, rule_id)
        if key in seen:
            return
        seen.add(key)

        report.add_finding(ScanFinding(
            rule_id=rule_id,
            rule_name=rule_name,
            severity=severity,
            message=message,
            file_path=str(file_path),
            line_number=line_no,
            line_content="(AST detected)"
        ))
    

    # =========================
    # Permission Inference
    # =========================

    def _infer_permissions(self, skill_path: Path) -> Set[str]:
        inferred: Set[str] = set()

        for file in self._iter_source_files(skill_path):
            try:
                content = file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            for perm, patterns in self.permission_patterns.items():
                for pattern in patterns:
                    if pattern.search(content):
                        inferred.add(perm)
                        break

        return inferred

    # =========================
    # Public API
    # =========================

    ALLOWED_BASE = Path.home() / ".openclaw"

    def scan_skill(self, skill_path: str) -> ScanReport:
        skill_path = Path(skill_path).resolve()

        if not skill_path.is_relative_to(self.ALLOWED_BASE):
            raise ValueError(
                f"[361] Path traversal blocked: '{skill_path}' is outside ~/.openclaw"
            )

        skill_name = self._get_skill_name(skill_path)

        report = ScanReport(skill_name=skill_name, skill_path=str(skill_path))
        print(f"[361] Scanning skill: {skill_name}")

        seen: Set[Tuple] = set()

        for file_path in self._iter_source_files(skill_path):
            self._scan_file(file_path, report, seen)

        self._audit_manifest(skill_path, report)

        if not report.is_safe:
            self._handle_unsafe(report)

        return report

    # =========================
    # Core Scanning
    # =========================

    def _scan_file(self, file_path: Path, report: ScanReport, seen: Set[Tuple]):

        # ✅ AST 扫描（只针对 Python）
        if file_path.suffix == ".py":
            self._scan_python_ast(file_path, report, seen)

        # ===== 原 regex 扫描（保留）=====
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return

        for i, raw_line in enumerate(content.splitlines(), start=1):

            line = raw_line.strip()
            if not line or self._is_comment_line(line, file_path.suffix):
                continue

            code_line = self._strip_inline_comment(raw_line, file_path.suffix)

            for rule in self.rules:
                if rule.get("check_type") == "manifest_audit":
                    continue

                for pattern in rule.get("compiled_patterns", []):
                    if pattern.search(code_line):

                        key = (str(file_path), i, rule["id"])
                        if key in seen:
                            continue
                        seen.add(key)

                        report.add_finding(ScanFinding(
                            rule_id=rule["id"],
                            rule_name=rule["name"],
                            severity=rule["severity"],
                            message=rule["message"],
                            file_path=str(file_path),
                            line_number=i,
                            line_content=raw_line,
                        ))
                        break
                        
    def scan_all_skills(self, skills_directory: str) -> list[ScanReport]:
        """Scan every skill inside the OpenClaw skills directory."""
        skills_dir = Path(skills_directory)
        reports = []

        if not skills_dir.is_dir():
            print(f"[361] ❌ Skills directory not found: {skills_dir}")
            return reports

        for child in sorted(skills_dir.iterdir()):
            if child.is_dir() and not child.name.startswith((".", "_")):
                report = self.scan_skill(str(child))
                reports.append(report)

        # Print aggregate summary
        total = len(reports)
        safe = sum(1 for r in reports if r.is_safe)
        unsafe = total - safe
        print(f"\n{'═'*60}")
        print(f"  🛡️  361 — FULL SCAN COMPLETE")
        print(f"  Total:  {total} skills")
        print(f"  Safe:   🟢 {safe}")
        print(f"  Unsafe: 🔴 {unsafe}")
        print(f"{'═'*60}\n")

        return reports


    def _audit_manifest(self, skill_path: Path, report: ScanReport):
        manifest_path = skill_path / "SKILL.md"
        manifest = self._load_manifest(skill_path)

        if manifest is None:
            report.add_finding(ScanFinding(
                rule_id="SKILL-007",
                rule_name="Missing Manifest",
                severity="MEDIUM",
                message="Missing or invalid SKILL.md",
                file_path=str(manifest_path),
                line_number=0,
                line_content="(missing or invalid frontmatter)",
            ))
            return

        self._validate_manifest(manifest, manifest_path, report)

        declared_perms = set(manifest.get("permissions", []))

        # 🚀 自动推断权限
        inferred_perms = self._infer_permissions(skill_path)

        # ❗ 缺失权限（严重）
        missing = inferred_perms - declared_perms
        if missing:
            report.add_finding(ScanFinding(
                rule_id="SKILL-010",
                rule_name="Missing Permissions (Auto Inferred)",
                severity="LOW",  # for show warning future big use
                message=f"Code uses permissions not declared: {missing}",
                file_path=str(manifest_path),
                line_number=0,
                line_content=f"declared={declared_perms}, inferred={inferred_perms}",
            ))

        # ⚠️ 过度授权（较轻）
        extra = declared_perms - inferred_perms
        if extra:
            report.add_finding(ScanFinding(
                rule_id="SKILL-011",
                rule_name="Overprivileged Skill",
                severity="LOW",
                message=f"Declared but unused permissions: {extra}",
                file_path=str(manifest_path),
                line_number=0,
                line_content=f"declared={declared_perms}, inferred={inferred_perms}",
            ))

    # =========================
    # Utils
    # =========================

    def _iter_source_files(self, root: Path):
        for path in root.rglob("*"):
            if path.is_symlink():
                continue
            if any(part in self.EXCLUDE_DIRS for part in path.parts):
                continue
            if path.is_file() and path.suffix in self.SCAN_EXTENSIONS:
                yield path

    def _get_skill_name(self, skill_path: Path) -> str:
        manifest = self._load_manifest(skill_path)

        if manifest:
            return manifest.get("name", skill_path.name)

        return skill_path.name

    def _handle_unsafe(self, report: ScanReport):
        self.alerter.send(
            title=f"Unsafe Skill: {report.skill_name}",
            body=f"Score: {report.score} | Findings: {len(report.findings)}",
            severity="HIGH",
            metadata={"skill_path": report.skill_path},
        )

        self.logger.log_event(
            rule_id="SCAN-RESULT",
            severity=Severity.HIGH,
            message=f"Skill '{report.skill_name}' UNSAFE",
            skill_name=report.skill_name,
            action_taken="FLAGGED",
        )
