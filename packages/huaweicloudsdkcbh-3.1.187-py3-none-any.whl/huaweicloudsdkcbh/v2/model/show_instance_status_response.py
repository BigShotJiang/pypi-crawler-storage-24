# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowInstanceStatusResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'status': 'str',
        'server_id': 'str'
    }

    attribute_map = {
        'name': 'name',
        'status': 'status',
        'server_id': 'server_id'
    }

    def __init__(self, name=None, status=None, server_id=None):
        r"""ShowInstanceStatusResponse

        The model defined in huaweicloud sdk

        :param name: 云堡垒机实例名称。
        :type name: str
        :param status: 堡垒机实例状态。 - POWERING_ON：正在开启 - POWERING_OFF：正在关闭 - DELETE_WAITE：等待删除 - REBOOTING：重启中 - RESIZE：变更中 - UPGRADING：升级中 - FROZEN：冻结 - ACTIVE：运行
        :type status: str
        :param server_id: 云堡垒机实例ID，使用UUID格式表示。
        :type server_id: str
        """
        
        super().__init__()

        self._name = None
        self._status = None
        self._server_id = None
        self.discriminator = None

        if name is not None:
            self.name = name
        if status is not None:
            self.status = status
        if server_id is not None:
            self.server_id = server_id

    @property
    def name(self):
        r"""Gets the name of this ShowInstanceStatusResponse.

        云堡垒机实例名称。

        :return: The name of this ShowInstanceStatusResponse.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this ShowInstanceStatusResponse.

        云堡垒机实例名称。

        :param name: The name of this ShowInstanceStatusResponse.
        :type name: str
        """
        self._name = name

    @property
    def status(self):
        r"""Gets the status of this ShowInstanceStatusResponse.

        堡垒机实例状态。 - POWERING_ON：正在开启 - POWERING_OFF：正在关闭 - DELETE_WAITE：等待删除 - REBOOTING：重启中 - RESIZE：变更中 - UPGRADING：升级中 - FROZEN：冻结 - ACTIVE：运行

        :return: The status of this ShowInstanceStatusResponse.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this ShowInstanceStatusResponse.

        堡垒机实例状态。 - POWERING_ON：正在开启 - POWERING_OFF：正在关闭 - DELETE_WAITE：等待删除 - REBOOTING：重启中 - RESIZE：变更中 - UPGRADING：升级中 - FROZEN：冻结 - ACTIVE：运行

        :param status: The status of this ShowInstanceStatusResponse.
        :type status: str
        """
        self._status = status

    @property
    def server_id(self):
        r"""Gets the server_id of this ShowInstanceStatusResponse.

        云堡垒机实例ID，使用UUID格式表示。

        :return: The server_id of this ShowInstanceStatusResponse.
        :rtype: str
        """
        return self._server_id

    @server_id.setter
    def server_id(self, server_id):
        r"""Sets the server_id of this ShowInstanceStatusResponse.

        云堡垒机实例ID，使用UUID格式表示。

        :param server_id: The server_id of this ShowInstanceStatusResponse.
        :type server_id: str
        """
        self._server_id = server_id

    def to_dict(self):
        import warnings
        warnings.warn("ShowInstanceStatusResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowInstanceStatusResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
