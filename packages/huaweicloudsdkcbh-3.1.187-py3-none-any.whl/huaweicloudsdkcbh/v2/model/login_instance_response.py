# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class LoginInstanceResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'login_url': 'str'
    }

    attribute_map = {
        'login_url': 'login_url'
    }

    def __init__(self, login_url=None):
        r"""LoginInstanceResponse

        The model defined in huaweicloud sdk

        :param login_url: 云堡垒机登录链接。
        :type login_url: str
        """
        
        super().__init__()

        self._login_url = None
        self.discriminator = None

        if login_url is not None:
            self.login_url = login_url

    @property
    def login_url(self):
        r"""Gets the login_url of this LoginInstanceResponse.

        云堡垒机登录链接。

        :return: The login_url of this LoginInstanceResponse.
        :rtype: str
        """
        return self._login_url

    @login_url.setter
    def login_url(self, login_url):
        r"""Sets the login_url of this LoginInstanceResponse.

        云堡垒机登录链接。

        :param login_url: The login_url of this LoginInstanceResponse.
        :type login_url: str
        """
        self._login_url = login_url

    def to_dict(self):
        import warnings
        warnings.warn("LoginInstanceResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, LoginInstanceResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
