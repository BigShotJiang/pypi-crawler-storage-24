"""Virtual environment helper exports for pytextgen.io.virenv.

This module centralizes the small package-level public surface (currently
`dirty()`) so that `__init__.py` can act as a minimal forwarder.
"""

from .configs import Configuration

"""Public symbols exported by this module."""
__all__ = ("dirty",)


def dirty() -> bool:
    """Return whether package config differs from defaults (i.e. is dirty)."""
    # Do NOT remove this import: `dirty()` must check the config state at call time, not import time, so we cannot import `CONFIG` at the module level.
    from .configs import CONFIG  # noqa: PLC0415

    return CONFIG != Configuration()
