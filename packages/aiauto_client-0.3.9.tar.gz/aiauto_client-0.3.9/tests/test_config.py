"""Tests for _config module: parse_grpc_target, is_secure_url, env var parsing."""

import importlib

import pytest

from aiauto._config import is_secure_url, parse_grpc_target


class TestParseGrpcTarget:
    """Test parse_grpc_target function."""

    def test_https_with_port(self):
        result = parse_grpc_target("https://aiauto.pangyo.ainode.ai:443")
        assert result == "aiauto.pangyo.ainode.ai:443"

    def test_http_with_port(self):
        result = parse_grpc_target("http://localhost:8080")
        assert result == "localhost:8080"

    def test_https_default_port(self):
        result = parse_grpc_target("https://aiauto.pangyo.ainode.ai")
        assert result == "aiauto.pangyo.ainode.ai:443"

    def test_http_default_port(self):
        result = parse_grpc_target("http://localhost")
        assert result == "localhost:80"

    def test_missing_hostname_raises(self):
        with pytest.raises(ValueError, match="hostname"):
            parse_grpc_target("https://")

    def test_missing_scheme_raises(self):
        with pytest.raises(ValueError, match="hostname"):
            parse_grpc_target("just-a-hostname")


class TestParseGrpcTargetEdgeCases:
    """Test parse_grpc_target edge cases."""

    def test_ip_address_with_port(self):
        result = parse_grpc_target("https://192.168.1.100:8443")
        assert result == "192.168.1.100:8443"

    def test_http_ip_default_port(self):
        result = parse_grpc_target("http://10.0.0.1")
        assert result == "10.0.0.1:80"

    def test_url_with_path_ignores_path(self):
        """Path portion is ignored, only host:port extracted."""
        result = parse_grpc_target("https://example.com:443/some/path")
        assert result == "example.com:443"

    def test_empty_string_raises(self):
        with pytest.raises(ValueError, match="hostname"):
            parse_grpc_target("")


class TestIsSecureUrl:
    """Test is_secure_url function."""

    def test_https_is_secure(self):
        assert is_secure_url("https://example.com:443") is True

    def test_http_is_not_secure(self):
        assert is_secure_url("http://localhost:8080") is False

    def test_empty_scheme(self):
        assert is_secure_url("example.com:443") is False

    def test_ftp_is_not_secure(self):
        """Non-https schemes return False."""
        assert is_secure_url("ftp://example.com") is False


class TestAiautoInsecureEnvParsing:
    """Test AIAUTO_INSECURE environment variable parsing.

    Tests the module-level code that parses AIAUTO_INSECURE from env.
    We reload the module with patched env to test different values.
    """

    def test_insecure_true_values(self, monkeypatch):
        """'true', '1', 'yes' (case-insensitive) should set AIAUTO_INSECURE=True."""
        import warnings

        for value in ("true", "True", "TRUE", "1", "yes", "Yes", "YES"):
            monkeypatch.setenv("AIAUTO_INSECURE", value)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                import aiauto._config as cfg_module

                reloaded = importlib.reload(cfg_module)
            assert reloaded.AIAUTO_INSECURE is True, f"Expected True for {value!r}"

    def test_insecure_false_values(self, monkeypatch):
        """Other values (empty, 'false', 'no', '0') should set AIAUTO_INSECURE=False."""
        for value in ("", "false", "no", "0", "anything"):
            monkeypatch.setenv("AIAUTO_INSECURE", value)
            import aiauto._config as cfg_module

            reloaded = importlib.reload(cfg_module)
            assert reloaded.AIAUTO_INSECURE is False, f"Expected False for {value!r}"

    def test_insecure_unset(self, monkeypatch):
        """Unset AIAUTO_INSECURE defaults to False."""
        monkeypatch.delenv("AIAUTO_INSECURE", raising=False)
        import aiauto._config as cfg_module

        reloaded = importlib.reload(cfg_module)
        assert reloaded.AIAUTO_INSECURE is False
