"""Tests for _version module: get_version(), semver validation, fallback."""

from unittest.mock import patch

from aiauto._version import _SEMVER_RE, get_version


class TestSemverRegex:
    """Test _SEMVER_RE pattern matches correct semver strings."""

    def test_valid_semver(self):
        assert _SEMVER_RE.match("0.0.0")
        assert _SEMVER_RE.match("1.2.3")
        assert _SEMVER_RE.match("10.20.30")

    def test_invalid_semver_with_suffix(self):
        assert _SEMVER_RE.match("1.2.3rc1") is None
        assert _SEMVER_RE.match("1.2.3.post1") is None
        assert _SEMVER_RE.match("1.2.3.dev1") is None

    def test_invalid_semver_formats(self):
        assert _SEMVER_RE.match("1.2") is None
        assert _SEMVER_RE.match("1") is None
        assert _SEMVER_RE.match("abc") is None
        assert _SEMVER_RE.match("") is None


class TestGetVersion:
    """Test get_version() function."""

    def test_returns_installed_version(self):
        """When package is installed, returns its version (semver format)."""
        with patch("aiauto._version.version", return_value="0.3.2"):
            result = get_version()
        assert result == "0.3.2"

    def test_package_not_found_returns_fallback(self):
        """When package is not installed, returns '0.0.0'."""
        from importlib.metadata import PackageNotFoundError

        with patch("aiauto._version.version", side_effect=PackageNotFoundError("not found")):
            result = get_version()
        assert result == "0.0.0"

    def test_non_semver_version_returns_fallback(self):
        """When version string is not semver-compatible, returns '0.0.0'."""
        with patch("aiauto._version.version", return_value="0.3.2rc1"):
            result = get_version()
        assert result == "0.0.0"

    def test_dev_version_returns_fallback(self):
        """Dev version like '0.3.2.dev1' returns '0.0.0'."""
        with patch("aiauto._version.version", return_value="0.3.2.dev1"):
            result = get_version()
        assert result == "0.0.0"
