import logging

from ._config import AIAUTO_BASE_URL, AIAUTO_INSECURE, AIAUTO_LOG_LEVEL
from ._version import __version__
from .constants import RUNTIME_IMAGES
from .core import AIAutoController, StudyWrapper, TrialController, WaitOption
from .grpc_helper import AIAutoRpcError
from .sampler import ExhaustiveCategoricalSampler, SearchSpaceExhausted

# Configure package-level logger (AIAUTO_LOG_LEVEL env var, default: INFO)
_pkg_logger = logging.getLogger("aiauto")
if not _pkg_logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(message)s"))
    _pkg_logger.addHandler(_handler)
    _pkg_logger.propagate = False
_pkg_logger.setLevel(getattr(logging, AIAUTO_LOG_LEVEL, logging.INFO))

__all__ = [
    "AIAUTO_BASE_URL",
    "AIAUTO_INSECURE",
    "RUNTIME_IMAGES",
    "AIAutoController",
    "AIAutoRpcError",
    "ExhaustiveCategoricalSampler",
    "SearchSpaceExhausted",
    "StudyWrapper",
    "TrialController",
    "WaitOption",
    "__version__",
]
