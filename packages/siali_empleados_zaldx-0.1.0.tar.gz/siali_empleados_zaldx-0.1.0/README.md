# Paquete Siali Empleados

Este es un paquete de Python para gestionar empleados mediante Programación Orientada a Objetos.
Incluye lectura de datos desde un archivo de texto.