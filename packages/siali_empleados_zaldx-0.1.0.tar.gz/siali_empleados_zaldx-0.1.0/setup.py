from setuptools import setup, find_packages

setup(
    name='siali_empleados_zaldx', # El nombre con el que la gente hará 'pip install ...' (debe ser único en todo PyPI)
    version='0.1.0',              # La versión de tu paquete
    packages=find_packages(),     # Esto buscará automáticamente tu carpeta siali_empleados
    include_package_data=True,    # ESTO ES VITAL: Le dice que lea el archivo MANIFEST.in
    description='Un paquete para la gestion de empleados en Siali',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Riera',
    author_email='rieraalex30@gmail.com',
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6', # Requiere Python 3.6 o superior
)