import random
import os
class Empleado:
  contador = 0

  def __init__  (self, name, surname):
    Empleado.contador += 1
    self.id = Empleado.contador
    self.name = name
    self.surname = surname
    self.email = f"{name.lower()}.{surname.lower()}@email.com"
    self.pay = random.randint(1500, 2200)
    self.msg = ""

  @classmethod
  def instanciador(cls, string):
    name, surname = string.split(",")
    return cls(name.strip(), surname.strip())

  def __str__(self):
    return(f"El empleado {self.name} cobra {self.pay:.2f} €")

  def __add__(self, other):
    return(f"La suma de los sueldos de {self.name} y {other.name} es: {self.pay + other.pay:.2f} €")

  def pay_rise(self):
    self.pay = self.pay * 1.15
    return self.pay

class CEO(Empleado):
  def __init__(self, name, surname):
    super().__init__(name, surname)
    self.employees = []
    self.historial = []

  def add_employee(self, employee):
    self.employees.append(employee)
    self.historial.append(f"{employee.name} {employee.surname} ha sido añadido a cargo de {self.name} {self.surname}")

  def remove_employee(self, employee):
    self.employees.remove(employee)
    self.historial.append(f"{employee.name} {employee.surname} ha sido eliminado del cargo de {self.name} {self.surname}")

  def __str__(self):
    return(f"El CEO {self.name} {self.surname} tiene {len(self.employees)} empleados")

CARPETA_ACTUAL = os.path.dirname(os.path.abspath(__file__))
RUTA_TXT = os.path.join(CARPETA_ACTUAL, "lista_empleados.txt")
with open(RUTA_TXT, 'r') as archivo:
  empleados = [Empleado.instanciador(linea) for linea in archivo]

for empleado in empleados:
  print(f"ID: {empleado.id}")
  print(f"Nombre: {empleado.name} {empleado.surname}")
  print(f"Email: {empleado.email}")
  print(f"Sueldo: {empleado.pay} €")
  print(empleado)

e1 = Empleado("Sergio", "Pesquera")
e2 = Empleado.instanciador("Miguel, Betegon")
e3 = Empleado.instanciador("Enrique, Pernia")
e4 = Empleado.instanciador("Juan, Garcia")
e5 = Empleado.instanciador("Pedro, Sanchez")
e6 = Empleado.instanciador("Ana, Martinez")

ceo = CEO("Sergio", "Pesquera")
ceo.add_employee(e4)
ceo.add_employee(e5)
ceo.add_employee(e6)
ceo.remove_employee(e5)

for empleado in [e1, e2, e3, e4, e5, e6]:
  print(f"ID: {empleado.id}")
  print(f"Nombre: {empleado.name} {empleado.surname}")
  print(f"Email: {empleado.email}")
  print(f"Sueldo: {empleado.pay} €")
  empleado.pay_rise()
  print(f"Sueldo tras subida: {empleado.pay:.2f}")

print(e1)
print("")

print(e1 + e2)
print("")

for i in ceo.historial:
  print(i)

