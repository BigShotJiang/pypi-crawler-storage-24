from datetime import timezone, timedelta, datetime
from fastapi import status, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from src.core.database import get_session
from src.models.schema.user import User
import bcrypt
from jose import JWTError, jwt
from src.core.settings import settings


security = HTTPBearer()


def hash_password(password: str) -> str:
    pwd_bytes = password.encode("utf-8")[:72]
    return bcrypt.hashpw(pwd_bytes, bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())


def create_access_token(sub: str | int, **extra) -> str:
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=10)
    payload = {
        "sub": str(sub),
        "exp": expire,
        "iat": now,
        **(extra or {}),
    }

    return jwt.encode(payload, settings.SECRET_KEY, settings.ALDORITHM)


def decode_access_token(token: str) -> dict | None:

    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALDORITHM])
    except JWTError:
        return None


async def get_current_user(
    credentails: HTTPAuthorizationCredentials = Depends(security),
    session: AsyncSession = Depends(get_session),
) -> User:
    token = credentails.credentials
    payload = decode_access_token(token)
    if not payload or "sub" not in payload:
        return HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expire token",
        )
    user_id = int(payload["sub"])
    res = await session.execute(select(User).where(User.id == user_id))
    user = res.scalar_one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found"
        )
    return user
