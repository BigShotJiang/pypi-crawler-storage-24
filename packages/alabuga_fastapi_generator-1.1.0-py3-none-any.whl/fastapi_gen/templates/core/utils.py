from typing import Callable
from fastapi import HTTPException
from src.core.exseption import DoesNotExist, UniqueConstarint


async def response(*, func: Callable, **kwargs):
    try:
        return await func(**kwargs)
    except DoesNotExist as e:
        raise HTTPException(status_code=404, detail=str(e))
    except UniqueConstarint as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:

        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")
