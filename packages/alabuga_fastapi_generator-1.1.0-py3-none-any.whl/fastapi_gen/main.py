import typer
from jinja2 import Template
from pathlib import Path
from typing import Optional
from typing_extensions import Annotated
import shutil

# Create a Typer application instance for CLI command handling
app = typer.Typer()

def generate_core_files():
    """Copy all .py files from templates/core."""
    # url
    source_dir = Path(__file__).parent / "templates" / "core"
    
    if not source_dir.exists() or not source_dir.is_dir():
        typer.secho(f"Ошибка: Директория {source_dir} не найдена.", fg="red")
        return

    # only .py files
    py_files = list(source_dir.glob("*.py"))

    if not py_files:
        typer.secho("В папке templates/core нет .py файлов.", fg="yellow")
        return

    for file_path in py_files:
        # Copy all files
        dest_path = Path.cwd() / file_path.name
        shutil.copy2(file_path, dest_path)
        typer.secho(f"Core файл скопирован: {file_path.name}", fg="magenta")

def generate_dynamic(name: str, template_name: str, file_prefix: str):
    """
    Generate a dynamic file from a Jinja2 template with variable substitution.

    Args:
        name (str): The base name to be used in the file name and template rendering
        template_name (str): Name of the Jinja2 template file (without extension)
        file_prefix (str): Prefix to be added to the generated file name
    """
    # Construct the full path to the template file
    template_path = Path(__file__).parent / "templates" / f"{template_name}.jinja2"

    # Check if the template file exists
    if not template_path.exists():
        typer.secho(f"Template {template_name} not found", fg="red")
        return

    # Read and parse the Jinja2 template
    template = Template(template_path.read_text(encoding="utf-8"))

    # Render the template with context variables:
    # - name: capitalized version of the input name
    # - lower_name: lowercase version of the input name
    rendered = template.render(name=name.capitalize(), lower_name=name.lower())

    # Generate the output file name using prefix and lowercase name
    file_name = f"{file_prefix}_{name.lower()}.py"

    # Write the rendered content to the output file with UTF‑8 encoding
    Path(file_name).write_text(rendered, encoding="utf-8")

    # Confirm successful file creation with a green message
    typer.secho(f"Dynamic file created: {file_name}", fg="green")



def generate_static(template_name: str, output_name: str):
    """
    Generate a static file by copying content from a template without variable substitution.

    Args:
        template_name (str): Name of the Jinja2 template file (without extension)
        output_name (str): Desired output file name with extension
    """
    # Construct the full path to the template file
    template_path = Path(__file__).parent / "templates" / f"{template_name}.jinja2"

    # Check if the template file exists
    if not template_path.exists():
        typer.secho(f"Template {template_name} not found", fg="red")
        return

    # Read the raw template content
    content = template_path.read_text(encoding="utf-8")

    # Write the raw content to the output file with UTF‑8 encoding
    Path(output_name).write_text(content, encoding="utf-8")

    # Confirm successful file creation with a cyan message
    typer.secho(f"Static module created: {output_name}", fg="cyan")


@app.callback(invoke_without_command=True)
def main(
    service: Annotated[Optional[str], typer.Option("--service", help="Create a model service file")] = None,
    router: Annotated[Optional[str], typer.Option("--router", help="Create a model router file")] = None,
    auth_service: Annotated[bool, typer.Option("--auth-service", help="Create an authentication service file")] = False,
    auth_core: Annotated[bool, typer.Option("--auth-core", help="Create JWT utilities and Auth Core files")] = False,
    auth_router: Annotated[bool, typer.Option("--auth-router", help="Create authentication routing file")] = False,
    user_schema: Annotated[bool, typer.Option("--user-schema", help="Create base user schema")] = False,
    user_dto: Annotated[bool, typer.Option("--user-dto", help="Create base dto for user schema")] = False,
    utils: Annotated[bool, typer.Option("--utils", help="Create a custom response funcion")] = False,
    core: Annotated[bool, typer.Option("--core", help="Make base core settings")] = False,
):
    """
    Main CLI application callback function.

    This function serves as the entry point for the CLI tool. It processes command‑line
    arguments and generates appropriate files based on the provided flags.

    Available options:
        --service: Generate a dynamic service file for a specified model
        --router: Generate a dynamic router file for a specified model
        --auth-service: Generate a static authentication service file
        --auth-core: Generate static JWT utilities and Auth Core file
        --auth-router: Generate a static authentication routing file
        --user-schema: Generate a base user schema
        --user-dto: Generate a base dto for user schema
        --core: Generate a base core settings

    If no arguments are provided, it displays usage instructions.
    """
    
    if core:
        generate_core_files()
    
    # Generate dynamic files based on model names
    if service:
        generate_dynamic(service, "service", "service")
    if router:
        generate_dynamic(router, "router", "router")

    # Generate static authentication‑related files
    if auth_service:
        generate_static("auth_service", "auth_service.py")
    if auth_core:
        generate_static("core_auth", "auth_core.py")
    if auth_router:
        generate_static("auth_router", "auth_router.py")
    if user_schema:
        generate_static("user_schema", "user_schema.py")
    if user_dto:
        generate_static("user_dto", "user_dto.py")
    if utils:
        generate_static("utils", "utils.py")

    # If no flags were provided, show usage instructions
    if not any([service, router, auth_service, auth_core, auth_router]):
        typer.echo("Use flags: --service, --router, --auth-service, --auth-core, --auth-router, --user-schema, --user-dto, --utils. For help, use: --help")

if __name__ == "__main__":
    # Run the Typer application when the script is executed directly
    app()
