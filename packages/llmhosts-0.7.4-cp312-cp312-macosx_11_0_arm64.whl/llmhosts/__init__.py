"""LLMHosts -- Your Personal AI Cloud."""

__version__ = "0.7.4"
