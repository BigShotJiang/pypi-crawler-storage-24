from datetime import datetime, timedelta
from solarradiation import Solar, panel_or

panel_1 = Solar(latitude = 56.17, longitude = 37.94, betta = 30, gamma=0, S = 1)
date = '2025-05-09'
print(f'Lw={panel_1.Lw}°; Le={panel_1.Le}°; Lst={panel_1.Lst}°;')
print('n=', panel_1.n(date), 'days')
print('δ=', panel_1.delta(date), '°')
print('ω=', panel_1.omega(16, date), '°')
print('ω_s=', panel_1.omega_s(date), '°')
print('cosΘ=', panel_1.cos_Teta_hour(17, date))
print('cosΘ_z=', panel_1.cos_Teta_hour_z(17, date))
print('R_b=', panel_1.R_b(17, date))
print('I_o=', panel_1.I_o(17, date, panel_or.inclinely), 'Вт*ч')
print('I_on=', panel_1.I_o(17, date, panel_or.normally), 'Вт*ч')
print('I_oz=', panel_1.I_o(17, date, panel_or.horizontally), 'Вт*ч')

for t_m in range(6 * 60, 20 * 60, 10):
    print(f' t = {t_m / 60:0.2f}ч. '
          f'cosΘ={panel_1.cos_Teta_hour(t_m / 60, "2025-04-03"):0.6f} '
          f'I_o= {panel_1.I_o(t_m / 60, "2025-04-03", panel_or.inclinely):0.2f} '
          f'Q_o = {panel_1.I_o(t_m / 60, "2025-04-03") * 3600:0.0f} Дж ')

#print(panel_1.I_o_per_period('2025-06-02', 10))

date = datetime(2025,1,1,0,0,0)
dtau = timedelta(weeks=1)
print(date.date())

for week in range(48):
    str_date = str(date.date())
    print(f' t = {str_date} ω_s = {panel_1.omega_s(str_date)}  Q_o = {sum(panel_1.I_o_per_period(str_date,7)):0.0f} Дж')
    date = date + dtau


