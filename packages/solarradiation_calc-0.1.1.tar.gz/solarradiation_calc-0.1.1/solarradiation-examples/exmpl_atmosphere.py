from datetime import datetime, timedelta
import random
from solarradiation import AtmosphereI, climate_type

panel_2 = AtmosphereI(latitude = 56.17, longitude = 37.94, betta = 30, gamma=0, S = 1, altitude=134)

date = '2025-05-09'
print('cosΘ =', panel_2.cos_Teta_hour(17, date))
print('τ_αλ =', panel_2.tau_al(17, date, β_t=0.35, lam=0.55, h_altitude=134, α=1.3))
print('τ_b =', panel_2.tau_b(13, date, 134, climate_type.temp_w))
print('I_bz =', panel_2.I_bz(13, date, 134, climate_type.temp_w), 'Вт*ч')
print('τ_d =', panel_2.tau_d(13, date, 134, climate_type.temp_w))
print('I_d =', panel_2.I_d(13, date, 134, climate_type.temp_w), 'Вт*ч')

K_T = random.random()
print('K_T =', K_T)
print('Hd_per_Ho =', panel_2.Hd_per_H(date, K_T))
print('r_d =', panel_2.r_d(13, date))
print('I_d_today =', panel_2.I_d_today(13, date), 'Вт*ч')
print('I_T =', panel_2.I_T(13, date, climate_type.temp_w, rho_g=0.6), 'Вт*ч')

#пример динамической модели
format_data = '%Y-%m-%d %H:%M:%S'
tau     = datetime.strptime('2024-04-07 01:00:00', format_data)
tau_end = datetime.strptime('2024-08-01 01:00:00', format_data)

d_minutes = 10#шаг моделирования
d_delta = timedelta(minutes=d_minutes)

while tau < tau_end:
    #смена климата: с мая по август летний умеренный климат иначе зимний умеренный
    if 5 <= tau.month and tau.month <= 8:
        climate = climate_type.temp_s
    else:
        climate = climate_type.temp_w
    tau = tau + d_delta
    #смена климата: конец

    I_T = panel_2.I_T(tau.hour + tau.minute/60, str(tau.date()), climate=climate, rho_g=0.6)
    Q_T = I_T * d_minutes / 60
    print(f'{tau.date()} {tau.time()} I_T = {I_T:0.2f} Вт*ч Q_T = {Q_T:0.2f} Дж')




