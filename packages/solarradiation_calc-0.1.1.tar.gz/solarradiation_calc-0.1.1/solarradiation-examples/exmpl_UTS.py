from datetime import datetime, timedelta
import random

from solarradiation import Solar, panel_or
from solarradiation import AtmosphereI, climate_type

panel_1 = Solar(latitude = 56.17, longitude = 37.94, betta = 30, gamma=0, S = 1, UTS=+3)
date = '2026-05-09'
print(f'Lw={panel_1.Lw}°; Le={panel_1.Le}°; Lst={panel_1.Lst}°;')
print('n=', panel_1.n(date), 'days')
print('δ=', panel_1.delta(date), '°')
print('ω=', panel_1.omega(16, date), '°')
print('ω_s=', panel_1.omega_s(date), '°')
print('cosΘ=', panel_1.cos_Teta_hour(17, date))
print('cosΘ_z=', panel_1.cos_Teta_hour_z(17, date))
print('R_b=', panel_1.R_b(17, date))
print('I_o=', panel_1.I_o(17, date, panel_or.inclinely), 'Вт*ч')
print('I_on=', panel_1.I_o(17, date, panel_or.normally), 'Вт*ч')
print('I_oz=', panel_1.I_o(17, date, panel_or.horizontally), 'Вт*ч')



panel_2 = AtmosphereI(latitude = 56.17, longitude = 37.94, betta = 30, gamma=0, S = 1, altitude=134, UTS="4:30")

date = '2026-05-09'
print('cosΘ =', panel_2.cos_Teta_hour(17, date))
print('τ_αλ =', panel_2.tau_al(17, date, β_t=0.35, lam=0.55, h_altitude=134, α=1.3))
print('τ_b =', panel_2.tau_b(13, date, 134, climate_type.temp_w))
print('I_bz =', panel_2.I_bz(13, date, 134, climate_type.temp_w), 'Вт*ч')
print('τ_d =', panel_2.tau_d(13, date, 134, climate_type.temp_w))
print('I_d =', panel_2.I_d(13, date, 134, climate_type.temp_w), 'Вт*ч')

K_T = random.random()
print('K_T =', K_T)
print('Hd_per_Ho =', panel_2.Hd_per_H(date, K_T))
print('r_d =', panel_2.r_d(13, date))
print('I_d_today =', panel_2.I_d_today(13, date), 'Вт*ч')
print('I_T =', panel_2.I_T(13, date, climate_type.temp_w, rho_g=0.6), 'Вт*ч')