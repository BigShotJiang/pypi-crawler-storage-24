import logging
from math import sin, cos, pi, tan, radians, degrees, acos, exp
import datetime
from enum import Enum


# Convert degrees-minutes-seconds to decimal degrees
def gradus(degrees: float, minutes: float, seconds: float):
    '''
    Converts degrees from format:
    <degrees°minutes'seconds"> to decimal degrees.
    :param degrees:float: ° - degrees;
    :param minutes:float: ' - minutes;
    :param seconds:float: " - seconds.
    :return:float: ° - decimal degrees.
    '''
    return degrees + minutes / 60 + seconds / 3600


def desgrads(s_degrees: str):
    '''
    Converts degrees from format:
    "degrees°minutes'seconds"" to decimal degrees.
    :param s_degrees:str - string format like "degrees°minutes'seconds""
    :return:float: ° - decimal degrees.
    '''
    str1 = s_degrees.split('°')
    degrees = float(str1[0])
    str2 = str1[1].split('′')
    minutes = float(str2[0])
    seconds = float(str2[1].replace('″', ''))
    return degrees + minutes / 60 + seconds / 3600


class panel_or(Enum):
    '''
    Orientation of the solar panel in space.
    '''
    normally = 1
    horizontally = 2
    inclinely = 3


# Расчет тепла получаемого от солнца
class Solar:

    # Конструктор
    def __init__(self,
                 latitude: float = 56.17,
                 longitude: float = 37.94,
                 betta: float = 30.,
                 gamma: float = 0.,
                 S: float = 1.,
                 UTS: float|str|None = None,
                 G_sc: float = 1353):
        '''
        Class constructor with default parameters.
        :latitude:float, φ ° - latitude [-90; 90]°;
        :longitude:float, ψ ° - western longitude (0;-180) - negative values,
        eastern longitude [0;180] - positive values. Can also be set
        as (180;360], which will be recalculated to western longitude (psi-360);
        :betta:float, β ° - surface tilt angle relative to the horizon;
        :gamma:float, γ ° - horizontal orientation, γ = 0° -
        direction exactly south, (0; 180)° - direction west,
        (-180; 0)° - direction east, γ = 180° - direction
        exactly north. In other words - this is (azimuth-180°). For northern
        hemisphere, values can be (90; 90)°.
        :S:float, m² - surface area of the panel;
        :UTS: float|str|None - часы, Coordinated Universal Time. If a value is
        provided, class functions will calculate time based on UTS.
        For example: float value for Venezuela - UTS = 4.5 or string
        format:"HH:MM" UTS = "4:30". If not provided, functions will perform
        calculations based on astronomical time;
        :G_sc:float, W * m⁻² - solar constant.
        '''
        self.phi = latitude  # широта;
        if -180 <= longitude and longitude <= 180:
            self.psi = longitude  # долгота;
        elif 180 < longitude and longitude <= 360:
            self.psi = longitude - 360  # долгота;
        else:
            logging.error('Error in Solar class constructor! Incorrect longitude specified.')
        self.betta = betta  # surface tilt angle relative to horizon
        self.gamma = gamma  # horizontal orientation (azimuth)
        self.S = S  # surface area of the panel

        if UTS:
            _uts = UTS
            if type(UTS) is str:
                _uts = UTS.split(':')
                _uts = float(_uts[0]) + float(_uts[1]) / 60

            self.L_w_UTS = _uts * 15.0
            # western UTS longitude [0; 360]
            if self.L_w_UTS > 0:
                self.L_w_UTS = 360 - self.L_w_UTS
            elif self.L_w_UTS <= 0:
                self.L_w_UTS = - self.L_w_UTS
        else:
            self.L_w_UTS = None

        # Solar constant
        self.G_sc = G_sc  # W * m⁻² - solar constant

        # L_w, ° - western longitude [0; 360]
        if self.psi > 0:
            self.L_w = 360 - longitude
        elif self.psi <= 0:
            self.L_w = -longitude

        # L_e, ° - eastern longitude [0; 360]
        if self.psi >= 0:
            self.L_e = longitude
        elif self.psi < 0:
            self.L_e = 180 - longitude

        # L_st, ° - local standard meridian. Local standard meridians are taken
        # as meridians from 0 to 360° west longitude with a step of 15°
        ts = self.L_w // 15
        ost = self.L_w % 15
        if ost > 7.5:
            self.L_st = (ts + 1) * 15
        else:
            self.L_st = ts * 15
        # [Дуников p. 60]
        self._φ = pi * self.phi / 180
        self._β = pi * self.betta / 180
        self._γ = pi * self.gamma / 180
        self._A = sin(self._φ) * cos(self._β)
        self._B = cos(self._φ) * sin(self._β) * cos(self._γ)
        self._C = sin(self._β) * sin(self._γ)
        self._D = cos(self._φ) * cos(self._β)
        self._E = sin(self._φ) * sin(self._β) * cos(self._γ)

    @property
    def Lw(self):
        '''L_w:float, ° - western longitude [0; 360]'''
        return self.L_w

    @property
    def Le(self):
        '''L_e:float, ° - eastern longitude [0; 360]'''
        return self.L_e

    @property
    def Lst(self):
        '''L_st:float, ° - local standard meridian. Local standard meridians
        are taken as meridians from 0 to 360° west longitude with a step of 15°'''
        return self.L_st

    def n(self, date: str):
        '''
        n:int, day -- number of days since the beginning of the year.

        Input parameters:
        :date:str, "YYYY-MM-DD" - date
        '''
        a = date.split('-')
        d0 = datetime.date(int(a[0]), 1, 1)
        d1 = datetime.date(int(a[0]), int(a[1]), int(a[2]))
        delta_d = d1 - d0
        n = delta_d.days  # number of days since the beginning of the year
        return n

    def delta(self, date: str):
        '''
        delta, ° -- declination angle. Declination is the angular distance on
        the celestial sphere from the plane of the celestial equator to a celestial body,
        positive for the northern hemisphere and negative for the southern.
        Takes values [-90; 90].

        Input parameters:
        :date:str, "YYYY-MM-DD" - date
        '''
        n = self.n(date)  # number of days since the beginning of the year
        δ = 23.45 * sin((2 * pi * (284 + n) / 365))
        return δ

    def omega(self, τ_н: float, date: str):
        '''ω, ° -- hour angle, taking into account corrections for the ellipticity of the orbit and
        the longitude of the observer's location.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0; -24];
        :date:str, "YYYY-MM-DD" - date
        '''
        n = self.n(date)  # number of days since the beginning of the year
        # [ВИЭ p. 55 formula 2.20][Даффи 1.5 Definition formula 1.2 p. 29]
        B = 2 * pi * (n - 1) / 365  # rad, must be in radians

        # [ВИЭ p. 55 formula 2.20(incorrect formula!!!)] original formula from [Duffie 1.5 Definitions 11 formula 1.5.3 p. 33]
        # [Даффи 1.5 Definition formula 1.5 p. 31]
        # below - this is the equation of time in minutes
        E = 229.2 * (0.000075 + 0.001868 * cos(B) - 0.032077 * sin(B) - 0.014615 * cos(2 * B) - 0.04089 * sin(2 * B))

        if self.L_w_UTS:
            # [ВИЭ p. 55 formula 2.21]
            Δ = (4 * (self.L_st - self.L_w_UTS) + E) / 60  # hour
        else:
            # [Duffie 1.5 Definitions 11 formula 1.5.2 p. 33]
            # correction in minutes converted to hours. Where 4°/min is the Earth's rotation speed.
            Δ = (4 * (self.L_st - self.L_w) + E) / 60  # hour

        # ° [ВИЭ p. 56 (equation is incorrect)], correct in
        # [Duffie 1.5 Definitions 11 Example 1.5.1 p. 33; 1.6 Direction of Beam Radiation 13 Definition: ω Hour angle]
        # Hour angle in °:
        omega = 15 * (τ_н - 12 + Δ)  # °
        return omega

    def omega_s(self, date: str):
        '''
        ω_s:float, ° -- sunset angle. The angle is measured from the meridian,
        small angles correspond to the winter season [0; 180].

        Input parameters:
        :date:str, "YYYY-MM-DD" - date
        '''
        δ = self.delta(date)  # declination angle, °
        ω_s = degrees(acos(-tan(radians(self.phi) * tan(radians(δ)))))  # , °
        return ω_s

    def cos_Teta_hour(self, τ_н: float, date: str):
        '''
        cosΘ:float, fraction, zenith angle - angle of incidence of solar rays, average over
        a period of 1 hour.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date
        '''
        # °, - Hour angle corrected for orbital ellipticity:
        omega = self.omega(τ_н, date)  # °
        delta = self.delta(date)  # °, - declination angle
        # Coefficients
        δ = pi * delta / 180
        ω = pi * omega / 180
        # [Мотулевич][ВИЭ p. 60]
        cosΘ = (self._A - self._B) * sin(δ) + (self._C * sin(ω) + (self._D + self._E) * cos(ω)) * cos(δ)
        return cosΘ

    def cos_Teta_hour_z(self, τ_н: float, date: str):
        '''
        cosΘ_z:float, fraction, zenith angle - angle of incidence of solar rays, average over
        a period of 1 hour on a horizontal surface.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date
        '''
        # °, - Hour angle corrected for orbital ellipticity:
        omega = self.omega(τ_н, date)  # °
        delta = self.delta(date)  # °, - declination angle
        # Coefficients
        δ = pi * delta / 180
        ω = pi * omega / 180
        cosΘ_z = cos(self._φ) * cos(δ) * cos(ω) + sin(self._φ) * sin(δ)
        return cosΘ_z

    def R_b(self, τ_н: float, date: str):
        '''
        R_b:float, fraction, - geometric factor, ratio of direct radiation energy
        incident on a tilted surface to that on a horizontal surface over
        a one-hour period.
        [ВИЭ p. 61][Duffie 24 Solar Radiation p. 24][Даффи Chapter 1 formula 1.24 p. 44]

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date
        '''
        # °, - Hour angle corrected for orbital ellipticity:
        omega = self.omega(τ_н, date)  # °
        delta = self.delta(date)  # °, - declination angle
        # Coefficients
        δ = pi * delta / 180
        ω = pi * omega / 180
        cosΘ = (self._A - self._B) * sin(δ) + (self._C * sin(ω) + (self._D + self._E) * cos(ω)) * cos(δ)

        # For horizontal surface β = 0
        cosΘ_z = cos(self._φ) * cos(δ) * cos(ω) + sin(self._φ) * sin(δ)
        rb = cosΘ / cosΘ_z
        if cosΘ <= 0 or cosΘ_z <= 0:  # if negative or greater than one, set to zero because the sun is below the horizon
            rb = 0
        return rb

    def I_o(self, τ_н, date: str, orientation: panel_or = panel_or.inclinely):
        '''
        I_o:float, W * h, - Returns the amount of energy received
        from extraterrestrial solar radiation on a surface over 1 hour.

        Input parameters:
        :start_date:str, "YYYY-MM-DD" - start date of the period;
        :days:int, dd - number of days from the start of the period;
        :orientation:panel_or = panel_or.inclinely,
        panel orientation can be:
        normally - perpendicular to the sun's rays,
        horizontally - horizontal,
        inclinely - tilted.
        '''
        n = self.n(date)  # number of days since the beginning of the year
        # Amount of thermal radiant solar energy [Даффи Chapter 1. Formula 1.29 p. 57]
        I_on = self.G_sc * (1 + 0.033 * cos(2 * pi * n / 365)) * self.S  # W * h

        if orientation == panel_or.normally:  # I_on
            I_o = I_on
        elif orientation == panel_or.inclinely:  # I_o
            # Amount of thermal radiant solar energy [Даффи Chapter 1. Formula 1.29 p. 57]
            I_o = I_on * self.cos_Teta_hour(τ_н, date)  # W * h
        elif orientation == panel_or.horizontally:  # I_oz
            # Amount of thermal radiant solar energy [Даффи Chapter 1. Formula 1.30 p. 58]
            I_o = I_on * self.cos_Teta_hour_z(τ_н, date)  # W * h

        if I_o < 0:
            I_o = 0  # if negative, set to zero because the sun is below the horizon
        return I_o

    def I_o_per_period(self, start_date: str, days: int = 1, orientation: panel_or = panel_or.inclinely):
        '''
        Returns an array (list) with the hourly amount of energy received from
        the sun on the panel surface over a specified number of days, W * h.

        Input parameters:
        :start_date:str, "YYYY-MM-DD" - start date of the period;
        :days:int, dd - number of days from the start of the period;
        :orientation:panel_or = panel_or.inclinely,
        can be:
        normally - perpendicular to the sun's rays,
        horizontally - horizontal,
        inclinely - tilted.
        :return: Returns [I_o1, I_o2, ...] with the hourly amount of energy
        received from the sun on the panel surface over a specified number of
        days, W * h.
        '''
        I_h_period = []
        sdate = start_date.split('-')
        date = datetime.date(int(sdate[0]), int(sdate[1]), int(sdate[2]))
        dhour = datetime.timedelta(hours=1)
        dday = datetime.timedelta(days=1)

        for j in range(days):
            for hour in range(24):
                # data_hour = str(date + dth)
                I_h = self.I_o(hour, str(date), orientation)
                I_h_period.append(I_h)
                # print(f'Date: {date} hour: {hour} Output: {I_h:0.2f}')
                date = date + dhour
            date = date + dday
        return I_h_period

    def I_T_by_data(self, τ_н: float, date: str, I_bz, I_dz, rho_g=0.6):
        '''
        Returns the sum of total solar radiation on a tilted surface over 1 hour.
        The sum includes direct radiation considering atmospheric transmittance (transparency) on the tilted surface;
        diffuse radiation on the horizontal surface; diffuse reflection for total solar radiation.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0; -24];
        :date:str, "YYYY-MM-DD" - date;
        :param I_bz:float - W * h, direct radiation on the tilted surface
        considering atmospheric transparency;
        :param I_dz:float - W * h, diffuse radiation on the horizontal surface;
        :param rho_g: - coefficient of diffuse reflection [0; 1]
        :return: I_T:float, W * h - Returns the sum of total solar radiation
        on a tilted surface over 1 hour.
        '''
        R_b = self.R_b(τ_н, date)
        I_z = I_bz + I_dz
        I_T = I_bz * R_b + I_dz * (1 + cos(self._β)) / 2 + I_z * rho_g * (1 - cos(self._β)) / 2
        return I_T



