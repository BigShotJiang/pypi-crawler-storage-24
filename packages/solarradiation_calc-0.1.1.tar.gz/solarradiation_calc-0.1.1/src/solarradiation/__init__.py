from .Solar import gradus
from .Solar import desgrads
from .Solar import panel_or
from .Solar import Solar

from .Atmosphere import climate_type
from .Atmosphere import AtmosphereI

"""
SolarRadiation Package

A comprehensive Python package for calculating solar radiation on tilted surfaces 
with atmospheric effects modeling.

This package provides tools for:
1. Basic astronomical solar geometry calculations (extraterrestrial radiation)
2. Atmospheric effects modeling for clear sky conditions
3. Climate-specific transmittance calculations

MAIN CLASSES:
-----------
1. Solar:
   Calculates extraterrestrial solar radiation without atmospheric effects.
   Handles solar geometry: declination, hour angle, zenith angles, and geometric factors.

   Key methods:
   - gradus(), desgrads() - coordinate conversion utilities
   - delta() - solar declination angle
   - cos_Teta_hour() - zenith angle of incidence
   - omega() - hour angle with orbital ellipticity correction
   - I_o() - extraterrestrial radiation
   - R_b() - geometric factor for tilted surfaces

2. AtmosphereI (inherits from Solar):
   Models solar radiation with atmospheric effects using clear sky model.
   Includes direct and diffuse radiation components with climate-specific transmittance.

   Key methods:
   - I_bz() - direct radiation with atmospheric transmittance
   - I_d() - diffuse radiation on horizontal surface
   - I_T() - total radiation on tilted surface (sum of direct, diffuse, and reflected)
   - tau_b(), tau_d() - atmospheric transmittance coefficients
   - climate_type enum for different climate models

ENUMS:
-----
- panel_or: Panel orientation (normally, horizontally, inclinely)
- climate_type: Climate models (trop, temp_s, temp_w, subar_s)
"""




