from math import sin, cos, pi, degrees, acos, exp
from datetime import datetime, timedelta
import random
from enum import Enum
from solarradiation import Solar, panel_or

class climate_type(Enum):
    '''
    Coefficients for the equation for calculating the atmospheric transmittance coefficient
    (atmospheric transparency coefficient) for direct radiation.
    [Hoyt]
    [Duffie 2.8 Solar Radiation p. 68 eq. 2.8.1a]
    [Даффи 2.8 Definition formula 2.5a p. 93]
    '''
    trop = {'r_0': 0.95, 'r_1': 0.98, 'r_k': 1.02, 'Climate': 'Tropical'}
    temp_s = {'r_0': 0.97, 'r_1': 0.99, 'r_k': 1.02, 'Climate': 'Temperate climate, summer'}
    subar_s = {'r_0': 0.99, 'r_1': 0.99, 'r_k': 1.01, 'Climate': 'Subarctic climate, summer'}
    temp_w = {'r_0': 1.03, 'r_1': 1.01, 'r_k': 1.00, 'Climate': 'Temperate climate, winter'}

class AtmosphereI(Solar):
    '''
    Class for calculating the hourly amount of thermal energy transferred
    by solar radiation to a tilted surface, for any azimuth, taking into account
    atmospheric phenomena.
    '''

    def __init__(self,
                 latitude: float = 56.17,
                 longitude: float = 37.94,
                 betta: float = 30.,
                 gamma: float = 0.,
                 S: float = 1.,
                 altitude: float = 134.,
                 UTS: float | str | None = None,
                 G_sc: float = 1353):
        '''
        Class constructor with default parameters.
        :latitude:float, φ ° - latitude [-90; 90]°;
        :longitude:float, ψ ° - western longitude (0;-180) - negative values,
        eastern longitude [0;180] - positive values. Can also be set
        as (180;360], which will be recalculated to western longitude (psi-360);
        :betta:float, β ° - surface tilt angle relative to the horizon;
        :gamma:float, γ ° - horizontal orientation, γ = 0° -
        direction exactly south, (0; 180)° - direction west,
        (-180; 0)° - direction east, γ = 180° - direction
        exactly north. In other words - this is (azimuth-180°). For the northern
        hemisphere, values can be (90; 90)°.
        :S:float, m² - surface area of the panel;
        :param altitude: m, - altitude above sea level;
        :UTS: float|str|None - часы, Coordinated Universal Time. If a value is
        provided, class functions will calculate time based on UTS.
        For example: float value for Venezuela - UTS = 4.5 or string
        format:"HH:MM" UTS = "4:30". If not provided, functions will perform
        calculations based on astronomical time;
        :G_sc:float, W * m⁻² - solar constant.
        '''
        super().__init__(latitude, longitude, betta, gamma, S, UTS, G_sc)  # parent class constructor
        self.altitude = altitude
        self.Hdz_data = {'date': '0000-00-00'}  # for storing coefficients for diffuse solar radiation

    def tau_al(self, τ_н: float, date: str, β_t: float, lam: float = 0.55, h_altitude: float = 134, α: float = 1.3):
        '''
        τ_αλ, fraction - light transmittance coefficient through the atmosphere - coefficient
        accounting for scattering on liquid droplets and dust particles, as well as
        the path length of rays through the atmosphere. Calculation is based on the
        Ångström turbidity equation.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date
        :β_t:float - Ångström turbidity coefficient
        also known as the Ångström parameter or Ångström selectivity exponent
        - varies in the range from 0 in very clear air to 0.4 in
        very turbid air;
        :lam:float = 0.55, #μm, wavelength of the middle of the solar spectrum [0.4; 0.7];
        :h_altitude:float = 134, m - altitude above sea level;
        α:float = 1.3  # depends on the size distribution of dust particles.
        Usually an exponent of 1.3 is used.
        '''
        # ray incidence on a horizontal surface
        cosΘ_z = self.cos_Teta_hour_z(τ_н, date)
        Θ_z = degrees(acos(cosΘ_z))  # °, in degrees
        # rad, - solar altitude angle - angle of ray incidence relative to the horizon
        alfa = 90 - abs(Θ_z)
        if Θ_z > 89:
            m = exp(-0.0001184 * h_altitude) / (cosΘ_z + 0.5057 * pow(96.08 - Θ_z, -1.634))
        else:
            m = 1 / cosΘ_z
        # Common exponent for all wavelengths
        α = 1.3  # depends on the size distribution of dust particles. Usually an exponent of 1.3 is used.
        λ = lam  # μm, wavelength of the middle of the solar spectrum

        # Light transmittance coefficient for the atmosphere can be written as
        # [Duffie p. 60 formula 2.6.1.][Даффи 2.6 Definition formula 2.1 p. 84][Дуников formula 2.43]
        τ_αλ = exp(- β_t * pow(λ, -α) * m)
        return τ_αλ

    def tau_b(self, τ_н: float, date: str, altitude: float = None, climate: climate_type = climate_type.temp_w):
        '''
        Calculates the atmospheric transmittance coefficient (atmospheric transparency coefficient)
        for direct radiation.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24);
        :date:str, "YYYY-MM-DD" - date;
        :param altitude: m, - altitude above sea level;
        :param climate:climate_type: - climate type;
        :return: fraction, - atmospheric transmittance coefficient (atmospheric transparency coefficient)
        for direct radiation.
        '''
        if altitude != None:
            _A = altitude / 1000
        else:
            _A = self.altitude / 1000
        a_0st = 0.4237 - 0.00821 * pow(6 - _A, 2)
        a_1st = 0.5055 - 0.00595 * pow(6.5 - _A, 2)
        k_st = 0.2711 - 0.01858 * pow(2.5 - _A, 2)

        # [Hoyt]
        r_0 = climate.value['r_0']
        r_1 = climate.value['r_1']
        r_k = climate.value['r_k']
        a_0 = r_0 * a_0st
        a_1 = r_1 * a_1st
        k = r_k * k_st

        cosΘ_z = self.cos_Teta_hour_z(τ_н, date)
        # [Duffie 2.8 Solar Radiation p. 68 eq. 2.8.1a][Даффи 2.8 Definition formula 2.5a p. 93]
        if cosΘ_z > 0:
            τ_b = a_0 + a_1 * exp(-k / cosΘ_z)
        else:
            τ_b = 0.0
        return τ_b

    def I_bz(self, τ_н: float, date: str, altitude: float = None, climate: climate_type = climate_type.temp_w):
        '''
        Returns the amount of energy received from solar radiation, taking into account
        atmospheric transmittance (transparency) for direct radiation on a horizontal
        surface over 1 hour.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date;
        :param altitude: m, - altitude above sea level;
        :param climate:climate_type: - climate type;
        :return: I_bR_b:float, W * h - Returns the amount of energy
        received from solar radiation, taking into account the atmospheric transmittance coefficient
        (atmospheric transparency coefficient) for direct radiation on a
        horizontal surface over 1 hour.
        '''
        if altitude == None:
            _altitude = self.altitude
        else:
            _altitude = altitude
        I_oz = self.I_o(τ_н, date, panel_or.horizontally)  # extraterrestrial radiation on a horizontal surface
        τ_b = self.tau_b(τ_н, date, altitude=_altitude, climate=climate)
        I_bz = I_oz * τ_b
        return I_bz

    def tau_d(self, τ_н: float, date: str, altitude: float = None, climate: climate_type = climate_type.temp_w):
        '''
        Calculates the atmospheric transmittance coefficient (atmospheric transparency coefficient)
        for direct radiation. τ_d = I_d / I_o

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date;
        :param altitude: m, - altitude above sea level;
        :param climate:climate_type: - climate type;
        :return: fraction, - atmospheric transmittance coefficient (atmospheric transparency coefficient)
        for direct radiation.
        '''
        if altitude == None:
            _altitude = self.altitude
        else:
            _altitude = altitude
        τ_b = self.tau_b(τ_н=τ_н, date=date, altitude=_altitude, climate=climate)

        # [Duffie 2.8 Estimation of Clear-Sky Radiation p. 69 eq. 2.8.5]
        # [Даффи Section 2.8 formula 2.9 p. 95]
        τ_d = 0.271 - 0.294 * τ_b
        return τ_d

    def I_d(self, τ_н: float, date: str, altitude: float = None, climate: climate_type = climate_type.temp_w):
        '''
        Returns the amount of diffuse solar energy on a horizontal
        surface over 1 hour.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date;
        :param altitude: m, - altitude above sea level;
        :param climate:climate_type: - climate type;
        :return: I_d:float, W * h - Returns the amount of diffuse
        solar energy on a horizontal surface over 1 hour.
        '''
        if altitude == None:
            _altitude = self.altitude
        else:
            _altitude = altitude
        I_oz = self.I_o(τ_н, date, panel_or.horizontally)  # extraterrestrial radiation on a tilted surface
        τ_d = self.tau_d(τ_н, date, altitude=_altitude, climate=climate)
        I_d = I_oz * τ_d
        return I_d

    def Hd_per_H(self, date, K_T):
        '''
        Hd_p_H, fraction of diffuse radiation according to the Liu and Jordan method
        [ВИЭ] for the period from May to August; for other months according to
        the Holland and Orgill method [Motulevich].
        Hd_per_H = H_dz / H_oz

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date;
        K_T, fraction [0, 1] - daily atmospheric transparency coefficient
        ([Duffie] daily clearness index), equal to the ratio of the daily
        sum of radiation incident on a horizontal surface on a given day to the daily sum of extraterrestrial radiation.
        :return:float - Hd_p_H, fraction of diffuse radiation.
        '''
        Hd_p_H = 0
        # according to the Liu and Jordan method [ВИЭ p. 78].
        # Applicable for the period from May to August.
        # if 5 <= int(date[5:7]) and int(date[5:7]) <= 8:

        if (self.omega_s(date) <= 81.4):  # for sunset angle ω_s < 81.4°
            # [Duffie chapter 2 p. 104 formula 2.17a]
            if (K_T >= 0.715):
                Hd_p_H = 0.143
            else:
                Hd_p_H = 1 - 0.2727 * K_T + 2.4495 * K_T ** 2 - 11.9514 * K_T ** 3 + 9.3879 * K_T ** 4
        else:
            # [Duffie chapter 2 p. 104 formula 2.17b]
            if (K_T >= 0.722):
                Hd_p_H = 0.175
            else:
                Hd_p_H = 1 + 0.2832 * K_T - 2.5557 * K_T ** 2 + 0.8448 * K_T ** 3

        # for other months according to the Holland and Orgill method [Motulevich p. 6.]
        # Applicable for the period from September to April.
        # else:
        #     if 0 <= K_T and K_T <= 0.35:
        #         Hd_p_H = 1 - 0.249 * K_T
        #     elif 0.35 < K_T and K_T < 0.75:
        #         Hd_p_H = 1.557 - 1.84 * K_T
        #     elif 0.75 <= K_T and K_T <= 1:
        #         Hd_p_H = 0.177
        return Hd_p_H

    def r_d(self, τ_н: float, date: str):
        '''
        Ratio of the hourly sum of diffuse radiation to the daily sum of diffuse
        radiation as a function of time and day length.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0; -24];
        :date:str, "YYYY-MM-DD" - date
        :return:float - r_d = I_dz / H_dz
        '''
        # °, - Hour angle corrected for orbital ellipticity:
        omega = self.omega(τ_н, date)  # °
        omega_s = self.omega_s(date)  # ° -- sunset angle
        ω = pi * omega / 180
        ω_s = pi * omega_s / 180
        cosω_s = cos(ω_s)
        # [Даффи 2.13 Definition formula 2.22 p. 110]
        r_d = pi / 24 * (cos(ω) - cosω_s) / (sin(ω_s) - pi * ω_s / 180 * cosω_s)
        return r_d

    def I_d_today(self, τ_н: float, date: str):
        '''
        Returns the amount of diffuse solar energy on a horizontal
        surface over 1 hour. K_T - is randomly set from 0 to 1 for
        generating distribution values.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0-24];
        :date:str, "YYYY-MM-DD" - date;
        :return: I_d:float, W * h - Returns the amount of diffuse
        solar energy on a horizontal surface over 1 hour.
        '''
        if self.Hdz_data['date'] != date:  # need to generate data for the current day
            # Extraterrestrial radiation on a horizontal surface during the day
            H_oz = sum(self.I_o_per_period(date, 1, panel_or.horizontally))
            # Random from 0 to 1
            K_T = random.random()
            Hd_per_H = self.Hd_per_H(date, K_T)
            self.Hdz_data = {'date': date,
                             'H_oz': H_oz,
                             'K_T': K_T,
                             'Hd_per_H': Hd_per_H, }
        r_d = self.r_d(τ_н, date)
        if r_d < 0:
            r_d = 0
        H_dz = self.Hdz_data['H_oz'] * self.Hdz_data['Hd_per_H']
        I_dz = H_dz * r_d
        return I_dz

    def I_T(self, τ_н: float, date: str, climate: climate_type = climate_type.temp_w, rho_g=0.6):
        '''
        Returns the sum of total solar radiation on a tilted
        surface over 1 hour. The sum includes direct radiation
        taking into account atmospheric transmittance (transparency) on the tilted surface;
        scattered radiation on the horizontal surface; diffuse
        reflection for total solar radiation.

        Input parameters:
        :τ_н:float, h - hour from the start of the day [0; -24];
        :date:str, "YYYY-MM-DD" - date;
        :param climate:climate_type: - climate type;
        :param rho_g: - coefficient of diffuse reflection [0; 1]
        :return: I_T:float, W * h - Returns the sum of total solar
        radiation on a tilted surface over 1 hour.
        '''
        # direct radiation on the tilted surface taking into account atmospheric transparency
        I_bz = self.I_bz(τ_н, date, climate=climate)
        R_b = self.R_b(τ_н, date)
        # diffuse radiation on the horizontal surface
        I_dz = self.I_d_today(τ_н, date)
        # radiation on the horizontal surface
        I_z = I_bz + I_dz
        I_T = I_bz * R_b + I_dz * (1 + cos(self._β)) / 2 + I_z * rho_g * (1 - cos(self._β)) / 2
        return I_T
