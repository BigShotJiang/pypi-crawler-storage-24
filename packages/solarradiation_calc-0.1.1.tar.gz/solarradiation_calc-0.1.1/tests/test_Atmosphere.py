from src.solarradiation.Atmosphere import AtmosphereI, climate_type

panel_2 = AtmosphereI(latitude = 56.17, longitude = 37.94, betta = 30, gamma=0, S = 1, altitude=134)

def test_cos_Teta_hour():
    assert f'cosΘ = {panel_2.cos_Teta_hour(17, '2025-05-09')}' == 'cosΘ = 0.4381690047990296'

def test_tau_al():
    assert f'τ_αλ = {panel_2.cos_Teta_hour(17, '2025-05-09')}' == 'τ_αλ = 0.4381690047990296'

def test_tau_b():
    assert f'τ_b = {panel_2.tau_b(13,'2025-05-09', 134, climate_type.temp_w)}' == 'τ_b = 0.3602711506795149'

def test_I_bz():
    assert f'I_bz = {panel_2.I_bz(13, '2025-05-09', 134, climate_type.temp_w)}' == 'I_bz = 367.32748640749026'

def test_tau_d():
    assert f'τ_d = {panel_2.tau_d(13, '2025-05-09', 134, climate_type.temp_w)}' == 'τ_d = 0.16508028170022265'

def test_I_d():
    assert f'I_d = {panel_2.I_d(13, '2025-05-09', 134, climate_type.temp_w)}' == 'I_d = 168.313573867937'

def test_Hd_per_H():
    assert f'Hd_per_Ho = {panel_2.Hd_per_H('2025-05-09', 0.42)}' == 'Hd_per_Ho = 0.7307080624000001'

def test_r_d():
    assert f'r_d = {panel_2.r_d(13, '2025-05-09')}' == 'r_d = 0.1765188614939998'

def test_I_d_today():
    assert panel_2.I_d_today(13, '2025-05-09') > 100

def test_I_T():
    assert panel_2.I_T(13, '2025-05-09', climate_type.temp_w, rho_g=0.6) > 200

panel_4 = AtmosphereI(latitude = 56.17, longitude = 37.94, betta = 30, gamma=0, S = 1, altitude=134, UTS="3:30")

def test_cos_Teta_hour4():
    assert f'cosΘ = {panel_4.cos_Teta_hour(17, '2025-05-09')}' == 'cosΘ = 0.22694092008322964'










