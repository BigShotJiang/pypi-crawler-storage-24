# tests/__init__.py
"""
Test suite for SolarRadiation library.

Tests verify solar geometry calculations and atmospheric models.
Run tests using: pytest tests/
"""