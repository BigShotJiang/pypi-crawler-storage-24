from setuptools import setup, find_packages

setup(
    name="solarradiation",
    version="0.1.0",  # Version of your package
    packages=find_packages(where="src"),  # Automatically find packages in the `src/` directory
    package_dir={"": "src"},  # Indicates that packages are located in `src/`

    # Optional parameters:
    author="Kurzanov S.",
    author_email="sergy84@gmail.com",
    description="A package for solar radiation calculations with atmospheric effects modeling",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://gitverse.ru/Sergei100/SolarRadiation.git",
    license="MIT",

    # Test dependencies
    extras_require={
        "dev": ["pytest>=7.0", "pytest-cov>=4.0", "black>=23.0", "flake8>=6.0"],
        "test": ["pytest>=7.0", "pytest-cov>=4.0"],
        "docs": ["sphinx>=7.0", "sphinx-rtd-theme>=1.0"],
    },

    # Dependencies (if any)
    install_requires=[
        # No external dependencies required for basic functionality
    ],

    # Classifiers (for PyPI)
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
    ],

    # Project URLs
    project_urls={
        "Homepage": "https://gitverse.ru/Sergei100/SolarRadiation.git",
        "Repository": "https://gitverse.ru/Sergei100/SolarRadiation.git",
        "Bug Tracker": "https://gitverse.ru/Sergei100/SolarRadiation/issues",
    },

    python_requires=">=3.10",  # Minimum Python version
    keywords=["solar", "radiation", "energy", "renewable", "atmosphere", "photovoltaics"],
)