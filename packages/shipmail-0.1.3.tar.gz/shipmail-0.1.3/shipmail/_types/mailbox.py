from __future__ import annotations

from typing import Literal, TypedDict

from .common import PaginationParams


class AutoReply(TypedDict):
    enabled: bool
    subject: str | None
    body: str | None
    from_date: str | None
    to_date: str | None


class Mailbox(TypedDict):
    object: Literal["mailbox"]
    id: str
    domain_id: str
    address: str
    display_name: str | None
    auto_reply: AutoReply
    created_at: str
    updated_at: str


class _CreateMailboxParamsRequired(TypedDict):
    domain_id: str
    address: str


class CreateMailboxParams(_CreateMailboxParamsRequired, total=False):
    display_name: str


class UpdateMailboxParams(TypedDict, total=False):
    display_name: str | None


class ListMailboxesParams(PaginationParams, total=False):
    domain_id: str


class _UpdateAutoReplyParamsRequired(TypedDict):
    enabled: bool


class UpdateAutoReplyParams(_UpdateAutoReplyParamsRequired, total=False):
    subject: str | None
    body: str | None
    from_date: str | None
    to_date: str | None
