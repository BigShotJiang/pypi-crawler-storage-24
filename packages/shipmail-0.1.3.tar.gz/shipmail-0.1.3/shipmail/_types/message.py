from __future__ import annotations

from typing import Literal, TypedDict, Union

from .common import EmailRecipient, EmailRecipientInput, MessageSource, MessageStatus, PaginationParams


class Message(TypedDict):
    object: Literal["message"]
    id: str
    mailbox_id: str
    thread_id: str | None
    subject: str | None
    from_address: str | None
    to_addresses: list[EmailRecipient] | None
    cc_addresses: list[EmailRecipient] | None
    bcc_addresses: list[EmailRecipient] | None
    source: MessageSource
    status: MessageStatus
    created_at: str
    updated_at: str


class SendMessageParams(TypedDict, total=False):
    mailbox_id: str
    to: list[EmailRecipientInput]
    cc: list[EmailRecipientInput]
    bcc: list[EmailRecipientInput]
    reply_to: EmailRecipientInput
    subject: str
    html: str
    text: str
    in_reply_to: str
    references: list[str]


# Allow specifying from as a key (reserved word in Python, but valid in TypedDict)
SendMessageParamsWithFrom = Union[SendMessageParams, dict[str, object]]


class ListMessagesParams(PaginationParams, total=False):
    mailbox_id: str


class ReplyToMessageParams(TypedDict, total=False):
    html: str
    text: str
    to: list[EmailRecipientInput]
    cc: list[EmailRecipientInput]
