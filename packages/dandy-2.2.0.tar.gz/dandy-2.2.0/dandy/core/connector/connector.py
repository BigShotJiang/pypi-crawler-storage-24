class BaseConnector:
    pass