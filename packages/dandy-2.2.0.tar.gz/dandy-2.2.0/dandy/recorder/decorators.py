from functools import wraps
from pathlib import Path
from typing import Callable

from dandy.recorder.recorder import Recorder


def _recorder_to_file_decorator_function(
        func: Callable,
        args: tuple,
        kwargs: dict,
        recording_name: str | None,
        renderer: str,
        path: Path | str,
) -> Callable:
    if recording_name is None:
        recording_name = (
            str(func.__qualname__)  # ty:ignore[unresolved-attribute]
            .replace('.', '_')
            .replace('<', '')
            .replace('>', '')
            .lower()
        )

    try:
        Recorder.start_recording(recording_name)

        return func(*args, **kwargs)

    finally:
        Recorder.stop_recording(recording_name)
        Recorder.to_file(recording_name, renderer, path)
        Recorder.delete_recording(recording_name)


def recorder_to_html_file(recording_name: str | None = None, path: Path | str | None = None) -> Callable:
    if path is None:
        path = Recorder.get_default_recording_path()

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Callable:
            return _recorder_to_file_decorator_function(func, args, kwargs, recording_name, 'html', path)

        return wrapper

    return decorator


def recorder_to_json_file(recording_name: str | None = None, path: Path | str | None = None) -> Callable:
    if path is None:
        path = Recorder.get_default_recording_path()

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Callable:
            return _recorder_to_file_decorator_function(func, args, kwargs, recording_name, 'json', path)

        return wrapper

    return decorator


def recorder_to_markdown_file(recording_name: str | None = None, path: Path | str | None = None) -> Callable:
    if path is None:
        path = Recorder.get_default_recording_path()

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Callable:
            return _recorder_to_file_decorator_function(func, args, kwargs, recording_name, 'markdown', path)

        return wrapper

    return decorator
