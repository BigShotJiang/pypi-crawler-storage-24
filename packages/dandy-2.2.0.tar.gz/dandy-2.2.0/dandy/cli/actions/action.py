from abc import ABC, abstractmethod

from dandy.cli.session import DandyCliSession


class BaseAction(ABC):
    name: str
    description: str
    calls: tuple[str, ...]

    def __init_subclass__(cls, **kwargs) -> None:
        check_attrs = ['name', 'description', 'calls']
        for attr in check_attrs:
            if not hasattr(cls, attr):
                message = f'Command `{attr}` is required'
                raise ValueError(message)

    @abstractmethod
    def help(self) -> None:
        raise NotImplementedError

    @classmethod
    @property
    def input_calls(cls) -> list[str]:
        return [f'/{call}' for call in cls.calls]

    @classmethod
    @property
    def name_gerund(cls) -> str:
        return f'{cls.name}ing'

    @abstractmethod
    def run(self, user_input: str) -> str:
        raise NotImplementedError
