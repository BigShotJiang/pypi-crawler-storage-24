# BaseGrid Python SDK

The official Python client for [BaseGrid](https://basegrid.io), the memory infrastructure for AI agents.

## Installation

```bash
pip install basegrid-io
```

## Usage

```python
from basegrid import BaseGrid

# Initialize client
client = BaseGrid(api_key="bg_...")

# Add a memory
client.memories.add(
    agent_id="agent-123",
    content="User prefers dark mode and heavily indented code.",
    metadata={"category": "preference"}
)

# Search memories
results = client.memories.search(
    agent_id="agent-123",
    query="What are the user's coding preferences?"
)

for memory in results:
    print(memory.content)
```

## Integrations

### LangChain
```bash
pip install "basegrid-io[langchain]"
```

### LlamaIndex
```bash
pip install "basegrid-io[llamaindex]"
```

## Configuration

```python
client = BaseGrid(
    api_key="bg_...",                                      # Required
    api_url="https://basegrid-production.up.railway.app"   # Optional (default)
)
```

## Troubleshooting

### Connection Refused Error
If you see `ConnectionError: Connection refused`, ensure you're using SDK version **0.1.3 or later**:
```bash
pip install --upgrade basegrid-io
```

Versions before 0.1.3 incorrectly defaulted to `localhost:3000` instead of the production API.
