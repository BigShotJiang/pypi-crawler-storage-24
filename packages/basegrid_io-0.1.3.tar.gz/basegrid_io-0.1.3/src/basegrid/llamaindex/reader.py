from typing import List, Any, Optional
try:
    from llama_index.core.readers.base import BaseReader
    from llama_index.core.schema import Document
except ImportError:
    # Mock for inspection
    class BaseReader: pass
    Document = Any

class BaseGridReader(BaseReader):
    """
    BaseGrid Reader for LlamaIndex.
    Loads memories as Documents based on a search query.
    """
    def __init__(self, client: Any, agent_id: str):
        self.client = client
        self.agent_id = agent_id

    def load_data(self, query: str, limit: int = 5) -> List[Document]:
        """
        Load memories matching the query.
        
        Args:
            query: Search query
            limit: Number of results
        """
        results = self.client.memories.search(
            agent_id=self.agent_id,
            query=query,
            limit=limit
        )
        
        docs = []
        for r in results:
            # LlamaIndex Document
            doc = Document(
                text=r.content,
                metadata=r.metadata or {},
                id_=r.id
            )
            docs.append(doc)
        return docs
