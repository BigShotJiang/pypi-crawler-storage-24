from typing import List, Optional, Any
try:
    from langchain_core.callbacks import CallbackManagerForRetrieverRun
    from langchain_core.documents import Document
    from langchain_core.retrievers import BaseRetriever
except ImportError:
    # Fallback/Mock for when langchain is not installed but code is inspected
    from pydantic import BaseModel as BaseRetriever
    CallbackManagerForRetrieverRun = Any
    Document = Any

class BaseGridRetriever(BaseRetriever):
    """
    BaseGrid Retriever for LangChain.
    
    Usage:
        client = BaseGrid(api_key="...")
        retriever = BaseGridRetriever(client=client, agent_id="my-agent")
        docs = retriever.invoke("query")
    """
    client: Any 
    agent_id: str
    k: int = 5

    def _get_relevant_documents(
        self, query: str, *, run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        results = self.client.memories.search(
            agent_id=self.agent_id,
            query=query,
            limit=self.k
        )
        
        return [
            Document(page_content=r.content, metadata=r.metadata or {})
            for r in results
        ]
