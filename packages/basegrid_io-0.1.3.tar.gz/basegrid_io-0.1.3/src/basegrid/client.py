import os
from typing import Optional, List, Dict, Any, Union
import requests
from pydantic import BaseModel, Field

class MemoryMetadata(BaseModel):
    items: Dict[str, Union[str, int, bool, None]]

class MemoryInput(BaseModel):
    agent_id: str = Field(..., alias="agentId")
    content: str
    metadata: Optional[Dict[str, Any]] = None
    importance: Optional[float] = None
    ttl: Optional[str] = None

class SearchInput(BaseModel):
    agent_id: str = Field(..., alias="agentId")
    query: str
    limit: Optional[int] = 5

class Memory(BaseModel):
    id: str
    agent_id: str = Field(..., alias="agentId")
    content: str
    metadata: Optional[Dict[str, Any]] = None
    similarity: Optional[float] = None
    created_at: Optional[str] = Field(None, alias="createdAt")

class MemoriesClient:
    def __init__(self, api_url: str, api_key: str):
        self._api_url = api_url.rstrip('/')
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "BaseGrid-Python-SDK/0.1.0"
        }

    def add(self, agent_id: str, content: str, metadata: Optional[Dict[str, Any]] = None, 
            importance: Optional[float] = None, ttl: Optional[str] = None) -> Union[Dict[str, Any], bool]:
        """
        Store a new memory fragment.
        """
        payload = {
            "agentId": agent_id,
            "content": content
        }
        if metadata:
            payload["metadata"] = metadata
        if importance is not None:
            payload["importance"] = importance
        if ttl:
            payload["ttl"] = ttl

        resp = requests.post(f"{self._api_url}/v1/memories", json=payload, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def search(self, agent_id: str, query: str, limit: int = 5) -> List[Memory]:
        """
        Semantic search for memories.
        """
        payload = {
            "agentId": agent_id,
            "query": query,
            "limit": limit
        }
        
        resp = requests.post(f"{self._api_url}/v1/memories/search", json=payload, headers=self._headers)
        resp.raise_for_status()
        
        data = resp.json()
        # Handle success implementation wrapper if it exists, roughly checking structure
        results = data.get("data", []) if "data" in data else data
        
        # If API returns simplified list
        if isinstance(results, list):
            return [Memory(**item) for item in results]
        return []

    def delete(self, pk: str) -> bool:
        """
        Delete a memory by ID.
        """
        resp = requests.delete(f"{self._api_url}/v1/memories/{pk}", headers=self._headers)
        if resp.status_code == 404:
            return False
        resp.raise_for_status()
        return True

class BaseGrid:
    def __init__(self, api_key: Optional[str] = None, api_url: Optional[str] = None):
        self.api_key = api_key or os.getenv("BASEGRID_API_KEY")
        if not self.api_key:
            raise ValueError("API Key is required. Pass in init or set BASEGRID_API_KEY env var.")
            
        self.api_url = api_url or os.getenv("BASEGRID_API_URL") or "https://basegrid-production.up.railway.app"
        
        self.memories = MemoriesClient(self.api_url, self.api_key)
