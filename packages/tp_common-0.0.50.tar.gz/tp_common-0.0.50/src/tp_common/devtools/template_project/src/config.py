import os

from pydantic_settings import BaseSettings, SettingsConfigDict
from tp_common.tp_logger.schemas import EnvironmentType

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_FILE = os.path.join(BASE_DIR, "..", ".env")


class Config(BaseSettings):
    """
    Класс настроек приложения.
    Все переменные можно передавать через переменные окружения или .env-файл.
    Обязательные значения должны быть заполнены.
    """

    ENV_TYPE: EnvironmentType = EnvironmentType.DEV
    KAFKA_URL: str = ""

    # OFDATA_API_URL: str = "https://token@business.ofdata.ru"

    # REDIS_URL: str = "127.0.0.1:6379/2"
    # KAFKA_URL: str = ""

    # def get_redis_url(self) -> str:
    #     return "redis://" + self.REDIS_URL

    def is_dev(self) -> bool:
        return self.ENV_TYPE in (EnvironmentType.DEV, EnvironmentType.LOCAL)

    def is_staging(self) -> bool:
        return self.ENV_TYPE == EnvironmentType.STAGING

    def is_prod(self) -> bool:
        return self.ENV_TYPE == EnvironmentType.PROD

    model_config = SettingsConfigDict(env_file=ENV_FILE, env_file_encoding="utf-8")


config = Config()
