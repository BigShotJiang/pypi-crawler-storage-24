from datetime import UTC, datetime

from sqlalchemy import TIMESTAMP, text
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
)


class BaseModel(DeclarativeBase):
    # Для автоматического приведения naive datetime к aware
    type_annotation_map = {
        datetime: TIMESTAMP(timezone=True),
    }


class CreatedUpdatedMixin(DeclarativeBase):
    created_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=text("TIMEZONE('utc', now())"),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        TIMESTAMP(timezone=True),
        server_default=text("TIMEZONE('utc', now())"),
        onupdate=text("TIMEZONE('utc', now())"),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
