"""
Script to check differences between Python enum and DB enum.
Automatically finds all enums in models and compares them with DB.

Usage:
    python alembic/scripts/check_enum_diff.py
"""

import os
import sys

# Set UTF-8 encoding environment variable before any imports that might use stdout
os.environ["PYTHONIOENCODING"] = "utf-8"

# Force UTF-8 encoding for stdout/stderr to avoid encoding issues on Windows
if sys.platform == "win32":
    import io

    # Reopen stdout/stderr with UTF-8 encoding
    if hasattr(sys.stdout, "buffer"):
        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )
    if hasattr(sys.stderr, "buffer"):
        sys.stderr = io.TextIOWrapper(
            sys.stderr.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )

import asyncio
import importlib
import traceback
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

# Override built-in print to handle encoding issues safely
_original_print = print


def safe_print(*args, **kwargs):
    """Print function that safely handles encoding issues on Windows."""
    try:
        _original_print(*args, **kwargs)
    except (UnicodeEncodeError, UnicodeError):
        # Fallback: encode to ASCII with error handling
        try:
            message = " ".join(
                str(arg).encode("ascii", errors="replace").decode("ascii")
                for arg in args
            )
            _original_print(message, **kwargs)
        except Exception:
            # Last resort: just print raw bytes
            _original_print(" ".join(repr(arg) for arg in args), **kwargs)


# Replace built-in print with safe version
import builtins

builtins.print = safe_print

# Добавляем корневую директорию проекта в путь
project_root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(project_root))

from config import config as project_config
from sqlalchemy import Enum as SQLEnumType
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine
from sqlalchemy.types import Enum as SQLEnum

from domain.shared.models.base_models import BaseModel

# Константы
DOMAIN_PATH = project_root / "src" / "domain"
SEPARATOR_LENGTH = 80
MODEL_FILE_NAME = "model.py"


@dataclass
class EnumInfo:
    """Информация об enum типе."""

    enum_class: type[Enum]
    python_name: str
    db_name: str


@dataclass
class EnumComparisonResult:
    """Результат сравнения enum между Python и БД."""

    enum_info: EnumInfo
    python_values: set[str]
    db_values: set[str]
    missing_in_db: set[str]
    extra_in_db: set[str]
    error: Exception | None = None

    @property
    def has_differences(self) -> bool:
        """Проверяет наличие различий."""
        return bool(self.missing_in_db or self.extra_in_db or self.error is not None)

    @property
    def is_ok(self) -> bool:
        """Проверяет, что enum синхронизирован."""
        return not self.has_differences


class ModelImporter:
    """Класс для импорта моделей из src/domain."""

    @staticmethod
    def import_all_models() -> int:
        """
        Импортирует все модели из src/domain.

        Returns:
            Количество успешно импортированных моделей
        """
        if not DOMAIN_PATH.exists():
            safe_print(f"[!] Directory {DOMAIN_PATH} not found")
            return 0

        imported_count = 0
        for subdir in DOMAIN_PATH.iterdir():
            if not subdir.is_dir() or subdir.name.startswith("_"):
                continue

            model_file = subdir / MODEL_FILE_NAME
            if not model_file.exists():
                continue

            module_name = f"src.domain.{subdir.name}.model"
            try:
                importlib.import_module(module_name)
                imported_count += 1
            except Exception as e:
                safe_print(f"  [!] Failed to import {module_name}: {e}")

        return imported_count


class EnumValueExtractor:
    """Класс для извлечения значений из enum."""

    @staticmethod
    def normalize_enum_name(value: Any) -> str:
        """
        Нормализует имя enum значения для сравнения.

        Args:
            value: Значение enum (строка или enum элемент)

        Returns:
            Нормализованное имя в верхнем регистре
        """
        if isinstance(value, str):
            return value.upper()

        if hasattr(value, "name") and hasattr(value, "value"):
            enum_name = value.name
            if isinstance(enum_name, str):
                return enum_name.upper()

        return str(value).upper()

    @staticmethod
    def extract_python_enum_values(enum_class: type[Enum]) -> set[str]:
        """
        Извлекает имена ключей из Python enum класса.

        Args:
            enum_class: Класс enum

        Returns:
            Множество имен ключей в верхнем регистре

        Raises:
            ValueError: Если enum класс не является итерируемым
        """
        python_values: set[str] = set()

        if hasattr(enum_class, "__members__"):
            # Используем __members__ для получения всех элементов enum по именам
            for enum_name in enum_class.__members__:
                python_values.add(enum_name.upper())
        elif hasattr(enum_class, "__iter__"):
            # Fallback: если нет __members__, итерируемся по enum классу
            for val in enum_class:  # type: ignore
                if hasattr(val, "name") and isinstance(val.name, str):
                    enum_name = val.name.upper()
                else:
                    enum_name = EnumValueExtractor.normalize_enum_name(val)
                python_values.add(enum_name)
        else:
            raise ValueError(f"{enum_class.__name__} is not an iterable enum")

        return python_values


class EnumFinder:
    """Класс для поиска enum'ов в моделях SQLAlchemy."""

    @staticmethod
    def find_enums_in_models() -> dict[str, EnumInfo]:
        """
        Находит все enum'ы, используемые в моделях.

        Returns:
            Словарь: {db_name: EnumInfo}
        """
        ModelImporter.import_all_models()

        enums_found: dict[str, EnumInfo] = {}

        for _, table in BaseModel.metadata.tables.items():
            for column in table.columns:
                if not isinstance(column.type, (SQLEnum, SQLEnumType)):
                    continue

                enum_info = EnumFinder._extract_enum_info(column)
                if not enum_info:
                    continue

                # Проверяем на конфликты
                if enum_info.db_name in enums_found:
                    existing_info = enums_found[enum_info.db_name]
                    if existing_info.enum_class != enum_info.enum_class:
                        safe_print(
                            f"[!] Conflict detected: {enum_info.db_name} "
                            f"is used by different enum classes"
                        )
                        safe_print(
                            f"   {existing_info.python_name} vs {enum_info.python_name}"
                        )
                    continue

                enums_found[enum_info.db_name] = enum_info

        return enums_found

    @staticmethod
    def _extract_enum_info(column: Any) -> EnumInfo | None:
        """
        Извлекает информацию об enum из колонки.

        Args:
            column: Колонка SQLAlchemy

        Returns:
            EnumInfo или None, если не удалось извлечь
        """
        enum_class = None
        if hasattr(column.type, "enum_class") and column.type.enum_class is not None:
            enum_class = column.type.enum_class

        db_name = None
        if hasattr(column.type, "name") and column.type.name is not None:
            db_name = column.type.name

        if not enum_class or not db_name:
            return None

        python_name = enum_class.__name__
        return EnumInfo(
            enum_class=enum_class,
            python_name=python_name,
            db_name=db_name,
        )


class DatabaseEnumReader:
    """Класс для чтения enum значений из БД."""

    SQL_QUERY = """
        SELECT enumlabel
        FROM pg_enum
        WHERE enumtypid = (
            SELECT oid
            FROM pg_type
            WHERE typname = :enum_name
        )
        ORDER BY enumsortorder;
    """

    @staticmethod
    async def get_db_enum_values(engine: AsyncEngine, enum_name: str) -> set[str]:
        """
        Получает значения enum из БД.

        Args:
            engine: Асинхронный движок SQLAlchemy
            enum_name: Имя enum типа в БД

        Returns:
            Множество значений enum из БД
        """
        async with engine.connect() as conn:
            result = await conn.execute(
                text(DatabaseEnumReader.SQL_QUERY),
                {"enum_name": enum_name},
            )
            return {row[0] for row in result}


class EnumChecker:
    """Основной класс для проверки различий между Python enum и БД enum."""

    def __init__(self, engine: AsyncEngine):
        """
        Инициализирует проверщик enum.

        Args:
            engine: Асинхронный движок SQLAlchemy
        """
        self.engine = engine
        self.finder = EnumFinder()
        self.extractor = EnumValueExtractor()
        self.db_reader = DatabaseEnumReader()

    async def check_all_enums(self) -> list[EnumComparisonResult]:
        """
        Проверяет все enum'ы на различия.

        Returns:
            Список результатов сравнения для каждого enum
        """
        enums_found = self.finder.find_enums_in_models()

        if not enums_found:
            safe_print("[!] No enums found in models!")
            return []

        results: list[EnumComparisonResult] = []

        for _, enum_info in sorted(enums_found.items()):
            result = await self._check_single_enum(enum_info)
            results.append(result)

        return results

    async def _check_single_enum(self, enum_info: EnumInfo) -> EnumComparisonResult:
        """
        Проверяет один enum на различия.

        Args:
            enum_info: Информация об enum

        Returns:
            Результат сравнения
        """
        try:
            python_values = self.extractor.extract_python_enum_values(
                enum_info.enum_class
            )
            db_values = await self.db_reader.get_db_enum_values(
                self.engine, enum_info.db_name
            )
            db_values_normalized = {v.upper() for v in db_values}

            missing_in_db = python_values - db_values_normalized
            extra_in_db = db_values_normalized - python_values

            return EnumComparisonResult(
                enum_info=enum_info,
                python_values=python_values,
                db_values=db_values_normalized,
                missing_in_db=missing_in_db,
                extra_in_db=extra_in_db,
            )
        except Exception as e:
            return EnumComparisonResult(
                enum_info=enum_info,
                python_values=set(),
                db_values=set(),
                missing_in_db=set(),
                extra_in_db=set(),
                error=e,
            )


class ResultPrinter:
    """Класс для вывода результатов проверки."""

    @staticmethod
    def print_results(results: list[EnumComparisonResult]) -> None:
        """
        Выводит результаты проверки enum'ов.

        Args:
            results: Список результатов сравнения
        """
        safe_print("Checking differences between Python enum and DB enum:\n")
        safe_print("=" * SEPARATOR_LENGTH)

        for result in results:
            ResultPrinter._print_single_result(result)

        safe_print("\n" + "=" * SEPARATOR_LENGTH)

    @staticmethod
    def _print_single_result(result: EnumComparisonResult) -> None:
        """Выводит результат для одного enum."""
        enum_info = result.enum_info

        if result.error:
            safe_print(
                f"\n[X] Error checking {enum_info.python_name} "
                f"({enum_info.db_name}): {result.error}"
            )
            traceback.print_exc()
            return

        if result.is_ok:
            return

        safe_print(f"\n[!] {enum_info.python_name} ({enum_info.db_name}):")
        safe_print(f"   Python: {sorted(result.python_values)}")
        safe_print(f"   DB:     {sorted(result.db_values)}")

        if result.missing_in_db:
            safe_print(f"   [X] Необходимо добавить: {sorted(result.missing_in_db)}")

        if result.extra_in_db:
            safe_print(
                f"   [!] Необходимо удалить или переименовать через создания нового в бд: {sorted(result.extra_in_db)}"
            )

    @staticmethod
    def print_summary(results: list[EnumComparisonResult]) -> None:
        """
        Выводит итоговую сводку проверки.

        Args:
            results: Список результатов сравнения
        """
        has_differences = any(result.has_differences for result in results)
        error_count = sum(1 for result in results if result.error is not None)
        missing_count = sum(1 for result in results if result.missing_in_db)
        extra_count = sum(1 for result in results if result.extra_in_db)

        if has_differences:
            safe_print(
                "\n[!] Differences detected! "
                "Run 'alembic revision --autogenerate' to create a migration."
            )
            if error_count > 0:
                safe_print(f"   Errors during check: {error_count}")
            if missing_count > 0:
                safe_print(f"   Enums with missing values in DB: {missing_count}")
            if extra_count > 0:
                safe_print(f"   Enums with extra values in DB: {extra_count}")
        else:
            safe_print("\n[OK] All enums are synchronized!")


async def check_enum_diff() -> int:
    """
    Основная функция для проверки различий между Python enum и БД enum.

    Returns:
        Код выхода: 0 если все синхронизировано, 1 если есть различия или ошибки
    """
    try:
        safe_print("Searching for enums in models...")
        imported_count = ModelImporter.import_all_models()
        safe_print(f"Imported models: {imported_count}")

        engine = create_async_engine(project_config.get_async_postgres_url_connection())

        try:
            checker = EnumChecker(engine)
            results = await checker.check_all_enums()

            if not results:
                safe_print("\n[!] No enums found in models!")
                safe_print("If this is unexpected, check the model configuration.")
                return 1

            safe_print(f"\nFound enums: {len(results)}\n")
            ResultPrinter.print_results(results)
            ResultPrinter.print_summary(results)

            has_differences = any(result.has_differences for result in results)

            if has_differences:
                safe_print(
                    "\n[X] Check failed: differences detected between Python enum and DB enum!"
                )
                return 1

            safe_print("\n[OK] Check passed: all enums are synchronized!")
            return 0
        finally:
            await engine.dispose()
    except Exception as e:
        safe_print(f"\n[X] Critical error during check: {e}")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(check_enum_diff())
    sys.exit(exit_code)
