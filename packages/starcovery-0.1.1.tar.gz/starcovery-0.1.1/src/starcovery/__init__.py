def hello() -> str:
    return "Hello from starcovery!"
