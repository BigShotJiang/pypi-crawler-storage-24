from __future__ import annotations

import numpy as np
import pandas as pd
import logging
import pytest

from cdm_reader_mapper.common.iterators import ParquetStreamReader

from cdm_reader_mapper.metmetpy import properties
from cdm_reader_mapper.metmetpy.datetime.correction_functions import dck_201_icoads
from cdm_reader_mapper.metmetpy.datetime.model_datetimes import (
    datetime_decimalhour_to_hm,
    to_datetime,
    from_datetime,
    icoads,
)
from cdm_reader_mapper.metmetpy.platform_type.correction_functions import (
    is_num,
    overwrite_data,
    fill_value,
    deck_717_gdac,
    deck_700_icoads,
    deck_892_icoads,
    deck_792_icoads,
    deck_992_icoads,
)
from cdm_reader_mapper.metmetpy.correct import (
    _correct_dt,
    _correct_pt,
    correct_datetime,
    correct_pt,
)
from cdm_reader_mapper.metmetpy.validate import (
    _get_id_col,
    _get_patterns,
    validate_id,
    validate_datetime,
)

YR = properties.metadata_datamodels["year"]["icoads"]
MO = properties.metadata_datamodels["month"]["icoads"]
DY = properties.metadata_datamodels["day"]["icoads"]
HR = properties.metadata_datamodels["hour"]["icoads"]
ID = properties.metadata_datamodels["id"]["icoads"]
SID = properties.metadata_datamodels["source"]["icoads"]
PT = properties.metadata_datamodels["platform"]["icoads"]

datetime_cols = [YR, MO, DY, HR]


@pytest.fixture
def sample_df():
    return pd.DataFrame({"A": [1, 2, 3]})


@pytest.mark.parametrize(
    "decimal_hour,expected",
    [
        (0.0, (0, 0)),
        (1.5, (1, 30)),
        (13.75, (13, 45)),
        (23.99, (23, 59)),
        (12.0, (12, 0)),
    ],
)
def test_datetime_decimalhour_to_hm(decimal_hour, expected):
    result = datetime_decimalhour_to_hm(decimal_hour)
    assert result == expected


def test_icoads_to_datetime_basis():
    df = pd.DataFrame(
        {
            YR: [2000, 2001],
            MO: [1, 2],
            DY: [10, 15],
            HR: [12.5, 6.25],
        }
    )

    result = icoads(df, "to_datetime")

    expected = pd.Series(
        pd.to_datetime(
            [
                "2000-01-10 12:30:00",
                "2001-02-15 06:15:00",
            ]
        )
    )
    pd.testing.assert_series_equal(result, expected)


def test_icoads_to_datetime_missing_values():
    df = pd.DataFrame(
        {
            YR: [2000, None, 2001],
            MO: [1, 2, 2],
            DY: [10, None, 15],
            HR: [12.5, None, 6.25],
        }
    )

    result = icoads(df, "to_datetime")

    expected = pd.Series(
        pd.to_datetime(
            [
                "2000-01-10 12:30:00",
                None,
                "2001-02-15 06:15:00",
            ]
        )
    )
    pd.testing.assert_series_equal(result, expected)


def test_icoads_from_datetime_basis():
    ds = pd.Series(
        [
            pd.Timestamp("2000-01-10 12:30"),
            pd.Timestamp("2001-02-15 06:15"),
            pd.Timestamp("2002-03-20 18:45"),
        ]
    )

    result = icoads(ds, "from_datetime")

    expected = pd.DataFrame(
        {
            YR: [2000, 2001, 2002],
            MO: [1, 2, 3],
            DY: [10, 15, 20],
            HR: [12.5, 6.25, 18.75],
        },
        dtype=object,
    )
    pd.testing.assert_frame_equal(result, expected)


def test_icoads_both_datetime():
    df_in = pd.DataFrame(
        {
            YR: [2000, 2001],
            MO: [1, 2],
            DY: [10, 15],
            HR: [12.5, 6.25],
        }
    )

    dt = icoads(df_in, "to_datetime")
    df_out = icoads(dt, "from_datetime")

    pd.testing.assert_frame_equal(df_in, df_out, check_dtype=False)


def test_icoads_valueerror():
    df = pd.DataFrame(
        {
            YR: [2000],
            MO: [1],
            DY: [10],
            HR: [12.5],
        }
    )

    with pytest.raises(
        ValueError, match="conversion must be one of {'to_datetime','from_datetime'}"
    ):
        icoads(df, "bad_conversion.")


def test_icoads_from_datetime_typeerror():
    df = pd.DataFrame([pd.Timestamp(2000)])

    with pytest.raises(TypeError):
        icoads(df, "from_datetime")


def test_icoads_to_datetime_typeerror():
    s = pd.Series([pd.Timestamp("2000-01-01")])

    with pytest.raises(TypeError):
        icoads(s, "to_datetime")


def test_icoads_to_datetime_false_date_columns():
    df = pd.DataFrame(
        {
            "YR": [2000, 2001],
            "MO": [1, 2],
            "DY": [10, 15],
            "HR": [12.5, 6.25],
        }
    )
    result = icoads(df, "to_datetime")

    pd.testing.assert_series_equal(result, pd.Series(dtype="datetime64[ns]"))


def test_icoads_to_datetime_missing_columns():
    df = pd.DataFrame({YR: [2000]})

    result = icoads(df, "to_datetime")

    pd.testing.assert_series_equal(result, pd.Series(pd.to_datetime([None])))


def test_icoads_from_datetime_empty_series():
    s = pd.Series([], dtype="datetime64[ns]")

    result = icoads(s, "from_datetime")

    assert isinstance(result, pd.DataFrame)
    assert result.empty


def test_to_datetime_basis():
    df = pd.DataFrame(
        {
            YR: [2000, 2001],
            MO: [1, 2],
            DY: [10, 15],
            HR: [12.5, 6.25],
        }
    )

    result = to_datetime(df)

    expected = pd.Series(pd.to_datetime(["2000-01-10 12:30:00", "2001-02-15 06:15:00"]))

    pd.testing.assert_series_equal(result, expected)


def test_to_datetime_no_correction():
    df = pd.DataFrame(
        {
            YR: [2000, 2001],
            MO: [1, 2],
            DY: [10, 15],
            HR: [12.5, 6.25],
        }
    )

    result = to_datetime(df, model="no_model")
    pd.testing.assert_frame_equal(result, df)


def test_from_datetime_basis():
    df = pd.Series(
        [
            pd.Timestamp("2000-01-10 12:30"),
            pd.Timestamp("2001-02-15 06:15"),
            pd.Timestamp("2002-03-20 18:45"),
        ]
    )

    result = from_datetime(df)

    expected = pd.DataFrame(
        {
            YR: [2000, 2001, 2002],
            MO: [1, 2, 3],
            DY: [10, 15, 20],
            HR: [12.5, 6.25, 18.75],
        },
        dtype=object,
    )
    pd.testing.assert_frame_equal(result, expected)


def test_from_datetime_no_correction():
    df = pd.Series(
        [
            pd.Timestamp("2000-01-10 12:30"),
            pd.Timestamp("2001-02-15 06:15"),
            pd.Timestamp("2002-03-20 18:45"),
        ]
    )

    result = from_datetime(df, model="no_model")
    pd.testing.assert_series_equal(result, df)


def test_dck_201_icoads():
    data = pd.DataFrame(
        {YR: [1899, 1900, 1899], MO: [1, 2, 3], DY: [1, 15, 1], HR: [0, 12, 0]}
    )

    expected = pd.DataFrame(
        {
            YR: [1898, 1900, 1899],
            MO: [12, 2, 2],
            DY: [31, 15, 28],
            HR: [0, 12, 0],
        }
    )

    result = dck_201_icoads(data.copy())

    pd.testing.assert_frame_equal(result, expected, check_dtype=False)


@pytest.mark.parametrize(
    "x, exp",
    [
        ("123", True),
        ("0", True),
        ("12.3", False),
        ("abc", False),
        (None, False),
        (1, False),
        (12.3, False),
    ],
)
def test_is_num(x, exp):
    assert is_num(x) is exp


def test_overwrite_data():
    df = pd.DataFrame({"PT": [1, 2, 3, 4], "VAL": [10, 20, 30, 40]})

    loc = df["PT"] > 2
    result = overwrite_data(df.copy(), loc, "VAL", 999)

    expected = pd.DataFrame({"PT": [1, 2, 3, 4], "VAL": [10, 20, 999, 999]})

    pd.testing.assert_frame_equal(result, expected)

    result2 = overwrite_data(df.copy(), loc, "NON_EXIST", 0)
    pd.testing.assert_frame_equal(result2, df)

    result3 = overwrite_data(df.copy(), [False, False, False, False], "VAL", 0)
    pd.testing.assert_frame_equal(result3, df)


def test_fill_value():
    s = pd.Series([1, 2, 3, None, 2])

    result = fill_value(s, fill_value=99, fillna=True)
    expected = pd.Series([1, 2, 3, 99, 2])
    pd.testing.assert_series_equal(result, expected, check_dtype=False)

    result2 = fill_value(s, fill_value=0, self_condition_value=2)
    expected2 = pd.Series([1, 0, 3, None, 0])
    pd.testing.assert_series_equal(result2, expected2)

    df = pd.DataFrame({"mask": [True, False, True, False, True]})
    result3 = fill_value(
        s, fill_value=-1, out_condition=df, out_condition_values={"mask": True}
    )
    expected3 = pd.Series([-1, 2, -1, None, -1])
    pd.testing.assert_series_equal(result3, expected3)


def test_deck_717_gdac():
    pt_col = properties.metadata_datamodels["platform"]["gdac"]

    df = pd.DataFrame({pt_col: [np.nan, 0, 1, np.nan], "N": [1, np.nan, 2, np.nan]})

    expected = pd.DataFrame({pt_col: ["7", "9", 1, "7"], "N": [1, np.nan, 2, np.nan]})

    result = deck_717_gdac(df.copy())

    pd.testing.assert_frame_equal(result, expected)


def test_deck_700_icoads():
    data = pd.DataFrame(
        {
            ID: ["12345", "54321", "00001", "ABCDE"],
            SID: ["147", "147", "999", "147"],
            PT: [pd.NA, "5", "5", "5"],
        }
    )

    expected = pd.DataFrame(
        {
            ID: ["12345", "54321", "00001", "ABCDE"],
            SID: ["147", "147", "999", "147"],
            PT: ["7", "6", "5", "5"],
        }
    )

    result = deck_700_icoads(data.copy())

    pd.testing.assert_frame_equal(result, expected)


def test_deck_892_icoads():
    columns = [ID, SID, PT]

    data = pd.DataFrame(
        [
            ["12345", "29", "5"],
            ["12345", "29", "6"],
            ["12345", "30", "5"],
            ["1234", "29", "5"],
        ],
        columns=columns,
    )

    expected = pd.DataFrame(
        [
            ["12345", "29", "6"],
            ["12345", "29", "6"],
            ["12345", "30", "5"],
            ["1234", "29", "5"],
        ],
        columns=columns,
    )

    result = deck_892_icoads(data.copy())

    pd.testing.assert_frame_equal(result, expected)


def test_deck_792_icoads_basic():
    data = pd.DataFrame(
        {
            ID: ["123456", "12345", "7123456", "2345678"],
            SID: ["103", "103", "103", "103"],
            PT: ["5", "5", "5", "5"],
        }
    )

    expected = pd.DataFrame(
        {
            ID: ["123456", "12345", "7123456", "2345678"],
            SID: ["103", "103", "103", "103"],
            PT: ["6", "5", "5", "5"],
        }
    )

    result = deck_792_icoads(data.copy())
    pd.testing.assert_frame_equal(result, expected)


def test_deck_792_icoads_no_change():
    data = pd.DataFrame(
        {
            ID: ["12345", "7123456", "56789"],
            SID: ["104", "103", "103"],
            PT: ["5", "6", "5"],
        }
    )

    expected = data.copy()
    result = deck_792_icoads(data.copy())
    pd.testing.assert_frame_equal(result, expected)


def test_deck_992_icoads_basic():
    data = pd.DataFrame(
        {
            ID: ["6202222", "123456", "7123456", "2345678"],
            SID: ["114", "114", "114", "114"],
            PT: ["5", "5", "5", "5"],
        }
    )

    expected = pd.DataFrame(
        {
            ID: ["6202222", "123456", "7123456", "2345678"],
            SID: ["114", "114", "114", "114"],
            PT: ["4", "6", "5", "5"],
        }
    )

    result = deck_992_icoads(data.copy())
    pd.testing.assert_frame_equal(result, expected)


def test_correct_dt_pass():
    data = pd.DataFrame(
        {
            YR: [1899, 1900, 1899],
            MO: [1, 2, 3],
            DY: [1, 15, 1],
            HR: [0, 12, 0],
        }
    )

    expected = pd.DataFrame(
        {
            YR: [1898, 1900, 1899],
            MO: [12, 2, 2],
            DY: [31, 15, 28],
            HR: [0, 12, 0],
        }
    )

    correction_method = {"201": {"function": "dck_201_icoads"}}

    result = _correct_dt(
        data.copy(),
        data_model="icoads",
        dck="201",
        correction_method=correction_method,
    )

    pd.testing.assert_frame_equal(result, expected, check_dtype=False)


def test_correct_dt_no_correction():
    data = pd.DataFrame(
        {
            YR: [1899, 1900, 1899],
            MO: [1, 2, 3],
            DY: [1, 15, 1],
            HR: [0, 12, 0],
        }
    )

    result = _correct_dt(
        data.copy(),
        data_model="icoads",
        dck="201",
        correction_method={},
    )

    pd.testing.assert_frame_equal(data, result)


def test_correct_dt_typeerror():
    series = pd.Series([1898, 1900, 1899])
    with pytest.raises(TypeError, match="pd.Series is not supported now."):
        _correct_dt(series, data_model="icoads", dck="201", correction_method={})


def test_correct_dt_attributeerror():
    data = pd.DataFrame(
        {
            YR: [1899, 1900, 1899],
            MO: [1, 2, 3],
            DY: [1, 15, 1],
            HR: [0, 12, 0],
        }
    )

    correction_method = {"201": {"function": "invalid_function"}}

    with pytest.raises(AttributeError, match="not found"):
        _correct_dt(
            data.copy(),
            data_model="icoads",
            dck="201",
            correction_method=correction_method,
        )


def test_correct_dt_runtimeerror():
    invalid_data = pd.DataFrame(
        {
            MO: [1, 2, 3],
            DY: [1, 15, 1],
            HR: [0, 12, 0],
        }
    )

    correction_method = {"201": {"function": "dck_201_icoads"}}

    with pytest.raises(RuntimeError, match="could not be executed"):
        _correct_dt(
            invalid_data,
            data_model="icoads",
            dck="201",
            correction_method=correction_method,
        )


def test_correct_pt_fillna():
    pt_col = "platform"
    data = pd.DataFrame({pt_col: [None, "5", None, "3"]})

    fix_methods = {
        "201": {
            "method": "fillna",
            "fill_value": "7",
        }
    }

    expected = pd.DataFrame({pt_col: ["7", "5", "7", "3"]})

    result = _correct_pt(
        data.copy(),
        imodel="icoads",
        dck="201",
        pt_col=pt_col,
        fix_methods=fix_methods,
    )

    pd.testing.assert_frame_equal(result, expected, check_dtype=False)


def test_correct_pt_function():
    data = pd.DataFrame(
        {
            ID: ["12345", "99999"],
            SID: ["147", "999"],
            PT: ["5", "5"],
        }
    )

    fix_methods = {
        "700": {
            "method": "function",
            "function": "deck_700_icoads",
        }
    }

    expected = pd.DataFrame(
        {
            ID: ["12345", "99999"],
            SID: ["147", "999"],
            PT: ["6", "5"],
        }
    )

    result = _correct_pt(
        data.copy(),
        imodel="icoads",
        dck="700",
        pt_col=PT,
        fix_methods=fix_methods,
    )

    pd.testing.assert_frame_equal(result, expected, check_dtype=False)


def test_correct_pt_no_correction():
    pt_col = "PT"
    data = pd.DataFrame({pt_col: ["1", None, "3"]})

    fix_methods = {"999": {"method": "fillna", "fill_value": "7"}}

    result = _correct_pt(
        data.copy(),
        imodel="icoads",
        dck="888",
        pt_col=pt_col,
        fix_methods=fix_methods,
    )

    pd.testing.assert_frame_equal(result, data)


def test_correct_pt_missing_platform_column():
    data = pd.DataFrame({"A": [1, 2], "B": [3, 4]})

    fix_methods = {"201": {"method": "fillna", "fill_value": "7"}}

    result = _correct_pt(
        data.copy(),
        imodel="icoads",
        dck="201",
        pt_col="PT",
        fix_methods=fix_methods,
    )

    pd.testing.assert_frame_equal(result, data)


def test_correct_pt_valueerror_not_implemented():
    data = pd.DataFrame({"PT": ["1", "2"]})

    fix_methods = {"201": {"method": "not_a_method"}}

    with pytest.raises(ValueError, match="not implemented"):
        _correct_pt(
            data.copy(),
            imodel="icoads",
            dck="201",
            pt_col="PT",
            fix_methods=fix_methods,
        )


def test_correct_pt_typeerror():
    series = pd.Series(["1", "2"])
    with pytest.raises(TypeError, match="pd.Series is not supported now."):
        _correct_pt(series, imodel="icoads", dck="201", pt_col="PT", fix_methods={})


def test_correct_pt_valuerror_fillvalue():
    data = pd.DataFrame({"PT": ["1", None]})

    fix_methods = {"201": {"method": "fillna"}}

    with pytest.raises(ValueError, match='requires "fill_value"'):
        _correct_pt(
            data.copy(),
            imodel="icoads",
            dck="201",
            pt_col="PT",
            fix_methods=fix_methods,
        )


def test_correct_pt_valueerror_no_function_name():
    data = pd.DataFrame({"PT": ["1", "2"]})

    fix_methods = {"700": {"method": "function"}}

    with pytest.raises(ValueError, match='requires "function" name'):
        _correct_pt(
            data.copy(),
            imodel="icoads",
            dck="700",
            pt_col="PT",
            fix_methods=fix_methods,
        )


def test_correct_pt_valueerror_no_function_found():
    data = pd.DataFrame({"PT": ["1", "2"]})

    fix_methods = {"700": {"method": "function", "function": "NO_SUCH_FUNC"}}

    with pytest.raises(ValueError, match="not found"):
        _correct_pt(
            data.copy(),
            imodel="icoads",
            dck="700",
            pt_col="PT",
            fix_methods=fix_methods,
        )


@pytest.mark.parametrize(
    "data,expected",
    [
        (
            pd.DataFrame({YR: [1899], MO: [1], DY: [1], HR: [0]}),
            pd.DataFrame({YR: [1898], MO: [12], DY: [31], HR: [0]}),
        ),
        (
            pd.DataFrame({YR: [1900], MO: [1], DY: [1], HR: [12]}),
            pd.DataFrame({YR: [1900], MO: [1], DY: [1], HR: [12]}),
        ),
    ],
)
def test_correct_datetime_pd(data, expected):
    result = correct_datetime(data.copy(), "icoads_r300_d201", log_level="CRITICAL")
    pd.testing.assert_frame_equal(result, expected)


def test_correct_datetime_psr():
    expected = pd.DataFrame({YR: [1898, 1900], MO: [12, 1], DY: [31, 1], HR: [0, 12]})

    df1 = pd.DataFrame({YR: [1899], MO: [1], DY: [1], HR: [0]}, index=[0])
    df2 = pd.DataFrame({YR: [1900], MO: [1], DY: [1], HR: [12]}, index=[1])
    psr = ParquetStreamReader([df1, df2])

    result = correct_datetime(psr, "icoads_r300_d201").read()

    pd.testing.assert_frame_equal(result, expected)


def test_correct_datetime_pd_no_correction_no_deck():
    data = pd.DataFrame({YR: [1899], MO: [1], DY: [1], HR: [0]})
    result = correct_datetime(data, "icoads_r300")

    pd.testing.assert_frame_equal(result, data)


def test_correct_datetime_pd_no_correction_false_deck():
    data = pd.DataFrame({YR: [1899], MO: [1], DY: [1], HR: [0]})
    result = correct_datetime(data, "icoads_r302_d992")

    pd.testing.assert_frame_equal(result, data)


@pytest.mark.parametrize("data", ["invalid_data", 1, 1.0, True, {"1": 2}, {1, 2}])
def test_correct_datetime_pd_invalid_data(data):
    with pytest.raises(TypeError, match="Unsupported data type"):
        correct_datetime(data, "icoads_r300_d201")


def test_correct_datetime_pd_series():
    with pytest.raises(TypeError, match="pd.Series is not supported now."):
        correct_datetime(pd.Series([1, 2, 3]), "icoads_r300_d201")


@pytest.mark.parametrize("data", [[1, 2], (1, 2)])
def test_correct_datetime_pd_invalid_iterable_entries(data):
    with pytest.raises(
        TypeError, match="Iterable must contain pd.DataFrame or pd.Series objects."
    ):
        correct_datetime(data, "icoads_r300_d201")


@pytest.mark.parametrize(
    "data", [ParquetStreamReader(iter([])), ParquetStreamReader(iter(()))]
)
def test_correct_datetime_empty_iterable(data):
    with pytest.raises(ValueError, match="Iterable is empty."):
        correct_datetime(data, "icoads_r300_d201")


def test_correct_datetime_valid_iterable():
    df1 = pd.DataFrame({YR: [1899], MO: [1], DY: [1], HR: [0]}, index=[0])
    df2 = pd.DataFrame({YR: [1900], MO: [1], DY: [1], HR: [12]}, index=[1])
    result = correct_datetime(ParquetStreamReader(iter([df1, df2])), "icoads_r300_d201")

    exp = pd.DataFrame({YR: [1898, 1900], MO: [12, 1], DY: [31, 1], HR: [0, 12]})
    pd.testing.assert_frame_equal(result.read(), exp)


@pytest.mark.parametrize(
    "data_input,imodel,expected",
    [
        (
            pd.DataFrame({PT: [None, "7", None]}),
            "icoads_r300_d993",
            pd.DataFrame({PT: ["5", "7", "5"]}),
        ),
        (
            pd.DataFrame(
                {
                    ID: ["12345", "99999"],
                    SID: ["147", "999"],
                    PT: ["5", "5"],
                }
            ),
            "icoads_r300_d700",
            pd.DataFrame(
                {
                    ID: ["12345", "99999"],
                    SID: ["147", "999"],
                    PT: ["6", "5"],
                }
            ),
        ),
    ],
)
def test_correct_pt_pd(data_input, imodel, expected):
    result = correct_pt(data_input.copy(), imodel, log_level="CRITICAL")
    pd.testing.assert_frame_equal(result, expected, check_dtype=False)


@pytest.mark.parametrize(
    "data_input,imodel,expected",
    [
        (
            [
                pd.DataFrame({PT: [None]}, index=[0]),
                pd.DataFrame({PT: ["7"]}, index=[1]),
                pd.DataFrame({PT: [None]}, index=[2]),
            ],
            "icoads_r300_d993",
            pd.DataFrame({PT: ["5", "7", "5"]}),
        ),
        (
            [
                pd.DataFrame({PT: ["5"], ID: ["12345"], SID: ["147"]}, index=[0]),
                pd.DataFrame({PT: ["5"], ID: ["99999"], SID: ["999"]}, index=[1]),
                pd.DataFrame({PT: ["7"], ID: ["123"], SID: ["999"]}, index=[2]),
            ],
            "icoads_r300_d700",
            pd.DataFrame(
                {
                    PT: ["6", "5", "7"],
                    ID: ["12345", "99999", "123"],
                    SID: ["147", "999", "999"],
                }
            ),
        ),
    ],
)
def test_correct_pt_psr(data_input, imodel, expected):
    """Test correct_pt with TextFileReader input."""
    psr = ParquetStreamReader(data_input)
    result = correct_pt(psr, imodel, log_level="CRITICAL")
    pd.testing.assert_frame_equal(result.read(), expected, check_dtype=False)


@pytest.mark.parametrize("data", ["invalid_data", 1, 1.0, True, {"1": 2}, {1, 2}])
def test_correct_pt_pd_invalid_data(data):
    with pytest.raises(TypeError, match="Unsupported data type"):
        correct_pt(data, "icoads_r300_d993")


def test_correct_pt_pd_series():
    with pytest.raises(TypeError, match="pd.Series is not supported now."):
        correct_pt(pd.Series([1, 2, 3]), "icoads_r300_d993")


@pytest.mark.parametrize("data", [[1, 2], (1, 2)])
def test_correct_pt_invalid_iterable_entries(data):
    with pytest.raises(
        TypeError, match="Iterable must contain pd.DataFrame or pd.Series objects."
    ):
        correct_pt(data, "icoads_r300_d993")


@pytest.mark.parametrize(
    "data", [ParquetStreamReader(iter([])), ParquetStreamReader(iter(()))]
)
def test_correct_pt_empty_iterable(data):
    with pytest.raises(ValueError, match="Iterable is empty."):
        correct_pt(data, "icoads_r300_d993")


def test_correct_pt_valid_iterable():
    df1 = pd.DataFrame({PT: [None, "7", None]}, index=[0, 1, 2])
    df2 = pd.DataFrame({PT: ["6", "7", None]}, index=[3, 4, 5])
    result = correct_pt(ParquetStreamReader(iter([df1, df2])), "icoads_r300_d993")

    exp = pd.DataFrame({PT: ["5", "7", "5", "6", "7", "5"]})
    pd.testing.assert_frame_equal(result.read(), exp)


def test_correct_pt_pd_no_correction_no_deck():
    data = pd.DataFrame({PT: [None, "7", None]})
    result = correct_pt(data, "icoads_r300")

    pd.testing.assert_frame_equal(result, data)


def test_correct_pt_pd_no_correction_false_deck():
    data = pd.DataFrame({PT: [None, "7", None]})
    result = correct_pt(data, "icoads_r300_d701")

    pd.testing.assert_frame_equal(result, data)


def test_get_id_col_not_defined():
    df = pd.DataFrame({"X": [1, 2, 3]})
    with pytest.raises(ValueError, match="ID column not defined in properties file"):
        _get_id_col(df, "unknown_model")


def test_get_id_col_missing_in_data():
    df = pd.DataFrame({"X": [1, 2, 3]})
    with pytest.raises(ValueError, match="No ID columns found."):
        _get_id_col(df, "icoads")


def test_get_id_col_single_column_present():
    df = pd.DataFrame({("core", "ID"): [1, 2, 3], ("other", "ID"): [4, 5, 6]})
    result = _get_id_col(df, "icoads")
    assert result == ("core", "ID")


def test_get_patterns_empty_dict():
    logger = logging.getLogger("test_logger")
    dck_id_model = {"valid_patterns": {}}
    blank = False
    dck = "123"
    data_model_files = ["dummy.json"]

    result = _get_patterns(dck_id_model, blank, dck, data_model_files, logger)
    assert result == [".*?"]


def test_get_patterns_with_patterns():
    logger = logging.getLogger("test_logger")
    dck_id_model = {"valid_patterns": {"p1": "A.*", "p2": "B.*"}}
    blank = False
    dck = "123"
    data_model_files = ["dummy.json"]

    result = _get_patterns(dck_id_model, blank, dck, data_model_files, logger)
    assert set(result) == {"A.*", "B.*"}


def test_get_patterns_with_blank_true():
    logger = logging.getLogger("test_logger")
    dck_id_model = {"valid_patterns": {"p1": "A.*"}}
    blank = True
    dck = "123"
    data_model_files = ["dummy.json"]

    result = _get_patterns(dck_id_model, blank, dck, data_model_files, logger)
    assert "A.*" in result
    assert "^$" in result
    assert len(result) == 2


def test_get_patterns_empty_and_blank_true():
    logger = logging.getLogger("test_logger")
    dck_id_model = {"valid_patterns": {}}
    blank = True
    dck = "123"
    data_model_files = ["dummy.json"]

    result = _get_patterns(dck_id_model, blank, dck, data_model_files, logger)
    assert ".*?" in result
    assert "^$" in result
    assert len(result) == 2


@pytest.mark.parametrize(
    "data_input, imodel, blank, expected",
    [
        (
            pd.DataFrame({ID: ["12345", "ABCDE"]}),
            "icoads_r300_d201",
            False,
            pd.Series([True, False]),
        ),
        (
            pd.DataFrame({ID: ["12345", ""]}),
            "icoads_r300_d201",
            True,
            pd.Series([True, True]),
        ),
        (
            pd.DataFrame({ID: ["12345", ""]}),
            "icoads_r300_d201",
            False,
            pd.Series([True, True]),
        ),
    ],
)
def test_validate_id_df(data_input, imodel, blank, expected):
    result = validate_id(data_input.copy(), imodel, blank=blank, log_level="CRITICAL")
    pd.testing.assert_series_equal(result, expected, check_dtype=False)


def test_validate_id_psr():
    df1 = pd.DataFrame({ID: ["12345"]}, index=[0])
    df2 = pd.DataFrame({ID: ["ABCDE"]}, index=[1])
    df3 = pd.DataFrame({ID: [None]}, index=[2])
    psr = ParquetStreamReader([df1, df2, df3])
    result = validate_id(psr, "icoads_r300_d201", blank=False, log_level="CRITICAL")
    expected = pd.Series([True, False, True])

    pd.testing.assert_series_equal(result.read(), expected)


def test_validate_id_valueerror_no_deck():
    data = pd.DataFrame({ID: ["12345", "ABCDE"]})

    with pytest.raises(ValueError, match="has no deck information"):
        validate_id(data, "icoads")


def test_validate_id_filenotfounderror():
    data = pd.DataFrame({ID: ["12345", "ABCDE"]})

    with pytest.raises(FileNotFoundError, match="has no ID deck library"):
        validate_id(data, "icoads_r302_d992")


def test_validate_id_valueerror_invalid_deck():
    data = pd.DataFrame({ID: ["12345", "ABCDE"]})

    with pytest.raises(ValueError, match="not defined in file"):
        validate_id(data, "icoads_r300_d200")


def test_validate_id_valueerror_no_columns():
    data = pd.DataFrame({"ID": ["12345", "ABCDE"]})

    with pytest.raises(ValueError, match="No ID columns found."):
        validate_id(data, "icoads_r300_d201")


@pytest.mark.parametrize(
    "data_input, expected",
    [
        (
            pd.DataFrame({YR: [2023, 2023], MO: [1, 1], DY: [1, 2], HR: [12, 13]}),
            pd.Series([True, True]),
        ),
        (
            pd.DataFrame({YR: [2023, 2023], MO: [1, 1], DY: [1, 2], HR: [12, None]}),
            pd.Series([True, False]),
        ),
        (
            pd.DataFrame(
                {YR: [2023, None], MO: [1, None], DY: [1, None], HR: [12, None]}
            ),
            pd.Series([True, False]),
        ),
    ],
)
def test_validate_datetime_dataframe(data_input, expected):
    result = validate_datetime(data_input.copy(), "icoads", log_level="CRITICAL")
    pd.testing.assert_series_equal(result, expected)


@pytest.mark.parametrize(
    "data_input, expected",
    [
        (
            [
                pd.DataFrame({YR: [2023], MO: [1], DY: [1], HR: [12]}, index=[0]),
                pd.DataFrame({YR: [2023], MO: [1], DY: [2], HR: [13]}, index=[1]),
                pd.DataFrame(
                    {YR: [None], MO: [None], DY: [None], HR: [None]}, index=[2]
                ),
            ],
            pd.Series([True, True, False]),
        ),
        (
            [
                pd.DataFrame({YR: [2023], MO: [1], DY: [1], HR: [12]}, index=[0]),
                pd.DataFrame({YR: [2023], MO: [1], DY: [2], HR: [None]}, index=[1]),
                pd.DataFrame(
                    {YR: [None], MO: [None], DY: [None], HR: [None]}, index=[2]
                ),
            ],
            pd.Series([True, False, False]),
        ),
    ],
)
def test_validate_datetime_psr(data_input, expected):
    psr = ParquetStreamReader(data_input)
    result = validate_datetime(psr, "icoads", log_level="CRITICAL")
    pd.testing.assert_series_equal(result.read(), expected)


def test_validate_datetime_valueerror():
    data = pd.DataFrame(
        {"YR": [2023, 2023], "MO": [1, 1], "DY": [1, 2], "HR": [12, 13]}
    )
    with pytest.raises(ValueError, match="No columns found for datetime conversion"):
        validate_datetime(data, "icoads")
