"""Generic markdown collection with FTS5 + semantic search."""

from markdown_vault_mcp.collection import Collection
from markdown_vault_mcp.config import CollectionConfig, load_config
from markdown_vault_mcp.exceptions import (
    ConcurrentModificationError,
    DocumentExistsError,
    DocumentNotFoundError,
    EditConflictError,
    MarkdownMCPError,
    ReadOnlyError,
)
from markdown_vault_mcp.git import GitWriteStrategy, git_write_strategy
from markdown_vault_mcp.types import (
    AttachmentContent,
    AttachmentInfo,
    ChangeSet,
    Chunk,
    CollectionStats,
    DeleteResult,
    EditResult,
    FTSResult,
    IndexStats,
    NoteContent,
    NoteInfo,
    ParsedNote,
    ReindexResult,
    RenameResult,
    SearchResult,
    WriteCallback,
    WriteResult,
)

__all__ = [
    "AttachmentContent",
    "AttachmentInfo",
    "ChangeSet",
    "Chunk",
    "Collection",
    "CollectionConfig",
    "CollectionStats",
    "ConcurrentModificationError",
    "DeleteResult",
    "DocumentExistsError",
    "DocumentNotFoundError",
    "EditConflictError",
    "EditResult",
    "FTSResult",
    "GitWriteStrategy",
    "IndexStats",
    "MarkdownMCPError",
    "NoteContent",
    "NoteInfo",
    "ParsedNote",
    "ReadOnlyError",
    "ReindexResult",
    "RenameResult",
    "SearchResult",
    "WriteCallback",
    "WriteResult",
    "git_write_strategy",
    "load_config",
]
