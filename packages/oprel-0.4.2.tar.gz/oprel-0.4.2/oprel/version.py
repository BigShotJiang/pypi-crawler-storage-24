"""
Version information for Oprel SDK
"""

__version__ = "0.4.2"
__author__ = "Oprel Team and Skyroot Solutions"
__email__ = "info@skyrootsolutions.com"
__url__ = "https://github.com/Skyroot-Solutions/Oprel"
__license__ = "MIT"
