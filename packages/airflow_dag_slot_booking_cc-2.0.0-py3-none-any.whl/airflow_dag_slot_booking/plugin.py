import json
import psycopg2
from flask import Blueprint, render_template, request, jsonify
from flask_login import current_user
from airflow.models import Variable, DagModel
from airflow.plugins_manager import AirflowPlugin
from airflow.settings import Session

dag_slot_bp = Blueprint(
    "dag_slot_booking",
    __name__,
    template_folder="templates",
)


@dag_slot_bp.record_once
def _exempt_from_csrf(state):
    csrf = state.app.extensions.get("csrf")
    if csrf:
        csrf.exempt(dag_slot_bp)


def _has_db_config():
    """Check if external DB config is available."""
    try:
        Variable.get("EXTRACTION_CONFIG", deserialize_json=True)
        return True
    except Exception:
        return False


def _get_db_conn():
    config = Variable.get("EXTRACTION_CONFIG", deserialize_json=True)
    return psycopg2.connect(
        host=config["DATABASE_HOST"],
        user=config["DATABASE_USER"],
        dbname=config["DATABASE_NAME"],
        password=config["DATABASE_PASSWORD"],
        port=config["DATABASE_PORT"],
    )


def _get_airflow_dags():
    """Read DAG schedules from Airflow's own metadata (no external DB needed)."""
    session = Session()
    try:
        dags = session.query(DagModel).filter(
            DagModel.is_active == True,
            DagModel.schedule_interval.isnot(None),
        ).all()
        result = []
        for dag in dags:
            cron = None
            schedule = dag.schedule_interval
            if isinstance(schedule, str):
                # Already a cron string
                parts = schedule.strip().split()
                if len(parts) == 5:
                    cron = schedule.strip()
            elif isinstance(schedule, dict):
                # Timetable dict — try to extract value
                cron = schedule.get("value") or schedule.get("__var")
                if cron and len(cron.strip().split()) != 5:
                    cron = None
            if cron:
                result.append({
                    "name": dag.dag_id,
                    "cron": cron,
                    "owner": dag.owners or "",
                    "cmd": "",
                    "type": "DAG",
                    "batch": "",
                })
        return result
    finally:
        session.close()


# -- GET main page ---
@dag_slot_bp.route("/dag_slot_booking", methods=["GET"])
def index():
    user_name = ""
    user_email = ""
    try:
        user_name = current_user.first_name or current_user.username or ""
        user_email = current_user.email or ""
    except Exception:
        pass

    db_mode = _has_db_config()
    return render_template("dag_slot_booking/index.html",
                           user_name=user_name, user_email=user_email,
                           db_mode=db_mode)


# -- GET all schedules ---
@dag_slot_bp.route("/dag_slot_booking/slots", methods=["GET"])
def get_slots():
    try:
        if _has_db_config():
            # DB mode — read from external database
            conn = _get_db_conn()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT "DAG_NAME", "SCHEDULE_TIME", "OWNER", "COMMAND_NAME", "TYPE", "BATCHES"
                FROM "TEST"."DAG_SCHEDULE_CONFIG"
                WHERE "IS_ACTIVE" = 'TRUE'
            """)
            rows = cursor.fetchall()
            cursor.close()
            conn.close()
            dags = [
                {
                    "name":  row[0],
                    "cron":  row[1],
                    "owner": row[2],
                    "cmd":   row[3],
                    "type":  row[4],
                    "batch": row[5],
                }
                for row in rows if row[1]
            ]
        else:
            # Default mode — read from Airflow metadata
            dags = _get_airflow_dags()

        return jsonify({"status": "ok", "dags": dags,
                        "mode": "db" if _has_db_config() else "airflow"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# -- POST book a slot (DB mode only) ---
@dag_slot_bp.route("/dag_slot_booking/book", methods=["POST"])
def book_slot():
    if not _has_db_config():
        return jsonify({"status": "error",
                        "message": "Booking requires database configuration. "
                                   "Set EXTRACTION_CONFIG Airflow Variable."}), 400
    try:
        data = request.get_json()
        dag_name = data.get("dag_name", "").strip()
        owner    = data.get("owner", "").strip()
        dag_type  = data.get("type", "Scrapy")
        cron      = data.get("cron", "")
        batch     = data.get("batch") or None
        cmd       = data.get("cmd")   or None
        selenium  = 'TRUE' if data.get("selenium") else ''

        if not dag_name or not owner or not cron:
            return jsonify({"status": "error", "message": "dag_name, owner and cron are required"}), 400

        MAX_DAGS_PER_SLOT = 5
        conn = _get_db_conn()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*) FROM "TEST"."DAG_SCHEDULE_CONFIG"
            WHERE "SCHEDULE_TIME" = %s AND "IS_ACTIVE" = 'TRUE'
        """, (cron,))
        count = cursor.fetchone()[0]
        if count >= MAX_DAGS_PER_SLOT:
            cursor.close()
            conn.close()
            return jsonify({"status": "error",
                            "message": f"Slot full — maximum {MAX_DAGS_PER_SLOT} DAGs per time slot"}), 400

        cursor.execute("""
            INSERT INTO "TEST"."DAG_SCHEDULE_CONFIG"
                ("DAG_NAME", "SELENIUM", "SCHEDULE_TIME", "BATCHES", "OWNER", "COMMAND_NAME", "TYPE", "IS_ACTIVE")
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (dag_name, selenium, cron, batch, owner, cmd, dag_type, 'TRUE'))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({"status": "ok", "message": f"{dag_name} booked successfully"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# -- GET available batches (DB mode only) ---
@dag_slot_bp.route("/dag_slot_booking/batches", methods=["GET"])
def get_batches():
    if not _has_db_config():
        return jsonify({"status": "ok", "batches": [], "next_batch": "batch_1"})
    try:
        conn = _get_db_conn()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT "BATCHES", COUNT(*) as cnt
            FROM "TEST"."DAG_SCHEDULE_CONFIG"
            WHERE "IS_ACTIVE" = 'TRUE'
              AND "BATCHES" IS NOT NULL
              AND "BATCHES" != ''
            GROUP BY "BATCHES"
            ORDER BY "BATCHES"
        """)
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

        MAX_PER_BATCH = 5
        batches = []
        max_num = 0
        for batch_name, count in rows:
            try:
                num = int(batch_name.rsplit('_', 1)[-1])
                if num > max_num:
                    max_num = num
            except (ValueError, IndexError):
                pass
            if count < MAX_PER_BATCH:
                batches.append({"name": batch_name, "count": count, "available": MAX_PER_BATCH - count})

        next_batch = f"batch_spider_{max_num + 1}"

        return jsonify({"status": "ok", "batches": batches, "next_batch": next_batch})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# -- Cancel a slot (DB mode only) ---
@dag_slot_bp.route("/dag_slot_booking/cancel", methods=["POST"])
def cancel_slot():
    if not _has_db_config():
        return jsonify({"status": "error",
                        "message": "Cancel requires database configuration."}), 400
    try:
        data = request.get_json()
        dag_name = data.get("dag_name", "").strip()
        conn = _get_db_conn()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE "TEST"."DAG_SCHEDULE_CONFIG"
            SET "IS_ACTIVE" = 'FALSE'
            WHERE "DAG_NAME" = %s
        """, (dag_name,))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({"status": "ok", "message": f"{dag_name} cancelled"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


class DagSlotBookingPlugin(AirflowPlugin):
    name = "dag_slot_booking"
    flask_blueprints = [dag_slot_bp]
