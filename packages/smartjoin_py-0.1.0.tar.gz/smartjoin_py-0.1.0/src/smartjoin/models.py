"""Typed models for analysis outputs and in-memory tables."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import polars as pl
from pydantic import BaseModel, Field


@dataclass(frozen=True)
class Table:
    """Standard internal table object used by analysis modules."""

    name: str
    df: pl.DataFrame
    path: Path
    metadata: dict[str, Any] = field(default_factory=dict)


class ColumnProfile(BaseModel):
    """Per-column profiling statistics."""

    name: str
    dtype: str
    null_pct: float = Field(ge=0.0, le=1.0)
    distinct_count: int = Field(ge=0)
    unique_ratio: float = Field(ge=0.0, le=1.0)
    near_unique: bool = False
    entropy: float = Field(ge=0.0)
    sample_values: list[Any]
    min_value: Any = None
    max_value: Any = None
    avg_length: float | None = Field(default=None, ge=0.0)
    min_length: int | None = Field(default=None, ge=0)
    max_length: int | None = Field(default=None, ge=0)


class TableProfile(BaseModel):
    """Per-table profile output."""

    table_name: str
    row_count: int = Field(ge=0)
    duplicate_row_count: int = Field(ge=0)
    duplicate_row_pct: float = Field(ge=0.0, le=1.0)
    candidate_unique_columns: list[str]
    near_unique_columns: list[str]
    columns: list[ColumnProfile]


class KeyCandidate(BaseModel):
    """Candidate key with supporting metrics."""

    table_name: str
    columns: list[str]
    uniqueness_ratio: float = Field(ge=0.0, le=1.0)
    null_row_pct: float = Field(ge=0.0, le=1.0)
    score: float = Field(ge=0.0, le=1.0)
    rationale: str


class TableKeyDiscovery(BaseModel):
    """Key discovery output per table."""

    table_name: str
    primary_key_candidates: list[KeyCandidate]
    composite_key_candidates: list[KeyCandidate]


class JoinScoreBreakdown(BaseModel):
    """Signal-level details for explainable join confidence."""

    signals: dict[str, float]
    weights: dict[str, float]
    weighted_score: float = Field(ge=0.0, le=1.0)


class DerivedTransform(BaseModel):
    """Metadata describing a deterministic derived-key transform."""

    transform_id: str
    params: dict[str, Any] = Field(default_factory=dict)
    description: str | None = None
    derived_from_table: str
    derived_from_column: str
    example_mappings: list[dict[str, str]] = Field(default_factory=list, max_length=3)
    notes: str | None = None


class JoinCandidate(BaseModel):
    """Join edge candidate between two columns."""

    left_table: str
    left_column: str
    right_table: str
    right_column: str
    confidence: float = Field(ge=0.0, le=1.0)
    relationship_guess: str
    breakdown: JoinScoreBreakdown
    derived: DerivedTransform | None = None


class AnalysisSettingsReport(BaseModel):
    """Settings snapshot used to generate a report."""

    min_confidence: float = Field(ge=0.0, le=1.0)
    retention_confidence_floor: float = Field(default=0.0, ge=0.0, le=1.0)
    sample_rows: int = Field(ge=1)
    sample_seed: int = Field(ge=0)
    distinct_low_card_threshold: int = Field(ge=1)
    near_unique_threshold: float = Field(ge=0.0, le=1.0)
    date_caps: dict[str, float]
    derived_joins_enabled: bool = True
    derived_max_transforms_per_column: int = Field(ge=1)
    derived_max_columns_per_table: int = Field(ge=1)
    derived_min_distinct: int = Field(ge=1)
    derived_max_ambiguous_targets: int = Field(ge=0)
    derived_conf_mult: float = Field(ge=0.0, le=1.0)


class AnalysisReport(BaseModel):
    """Top-level JSON report produced by `smartjoin analyze`."""

    source_path: str
    settings: AnalysisSettingsReport
    tables: list[TableProfile]
    keys: list[TableKeyDiscovery]
    joins: list[JoinCandidate]
