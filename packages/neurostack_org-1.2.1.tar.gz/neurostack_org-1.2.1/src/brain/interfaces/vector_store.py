"""
Abstract vector store interface.
"""

from typing import Protocol, List, Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class SearchResult:
    """Single search result from vector store"""
    id: str
    score: float  # Similarity score
    metadata: Dict[str, Any]  # Includes all KnowledgeMetadata fields
    content: str


class VectorStoreClient(Protocol):
    """
    Abstract interface for vector stores.
    
    Brain never depends on specific vector DB (Pinecone, Weaviate, etc.).
    """
    
    def search(
        self,
        query_embedding: List[float],
        top_k: int,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        Semantic search in vector store.
        
        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            filters: Optional metadata filters (e.g., tenant_id, visibility)
        
        Returns:
            Top-K results sorted by score (descending)
        
        Raises:
            Exception if search fails
        """
        ...