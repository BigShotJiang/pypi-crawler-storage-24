"""
Abstract LLM client interface.
"""

from typing import Protocol, List
from dataclasses import dataclass


@dataclass
class LLMMessage:
    """Single message for LLM"""
    role: str  # "user" | "assistant" | "system"
    content: str


@dataclass
class LLMResponse:
    """Response from LLM"""
    content: str
    tokens_used: int
    model: str


class LLMClient(Protocol):
    """
    Abstract interface for LLM clients.
    
    Brain never depends on specific LLM implementation.
    """
    
    def complete(
        self,
        messages: List[LLMMessage],
        max_tokens: int = 1000,
        temperature: float = 0.0
    ) -> LLMResponse:
        """
        Generate completion from messages.
        
        Args:
            messages: Conversation history
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0 = deterministic)
        
        Returns:
            LLM response
        
        Raises:
            Exception if LLM call fails (component should handle retry)
        """
        ...