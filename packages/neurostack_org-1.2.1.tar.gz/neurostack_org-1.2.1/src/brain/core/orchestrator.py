"""
Brain orchestrator (main coordinator).

Executes the full reasoning pipeline.
"""

from datetime import datetime, timezone

from ..models.request import ValidatedInput
from ..models.response import BrainResponse, AsyncJob, ResponseType
from ..models.intent import ResponseMode, Intent
from ..models.persona import UserContext
from .input_validator import InputValidator
from .intent_classifier import IntentClassifier
from .knowledge_retriever import KnowledgeRetriever
from .reasoning_engine import ReasoningEngine
from .response_formatter import ResponseFormatter
from ..logging.logger import get_logger
from ..logging.trace import QueryTrace, TraceLevel
from brain.utils.validation import ValidationError

class BrainOrchestrator:
    """
    Main brain coordinator.
    
    Executes the 5-stage reasoning pipeline.
    """
    
    def __init__(
        self,
        input_validator: InputValidator,
        intent_classifier: IntentClassifier,
        knowledge_retriever: KnowledgeRetriever,
        reasoning_engine: ReasoningEngine,
        response_formatter: ResponseFormatter
    ):
        """
        Initialize orchestrator.
        
        Args:
            input_validator: InputValidator component
            intent_classifier: IntentClassifier component
            knowledge_retriever: KnowledgeRetriever component
            reasoning_engine: ReasoningEngine component
            response_formatter: ResponseFormatter component
        """
        self.input_validator = input_validator
        self.intent_classifier = intent_classifier
        self.knowledge_retriever = knowledge_retriever
        self.reasoning_engine = reasoning_engine
        self.response_formatter = response_formatter
        self.logger = get_logger()
    
    def process(self, raw_request: dict) -> BrainResponse:
        """
        Main entry point. Executes full pipeline.
        
        Args:
            raw_request: Raw request dictionary
        
        Returns:
            BrainResponse
        """
        trace = None
        
        try:
            # Stage 1: Validate input
            validated_input = self.input_validator.validate(raw_request)
            
            # Initialize trace
            trace = QueryTrace(
                query_id=validated_input.query_id,
                tenant_id=validated_input.tenant_id,
                user_id=validated_input.user_id,
                persona=validated_input.persona.value,
                start_time=datetime.now(timezone.utc)
            )
            
            trace.add_event(
                TraceLevel.STAGE,
                stage="parse",
                component="InputValidator",
                event="Input validated"
            )
            
            # Stage 2: Classify intent
            user_context = self._build_user_context(validated_input)
            
            intent_classification = self.intent_classifier.classify(
                validated_input,
                user_context
            )
            
            trace.add_event(
                TraceLevel.STAGE,
                stage="classify",
                component="IntentClassifier",
                event=f"Intent classified: {intent_classification.intent.value}",
                data={"confidence": intent_classification.classification_confidence}
            )
            
            # Check if out of scope
            if intent_classification.intent == Intent.OUT_OF_SCOPE:
                return self._handle_out_of_scope(validated_input, intent_classification, trace)
            
            # Stage 3: Retrieve knowledge
            retrieval_result = self.knowledge_retriever.retrieve(
                query=validated_input.query,
                intent=intent_classification.intent,
                persona=validated_input.persona,
                user_context=user_context,
                retrieval_strategy=intent_classification.retrieval_strategy,
                live_context=validated_input.live_context,
                max_retrieval_depth=validated_input.options.max_retrieval_depth
            )
            
            trace.add_event(
                TraceLevel.STAGE,
                stage="retrieve",
                component="KnowledgeRetriever",
                event=f"Retrieved {len(retrieval_result.retrieved_knowledge)} sources",
                data={"confidence": retrieval_result.retrieval_confidence.value}
            )
            
            # Stage 4: Reason
            reasoning_result = self.reasoning_engine.reason(
                validated_input,
                intent_classification,
                retrieval_result,
                validated_input.persona
            )
            
            trace.add_event(
                TraceLevel.STAGE,
                stage="reason",
                component="ReasoningEngine",
                event="Reasoning complete",
                data={
                    "confidence": reasoning_result.answer.confidence.value if reasoning_result.answer else "N/A"
                }
            )
            
            # Stage 5: Format response
            response = self.response_formatter.format(
                query_id=validated_input.query_id,
                intent=intent_classification.intent,
                reasoning_result=reasoning_result,
                retrieval_result=retrieval_result,
                options=validated_input.options
            )
            
            trace.add_event(
                TraceLevel.STAGE,
                stage="format",
                component="ResponseFormatter",
                event=f"Response formatted: {response.response_type}"
            )
            
            # Finalize trace
            trace.finalize()
            self._log_trace(trace)
            
            return response
        
        except ValidationError:
    # Let tests (and callers) see validation failures
            raise

        except Exception as e:
            self.logger.error(
                "Pipeline execution failed",
                context={"error": str(e)},
                exc_info=True
            )
            
            if trace:
                trace.add_event(
                    TraceLevel.STAGE,
                    stage="error",  
                    component="BrainOrchestrator",
                    event=f"Pipeline failed: {str(e)}"
                )
                trace.finalize()
                self._log_trace(trace)
            
            # Return error response
            return self._error_response(
                str(e),
                query_id=validated_input.query_id if 'validated_input' in locals() else None
            )

    
    def _build_user_context(self, validated_input: ValidatedInput) -> UserContext:
        """Build user context from validated input"""
        # In real system, this would fetch user's teams from database
        # For now, simplified implementation
        return UserContext(
            user_id=validated_input.user_id,
            persona=validated_input.persona,
            teams=[],  # Would be populated from user profile
            managed_teams=[]  # Would be populated for managers
        )
    

    def _handle_out_of_scope(
        self,
        validated_input: ValidatedInput,
        intent_classification,
        trace: QueryTrace
    ) -> BrainResponse:
        """Handle out of scope request"""
        
        from ..models.response import Answer
        from ..models.confidence import AnswerConfidence
        
        trace.add_event(
            TraceLevel.STAGE,
            stage="classify",
            component="IntentClassifier",
            event="Request out of scope"
        )
        trace.finalize()
        self._log_trace(trace)
        
        return BrainResponse(
            query_id=validated_input.query_id,
            intent=Intent.OUT_OF_SCOPE,
            response_type=ResponseType.REFUSAL,
            message=intent_classification.refusal_reason or "This request exceeds your access level.",
            reason="exceeds_persona_scope",
            suggestions=["Ask your manager for assistance", "Focus on personal tasks"]
        )
    
    def _error_response(self, error_message: str, query_id: str | None = None) -> BrainResponse:
        """Create error response"""
        return BrainResponse(
            query_id=query_id or "error",
            intent=Intent.CLARIFICATION_REQUIRED,
            response_type=ResponseType.REFUSAL,
            message=f"An error occurred: {error_message}",
            reason="system_error"
        )

    
    def _log_trace(self, trace: QueryTrace) -> None:
        """Log query trace for audit"""
        self.logger.info(
            "Query trace",
            context={
                "query_id": trace.query_id,
                "duration_ms": trace.total_duration_ms,
                "events": len(trace.events)
            }
        )
        
        # In production, would also write to trace storage
        # For now, just log summary