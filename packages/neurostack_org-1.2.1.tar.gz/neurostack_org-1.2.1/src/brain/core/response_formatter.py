"""
Response formatter component (Stage 5).

Formats reasoning results into final output schema.
"""

from typing import List, Optional

from ..models.request import ValidatedInput, RequestOptions
from ..models.intent import Intent, IntentClassification
from ..models.retrieval import RetrievalResult
from ..models.response import (
    BrainResponse,
    ResponseType,
    Source,
    Conflict,
    Answer,
    Action
)
from ..models.confidence import AnswerConfidence
from ..logging.logger import get_logger
from typing import List, Dict, Optional, Any


class ResponseFormatter:
    """
    Formats reasoning results into final output.
    
    Pure logic, no external dependencies.
    """
    
    def __init__(self):
        """Initialize formatter"""
        self.logger = get_logger()
    
    def format(
        self,
        query_id: str,
        intent: Intent,
        reasoning_result,  # ReasoningResult
        retrieval_result: RetrievalResult,
        options: RequestOptions
    ) -> BrainResponse:
        """
        Format final response.
        
        Args:
            query_id: Query identifier
            intent: Classified intent
            reasoning_result: Result from reasoning engine
            retrieval_result: Result from retrieval
            options: Request options
        
        Returns:
            BrainResponse (final output)
        """
        self.logger.debug(
            "Formatting response",
            context={"query_id": query_id, "intent": intent.value}
        )
        
        # Determine response type
        if intent == Intent.OUT_OF_SCOPE:
            response_type = ResponseType.REFUSAL
        elif intent == Intent.CLARIFICATION_REQUIRED:
            response_type = ResponseType.CLARIFICATION
        elif intent == Intent.TASK_ACTION and reasoning_result.action:
            response_type = ResponseType.ACTION
        else:
            response_type = ResponseType.PROSE
        
        # Build response based on type
        if response_type == ResponseType.REFUSAL:
            return self._format_refusal(query_id, intent, reasoning_result)
        
        elif response_type == ResponseType.CLARIFICATION:
            return self._format_clarification(query_id, reasoning_result)
        
        elif response_type == ResponseType.ACTION:
            return self._format_action(
                query_id,
                intent,
                reasoning_result,
                retrieval_result,
                options
            )
        
        else:  # PROSE
            return self._format_prose(
                query_id,
                intent,
                reasoning_result,
                retrieval_result,
                options
            )
    
    def _format_prose(
        self,
        query_id: str,
        intent: Intent,
        reasoning_result,
        retrieval_result: RetrievalResult,
        options: RequestOptions
    ) -> BrainResponse:
        """Format prose response"""
        
        answer = reasoning_result.answer
        # SAFETY: ensure answer and content always exist
        if not answer or not answer.content:
            answer = Answer(
                content="I found some information, but it may be incomplete.",
                confidence=AnswerConfidence.UNCERTAIN
            )
            
        # Ensure live context is surfaced for status queries
        if (
            intent == Intent.STATUS_QUERY and
            retrieval_result.live_data and
            "task" not in answer.content.lower()
        ):
            answer.content += (
                "\n\nCurrent task status:\n"
                + str(retrieval_result.live_data)
            )
            

        
        # Determine if sources should be included
        include_sources = (
            options.require_sources or
            answer.confidence != AnswerConfidence.CERTAIN
        )
        
        # Build sources list
        sources = []
        if include_sources:
            sources = self._build_sources(
                retrieval_result.retrieved_knowledge,
                reasoning_result.sources_used
            )
        
        # Build conflicts list
        conflicts = self._build_conflicts(retrieval_result.conflicts)
        
        # Build warnings list
        warnings = retrieval_result.warnings + getattr(reasoning_result, "warnings", [])



        
        # Build suggestions (if confidence is low)
        suggestions = []
        if answer.confidence in [AnswerConfidence.UNCERTAIN, AnswerConfidence.UNKNOWN]:
            suggestions = self._generate_suggestions(intent, retrieval_result)
        
        return BrainResponse(
            query_id=query_id,
            intent=intent,
            response_type=ResponseType.PROSE,
            answer=answer,
            sources=sources,
            conflicts=conflicts,
            warnings=warnings,
            suggestions=suggestions,
            options=options
        )
    
    def _format_action(
        self,
        query_id: str,
        intent: Intent,
        reasoning_result,
        retrieval_result: RetrievalResult,
        options: RequestOptions
    ) -> BrainResponse:
        """Format action response"""
        
        action = reasoning_result.action
        explanation = reasoning_result.answer.content
        
        # Always include sources for actions (traceability)
        sources = self._build_sources(
            retrieval_result.retrieved_knowledge,
            reasoning_result.sources_used
        )
        
        return BrainResponse(
            query_id=query_id,
            intent=intent,
            response_type=ResponseType.ACTION,
            action=action,
            explanation=explanation,
            sources=sources,
            conflicts=[],
            warnings=[],
            suggestions=[]
        )
    
    def _format_refusal(
        self,
        query_id: str,
        intent: Intent,
        reasoning_result
    ) -> BrainResponse:
        """Format refusal response"""
        
        return BrainResponse(
            query_id=query_id,
            intent=intent,
            response_type=ResponseType.REFUSAL,
            message=reasoning_result.answer.content if reasoning_result.answer else "This request is out of scope.",
            reason="exceeds_persona_scope",
            suggestions=["Ask your manager for assistance", "Rephrase your question to focus on personal tasks"]
        )
    
    def _format_clarification(
        self,
        query_id: str,
        reasoning_result
    ) -> BrainResponse:
        """Format clarification response"""
        
        return BrainResponse(
            query_id=query_id,
            intent=Intent.CLARIFICATION_REQUIRED,
            response_type=ResponseType.CLARIFICATION,
            message=reasoning_result.answer.content if reasoning_result.answer else "I need more information to answer your question.",
            reason="ambiguous_query",
            suggestions=["Can you be more specific?", "Which project or task are you referring to?"]
        )
    
    def _build_sources(
        self,
        retrieved_knowledge: List,
        sources_used: List[str]
    ) -> List[Source]:
        """Build sources list"""
        sources = []
        
        # Filter to only used sources
        if sources_used:
            used_sources = [
                rs for rs in retrieved_knowledge
                if rs.source.id in sources_used
            ]
        else:
            used_sources = retrieved_knowledge[:5]

        # HARD SAFETY: if confidence != CERTAIN and no sources matched, still expose top-K
        if not used_sources and retrieved_knowledge:
            used_sources = retrieved_knowledge[:5]
  # Top 5 if no specific sources
        
        for rs in used_sources:
            source = rs.source
            sources.append(Source(
                knowledge_type=source.type.value,
                id=source.id,
                title=source.metadata.source,
                timestamp=source.metadata.timestamp,
                authority=source.metadata.authority.value,
                relevance_note=rs.reason_selected
            ))
        
        return sources
    
    def _build_conflicts(self, conflicts: List[Dict]) -> List[Conflict]:
        """Build conflicts list"""
        return [
            Conflict(
                description=c["description"],
                resolution=c["resolution"]
            )
            for c in conflicts
        ]
    
    def _generate_suggestions(
        self,
        intent: Intent,
        retrieval_result: RetrievalResult
    ) -> List[str]:
        """Generate helpful suggestions based on context"""
        suggestions = []
        
        if retrieval_result.retrieval_confidence.value == "low":
            suggestions.append("Try rephrasing your question with more specific terms")
        
        if "stale_data" in retrieval_result.warnings:
            suggestions.append("The information I found may be outdated. Check with your team for the latest.")
        
        if len(retrieval_result.retrieved_knowledge) == 0:
            suggestions.append("I couldn't find relevant information. This might be a new topic or not documented yet.")
        
        return suggestions