"""
Knowledge retrieval component (Stage 3).

Retrieves relevant knowledge from RAG and live context.
"""

from typing import List, Optional, Dict, Any

from ..models.request import ValidatedInput
from ..models.intent import Intent, RetrievalStrategy
from ..models.persona import Persona, UserContext
from neurostack.models import Knowledge
from ..models.retrieval import RetrievalResult, RankedSource
from ..models.confidence import RetrievalConfidence
from ..interfaces.vector_store import VectorStoreClient
from ..interfaces.embedding import EmbeddingClient
from ..config.retrieval_config import RetrieverConfig
from ..utils.ranking import rank_sources, filter_sources_by_persona, detect_conflicts
from ..utils.confidence import assess_retrieval_confidence
from ..utils.time import is_stale, get_default_staleness_thresholds
from ..logging.logger import get_logger


class KnowledgeRetriever:
    """
    Retrieves knowledge via RAG and live context.
    
    Handles retrieval, ranking, filtering, and conflict detection.
    """
    
    def __init__(
        self,
        vector_store: VectorStoreClient,
        embedding_client: EmbeddingClient,
        config: RetrieverConfig
    ):
        """
        Initialize retriever.
        
        Args:
            vector_store: Vector store client
            embedding_client: Embedding client
            config: Retrieval configuration
        """
        self.vector_store = vector_store
        self.embedding_client = embedding_client
        self.config = config
        self.logger = get_logger()
        self.staleness_thresholds = get_default_staleness_thresholds()
    
    def retrieve(
        self,
        query: str,
        intent: Intent,
        persona: Persona,
        user_context: UserContext,
        retrieval_strategy: RetrievalStrategy,
        live_context: Optional[Dict[str, Any]],
        max_retrieval_depth: Optional[int] = None
    ) -> RetrievalResult:
        """
        Retrieve relevant knowledge.
        
        Args:
            query: User query
            intent: Classified intent
            persona: User persona
            user_context: User context (for filtering)
            retrieval_strategy: How to retrieve (RAG/live/hybrid/none)
            live_context: Current state data
            max_retrieval_depth: Soft hint for top-K (can be overridden)
        
        Returns:
            RetrievalResult with sources, confidence, conflicts
        """
        self.logger.debug(
            "Starting knowledge retrieval",
            context={"strategy": retrieval_strategy.value}
        )
        
        retrieved_knowledge = []
        live_data = None
        warnings = []
        
        # Step 1: RAG retrieval (if needed)
        if retrieval_strategy in [RetrievalStrategy.RAG_ONLY, RetrievalStrategy.HYBRID]:
            retrieved_knowledge = self._retrieve_from_rag(
                query,
                persona,
                user_context,
                max_retrieval_depth
            )
        # if retrieval_strategy == RetrievalStrategy.RAG_ONLY:
        #     return RetrievalResult(
        #         retrieved_knowledge=retrieved_knowledge,
        #         live_data=None,
        #         retrieval_confidence=(
        #             RetrievalConfidence.HIGH
        #             if retrieved_knowledge
        #             else RetrievalConfidence.LOW
        #         ),
        #         conflicts=[],
        #         warnings=[]
        #     )

        
        # Step 2: Live context extraction (if needed)
        if retrieval_strategy in [RetrievalStrategy.LIVE_ONLY, RetrievalStrategy.HYBRID]:
            live_data = self._extract_live_context(live_context, intent)
        
        # Step 3: Assess retrieval confidence
        retrieval_confidence = assess_retrieval_confidence(
            retrieved_knowledge,
            self.config.strong_threshold,
            self.config.acceptable_threshold,
            self.config.dominance_gap
        )
        
        # Step 4: Detect conflicts
        conflicts = detect_conflicts(retrieved_knowledge)
        
        # Step 5: Check for stale data
        stale_sources = self._check_staleness(retrieved_knowledge)
        if stale_sources:
            warnings.append("stale_data")
        
        # Step 6: Build result
        result = RetrievalResult(
            retrieved_knowledge=retrieved_knowledge,
            live_data=live_data,
            retrieval_confidence=retrieval_confidence,
            conflicts=[{"description": c["description"], "resolution": c["resolution"]} for c in conflicts],
            warnings=warnings
        )
        
        self.logger.info(
            "Knowledge retrieval complete",
            context={
                "num_sources": len(retrieved_knowledge),
                "confidence": retrieval_confidence.value,
                "has_live_data": live_data is not None,
                "conflicts": len(conflicts)
            }
        )
        
        return result
    
    def _retrieve_from_rag(
        self,
        query: str,
        persona: Persona,
        user_context: UserContext,
        max_retrieval_depth: Optional[int]
    ) -> List[RankedSource]:
        """Retrieve from RAG (vector store)"""
        
        if not isinstance(persona, Persona):
             raise TypeError(f"Expected Persona enum, got {type(persona)}")



        top_k = max_retrieval_depth if max_retrieval_depth else self.config.default_top_k
        top_k = min(top_k, self.config.max_top_k)  # Hard cap
        
        try:
            # Step 1: Generate query embedding
            query_embedding = self.embedding_client.embed(query)
            
            # Step 2: Build permission filters (tenant isolation + user access)
            filters = {}
            if hasattr(user_context, 'tenant_id') and user_context.tenant_id:
                filters["tenant_id"] = user_context.tenant_id
            if user_context.user_id:
                filters["user_id"] = user_context.user_id
            if user_context.teams:
                filters["team_ids"] = user_context.teams

            # Step 3: Search vector store
            search_results = self.vector_store.search(
                query_embedding=query_embedding,
                top_k=top_k * 2,  # Retrieve more, filter later
                filters=filters
            )
            
            # Step 4: Convert to Knowledge objects
            knowledge_objects = []
            similarity_scores = []
            
            for result in search_results:
                # Reconstruct Knowledge from search result
                # (In real system, metadata would include all Knowledge fields)
                knowledge = self._reconstruct_knowledge(result)
                knowledge_objects.append(knowledge)
                similarity_scores.append(result.score)
            
            # Step 5: Rank sources
            from ..utils.time import get_default_decay_rates
            ranked = rank_sources(
                knowledge_objects,
                similarity_scores,
                self.config.authority_weights,
                self.config.recency_boost_factor,
                get_default_decay_rates()
            )
            
            # Step 6: Filter by persona
            ranked = filter_sources_by_persona(ranked, persona, user_context)
            
            # Step 7: Return top-K after filtering
            return ranked[:top_k]
        
        except RuntimeError as e:
            self.logger.error(
                "RAG retrieval failed",
                context={"error": str(e)},
                exc_info=True
            )
            return []
    
    def _reconstruct_knowledge(self, search_result) -> Knowledge:
        """Reconstruct Knowledge object from search result"""
        from neurostack.models import Knowledge, KnowledgeType, KnowledgeMetadata, Authority, Visibility
        from datetime import datetime, timezone
        
        # Extract from metadata
        metadata = search_result.metadata
        
        return Knowledge(
            id=search_result.id,
            type=KnowledgeType(metadata.get("type", "document")),
            content=search_result.content,
            metadata=KnowledgeMetadata(
                timestamp=datetime.fromisoformat(metadata.get("timestamp", datetime.now(timezone.utc).isoformat())),
                source=metadata.get("source", "unknown"),
                tenant_id=metadata.get("tenant_id", ""),
                authority=Authority(metadata.get("authority", "medium")),
                visibility=Visibility(metadata.get("visibility", "public")),
                owner=metadata.get("owner"),
                team_id=metadata.get("team_id")
            )
        )
    
    def _extract_live_context(
        self,
        live_context: Optional[Dict[str, Any]],
        intent: Intent
    ) -> Optional[Dict[str, Any]]:
        """Extract relevant live context based on intent"""
        if not live_context:
            return None
        
        # Filter live context by intent
        # For status queries, extract current task states
        if intent == Intent.STATUS_QUERY:
            return live_context.get("tasks", {})
        
        # For metrics queries, extract current metrics
        if intent == Intent.METRICS_QUERY:
            return live_context.get("metrics", {})
        
        # For planning, extract tasks + metrics
        if intent == Intent.PLANNING_REQUEST:
            return {
                "tasks": live_context.get("tasks", {}),
                "metrics": live_context.get("metrics", {})
            }
        
        # For actions, extract tasks
        if intent == Intent.TASK_ACTION:
            return live_context.get("tasks", {})
        
        return live_context
    
    def _check_staleness(self, sources: List[RankedSource]) -> List[str]:
        """Check for stale sources, return list of stale source IDs"""
        stale = []
        for rs in sources:
            if is_stale(
                rs.source.metadata.timestamp,
                rs.source.type,
                self.staleness_thresholds
            ):
                stale.append(rs.source.id)
        return stale