from dataclasses import dataclass, field
from typing import Dict


@dataclass
class RetrieverConfig:
    """Retrieval configuration"""
    
    # Retrieval depth
    default_top_k: int = 5
    max_top_k: int = 20  # hard cap
    
    # Confidence thresholds (relative)
    strong_threshold: float = 0.75
    acceptable_threshold: float = 0.60
    dominance_gap: float = 0.15
    recency_boost_factor: float = 0.1
    # Authority weights
    authority_weights: dict = field(default_factory=lambda: {
        "high": 1.2,
        "medium": 1.0,
        "low": 0.8
    })