"""
Persona configuration and rules.
"""

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class PersonaConfig:
    """Configuration for persona enforcement"""
    
    # Employee restrictions
    employee_allowed_scopes: List[str] = field(default_factory=lambda: [
        "personal",
        "public"
    ])
    
    employee_forbidden_intents: List[str] = field(default_factory=lambda: [
        "metrics_query",  # When scope = team
        "planning_request"  # When scope = team
    ])
    
    # Manager permissions
    manager_allowed_scopes: List[str] = field(default_factory=lambda: [
        "personal",
        "public",
        "team"
    ])
    
    # Ethical constraints (apply to all personas)
    forbidden_query_patterns: List[str] = field(default_factory=lambda: [
        "performance_comparison",  # "Who is slower, Alice or Bob?"
        "surveillance_tracking",   # "How many hours did X work?"
        "punitive_metrics"         # "Show me underperformers"
    ])
    
    # Scope detection keywords
    team_scope_keywords: List[str] = field(default_factory=lambda: [
        "team", "our", "we", "everyone", "all", "group"
    ])
    
    personal_scope_keywords: List[str] = field(default_factory=lambda: [
        "my", "I", "me", "mine"
    ])
    
    @classmethod
    def from_dict(cls, data: dict) -> "PersonaConfig":
        """Create from dictionary"""
        return cls(**data)