"""
Main brain configuration.

Dataclasses are source of truth. YAML loading is optional convenience.
"""

from dataclasses import dataclass, field
from typing import Dict, Optional
import yaml

from .retrieval_config import RetrieverConfig
from .confidence_config import ConfidenceConfig
from .persona_config import PersonaConfig


@dataclass
class LLMSettings:
    """LLM client settings"""
    model: str = "claude-sonnet-4-20250514"
    temperature: float = 0.0
    max_tokens: int = 1000
    timeout_seconds: int = 30


@dataclass
class ConversationSettings:
    """Conversation management settings"""
    max_history_turns: int = 5  # Last N turns to include
    max_history_tokens: int = 2000  # Approximate token budget for history




@dataclass
class BrainConfig:
    """
    Main brain configuration.
    
    All components receive config from this root object.
    """
    
    # Component configs
    llm: LLMSettings = field(default_factory=LLMSettings)
    retrieval: RetrieverConfig = field(default_factory=RetrieverConfig)
    confidence: ConfidenceConfig = field(default_factory=ConfidenceConfig)
    persona: PersonaConfig = field(default_factory=PersonaConfig)
    conversation: ConversationSettings = field(default_factory=ConversationSettings)
    
    @classmethod
    def default(cls) -> "BrainConfig":
        """Create config with all defaults"""
        return cls()
    
    @classmethod
    def from_yaml(cls, path: str) -> "BrainConfig":
        """
        Load config from YAML file.
        
        YAML structure should mirror dataclass hierarchy.
        """
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
        
        return cls(
            llm=LLMSettings(**data.get('llm', {})),
            retrieval=RetrieverConfig.from_dict(data.get('retrieval', {})),
            confidence=ConfidenceConfig.from_dict(data.get('confidence', {})),
            persona=PersonaConfig.from_dict(data.get('persona', {})),
            conversation=ConversationSettings(**data.get('conversation', {}))
        )
    
    def to_yaml(self, path: str) -> None:
        """Export config to YAML file"""
        # Implementation for config export
        pass