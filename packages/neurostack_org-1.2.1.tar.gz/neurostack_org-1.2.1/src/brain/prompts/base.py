"""
Base prompt templates.

All prompts are Python strings, not external files.
"""

from typing import Dict
from ..models.persona import Persona
from ..models.intent import Intent


BASE_SYSTEM_PROMPT = """You are an AI brain reasoning over company knowledge.

You are embedded in an enterprise system and serve {persona} users.

Your role is to:
- Answer questions based on provided sources
- Ground all answers in evidence
- Indicate confidence explicitly
- Admit uncertainty when appropriate
- Never invent facts not present in sources

STRICT RULES:
1. Only reference knowledge visible to this persona
2. If answer requires out-of-scope data, refuse politely
3. Prefer newer information when conflicts arise
4. If confidence is less than certain, explain why
5. If information is stale, warn the user
6. Never make up information

{persona_instructions}

{intent_instructions}
"""


PERSONA_EMPLOYEE_INSTRUCTIONS = """
PERSONA: Employee (Individual Contributor)

Scope:
- You can answer questions about personal tasks, team decisions, and company policies
- You CANNOT provide team-level analytics or compare individuals
- Focus on actionable information for this specific employee

Response style:
- Clear and concise
- Focus on "what should I do next?"
- Avoid team-level context unless directly relevant
"""


PERSONA_MANAGER_INSTRUCTIONS = """
PERSONA: Manager (Team Lead)

Scope:
- You can answer questions about personal tasks, team analytics, and planning
- You can provide team-level insights and workload analysis
- You can see task status for your team members
- You CANNOT provide punitive comparisons or surveillance-style tracking

Response style:
- Include team context when relevant
- Surface risks and blockers proactively
- Focus on team health and actionability
- Consider workload balance in recommendations
"""


def build_system_prompt(
    persona: Persona,
    intent: Intent,
    intent_instructions: str
) -> str:
    """
    Build complete system prompt.
    
    Args:
        persona: User persona
        intent: Classified intent
        intent_instructions: Intent-specific instructions
    
    Returns:
        Complete system prompt
    """
    # Select persona instructions
    if persona == Persona.EMPLOYEE:
        persona_instructions = PERSONA_EMPLOYEE_INSTRUCTIONS
    else:
        persona_instructions = PERSONA_MANAGER_INSTRUCTIONS
    
    # Build final prompt
    return BASE_SYSTEM_PROMPT.format(
        persona=persona.value,
        persona_instructions=persona_instructions,
        intent_instructions=intent_instructions
    )


def build_user_prompt(
    query: str,
    sources: str,
    live_context: str = "",
    conversation_history: str = ""
) -> str:
    """
    Build user prompt with query and context.
    
    Args:
        query: User's question
        sources: Retrieved sources (formatted)
        live_context: Live context data (formatted)
        conversation_history: Recent conversation (formatted)
    
    Returns:
        Complete user prompt
    """
    parts = []
    
    if conversation_history:
        parts.append(f"CONVERSATION HISTORY:\n{conversation_history}\n")
    
    if sources:
        parts.append(f"RETRIEVED KNOWLEDGE:\n{sources}\n")
    
    if live_context:
        parts.append(f"CURRENT STATE:\n{live_context}\n")
    
    parts.append(f"USER QUERY:\n{query}")
    
    return "\n".join(parts)