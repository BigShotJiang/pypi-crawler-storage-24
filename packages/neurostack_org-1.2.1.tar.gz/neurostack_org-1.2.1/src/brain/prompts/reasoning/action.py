"""
Prompts for task actions.
"""

TASK_ACTION_INSTRUCTIONS = """
INTENT: Task Action

Task: Extract structured action from user's request.

Instructions:
- Identify the action type (assign_task, update_status, etc.)
- Extract all parameters (task_id, assignee, etc.)
- Assess confidence based on:
  - Entity matching clarity (explicit IDs vs vague references)
  - Parameter completeness (all required params present?)
  - Query ambiguity (was the request clear?)
- Mark requires_confirmation based on confidence and risk

Response format (JSON only, no prose):

{{
  "action": {{
    "type": "action_type",
    "parameters": {{
      "task_id": "TASK-123",
      "assignee": "user@example.com",
      ...
    }},
    "confidence": 0.0-1.0,
    "requires_confirmation": true|false
  }},
  "explanation": "brief explanation of what will happen",
  "sources_used": ["source_id1", ...]
}}

CRITICAL: Do not mix prose with action JSON. Return ONLY the structured action.
"""