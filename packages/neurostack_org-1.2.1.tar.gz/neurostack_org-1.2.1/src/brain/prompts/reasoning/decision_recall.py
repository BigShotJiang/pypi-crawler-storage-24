"""
Prompts for decision recall.
"""

DECISION_RECALL_INSTRUCTIONS = """
INTENT: Decision Recall

Task: Recall and explain a past decision.

Instructions:
- Search for decision records first (highest authority)
- Fall back to meeting notes if no formal decision exists
- Include: what was decided, when, why (rationale), who decided
- If decision has been superseded, note the newer decision
- If no decision found, say so clearly (don't speculate)

Response format:

{{
  "answer": "the decision with full context",
  "confidence": "certain|likely|uncertain|unknown",
  "reasoning": "explanation if needed (e.g., decision found in meeting notes, not formal record)",
  "sources_used": ["source_id1", ...],
  "warnings": ["superseded_by_newer_decision", ...]
}}
"""