"""
Visibility check — moved from Knowledge.is_visible_to().
"""

from neurostack.models import Knowledge, Visibility
from ..models.persona import Persona, UserContext


def is_visible_to(knowledge: Knowledge, persona: Persona, user_context: UserContext) -> bool:
    if knowledge.metadata.visibility == Visibility.PUBLIC:
        return True
    if knowledge.metadata.visibility == Visibility.PRIVATE:
        return knowledge.metadata.owner == user_context.user_id
    if knowledge.metadata.visibility == Visibility.TEAM:
        if persona == Persona.MANAGER:
            return knowledge.metadata.team_id in user_context.managed_teams
        return knowledge.metadata.team_id in user_context.teams
    return False