"""
Source ranking utilities.

Pure functions for ranking and filtering retrieved sources.
"""

from typing import List, Dict
from datetime import datetime

from ..models.retrieval import RankedSource
from neurostack.models import Knowledge
from .time import calculate_recency_score
from .visibility import is_visible_to
from brain.models.persona import Persona, UserContext


def rank_sources(
    sources: List[Knowledge],
    similarity_scores: List[float],
    authority_weights: Dict[str, float],
    recency_boost_factor: float,
    decay_rates: Dict
) -> List[RankedSource]:
    """
    Rank sources by combined score.
    
    Combined score = similarity * authority_weight * (1 + recency_boost)
    
    Args:
        sources: Retrieved knowledge objects
        similarity_scores: Raw similarity scores from vector search
        authority_weights: Weight multipliers per authority level
        recency_boost_factor: Maximum boost for very recent items
        decay_rates: Decay rates for recency scoring
    
    Returns:
        Ranked sources (highest score first)
    """
    ranked = []
    
    for i, (source, sim_score) in enumerate(zip(sources, similarity_scores)):
        # Get authority weight
        auth_str = source.metadata.authority.value
        auth_weight = authority_weights.get(auth_str, 1.0)
        
        # Calculate recency score
        recency_score = calculate_recency_score(
            source.metadata.timestamp,
            source.type,
            decay_rates
        )
        
        # Calculate recency boost (0.0 to recency_boost_factor)
        recency_boost = recency_score * recency_boost_factor
        
        # Combined score
        combined_score = sim_score * auth_weight * (1.0 + recency_boost)
        
        # Determine reason selected
        reason = _determine_selection_reason(
            sim_score, auth_weight, recency_score, recency_boost_factor
        )
        
        ranked.append(RankedSource(
            source=source,
            score=combined_score,
            rank=i + 1,  # Will be reordered after sorting
            reason_selected=reason
        ))
    
    # Sort by combined score (descending)
    ranked.sort(key=lambda x: x.score, reverse=True)
    
    # Update ranks after sorting
    for i, rs in enumerate(ranked):
        rs.rank = i + 1
    
    return ranked


def _determine_selection_reason(
    similarity: float,
    authority_weight: float,
    recency: float,
    recency_boost_factor: float
) -> str:
    """
    Determine primary reason for source selection.
    
    Args:
        similarity: Raw similarity score
        authority_weight: Authority weight applied
        recency: Recency score (0.0 to 1.0)
        recency_boost_factor: Max recency boost
    
    Returns:
        Reason string: "high_authority" | "recent" | "relevant"
    """
    # High authority if weight significantly above 1.0
    if authority_weight >= 1.15:
        return "high_authority"
    
    # Recent if recency contributes significantly
    recency_contribution = recency * recency_boost_factor
    if recency_contribution > 0.05 and recency > 0.8:
        return "recent"
    
    # Default to relevant (similarity-based)
    return "relevant"


def filter_sources_by_persona(
    sources: List[RankedSource],
    persona: Persona,
    user_context: UserContext
) -> List[RankedSource]:
    """
    Filter sources based on persona visibility rules.
    
    Args:
        sources: Ranked sources
        persona: User persona
        user_context: User context (teams, etc.)
    
    Returns:
        Filtered sources (only visible to persona)
    """
    return [
        rs for rs in sources
        if is_visible_to(rs.source, persona, user_context)
    ]


def detect_conflicts(
    sources: List[RankedSource],
    similarity_threshold: float = 0.7
) -> List[Dict[str, str]]:
    """
    Detect conflicting information in sources.
    
    Conflicts are detected when:
    - Sources have similar semantic content (high similarity)
    - But different timestamps or contradictory statements
    
    This is a simplified heuristic. Real conflict detection would need
    deeper semantic analysis.
    
    Args:
        sources: Ranked sources
        similarity_threshold: Threshold for considering sources similar
    
    Returns:
        List of detected conflicts with descriptions
    """
    conflicts = []
    
    # Simple heuristic: if top sources have very different timestamps
    # but similar content, flag as potential conflict
    
    if len(sources) < 2:
        return conflicts
    
    # Compare top sources
    for i in range(len(sources) - 1):
        source_a = sources[i].source
        source_b = sources[i + 1].source
        
        # If both scores are close (similar relevance)
        score_diff = abs(sources[i].score - sources[i + 1].score)
        if score_diff < 0.1:  # Close scores
            # Check timestamp difference
            time_diff = abs(
                (source_a.metadata.timestamp - source_b.metadata.timestamp).days
            )
            
            # If timestamps are far apart (>90 days), potential conflict
            if time_diff > 90:
                conflicts.append({
                    "description": (
                        f"Sources from different times: "
                        f"{source_a.metadata.source} ({source_a.metadata.timestamp.strftime('%Y-%m-%d')}) "
                        f"vs {source_b.metadata.source} ({source_b.metadata.timestamp.strftime('%Y-%m-%d')})"
                    ),
                    "resolution": "preferred_newer"
                })
                break  # Only report first conflict
    
    return conflicts