"""
Persona definitions and scope rules.
"""

from dataclasses import dataclass
from enum import Enum
from typing import List


class Persona(Enum):
    """User persona types"""
    EMPLOYEE = "employee"
    MANAGER = "manager"


class ScopeCheck(Enum):
    """Result of persona scope validation"""
    ALLOWED = "allowed"
    OUT_OF_SCOPE = "out_of_scope"


@dataclass
class UserContext:
    """User context for persona enforcement"""
    user_id: str
    persona: Persona
    teams: List[str]  # Teams user is member of
    managed_teams: List[str]  # Teams user manages (empty for employees)


@dataclass
class QueryScope:
    """Detected scope of a query"""
    level: str  # "personal" | "team" | "multi_team" | "company"
    mentions_users: List[str]  # User IDs mentioned in query
    mentions_teams: List[str]  # Team IDs mentioned in query
    requires_analytics: bool  # Does query ask for metrics/aggregations?