"""
Intent classification models.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
from .persona import ScopeCheck, QueryScope


class Intent(Enum):
    """Query intent types"""
    INFORMATIONAL_QUERY = "informational_query"
    STATUS_QUERY = "status_query"
    METRICS_QUERY = "metrics_query"
    SUMMARY_REQUEST = "summary_request"
    PLANNING_REQUEST = "planning_request"
    TASK_ACTION = "task_action"
    DECISION_RECALL = "decision_recall"
    CLARIFICATION_REQUIRED = "clarification_required"
    OUT_OF_SCOPE = "out_of_scope"


class RetrievalStrategy(Enum):
    """How to retrieve knowledge"""
    RAG_ONLY = "rag_only"          # Historical memory only
    LIVE_ONLY = "live_only"        # Current state only
    HYBRID = "hybrid"              # Both RAG + live
    NONE = "none"                  # No retrieval needed


class ResponseMode(Enum):
    """Sync vs async execution"""
    SYNC = "sync"
    ASYNC = "async"


@dataclass
class IntentClassification:
    """Result of intent classification"""
    intent: Intent
    retrieval_strategy: RetrievalStrategy
    response_mode: ResponseMode
    persona_check: ScopeCheck
    classification_confidence: float  # 0.0 to 1.0
    query_scope: QueryScope
    refusal_reason: Optional[str] = None