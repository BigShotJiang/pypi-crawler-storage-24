"""
Shared logging configuration for the Neurostack SDK.
"""

import logging
import sys


def get_logger(name: str = "neurostack") -> logging.Logger:
    return logging.getLogger(name)


def configure_logging(
    level: int = logging.INFO,
    format_string: str = "%(asctime)s [%(name)s] %(levelname)s: %(message)s",
):
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(format_string))
    root = logging.getLogger("neurostack")
    root.setLevel(level)
    if not root.handlers:
        root.addHandler(handler)