"""
Shared permission models.

Used by Pipeline (storage) and Brain (querying).
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any


class VisibilityScope(Enum):
    PUBLIC = "public"
    TEAM = "team"
    PRIVATE = "private"
    RESTRICTED = "restricted"


class PermissionChangeType(Enum):
    GRANTED = "granted"
    REVOKED = "revoked"
    UPDATED = "updated"


@dataclass
class RawPermission:
    """Raw permission data from source system. Ground truth."""
    content_id: str
    source_type: str
    source_id: str
    raw_data: Dict[str, Any]
    extracted_at: datetime
    source_url: Optional[str] = None
    extractor_version: str = "1.0"


@dataclass
class IndexedVisibility:
    """Computed visibility for fast filtering."""
    content_id: str
    scope: VisibilityScope
    user_ids: List[str] = field(default_factory=list)
    team_ids: List[str] = field(default_factory=list)
    role_ids: List[str] = field(default_factory=list)
    excluded_user_ids: List[str] = field(default_factory=list)
    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    derived_from: str = ""
    expires_at: Optional[datetime] = None

    def is_visible_to_user(self, user_id: str, user_teams: List[str]) -> bool:
        if self.expires_at and datetime.now(timezone.utc) > self.expires_at:
            return False
        if user_id in self.excluded_user_ids:
            return False
        if self.scope == VisibilityScope.PUBLIC:
            return True
        if user_id in self.user_ids:
            return True
        if self.scope == VisibilityScope.TEAM:
            return any(t in self.team_ids for t in user_teams)
        if self.scope == VisibilityScope.PRIVATE:
            return user_id in self.user_ids
        return False


@dataclass
class PermissionRecord:
    id: str
    content_id: str
    tenant_id: str
    raw: RawPermission
    indexed: IndexedVisibility
    version: int = 1
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    created_by: str = "pipeline"
    last_synced_at: Optional[datetime] = None


@dataclass
class PermissionChangeEvent:
    event_id: str
    content_id: str
    change_type: PermissionChangeType
    affected_user_ids: List[str] = field(default_factory=list)
    affected_team_ids: List[str] = field(default_factory=list)
    source_type: str = ""
    reason: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    detected_by: str = "permission_sync"


@dataclass
class PermissionSyncJob:
    job_id: str
    tenant_id: str
    source_type: str
    status: str = "pending"
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    items_checked: int = 0
    permissions_updated: int = 0
    permissions_revoked: int = 0
    errors: int = 0
    last_cursor: Optional[str] = None
    error_messages: List[str] = field(default_factory=list)


@dataclass
class PermissionQuery:
    tenant_id: str
    user_id: str
    user_teams: List[str] = field(default_factory=list)
    knowledge_types: Optional[List[str]] = None
    source_types: Optional[List[str]] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    scope_filter: Optional[str] = None