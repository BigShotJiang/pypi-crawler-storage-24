"""
Shared knowledge models.

Used by both Brain and Pipeline. Single source of truth.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class KnowledgeType(Enum):
    """Types of knowledge the system can reason over"""
    DOCUMENT = "document"
    TASK = "task"
    MEETING = "meeting"
    DECISION = "decision"
    METRIC = "metric"
    EVENT = "event"
    FACT = "fact"


class Authority(Enum):
    """Authority level of knowledge source"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Visibility(Enum):
    """Visibility scope"""
    PUBLIC = "public"
    TEAM = "team"
    PRIVATE = "private"


@dataclass
class KnowledgeMetadata:
    """Common metadata for all knowledge objects"""
    timestamp: datetime
    source: str
    tenant_id: str
    authority: Authority
    visibility: Visibility
    owner: Optional[str] = None
    team_id: Optional[str] = None
    recency_score: Optional[float] = None


@dataclass
class Knowledge:
    """
    Single piece of knowledge.

    Used by Pipeline (storage) and Brain (reasoning).
    """
    id: str
    type: KnowledgeType
    content: str
    metadata: KnowledgeMetadata