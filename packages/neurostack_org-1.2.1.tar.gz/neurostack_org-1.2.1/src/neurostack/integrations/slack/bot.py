"""
Slack bot integration for Neurostack.

Uses slack_bolt for event handling and slack_sdk for API calls.
Both are optional dependencies — import failures are caught gracefully
so the rest of the SDK can load without them.
"""

import logging
from typing import Any, Optional

from ..base import BotIntegration, BotResponse
from .formatters import SlackFormatter

logger = logging.getLogger("neurostack.integrations.slack.bot")

try:
    from slack_bolt import App as BoltApp
    from slack_bolt.adapter.fastapi import SlackRequestHandler
    from slack_sdk import WebClient

    HAS_SLACK = True
except ImportError:
    HAS_SLACK = False
    logger.debug(
        "slack_bolt / slack_sdk not installed. "
        "Install with: pip install slack_bolt slack_sdk"
    )

# Default tenant / persona used when we cannot resolve a Slack user
_DEFAULT_TENANT = "default"
_DEFAULT_PERSONA = "employee"


class SlackBot(BotIntegration):
    """
    Slack integration built on top of Bolt for Python.

    Args:
        signing_secret: Slack app signing secret (for request verification).
        bot_token: Slack Bot User OAuth token (xoxb-...).
        brain_manager: The BrainManager singleton from the backend.
    """

    def __init__(
        self,
        signing_secret: str,
        bot_token: str,
        brain_manager: Any,
    ) -> None:
        if not HAS_SLACK:
            raise RuntimeError(
                "slack_bolt and slack_sdk are required for the Slack integration. "
                "Install them with: pip install slack_bolt slack_sdk"
            )

        self.brain_manager = brain_manager
        self.signing_secret = signing_secret
        self.bot_token = bot_token

        # Bolt application
        self.app = BoltApp(
            signing_secret=signing_secret,
            token=bot_token,
        )
        self.client: WebClient = self.app.client
        self.handler = SlackRequestHandler(self.app)

        # Register event listeners
        self._register_events()

        # In-memory user cache {slack_user_id -> resolved identity}
        self._user_cache: dict[str, dict] = {}

        logger.info("SlackBot initialized")

    # ------------------------------------------------------------------
    # Event registration
    # ------------------------------------------------------------------

    def _register_events(self) -> None:
        """Wire up Bolt event listeners and slash commands."""

        # Direct messages
        @self.app.event("message")
        def _on_message(event: dict, say: Any) -> None:
            self._handle_message_event(event, say)

        # @mentions in channels
        @self.app.event("app_mention")
        def _on_mention(event: dict, say: Any) -> None:
            self._handle_message_event(event, say)

        # Import command handlers and register them
        from .commands import handle_ask, handle_status, handle_help

        @self.app.command("/neurostack")
        def _on_slash(ack: Any, command: dict, say: Any) -> None:
            """Route /neurostack subcommands."""
            text = (command.get("text") or "").strip()
            subcommand = text.split()[0].lower() if text else "help"

            if subcommand == "ask":
                handle_ask(ack, command, say, self.brain_manager, self)
            elif subcommand == "status":
                handle_status(ack, command, say, self.brain_manager)
            elif subcommand == "help":
                handle_help(ack, command, say)
            else:
                handle_help(ack, command, say)

        logger.info("Slack event handlers registered")

    # ------------------------------------------------------------------
    # Core message handling
    # ------------------------------------------------------------------

    def _handle_message_event(self, event: dict, say: Any) -> None:
        """
        Internal handler for both DMs and @mentions.

        Extracts user info, resolves identity, calls the Brain, and
        posts the formatted response back into the thread.
        """
        slack_user_id = event.get("user", "")
        text = event.get("text", "").strip()
        channel_id = event.get("channel", "")
        thread_ts = event.get("thread_ts") or event.get("ts")

        # Ignore bot's own messages and empty text
        if event.get("bot_id") or not text:
            return

        # Strip the bot mention prefix (e.g. "<@U12345> question")
        if text.startswith("<@"):
            text = text.split(">", 1)[-1].strip()

        if not text:
            return

        logger.info(
            "Slack message received",
            extra={
                "slack_user_id": slack_user_id,
                "channel_id": channel_id,
                "text_length": len(text),
            },
        )

        try:
            bot_response = self._process_message(
                platform_user_id=slack_user_id,
                message_text=text,
                channel_id=channel_id,
                thread_id=thread_ts,
            )

            say_kwargs: dict[str, Any] = {"thread_ts": thread_ts}
            if bot_response.blocks:
                say_kwargs["blocks"] = bot_response.blocks
                say_kwargs["text"] = bot_response.text  # fallback for notifications
            else:
                say_kwargs["text"] = bot_response.text

            say(**say_kwargs)

        except Exception:
            logger.exception("Error processing Slack message")
            error_blocks = SlackFormatter.format_error(
                "Something went wrong while processing your request."
            )
            say(blocks=error_blocks, text="Error processing request", thread_ts=thread_ts)

    def _process_message(
        self,
        platform_user_id: str,
        message_text: str,
        channel_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> BotResponse:
        """Synchronous wrapper used by Bolt listeners."""
        user_info = self.resolve_user(platform_user_id)

        raw_request = {
            "query": {
                "user_input": message_text,
                "query_id": None,
                "timestamp": None,
            },
            "context": {
                "tenant_id": user_info["tenant_id"],
                "persona": user_info["persona"],
                "user_id": user_info["user_id"],
            },
            "conversation_history": [],
            "live_context": {},
            "options": {
                "mode": "answer",
                "max_retrieval_depth": None,
                "require_sources": True,
            },
        }

        logger.info(
            "Calling brain_manager.process",
            extra={"user_id": user_info["user_id"], "tenant_id": user_info["tenant_id"]},
        )

        brain_response = self.brain_manager.process(raw_request)
        return self._build_bot_response(brain_response)

    # ------------------------------------------------------------------
    # BotIntegration interface
    # ------------------------------------------------------------------

    async def handle_message(
        self,
        platform_user_id: str,
        message_text: str,
        channel_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> BotResponse:
        """Async entry-point (e.g. called from FastAPI routes)."""
        return self._process_message(
            platform_user_id=platform_user_id,
            message_text=message_text,
            channel_id=channel_id,
            thread_id=thread_id,
        )

    def format_response(self, brain_response: Any) -> dict:
        """Return a dict with 'text' and 'blocks' keys for Slack."""
        blocks = SlackFormatter.format_answer(brain_response)
        answer = getattr(brain_response, "answer", None)
        fallback_text = answer.content if answer else "No answer available."
        return {"text": fallback_text, "blocks": blocks}

    def resolve_user(self, platform_user_id: str) -> dict:
        """
        Map a Slack user ID to a Neurostack identity.

        Strategy:
        1. Check in-memory cache.
        2. Call Slack users.info to get the user's email.
        3. Derive tenant_id from the email domain.
        4. Fall back to defaults if resolution fails.
        """
        if platform_user_id in self._user_cache:
            return self._user_cache[platform_user_id]

        user_identity = {
            "user_id": platform_user_id,
            "tenant_id": _DEFAULT_TENANT,
            "teams": [],
            "persona": _DEFAULT_PERSONA,
        }

        try:
            result = self.client.users_info(user=platform_user_id)
            if result and result.get("ok"):
                profile = result["user"].get("profile", {})
                email = profile.get("email", "")
                real_name = profile.get("real_name", "")

                if email:
                    domain = email.split("@")[-1].split(".")[0]
                    user_identity["tenant_id"] = domain
                    user_identity["user_id"] = email

                if real_name:
                    user_identity["display_name"] = real_name

                logger.info(
                    "Resolved Slack user",
                    extra={
                        "slack_user_id": platform_user_id,
                        "tenant_id": user_identity["tenant_id"],
                        "user_id": user_identity["user_id"],
                    },
                )
        except Exception:
            logger.warning(
                "Failed to resolve Slack user, using defaults",
                extra={"slack_user_id": platform_user_id},
                exc_info=True,
            )

        self._user_cache[platform_user_id] = user_identity
        return user_identity

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_bot_response(self, brain_response: Any) -> BotResponse:
        """Convert a BrainResponse into a BotResponse with Slack blocks."""
        blocks = SlackFormatter.format_answer(brain_response)
        answer = getattr(brain_response, "answer", None)
        fallback_text = answer.content if answer else "No answer available."
        return BotResponse(text=fallback_text, blocks=blocks)
