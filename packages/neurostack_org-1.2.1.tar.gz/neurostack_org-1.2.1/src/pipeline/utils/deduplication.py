"""
Content deduplication utilities.

Detects duplicate content using content hashing and fingerprinting.
Critical for preventing duplicate ingestion, especially for:
- Public Slack channels accessed by multiple users
- Incremental syncs (unchanged content)
- Re-runs of same connector

Strategies:
1. Content hash (exact match)
2. Fingerprinting (fuzzy match)
3. Source ID tracking (connector-level)
"""

import hashlib
import logging
from typing import Dict, Set, Optional, Any, List, Tuple
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from enum import Enum

from ..connectors.base import RawItem
from neurostack.models import Knowledge


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.utils.deduplication")


# ============================================================================
# DEDUPLICATION ENUMS
# ============================================================================

class DeduplicationStrategy(Enum):
    """Deduplication strategy"""
    CONTENT_HASH = "content_hash"           # Exact content match (fast)
    FINGERPRINT = "fingerprint"             # Fuzzy match (slower, catches near-duplicates)
    SOURCE_ID = "source_id"                 # Source system ID (connector-level)
    HYBRID = "hybrid"                       # Combination of strategies


class DuplicateStatus(Enum):
    """Duplicate detection result"""
    UNIQUE = "unique"                       # Not a duplicate
    EXACT_DUPLICATE = "exact_duplicate"     # Exact content match
    NEAR_DUPLICATE = "near_duplicate"       # Similar content (fingerprint match)
    SOURCE_DUPLICATE = "source_duplicate"   # Same source ID


# ============================================================================
# DEDUPLICATION RESULT
# ============================================================================

@dataclass
class DeduplicationResult:
    """
    Result of duplicate detection.
    """
    status: DuplicateStatus
    is_duplicate: bool
    content_hash: Optional[str] = None
    fingerprint: Optional[str] = None
    matched_id: Optional[str] = None        # ID of duplicate item
    similarity_score: Optional[float] = None  # For fuzzy matching
    
    def __bool__(self) -> bool:
        """Allow boolean check: if dedup_result:"""
        return self.is_duplicate


# ============================================================================
# CONTENT DEDUPLICATOR
# ============================================================================

class ContentDeduplicator:
    """
    Content deduplication using multiple strategies.
    
    Maintains in-memory cache of content hashes and fingerprints
    for fast duplicate detection during ingestion.
    
    Usage:
        dedup = ContentDeduplicator()
        
        # Check if duplicate
        if dedup.is_duplicate(raw_item):
            logger.info("Duplicate detected, skipping")
            continue
        
        # Register new content
        dedup.register(raw_item)
    """
    
    def __init__(
        self,
        strategy: DeduplicationStrategy = DeduplicationStrategy.HYBRID,
        cache_size: int = 100000,
        cache_ttl_hours: int = 24,
        fingerprint_threshold: float = 0.95  # 95% similarity = near-duplicate
    ):
        """
        Initialize deduplicator.
        
        Args:
            strategy: Deduplication strategy to use
            cache_size: Maximum items in cache (LRU eviction)
            cache_ttl_hours: Cache entry TTL in hours
            fingerprint_threshold: Similarity threshold for near-duplicates (0-1)
        """
        self.strategy = strategy
        self.cache_size = cache_size
        self.cache_ttl = timedelta(hours=cache_ttl_hours)
        self.fingerprint_threshold = fingerprint_threshold
        
        # Content hash cache: hash -> (content_id, timestamp)
        self._content_hash_cache: Dict[str, Tuple[str, datetime]] = {}
        
        # Fingerprint cache: fingerprint -> (content_id, timestamp)
        self._fingerprint_cache: Dict[str, Tuple[str, datetime]] = {}
        
        # Source ID cache: (source_type, source_id) -> (content_id, timestamp)
        self._source_id_cache: Dict[Tuple[str, str], Tuple[str, datetime]] = {}
        
        # Stats
        self.total_checks = 0
        self.exact_duplicates = 0
        self.near_duplicates = 0
        self.source_duplicates = 0
        self.unique_items = 0
    
    # -------------------------
    # MAIN API
    # -------------------------
    
    def is_duplicate(self, item: RawItem) -> bool:
        """
        Check if item is duplicate (simple boolean check).
        
        Args:
            item: Raw item to check
            
        Returns:
            True if duplicate
        """
        result = self.check_duplicate(item)
        return result.is_duplicate
    
    def check_duplicate(self, item: RawItem) -> DeduplicationResult:
        """
        Check if item is duplicate with detailed result.
        
        Args:
            item: Raw item to check
            
        Returns:
            DeduplicationResult with detection details
        """
        self.total_checks += 1
        
        # Clean expired cache entries periodically
        if self.total_checks % 1000 == 0:
            self._clean_expired_cache()
        
        # Strategy: Source ID (fastest, connector-level)
        if self.strategy in [DeduplicationStrategy.SOURCE_ID, DeduplicationStrategy.HYBRID]:
            result = self._check_source_id(item)
            if result.is_duplicate:
                self.source_duplicates += 1
                return result
        
        # Strategy: Content hash (fast, exact match)
        if self.strategy in [DeduplicationStrategy.CONTENT_HASH, DeduplicationStrategy.HYBRID]:
            result = self._check_content_hash(item)
            if result.is_duplicate:
                self.exact_duplicates += 1
                return result
        
        # Strategy: Fingerprint (slower, fuzzy match)
        if self.strategy in [DeduplicationStrategy.FINGERPRINT, DeduplicationStrategy.HYBRID]:
            result = self._check_fingerprint(item)
            if result.is_duplicate:
                self.near_duplicates += 1
                return result
        
        # Not a duplicate
        self.unique_items += 1
        return DeduplicationResult(
            status=DuplicateStatus.UNIQUE,
            is_duplicate=False
        )
    
    def register(self, item: RawItem, content_id: Optional[str] = None) -> None:
        """
        Register item in deduplication cache.
        
        Call this after successfully processing an item to prevent
        future duplicates.
        
        Args:
            item: Raw item to register
            content_id: Optional content ID (generated if not provided)
        """
        if content_id is None:
            content_id = self._generate_content_id(item)
        
        timestamp = datetime.now(timezone.utc)
        
        # Register in all caches based on strategy
        if self.strategy in [DeduplicationStrategy.SOURCE_ID, DeduplicationStrategy.HYBRID]:
            key = (item.source_type, item.source_id)
            self._source_id_cache[key] = (content_id, timestamp)
        
        if self.strategy in [DeduplicationStrategy.CONTENT_HASH, DeduplicationStrategy.HYBRID]:
            content_hash = self._compute_content_hash(item)
            self._content_hash_cache[content_hash] = (content_id, timestamp)
        
        if self.strategy in [DeduplicationStrategy.FINGERPRINT, DeduplicationStrategy.HYBRID]:
            fingerprint = self._compute_fingerprint(item)
            self._fingerprint_cache[fingerprint] = (content_id, timestamp)
        
        # Enforce cache size limit
        self._enforce_cache_limits()
    
    def clear(self) -> None:
        """Clear all deduplication caches"""
        self._content_hash_cache.clear()
        self._fingerprint_cache.clear()
        self._source_id_cache.clear()
        
        # Reset stats
        self.total_checks = 0
        self.exact_duplicates = 0
        self.near_duplicates = 0
        self.source_duplicates = 0
        self.unique_items = 0
    
    # -------------------------
    # DEDUPLICATION STRATEGIES
    # -------------------------
    
    def _check_source_id(self, item: RawItem) -> DeduplicationResult:
        """
        Check duplicate by source ID.
        
        Fastest method. Checks if (source_type, source_id) already processed.
        """
        key = (item.source_type, item.source_id)
        
        if key in self._source_id_cache:
            content_id, timestamp = self._source_id_cache[key]
            
            # Check if expired
            if datetime.now(timezone.utc) - timestamp > self.cache_ttl:
                # Expired, not a duplicate
                del self._source_id_cache[key]
                return DeduplicationResult(
                    status=DuplicateStatus.UNIQUE,
                    is_duplicate=False
                )
            
            return DeduplicationResult(
                status=DuplicateStatus.SOURCE_DUPLICATE,
                is_duplicate=True,
                matched_id=content_id
            )
        
        return DeduplicationResult(
            status=DuplicateStatus.UNIQUE,
            is_duplicate=False
        )
    
    def _check_content_hash(self, item: RawItem) -> DeduplicationResult:
        """
        Check duplicate by content hash.
        
        Fast method. Exact content match using SHA-256.
        """
        content_hash = self._compute_content_hash(item)
        
        if content_hash in self._content_hash_cache:
            content_id, timestamp = self._content_hash_cache[content_hash]
            
            # Check if expired
            if datetime.now(timezone.utc) - timestamp > self.cache_ttl:
                del self._content_hash_cache[content_hash]
                return DeduplicationResult(
                    status=DuplicateStatus.UNIQUE,
                    is_duplicate=False,
                    content_hash=content_hash
                )
            
            return DeduplicationResult(
                status=DuplicateStatus.EXACT_DUPLICATE,
                is_duplicate=True,
                content_hash=content_hash,
                matched_id=content_id,
                similarity_score=1.0
            )
        
        return DeduplicationResult(
            status=DuplicateStatus.UNIQUE,
            is_duplicate=False,
            content_hash=content_hash
        )
    
    def _check_fingerprint(self, item: RawItem) -> DeduplicationResult:
        """
        Check duplicate by fingerprint (fuzzy match).
        
        Slower method. Detects near-duplicates using simhash or similar.
        """
        fingerprint = self._compute_fingerprint(item)
        
        # Exact fingerprint match
        if fingerprint in self._fingerprint_cache:
            content_id, timestamp = self._fingerprint_cache[fingerprint]
            
            if datetime.now(timezone.utc) - timestamp > self.cache_ttl:
                del self._fingerprint_cache[fingerprint]
                return DeduplicationResult(
                    status=DuplicateStatus.UNIQUE,
                    is_duplicate=False,
                    fingerprint=fingerprint
                )
            
            return DeduplicationResult(
                status=DuplicateStatus.NEAR_DUPLICATE,
                is_duplicate=True,
                fingerprint=fingerprint,
                matched_id=content_id,
                similarity_score=1.0
            )
        
        # Fuzzy match (check similar fingerprints)
        # For MVP, we only check exact fingerprint match
        # Full implementation would use Hamming distance on simhash
        
        return DeduplicationResult(
            status=DuplicateStatus.UNIQUE,
            is_duplicate=False,
            fingerprint=fingerprint
        )
    
    # -------------------------
    # HASHING & FINGERPRINTING
    # -------------------------
    
    def _compute_content_hash(self, item: RawItem) -> str:
        """
        Compute content hash (SHA-256).
        
        Hashes the raw_data JSON structure for exact duplicate detection.
        """
        import json
        
        # Serialize raw_data to canonical JSON (sorted keys)
        content_json = json.dumps(item.raw_data, sort_keys=True, ensure_ascii=True)
        
        # Compute SHA-256 hash
        hash_obj = hashlib.sha256(content_json.encode('utf-8'))
        return hash_obj.hexdigest()
    
    def _compute_fingerprint(self, item: RawItem) -> str:
        """
        Compute content fingerprint for fuzzy matching.
        
        Uses simhash-like approach: extract text, compute signature.
        """
        # Extract text content from raw_data
        text = self._extract_text_from_raw_data(item.raw_data)
        
        # For MVP: use simple hash of normalized text
        # Production would use simhash algorithm
        normalized_text = self._normalize_text(text)
        
        # Compute hash of normalized text
        hash_obj = hashlib.md5(normalized_text.encode('utf-8'))
        return hash_obj.hexdigest()
    
    def _extract_text_from_raw_data(self, raw_data: Dict[str, Any]) -> str:
        """
        Extract text content from raw data recursively.
        
        Args:
            raw_data: Raw data dictionary
            
        Returns:
            Extracted text
        """
        texts = []
        
        def extract_recursive(obj):
            if isinstance(obj, str):
                texts.append(obj)
            elif isinstance(obj, dict):
                for value in obj.values():
                    extract_recursive(value)
            elif isinstance(obj, list):
                for item in obj:
                    extract_recursive(item)
        
        extract_recursive(raw_data)
        return " ".join(texts)
    
    def _normalize_text(self, text: str) -> str:
        """
        Normalize text for fingerprinting.
        
        Removes whitespace variations, lowercases, etc.
        """
        # Lowercase
        text = text.lower()
        
        # Remove extra whitespace
        text = " ".join(text.split())
        
        # Remove punctuation (optional, makes fuzzy matching more lenient)
        import string
        text = text.translate(str.maketrans("", "", string.punctuation))
        
        return text
    
    # -------------------------
    # CACHE MANAGEMENT
    # -------------------------
    
    def _clean_expired_cache(self) -> None:
        """Remove expired entries from all caches"""
        now = datetime.now(timezone.utc)
        
        # Clean content hash cache
        expired_hashes = [
            h for h, (_, ts) in self._content_hash_cache.items()
            if now - ts > self.cache_ttl
        ]
        for h in expired_hashes:
            del self._content_hash_cache[h]
        
        # Clean fingerprint cache
        expired_fingerprints = [
            f for f, (_, ts) in self._fingerprint_cache.items()
            if now - ts > self.cache_ttl
        ]
        for f in expired_fingerprints:
            del self._fingerprint_cache[f]
        
        # Clean source ID cache
        expired_sources = [
            k for k, (_, ts) in self._source_id_cache.items()
            if now - ts > self.cache_ttl
        ]
        for k in expired_sources:
            del self._source_id_cache[k]
    
    def _enforce_cache_limits(self) -> None:
        """Enforce maximum cache size (LRU eviction)"""
        # Simple implementation: if over limit, remove oldest entries
        
        # Content hash cache
        if len(self._content_hash_cache) > self.cache_size:
            # Sort by timestamp, remove oldest
            sorted_items = sorted(
                self._content_hash_cache.items(),
                key=lambda x: x[1][1]
            )
            keep_count = int(self.cache_size * 0.9)  # Keep 90%
            self._content_hash_cache = dict(sorted_items[-keep_count:])
        
        # Fingerprint cache
        if len(self._fingerprint_cache) > self.cache_size:
            sorted_items = sorted(
                self._fingerprint_cache.items(),
                key=lambda x: x[1][1]
            )
            keep_count = int(self.cache_size * 0.9)
            self._fingerprint_cache = dict(sorted_items[-keep_count:])
        
        # Source ID cache
        if len(self._source_id_cache) > self.cache_size:
            sorted_items = sorted(
                self._source_id_cache.items(),
                key=lambda x: x[1][1]
            )
            keep_count = int(self.cache_size * 0.9)
            self._source_id_cache = dict(sorted_items[-keep_count:])
    
    # -------------------------
    # UTILITIES
    # -------------------------
    
    def _generate_content_id(self, item: RawItem) -> str:
        """
        Generate unique content ID from item.
        
        Format: {source_type}_{source_id}
        """
        return f"{item.source_type}_{item.source_id}"
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get deduplication statistics.
        
        Returns:
            Dictionary with stats
        """
        total_duplicates = (
            self.exact_duplicates +
            self.near_duplicates +
            self.source_duplicates
        )
        
        return {
            "total_checks": self.total_checks,
            "unique_items": self.unique_items,
            "total_duplicates": total_duplicates,
            "exact_duplicates": self.exact_duplicates,
            "near_duplicates": self.near_duplicates,
            "source_duplicates": self.source_duplicates,
            "duplicate_rate": (
                total_duplicates / self.total_checks
                if self.total_checks > 0
                else 0
            ),
            "cache_sizes": {
                "content_hash": len(self._content_hash_cache),
                "fingerprint": len(self._fingerprint_cache),
                "source_id": len(self._source_id_cache)
            }
        }


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def compute_content_hash(content: str) -> str:
    """
    Compute SHA-256 hash of content.
    
    Standalone utility for hashing arbitrary content.
    
    Args:
        content: Content string to hash
        
    Returns:
        Hexadecimal hash string
    """
    hash_obj = hashlib.sha256(content.encode('utf-8'))
    return hash_obj.hexdigest()


def compute_simhash(text: str, hash_bits: int = 64) -> int:
    """
    Compute simhash fingerprint of text.
    
    Simhash is locality-sensitive hashing algorithm for near-duplicate detection.
    Similar texts have similar hash values (measured by Hamming distance).
    
    Args:
        text: Input text
        hash_bits: Number of bits in hash (default 64)
        
    Returns:
        Simhash as integer
    """
    import re
    
    # Tokenize text into words
    tokens = re.findall(r'\w+', text.lower())
    
    # Feature vector (counts)
    features: Dict[str, int] = {}
    for token in tokens:
        features[token] = features.get(token, 0) + 1
    
    # Compute weighted bit vectors
    bit_vector = [0] * hash_bits
    
    for feature, weight in features.items():
        # Hash feature to bit pattern
        hash_value = int(hashlib.md5(feature.encode()).hexdigest(), 16)
        
        for i in range(hash_bits):
            # Check if bit i is set
            if hash_value & (1 << i):
                bit_vector[i] += weight
            else:
                bit_vector[i] -= weight
    
    # Convert to final hash
    fingerprint = 0
    for i in range(hash_bits):
        if bit_vector[i] > 0:
            fingerprint |= (1 << i)
    
    return fingerprint


def hamming_distance(hash1: int, hash2: int) -> int:
    """
    Compute Hamming distance between two hashes.
    
    Hamming distance = number of differing bits.
    Used to measure similarity of simhash fingerprints.
    
    Args:
        hash1: First hash (integer)
        hash2: Second hash (integer)
        
    Returns:
        Hamming distance (0 = identical, 64 = completely different for 64-bit hash)
    """
    xor = hash1 ^ hash2
    # Count set bits
    distance = bin(xor).count('1')
    return distance


def are_similar(hash1: int, hash2: int, threshold: int = 3) -> bool:
    """
    Check if two hashes are similar.
    
    Args:
        hash1: First hash
        hash2: Second hash
        threshold: Maximum Hamming distance for similarity (default 3 bits)
        
    Returns:
        True if hashes are similar (Hamming distance <= threshold)
    """
    return hamming_distance(hash1, hash2) <= threshold


# ============================================================================
# BATCH DEDUPLICATION
# ============================================================================

def deduplicate_batch(items: List[RawItem]) -> Tuple[List[RawItem], List[RawItem]]:
    """
    Deduplicate a batch of items.
    
    Useful for removing duplicates within a single batch before processing.
    
    Args:
        items: List of raw items
        
    Returns:
        Tuple of (unique_items, duplicate_items)
    """
    dedup = ContentDeduplicator()
    
    unique = []
    duplicates = []
    
    for item in items:
        if dedup.is_duplicate(item):
            duplicates.append(item)
        else:
            unique.append(item)
            dedup.register(item)
    
    return unique, duplicates