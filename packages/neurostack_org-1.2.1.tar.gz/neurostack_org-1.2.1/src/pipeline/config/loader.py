"""Configuration loader for Neurostack.

Reads neurostack.yaml, validates with Pydantic, and supports
environment-variable overrides using the NEUROSTACK_* prefix.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Config section models
# ---------------------------------------------------------------------------

class LLMConfig(BaseModel):
    """LLM provider configuration."""
    provider: str = "anthropic"
    model: str = "claude-sonnet-4-20250514"
    api_key_env: str = "ANTHROPIC_API_KEY"
    max_tokens: int = 4096
    temperature: float = 0.0


class VectorStoreConfig(BaseModel):
    """Vector-store configuration."""
    provider: str = "qdrant"
    host: str = "localhost"
    port: int = 6333
    collection: str = "neurostack"
    embedding_model: str = "text-embedding-3-small"
    embedding_dimensions: int = 1536


class DatabaseConfig(BaseModel):
    """Relational database configuration."""
    url: str = "postgresql://neurostack:neurostack@localhost:5432/neurostack"
    pool_size: int = 5
    max_overflow: int = 10


class ConnectorConfig(BaseModel):
    """Individual connector definition."""
    type: str
    enabled: bool = True
    config_path: Optional[str] = None
    sync_interval_minutes: Optional[int] = None


class SyncConfig(BaseModel):
    """Sync / scheduling settings."""
    default_interval_minutes: int = 60
    max_concurrent: int = 3
    retry_attempts: int = 3
    retry_delay_seconds: int = 30


class LoggingConfig(BaseModel):
    """Logging configuration."""
    level: str = "INFO"
    format: str = "json"
    file: Optional[str] = None


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------

class NeurostackConfig(BaseModel):
    """Top-level Neurostack configuration."""
    llm: LLMConfig = Field(default_factory=LLMConfig)
    vector_store: VectorStoreConfig = Field(default_factory=VectorStoreConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    connectors: list[ConnectorConfig] = Field(default_factory=list)
    sync: SyncConfig = Field(default_factory=SyncConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)


# ---------------------------------------------------------------------------
# Environment variable overrides
# ---------------------------------------------------------------------------

_ENV_PREFIX = "NEUROSTACK_"


def _apply_env_overrides(data: dict) -> dict:
    """Apply NEUROSTACK_* environment variable overrides.

    Mapping convention:
        NEUROSTACK_LLM__PROVIDER  ->  data["llm"]["provider"]
        NEUROSTACK_DATABASE__URL  ->  data["database"]["url"]

    Double-underscore separates nested keys; values are always strings.
    """
    for key, value in os.environ.items():
        if not key.startswith(_ENV_PREFIX):
            continue
        parts = key[len(_ENV_PREFIX):].lower().split("__")
        target = data
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        target[parts[-1]] = value
    return data


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_config(path: str | Path = "neurostack.yaml") -> NeurostackConfig:
    """Load and validate a Neurostack configuration file.

    Args:
        path: Path to the YAML configuration file.

    Returns:
        Validated NeurostackConfig instance.

    Raises:
        FileNotFoundError: If the config file does not exist.
        pydantic.ValidationError: If the config is invalid.
    """
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r") as f:
        raw = yaml.safe_load(f) or {}

    raw = _apply_env_overrides(raw)
    return NeurostackConfig.model_validate(raw)
