"""
Permission Sync System (Phase 4B).

Periodically re-checks source permissions for stored knowledge items and
updates IndexedVisibility when they diverge.  Produces audit-grade
PermissionChangeEvent records for every mutation.

Components:
    PermissionDiffCalculator  - pure comparison logic
    PermissionSyncRunner      - orchestrates a single sync pass
    PermissionSyncScheduler   - timer-based recurring execution
"""

from __future__ import annotations

import logging
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from neurostack.models import (
    IndexedVisibility,
    PermissionChangeEvent,
    PermissionChangeType,
    PermissionQuery,
    PermissionRecord,
    PermissionSyncJob,
    RawPermission,
    VisibilityScope,
)
from pipeline.connectors.base import Connector, PermissionMetadata, RawItem
from pipeline.storage.interfaces import StorageBackend

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# PermissionDiff / PermissionDiffCalculator
# ---------------------------------------------------------------------------

@dataclass
class PermissionDiff:
    """Result of comparing two IndexedVisibility snapshots."""

    has_changed: bool = False
    scope_changed: bool = False
    users_added: List[str] = field(default_factory=list)
    users_removed: List[str] = field(default_factory=list)
    teams_added: List[str] = field(default_factory=list)
    teams_removed: List[str] = field(default_factory=list)
    roles_added: List[str] = field(default_factory=list)
    roles_removed: List[str] = field(default_factory=list)


class PermissionDiffCalculator:
    """Stateless helper that diffs two IndexedVisibility objects."""

    @staticmethod
    def compare(
        old: Optional[IndexedVisibility],
        new: IndexedVisibility,
    ) -> PermissionDiff:
        """Return a *PermissionDiff* describing what changed between *old* and *new*.

        If *old* is ``None`` the item is treated as newly-permissioned and every
        field in *new* counts as an addition.
        """
        if old is None:
            return PermissionDiff(
                has_changed=True,
                scope_changed=True,
                users_added=list(new.user_ids),
                teams_added=list(new.team_ids),
                roles_added=list(new.role_ids),
            )

        old_users = set(old.user_ids)
        new_users = set(new.user_ids)
        old_teams = set(old.team_ids)
        new_teams = set(new.team_ids)
        old_roles = set(old.role_ids)
        new_roles = set(new.role_ids)

        scope_changed = old.scope != new.scope
        users_added = sorted(new_users - old_users)
        users_removed = sorted(old_users - new_users)
        teams_added = sorted(new_teams - old_teams)
        teams_removed = sorted(old_teams - new_teams)
        roles_added = sorted(new_roles - old_roles)
        roles_removed = sorted(old_roles - new_roles)

        has_changed = (
            scope_changed
            or bool(users_added)
            or bool(users_removed)
            or bool(teams_added)
            or bool(teams_removed)
            or bool(roles_added)
            or bool(roles_removed)
        )

        return PermissionDiff(
            has_changed=has_changed,
            scope_changed=scope_changed,
            users_added=users_added,
            users_removed=users_removed,
            teams_added=teams_added,
            teams_removed=teams_removed,
            roles_added=roles_added,
            roles_removed=roles_removed,
        )


# ---------------------------------------------------------------------------
# PermissionSyncRunner
# ---------------------------------------------------------------------------

class PermissionSyncRunner:
    """Executes a single permission-sync pass for one source type / tenant.

    For every stored knowledge item that originated from the given source, the
    runner asks the connector for fresh permissions, diffs them against the
    stored ``IndexedVisibility``, and persists any changes.
    """

    def __init__(
        self,
        storage_backend: StorageBackend,
        audit_logger: Optional[logging.Logger] = None,
    ) -> None:
        self._storage = storage_backend
        self._audit = audit_logger or logger
        self._diff = PermissionDiffCalculator()

    # -- public API --------------------------------------------------------

    def run_sync(
        self,
        connector: Connector,
        tenant_id: str,
        source_type: str,
    ) -> PermissionSyncJob:
        """Run a full permission-sync pass and return the completed job."""

        job = PermissionSyncJob(
            job_id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            source_type=source_type,
            status="running",
            started_at=datetime.now(timezone.utc),
        )

        logger.info(
            "permission_sync.started",
            extra={
                "job_id": job.job_id,
                "tenant_id": tenant_id,
                "source_type": source_type,
            },
        )

        self._storage.metadata.save_permission_sync_job(job)

        try:
            knowledge_items = self._fetch_knowledge_items(tenant_id, source_type)
            logger.info(
                "permission_sync.items_found",
                extra={"job_id": job.job_id, "count": len(knowledge_items)},
            )

            for item in knowledge_items:
                self._sync_single_item(
                    job=job,
                    connector=connector,
                    content_id=item.id,
                    source_type=source_type,
                    raw_data=getattr(item, "raw_data", None) or {},
                )

            job.status = "completed"
        except Exception:
            logger.exception(
                "permission_sync.failed",
                extra={"job_id": job.job_id},
            )
            job.status = "failed"
        finally:
            job.completed_at = datetime.now(timezone.utc)
            self._storage.metadata.save_permission_sync_job(job)

        logger.info(
            "permission_sync.finished",
            extra={
                "job_id": job.job_id,
                "status": job.status,
                "items_checked": job.items_checked,
                "permissions_updated": job.permissions_updated,
                "permissions_revoked": job.permissions_revoked,
                "errors": job.errors,
            },
        )

        return job

    # -- internals ---------------------------------------------------------

    def _fetch_knowledge_items(self, tenant_id: str, source_type: str):
        """Retrieve all knowledge items for the given tenant + source."""
        query = PermissionQuery(
            tenant_id=tenant_id,
            user_id="__system__",
            source_types=[source_type],
        )
        return self._storage.metadata.query_knowledge(
            query=query,
            limit=10_000,
            offset=0,
        )

    def _sync_single_item(
        self,
        job: PermissionSyncJob,
        connector: Connector,
        content_id: str,
        source_type: str,
        raw_data: Dict[str, Any],
    ) -> None:
        """Compare fresh permissions against stored ones for one item."""
        job.items_checked += 1

        try:
            # Build a lightweight RawItem so the connector can extract perms.
            raw_item = RawItem(
                source_id=content_id,
                source_type=source_type,
                raw_data=raw_data,
            )
            fresh_perms: PermissionMetadata = connector.extract_permissions(raw_item)

            # Build a new IndexedVisibility from the connector's suggestion.
            new_indexed = self._build_indexed_visibility(
                content_id=content_id,
                perm_meta=fresh_perms,
                source_type=source_type,
            )

            # Retrieve the current stored permission.
            existing_record: Optional[PermissionRecord] = (
                self._storage.metadata.get_permission(content_id)
            )
            old_indexed = existing_record.indexed if existing_record else None

            diff = self._diff.compare(old_indexed, new_indexed)

            if not diff.has_changed:
                # Touch the last_synced_at timestamp even when unchanged.
                if existing_record is not None:
                    existing_record.last_synced_at = datetime.now(timezone.utc)
                    self._storage.metadata.write_permission(existing_record)
                return

            # Persist the updated visibility.
            self._storage.metadata.update_indexed_visibility(content_id, new_indexed)

            # Determine change type and log the event.
            change_type = self._determine_change_type(diff, old_indexed)

            if change_type == PermissionChangeType.REVOKED:
                job.permissions_revoked += 1
            else:
                job.permissions_updated += 1

            event = PermissionChangeEvent(
                event_id=str(uuid.uuid4()),
                content_id=content_id,
                change_type=change_type,
                affected_user_ids=diff.users_added + diff.users_removed,
                affected_team_ids=diff.teams_added + diff.teams_removed,
                source_type=source_type,
                reason=f"permission_sync job={job.job_id}",
                timestamp=datetime.now(timezone.utc),
                detected_by="permission_sync",
            )
            self._storage.metadata.log_permission_change(event)

            self._audit.info(
                "permission_sync.change_detected",
                extra={
                    "job_id": job.job_id,
                    "content_id": content_id,
                    "change_type": change_type.value,
                    "scope_changed": diff.scope_changed,
                    "users_added": diff.users_added,
                    "users_removed": diff.users_removed,
                    "teams_added": diff.teams_added,
                    "teams_removed": diff.teams_removed,
                },
            )

        except Exception as exc:
            job.errors += 1
            job.error_messages.append(
                f"content_id={content_id}: {type(exc).__name__}: {exc}"
            )
            logger.warning(
                "permission_sync.item_error",
                extra={"job_id": job.job_id, "content_id": content_id, "error": str(exc)},
            )

    # -- helpers -----------------------------------------------------------

    @staticmethod
    def _build_indexed_visibility(
        content_id: str,
        perm_meta: PermissionMetadata,
        source_type: str,
    ) -> IndexedVisibility:
        """Translate a connector's PermissionMetadata into IndexedVisibility."""

        scope_map = {
            "public": VisibilityScope.PUBLIC,
            "team": VisibilityScope.TEAM,
            "private": VisibilityScope.PRIVATE,
            "restricted": VisibilityScope.RESTRICTED,
        }
        scope = scope_map.get(
            (perm_meta.suggested_scope or "").lower(),
            VisibilityScope.PRIVATE,
        )

        return IndexedVisibility(
            content_id=content_id,
            scope=scope,
            user_ids=list(perm_meta.suggested_user_ids),
            team_ids=list(perm_meta.suggested_team_ids),
            computed_at=datetime.now(timezone.utc),
            derived_from=source_type,
        )

    @staticmethod
    def _determine_change_type(
        diff: PermissionDiff,
        old_indexed: Optional[IndexedVisibility],
    ) -> PermissionChangeType:
        """Heuristic to classify what *kind* of permission change occurred."""

        if old_indexed is None:
            return PermissionChangeType.GRANTED

        # If the scope narrowed to PRIVATE/RESTRICTED with no users left, treat
        # as a revocation.
        if diff.scope_changed and diff.users_removed and not diff.users_added:
            return PermissionChangeType.REVOKED

        # Pure removals without any additions are revocations.
        if diff.users_removed and not diff.users_added and not diff.teams_added:
            return PermissionChangeType.REVOKED

        if diff.users_added and not diff.users_removed:
            return PermissionChangeType.GRANTED

        return PermissionChangeType.UPDATED


# ---------------------------------------------------------------------------
# PermissionSyncScheduler
# ---------------------------------------------------------------------------

@dataclass
class _ScheduleEntry:
    """Internal bookkeeping for a single recurring schedule."""

    source_type: str
    tenant_id: str
    interval_seconds: int
    timer: Optional[threading.Timer] = field(default=None, repr=False)
    active: bool = True
    last_run_at: Optional[datetime] = None
    next_run_at: Optional[datetime] = None


class PermissionSyncScheduler:
    """Lightweight timer-based scheduler for recurring permission syncs.

    Uses ``threading.Timer`` so there are no heavy external dependencies.
    Each source-type gets its own repeating timer that fires
    ``PermissionSyncRunner.run_sync`` at the requested interval.
    """

    def __init__(self, sync_runner: PermissionSyncRunner) -> None:
        self._runner = sync_runner
        self._schedules: Dict[str, _ScheduleEntry] = {}
        self._lock = threading.Lock()

    # -- public API --------------------------------------------------------

    def schedule(
        self,
        connector: Connector,
        tenant_id: str,
        source_type: str,
        interval_seconds: int,
    ) -> None:
        """Register (or replace) a recurring sync for *source_type*.

        The first execution fires after *interval_seconds*; subsequent
        executions repeat at the same cadence.
        """
        with self._lock:
            # Cancel any pre-existing schedule for this source.
            self._cancel_locked(source_type)

            entry = _ScheduleEntry(
                source_type=source_type,
                tenant_id=tenant_id,
                interval_seconds=interval_seconds,
            )
            self._schedules[source_type] = entry

            logger.info(
                "permission_sync.scheduled",
                extra={
                    "source_type": source_type,
                    "tenant_id": tenant_id,
                    "interval_seconds": interval_seconds,
                },
            )

            self._start_timer(entry, connector)

    def cancel(self, source_type: str) -> None:
        """Cancel the recurring sync for *source_type*, if any."""
        with self._lock:
            self._cancel_locked(source_type)

    def cancel_all(self) -> None:
        """Cancel every active schedule."""
        with self._lock:
            for source_type in list(self._schedules):
                self._cancel_locked(source_type)

    def get_schedule(self) -> List[Dict[str, Any]]:
        """Return a snapshot of all active schedules."""
        with self._lock:
            return [
                {
                    "source_type": e.source_type,
                    "tenant_id": e.tenant_id,
                    "interval_seconds": e.interval_seconds,
                    "active": e.active,
                    "last_run_at": e.last_run_at.isoformat() if e.last_run_at else None,
                    "next_run_at": e.next_run_at.isoformat() if e.next_run_at else None,
                }
                for e in self._schedules.values()
                if e.active
            ]

    # -- internals ---------------------------------------------------------

    def _cancel_locked(self, source_type: str) -> None:
        """Cancel a schedule while already holding ``self._lock``."""
        entry = self._schedules.pop(source_type, None)
        if entry is not None:
            entry.active = False
            if entry.timer is not None:
                entry.timer.cancel()
            logger.info(
                "permission_sync.cancelled",
                extra={"source_type": source_type},
            )

    def _start_timer(
        self,
        entry: _ScheduleEntry,
        connector: Connector,
    ) -> None:
        """Schedule the next timer tick for *entry*."""
        if not entry.active:
            return

        entry.next_run_at = datetime.now(timezone.utc) + timedelta(
            seconds=entry.interval_seconds,
        )

        timer = threading.Timer(
            entry.interval_seconds,
            self._tick,
            args=(entry, connector),
        )
        timer.daemon = True
        timer.start()
        entry.timer = timer

    def _tick(self, entry: _ScheduleEntry, connector: Connector) -> None:
        """Callback executed by the timer thread."""
        if not entry.active:
            return

        logger.info(
            "permission_sync.tick",
            extra={"source_type": entry.source_type, "tenant_id": entry.tenant_id},
        )

        try:
            self._runner.run_sync(
                connector=connector,
                tenant_id=entry.tenant_id,
                source_type=entry.source_type,
            )
        except Exception:
            logger.exception(
                "permission_sync.tick_failed",
                extra={"source_type": entry.source_type},
            )
        finally:
            entry.last_run_at = datetime.now(timezone.utc)
            # Re-arm the timer for the next cycle.
            with self._lock:
                if entry.active and entry.source_type in self._schedules:
                    self._start_timer(entry, connector)
