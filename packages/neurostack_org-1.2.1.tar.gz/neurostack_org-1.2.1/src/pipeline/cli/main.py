"""Neurostack CLI - main entry point."""

import os
import subprocess

import click
import yaml


@click.group()
@click.version_option(version="0.1.0", prog_name="neurostack")
def cli():
    """Neurostack - Enterprise AI Intelligence Brain."""
    pass


@cli.command()
def migrate():
    """Run database migrations (Alembic)."""
    click.echo("Running database migrations...")
    click.echo("  -> alembic upgrade head")
    try:
        from alembic.config import Config
        from alembic import command

        alembic_cfg = Config("alembic.ini")
        command.upgrade(alembic_cfg, "head")
        click.echo("Migrations completed successfully.")
    except Exception as e:
        click.echo(f"Migration failed: {e}", err=True)
        raise SystemExit(1)


@cli.command()
@click.argument("connector_type")
@click.option("--full", is_flag=True, help="Run full sync instead of incremental.")
def ingest(connector_type: str, full: bool):
    """Run ingestion for a specific connector type (e.g. jira, slack, google)."""
    mode = "full" if full else "incremental"
    click.echo(f"Starting {mode} ingestion for connector: {connector_type}")
    try:
        from pipeline.connectors.registry import get_connector

        connector = get_connector(connector_type)
        connector.sync(full=full)
        click.echo(f"Ingestion for '{connector_type}' completed.")
    except ImportError:
        click.echo(f"Connector '{connector_type}' is not available. Check installation.", err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(f"Ingestion failed: {e}", err=True)
        raise SystemExit(1)


@cli.command()
def test():
    """Run health checks on all subsystems."""
    click.echo("Running Neurostack health checks...\n")
    checks = {
        "Configuration": _check_config,
        "Database": _check_database,
        "Vector Store": _check_vector_store,
        "LLM": _check_llm,
    }
    all_ok = True
    for name, check_fn in checks.items():
        try:
            check_fn()
            click.echo(f"  [OK]   {name}")
        except Exception as e:
            click.echo(f"  [FAIL] {name}: {e}")
            all_ok = False

    click.echo()
    if all_ok:
        click.echo("All health checks passed.")
    else:
        click.echo("Some health checks failed.", err=True)
        raise SystemExit(1)


@cli.group()
def config():
    """Configuration management commands."""
    pass


@config.command("validate")
@click.option("--path", default="neurostack.yaml", help="Path to config file.")
def config_validate(path: str):
    """Validate the neurostack.yaml configuration file."""
    click.echo(f"Validating configuration: {path}")
    try:
        from pipeline.config.loader import load_config

        cfg = load_config(path)
        click.echo("Configuration is valid.")
        click.echo(f"  LLM provider:     {cfg.llm.provider}")
        click.echo(f"  Vector store:     {cfg.vector_store.provider}")
        click.echo(f"  Database URL set:  {'yes' if cfg.database.url else 'no'}")
        click.echo(f"  Connectors:       {len(cfg.connectors)}")
    except FileNotFoundError:
        click.echo(f"Config file not found: {path}", err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(f"Validation failed: {e}", err=True)
        raise SystemExit(1)


@config.command("show")
@click.option("--path", default="neurostack.yaml", help="Path to config file.")
def config_show(path: str):
    """Show the current configuration (secrets redacted)."""
    click.echo(f"Loading configuration from: {path}\n")
    try:
        from pipeline.config.loader import load_config

        cfg = load_config(path)
        _print_config(cfg)
    except FileNotFoundError:
        click.echo(f"Config file not found: {path}", err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(f"Failed to load config: {e}", err=True)
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Docker helper (supports both `docker compose` and `docker-compose`)
# ---------------------------------------------------------------------------

def _run_docker_compose(*args):
    """Run docker compose command, trying both modern and legacy syntax."""
    # Try modern syntax first: `docker compose ...`
    try:
        result = subprocess.run(
            ["docker", "compose"] + list(args),
            capture_output=True, text=True,
        )
        if result.returncode == 0 or "not found" not in result.stderr.lower():
            return result
    except FileNotFoundError:
        pass

    # Fallback to legacy: `docker-compose ...`
    try:
        return subprocess.run(
            ["docker-compose"] + list(args),
            capture_output=True, text=True,
        )
    except FileNotFoundError:
        # Neither found
        class FakeResult:
            returncode = 1
            stderr = "Docker not found. Install Docker Desktop: https://docker.com/get-started"
        return FakeResult()


# ---------------------------------------------------------------------------
# Health-check helpers
# ---------------------------------------------------------------------------

def _check_config():
    from pipeline.config.loader import load_config

    load_config("neurostack.yaml")


def _check_database():
    from pipeline.config.loader import load_config

    cfg = load_config("neurostack.yaml")
    if not cfg.database.url:
        raise RuntimeError("database.url is not configured")


def _check_vector_store():
    from pipeline.config.loader import load_config

    cfg = load_config("neurostack.yaml")
    if not cfg.vector_store.provider:
        raise RuntimeError("vector_store.provider is not configured")


def _check_llm():
    import os
    from pipeline.config.loader import load_config

    cfg = load_config("neurostack.yaml")
    env_var = cfg.llm.api_key_env
    if env_var and not os.environ.get(env_var):
        raise RuntimeError(f"Environment variable '{env_var}' is not set")


def _print_config(cfg):
    """Pretty-print configuration with secrets redacted."""
    click.echo("llm:")
    click.echo(f"  provider:    {cfg.llm.provider}")
    click.echo(f"  model:       {cfg.llm.model}")
    click.echo(f"  api_key_env: {cfg.llm.api_key_env}")

    click.echo("vector_store:")
    click.echo(f"  provider:   {cfg.vector_store.provider}")
    click.echo(f"  host:       {cfg.vector_store.host}")
    click.echo(f"  port:       {cfg.vector_store.port}")
    click.echo(f"  collection: {cfg.vector_store.collection}")

    click.echo("database:")
    url = cfg.database.url
    if url and "@" in url:
        # Redact password in connection string
        redacted = url.split("@")[-1]
        click.echo(f"  url: ***@{redacted}")
    else:
        click.echo(f"  url: {url}")

    click.echo("connectors:")
    for c in cfg.connectors:
        click.echo(f"  - type: {c.type}, enabled: {c.enabled}")

    click.echo("sync:")
    click.echo(f"  default_interval_minutes: {cfg.sync.default_interval_minutes}")
    click.echo(f"  max_concurrent:           {cfg.sync.max_concurrent}")


# ---------------------------------------------------------------------------
# Setup wizard
# ---------------------------------------------------------------------------

@cli.command()
def setup():
    """Interactive first-run setup wizard."""
    click.echo(click.style("\n=== Neurostack Setup Wizard ===\n", bold=True))

    config = {}

    # ── Step 1: LLM Provider ──────────────────────────────────────────────
    click.echo(click.style("Step 1: LLM Provider", fg="cyan", bold=True))
    click.echo("  Free tier providers:")
    click.echo("    groq       — Llama 3.3 70B (fastest free, 30 req/min)")
    click.echo("    gemini     — Google Gemini 2.0 Flash (free, 15 req/min)")
    click.echo("    nvidia     — 160+ models via NVIDIA NIM (free, 1000 req/day)")
    click.echo("    ollama     — Local models, no API key needed")
    click.echo("  Paid providers:")
    click.echo("    anthropic  — Claude Sonnet (best quality)")
    click.echo("    openai     — GPT-4o")
    click.echo("    azure      — Azure OpenAI")
    click.echo()
    provider = click.prompt(
        "  Choose LLM provider",
        type=click.Choice(
            ["groq", "gemini", "nvidia", "ollama", "anthropic", "openai", "azure"],
            case_sensitive=False,
        ),
        default="groq",
    )

    provider_config = {
        "groq":      {"model": "llama-3.3-70b-versatile", "env": "GROQ_API_KEY"},
        "gemini":    {"model": "gemini-2.0-flash",        "env": "GEMINI_API_KEY"},
        "nvidia":    {"model": "meta/llama-3.1-70b-instruct", "env": "NVIDIA_API_KEY"},
        "anthropic": {"model": "claude-sonnet-4-20250514", "env": "ANTHROPIC_API_KEY"},
        "openai":    {"model": "gpt-4o-mini",             "env": "OPENAI_API_KEY"},
        "azure":     {"model": "gpt-4o",                  "env": "AZURE_OPENAI_API_KEY"},
        "ollama":    {"model": "llama3.2",                 "env": None},
    }

    pconf = provider_config[provider]
    api_key_env = pconf["env"]

    if provider == "ollama":
        click.echo("  No API key needed for Ollama (runs locally)")
        click.echo("  Make sure Ollama is running: https://ollama.com")
    else:
        api_key = click.prompt("  API key", hide_input=True)
        os.environ[api_key_env] = api_key

    config["llm"] = {
        "provider": provider,
        "model": pconf["model"],
        "api_key_env": api_key_env or "",
    }
    click.echo()

    # ── Step 2: Database ──────────────────────────────────────────────────
    click.echo(click.style("Step 2: Database", fg="cyan", bold=True))
    db_choice = click.prompt(
        "  Choose database option",
        type=click.Choice(["docker", "existing"], case_sensitive=False),
        default="docker",
    )

    if db_choice == "docker":
        click.echo("  Starting local PostgreSQL via Docker...")
        result = _run_docker_compose("up", "-d", "postgres")
        if result.returncode != 0:
            click.echo(click.style(f"  Docker error: {result.stderr.strip()}", fg="red"))
        else:
            click.echo("  PostgreSQL container started.")
        db_url = "postgresql://neurostack:neurostack@localhost:5432/neurostack"
    else:
        db_url = click.prompt("  PostgreSQL connection URL")

    config["database"] = {"url": db_url}
    click.echo()

    # ── Step 3: Vector Store ──────────────────────────────────────────────
    click.echo(click.style("Step 3: Vector Store", fg="cyan", bold=True))
    vs_choice = click.prompt(
        "  Choose vector store option",
        type=click.Choice(["docker", "existing"], case_sensitive=False),
        default="docker",
    )

    if vs_choice == "docker":
        click.echo("  Starting local Qdrant via Docker...")
        result = _run_docker_compose("up", "-d", "qdrant")
        if result.returncode != 0:
            click.echo(click.style(f"  Docker error: {result.stderr.strip()}", fg="red"))
        else:
            click.echo("  Qdrant container started.")
        vs_host = "localhost"
        vs_port = 6333
    else:
        vs_host = click.prompt("  Qdrant host", default="localhost")
        vs_port = click.prompt("  Qdrant port", default=6333, type=int)

    config["vector_store"] = {
        "provider": "qdrant",
        "host": vs_host,
        "port": vs_port,
        "collection": "neurostack",
    }
    click.echo()

    # ── Step 4: First Data Source ─────────────────────────────────────────
    click.echo(click.style("Step 4: First Data Source", fg="cyan", bold=True))
    source = click.prompt(
        "  Choose a data source",
        type=click.Choice(["csv", "jira", "slack", "google_docs"], case_sensitive=False),
        default="csv",
    )

    connector = {"type": source, "enabled": True}

    if source == "csv":
        csv_path = click.prompt("  Path to CSV file")
        connector["path"] = csv_path
    elif source == "jira":
        connector["email"] = click.prompt("  Jira email")
        connector["api_token"] = click.prompt("  Jira API token", hide_input=True)
        connector["domain"] = click.prompt("  Jira domain (e.g. myteam.atlassian.net)")
    elif source == "slack":
        connector["bot_token"] = click.prompt("  Slack bot token", hide_input=True)
    elif source == "google_docs":
        connector["credentials_path"] = click.prompt("  Path to Google credentials JSON")

    config["connectors"] = [connector]
    click.echo()

    # ── Step 5: Save config & optional test query ─────────────────────────
    config["sync"] = {
        "default_interval_minutes": 60,
        "max_concurrent": 2,
    }

    config_path = "neurostack.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    click.echo(f"Configuration saved to {click.style(config_path, bold=True)}")

    if click.confirm("\n  Would you like to test a query now?", default=False):
        query = click.prompt("  Enter a question")
        click.echo(f"\n  You asked: {query}")
        click.echo(click.style(
            "  Setup complete. Run 'neurostack ask' to query the brain "
            "once ingestion is finished.",
            fg="green",
        ))
    else:
        click.echo(click.style("\n  Setup complete!", fg="green"))

    click.echo(
        "\nNext steps:\n"
        "  1. neurostack migrate        — run database migrations\n"
        "  2. neurostack ingest <type>   — ingest your data source\n"
        "  3. neurostack ask             — start asking questions\n"
    )


# ---------------------------------------------------------------------------
# Ask (query the brain)
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("question", required=False, default=None)
def ask(question: str):
    """Query the Neurostack brain.

    Pass a QUESTION argument for single-shot mode, or omit it to enter
    an interactive REPL.
    """
    brain = _init_brain_or_none()

    if question:
        _process_question(brain, question)
    else:
        click.echo(click.style("Neurostack interactive mode", fg="cyan", bold=True))
        click.echo("Type your question and press Enter. Type 'exit' to quit.\n")
        while True:
            try:
                q = click.prompt("neurostack", prompt_suffix="> ")
            except (EOFError, KeyboardInterrupt):
                click.echo("\nGoodbye!")
                break
            if q.strip().lower() in ("exit", "quit"):
                click.echo("Goodbye!")
                break
            if not q.strip():
                continue
            _process_question(brain, q)
            click.echo()


def _init_brain_or_none():
    """Try to initialise the Brain; return None on failure."""
    try:
        from pipeline.config.loader import load_config

        cfg = load_config("neurostack.yaml")
    except Exception:
        click.echo(click.style(
            "Warning: could not load neurostack.yaml. "
            "Run 'neurostack setup' first.",
            fg="yellow",
        ))
        return None

    try:
        from brain.factory import BrainFactory
        from brain.config.brain_config import BrainConfig

        # Build real clients from pipeline config
        llm_client = _build_llm_client(cfg)
        vector_store = _build_vector_store(cfg)
        embedding_client = _build_embedding_client(cfg)

        brain_config = BrainConfig.default()
        brain = BrainFactory.create_brain(
            llm_client=llm_client,
            vector_store=vector_store,
            embedding_client=embedding_client,
            config=brain_config,
        )
        return brain
    except Exception as exc:
        click.echo(click.style(
            f"Warning: Brain could not be initialised ({exc}). "
            "Falling back to offline mode.",
            fg="yellow",
        ))
        return None


def _build_llm_client(cfg):
    """Build an LLM client from pipeline config (import at call-time)."""
    from brain.interfaces.llm import LLMClient

    provider = cfg.llm.provider
    api_key = os.environ.get(cfg.llm.api_key_env, "")

    # Try to use the concrete implementation if available
    try:
        if provider == "anthropic":
            from pipeline.llm.anthropic_client import AnthropicLLMClient
            return AnthropicLLMClient(api_key=api_key, model=cfg.llm.model)
        elif provider in ("azure_openai", "openai"):
            from pipeline.llm.openai_client import OpenAILLMClient
            return OpenAILLMClient(api_key=api_key, model=cfg.llm.model)
    except ImportError:
        pass

    raise RuntimeError(
        f"No LLM client available for provider '{provider}'. "
        "Check that the required package is installed."
    )


def _build_vector_store(cfg):
    """Build a vector-store client from pipeline config."""
    try:
        from pipeline.vectorstore.qdrant_client import QdrantVectorStore
        return QdrantVectorStore(
            host=cfg.vector_store.host,
            port=cfg.vector_store.port,
            collection=cfg.vector_store.collection,
        )
    except ImportError:
        pass

    raise RuntimeError(
        "No vector-store client available. Check that qdrant-client is installed."
    )


def _build_embedding_client(cfg):
    """Build an embedding client from pipeline config."""
    try:
        from pipeline.embedding.client import EmbeddingClientImpl
        return EmbeddingClientImpl()
    except ImportError:
        pass

    raise RuntimeError(
        "No embedding client available. Check installation."
    )


def _process_question(brain, question: str):
    """Send a question to the brain and print the result."""
    if brain is None:
        click.echo(click.style(
            "Brain is not initialised. Run 'neurostack setup' to configure.",
            fg="red",
        ))
        return

    try:
        from datetime import datetime, timezone

        raw_request = {
            "query": {"user_input": question, "query_id": "cli", "timestamp": datetime.now(timezone.utc).isoformat()},
            "context": {"tenant_id": "default", "persona": "IC", "user_id": "cli-user"},
        }
        response = brain.process(raw_request)

        # Print answer
        if response.answer:
            click.echo(click.style(response.answer.content, fg="green"))
            click.echo(click.style(
                f"  Confidence: {response.answer.confidence.value}",
                fg="yellow",
            ))
        elif response.message:
            click.echo(click.style(response.message, fg="green"))

        # Print sources
        if response.sources:
            click.echo(click.style("  Sources:", fg="cyan"))
            for src in response.sources:
                click.echo(click.style(f"    - {src.title} ({src.knowledge_type})", fg="cyan"))

        # Print warnings
        for w in response.warnings:
            click.echo(click.style(f"  Warning: {w}", fg="yellow"))

    except Exception as exc:
        click.echo(click.style(f"Error processing query: {exc}", fg="red"))


# ---------------------------------------------------------------------------
# Bot launcher
# ---------------------------------------------------------------------------

@cli.group()
def bot():
    """Bot launcher commands."""
    pass


@bot.command("slack")
def bot_slack():
    """Launch / configure the Slack bot."""
    click.echo(click.style("Slack Bot Setup", fg="cyan", bold=True))
    click.echo(
        "\nTo connect Neurostack to Slack:\n"
        "  1. Create a Slack App at https://api.slack.com/apps\n"
        "  2. Add Bot Token Scopes: chat:write, app_mentions:read, channels:history\n"
        "  3. Install the app to your workspace\n"
        "  4. Copy the Bot User OAuth Token\n"
        "  5. Set the environment variable:\n"
        "       export SLACK_BOT_TOKEN=xoxb-...\n"
        "  6. Run:  neurostack bot slack --start  (coming soon)\n"
    )


@bot.command("telegram")
def bot_telegram():
    """Launch / configure the Telegram bot."""
    click.echo(click.style("Telegram Bot Setup", fg="cyan", bold=True))
    click.echo(
        "\nTo connect Neurostack to Telegram:\n"
        "  1. Talk to @BotFather on Telegram and create a new bot\n"
        "  2. Copy the HTTP API token\n"
        "  3. Set the environment variable:\n"
        "       export TELEGRAM_BOT_TOKEN=123456:ABC-...\n"
        "  4. Run:  neurostack bot telegram --start  (coming soon)\n"
    )


if __name__ == "__main__":
    cli()
