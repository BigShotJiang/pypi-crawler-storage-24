"""
Document chunker for knowledge items.

Splits long documents into smaller chunks for better retrieval and embedding.
Different chunking strategies based on knowledge type and content structure.

Chunking is critical for:
- RAG performance (smaller chunks = better relevance)
- Embedding limits (models have max token limits)
- Context window management (LLMs have token limits)
- Granular permission enforcement (chunk-level access)

Strategies:
1. Fixed-size chunking (simple, predictable)
2. Semantic chunking (respect paragraph/sentence boundaries)
3. Structured chunking (respect document structure: headers, sections)
4. Knowledge-type-specific chunking (tasks, meetings, docs)
"""

import re
from typing import List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

from neurostack.models import Knowledge, KnowledgeType


# ============================================================================
# CHUNKING ENUMS
# ============================================================================

class ChunkingStrategy(Enum):
    """Chunking strategy"""
    FIXED_SIZE = "fixed_size"              # Fixed character/token count
    SEMANTIC = "semantic"                  # Respect sentence boundaries
    PARAGRAPH = "paragraph"                # Respect paragraph boundaries
    STRUCTURED = "structured"              # Respect document structure (headers)
    KNOWLEDGE_TYPE = "knowledge_type"      # Type-specific logic


# ============================================================================
# CHUNKING CONFIG
# ============================================================================

@dataclass
class ChunkingConfig:
    """
    Chunking configuration.
    
    Controls how documents are split into chunks.
    """
    # Size limits
    target_chunk_size: int = 500           # Target characters per chunk
    max_chunk_size: int = 1000             # Hard maximum (avoid truncation)
    min_chunk_size: int = 100              # Minimum viable chunk
    
    # Overlap for continuity
    chunk_overlap: int = 50                # Characters to overlap between chunks
    
    # Strategy
    strategy: ChunkingStrategy = ChunkingStrategy.SEMANTIC
    
    # Semantic settings
    respect_sentences: bool = True          # Don't split mid-sentence
    respect_paragraphs: bool = True         # Don't split mid-paragraph (if possible)
    
    # Structured settings
    preserve_headers: bool = True           # Keep headers with their content
    max_header_levels: int = 3              # How many header levels to preserve
    
    # Type-specific overrides
    task_max_chunk_size: int = 2000        # Tasks can be longer (usually short anyway)
    meeting_max_chunk_size: int = 1500     # Meetings can be longer
    metric_max_chunk_size: int = 500       # Metrics should be concise


# ============================================================================
# DOCUMENT CHUNKER
# ============================================================================

class DocumentChunker:
    """
    Chunks knowledge items into smaller pieces for retrieval.
    
    Different strategies based on knowledge type and content.
    
    Usage:
        chunker = DocumentChunker()
        chunks = chunker.chunk_knowledge(knowledge)
        
        # Returns list of text chunks
        for chunk in chunks:
            print(chunk[:100])  # First 100 chars
    """
    
    def __init__(self, config: Optional[ChunkingConfig] = None):
        """
        Initialize document chunker.
        
        Args:
            config: Chunking configuration (default if None)
        """
        self.config = config or ChunkingConfig()
        
        # Stats
        self.total_documents_chunked = 0
        self.total_chunks_created = 0
    
    # -------------------------
    # MAIN API
    # -------------------------
    
    def chunk_knowledge(self, knowledge: Knowledge) -> List[str]:
        """
        Chunk knowledge item into retrievable pieces.
        
        Dispatches to appropriate chunking strategy based on knowledge type.
        
        Args:
            knowledge: Knowledge item to chunk
            
        Returns:
            List of text chunks
        """
        content = knowledge.content
        
        # Short content: no chunking needed
        if len(content) <= self.config.min_chunk_size:
            self.total_documents_chunked += 1
            self.total_chunks_created += 1
            return [content]
        
        # Dispatch to type-specific chunker
        if self.config.strategy == ChunkingStrategy.KNOWLEDGE_TYPE:
            chunks = self._chunk_by_knowledge_type(knowledge)
        
        elif self.config.strategy == ChunkingStrategy.STRUCTURED:
            chunks = self._chunk_structured(content)
        
        elif self.config.strategy == ChunkingStrategy.PARAGRAPH:
            chunks = self._chunk_by_paragraph(content)
        
        elif self.config.strategy == ChunkingStrategy.SEMANTIC:
            chunks = self._chunk_semantic(content)
        
        else:  # FIXED_SIZE
            chunks = self._chunk_fixed_size(content)
        
        # Update stats
        self.total_documents_chunked += 1
        self.total_chunks_created += len(chunks)
        
        return chunks
    
    def chunk_text(
        self,
        text: str,
        strategy: Optional[ChunkingStrategy] = None
    ) -> List[str]:
        """
        Chunk arbitrary text (not tied to Knowledge object).
        
        Convenience method for standalone text chunking.
        
        Args:
            text: Text to chunk
            strategy: Optional strategy override
            
        Returns:
            List of text chunks
        """
        if strategy is None:
            strategy = self.config.strategy
        
        if len(text) <= self.config.min_chunk_size:
            return [text]
        
        if strategy == ChunkingStrategy.STRUCTURED:
            return self._chunk_structured(text)
        elif strategy == ChunkingStrategy.PARAGRAPH:
            return self._chunk_by_paragraph(text)
        elif strategy == ChunkingStrategy.SEMANTIC:
            return self._chunk_semantic(text)
        else:
            return self._chunk_fixed_size(text)
    
    # -------------------------
    # KNOWLEDGE TYPE-SPECIFIC CHUNKING
    # -------------------------
    
    def _chunk_by_knowledge_type(self, knowledge: Knowledge) -> List[str]:
        """
        Chunk based on knowledge type.
        
        Different types have different optimal chunking strategies.
        
        Args:
            knowledge: Knowledge item
            
        Returns:
            List of chunks
        """
        content = knowledge.content
        knowledge_type = knowledge.type
        
        # TASK: Usually short, chunk by sections if long
        if knowledge_type == KnowledgeType.TASK:
            return self._chunk_task(content)
        
        # MEETING: Chunk by topics or speakers
        elif knowledge_type == KnowledgeType.MEETING:
            return self._chunk_meeting(content)
        
        # DOCUMENT: Structured chunking (respect headers)
        elif knowledge_type == KnowledgeType.DOCUMENT:
            return self._chunk_structured(content)
        
        # DECISION: Usually concise, minimal chunking
        elif knowledge_type == KnowledgeType.DECISION:
            return self._chunk_decision(content)
        
        # METRIC: Usually very short, no chunking
        elif knowledge_type == KnowledgeType.METRIC:
            return [content]  # Metrics are atomic
        
        # EVENT: Usually short, minimal chunking
        elif knowledge_type == KnowledgeType.EVENT:
            return self._chunk_by_paragraph(content)
        
        # FACT: Always atomic
        elif knowledge_type == KnowledgeType.FACT:
            return [content]
        
        # Default: semantic chunking
        else:
            return self._chunk_semantic(content)
    
    def _chunk_task(self, content: str) -> List[str]:
        """
        Chunk task content.
        
        Tasks typically have: Title, Description, Comments
        Keep logical sections together.
        """
        # Check if content has clear sections
        if self._has_sections(content):
            return self._chunk_by_sections(content)
        else:
            # Simple paragraph-based chunking
            return self._chunk_by_paragraph(
                content,
                max_size=self.config.task_max_chunk_size
            )
    
    def _chunk_meeting(self, content: str) -> List[str]:
        """
        Chunk meeting notes.
        
        Meetings typically have: Agenda items, Discussion, Decisions
        """
        # Try to chunk by agenda items or sections
        if self._has_sections(content):
            return self._chunk_by_sections(content)
        else:
            return self._chunk_by_paragraph(
                content,
                max_size=self.config.meeting_max_chunk_size
            )
    
    def _chunk_decision(self, content: str) -> List[str]:
        """
        Chunk decision records.
        
        Decisions typically have: Context, Decision, Rationale
        Keep decision context together.
        """
        # Decisions should usually fit in one chunk
        if len(content) <= self.config.max_chunk_size:
            return [content]
        else:
            # If too long, split by paragraphs
            return self._chunk_by_paragraph(content)
    
    # -------------------------
    # STRUCTURED CHUNKING
    # -------------------------
    
    def _chunk_structured(self, text: str) -> List[str]:
        """
        Chunk based on document structure (headers, sections).
        
        Respects markdown/text structure:
        - # Headers
        - ## Subheaders
        - Paragraphs
        
        Args:
            text: Document text
            
        Returns:
            List of chunks
        """
        # Detect headers
        sections = self._split_by_headers(text)
        
        if len(sections) <= 1:
            # No clear structure, fall back to paragraph chunking
            return self._chunk_by_paragraph(text)
        
        chunks = []
        
        for header, section_text in sections:
            # Each section: header + content
            section_content = header + "\n\n" + section_text if header else section_text
            
            # If section fits in one chunk, keep it
            if len(section_content) <= self.config.max_chunk_size:
                chunks.append(section_content)
            else:
                # Section too long, split further by paragraphs
                section_chunks = self._chunk_by_paragraph(section_content)
                chunks.extend(section_chunks)
        
        return chunks
    
    def _split_by_headers(self, text: str) -> List[Tuple[str, str]]:
        """
        Split text by markdown headers.
        
        Returns list of (header, content) tuples.
        """
        # Pattern for markdown headers (# Header)
        header_pattern = r'^(#{1,6})\s+(.+)$'
        
        lines = text.split('\n')
        sections = []
        current_header = ""
        current_content = []
        
        for line in lines:
            match = re.match(header_pattern, line)
            if match:
                # Save previous section
                if current_content or current_header:
                    sections.append((
                        current_header,
                        '\n'.join(current_content).strip()
                    ))
                
                # Start new section
                current_header = line
                current_content = []
            else:
                current_content.append(line)
        
        # Save last section
        if current_content or current_header:
            sections.append((
                current_header,
                '\n'.join(current_content).strip()
            ))
        
        return sections
    
    def _has_sections(self, text: str) -> bool:
        """Check if text has clear section markers"""
        # Check for markdown headers
        if re.search(r'^#{1,6}\s+', text, re.MULTILINE):
            return True
        
        # Check for common section patterns
        section_patterns = [
            r'^\*\*[A-Z][^*]+\*\*',  # **Section Title**
            r'^[A-Z][^:]+:',          # Title:
            r'^\d+\.',                # 1. Numbered
        ]
        
        for pattern in section_patterns:
            if re.search(pattern, text, re.MULTILINE):
                return True
        
        return False
    
    def _chunk_by_sections(self, text: str) -> List[str]:
        """
        Chunk by detected sections.
        
        Tries multiple section detection patterns.
        """
        # Try markdown headers first
        sections = self._split_by_headers(text)
        
        if len(sections) > 1:
            chunks = []
            for header, content in sections:
                section_text = header + "\n\n" + content if header else content
                
                if len(section_text) <= self.config.max_chunk_size:
                    chunks.append(section_text)
                else:
                    # Further split large sections
                    sub_chunks = self._chunk_by_paragraph(section_text)
                    chunks.extend(sub_chunks)
            
            return chunks
        
        # Fallback to paragraph chunking
        return self._chunk_by_paragraph(text)
    
    # -------------------------
    # PARAGRAPH CHUNKING
    # -------------------------
    
    def _chunk_by_paragraph(
        self,
        text: str,
        max_size: Optional[int] = None
    ) -> List[str]:
        """
        Chunk by paragraphs (respects paragraph boundaries).
        
        Combines paragraphs until reaching target size.
        
        Args:
            text: Text to chunk
            max_size: Optional max chunk size override
            
        Returns:
            List of chunks
        """
        if max_size is None:
            max_size = self.config.max_chunk_size
        
        target_size = self.config.target_chunk_size
        overlap = self.config.chunk_overlap
        
        # Split into paragraphs (double newline)
        paragraphs = re.split(r'\n\s*\n', text)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]
        
        if not paragraphs:
            return [text]
        
        chunks = []
        current_chunk = []
        current_size = 0
        
        for para in paragraphs:
            para_size = len(para)
            
            # If single paragraph exceeds max size, split it
            if para_size > max_size:
                # Save current chunk if not empty
                if current_chunk:
                    chunks.append('\n\n'.join(current_chunk))
                    current_chunk = []
                    current_size = 0
                
                # Split oversized paragraph
                para_chunks = self._chunk_semantic(para, max_size=max_size)
                chunks.extend(para_chunks)
                continue
            
            # Check if adding this paragraph would exceed target
            if current_size + para_size > target_size and current_chunk:
                # Save current chunk
                chunks.append('\n\n'.join(current_chunk))
                
                # Start new chunk with overlap
                if overlap > 0 and current_chunk:
                    # Include last paragraph for continuity
                    current_chunk = [current_chunk[-1], para]
                    current_size = len(current_chunk[-2]) + para_size
                else:
                    current_chunk = [para]
                    current_size = para_size
            else:
                # Add paragraph to current chunk
                current_chunk.append(para)
                current_size += para_size
        
        # Save last chunk
        if current_chunk:
            chunks.append('\n\n'.join(current_chunk))
        
        return chunks
    
    # -------------------------
    # SEMANTIC CHUNKING
    # -------------------------
    
    def _chunk_semantic(
        self,
        text: str,
        max_size: Optional[int] = None
    ) -> List[str]:
        """
        Semantic chunking (respects sentence boundaries).
        
        Splits at sentence boundaries, never mid-sentence.
        
        Args:
            text: Text to chunk
            max_size: Optional max chunk size override
            
        Returns:
            List of chunks
        """
        if max_size is None:
            max_size = self.config.max_chunk_size
        
        target_size = self.config.target_chunk_size
        overlap = self.config.chunk_overlap
        
        # Split into sentences
        sentences = self._split_sentences(text)
        
        if not sentences:
            return [text]
        
        chunks = []
        current_chunk = []
        current_size = 0
        
        for sentence in sentences:
            sentence_size = len(sentence)
            
            # If single sentence exceeds max size, split it (last resort)
            if sentence_size > max_size:
                # Save current chunk
                if current_chunk:
                    chunks.append(' '.join(current_chunk))
                    current_chunk = []
                    current_size = 0
                
                # Force split oversized sentence
                forced_chunks = self._chunk_fixed_size(sentence, max_size=max_size)
                chunks.extend(forced_chunks)
                continue
            
            # Check if adding this sentence would exceed target
            if current_size + sentence_size > target_size and current_chunk:
                # Save current chunk
                chunks.append(' '.join(current_chunk))
                
                # Start new chunk with overlap
                if overlap > 0 and current_chunk:
                    # Include last sentence for continuity
                    overlap_sentences = []
                    overlap_size = 0
                    for sent in reversed(current_chunk):
                        if overlap_size + len(sent) <= overlap:
                            overlap_sentences.insert(0, sent)
                            overlap_size += len(sent)
                        else:
                            break
                    
                    current_chunk = overlap_sentences + [sentence]
                    current_size = overlap_size + sentence_size
                else:
                    current_chunk = [sentence]
                    current_size = sentence_size
            else:
                # Add sentence to current chunk
                current_chunk.append(sentence)
                current_size += sentence_size
        
        # Save last chunk
        if current_chunk:
            chunks.append(' '.join(current_chunk))
        
        return chunks
    
    def _split_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences.
        
        Uses simple heuristic (. ! ?) with basic rules.
        Production would use NLTK or spaCy.
        """
        # Simple sentence splitting (improved)
        # Handles common cases: Mr. Dr. etc.
        
        # Replace common abbreviations to avoid false splits
        text = re.sub(r'\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr)\.', r'\1<DOT>', text)
        
        # Split on sentence terminators
        sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text)
        
        # Restore abbreviations
        sentences = [s.replace('<DOT>', '.') for s in sentences]
        
        # Clean up
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return sentences
    
    # -------------------------
    # FIXED-SIZE CHUNKING
    # -------------------------
    
    def _chunk_fixed_size(
        self,
        text: str,
        max_size: Optional[int] = None
    ) -> List[str]:
        """
        Fixed-size chunking (simple character-based).
        
        Splits text into fixed-size chunks with optional overlap.
        Fast but may split mid-word or mid-sentence.
        
        Args:
            text: Text to chunk
            max_size: Optional max chunk size override
            
        Returns:
            List of chunks
        """
        if max_size is None:
            max_size = self.config.max_chunk_size
        
        target_size = self.config.target_chunk_size
        overlap = self.config.chunk_overlap
        
        if len(text) <= target_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + target_size
            
            # Try to avoid splitting mid-word
            if end < len(text):
                # Find last whitespace before end
                last_space = text.rfind(' ', start, end)
                if last_space > start:
                    end = last_space
            
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            # Move start with overlap
            start = end - overlap if overlap > 0 else end
        
        return chunks
    
    # -------------------------
    # UTILITIES
    # -------------------------
    
    def estimate_chunks(self, text: str) -> int:
        """
        Estimate number of chunks without actually chunking.
        
        Useful for resource planning.
        
        Args:
            text: Text to estimate
            
        Returns:
            Estimated number of chunks
        """
        if len(text) <= self.config.min_chunk_size:
            return 1
        
        # Simple estimate based on target chunk size
        estimated = (len(text) // self.config.target_chunk_size) + 1
        return estimated
    
    def get_chunk_stats(self, chunks: List[str]) -> dict:
        """
        Get statistics about chunks.
        
        Args:
            chunks: List of chunks
            
        Returns:
            Dictionary with stats
        """
        if not chunks:
            return {
                "count": 0,
                "total_size": 0,
                "avg_size": 0,
                "min_size": 0,
                "max_size": 0
            }
        
        sizes = [len(c) for c in chunks]
        
        return {
            "count": len(chunks),
            "total_size": sum(sizes),
            "avg_size": sum(sizes) / len(sizes),
            "min_size": min(sizes),
            "max_size": max(sizes)
        }
    
    def get_stats(self) -> dict:
        """
        Get chunker statistics.
        
        Returns:
            Dictionary with stats
        """
        avg_chunks_per_doc = (
            self.total_chunks_created / self.total_documents_chunked
            if self.total_documents_chunked > 0
            else 0
        )
        
        return {
            "total_documents_chunked": self.total_documents_chunked,
            "total_chunks_created": self.total_chunks_created,
            "avg_chunks_per_document": avg_chunks_per_doc
        }


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def chunk_text_simple(
    text: str,
    chunk_size: int = 500,
    overlap: int = 50
) -> List[str]:
    """
    Simple text chunking (convenience function).
    
    Args:
        text: Text to chunk
        chunk_size: Target chunk size
        overlap: Overlap between chunks
        
    Returns:
        List of chunks
    """
    config = ChunkingConfig(
        target_chunk_size=chunk_size,
        chunk_overlap=overlap,
        strategy=ChunkingStrategy.SEMANTIC
    )
    
    chunker = DocumentChunker(config)
    return chunker.chunk_text(text)


def estimate_token_count(text: str, chars_per_token: float = 4.0) -> int:
    """
    Estimate token count from character count.
    
    Rough heuristic: ~4 characters per token for English text.
    
    Args:
        text: Text to estimate
        chars_per_token: Characters per token ratio
        
    Returns:
        Estimated token count
    """
    return int(len(text) / chars_per_token)


def chunk_to_token_limit(
    text: str,
    max_tokens: int = 512,
    chars_per_token: float = 4.0
) -> List[str]:
    """
    Chunk text to fit within token limit.
    
    Useful for embedding models with token limits.
    
    Args:
        text: Text to chunk
        max_tokens: Maximum tokens per chunk
        chars_per_token: Characters per token ratio
        
    Returns:
        List of chunks
    """
    # Convert token limit to character limit
    max_chars = int(max_tokens * chars_per_token)
    
    config = ChunkingConfig(
        target_chunk_size=int(max_chars * 0.8),  # 80% of max for safety
        max_chunk_size=max_chars,
        strategy=ChunkingStrategy.SEMANTIC
    )
    
    chunker = DocumentChunker(config)
    return chunker.chunk_text(text)


def split_by_delimiter(
    text: str,
    delimiter: str = '\n\n',
    max_chunk_size: int = 1000
) -> List[str]:
    """
    Split text by delimiter with size limit.
    
    Args:
        text: Text to split
        delimiter: Delimiter to split on
        max_chunk_size: Maximum chunk size
        
    Returns:
        List of chunks
    """
    parts = text.split(delimiter)
    chunks = []
    current_chunk = []
    current_size = 0
    
    for part in parts:
        part = part.strip()
        if not part:
            continue
        
        part_size = len(part)
        
        if part_size > max_chunk_size:
            # Save current chunk
            if current_chunk:
                chunks.append(delimiter.join(current_chunk))
                current_chunk = []
                current_size = 0
            
            # Split oversized part
            chunker = DocumentChunker()
            sub_chunks = chunker.chunk_text(part)
            chunks.extend(sub_chunks)
        
        elif current_size + part_size > max_chunk_size:
            # Save current chunk
            chunks.append(delimiter.join(current_chunk))
            current_chunk = [part]
            current_size = part_size
        else:
            current_chunk.append(part)
            current_size += part_size
    
    # Save last chunk
    if current_chunk:
        chunks.append(delimiter.join(current_chunk))
    
    return chunks


# ============================================================================
# SPECIALIZED CHUNKERS
# ============================================================================

class CodeChunker:
    """
    Specialized chunker for code files.
    
    Respects function/class boundaries, preserves syntax.
    """
    
    def chunk_code(self, code: str, language: str = "python") -> List[str]:
        """
        Chunk code file intelligently.
        
        For MVP: simple function-based splitting.
        Production: use language-specific parsers (AST).
        
        Args:
            code: Code text
            language: Programming language
            
        Returns:
            List of code chunks
        """
        if language == "python":
            return self._chunk_python(code)
        else:
            # Fallback to simple chunking
            return chunk_text_simple(code, chunk_size=1000)
    
    def _chunk_python(self, code: str) -> List[str]:
        """Chunk Python code by functions/classes"""
        # Simple pattern: split on 'def ' and 'class ' at line start
        chunks = []
        current_chunk = []
        
        for line in code.split('\n'):
            # Detect function/class definition
            if re.match(r'^(def |class )', line):
                if current_chunk:
                    chunks.append('\n'.join(current_chunk))
                current_chunk = [line]
            else:
                current_chunk.append(line)
        
        if current_chunk:
            chunks.append('\n'.join(current_chunk))
        
        return chunks


class TableChunker:
    """
    Specialized chunker for tables/CSV data.
    
    Preserves table structure, chunks by rows.
    """
    
    def chunk_table(
        self,
        table_text: str,
        rows_per_chunk: int = 50
    ) -> List[str]:
        """
        Chunk table data by rows.
        
        Args:
            table_text: Table as text (CSV, TSV, markdown)
            rows_per_chunk: Rows per chunk
            
        Returns:
            List of table chunks
        """
        lines = table_text.split('\n')
        
        # Assume first line is header
        header = lines[0] if lines else ""
        data_lines = lines[1:] if len(lines) > 1 else []
        
        chunks = []
        
        for i in range(0, len(data_lines), rows_per_chunk):
            chunk_lines = [header] + data_lines[i:i + rows_per_chunk]
            chunks.append('\n'.join(chunk_lines))
        
        return chunks