"""
Mock embedding client for testing.

Provides a fast, deterministic embedding implementation that doesn't
require API calls or external dependencies. Useful for:
- Unit tests
- Integration tests
- Development without API costs
- CI/CD pipelines
- Offline development

The mock generates realistic-looking embeddings using simple algorithms
that preserve basic semantic properties (same text = same embedding).

Features:
- Deterministic (same input = same output)
- Fast (no network calls)
- Configurable dimensions
- Simulates token counting
- Zero cost
- Thread-safe
"""

import hashlib
import logging
import math
from typing import List, Optional, Dict, Any
import random

from .embedding_client import (
    EmbeddingClient,
    EmbeddingConfig,
    EmbeddingProvider,
    EmbeddingModel
)
from ...utils.exceptions import EmbeddingError

logger = logging.getLogger("neurostack.pipeline.processing.embeddings.mock")


# ============================================================================
# MOCK EMBEDDING CLIENT
# ============================================================================

class MockEmbeddingClient(EmbeddingClient):
    """
    Mock embedding client for testing.
    
    Generates deterministic pseudo-embeddings using hash-based approach.
    Same text always produces same embedding, different texts produce
    different embeddings with realistic distribution.
    
    Algorithm:
    1. Hash text content (MD5)
    2. Use hash to seed random number generator
    3. Generate vector with unit norm
    4. Add small perturbations for realism
    
    Properties:
    - Deterministic (reproducible)
    - Fast (no I/O)
    - Cosine similarity preserved for identical texts
    - Different texts have realistic similarity distribution
    
    Usage:
        config = EmbeddingConfig(
            provider=EmbeddingProvider.MOCK,
            model=EmbeddingModel.MOCK
        )
        
        client = MockEmbeddingClient(config)
        
        # Same as real client
        result = client.embed("Hello world")
        batch_result = client.embed_batch(["text1", "text2"])
    """
    
    # Default settings
    DEFAULT_DIMENSIONS = 384  # Smaller than real models for speed
    CHARS_PER_TOKEN = 4.0     # Approximate token counting
    
    def __init__(self, config: EmbeddingConfig):
        """
        Initialize mock embedding client.
        
        Args:
            config: Embedding configuration
        """
        # Validate config
        if config.provider != EmbeddingProvider.MOCK:
            raise ValueError(f"Expected MOCK provider, got {config.provider}")
        
        super().__init__(config)
        
        # Mock-specific settings
        self.dimensions = config.model.get_dimensions()
        
        # Embedding generation parameters
        self.seed_multiplier = 12345  # For hash-to-seed conversion
        self.noise_factor = 0.01      # Small noise for realism
        
        logger.info(f"Initialized with {self.dimensions} dimensions")
    
    # -------------------------
    # ABSTRACT METHOD IMPLEMENTATIONS
    # -------------------------
    
    def _generate_embedding(self, text: str) -> List[float]:
        """
        Generate deterministic mock embedding for text.
        
        Uses hash-based seeding for reproducibility.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        # Generate seed from text hash
        seed = self._text_to_seed(text)
        
        # Generate vector
        vector = self._generate_vector_from_seed(seed, self.dimensions)
        
        return vector
    
    def _generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate mock embeddings for batch.
        
        Simply calls single embedding for each text (no network overhead).
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        return [self._generate_embedding(text) for text in texts]
    
    def count_tokens(self, text: str) -> int:
        """
        Mock token counting using character-based heuristic.
        
        Args:
            text: Text to tokenize
            
        Returns:
            Estimated token count
        """
        # Simple estimate: chars / 4
        return max(1, int(len(text) / self.CHARS_PER_TOKEN))
    
    # -------------------------
    # MOCK-SPECIFIC METHODS
    # -------------------------
    
    def _text_to_seed(self, text: str) -> int:
        """
        Convert text to deterministic seed.
        
        Uses MD5 hash for reproducibility.
        
        Args:
            text: Input text
            
        Returns:
            Integer seed
        """
        # Hash text
        hash_obj = hashlib.md5(text.encode('utf-8'))
        hash_hex = hash_obj.hexdigest()
        
        # Convert to integer seed
        seed = int(hash_hex[:8], 16) % (2**31 - 1)
        
        return seed
    
    def _generate_vector_from_seed(
        self,
        seed: int,
        dimensions: int
    ) -> List[float]:
        """
        Generate unit-normalized vector from seed.
        
        Uses random number generator seeded with hash for reproducibility.
        
        Args:
            seed: Random seed
            dimensions: Vector dimensions
            
        Returns:
            Unit-normalized vector
        """
        # Create seeded random generator
        rng = random.Random(seed)
        
        # Generate random vector
        vector = [rng.gauss(0, 1) for _ in range(dimensions)]
        
        # Normalize to unit length (cosine similarity friendly)
        magnitude = math.sqrt(sum(x * x for x in vector))
        
        if magnitude > 0:
            vector = [x / magnitude for x in vector]
        
        # Add tiny noise for realism (still deterministic)
        noise_rng = random.Random(seed + self.seed_multiplier)
        vector = [
            x + noise_rng.gauss(0, self.noise_factor)
            for x in vector
        ]
        
        # Re-normalize after noise
        magnitude = math.sqrt(sum(x * x for x in vector))
        if magnitude > 0:
            vector = [x / magnitude for x in vector]
        
        return vector
    
    # -------------------------
    # TESTING HELPERS
    # -------------------------
    
    def generate_similar_embedding(
        self,
        reference_text: str,
        similarity: float = 0.9
    ) -> List[float]:
        """
        Generate embedding similar to reference.
        
        Useful for testing similarity search.
        
        Args:
            reference_text: Reference text
            similarity: Target cosine similarity (0-1)
            
        Returns:
            Similar embedding vector
        """
        # Generate reference embedding
        ref_vector = self._generate_embedding(reference_text)
        
        # Generate random orthogonal component
        seed = self._text_to_seed(reference_text + "_similar")
        rng = random.Random(seed)
        ortho_vector = [rng.gauss(0, 1) for _ in range(self.dimensions)]
        
        # Normalize orthogonal vector
        magnitude = math.sqrt(sum(x * x for x in ortho_vector))
        if magnitude > 0:
            ortho_vector = [x / magnitude for x in ortho_vector]
        
        # Mix reference and orthogonal to achieve target similarity
        # similarity = cos(angle) = dot(v1, v2)
        # We want: new_vector = similarity * ref_vector + sqrt(1 - similarity^2) * ortho_vector
        
        weight_ref = similarity
        weight_ortho = math.sqrt(max(0, 1 - similarity * similarity))
        
        similar_vector = [
            weight_ref * ref + weight_ortho * orth
            for ref, orth in zip(ref_vector, ortho_vector)
        ]
        
        # Normalize
        magnitude = math.sqrt(sum(x * x for x in similar_vector))
        if magnitude > 0:
            similar_vector = [x / magnitude for x in similar_vector]
        
        return similar_vector
    
    def set_noise_factor(self, noise_factor: float) -> None:
        """
        Set noise factor for embedding generation.
        
        Args:
            noise_factor: Noise standard deviation (default 0.01)
        """
        self.noise_factor = noise_factor
    
    def get_embedding_distribution_stats(
        self,
        sample_texts: List[str]
    ) -> Dict[str, Any]:
        """
        Get statistics about embedding distribution.
        
        Useful for testing/validation.
        
        Args:
            sample_texts: Sample texts to analyze
            
        Returns:
            Dictionary with distribution stats
        """
        embeddings = [self._generate_embedding(t) for t in sample_texts]
        
        # Calculate pairwise similarities
        similarities = []
        for i in range(len(embeddings)):
            for j in range(i + 1, len(embeddings)):
                sim = self._cosine_similarity(embeddings[i], embeddings[j])
                similarities.append(sim)
        
        if not similarities:
            return {"error": "Need at least 2 texts"}
        
        # Stats
        avg_similarity = sum(similarities) / len(similarities)
        min_similarity = min(similarities)
        max_similarity = max(similarities)
        
        return {
            "num_samples": len(sample_texts),
            "dimensions": self.dimensions,
            "avg_pairwise_similarity": round(avg_similarity, 3),
            "min_similarity": round(min_similarity, 3),
            "max_similarity": round(max_similarity, 3),
            "num_comparisons": len(similarities)
        }
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between vectors"""
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        mag1 = math.sqrt(sum(a * a for a in vec1))
        mag2 = math.sqrt(sum(b * b for b in vec2))
        
        if mag1 == 0 or mag2 == 0:
            return 0.0
        
        return dot_product / (mag1 * mag2)
    
    # -------------------------
    # TESTING UTILITIES
    # -------------------------
    
    def verify_determinism(self, text: str, iterations: int = 10) -> bool:
        """
        Verify embeddings are deterministic.
        
        Args:
            text: Test text
            iterations: Number of iterations to test
            
        Returns:
            True if all embeddings identical
        """
        embeddings = [self._generate_embedding(text) for _ in range(iterations)]
        
        # Check all identical
        first = embeddings[0]
        
        for emb in embeddings[1:]:
            if emb != first:
                return False
        
        return True
    
    def verify_uniqueness(self, texts: List[str]) -> bool:
        """
        Verify different texts produce different embeddings.
        
        Args:
            texts: List of different texts
            
        Returns:
            True if all embeddings unique
        """
        embeddings = [self._generate_embedding(t) for t in texts]
        
        # Check pairwise
        for i in range(len(embeddings)):
            for j in range(i + 1, len(embeddings)):
                if embeddings[i] == embeddings[j]:
                    return False
        
        return True
    
    def create_test_dataset(
        self,
        num_texts: int = 100,
        text_length: int = 50
    ) -> List[str]:
        """
        Create synthetic test dataset.
        
        Args:
            num_texts: Number of texts to generate
            text_length: Average text length
            
        Returns:
            List of synthetic texts
        """
        texts = []
        
        for i in range(num_texts):
            # Generate pseudo-random text
            words = []
            rng = random.Random(i)
            
            num_words = max(1, int(rng.gauss(text_length / 5, 5)))
            
            for _ in range(num_words):
                # Generate random word (5-10 chars)
                word_len = rng.randint(5, 10)
                word = ''.join(rng.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(word_len))
                words.append(word)
            
            text = ' '.join(words)
            texts.append(text)
        
        return texts


# ============================================================================
# TESTING HELPERS
# ============================================================================

def create_mock_client(
    dimensions: int = 384,
    **kwargs
) -> MockEmbeddingClient:
    """
    Helper to create mock embedding client.
    
    Args:
        dimensions: Embedding dimensions
        **kwargs: Additional config parameters
        
    Returns:
        MockEmbeddingClient instance
    """
    # Create custom mock model with specified dimensions
    class CustomMockModel(EmbeddingModel):
        def get_dimensions(self) -> int:
            return dimensions
        
        def get_max_tokens(self) -> int:
            return 512
        
        def get_cost_per_1k_tokens(self) -> float:
            return 0.0
    
    config = EmbeddingConfig(
        provider=EmbeddingProvider.MOCK,
        model=EmbeddingModel.MOCK,
        **kwargs
    )
    
    client = MockEmbeddingClient(config)
    client.dimensions = dimensions  # Override
    
    return client


def generate_test_embeddings(
    num_embeddings: int = 100,
    dimensions: int = 384,
    include_duplicates: bool = False
) -> List[List[float]]:
    """
    Generate test embeddings for benchmarking/testing.
    
    Args:
        num_embeddings: Number of embeddings to generate
        dimensions: Embedding dimensions
        include_duplicates: Whether to include some duplicates
        
    Returns:
        List of embedding vectors
    """
    client = create_mock_client(dimensions=dimensions)
    
    # Generate texts
    texts = []
    for i in range(num_embeddings):
        if include_duplicates and i % 10 == 0 and i > 0:
            # Reuse previous text (creates duplicate)
            texts.append(texts[i - 1])
        else:
            texts.append(f"test_text_{i}")
    
    # Generate embeddings
    result = client.embed_batch(texts)
    
    return [emb.vector for emb in result.embeddings]


def benchmark_mock_performance(
    num_texts: int = 1000,
    dimensions: int = 384
) -> Dict[str, Any]:
    """
    Benchmark mock embedding client performance.
    
    Args:
        num_texts: Number of texts to process
        dimensions: Embedding dimensions
        
    Returns:
        Dictionary with benchmark results
    """
    import time
    
    client = create_mock_client(dimensions=dimensions)
    
    # Create test dataset
    texts = client.create_test_dataset(num_texts)
    
    # Benchmark single embedding
    start = time.time()
    for text in texts[:100]:
        client.embed(text)
    single_time = time.time() - start
    
    # Benchmark batch embedding
    start = time.time()
    client.embed_batch(texts)
    batch_time = time.time() - start
    
    return {
        "num_texts": num_texts,
        "dimensions": dimensions,
        "single_embedding_time_avg_ms": (single_time / 100) * 1000,
        "batch_embedding_time_total_s": batch_time,
        "embeddings_per_second": num_texts / batch_time,
        "speedup_vs_single": (single_time * num_texts / 100) / batch_time
    }


# ============================================================================
# SIMILARITY TESTING
# ============================================================================

class MockSimilarityTester:
    """
    Helper for testing similarity search with mock embeddings.
    
    Generates realistic test datasets with known similarity patterns.
    """
    
    def __init__(self, dimensions: int = 384):
        """
        Initialize similarity tester.
        
        Args:
            dimensions: Embedding dimensions
        """
        self.client = create_mock_client(dimensions=dimensions)
        self.dimensions = dimensions
    
    def create_similar_cluster(
        self,
        base_text: str,
        cluster_size: int = 10,
        similarity_range: tuple = (0.8, 0.95)
    ) -> List[tuple[str, List[float]]]:
        """
        Create cluster of similar embeddings.
        
        Args:
            base_text: Base text for cluster
            cluster_size: Number of similar texts
            similarity_range: (min_similarity, max_similarity)
            
        Returns:
            List of (text, embedding) tuples
        """
        cluster = [(base_text, self.client.embed(base_text).vector)]
        
        min_sim, max_sim = similarity_range
        
        for i in range(1, cluster_size):
            # Generate similar text
            similar_text = f"{base_text}_similar_{i}"
            
            # Target similarity
            target_sim = min_sim + (max_sim - min_sim) * (i / cluster_size)
            
            # Generate similar embedding
            similar_emb = self.client.generate_similar_embedding(
                base_text,
                similarity=target_sim
            )
            
            cluster.append((similar_text, similar_emb))
        
        return cluster
    
    def create_multi_cluster_dataset(
        self,
        num_clusters: int = 5,
        cluster_size: int = 10
    ) -> List[tuple[str, List[float], int]]:
        """
        Create dataset with multiple similarity clusters.
        
        Args:
            num_clusters: Number of clusters
            cluster_size: Texts per cluster
            
        Returns:
            List of (text, embedding, cluster_id) tuples
        """
        dataset = []
        
        for cluster_id in range(num_clusters):
            base_text = f"cluster_{cluster_id}_base"
            
            cluster = self.create_similar_cluster(
                base_text,
                cluster_size
            )
            
            for text, embedding in cluster:
                dataset.append((text, embedding, cluster_id))
        
        return dataset
    
    def test_similarity_search(
        self,
        query_text: str,
        candidates: List[tuple[str, List[float]]],
        top_k: int = 5
    ) -> List[tuple[str, float]]:
        """
        Test similarity search.
        
        Args:
            query_text: Query text
            candidates: List of (text, embedding) tuples
            top_k: Number of results
            
        Returns:
            List of (text, similarity) tuples
        """
        query_emb = self.client.embed(query_text).vector
        
        # Calculate similarities
        similarities = []
        for text, candidate_emb in candidates:
            sim = self._cosine_similarity(query_emb, candidate_emb)
            similarities.append((text, sim))
        
        # Sort by similarity
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        return similarities[:top_k]
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity"""
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        mag1 = math.sqrt(sum(a * a for a in vec1))
        mag2 = math.sqrt(sum(b * b for b in vec2))
        
        if mag1 == 0 or mag2 == 0:
            return 0.0
        
        return dot_product / (mag1 * mag2)


# ============================================================================
# PYTEST FIXTURES (for testing)
# ============================================================================

def pytest_mock_embedding_client():
    """
    Pytest fixture for mock embedding client.
    
    Usage in tests:
        def test_something(mock_embedding_client):
            result = mock_embedding_client.embed("test")
            assert len(result.vector) == 384
    """
    return create_mock_client()


def pytest_mock_embeddings_batch():
    """
    Pytest fixture for batch of mock embeddings.
    
    Returns 100 pre-generated embeddings.
    """
    return generate_test_embeddings(num_embeddings=100)


# ============================================================================
# VALIDATION
# ============================================================================

def validate_mock_embeddings():
    """
    Validate mock embedding client correctness.
    
    Runs a series of tests to ensure mock behaves correctly.
    
    Returns:
        True if all tests pass
    """
    client = create_mock_client()
    
    logger.info("Testing mock embedding client...")

    # Test 1: Determinism
    logger.info("Test 1: Determinism")
    assert client.verify_determinism("test text"), "Failed: Not deterministic"

    # Test 2: Uniqueness
    logger.info("Test 2: Uniqueness")
    test_texts = ["text1", "text2", "text3", "different", "unique"]
    assert client.verify_uniqueness(test_texts), "Failed: Not unique"

    # Test 3: Dimensions
    logger.info("Test 3: Dimensions")
    result = client.embed("test")
    assert len(result.vector) == client.dimensions, "Failed: Wrong dimensions"

    # Test 4: Normalization
    logger.info("Test 4: Unit normalization")
    magnitude = math.sqrt(sum(x * x for x in result.vector))
    assert abs(magnitude - 1.0) < 0.01, "Failed: Not normalized"

    # Test 5: Batch consistency
    logger.info("Test 5: Batch consistency")
    texts = ["a", "b", "c"]
    single_results = [client.embed(t).vector for t in texts]
    batch_results = [r.vector for r in client.embed_batch(texts).embeddings]
    assert single_results == batch_results, "Failed: Batch inconsistent"

    # Test 6: Similarity generation
    logger.info("Test 6: Similar embedding generation")
    base = "reference text"
    similar = client.generate_similar_embedding(base, similarity=0.9)
    base_emb = client.embed(base).vector

    # Calculate actual similarity
    sim = client._cosine_similarity(base_emb, similar)
    assert abs(sim - 0.9) < 0.1, f"Failed: Expected ~0.9, got {sim}"

    logger.info("All tests passed!")
    return True


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    # Run validation when module executed directly
    validate_mock_embeddings()

    # Run benchmark
    logger.info("Running performance test...")
    results = benchmark_mock_performance(num_texts=1000)

    logger.info(f"Processed {results['num_texts']} texts")
    logger.info(f"Rate: {results['embeddings_per_second']:.0f} embeddings/second")
    logger.info(f"Batch speedup: {results['speedup_vs_single']:.1f}x vs single")